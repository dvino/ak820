                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000027                        587 _process_action_sloc0_1_0:
      000027                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      000813                        615 _tp_buttons::
      000813                        616 	.ds 2
      000815                        617 _action_exec_PARM_1:
      000815                        618 	.ds 6
      00081B                        619 _action_exec_record_10001_625:
      00081B                        620 	.ds 9
      000824                        621 _ak820_action_exec_event_10000_629:
      000824                        622 	.ds 2
      000826                        623 _ak820_action_exec_snapshot_10000_630:
      000826                        624 	.ds 6
      00082C                        625 _process_record_record_argument_10000_633:
      00082C                        626 	.ds 2
      00082E                        627 _process_record_handler_record_argument_10000_641:
      00082E                        628 	.ds 2
      000830                        629 _process_record_handler_action_10000_642:
      000830                        630 	.ds 2
      000832                        631 _process_action_PARM_2:
      000832                        632 	.ds 2
      000834                        633 _process_action_record_argument_10000_653:
      000834                        634 	.ds 2
      000836                        635 _process_action_on_40000_676:
      000836                        636 	.ds 1
      000837                        637 _register_code_code_10000_710:
      000837                        638 	.ds 1
      000838                        639 _unregister_code_code_10000_724:
      000838                        640 	.ds 1
      000839                        641 _tap_code_delay_PARM_2:
      000839                        642 	.ds 2
      00083B                        643 _tap_code_delay_code_10000_737:
      00083B                        644 	.ds 1
      00083C                        645 _tap_code_code_10000_744:
      00083C                        646 	.ds 1
      00083D                        647 _register_mods_mods_10000_746:
      00083D                        648 	.ds 1
      00083E                        649 _unregister_mods_mods_10000_750:
      00083E                        650 	.ds 1
      00083F                        651 _register_weak_mods_mods_10000_754:
      00083F                        652 	.ds 1
      000840                        653 _unregister_weak_mods_mods_10000_758:
      000840                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D9C                        663 _disable_action_cache::
      000D9C                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      0071F9                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0071F9 90 08 17         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0071FC 12 37 A0         [24]  711 	lcall	_ak820_outline_0004
      0071FF 12 35 B8         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007202 90 08 15         [24]  714 	mov	dptr,#_action_exec_PARM_1
      007205 12 45 57         [24]  715 	lcall	_ak820_tapping_before
      007208 E5 82            [12]  716 	mov	a, dpl
      00720A 70 01            [24]  717 	jnz	00102$
      00720C 22               [24]  718 	ret
      00720D                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      00720D 90 08 1A         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007210 E0               [24]  722 	movx	a,@dptr
      007211 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      007213 12 83 24         [24]  725 	lcall	_clear_weak_mods
      007216                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      007216 90 0D 7C         [24]  728 	mov	dptr,#___memcpy_PARM_2
      007219 74 15            [12]  729 	mov	a,#_action_exec_PARM_1
      00721B F0               [24]  730 	movx	@dptr,a
      00721C 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      00721E 12 78 75         [24]  732 	lcall	_ak820_outline_0050
      007221 12 78 95         [24]  733 	lcall	_ak820_outline_0108
      007224 90 08 1B         [24]  734 	mov	dptr,#_action_exec_record_10001_625
      007227 F5 F0            [12]  735 	mov	b,a
      007229 12 B9 8B         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      00722C 90 08 21         [24]  738 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      00722F E0               [24]  739 	movx	a,@dptr
      007230 54 0F            [12]  740 	anl	a,#0x0f
      007232 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      007233 90 08 22         [24]  743 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007236 12 50 65         [24]  744 	lcall	_ak820_outline_0180
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007239 90 08 1F         [24]  746 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      00723C E0               [24]  747 	movx	a,@dptr
      00723D 60 0A            [24]  748 	jz	00107$
      00723F 90 08 1B         [24]  749 	mov	dptr,#_action_exec_record_10001_625
      007242 12 A0 92         [24]  750 	lcall	_pre_process_record_quantum
      007245 E5 82            [12]  751 	mov	a, dpl
      007247 60 11            [24]  752 	jz	00110$
      007249                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007249 90 08 1B         [24]  755 	mov	dptr,#_action_exec_record_10001_625
      00724C 12 46 3B         [24]  756 	lcall	_ak820_tapping_process
      00724F E5 82            [12]  757 	mov	a, dpl
      007251 70 01            [24]  758 	jnz	00106$
      007253 22               [24]  759 	ret
      007254                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      007254 90 08 1B         [24]  762 	mov	dptr,#_action_exec_record_10001_625
                                    763 ;	quantum/action.c:200: }
      007257 02 72 98         [24]  764 	ljmp	_process_record
      00725A                        765 00110$:
      00725A 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      00725B                        777 _ak820_action_exec:
      00725B 12 38 49         [24]  778 	lcall	_ak820_outline_0104
      00725E 90 08 24         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_629
      007261 12 38 4E         [24]  780 	lcall	_ak820_outline_0105
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007264 90 08 24         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      007267 12 38 17         [24]  783 	lcall	_ak820_outline_0058
      00726A 90 0D 7C         [24]  784 	mov	dptr,#___memcpy_PARM_2
      00726D ED               [12]  785 	mov	a,r5
      00726E 12 37 DF         [24]  786 	lcall	_ak820_outline_0016
      007271 90 0D 7F         [24]  787 	mov	dptr,#___memcpy_PARM_3
      007274 12 78 95         [24]  788 	lcall	_ak820_outline_0108
      007277 90 08 26         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      00727A F5 F0            [12]  790 	mov	b,a
      00727C 12 B9 8B         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      00727F 90 0D 7C         [24]  793 	mov	dptr,#___memcpy_PARM_2
      007282 74 26            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007284 F0               [24]  795 	movx	@dptr,a
      007285 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      007287 12 78 75         [24]  797 	lcall	_ak820_outline_0050
      00728A 12 78 95         [24]  798 	lcall	_ak820_outline_0108
      00728D 90 08 15         [24]  799 	mov	dptr,#_action_exec_PARM_1
      007290 F5 F0            [12]  800 	mov	b,a
      007292 12 B9 8B         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      007295 02 71 F9         [24]  803 	ljmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      007298                        813 _process_record:
      007298 12 38 49         [24]  814 	lcall	_ak820_outline_0104
      00729B 90 08 2C         [24]  815 	mov	dptr,#_process_record_record_argument_10000_633
      00729E 12 38 4E         [24]  816 	lcall	_ak820_outline_0105
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0072A1 90 08 2C         [24]  818 	mov	dptr,#_process_record_record_argument_10000_633
      0072A4 12 38 00         [24]  819 	lcall	_ak820_outline_0051
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0072A7 74 04            [12]  821 	mov	a,#0x04
      0072A9 12 49 67         [24]  822 	lcall	_ak820_outline_0012
      0072AC 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      0072AE 22               [24]  825 	ret
      0072AF                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0072AF 8E 04            [24]  828 	mov	ar4,r6
      0072B1 8F 05            [24]  829 	mov	ar5,r7
      0072B3 90 0D 7C         [24]  830 	mov	dptr,#___memcpy_PARM_2
      0072B6 EC               [12]  831 	mov	a,r4
      0072B7 F0               [24]  832 	movx	@dptr,a
      0072B8 ED               [12]  833 	mov	a,r5
      0072B9 12 78 75         [24]  834 	lcall	_ak820_outline_0050
      0072BC 12 50 57         [24]  835 	lcall	_ak820_outline_0107
      0072BF 90 06 28         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      0072C2 F5 F0            [12]  837 	mov	b,a
      0072C4 C0 07            [24]  838 	push	ar7
      0072C6 C0 06            [24]  839 	push	ar6
      0072C8 12 B9 8B         [24]  840 	lcall	___memcpy
      0072CB 12 44 93         [24]  841 	lcall	_ak820_tapping_source
      0072CE AD 82            [24]  842 	mov	r5, dpl
      0072D0 D0 06            [24]  843 	pop	ar6
      0072D2 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0072D4 12 43 39         [24]  846 	lcall	_ak820_outline_0010
      0072D7 E0               [24]  847 	movx	a,@dptr
      0072D8 FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0072D9 74 07            [12]  850 	mov	a,#0x07
      0072DB 2E               [12]  851 	add	a, r6
      0072DC FA               [12]  852 	mov	r2,a
      0072DD E4               [12]  853 	clr	a
      0072DE 3F               [12]  854 	addc	a, r7
      0072DF FB               [12]  855 	mov	r3,a
      0072E0 90 0B DE         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      0072E3 12 49 B0         [24]  857 	lcall	_ak820_outline_0055
      0072E6 C0 07            [24]  858 	push	ar7
      0072E8 C0 06            [24]  859 	push	ar6
      0072EA C0 05            [24]  860 	push	ar5
      0072EC C0 04            [24]  861 	push	ar4
      0072EE C0 03            [24]  862 	push	ar3
      0072F0 C0 02            [24]  863 	push	ar2
      0072F2 12 A0 55         [24]  864 	lcall	_get_record_keycode
      0072F5 A8 82            [24]  865 	mov	r0, dpl
      0072F7 A9 83            [24]  866 	mov	r1, dph
      0072F9 D0 02            [24]  867 	pop	ar2
      0072FB D0 03            [24]  868 	pop	ar3
      0072FD D0 04            [24]  869 	pop	ar4
      0072FF D0 05            [24]  870 	pop	ar5
      007301 D0 06            [24]  871 	pop	ar6
      007303 D0 07            [24]  872 	pop	ar7
      007305 12 43 A9         [24]  873 	lcall	_ak820_outline_0140
      007308 E8               [12]  874 	mov	a,r0
      007309 F0               [24]  875 	movx	@dptr,a
      00730A E9               [12]  876 	mov	a,r1
      00730B A3               [24]  877 	inc	dptr
      00730C F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00730D 74 07            [12]  880 	mov	a,#0x07
      00730F 12 37 E7         [24]  881 	lcall	_ak820_outline_0017
      007312 FA               [12]  882 	mov	r2,a
      007313 A3               [24]  883 	inc	dptr
      007314 E0               [24]  884 	movx	a,@dptr
      007315 FB               [12]  885 	mov	r3,a
      007316 90 06 38         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007319 ED               [12]  887 	mov	a,r5
      00731A F0               [24]  888 	movx	@dptr,a
      00731B 90 06 39         [24]  889 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00731E EC               [12]  890 	mov	a,r4
      00731F F0               [24]  891 	movx	@dptr,a
      007320 12 43 A9         [24]  892 	lcall	_ak820_outline_0140
      007323 C0 07            [24]  893 	push	ar7
      007325 C0 06            [24]  894 	push	ar6
      007327 C0 05            [24]  895 	push	ar5
      007329 C0 04            [24]  896 	push	ar4
      00732B 12 47 E2         [24]  897 	lcall	_ak820_oneshot_process
      00732E E5 82            [12]  898 	mov	a, dpl
      007330 D0 04            [24]  899 	pop	ar4
      007332 D0 05            [24]  900 	pop	ar5
      007334 D0 06            [24]  901 	pop	ar6
      007336 D0 07            [24]  902 	pop	ar7
      007338 70 01            [24]  903 	jnz	00104$
      00733A 22               [24]  904 	ret
      00733B                        905 00104$:
                                    906 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00733B 12 43 8D         [24]  907 	lcall	_ak820_outline_0117
      00733E C0 07            [24]  908 	push	ar7
      007340 C0 06            [24]  909 	push	ar6
      007342 C0 05            [24]  910 	push	ar5
      007344 C0 04            [24]  911 	push	ar4
      007346 12 A0 D4         [24]  912 	lcall	_process_record_quantum
      007349 E5 82            [12]  913 	mov	a, dpl
      00734B D0 04            [24]  914 	pop	ar4
      00734D D0 05            [24]  915 	pop	ar5
      00734F D0 06            [24]  916 	pop	ar6
      007351 D0 07            [24]  917 	pop	ar7
      007353 70 0A            [24]  918 	jnz	00106$
                                    919 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007355 90 05 98         [24]  920 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007358 EC               [12]  921 	mov	a,r4
      007359 F0               [24]  922 	movx	@dptr,a
      00735A 8D 82            [24]  923 	mov	dpl, r5
                                    924 ;	quantum/action.c:376: return;
      00735C 02 2E 6F         [24]  925 	ljmp	_ak820_oneshot_post
      00735F                        926 00106$:
                                    927 ;	quantum/action.c:382: process_record_handler(record);
      00735F 12 43 8D         [24]  928 	lcall	_ak820_outline_0117
      007362 C0 05            [24]  929 	push	ar5
      007364 C0 04            [24]  930 	push	ar4
      007366 12 73 77         [24]  931 	lcall	_process_record_handler
      007369 D0 04            [24]  932 	pop	ar4
      00736B D0 05            [24]  933 	pop	ar5
                                    934 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00736D 90 05 98         [24]  935 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007370 EC               [12]  936 	mov	a,r4
      007371 F0               [24]  937 	movx	@dptr,a
      007372 8D 82            [24]  938 	mov	dpl, r5
                                    939 ;	quantum/action.c:392: }
      007374 02 2E 6F         [24]  940 	ljmp	_ak820_oneshot_post
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'process_record_handler'
                                    943 ;------------------------------------------------------------
                                    944 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    945 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    946 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function process_record_handler
                                    951 ;	-----------------------------------------
      007377                        952 _process_record_handler:
      007377 12 38 49         [24]  953 	lcall	_ak820_outline_0104
      00737A 90 08 2E         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_641
      00737D 12 38 4E         [24]  955 	lcall	_ak820_outline_0105
                                    956 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007380 90 08 2E         [24]  957 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007383 12 37 B7         [24]  958 	lcall	_ak820_outline_0009
                                    959 ;	quantum/action.c:405: if (record->keycode) {
      007386 4C               [12]  960 	orl	a,r4
      007387 60 19            [24]  961 	jz	00102$
                                    962 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007389 12 38 60         [24]  963 	lcall	_ak820_outline_0121
      00738C C0 07            [24]  964 	push	ar7
      00738E C0 06            [24]  965 	push	ar6
      007390 12 97 26         [24]  966 	lcall	_action_for_keycode
      007393 12 43 AE         [24]  967 	lcall	_ak820_outline_0145
      007396 D0 06            [24]  968 	pop	ar6
      007398 D0 07            [24]  969 	pop	ar7
      00739A 90 08 30         [24]  970 	mov	dptr,#_process_record_handler_action_10000_642
      00739D 12 38 25         [24]  971 	lcall	_ak820_outline_0071
      0073A0 80 2A            [24]  972 	sjmp	00104$
      0073A2                        973 00102$:
                                    974 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0073A2 12 78 5D         [24]  975 	lcall	_ak820_outline_0019
      0073A5 7A 00            [12]  976 	mov	r2,#0x00
      0073A7 12 43 A3         [24]  977 	lcall	_ak820_outline_0139
      0073AA 12 43 39         [24]  978 	lcall	_ak820_outline_0010
      0073AD E0               [24]  979 	movx	a,@dptr
      0073AE 90 09 6B         [24]  980 	mov	dptr,#_ak820_resolve_key_PARM_2
      0073B1 F0               [24]  981 	movx	@dptr,a
      0073B2 12 43 CE         [24]  982 	lcall	_ak820_outline_0186
      0073B5 C0 07            [24]  983 	push	ar7
      0073B7 C0 06            [24]  984 	push	ar6
      0073B9 12 7B FA         [24]  985 	lcall	_ak820_resolve_key
      0073BC 12 97 26         [24]  986 	lcall	_action_for_keycode
      0073BF 12 43 AE         [24]  987 	lcall	_ak820_outline_0145
      0073C2 D0 06            [24]  988 	pop	ar6
      0073C4 D0 07            [24]  989 	pop	ar7
      0073C6 90 08 30         [24]  990 	mov	dptr,#_process_record_handler_action_10000_642
      0073C9 12 38 25         [24]  991 	lcall	_ak820_outline_0071
                                    992 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0073CC                        993 00104$:
                                    994 ;	quantum/action.c:429: process_action(record, action);
      0073CC 90 0D 7C         [24]  995 	mov	dptr,#___memcpy_PARM_2
      0073CF 74 30            [12]  996 	mov	a,#_process_record_handler_action_10000_642
      0073D1 F0               [24]  997 	movx	@dptr,a
      0073D2 74 08            [12]  998 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      0073D4 12 78 75         [24]  999 	lcall	_ak820_outline_0050
      0073D7 12 50 57         [24] 1000 	lcall	_ak820_outline_0107
      0073DA 90 08 32         [24] 1001 	mov	dptr,#_process_action_PARM_2
      0073DD F5 F0            [12] 1002 	mov	b,a
      0073DF C0 07            [24] 1003 	push	ar7
      0073E1 C0 06            [24] 1004 	push	ar6
      0073E3 12 B9 8B         [24] 1005 	lcall	___memcpy
      0073E6 D0 06            [24] 1006 	pop	ar6
      0073E8 D0 07            [24] 1007 	pop	ar7
      0073EA 12 43 8D         [24] 1008 	lcall	_ak820_outline_0117
                                   1009 ;	quantum/action.c:430: }
      0073ED 02 73 F0         [24] 1010 	ljmp	_process_action
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'register_mouse'
                                   1013 ;------------------------------------------------------------
                                   1014 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1015 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function process_action
                                   1020 ;	-----------------------------------------
      0073F0                       1021 _process_action:
      0073F0 12 38 49         [24] 1022 	lcall	_ak820_outline_0104
      0073F3 90 08 34         [24] 1023 	mov	dptr,#_process_action_record_argument_10000_653
      0073F6 12 38 4E         [24] 1024 	lcall	_ak820_outline_0105
                                   1025 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073F9 90 08 34         [24] 1026 	mov	dptr,#_process_action_record_argument_10000_653
      0073FC 12 37 A0         [24] 1027 	lcall	_ak820_outline_0004
                                   1028 ;	quantum/action.c:501: pressed = record->event.pressed;
      0073FF A3               [24] 1029 	inc	dptr
      007400 A3               [24] 1030 	inc	dptr
      007401 A3               [24] 1031 	inc	dptr
      007402 A3               [24] 1032 	inc	dptr
      007403 A3               [24] 1033 	inc	dptr
      007404 E0               [24] 1034 	movx	a,@dptr
      007405 F5 27            [12] 1035 	mov	_process_action_sloc0_1_0,a
                                   1036 ;	quantum/action.c:525: switch (action.kind.id) {
      007407 90 08 33         [24] 1037 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00740A E0               [24] 1038 	movx	a,@dptr
      00740B C4               [12] 1039 	swap	a
      00740C 54 0F            [12] 1040 	anl	a,#0x0f
      00740E FD               [12] 1041 	mov  r5,a
      00740F 24 F4            [12] 1042 	add	a,#0xff - 0x0b
      007411 50 03            [24] 1043 	jnc	00434$
      007413 02 76 91         [24] 1044 	ljmp	00181$
      007416                       1045 00434$:
                                   1046 ;	free result
      007416 ED               [12] 1047 	mov	a,r5
      007417 24 0A            [12] 1048 	add	a,#(00435$-3-.)
      007419 83               [24] 1049 	movc	a,@a+pc
      00741A F5 82            [12] 1050 	mov	dpl,a
      00741C ED               [12] 1051 	mov	a,r5
      00741D 24 10            [12] 1052 	add	a,#(00436$-3-.)
      00741F 83               [24] 1053 	movc	a,@a+pc
      007420 F5 83            [12] 1054 	mov	dph,a
      007422 E4               [12] 1055 	clr	a
      007423 73               [24] 1056 	jmp	@a+dptr
      007424                       1057 00435$:
      007424 3C                    1058 	.db	00102$
      007425 3C                    1059 	.db	00102$
      007426 91                    1060 	.db	00181$
      007427 91                    1061 	.db	00181$
      007428 C6                    1062 	.db	00123$
      007429 91                    1063 	.db	00181$
      00742A 91                    1064 	.db	00181$
      00742B 91                    1065 	.db	00181$
      00742C 26                    1066 	.db	00131$
      00742D F8                    1067 	.db	00147$
      00742E 1E                    1068 	.db	00152$
      00742F 1E                    1069 	.db	00152$
      007430                       1070 00436$:
      007430 74                    1071 	.db	00102$>>8
      007431 74                    1072 	.db	00102$>>8
      007432 76                    1073 	.db	00181$>>8
      007433 76                    1074 	.db	00181$>>8
      007434 74                    1075 	.db	00123$>>8
      007435 76                    1076 	.db	00181$>>8
      007436 76                    1077 	.db	00181$>>8
      007437 76                    1078 	.db	00181$>>8
      007438 75                    1079 	.db	00131$>>8
      007439 75                    1080 	.db	00147$>>8
      00743A 76                    1081 	.db	00152$>>8
      00743B 76                    1082 	.db	00152$>>8
                                   1083 ;	quantum/action.c:528: case ACT_RMODS: {
      00743C                       1084 00102$:
                                   1085 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00743C 90 08 33         [24] 1086 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00743F E0               [24] 1087 	movx	a,@dptr
      007440 54 F0            [12] 1088 	anl	a,#0xf0
      007442 70 06            [24] 1089 	jnz	00194$
      007444 12 78 9C         [24] 1090 	lcall	_ak820_outline_0110
      007447 FD               [12] 1091 	mov	r5,a
      007448 80 07            [24] 1092 	sjmp	00195$
      00744A                       1093 00194$:
      00744A 12 78 9C         [24] 1094 	lcall	_ak820_outline_0110
      00744D C4               [12] 1095 	swap	a
      00744E 54 F0            [12] 1096 	anl	a,#0xf0
      007450 FD               [12] 1097 	mov	r5,a
      007451                       1098 00195$:
                                   1099 ;	quantum/action.c:531: if (pressed) {
      007451 E5 27            [12] 1100 	mov	a,_process_action_sloc0_1_0
      007453 60 35            [24] 1101 	jz	00119$
                                   1102 ;	quantum/action.c:532: if (mods) {
      007455 ED               [12] 1103 	mov	a,r5
      007456 60 29            [24] 1104 	jz	00110$
                                   1105 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007458 12 78 AE         [24] 1106 	lcall	_ak820_outline_0154
      00745B FC               [12] 1107 	mov	r4,a
      00745C BC E0 00         [24] 1108 	cjne	r4,#0xe0,00440$
      00745F                       1109 00440$:
      00745F 40 07            [24] 1110 	jc	00108$
      007461 12 78 AE         [24] 1111 	lcall	_ak820_outline_0154
      007464 24 18            [12] 1112 	add	a,#0xff - 0xe7
      007466 50 0A            [24] 1113 	jnc	00104$
                                   1114 ;	free result
      007468                       1115 00108$:
      007468 7B 32            [12] 1116 	mov	r3,#_process_action_PARM_2
      00746A 7C 08            [12] 1117 	mov	r4,#(_process_action_PARM_2 >> 8)
      00746C 12 33 FC         [24] 1118 	lcall	_ak820_outline_0122
      00746F E0               [24] 1119 	movx	a,@dptr
      007470 70 07            [24] 1120 	jnz	00105$
      007472                       1121 00104$:
                                   1122 ;	quantum/action.c:537: add_owned_mods(mods);
      007472 8D 82            [24] 1123 	mov	dpl, r5
      007474 12 7E DE         [24] 1124 	lcall	_add_owned_mods
      007477 80 05            [24] 1125 	sjmp	00106$
      007479                       1126 00105$:
                                   1127 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007479 8D 82            [24] 1128 	mov	dpl, r5
      00747B 12 7E FD         [24] 1129 	lcall	_add_owned_weak_mods
      00747E                       1130 00106$:
                                   1131 ;	quantum/action.c:541: send_keyboard_report();
      00747E 12 82 1A         [24] 1132 	lcall	_send_keyboard_report
      007481                       1133 00110$:
                                   1134 ;	quantum/action.c:543: register_code(action.key.code);
      007481 12 78 85         [24] 1135 	lcall	_ak820_outline_0075
      007484 12 76 A8         [24] 1136 	lcall	_register_code
      007487 02 76 91         [24] 1137 	ljmp	00181$
      00748A                       1138 00119$:
                                   1139 ;	quantum/action.c:545: unregister_code(action.key.code);
      00748A 12 78 85         [24] 1140 	lcall	_ak820_outline_0075
      00748D C0 05            [24] 1141 	push	ar5
      00748F 12 77 15         [24] 1142 	lcall	_unregister_code
      007492 D0 05            [24] 1143 	pop	ar5
                                   1144 ;	quantum/action.c:546: if (mods) {
      007494 ED               [12] 1145 	mov	a,r5
      007495 70 03            [24] 1146 	jnz	00444$
      007497 02 76 91         [24] 1147 	ljmp	00181$
      00749A                       1148 00444$:
                                   1149 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00749A 12 78 AE         [24] 1150 	lcall	_ak820_outline_0154
      00749D FC               [12] 1151 	mov	r4,a
      00749E BC E0 00         [24] 1152 	cjne	r4,#0xe0,00445$
      0074A1                       1153 00445$:
      0074A1 40 07            [24] 1154 	jc	00115$
      0074A3 12 78 AE         [24] 1155 	lcall	_ak820_outline_0154
      0074A6 24 18            [12] 1156 	add	a,#0xff - 0xe7
      0074A8 50 0A            [24] 1157 	jnc	00111$
                                   1158 ;	free result
      0074AA                       1159 00115$:
      0074AA 7B 32            [12] 1160 	mov	r3,#_process_action_PARM_2
      0074AC 7C 08            [12] 1161 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074AE 12 33 FC         [24] 1162 	lcall	_ak820_outline_0122
      0074B1 E0               [24] 1163 	movx	a,@dptr
      0074B2 70 07            [24] 1164 	jnz	00112$
      0074B4                       1165 00111$:
                                   1166 ;	quantum/action.c:548: del_owned_mods(mods);
      0074B4 8D 82            [24] 1167 	mov	dpl, r5
      0074B6 12 7E EE         [24] 1168 	lcall	_del_owned_mods
      0074B9 80 05            [24] 1169 	sjmp	00113$
      0074BB                       1170 00112$:
                                   1171 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0074BB 8D 82            [24] 1172 	mov	dpl, r5
      0074BD 12 7F 0D         [24] 1173 	lcall	_del_owned_weak_mods
      0074C0                       1174 00113$:
                                   1175 ;	quantum/action.c:552: send_keyboard_report();
      0074C0 12 82 1A         [24] 1176 	lcall	_send_keyboard_report
                                   1177 ;	quantum/action.c:555: } break;
      0074C3 02 76 91         [24] 1178 	ljmp	00181$
                                   1179 ;	quantum/action.c:632: case ACT_USAGE:
      0074C6                       1180 00123$:
                                   1181 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0074C6 74 07            [12] 1182 	mov	a,#0x07
      0074C8 12 37 F0         [24] 1183 	lcall	_ak820_outline_0031
      0074CB 12 37 CB         [24] 1184 	lcall	_ak820_outline_0011
      0074CE C3               [12] 1185 	clr	c
      0074CF EC               [12] 1186 	mov	a,r4
      0074D0 94 A5            [12] 1187 	subb	a,#0xa5
      0074D2 ED               [12] 1188 	mov	a,r5
      0074D3 94 00            [12] 1189 	subb	a,#0x00
      0074D5 40 15            [24] 1190 	jc	00125$
      0074D7 74 C2            [12] 1191 	mov	a,#0xc2
      0074D9 9C               [12] 1192 	subb	a,r4
      0074DA E4               [12] 1193 	clr	a
      0074DB 9D               [12] 1194 	subb	a,r5
      0074DC 40 0E            [24] 1195 	jc	00125$
                                   1196 ;	free result
                                   1197 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0074DE 90 0A 95         [24] 1198 	mov	dptr,#_owned_usage_key_PARM_2
      0074E1 E5 27            [12] 1199 	mov	a,_process_action_sloc0_1_0
      0074E3 F0               [24] 1200 	movx	@dptr,a
      0074E4 8E 82            [24] 1201 	mov	dpl, r6
      0074E6 12 80 C5         [24] 1202 	lcall	_owned_usage_key
                                   1203 ;	quantum/action.c:640: break;
      0074E9 02 76 91         [24] 1204 	ljmp	00181$
      0074EC                       1205 00125$:
                                   1206 ;	quantum/action.c:643: switch (action.usage.page) {
      0074EC 12 78 8C         [24] 1207 	lcall	_ak820_outline_0085
      0074EF FF               [12] 1208 	mov	r7,a
      0074F0 60 08            [24] 1209 	jz	00127$
      0074F2 BF 01 02         [24] 1210 	cjne	r7,#0x01,00452$
      0074F5 80 19            [24] 1211 	sjmp	00128$
      0074F7                       1212 00452$:
      0074F7 02 76 91         [24] 1213 	ljmp	00181$
                                   1214 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0074FA                       1215 00127$:
                                   1216 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0074FA E5 27            [12] 1217 	mov	a,_process_action_sloc0_1_0
      0074FC 60 05            [24] 1218 	jz	00196$
      0074FE 12 78 A3         [24] 1219 	lcall	_ak820_outline_0129
      007501 80 04            [24] 1220 	sjmp	00197$
      007503                       1221 00196$:
      007503 7E 00            [12] 1222 	mov	r6,#0x00
      007505 7F 00            [12] 1223 	mov	r7,#0x00
      007507                       1224 00197$:
      007507 12 43 8D         [24] 1225 	lcall	_ak820_outline_0117
      00750A 12 6E F2         [24] 1226 	lcall	_host_system_send
                                   1227 ;	quantum/action.c:646: break;
      00750D 02 76 91         [24] 1228 	ljmp	00181$
                                   1229 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007510                       1230 00128$:
                                   1231 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007510 E5 27            [12] 1232 	mov	a,_process_action_sloc0_1_0
      007512 60 05            [24] 1233 	jz	00198$
      007514 12 78 A3         [24] 1234 	lcall	_ak820_outline_0129
      007517 80 04            [24] 1235 	sjmp	00199$
      007519                       1236 00198$:
      007519 7E 00            [12] 1237 	mov	r6,#0x00
      00751B 7F 00            [12] 1238 	mov	r7,#0x00
      00751D                       1239 00199$:
      00751D 12 43 8D         [24] 1240 	lcall	_ak820_outline_0117
      007520 12 6F 22         [24] 1241 	lcall	_host_consumer_send
                                   1242 ;	quantum/action.c:651: break;
      007523 02 76 91         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:658: case ACT_LAYER: {
      007526                       1245 00131$:
                                   1246 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007526 90 08 33         [24] 1247 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007529 E0               [24] 1248 	movx	a,@dptr
      00752A 54 03            [12] 1249 	anl	a,#0x03
      00752C 90 08 36         [24] 1250 	mov	dptr,#_process_action_on_40000_676
      00752F F0               [24] 1251 	movx	@dptr,a
                                   1252 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007530 E0               [24] 1253 	movx	a,@dptr
      007531 FF               [12] 1254 	mov	r7,a
      007532 60 11            [24] 1255 	jz	00200$
      007534 E5 27            [12] 1256 	mov	a,_process_action_sloc0_1_0
      007536 60 07            [24] 1257 	jz	00202$
      007538 8F 06            [24] 1258 	mov	ar6,r7
      00753A 53 06 01         [24] 1259 	anl	ar6,#0x01
      00753D 80 10            [24] 1260 	sjmp	00201$
      00753F                       1261 00202$:
      00753F 74 02            [12] 1262 	mov	a,#0x02
      007541 5F               [12] 1263 	anl	a,r7
      007542 FE               [12] 1264 	mov	r6,a
      007543 80 0A            [24] 1265 	sjmp	00201$
      007545                       1266 00200$:
      007545 E5 27            [12] 1267 	mov	a,_process_action_sloc0_1_0
      007547 B4 01 00         [24] 1268 	cjne	a,#0x01,00457$
      00754A                       1269 00457$:
      00754A 92 1D            [24] 1270 	mov  _process_action_sloc1_1_0,c
      00754C E4               [12] 1271 	clr	a
      00754D 33               [12] 1272 	rlc	a
      00754E FE               [12] 1273 	mov	r6,a
      00754F                       1274 00201$:
      00754F EE               [12] 1275 	mov	a,r6
      007550 70 03            [24] 1276 	jnz	00458$
      007552 02 76 91         [24] 1277 	ljmp	00181$
      007555                       1278 00458$:
                                   1279 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007555 12 78 AE         [24] 1280 	lcall	_ak820_outline_0154
      007558 C4               [12] 1281 	swap	a
      007559 03               [12] 1282 	rr	a
      00755A 54 07            [12] 1283 	anl	a,#0x07
      00755C 25 E0            [12] 1284 	add	a,acc
      00755E 25 E0            [12] 1285 	add	a,acc
      007560 FF               [12] 1286 	mov	r7,a
                                   1287 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007561 12 78 AE         [24] 1288 	lcall	_ak820_outline_0154
      007564 54 0F            [12] 1289 	anl	a,#0x0f
      007566 FE               [12] 1290 	mov	r6,a
      007567 8F F0            [24] 1291 	mov	b,r7
      007569 05 F0            [12] 1292 	inc	b
      00756B EE               [12] 1293 	mov	a,r6
      00756C 80 02            [24] 1294 	sjmp	00460$
      00756E                       1295 00459$:
      00756E 25 E0            [12] 1296 	add	a,acc
      007570                       1297 00460$:
      007570 D5 F0 FB         [24] 1298 	djnz	b,00459$
      007573 FE               [12] 1299 	mov	r6,a
                                   1300 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007574 12 78 AE         [24] 1301 	lcall	_ak820_outline_0154
      007577 30 E4 11         [24] 1302 	jnb	acc.4,00204$
      00757A 8F F0            [24] 1303 	mov	b,r7
      00757C 05 F0            [12] 1304 	inc	b
      00757E 74 0F            [12] 1305 	mov	a,#0x0f
      007580 80 02            [24] 1306 	sjmp	00463$
      007582                       1307 00462$:
      007582 25 E0            [12] 1308 	add	a,acc
      007584                       1309 00463$:
      007584 D5 F0 FB         [24] 1310 	djnz	b,00462$
      007587 F4               [12] 1311 	cpl	a
      007588 FF               [12] 1312 	mov	r7,a
      007589 80 02            [24] 1313 	sjmp	00205$
      00758B                       1314 00204$:
      00758B 7F 00            [12] 1315 	mov	r7,#0x00
      00758D                       1316 00205$:
                                   1317 ;	quantum/action.c:666: bits |= mask;
      00758D EE               [12] 1318 	mov	a,r6
      00758E 42 07            [12] 1319 	orl	ar7,a
                                   1320 ;	quantum/action.c:667: if (!on) {
      007590 90 08 36         [24] 1321 	mov	dptr,#_process_action_on_40000_676
      007593 E0               [24] 1322 	movx	a,@dptr
      007594 70 31            [24] 1323 	jnz	00143$
                                   1324 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007596 12 78 8C         [24] 1325 	lcall	_ak820_outline_0085
      007599 FE               [12] 1326 	mov	r6,a
      00759A 2E               [12] 1327 	add	a,r6
                                   1328 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00759B 90 75 9F         [24] 1329 	mov	dptr,#00465$
      00759E 73               [24] 1330 	jmp	@a+dptr
      00759F                       1331 00465$:
      00759F 80 06            [24] 1332 	sjmp	00132$
      0075A1 80 0C            [24] 1333 	sjmp	00133$
      0075A3 80 12            [24] 1334 	sjmp	00134$
      0075A5 80 18            [24] 1335 	sjmp	00135$
      0075A7                       1336 00132$:
      0075A7 8F 82            [24] 1337 	mov	dpl, r7
      0075A9 12 79 09         [24] 1338 	lcall	_default_layer_and
      0075AC 02 76 91         [24] 1339 	ljmp	00181$
                                   1340 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0075AF                       1341 00133$:
      0075AF 8F 82            [24] 1342 	mov	dpl, r7
      0075B1 12 78 F8         [24] 1343 	lcall	_default_layer_or
      0075B4 02 76 91         [24] 1344 	ljmp	00181$
                                   1345 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0075B7                       1346 00134$:
      0075B7 8F 82            [24] 1347 	mov	dpl, r7
      0075B9 12 79 1F         [24] 1348 	lcall	_default_layer_xor
      0075BC 02 76 91         [24] 1349 	ljmp	00181$
                                   1350 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0075BF                       1351 00135$:
      0075BF 8F 82            [24] 1352 	mov	dpl, r7
      0075C1 12 78 ED         [24] 1353 	lcall	_default_layer_set
                                   1354 ;	quantum/action.c:673: }
      0075C4 02 76 91         [24] 1355 	ljmp	00181$
      0075C7                       1356 00143$:
                                   1357 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0075C7 12 78 8C         [24] 1358 	lcall	_ak820_outline_0085
      0075CA FE               [12] 1359 	mov	r6,a
      0075CB 2E               [12] 1360 	add	a,r6
                                   1361 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0075CC 90 75 D0         [24] 1362 	mov	dptr,#00466$
      0075CF 73               [24] 1363 	jmp	@a+dptr
      0075D0                       1364 00466$:
      0075D0 80 06            [24] 1365 	sjmp	00137$
      0075D2 80 0C            [24] 1366 	sjmp	00138$
      0075D4 80 12            [24] 1367 	sjmp	00139$
      0075D6 80 18            [24] 1368 	sjmp	00140$
      0075D8                       1369 00137$:
      0075D8 8F 82            [24] 1370 	mov	dpl, r7
      0075DA 12 7A A2         [24] 1371 	lcall	_layer_and
      0075DD 02 76 91         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0075E0                       1374 00138$:
      0075E0 8F 82            [24] 1375 	mov	dpl, r7
      0075E2 12 7A 91         [24] 1376 	lcall	_layer_or
      0075E5 02 76 91         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0075E8                       1379 00139$:
      0075E8 8F 82            [24] 1380 	mov	dpl, r7
      0075EA 12 7A B8         [24] 1381 	lcall	_layer_xor
      0075ED 02 76 91         [24] 1382 	ljmp	00181$
                                   1383 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0075F0                       1384 00140$:
      0075F0 8F 82            [24] 1385 	mov	dpl, r7
      0075F2 12 7A 2E         [24] 1386 	lcall	_layer_state_set
                                   1387 ;	quantum/action.c:683: break;
      0075F5 02 76 91         [24] 1388 	ljmp	00181$
                                   1389 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0075F8                       1390 00147$:
                                   1391 ;	quantum/action.c:686: if (pressed) {
      0075F8 E5 27            [12] 1392 	mov	a,_process_action_sloc0_1_0
      0075FA 60 11            [24] 1393 	jz	00149$
                                   1394 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0075FC 12 78 9C         [24] 1395 	lcall	_ak820_outline_0110
      0075FF F5 82            [12] 1396 	mov	dpl,a
      007601 12 79 8F         [24] 1397 	lcall	_layer_hold_on
                                   1398 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007604 12 78 85         [24] 1399 	lcall	_ak820_outline_0075
      007607 12 77 CB         [24] 1400 	lcall	_register_mods
      00760A 02 76 91         [24] 1401 	ljmp	00181$
      00760D                       1402 00149$:
                                   1403 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      00760D 12 78 85         [24] 1404 	lcall	_ak820_outline_0075
      007610 12 77 DF         [24] 1405 	lcall	_unregister_mods
                                   1406 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007613 12 78 9C         [24] 1407 	lcall	_ak820_outline_0110
      007616 F5 82            [12] 1408 	mov	dpl,a
      007618 12 79 C7         [24] 1409 	lcall	_layer_hold_off
                                   1410 ;	quantum/action.c:693: break;
      00761B 02 76 91         [24] 1411 	ljmp	00181$
                                   1412 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      00761E                       1413 00152$:
                                   1414 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      00761E 12 78 AE         [24] 1415 	lcall	_ak820_outline_0154
      007621 FF               [12] 1416 	mov	r7,a
      007622 BF F1 02         [24] 1417 	cjne	r7,#0xf1,00468$
      007625 80 0A            [24] 1418 	sjmp	00154$
      007627                       1419 00468$:
      007627 BF F2 02         [24] 1420 	cjne	r7,#0xf2,00469$
      00762A 80 19            [24] 1421 	sjmp	00155$
      00762C                       1422 00469$:
                                   1423 ;	quantum/action.c:712: momentary_layer_action:
      00762C BF F3 3B         [24] 1424 	cjne	r7,#0xf3,00160$
      00762F 80 28            [24] 1425 	sjmp	00156$
      007631                       1426 00154$:
                                   1427 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007631 E5 27            [12] 1428 	mov	a,_process_action_sloc0_1_0
      007633 60 08            [24] 1429 	jz	00206$
      007635 12 78 6C         [24] 1430 	lcall	_ak820_outline_0039
      007638 12 79 8F         [24] 1431 	lcall	_layer_hold_on
      00763B 80 54            [24] 1432 	sjmp	00181$
      00763D                       1433 00206$:
      00763D 12 78 6C         [24] 1434 	lcall	_ak820_outline_0039
      007640 12 79 C7         [24] 1435 	lcall	_layer_hold_off
                                   1436 ;	quantum/action.c:714: break;
                                   1437 ;	quantum/action.c:715: case OP_OFF_ON:
      007643 80 4C            [24] 1438 	sjmp	00181$
      007645                       1439 00155$:
                                   1440 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007645 E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      007647 60 08            [24] 1442 	jz	00208$
      007649 12 78 6C         [24] 1443 	lcall	_ak820_outline_0039
      00764C 12 7A 73         [24] 1444 	lcall	_layer_off
      00764F 80 40            [24] 1445 	sjmp	00181$
      007651                       1446 00208$:
      007651 12 78 6C         [24] 1447 	lcall	_ak820_outline_0039
      007654 12 7A 58         [24] 1448 	lcall	_layer_on
                                   1449 ;	quantum/action.c:717: break;
                                   1450 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007657 80 38            [24] 1451 	sjmp	00181$
      007659                       1452 00156$:
                                   1453 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007659 E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      00765B 60 08            [24] 1455 	jz	00210$
      00765D 12 78 6C         [24] 1456 	lcall	_ak820_outline_0039
      007660 12 7A 42         [24] 1457 	lcall	_layer_move
      007663 80 2C            [24] 1458 	sjmp	00181$
      007665                       1459 00210$:
      007665 12 7A 3C         [24] 1460 	lcall	_layer_clear
                                   1461 ;	quantum/action.c:720: break;
                                   1462 ;	quantum/action.c:766: default:
      007668 80 27            [24] 1463 	sjmp	00181$
      00766A                       1464 00160$:
                                   1465 ;	quantum/action.c:773: if (pressed) {
      00766A E5 27            [12] 1466 	mov	a,_process_action_sloc0_1_0
      00766C 60 08            [24] 1467 	jz	00163$
                                   1468 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00766E 12 78 85         [24] 1469 	lcall	_ak820_outline_0075
      007671 12 76 A8         [24] 1470 	lcall	_register_code
                                   1471 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007674 80 1B            [24] 1472 	sjmp	00181$
      007676                       1473 00163$:
                                   1474 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007676 12 78 AE         [24] 1475 	lcall	_ak820_outline_0154
      007679 FF               [12] 1476 	mov	r7,a
      00767A BF 39 0E         [24] 1477 	cjne	r7,#0x39,00175$
                                   1478 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00767D 7F 50            [12] 1479 	mov	r7,#0x50
      00767F                       1480 00187$:
      00767F EF               [12] 1481 	mov	a,r7
      007680 60 09            [24] 1482 	jz	00175$
      007682 90 00 01         [24] 1483 	mov	dptr,#0x0001
      007685 12 59 E6         [24] 1484 	lcall	_mDelaymS
      007688 1F               [12] 1485 	dec	r7
                                   1486 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007689 80 F4            [24] 1487 	sjmp	00187$
      00768B                       1488 00175$:
                                   1489 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00768B 12 78 85         [24] 1490 	lcall	_ak820_outline_0075
      00768E 12 77 15         [24] 1491 	lcall	_unregister_code
                                   1492 ;	quantum/action.c:866: }
      007691                       1493 00181$:
                                   1494 ;	quantum/action.c:887: switch (action.kind.id) {
      007691 90 08 33         [24] 1495 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007694 E0               [24] 1496 	movx	a,@dptr
      007695 C4               [12] 1497 	swap	a
      007696 54 0F            [12] 1498 	anl	a,#0x0f
      007698 FF               [12] 1499 	mov	r7,a
      007699 BF 08 02         [24] 1500 	cjne	r7,#0x08,00478$
      00769C 80 03            [24] 1501 	sjmp	00183$
      00769E                       1502 00478$:
      00769E BF 09 06         [24] 1503 	cjne	r7,#0x09,00192$
                                   1504 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0076A1                       1505 00183$:
                                   1506 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0076A1 12 6E 57         [24] 1507 	lcall	_host_keyboard_leds
                                   1508 ;	quantum/action.c:898: }
                                   1509 ;	quantum/action.c:951: }
      0076A4 02 99 DB         [24] 1510 	ljmp	_led_set
      0076A7                       1511 00192$:
      0076A7 22               [24] 1512 	ret
                                   1513 ;------------------------------------------------------------
                                   1514 ;Allocation info for local variables in function 'register_code'
                                   1515 ;------------------------------------------------------------
                                   1516 ;code          Allocated with name '_register_code_code_10000_710'
                                   1517 ;------------------------------------------------------------
                                   1518 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1519 ;	-----------------------------------------
                                   1520 ;	 function register_code
                                   1521 ;	-----------------------------------------
      0076A8                       1522 _register_code:
      0076A8 E5 82            [12] 1523 	mov	a,dpl
      0076AA 90 08 37         [24] 1524 	mov	dptr,#_register_code_code_10000_710
      0076AD F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action.c:958: if (code == KC_NO) {
      0076AE E0               [24] 1527 	movx	a,@dptr
      0076AF FF               [12] 1528 	mov	r7,a
      0076B0 70 01            [24] 1529 	jnz	00123$
                                   1530 ;	quantum/action.c:959: return;
      0076B2 22               [24] 1531 	ret
      0076B3                       1532 00123$:
                                   1533 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0076B3 BF 04 00         [24] 1534 	cjne	r7,#0x04,00186$
      0076B6                       1535 00186$:
      0076B6 40 12            [24] 1536 	jc	00119$
      0076B8 EF               [12] 1537 	mov	a,r7
      0076B9 24 5B            [12] 1538 	add	a,#0xff - 0xa4
      0076BB 40 0D            [24] 1539 	jc	00119$
                                   1540 ;	free result
                                   1541 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0076BD 8F 82            [24] 1542 	mov	dpl, r7
      0076BF 12 7F 82         [24] 1543 	lcall	_add_owned_key
      0076C2 E5 82            [12] 1544 	mov	a, dpl
      0076C4 70 01            [24] 1545 	jnz	00104$
      0076C6 22               [24] 1546 	ret
      0076C7                       1547 00104$:
                                   1548 ;	quantum/action.c:1013: send_keyboard_report();
      0076C7 02 82 1A         [24] 1549 	ljmp	_send_keyboard_report
      0076CA                       1550 00119$:
                                   1551 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0076CA 12 78 B3         [24] 1552 	lcall	_ak820_outline_0162
      0076CD BF E0 00         [24] 1553 	cjne	r7,#0xe0,00190$
      0076D0                       1554 00190$:
      0076D0 40 1A            [24] 1555 	jc	00115$
      0076D2 EF               [12] 1556 	mov	a,r7
      0076D3 24 18            [12] 1557 	add	a,#0xff - 0xe7
      0076D5 40 15            [24] 1558 	jc	00115$
                                   1559 ;	free result
                                   1560 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0076D7 74 07            [12] 1561 	mov	a,#0x07
      0076D9 5F               [12] 1562 	anl	a,r7
      0076DA 12 78 7E         [24] 1563 	lcall	_ak820_outline_0063
      0076DD 80 02            [24] 1564 	sjmp	00194$
      0076DF                       1565 00193$:
      0076DF 25 E0            [12] 1566 	add	a,acc
      0076E1                       1567 00194$:
      0076E1 D5 F0 FB         [24] 1568 	djnz	b,00193$
      0076E4 F5 82            [12] 1569 	mov	dpl,a
      0076E6 12 7E DE         [24] 1570 	lcall	_add_owned_mods
                                   1571 ;	quantum/action.c:1016: send_keyboard_report();
      0076E9 02 82 1A         [24] 1572 	ljmp	_send_keyboard_report
      0076EC                       1573 00115$:
                                   1574 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0076EC 12 78 B3         [24] 1575 	lcall	_ak820_outline_0162
      0076EF BF A5 00         [24] 1576 	cjne	r7,#0xa5,00195$
      0076F2                       1577 00195$:
      0076F2 40 05            [24] 1578 	jc	00113$
      0076F4 EF               [12] 1579 	mov	a,r7
      0076F5 24 58            [12] 1580 	add	a,#0xff - 0xa7
      0076F7 50 0D            [24] 1581 	jnc	00108$
                                   1582 ;	free result
      0076F9                       1583 00113$:
      0076F9 12 78 B3         [24] 1584 	lcall	_ak820_outline_0162
      0076FC BF A8 00         [24] 1585 	cjne	r7,#0xa8,00198$
      0076FF                       1586 00198$:
      0076FF 40 13            [24] 1587 	jc	00125$
      007701 EF               [12] 1588 	mov	a,r7
      007702 24 3D            [12] 1589 	add	a,#0xff - 0xc2
      007704 40 0E            [24] 1590 	jc	00125$
                                   1591 ;	free result
      007706                       1592 00108$:
                                   1593 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007706 12 78 B3         [24] 1594 	lcall	_ak820_outline_0162
      007709 90 0A 95         [24] 1595 	mov	dptr,#_owned_usage_key_PARM_2
      00770C 74 01            [12] 1596 	mov	a,#0x01
      00770E F0               [24] 1597 	movx	@dptr,a
      00770F 8F 82            [24] 1598 	mov	dpl, r7
                                   1599 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1600 ;	quantum/action.c:1031: }
      007711 02 80 C5         [24] 1601 	ljmp	_owned_usage_key
      007714                       1602 00125$:
      007714 22               [24] 1603 	ret
                                   1604 ;------------------------------------------------------------
                                   1605 ;Allocation info for local variables in function 'unregister_code'
                                   1606 ;------------------------------------------------------------
                                   1607 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1608 ;------------------------------------------------------------
                                   1609 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1610 ;	-----------------------------------------
                                   1611 ;	 function unregister_code
                                   1612 ;	-----------------------------------------
      007715                       1613 _unregister_code:
      007715 E5 82            [12] 1614 	mov	a,dpl
      007717 90 08 38         [24] 1615 	mov	dptr,#_unregister_code_code_10000_724
      00771A F0               [24] 1616 	movx	@dptr,a
                                   1617 ;	quantum/action.c:1038: if (code == KC_NO) {
      00771B E0               [24] 1618 	movx	a,@dptr
      00771C FF               [12] 1619 	mov	r7,a
      00771D 70 01            [24] 1620 	jnz	00121$
                                   1621 ;	quantum/action.c:1039: return;
      00771F 22               [24] 1622 	ret
      007720                       1623 00121$:
                                   1624 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007720 BF 04 00         [24] 1625 	cjne	r7,#0x04,00184$
      007723                       1626 00184$:
      007723 40 12            [24] 1627 	jc	00117$
      007725 EF               [12] 1628 	mov	a,r7
      007726 24 5B            [12] 1629 	add	a,#0xff - 0xa4
      007728 40 0D            [24] 1630 	jc	00117$
                                   1631 ;	free result
                                   1632 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      00772A 8F 82            [24] 1633 	mov	dpl, r7
      00772C 12 7F FC         [24] 1634 	lcall	_del_owned_key
      00772F E5 82            [12] 1635 	mov	a, dpl
      007731 70 01            [24] 1636 	jnz	00102$
      007733 22               [24] 1637 	ret
      007734                       1638 00102$:
                                   1639 ;	quantum/action.c:1080: send_keyboard_report();
      007734 02 82 1A         [24] 1640 	ljmp	_send_keyboard_report
      007737                       1641 00117$:
                                   1642 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007737 12 78 B9         [24] 1643 	lcall	_ak820_outline_0163
      00773A BF E0 00         [24] 1644 	cjne	r7,#0xe0,00188$
      00773D                       1645 00188$:
      00773D 40 1A            [24] 1646 	jc	00113$
      00773F EF               [12] 1647 	mov	a,r7
      007740 24 18            [12] 1648 	add	a,#0xff - 0xe7
      007742 40 15            [24] 1649 	jc	00113$
                                   1650 ;	free result
                                   1651 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007744 74 07            [12] 1652 	mov	a,#0x07
      007746 5F               [12] 1653 	anl	a,r7
      007747 12 78 7E         [24] 1654 	lcall	_ak820_outline_0063
      00774A 80 02            [24] 1655 	sjmp	00192$
      00774C                       1656 00191$:
      00774C 25 E0            [12] 1657 	add	a,acc
      00774E                       1658 00192$:
      00774E D5 F0 FB         [24] 1659 	djnz	b,00191$
      007751 F5 82            [12] 1660 	mov	dpl,a
      007753 12 7E EE         [24] 1661 	lcall	_del_owned_mods
                                   1662 ;	quantum/action.c:1083: send_keyboard_report();
      007756 02 82 1A         [24] 1663 	ljmp	_send_keyboard_report
      007759                       1664 00113$:
                                   1665 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007759 12 78 B9         [24] 1666 	lcall	_ak820_outline_0163
      00775C BF A5 00         [24] 1667 	cjne	r7,#0xa5,00193$
      00775F                       1668 00193$:
      00775F 40 05            [24] 1669 	jc	00111$
      007761 EF               [12] 1670 	mov	a,r7
      007762 24 58            [12] 1671 	add	a,#0xff - 0xa7
      007764 50 0D            [24] 1672 	jnc	00106$
                                   1673 ;	free result
      007766                       1674 00111$:
      007766 12 78 B9         [24] 1675 	lcall	_ak820_outline_0163
      007769 BF A8 00         [24] 1676 	cjne	r7,#0xa8,00196$
      00776C                       1677 00196$:
      00776C 40 12            [24] 1678 	jc	00123$
      00776E EF               [12] 1679 	mov	a,r7
      00776F 24 3D            [12] 1680 	add	a,#0xff - 0xc2
      007771 40 0D            [24] 1681 	jc	00123$
                                   1682 ;	free result
      007773                       1683 00106$:
                                   1684 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007773 12 78 B9         [24] 1685 	lcall	_ak820_outline_0163
      007776 90 0A 95         [24] 1686 	mov	dptr,#_owned_usage_key_PARM_2
      007779 E4               [12] 1687 	clr	a
      00777A F0               [24] 1688 	movx	@dptr,a
      00777B 8F 82            [24] 1689 	mov	dpl, r7
                                   1690 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1691 ;	quantum/action.c:1098: }
      00777D 02 80 C5         [24] 1692 	ljmp	_owned_usage_key
      007780                       1693 00123$:
      007780 22               [24] 1694 	ret
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'tap_code_delay'
                                   1697 ;------------------------------------------------------------
                                   1698 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1699 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1700 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1701 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1702 ;------------------------------------------------------------
                                   1703 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1704 ;	-----------------------------------------
                                   1705 ;	 function tap_code_delay
                                   1706 ;	-----------------------------------------
      007781                       1707 _tap_code_delay:
      007781 E5 82            [12] 1708 	mov	a,dpl
      007783 90 08 3B         [24] 1709 	mov	dptr,#_tap_code_delay_code_10000_737
      007786 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	quantum/action.c:1106: register_code(code);
      007787 E0               [24] 1712 	movx	a,@dptr
      007788 FF               [12] 1713 	mov	r7,a
      007789 F5 82            [12] 1714 	mov	dpl,a
      00778B C0 07            [24] 1715 	push	ar7
      00778D 12 76 A8         [24] 1716 	lcall	_register_code
      007790 D0 07            [24] 1717 	pop	ar7
                                   1718 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007792 90 08 39         [24] 1719 	mov	dptr,#_tap_code_delay_PARM_2
      007795 12 43 7B         [24] 1720 	lcall	_ak820_outline_0097
      007798                       1721 00110$:
      007798 ED               [12] 1722 	mov	a,r5
      007799 4E               [12] 1723 	orl	a,r6
      00779A 60 0D            [24] 1724 	jz	00105$
                                   1725 ;	quantum/action.c:1108: wait_ms(1);
      00779C 90 00 01         [24] 1726 	mov	dptr,#0x0001
      00779F 12 59 E6         [24] 1727 	lcall	_mDelaymS
                                   1728 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0077A2 1D               [12] 1729 	dec	r5
      0077A3 BD FF 01         [24] 1730 	cjne	r5,#0xff,00141$
      0077A6 1E               [12] 1731 	dec	r6
      0077A7                       1732 00141$:
      0077A7 80 EF            [24] 1733 	sjmp	00110$
      0077A9                       1734 00105$:
                                   1735 ;	quantum/action.c:1110: unregister_code(code);
      0077A9 8F 82            [24] 1736 	mov	dpl, r7
                                   1737 ;	quantum/action.c:1111: }
      0077AB 02 77 15         [24] 1738 	ljmp	_unregister_code
                                   1739 ;------------------------------------------------------------
                                   1740 ;Allocation info for local variables in function 'tap_code'
                                   1741 ;------------------------------------------------------------
                                   1742 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1743 ;------------------------------------------------------------
                                   1744 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1745 ;	-----------------------------------------
                                   1746 ;	 function tap_code
                                   1747 ;	-----------------------------------------
      0077AE                       1748 _tap_code:
      0077AE E5 82            [12] 1749 	mov	a,dpl
      0077B0 90 08 3C         [24] 1750 	mov	dptr,#_tap_code_code_10000_744
      0077B3 F0               [24] 1751 	movx	@dptr,a
                                   1752 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0077B4 E0               [24] 1753 	movx	a,@dptr
      0077B5 FF               [12] 1754 	mov	r7,a
      0077B6 BF 39 04         [24] 1755 	cjne	r7,#0x39,00103$
      0077B9 7E 50            [12] 1756 	mov	r6,#0x50
      0077BB 80 02            [24] 1757 	sjmp	00104$
      0077BD                       1758 00103$:
      0077BD 7E 00            [12] 1759 	mov	r6,#0x00
      0077BF                       1760 00104$:
      0077BF 90 08 39         [24] 1761 	mov	dptr,#_tap_code_delay_PARM_2
      0077C2 EE               [12] 1762 	mov	a,r6
      0077C3 12 38 65         [24] 1763 	lcall	_ak820_outline_0123
      0077C6 8F 82            [24] 1764 	mov	dpl, r7
                                   1765 ;	quantum/action.c:1119: }
      0077C8 02 77 81         [24] 1766 	ljmp	_tap_code_delay
                                   1767 ;------------------------------------------------------------
                                   1768 ;Allocation info for local variables in function 'register_mods'
                                   1769 ;------------------------------------------------------------
                                   1770 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1771 ;------------------------------------------------------------
                                   1772 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1773 ;	-----------------------------------------
                                   1774 ;	 function register_mods
                                   1775 ;	-----------------------------------------
      0077CB                       1776 _register_mods:
      0077CB E5 82            [12] 1777 	mov	a,dpl
      0077CD 90 08 3D         [24] 1778 	mov	dptr,#_register_mods_mods_10000_746
      0077D0 F0               [24] 1779 	movx	@dptr,a
                                   1780 ;	quantum/action.c:1126: if (mods) {
      0077D1 E0               [24] 1781 	movx	a,@dptr
      0077D2 FF               [12] 1782 	mov	r7,a
      0077D3 E0               [24] 1783 	movx	a,@dptr
      0077D4 60 08            [24] 1784 	jz	00103$
                                   1785 ;	quantum/action.c:1127: add_owned_mods(mods);
      0077D6 8F 82            [24] 1786 	mov	dpl, r7
      0077D8 12 7E DE         [24] 1787 	lcall	_add_owned_mods
                                   1788 ;	quantum/action.c:1128: send_keyboard_report();
                                   1789 ;	quantum/action.c:1130: }
      0077DB 02 82 1A         [24] 1790 	ljmp	_send_keyboard_report
      0077DE                       1791 00103$:
      0077DE 22               [24] 1792 	ret
                                   1793 ;------------------------------------------------------------
                                   1794 ;Allocation info for local variables in function 'unregister_mods'
                                   1795 ;------------------------------------------------------------
                                   1796 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1797 ;------------------------------------------------------------
                                   1798 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1799 ;	-----------------------------------------
                                   1800 ;	 function unregister_mods
                                   1801 ;	-----------------------------------------
      0077DF                       1802 _unregister_mods:
      0077DF E5 82            [12] 1803 	mov	a,dpl
      0077E1 90 08 3E         [24] 1804 	mov	dptr,#_unregister_mods_mods_10000_750
      0077E4 F0               [24] 1805 	movx	@dptr,a
                                   1806 ;	quantum/action.c:1137: if (mods) {
      0077E5 E0               [24] 1807 	movx	a,@dptr
      0077E6 FF               [12] 1808 	mov	r7,a
      0077E7 E0               [24] 1809 	movx	a,@dptr
      0077E8 60 08            [24] 1810 	jz	00103$
                                   1811 ;	quantum/action.c:1138: del_owned_mods(mods);
      0077EA 8F 82            [24] 1812 	mov	dpl, r7
      0077EC 12 7E EE         [24] 1813 	lcall	_del_owned_mods
                                   1814 ;	quantum/action.c:1139: send_keyboard_report();
                                   1815 ;	quantum/action.c:1141: }
      0077EF 02 82 1A         [24] 1816 	ljmp	_send_keyboard_report
      0077F2                       1817 00103$:
      0077F2 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'register_weak_mods'
                                   1821 ;------------------------------------------------------------
                                   1822 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1823 ;------------------------------------------------------------
                                   1824 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1825 ;	-----------------------------------------
                                   1826 ;	 function register_weak_mods
                                   1827 ;	-----------------------------------------
      0077F3                       1828 _register_weak_mods:
      0077F3 E5 82            [12] 1829 	mov	a,dpl
      0077F5 90 08 3F         [24] 1830 	mov	dptr,#_register_weak_mods_mods_10000_754
      0077F8 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	quantum/action.c:1148: if (mods) {
      0077F9 E0               [24] 1833 	movx	a,@dptr
      0077FA FF               [12] 1834 	mov	r7,a
      0077FB E0               [24] 1835 	movx	a,@dptr
      0077FC 60 08            [24] 1836 	jz	00103$
                                   1837 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0077FE 8F 82            [24] 1838 	mov	dpl, r7
      007800 12 7E FD         [24] 1839 	lcall	_add_owned_weak_mods
                                   1840 ;	quantum/action.c:1150: send_keyboard_report();
                                   1841 ;	quantum/action.c:1152: }
      007803 02 82 1A         [24] 1842 	ljmp	_send_keyboard_report
      007806                       1843 00103$:
      007806 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function unregister_weak_mods
                                   1853 ;	-----------------------------------------
      007807                       1854 _unregister_weak_mods:
      007807 E5 82            [12] 1855 	mov	a,dpl
      007809 90 08 40         [24] 1856 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      00780C F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1159: if (mods) {
      00780D E0               [24] 1859 	movx	a,@dptr
      00780E FF               [12] 1860 	mov	r7,a
      00780F E0               [24] 1861 	movx	a,@dptr
      007810 60 08            [24] 1862 	jz	00103$
                                   1863 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007812 8F 82            [24] 1864 	mov	dpl, r7
      007814 12 7F 0D         [24] 1865 	lcall	_del_owned_weak_mods
                                   1866 ;	quantum/action.c:1161: send_keyboard_report();
                                   1867 ;	quantum/action.c:1163: }
      007817 02 82 1A         [24] 1868 	ljmp	_send_keyboard_report
      00781A                       1869 00103$:
      00781A 22               [24] 1870 	ret
                                   1871 ;------------------------------------------------------------
                                   1872 ;Allocation info for local variables in function 'clear_keyboard'
                                   1873 ;------------------------------------------------------------
                                   1874 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1875 ;	-----------------------------------------
                                   1876 ;	 function clear_keyboard
                                   1877 ;	-----------------------------------------
      00781B                       1878 _clear_keyboard:
                                   1879 ;	quantum/action.c:1170: clear_mods();
      00781B 12 82 EF         [24] 1880 	lcall	_clear_mods
                                   1881 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1882 ;	quantum/action.c:1172: }
      00781E 02 78 21         [24] 1883 	ljmp	_clear_keyboard_but_mods
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard_but_mods
                                   1890 ;	-----------------------------------------
      007821                       1891 _clear_keyboard_but_mods:
                                   1892 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007821 90 0D A1         [24] 1893 	mov	dptr,#_actual_keyboard_report
      007824 12 71 17         [24] 1894 	lcall	_clear_keys_from_report
                                   1895 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1896 ;	quantum/action.c:1181: }
      007827 02 78 2A         [24] 1897 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function clear_keyboard_but_mods_and_keys
                                   1904 ;	-----------------------------------------
      00782A                       1905 _clear_keyboard_but_mods_and_keys:
                                   1906 ;	quantum/action.c:1189: ak820_tapping_cancel();
      00782A 12 47 BA         [24] 1907 	lcall	_ak820_tapping_cancel
                                   1908 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      00782D 12 2E A4         [24] 1909 	lcall	_ak820_oneshot_cancel
                                   1910 ;	quantum/action.c:1209: ak820_combo_cancel();
      007830 12 35 27         [24] 1911 	lcall	_ak820_combo_cancel
                                   1912 ;	quantum/action.c:1212: repeat_key_cancel();
      007833 12 A2 EC         [24] 1913 	lcall	_repeat_key_cancel
                                   1914 ;	quantum/action.c:1214: clear_owned_mods();
      007836 12 7F 1D         [24] 1915 	lcall	_clear_owned_mods
                                   1916 ;	quantum/action.c:1215: clear_owned_keys();
      007839 12 7F 55         [24] 1917 	lcall	_clear_owned_keys
                                   1918 ;	quantum/action.c:1216: clear_owned_usages();
      00783C 12 80 8D         [24] 1919 	lcall	_clear_owned_usages
                                   1920 ;	quantum/action.c:1217: layer_hold_clear();
      00783F 12 79 FF         [24] 1921 	lcall	_layer_hold_clear
                                   1922 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007842 12 9E 6A         [24] 1923 	lcall	_clear_macro_tri_layer
                                   1924 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007845 90 0D A1         [24] 1925 	mov	dptr,#_actual_keyboard_report
      007848 12 71 17         [24] 1926 	lcall	_clear_keys_from_report
                                   1927 ;	quantum/action.c:1224: host_system_send(0);
      00784B 90 00 00         [24] 1928 	mov	dptr,#0x0000
      00784E 12 6E F2         [24] 1929 	lcall	_host_system_send
                                   1930 ;	quantum/action.c:1225: host_consumer_send(0);
      007851 90 00 00         [24] 1931 	mov	dptr,#0x0000
      007854 12 6F 22         [24] 1932 	lcall	_host_consumer_send
                                   1933 ;	quantum/action.c:1227: clear_weak_mods();
      007857 12 83 24         [24] 1934 	lcall	_clear_weak_mods
                                   1935 ;	quantum/action.c:1228: send_keyboard_report();
                                   1936 ;	quantum/action.c:1236: }
      00785A 02 82 1A         [24] 1937 	ljmp	_send_keyboard_report
                                   1938 ;------------------------------------------------------------
                                   1939 ;Allocation info for local variables in function 'is_tap_record'
                                   1940 ;------------------------------------------------------------
                                   1941 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1942 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1945 ;	-----------------------------------------
                                   1946 	.area CSEG    (CODE)
                                   1947 	.area CONST   (CODE)
                                   1948 	.area XINIT   (CODE)
      00C25B                       1949 __xinit__disable_action_cache:
      00C25B 00                    1950 	.db #0x00	;  0
                                   1951 	.area CABS    (ABS,CODE)
                                   1952 
                                   1953 ; Experimental exact instruction outlining.
                                   1954 	.globl _ak820_outline_0004
                                   1955 	.globl _ak820_outline_0009
                                   1956 	.globl _ak820_outline_0010
                                   1957 	.globl _ak820_outline_0011
                                   1958 	.globl _ak820_outline_0012
                                   1959 	.globl _ak820_outline_0016
                                   1960 	.globl _ak820_outline_0017
                                   1961 	.globl _ak820_outline_0019
                                   1962 	.globl _ak820_outline_0031
                                   1963 	.globl _ak820_outline_0039
                                   1964 	.globl _ak820_outline_0050
                                   1965 	.globl _ak820_outline_0051
                                   1966 	.globl _ak820_outline_0055
                                   1967 	.globl _ak820_outline_0058
                                   1968 	.globl _ak820_outline_0063
                                   1969 	.globl _ak820_outline_0071
                                   1970 	.globl _ak820_outline_0075
                                   1971 	.globl _ak820_outline_0085
                                   1972 	.globl _ak820_outline_0097
                                   1973 	.globl _ak820_outline_0104
                                   1974 	.globl _ak820_outline_0105
                                   1975 	.globl _ak820_outline_0107
                                   1976 	.globl _ak820_outline_0108
                                   1977 	.globl _ak820_outline_0110
                                   1978 	.globl _ak820_outline_0117
                                   1979 	.globl _ak820_outline_0121
                                   1980 	.globl _ak820_outline_0122
                                   1981 	.globl _ak820_outline_0123
                                   1982 	.globl _ak820_outline_0129
                                   1983 	.globl _ak820_outline_0139
                                   1984 	.globl _ak820_outline_0140
                                   1985 	.globl _ak820_outline_0145
                                   1986 	.globl _ak820_outline_0154
                                   1987 	.globl _ak820_outline_0162
                                   1988 	.globl _ak820_outline_0163
                                   1989 	.globl _ak820_outline_0180
                                   1990 	.globl _ak820_outline_0186
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0019
      00785D                       1994 _ak820_outline_0019:
      00785D 8E 82            [24] 1995 	mov	dpl,r6
      00785F 8F 83            [24] 1996 	mov	dph,r7
      007861 A3               [24] 1997 	inc	dptr
      007862 E0               [24] 1998 	movx	a,@dptr
      007863 FC               [12] 1999 	mov	r4,a
      007864 7D 00            [12] 2000 	mov	r5,#0x00
      007866 8E 82            [24] 2001 	mov	dpl,r6
      007868 8F 83            [24] 2002 	mov	dph,r7
      00786A E0               [24] 2003 	movx	a,@dptr
      00786B 22               [24] 2004 	ret
                                   2005 
                                   2006 	.area CSEG (CODE)
                                   2007 ; function ak820_outline_0039
      00786C                       2008 _ak820_outline_0039:
      00786C 90 08 33         [24] 2009 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00786F E0               [24] 2010 	movx	a,@dptr
      007870 54 1F            [12] 2011 	anl	a,#0x1f
      007872 F5 82            [12] 2012 	mov	dpl,a
      007874 22               [24] 2013 	ret
                                   2014 
                                   2015 	.area CSEG (CODE)
                                   2016 ; function ak820_outline_0050
      007875                       2017 _ak820_outline_0050:
      007875 A3               [24] 2018 	inc	dptr
      007876 F0               [24] 2019 	movx	@dptr,a
      007877 E4               [12] 2020 	clr	a
      007878 A3               [24] 2021 	inc	dptr
      007879 F0               [24] 2022 	movx	@dptr,a
      00787A 90 0D 7F         [24] 2023 	mov	dptr,#___memcpy_PARM_3
      00787D 22               [24] 2024 	ret
                                   2025 
                                   2026 	.area CSEG (CODE)
                                   2027 ; function ak820_outline_0063
      00787E                       2028 _ak820_outline_0063:
      00787E F5 F0            [12] 2029 	mov	b,a
      007880 05 F0            [12] 2030 	inc	b
      007882 74 01            [12] 2031 	mov	a,#0x01
      007884 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0075
      007885                       2036 _ak820_outline_0075:
      007885 90 08 32         [24] 2037 	mov	dptr,#_process_action_PARM_2
      007888 E0               [24] 2038 	movx	a,@dptr
      007889 F5 82            [12] 2039 	mov	dpl,a
      00788B 22               [24] 2040 	ret
                                   2041 
                                   2042 	.area CSEG (CODE)
                                   2043 ; function ak820_outline_0085
      00788C                       2044 _ak820_outline_0085:
      00788C 90 08 33         [24] 2045 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00788F E0               [24] 2046 	movx	a,@dptr
      007890 03               [12] 2047 	rr	a
      007891 03               [12] 2048 	rr	a
      007892 54 03            [12] 2049 	anl	a,#0x03
      007894 22               [24] 2050 	ret
                                   2051 
                                   2052 	.area CSEG (CODE)
                                   2053 ; function ak820_outline_0108
      007895                       2054 _ak820_outline_0108:
      007895 74 06            [12] 2055 	mov	a,#0x06
      007897 F0               [24] 2056 	movx	@dptr,a
      007898 E4               [12] 2057 	clr	a
      007899 A3               [24] 2058 	inc	dptr
      00789A F0               [24] 2059 	movx	@dptr,a
      00789B 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0110
      00789C                       2064 _ak820_outline_0110:
      00789C 90 08 33         [24] 2065 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00789F E0               [24] 2066 	movx	a,@dptr
      0078A0 54 0F            [12] 2067 	anl	a,#0x0f
      0078A2 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0129
      0078A3                       2072 _ak820_outline_0129:
      0078A3 90 08 32         [24] 2073 	mov	dptr,#_process_action_PARM_2
      0078A6 E0               [24] 2074 	movx	a,@dptr
      0078A7 FE               [12] 2075 	mov	r6,a
      0078A8 A3               [24] 2076 	inc	dptr
      0078A9 E0               [24] 2077 	movx	a,@dptr
      0078AA 54 03            [12] 2078 	anl	a,#0x03
      0078AC FF               [12] 2079 	mov	r7,a
      0078AD 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0154
      0078AE                       2084 _ak820_outline_0154:
      0078AE 90 08 32         [24] 2085 	mov	dptr,#_process_action_PARM_2
      0078B1 E0               [24] 2086 	movx	a,@dptr
      0078B2 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0162
      0078B3                       2091 _ak820_outline_0162:
      0078B3 90 08 37         [24] 2092 	mov	dptr,#_register_code_code_10000_710
      0078B6 E0               [24] 2093 	movx	a,@dptr
      0078B7 FF               [12] 2094 	mov	r7,a
      0078B8 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0163
      0078B9                       2099 _ak820_outline_0163:
      0078B9 90 08 38         [24] 2100 	mov	dptr,#_unregister_code_code_10000_724
      0078BC E0               [24] 2101 	movx	a,@dptr
      0078BD FF               [12] 2102 	mov	r7,a
      0078BE 22               [24] 2103 	ret
