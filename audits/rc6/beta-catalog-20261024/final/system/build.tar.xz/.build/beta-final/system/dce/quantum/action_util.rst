                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_mac_mode
                                    269 	.globl _ak820_gui_process
                                    270 	.globl _ak820_macro_change
                                    271 	.globl _add_owned_mods
                                    272 	.globl _del_owned_mods
                                    273 	.globl _add_owned_weak_mods
                                    274 	.globl _del_owned_weak_mods
                                    275 	.globl _clear_owned_mods
                                    276 	.globl _clear_owned_keys
                                    277 	.globl _add_owned_key
                                    278 	.globl _del_owned_key
                                    279 	.globl _clear_owned_usages
                                    280 	.globl _owned_usage_key
                                    281 	.globl _send_keyboard_report
                                    282 	.globl _get_mods
                                    283 	.globl _clear_mods
                                    284 	.globl _get_weak_mods
                                    285 	.globl _add_weak_mods
                                    286 	.globl _del_weak_mods
                                    287 	.globl _clear_weak_mods
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 	.area	OSEG    (OVR,DATA)
      000054                        554 _change_owned_sloc1_1_0:
      000054                        555 	.ds 1
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      00001E                        569 _ak820_mac_mode::
      00001E                        570 	.ds 1
      00001F                        571 _gui_disabled:
      00001F                        572 	.ds 1
      000020                        573 _ctrl_gui_swapped:
      000020                        574 	.ds 1
      000021                        575 _ak820_gui_process_sloc0_1_0:
      000021                        576 	.ds 1
      000022                        577 _ak820_macro_change_sloc0_1_0:
      000022                        578 	.ds 1
      000023                        579 _change_owned_sloc0_1_0:
      000023                        580 	.ds 1
      000024                        581 _owned_usage_key_sloc0_1_0:
      000024                        582 	.ds 1
                                    583 ;--------------------------------------------------------
                                    584 ; paged external ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area PSEG    (PAG,XDATA)
                                    587 ;--------------------------------------------------------
                                    588 ; uninitialized external ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area XSEG    (XDATA)
      000971                        591 _ak820_gui_process_PARM_2:
      000971                        592 	.ds 1
      000972                        593 _ak820_gui_process_code_10000_294:
      000972                        594 	.ds 2
      000974                        595 _owned_mod_refs:
      000974                        596 	.ds 8
      00097C                        597 _owned_weak_refs:
      00097C                        598 	.ds 8
      000984                        599 _owned_mods:
      000984                        600 	.ds 1
      000985                        601 _owned_weak_mods:
      000985                        602 	.ds 1
      000986                        603 _macro_mods:
      000986                        604 	.ds 2
      000988                        605 _ak820_macro_primitive::
      000988                        606 	.ds 1
      000989                        607 _ak820_macro_cancelled::
      000989                        608 	.ds 1
      00098A                        609 _ak820_macro_change_PARM_2:
      00098A                        610 	.ds 1
      00098B                        611 _ak820_macro_change_PARM_3:
      00098B                        612 	.ds 1
      00098C                        613 _ak820_macro_change_bits_10000_307:
      00098C                        614 	.ds 2
      00098E                        615 _change_owned_PARM_2:
      00098E                        616 	.ds 1
      00098F                        617 _change_owned_mods_10000_312:
      00098F                        618 	.ds 1
      000990                        619 _change_owned_result_10001_316:
      000990                        620 	.ds 1
      000991                        621 _change_owned_bit_20001_317:
      000991                        622 	.ds 1
      000992                        623 _add_owned_mods_mods_10000_325:
      000992                        624 	.ds 1
      000993                        625 _del_owned_mods_mods_10000_327:
      000993                        626 	.ds 1
      000994                        627 _add_owned_weak_mods_mods_10000_329:
      000994                        628 	.ds 1
      000995                        629 _del_owned_weak_mods_mods_10000_331:
      000995                        630 	.ds 1
      000996                        631 _key_refs:
      000996                        632 	.ds 165
      000A3B                        633 _distinct_keys:
      000A3B                        634 	.ds 1
      000A3C                        635 _macro_keys:
      000A3C                        636 	.ds 21
      000A51                        637 _add_owned_key_code_10000_340:
      000A51                        638 	.ds 1
      000A52                        639 _del_owned_key_code_10000_355:
      000A52                        640 	.ds 1
      000A53                        641 _usage_refs:
      000A53                        642 	.ds 30
      000A71                        643 _usage_order:
      000A71                        644 	.ds 30
      000A8F                        645 _usage_lengths:
      000A8F                        646 	.ds 2
      000A91                        647 _macro_usages:
      000A91                        648 	.ds 4
      000A95                        649 _owned_usage_key_PARM_2:
      000A95                        650 	.ds 1
      000A96                        651 _owned_usage_key_code_10000_382:
      000A96                        652 	.ds 1
      000A97                        653 _owned_usage_key___200000085_20000_383:
      000A97                        654 	.ds 2
      000A99                        655 _owned_usage_key_which_10000_383:
      000A99                        656 	.ds 1
      000A9A                        657 _owned_usage_key_count_10000_383:
      000A9A                        658 	.ds 1
      000A9B                        659 _owned_usage_key_pos_30001_390:
      000A9B                        660 	.ds 1
      000A9C                        661 _owned_usage_key_key_40000_395:
      000A9C                        662 	.ds 1
      000A9D                        663 _send_keyboard_report_last_report_10001_407:
      000A9D                        664 	.ds 32
      000ABD                        665 _send_keyboard_report_changed_10001_407:
      000ABD                        666 	.ds 1
      000ABE                        667 _add_weak_mods_mods_10000_425:
      000ABE                        668 	.ds 1
      000ABF                        669 _del_weak_mods_mods_10000_427:
      000ABF                        670 	.ds 1
                                    671 ;--------------------------------------------------------
                                    672 ; absolute external ram data
                                    673 ;--------------------------------------------------------
                                    674 	.area XABS    (ABS,XDATA)
                                    675 ;--------------------------------------------------------
                                    676 ; initialized external ram data
                                    677 ;--------------------------------------------------------
                                    678 	.area XISEG   (XDATA)
      000D9F                        679 _real_mods:
      000D9F                        680 	.ds 1
      000DA0                        681 _weak_mods:
      000DA0                        682 	.ds 1
      000DA1                        683 _actual_keyboard_report::
      000DA1                        684 	.ds 32
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function ak820_gui_process
                                    727 ;	-----------------------------------------
      007C68                        728 _ak820_gui_process:
      007C68 12 38 40         [24]  729 	lcall	_ak820_outline_0104
      007C6B 90 09 72         [24]  730 	mov	dptr,#_ak820_gui_process_code_10000_294
      007C6E 12 38 45         [24]  731 	lcall	_ak820_outline_0105
                                    732 ;	quantum/action_util.c:62: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) {
      007C71 90 09 72         [24]  733 	mov	dptr,#_ak820_gui_process_code_10000_294
      007C74 12 37 F7         [24]  734 	lcall	_ak820_outline_0051
      007C77 E4               [12]  735 	clr	a
      007C78 BE 14 04         [24]  736 	cjne	r6,#0x14,00203$
      007C7B BF 70 01         [24]  737 	cjne	r7,#0x70,00203$
      007C7E 04               [12]  738 	inc	a
      007C7F                        739 00203$:
      007C7F FD               [12]  740 	mov	r5,a
      007C80 70 0E            [24]  741 	jnz	00103$
      007C82 BE 15 05         [24]  742 	cjne	r6,#0x15,00206$
      007C85 BF 70 02         [24]  743 	cjne	r7,#0x70,00206$
      007C88 80 06            [24]  744 	sjmp	00103$
      007C8A                        745 00206$:
      007C8A BE 16 27         [24]  746 	cjne	r6,#0x16,00104$
      007C8D BF 70 24         [24]  747 	cjne	r7,#0x70,00104$
      007C90                        748 00103$:
                                    749 ;	quantum/action_util.c:63: if (pressed) {
      007C90 90 09 71         [24]  750 	mov	dptr,#_ak820_gui_process_PARM_2
      007C93 E0               [24]  751 	movx	a,@dptr
      007C94 60 1A            [24]  752 	jz	00102$
                                    753 ;	quantum/action_util.c:64: ak820_mac_mode = code == QK_MAGIC_TOGGLE_ALT_GUI ? !ak820_mac_mode : code == QK_MAGIC_SWAP_ALT_GUI;
      007C96 BE 16 0D         [24]  754 	cjne	r6,#0x16,00120$
      007C99 BF 70 0A         [24]  755 	cjne	r7,#0x70,00120$
      007C9C A2 1E            [12]  756 	mov	c,_ak820_mac_mode
      007C9E B3               [12]  757 	cpl	c
      007C9F 92 21            [24]  758 	mov  _ak820_gui_process_sloc0_1_0,c
      007CA1 E4               [12]  759 	clr	a
      007CA2 33               [12]  760 	rlc	a
      007CA3 FC               [12]  761 	mov	r4,a
      007CA4 80 02            [24]  762 	sjmp	00121$
      007CA6                        763 00120$:
      007CA6 8D 04            [24]  764 	mov	ar4,r5
      007CA8                        765 00121$:
                                    766 ;	assignBit
      007CA8 EC               [12]  767 	mov	a,r4
      007CA9 24 FF            [12]  768 	add	a,#0xff
      007CAB 92 1E            [24]  769 	mov	_ak820_mac_mode,c
                                    770 ;	quantum/action_util.c:65: send_keyboard_report();
      007CAD 12 81 A3         [24]  771 	lcall	_send_keyboard_report
      007CB0                        772 00102$:
                                    773 ;	quantum/action_util.c:67: return false;
      007CB0 75 82 00         [24]  774 	mov	dpl, #0x00
      007CB3 22               [24]  775 	ret
      007CB4                        776 00104$:
                                    777 ;	quantum/action_util.c:71: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) {
      007CB4 E4               [12]  778 	clr	a
      007CB5 BE 1B 04         [24]  779 	cjne	r6,#0x1b,00212$
      007CB8 BF 70 01         [24]  780 	cjne	r7,#0x70,00212$
      007CBB 04               [12]  781 	inc	a
      007CBC                        782 00212$:
      007CBC FD               [12]  783 	mov	r5,a
      007CBD 70 0E            [24]  784 	jnz	00109$
      007CBF BE 1C 05         [24]  785 	cjne	r6,#0x1c,00215$
      007CC2 BF 70 02         [24]  786 	cjne	r7,#0x70,00215$
      007CC5 80 06            [24]  787 	sjmp	00109$
      007CC7                        788 00215$:
      007CC7 BE 1D 27         [24]  789 	cjne	r6,#0x1d,00110$
      007CCA BF 70 24         [24]  790 	cjne	r7,#0x70,00110$
      007CCD                        791 00109$:
                                    792 ;	quantum/action_util.c:72: if (pressed) {
      007CCD 90 09 71         [24]  793 	mov	dptr,#_ak820_gui_process_PARM_2
      007CD0 E0               [24]  794 	movx	a,@dptr
      007CD1 60 1A            [24]  795 	jz	00108$
                                    796 ;	quantum/action_util.c:73: ctrl_gui_swapped = code == QK_MAGIC_TOGGLE_CTL_GUI ? !ctrl_gui_swapped : code == QK_MAGIC_SWAP_CTL_GUI;
      007CD3 BE 1D 0D         [24]  797 	cjne	r6,#0x1d,00122$
      007CD6 BF 70 0A         [24]  798 	cjne	r7,#0x70,00122$
      007CD9 A2 20            [12]  799 	mov	c,_ctrl_gui_swapped
      007CDB B3               [12]  800 	cpl	c
      007CDC 92 21            [24]  801 	mov  _ak820_gui_process_sloc0_1_0,c
      007CDE E4               [12]  802 	clr	a
      007CDF 33               [12]  803 	rlc	a
      007CE0 FC               [12]  804 	mov	r4,a
      007CE1 80 02            [24]  805 	sjmp	00123$
      007CE3                        806 00122$:
      007CE3 8D 04            [24]  807 	mov	ar4,r5
      007CE5                        808 00123$:
                                    809 ;	assignBit
      007CE5 EC               [12]  810 	mov	a,r4
      007CE6 24 FF            [12]  811 	add	a,#0xff
      007CE8 92 20            [24]  812 	mov	_ctrl_gui_swapped,c
                                    813 ;	quantum/action_util.c:74: send_keyboard_report();
      007CEA 12 81 A3         [24]  814 	lcall	_send_keyboard_report
      007CED                        815 00108$:
                                    816 ;	quantum/action_util.c:76: return false;
      007CED 75 82 00         [24]  817 	mov	dpl, #0x00
      007CF0 22               [24]  818 	ret
      007CF1                        819 00110$:
                                    820 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007CF1 C3               [12]  821 	clr	c
      007CF2 EE               [12]  822 	mov	a,r6
      007CF3 94 09            [12]  823 	subb	a,#0x09
      007CF5 EF               [12]  824 	mov	a,r7
      007CF6 94 70            [12]  825 	subb	a,#0x70
      007CF8 40 08            [24]  826 	jc	00113$
      007CFA 74 0B            [12]  827 	mov	a,#0x0b
      007CFC 9E               [12]  828 	subb	a,r6
      007CFD 74 70            [12]  829 	mov	a,#0x70
      007CFF 9F               [12]  830 	subb	a,r7
      007D00 50 04            [24]  831 	jnc	00114$
                                    832 ;	free result
      007D02                        833 00113$:
      007D02 75 82 01         [24]  834 	mov	dpl, #0x01
      007D05 22               [24]  835 	ret
      007D06                        836 00114$:
                                    837 ;	quantum/action_util.c:81: if (pressed) {
      007D06 90 09 71         [24]  838 	mov	dptr,#_ak820_gui_process_PARM_2
      007D09 E0               [24]  839 	movx	a,@dptr
      007D0A 60 21            [24]  840 	jz	00117$
                                    841 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007D0C BE 0B 0D         [24]  842 	cjne	r6,#0x0b,00124$
      007D0F BF 70 0A         [24]  843 	cjne	r7,#0x70,00124$
      007D12 A2 1F            [12]  844 	mov	c,_gui_disabled
      007D14 B3               [12]  845 	cpl	c
      007D15 92 21            [24]  846 	mov  _ak820_gui_process_sloc0_1_0,c
      007D17 E4               [12]  847 	clr	a
      007D18 33               [12]  848 	rlc	a
      007D19 FD               [12]  849 	mov	r5,a
      007D1A 80 09            [24]  850 	sjmp	00125$
      007D1C                        851 00124$:
      007D1C E4               [12]  852 	clr	a
      007D1D BE 0A 04         [24]  853 	cjne	r6,#0x0a,00226$
      007D20 BF 70 01         [24]  854 	cjne	r7,#0x70,00226$
      007D23 04               [12]  855 	inc	a
      007D24                        856 00226$:
      007D24 FD               [12]  857 	mov	r5,a
      007D25                        858 00125$:
                                    859 ;	assignBit
      007D25 ED               [12]  860 	mov	a,r5
      007D26 24 FF            [12]  861 	add	a,#0xff
      007D28 92 1F            [24]  862 	mov	_gui_disabled,c
                                    863 ;	quantum/action_util.c:83: send_keyboard_report();
      007D2A 12 81 A3         [24]  864 	lcall	_send_keyboard_report
      007D2D                        865 00117$:
                                    866 ;	quantum/action_util.c:85: return false;
      007D2D 75 82 00         [24]  867 	mov	dpl, #0x00
                                    868 ;	quantum/action_util.c:89: }
      007D30 22               [24]  869 	ret
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'ak820_macro_change'
                                    872 ;------------------------------------------------------------
                                    873 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    874 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    875 ;bits          Allocated with name '_ak820_macro_change_bits_10000_307'
                                    876 ;mask          Allocated with name '_ak820_macro_change_mask_10001_310'
                                    877 ;------------------------------------------------------------
                                    878 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function ak820_macro_change
                                    881 ;	-----------------------------------------
      007D31                        882 _ak820_macro_change:
      007D31 12 38 40         [24]  883 	lcall	_ak820_outline_0104
      007D34 90 09 8C         [24]  884 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007D37 12 38 45         [24]  885 	lcall	_ak820_outline_0105
                                    886 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007D3A 90 09 88         [24]  887 	mov	dptr,#_ak820_macro_primitive
      007D3D E0               [24]  888 	movx	a,@dptr
      007D3E 70 04            [24]  889 	jnz	00102$
      007D40 75 82 01         [24]  890 	mov	dpl, #0x01
      007D43 22               [24]  891 	ret
      007D44                        892 00102$:
                                    893 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007D44 90 09 8A         [24]  894 	mov	dptr,#_ak820_macro_change_PARM_2
      007D47 E0               [24]  895 	movx	a,@dptr
      007D48 FF               [12]  896 	mov	r7,a
      007D49 74 07            [12]  897 	mov	a,#0x07
      007D4B 5F               [12]  898 	anl	a,r7
      007D4C 12 78 2A         [24]  899 	lcall	_ak820_outline_0063
      007D4F 80 02            [24]  900 	sjmp	00123$
      007D51                        901 00122$:
      007D51 25 E0            [12]  902 	add	a,acc
      007D53                        903 00123$:
      007D53 D5 F0 FB         [24]  904 	djnz	b,00122$
      007D56 FE               [12]  905 	mov	r6,a
                                    906 ;	quantum/action_util.c:101: bits += index >> 3;
      007D57 EF               [12]  907 	mov	a,r7
      007D58 12 58 00         [24]  908 	lcall	_ak820_outline_0168
      007D5B FF               [12]  909 	mov	r7,a
      007D5C 90 09 8C         [24]  910 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007D5F 12 38 16         [24]  911 	lcall	_ak820_outline_0060
      007D62 90 09 8C         [24]  912 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007D65 EF               [12]  913 	mov	a,r7
      007D66 2C               [12]  914 	add	a, r4
      007D67 F0               [24]  915 	movx	@dptr,a
      007D68 E4               [12]  916 	clr	a
      007D69 3D               [12]  917 	addc	a, r5
      007D6A A3               [24]  918 	inc	dptr
      007D6B F0               [24]  919 	movx	@dptr,a
                                    920 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007D6C 90 09 8C         [24]  921 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007D6F E0               [24]  922 	movx	a,@dptr
      007D70 FD               [12]  923 	mov	r5,a
      007D71 A3               [24]  924 	inc	dptr
      007D72 E0               [24]  925 	movx	a,@dptr
      007D73 FF               [12]  926 	mov	r7,a
      007D74 12 83 16         [24]  927 	lcall	_ak820_outline_0187
      007D77 E0               [24]  928 	movx	a,@dptr
      007D78 FC               [12]  929 	mov	r4,a
      007D79 EE               [12]  930 	mov	a,r6
      007D7A 5C               [12]  931 	anl	a,r4
      007D7B B4 01 00         [24]  932 	cjne	a,#0x01,00124$
      007D7E                        933 00124$:
      007D7E B3               [12]  934 	cpl	c
      007D7F 92 22            [24]  935 	mov	_ak820_macro_change_sloc0_1_0,c
      007D81 90 09 8B         [24]  936 	mov	dptr,#_ak820_macro_change_PARM_3
      007D84 E0               [24]  937 	movx	a,@dptr
      007D85 FB               [12]  938 	mov	r3,a
      007D86 A2 22            [12]  939 	mov	c,_ak820_macro_change_sloc0_1_0
      007D88 E4               [12]  940 	clr	a
      007D89 33               [12]  941 	rlc	a
      007D8A B5 03 04         [24]  942 	cjne	a,ar3,00104$
      007D8D 75 82 00         [24]  943 	mov	dpl, #0x00
      007D90 22               [24]  944 	ret
      007D91                        945 00104$:
                                    946 ;	quantum/action_util.c:103: *bits ^= mask;
      007D91 EC               [12]  947 	mov	a,r4
      007D92 62 06            [12]  948 	xrl	ar6,a
      007D94 12 83 16         [24]  949 	lcall	_ak820_outline_0187
      007D97 EE               [12]  950 	mov	a,r6
      007D98 F0               [24]  951 	movx	@dptr,a
                                    952 ;	quantum/action_util.c:104: return true;
      007D99 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	quantum/action_util.c:105: }
      007D9C 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'change_owned'
                                    958 ;------------------------------------------------------------
                                    959 ;mode          Allocated with name '_change_owned_PARM_2'
                                    960 ;mods          Allocated with name '_change_owned_mods_10000_312'
                                    961 ;kind          Allocated with name '_change_owned_kind_10000_313'
                                    962 ;pressed       Allocated with name '_change_owned_pressed_10000_313'
                                    963 ;refs          Allocated with name '_change_owned_refs_10000_313'
                                    964 ;old           Allocated with name '_change_owned_old_30000_315'
                                    965 ;result        Allocated with name '_change_owned_result_10001_316'
                                    966 ;i             Allocated with name '_change_owned_i_20001_317'
                                    967 ;bit           Allocated with name '_change_owned_bit_20001_317'
                                    968 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    969 ;------------------------------------------------------------
                                    970 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function change_owned
                                    973 ;	-----------------------------------------
      007D9D                        974 _change_owned:
      007D9D E5 82            [12]  975 	mov	a,dpl
      007D9F 90 09 8F         [24]  976 	mov	dptr,#_change_owned_mods_10000_312
      007DA2 F0               [24]  977 	movx	@dptr,a
                                    978 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007DA3 90 09 8E         [24]  979 	mov	dptr,#_change_owned_PARM_2
      007DA6 E0               [24]  980 	movx	a,@dptr
      007DA7 FF               [12]  981 	mov	r7,a
      007DA8 C3               [12]  982 	clr	c
      007DA9 13               [12]  983 	rrc	a
      007DAA FE               [12]  984 	mov	r6,a
                                    985 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007DAB 53 07 01         [24]  986 	anl	ar7,#0x01
      007DAE EF               [12]  987 	mov	a,r7
      007DAF B4 01 00         [24]  988 	cjne	a,#0x01,00205$
      007DB2                        989 00205$:
      007DB2 92 23            [24]  990 	mov  _change_owned_sloc0_1_0,c
      007DB4 B3               [12]  991 	cpl	c
      007DB5 E4               [12]  992 	clr	a
      007DB6 33               [12]  993 	rlc	a
      007DB7 F5 54            [12]  994 	mov	_change_owned_sloc1_1_0,a
                                    995 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007DB9 EE               [12]  996 	mov	a,r6
      007DBA 60 06            [24]  997 	jz	00121$
      007DBC 7D 7C            [12]  998 	mov	r5,#_owned_weak_refs
      007DBE 7F 09            [12]  999 	mov	r7,#(_owned_weak_refs >> 8)
      007DC0 80 04            [24] 1000 	sjmp	00122$
      007DC2                       1001 00121$:
      007DC2 7D 74            [12] 1002 	mov	r5,#_owned_mod_refs
      007DC4 7F 09            [12] 1003 	mov	r7,#(_owned_mod_refs >> 8)
      007DC6                       1004 00122$:
                                   1005 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007DC6 90 09 88         [24] 1006 	mov	dptr,#_ak820_macro_primitive
      007DC9 E0               [24] 1007 	movx	a,@dptr
      007DCA 60 37            [24] 1008 	jz	00102$
                                   1009 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007DCC EE               [12] 1010 	mov	a,r6
      007DCD 24 86            [12] 1011 	add	a, #_macro_mods
      007DCF FB               [12] 1012 	mov	r3,a
      007DD0 E4               [12] 1013 	clr	a
      007DD1 34 09            [12] 1014 	addc	a, #(_macro_mods >> 8)
      007DD3 FC               [12] 1015 	mov	r4,a
      007DD4 12 49 B4         [24] 1016 	lcall	_ak820_outline_0065
                                   1017 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007DD7 E5 54            [12] 1018 	mov	a,_change_owned_sloc1_1_0
      007DD9 60 0A            [24] 1019 	jz	00123$
      007DDB 90 09 8F         [24] 1020 	mov	dptr,#_change_owned_mods_10000_312
      007DDE E0               [24] 1021 	movx	a,@dptr
      007DDF F9               [12] 1022 	mov	r1,a
      007DE0 EA               [12] 1023 	mov	a,r2
      007DE1 42 01            [12] 1024 	orl	ar1,a
      007DE3 80 07            [24] 1025 	sjmp	00124$
      007DE5                       1026 00123$:
      007DE5 90 09 8F         [24] 1027 	mov	dptr,#_change_owned_mods_10000_312
      007DE8 E0               [24] 1028 	movx	a,@dptr
      007DE9 F4               [12] 1029 	cpl	a
      007DEA 5A               [12] 1030 	anl	a,r2
      007DEB F9               [12] 1031 	mov	r1,a
      007DEC                       1032 00124$:
      007DEC 12 33 FC         [24] 1033 	lcall	_ak820_outline_0122
      007DEF E9               [12] 1034 	mov	a,r1
      007DF0 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007DF1 E5 54            [12] 1037 	mov	a,_change_owned_sloc1_1_0
      007DF3 60 06            [24] 1038 	jz	00125$
      007DF5 74 FF            [12] 1039 	mov	a,#0xff
      007DF7 6A               [12] 1040 	xrl	a,r2
      007DF8 FC               [12] 1041 	mov	r4,a
      007DF9 80 02            [24] 1042 	sjmp	00126$
      007DFB                       1043 00125$:
      007DFB 8A 04            [24] 1044 	mov	ar4,r2
      007DFD                       1045 00126$:
      007DFD 90 09 8F         [24] 1046 	mov	dptr,#_change_owned_mods_10000_312
      007E00 E0               [24] 1047 	movx	a,@dptr
      007E01 5C               [12] 1048 	anl	a,r4
      007E02 F0               [24] 1049 	movx	@dptr,a
      007E03                       1050 00102$:
                                   1051 ;	quantum/action_util.c:115: uint8_t result = 0;
      007E03 90 09 90         [24] 1052 	mov	dptr,#_change_owned_result_10001_316
      007E06 E4               [12] 1053 	clr	a
      007E07 F0               [24] 1054 	movx	@dptr,a
                                   1055 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007E08 90 09 91         [24] 1056 	mov	dptr,#_change_owned_bit_20001_317
      007E0B 04               [12] 1057 	inc	a
      007E0C F0               [24] 1058 	movx	@dptr,a
      007E0D 90 09 8F         [24] 1059 	mov	dptr,#_change_owned_mods_10000_312
      007E10 E0               [24] 1060 	movx	a,@dptr
      007E11 FC               [12] 1061 	mov	r4,a
      007E12 7B 00            [12] 1062 	mov	r3,#0x00
      007E14                       1063 00117$:
      007E14 BB 08 00         [24] 1064 	cjne	r3,#0x08,00210$
      007E17                       1065 00210$:
      007E17 50 3F            [24] 1066 	jnc	00112$
                                   1067 ;	quantum/action_util.c:117: if (mods & bit) {
      007E19 90 09 91         [24] 1068 	mov	dptr,#_change_owned_bit_20001_317
      007E1C E0               [24] 1069 	movx	a,@dptr
      007E1D 5C               [12] 1070 	anl	a,r4
      007E1E 60 1C            [24] 1071 	jz	00109$
                                   1072 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007E20 E5 54            [12] 1073 	mov	a,_change_owned_sloc1_1_0
      007E22 60 0C            [24] 1074 	jz	00106$
      007E24 EB               [12] 1075 	mov	a,r3
      007E25 2D               [12] 1076 	add	a, r5
      007E26 12 37 CC         [24] 1077 	lcall	_ak820_outline_0014
      007E29 F8               [12] 1078 	mov	r0,a
      007E2A 08               [12] 1079 	inc	r0
      007E2B 12 82 C1         [24] 1080 	lcall	_ak820_outline_0064
      007E2E 80 0C            [24] 1081 	sjmp	00109$
      007E30                       1082 00106$:
                                   1083 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007E30 EB               [12] 1084 	mov	a,r3
      007E31 2D               [12] 1085 	add	a, r5
      007E32 12 37 CC         [24] 1086 	lcall	_ak820_outline_0014
      007E35 F8               [12] 1087 	mov	r0,a
      007E36 60 04            [24] 1088 	jz	00109$
      007E38 18               [12] 1089 	dec	r0
      007E39 12 82 C1         [24] 1090 	lcall	_ak820_outline_0064
      007E3C                       1091 00109$:
                                   1092 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007E3C EB               [12] 1093 	mov	a,r3
      007E3D 2D               [12] 1094 	add	a, r5
      007E3E 12 37 CC         [24] 1095 	lcall	_ak820_outline_0014
      007E41 60 0B            [24] 1096 	jz	00118$
      007E43 90 09 91         [24] 1097 	mov	dptr,#_change_owned_bit_20001_317
      007E46 E0               [24] 1098 	movx	a,@dptr
      007E47 FA               [12] 1099 	mov	r2,a
      007E48 90 09 90         [24] 1100 	mov	dptr,#_change_owned_result_10001_316
      007E4B E0               [24] 1101 	movx	a,@dptr
      007E4C 4A               [12] 1102 	orl	a,r2
      007E4D F0               [24] 1103 	movx	@dptr,a
      007E4E                       1104 00118$:
                                   1105 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007E4E 0B               [12] 1106 	inc	r3
      007E4F 90 09 91         [24] 1107 	mov	dptr,#_change_owned_bit_20001_317
      007E52 E0               [24] 1108 	movx	a,@dptr
      007E53 25 E0            [12] 1109 	add	a,acc
      007E55 F0               [24] 1110 	movx	@dptr,a
      007E56 80 BC            [24] 1111 	sjmp	00117$
      007E58                       1112 00112$:
                                   1113 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007E58 EE               [12] 1114 	mov	a,r6
      007E59 60 09            [24] 1115 	jz	00114$
      007E5B 90 09 90         [24] 1116 	mov	dptr,#_change_owned_result_10001_316
      007E5E E0               [24] 1117 	movx	a,@dptr
      007E5F 90 09 85         [24] 1118 	mov	dptr,#_owned_weak_mods
      007E62 F0               [24] 1119 	movx	@dptr,a
      007E63 22               [24] 1120 	ret
      007E64                       1121 00114$:
                                   1122 ;	quantum/action_util.c:124: else owned_mods = result;
      007E64 90 09 90         [24] 1123 	mov	dptr,#_change_owned_result_10001_316
      007E67 E0               [24] 1124 	movx	a,@dptr
      007E68 90 09 84         [24] 1125 	mov	dptr,#_owned_mods
      007E6B F0               [24] 1126 	movx	@dptr,a
                                   1127 ;	quantum/action_util.c:125: }
      007E6C 22               [24] 1128 	ret
                                   1129 ;------------------------------------------------------------
                                   1130 ;Allocation info for local variables in function 'add_owned_mods'
                                   1131 ;------------------------------------------------------------
                                   1132 ;mods          Allocated with name '_add_owned_mods_mods_10000_325'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function add_owned_mods
                                   1137 ;	-----------------------------------------
      007E6D                       1138 _add_owned_mods:
      007E6D E5 82            [12] 1139 	mov	a,dpl
      007E6F 90 09 92         [24] 1140 	mov	dptr,#_add_owned_mods_mods_10000_325
      007E72 12 82 E1         [24] 1141 	lcall	_ak820_outline_0114
      007E75 74 01            [12] 1142 	mov	a,#0x01
      007E77 F0               [24] 1143 	movx	@dptr,a
      007E78 8F 82            [24] 1144 	mov	dpl, r7
      007E7A A1 9D            [24] 1145 	ajmp	_change_owned
                                   1146 ;------------------------------------------------------------
                                   1147 ;Allocation info for local variables in function 'del_owned_mods'
                                   1148 ;------------------------------------------------------------
                                   1149 ;mods          Allocated with name '_del_owned_mods_mods_10000_327'
                                   1150 ;------------------------------------------------------------
                                   1151 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1152 ;	-----------------------------------------
                                   1153 ;	 function del_owned_mods
                                   1154 ;	-----------------------------------------
      007E7C                       1155 _del_owned_mods:
      007E7C E5 82            [12] 1156 	mov	a,dpl
      007E7E 90 09 93         [24] 1157 	mov	dptr,#_del_owned_mods_mods_10000_327
      007E81 12 82 E1         [24] 1158 	lcall	_ak820_outline_0114
      007E84 E4               [12] 1159 	clr	a
      007E85 F0               [24] 1160 	movx	@dptr,a
      007E86 8F 82            [24] 1161 	mov	dpl, r7
      007E88 A1 9D            [24] 1162 	ajmp	_change_owned
                                   1163 ;------------------------------------------------------------
                                   1164 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1165 ;------------------------------------------------------------
                                   1166 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_329'
                                   1167 ;------------------------------------------------------------
                                   1168 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1169 ;	-----------------------------------------
                                   1170 ;	 function add_owned_weak_mods
                                   1171 ;	-----------------------------------------
      007E8A                       1172 _add_owned_weak_mods:
      007E8A E5 82            [12] 1173 	mov	a,dpl
      007E8C 90 09 94         [24] 1174 	mov	dptr,#_add_owned_weak_mods_mods_10000_329
      007E8F 12 82 E1         [24] 1175 	lcall	_ak820_outline_0114
      007E92 74 03            [12] 1176 	mov	a,#0x03
      007E94 F0               [24] 1177 	movx	@dptr,a
      007E95 8F 82            [24] 1178 	mov	dpl, r7
      007E97 A1 9D            [24] 1179 	ajmp	_change_owned
                                   1180 ;------------------------------------------------------------
                                   1181 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1182 ;------------------------------------------------------------
                                   1183 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_331'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function del_owned_weak_mods
                                   1188 ;	-----------------------------------------
      007E99                       1189 _del_owned_weak_mods:
      007E99 E5 82            [12] 1190 	mov	a,dpl
      007E9B 90 09 95         [24] 1191 	mov	dptr,#_del_owned_weak_mods_mods_10000_331
      007E9E 12 82 E1         [24] 1192 	lcall	_ak820_outline_0114
      007EA1 74 02            [12] 1193 	mov	a,#0x02
      007EA3 F0               [24] 1194 	movx	@dptr,a
      007EA4 8F 82            [24] 1195 	mov	dpl, r7
      007EA6 A1 9D            [24] 1196 	ajmp	_change_owned
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1199 ;------------------------------------------------------------
                                   1200 ;i             Allocated with name '_clear_owned_mods_i_20000_335'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function clear_owned_mods
                                   1205 ;	-----------------------------------------
      007EA8                       1206 _clear_owned_mods:
                                   1207 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007EA8 7F 00            [12] 1208 	mov	r7,#0x00
      007EAA                       1209 00103$:
      007EAA BF 08 00         [24] 1210 	cjne	r7,#0x08,00122$
      007EAD                       1211 00122$:
      007EAD 50 1A            [24] 1212 	jnc	00101$
      007EAF EF               [12] 1213 	mov	a,r7
      007EB0 24 74            [12] 1214 	add	a, #_owned_mod_refs
      007EB2 FD               [12] 1215 	mov	r5,a
      007EB3 E4               [12] 1216 	clr	a
      007EB4 34 09            [12] 1217 	addc	a, #(_owned_mod_refs >> 8)
      007EB6 FE               [12] 1218 	mov	r6,a
      007EB7 EF               [12] 1219 	mov	a,r7
      007EB8 24 7C            [12] 1220 	add	a, #_owned_weak_refs
      007EBA F5 82            [12] 1221 	mov	dpl,a
      007EBC E4               [12] 1222 	clr	a
      007EBD 34 09            [12] 1223 	addc	a, #(_owned_weak_refs >> 8)
      007EBF F5 83            [12] 1224 	mov	dph,a
      007EC1 E4               [12] 1225 	clr	a
      007EC2 F0               [24] 1226 	movx	@dptr,a
      007EC3 12 82 E8         [24] 1227 	lcall	_ak820_outline_0119
      007EC6 0F               [12] 1228 	inc	r7
      007EC7 80 E1            [24] 1229 	sjmp	00103$
      007EC9                       1230 00101$:
                                   1231 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007EC9 90 09 87         [24] 1232 	mov	dptr,#(_macro_mods + 0x0001)
      007ECC E4               [12] 1233 	clr	a
      007ECD F0               [24] 1234 	movx	@dptr,a
      007ECE 90 09 86         [24] 1235 	mov	dptr,#_macro_mods
      007ED1 F0               [24] 1236 	movx	@dptr,a
      007ED2 90 09 85         [24] 1237 	mov	dptr,#_owned_weak_mods
      007ED5 F0               [24] 1238 	movx	@dptr,a
      007ED6 90 09 84         [24] 1239 	mov	dptr,#_owned_mods
      007ED9 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007EDA 90 09 89         [24] 1242 	mov	dptr,#_ak820_macro_cancelled
      007EDD 04               [12] 1243 	inc	a
      007EDE F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:134: }
      007EDF 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1249 ;------------------------------------------------------------
                                   1250 ;i             Allocated with name '_clear_owned_keys_i_20000_338'
                                   1251 ;i             Allocated with name '_clear_owned_keys_i_20000_339'
                                   1252 ;------------------------------------------------------------
                                   1253 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1254 ;	-----------------------------------------
                                   1255 ;	 function clear_owned_keys
                                   1256 ;	-----------------------------------------
      007EE0                       1257 _clear_owned_keys:
                                   1258 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007EE0 7F 00            [12] 1259 	mov	r7,#0x00
      007EE2                       1260 00104$:
      007EE2 EF               [12] 1261 	mov	a,r7
      007EE3 24 5B            [12] 1262 	add	a,#0xff - 0xa4
      007EE5 40 0D            [24] 1263 	jc	00101$
                                   1264 ;	free result
      007EE7 EF               [12] 1265 	mov	a,r7
      007EE8 24 96            [12] 1266 	add	a, #_key_refs
      007EEA F5 82            [12] 1267 	mov	dpl,a
      007EEC E4               [12] 1268 	clr	a
      007EED 34 09            [12] 1269 	addc	a, #(_key_refs >> 8)
      007EEF 12 7C 59         [24] 1270 	lcall	_ak820_outline_0158
      007EF2 80 EE            [24] 1271 	sjmp	00104$
      007EF4                       1272 00101$:
                                   1273 ;	quantum/action_util.c:142: distinct_keys = 0;
      007EF4 90 0A 3B         [24] 1274 	mov	dptr,#_distinct_keys
      007EF7 E4               [12] 1275 	clr	a
      007EF8 F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007EF9 FF               [12] 1278 	mov	r7,a
      007EFA                       1279 00107$:
      007EFA BF 15 00         [24] 1280 	cjne	r7,#0x15,00142$
      007EFD                       1281 00142$:
      007EFD 50 0D            [24] 1282 	jnc	00109$
      007EFF EF               [12] 1283 	mov	a,r7
      007F00 24 3C            [12] 1284 	add	a, #_macro_keys
      007F02 F5 82            [12] 1285 	mov	dpl,a
      007F04 E4               [12] 1286 	clr	a
      007F05 34 0A            [12] 1287 	addc	a, #(_macro_keys >> 8)
      007F07 12 7C 59         [24] 1288 	lcall	_ak820_outline_0158
      007F0A 80 EE            [24] 1289 	sjmp	00107$
      007F0C                       1290 00109$:
                                   1291 ;	quantum/action_util.c:144: }
      007F0C 22               [24] 1292 	ret
                                   1293 ;------------------------------------------------------------
                                   1294 ;Allocation info for local variables in function 'add_owned_key'
                                   1295 ;------------------------------------------------------------
                                   1296 ;code          Allocated with name '_add_owned_key_code_10000_340'
                                   1297 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_349'
                                   1298 ;key           Allocated with name '_add_owned_key_key_50000_350'
                                   1299 ;i             Allocated with name '_add_owned_key_i_40000_348'
                                   1300 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_352'
                                   1301 ;key           Allocated with name '_add_owned_key_key_40000_353'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function add_owned_key
                                   1306 ;	-----------------------------------------
      007F0D                       1307 _add_owned_key:
      007F0D E5 82            [12] 1308 	mov	a,dpl
      007F0F 90 0A 51         [24] 1309 	mov	dptr,#_add_owned_key_code_10000_340
      007F12 12 82 F9         [24] 1310 	lcall	_ak820_outline_0130
                                   1311 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007F15 74 01            [12] 1312 	mov	a,#0x01
      007F17 F0               [24] 1313 	movx	@dptr,a
      007F18 90 0A 3C         [24] 1314 	mov	dptr,#_macro_keys
      007F1B C0 07            [24] 1315 	push	ar7
      007F1D B1 31            [12] 1316 	acall	_ak820_macro_change
      007F1F E5 82            [12] 1317 	mov	a, dpl
      007F21 D0 07            [24] 1318 	pop	ar7
      007F23 70 03            [24] 1319 	jnz	00102$
      007F25 F5 82            [12] 1320 	mov	dpl,a
      007F27 22               [24] 1321 	ret
      007F28                       1322 00102$:
                                   1323 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007F28 12 82 B3         [24] 1324 	lcall	_ak820_outline_0029
      007F2B FC               [12] 1325 	mov	r4,a
      007F2C 04               [12] 1326 	inc	a
      007F2D 12 82 E8         [24] 1327 	lcall	_ak820_outline_0119
      007F30 EC               [12] 1328 	mov	a,r4
      007F31 60 04            [24] 1329 	jz	00104$
      007F33 75 82 00         [24] 1330 	mov	dpl, #0x00
      007F36 22               [24] 1331 	ret
      007F37                       1332 00104$:
                                   1333 ;	quantum/action_util.c:148: ++distinct_keys;
      007F37 90 0A 3B         [24] 1334 	mov	dptr,#_distinct_keys
      007F3A E0               [24] 1335 	movx	a,@dptr
      007F3B 24 01            [12] 1336 	add	a, #0x01
      007F3D F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007F3E 90 0D 8E         [24] 1339 	mov	dptr,#_keyboard_protocol
      007F41 E0               [24] 1340 	movx	a,@dptr
      007F42 60 11            [24] 1341 	jz	00106$
      007F44 90 0A C0         [24] 1342 	mov	dptr,#_keymap_config
      007F47 E0               [24] 1343 	movx	a,@dptr
      007F48 30 E7 0A         [24] 1344 	jnb	acc.7,00106$
                                   1345 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007F4B 12 83 0D         [24] 1346 	lcall	_ak820_outline_0173
      007F4E 12 70 61         [24] 1347 	lcall	_add_key_to_report
                                   1348 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007F51 75 82 01         [24] 1349 	mov	dpl, #0x01
      007F54 22               [24] 1350 	ret
      007F55                       1351 00106$:
                                   1352 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007F55 90 0A 3B         [24] 1353 	mov	dptr,#_distinct_keys
      007F58 E0               [24] 1354 	movx	a,@dptr
      007F59 24 F9            [12] 1355 	add	a,#0xff - 0x06
      007F5B 50 17            [24] 1356 	jnc	00110$
                                   1357 ;	free result
                                   1358 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007F5D 7F 00            [12] 1359 	mov	r7,#0x00
      007F5F                       1360 00115$:
      007F5F BF 06 00         [24] 1361 	cjne	r7,#0x06,00174$
      007F62                       1362 00174$:
      007F62 50 1E            [24] 1363 	jnc	00111$
      007F64 EF               [12] 1364 	mov	a,r7
      007F65 24 A3            [12] 1365 	add	a, #(_actual_keyboard_report + 0x0002)
      007F67 F5 82            [12] 1366 	mov	dpl,a
      007F69 E4               [12] 1367 	clr	a
      007F6A 34 0D            [12] 1368 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007F6C F5 83            [12] 1369 	mov	dph,a
      007F6E 74 01            [12] 1370 	mov	a,#0x01
      007F70 F0               [24] 1371 	movx	@dptr,a
      007F71 0F               [12] 1372 	inc	r7
      007F72 80 EB            [24] 1373 	sjmp	00115$
      007F74                       1374 00110$:
                                   1375 ;	quantum/action_util.c:154: } else add_key(code);
      007F74 90 0A 51         [24] 1376 	mov	dptr,#_add_owned_key_code_10000_340
      007F77 E0               [24] 1377 	movx	a,@dptr
                                   1378 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007F78 90 08 04         [24] 1379 	mov	dptr,#_add_key_to_report_PARM_2
      007F7B F0               [24] 1380 	movx	@dptr,a
      007F7C 90 0D A1         [24] 1381 	mov	dptr,#_actual_keyboard_report
      007F7F 12 70 61         [24] 1382 	lcall	_add_key_to_report
                                   1383 ;	quantum/action_util.c:154: } else add_key(code);
      007F82                       1384 00111$:
                                   1385 ;	quantum/action_util.c:155: return true;
      007F82 75 82 01         [24] 1386 	mov	dpl, #0x01
                                   1387 ;	quantum/action_util.c:156: }
      007F85 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'del_owned_key'
                                   1391 ;------------------------------------------------------------
                                   1392 ;code          Allocated with name '_del_owned_key_code_10000_355'
                                   1393 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_366'
                                   1394 ;key           Allocated with name '_del_owned_key_key_50000_367'
                                   1395 ;key           Allocated with name '_del_owned_key_key_40000_364'
                                   1396 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_372'
                                   1397 ;key           Allocated with name '_del_owned_key_key_70000_373'
                                   1398 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_375'
                                   1399 ;key           Allocated with name '_del_owned_key_key_40000_376'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function del_owned_key
                                   1404 ;	-----------------------------------------
      007F86                       1405 _del_owned_key:
      007F86 E5 82            [12] 1406 	mov	a,dpl
      007F88 90 0A 52         [24] 1407 	mov	dptr,#_del_owned_key_code_10000_355
      007F8B 12 82 F9         [24] 1408 	lcall	_ak820_outline_0130
                                   1409 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007F8E E4               [12] 1410 	clr	a
      007F8F F0               [24] 1411 	movx	@dptr,a
      007F90 90 0A 3C         [24] 1412 	mov	dptr,#_macro_keys
      007F93 C0 07            [24] 1413 	push	ar7
      007F95 12 7D 31         [24] 1414 	lcall	_ak820_macro_change
      007F98 E5 82            [12] 1415 	mov	a, dpl
      007F9A D0 07            [24] 1416 	pop	ar7
      007F9C 70 03            [24] 1417 	jnz	00102$
      007F9E F5 82            [12] 1418 	mov	dpl,a
      007FA0 22               [24] 1419 	ret
      007FA1                       1420 00102$:
                                   1421 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      007FA1 12 82 B3         [24] 1422 	lcall	_ak820_outline_0029
      007FA4 FC               [12] 1423 	mov	r4,a
      007FA5 60 09            [24] 1424 	jz	00103$
      007FA7 1C               [12] 1425 	dec	r4
      007FA8 12 38 61         [24] 1426 	lcall	_ak820_outline_0131
      007FAB EC               [12] 1427 	mov	a,r4
      007FAC F0               [24] 1428 	movx	@dptr,a
      007FAD EC               [12] 1429 	mov	a,r4
      007FAE 60 04            [24] 1430 	jz	00104$
      007FB0                       1431 00103$:
      007FB0 75 82 00         [24] 1432 	mov	dpl, #0x00
      007FB3 22               [24] 1433 	ret
      007FB4                       1434 00104$:
                                   1435 ;	quantum/action_util.c:160: --distinct_keys;
      007FB4 90 0A 3B         [24] 1436 	mov	dptr,#_distinct_keys
      007FB7 E0               [24] 1437 	movx	a,@dptr
      007FB8 14               [12] 1438 	dec	a
      007FB9 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007FBA 90 0D 8E         [24] 1441 	mov	dptr,#_keyboard_protocol
      007FBD E0               [24] 1442 	movx	a,@dptr
      007FBE 60 16            [24] 1443 	jz	00107$
      007FC0 90 0A C0         [24] 1444 	mov	dptr,#_keymap_config
      007FC3 E0               [24] 1445 	movx	a,@dptr
      007FC4 30 E7 0F         [24] 1446 	jnb	acc.7,00107$
                                   1447 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007FC7 90 08 07         [24] 1448 	mov	dptr,#_del_key_from_report_PARM_2
      007FCA EF               [12] 1449 	mov	a,r7
      007FCB F0               [24] 1450 	movx	@dptr,a
      007FCC 90 0D A1         [24] 1451 	mov	dptr,#_actual_keyboard_report
      007FCF 12 70 97         [24] 1452 	lcall	_del_key_from_report
                                   1453 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007FD2 75 82 01         [24] 1454 	mov	dpl, #0x01
      007FD5 22               [24] 1455 	ret
      007FD6                       1456 00107$:
                                   1457 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007FD6 90 0A 3B         [24] 1458 	mov	dptr,#_distinct_keys
      007FD9 E0               [24] 1459 	movx	a,@dptr
      007FDA FF               [12] 1460 	mov  r7,a
      007FDB 24 F9            [12] 1461 	add	a,#0xff - 0x06
      007FDD 50 04            [24] 1462 	jnc	00110$
                                   1463 ;	free result
      007FDF 75 82 01         [24] 1464 	mov	dpl, #0x01
      007FE2 22               [24] 1465 	ret
      007FE3                       1466 00110$:
                                   1467 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007FE3 BF 06 1F         [24] 1468 	cjne	r7,#0x06,00115$
                                   1469 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007FE6 90 0D A1         [24] 1470 	mov	dptr,#_actual_keyboard_report
      007FE9 12 70 CC         [24] 1471 	lcall	_clear_keys_from_report
                                   1472 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007FEC 7F 04            [12] 1473 	mov	r7,#0x04
      007FEE                       1474 00122$:
      007FEE EF               [12] 1475 	mov	a,r7
      007FEF 24 5B            [12] 1476 	add	a,#0xff - 0xa4
      007FF1 40 20            [24] 1477 	jc	00116$
                                   1478 ;	free result
      007FF3 12 82 B3         [24] 1479 	lcall	_ak820_outline_0029
      007FF6 60 0A            [24] 1480 	jz	00123$
                                   1481 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007FF8 12 83 0D         [24] 1482 	lcall	_ak820_outline_0173
      007FFB C0 07            [24] 1483 	push	ar7
      007FFD 12 70 61         [24] 1484 	lcall	_add_key_to_report
      008000 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008002                       1487 00123$:
      008002 0F               [12] 1488 	inc	r7
      008003 80 E9            [24] 1489 	sjmp	00122$
      008005                       1490 00115$:
                                   1491 ;	quantum/action_util.c:169: } else del_key(code);
      008005 90 0A 52         [24] 1492 	mov	dptr,#_del_owned_key_code_10000_355
      008008 E0               [24] 1493 	movx	a,@dptr
                                   1494 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008009 90 08 07         [24] 1495 	mov	dptr,#_del_key_from_report_PARM_2
      00800C F0               [24] 1496 	movx	@dptr,a
      00800D 90 0D A1         [24] 1497 	mov	dptr,#_actual_keyboard_report
      008010 12 70 97         [24] 1498 	lcall	_del_key_from_report
                                   1499 ;	quantum/action_util.c:169: } else del_key(code);
      008013                       1500 00116$:
                                   1501 ;	quantum/action_util.c:170: return true;
      008013 75 82 01         [24] 1502 	mov	dpl, #0x01
                                   1503 ;	quantum/action_util.c:171: }
      008016 22               [24] 1504 	ret
                                   1505 ;------------------------------------------------------------
                                   1506 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1507 ;------------------------------------------------------------
                                   1508 ;i             Allocated with name '_clear_owned_usages_i_20000_380'
                                   1509 ;i             Allocated with name '_clear_owned_usages_i_20000_381'
                                   1510 ;------------------------------------------------------------
                                   1511 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1512 ;	-----------------------------------------
                                   1513 ;	 function clear_owned_usages
                                   1514 ;	-----------------------------------------
      008017                       1515 _clear_owned_usages:
                                   1516 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008017 7F 00            [12] 1517 	mov	r7,#0x00
      008019                       1518 00104$:
      008019 BF 1E 00         [24] 1519 	cjne	r7,#0x1e,00141$
      00801C                       1520 00141$:
      00801C 50 14            [24] 1521 	jnc	00101$
      00801E EF               [12] 1522 	mov	a,r7
      00801F 24 53            [12] 1523 	add	a, #_usage_refs
      008021 FD               [12] 1524 	mov	r5,a
      008022 E4               [12] 1525 	clr	a
      008023 34 0A            [12] 1526 	addc	a, #(_usage_refs >> 8)
      008025 FE               [12] 1527 	mov	r6,a
      008026 EF               [12] 1528 	mov	a,r7
      008027 12 82 C8         [24] 1529 	lcall	_ak820_outline_0068
      00802A E4               [12] 1530 	clr	a
      00802B F0               [24] 1531 	movx	@dptr,a
      00802C 12 82 E8         [24] 1532 	lcall	_ak820_outline_0119
      00802F 0F               [12] 1533 	inc	r7
      008030 80 E7            [24] 1534 	sjmp	00104$
      008032                       1535 00101$:
                                   1536 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008032 90 0A 90         [24] 1537 	mov	dptr,#(_usage_lengths + 0x0001)
      008035 E4               [12] 1538 	clr	a
      008036 F0               [24] 1539 	movx	@dptr,a
      008037 90 0A 8F         [24] 1540 	mov	dptr,#_usage_lengths
      00803A F0               [24] 1541 	movx	@dptr,a
                                   1542 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      00803B FF               [12] 1543 	mov	r7,a
      00803C                       1544 00107$:
      00803C BF 04 00         [24] 1545 	cjne	r7,#0x04,00143$
      00803F                       1546 00143$:
      00803F 50 0D            [24] 1547 	jnc	00109$
      008041 EF               [12] 1548 	mov	a,r7
      008042 24 91            [12] 1549 	add	a, #_macro_usages
      008044 F5 82            [12] 1550 	mov	dpl,a
      008046 E4               [12] 1551 	clr	a
      008047 34 0A            [12] 1552 	addc	a, #(_macro_usages >> 8)
      008049 12 7C 59         [24] 1553 	lcall	_ak820_outline_0158
      00804C 80 EE            [24] 1554 	sjmp	00107$
      00804E                       1555 00109$:
                                   1556 ;	quantum/action_util.c:185: }
      00804E 22               [24] 1557 	ret
                                   1558 ;------------------------------------------------------------
                                   1559 ;Allocation info for local variables in function 'owned_usage_key'
                                   1560 ;------------------------------------------------------------
                                   1561 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1562 ;code          Allocated with name '_owned_usage_key_code_10000_382'
                                   1563 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_383'
                                   1564 ;which         Allocated with name '_owned_usage_key_which_10000_383'
                                   1565 ;base          Allocated with name '_owned_usage_key_base_10000_383'
                                   1566 ;count         Allocated with name '_owned_usage_key_count_10000_383'
                                   1567 ;index         Allocated with name '_owned_usage_key_index_10000_383'
                                   1568 ;pos           Allocated with name '_owned_usage_key_pos_30001_390'
                                   1569 ;i             Allocated with name '_owned_usage_key_i_40001_391'
                                   1570 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_394'
                                   1571 ;key           Allocated with name '_owned_usage_key_key_40000_395'
                                   1572 ;------------------------------------------------------------
                                   1573 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1574 ;	-----------------------------------------
                                   1575 ;	 function owned_usage_key
                                   1576 ;	-----------------------------------------
      00804F                       1577 _owned_usage_key:
      00804F E5 82            [12] 1578 	mov	a,dpl
      008051 90 0A 96         [24] 1579 	mov	dptr,#_owned_usage_key_code_10000_382
      008054 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      008055 E0               [24] 1582 	movx	a,@dptr
      008056 FF               [12] 1583 	mov	r7,a
      008057 BF A8 00         [24] 1584 	cjne	r7,#0xa8,00244$
      00805A                       1585 00244$:
      00805A B3               [12] 1586 	cpl	c
      00805B 92 24            [24] 1587 	mov	_owned_usage_key_sloc0_1_0,c
      00805D E4               [12] 1588 	clr	a
      00805E 33               [12] 1589 	rlc	a
      00805F FF               [12] 1590 	mov	r7,a
      008060 90 0A 99         [24] 1591 	mov	dptr,#_owned_usage_key_which_10000_383
      008063 F0               [24] 1592 	movx	@dptr,a
                                   1593 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008064 EF               [12] 1594 	mov	a,r7
      008065 60 02            [24] 1595 	jz	00129$
      008067 74 03            [12] 1596 	mov	a,#0x03
      008069                       1597 00129$:
      008069 FE               [12] 1598 	mov	r6,a
                                   1599 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      00806A EF               [12] 1600 	mov	a,r7
      00806B 24 8F            [12] 1601 	add	a, #_usage_lengths
      00806D FD               [12] 1602 	mov	r5,a
      00806E E4               [12] 1603 	clr	a
      00806F 34 0A            [12] 1604 	addc	a, #(_usage_lengths >> 8)
      008071 FF               [12] 1605 	mov	r7,a
      008072 12 83 16         [24] 1606 	lcall	_ak820_outline_0187
      008075 E0               [24] 1607 	movx	a,@dptr
      008076 FC               [12] 1608 	mov	r4,a
                                   1609 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      008077 90 0A 96         [24] 1610 	mov	dptr,#_owned_usage_key_code_10000_382
      00807A E0               [24] 1611 	movx	a,@dptr
      00807B 24 5B            [12] 1612 	add	a,#0x5b
      00807D FB               [12] 1613 	mov	r3,a
                                   1614 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00807E 90 0A 95         [24] 1615 	mov	dptr,#_owned_usage_key_PARM_2
      008081 E0               [24] 1616 	movx	a,@dptr
      008082 FA               [12] 1617 	mov	r2,a
      008083 90 09 8A         [24] 1618 	mov	dptr,#_ak820_macro_change_PARM_2
      008086 EB               [12] 1619 	mov	a,r3
      008087 F0               [24] 1620 	movx	@dptr,a
      008088 90 09 8B         [24] 1621 	mov	dptr,#_ak820_macro_change_PARM_3
      00808B EA               [12] 1622 	mov	a,r2
      00808C F0               [24] 1623 	movx	@dptr,a
      00808D 90 0A 91         [24] 1624 	mov	dptr,#_macro_usages
      008090 C0 07            [24] 1625 	push	ar7
      008092 C0 06            [24] 1626 	push	ar6
      008094 C0 05            [24] 1627 	push	ar5
      008096 C0 04            [24] 1628 	push	ar4
      008098 C0 03            [24] 1629 	push	ar3
      00809A C0 02            [24] 1630 	push	ar2
      00809C 12 7D 31         [24] 1631 	lcall	_ak820_macro_change
      00809F E5 82            [12] 1632 	mov	a, dpl
      0080A1 D0 02            [24] 1633 	pop	ar2
      0080A3 D0 03            [24] 1634 	pop	ar3
      0080A5 D0 04            [24] 1635 	pop	ar4
      0080A7 D0 05            [24] 1636 	pop	ar5
      0080A9 D0 06            [24] 1637 	pop	ar6
      0080AB D0 07            [24] 1638 	pop	ar7
      0080AD 70 01            [24] 1639 	jnz	00102$
      0080AF 22               [24] 1640 	ret
      0080B0                       1641 00102$:
                                   1642 ;	quantum/action_util.c:192: if (pressed) {
      0080B0 EA               [12] 1643 	mov	a,r2
      0080B1 60 1A            [24] 1644 	jz	00115$
                                   1645 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      0080B3 12 82 D2         [24] 1646 	lcall	_ak820_outline_0074
      0080B6 04               [12] 1647 	inc	a
      0080B7 12 6D E7         [24] 1648 	lcall	_ak820_outline_0136
      0080BA E8               [12] 1649 	mov	a,r0
      0080BB 60 01            [24] 1650 	jz	00104$
      0080BD 22               [24] 1651 	ret
      0080BE                       1652 00104$:
                                   1653 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      0080BE 90 0A 9A         [24] 1654 	mov	dptr,#_owned_usage_key_count_10000_383
      0080C1 EC               [12] 1655 	mov	a,r4
      0080C2 04               [12] 1656 	inc	a
      0080C3 F0               [24] 1657 	movx	@dptr,a
      0080C4 EC               [12] 1658 	mov	a,r4
      0080C5 2E               [12] 1659 	add	a, r6
      0080C6 12 82 C8         [24] 1660 	lcall	_ak820_outline_0068
      0080C9 EB               [12] 1661 	mov	a,r3
      0080CA F0               [24] 1662 	movx	@dptr,a
      0080CB 21 2E            [12] 1663 	ajmp	00116$
      0080CD                       1664 00115$:
                                   1665 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      0080CD 12 82 D2         [24] 1666 	lcall	_ak820_outline_0074
      0080D0 60 07            [24] 1667 	jz	00105$
      0080D2 18               [12] 1668 	dec	r0
      0080D3 12 82 C1         [24] 1669 	lcall	_ak820_outline_0064
      0080D6 E8               [12] 1670 	mov	a,r0
      0080D7 60 01            [24] 1671 	jz	00106$
      0080D9                       1672 00105$:
      0080D9 22               [24] 1673 	ret
      0080DA                       1674 00106$:
                                   1675 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      0080DA 7A 00            [12] 1676 	mov	r2,#0x00
      0080DC                       1677 00108$:
      0080DC EA               [12] 1678 	mov	a,r2
      0080DD 2E               [12] 1679 	add	a, r6
      0080DE 12 82 C8         [24] 1680 	lcall	_ak820_outline_0068
      0080E1 E0               [24] 1681 	movx	a,@dptr
      0080E2 B5 03 02         [24] 1682 	cjne	a,ar3,00251$
      0080E5 80 03            [24] 1683 	sjmp	00167$
      0080E7                       1684 00251$:
      0080E7 0A               [12] 1685 	inc	r2
      0080E8 80 F2            [24] 1686 	sjmp	00108$
      0080EA                       1687 00167$:
      0080EA 90 0A 9B         [24] 1688 	mov	dptr,#_owned_usage_key_pos_30001_390
      0080ED EA               [12] 1689 	mov	a,r2
      0080EE F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:199: --count;
      0080EF 1C               [12] 1692 	dec	r4
      0080F0 90 0A 9A         [24] 1693 	mov	dptr,#_owned_usage_key_count_10000_383
      0080F3 EC               [12] 1694 	mov	a,r4
      0080F4 F0               [24] 1695 	movx	@dptr,a
                                   1696 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      0080F5 8A 03            [24] 1697 	mov	ar3,r2
      0080F7                       1698 00125$:
      0080F7 C3               [12] 1699 	clr	c
      0080F8 EB               [12] 1700 	mov	a,r3
      0080F9 9C               [12] 1701 	subb	a,r4
      0080FA 50 23            [24] 1702 	jnc	00111$
      0080FC C0 05            [24] 1703 	push	ar5
      0080FE C0 07            [24] 1704 	push	ar7
      008100 EB               [12] 1705 	mov	a,r3
      008101 2E               [12] 1706 	add	a, r6
      008102 FA               [12] 1707 	mov	r2,a
      008103 24 71            [12] 1708 	add	a, #_usage_order
      008105 F8               [12] 1709 	mov	r0,a
      008106 E4               [12] 1710 	clr	a
      008107 34 0A            [12] 1711 	addc	a, #(_usage_order >> 8)
      008109 F9               [12] 1712 	mov	r1,a
      00810A 0A               [12] 1713 	inc	r2
      00810B EA               [12] 1714 	mov	a,r2
      00810C 33               [12] 1715 	rlc	a
      00810D 95 E0            [12] 1716 	subb	a,acc
      00810F FF               [12] 1717 	mov	r7,a
      008110 EA               [12] 1718 	mov	a,r2
      008111 12 82 EE         [24] 1719 	lcall	_ak820_outline_0124
      008114 12 38 6C         [24] 1720 	lcall	_ak820_outline_0152
      008117 F0               [24] 1721 	movx	@dptr,a
      008118 0B               [12] 1722 	inc	r3
      008119 D0 07            [24] 1723 	pop	ar7
      00811B D0 05            [24] 1724 	pop	ar5
      00811D 80 D8            [24] 1725 	sjmp	00125$
      00811F                       1726 00111$:
                                   1727 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      00811F 12 83 16         [24] 1728 	lcall	_ak820_outline_0187
      008122 EC               [12] 1729 	mov	a,r4
      008123 F0               [24] 1730 	movx	@dptr,a
                                   1731 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008124 90 0A 9B         [24] 1732 	mov	dptr,#_owned_usage_key_pos_30001_390
      008127 E0               [24] 1733 	movx	a,@dptr
      008128 B5 04 02         [24] 1734 	cjne	a,ar4,00253$
      00812B 80 01            [24] 1735 	sjmp	00116$
      00812D                       1736 00253$:
      00812D 22               [24] 1737 	ret
      00812E                       1738 00116$:
                                   1739 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      00812E 90 0A 9A         [24] 1740 	mov	dptr,#_owned_usage_key_count_10000_383
      008131 E0               [24] 1741 	movx	a,@dptr
      008132 FC               [12] 1742 	mov	r4,a
      008133 12 83 16         [24] 1743 	lcall	_ak820_outline_0187
      008136 F0               [24] 1744 	movx	@dptr,a
                                   1745 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008137 EC               [12] 1746 	mov	a,r4
      008138 60 15            [24] 1747 	jz	00131$
      00813A EC               [12] 1748 	mov	a,r4
      00813B 2E               [12] 1749 	add	a, r6
      00813C FE               [12] 1750 	mov	r6,a
      00813D 1E               [12] 1751 	dec	r6
      00813E EE               [12] 1752 	mov	a,r6
      00813F 33               [12] 1753 	rlc	a
      008140 95 E0            [12] 1754 	subb	a,acc
      008142 FF               [12] 1755 	mov	r7,a
      008143 EE               [12] 1756 	mov	a,r6
      008144 12 82 EE         [24] 1757 	lcall	_ak820_outline_0124
      008147 24 A5            [12] 1758 	add	a,#0xa5
      008149 FE               [12] 1759 	mov	r6,a
      00814A 33               [12] 1760 	rlc	a
      00814B 95 E0            [12] 1761 	subb	a,acc
      00814D 80 02            [24] 1762 	sjmp	00132$
      00814F                       1763 00131$:
      00814F 7E 00            [12] 1764 	mov	r6,#0x00
      008151                       1765 00132$:
      008151 90 0A 96         [24] 1766 	mov	dptr,#_owned_usage_key_code_10000_382
      008154 EE               [12] 1767 	mov	a,r6
      008155 F0               [24] 1768 	movx	@dptr,a
                                   1769 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008156 90 0A 99         [24] 1770 	mov	dptr,#_owned_usage_key_which_10000_383
      008159 E0               [24] 1771 	movx	a,@dptr
      00815A 60 18            [24] 1772 	jz	00118$
      00815C EE               [12] 1773 	mov	a,r6
      00815D 60 0B            [24] 1774 	jz	00133$
      00815F 8E 82            [24] 1775 	mov	dpl, r6
      008161 12 6F 1E         [24] 1776 	lcall	_KEYCODE2CONSUMER
      008164 AD 82            [24] 1777 	mov	r5, dpl
      008166 AF 83            [24] 1778 	mov	r7, dph
      008168 80 04            [24] 1779 	sjmp	00134$
      00816A                       1780 00133$:
      00816A 7D 00            [12] 1781 	mov	r5,#0x00
      00816C 7F 00            [12] 1782 	mov	r7,#0x00
      00816E                       1783 00134$:
      00816E 12 83 16         [24] 1784 	lcall	_ak820_outline_0187
      008171 02 6E D9         [24] 1785 	ljmp	_host_consumer_send
      008174                       1786 00118$:
                                   1787 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008174 EE               [12] 1788 	mov	a,r6
      008175 60 22            [24] 1789 	jz	00135$
                                   1790 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008177 BE A5 00         [24] 1791 	cjne	r6,#0xa5,00258$
      00817A                       1792 00258$:
      00817A 40 05            [24] 1793 	jc	00121$
      00817C EE               [12] 1794 	mov	a,r6
      00817D 24 58            [12] 1795 	add	a,#0xff - 0xa7
      00817F 50 08            [24] 1796 	jnc	00122$
                                   1797 ;	free result
      008181                       1798 00121$:
      008181 90 0A 97         [24] 1799 	mov	dptr,#_owned_usage_key___200000085_20000_383
      008184 12 50 53         [24] 1800 	lcall	_ak820_outline_0180
      008187 80 09            [24] 1801 	sjmp	00123$
      008189                       1802 00122$:
                                   1803 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008189 74 DC            [12] 1804 	mov	a,#0xdc
      00818B 2E               [12] 1805 	add	a, r6
      00818C 90 0A 97         [24] 1806 	mov	dptr,#_owned_usage_key___200000085_20000_383
      00818F 12 38 5C         [24] 1807 	lcall	_ak820_outline_0123
                                   1808 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008192                       1809 00123$:
      008192 90 0A 97         [24] 1810 	mov	dptr,#_owned_usage_key___200000085_20000_383
      008195 E0               [24] 1811 	movx	a,@dptr
      008196 FF               [12] 1812 	mov	r7,a
      008197 80 02            [24] 1813 	sjmp	00136$
      008199                       1814 00135$:
      008199 7F 00            [12] 1815 	mov	r7,#0x00
      00819B                       1816 00136$:
      00819B 7E 00            [12] 1817 	mov	r6,#0x00
      00819D 12 43 AA         [24] 1818 	lcall	_ak820_outline_0153
                                   1819 ;	quantum/action_util.c:208: }
      0081A0 02 6E AA         [24] 1820 	ljmp	_host_system_send
                                   1821 ;------------------------------------------------------------
                                   1822 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1823 ;------------------------------------------------------------
                                   1824 ;mods          Allocated with name '_send_keyboard_report_mods_30000_403'
                                   1825 ;mods          Allocated with name '_send_keyboard_report_mods_30000_405'
                                   1826 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_407'
                                   1827 ;changed       Allocated with name '_send_keyboard_report_changed_10001_407'
                                   1828 ;dest          Allocated with name '_send_keyboard_report_dest_10001_407'
                                   1829 ;src           Allocated with name '_send_keyboard_report_src_10001_407'
                                   1830 ;i             Allocated with name '_send_keyboard_report_i_20001_408'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function send_keyboard_report
                                   1835 ;	-----------------------------------------
      0081A3                       1836 _send_keyboard_report:
                                   1837 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0081A3 90 0D 9F         [24] 1838 	mov	dptr,#_real_mods
      0081A6 E0               [24] 1839 	movx	a,@dptr
      0081A7 FF               [12] 1840 	mov	r7,a
      0081A8 90 0D A1         [24] 1841 	mov	dptr,#_actual_keyboard_report
      0081AB F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      0081AC 90 0D A0         [24] 1844 	mov	dptr,#_weak_mods
      0081AF E0               [24] 1845 	movx	a,@dptr
      0081B0 42 07            [12] 1846 	orl	ar7,a
      0081B2 90 0D A1         [24] 1847 	mov	dptr,#_actual_keyboard_report
      0081B5 EF               [12] 1848 	mov	a,r7
      0081B6 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0081B7 90 09 85         [24] 1851 	mov	dptr,#_owned_weak_mods
      0081BA E0               [24] 1852 	movx	a,@dptr
      0081BB FE               [12] 1853 	mov	r6,a
      0081BC 90 09 84         [24] 1854 	mov	dptr,#_owned_mods
      0081BF E0               [24] 1855 	movx	a,@dptr
      0081C0 4E               [12] 1856 	orl	a,r6
      0081C1 42 07            [12] 1857 	orl	ar7,a
      0081C3 90 0D A1         [24] 1858 	mov	dptr,#_actual_keyboard_report
      0081C6 EF               [12] 1859 	mov	a,r7
      0081C7 F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/action_util.c:463: if (ak820_mac_mode) {
      0081C8 30 1E 1F         [24] 1862 	jnb	_ak820_mac_mode,00102$
                                   1863 ;	quantum/action_util.c:464: uint8_t mods = keyboard_report->mods;
      0081CB 90 0D A1         [24] 1864 	mov	dptr,#_actual_keyboard_report
      0081CE E0               [24] 1865 	movx	a,@dptr
      0081CF FF               [12] 1866 	mov	r7,a
                                   1867 ;	quantum/action_util.c:465: keyboard_report->mods = (mods & 0x33) | ((mods & 0x44) << 1) | ((mods & 0x88) >> 1);
      0081D0 74 33            [12] 1868 	mov	a,#0x33
      0081D2 5F               [12] 1869 	anl	a,r7
      0081D3 FE               [12] 1870 	mov	r6,a
      0081D4 8F 05            [24] 1871 	mov	ar5,r7
      0081D6 53 05 44         [24] 1872 	anl	ar5,#0x44
      0081D9 ED               [12] 1873 	mov	a,r5
      0081DA 2D               [12] 1874 	add	a,r5
      0081DB 42 06            [12] 1875 	orl	ar6,a
      0081DD 53 07 88         [24] 1876 	anl	ar7,#0x88
      0081E0 E4               [12] 1877 	clr	a
      0081E1 A2 E7            [12] 1878 	mov	c,acc.7
      0081E3 13               [12] 1879 	rrc	a
      0081E4 CF               [12] 1880 	xch	a,r7
      0081E5 13               [12] 1881 	rrc	a
      0081E6 CF               [12] 1882 	xch	a,r7
      0081E7 12 83 04         [24] 1883 	lcall	_ak820_outline_0170
      0081EA                       1884 00102$:
                                   1885 ;	quantum/action_util.c:469: if (ctrl_gui_swapped) {
      0081EA 30 20 2C         [24] 1886 	jnb	_ctrl_gui_swapped,00104$
                                   1887 ;	quantum/action_util.c:470: uint8_t mods = keyboard_report->mods;
      0081ED 90 0D A1         [24] 1888 	mov	dptr,#_actual_keyboard_report
      0081F0 E0               [24] 1889 	movx	a,@dptr
      0081F1 FF               [12] 1890 	mov	r7,a
                                   1891 ;	quantum/action_util.c:471: keyboard_report->mods = (mods & 0x66) | ((mods & 0x11) << 3) | ((mods & 0x88) >> 3);
      0081F2 74 66            [12] 1892 	mov	a,#0x66
      0081F4 5F               [12] 1893 	anl	a,r7
      0081F5 FE               [12] 1894 	mov	r6,a
      0081F6 8F 05            [24] 1895 	mov	ar5,r7
      0081F8 53 05 11         [24] 1896 	anl	ar5,#0x11
      0081FB ED               [12] 1897 	mov	a,r5
      0081FC 12 38 87         [24] 1898 	lcall	_ak820_outline_0185
      0081FF 42 06            [12] 1899 	orl	ar6,a
      008201 53 07 88         [24] 1900 	anl	ar7,#0x88
      008204 E4               [12] 1901 	clr	a
      008205 23               [12] 1902 	rl	a
      008206 CF               [12] 1903 	xch	a,r7
      008207 12 58 00         [24] 1904 	lcall	_ak820_outline_0168
      00820A 6F               [12] 1905 	xrl	a,r7
      00820B CF               [12] 1906 	xch	a,r7
      00820C 54 1F            [12] 1907 	anl	a,#0x1f
      00820E CF               [12] 1908 	xch	a,r7
      00820F 6F               [12] 1909 	xrl	a,r7
      008210 CF               [12] 1910 	xch	a,r7
      008211 30 E4 02         [24] 1911 	jnb	acc.4,00169$
      008214 44 E0            [12] 1912 	orl	a,#0xffffffe0
      008216                       1913 00169$:
      008216 12 83 04         [24] 1914 	lcall	_ak820_outline_0170
      008219                       1915 00104$:
                                   1916 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008219 30 1F 07         [24] 1917 	jnb	_gui_disabled,00106$
      00821C 90 0D A1         [24] 1918 	mov	dptr,#_actual_keyboard_report
      00821F E0               [24] 1919 	movx	a,@dptr
      008220 54 77            [12] 1920 	anl	a,#0x77
      008222 F0               [24] 1921 	movx	@dptr,a
      008223                       1922 00106$:
                                   1923 ;	quantum/action_util.c:515: bool changed = false;
      008223 90 0A BD         [24] 1924 	mov	dptr,#_send_keyboard_report_changed_10001_407
      008226 E4               [12] 1925 	clr	a
      008227 F0               [24] 1926 	movx	@dptr,a
                                   1927 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1928 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1929 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008228 FF               [12] 1930 	mov	r7,a
      008229                       1931 00113$:
      008229 BF 20 00         [24] 1932 	cjne	r7,#0x20,00171$
      00822C                       1933 00171$:
      00822C 50 2A            [24] 1934 	jnc	00109$
                                   1935 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      00822E EF               [12] 1936 	mov	a,r7
      00822F 24 9D            [12] 1937 	add	a, #_send_keyboard_report_last_report_10001_407
      008231 FD               [12] 1938 	mov	r5,a
      008232 E4               [12] 1939 	clr	a
      008233 34 0A            [12] 1940 	addc	a, #(_send_keyboard_report_last_report_10001_407 >> 8)
      008235 12 49 A6         [24] 1941 	lcall	_ak820_outline_0057
      008238 EF               [12] 1942 	mov	a,r7
      008239 24 A1            [12] 1943 	add	a, #_actual_keyboard_report
      00823B F5 82            [12] 1944 	mov	dpl,a
      00823D E4               [12] 1945 	clr	a
      00823E 34 0D            [12] 1946 	addc	a, #(_actual_keyboard_report >> 8)
      008240 F5 83            [12] 1947 	mov	dph,a
      008242 E0               [24] 1948 	movx	a,@dptr
      008243 FB               [12] 1949 	mov	r3,a
      008244 EC               [12] 1950 	mov	a,r4
      008245 B5 03 02         [24] 1951 	cjne	a,ar3,00173$
      008248 80 0B            [24] 1952 	sjmp	00114$
      00824A                       1953 00173$:
                                   1954 ;	quantum/action_util.c:525: dest[i] = src[i];
      00824A 12 38 61         [24] 1955 	lcall	_ak820_outline_0131
      00824D EB               [12] 1956 	mov	a,r3
      00824E F0               [24] 1957 	movx	@dptr,a
                                   1958 ;	quantum/action_util.c:526: changed = true;
      00824F 90 0A BD         [24] 1959 	mov	dptr,#_send_keyboard_report_changed_10001_407
      008252 74 01            [12] 1960 	mov	a,#0x01
      008254 F0               [24] 1961 	movx	@dptr,a
      008255                       1962 00114$:
                                   1963 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008255 0F               [12] 1964 	inc	r7
      008256 80 D1            [24] 1965 	sjmp	00113$
      008258                       1966 00109$:
                                   1967 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008258 90 0A BD         [24] 1968 	mov	dptr,#_send_keyboard_report_changed_10001_407
      00825B E0               [24] 1969 	movx	a,@dptr
      00825C 60 09            [24] 1970 	jz	00115$
      00825E 90 0D A1         [24] 1971 	mov	dptr,#_actual_keyboard_report
      008261 75 F0 00         [24] 1972 	mov	b, #0x00
                                   1973 ;	quantum/action_util.c:538: }
      008264 02 6E 1F         [24] 1974 	ljmp	_host_keyboard_send
      008267                       1975 00115$:
      008267 22               [24] 1976 	ret
                                   1977 ;------------------------------------------------------------
                                   1978 ;Allocation info for local variables in function 'get_mods'
                                   1979 ;------------------------------------------------------------
                                   1980 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1981 ;	-----------------------------------------
                                   1982 ;	 function get_mods
                                   1983 ;	-----------------------------------------
      008268                       1984 _get_mods:
      008268 C0 07            [24] 1985 	push	ar7
                                   1986 ;	quantum/action_util.c:549: ;
      00826A 90 09 84         [24] 1987 	mov	dptr,#_owned_mods
      00826D E0               [24] 1988 	movx	a,@dptr
      00826E FF               [12] 1989 	mov	r7,a
      00826F 90 0D 9F         [24] 1990 	mov	dptr,#_real_mods
      008272 12 7C 53         [24] 1991 	lcall	_ak820_outline_0138
                                   1992 ;	quantum/action_util.c:550: }
      008275 D0 07            [24] 1993 	pop	ar7
      008277 22               [24] 1994 	ret
                                   1995 ;------------------------------------------------------------
                                   1996 ;Allocation info for local variables in function 'add_mods'
                                   1997 ;------------------------------------------------------------
                                   1998 ;mods          Allocated with name '_add_mods_mods_10000_415'
                                   1999 ;------------------------------------------------------------
                                   2000 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   2001 ;	-----------------------------------------
                                   2002 ;	 function clear_mods
                                   2003 ;	-----------------------------------------
      008278                       2004 _clear_mods:
                                   2005 ;	quantum/action_util.c:577: real_mods = 0;
      008278 90 0D 9F         [24] 2006 	mov	dptr,#_real_mods
      00827B E4               [12] 2007 	clr	a
      00827C F0               [24] 2008 	movx	@dptr,a
                                   2009 ;	quantum/action_util.c:578: }
      00827D 22               [24] 2010 	ret
                                   2011 ;------------------------------------------------------------
                                   2012 ;Allocation info for local variables in function 'get_weak_mods'
                                   2013 ;------------------------------------------------------------
                                   2014 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   2015 ;	-----------------------------------------
                                   2016 ;	 function get_weak_mods
                                   2017 ;	-----------------------------------------
      00827E                       2018 _get_weak_mods:
      00827E C0 07            [24] 2019 	push	ar7
                                   2020 ;	quantum/action_util.c:589: ;
      008280 90 09 85         [24] 2021 	mov	dptr,#_owned_weak_mods
      008283 E0               [24] 2022 	movx	a,@dptr
      008284 FF               [12] 2023 	mov	r7,a
      008285 90 0D A0         [24] 2024 	mov	dptr,#_weak_mods
      008288 12 7C 53         [24] 2025 	lcall	_ak820_outline_0138
                                   2026 ;	quantum/action_util.c:590: }
      00828B D0 07            [24] 2027 	pop	ar7
      00828D 22               [24] 2028 	ret
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'add_weak_mods'
                                   2031 ;------------------------------------------------------------
                                   2032 ;mods          Allocated with name '_add_weak_mods_mods_10000_425'
                                   2033 ;------------------------------------------------------------
                                   2034 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   2035 ;	-----------------------------------------
                                   2036 ;	 function add_weak_mods
                                   2037 ;	-----------------------------------------
      00828E                       2038 _add_weak_mods:
      00828E E5 82            [12] 2039 	mov	a,dpl
      008290 90 0A BE         [24] 2040 	mov	dptr,#_add_weak_mods_mods_10000_425
      008293 F0               [24] 2041 	movx	@dptr,a
                                   2042 ;	quantum/action_util.c:596: weak_mods |= mods;
      008294 E0               [24] 2043 	movx	a,@dptr
      008295 FF               [12] 2044 	mov	r7,a
      008296 90 0D A0         [24] 2045 	mov	dptr,#_weak_mods
      008299 E0               [24] 2046 	movx	a,@dptr
      00829A 4F               [12] 2047 	orl	a,r7
      00829B F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	quantum/action_util.c:597: }
      00829C 22               [24] 2050 	ret
                                   2051 ;------------------------------------------------------------
                                   2052 ;Allocation info for local variables in function 'del_weak_mods'
                                   2053 ;------------------------------------------------------------
                                   2054 ;mods          Allocated with name '_del_weak_mods_mods_10000_427'
                                   2055 ;------------------------------------------------------------
                                   2056 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   2057 ;	-----------------------------------------
                                   2058 ;	 function del_weak_mods
                                   2059 ;	-----------------------------------------
      00829D                       2060 _del_weak_mods:
      00829D E5 82            [12] 2061 	mov	a,dpl
      00829F 90 0A BF         [24] 2062 	mov	dptr,#_del_weak_mods_mods_10000_427
      0082A2 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      0082A3 E0               [24] 2065 	movx	a,@dptr
      0082A4 F4               [12] 2066 	cpl	a
      0082A5 FF               [12] 2067 	mov	r7,a
      0082A6 90 0D A0         [24] 2068 	mov	dptr,#_weak_mods
      0082A9 E0               [24] 2069 	movx	a,@dptr
      0082AA 5F               [12] 2070 	anl	a,r7
      0082AB F0               [24] 2071 	movx	@dptr,a
                                   2072 ;	quantum/action_util.c:604: }
      0082AC 22               [24] 2073 	ret
                                   2074 ;------------------------------------------------------------
                                   2075 ;Allocation info for local variables in function 'set_weak_mods'
                                   2076 ;------------------------------------------------------------
                                   2077 ;mods          Allocated with name '_set_weak_mods_mods_10000_429'
                                   2078 ;------------------------------------------------------------
                                   2079 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   2080 ;	-----------------------------------------
                                   2081 ;	 function clear_weak_mods
                                   2082 ;	-----------------------------------------
      0082AD                       2083 _clear_weak_mods:
                                   2084 ;	quantum/action_util.c:617: weak_mods = 0;
      0082AD 90 0D A0         [24] 2085 	mov	dptr,#_weak_mods
      0082B0 E4               [12] 2086 	clr	a
      0082B1 F0               [24] 2087 	movx	@dptr,a
                                   2088 ;	quantum/action_util.c:618: }
      0082B2 22               [24] 2089 	ret
                                   2090 ;------------------------------------------------------------
                                   2091 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2092 ;------------------------------------------------------------
                                   2093 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_433'
                                   2094 ;------------------------------------------------------------
                                   2095 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2096 ;	-----------------------------------------
                                   2097 	.area CSEG    (CODE)
                                   2098 	.area CONST   (CODE)
                                   2099 	.area XINIT   (CODE)
      00C16A                       2100 __xinit__real_mods:
      00C16A 00                    2101 	.db #0x00	; 0
      00C16B                       2102 __xinit__weak_mods:
      00C16B 00                    2103 	.db #0x00	; 0
      00C16C                       2104 __xinit__actual_keyboard_report:
      00C16C 00                    2105 	.db #0x00	; 0
      00C16D 00                    2106 	.db #0x00	; 0
      00C16E 00                    2107 	.db #0x00	; 0
      00C16F 00                    2108 	.db #0x00	; 0
      00C170 00                    2109 	.db #0x00	; 0
      00C171 00                    2110 	.db #0x00	; 0
      00C172 00                    2111 	.db #0x00	; 0
      00C173 00                    2112 	.db #0x00	; 0
      00C174 00                    2113 	.db 0x00
      00C175 00                    2114 	.db 0x00
      00C176 00                    2115 	.db 0x00
      00C177 00                    2116 	.db 0x00
      00C178 00                    2117 	.db 0x00
      00C179 00                    2118 	.db 0x00
      00C17A 00                    2119 	.db 0x00
      00C17B 00                    2120 	.db 0x00
      00C17C 00                    2121 	.db 0x00
      00C17D 00                    2122 	.db 0x00
      00C17E 00                    2123 	.db 0x00
      00C17F 00                    2124 	.db 0x00
      00C180 00                    2125 	.db 0x00
      00C181 00                    2126 	.db 0x00
      00C182 00                    2127 	.db 0x00
      00C183 00                    2128 	.db 0x00
      00C184 00                    2129 	.db 0x00
      00C185 00                    2130 	.db 0x00
      00C186 00                    2131 	.db 0x00
      00C187 00                    2132 	.db 0x00
      00C188 00                    2133 	.db 0x00
      00C189 00                    2134 	.db 0x00
      00C18A 00                    2135 	.db 0x00
      00C18B 00                    2136 	.db 0x00
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0014
                                   2141 	.globl _ak820_outline_0029
                                   2142 	.globl _ak820_outline_0051
                                   2143 	.globl _ak820_outline_0057
                                   2144 	.globl _ak820_outline_0060
                                   2145 	.globl _ak820_outline_0063
                                   2146 	.globl _ak820_outline_0064
                                   2147 	.globl _ak820_outline_0065
                                   2148 	.globl _ak820_outline_0068
                                   2149 	.globl _ak820_outline_0074
                                   2150 	.globl _ak820_outline_0104
                                   2151 	.globl _ak820_outline_0105
                                   2152 	.globl _ak820_outline_0114
                                   2153 	.globl _ak820_outline_0119
                                   2154 	.globl _ak820_outline_0122
                                   2155 	.globl _ak820_outline_0123
                                   2156 	.globl _ak820_outline_0124
                                   2157 	.globl _ak820_outline_0130
                                   2158 	.globl _ak820_outline_0131
                                   2159 	.globl _ak820_outline_0136
                                   2160 	.globl _ak820_outline_0138
                                   2161 	.globl _ak820_outline_0152
                                   2162 	.globl _ak820_outline_0153
                                   2163 	.globl _ak820_outline_0158
                                   2164 	.globl _ak820_outline_0168
                                   2165 	.globl _ak820_outline_0170
                                   2166 	.globl _ak820_outline_0173
                                   2167 	.globl _ak820_outline_0180
                                   2168 	.globl _ak820_outline_0185
                                   2169 	.globl _ak820_outline_0187
                                   2170 
                                   2171 	.area CSEG (CODE)
                                   2172 ; function ak820_outline_0029
      0082B3                       2173 _ak820_outline_0029:
      0082B3 EF               [12] 2174 	mov	a,r7
      0082B4 24 96            [12] 2175 	add	a,#_key_refs
      0082B6 FD               [12] 2176 	mov	r5,a
      0082B7 E4               [12] 2177 	clr	a
      0082B8 34 09            [12] 2178 	addc	a,#(_key_refs>>8)
      0082BA FE               [12] 2179 	mov	r6,a
      0082BB 8D 82            [24] 2180 	mov	dpl,r5
      0082BD 8E 83            [24] 2181 	mov	dph,r6
      0082BF E0               [24] 2182 	movx	a,@dptr
      0082C0 22               [24] 2183 	ret
                                   2184 
                                   2185 	.area CSEG (CODE)
                                   2186 ; function ak820_outline_0064
      0082C1                       2187 _ak820_outline_0064:
      0082C1 89 82            [24] 2188 	mov	dpl,r1
      0082C3 8A 83            [24] 2189 	mov	dph,r2
      0082C5 E8               [12] 2190 	mov	a,r0
      0082C6 F0               [24] 2191 	movx	@dptr,a
      0082C7 22               [24] 2192 	ret
                                   2193 
                                   2194 	.area CSEG (CODE)
                                   2195 ; function ak820_outline_0068
      0082C8                       2196 _ak820_outline_0068:
      0082C8 24 71            [12] 2197 	add	a,#_usage_order
      0082CA F5 82            [12] 2198 	mov	dpl,a
      0082CC E4               [12] 2199 	clr	a
      0082CD 34 0A            [12] 2200 	addc	a,#(_usage_order>>8)
      0082CF F5 83            [12] 2201 	mov	dph,a
      0082D1 22               [24] 2202 	ret
                                   2203 
                                   2204 	.area CSEG (CODE)
                                   2205 ; function ak820_outline_0074
      0082D2                       2206 _ak820_outline_0074:
      0082D2 EB               [12] 2207 	mov	a,r3
      0082D3 24 53            [12] 2208 	add	a,#_usage_refs
      0082D5 F9               [12] 2209 	mov	r1,a
      0082D6 E4               [12] 2210 	clr	a
      0082D7 34 0A            [12] 2211 	addc	a,#(_usage_refs>>8)
      0082D9 FA               [12] 2212 	mov	r2,a
      0082DA 89 82            [24] 2213 	mov	dpl,r1
      0082DC 8A 83            [24] 2214 	mov	dph,r2
      0082DE E0               [24] 2215 	movx	a,@dptr
      0082DF F8               [12] 2216 	mov	r0,a
      0082E0 22               [24] 2217 	ret
                                   2218 
                                   2219 	.area CSEG (CODE)
                                   2220 ; function ak820_outline_0114
      0082E1                       2221 _ak820_outline_0114:
      0082E1 F0               [24] 2222 	movx	@dptr,a
      0082E2 E0               [24] 2223 	movx	a,@dptr
      0082E3 FF               [12] 2224 	mov	r7,a
      0082E4 90 09 8E         [24] 2225 	mov	dptr,#_change_owned_PARM_2
      0082E7 22               [24] 2226 	ret
                                   2227 
                                   2228 	.area CSEG (CODE)
                                   2229 ; function ak820_outline_0119
      0082E8                       2230 _ak820_outline_0119:
      0082E8 8D 82            [24] 2231 	mov	dpl,r5
      0082EA 8E 83            [24] 2232 	mov	dph,r6
      0082EC F0               [24] 2233 	movx	@dptr,a
      0082ED 22               [24] 2234 	ret
                                   2235 
                                   2236 	.area CSEG (CODE)
                                   2237 ; function ak820_outline_0124
      0082EE                       2238 _ak820_outline_0124:
      0082EE 24 71            [12] 2239 	add	a,#_usage_order
      0082F0 F5 82            [12] 2240 	mov	dpl,a
      0082F2 EF               [12] 2241 	mov	a,r7
      0082F3 34 0A            [12] 2242 	addc	a,#(_usage_order>>8)
      0082F5 F5 83            [12] 2243 	mov	dph,a
      0082F7 E0               [24] 2244 	movx	a,@dptr
      0082F8 22               [24] 2245 	ret
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0130
      0082F9                       2249 _ak820_outline_0130:
      0082F9 F0               [24] 2250 	movx	@dptr,a
      0082FA E0               [24] 2251 	movx	a,@dptr
      0082FB FF               [12] 2252 	mov	r7,a
      0082FC 90 09 8A         [24] 2253 	mov	dptr,#_ak820_macro_change_PARM_2
      0082FF F0               [24] 2254 	movx	@dptr,a
      008300 90 09 8B         [24] 2255 	mov	dptr,#_ak820_macro_change_PARM_3
      008303 22               [24] 2256 	ret
                                   2257 
                                   2258 	.area CSEG (CODE)
                                   2259 ; function ak820_outline_0170
      008304                       2260 _ak820_outline_0170:
      008304 EF               [12] 2261 	mov	a,r7
      008305 42 06            [12] 2262 	orl	ar6,a
      008307 90 0D A1         [24] 2263 	mov	dptr,#_actual_keyboard_report
      00830A EE               [12] 2264 	mov	a,r6
      00830B F0               [24] 2265 	movx	@dptr,a
      00830C 22               [24] 2266 	ret
                                   2267 
                                   2268 	.area CSEG (CODE)
                                   2269 ; function ak820_outline_0173
      00830D                       2270 _ak820_outline_0173:
      00830D 90 08 04         [24] 2271 	mov	dptr,#_add_key_to_report_PARM_2
      008310 EF               [12] 2272 	mov	a,r7
      008311 F0               [24] 2273 	movx	@dptr,a
      008312 90 0D A1         [24] 2274 	mov	dptr,#_actual_keyboard_report
      008315 22               [24] 2275 	ret
                                   2276 
                                   2277 	.area CSEG (CODE)
                                   2278 ; function ak820_outline_0187
      008316                       2279 _ak820_outline_0187:
      008316 8D 82            [24] 2280 	mov	dpl,r5
      008318 8F 83            [24] 2281 	mov	dph,r7
      00831A 22               [24] 2282 	ret
