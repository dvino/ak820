                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007F6                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007F6                        556 	.ds 1
      0007F7                        557 _add_key_byte_PARM_2:
      0007F7                        558 	.ds 1
      0007F8                        559 _add_key_byte_report_arg_10000_144:
      0007F8                        560 	.ds 2
      0007FA                        561 _add_key_byte_empty_10000_145:
      0007FA                        562 	.ds 1
      0007FB                        563 _del_key_byte_PARM_2:
      0007FB                        564 	.ds 1
      0007FC                        565 _del_key_byte_report_arg_10000_156:
      0007FC                        566 	.ds 2
      0007FE                        567 _add_key_bit_PARM_2:
      0007FE                        568 	.ds 1
      0007FF                        569 _add_key_bit_report_arg_10000_162:
      0007FF                        570 	.ds 2
      000801                        571 _del_key_bit_PARM_2:
      000801                        572 	.ds 1
      000802                        573 _del_key_bit_report_arg_10000_167:
      000802                        574 	.ds 2
      000804                        575 _add_key_to_report_PARM_2:
      000804                        576 	.ds 1
      000805                        577 _add_key_to_report_report_arg_10000_172:
      000805                        578 	.ds 2
      000807                        579 _del_key_from_report_PARM_2:
      000807                        580 	.ds 1
      000808                        581 _del_key_from_report_report_arg_10000_176:
      000808                        582 	.ds 2
      00080A                        583 _clear_keys_from_report_report_arg_10000_180:
      00080A                        584 	.ds 2
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006F68                        636 _KEYCODE2CONSUMER:
      006F68 E5 82            [12]  637 	mov	a,dpl
      006F6A 90 07 F6         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006F6D F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006F6E E0               [24]  641 	movx	a,@dptr
      006F6F FF               [12]  642 	mov	r7,a
      006F70 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006F73                        644 00113$:
      006F73 40 05            [24]  645 	jc	00101$
      006F75 EF               [12]  646 	mov	a,r7
      006F76 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006F78 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006F7A                        650 00101$:
      006F7A 90 00 00         [24]  651 	mov	dptr,#0x0000
      006F7D 22               [24]  652 	ret
      006F7E                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      006F7E EF               [12]  655 	mov	a,r7
      006F7F 24 58            [12]  656 	add	a,#0x58
      006F81 FF               [12]  657 	mov	r7,a
      006F82 C2 D5            [12]  658 	clr	F0
      006F84 75 F0 02         [24]  659 	mov	b,#0x02
      006F87 EF               [12]  660 	mov	a,r7
      006F88 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006F8B B2 D5            [12]  662 	cpl	F0
      006F8D F4               [12]  663 	cpl	a
      006F8E 04               [12]  664 	inc	a
      006F8F                        665 00116$:
      006F8F A4               [48]  666 	mul	ab
      006F90 30 D5 03         [24]  667 	jnb	F0,00117$
      006F93 12 71 78         [24]  668 	lcall	_ak820_outline_0128
      006F96                        669 00117$:
      006F96 24 10            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006F98 F5 82            [12]  671 	mov	dpl,a
      006F9A 74 BB            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006F9C 12 58 29         [24]  673 	lcall	_ak820_outline_0106
      006F9F FE               [12]  674 	mov	r6,a
      006FA0 A3               [24]  675 	inc	dptr
      006FA1 E4               [12]  676 	clr	a
      006FA2 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:45: }
      006FA3 8E 82            [24]  679 	mov	dpl,r6
      006FA5 F5 83            [12]  680 	mov	dph,a
      006FA7 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006FA8                        695 _add_key_byte:
      006FA8 12 38 49         [24]  696 	lcall	_ak820_outline_0104
      006FAB 90 07 F8         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006FAE 12 38 4E         [24]  698 	lcall	_ak820_outline_0105
                                    699 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006FB1 90 07 F8         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006FB4 12 38 00         [24]  701 	lcall	_ak820_outline_0051
                                    702 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      006FB7 90 07 FA         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006FBA 74 FF            [12]  704 	mov	a,#0xff
      006FBC F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:200: }
      006FBD 7D 00            [12]  707 	mov	r5,#0x00
      006FBF                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006FBF C3               [12]  710 	clr	c
      006FC0 ED               [12]  711 	mov	a,r5
      006FC1 64 80            [12]  712 	xrl	a,#0x80
      006FC3 94 86            [12]  713 	subb	a,#0x86
      006FC5 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      006FC7 12 71 83         [24]  716 	lcall	_ak820_outline_0142
      006FCA F5 82            [12]  717 	mov	dpl,a
      006FCC E4               [12]  718 	clr	a
      006FCD 3C               [12]  719 	addc	a, r4
      006FCE F5 83            [12]  720 	mov	dph,a
      006FD0 E0               [24]  721 	movx	a,@dptr
      006FD1 FC               [12]  722 	mov	r4,a
      006FD2 90 07 F7         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      006FD5 E0               [24]  724 	movx	a,@dptr
      006FD6 FB               [12]  725 	mov	r3,a
      006FD7 EC               [12]  726 	mov	a,r4
      006FD8 B5 03 02         [24]  727 	cjne	a,ar3,00167$
      006FDB 80 13            [24]  728 	sjmp	00106$
      006FDD                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006FDD 90 07 FA         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      006FE0 E0               [24]  732 	movx	a,@dptr
      006FE1 FB               [12]  733 	mov	r3,a
      006FE2 BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      006FE5 EC               [12]  735 	mov	a,r4
      006FE6 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:191: empty = i;
      006FE8 90 07 FA         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      006FEB ED               [12]  739 	mov	a,r5
      006FEC F0               [24]  740 	movx	@dptr,a
      006FED                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006FED 0D               [12]  743 	inc	r5
      006FEE 80 CF            [24]  744 	sjmp	00112$
      006FF0                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      006FF0 BD 06 1C         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      006FF3 90 07 FA         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      006FF6 E0               [24]  750 	movx	a,@dptr
      006FF7 FD               [12]  751 	mov	r5,a
      006FF8 BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      006FFB 22               [24]  753 	ret
      006FFC                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      006FFC 74 02            [12]  756 	mov	a,#0x02
      006FFE 12 43 9D         [24]  757 	lcall	_ak820_outline_0134
      007001 ED               [12]  758 	mov	a,r5
      007002 2E               [12]  759 	add	a, r6
      007003 FD               [12]  760 	mov	r5,a
      007004 E4               [12]  761 	clr	a
      007005 3F               [12]  762 	addc	a, r7
      007006 FC               [12]  763 	mov	r4,a
      007007 90 07 F7         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      00700A E0               [24]  765 	movx	a,@dptr
      00700B 12 43 CE         [24]  766 	lcall	_ak820_outline_0186
      00700E F0               [24]  767 	movx	@dptr,a
      00700F                        768 00114$:
                                    769 ;	tmk_core/protocol/report.c:200: }
      00700F 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'del_key_byte'
                                    773 ;------------------------------------------------------------
                                    774 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    775 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    776 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    777 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    778 ;------------------------------------------------------------
                                    779 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    780 ;	-----------------------------------------
                                    781 ;	 function del_key_byte
                                    782 ;	-----------------------------------------
      007010                        783 _del_key_byte:
      007010 12 38 49         [24]  784 	lcall	_ak820_outline_0104
      007013 90 07 FC         [24]  785 	mov	dptr,#_del_key_byte_report_arg_10000_156
      007016 12 38 4E         [24]  786 	lcall	_ak820_outline_0105
                                    787 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007019 90 07 FC         [24]  788 	mov	dptr,#_del_key_byte_report_arg_10000_156
      00701C 12 38 00         [24]  789 	lcall	_ak820_outline_0051
                                    790 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      00701F 7D 00            [12]  791 	mov	r5,#0x00
      007021                        792 00105$:
      007021 BD 06 00         [24]  793 	cjne	r5,#0x06,00131$
      007024                        794 00131$:
      007024 50 1B            [24]  795 	jnc	00107$
                                    796 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      007026 12 71 83         [24]  797 	lcall	_ak820_outline_0142
      007029 FB               [12]  798 	mov	r3,a
      00702A E4               [12]  799 	clr	a
      00702B 3C               [12]  800 	addc	a, r4
      00702C FC               [12]  801 	mov	r4,a
      00702D 12 49 C6         [24]  802 	lcall	_ak820_outline_0065
      007030 90 07 FB         [24]  803 	mov	dptr,#_del_key_byte_PARM_2
      007033 E0               [24]  804 	movx	a,@dptr
      007034 F9               [12]  805 	mov	r1,a
      007035 EA               [12]  806 	mov	a,r2
      007036 B5 01 05         [24]  807 	cjne	a,ar1,00106$
                                    808 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      007039 12 33 FC         [24]  809 	lcall	_ak820_outline_0122
      00703C E4               [12]  810 	clr	a
      00703D F0               [24]  811 	movx	@dptr,a
      00703E                        812 00106$:
                                    813 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      00703E 0D               [12]  814 	inc	r5
      00703F 80 E0            [24]  815 	sjmp	00105$
      007041                        816 00107$:
                                    817 ;	tmk_core/protocol/report.c:240: }
      007041 22               [24]  818 	ret
                                    819 ;------------------------------------------------------------
                                    820 ;Allocation info for local variables in function 'add_key_bit'
                                    821 ;------------------------------------------------------------
                                    822 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    823 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    824 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    825 ;------------------------------------------------------------
                                    826 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    827 ;	-----------------------------------------
                                    828 ;	 function add_key_bit
                                    829 ;	-----------------------------------------
      007042                        830 _add_key_bit:
      007042 12 38 49         [24]  831 	lcall	_ak820_outline_0104
      007045 90 07 FF         [24]  832 	mov	dptr,#_add_key_bit_report_arg_10000_162
      007048 12 38 4E         [24]  833 	lcall	_ak820_outline_0105
                                    834 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00704B 90 07 FF         [24]  835 	mov	dptr,#_add_key_bit_report_arg_10000_162
      00704E 12 38 00         [24]  836 	lcall	_ak820_outline_0051
                                    837 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007051 90 07 FE         [24]  838 	mov	dptr,#_add_key_bit_PARM_2
      007054 E0               [24]  839 	movx	a,@dptr
      007055 FD               [12]  840 	mov	r5,a
      007056 12 58 48         [24]  841 	lcall	_ak820_outline_0168
      007059 FC               [12]  842 	mov	r4,a
      00705A BC 1E 00         [24]  843 	cjne	r4,#0x1e,00112$
      00705D                        844 00112$:
      00705D 50 16            [24]  845 	jnc	00103$
                                    846 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      00705F 12 71 61         [24]  847 	lcall	_ak820_outline_0032
      007062 80 02            [24]  848 	sjmp	00115$
      007064                        849 00114$:
      007064 25 E0            [12]  850 	add	a,acc
      007066                        851 00115$:
      007066 D5 F0 FB         [24]  852 	djnz	b,00114$
      007069 FF               [12]  853 	mov	r7,a
      00706A 12 43 C9         [24]  854 	lcall	_ak820_outline_0182
      00706D E0               [24]  855 	movx	a,@dptr
      00706E 42 07            [12]  856 	orl	ar7,a
      007070 12 43 C9         [24]  857 	lcall	_ak820_outline_0182
      007073 EF               [12]  858 	mov	a,r7
      007074 F0               [24]  859 	movx	@dptr,a
      007075                        860 00103$:
                                    861 ;	tmk_core/protocol/report.c:254: }
      007075 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'del_key_bit'
                                    865 ;------------------------------------------------------------
                                    866 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    867 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    868 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    869 ;------------------------------------------------------------
                                    870 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function del_key_bit
                                    873 ;	-----------------------------------------
      007076                        874 _del_key_bit:
      007076 12 38 49         [24]  875 	lcall	_ak820_outline_0104
      007079 90 08 02         [24]  876 	mov	dptr,#_del_key_bit_report_arg_10000_167
      00707C 12 38 4E         [24]  877 	lcall	_ak820_outline_0105
                                    878 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00707F 90 08 02         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007082 12 38 00         [24]  880 	lcall	_ak820_outline_0051
                                    881 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007085 90 08 01         [24]  882 	mov	dptr,#_del_key_bit_PARM_2
      007088 E0               [24]  883 	movx	a,@dptr
      007089 FD               [12]  884 	mov	r5,a
      00708A 12 58 48         [24]  885 	lcall	_ak820_outline_0168
      00708D FC               [12]  886 	mov	r4,a
      00708E BC 1E 00         [24]  887 	cjne	r4,#0x1e,00112$
      007091                        888 00112$:
      007091 50 17            [24]  889 	jnc	00103$
                                    890 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      007093 12 71 61         [24]  891 	lcall	_ak820_outline_0032
      007096 80 02            [24]  892 	sjmp	00115$
      007098                        893 00114$:
      007098 25 E0            [12]  894 	add	a,acc
      00709A                        895 00115$:
      00709A D5 F0 FB         [24]  896 	djnz	b,00114$
      00709D F4               [12]  897 	cpl	a
      00709E FF               [12]  898 	mov	r7,a
      00709F 12 43 C9         [24]  899 	lcall	_ak820_outline_0182
      0070A2 E0               [24]  900 	movx	a,@dptr
      0070A3 52 07            [12]  901 	anl	ar7,a
      0070A5 12 43 C9         [24]  902 	lcall	_ak820_outline_0182
      0070A8 EF               [12]  903 	mov	a,r7
      0070A9 F0               [24]  904 	movx	@dptr,a
      0070AA                        905 00103$:
                                    906 ;	tmk_core/protocol/report.c:267: }
      0070AA 22               [24]  907 	ret
                                    908 ;------------------------------------------------------------
                                    909 ;Allocation info for local variables in function 'add_key_to_report'
                                    910 ;------------------------------------------------------------
                                    911 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    912 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    913 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function add_key_to_report
                                    918 ;	-----------------------------------------
      0070AB                        919 _add_key_to_report:
      0070AB 12 38 49         [24]  920 	lcall	_ak820_outline_0104
      0070AE 90 08 05         [24]  921 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      0070B1 12 38 4E         [24]  922 	lcall	_ak820_outline_0105
                                    923 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0070B4 90 08 05         [24]  924 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      0070B7 12 38 00         [24]  925 	lcall	_ak820_outline_0051
                                    926 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      0070BA 90 0D 8E         [24]  927 	mov	dptr,#_keyboard_protocol
      0070BD E0               [24]  928 	movx	a,@dptr
      0070BE 60 14            [24]  929 	jz	00102$
      0070C0 90 0A C0         [24]  930 	mov	dptr,#_keymap_config
      0070C3 E0               [24]  931 	movx	a,@dptr
      0070C4 30 E7 0D         [24]  932 	jnb	acc.7,00102$
                                    933 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      0070C7 90 08 04         [24]  934 	mov	dptr,#_add_key_to_report_PARM_2
      0070CA E0               [24]  935 	movx	a,@dptr
      0070CB 90 07 FE         [24]  936 	mov	dptr,#_add_key_bit_PARM_2
      0070CE 12 43 6F         [24]  937 	lcall	_ak820_outline_0061
                                    938 ;	tmk_core/protocol/report.c:279: return;
      0070D1 02 70 42         [24]  939 	ljmp	_add_key_bit
      0070D4                        940 00102$:
                                    941 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      0070D4 90 08 04         [24]  942 	mov	dptr,#_add_key_to_report_PARM_2
      0070D7 E0               [24]  943 	movx	a,@dptr
      0070D8 90 07 F7         [24]  944 	mov	dptr,#_add_key_byte_PARM_2
      0070DB 12 43 6F         [24]  945 	lcall	_ak820_outline_0061
                                    946 ;	tmk_core/protocol/report.c:283: }
      0070DE 02 6F A8         [24]  947 	ljmp	_add_key_byte
                                    948 ;------------------------------------------------------------
                                    949 ;Allocation info for local variables in function 'del_key_from_report'
                                    950 ;------------------------------------------------------------
                                    951 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    952 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    953 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    954 ;------------------------------------------------------------
                                    955 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function del_key_from_report
                                    958 ;	-----------------------------------------
      0070E1                        959 _del_key_from_report:
      0070E1 12 38 49         [24]  960 	lcall	_ak820_outline_0104
      0070E4 90 08 08         [24]  961 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      0070E7 12 38 4E         [24]  962 	lcall	_ak820_outline_0105
                                    963 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0070EA 90 08 08         [24]  964 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      0070ED 12 38 00         [24]  965 	lcall	_ak820_outline_0051
                                    966 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      0070F0 90 0D 8E         [24]  967 	mov	dptr,#_keyboard_protocol
      0070F3 E0               [24]  968 	movx	a,@dptr
      0070F4 60 14            [24]  969 	jz	00102$
      0070F6 90 0A C0         [24]  970 	mov	dptr,#_keymap_config
      0070F9 E0               [24]  971 	movx	a,@dptr
      0070FA 30 E7 0D         [24]  972 	jnb	acc.7,00102$
                                    973 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      0070FD 90 08 07         [24]  974 	mov	dptr,#_del_key_from_report_PARM_2
      007100 E0               [24]  975 	movx	a,@dptr
      007101 90 08 01         [24]  976 	mov	dptr,#_del_key_bit_PARM_2
      007104 12 43 6F         [24]  977 	lcall	_ak820_outline_0061
                                    978 ;	tmk_core/protocol/report.c:294: return;
      007107 02 70 76         [24]  979 	ljmp	_del_key_bit
      00710A                        980 00102$:
                                    981 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      00710A 90 08 07         [24]  982 	mov	dptr,#_del_key_from_report_PARM_2
      00710D E0               [24]  983 	movx	a,@dptr
      00710E 90 07 FB         [24]  984 	mov	dptr,#_del_key_byte_PARM_2
      007111 12 43 6F         [24]  985 	lcall	_ak820_outline_0061
                                    986 ;	tmk_core/protocol/report.c:298: }
      007114 02 70 10         [24]  987 	ljmp	_del_key_byte
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    990 ;------------------------------------------------------------
                                    991 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    992 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    993 ;------------------------------------------------------------
                                    994 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function clear_keys_from_report
                                    997 ;	-----------------------------------------
      007117                        998 _clear_keys_from_report:
      007117 12 38 49         [24]  999 	lcall	_ak820_outline_0104
      00711A 90 08 0A         [24] 1000 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      00711D 12 38 4E         [24] 1001 	lcall	_ak820_outline_0105
                                   1002 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007120 90 08 0A         [24] 1003 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      007123 12 38 00         [24] 1004 	lcall	_ak820_outline_0051
                                   1005 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      007126 90 0D 8E         [24] 1006 	mov	dptr,#_keyboard_protocol
      007129 E0               [24] 1007 	movx	a,@dptr
      00712A 60 1E            [24] 1008 	jz	00102$
      00712C 90 0A C0         [24] 1009 	mov	dptr,#_keymap_config
      00712F E0               [24] 1010 	movx	a,@dptr
      007130 30 E7 17         [24] 1011 	jnb	acc.7,00102$
                                   1012 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      007133 74 02            [12] 1013 	mov	a,#0x02
      007135 12 43 B8         [24] 1014 	lcall	_ak820_outline_0156
      007138 7B 00            [12] 1015 	mov	r3,#0x00
      00713A 12 71 8D         [24] 1016 	lcall	_ak820_outline_0178
      00713D 74 1E            [12] 1017 	mov	a,#0x1e
      00713F F0               [24] 1018 	movx	@dptr,a
      007140 E4               [12] 1019 	clr	a
      007141 A3               [24] 1020 	inc	dptr
      007142 12 38 31         [24] 1021 	lcall	_ak820_outline_0096
      007145 8B F0            [24] 1022 	mov	b, r3
                                   1023 ;	tmk_core/protocol/report.c:310: return;
      007147 02 BA 01         [24] 1024 	ljmp	_memset
      00714A                       1025 00102$:
                                   1026 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      00714A 74 02            [12] 1027 	mov	a,#0x02
      00714C 12 43 9D         [24] 1028 	lcall	_ak820_outline_0134
      00714F 7D 00            [12] 1029 	mov	r5,#0x00
      007151 12 71 8D         [24] 1030 	lcall	_ak820_outline_0178
      007154 74 06            [12] 1031 	mov	a,#0x06
      007156 F0               [24] 1032 	movx	@dptr,a
      007157 E4               [12] 1033 	clr	a
      007158 A3               [24] 1034 	inc	dptr
      007159 12 43 6F         [24] 1035 	lcall	_ak820_outline_0061
      00715C 8D F0            [24] 1036 	mov	b, r5
                                   1037 ;	tmk_core/protocol/report.c:314: }
      00715E 02 BA 01         [24] 1038 	ljmp	_memset
                                   1039 	.area CSEG    (CODE)
                                   1040 	.area CONST   (CODE)
                                   1041 	.area CONST   (CODE)
      00BB10                       1042 _KEYCODE2CONSUMER_usages_10000_118:
      00BB10 E2 00                 1043 	.byte #0xe2, #0x00	; 226
      00BB12 E9 00                 1044 	.byte #0xe9, #0x00	; 233
      00BB14 EA 00                 1045 	.byte #0xea, #0x00	; 234
      00BB16 B5 00                 1046 	.byte #0xb5, #0x00	; 181
      00BB18 B6 00                 1047 	.byte #0xb6, #0x00	; 182
      00BB1A B7 00                 1048 	.byte #0xb7, #0x00	; 183
      00BB1C CD 00                 1049 	.byte #0xcd, #0x00	; 205
      00BB1E 83 01                 1050 	.byte #0x83, #0x01	; 387
      00BB20 CC 00                 1051 	.byte #0xcc, #0x00	; 204
      00BB22 8A 01                 1052 	.byte #0x8a, #0x01	; 394
      00BB24 92 01                 1053 	.byte #0x92, #0x01	; 402
      00BB26 94 01                 1054 	.byte #0x94, #0x01	; 404
      00BB28 21 02                 1055 	.byte #0x21, #0x02	; 545
      00BB2A 23 02                 1056 	.byte #0x23, #0x02	; 547
      00BB2C 24 02                 1057 	.byte #0x24, #0x02	; 548
      00BB2E 25 02                 1058 	.byte #0x25, #0x02	; 549
      00BB30 26 02                 1059 	.byte #0x26, #0x02	; 550
      00BB32 27 02                 1060 	.byte #0x27, #0x02	; 551
      00BB34 2A 02                 1061 	.byte #0x2a, #0x02	; 554
      00BB36 B3 00                 1062 	.byte #0xb3, #0x00	; 179
      00BB38 B4 00                 1063 	.byte #0xb4, #0x00	; 180
      00BB3A 6F 00                 1064 	.byte #0x6f, #0x00	; 111
      00BB3C 70 00                 1065 	.byte #0x70, #0x00	; 112
      00BB3E 9F 01                 1066 	.byte #0x9f, #0x01	; 415
      00BB40 CB 01                 1067 	.byte #0xcb, #0x01	; 459
      00BB42 9F 02                 1068 	.byte #0x9f, #0x02	; 671
      00BB44 A0 02                 1069 	.byte #0xa0, #0x02	; 672
                                   1070 	.area CSEG    (CODE)
                                   1071 	.area XINIT   (CODE)
                                   1072 	.area CABS    (ABS,CODE)
                                   1073 
                                   1074 ; Experimental exact instruction outlining.
                                   1075 	.globl _ak820_outline_0032
                                   1076 	.globl _ak820_outline_0051
                                   1077 	.globl _ak820_outline_0061
                                   1078 	.globl _ak820_outline_0065
                                   1079 	.globl _ak820_outline_0096
                                   1080 	.globl _ak820_outline_0104
                                   1081 	.globl _ak820_outline_0105
                                   1082 	.globl _ak820_outline_0106
                                   1083 	.globl _ak820_outline_0122
                                   1084 	.globl _ak820_outline_0128
                                   1085 	.globl _ak820_outline_0134
                                   1086 	.globl _ak820_outline_0142
                                   1087 	.globl _ak820_outline_0156
                                   1088 	.globl _ak820_outline_0168
                                   1089 	.globl _ak820_outline_0178
                                   1090 	.globl _ak820_outline_0182
                                   1091 	.globl _ak820_outline_0186
                                   1092 
                                   1093 	.area CSEG (CODE)
                                   1094 ; function ak820_outline_0032
      007161                       1095 _ak820_outline_0032:
      007161 74 02            [12] 1096 	mov	a,#0x02
      007163 2E               [12] 1097 	add	a,r6
      007164 FE               [12] 1098 	mov	r6,a
      007165 E4               [12] 1099 	clr	a
      007166 3F               [12] 1100 	addc	a,r7
      007167 FF               [12] 1101 	mov	r7,a
      007168 EC               [12] 1102 	mov	a,r4
      007169 2E               [12] 1103 	add	a,r6
      00716A FC               [12] 1104 	mov	r4,a
      00716B E4               [12] 1105 	clr	a
      00716C 3F               [12] 1106 	addc	a,r7
      00716D FB               [12] 1107 	mov	r3,a
      00716E 74 07            [12] 1108 	mov	a,#0x07
      007170 5D               [12] 1109 	anl	a,r5
      007171 F5 F0            [12] 1110 	mov	b,a
      007173 05 F0            [12] 1111 	inc	b
      007175 74 01            [12] 1112 	mov	a,#0x01
      007177 22               [24] 1113 	ret
                                   1114 
                                   1115 	.area CSEG (CODE)
                                   1116 ; function ak820_outline_0128
      007178                       1117 _ak820_outline_0128:
      007178 F4               [12] 1118 	cpl	a
      007179 24 01            [12] 1119 	add	a,#0x01
      00717B C5 F0            [12] 1120 	xch	a,b
      00717D F4               [12] 1121 	cpl	a
      00717E 34 00            [12] 1122 	addc	a,#0x00
      007180 C5 F0            [12] 1123 	xch	a,b
      007182 22               [24] 1124 	ret
                                   1125 
                                   1126 	.area CSEG (CODE)
                                   1127 ; function ak820_outline_0142
      007183                       1128 _ak820_outline_0142:
      007183 74 02            [12] 1129 	mov	a,#0x02
      007185 2E               [12] 1130 	add	a,r6
      007186 FB               [12] 1131 	mov	r3,a
      007187 E4               [12] 1132 	clr	a
      007188 3F               [12] 1133 	addc	a,r7
      007189 FC               [12] 1134 	mov	r4,a
      00718A ED               [12] 1135 	mov	a,r5
      00718B 2B               [12] 1136 	add	a,r3
      00718C 22               [24] 1137 	ret
                                   1138 
                                   1139 	.area CSEG (CODE)
                                   1140 ; function ak820_outline_0178
      00718D                       1141 _ak820_outline_0178:
      00718D 90 0D 84         [24] 1142 	mov	dptr,#_memset_PARM_2
      007190 E4               [12] 1143 	clr	a
      007191 F0               [24] 1144 	movx	@dptr,a
      007192 90 0D 85         [24] 1145 	mov	dptr,#_memset_PARM_3
      007195 22               [24] 1146 	ret
