                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BB2                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BB2 E5 82            [12]  215 	mov	a,dpl
      003BB4 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BB7 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BB8 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003BBB 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BBE E0               [24]  221 	movx	a,@dptr
      003BBF 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003BC2 F0               [24]  223 	movx	@dptr,a
      003BC3                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003BC3 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003BC5 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003BC6                        239 _ak820_nvm_diagnostic:
      003BC6 12 38 40         [24]  240 	lcall	_ak820_outline_0104
      003BC9 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BCC 12 38 45         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BCF 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BD2 12 37 F7         [24]  245 	lcall	_ak820_outline_0051
      003BD5 A2 09            [12]  246 	mov	c,_storage_failed
      003BD7 E4               [12]  247 	clr	a
      003BD8 33               [12]  248 	rlc	a
      003BD9 12 43 84         [24]  249 	lcall	_ak820_outline_0117
      003BDC 12 43 66         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BDF A3               [24]  252 	inc	dptr
      003BE0 A2 07            [12]  253 	mov	c,_page_valid
      003BE2 E4               [12]  254 	clr	a
      003BE3 33               [12]  255 	rlc	a
      003BE4 12 43 3A         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BE7 A2 08            [12]  258 	mov	c,_page_dirty
      003BE9 E4               [12]  259 	clr	a
      003BEA 33               [12]  260 	rlc	a
      003BEB F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BEC 74 03            [12]  263 	mov	a,#0x03
      003BEE 12 43 AF         [24]  264 	lcall	_ak820_outline_0156
      003BF1 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003BF4 E0               [24]  266 	movx	a,@dptr
      003BF5 12 38 57         [24]  267 	lcall	_ak820_outline_0121
      003BF8 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BF9 74 04            [12]  270 	mov	a,#0x04
      003BFB 12 43 AF         [24]  271 	lcall	_ak820_outline_0156
      003BFE 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003C01 E0               [24]  273 	movx	a,@dptr
      003C02 12 38 57         [24]  274 	lcall	_ak820_outline_0121
      003C05 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C06 12 43 30         [24]  277 	lcall	_ak820_outline_0010
      003C09 E4               [12]  278 	clr	a
      003C0A F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C0B 74 06            [12]  281 	mov	a,#0x06
      003C0D 12 43 94         [24]  282 	lcall	_ak820_outline_0134
      003C10 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003C13 E0               [24]  284 	movx	a,@dptr
      003C14 12 43 84         [24]  285 	lcall	_ak820_outline_0117
      003C17 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C18 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C19                        300 _crc_byte:
      003C19 12 38 40         [24]  301 	lcall	_ak820_outline_0104
      003C1C 90 05 60         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C1F 12 38 45         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C22 90 05 5F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C25 E0               [24]  306 	movx	a,@dptr
      003C26 FF               [12]  307 	mov	r7,a
      003C27 7E 00            [12]  308 	mov	r6,#0x00
      003C29 90 05 60         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C2C E0               [24]  310 	movx	a,@dptr
      003C2D 6E               [12]  311 	xrl	a,r6
      003C2E F0               [24]  312 	movx	@dptr,a
      003C2F A3               [24]  313 	inc	dptr
      003C30 E0               [24]  314 	movx	a,@dptr
      003C31 6F               [12]  315 	xrl	a,r7
      003C32 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C33 7F 00            [12]  318 	mov	r7,#0x00
      003C35                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C35 90 05 60         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C38 12 43 72         [24]  322 	lcall	_ak820_outline_0097
      003C3B 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C3E ED               [12]  324 	mov	a,r5
      003C3F 2D               [12]  325 	add	a,r5
      003C40 FB               [12]  326 	mov	r3,a
      003C41 EE               [12]  327 	mov	a,r6
      003C42 33               [12]  328 	rlc	a
      003C43 FC               [12]  329 	mov	r4,a
      003C44 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C47 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C4A 80 06            [24]  332 	sjmp	00107$
      003C4C                        333 00106$:
      003C4C ED               [12]  334 	mov	a,r5
      003C4D 2D               [12]  335 	add	a,r5
      003C4E FB               [12]  336 	mov	r3,a
      003C4F EE               [12]  337 	mov	a,r6
      003C50 33               [12]  338 	rlc	a
      003C51 FC               [12]  339 	mov	r4,a
      003C52                        340 00107$:
      003C52 90 05 60         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C55 12 38 22         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C58 0F               [12]  344 	inc	r7
      003C59 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C5C 12 33 FC         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C5F 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C60                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C60 90 05 62         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C63 74 FF            [12]  363 	mov	a,#0xff
      003C65 F0               [24]  364 	movx	@dptr,a
      003C66 A3               [24]  365 	inc	dptr
      003C67 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C68 7F 00            [12]  368 	mov	r7,#0x00
      003C6A                        369 00102$:
      003C6A 90 05 62         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C6D 12 43 72         [24]  371 	lcall	_ak820_outline_0097
      003C70 12 43 78         [24]  372 	lcall	_ak820_outline_0102
      003C73 90 05 5F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C76 F0               [24]  374 	movx	@dptr,a
      003C77 12 38 61         [24]  375 	lcall	_ak820_outline_0131
      003C7A C0 07            [24]  376 	push	ar7
      003C7C 12 3C 19         [24]  377 	lcall	_crc_byte
      003C7F AD 82            [24]  378 	mov	r5, dpl
      003C81 AE 83            [24]  379 	mov	r6, dph
      003C83 D0 07            [24]  380 	pop	ar7
      003C85 90 05 62         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C88 12 43 B5         [24]  382 	lcall	_ak820_outline_0157
      003C8B 0F               [12]  383 	inc	r7
      003C8C BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C8F 12 38 61         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C92 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C93                        399 _write_page:
      003C93 12 38 40         [24]  400 	lcall	_ak820_outline_0104
      003C96 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C99 12 38 45         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C9C 90 05 64         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C9F 12 37 97         [24]  405 	lcall	_ak820_outline_0004
      003CA2 C0 07            [24]  406 	push	ar7
      003CA4 C0 06            [24]  407 	push	ar6
      003CA6 12 39 BD         [24]  408 	lcall	_ak820_flash_erase
      003CA9 E5 82            [12]  409 	mov	a, dpl
      003CAB D0 06            [24]  410 	pop	ar6
      003CAD D0 07            [24]  411 	pop	ar7
      003CAF 70 03            [24]  412 	jnz	00102$
      003CB1 F5 82            [12]  413 	mov	dpl,a
      003CB3 22               [24]  414 	ret
      003CB4                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CB4 90 04 F5         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CB7 74 19            [12]  418 	mov	a,#_page_data
      003CB9 F0               [24]  419 	movx	@dptr,a
      003CBA 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CBC A3               [24]  421 	inc	dptr
      003CBD 12 43 66         [24]  422 	lcall	_ak820_outline_0061
      003CC0 12 3A D1         [24]  423 	lcall	_ak820_flash_program_page
      003CC3 E5 82            [12]  424 	mov	a, dpl
      003CC5 70 03            [24]  425 	jnz	00120$
      003CC7 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC9 22               [24]  428 	ret
      003CCA                        429 00120$:
      003CCA 7F 00            [12]  430 	mov	r7,#0x00
      003CCC                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CCC 8F 05            [24]  433 	mov	ar5,r7
      003CCE 7E 00            [12]  434 	mov	r6,#0x00
      003CD0 90 05 64         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CD3 12 38 3A         [24]  436 	lcall	_ak820_outline_0101
      003CD6 ED               [12]  437 	mov	a,r5
      003CD7 2B               [12]  438 	add	a, r3
      003CD8 FB               [12]  439 	mov	r3,a
      003CD9 EE               [12]  440 	mov	a,r6
      003CDA 3C               [12]  441 	addc	a, r4
      003CDB FC               [12]  442 	mov	r4,a
      003CDC 12 33 FC         [24]  443 	lcall	_ak820_outline_0122
      003CDF 12 38 B0         [24]  444 	lcall	_ak820_flash_read
      003CE2 AE 82            [24]  445 	mov	r6, dpl
      003CE4 12 43 78         [24]  446 	lcall	_ak820_outline_0102
      003CE7 FD               [12]  447 	mov	r5,a
      003CE8 EE               [12]  448 	mov	a,r6
      003CE9 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CEC 80 04            [24]  450 	sjmp	00109$
      003CEE                        451 00149$:
      003CEE 75 82 00         [24]  452 	mov	dpl, #0x00
      003CF1 22               [24]  453 	ret
      003CF2                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CF2 0F               [12]  456 	inc	r7
      003CF3 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CF6 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CF9 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CFA                        472 _journal_header_valid:
      003CFA 12 38 40         [24]  473 	lcall	_ak820_outline_0104
      003CFD 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003D00 12 38 45         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D03 90 05 66         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D06 12 37 97         [24]  478 	lcall	_ak820_outline_0004
      003D09 E0               [24]  479 	movx	a,@dptr
      003D0A FD               [12]  480 	mov	r5,a
      003D0B BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D0E 80 04            [24]  482 	sjmp	00116$
      003D10                        483 00138$:
      003D10 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D13 22               [24]  486 	ret
      003D14                        487 00116$:
      003D14 7D 01            [12]  488 	mov	r5,#0x01
      003D16                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D16 ED               [12]  491 	mov	a,r5
      003D17 12 37 DE         [24]  492 	lcall	_ak820_outline_0017
      003D1A FC               [12]  493 	mov	r4,a
      003D1B 8D 02            [24]  494 	mov	ar2,r5
      003D1D 7B 00            [12]  495 	mov	r3,#0x00
      003D1F 74 04            [12]  496 	mov	a,#0x04
      003D21 2A               [12]  497 	add	a, r2
      003D22 FA               [12]  498 	mov	r2,a
      003D23 E4               [12]  499 	clr	a
      003D24 3B               [12]  500 	addc	a, r3
      003D25 FB               [12]  501 	mov	r3,a
      003D26 EA               [12]  502 	mov	a,r2
      003D27 2E               [12]  503 	add	a, r6
      003D28 F5 82            [12]  504 	mov	dpl,a
      003D2A EB               [12]  505 	mov	a,r3
      003D2B 3F               [12]  506 	addc	a, r7
      003D2C F5 83            [12]  507 	mov	dph,a
      003D2E E0               [24]  508 	movx	a,@dptr
      003D2F 62 04            [12]  509 	xrl	ar4,a
      003D31 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003D34 80 04            [24]  511 	sjmp	00107$
      003D36                        512 00139$:
      003D36 75 82 00         [24]  513 	mov	dpl, #0x00
      003D39 22               [24]  514 	ret
      003D3A                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D3A 0D               [12]  517 	inc	r5
      003D3B BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D3E 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D41 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003D42                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D42 7F 00            [12]  537 	mov	r7,#0x00
      003D44                        538 00115$:
      003D44 EF               [12]  539 	mov	a,r7
      003D45 24 68            [12]  540 	add	a, #_recover_journal_header_10000_46
      003D47 FD               [12]  541 	mov	r5,a
      003D48 E4               [12]  542 	clr	a
      003D49 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D4B FE               [12]  544 	mov	r6,a
      003D4C 8F 04            [24]  545 	mov	ar4,r7
      003D4E 7B 00            [12]  546 	mov	r3,#0x00
      003D50 74 40            [12]  547 	mov	a,#0x40
      003D52 2C               [12]  548 	add	a, r4
      003D53 FC               [12]  549 	mov	r4,a
      003D54 74 EF            [12]  550 	mov	a,#0xef
      003D56 3B               [12]  551 	addc	a, r3
      003D57 FB               [12]  552 	mov	r3,a
      003D58 12 43 C0         [24]  553 	lcall	_ak820_outline_0182
      003D5B 12 38 B0         [24]  554 	lcall	_ak820_flash_read
      003D5E AC 82            [24]  555 	mov	r4, dpl
      003D60 12 38 61         [24]  556 	lcall	_ak820_outline_0131
      003D63 EC               [12]  557 	mov	a,r4
      003D64 F0               [24]  558 	movx	@dptr,a
      003D65 0F               [12]  559 	inc	r7
      003D66 BF 09 DB         [24]  560 	cjne	r7,#0x09,00115$
                                    561 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D69 90 05 68         [24]  562 	mov	dptr,#_recover_journal_header_10000_46
      003D6C 12 3C FA         [24]  563 	lcall	_journal_header_valid
      003D6F E5 82            [12]  564 	mov	a, dpl
      003D71 70 01            [24]  565 	jnz	00103$
      003D73 22               [24]  566 	ret
      003D74                        567 00103$:
                                    568 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D74 90 05 69         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D77 E0               [24]  570 	movx	a,@dptr
      003D78 FF               [12]  571 	mov	r7,a
      003D79 7E 00            [12]  572 	mov	r6,#0x00
      003D7B 90 05 6A         [24]  573 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D7E E0               [24]  574 	movx	a,@dptr
      003D7F FC               [12]  575 	mov	r4,a
      003D80 E4               [12]  576 	clr	a
      003D81 42 07            [12]  577 	orl	ar7,a
      003D83 EC               [12]  578 	mov	a,r4
      003D84 42 06            [12]  579 	orl	ar6,a
                                    580 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D86 90 05 6B         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D89 E0               [24]  582 	movx	a,@dptr
      003D8A FD               [12]  583 	mov	r5,a
      003D8B 7C 00            [12]  584 	mov	r4,#0x00
      003D8D 90 05 6C         [24]  585 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D90 E0               [24]  586 	movx	a,@dptr
      003D91 FA               [12]  587 	mov	r2,a
      003D92 E4               [12]  588 	clr	a
      003D93 12 43 9A         [24]  589 	lcall	_ak820_outline_0139
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D96 C3               [12]  591 	clr	c
      003D97 EF               [12]  592 	mov	a,r7
      003D98 94 A0            [12]  593 	subb	a,#0xa0
      003D9A EE               [12]  594 	mov	a,r6
      003D9B 94 00            [12]  595 	subb	a,#0x00
      003D9D 40 06            [24]  596 	jc	00134$
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D9F 75 82 01         [24]  598 	mov	dpl, #0x01
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DA2 02 3B B2         [24]  600 	ljmp	_nvm_fail
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DA5                        602 00134$:
      003DA5 7B 00            [12]  603 	mov	r3,#0x00
      003DA7                        604 00117$:
      003DA7 C0 05            [24]  605 	push	ar5
      003DA9 C0 04            [24]  606 	push	ar4
      003DAB EB               [12]  607 	mov	a,r3
      003DAC 24 19            [12]  608 	add	a, #_page_data
      003DAE F9               [12]  609 	mov	r1,a
      003DAF E4               [12]  610 	clr	a
      003DB0 34 05            [12]  611 	addc	a, #(_page_data >> 8)
      003DB2 FA               [12]  612 	mov	r2,a
      003DB3 8B 00            [24]  613 	mov	ar0,r3
      003DB5 7D 00            [12]  614 	mov	r5,#0x00
      003DB7 74 EF            [12]  615 	mov	a,#0xef
      003DB9 2D               [12]  616 	add	a, r5
      003DBA FD               [12]  617 	mov	r5,a
      003DBB 88 82            [24]  618 	mov	dpl, r0
      003DBD 8D 83            [24]  619 	mov	dph, r5
      003DBF 12 38 B0         [24]  620 	lcall	_ak820_flash_read
      003DC2 AD 82            [24]  621 	mov	r5, dpl
      003DC4 12 43 BB         [24]  622 	lcall	_ak820_outline_0181
      003DC7 ED               [12]  623 	mov	a,r5
      003DC8 F0               [24]  624 	movx	@dptr,a
      003DC9 0B               [12]  625 	inc	r3
      003DCA BB 40 02         [24]  626 	cjne	r3,#0x40,00190$
      003DCD 80 06            [24]  627 	sjmp	00191$
      003DCF                        628 00190$:
      003DCF D0 04            [24]  629 	pop	ar4
      003DD1 D0 05            [24]  630 	pop	ar5
      003DD3 80 D2            [24]  631 	sjmp	00117$
      003DD5                        632 00191$:
      003DD5 D0 04            [24]  633 	pop	ar4
      003DD7 D0 05            [24]  634 	pop	ar5
                                    635 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DD9 C0 07            [24]  636 	push	ar7
      003DDB C0 06            [24]  637 	push	ar6
      003DDD C0 05            [24]  638 	push	ar5
      003DDF C0 04            [24]  639 	push	ar4
      003DE1 12 3C 60         [24]  640 	lcall	_page_crc
      003DE4 AA 82            [24]  641 	mov	r2, dpl
      003DE6 AB 83            [24]  642 	mov	r3, dph
      003DE8 D0 04            [24]  643 	pop	ar4
      003DEA D0 05            [24]  644 	pop	ar5
      003DEC D0 06            [24]  645 	pop	ar6
      003DEE D0 07            [24]  646 	pop	ar7
      003DF0 EA               [12]  647 	mov	a,r2
      003DF1 B5 05 06         [24]  648 	cjne	a,ar5,00192$
      003DF4 EB               [12]  649 	mov	a,r3
      003DF5 B5 04 02         [24]  650 	cjne	a,ar4,00192$
      003DF8 80 06            [24]  651 	sjmp	00113$
      003DFA                        652 00192$:
      003DFA 75 82 02         [24]  653 	mov	dpl, #0x02
      003DFD 02 3B B2         [24]  654 	ljmp	_nvm_fail
      003E00                        655 00113$:
                                    656 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E00 EE               [12]  657 	mov	a,r6
      003E01 54 03            [12]  658 	anl	a,#0x03
      003E03 A2 E0            [12]  659 	mov	c,acc.0
      003E05 CF               [12]  660 	xch	a,r7
      003E06 13               [12]  661 	rrc	a
      003E07 CF               [12]  662 	xch	a,r7
      003E08 13               [12]  663 	rrc	a
      003E09 A2 E0            [12]  664 	mov	c,acc.0
      003E0B CF               [12]  665 	xch	a,r7
      003E0C 13               [12]  666 	rrc	a
      003E0D CF               [12]  667 	xch	a,r7
      003E0E 13               [12]  668 	rrc	a
      003E0F CF               [12]  669 	xch	a,r7
      003E10 24 C7            [12]  670 	add	a,#0xc7
      003E12 FE               [12]  671 	mov	r6,a
      003E13 12 43 AA         [24]  672 	lcall	_ak820_outline_0153
      003E16 12 3C 93         [24]  673 	lcall	_write_page
      003E19 E5 82            [12]  674 	mov	a, dpl
      003E1B 70 06            [24]  675 	jnz	00110$
      003E1D 75 82 03         [24]  676 	mov	dpl, #0x03
      003E20 02 3B B2         [24]  677 	ljmp	_nvm_fail
      003E23                        678 00110$:
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E23 90 EF 40         [24]  680 	mov	dptr,#0xef40
      003E26 12 39 BD         [24]  681 	lcall	_ak820_flash_erase
      003E29 E5 82            [12]  682 	mov	a, dpl
      003E2B 70 06            [24]  683 	jnz	00119$
      003E2D 75 82 04         [24]  684 	mov	dpl, #0x04
                                    685 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E30 02 3B B2         [24]  686 	ljmp	_nvm_fail
      003E33                        687 00119$:
      003E33 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    691 ;------------------------------------------------------------
                                    692 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function eeprom_driver_init
                                    695 ;	-----------------------------------------
      003E34                        696 _eeprom_driver_init:
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    698 ;	assignBit
      003E34 C2 09            [12]  699 	clr	_storage_failed
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E36 90 05 5B         [24]  701 	mov	dptr,#_first_failure_stage
      003E39 E4               [12]  702 	clr	a
      003E3A F0               [24]  703 	movx	@dptr,a
                                    704 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    705 ;	assignBit
      003E3B C2 08            [12]  706 	clr	_page_dirty
                                    707 ;	assignBit
      003E3D C2 07            [12]  708 	clr	_page_valid
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E3F 90 05 5A         [24]  710 	mov	dptr,#_batch_depth
      003E42 E4               [12]  711 	clr	a
      003E43 F0               [24]  712 	movx	@dptr,a
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E44 12 3D 42         [24]  714 	lcall	_recover_journal
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E47 02 2A 6B         [24]  717 	ljmp	_ak820_macro_init
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    720 ;------------------------------------------------------------
                                    721 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    722 ;	-----------------------------------------
                                    723 ;	 function ak820_nvm_ok
                                    724 ;	-----------------------------------------
      003E4A                        725 _ak820_nvm_ok:
      003E4A A2 09            [12]  726 	mov	c,_storage_failed
      003E4C B3               [12]  727 	cpl	c
      003E4D 92 0A            [24]  728 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E4F 12 38 7D         [24]  729 	lcall	_ak820_outline_0166
      003E52 22               [24]  730 	ret
                                    731 ;------------------------------------------------------------
                                    732 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    733 ;------------------------------------------------------------
                                    734 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    735 ;	-----------------------------------------
                                    736 ;	 function ak820_nvm_schema_fault
                                    737 ;	-----------------------------------------
      003E53                        738 _ak820_nvm_schema_fault:
      003E53 75 82 10         [24]  739 	mov	dpl, #0x10
      003E56 02 3B B2         [24]  740 	ljmp	_nvm_fail
                                    741 ;------------------------------------------------------------
                                    742 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    743 ;------------------------------------------------------------
                                    744 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    745 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    746 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    747 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    748 ;------------------------------------------------------------
                                    749 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function ak820_nvm_flush
                                    752 ;	-----------------------------------------
      003E59                        753 _ak820_nvm_flush:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E59 30 08 03         [24]  755 	jnb	_page_dirty,00101$
      003E5C 30 09 01         [24]  756 	jnb	_storage_failed,00102$
      003E5F                        757 00101$:
      003E5F 22               [24]  758 	ret
      003E60                        759 00102$:
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E60 12 3C 60         [24]  761 	lcall	_page_crc
      003E63 12 43 8F         [24]  762 	lcall	_ak820_outline_0132
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E66 90 05 71         [24]  764 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E69 74 A5            [12]  765 	mov	a,#0xa5
      003E6B F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E6C 90 05 59         [24]  768 	mov	dptr,#_cached_page
      003E6F E0               [24]  769 	movx	a,@dptr
      003E70 90 05 72         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E73 F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E74 90 05 73         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E77 E4               [12]  774 	clr	a
      003E78 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E79 8E 05            [24]  777 	mov	ar5,r6
      003E7B 90 05 74         [24]  778 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E7E ED               [12]  779 	mov	a,r5
      003E7F F0               [24]  780 	movx	@dptr,a
                                    781 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E80 8F 06            [24]  782 	mov	ar6,r7
      003E82 90 05 75         [24]  783 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E85 EE               [12]  784 	mov	a,r6
      003E86 F0               [24]  785 	movx	@dptr,a
                                    786 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E87 7F 01            [12]  787 	mov	r7,#0x01
      003E89                        788 00128$:
      003E89 8F 06            [24]  789 	mov	ar6,r7
      003E8B EE               [12]  790 	mov	a,r6
      003E8C 24 04            [12]  791 	add	a,#0x04
      003E8E FE               [12]  792 	mov	r6,a
      003E8F 33               [12]  793 	rlc	a
      003E90 95 E0            [12]  794 	subb	a,acc
      003E92 FD               [12]  795 	mov	r5,a
      003E93 EE               [12]  796 	mov	a,r6
      003E94 24 71            [12]  797 	add	a, #_ak820_nvm_flush_header_10000_62
      003E96 FE               [12]  798 	mov	r6,a
      003E97 ED               [12]  799 	mov	a,r5
      003E98 34 05            [12]  800 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E9A FD               [12]  801 	mov	r5,a
      003E9B 12 43 49         [24]  802 	lcall	_ak820_outline_0041
      003E9E FC               [12]  803 	mov	r4,a
      003E9F 63 04 FF         [24]  804 	xrl	ar4,#0xff
      003EA2 8E 82            [24]  805 	mov	dpl,r6
      003EA4 8D 83            [24]  806 	mov	dph,r5
      003EA6 EC               [12]  807 	mov	a,r4
      003EA7 F0               [24]  808 	movx	@dptr,a
      003EA8 0F               [12]  809 	inc	r7
      003EA9 BF 05 DD         [24]  810 	cjne	r7,#0x05,00128$
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EAC 90 05 7A         [24]  812 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAF 74 05            [12]  813 	mov	a,#0x05
      003EB1 F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EB2 90 EF 40         [24]  816 	mov	dptr,#0xef40
      003EB5 12 39 BD         [24]  817 	lcall	_ak820_flash_erase
      003EB8 E5 82            [12]  818 	mov	a, dpl
      003EBA 70 03            [24]  819 	jnz	00269$
      003EBC 02 3F A2         [24]  820 	ljmp	00127$
      003EBF                        821 00269$:
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EBF 90 05 7A         [24]  823 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC2 74 06            [12]  824 	mov	a,#0x06
      003EC4 F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EC5 7F 00            [12]  827 	mov	r7,#0x00
      003EC7                        828 00130$:
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003EC7 12 43 55         [24]  830 	lcall	_ak820_outline_0052
      003ECA 12 38 B0         [24]  831 	lcall	_ak820_flash_read
      003ECD E5 82            [12]  832 	mov	a, dpl
      003ECF 60 03            [24]  833 	jz	00270$
      003ED1 02 3F A2         [24]  834 	ljmp	00127$
      003ED4                        835 00270$:
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003ED4 0F               [12]  837 	inc	r7
      003ED5 BF 40 EF         [24]  838 	cjne	r7,#0x40,00130$
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003ED8 90 05 7A         [24]  840 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EDB 74 07            [12]  841 	mov	a,#0x07
      003EDD F0               [24]  842 	movx	@dptr,a
                                    843 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EDE 90 EF 00         [24]  844 	mov	dptr,#0xef00
      003EE1 12 3C 93         [24]  845 	lcall	_write_page
      003EE4 E5 82            [12]  846 	mov	a, dpl
      003EE6 70 03            [24]  847 	jnz	00273$
      003EE8 02 3F A2         [24]  848 	ljmp	00127$
      003EEB                        849 00273$:
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EEB 90 05 7A         [24]  851 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EEE 74 08            [12]  852 	mov	a,#0x08
      003EF0 F0               [24]  853 	movx	@dptr,a
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EF1 7F 01            [12]  855 	mov	r7,#0x01
      003EF3                        856 00132$:
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EF3 12 43 49         [24]  858 	lcall	_ak820_outline_0041
      003EF6 FE               [12]  859 	mov	r6,a
      003EF7 60 22            [24]  860 	jz	00133$
      003EF9 8F 05            [24]  861 	mov	ar5,r7
      003EFB 7C 00            [12]  862 	mov	r4,#0x00
      003EFD 74 40            [12]  863 	mov	a,#0x40
      003EFF 2D               [12]  864 	add	a, r5
      003F00 FD               [12]  865 	mov	r5,a
      003F01 74 EF            [12]  866 	mov	a,#0xef
      003F03 3C               [12]  867 	addc	a, r4
      003F04 FC               [12]  868 	mov	r4,a
      003F05 90 04 F2         [24]  869 	mov	dptr,#_ak820_flash_program_PARM_2
      003F08 EE               [12]  870 	mov	a,r6
      003F09 F0               [24]  871 	movx	@dptr,a
      003F0A 12 43 C5         [24]  872 	lcall	_ak820_outline_0186
      003F0D C0 07            [24]  873 	push	ar7
      003F0F 12 3A 1D         [24]  874 	lcall	_ak820_flash_program
      003F12 E5 82            [12]  875 	mov	a, dpl
      003F14 D0 07            [24]  876 	pop	ar7
      003F16 70 03            [24]  877 	jnz	00275$
      003F18 02 3F A2         [24]  878 	ljmp	00127$
      003F1B                        879 00275$:
      003F1B                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F1B 0F               [12]  882 	inc	r7
      003F1C BF 09 D4         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F1F 90 05 7A         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F22 74 09            [12]  886 	mov	a,#0x09
      003F24 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F25 7F 01            [12]  889 	mov	r7,#0x01
      003F27                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F27 12 43 55         [24]  892 	lcall	_ak820_outline_0052
      003F2A 12 38 B0         [24]  893 	lcall	_ak820_flash_read
      003F2D AE 82            [24]  894 	mov	r6, dpl
      003F2F 12 43 49         [24]  895 	lcall	_ak820_outline_0041
      003F32 FD               [12]  896 	mov	r5,a
      003F33 EE               [12]  897 	mov	a,r6
      003F34 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F37 0F               [12]  900 	inc	r7
      003F38 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F3B 90 05 7A         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F3E 74 0A            [12]  904 	mov	a,#0x0a
      003F40 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F41 90 05 71         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F44 E0               [24]  908 	movx	a,@dptr
      003F45 90 04 F2         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      003F48 F0               [24]  910 	movx	@dptr,a
      003F49 90 EF 40         [24]  911 	mov	dptr,#0xef40
      003F4C 12 3A 1D         [24]  912 	lcall	_ak820_flash_program
      003F4F E5 82            [12]  913 	mov	a, dpl
      003F51 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F53 90 05 7A         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F56 74 0B            [12]  917 	mov	a,#0x0b
      003F58 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F59 90 EF 40         [24]  920 	mov	dptr,#0xef40
      003F5C 12 38 B0         [24]  921 	lcall	_ak820_flash_read
      003F5F AF 82            [24]  922 	mov	r7, dpl
      003F61 90 05 71         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F64 E0               [24]  924 	movx	a,@dptr
      003F65 FE               [12]  925 	mov	r6,a
      003F66 EF               [12]  926 	mov	a,r7
      003F67 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F6A 90 05 7A         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F6D 74 0C            [12]  930 	mov	a,#0x0c
      003F6F F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F70 90 05 59         [24]  933 	mov	dptr,#_cached_page
      003F73 E0               [24]  934 	movx	a,@dptr
      003F74 FE               [12]  935 	mov	r6,a
      003F75 E4               [12]  936 	clr	a
      003F76 C3               [12]  937 	clr	c
      003F77 CE               [12]  938 	xch	a,r6
      003F78 13               [12]  939 	rrc	a
      003F79 CE               [12]  940 	xch	a,r6
      003F7A 13               [12]  941 	rrc	a
      003F7B A2 E0            [12]  942 	mov	c,acc.0
      003F7D CE               [12]  943 	xch	a,r6
      003F7E 13               [12]  944 	rrc	a
      003F7F CE               [12]  945 	xch	a,r6
      003F80 13               [12]  946 	rrc	a
      003F81 CE               [12]  947 	xch	a,r6
      003F82 24 C7            [12]  948 	add	a,#0xc7
      003F84 FF               [12]  949 	mov	r7,a
      003F85 12 43 84         [24]  950 	lcall	_ak820_outline_0117
      003F88 12 3C 93         [24]  951 	lcall	_write_page
      003F8B E5 82            [12]  952 	mov	a, dpl
      003F8D 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F8F 90 05 7A         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F92 74 0D            [12]  956 	mov	a,#0x0d
      003F94 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F95 90 EF 40         [24]  959 	mov	dptr,#0xef40
      003F98 12 39 BD         [24]  960 	lcall	_ak820_flash_erase
      003F9B E5 82            [12]  961 	mov	a, dpl
      003F9D 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      003F9F C2 08            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003FA1 22               [24]  968 	ret
      003FA2                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FA2 90 05 7A         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FA5 E0               [24]  972 	movx	a,@dptr
      003FA6 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FA8 02 3B B2         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      003FAB                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FAB 90 05 5A         [24]  985 	mov	dptr,#_batch_depth
      003FAE E0               [24]  986 	movx	a,@dptr
      003FAF FF               [12]  987 	mov	r7,a
      003FB0 BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      003FB3 75 82 0F         [24]  989 	mov	dpl, #0x0f
      003FB6 02 3B B2         [24]  990 	ljmp	_nvm_fail
      003FB9                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FB9 90 05 5A         [24]  993 	mov	dptr,#_batch_depth
      003FBC EF               [12]  994 	mov	a,r7
      003FBD 04               [12]  995 	inc	a
      003FBE F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FBF 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      003FC0                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FC0 90 05 5A         [24] 1008 	mov	dptr,#_batch_depth
      003FC3 E0               [24] 1009 	movx	a,@dptr
      003FC4 FF               [12] 1010 	mov	r7,a
      003FC5 E0               [24] 1011 	movx	a,@dptr
      003FC6 60 06            [24] 1012 	jz	00102$
      003FC8 EF               [12] 1013 	mov	a,r7
      003FC9 14               [12] 1014 	dec	a
      003FCA 90 05 5A         [24] 1015 	mov	dptr,#_batch_depth
      003FCD F0               [24] 1016 	movx	@dptr,a
      003FCE                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FCE 90 05 5A         [24] 1019 	mov	dptr,#_batch_depth
      003FD1 E0               [24] 1020 	movx	a,@dptr
      003FD2 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FD4 02 3E 59         [24] 1023 	ljmp	_ak820_nvm_flush
      003FD7                       1024 00105$:
      003FD7 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      003FD8                       1036 _load_page:
      003FD8 E5 82            [12] 1037 	mov	a,dpl
      003FDA 90 05 7B         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      003FDD F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FDE 30 07 17         [24] 1041 	jnb	_page_valid,00102$
      003FE1 90 05 59         [24] 1042 	mov	dptr,#_cached_page
      003FE4 E0               [24] 1043 	movx	a,@dptr
      003FE5 FF               [12] 1044 	mov	r7,a
      003FE6 90 05 7B         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      003FE9 E0               [24] 1046 	movx	a,@dptr
      003FEA FE               [12] 1047 	mov	r6,a
      003FEB EF               [12] 1048 	mov	a,r7
      003FEC B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      003FEF A2 09            [12] 1050 	mov	c,_storage_failed
      003FF1 B3               [12] 1051 	cpl	c
      003FF2 92 0B            [24] 1052 	mov  _load_page_sloc0_1_0,c
      003FF4 12 38 7D         [24] 1053 	lcall	_ak820_outline_0166
      003FF7 22               [24] 1054 	ret
      003FF8                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FF8 12 3E 59         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FFB 30 09 04         [24] 1059 	jnb	_storage_failed,00119$
      003FFE 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004001 22               [24] 1062 	ret
      004002                       1063 00119$:
      004002 7F 00            [12] 1064 	mov	r7,#0x00
      004004                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004004 EF               [12] 1067 	mov	a,r7
      004005 24 19            [12] 1068 	add	a, #_page_data
      004007 FD               [12] 1069 	mov	r5,a
      004008 E4               [12] 1070 	clr	a
      004009 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      00400B FE               [12] 1072 	mov	r6,a
      00400C 90 05 7B         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00400F E0               [24] 1074 	movx	a,@dptr
      004010 FC               [12] 1075 	mov	r4,a
      004011 FA               [12] 1076 	mov	r2,a
      004012 E4               [12] 1077 	clr	a
      004013 C3               [12] 1078 	clr	c
      004014 CA               [12] 1079 	xch	a,r2
      004015 13               [12] 1080 	rrc	a
      004016 CA               [12] 1081 	xch	a,r2
      004017 13               [12] 1082 	rrc	a
      004018 A2 E0            [12] 1083 	mov	c,acc.0
      00401A CA               [12] 1084 	xch	a,r2
      00401B 13               [12] 1085 	rrc	a
      00401C CA               [12] 1086 	xch	a,r2
      00401D 13               [12] 1087 	rrc	a
      00401E CA               [12] 1088 	xch	a,r2
      00401F 24 C7            [12] 1089 	add	a,#0xc7
      004021 FB               [12] 1090 	mov	r3,a
      004022 8F 01            [24] 1091 	mov	ar1,r7
      004024 89 00            [24] 1092 	mov	ar0,r1
      004026 79 00            [12] 1093 	mov	r1,#0x00
      004028 E8               [12] 1094 	mov	a,r0
      004029 2A               [12] 1095 	add	a, r2
      00402A FA               [12] 1096 	mov	r2,a
      00402B E9               [12] 1097 	mov	a,r1
      00402C 3B               [12] 1098 	addc	a, r3
      00402D FB               [12] 1099 	mov	r3,a
      00402E 12 43 A0         [24] 1100 	lcall	_ak820_outline_0140
      004031 12 38 B0         [24] 1101 	lcall	_ak820_flash_read
      004034 AB 82            [24] 1102 	mov	r3, dpl
      004036 12 38 61         [24] 1103 	lcall	_ak820_outline_0131
      004039 EB               [12] 1104 	mov	a,r3
      00403A F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00403B 0F               [12] 1107 	inc	r7
      00403C BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00403F 90 05 59         [24] 1110 	mov	dptr,#_cached_page
      004042 EC               [12] 1111 	mov	a,r4
      004043 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004044 D2 07            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004046 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004049 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      00404A                       1129 _read_offset:
      00404A 12 38 40         [24] 1130 	lcall	_ak820_outline_0104
      00404D 90 05 7C         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      004050 12 38 45         [24] 1132 	lcall	_ak820_outline_0105
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004053 90 05 7C         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004056 12 37 F7         [24] 1135 	lcall	_ak820_outline_0051
      004059 C3               [12] 1136 	clr	c
      00405A 94 28            [12] 1137 	subb	a,#0x28
      00405C 40 04            [24] 1138 	jc	00102$
      00405E 75 82 00         [24] 1139 	mov	dpl, #0x00
      004061 22               [24] 1140 	ret
      004062                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004062 30 07 34         [24] 1143 	jnb	_page_valid,00104$
      004065 8E 04            [24] 1144 	mov	ar4,r6
      004067 EF               [12] 1145 	mov	a,r7
      004068 A2 E7            [12] 1146 	mov	c,acc.7
      00406A CC               [12] 1147 	xch	a,r4
      00406B 33               [12] 1148 	rlc	a
      00406C CC               [12] 1149 	xch	a,r4
      00406D 33               [12] 1150 	rlc	a
      00406E A2 E7            [12] 1151 	mov	c,acc.7
      004070 CC               [12] 1152 	xch	a,r4
      004071 33               [12] 1153 	rlc	a
      004072 CC               [12] 1154 	xch	a,r4
      004073 33               [12] 1155 	rlc	a
      004074 CC               [12] 1156 	xch	a,r4
      004075 54 03            [12] 1157 	anl	a,#0x03
      004077 FD               [12] 1158 	mov	r5,a
      004078 90 05 59         [24] 1159 	mov	dptr,#_cached_page
      00407B E0               [24] 1160 	movx	a,@dptr
      00407C FA               [12] 1161 	mov	r2,a
      00407D 7B 00            [12] 1162 	mov	r3,#0x00
      00407F EC               [12] 1163 	mov	a,r4
      004080 B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      004083 ED               [12] 1165 	mov	a,r5
      004084 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004087 74 3F            [12] 1168 	mov	a,#0x3f
      004089 5E               [12] 1169 	anl	a,r6
      00408A 7D 00            [12] 1170 	mov	r5,#0x00
      00408C 24 19            [12] 1171 	add	a, #_page_data
      00408E F5 82            [12] 1172 	mov	dpl,a
      004090 ED               [12] 1173 	mov	a,r5
      004091 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      004093 F5 83            [12] 1175 	mov	dph,a
      004095 E0               [24] 1176 	movx	a,@dptr
      004096 F5 82            [12] 1177 	mov	dpl,a
      004098 22               [24] 1178 	ret
      004099                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004099 74 C7            [12] 1181 	mov	a,#0xc7
      00409B 2F               [12] 1182 	add	a, r7
      00409C FF               [12] 1183 	mov	r7,a
      00409D 12 43 84         [24] 1184 	lcall	_ak820_outline_0117
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0040A0 02 38 B0         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0040A3                       1196 _eeprom_read_byte:
      0040A3 C0 07            [24] 1197 	push	ar7
      0040A5 C0 06            [24] 1198 	push	ar6
      0040A7 12 43 42         [24] 1199 	lcall	_ak820_outline_0037
      0040AA 90 05 7E         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040AD 12 37 D6         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040B0 90 05 7E         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040B3 12 37 97         [24] 1204 	lcall	_ak820_outline_0004
      0040B6 C0 06            [24] 1205 	push	ar6
      0040B8 C0 05            [24] 1206 	push	ar5
      0040BA C0 04            [24] 1207 	push	ar4
      0040BC C0 03            [24] 1208 	push	ar3
      0040BE C0 02            [24] 1209 	push	ar2
      0040C0 C0 01            [24] 1210 	push	ar1
      0040C2 C0 00            [24] 1211 	push	ar0
      0040C4 12 40 4A         [24] 1212 	lcall	_read_offset
      0040C7 AF 82            [24] 1213 	mov	r7, dpl
      0040C9 D0 00            [24] 1214 	pop	ar0
      0040CB D0 01            [24] 1215 	pop	ar1
      0040CD D0 02            [24] 1216 	pop	ar2
      0040CF D0 03            [24] 1217 	pop	ar3
      0040D1 D0 04            [24] 1218 	pop	ar4
      0040D3 D0 05            [24] 1219 	pop	ar5
      0040D5 D0 06            [24] 1220 	pop	ar6
      0040D7 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040D9 D0 06            [24] 1223 	pop	ar6
      0040DB D0 07            [24] 1224 	pop	ar7
      0040DD 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0040DE                       1239 _ak820_eeprom_read_block_xdata:
      0040DE 12 38 40         [24] 1240 	lcall	_ak820_outline_0104
      0040E1 90 05 86         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040E4 12 38 45         [24] 1242 	lcall	_ak820_outline_0105
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040E7 90 05 81         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040EA 12 37 F7         [24] 1245 	lcall	_ak820_outline_0051
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040ED 90 05 86         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040F0 12 38 16         [24] 1248 	lcall	_ak820_outline_0060
      0040F3 90 05 88         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F6 12 38 1C         [24] 1250 	lcall	_ak820_outline_0071
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040F9 90 05 84         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040FC 12 38 16         [24] 1253 	lcall	_ak820_outline_0060
      0040FF                       1254 00103$:
      0040FF 8C 02            [24] 1255 	mov	ar2,r4
      004101 8D 03            [24] 1256 	mov	ar3,r5
      004103 1C               [12] 1257 	dec	r4
      004104 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004107 1D               [12] 1259 	dec	r5
      004108                       1260 00130$:
      004108 EA               [12] 1261 	mov	a,r2
      004109 4B               [12] 1262 	orl	a,r3
      00410A 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00410C 8E 02            [24] 1265 	mov	ar2,r6
      00410E 8F 03            [24] 1266 	mov	ar3,r7
      004110 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004112 2B               [12] 1268 	add	a,r3
      004113 50 17            [24] 1269 	jnc	00102$
      004115 90 05 88         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004118 12 43 89         [24] 1271 	lcall	_ak820_outline_0120
      00411B 12 43 A0         [24] 1272 	lcall	_ak820_outline_0140
      00411E E4               [12] 1273 	clr	a
      00411F F0               [24] 1274 	movx	@dptr,a
      004120 90 05 88         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004123 04               [12] 1276 	inc	a
      004124 2A               [12] 1277 	add	a, r2
      004125 F0               [24] 1278 	movx	@dptr,a
      004126 E4               [12] 1279 	clr	a
      004127 3B               [12] 1280 	addc	a, r3
      004128 A3               [24] 1281 	inc	dptr
      004129 F0               [24] 1282 	movx	@dptr,a
      00412A 80 D3            [24] 1283 	sjmp	00103$
      00412C                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00412C 90 05 88         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00412F 12 43 89         [24] 1287 	lcall	_ak820_outline_0120
      004132 12 43 84         [24] 1288 	lcall	_ak820_outline_0117
      004135 C0 07            [24] 1289 	push	ar7
      004137 C0 06            [24] 1290 	push	ar6
      004139 C0 05            [24] 1291 	push	ar5
      00413B C0 04            [24] 1292 	push	ar4
      00413D C0 03            [24] 1293 	push	ar3
      00413F C0 02            [24] 1294 	push	ar2
      004141 12 40 4A         [24] 1295 	lcall	_read_offset
      004144 A9 82            [24] 1296 	mov	r1, dpl
      004146 D0 02            [24] 1297 	pop	ar2
      004148 D0 03            [24] 1298 	pop	ar3
      00414A D0 04            [24] 1299 	pop	ar4
      00414C D0 05            [24] 1300 	pop	ar5
      00414E D0 06            [24] 1301 	pop	ar6
      004150 D0 07            [24] 1302 	pop	ar7
      004152 12 43 A0         [24] 1303 	lcall	_ak820_outline_0140
      004155 E9               [12] 1304 	mov	a,r1
      004156 F0               [24] 1305 	movx	@dptr,a
      004157 90 05 88         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00415A 74 01            [12] 1307 	mov	a,#0x01
      00415C 2A               [12] 1308 	add	a, r2
      00415D F0               [24] 1309 	movx	@dptr,a
      00415E E4               [12] 1310 	clr	a
      00415F 3B               [12] 1311 	addc	a, r3
      004160 A3               [24] 1312 	inc	dptr
      004161 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004162 0E               [12] 1315 	inc	r6
      004163 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      004166 0F               [12] 1317 	inc	r7
      004167 80 96            [24] 1318 	sjmp	00103$
      004169                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004169 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      00416A                       1337 _ak820_eeprom_write_block_xdata:
      00416A 12 38 40         [24] 1338 	lcall	_ak820_outline_0104
      00416D 90 05 8F         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004170 12 38 45         [24] 1340 	lcall	_ak820_outline_0105
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004173 90 05 8A         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004176 12 37 F7         [24] 1343 	lcall	_ak820_outline_0051
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004179 90 05 8F         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00417C 12 38 16         [24] 1346 	lcall	_ak820_outline_0060
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00417F 8E 02            [24] 1348 	mov	ar2,r6
      004181 8F 03            [24] 1349 	mov	ar3,r7
      004183 C3               [12] 1350 	clr	c
      004184 E4               [12] 1351 	clr	a
      004185 9A               [12] 1352 	subb	a,r2
      004186 74 28            [12] 1353 	mov	a,#0x28
      004188 9B               [12] 1354 	subb	a,r3
      004189 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      00418B E4               [12] 1357 	clr	a
      00418C C3               [12] 1358 	clr	c
      00418D 9E               [12] 1359 	subb	a,r6
      00418E FA               [12] 1360 	mov	r2,a
      00418F 74 28            [12] 1361 	mov	a,#0x28
      004191 9F               [12] 1362 	subb	a,r7
      004192 FB               [12] 1363 	mov	r3,a
      004193 90 05 8D         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004196 12 38 34         [24] 1365 	lcall	_ak820_outline_0100
      004199 C3               [12] 1366 	clr	c
      00419A EA               [12] 1367 	mov	a,r2
      00419B 98               [12] 1368 	subb	a,r0
      00419C EB               [12] 1369 	mov	a,r3
      00419D 99               [12] 1370 	subb	a,r1
      00419E 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0041A0                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0041A0 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041A3 02 3B B2         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041A6                       1379 00125$:
      0041A6 90 05 8D         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041A9 12 43 89         [24] 1381 	lcall	_ak820_outline_0120
      0041AC                       1382 00108$:
      0041AC 8A 00            [24] 1383 	mov	ar0,r2
      0041AE 8B 01            [24] 1384 	mov	ar1,r3
      0041B0 1A               [12] 1385 	dec	r2
      0041B1 BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      0041B4 1B               [12] 1387 	dec	r3
      0041B5                       1388 00159$:
      0041B5 E8               [12] 1389 	mov	a,r0
      0041B6 49               [12] 1390 	orl	a,r1
      0041B7 70 03            [24] 1391 	jnz	00160$
      0041B9 02 42 43         [24] 1392 	ljmp	00110$
      0041BC                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041BC C0 02            [24] 1395 	push	ar2
      0041BE C0 03            [24] 1396 	push	ar3
      0041C0 12 43 6C         [24] 1397 	lcall	_ak820_outline_0092
      0041C3 F9               [12] 1398 	mov	r1,a
      0041C4 A3               [24] 1399 	inc	dptr
      0041C5 12 43 A5         [24] 1400 	lcall	_ak820_outline_0145
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0041C8 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0041CA 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0041CC A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041CE E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041D0 A2 E7            [12] 1406 	mov	c,acc.7
      0041D2 C8               [12] 1407 	xch	a,r0
      0041D3 33               [12] 1408 	rlc	a
      0041D4 C8               [12] 1409 	xch	a,r0
      0041D5 33               [12] 1410 	rlc	a
      0041D6 A2 E7            [12] 1411 	mov	c,acc.7
      0041D8 C8               [12] 1412 	xch	a,r0
      0041D9 33               [12] 1413 	rlc	a
      0041DA C8               [12] 1414 	xch	a,r0
      0041DB 33               [12] 1415 	rlc	a
      0041DC C8               [12] 1416 	xch	a,r0
      0041DD 54 03            [12] 1417 	anl	a,#0x03
      0041DF FB               [12] 1418 	mov	r3,a
      0041E0 88 82            [24] 1419 	mov	dpl, r0
      0041E2 C0 07            [24] 1420 	push	ar7
      0041E4 C0 06            [24] 1421 	push	ar6
      0041E6 C0 05            [24] 1422 	push	ar5
      0041E8 C0 04            [24] 1423 	push	ar4
      0041EA C0 03            [24] 1424 	push	ar3
      0041EC C0 02            [24] 1425 	push	ar2
      0041EE C0 01            [24] 1426 	push	ar1
      0041F0 12 3F D8         [24] 1427 	lcall	_load_page
      0041F3 E5 82            [12] 1428 	mov	a, dpl
      0041F5 D0 01            [24] 1429 	pop	ar1
      0041F7 D0 02            [24] 1430 	pop	ar2
      0041F9 D0 03            [24] 1431 	pop	ar3
      0041FB D0 04            [24] 1432 	pop	ar4
      0041FD D0 05            [24] 1433 	pop	ar5
      0041FF D0 06            [24] 1434 	pop	ar6
      004201 D0 07            [24] 1435 	pop	ar7
      004203 D0 03            [24] 1436 	pop	ar3
      004205 D0 02            [24] 1437 	pop	ar2
      004207 70 01            [24] 1438 	jnz	00105$
      004209 22               [24] 1439 	ret
      00420A                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00420A C0 06            [24] 1442 	push	ar6
      00420C C0 07            [24] 1443 	push	ar7
      00420E 74 3F            [12] 1444 	mov	a,#0x3f
      004210 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004212 7F 00            [12] 1446 	mov	r7,#0x00
      004214 24 19            [12] 1447 	add	a, #_page_data
      004216 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004218 EF               [12] 1449 	mov	a,r7
      004219 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      00421B F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00421D 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004220 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004223 E0               [24] 1454 	movx	a,@dptr
      004224 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004227 D0 07            [24] 1456 	pop	ar7
      004229 D0 06            [24] 1457 	pop	ar6
      00422B 80 0E            [24] 1458 	sjmp	00107$
      00422D                       1459 00162$:
      00422D D0 07            [24] 1460 	pop	ar7
      00422F D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004231 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004234 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004237 E9               [12] 1465 	mov	a,r1
      004238 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004239 D2 08            [12] 1469 	setb	_page_dirty
      00423B                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00423B 0E               [12] 1472 	inc	r6
      00423C BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00423F 0F               [12] 1474 	inc	r7
      004240                       1475 00163$:
      004240 02 41 AC         [24] 1476 	ljmp	00108$
      004243                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004243 90 05 5A         [24] 1479 	mov	dptr,#_batch_depth
      004246 E0               [24] 1480 	movx	a,@dptr
      004247 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004249 02 3E 59         [24] 1483 	ljmp	_ak820_nvm_flush
      00424C                       1484 00113$:
      00424C 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      00424D                       1503 _ak820_eeprom_update_block_xdata:
      00424D 12 38 40         [24] 1504 	lcall	_ak820_outline_0104
      004250 90 05 96         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004253 12 38 45         [24] 1506 	lcall	_ak820_outline_0105
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004256 90 05 96         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004259 12 37 F7         [24] 1509 	lcall	_ak820_outline_0051
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00425C 90 05 91         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00425F E0               [24] 1512 	movx	a,@dptr
      004260 F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004262 A3               [24] 1514 	inc	dptr
      004263 E0               [24] 1515 	movx	a,@dptr
      004264 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004266 A3               [24] 1517 	inc	dptr
      004267 E0               [24] 1518 	movx	a,@dptr
      004268 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      00426A A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00426C AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00426E E4               [12] 1523 	clr	a
      00426F F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004271 F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004273                       1526 00105$:
      004273 90 05 94         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004276 E0               [24] 1528 	movx	a,@dptr
      004277 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004279 A3               [24] 1530 	inc	dptr
      00427A E0               [24] 1531 	movx	a,@dptr
      00427B F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00427D C3               [12] 1533 	clr	c
      00427E E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004280 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004282 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004284 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004286 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004288 89 00            [24] 1540 	mov	ar0,r1
      00428A 8A 05            [24] 1541 	mov	ar5,r2
      00428C E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00428E 28               [12] 1543 	add	a, r0
      00428F F8               [12] 1544 	mov	r0,a
      004290 E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004292 3D               [12] 1546 	addc	a, r5
      004293 FD               [12] 1547 	mov	r5,a
      004294 88 82            [24] 1548 	mov	dpl, r0
      004296 8D 83            [24] 1549 	mov	dph, r5
      004298 C0 07            [24] 1550 	push	ar7
      00429A C0 06            [24] 1551 	push	ar6
      00429C C0 02            [24] 1552 	push	ar2
      00429E C0 01            [24] 1553 	push	ar1
      0042A0 12 40 4A         [24] 1554 	lcall	_read_offset
      0042A3 AD 82            [24] 1555 	mov	r5, dpl
      0042A5 D0 01            [24] 1556 	pop	ar1
      0042A7 D0 02            [24] 1557 	pop	ar2
      0042A9 D0 06            [24] 1558 	pop	ar6
      0042AB D0 07            [24] 1559 	pop	ar7
      0042AD E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042AF 2E               [12] 1561 	add	a, r6
      0042B0 F5 82            [12] 1562 	mov	dpl,a
      0042B2 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042B4 3F               [12] 1564 	addc	a, r7
      0042B5 F5 83            [12] 1565 	mov	dph,a
      0042B7 E0               [24] 1566 	movx	a,@dptr
      0042B8 FC               [12] 1567 	mov	r4,a
      0042B9 ED               [12] 1568 	mov	a,r5
      0042BA B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      0042BD 80 27            [24] 1570 	sjmp	00106$
      0042BF                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042BF 90 05 96         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042C2 E0               [24] 1574 	movx	a,@dptr
      0042C3 F8               [12] 1575 	mov	r0,a
      0042C4 A3               [24] 1576 	inc	dptr
      0042C5 E0               [24] 1577 	movx	a,@dptr
      0042C6 FD               [12] 1578 	mov	r5,a
      0042C7 90 05 8A         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0042CA E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042CC F0               [24] 1581 	movx	@dptr,a
      0042CD E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042CF A3               [24] 1583 	inc	dptr
      0042D0 F0               [24] 1584 	movx	@dptr,a
      0042D1 E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042D3 A3               [24] 1586 	inc	dptr
      0042D4 F0               [24] 1587 	movx	@dptr,a
      0042D5 90 05 8D         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042D8 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042DA F0               [24] 1590 	movx	@dptr,a
      0042DB E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042DD A3               [24] 1592 	inc	dptr
      0042DE F0               [24] 1593 	movx	@dptr,a
      0042DF 88 82            [24] 1594 	mov	dpl, r0
      0042E1 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042E3 02 41 6A         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      0042E6                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042E6 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042E8 E4               [12] 1601 	clr	a
      0042E9 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042EC 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042EE 80 83            [24] 1604 	sjmp	00105$
      0042F0                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042F0 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      0042F1                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042F1 12 3E 59         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042F4 7F 00            [12] 1622 	mov	r7,#0x00
      0042F6                       1623 00111$:
      0042F6 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      0042F9 22               [24] 1625 	ret
      0042FA                       1626 00165$:
      0042FA 20 09 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042FD 8F 82            [24] 1629 	mov	dpl, r7
      0042FF C0 07            [24] 1630 	push	ar7
      004301 12 3F D8         [24] 1631 	lcall	_load_page
      004304 E5 82            [12] 1632 	mov	a, dpl
      004306 D0 07            [24] 1633 	pop	ar7
      004308 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00430A 22               [24] 1636 	ret
      00430B                       1637 00126$:
      00430B 7E 00            [12] 1638 	mov	r6,#0x00
      00430D                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00430D EE               [12] 1641 	mov	a,r6
      00430E 24 19            [12] 1642 	add	a, #_page_data
      004310 FC               [12] 1643 	mov	r4,a
      004311 E4               [12] 1644 	clr	a
      004312 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004314 FD               [12] 1646 	mov	r5,a
      004315 12 43 6C         [24] 1647 	lcall	_ak820_outline_0092
      004318 60 07            [24] 1648 	jz	00108$
      00431A 12 38 57         [24] 1649 	lcall	_ak820_outline_0121
      00431D E4               [12] 1650 	clr	a
      00431E F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      00431F D2 08            [12] 1653 	setb	_page_dirty
      004321                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004321 0E               [12] 1656 	inc	r6
      004322 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004325 C0 07            [24] 1659 	push	ar7
      004327 12 3E 59         [24] 1660 	lcall	_ak820_nvm_flush
      00432A D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00432C 0F               [12] 1663 	inc	r7
      00432D 80 C7            [24] 1664 	sjmp	00111$
      00432F                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00432F 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0004
                                   1675 	.globl _ak820_outline_0010
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0017
                                   1678 	.globl _ak820_outline_0030
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0041
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0052
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0061
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0092
                                   1688 	.globl _ak820_outline_0097
                                   1689 	.globl _ak820_outline_0100
                                   1690 	.globl _ak820_outline_0101
                                   1691 	.globl _ak820_outline_0102
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0105
                                   1694 	.globl _ak820_outline_0117
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0131
                                   1699 	.globl _ak820_outline_0132
                                   1700 	.globl _ak820_outline_0134
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0140
                                   1703 	.globl _ak820_outline_0145
                                   1704 	.globl _ak820_outline_0153
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0181
                                   1709 	.globl _ak820_outline_0182
                                   1710 	.globl _ak820_outline_0186
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0010
      004330                       1714 _ak820_outline_0010:
      004330 8E 82            [24] 1715 	mov	dpl,r6
      004332 8F 83            [24] 1716 	mov	dph,r7
      004334 A3               [24] 1717 	inc	dptr
      004335 A3               [24] 1718 	inc	dptr
      004336 A3               [24] 1719 	inc	dptr
      004337 A3               [24] 1720 	inc	dptr
      004338 A3               [24] 1721 	inc	dptr
      004339 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0030
      00433A                       1726 _ak820_outline_0030:
      00433A F0               [24] 1727 	movx	@dptr,a
      00433B 8E 82            [24] 1728 	mov	dpl,r6
      00433D 8F 83            [24] 1729 	mov	dph,r7
      00433F A3               [24] 1730 	inc	dptr
      004340 A3               [24] 1731 	inc	dptr
      004341 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0037
      004342                       1736 _ak820_outline_0037:
      004342 AF F0            [24] 1737 	mov	r7,b
      004344 AE 83            [24] 1738 	mov	r6,dph
      004346 E5 82            [12] 1739 	mov	a,dpl
      004348 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0041
      004349                       1744 _ak820_outline_0041:
      004349 EF               [12] 1745 	mov	a,r7
      00434A 24 71            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      00434C F5 82            [12] 1747 	mov	dpl,a
      00434E E4               [12] 1748 	clr	a
      00434F 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004351 F5 83            [12] 1750 	mov	dph,a
      004353 E0               [24] 1751 	movx	a,@dptr
      004354 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0052
      004355                       1756 _ak820_outline_0052:
      004355 8F 06            [24] 1757 	mov	ar6,r7
      004357 7D 00            [12] 1758 	mov	r5,#0x00
      004359 74 40            [12] 1759 	mov	a,#0x40
      00435B 2E               [12] 1760 	add	a,r6
      00435C FE               [12] 1761 	mov	r6,a
      00435D 74 EF            [12] 1762 	mov	a,#0xef
      00435F 3D               [12] 1763 	addc	a,r5
      004360 FD               [12] 1764 	mov	r5,a
      004361 8E 82            [24] 1765 	mov	dpl,r6
      004363 8D 83            [24] 1766 	mov	dph,r5
      004365 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0061
      004366                       1771 _ak820_outline_0061:
      004366 F0               [24] 1772 	movx	@dptr,a
      004367 8E 82            [24] 1773 	mov	dpl,r6
      004369 8F 83            [24] 1774 	mov	dph,r7
      00436B 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0092
      00436C                       1779 _ak820_outline_0092:
      00436C 8C 82            [24] 1780 	mov	dpl,r4
      00436E 8D 83            [24] 1781 	mov	dph,r5
      004370 E0               [24] 1782 	movx	a,@dptr
      004371 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0097
      004372                       1787 _ak820_outline_0097:
      004372 E0               [24] 1788 	movx	a,@dptr
      004373 FD               [12] 1789 	mov	r5,a
      004374 A3               [24] 1790 	inc	dptr
      004375 E0               [24] 1791 	movx	a,@dptr
      004376 FE               [12] 1792 	mov	r6,a
      004377 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0102
      004378                       1797 _ak820_outline_0102:
      004378 EF               [12] 1798 	mov	a,r7
      004379 24 19            [12] 1799 	add	a,#_page_data
      00437B F5 82            [12] 1800 	mov	dpl,a
      00437D E4               [12] 1801 	clr	a
      00437E 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      004380 F5 83            [12] 1803 	mov	dph,a
      004382 E0               [24] 1804 	movx	a,@dptr
      004383 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0117
      004384                       1809 _ak820_outline_0117:
      004384 8E 82            [24] 1810 	mov	dpl,r6
      004386 8F 83            [24] 1811 	mov	dph,r7
      004388 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0120
      004389                       1816 _ak820_outline_0120:
      004389 E0               [24] 1817 	movx	a,@dptr
      00438A FA               [12] 1818 	mov	r2,a
      00438B A3               [24] 1819 	inc	dptr
      00438C E0               [24] 1820 	movx	a,@dptr
      00438D FB               [12] 1821 	mov	r3,a
      00438E 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0132
      00438F                       1826 _ak820_outline_0132:
      00438F AE 82            [24] 1827 	mov	r6,dpl
      004391 AF 83            [24] 1828 	mov	r7,dph
      004393 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0134
      004394                       1833 _ak820_outline_0134:
      004394 2E               [12] 1834 	add	a,r6
      004395 FE               [12] 1835 	mov	r6,a
      004396 E4               [12] 1836 	clr	a
      004397 3F               [12] 1837 	addc	a,r7
      004398 FF               [12] 1838 	mov	r7,a
      004399 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0139
      00439A                       1843 _ak820_outline_0139:
      00439A 42 05            [12] 1844 	orl	ar5,a
      00439C EA               [12] 1845 	mov	a,r2
      00439D 42 04            [12] 1846 	orl	ar4,a
      00439F 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0140
      0043A0                       1851 _ak820_outline_0140:
      0043A0 8A 82            [24] 1852 	mov	dpl,r2
      0043A2 8B 83            [24] 1853 	mov	dph,r3
      0043A4 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0145
      0043A5                       1858 _ak820_outline_0145:
      0043A5 AC 82            [24] 1859 	mov	r4,dpl
      0043A7 AD 83            [24] 1860 	mov	r5,dph
      0043A9 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0153
      0043AA                       1865 _ak820_outline_0153:
      0043AA 8F 82            [24] 1866 	mov	dpl,r7
      0043AC 8E 83            [24] 1867 	mov	dph,r6
      0043AE 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0156
      0043AF                       1872 _ak820_outline_0156:
      0043AF 2E               [12] 1873 	add	a,r6
      0043B0 FC               [12] 1874 	mov	r4,a
      0043B1 E4               [12] 1875 	clr	a
      0043B2 3F               [12] 1876 	addc	a,r7
      0043B3 FD               [12] 1877 	mov	r5,a
      0043B4 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0157
      0043B5                       1882 _ak820_outline_0157:
      0043B5 ED               [12] 1883 	mov	a,r5
      0043B6 F0               [24] 1884 	movx	@dptr,a
      0043B7 EE               [12] 1885 	mov	a,r6
      0043B8 A3               [24] 1886 	inc	dptr
      0043B9 F0               [24] 1887 	movx	@dptr,a
      0043BA 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0181
      0043BB                       1892 _ak820_outline_0181:
      0043BB 89 82            [24] 1893 	mov	dpl,r1
      0043BD 8A 83            [24] 1894 	mov	dph,r2
      0043BF 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0182
      0043C0                       1899 _ak820_outline_0182:
      0043C0 8C 82            [24] 1900 	mov	dpl,r4
      0043C2 8B 83            [24] 1901 	mov	dph,r3
      0043C4 22               [24] 1902 	ret
                                   1903 
                                   1904 	.area CSEG (CODE)
                                   1905 ; function ak820_outline_0186
      0043C5                       1906 _ak820_outline_0186:
      0043C5 8D 82            [24] 1907 	mov	dpl,r5
      0043C7 8C 83            [24] 1908 	mov	dph,r4
      0043C9 22               [24] 1909 	ret
