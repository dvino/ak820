                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000026                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000026                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ADA                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ADA                        628 	.ds 1
      000ADB                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ADB                        630 	.ds 1
      000ADC                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000ADC                        632 	.ds 1
      000ADD                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ADD                        634 	.ds 1
      000ADE                        635 _dynamic_keymap_get_keycode_PARM_3:
      000ADE                        636 	.ds 1
      000ADF                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000ADF                        638 	.ds 1
      000AE0                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AE0                        640 	.ds 1
      000AE1                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AE1                        642 	.ds 1
      000AE2                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AE2                        644 	.ds 2
      000AE4                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000AE4                        646 	.ds 1
      000AE5                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AE5                        648 	.ds 1
      000AE6                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000AE6                        650 	.ds 1
      000AE7                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE7                        652 	.ds 1
      000AE8                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AE8                        654 	.ds 1
      000AE9                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AE9                        656 	.ds 1
      000AEA                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AEA                        658 	.ds 1
      000AEB                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AEB                        660 	.ds 1
      000AEC                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AEC                        662 	.ds 2
      000AEE                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AEE                        664 	.ds 1
      000AEF                        665 _dynamic_keymap_get_combo_PARM_2:
      000AEF                        666 	.ds 3
      000AF2                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AF2                        668 	.ds 1
      000AF3                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF3                        670 	.ds 3
      000AF6                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AF6                        672 	.ds 1
      000AF7                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AF7                        674 	.ds 10
      000B01                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B01                        676 	.ds 1
      000B02                        677 _dynamic_keymap_reset_combo_10001_408:
      000B02                        678 	.ds 10
      000B0C                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B0C                        680 	.ds 2
      000B0E                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B0E                        682 	.ds 2
      000B10                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B10                        684 	.ds 2
      000B12                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B12                        686 	.ds 3
      000B15                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B15                        688 	.ds 2
      000B17                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B17                        690 	.ds 1
      000B18                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B18                        692 	.ds 2
      000B1A                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B1A                        694 	.ds 3
      000B1D                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B1D                        696 	.ds 2
      000B1F                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B1F                        698 	.ds 2
      000B21                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B21                        700 	.ds 3
      000B24                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B24                        702 	.ds 2
      000B26                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B26                        704 	.ds 1
      000B27                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B27                        706 	.ds 1
      000B28                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B28                        708 	.ds 1
      000B29                        709 _keycode_at_keymap_location_PARM_2:
      000B29                        710 	.ds 1
      000B2A                        711 _keycode_at_keymap_location_PARM_3:
      000B2A                        712 	.ds 1
      000B2B                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B2B                        714 	.ds 1
      000B2C                        715 _keycode_at_encodermap_location_PARM_2:
      000B2C                        716 	.ds 1
      000B2D                        717 _keycode_at_encodermap_location_PARM_3:
      000B2D                        718 	.ds 1
      000B2E                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B2E                        720 	.ds 1
      000B2F                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B2F                        722 	.ds 2
      000B31                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B31                        724 	.ds 3
      000B34                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B34                        726 	.ds 2
      000B36                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B36                        728 	.ds 2
      000B38                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B38                        730 	.ds 3
      000B3B                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B3B                        732 	.ds 2
      000B3D                        733 _decode_keycode_kc_10000_455:
      000B3D                        734 	.ds 2
      000B3F                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B3F                        736 	.ds 1
      000B40                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B40                        738 	.ds 1
      000B41                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B41                        740 	.ds 2
      000B43                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B43                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      0085A8                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0085A8 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      0085AB 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      0085AC                        810 _dynamic_keymap_key_to_eeprom_address:
      0085AC E5 82            [12]  811 	mov	a,dpl
      0085AE 90 0A DC         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      0085B1 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0085B2 E0               [24]  815 	movx	a,@dptr
      0085B3 FF               [12]  816 	mov	r7,a
      0085B4 7E 00            [12]  817 	mov	r6,#0x00
      0085B6 74 40            [12]  818 	mov	a,#0x40
      0085B8 12 43 94         [24]  819 	lcall	_ak820_outline_0134
      0085BB 7D 00            [12]  820 	mov	r5,#0x00
      0085BD 90 0A DA         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0085C0 E0               [24]  822 	movx	a,@dptr
      0085C1 75 F0 10         [24]  823 	mov	b,#0x10
      0085C4 A4               [48]  824 	mul	ab
      0085C5 2E               [12]  825 	add	a, r6
      0085C6 FE               [12]  826 	mov	r6,a
      0085C7 EF               [12]  827 	mov	a,r7
      0085C8 35 F0            [12]  828 	addc	a, b
      0085CA FF               [12]  829 	mov	r7,a
      0085CB 90 0A DB         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0085CE E0               [24]  831 	movx	a,@dptr
      0085CF 7C 00            [12]  832 	mov	r4,#0x00
      0085D1 25 E0            [12]  833 	add	a,acc
      0085D3 FB               [12]  834 	mov	r3,a
      0085D4 EC               [12]  835 	mov	a,r4
      0085D5 33               [12]  836 	rlc	a
      0085D6 FC               [12]  837 	mov	r4,a
      0085D7 EB               [12]  838 	mov	a,r3
      0085D8 2E               [12]  839 	add	a, r6
      0085D9 FE               [12]  840 	mov	r6,a
      0085DA EC               [12]  841 	mov	a,r4
      0085DB 3F               [12]  842 	addc	a, r7
      0085DC FF               [12]  843 	mov	r7,a
      0085DD 12 43 84         [24]  844 	lcall	_ak820_outline_0117
      0085E0 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      0085E2 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      0085E3                        861 _dynamic_keymap_get_keycode:
      0085E3 E5 82            [12]  862 	mov	a,dpl
      0085E5 90 0A DF         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0085E8 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0085E9 E0               [24]  866 	movx	a,@dptr
      0085EA FF               [12]  867 	mov	r7,a
      0085EB BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      0085EE                        869 00121$:
      0085EE 50 14            [24]  870 	jnc	00101$
      0085F0 90 0A DD         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0085F3 E0               [24]  872 	movx	a,@dptr
      0085F4 FE               [12]  873 	mov	r6,a
      0085F5 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      0085F8                        875 00123$:
      0085F8 50 0A            [24]  876 	jnc	00101$
      0085FA 90 0A DE         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0085FD E0               [24]  878 	movx	a,@dptr
      0085FE FD               [12]  879 	mov	r5,a
      0085FF BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008602                        881 00125$:
      008602 40 04            [24]  882 	jc	00102$
      008604                        883 00101$:
      008604 90 00 00         [24]  884 	mov	dptr,#0x0000
      008607 22               [24]  885 	ret
      008608                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008608 12 90 4A         [24]  888 	lcall	_ak820_outline_0095
      00860B B1 AC            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      00860D 12 90 57         [24]  891 	lcall	_ak820_outline_0113
      008610 12 40 A3         [24]  892 	lcall	_eeprom_read_byte
      008613 AB 82            [24]  893 	mov	r3,dpl
      008615 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008617 0D               [12]  896 	inc	r5
      008618 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      00861B 0E               [12]  898 	inc	r6
      00861C                        899 00127$:
      00861C 12 50 0A         [24]  900 	lcall	_ak820_outline_0044
      00861F 12 40 A3         [24]  901 	lcall	_eeprom_read_byte
      008622 AF 82            [24]  902 	mov	r7, dpl
      008624 7E 00            [12]  903 	mov	r6,#0x00
      008626 EF               [12]  904 	mov	a,r7
      008627 42 04            [12]  905 	orl	ar4,a
      008629 EE               [12]  906 	mov	a,r6
      00862A 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      00862C 12 43 C0         [24]  909 	lcall	_ak820_outline_0182
                                    910 ;	quantum/dynamic_keymap.c:215: }
      00862F 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008630                        925 _dynamic_keymap_set_keycode:
      008630 E5 82            [12]  926 	mov	a,dpl
      008632 90 0A E4         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008635 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008636 E0               [24]  930 	movx	a,@dptr
      008637 FF               [12]  931 	mov	r7,a
      008638 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      00863B                        933 00121$:
      00863B 50 14            [24]  934 	jnc	00101$
      00863D 90 0A E0         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008640 E0               [24]  936 	movx	a,@dptr
      008641 FE               [12]  937 	mov	r6,a
      008642 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      008645                        939 00123$:
      008645 50 0A            [24]  940 	jnc	00101$
      008647 90 0A E1         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00864A E0               [24]  942 	movx	a,@dptr
      00864B FD               [12]  943 	mov	r5,a
      00864C BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      00864F                        945 00125$:
      00864F 40 01            [24]  946 	jc	00102$
      008651                        947 00101$:
      008651 22               [24]  948 	ret
      008652                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008652 12 90 4A         [24]  951 	lcall	_ak820_outline_0095
      008655 B1 AC            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      008657 12 90 57         [24]  953 	lcall	_ak820_outline_0113
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      00865A 90 0A E2         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00865D E0               [24]  956 	movx	a,@dptr
      00865E FB               [12]  957 	mov	r3,a
      00865F A3               [24]  958 	inc	dptr
      008660 E0               [24]  959 	movx	a,@dptr
      008661 90 06 9F         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      008664 F0               [24]  961 	movx	@dptr,a
      008665 12 50 0A         [24]  962 	lcall	_ak820_outline_0044
      008668 12 4E F4         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      00866B 0D               [12]  965 	inc	r5
      00866C BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      00866F 0E               [12]  967 	inc	r6
      008670                        968 00127$:
      008670 90 06 9F         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008673 EB               [12]  970 	mov	a,r3
      008674 F0               [24]  971 	movx	@dptr,a
      008675 12 50 0A         [24]  972 	lcall	_ak820_outline_0044
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008678 02 4E F4         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      00867B                        985 _dynamic_keymap_encoder_to_eeprom_address:
      00867B E5 82            [12]  986 	mov	a,dpl
      00867D 90 0A E6         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008680 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008681 E0               [24]  990 	movx	a,@dptr
      008682 75 F0 04         [24]  991 	mov	b,#0x04
      008685 A4               [48]  992 	mul	ab
      008686 24 40            [12]  993 	add	a, #0x40
      008688 FD               [12]  994 	mov	r5,a
      008689 74 06            [12]  995 	mov	a,#0x06
      00868B 35 F0            [12]  996 	addc	a, b
      00868D FE               [12]  997 	mov	r6,a
      00868E 7F 00            [12]  998 	mov	r7,#0x00
      008690 90 0A E5         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008693 E0               [24] 1000 	movx	a,@dptr
      008694 75 F0 04         [24] 1001 	mov	b,#0x04
      008697 A4               [48] 1002 	mul	ab
      008698 2D               [12] 1003 	add	a, r5
      008699 FD               [12] 1004 	mov	r5,a
      00869A EE               [12] 1005 	mov	a,r6
      00869B 35 F0            [12] 1006 	addc	a, b
      00869D FE               [12] 1007 	mov	r6,a
      00869E 12 50 0A         [24] 1008 	lcall	_ak820_outline_0044
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      0086A1 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      0086A2                       1024 _dynamic_keymap_get_encoder:
      0086A2 E5 82            [12] 1025 	mov	a,dpl
      0086A4 90 0A E9         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      0086A7 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0086A8 E0               [24] 1029 	movx	a,@dptr
      0086A9 FF               [12] 1030 	mov	r7,a
      0086AA BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      0086AD                       1032 00131$:
      0086AD 50 0A            [24] 1033 	jnc	00101$
      0086AF 90 0A E7         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0086B2 E0               [24] 1035 	movx	a,@dptr
      0086B3 FE               [12] 1036 	mov	r6,a
      0086B4 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      0086B7                       1038 00133$:
      0086B7 40 04            [24] 1039 	jc	00102$
      0086B9                       1040 00101$:
      0086B9 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0086BC 22               [24] 1042 	ret
      0086BD                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0086BD 90 0A E5         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0086C0 E4               [12] 1046 	clr	a
      0086C1 F0               [24] 1047 	movx	@dptr,a
      0086C2 8F 82            [24] 1048 	mov	dpl, r7
      0086C4 D1 7B            [12] 1049 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0086C6 12 90 57         [24] 1050 	lcall	_ak820_outline_0113
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0086C9 90 0A E8         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0086CC E0               [24] 1053 	movx	a,@dptr
      0086CD FC               [12] 1054 	mov	r4,a
      0086CE E0               [24] 1055 	movx	a,@dptr
      0086CF 60 04            [24] 1056 	jz	00106$
      0086D1 7B 00            [12] 1057 	mov	r3,#0x00
      0086D3 80 02            [24] 1058 	sjmp	00107$
      0086D5                       1059 00106$:
      0086D5 7B 02            [12] 1060 	mov	r3,#0x02
      0086D7                       1061 00107$:
      0086D7 EB               [12] 1062 	mov	a,r3
      0086D8 12 90 28         [24] 1063 	lcall	_ak820_outline_0025
      0086DB 12 40 A3         [24] 1064 	lcall	_eeprom_read_byte
      0086DE AA 82            [24] 1065 	mov	r2,dpl
      0086E0 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0086E2 EC               [12] 1068 	mov	a,r4
      0086E3 60 04            [24] 1069 	jz	00108$
      0086E5 7C 00            [12] 1070 	mov	r4,#0x00
      0086E7 80 02            [24] 1071 	sjmp	00109$
      0086E9                       1072 00108$:
      0086E9 7C 02            [12] 1073 	mov	r4,#0x02
      0086EB                       1074 00109$:
      0086EB EC               [12] 1075 	mov	a,r4
      0086EC 12 38 71         [24] 1076 	lcall	_ak820_outline_0155
      0086EF 0D               [12] 1077 	inc	r5
      0086F0 BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      0086F3 0E               [12] 1079 	inc	r6
      0086F4                       1080 00137$:
      0086F4 12 50 0A         [24] 1081 	lcall	_ak820_outline_0044
      0086F7 12 40 A3         [24] 1082 	lcall	_eeprom_read_byte
      0086FA AF 82            [24] 1083 	mov	r7, dpl
      0086FC 7E 00            [12] 1084 	mov	r6,#0x00
      0086FE EF               [12] 1085 	mov	a,r7
      0086FF 42 03            [12] 1086 	orl	ar3,a
      008701 EE               [12] 1087 	mov	a,r6
      008702 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      008704 8B 82            [24] 1090 	mov	dpl, r3
      008706 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      008708 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008709                       1108 _dynamic_keymap_set_encoder:
      008709 E5 82            [12] 1109 	mov	a,dpl
      00870B 90 0A EE         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      00870E F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00870F E0               [24] 1113 	movx	a,@dptr
      008710 FF               [12] 1114 	mov	r7,a
      008711 BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      008714                       1116 00131$:
      008714 50 0A            [24] 1117 	jnc	00101$
      008716 90 0A EA         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008719 E0               [24] 1119 	movx	a,@dptr
      00871A FE               [12] 1120 	mov	r6,a
      00871B BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      00871E                       1122 00133$:
      00871E 40 01            [24] 1123 	jc	00102$
      008720                       1124 00101$:
      008720 22               [24] 1125 	ret
      008721                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008721 90 0A E5         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008724 E4               [12] 1129 	clr	a
      008725 F0               [24] 1130 	movx	@dptr,a
      008726 8F 82            [24] 1131 	mov	dpl, r7
      008728 D1 7B            [12] 1132 	acall	_dynamic_keymap_encoder_to_eeprom_address
      00872A 12 90 57         [24] 1133 	lcall	_ak820_outline_0113
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      00872D 90 0A EB         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008730 E0               [24] 1136 	movx	a,@dptr
      008731 FC               [12] 1137 	mov	r4,a
      008732 E0               [24] 1138 	movx	a,@dptr
      008733 60 04            [24] 1139 	jz	00106$
      008735 7B 00            [12] 1140 	mov	r3,#0x00
      008737 80 02            [24] 1141 	sjmp	00107$
      008739                       1142 00106$:
      008739 7B 02            [12] 1143 	mov	r3,#0x02
      00873B                       1144 00107$:
      00873B EB               [12] 1145 	mov	a,r3
      00873C 12 90 69         [24] 1146 	lcall	_ak820_outline_0133
      00873F 8F 03            [24] 1147 	mov	ar3,r7
      008741 90 0A EC         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008744 E0               [24] 1149 	movx	a,@dptr
      008745 F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008747 A3               [24] 1151 	inc	dptr
      008748 E0               [24] 1152 	movx	a,@dptr
      008749 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      00874B 90 06 9F         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      00874E F0               [24] 1155 	movx	@dptr,a
      00874F 12 43 BB         [24] 1156 	lcall	_ak820_outline_0181
      008752 8B F0            [24] 1157 	mov	b, r3
      008754 12 4E F4         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008757 EC               [12] 1160 	mov	a,r4
      008758 60 04            [24] 1161 	jz	00108$
      00875A 7C 00            [12] 1162 	mov	r4,#0x00
      00875C 80 02            [24] 1163 	sjmp	00109$
      00875E                       1164 00108$:
      00875E 7C 02            [12] 1165 	mov	r4,#0x02
      008760                       1166 00109$:
      008760 EC               [12] 1167 	mov	a,r4
      008761 12 38 71         [24] 1168 	lcall	_ak820_outline_0155
      008764 0D               [12] 1169 	inc	r5
      008765 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      008768 0E               [12] 1171 	inc	r6
      008769                       1172 00137$:
      008769 90 06 9F         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      00876C E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      00876E F0               [24] 1175 	movx	@dptr,a
      00876F 12 50 0A         [24] 1176 	lcall	_ak820_outline_0044
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      008772 02 4E F4         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      008775                       1193 _dynamic_keymap_get_combo:
      008775 E5 82            [12] 1194 	mov	a,dpl
      008777 90 0A F2         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00877A F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00877B 90 0A EF         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00877E 12 37 F7         [24] 1199 	lcall	_ak820_outline_0051
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008781 90 0A F2         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008784 E0               [24] 1202 	movx	a,@dptr
      008785 FD               [12] 1203 	mov	r5,a
      008786 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008789                       1205 00132$:
      008789 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      00878B 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      00878E 22               [24] 1209 	ret
      00878F                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00878F 12 90 36         [24] 1212 	lcall	_ak820_outline_0078
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008792 8E 02            [24] 1214 	mov	ar2,r6
      008794 8F 03            [24] 1215 	mov	ar3,r7
      008796 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008799 12 38 1C         [24] 1217 	lcall	_ak820_outline_0071
      00879C E4               [12] 1218 	clr	a
      00879D A3               [24] 1219 	inc	dptr
      00879E F0               [24] 1220 	movx	@dptr,a
      00879F 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0087A2 74 0A            [12] 1222 	mov	a,#0x0a
      0087A4 12 38 5C         [24] 1223 	lcall	_ak820_outline_0123
      0087A7 12 43 A0         [24] 1224 	lcall	_ak820_outline_0140
      0087AA C0 07            [24] 1225 	push	ar7
      0087AC C0 06            [24] 1226 	push	ar6
      0087AE 12 40 DE         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      0087B1 D0 06            [24] 1228 	pop	ar6
      0087B3 D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0087B5 74 04            [12] 1231 	mov	a,#0x04
      0087B7 12 49 55         [24] 1232 	lcall	_ak820_outline_0012
      0087BA FA               [12] 1233 	mov	r2,a
      0087BB A3               [24] 1234 	inc	dptr
      0087BC E0               [24] 1235 	movx	a,@dptr
      0087BD FB               [12] 1236 	mov	r3,a
      0087BE BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      0087C1 BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      0087C4 74 06            [12] 1239 	mov	a,#0x06
      0087C6 12 37 DE         [24] 1240 	lcall	_ak820_outline_0017
      0087C9 FA               [12] 1241 	mov	r2,a
      0087CA A3               [24] 1242 	inc	dptr
      0087CB E0               [24] 1243 	movx	a,@dptr
      0087CC FB               [12] 1244 	mov	r3,a
      0087CD BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      0087D0 BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      0087D3 80 05            [24] 1247 	sjmp	00109$
      0087D5                       1248 00136$:
      0087D5                       1249 00108$:
      0087D5 75 2B 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0087D8 80 03            [24] 1251 	sjmp	00110$
      0087DA                       1252 00109$:
      0087DA 75 2B 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0087DD                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      0087DD 74 06            [12] 1256 	mov	a,#0x06
      0087DF 12 37 E7         [24] 1257 	lcall	_ak820_outline_0031
      0087E2 E4               [12] 1258 	clr	a
      0087E3 F0               [24] 1259 	movx	@dptr,a
      0087E4 A3               [24] 1260 	inc	dptr
      0087E5 12 38 28         [24] 1261 	lcall	_ak820_outline_0096
      0087E8 F0               [24] 1262 	movx	@dptr,a
      0087E9 A3               [24] 1263 	inc	dptr
      0087EA F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0087EB E5 2B            [12] 1266 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0087ED 60 12            [24] 1267 	jz	00103$
      0087EF 12 43 84         [24] 1268 	lcall	_ak820_outline_0117
      0087F2 C0 07            [24] 1269 	push	ar7
      0087F4 C0 06            [24] 1270 	push	ar6
      0087F6 12 34 68         [24] 1271 	lcall	_ak820_combo_valid
      0087F9 E5 82            [12] 1272 	mov	a, dpl
      0087FB D0 06            [24] 1273 	pop	ar6
      0087FD D0 07            [24] 1274 	pop	ar7
      0087FF 70 17            [24] 1275 	jnz	00104$
      008801                       1276 00103$:
      008801 7D 00            [12] 1277 	mov	r5,#0x00
      008803 90 0D 84         [24] 1278 	mov	dptr,#_memset_PARM_2
      008806 E4               [12] 1279 	clr	a
      008807 F0               [24] 1280 	movx	@dptr,a
      008808 90 0D 85         [24] 1281 	mov	dptr,#_memset_PARM_3
      00880B 74 0A            [12] 1282 	mov	a,#0x0a
      00880D F0               [24] 1283 	movx	@dptr,a
      00880E E4               [12] 1284 	clr	a
      00880F A3               [24] 1285 	inc	dptr
      008810 12 43 66         [24] 1286 	lcall	_ak820_outline_0061
      008813 8D F0            [24] 1287 	mov	b, r5
      008815 12 B9 0D         [24] 1288 	lcall	_memset
      008818                       1289 00104$:
                                   1290 ;	quantum/dynamic_keymap.c:329: return 0;
      008818 90 00 00         [24] 1291 	mov	dptr,#0x0000
                                   1292 ;	quantum/dynamic_keymap.c:330: }
      00881B 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1296 ;------------------------------------------------------------
                                   1297 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1298 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1299 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1300 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1301 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function dynamic_keymap_set_combo
                                   1306 ;	-----------------------------------------
      00881C                       1307 _dynamic_keymap_set_combo:
      00881C E5 82            [12] 1308 	mov	a,dpl
      00881E 90 0A F6         [24] 1309 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008821 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008822 90 0A F3         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008825 12 37 97         [24] 1313 	lcall	_ak820_outline_0004
                                   1314 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008828 C0 07            [24] 1315 	push	ar7
      00882A C0 06            [24] 1316 	push	ar6
      00882C 12 34 68         [24] 1317 	lcall	_ak820_combo_valid
      00882F E5 82            [12] 1318 	mov	a, dpl
      008831 D0 06            [24] 1319 	pop	ar6
      008833 D0 07            [24] 1320 	pop	ar7
      008835 60 07            [24] 1321 	jz	00101$
      008837 12 3E 4A         [24] 1322 	lcall	_ak820_nvm_ok
      00883A E5 82            [12] 1323 	mov	a, dpl
      00883C 70 04            [24] 1324 	jnz	00102$
      00883E                       1325 00101$:
      00883E 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      008841 22               [24] 1327 	ret
      008842                       1328 00102$:
                                   1329 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008842 90 0A F6         [24] 1330 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008845 E0               [24] 1331 	movx	a,@dptr
      008846 FD               [12] 1332 	mov	r5,a
      008847 BD 08 00         [24] 1333 	cjne	r5,#0x08,00133$
      00884A                       1334 00133$:
      00884A 40 04            [24] 1335 	jc	00105$
                                   1336 ;	quantum/dynamic_keymap.c:342: return -1;
      00884C 90 FF FF         [24] 1337 	mov	dptr,#0xffff
      00884F 22               [24] 1338 	ret
      008850                       1339 00105$:
                                   1340 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008850 12 90 36         [24] 1341 	lcall	_ak820_outline_0078
                                   1342 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008853 C0 07            [24] 1343 	push	ar7
      008855 C0 06            [24] 1344 	push	ar6
      008857 C0 05            [24] 1345 	push	ar5
      008859 C0 04            [24] 1346 	push	ar4
      00885B 12 77 C9         [24] 1347 	lcall	_clear_keyboard
      00885E D0 04            [24] 1348 	pop	ar4
      008860 D0 05            [24] 1349 	pop	ar5
      008862 D0 06            [24] 1350 	pop	ar6
      008864 D0 07            [24] 1351 	pop	ar7
                                   1352 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008866 90 0D 7C         [24] 1353 	mov	dptr,#___memcpy_PARM_2
      008869 12 49 AE         [24] 1354 	lcall	_ak820_outline_0059
      00886C E4               [12] 1355 	clr	a
      00886D A3               [24] 1356 	inc	dptr
      00886E F0               [24] 1357 	movx	@dptr,a
      00886F 90 0D 7F         [24] 1358 	mov	dptr,#___memcpy_PARM_3
      008872 74 0A            [12] 1359 	mov	a,#0x0a
      008874 12 38 5C         [24] 1360 	lcall	_ak820_outline_0123
      008877 90 0A F7         [24] 1361 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00887A F5 F0            [12] 1362 	mov	b,a
      00887C C0 05            [24] 1363 	push	ar5
      00887E C0 04            [24] 1364 	push	ar4
      008880 12 B8 97         [24] 1365 	lcall	___memcpy
      008883 D0 04            [24] 1366 	pop	ar4
      008885 D0 05            [24] 1367 	pop	ar5
                                   1368 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008887 90 0A FB         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      00888A 74 20            [12] 1370 	mov	a,#0x20
      00888C F0               [24] 1371 	movx	@dptr,a
      00888D 74 08            [12] 1372 	mov	a,#0x08
      00888F A3               [24] 1373 	inc	dptr
      008890 F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008891 90 0A FD         [24] 1376 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008894 74 01            [12] 1377 	mov	a,#0x01
      008896 12 38 5C         [24] 1378 	lcall	_ak820_outline_0123
                                   1379 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008899 90 05 8A         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00889C 12 38 1C         [24] 1381 	lcall	_ak820_outline_0071
      00889F E4               [12] 1382 	clr	a
      0088A0 A3               [24] 1383 	inc	dptr
      0088A1 F0               [24] 1384 	movx	@dptr,a
      0088A2 90 05 8D         [24] 1385 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0088A5 74 0A            [12] 1386 	mov	a,#0x0a
      0088A7 12 38 5C         [24] 1387 	lcall	_ak820_outline_0123
      0088AA 90 0A F7         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      0088AD 12 41 6A         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      0088B0 12 3E 59         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      0088B3 12 3E 4A         [24] 1393 	lcall	_ak820_nvm_ok
      0088B6 E5 82            [12] 1394 	mov	a, dpl
      0088B8 70 04            [24] 1395 	jnz	00107$
      0088BA 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      0088BD 22               [24] 1397 	ret
      0088BE                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      0088BE 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      0088C1 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1405 ;------------------------------------------------------------
                                   1406 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1407 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1408 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1409 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1410 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1411 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1412 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function dynamic_keymap_reset
                                   1417 ;	-----------------------------------------
      0088C2                       1418 _dynamic_keymap_reset:
                                   1419 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      0088C2 90 0D FC         [24] 1420 	mov	dptr,#_vial_unlocked
      0088C5 E0               [24] 1421 	movx	a,@dptr
      0088C6 90 0B 01         [24] 1422 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0088C9 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      0088CA 90 0D FC         [24] 1425 	mov	dptr,#_vial_unlocked
      0088CD 74 01            [12] 1426 	mov	a,#0x01
      0088CF F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0088D0 7F 00            [12] 1429 	mov	r7,#0x00
      0088D2                       1430 00116$:
      0088D2 BF 06 00         [24] 1431 	cjne	r7,#0x06,00198$
      0088D5                       1432 00198$:
      0088D5 40 02            [24] 1433 	jc	00199$
      0088D7 21 83            [12] 1434 	ajmp	00104$
      0088D9                       1435 00199$:
                                   1436 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0088D9 7E 00            [12] 1437 	mov	r6,#0x00
      0088DB                       1438 00110$:
      0088DB BE 10 00         [24] 1439 	cjne	r6,#0x10,00200$
      0088DE                       1440 00200$:
      0088DE 50 4D            [24] 1441 	jnc	00102$
                                   1442 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0088E0 7D 00            [12] 1443 	mov	r5,#0x00
      0088E2                       1444 00107$:
      0088E2 BD 08 00         [24] 1445 	cjne	r5,#0x08,00202$
      0088E5                       1446 00202$:
      0088E5 50 43            [24] 1447 	jnc	00111$
                                   1448 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0088E7 90 0B 9D         [24] 1449 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0088EA EE               [12] 1450 	mov	a,r6
      0088EB F0               [24] 1451 	movx	@dptr,a
      0088EC 90 0B 9E         [24] 1452 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0088EF ED               [12] 1453 	mov	a,r5
      0088F0 F0               [24] 1454 	movx	@dptr,a
      0088F1 8F 82            [24] 1455 	mov	dpl, r7
      0088F3 C0 07            [24] 1456 	push	ar7
      0088F5 C0 06            [24] 1457 	push	ar6
      0088F7 C0 05            [24] 1458 	push	ar5
      0088F9 12 98 65         [24] 1459 	lcall	_keycode_at_keymap_location_raw
      0088FC AB 82            [24] 1460 	mov	r3, dpl
      0088FE AC 83            [24] 1461 	mov	r4, dph
      008900 D0 05            [24] 1462 	pop	ar5
      008902 D0 06            [24] 1463 	pop	ar6
      008904 D0 07            [24] 1464 	pop	ar7
      008906 90 0A E0         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008909 EE               [12] 1466 	mov	a,r6
      00890A F0               [24] 1467 	movx	@dptr,a
      00890B 90 0A E1         [24] 1468 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00890E ED               [12] 1469 	mov	a,r5
      00890F F0               [24] 1470 	movx	@dptr,a
      008910 90 0A E2         [24] 1471 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008913 12 38 22         [24] 1472 	lcall	_ak820_outline_0076
      008916 8F 82            [24] 1473 	mov	dpl, r7
      008918 C0 07            [24] 1474 	push	ar7
      00891A C0 06            [24] 1475 	push	ar6
      00891C C0 05            [24] 1476 	push	ar5
      00891E 12 86 30         [24] 1477 	lcall	_dynamic_keymap_set_keycode
      008921 D0 05            [24] 1478 	pop	ar5
      008923 D0 06            [24] 1479 	pop	ar6
      008925 D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008927 0D               [12] 1482 	inc	r5
      008928 80 B8            [24] 1483 	sjmp	00107$
      00892A                       1484 00111$:
                                   1485 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      00892A 0E               [12] 1486 	inc	r6
      00892B 80 AE            [24] 1487 	sjmp	00110$
      00892D                       1488 00102$:
                                   1489 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00892D 7E 00            [12] 1490 	mov	r6,#0x00
      00892F                       1491 00113$:
      00892F BE 01 00         [24] 1492 	cjne	r6,#0x01,00204$
      008932                       1493 00204$:
      008932 50 4C            [24] 1494 	jnc	00117$
                                   1495 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008934 12 90 85         [24] 1496 	lcall	_ak820_outline_0176
      008937 04               [12] 1497 	inc	a
      008938 F0               [24] 1498 	movx	@dptr,a
      008939 8F 82            [24] 1499 	mov	dpl, r7
      00893B C0 07            [24] 1500 	push	ar7
      00893D 12 98 AA         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      008940 12 43 A5         [24] 1502 	lcall	_ak820_outline_0145
      008943 D0 07            [24] 1503 	pop	ar7
      008945 12 90 7C         [24] 1504 	lcall	_ak820_outline_0175
      008948 04               [12] 1505 	inc	a
      008949 F0               [24] 1506 	movx	@dptr,a
      00894A 90 0A EC         [24] 1507 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00894D 12 38 1C         [24] 1508 	lcall	_ak820_outline_0071
      008950 8F 82            [24] 1509 	mov	dpl, r7
      008952 C0 07            [24] 1510 	push	ar7
      008954 12 87 09         [24] 1511 	lcall	_dynamic_keymap_set_encoder
      008957 D0 07            [24] 1512 	pop	ar7
                                   1513 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008959 12 90 85         [24] 1514 	lcall	_ak820_outline_0176
      00895C F0               [24] 1515 	movx	@dptr,a
      00895D 8F 82            [24] 1516 	mov	dpl, r7
      00895F C0 07            [24] 1517 	push	ar7
      008961 12 98 AA         [24] 1518 	lcall	_keycode_at_encodermap_location_raw
      008964 12 43 A5         [24] 1519 	lcall	_ak820_outline_0145
      008967 D0 07            [24] 1520 	pop	ar7
      008969 12 90 7C         [24] 1521 	lcall	_ak820_outline_0175
      00896C F0               [24] 1522 	movx	@dptr,a
      00896D 90 0A EC         [24] 1523 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008970 12 38 1C         [24] 1524 	lcall	_ak820_outline_0071
      008973 8F 82            [24] 1525 	mov	dpl, r7
      008975 C0 07            [24] 1526 	push	ar7
      008977 12 87 09         [24] 1527 	lcall	_dynamic_keymap_set_encoder
      00897A D0 07            [24] 1528 	pop	ar7
                                   1529 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00897C 7E 01            [12] 1530 	mov	r6,#0x01
      00897E 80 AF            [24] 1531 	sjmp	00113$
      008980                       1532 00117$:
                                   1533 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008980 0F               [12] 1534 	inc	r7
      008981 01 D2            [12] 1535 	ajmp	00116$
      008983                       1536 00104$:
                                   1537 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008983 90 0B 02         [24] 1538 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008986 12 50 53         [24] 1539 	lcall	_ak820_outline_0180
      008989 90 0B 04         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      00898C F0               [24] 1541 	movx	@dptr,a
      00898D A3               [24] 1542 	inc	dptr
      00898E F0               [24] 1543 	movx	@dptr,a
      00898F 90 0B 06         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008992 F0               [24] 1545 	movx	@dptr,a
      008993 A3               [24] 1546 	inc	dptr
      008994 F0               [24] 1547 	movx	@dptr,a
      008995 90 0B 08         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008998 F0               [24] 1549 	movx	@dptr,a
      008999 A3               [24] 1550 	inc	dptr
      00899A F0               [24] 1551 	movx	@dptr,a
      00899B 90 0B 0A         [24] 1552 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      00899E F0               [24] 1553 	movx	@dptr,a
      00899F A3               [24] 1554 	inc	dptr
      0089A0 F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0089A1 FF               [12] 1557 	mov	r7,a
      0089A2                       1558 00119$:
      0089A2 BF 08 00         [24] 1559 	cjne	r7,#0x08,00206$
      0089A5                       1560 00206$:
      0089A5 50 16            [24] 1561 	jnc	00105$
                                   1562 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      0089A7 90 0A F3         [24] 1563 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0089AA 74 02            [12] 1564 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      0089AC F0               [24] 1565 	movx	@dptr,a
      0089AD 74 0B            [12] 1566 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      0089AF 12 38 51         [24] 1567 	lcall	_ak820_outline_0118
      0089B2 8F 82            [24] 1568 	mov	dpl, r7
      0089B4 C0 07            [24] 1569 	push	ar7
      0089B6 11 1C            [24] 1570 	acall	_dynamic_keymap_set_combo
      0089B8 D0 07            [24] 1571 	pop	ar7
                                   1572 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0089BA 0F               [12] 1573 	inc	r7
      0089BB 80 E5            [24] 1574 	sjmp	00119$
      0089BD                       1575 00105$:
                                   1576 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      0089BD 90 0B 01         [24] 1577 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0089C0 E0               [24] 1578 	movx	a,@dptr
      0089C1 90 0D FC         [24] 1579 	mov	dptr,#_vial_unlocked
      0089C4 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/dynamic_keymap.c:468: }
      0089C5 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1587 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1588 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1589 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1590 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1591 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1592 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1593 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1594 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1595 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function ak820_dynamic_read_buffer
                                   1600 ;	-----------------------------------------
      0089C6                       1601 _ak820_dynamic_read_buffer:
      0089C6 12 38 40         [24] 1602 	lcall	_ak820_outline_0104
      0089C9 90 0B 15         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0089CC 12 38 45         [24] 1604 	lcall	_ak820_outline_0105
                                   1605 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0089CF 90 0B 12         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0089D2 12 37 F7         [24] 1607 	lcall	_ak820_outline_0051
                                   1608 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      0089D5 90 0B 17         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0089D8 E4               [12] 1610 	clr	a
      0089D9 F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      0089DA 90 0B 10         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0089DD 12 38 16         [24] 1614 	lcall	_ak820_outline_0060
      0089E0 8C 02            [24] 1615 	mov	ar2,r4
      0089E2 8D 03            [24] 1616 	mov	ar3,r5
      0089E4 C3               [12] 1617 	clr	c
      0089E5 74 1C            [12] 1618 	mov	a,#0x1c
      0089E7 9A               [12] 1619 	subb	a,r2
      0089E8 E4               [12] 1620 	clr	a
      0089E9 9B               [12] 1621 	subb	a,r3
      0089EA 50 01            [24] 1622 	jnc	00102$
                                   1623 ;	free result
      0089EC 22               [24] 1624 	ret
      0089ED                       1625 00102$:
                                   1626 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      0089ED 90 0B 0E         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0089F0 12 43 89         [24] 1628 	lcall	_ak820_outline_0120
      0089F3 90 0B 0C         [24] 1629 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0089F6 12 38 34         [24] 1630 	lcall	_ak820_outline_0100
      0089F9 C3               [12] 1631 	clr	c
      0089FA EA               [12] 1632 	mov	a,r2
      0089FB 98               [12] 1633 	subb	a,r0
      0089FC EB               [12] 1634 	mov	a,r3
      0089FD 99               [12] 1635 	subb	a,r1
      0089FE 50 17            [24] 1636 	jnc	00104$
                                   1637 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008A00 E8               [12] 1638 	mov	a,r0
      008A01 C3               [12] 1639 	clr	c
      008A02 9A               [12] 1640 	subb	a,r2
      008A03 F8               [12] 1641 	mov	r0,a
      008A04 E9               [12] 1642 	mov	a,r1
      008A05 9B               [12] 1643 	subb	a,r3
      008A06 F9               [12] 1644 	mov	r1,a
                                   1645 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008A07 C3               [12] 1646 	clr	c
      008A08 E8               [12] 1647 	mov	a,r0
      008A09 9C               [12] 1648 	subb	a,r4
      008A0A E9               [12] 1649 	mov	a,r1
      008A0B 9D               [12] 1650 	subb	a,r5
      008A0C 40 04            [24] 1651 	jc	00114$
      008A0E 8C 00            [24] 1652 	mov	ar0,r4
      008A10 8D 01            [24] 1653 	mov	ar1,r5
      008A12                       1654 00114$:
      008A12 90 0B 17         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A15 E8               [12] 1656 	mov	a,r0
      008A16 F0               [24] 1657 	movx	@dptr,a
      008A17                       1658 00104$:
                                   1659 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A17 90 0B 17         [24] 1660 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A1A E0               [24] 1661 	movx	a,@dptr
      008A1B F5 2C            [12] 1662 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008A1D E0               [24] 1663 	movx	a,@dptr
      008A1E 60 42            [24] 1664 	jz	00106$
      008A20 C0 04            [24] 1665 	push	ar4
      008A22 C0 05            [24] 1666 	push	ar5
      008A24 8E 00            [24] 1667 	mov	ar0,r6
      008A26 8F 05            [24] 1668 	mov	ar5,r7
      008A28 90 0B 15         [24] 1669 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008A2B E0               [24] 1670 	movx	a,@dptr
      008A2C F9               [12] 1671 	mov	r1,a
      008A2D A3               [24] 1672 	inc	dptr
      008A2E E0               [24] 1673 	movx	a,@dptr
      008A2F FC               [12] 1674 	mov	r4,a
      008A30 EA               [12] 1675 	mov	a,r2
      008A31 29               [12] 1676 	add	a, r1
      008A32 FA               [12] 1677 	mov	r2,a
      008A33 EB               [12] 1678 	mov	a,r3
      008A34 3C               [12] 1679 	addc	a, r4
      008A35 FB               [12] 1680 	mov	r3,a
      008A36 90 05 81         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A39 EA               [12] 1682 	mov	a,r2
      008A3A F0               [24] 1683 	movx	@dptr,a
      008A3B EB               [12] 1684 	mov	a,r3
      008A3C 12 38 51         [24] 1685 	lcall	_ak820_outline_0118
      008A3F 90 05 84         [24] 1686 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A42 E5 2C            [12] 1687 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008A44 12 38 5C         [24] 1688 	lcall	_ak820_outline_0123
      008A47 88 82            [24] 1689 	mov	dpl, r0
      008A49 8D 83            [24] 1690 	mov	dph, r5
      008A4B C0 07            [24] 1691 	push	ar7
      008A4D C0 06            [24] 1692 	push	ar6
      008A4F C0 05            [24] 1693 	push	ar5
      008A51 C0 04            [24] 1694 	push	ar4
      008A53 12 40 DE         [24] 1695 	lcall	_ak820_eeprom_read_block_xdata
      008A56 D0 04            [24] 1696 	pop	ar4
      008A58 D0 05            [24] 1697 	pop	ar5
      008A5A D0 06            [24] 1698 	pop	ar6
      008A5C D0 07            [24] 1699 	pop	ar7
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A5E D0 05            [24] 1701 	pop	ar5
      008A60 D0 04            [24] 1702 	pop	ar4
                                   1703 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A62                       1704 00106$:
                                   1705 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A62 90 0B 17         [24] 1706 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A65 E0               [24] 1707 	movx	a,@dptr
      008A66 FB               [12] 1708 	mov	r3,a
      008A67                       1709 00109$:
      008A67 8B 01            [24] 1710 	mov	ar1,r3
      008A69 7A 00            [12] 1711 	mov	r2,#0x00
      008A6B C3               [12] 1712 	clr	c
      008A6C E9               [12] 1713 	mov	a,r1
      008A6D 9C               [12] 1714 	subb	a,r4
      008A6E EA               [12] 1715 	mov	a,r2
      008A6F 9D               [12] 1716 	subb	a,r5
      008A70 50 09            [24] 1717 	jnc	00111$
      008A72 EB               [12] 1718 	mov	a,r3
      008A73 12 37 E7         [24] 1719 	lcall	_ak820_outline_0031
      008A76 E4               [12] 1720 	clr	a
      008A77 F0               [24] 1721 	movx	@dptr,a
      008A78 0B               [12] 1722 	inc	r3
      008A79 80 EC            [24] 1723 	sjmp	00109$
      008A7B                       1724 00111$:
                                   1725 ;	quantum/dynamic_keymap.c:483: }
      008A7B 22               [24] 1726 	ret
                                   1727 ;------------------------------------------------------------
                                   1728 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1729 ;------------------------------------------------------------
                                   1730 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1731 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1732 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function dynamic_keymap_get_buffer
                                   1737 ;	-----------------------------------------
      008A7C                       1738 _dynamic_keymap_get_buffer:
      008A7C 12 38 40         [24] 1739 	lcall	_ak820_outline_0104
      008A7F 90 0B 1D         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A82 12 38 45         [24] 1741 	lcall	_ak820_outline_0105
                                   1742 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008A85 90 0B 1D         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008A88 12 37 F7         [24] 1744 	lcall	_ak820_outline_0051
      008A8B 90 0B 18         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008A8E 12 38 16         [24] 1746 	lcall	_ak820_outline_0060
      008A91 90 0B 1A         [24] 1747 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008A94 12 50 33         [24] 1748 	lcall	_ak820_outline_0087
      008A97 90 0B 0C         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A9A E4               [12] 1750 	clr	a
      008A9B F0               [24] 1751 	movx	@dptr,a
      008A9C 74 06            [12] 1752 	mov	a,#0x06
      008A9E A3               [24] 1753 	inc	dptr
      008A9F F0               [24] 1754 	movx	@dptr,a
      008AA0 90 0B 0E         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008AA3 12 49 AE         [24] 1756 	lcall	_ak820_outline_0059
      008AA6 90 0B 10         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008AA9 12 38 1C         [24] 1758 	lcall	_ak820_outline_0071
      008AAC 90 0B 12         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008AAF E9               [12] 1760 	mov	a,r1
      008AB0 12 50 4C         [24] 1761 	lcall	_ak820_outline_0151
      008AB3 F0               [24] 1762 	movx	@dptr,a
      008AB4 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:511: }
      008AB7 21 C6            [12] 1765 	ajmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      008AB9                       1790 _dynamic_keymap_set_buffer:
      008AB9 12 38 40         [24] 1791 	lcall	_ak820_outline_0104
      008ABC 90 0B 24         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008ABF 12 38 45         [24] 1793 	lcall	_ak820_outline_0105
                                   1794 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008AC2 90 0B 24         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008AC5 12 37 C2         [24] 1796 	lcall	_ak820_outline_0011
      008AC8 74 40            [12] 1797 	mov	a,#0x40
      008ACA 2C               [12] 1798 	add	a, r4
      008ACB FA               [12] 1799 	mov	r2,a
      008ACC E4               [12] 1800 	clr	a
      008ACD 3D               [12] 1801 	addc	a, r5
      008ACE FB               [12] 1802 	mov	r3,a
                                   1803 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008ACF 90 0B 21         [24] 1804 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008AD2 12 38 34         [24] 1805 	lcall	_ak820_outline_0100
                                   1806 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008AD5 90 0B 1F         [24] 1807 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008AD8 E0               [24] 1808 	movx	a,@dptr
      008AD9 F5 2D            [12] 1809 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008ADB A3               [24] 1810 	inc	dptr
      008ADC E0               [24] 1811 	movx	a,@dptr
      008ADD F5 2E            [12] 1812 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008ADF E5 2D            [12] 1813 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008AE1 45 2E            [12] 1814 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AE3 70 01            [24] 1815 	jnz	00102$
      008AE5 22               [24] 1816 	ret
      008AE6                       1817 00102$:
                                   1818 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008AE6 85 2D 2F         [24] 1819 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008AE9 85 2E 30         [24] 1820 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AEC C3               [12] 1821 	clr	c
      008AED 74 1C            [12] 1822 	mov	a,#0x1c
      008AEF 95 2F            [12] 1823 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008AF1 E4               [12] 1824 	clr	a
      008AF2 95 30            [12] 1825 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008AF4 50 01            [24] 1826 	jnc	00104$
                                   1827 ;	free result
      008AF6 22               [24] 1828 	ret
      008AF7                       1829 00104$:
                                   1830 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008AF7 85 2D 31         [24] 1831 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1832 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008AFA 74 FA            [12] 1833 	mov	a,#0x100 - 0x06
      008AFC 2F               [12] 1834 	add	a,r7
      008AFD 40 11            [24] 1835 	jc	00105$
      008AFF E4               [12] 1836 	clr	a
      008B00 C3               [12] 1837 	clr	c
      008B01 9E               [12] 1838 	subb	a,r6
      008B02 FE               [12] 1839 	mov	r6,a
      008B03 74 06            [12] 1840 	mov	a,#0x06
      008B05 9F               [12] 1841 	subb	a,r7
      008B06 FF               [12] 1842 	mov	r7,a
      008B07 C3               [12] 1843 	clr	c
      008B08 EE               [12] 1844 	mov	a,r6
      008B09 95 2D            [12] 1845 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B0B EF               [12] 1846 	mov	a,r7
      008B0C 95 2E            [12] 1847 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B0E 50 01            [24] 1848 	jnc	00106$
      008B10                       1849 00105$:
                                   1850 ;	quantum/dynamic_keymap.c:529: return;
      008B10 22               [24] 1851 	ret
      008B11                       1852 00106$:
                                   1853 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008B11 90 0D FC         [24] 1854 	mov	dptr,#_vial_unlocked
      008B14 E0               [24] 1855 	movx	a,@dptr
      008B15 60 02            [24] 1856 	jz	00207$
      008B17 81 24            [12] 1857 	ajmp	00120$
      008B19                       1858 00207$:
                                   1859 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008B19 90 0B 26         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B1C E4               [12] 1861 	clr	a
      008B1D F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008B1E 90 0B 27         [24] 1864 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008B21 E5 31            [12] 1865 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B23 F0               [24] 1866 	movx	@dptr,a
                                   1867 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008B24 EC               [12] 1868 	mov	a,r4
      008B25 30 E0 33         [24] 1869 	jnb	acc.0,00111$
                                   1870 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008B28 EA               [12] 1871 	mov	a,r2
      008B29 24 FF            [12] 1872 	add	a,#0xff
      008B2B FE               [12] 1873 	mov	r6,a
      008B2C EB               [12] 1874 	mov	a,r3
      008B2D 34 FF            [12] 1875 	addc	a,#0xff
      008B2F FF               [12] 1876 	mov	r7,a
      008B30 7D 00            [12] 1877 	mov	r5,#0x00
      008B32 12 43 84         [24] 1878 	lcall	_ak820_outline_0117
      008B35 8D F0            [24] 1879 	mov	b, r5
      008B37 12 40 A3         [24] 1880 	lcall	_eeprom_read_byte
      008B3A AE 82            [24] 1881 	mov	r6,dpl
      008B3C 7F 00            [12] 1882 	mov	r7,#0x00
      008B3E 12 38 6C         [24] 1883 	lcall	_ak820_outline_0152
      008B41 E0               [24] 1884 	movx	a,@dptr
      008B42 7C 00            [12] 1885 	mov	r4,#0x00
      008B44 42 07            [12] 1886 	orl	ar7,a
      008B46 EC               [12] 1887 	mov	a,r4
      008B47 42 06            [12] 1888 	orl	ar6,a
                                   1889 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008B49 BF 00 09         [24] 1890 	cjne	r7,#0x00,00109$
      008B4C BE 7C 06         [24] 1891 	cjne	r6,#0x7c,00109$
                                   1892 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008B4F 12 38 6C         [24] 1893 	lcall	_ak820_outline_0152
      008B52 74 FF            [12] 1894 	mov	a,#0xff
      008B54 F0               [24] 1895 	movx	@dptr,a
      008B55                       1896 00109$:
                                   1897 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008B55 90 0B 26         [24] 1898 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B58 74 01            [12] 1899 	mov	a,#0x01
      008B5A F0               [24] 1900 	movx	@dptr,a
      008B5B                       1901 00111$:
                                   1902 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008B5B 90 0B 24         [24] 1903 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B5E 12 37 F7         [24] 1904 	lcall	_ak820_outline_0051
      008B61 E5 2D            [12] 1905 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B63 2E               [12] 1906 	add	a, r6
      008B64 FE               [12] 1907 	mov	r6,a
      008B65 E5 2E            [12] 1908 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B67 3F               [12] 1909 	addc	a, r7
      008B68 EE               [12] 1910 	mov	a,r6
      008B69 30 E0 5A         [24] 1911 	jnb	acc.0,00115$
                                   1912 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008B6C AE 31            [24] 1913 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008B6E 7F 00            [12] 1914 	mov	r7,#0x00
      008B70 EE               [12] 1915 	mov	a,r6
      008B71 24 FF            [12] 1916 	add	a,#0xff
      008B73 FC               [12] 1917 	mov	r4,a
      008B74 EF               [12] 1918 	mov	a,r7
      008B75 34 FF            [12] 1919 	addc	a,#0xff
      008B77 FD               [12] 1920 	mov	r5,a
      008B78 EC               [12] 1921 	mov	a,r4
      008B79 28               [12] 1922 	add	a, r0
      008B7A F5 82            [12] 1923 	mov	dpl,a
      008B7C ED               [12] 1924 	mov	a,r5
      008B7D 39               [12] 1925 	addc	a, r1
      008B7E F5 83            [12] 1926 	mov	dph,a
      008B80 E0               [24] 1927 	movx	a,@dptr
      008B81 FC               [12] 1928 	mov	r4,a
      008B82 7D 00            [12] 1929 	mov	r5,#0x00
      008B84 E5 31            [12] 1930 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B86 2A               [12] 1931 	add	a, r2
      008B87 FA               [12] 1932 	mov	r2,a
      008B88 E4               [12] 1933 	clr	a
      008B89 3B               [12] 1934 	addc	a, r3
      008B8A FB               [12] 1935 	mov	r3,a
      008B8B C0 00            [24] 1936 	push	ar0
      008B8D C0 01            [24] 1937 	push	ar1
      008B8F 8B 01            [24] 1938 	mov	ar1,r3
      008B91 7B 00            [12] 1939 	mov	r3,#0x00
      008B93 8A 82            [24] 1940 	mov	dpl, r2
      008B95 89 83            [24] 1941 	mov	dph, r1
      008B97 8B F0            [24] 1942 	mov	b, r3
      008B99 12 40 A3         [24] 1943 	lcall	_eeprom_read_byte
      008B9C AB 82            [24] 1944 	mov	r3, dpl
      008B9E 7A 00            [12] 1945 	mov	r2,#0x00
      008BA0 EB               [12] 1946 	mov	a,r3
      008BA1 12 43 9A         [24] 1947 	lcall	_ak820_outline_0139
                                   1948 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008BA4 BD 00 05         [24] 1949 	cjne	r5,#0x00,00212$
      008BA7 BC 7C 02         [24] 1950 	cjne	r4,#0x7c,00212$
      008BAA 80 06            [24] 1951 	sjmp	00213$
      008BAC                       1952 00212$:
      008BAC D0 01            [24] 1953 	pop	ar1
      008BAE D0 00            [24] 1954 	pop	ar0
      008BB0 80 0D            [24] 1955 	sjmp	00113$
      008BB2                       1956 00213$:
      008BB2 D0 01            [24] 1957 	pop	ar1
      008BB4 D0 00            [24] 1958 	pop	ar0
                                   1959 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008BB6 1E               [12] 1960 	dec	r6
      008BB7 BE FF 01         [24] 1961 	cjne	r6,#0xff,00214$
      008BBA 1F               [12] 1962 	dec	r7
      008BBB                       1963 00214$:
      008BBB EE               [12] 1964 	mov	a,r6
      008BBC 12 90 5E         [24] 1965 	lcall	_ak820_outline_0127
      008BBF                       1966 00113$:
                                   1967 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008BBF E5 31            [12] 1968 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008BC1 14               [12] 1969 	dec	a
      008BC2 90 0B 27         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BC5 F0               [24] 1971 	movx	@dptr,a
      008BC6                       1972 00115$:
                                   1973 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008BC6 90 0B 26         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008BC9 E0               [24] 1975 	movx	a,@dptr
      008BCA 90 0B 28         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008BCD F0               [24] 1977 	movx	@dptr,a
      008BCE                       1978 00122$:
      008BCE 90 0B 28         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008BD1 E0               [24] 1980 	movx	a,@dptr
      008BD2 FF               [12] 1981 	mov	r7,a
      008BD3 90 0B 27         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BD6 E0               [24] 1983 	movx	a,@dptr
      008BD7 FE               [12] 1984 	mov	r6,a
      008BD8 C3               [12] 1985 	clr	c
      008BD9 EF               [12] 1986 	mov	a,r7
      008BDA 9E               [12] 1987 	subb	a,r6
      008BDB 50 47            [24] 1988 	jnc	00120$
                                   1989 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008BDD EF               [12] 1990 	mov	a,r7
      008BDE 28               [12] 1991 	add	a, r0
      008BDF FD               [12] 1992 	mov	r5,a
      008BE0 E4               [12] 1993 	clr	a
      008BE1 39               [12] 1994 	addc	a, r1
      008BE2 12 49 A6         [24] 1995 	lcall	_ak820_outline_0057
      008BE5 7B 00            [12] 1996 	mov	r3,#0x00
      008BE7 8C 2E            [24] 1997 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008BE9 8B 2D            [24] 1998 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008BEB 8F 02            [24] 1999 	mov	ar2,r7
      008BED 7F 00            [12] 2000 	mov	r7,#0x00
      008BEF 74 01            [12] 2001 	mov	a,#0x01
      008BF1 2A               [12] 2002 	add	a, r2
      008BF2 FB               [12] 2003 	mov	r3,a
      008BF3 E4               [12] 2004 	clr	a
      008BF4 3F               [12] 2005 	addc	a, r7
      008BF5 FC               [12] 2006 	mov	r4,a
      008BF6 EB               [12] 2007 	mov	a,r3
      008BF7 28               [12] 2008 	add	a, r0
      008BF8 F5 82            [12] 2009 	mov	dpl,a
      008BFA EC               [12] 2010 	mov	a,r4
      008BFB 39               [12] 2011 	addc	a, r1
      008BFC F5 83            [12] 2012 	mov	dph,a
      008BFE E0               [24] 2013 	movx	a,@dptr
      008BFF FC               [12] 2014 	mov	r4,a
      008C00 7B 00            [12] 2015 	mov	r3,#0x00
      008C02 E5 2E            [12] 2016 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C04 42 03            [12] 2017 	orl	ar3,a
                                   2018 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008C06 BC 00 12         [24] 2019 	cjne	r4,#0x00,00123$
      008C09 BB 7C 0F         [24] 2020 	cjne	r3,#0x7c,00123$
                                   2021 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008C0C 12 38 61         [24] 2022 	lcall	_ak820_outline_0131
      008C0F 74 FF            [12] 2023 	mov	a,#0xff
      008C11 F0               [24] 2024 	movx	@dptr,a
                                   2025 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008C12 0A               [12] 2026 	inc	r2
      008C13 BA 00 01         [24] 2027 	cjne	r2,#0x00,00218$
      008C16 0F               [12] 2028 	inc	r7
      008C17                       2029 00218$:
      008C17 EA               [12] 2030 	mov	a,r2
      008C18 12 90 5E         [24] 2031 	lcall	_ak820_outline_0127
      008C1B                       2032 00123$:
                                   2033 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C1B 90 0B 28         [24] 2034 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C1E E0               [24] 2035 	movx	a,@dptr
      008C1F 24 02            [12] 2036 	add	a,#0x02
      008C21 F0               [24] 2037 	movx	@dptr,a
      008C22 80 AA            [24] 2038 	sjmp	00122$
      008C24                       2039 00120$:
                                   2040 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008C24 90 0B 24         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008C27 12 37 F7         [24] 2042 	lcall	_ak820_outline_0051
      008C2A 74 40            [12] 2043 	mov	a,#0x40
      008C2C 12 43 94         [24] 2044 	lcall	_ak820_outline_0134
      008C2F 90 05 8A         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C32 12 49 AE         [24] 2046 	lcall	_ak820_outline_0059
      008C35 E4               [12] 2047 	clr	a
      008C36 A3               [24] 2048 	inc	dptr
      008C37 F0               [24] 2049 	movx	@dptr,a
      008C38 90 05 8D         [24] 2050 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C3B E5 2F            [12] 2051 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008C3D F0               [24] 2052 	movx	@dptr,a
      008C3E E5 30            [12] 2053 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008C40 A3               [24] 2054 	inc	dptr
      008C41 F0               [24] 2055 	movx	@dptr,a
      008C42 12 38 6C         [24] 2056 	lcall	_ak820_outline_0152
                                   2057 ;	quantum/dynamic_keymap.c:584: }
      008C45 02 41 6A         [24] 2058 	ljmp	_ak820_eeprom_write_block_xdata
                                   2059 ;------------------------------------------------------------
                                   2060 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2061 ;------------------------------------------------------------
                                   2062 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2063 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2064 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2065 ;------------------------------------------------------------
                                   2066 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2067 ;	-----------------------------------------
                                   2068 ;	 function keycode_at_keymap_location
                                   2069 ;	-----------------------------------------
      008C48                       2070 _keycode_at_keymap_location:
      008C48 E5 82            [12] 2071 	mov	a,dpl
      008C4A 90 0B 2B         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008C4D F0               [24] 2073 	movx	@dptr,a
                                   2074 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008C4E E0               [24] 2075 	movx	a,@dptr
      008C4F FF               [12] 2076 	mov	r7,a
      008C50 BF 06 00         [24] 2077 	cjne	r7,#0x06,00128$
      008C53                       2078 00128$:
      008C53 50 23            [24] 2079 	jnc	00102$
      008C55 90 0B 29         [24] 2080 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008C58 E0               [24] 2081 	movx	a,@dptr
      008C59 FE               [12] 2082 	mov	r6,a
      008C5A BE 10 00         [24] 2083 	cjne	r6,#0x10,00130$
      008C5D                       2084 00130$:
      008C5D 50 19            [24] 2085 	jnc	00102$
      008C5F 90 0B 2A         [24] 2086 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008C62 E0               [24] 2087 	movx	a,@dptr
      008C63 FD               [12] 2088 	mov	r5,a
      008C64 BD 08 00         [24] 2089 	cjne	r5,#0x08,00132$
      008C67                       2090 00132$:
      008C67 50 0F            [24] 2091 	jnc	00102$
                                   2092 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008C69 90 0A DD         [24] 2093 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008C6C EE               [12] 2094 	mov	a,r6
      008C6D F0               [24] 2095 	movx	@dptr,a
      008C6E 90 0A DE         [24] 2096 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008C71 ED               [12] 2097 	mov	a,r5
      008C72 F0               [24] 2098 	movx	@dptr,a
      008C73 8F 82            [24] 2099 	mov	dpl, r7
      008C75 02 85 E3         [24] 2100 	ljmp	_dynamic_keymap_get_keycode
      008C78                       2101 00102$:
                                   2102 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008C78 90 00 00         [24] 2103 	mov	dptr,#0x0000
                                   2104 ;	quantum/dynamic_keymap.c:591: }
      008C7B 22               [24] 2105 	ret
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2108 ;------------------------------------------------------------
                                   2109 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2110 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2111 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2112 ;------------------------------------------------------------
                                   2113 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2114 ;	-----------------------------------------
                                   2115 ;	 function keycode_at_encodermap_location
                                   2116 ;	-----------------------------------------
      008C7C                       2117 _keycode_at_encodermap_location:
      008C7C E5 82            [12] 2118 	mov	a,dpl
      008C7E 90 0B 2E         [24] 2119 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008C81 F0               [24] 2120 	movx	@dptr,a
                                   2121 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008C82 E0               [24] 2122 	movx	a,@dptr
      008C83 FF               [12] 2123 	mov	r7,a
      008C84 BF 06 00         [24] 2124 	cjne	r7,#0x06,00120$
      008C87                       2125 00120$:
      008C87 50 1E            [24] 2126 	jnc	00102$
      008C89 90 0B 2C         [24] 2127 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008C8C E0               [24] 2128 	movx	a,@dptr
      008C8D FE               [12] 2129 	mov	r6,a
      008C8E BE 01 00         [24] 2130 	cjne	r6,#0x01,00122$
      008C91                       2131 00122$:
      008C91 50 14            [24] 2132 	jnc	00102$
                                   2133 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008C93 90 0B 2D         [24] 2134 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008C96 E0               [24] 2135 	movx	a,@dptr
      008C97 FE               [12] 2136 	mov	r6,a
      008C98 90 0A E7         [24] 2137 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008C9B E4               [12] 2138 	clr	a
      008C9C F0               [24] 2139 	movx	@dptr,a
      008C9D 90 0A E8         [24] 2140 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008CA0 EE               [12] 2141 	mov	a,r6
      008CA1 F0               [24] 2142 	movx	@dptr,a
      008CA2 8F 82            [24] 2143 	mov	dpl, r7
      008CA4 02 86 A2         [24] 2144 	ljmp	_dynamic_keymap_get_encoder
      008CA7                       2145 00102$:
                                   2146 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008CA7 90 00 00         [24] 2147 	mov	dptr,#0x0000
                                   2148 ;	quantum/dynamic_keymap.c:599: }
      008CAA 22               [24] 2149 	ret
                                   2150 ;------------------------------------------------------------
                                   2151 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2152 ;------------------------------------------------------------
                                   2153 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2154 ;	-----------------------------------------
                                   2155 ;	 function dynamic_keymap_macro_get_count
                                   2156 ;	-----------------------------------------
      008CAB                       2157 _dynamic_keymap_macro_get_count:
                                   2158 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008CAB 75 82 10         [24] 2159 	mov	dpl, #0x10
                                   2160 ;	quantum/dynamic_keymap.c:604: }
      008CAE 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2168 ;	-----------------------------------------
      008CAF                       2169 _dynamic_keymap_macro_get_buffer_size:
                                   2170 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008CAF 90 20 00         [24] 2171 	mov	dptr,#0x2000
                                   2172 ;	quantum/dynamic_keymap.c:608: }
      008CB2 22               [24] 2173 	ret
                                   2174 ;------------------------------------------------------------
                                   2175 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2176 ;------------------------------------------------------------
                                   2177 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2178 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2179 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2180 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2181 ;------------------------------------------------------------
                                   2182 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2183 ;	-----------------------------------------
                                   2184 ;	 function dynamic_keymap_macro_get_buffer
                                   2185 ;	-----------------------------------------
      008CB3                       2186 _dynamic_keymap_macro_get_buffer:
      008CB3 12 38 40         [24] 2187 	lcall	_ak820_outline_0104
      008CB6 90 0B 34         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008CB9 12 38 45         [24] 2189 	lcall	_ak820_outline_0105
                                   2190 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008CBC 12 2A DF         [24] 2191 	lcall	_ak820_macro_length
      008CBF 12 43 8F         [24] 2192 	lcall	_ak820_outline_0132
      008CC2 90 0B 34         [24] 2193 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008CC5 12 38 16         [24] 2194 	lcall	_ak820_outline_0060
      008CC8 90 0B 2F         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008CCB E0               [24] 2196 	movx	a,@dptr
      008CCC F5 32            [12] 2197 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008CCE A3               [24] 2198 	inc	dptr
      008CCF E0               [24] 2199 	movx	a,@dptr
      008CD0 F5 33            [12] 2200 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008CD2 90 0B 31         [24] 2201 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008CD5 12 38 34         [24] 2202 	lcall	_ak820_outline_0100
      008CD8 A3               [24] 2203 	inc	dptr
      008CD9 E0               [24] 2204 	movx	a,@dptr
      008CDA FB               [12] 2205 	mov	r3,a
      008CDB 90 0B 0C         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CDE 12 49 AE         [24] 2207 	lcall	_ak820_outline_0059
      008CE1 90 0B 0E         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CE4 12 38 1C         [24] 2209 	lcall	_ak820_outline_0071
      008CE7 90 0B 10         [24] 2210 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008CEA E5 32            [12] 2211 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008CEC F0               [24] 2212 	movx	@dptr,a
      008CED E5 33            [12] 2213 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008CEF A3               [24] 2214 	inc	dptr
      008CF0 F0               [24] 2215 	movx	@dptr,a
      008CF1 90 0B 12         [24] 2216 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008CF4 E8               [12] 2217 	mov	a,r0
      008CF5 F0               [24] 2218 	movx	@dptr,a
      008CF6 E9               [12] 2219 	mov	a,r1
      008CF7 A3               [24] 2220 	inc	dptr
      008CF8 F0               [24] 2221 	movx	@dptr,a
      008CF9 EB               [12] 2222 	mov	a,r3
      008CFA A3               [24] 2223 	inc	dptr
      008CFB F0               [24] 2224 	movx	@dptr,a
      008CFC 90 08 00         [24] 2225 	mov	dptr,#0x0800
                                   2226 ;	quantum/dynamic_keymap.c:635: }
      008CFF 21 C6            [12] 2227 	ajmp	_ak820_dynamic_read_buffer
                                   2228 ;------------------------------------------------------------
                                   2229 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2230 ;------------------------------------------------------------
                                   2231 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2232 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2233 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2234 ;------------------------------------------------------------
                                   2235 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2236 ;	-----------------------------------------
                                   2237 ;	 function dynamic_keymap_macro_set_buffer
                                   2238 ;	-----------------------------------------
      008D01                       2239 _dynamic_keymap_macro_set_buffer:
      008D01 12 38 40         [24] 2240 	lcall	_ak820_outline_0104
      008D04 90 0B 3B         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008D07 12 38 45         [24] 2242 	lcall	_ak820_outline_0105
                                   2243 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008D0A 90 0B 3B         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008D0D 12 37 F7         [24] 2245 	lcall	_ak820_outline_0051
      008D10 90 0B 36         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008D13 12 38 16         [24] 2247 	lcall	_ak820_outline_0060
      008D16 90 0B 38         [24] 2248 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008D19 12 50 33         [24] 2249 	lcall	_ak820_outline_0087
      008D1C 90 05 10         [24] 2250 	mov	dptr,#_ak820_macro_write_PARM_2
      008D1F 12 38 1C         [24] 2251 	lcall	_ak820_outline_0071
      008D22 90 05 12         [24] 2252 	mov	dptr,#_ak820_macro_write_PARM_3
      008D25 E9               [12] 2253 	mov	a,r1
      008D26 12 50 4C         [24] 2254 	lcall	_ak820_outline_0151
      008D29 12 43 66         [24] 2255 	lcall	_ak820_outline_0061
                                   2256 ;	quantum/dynamic_keymap.c:640: }
      008D2C 02 2A F9         [24] 2257 	ljmp	_ak820_macro_write
                                   2258 ;------------------------------------------------------------
                                   2259 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2260 ;------------------------------------------------------------
                                   2261 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2262 ;	-----------------------------------------
                                   2263 ;	 function dynamic_keymap_macro_reset
                                   2264 ;	-----------------------------------------
      008D2F                       2265 _dynamic_keymap_macro_reset:
                                   2266 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2267 ;	quantum/dynamic_keymap.c:666: }
      008D2F 02 2E 18         [24] 2268 	ljmp	_ak820_macro_reset
                                   2269 ;------------------------------------------------------------
                                   2270 ;Allocation info for local variables in function 'decode_keycode'
                                   2271 ;------------------------------------------------------------
                                   2272 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function decode_keycode
                                   2277 ;	-----------------------------------------
      008D32                       2278 _decode_keycode:
      008D32 12 38 40         [24] 2279 	lcall	_ak820_outline_0104
      008D35 90 0B 3D         [24] 2280 	mov	dptr,#_decode_keycode_kc_10000_455
      008D38 12 38 45         [24] 2281 	lcall	_ak820_outline_0105
                                   2282 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008D3B 90 0B 3D         [24] 2283 	mov	dptr,#_decode_keycode_kc_10000_455
      008D3E 12 37 C2         [24] 2284 	lcall	_ak820_outline_0011
      008D41 C3               [12] 2285 	clr	c
      008D42 E4               [12] 2286 	clr	a
      008D43 9C               [12] 2287 	subb	a,r4
      008D44 74 FF            [12] 2288 	mov	a,#0xff
      008D46 9D               [12] 2289 	subb	a,r5
      008D47 50 08            [24] 2290 	jnc	00102$
                                   2291 ;	free result
                                   2292 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008D49 8C 05            [24] 2293 	mov	ar5,r4
      008D4B 7C 00            [12] 2294 	mov	r4,#0x00
      008D4D 12 38 57         [24] 2295 	lcall	_ak820_outline_0121
      008D50 22               [24] 2296 	ret
      008D51                       2297 00102$:
                                   2298 ;	quantum/dynamic_keymap.c:672: return kc;
      008D51 12 43 84         [24] 2299 	lcall	_ak820_outline_0117
                                   2300 ;	quantum/dynamic_keymap.c:673: }
      008D54 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2304 ;------------------------------------------------------------
                                   2305 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2306 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2307 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2308 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2309 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2310 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2311 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2312 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2313 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2314 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2315 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function dynamic_keymap_macro_send
                                   2321 ;	-----------------------------------------
      008D55                       2322 _dynamic_keymap_macro_send:
      008D55 E5 82            [12] 2323 	mov	a,dpl
      008D57 90 0B 3F         [24] 2324 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D5A F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008D5B 90 0B 40         [24] 2327 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008D5E E0               [24] 2328 	movx	a,@dptr
      008D5F 60 01            [24] 2329 	jz	00102$
      008D61 22               [24] 2330 	ret
      008D62                       2331 00102$:
                                   2332 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008D62 90 0B 3F         [24] 2333 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008D65 E0               [24] 2334 	movx	a,@dptr
      008D66 FF               [12] 2335 	mov	r7,a
      008D67 BF 10 00         [24] 2336 	cjne	r7,#0x10,00422$
      008D6A                       2337 00422$:
      008D6A 40 01            [24] 2338 	jc	00104$
                                   2339 ;	quantum/dynamic_keymap.c:683: return;
      008D6C 22               [24] 2340 	ret
      008D6D                       2341 00104$:
                                   2342 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008D6D C0 07            [24] 2343 	push	ar7
      008D6F 12 2A A6         [24] 2344 	lcall	_ak820_macro_ready
      008D72 E5 82            [12] 2345 	mov	a, dpl
      008D74 D0 07            [24] 2346 	pop	ar7
      008D76 70 01            [24] 2347 	jnz	00106$
      008D78 22               [24] 2348 	ret
      008D79                       2349 00106$:
                                   2350 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008D79 90 0B 41         [24] 2351 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008D7C E4               [12] 2352 	clr	a
      008D7D F0               [24] 2353 	movx	@dptr,a
      008D7E 74 08            [12] 2354 	mov	a,#0x08
      008D80 A3               [24] 2355 	inc	dptr
      008D81 F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008D82 C0 07            [24] 2358 	push	ar7
      008D84 12 2A DF         [24] 2359 	lcall	_ak820_macro_length
      008D87 AD 82            [24] 2360 	mov	r5, dpl
      008D89 AE 83            [24] 2361 	mov	r6, dph
      008D8B D0 07            [24] 2362 	pop	ar7
      008D8D 74 08            [12] 2363 	mov	a,#0x08
      008D8F 2E               [12] 2364 	add	a, r6
      008D90 FE               [12] 2365 	mov	r6,a
                                   2366 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008D91 7B 00            [12] 2367 	mov	r3,#0x00
      008D93 7C 08            [12] 2368 	mov	r4,#0x08
      008D95                       2369 00111$:
      008D95 EF               [12] 2370 	mov	a,r7
      008D96 60 31            [24] 2371 	jz	00113$
                                   2372 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008D98 EB               [12] 2373 	mov	a,r3
      008D99 B5 05 05         [24] 2374 	cjne	a,ar5,00108$
      008D9C EC               [12] 2375 	mov	a,r4
      008D9D B5 06 01         [24] 2376 	cjne	a,ar6,00108$
                                   2377 ;	quantum/dynamic_keymap.c:717: return;
      008DA0 22               [24] 2378 	ret
      008DA1                       2379 00108$:
                                   2380 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008DA1 8B 01            [24] 2381 	mov	ar1,r3
      008DA3 8C 02            [24] 2382 	mov	ar2,r4
      008DA5 8A 00            [24] 2383 	mov	ar0,r2
      008DA7 7A 00            [12] 2384 	mov	r2,#0x00
      008DA9 89 82            [24] 2385 	mov	dpl, r1
      008DAB 88 83            [24] 2386 	mov	dph, r0
      008DAD 8A F0            [24] 2387 	mov	b, r2
      008DAF 12 40 A3         [24] 2388 	lcall	_eeprom_read_byte
      008DB2 E5 82            [12] 2389 	mov	a, dpl
      008DB4 70 06            [24] 2390 	jnz	00110$
                                   2391 ;	quantum/dynamic_keymap.c:720: --id;
      008DB6 1F               [12] 2392 	dec	r7
      008DB7 90 0B 3F         [24] 2393 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008DBA EF               [12] 2394 	mov	a,r7
      008DBB F0               [24] 2395 	movx	@dptr,a
      008DBC                       2396 00110$:
                                   2397 ;	quantum/dynamic_keymap.c:722: ++p;
      008DBC 0B               [12] 2398 	inc	r3
      008DBD BB 00 01         [24] 2399 	cjne	r3,#0x00,00429$
      008DC0 0C               [12] 2400 	inc	r4
      008DC1                       2401 00429$:
      008DC1 90 0B 41         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DC4 12 38 22         [24] 2403 	lcall	_ak820_outline_0076
      008DC7 80 CC            [24] 2404 	sjmp	00111$
      008DC9                       2405 00113$:
                                   2406 ;	quantum/dynamic_keymap.c:728: sending = true;
      008DC9 90 0B 40         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008DCC 74 01            [12] 2408 	mov	a,#0x01
      008DCE F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008DCF 12 90 76         [24] 2411 	lcall	_ak820_outline_0160
      008DD2 90 09 89         [24] 2412 	mov	dptr,#_ak820_macro_cancelled
      008DD5 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008DD6 90 0B 43         [24] 2415 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008DD9 F0               [24] 2416 	movx	@dptr,a
      008DDA 90 0B 44         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008DDD F0               [24] 2418 	movx	@dptr,a
      008DDE 90 0B 45         [24] 2419 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008DE1 F0               [24] 2420 	movx	@dptr,a
      008DE2 90 0B 46         [24] 2421 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008DE5 F0               [24] 2422 	movx	@dptr,a
                                   2423 ;	quantum/dynamic_keymap.c:738: while (p < end
      008DE6                       2424 00167$:
                                   2425 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008DE6 90 0B 41         [24] 2426 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008DE9 E0               [24] 2427 	movx	a,@dptr
      008DEA FC               [12] 2428 	mov	r4,a
      008DEB A3               [24] 2429 	inc	dptr
      008DEC E0               [24] 2430 	movx	a,@dptr
      008DED FF               [12] 2431 	mov	r7,a
      008DEE C3               [12] 2432 	clr	c
      008DEF EC               [12] 2433 	mov	a,r4
      008DF0 9D               [12] 2434 	subb	a,r5
      008DF1 EF               [12] 2435 	mov	a,r7
      008DF2 9E               [12] 2436 	subb	a,r6
      008DF3 40 03            [24] 2437 	jc	00430$
      008DF5 02 90 04         [24] 2438 	ljmp	00169$
      008DF8                       2439 00430$:
      008DF8 90 09 89         [24] 2440 	mov	dptr,#_ak820_macro_cancelled
      008DFB E0               [24] 2441 	movx	a,@dptr
      008DFC 60 03            [24] 2442 	jz	00431$
      008DFE 02 90 04         [24] 2443 	ljmp	00169$
      008E01                       2444 00431$:
                                   2445 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E01 8C 02            [24] 2446 	mov	ar2,r4
      008E03 8F 03            [24] 2447 	mov	ar3,r7
      008E05 90 0B 41         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E08 74 01            [12] 2449 	mov	a,#0x01
      008E0A 2C               [12] 2450 	add	a, r4
      008E0B F0               [24] 2451 	movx	@dptr,a
      008E0C E4               [12] 2452 	clr	a
      008E0D 3F               [12] 2453 	addc	a, r7
      008E0E A3               [24] 2454 	inc	dptr
      008E0F F0               [24] 2455 	movx	@dptr,a
      008E10 7F 00            [12] 2456 	mov	r7,#0x00
      008E12 12 43 A0         [24] 2457 	lcall	_ak820_outline_0140
      008E15 8F F0            [24] 2458 	mov	b, r7
      008E17 12 40 A3         [24] 2459 	lcall	_eeprom_read_byte
      008E1A AF 82            [24] 2460 	mov	r7, dpl
      008E1C 90 0B 43         [24] 2461 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E1F EF               [12] 2462 	mov	a,r7
      008E20 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008E21 90 0B 44         [24] 2465 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E24 E4               [12] 2466 	clr	a
      008E25 F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008E26 90 0B 43         [24] 2469 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E29 E0               [24] 2470 	movx	a,@dptr
      008E2A 70 03            [24] 2471 	jnz	00432$
      008E2C 02 90 04         [24] 2472 	ljmp	00169$
      008E2F                       2473 00432$:
                                   2474 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008E2F 90 0B 43         [24] 2475 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E32 E0               [24] 2476 	movx	a,@dptr
      008E33 FF               [12] 2477 	mov	r7,a
      008E34 BF 01 02         [24] 2478 	cjne	r7,#0x01,00433$
      008E37 80 03            [24] 2479 	sjmp	00434$
      008E39                       2480 00433$:
      008E39 02 8F E6         [24] 2481 	ljmp	00164$
      008E3C                       2482 00434$:
                                   2483 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E3C 12 90 0C         [24] 2484 	lcall	_ak820_outline_0000
      008E3F 12 40 A3         [24] 2485 	lcall	_eeprom_read_byte
      008E42 AF 82            [24] 2486 	mov	r7, dpl
      008E44 90 0B 44         [24] 2487 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E47 EF               [12] 2488 	mov	a,r7
      008E48 F0               [24] 2489 	movx	@dptr,a
                                   2490 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008E49 EF               [12] 2491 	mov	a,r7
      008E4A 70 03            [24] 2492 	jnz	00435$
      008E4C 02 90 04         [24] 2493 	ljmp	00169$
      008E4F                       2494 00435$:
                                   2495 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008E4F 12 90 44         [24] 2496 	lcall	_ak820_outline_0089
      008E52 BF 01 02         [24] 2497 	cjne	r7,#0x01,00436$
      008E55 80 12            [24] 2498 	sjmp	00151$
      008E57                       2499 00436$:
      008E57 12 90 44         [24] 2500 	lcall	_ak820_outline_0089
      008E5A BF 02 02         [24] 2501 	cjne	r7,#0x02,00437$
      008E5D 80 0A            [24] 2502 	sjmp	00151$
      008E5F                       2503 00437$:
      008E5F 12 90 44         [24] 2504 	lcall	_ak820_outline_0089
      008E62 BF 03 02         [24] 2505 	cjne	r7,#0x03,00438$
      008E65 80 02            [24] 2506 	sjmp	00439$
      008E67                       2507 00438$:
      008E67 C1 C8            [12] 2508 	ajmp	00152$
      008E69                       2509 00439$:
      008E69                       2510 00151$:
                                   2511 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E69 12 90 0C         [24] 2512 	lcall	_ak820_outline_0000
      008E6C 12 40 A3         [24] 2513 	lcall	_eeprom_read_byte
      008E6F 12 90 8E         [24] 2514 	lcall	_ak820_outline_0179
                                   2515 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008E72 70 02            [24] 2516 	jnz	00440$
      008E74 A1 E6            [12] 2517 	ajmp	00167$
      008E76                       2518 00440$:
                                   2519 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008E76 12 90 44         [24] 2520 	lcall	_ak820_outline_0089
      008E79 BF 01 03         [24] 2521 	cjne	r7,#0x01,00441$
      008E7C D3               [12] 2522 	setb	c
      008E7D 80 01            [24] 2523 	sjmp	00442$
      008E7F                       2524 00441$:
      008E7F C3               [12] 2525 	clr	c
      008E80                       2526 00442$:
      008E80 92 26            [24] 2527 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008E82 90 09 88         [24] 2528 	mov	dptr,#_ak820_macro_primitive
      008E85 B3               [12] 2529 	cpl	c
      008E86 E4               [12] 2530 	clr	a
      008E87 33               [12] 2531 	rlc	a
      008E88 F0               [24] 2532 	movx	@dptr,a
                                   2533 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008E89 12 90 44         [24] 2534 	lcall	_ak820_outline_0089
      008E8C BF 01 10         [24] 2535 	cjne	r7,#0x01,00122$
      008E8F 12 90 6F         [24] 2536 	lcall	_ak820_outline_0147
      008E92 C0 06            [24] 2537 	push	ar6
      008E94 C0 05            [24] 2538 	push	ar5
      008E96 12 77 5D         [24] 2539 	lcall	_tap_code
      008E99 D0 05            [24] 2540 	pop	ar5
      008E9B D0 06            [24] 2541 	pop	ar6
      008E9D 80 24            [24] 2542 	sjmp	00123$
      008E9F                       2543 00122$:
                                   2544 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008E9F 12 90 44         [24] 2545 	lcall	_ak820_outline_0089
      008EA2 BF 02 10         [24] 2546 	cjne	r7,#0x02,00119$
      008EA5 12 90 6F         [24] 2547 	lcall	_ak820_outline_0147
      008EA8 C0 06            [24] 2548 	push	ar6
      008EAA C0 05            [24] 2549 	push	ar5
      008EAC 12 76 59         [24] 2550 	lcall	_register_code
      008EAF D0 05            [24] 2551 	pop	ar5
      008EB1 D0 06            [24] 2552 	pop	ar6
      008EB3 80 0E            [24] 2553 	sjmp	00123$
      008EB5                       2554 00119$:
                                   2555 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008EB5 12 90 6F         [24] 2556 	lcall	_ak820_outline_0147
      008EB8 C0 06            [24] 2557 	push	ar6
      008EBA C0 05            [24] 2558 	push	ar5
      008EBC 12 76 C6         [24] 2559 	lcall	_unregister_code
      008EBF D0 05            [24] 2560 	pop	ar5
      008EC1 D0 06            [24] 2561 	pop	ar6
      008EC3                       2562 00123$:
                                   2563 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008EC3 12 90 76         [24] 2564 	lcall	_ak820_outline_0160
      008EC6 A1 E6            [12] 2565 	ajmp	00167$
      008EC8                       2566 00152$:
                                   2567 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008EC8 12 90 44         [24] 2568 	lcall	_ak820_outline_0089
      008ECB BF 05 02         [24] 2569 	cjne	r7,#0x05,00447$
      008ECE 80 13            [24] 2570 	sjmp	00146$
      008ED0                       2571 00447$:
      008ED0 12 90 44         [24] 2572 	lcall	_ak820_outline_0089
      008ED3 BF 06 02         [24] 2573 	cjne	r7,#0x06,00448$
      008ED6 80 0B            [24] 2574 	sjmp	00146$
      008ED8                       2575 00448$:
      008ED8 12 90 44         [24] 2576 	lcall	_ak820_outline_0089
      008EDB BF 07 02         [24] 2577 	cjne	r7,#0x07,00449$
      008EDE 80 03            [24] 2578 	sjmp	00450$
      008EE0                       2579 00449$:
      008EE0 02 8F 86         [24] 2580 	ljmp	00147$
      008EE3                       2581 00450$:
      008EE3                       2582 00146$:
                                   2583 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EE3 12 90 0C         [24] 2584 	lcall	_ak820_outline_0000
      008EE6 12 40 A3         [24] 2585 	lcall	_eeprom_read_byte
      008EE9 12 90 8E         [24] 2586 	lcall	_ak820_outline_0179
                                   2587 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008EEC 70 02            [24] 2588 	jnz	00451$
      008EEE A1 E6            [12] 2589 	ajmp	00167$
      008EF0                       2590 00451$:
                                   2591 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EF0 12 90 0C         [24] 2592 	lcall	_ak820_outline_0000
      008EF3 12 40 A3         [24] 2593 	lcall	_eeprom_read_byte
      008EF6 AF 82            [24] 2594 	mov	r7, dpl
      008EF8 90 0B 46         [24] 2595 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008EFB EF               [12] 2596 	mov	a,r7
      008EFC F0               [24] 2597 	movx	@dptr,a
                                   2598 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008EFD EF               [12] 2599 	mov	a,r7
      008EFE 70 02            [24] 2600 	jnz	00452$
      008F00 A1 E6            [12] 2601 	ajmp	00167$
      008F02                       2602 00452$:
                                   2603 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008F02 90 0B 45         [24] 2604 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008F05 E0               [24] 2605 	movx	a,@dptr
      008F06 FF               [12] 2606 	mov	r7,a
      008F07 90 0B 46         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008F0A E0               [24] 2608 	movx	a,@dptr
      008F0B FB               [12] 2609 	mov	r3,a
      008F0C E4               [12] 2610 	clr	a
      008F0D FC               [12] 2611 	mov	r4,a
      008F0E FA               [12] 2612 	mov	r2,a
      008F0F EF               [12] 2613 	mov	a,r7
      008F10 42 04            [12] 2614 	orl	ar4,a
      008F12 EA               [12] 2615 	mov	a,r2
      008F13 42 03            [12] 2616 	orl	ar3,a
                                   2617 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008F15 12 43 C0         [24] 2618 	lcall	_ak820_outline_0182
      008F18 C0 06            [24] 2619 	push	ar6
      008F1A C0 05            [24] 2620 	push	ar5
      008F1C B1 32            [12] 2621 	acall	_decode_keycode
      008F1E AC 82            [24] 2622 	mov	r4, dpl
      008F20 AF 83            [24] 2623 	mov	r7, dph
      008F22 D0 05            [24] 2624 	pop	ar5
      008F24 D0 06            [24] 2625 	pop	ar6
                                   2626 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008F26 90 0B 44         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008F29 E0               [24] 2628 	movx	a,@dptr
      008F2A FB               [12] 2629 	mov	r3,a
      008F2B BB 05 03         [24] 2630 	cjne	r3,#0x05,00453$
      008F2E D3               [12] 2631 	setb	c
      008F2F 80 01            [24] 2632 	sjmp	00454$
      008F31                       2633 00453$:
      008F31 C3               [12] 2634 	clr	c
      008F32                       2635 00454$:
      008F32 92 26            [24] 2636 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008F34 90 09 88         [24] 2637 	mov	dptr,#_ak820_macro_primitive
      008F37 B3               [12] 2638 	cpl	c
      008F38 E4               [12] 2639 	clr	a
      008F39 33               [12] 2640 	rlc	a
      008F3A F0               [24] 2641 	movx	@dptr,a
                                   2642 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008F3B 90 0B 44         [24] 2643 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008F3E E0               [24] 2644 	movx	a,@dptr
      008F3F FB               [12] 2645 	mov	r3,a
      008F40 BB 05 02         [24] 2646 	cjne	r3,#0x05,00455$
      008F43 80 0A            [24] 2647 	sjmp	00126$
      008F45                       2648 00455$:
      008F45 BB 06 02         [24] 2649 	cjne	r3,#0x06,00456$
      008F48 80 16            [24] 2650 	sjmp	00127$
      008F4A                       2651 00456$:
                                   2652 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008F4A BB 07 33         [24] 2653 	cjne	r3,#0x07,00129$
      008F4D 80 22            [24] 2654 	sjmp	00128$
      008F4F                       2655 00126$:
                                   2656 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008F4F 8C 82            [24] 2657 	mov	dpl, r4
      008F51 8F 83            [24] 2658 	mov	dph, r7
      008F53 C0 06            [24] 2659 	push	ar6
      008F55 C0 05            [24] 2660 	push	ar5
      008F57 12 B2 9E         [24] 2661 	lcall	_vial_keycode_tap
      008F5A D0 05            [24] 2662 	pop	ar5
      008F5C D0 06            [24] 2663 	pop	ar6
                                   2664 ;	quantum/dynamic_keymap.c:795: break;
                                   2665 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008F5E 80 20            [24] 2666 	sjmp	00129$
      008F60                       2667 00127$:
                                   2668 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008F60 8C 82            [24] 2669 	mov	dpl, r4
      008F62 8F 83            [24] 2670 	mov	dph, r7
      008F64 C0 06            [24] 2671 	push	ar6
      008F66 C0 05            [24] 2672 	push	ar5
      008F68 12 B1 D3         [24] 2673 	lcall	_vial_keycode_down
      008F6B D0 05            [24] 2674 	pop	ar5
      008F6D D0 06            [24] 2675 	pop	ar6
                                   2676 ;	quantum/dynamic_keymap.c:798: break;
                                   2677 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008F6F 80 0F            [24] 2678 	sjmp	00129$
      008F71                       2679 00128$:
                                   2680 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008F71 8C 82            [24] 2681 	mov	dpl, r4
      008F73 8F 83            [24] 2682 	mov	dph, r7
      008F75 C0 06            [24] 2683 	push	ar6
      008F77 C0 05            [24] 2684 	push	ar5
      008F79 12 B2 39         [24] 2685 	lcall	_vial_keycode_up
      008F7C D0 05            [24] 2686 	pop	ar5
      008F7E D0 06            [24] 2687 	pop	ar6
                                   2688 ;	quantum/dynamic_keymap.c:802: }
      008F80                       2689 00129$:
                                   2690 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      008F80 12 90 76         [24] 2691 	lcall	_ak820_outline_0160
      008F83 02 8D E6         [24] 2692 	ljmp	00167$
      008F86                       2693 00147$:
                                   2694 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      008F86 12 90 44         [24] 2695 	lcall	_ak820_outline_0089
      008F89 BF 04 02         [24] 2696 	cjne	r7,#0x04,00458$
      008F8C 80 03            [24] 2697 	sjmp	00459$
      008F8E                       2698 00458$:
      008F8E 02 8D E6         [24] 2699 	ljmp	00167$
      008F91                       2700 00459$:
                                   2701 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F91 12 90 0C         [24] 2702 	lcall	_ak820_outline_0000
      008F94 12 40 A3         [24] 2703 	lcall	_eeprom_read_byte
      008F97 AF 82            [24] 2704 	mov	r7, dpl
                                   2705 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F99 90 0B 41         [24] 2706 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008F9C 12 38 3A         [24] 2707 	lcall	_ak820_outline_0101
      008F9F 90 0B 41         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FA2 74 01            [12] 2709 	mov	a,#0x01
      008FA4 2B               [12] 2710 	add	a, r3
      008FA5 F0               [24] 2711 	movx	@dptr,a
      008FA6 E4               [12] 2712 	clr	a
      008FA7 3C               [12] 2713 	addc	a, r4
      008FA8 A3               [24] 2714 	inc	dptr
      008FA9 F0               [24] 2715 	movx	@dptr,a
      008FAA 7A 00            [12] 2716 	mov	r2,#0x00
      008FAC 12 33 FC         [24] 2717 	lcall	_ak820_outline_0122
      008FAF 8A F0            [24] 2718 	mov	b, r2
      008FB1 12 40 A3         [24] 2719 	lcall	_eeprom_read_byte
      008FB4 AC 82            [24] 2720 	mov	r4, dpl
                                   2721 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      008FB6 EF               [12] 2722 	mov	a,r7
      008FB7 60 4B            [24] 2723 	jz	00169$
      008FB9 EC               [12] 2724 	mov	a,r4
      008FBA 60 48            [24] 2725 	jz	00169$
                                   2726 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008FBC 1F               [12] 2727 	dec	r7
      008FBD 1C               [12] 2728 	dec	r4
      008FBE EC               [12] 2729 	mov	a,r4
      008FBF 75 F0 FF         [24] 2730 	mov	b,#0xff
      008FC2 A4               [48] 2731 	mul	ab
      008FC3 FC               [12] 2732 	mov	r4,a
      008FC4 AB F0            [24] 2733 	mov	r3,b
      008FC6 7A 00            [12] 2734 	mov	r2,#0x00
      008FC8 EC               [12] 2735 	mov	a,r4
      008FC9 2F               [12] 2736 	add	a, r7
      008FCA FC               [12] 2737 	mov	r4,a
      008FCB EB               [12] 2738 	mov	a,r3
      008FCC 3A               [12] 2739 	addc	a, r2
      008FCD FB               [12] 2740 	mov	r3,a
                                   2741 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      008FCE                       2742 00141$:
      008FCE 8C 02            [24] 2743 	mov	ar2,r4
      008FD0 8B 07            [24] 2744 	mov	ar7,r3
      008FD2 1C               [12] 2745 	dec	r4
      008FD3 BC FF 01         [24] 2746 	cjne	r4,#0xff,00462$
      008FD6 1B               [12] 2747 	dec	r3
      008FD7                       2748 00462$:
      008FD7 EA               [12] 2749 	mov	a,r2
      008FD8 4F               [12] 2750 	orl	a,r7
      008FD9 70 03            [24] 2751 	jnz	00463$
      008FDB 02 8D E6         [24] 2752 	ljmp	00167$
      008FDE                       2753 00463$:
      008FDE 90 00 01         [24] 2754 	mov	dptr,#0x0001
      008FE1 12 59 9E         [24] 2755 	lcall	_mDelaymS
      008FE4 80 E8            [24] 2756 	sjmp	00141$
      008FE6                       2757 00164$:
                                   2758 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      008FE6 90 0B 43         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008FE9 E0               [24] 2760 	movx	a,@dptr
      008FEA FF               [12] 2761 	mov	r7,a
      008FEB BF 80 00         [24] 2762 	cjne	r7,#0x80,00464$
      008FEE                       2763 00464$:
      008FEE 50 14            [24] 2764 	jnc	00169$
                                   2765 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      008FF0 90 0B 43         [24] 2766 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008FF3 E0               [24] 2767 	movx	a,@dptr
      008FF4 F5 82            [12] 2768 	mov	dpl,a
      008FF6 C0 06            [24] 2769 	push	ar6
      008FF8 C0 05            [24] 2770 	push	ar5
      008FFA 12 A5 60         [24] 2771 	lcall	_send_char
      008FFD D0 05            [24] 2772 	pop	ar5
      008FFF D0 06            [24] 2773 	pop	ar6
                                   2774 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009001 02 8D E6         [24] 2775 	ljmp	00167$
      009004                       2776 00169$:
                                   2777 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009004 12 90 76         [24] 2778 	lcall	_ak820_outline_0160
                                   2779 ;	quantum/dynamic_keymap.c:837: sending = false;
      009007 90 0B 40         [24] 2780 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      00900A F0               [24] 2781 	movx	@dptr,a
                                   2782 ;	quantum/dynamic_keymap.c:839: }
      00900B 22               [24] 2783 	ret
                                   2784 	.area CSEG    (CODE)
                                   2785 	.area CONST   (CODE)
                                   2786 	.area XINIT   (CODE)
                                   2787 	.area CABS    (ABS,CODE)
                                   2788 
                                   2789 ; Experimental exact instruction outlining.
                                   2790 	.globl _ak820_outline_0000
                                   2791 	.globl _ak820_outline_0004
                                   2792 	.globl _ak820_outline_0011
                                   2793 	.globl _ak820_outline_0012
                                   2794 	.globl _ak820_outline_0017
                                   2795 	.globl _ak820_outline_0025
                                   2796 	.globl _ak820_outline_0031
                                   2797 	.globl _ak820_outline_0044
                                   2798 	.globl _ak820_outline_0051
                                   2799 	.globl _ak820_outline_0057
                                   2800 	.globl _ak820_outline_0059
                                   2801 	.globl _ak820_outline_0060
                                   2802 	.globl _ak820_outline_0061
                                   2803 	.globl _ak820_outline_0071
                                   2804 	.globl _ak820_outline_0076
                                   2805 	.globl _ak820_outline_0078
                                   2806 	.globl _ak820_outline_0087
                                   2807 	.globl _ak820_outline_0089
                                   2808 	.globl _ak820_outline_0095
                                   2809 	.globl _ak820_outline_0096
                                   2810 	.globl _ak820_outline_0100
                                   2811 	.globl _ak820_outline_0101
                                   2812 	.globl _ak820_outline_0104
                                   2813 	.globl _ak820_outline_0105
                                   2814 	.globl _ak820_outline_0113
                                   2815 	.globl _ak820_outline_0117
                                   2816 	.globl _ak820_outline_0118
                                   2817 	.globl _ak820_outline_0120
                                   2818 	.globl _ak820_outline_0121
                                   2819 	.globl _ak820_outline_0122
                                   2820 	.globl _ak820_outline_0123
                                   2821 	.globl _ak820_outline_0127
                                   2822 	.globl _ak820_outline_0131
                                   2823 	.globl _ak820_outline_0132
                                   2824 	.globl _ak820_outline_0133
                                   2825 	.globl _ak820_outline_0134
                                   2826 	.globl _ak820_outline_0139
                                   2827 	.globl _ak820_outline_0140
                                   2828 	.globl _ak820_outline_0145
                                   2829 	.globl _ak820_outline_0147
                                   2830 	.globl _ak820_outline_0151
                                   2831 	.globl _ak820_outline_0152
                                   2832 	.globl _ak820_outline_0155
                                   2833 	.globl _ak820_outline_0160
                                   2834 	.globl _ak820_outline_0175
                                   2835 	.globl _ak820_outline_0176
                                   2836 	.globl _ak820_outline_0179
                                   2837 	.globl _ak820_outline_0180
                                   2838 	.globl _ak820_outline_0181
                                   2839 	.globl _ak820_outline_0182
                                   2840 
                                   2841 	.area CSEG (CODE)
                                   2842 ; function ak820_outline_0000
      00900C                       2843 _ak820_outline_0000:
      00900C 90 0B 41         [24] 2844 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00900F E0               [24] 2845 	movx	a,@dptr
      009010 FC               [12] 2846 	mov	r4,a
      009011 A3               [24] 2847 	inc	dptr
      009012 E0               [24] 2848 	movx	a,@dptr
      009013 FF               [12] 2849 	mov	r7,a
      009014 90 0B 41         [24] 2850 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009017 74 01            [12] 2851 	mov	a,#0x01
      009019 2C               [12] 2852 	add	a,r4
      00901A F0               [24] 2853 	movx	@dptr,a
      00901B E4               [12] 2854 	clr	a
      00901C 3F               [12] 2855 	addc	a,r7
      00901D A3               [24] 2856 	inc	dptr
      00901E F0               [24] 2857 	movx	@dptr,a
      00901F 7B 00            [12] 2858 	mov	r3,#0x00
      009021 8C 82            [24] 2859 	mov	dpl,r4
      009023 8F 83            [24] 2860 	mov	dph,r7
      009025 8B F0            [24] 2861 	mov	b,r3
      009027 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0025
      009028                       2866 _ak820_outline_0025:
      009028 2D               [12] 2867 	add	a,r5
      009029 F9               [12] 2868 	mov	r1,a
      00902A E4               [12] 2869 	clr	a
      00902B 3E               [12] 2870 	addc	a,r6
      00902C FA               [12] 2871 	mov	r2,a
      00902D 8F 03            [24] 2872 	mov	ar3,r7
      00902F 89 82            [24] 2873 	mov	dpl,r1
      009031 8A 83            [24] 2874 	mov	dph,r2
      009033 8B F0            [24] 2875 	mov	b,r3
      009035 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0078
      009036                       2880 _ak820_outline_0078:
      009036 ED               [12] 2881 	mov	a,r5
      009037 75 F0 0A         [24] 2882 	mov	b,#0x0a
      00903A A4               [48] 2883 	mul	ab
      00903B 24 58            [12] 2884 	add	a,#0x58
      00903D FC               [12] 2885 	mov	r4,a
      00903E 74 06            [12] 2886 	mov	a,#0x06
      009040 35 F0            [12] 2887 	addc	a,b
      009042 FD               [12] 2888 	mov	r5,a
      009043 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0089
      009044                       2893 _ak820_outline_0089:
      009044 90 0B 44         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      009047 E0               [24] 2895 	movx	a,@dptr
      009048 FF               [12] 2896 	mov	r7,a
      009049 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0095
      00904A                       2901 _ak820_outline_0095:
      00904A 90 0A DA         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00904D EE               [12] 2903 	mov	a,r6
      00904E F0               [24] 2904 	movx	@dptr,a
      00904F 90 0A DB         [24] 2905 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009052 ED               [12] 2906 	mov	a,r5
      009053 F0               [24] 2907 	movx	@dptr,a
      009054 8F 82            [24] 2908 	mov	dpl,r7
      009056 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0113
      009057                       2913 _ak820_outline_0113:
      009057 AD 82            [24] 2914 	mov	r5,dpl
      009059 AE 83            [24] 2915 	mov	r6,dph
      00905B AF F0            [24] 2916 	mov	r7,b
      00905D 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0127
      00905E                       2921 _ak820_outline_0127:
      00905E 28               [12] 2922 	add	a,r0
      00905F F5 82            [12] 2923 	mov	dpl,a
      009061 EF               [12] 2924 	mov	a,r7
      009062 39               [12] 2925 	addc	a,r1
      009063 F5 83            [12] 2926 	mov	dph,a
      009065 74 FF            [12] 2927 	mov	a,#0xff
      009067 F0               [24] 2928 	movx	@dptr,a
      009068 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0133
      009069                       2933 _ak820_outline_0133:
      009069 2D               [12] 2934 	add	a,r5
      00906A F9               [12] 2935 	mov	r1,a
      00906B E4               [12] 2936 	clr	a
      00906C 3E               [12] 2937 	addc	a,r6
      00906D FA               [12] 2938 	mov	r2,a
      00906E 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0147
      00906F                       2943 _ak820_outline_0147:
      00906F 90 0B 45         [24] 2944 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009072 E0               [24] 2945 	movx	a,@dptr
      009073 F5 82            [12] 2946 	mov	dpl,a
      009075 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0160
      009076                       2951 _ak820_outline_0160:
      009076 90 09 88         [24] 2952 	mov	dptr,#_ak820_macro_primitive
      009079 E4               [12] 2953 	clr	a
      00907A F0               [24] 2954 	movx	@dptr,a
      00907B 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0175
      00907C                       2959 _ak820_outline_0175:
      00907C 90 0A EA         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00907F E4               [12] 2961 	clr	a
      009080 F0               [24] 2962 	movx	@dptr,a
      009081 90 0A EB         [24] 2963 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009084 22               [24] 2964 	ret
                                   2965 
                                   2966 	.area CSEG (CODE)
                                   2967 ; function ak820_outline_0176
      009085                       2968 _ak820_outline_0176:
      009085 90 0B A0         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009088 E4               [12] 2970 	clr	a
      009089 F0               [24] 2971 	movx	@dptr,a
      00908A 90 0B A1         [24] 2972 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      00908D 22               [24] 2973 	ret
                                   2974 
                                   2975 	.area CSEG (CODE)
                                   2976 ; function ak820_outline_0179
      00908E                       2977 _ak820_outline_0179:
      00908E AF 82            [24] 2978 	mov	r7,dpl
      009090 90 0B 45         [24] 2979 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009093 EF               [12] 2980 	mov	a,r7
      009094 F0               [24] 2981 	movx	@dptr,a
      009095 EF               [12] 2982 	mov	a,r7
      009096 22               [24] 2983 	ret
