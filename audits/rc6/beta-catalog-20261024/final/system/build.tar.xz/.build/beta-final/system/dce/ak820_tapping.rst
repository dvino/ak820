                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005A2                        562 _source_state:
      0005A2                        563 	.ds 130
      000624                        564 _pending_time:
      000624                        565 	.ds 2
      000626                        566 _pending_code:
      000626                        567 	.ds 2
      000628                        568 _ak820_tapping_source_PARM_1:
      000628                        569 	.ds 2
      00062A                        570 _hold_PARM_2:
      00062A                        571 	.ds 1
      00062B                        572 _hold_code_10000_602:
      00062B                        573 	.ds 2
      00062D                        574 _hold_mods_30000_605:
      00062D                        575 	.ds 1
      00062E                        576 _commit_pending_id_10000_611:
      00062E                        577 	.ds 1
      00062F                        578 _ak820_tapping_before_event_10000_612:
      00062F                        579 	.ds 2
      000631                        580 _ak820_tapping_process_record_10000_623:
      000631                        581 	.ds 2
      000633                        582 _ak820_tapping_process_code_10000_624:
      000633                        583 	.ds 2
      000635                        584 _ak820_tapping_process_sc_mods_10000_624:
      000635                        585 	.ds 1
      000636                        586 _ak820_oneshot_mods::
      000636                        587 	.ds 1
      000637                        588 _ak820_oneshot_consumed::
      000637                        589 	.ds 1
      000638                        590 _ak820_oneshot_process_PARM_2:
      000638                        591 	.ds 1
      000639                        592 _ak820_oneshot_process_PARM_3:
      000639                        593 	.ds 1
      00063A                        594 _ak820_oneshot_process_code_10000_649:
      00063A                        595 	.ds 2
      00063C                        596 _ak820_oneshot_process_mods_10000_650:
      00063C                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D8C                        606 _pending:
      000D8C                        607 	.ds 1
      000D8D                        608 _ak820_oneshot_target::
      000D8D                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      00448A                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00448A 90 06 29         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00448D E0               [24]  656 	movx	a,@dptr
      00448E FF               [12]  657 	mov	r7,a
      00448F BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004492                        659 00147$:
      004492 50 14            [24]  660 	jnc	00102$
      004494 90 06 28         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004497 E0               [24]  662 	movx	a,@dptr
      004498 FE               [12]  663 	mov	r6,a
      004499 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      00449C                        665 00149$:
      00449C 50 0A            [24]  666 	jnc	00102$
      00449E 8F 05            [24]  667 	mov	ar5,r7
      0044A0 ED               [12]  668 	mov	a,r5
      0044A1 12 38 87         [24]  669 	lcall	_ak820_outline_0185
      0044A4 2E               [12]  670 	add	a,r6
      0044A5 F5 82            [12]  671 	mov	dpl,a
      0044A7 22               [24]  672 	ret
      0044A8                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0044A8 90 06 28         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0044AB E0               [24]  676 	movx	a,@dptr
      0044AC FE               [12]  677 	mov	r6,a
      0044AD BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0044B0                        679 00151$:
      0044B0 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0044B2 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0044B5 75 82 80         [24]  683 	mov	dpl, #0x80
      0044B8 22               [24]  684 	ret
      0044B9                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0044B9 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0044BC 75 82 81         [24]  688 	mov	dpl, #0x81
      0044BF 22               [24]  689 	ret
      0044C0                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      0044C0 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      0044C3 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0044C4                        707 _hold:
      0044C4 12 38 40         [24]  708 	lcall	_ak820_outline_0104
      0044C7 90 06 2B         [24]  709 	mov	dptr,#_hold_code_10000_602
      0044CA 12 38 45         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      0044CD 90 06 2B         [24]  712 	mov	dptr,#_hold_code_10000_602
      0044D0 12 37 C2         [24]  713 	lcall	_ak820_outline_0011
      0044D3 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0044D5 2D               [12]  715 	add	a,r5
      0044D6 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      0044D8 8F 05            [24]  718 	mov	ar5,r7
      0044DA 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0044DD 90 06 2D         [24]  720 	mov	dptr,#_hold_mods_30000_605
      0044E0 ED               [12]  721 	mov	a,r5
      0044E1 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      0044E2 ED               [12]  724 	mov	a,r5
      0044E3 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0044E6 ED               [12]  726 	mov	a,r5
      0044E7 C4               [12]  727 	swap	a
      0044E8 54 F0            [12]  728 	anl	a,#0xf0
      0044EA 90 06 2D         [24]  729 	mov	dptr,#_hold_mods_30000_605
      0044ED F0               [24]  730 	movx	@dptr,a
      0044EE                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      0044EE 90 06 2A         [24]  733 	mov	dptr,#_hold_PARM_2
      0044F1 E0               [24]  734 	movx	a,@dptr
      0044F2 60 09            [24]  735 	jz	00104$
      0044F4 90 06 2D         [24]  736 	mov	dptr,#_hold_mods_30000_605
      0044F7 E0               [24]  737 	movx	a,@dptr
      0044F8 F5 82            [12]  738 	mov	dpl,a
      0044FA 02 77 79         [24]  739 	ljmp	_register_mods
      0044FD                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      0044FD 90 06 2D         [24]  742 	mov	dptr,#_hold_mods_30000_605
      004500 E0               [24]  743 	movx	a,@dptr
      004501 F5 82            [12]  744 	mov	dpl,a
      004503 02 77 8D         [24]  745 	ljmp	_unregister_mods
      004506                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004506 8F 06            [24]  748 	mov	ar6,r7
      004508 74 0F            [12]  749 	mov	a,#0x0f
      00450A 5E               [12]  750 	anl	a,r6
      00450B FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      00450C 90 06 2A         [24]  753 	mov	dptr,#_hold_PARM_2
      00450F E0               [24]  754 	movx	a,@dptr
      004510 60 05            [24]  755 	jz	00107$
      004512 8F 82            [24]  756 	mov	dpl, r7
      004514 02 79 33         [24]  757 	ljmp	_layer_hold_on
      004517                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004517 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004519 02 79 69         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00451C                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      00451C 90 0D 8C         [24]  774 	mov	dptr,#_pending
      00451F E0               [24]  775 	movx	a,@dptr
      004520 90 06 2E         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      004523 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004524 12 49 D0         [24]  779 	lcall	_ak820_outline_0150
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004527 90 06 2E         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      00452A E0               [24]  782 	movx	a,@dptr
      00452B 24 A2            [12]  783 	add	a,#_source_state
      00452D FF               [12]  784 	mov	r7,a
      00452E E4               [12]  785 	clr	a
      00452F 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004531 FE               [12]  787 	mov	r6,a
      004532 12 43 AA         [24]  788 	lcall	_ak820_outline_0153
      004535 E0               [24]  789 	movx	a,@dptr
      004536 FD               [12]  790 	mov	r5,a
      004537 43 05 04         [24]  791 	orl	ar5,#0x04
      00453A 12 43 AA         [24]  792 	lcall	_ak820_outline_0153
      00453D ED               [12]  793 	mov	a,r5
      00453E F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      00453F 90 06 26         [24]  796 	mov	dptr,#_pending_code
      004542 12 37 F7         [24]  797 	lcall	_ak820_outline_0051
      004545 90 06 2A         [24]  798 	mov	dptr,#_hold_PARM_2
      004548 12 49 9E         [24]  799 	lcall	_ak820_outline_0055
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      00454B 81 C4            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      00454D                        812 _ak820_tapping_before:
      00454D 12 38 40         [24]  813 	lcall	_ak820_outline_0104
      004550 90 06 2F         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004553 12 38 45         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004556 90 06 2F         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004559 12 37 C2         [24]  818 	lcall	_ak820_outline_0011
      00455C 12 49 6B         [24]  819 	lcall	_ak820_outline_0022
      00455F C0 07            [24]  820 	push	ar7
      004561 C0 06            [24]  821 	push	ar6
      004563 12 B8 97         [24]  822 	lcall	___memcpy
      004566 91 8A            [12]  823 	acall	_ak820_tapping_source
      004568 AD 82            [24]  824 	mov	r5, dpl
      00456A D0 06            [24]  825 	pop	ar6
      00456C D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      00456E 90 0D FD         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004571 E0               [24]  829 	movx	a,@dptr
      004572 60 21            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004574 74 04            [12]  832 	mov	a,#0x04
      004576 12 49 60         [24]  833 	lcall	_ak820_outline_0013
      004579 60 16            [24]  834 	jz	00102$
      00457B BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      00457E 80 11            [24]  836 	sjmp	00102$
      004580                        837 00218$:
      004580 74 05            [12]  838 	mov	a,#0x05
      004582 12 49 60         [24]  839 	lcall	_ak820_outline_0013
      004585 70 0A            [24]  840 	jnz	00102$
      004587 ED               [12]  841 	mov	a,r5
      004588 12 49 85         [24]  842 	lcall	_ak820_outline_0024
      00458B 53 02 FD         [24]  843 	anl	ar2,#0xfd
      00458E 12 49 C9         [24]  844 	lcall	_ak820_outline_0091
      004591                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004591 75 82 00         [24]  847 	mov	dpl, #0x00
      004594 22               [24]  848 	ret
      004595                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004595 90 0D 8C         [24]  851 	mov	dptr,#_pending
      004598 E0               [24]  852 	movx	a,@dptr
      004599 FC               [12]  853 	mov	r4,a
      00459A BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      00459D 80 3A            [24]  855 	sjmp	00108$
      00459F                        856 00220$:
      00459F 12 37 EF         [24]  857 	lcall	_ak820_outline_0034
      0045A2 FA               [12]  858 	mov	r2,a
      0045A3 A3               [24]  859 	inc	dptr
      0045A4 E0               [24]  860 	movx	a,@dptr
      0045A5 FB               [12]  861 	mov	r3,a
      0045A6 90 06 24         [24]  862 	mov	dptr,#_pending_time
      0045A9 12 38 34         [24]  863 	lcall	_ak820_outline_0100
      0045AC EA               [12]  864 	mov	a,r2
      0045AD C3               [12]  865 	clr	c
      0045AE 98               [12]  866 	subb	a,r0
      0045AF FA               [12]  867 	mov	r2,a
      0045B0 EB               [12]  868 	mov	a,r3
      0045B1 99               [12]  869 	subb	a,r1
      0045B2 FB               [12]  870 	mov	r3,a
      0045B3 C3               [12]  871 	clr	c
      0045B4 EA               [12]  872 	mov	a,r2
      0045B5 94 C8            [12]  873 	subb	a,#0xc8
      0045B7 EB               [12]  874 	mov	a,r3
      0045B8 94 00            [12]  875 	subb	a,#0x00
      0045BA 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0045BC 74 04            [12]  878 	mov	a,#0x04
      0045BE 12 49 93         [24]  879 	lcall	_ak820_outline_0046
      0045C1 60 16            [24]  880 	jz	00108$
      0045C3 12 37 A1         [24]  881 	lcall	_ak820_outline_0005
      0045C6 60 11            [24]  882 	jz	00108$
      0045C8 BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      0045CB 80 06            [24]  884 	sjmp	00107$
      0045CD                        885 00224$:
      0045CD ED               [12]  886 	mov	a,r5
      0045CE B5 04 02         [24]  887 	cjne	a,ar4,00225$
      0045D1 80 06            [24]  888 	sjmp	00108$
      0045D3                        889 00225$:
      0045D3                        890 00107$:
      0045D3 C0 05            [24]  891 	push	ar5
      0045D5 B1 1C            [12]  892 	acall	_commit_pending
      0045D7 D0 05            [24]  893 	pop	ar5
      0045D9                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      0045D9 90 06 2F         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0045DC 12 37 F7         [24]  897 	lcall	_ak820_outline_0051
      0045DF 74 04            [12]  898 	mov	a,#0x04
      0045E1 12 49 60         [24]  899 	lcall	_ak820_outline_0013
      0045E4 60 03            [24]  900 	jz	00114$
      0045E6 BD FF 04         [24]  901 	cjne	r5,#0xff,00115$
      0045E9                        902 00114$:
      0045E9 75 82 01         [24]  903 	mov	dpl, #0x01
      0045EC 22               [24]  904 	ret
      0045ED                        905 00115$:
                                    906 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0045ED ED               [12]  907 	mov	a,r5
      0045EE 12 49 BB         [24]  908 	lcall	_ak820_outline_0077
      0045F1 30 E1 13         [24]  909 	jnb	acc.1,00120$
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0045F4 74 05            [12]  911 	mov	a,#0x05
      0045F6 2E               [12]  912 	add	a, r6
      0045F7 12 37 CC         [24]  913 	lcall	_ak820_outline_0014
      0045FA 70 07            [24]  914 	jnz	00118$
      0045FC 74 FD            [12]  915 	mov	a,#0xfd
      0045FE 5B               [12]  916 	anl	a,r3
      0045FF 12 38 57         [24]  917 	lcall	_ak820_outline_0121
      004602 F0               [24]  918 	movx	@dptr,a
      004603                        919 00118$:
                                    920 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004603 75 82 00         [24]  921 	mov	dpl, #0x00
      004606 22               [24]  922 	ret
      004607                        923 00120$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004607 12 43 30         [24]  925 	lcall	_ak820_outline_0010
      00460A E0               [24]  926 	movx	a,@dptr
      00460B FF               [12]  927 	mov	r7,a
      00460C 8B 06            [24]  928 	mov	ar6,r3
      00460E 53 06 01         [24]  929 	anl	ar6,#0x01
      004611 EE               [12]  930 	mov	a,r6
      004612 B4 01 00         [24]  931 	cjne	a,#0x01,00231$
      004615                        932 00231$:
      004615 B3               [12]  933 	cpl	c
      004616 92 0C            [24]  934 	mov	_ak820_tapping_before_sloc0_1_0,c
      004618 8F F0            [24]  935 	mov	b,r7
      00461A E4               [12]  936 	clr	a
      00461B 33               [12]  937 	rlc	a
      00461C B5 F0 04         [24]  938 	cjne	a,b,00122$
      00461F 75 82 00         [24]  939 	mov	dpl, #0x00
      004622 22               [24]  940 	ret
      004623                        941 00122$:
                                    942 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004623 63 03 01         [24]  943 	xrl	ar3,#0x01
      004626 12 38 57         [24]  944 	lcall	_ak820_outline_0121
      004629 EB               [12]  945 	mov	a,r3
      00462A F0               [24]  946 	movx	@dptr,a
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      00462B 75 82 01         [24]  948 	mov	dpl, #0x01
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00462E 22               [24]  950 	ret
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    953 ;------------------------------------------------------------
                                    954 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    955 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    956 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    957 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    958 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    959 ;------------------------------------------------------------
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function ak820_tapping_process
                                    963 ;	-----------------------------------------
      00462F                        964 _ak820_tapping_process:
      00462F 12 38 40         [24]  965 	lcall	_ak820_outline_0104
      004632 90 06 31         [24]  966 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004635 12 38 45         [24]  967 	lcall	_ak820_outline_0105
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004638 90 06 35         [24]  969 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00463B E4               [12]  970 	clr	a
      00463C F0               [24]  971 	movx	@dptr,a
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      00463D 90 06 31         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004640 12 37 F7         [24]  974 	lcall	_ak820_outline_0051
      004643 74 04            [12]  975 	mov	a,#0x04
      004645 12 49 55         [24]  976 	lcall	_ak820_outline_0012
      004648 70 04            [24]  977 	jnz	00102$
      00464A 75 82 01         [24]  978 	mov	dpl, #0x01
      00464D 22               [24]  979 	ret
      00464E                        980 00102$:
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      00464E 8E 04            [24]  982 	mov	ar4,r6
      004650 8F 05            [24]  983 	mov	ar5,r7
      004652 12 49 6B         [24]  984 	lcall	_ak820_outline_0022
      004655 C0 07            [24]  985 	push	ar7
      004657 C0 06            [24]  986 	push	ar6
      004659 12 B8 97         [24]  987 	lcall	___memcpy
      00465C 91 8A            [12]  988 	acall	_ak820_tapping_source
      00465E AD 82            [24]  989 	mov	r5, dpl
      004660 D0 06            [24]  990 	pop	ar6
      004662 D0 07            [24]  991 	pop	ar7
                                    992 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004664 BD FF 04         [24]  993 	cjne	r5,#0xff,00104$
      004667 75 82 01         [24]  994 	mov	dpl, #0x01
      00466A 22               [24]  995 	ret
      00466B                        996 00104$:
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      00466B 74 07            [12]  998 	mov	a,#0x07
      00466D 12 37 DE         [24]  999 	lcall	_ak820_outline_0017
      004670 FE               [12] 1000 	mov	r6,a
      004671 A3               [24] 1001 	inc	dptr
      004672 E0               [24] 1002 	movx	a,@dptr
      004673 FF               [12] 1003 	mov	r7,a
      004674 90 06 33         [24] 1004 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004677 12 49 AE         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      00467A BE 1A 15         [24] 1007 	cjne	r6,#0x1a,00111$
      00467D BF 7C 12         [24] 1008 	cjne	r7,#0x7c,00111$
      004680 90 06 33         [24] 1009 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004683 74 26            [12] 1010 	mov	a,#0x26
      004685 F0               [24] 1011 	movx	@dptr,a
      004686 74 22            [12] 1012 	mov	a,#0x22
      004688 A3               [24] 1013 	inc	dptr
      004689 F0               [24] 1014 	movx	@dptr,a
      00468A 90 06 35         [24] 1015 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00468D 74 02            [12] 1016 	mov	a,#0x02
      00468F F0               [24] 1017 	movx	@dptr,a
      004690 80 28            [24] 1018 	sjmp	00112$
      004692                       1019 00111$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004692 BE 1B 15         [24] 1021 	cjne	r6,#0x1b,00108$
      004695 BF 7C 12         [24] 1022 	cjne	r7,#0x7c,00108$
      004698 90 06 33         [24] 1023 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00469B 74 27            [12] 1024 	mov	a,#0x27
      00469D F0               [24] 1025 	movx	@dptr,a
      00469E 74 32            [12] 1026 	mov	a,#0x32
      0046A0 A3               [24] 1027 	inc	dptr
      0046A1 F0               [24] 1028 	movx	@dptr,a
      0046A2 90 06 35         [24] 1029 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0046A5 74 20            [12] 1030 	mov	a,#0x20
      0046A7 F0               [24] 1031 	movx	@dptr,a
      0046A8 80 10            [24] 1032 	sjmp	00112$
      0046AA                       1033 00108$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0046AA BE 1E 0D         [24] 1035 	cjne	r6,#0x1e,00112$
      0046AD BF 7C 0A         [24] 1036 	cjne	r7,#0x7c,00112$
      0046B0 90 06 33         [24] 1037 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046B3 74 28            [12] 1038 	mov	a,#0x28
      0046B5 F0               [24] 1039 	movx	@dptr,a
      0046B6 74 32            [12] 1040 	mov	a,#0x32
      0046B8 A3               [24] 1041 	inc	dptr
      0046B9 F0               [24] 1042 	movx	@dptr,a
      0046BA                       1043 00112$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      0046BA 90 06 33         [24] 1045 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046BD E0               [24] 1046 	movx	a,@dptr
      0046BE A3               [24] 1047 	inc	dptr
      0046BF E0               [24] 1048 	movx	a,@dptr
      0046C0 FF               [12] 1049 	mov	r7,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      0046C1 BF 20 00         [24] 1051 	cjne	r7,#0x20,00242$
      0046C4                       1052 00242$:
      0046C4 40 05            [24] 1053 	jc	00113$
      0046C6 BF 50 00         [24] 1054 	cjne	r7,#0x50,00244$
      0046C9                       1055 00244$:
      0046C9 40 04            [24] 1056 	jc	00114$
      0046CB                       1057 00113$:
      0046CB 75 82 01         [24] 1058 	mov	dpl, #0x01
      0046CE 22               [24] 1059 	ret
      0046CF                       1060 00114$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0046CF BF 40 00         [24] 1062 	cjne	r7,#0x40,00246$
      0046D2                       1063 00246$:
      0046D2 40 0C            [24] 1064 	jc	00117$
      0046D4 53 07 0F         [24] 1065 	anl	ar7,#0x0f
      0046D7 BF 06 00         [24] 1066 	cjne	r7,#0x06,00248$
      0046DA                       1067 00248$:
      0046DA 40 04            [24] 1068 	jc	00117$
      0046DC 75 82 00         [24] 1069 	mov	dpl, #0x00
      0046DF 22               [24] 1070 	ret
      0046E0                       1071 00117$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      0046E0 90 06 31         [24] 1073 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0046E3 12 37 F7         [24] 1074 	lcall	_ak820_outline_0051
      0046E6 74 05            [12] 1075 	mov	a,#0x05
      0046E8 12 49 60         [24] 1076 	lcall	_ak820_outline_0013
      0046EB 60 1E            [24] 1077 	jz	00131$
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      0046ED 90 0D 8C         [24] 1079 	mov	dptr,#_pending
      0046F0 ED               [12] 1080 	mov	a,r5
      0046F1 12 43 3A         [24] 1081 	lcall	_ak820_outline_0030
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      0046F4 12 37 F7         [24] 1083 	lcall	_ak820_outline_0051
      0046F7 90 06 24         [24] 1084 	mov	dptr,#_pending_time
      0046FA 12 49 AE         [24] 1085 	lcall	_ak820_outline_0059
                                   1086 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      0046FD 90 06 33         [24] 1087 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004700 12 37 F7         [24] 1088 	lcall	_ak820_outline_0051
      004703 90 06 26         [24] 1089 	mov	dptr,#_pending_code
      004706 12 49 AE         [24] 1090 	lcall	_ak820_outline_0059
      004709 E1 A6            [12] 1091 	ajmp	00132$
      00470B                       1092 00131$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      00470B 90 0D 8C         [24] 1094 	mov	dptr,#_pending
      00470E E0               [24] 1095 	movx	a,@dptr
      00470F FF               [12] 1096 	mov	r7,a
      004710 ED               [12] 1097 	mov	a,r5
      004711 B5 07 02         [24] 1098 	cjne	a,ar7,00251$
      004714 80 02            [24] 1099 	sjmp	00252$
      004716                       1100 00251$:
      004716 E1 80            [24] 1101 	ajmp	00128$
      004718                       1102 00252$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004718 12 49 D0         [24] 1104 	lcall	_ak820_outline_0150
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      00471B 90 06 35         [24] 1106 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00471E E0               [24] 1107 	movx	a,@dptr
      00471F FF               [12] 1108 	mov	r7,a
      004720 E0               [24] 1109 	movx	a,@dptr
      004721 60 05            [24] 1110 	jz	00120$
      004723 8F 82            [24] 1111 	mov	dpl, r7
      004725 12 7E 6D         [24] 1112 	lcall	_add_owned_mods
      004728                       1113 00120$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004728 90 06 31         [24] 1115 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00472B 12 37 F7         [24] 1116 	lcall	_ak820_outline_0051
      00472E 74 07            [12] 1117 	mov	a,#0x07
      004730 2E               [12] 1118 	add	a, r6
      004731 FB               [12] 1119 	mov	r3,a
      004732 E4               [12] 1120 	clr	a
      004733 3F               [12] 1121 	addc	a, r7
      004734 FC               [12] 1122 	mov	r4,a
      004735 90 06 33         [24] 1123 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004738 E0               [24] 1124 	movx	a,@dptr
      004739 F9               [12] 1125 	mov	r1,a
      00473A 7A 00            [12] 1126 	mov	r2,#0x00
      00473C 12 33 FC         [24] 1127 	lcall	_ak820_outline_0122
      00473F E9               [12] 1128 	mov	a,r1
      004740 F0               [24] 1129 	movx	@dptr,a
      004741 EA               [12] 1130 	mov	a,r2
      004742 A3               [24] 1131 	inc	dptr
      004743 F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004744 C3               [12] 1134 	clr	c
      004745 04               [12] 1135 	inc	a
      004746 99               [12] 1136 	subb	a,r1
      004747 50 25            [24] 1137 	jnc	00122$
                                   1138 ;	free result
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004749 74 06            [12] 1140 	mov	a,#0x06
      00474B 12 37 DE         [24] 1141 	lcall	_ak820_outline_0017
      00474E 54 0F            [12] 1142 	anl	a,#0x0f
      004750 44 10            [12] 1143 	orl	a,#0x10
      004752 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004753 12 43 30         [24] 1146 	lcall	_ak820_outline_0010
      004756 12 49 9E         [24] 1147 	lcall	_ak820_outline_0055
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004759 12 72 4B         [24] 1149 	lcall	_process_record
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      00475C 90 06 31         [24] 1151 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00475F 12 37 97         [24] 1152 	lcall	_ak820_outline_0004
      004762 A3               [24] 1153 	inc	dptr
      004763 A3               [24] 1154 	inc	dptr
      004764 A3               [24] 1155 	inc	dptr
      004765 A3               [24] 1156 	inc	dptr
      004766 A3               [24] 1157 	inc	dptr
      004767 E4               [12] 1158 	clr	a
      004768 12 43 66         [24] 1159 	lcall	_ak820_outline_0061
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      00476B 12 72 4B         [24] 1161 	lcall	_process_record
      00476E                       1162 00122$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      00476E 90 06 35         [24] 1164 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004771 E0               [24] 1165 	movx	a,@dptr
      004772 FF               [12] 1166 	mov	r7,a
      004773 E0               [24] 1167 	movx	a,@dptr
      004774 60 30            [24] 1168 	jz	00132$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004776 8F 82            [24] 1170 	mov	dpl, r7
      004778 12 7E 7C         [24] 1171 	lcall	_del_owned_mods
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      00477B 12 81 A3         [24] 1173 	lcall	_send_keyboard_report
      00477E 80 26            [24] 1174 	sjmp	00132$
      004780                       1175 00128$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004780 ED               [12] 1177 	mov	a,r5
      004781 24 A2            [12] 1178 	add	a, #_source_state
      004783 FE               [12] 1179 	mov	r6,a
      004784 E4               [12] 1180 	clr	a
      004785 34 05            [12] 1181 	addc	a, #(_source_state >> 8)
      004787 FF               [12] 1182 	mov	r7,a
      004788 12 38 2E         [24] 1183 	lcall	_ak820_outline_0098
      00478B FD               [12] 1184 	mov	r5,a
      00478C 30 E2 17         [24] 1185 	jnb	acc.2,00132$
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      00478F 53 05 FB         [24] 1187 	anl	ar5,#0xfb
      004792 12 43 84         [24] 1188 	lcall	_ak820_outline_0117
      004795 ED               [12] 1189 	mov	a,r5
      004796 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004797 90 06 33         [24] 1192 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00479A 12 37 F7         [24] 1193 	lcall	_ak820_outline_0051
      00479D 90 06 2A         [24] 1194 	mov	dptr,#_hold_PARM_2
      0047A0 E4               [12] 1195 	clr	a
      0047A1 12 43 66         [24] 1196 	lcall	_ak820_outline_0061
      0047A4 91 C4            [12] 1197 	acall	_hold
      0047A6                       1198 00132$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0047A6 75 82 00         [24] 1200 	mov	dpl, #0x00
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0047A9 22               [24] 1202 	ret
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1205 ;------------------------------------------------------------
                                   1206 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1207 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function ak820_tapping_cancel
                                   1212 ;	-----------------------------------------
      0047AA                       1213 _ak820_tapping_cancel:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0047AA 12 49 D0         [24] 1215 	lcall	_ak820_outline_0150
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0047AD 7F 00            [12] 1217 	mov	r7,#0x00
      0047AF                       1218 00103$:
      0047AF BF 82 00         [24] 1219 	cjne	r7,#0x82,00122$
      0047B2                       1220 00122$:
      0047B2 50 1D            [24] 1221 	jnc	00105$
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0047B4 EF               [12] 1223 	mov	a,r7
      0047B5 24 A2            [12] 1224 	add	a, #_source_state
      0047B7 FD               [12] 1225 	mov	r5,a
      0047B8 E4               [12] 1226 	clr	a
      0047B9 34 05            [12] 1227 	addc	a, #(_source_state >> 8)
      0047BB 12 49 A6         [24] 1228 	lcall	_ak820_outline_0057
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0047BE 74 02            [12] 1230 	mov	a,#0x02
      0047C0 5C               [12] 1231 	anl	a,r4
      0047C1 FB               [12] 1232 	mov	r3,a
      0047C2 53 04 01         [24] 1233 	anl	ar4,#0x01
      0047C5 EC               [12] 1234 	mov	a,r4
      0047C6 2C               [12] 1235 	add	a,r4
      0047C7 42 03            [12] 1236 	orl	ar3,a
      0047C9 12 38 61         [24] 1237 	lcall	_ak820_outline_0131
      0047CC EB               [12] 1238 	mov	a,r3
      0047CD F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0047CE 0F               [12] 1241 	inc	r7
      0047CF 80 DE            [24] 1242 	sjmp	00103$
      0047D1                       1243 00105$:
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      0047D1 22               [24] 1245 	ret
                                   1246 ;------------------------------------------------------------
                                   1247 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1248 ;------------------------------------------------------------
                                   1249 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1250 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1251 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1252 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1253 ;i             Allocated with name '_ak820_oneshot_process_i_40000_667'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function ak820_oneshot_process
                                   1258 ;	-----------------------------------------
      0047D2                       1259 _ak820_oneshot_process:
      0047D2 12 38 40         [24] 1260 	lcall	_ak820_outline_0104
      0047D5 90 06 3A         [24] 1261 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0047D8 12 38 45         [24] 1262 	lcall	_ak820_outline_0105
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      0047DB 90 06 38         [24] 1264 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0047DE E0               [24] 1265 	movx	a,@dptr
      0047DF FF               [12] 1266 	mov	r7,a
      0047E0 BF FF 02         [24] 1267 	cjne	r7,#0xff,00301$
      0047E3 80 07            [24] 1268 	sjmp	00101$
      0047E5                       1269 00301$:
      0047E5 12 A2 C6         [24] 1270 	lcall	_get_repeat_key_count
      0047E8 E5 82            [12] 1271 	mov	a, dpl
      0047EA 60 04            [24] 1272 	jz	00102$
      0047EC                       1273 00101$:
      0047EC 75 82 01         [24] 1274 	mov	dpl, #0x01
      0047EF 22               [24] 1275 	ret
      0047F0                       1276 00102$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      0047F0 90 06 3A         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0047F3 12 43 72         [24] 1279 	lcall	_ak820_outline_0097
      0047F6 C3               [12] 1280 	clr	c
      0047F7 ED               [12] 1281 	mov	a,r5
      0047F8 94 09            [12] 1282 	subb	a,#0x09
      0047FA EE               [12] 1283 	mov	a,r6
      0047FB 94 70            [12] 1284 	subb	a,#0x70
      0047FD 40 0C            [24] 1285 	jc	00105$
      0047FF 74 0B            [12] 1286 	mov	a,#0x0b
      004801 9D               [12] 1287 	subb	a,r5
      004802 74 70            [12] 1288 	mov	a,#0x70
      004804 9E               [12] 1289 	subb	a,r6
      004805 40 04            [24] 1290 	jc	00105$
                                   1291 ;	free result
      004807 75 82 01         [24] 1292 	mov	dpl, #0x01
      00480A 22               [24] 1293 	ret
      00480B                       1294 00105$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) return true;
      00480B 90 06 3A         [24] 1296 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00480E 12 38 3A         [24] 1297 	lcall	_ak820_outline_0101
      004811 8B 01            [24] 1298 	mov	ar1,r3
      004813 8C 02            [24] 1299 	mov	ar2,r4
      004815 B9 1B 05         [24] 1300 	cjne	r1,#0x1b,00305$
      004818 BA 70 02         [24] 1301 	cjne	r2,#0x70,00305$
      00481B 80 0E            [24] 1302 	sjmp	00107$
      00481D                       1303 00305$:
      00481D B9 1C 05         [24] 1304 	cjne	r1,#0x1c,00306$
      004820 BA 70 02         [24] 1305 	cjne	r2,#0x70,00306$
      004823 80 06            [24] 1306 	sjmp	00107$
      004825                       1307 00306$:
      004825 B9 1D 07         [24] 1308 	cjne	r1,#0x1d,00108$
      004828 BA 70 04         [24] 1309 	cjne	r2,#0x70,00108$
      00482B                       1310 00107$:
      00482B 75 82 01         [24] 1311 	mov	dpl, #0x01
      00482E 22               [24] 1312 	ret
      00482F                       1313 00108$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) return true;
      00482F B9 14 05         [24] 1315 	cjne	r1,#0x14,00309$
      004832 BA 70 02         [24] 1316 	cjne	r2,#0x70,00309$
      004835 80 0E            [24] 1317 	sjmp	00111$
      004837                       1318 00309$:
      004837 B9 15 05         [24] 1319 	cjne	r1,#0x15,00310$
      00483A BA 70 02         [24] 1320 	cjne	r2,#0x70,00310$
      00483D 80 06            [24] 1321 	sjmp	00111$
      00483F                       1322 00310$:
      00483F B9 16 07         [24] 1323 	cjne	r1,#0x16,00112$
      004842 BA 70 04         [24] 1324 	cjne	r2,#0x70,00112$
      004845                       1325 00111$:
      004845 75 82 01         [24] 1326 	mov	dpl, #0x01
      004848 22               [24] 1327 	ret
      004849                       1328 00112$:
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004849 8C 01            [24] 1330 	mov	ar1,r4
      00484B B9 52 02         [24] 1331 	cjne	r1,#0x52,00313$
      00484E 80 02            [24] 1332 	sjmp	00314$
      004850                       1333 00313$:
      004850 01 F5            [12] 1334 	ajmp	00127$
      004852                       1335 00314$:
      004852 8B 02            [24] 1336 	mov	ar2,r3
      004854 53 02 E0         [24] 1337 	anl	ar2,#0xe0
      004857 BA A0 02         [24] 1338 	cjne	r2,#0xa0,00315$
      00485A 80 02            [24] 1339 	sjmp	00316$
      00485C                       1340 00315$:
      00485C 01 F5            [12] 1341 	ajmp	00127$
      00485E                       1342 00316$:
                                   1343 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      00485E 8B 02            [24] 1344 	mov	ar2,r3
      004860 53 02 0F         [24] 1345 	anl	ar2,#0x0f
      004863 90 06 3C         [24] 1346 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004866 EA               [12] 1347 	mov	a,r2
      004867 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004868 EB               [12] 1350 	mov	a,r3
      004869 30 E4 08         [24] 1351 	jnb	acc.4,00116$
      00486C EA               [12] 1352 	mov	a,r2
      00486D C4               [12] 1353 	swap	a
      00486E 54 F0            [12] 1354 	anl	a,#0xf0
      004870 90 06 3C         [24] 1355 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004873 F0               [24] 1356 	movx	@dptr,a
      004874                       1357 00116$:
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004874 90 06 39         [24] 1359 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004877 E0               [24] 1360 	movx	a,@dptr
      004878 60 2E            [24] 1361 	jz	00124$
                                   1362 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      00487A EF               [12] 1363 	mov	a,r7
      00487B 12 49 85         [24] 1364 	lcall	_ak820_outline_0024
      00487E 43 02 08         [24] 1365 	orl	ar2,#0x08
      004881 12 49 C9         [24] 1366 	lcall	_ak820_outline_0091
                                   1367 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004884 53 02 EF         [24] 1368 	anl	ar2,#0xef
      004887 12 49 C9         [24] 1369 	lcall	_ak820_outline_0091
                                   1370 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00488A 90 0D 8D         [24] 1371 	mov	dptr,#_ak820_oneshot_target
      00488D E0               [24] 1372 	movx	a,@dptr
      00488E FA               [12] 1373 	mov	r2,a
      00488F BA FF 02         [24] 1374 	cjne	r2,#0xff,00319$
      004892 80 09            [24] 1375 	sjmp	00118$
      004894                       1376 00319$:
      004894 12 49 B4         [24] 1377 	lcall	_ak820_outline_0065
      004897 43 02 10         [24] 1378 	orl	ar2,#0x10
      00489A 12 49 C9         [24] 1379 	lcall	_ak820_outline_0091
      00489D                       1380 00118$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      00489D 90 06 3C         [24] 1382 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0048A0 E0               [24] 1383 	movx	a,@dptr
      0048A1 F5 82            [12] 1384 	mov	dpl,a
      0048A3 12 77 79         [24] 1385 	lcall	_register_mods
      0048A6 80 49            [24] 1386 	sjmp	00125$
      0048A8                       1387 00124$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      0048A8 EF               [12] 1389 	mov	a,r7
      0048A9 12 49 85         [24] 1390 	lcall	_ak820_outline_0024
      0048AC 30 E3 42         [24] 1391 	jnb	acc.3,00125$
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0048AF EA               [12] 1393 	mov	a,r2
      0048B0 20 E4 24         [24] 1394 	jb	acc.4,00120$
                                   1395 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      0048B3 90 06 36         [24] 1396 	mov	dptr,#_ak820_oneshot_mods
      0048B6 E0               [24] 1397 	movx	a,@dptr
      0048B7 F4               [12] 1398 	cpl	a
      0048B8 FA               [12] 1399 	mov	r2,a
      0048B9 90 06 3C         [24] 1400 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0048BC E0               [24] 1401 	movx	a,@dptr
      0048BD F9               [12] 1402 	mov	r1,a
      0048BE 52 02            [12] 1403 	anl	ar2,a
      0048C0 8A 82            [24] 1404 	mov	dpl, r2
      0048C2 C0 04            [24] 1405 	push	ar4
      0048C4 C0 03            [24] 1406 	push	ar3
      0048C6 C0 01            [24] 1407 	push	ar1
      0048C8 12 7E 6D         [24] 1408 	lcall	_add_owned_mods
      0048CB D0 01            [24] 1409 	pop	ar1
      0048CD D0 03            [24] 1410 	pop	ar3
      0048CF D0 04            [24] 1411 	pop	ar4
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      0048D1 90 06 36         [24] 1413 	mov	dptr,#_ak820_oneshot_mods
      0048D4 E0               [24] 1414 	movx	a,@dptr
      0048D5 49               [12] 1415 	orl	a,r1
      0048D6 F0               [24] 1416 	movx	@dptr,a
      0048D7                       1417 00120$:
                                   1418 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      0048D7 90 06 3C         [24] 1419 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0048DA E0               [24] 1420 	movx	a,@dptr
      0048DB F5 82            [12] 1421 	mov	dpl,a
      0048DD C0 04            [24] 1422 	push	ar4
      0048DF C0 03            [24] 1423 	push	ar3
      0048E1 12 77 8D         [24] 1424 	lcall	_unregister_mods
      0048E4 D0 03            [24] 1425 	pop	ar3
      0048E6 D0 04            [24] 1426 	pop	ar4
                                   1427 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0048E8 12 49 B4         [24] 1428 	lcall	_ak820_outline_0065
      0048EB 53 02 E7         [24] 1429 	anl	ar2,#0xe7
      0048EE 12 49 C9         [24] 1430 	lcall	_ak820_outline_0091
      0048F1                       1431 00125$:
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      0048F1 75 82 00         [24] 1433 	mov	dpl, #0x00
      0048F4 22               [24] 1434 	ret
      0048F5                       1435 00127$:
                                   1436 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      0048F5 90 06 39         [24] 1437 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0048F8 E0               [24] 1438 	movx	a,@dptr
      0048F9 60 56            [24] 1439 	jz	00135$
      0048FB C3               [12] 1440 	clr	c
      0048FC 74 01            [12] 1441 	mov	a,#0x01
      0048FE 9D               [12] 1442 	subb	a,r5
      0048FF E4               [12] 1443 	clr	a
      004900 9E               [12] 1444 	subb	a,r6
      004901 50 4E            [24] 1445 	jnc	00135$
                                   1446 ;	free result
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004903 C3               [12] 1448 	clr	c
      004904 ED               [12] 1449 	mov	a,r5
      004905 94 E0            [12] 1450 	subb	a,#0xe0
      004907 EE               [12] 1451 	mov	a,r6
      004908 94 00            [12] 1452 	subb	a,#0x00
      00490A 40 07            [24] 1453 	jc	00140$
      00490C 74 E7            [12] 1454 	mov	a,#0xe7
      00490E 9D               [12] 1455 	subb	a,r5
      00490F E4               [12] 1456 	clr	a
      004910 9E               [12] 1457 	subb	a,r6
      004911 50 3E            [24] 1458 	jnc	00135$
                                   1459 ;	free result
      004913                       1460 00140$:
                                   1461 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004913 74 AE            [12] 1462 	mov	a,#0x100 - 0x52
      004915 2E               [12] 1463 	add	a,r6
      004916 50 09            [24] 1464 	jnc	00188$
      004918 C3               [12] 1465 	clr	c
      004919 74 DF            [12] 1466 	mov	a,#0xdf
      00491B 9D               [12] 1467 	subb	a,r5
      00491C 74 52            [12] 1468 	mov	a,#0x52
      00491E 9E               [12] 1469 	subb	a,r6
      00491F 50 30            [24] 1470 	jnc	00135$
                                   1471 ;	free result
                                   1472 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004921                       1473 00188$:
      004921 7E 00            [12] 1474 	mov	r6,#0x00
      004923                       1475 00142$:
      004923 BE 82 00         [24] 1476 	cjne	r6,#0x82,00328$
      004926                       1477 00328$:
      004926 50 12            [24] 1478 	jnc	00131$
                                   1479 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004928 EE               [12] 1480 	mov	a,r6
      004929 12 49 BB         [24] 1481 	lcall	_ak820_outline_0077
      00492C 30 E3 08         [24] 1482 	jnb	acc.3,00143$
      00492F 43 03 10         [24] 1483 	orl	ar3,#0x10
      004932 12 38 57         [24] 1484 	lcall	_ak820_outline_0121
      004935 EB               [12] 1485 	mov	a,r3
      004936 F0               [24] 1486 	movx	@dptr,a
      004937                       1487 00143$:
                                   1488 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004937 0E               [12] 1489 	inc	r6
      004938 80 E9            [24] 1490 	sjmp	00142$
      00493A                       1491 00131$:
                                   1492 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      00493A 90 06 36         [24] 1493 	mov	dptr,#_ak820_oneshot_mods
      00493D E0               [24] 1494 	movx	a,@dptr
      00493E FE               [12] 1495 	mov	r6,a
      00493F E0               [24] 1496 	movx	a,@dptr
      004940 60 0F            [24] 1497 	jz	00135$
                                   1498 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004942 90 06 37         [24] 1499 	mov	dptr,#_ak820_oneshot_consumed
      004945 EE               [12] 1500 	mov	a,r6
      004946 F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004947 90 0D 8D         [24] 1503 	mov	dptr,#_ak820_oneshot_target
      00494A EF               [12] 1504 	mov	a,r7
      00494B F0               [24] 1505 	movx	@dptr,a
                                   1506 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      00494C 90 06 36         [24] 1507 	mov	dptr,#_ak820_oneshot_mods
      00494F E4               [12] 1508 	clr	a
      004950 F0               [24] 1509 	movx	@dptr,a
      004951                       1510 00135$:
                                   1511 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004951 75 82 01         [24] 1512 	mov	dpl, #0x01
                                   1513 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004954 22               [24] 1514 	ret
                                   1515 	.area CSEG    (CODE)
                                   1516 	.area CONST   (CODE)
                                   1517 	.area XINIT   (CODE)
      00C157                       1518 __xinit__pending:
      00C157 FF                    1519 	.db #0xff	; 255
      00C158                       1520 __xinit__ak820_oneshot_target:
      00C158 FF                    1521 	.db #0xff	; 255
                                   1522 	.area CABS    (ABS,CODE)
                                   1523 
                                   1524 ; Experimental exact instruction outlining.
                                   1525 	.globl _ak820_outline_0004
                                   1526 	.globl _ak820_outline_0005
                                   1527 	.globl _ak820_outline_0010
                                   1528 	.globl _ak820_outline_0011
                                   1529 	.globl _ak820_outline_0012
                                   1530 	.globl _ak820_outline_0013
                                   1531 	.globl _ak820_outline_0014
                                   1532 	.globl _ak820_outline_0017
                                   1533 	.globl _ak820_outline_0022
                                   1534 	.globl _ak820_outline_0024
                                   1535 	.globl _ak820_outline_0030
                                   1536 	.globl _ak820_outline_0034
                                   1537 	.globl _ak820_outline_0046
                                   1538 	.globl _ak820_outline_0051
                                   1539 	.globl _ak820_outline_0055
                                   1540 	.globl _ak820_outline_0057
                                   1541 	.globl _ak820_outline_0059
                                   1542 	.globl _ak820_outline_0061
                                   1543 	.globl _ak820_outline_0065
                                   1544 	.globl _ak820_outline_0077
                                   1545 	.globl _ak820_outline_0091
                                   1546 	.globl _ak820_outline_0097
                                   1547 	.globl _ak820_outline_0098
                                   1548 	.globl _ak820_outline_0100
                                   1549 	.globl _ak820_outline_0101
                                   1550 	.globl _ak820_outline_0104
                                   1551 	.globl _ak820_outline_0105
                                   1552 	.globl _ak820_outline_0117
                                   1553 	.globl _ak820_outline_0121
                                   1554 	.globl _ak820_outline_0122
                                   1555 	.globl _ak820_outline_0131
                                   1556 	.globl _ak820_outline_0150
                                   1557 	.globl _ak820_outline_0153
                                   1558 	.globl _ak820_outline_0185
                                   1559 
                                   1560 	.area CSEG (CODE)
                                   1561 ; function ak820_outline_0012
      004955                       1562 _ak820_outline_0012:
      004955 2E               [12] 1563 	add	a,r6
      004956 FC               [12] 1564 	mov	r4,a
      004957 E4               [12] 1565 	clr	a
      004958 3F               [12] 1566 	addc	a,r7
      004959 FD               [12] 1567 	mov	r5,a
      00495A 8C 82            [24] 1568 	mov	dpl,r4
      00495C 8D 83            [24] 1569 	mov	dph,r5
      00495E E0               [24] 1570 	movx	a,@dptr
      00495F 22               [24] 1571 	ret
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0013
      004960                       1575 _ak820_outline_0013:
      004960 2E               [12] 1576 	add	a,r6
      004961 FB               [12] 1577 	mov	r3,a
      004962 E4               [12] 1578 	clr	a
      004963 3F               [12] 1579 	addc	a,r7
      004964 FC               [12] 1580 	mov	r4,a
      004965 8B 82            [24] 1581 	mov	dpl,r3
      004967 8C 83            [24] 1582 	mov	dph,r4
      004969 E0               [24] 1583 	movx	a,@dptr
      00496A 22               [24] 1584 	ret
                                   1585 
                                   1586 	.area CSEG (CODE)
                                   1587 ; function ak820_outline_0022
      00496B                       1588 _ak820_outline_0022:
      00496B 90 0D 7C         [24] 1589 	mov	dptr,#___memcpy_PARM_2
      00496E EC               [12] 1590 	mov	a,r4
      00496F F0               [24] 1591 	movx	@dptr,a
      004970 ED               [12] 1592 	mov	a,r5
      004971 A3               [24] 1593 	inc	dptr
      004972 F0               [24] 1594 	movx	@dptr,a
      004973 E4               [12] 1595 	clr	a
      004974 A3               [24] 1596 	inc	dptr
      004975 F0               [24] 1597 	movx	@dptr,a
      004976 90 0D 7F         [24] 1598 	mov	dptr,#___memcpy_PARM_3
      004979 74 02            [12] 1599 	mov	a,#0x02
      00497B F0               [24] 1600 	movx	@dptr,a
      00497C E4               [12] 1601 	clr	a
      00497D A3               [24] 1602 	inc	dptr
      00497E F0               [24] 1603 	movx	@dptr,a
      00497F 90 06 28         [24] 1604 	mov	dptr,#_ak820_tapping_source_PARM_1
      004982 F5 F0            [12] 1605 	mov	b,a
      004984 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0024
      004985                       1610 _ak820_outline_0024:
      004985 24 A2            [12] 1611 	add	a,#_source_state
      004987 FB               [12] 1612 	mov	r3,a
      004988 E4               [12] 1613 	clr	a
      004989 34 05            [12] 1614 	addc	a,#(_source_state>>8)
      00498B FC               [12] 1615 	mov	r4,a
      00498C 8B 82            [24] 1616 	mov	dpl,r3
      00498E 8C 83            [24] 1617 	mov	dph,r4
      004990 E0               [24] 1618 	movx	a,@dptr
      004991 FA               [12] 1619 	mov	r2,a
      004992 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0046
      004993                       1624 _ak820_outline_0046:
      004993 2E               [12] 1625 	add	a,r6
      004994 FA               [12] 1626 	mov	r2,a
      004995 E4               [12] 1627 	clr	a
      004996 3F               [12] 1628 	addc	a,r7
      004997 FB               [12] 1629 	mov	r3,a
      004998 8A 82            [24] 1630 	mov	dpl,r2
      00499A 8B 83            [24] 1631 	mov	dph,r3
      00499C E0               [24] 1632 	movx	a,@dptr
      00499D 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0055
      00499E                       1637 _ak820_outline_0055:
      00499E 74 01            [12] 1638 	mov	a,#0x01
      0049A0 F0               [24] 1639 	movx	@dptr,a
      0049A1 8E 82            [24] 1640 	mov	dpl,r6
      0049A3 8F 83            [24] 1641 	mov	dph,r7
      0049A5 22               [24] 1642 	ret
                                   1643 
                                   1644 	.area CSEG (CODE)
                                   1645 ; function ak820_outline_0057
      0049A6                       1646 _ak820_outline_0057:
      0049A6 FE               [12] 1647 	mov	r6,a
      0049A7 8D 82            [24] 1648 	mov	dpl,r5
      0049A9 8E 83            [24] 1649 	mov	dph,r6
      0049AB E0               [24] 1650 	movx	a,@dptr
      0049AC FC               [12] 1651 	mov	r4,a
      0049AD 22               [24] 1652 	ret
                                   1653 
                                   1654 	.area CSEG (CODE)
                                   1655 ; function ak820_outline_0059
      0049AE                       1656 _ak820_outline_0059:
      0049AE EE               [12] 1657 	mov	a,r6
      0049AF F0               [24] 1658 	movx	@dptr,a
      0049B0 EF               [12] 1659 	mov	a,r7
      0049B1 A3               [24] 1660 	inc	dptr
      0049B2 F0               [24] 1661 	movx	@dptr,a
      0049B3 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0065
      0049B4                       1666 _ak820_outline_0065:
      0049B4 8B 82            [24] 1667 	mov	dpl,r3
      0049B6 8C 83            [24] 1668 	mov	dph,r4
      0049B8 E0               [24] 1669 	movx	a,@dptr
      0049B9 FA               [12] 1670 	mov	r2,a
      0049BA 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0077
      0049BB                       1675 _ak820_outline_0077:
      0049BB 24 A2            [12] 1676 	add	a,#_source_state
      0049BD FC               [12] 1677 	mov	r4,a
      0049BE E4               [12] 1678 	clr	a
      0049BF 34 05            [12] 1679 	addc	a,#(_source_state>>8)
      0049C1 FD               [12] 1680 	mov	r5,a
      0049C2 8C 82            [24] 1681 	mov	dpl,r4
      0049C4 8D 83            [24] 1682 	mov	dph,r5
      0049C6 E0               [24] 1683 	movx	a,@dptr
      0049C7 FB               [12] 1684 	mov	r3,a
      0049C8 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0091
      0049C9                       1689 _ak820_outline_0091:
      0049C9 8B 82            [24] 1690 	mov	dpl,r3
      0049CB 8C 83            [24] 1691 	mov	dph,r4
      0049CD EA               [12] 1692 	mov	a,r2
      0049CE F0               [24] 1693 	movx	@dptr,a
      0049CF 22               [24] 1694 	ret
                                   1695 
                                   1696 	.area CSEG (CODE)
                                   1697 ; function ak820_outline_0150
      0049D0                       1698 _ak820_outline_0150:
      0049D0 90 0D 8C         [24] 1699 	mov	dptr,#_pending
      0049D3 74 FF            [12] 1700 	mov	a,#0xff
      0049D5 F0               [24] 1701 	movx	@dptr,a
      0049D6 22               [24] 1702 	ret
