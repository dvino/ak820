                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000027                        587 _process_action_sloc0_1_0:
      000027                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      000813                        615 _tp_buttons::
      000813                        616 	.ds 2
      000815                        617 _action_exec_PARM_1:
      000815                        618 	.ds 6
      00081B                        619 _action_exec_record_10001_625:
      00081B                        620 	.ds 9
      000824                        621 _ak820_action_exec_event_10000_629:
      000824                        622 	.ds 2
      000826                        623 _ak820_action_exec_snapshot_10000_630:
      000826                        624 	.ds 6
      00082C                        625 _process_record_record_argument_10000_633:
      00082C                        626 	.ds 2
      00082E                        627 _process_record_handler_record_argument_10000_641:
      00082E                        628 	.ds 2
      000830                        629 _process_record_handler_action_10000_642:
      000830                        630 	.ds 2
      000832                        631 _process_action_PARM_2:
      000832                        632 	.ds 2
      000834                        633 _process_action_record_argument_10000_653:
      000834                        634 	.ds 2
      000836                        635 _process_action_on_40000_676:
      000836                        636 	.ds 1
      000837                        637 _register_code_code_10000_710:
      000837                        638 	.ds 1
      000838                        639 _unregister_code_code_10000_724:
      000838                        640 	.ds 1
      000839                        641 _tap_code_delay_PARM_2:
      000839                        642 	.ds 2
      00083B                        643 _tap_code_delay_code_10000_737:
      00083B                        644 	.ds 1
      00083C                        645 _tap_code_code_10000_744:
      00083C                        646 	.ds 1
      00083D                        647 _register_mods_mods_10000_746:
      00083D                        648 	.ds 1
      00083E                        649 _unregister_mods_mods_10000_750:
      00083E                        650 	.ds 1
      00083F                        651 _register_weak_mods_mods_10000_754:
      00083F                        652 	.ds 1
      000840                        653 _unregister_weak_mods_mods_10000_758:
      000840                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D9C                        663 _disable_action_cache::
      000D9C                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      0071AE                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0071AE 90 08 17         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0071B1 12 37 97         [24]  711 	lcall	_ak820_outline_0004
      0071B4 12 35 B7         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0071B7 90 08 15         [24]  714 	mov	dptr,#_action_exec_PARM_1
      0071BA 12 45 4D         [24]  715 	lcall	_ak820_tapping_before
      0071BD E5 82            [12]  716 	mov	a, dpl
      0071BF 70 01            [24]  717 	jnz	00102$
      0071C1 22               [24]  718 	ret
      0071C2                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      0071C2 90 08 1A         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0071C5 E0               [24]  722 	movx	a,@dptr
      0071C6 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      0071C8 12 82 AD         [24]  725 	lcall	_clear_weak_mods
      0071CB                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      0071CB 90 0D 7C         [24]  728 	mov	dptr,#___memcpy_PARM_2
      0071CE 74 15            [12]  729 	mov	a,#_action_exec_PARM_1
      0071D0 F0               [24]  730 	movx	@dptr,a
      0071D1 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      0071D3 12 78 21         [24]  732 	lcall	_ak820_outline_0050
      0071D6 12 78 41         [24]  733 	lcall	_ak820_outline_0108
      0071D9 90 08 1B         [24]  734 	mov	dptr,#_action_exec_record_10001_625
      0071DC F5 F0            [12]  735 	mov	b,a
      0071DE 12 B8 97         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      0071E1 90 08 21         [24]  738 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      0071E4 E0               [24]  739 	movx	a,@dptr
      0071E5 54 0F            [12]  740 	anl	a,#0x0f
      0071E7 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      0071E8 90 08 22         [24]  743 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      0071EB 12 50 53         [24]  744 	lcall	_ak820_outline_0180
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0071EE 90 08 1F         [24]  746 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      0071F1 E0               [24]  747 	movx	a,@dptr
      0071F2 60 0A            [24]  748 	jz	00107$
      0071F4 90 08 1B         [24]  749 	mov	dptr,#_action_exec_record_10001_625
      0071F7 12 9F E1         [24]  750 	lcall	_pre_process_record_quantum
      0071FA E5 82            [12]  751 	mov	a, dpl
      0071FC 60 10            [24]  752 	jz	00110$
      0071FE                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0071FE 90 08 1B         [24]  755 	mov	dptr,#_action_exec_record_10001_625
      007201 12 46 2F         [24]  756 	lcall	_ak820_tapping_process
      007204 E5 82            [12]  757 	mov	a, dpl
      007206 70 01            [24]  758 	jnz	00106$
      007208 22               [24]  759 	ret
      007209                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      007209 90 08 1B         [24]  762 	mov	dptr,#_action_exec_record_10001_625
                                    763 ;	quantum/action.c:200: }
      00720C 41 4B            [12]  764 	ajmp	_process_record
      00720E                        765 00110$:
      00720E 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      00720F                        777 _ak820_action_exec:
      00720F 12 38 40         [24]  778 	lcall	_ak820_outline_0104
      007212 90 08 24         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_629
      007215 12 38 45         [24]  780 	lcall	_ak820_outline_0105
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007218 90 08 24         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      00721B 12 38 0E         [24]  783 	lcall	_ak820_outline_0058
      00721E 90 0D 7C         [24]  784 	mov	dptr,#___memcpy_PARM_2
      007221 ED               [12]  785 	mov	a,r5
      007222 12 37 D6         [24]  786 	lcall	_ak820_outline_0016
      007225 90 0D 7F         [24]  787 	mov	dptr,#___memcpy_PARM_3
      007228 12 78 41         [24]  788 	lcall	_ak820_outline_0108
      00722B 90 08 26         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      00722E F5 F0            [12]  790 	mov	b,a
      007230 12 B8 97         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      007233 90 0D 7C         [24]  793 	mov	dptr,#___memcpy_PARM_2
      007236 74 26            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007238 F0               [24]  795 	movx	@dptr,a
      007239 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      00723B 12 78 21         [24]  797 	lcall	_ak820_outline_0050
      00723E 12 78 41         [24]  798 	lcall	_ak820_outline_0108
      007241 90 08 15         [24]  799 	mov	dptr,#_action_exec_PARM_1
      007244 F5 F0            [12]  800 	mov	b,a
      007246 12 B8 97         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      007249 21 AE            [12]  803 	ajmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      00724B                        813 _process_record:
      00724B 12 38 40         [24]  814 	lcall	_ak820_outline_0104
      00724E 90 08 2C         [24]  815 	mov	dptr,#_process_record_record_argument_10000_633
      007251 12 38 45         [24]  816 	lcall	_ak820_outline_0105
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007254 90 08 2C         [24]  818 	mov	dptr,#_process_record_record_argument_10000_633
      007257 12 37 F7         [24]  819 	lcall	_ak820_outline_0051
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00725A 74 04            [12]  821 	mov	a,#0x04
      00725C 12 49 55         [24]  822 	lcall	_ak820_outline_0012
      00725F 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      007261 22               [24]  825 	ret
      007262                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007262 8E 04            [24]  828 	mov	ar4,r6
      007264 8F 05            [24]  829 	mov	ar5,r7
      007266 90 0D 7C         [24]  830 	mov	dptr,#___memcpy_PARM_2
      007269 EC               [12]  831 	mov	a,r4
      00726A F0               [24]  832 	movx	@dptr,a
      00726B ED               [12]  833 	mov	a,r5
      00726C 12 78 21         [24]  834 	lcall	_ak820_outline_0050
      00726F 12 50 45         [24]  835 	lcall	_ak820_outline_0107
      007272 90 06 28         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      007275 F5 F0            [12]  837 	mov	b,a
      007277 C0 07            [24]  838 	push	ar7
      007279 C0 06            [24]  839 	push	ar6
      00727B 12 B8 97         [24]  840 	lcall	___memcpy
      00727E 12 44 8A         [24]  841 	lcall	_ak820_tapping_source
      007281 AD 82            [24]  842 	mov	r5, dpl
      007283 D0 06            [24]  843 	pop	ar6
      007285 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007287 12 43 30         [24]  846 	lcall	_ak820_outline_0010
      00728A E0               [24]  847 	movx	a,@dptr
      00728B FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00728C 74 07            [12]  850 	mov	a,#0x07
      00728E 2E               [12]  851 	add	a, r6
      00728F FA               [12]  852 	mov	r2,a
      007290 E4               [12]  853 	clr	a
      007291 3F               [12]  854 	addc	a, r7
      007292 FB               [12]  855 	mov	r3,a
      007293 90 0B DE         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      007296 12 49 9E         [24]  857 	lcall	_ak820_outline_0055
      007299 C0 07            [24]  858 	push	ar7
      00729B C0 06            [24]  859 	push	ar6
      00729D C0 05            [24]  860 	push	ar5
      00729F C0 04            [24]  861 	push	ar4
      0072A1 C0 03            [24]  862 	push	ar3
      0072A3 C0 02            [24]  863 	push	ar2
      0072A5 12 9F A4         [24]  864 	lcall	_get_record_keycode
      0072A8 A8 82            [24]  865 	mov	r0, dpl
      0072AA A9 83            [24]  866 	mov	r1, dph
      0072AC D0 02            [24]  867 	pop	ar2
      0072AE D0 03            [24]  868 	pop	ar3
      0072B0 D0 04            [24]  869 	pop	ar4
      0072B2 D0 05            [24]  870 	pop	ar5
      0072B4 D0 06            [24]  871 	pop	ar6
      0072B6 D0 07            [24]  872 	pop	ar7
      0072B8 12 43 A0         [24]  873 	lcall	_ak820_outline_0140
      0072BB E8               [12]  874 	mov	a,r0
      0072BC F0               [24]  875 	movx	@dptr,a
      0072BD E9               [12]  876 	mov	a,r1
      0072BE A3               [24]  877 	inc	dptr
      0072BF F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0072C0 74 07            [12]  880 	mov	a,#0x07
      0072C2 12 37 DE         [24]  881 	lcall	_ak820_outline_0017
      0072C5 FA               [12]  882 	mov	r2,a
      0072C6 A3               [24]  883 	inc	dptr
      0072C7 E0               [24]  884 	movx	a,@dptr
      0072C8 FB               [12]  885 	mov	r3,a
      0072C9 90 06 38         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0072CC ED               [12]  887 	mov	a,r5
      0072CD F0               [24]  888 	movx	@dptr,a
      0072CE 90 06 39         [24]  889 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0072D1 EC               [12]  890 	mov	a,r4
      0072D2 F0               [24]  891 	movx	@dptr,a
      0072D3 12 43 A0         [24]  892 	lcall	_ak820_outline_0140
      0072D6 C0 07            [24]  893 	push	ar7
      0072D8 C0 06            [24]  894 	push	ar6
      0072DA C0 05            [24]  895 	push	ar5
      0072DC C0 04            [24]  896 	push	ar4
      0072DE 12 47 D2         [24]  897 	lcall	_ak820_oneshot_process
      0072E1 E5 82            [12]  898 	mov	a, dpl
      0072E3 D0 04            [24]  899 	pop	ar4
      0072E5 D0 05            [24]  900 	pop	ar5
      0072E7 D0 06            [24]  901 	pop	ar6
      0072E9 D0 07            [24]  902 	pop	ar7
      0072EB 70 01            [24]  903 	jnz	00104$
      0072ED 22               [24]  904 	ret
      0072EE                        905 00104$:
                                    906 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0072EE 12 43 84         [24]  907 	lcall	_ak820_outline_0117
      0072F1 C0 07            [24]  908 	push	ar7
      0072F3 C0 06            [24]  909 	push	ar6
      0072F5 C0 05            [24]  910 	push	ar5
      0072F7 C0 04            [24]  911 	push	ar4
      0072F9 12 A0 22         [24]  912 	lcall	_process_record_quantum
      0072FC E5 82            [12]  913 	mov	a, dpl
      0072FE D0 04            [24]  914 	pop	ar4
      007300 D0 05            [24]  915 	pop	ar5
      007302 D0 06            [24]  916 	pop	ar6
      007304 D0 07            [24]  917 	pop	ar7
      007306 70 0A            [24]  918 	jnz	00106$
                                    919 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007308 90 05 98         [24]  920 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00730B EC               [12]  921 	mov	a,r4
      00730C F0               [24]  922 	movx	@dptr,a
      00730D 8D 82            [24]  923 	mov	dpl, r5
                                    924 ;	quantum/action.c:376: return;
      00730F 02 2E 6F         [24]  925 	ljmp	_ak820_oneshot_post
      007312                        926 00106$:
                                    927 ;	quantum/action.c:382: process_record_handler(record);
      007312 12 43 84         [24]  928 	lcall	_ak820_outline_0117
      007315 C0 05            [24]  929 	push	ar5
      007317 C0 04            [24]  930 	push	ar4
      007319 71 29            [24]  931 	acall	_process_record_handler
      00731B D0 04            [24]  932 	pop	ar4
      00731D D0 05            [24]  933 	pop	ar5
                                    934 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00731F 90 05 98         [24]  935 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007322 EC               [12]  936 	mov	a,r4
      007323 F0               [24]  937 	movx	@dptr,a
      007324 8D 82            [24]  938 	mov	dpl, r5
                                    939 ;	quantum/action.c:392: }
      007326 02 2E 6F         [24]  940 	ljmp	_ak820_oneshot_post
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'process_record_handler'
                                    943 ;------------------------------------------------------------
                                    944 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    945 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    946 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function process_record_handler
                                    951 ;	-----------------------------------------
      007329                        952 _process_record_handler:
      007329 12 38 40         [24]  953 	lcall	_ak820_outline_0104
      00732C 90 08 2E         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_641
      00732F 12 38 45         [24]  955 	lcall	_ak820_outline_0105
                                    956 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007332 90 08 2E         [24]  957 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007335 12 37 AE         [24]  958 	lcall	_ak820_outline_0009
                                    959 ;	quantum/action.c:405: if (record->keycode) {
      007338 4C               [12]  960 	orl	a,r4
      007339 60 19            [24]  961 	jz	00102$
                                    962 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00733B 12 38 57         [24]  963 	lcall	_ak820_outline_0121
      00733E C0 07            [24]  964 	push	ar7
      007340 C0 06            [24]  965 	push	ar6
      007342 12 96 82         [24]  966 	lcall	_action_for_keycode
      007345 12 43 A5         [24]  967 	lcall	_ak820_outline_0145
      007348 D0 06            [24]  968 	pop	ar6
      00734A D0 07            [24]  969 	pop	ar7
      00734C 90 08 30         [24]  970 	mov	dptr,#_process_record_handler_action_10000_642
      00734F 12 38 1C         [24]  971 	lcall	_ak820_outline_0071
      007352 80 2A            [24]  972 	sjmp	00104$
      007354                        973 00102$:
                                    974 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007354 12 78 09         [24]  975 	lcall	_ak820_outline_0019
      007357 7A 00            [12]  976 	mov	r2,#0x00
      007359 12 43 9A         [24]  977 	lcall	_ak820_outline_0139
      00735C 12 43 30         [24]  978 	lcall	_ak820_outline_0010
      00735F E0               [24]  979 	movx	a,@dptr
      007360 90 09 6B         [24]  980 	mov	dptr,#_ak820_resolve_key_PARM_2
      007363 F0               [24]  981 	movx	@dptr,a
      007364 12 43 C5         [24]  982 	lcall	_ak820_outline_0186
      007367 C0 07            [24]  983 	push	ar7
      007369 C0 06            [24]  984 	push	ar6
      00736B 12 7B 8D         [24]  985 	lcall	_ak820_resolve_key
      00736E 12 96 82         [24]  986 	lcall	_action_for_keycode
      007371 12 43 A5         [24]  987 	lcall	_ak820_outline_0145
      007374 D0 06            [24]  988 	pop	ar6
      007376 D0 07            [24]  989 	pop	ar7
      007378 90 08 30         [24]  990 	mov	dptr,#_process_record_handler_action_10000_642
      00737B 12 38 1C         [24]  991 	lcall	_ak820_outline_0071
                                    992 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00737E                        993 00104$:
                                    994 ;	quantum/action.c:429: process_action(record, action);
      00737E 90 0D 7C         [24]  995 	mov	dptr,#___memcpy_PARM_2
      007381 74 30            [12]  996 	mov	a,#_process_record_handler_action_10000_642
      007383 F0               [24]  997 	movx	@dptr,a
      007384 74 08            [12]  998 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007386 12 78 21         [24]  999 	lcall	_ak820_outline_0050
      007389 12 50 45         [24] 1000 	lcall	_ak820_outline_0107
      00738C 90 08 32         [24] 1001 	mov	dptr,#_process_action_PARM_2
      00738F F5 F0            [12] 1002 	mov	b,a
      007391 C0 07            [24] 1003 	push	ar7
      007393 C0 06            [24] 1004 	push	ar6
      007395 12 B8 97         [24] 1005 	lcall	___memcpy
      007398 D0 06            [24] 1006 	pop	ar6
      00739A D0 07            [24] 1007 	pop	ar7
      00739C 12 43 84         [24] 1008 	lcall	_ak820_outline_0117
                                   1009 ;	quantum/action.c:430: }
      00739F 61 A1            [24] 1010 	ajmp	_process_action
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'register_mouse'
                                   1013 ;------------------------------------------------------------
                                   1014 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1015 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function process_action
                                   1020 ;	-----------------------------------------
      0073A1                       1021 _process_action:
      0073A1 12 38 40         [24] 1022 	lcall	_ak820_outline_0104
      0073A4 90 08 34         [24] 1023 	mov	dptr,#_process_action_record_argument_10000_653
      0073A7 12 38 45         [24] 1024 	lcall	_ak820_outline_0105
                                   1025 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073AA 90 08 34         [24] 1026 	mov	dptr,#_process_action_record_argument_10000_653
      0073AD 12 37 97         [24] 1027 	lcall	_ak820_outline_0004
                                   1028 ;	quantum/action.c:501: pressed = record->event.pressed;
      0073B0 A3               [24] 1029 	inc	dptr
      0073B1 A3               [24] 1030 	inc	dptr
      0073B2 A3               [24] 1031 	inc	dptr
      0073B3 A3               [24] 1032 	inc	dptr
      0073B4 A3               [24] 1033 	inc	dptr
      0073B5 E0               [24] 1034 	movx	a,@dptr
      0073B6 F5 27            [12] 1035 	mov	_process_action_sloc0_1_0,a
                                   1036 ;	quantum/action.c:525: switch (action.kind.id) {
      0073B8 90 08 33         [24] 1037 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073BB E0               [24] 1038 	movx	a,@dptr
      0073BC C4               [12] 1039 	swap	a
      0073BD 54 0F            [12] 1040 	anl	a,#0x0f
      0073BF FD               [12] 1041 	mov  r5,a
      0073C0 24 F4            [12] 1042 	add	a,#0xff - 0x0b
      0073C2 50 03            [24] 1043 	jnc	00434$
      0073C4 02 76 42         [24] 1044 	ljmp	00181$
      0073C7                       1045 00434$:
                                   1046 ;	free result
      0073C7 ED               [12] 1047 	mov	a,r5
      0073C8 24 0A            [12] 1048 	add	a,#(00435$-3-.)
      0073CA 83               [24] 1049 	movc	a,@a+pc
      0073CB F5 82            [12] 1050 	mov	dpl,a
      0073CD ED               [12] 1051 	mov	a,r5
      0073CE 24 10            [12] 1052 	add	a,#(00436$-3-.)
      0073D0 83               [24] 1053 	movc	a,@a+pc
      0073D1 F5 83            [12] 1054 	mov	dph,a
      0073D3 E4               [12] 1055 	clr	a
      0073D4 73               [24] 1056 	jmp	@a+dptr
      0073D5                       1057 00435$:
      0073D5 ED                    1058 	.db	00102$
      0073D6 ED                    1059 	.db	00102$
      0073D7 42                    1060 	.db	00181$
      0073D8 42                    1061 	.db	00181$
      0073D9 77                    1062 	.db	00123$
      0073DA 42                    1063 	.db	00181$
      0073DB 42                    1064 	.db	00181$
      0073DC 42                    1065 	.db	00181$
      0073DD D7                    1066 	.db	00131$
      0073DE A9                    1067 	.db	00147$
      0073DF CF                    1068 	.db	00152$
      0073E0 CF                    1069 	.db	00152$
      0073E1                       1070 00436$:
      0073E1 73                    1071 	.db	00102$>>8
      0073E2 73                    1072 	.db	00102$>>8
      0073E3 76                    1073 	.db	00181$>>8
      0073E4 76                    1074 	.db	00181$>>8
      0073E5 74                    1075 	.db	00123$>>8
      0073E6 76                    1076 	.db	00181$>>8
      0073E7 76                    1077 	.db	00181$>>8
      0073E8 76                    1078 	.db	00181$>>8
      0073E9 74                    1079 	.db	00131$>>8
      0073EA 75                    1080 	.db	00147$>>8
      0073EB 75                    1081 	.db	00152$>>8
      0073EC 75                    1082 	.db	00152$>>8
                                   1083 ;	quantum/action.c:528: case ACT_RMODS: {
      0073ED                       1084 00102$:
                                   1085 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0073ED 90 08 33         [24] 1086 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073F0 E0               [24] 1087 	movx	a,@dptr
      0073F1 54 F0            [12] 1088 	anl	a,#0xf0
      0073F3 70 06            [24] 1089 	jnz	00194$
      0073F5 12 78 48         [24] 1090 	lcall	_ak820_outline_0110
      0073F8 FD               [12] 1091 	mov	r5,a
      0073F9 80 07            [24] 1092 	sjmp	00195$
      0073FB                       1093 00194$:
      0073FB 12 78 48         [24] 1094 	lcall	_ak820_outline_0110
      0073FE C4               [12] 1095 	swap	a
      0073FF 54 F0            [12] 1096 	anl	a,#0xf0
      007401 FD               [12] 1097 	mov	r5,a
      007402                       1098 00195$:
                                   1099 ;	quantum/action.c:531: if (pressed) {
      007402 E5 27            [12] 1100 	mov	a,_process_action_sloc0_1_0
      007404 60 35            [24] 1101 	jz	00119$
                                   1102 ;	quantum/action.c:532: if (mods) {
      007406 ED               [12] 1103 	mov	a,r5
      007407 60 29            [24] 1104 	jz	00110$
                                   1105 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007409 12 78 5A         [24] 1106 	lcall	_ak820_outline_0154
      00740C FC               [12] 1107 	mov	r4,a
      00740D BC E0 00         [24] 1108 	cjne	r4,#0xe0,00440$
      007410                       1109 00440$:
      007410 40 07            [24] 1110 	jc	00108$
      007412 12 78 5A         [24] 1111 	lcall	_ak820_outline_0154
      007415 24 18            [12] 1112 	add	a,#0xff - 0xe7
      007417 50 0A            [24] 1113 	jnc	00104$
                                   1114 ;	free result
      007419                       1115 00108$:
      007419 7B 32            [12] 1116 	mov	r3,#_process_action_PARM_2
      00741B 7C 08            [12] 1117 	mov	r4,#(_process_action_PARM_2 >> 8)
      00741D 12 33 FC         [24] 1118 	lcall	_ak820_outline_0122
      007420 E0               [24] 1119 	movx	a,@dptr
      007421 70 07            [24] 1120 	jnz	00105$
      007423                       1121 00104$:
                                   1122 ;	quantum/action.c:537: add_owned_mods(mods);
      007423 8D 82            [24] 1123 	mov	dpl, r5
      007425 12 7E 6D         [24] 1124 	lcall	_add_owned_mods
      007428 80 05            [24] 1125 	sjmp	00106$
      00742A                       1126 00105$:
                                   1127 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      00742A 8D 82            [24] 1128 	mov	dpl, r5
      00742C 12 7E 8A         [24] 1129 	lcall	_add_owned_weak_mods
      00742F                       1130 00106$:
                                   1131 ;	quantum/action.c:541: send_keyboard_report();
      00742F 12 81 A3         [24] 1132 	lcall	_send_keyboard_report
      007432                       1133 00110$:
                                   1134 ;	quantum/action.c:543: register_code(action.key.code);
      007432 12 78 31         [24] 1135 	lcall	_ak820_outline_0075
      007435 12 76 59         [24] 1136 	lcall	_register_code
      007438 02 76 42         [24] 1137 	ljmp	00181$
      00743B                       1138 00119$:
                                   1139 ;	quantum/action.c:545: unregister_code(action.key.code);
      00743B 12 78 31         [24] 1140 	lcall	_ak820_outline_0075
      00743E C0 05            [24] 1141 	push	ar5
      007440 12 76 C6         [24] 1142 	lcall	_unregister_code
      007443 D0 05            [24] 1143 	pop	ar5
                                   1144 ;	quantum/action.c:546: if (mods) {
      007445 ED               [12] 1145 	mov	a,r5
      007446 70 03            [24] 1146 	jnz	00444$
      007448 02 76 42         [24] 1147 	ljmp	00181$
      00744B                       1148 00444$:
                                   1149 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00744B 12 78 5A         [24] 1150 	lcall	_ak820_outline_0154
      00744E FC               [12] 1151 	mov	r4,a
      00744F BC E0 00         [24] 1152 	cjne	r4,#0xe0,00445$
      007452                       1153 00445$:
      007452 40 07            [24] 1154 	jc	00115$
      007454 12 78 5A         [24] 1155 	lcall	_ak820_outline_0154
      007457 24 18            [12] 1156 	add	a,#0xff - 0xe7
      007459 50 0A            [24] 1157 	jnc	00111$
                                   1158 ;	free result
      00745B                       1159 00115$:
      00745B 7B 32            [12] 1160 	mov	r3,#_process_action_PARM_2
      00745D 7C 08            [12] 1161 	mov	r4,#(_process_action_PARM_2 >> 8)
      00745F 12 33 FC         [24] 1162 	lcall	_ak820_outline_0122
      007462 E0               [24] 1163 	movx	a,@dptr
      007463 70 07            [24] 1164 	jnz	00112$
      007465                       1165 00111$:
                                   1166 ;	quantum/action.c:548: del_owned_mods(mods);
      007465 8D 82            [24] 1167 	mov	dpl, r5
      007467 12 7E 7C         [24] 1168 	lcall	_del_owned_mods
      00746A 80 05            [24] 1169 	sjmp	00113$
      00746C                       1170 00112$:
                                   1171 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00746C 8D 82            [24] 1172 	mov	dpl, r5
      00746E 12 7E 99         [24] 1173 	lcall	_del_owned_weak_mods
      007471                       1174 00113$:
                                   1175 ;	quantum/action.c:552: send_keyboard_report();
      007471 12 81 A3         [24] 1176 	lcall	_send_keyboard_report
                                   1177 ;	quantum/action.c:555: } break;
      007474 02 76 42         [24] 1178 	ljmp	00181$
                                   1179 ;	quantum/action.c:632: case ACT_USAGE:
      007477                       1180 00123$:
                                   1181 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007477 74 07            [12] 1182 	mov	a,#0x07
      007479 12 37 E7         [24] 1183 	lcall	_ak820_outline_0031
      00747C 12 37 C2         [24] 1184 	lcall	_ak820_outline_0011
      00747F C3               [12] 1185 	clr	c
      007480 EC               [12] 1186 	mov	a,r4
      007481 94 A5            [12] 1187 	subb	a,#0xa5
      007483 ED               [12] 1188 	mov	a,r5
      007484 94 00            [12] 1189 	subb	a,#0x00
      007486 40 15            [24] 1190 	jc	00125$
      007488 74 C2            [12] 1191 	mov	a,#0xc2
      00748A 9C               [12] 1192 	subb	a,r4
      00748B E4               [12] 1193 	clr	a
      00748C 9D               [12] 1194 	subb	a,r5
      00748D 40 0E            [24] 1195 	jc	00125$
                                   1196 ;	free result
                                   1197 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      00748F 90 0A 95         [24] 1198 	mov	dptr,#_owned_usage_key_PARM_2
      007492 E5 27            [12] 1199 	mov	a,_process_action_sloc0_1_0
      007494 F0               [24] 1200 	movx	@dptr,a
      007495 8E 82            [24] 1201 	mov	dpl, r6
      007497 12 80 4F         [24] 1202 	lcall	_owned_usage_key
                                   1203 ;	quantum/action.c:640: break;
      00749A 02 76 42         [24] 1204 	ljmp	00181$
      00749D                       1205 00125$:
                                   1206 ;	quantum/action.c:643: switch (action.usage.page) {
      00749D 12 78 38         [24] 1207 	lcall	_ak820_outline_0085
      0074A0 FF               [12] 1208 	mov	r7,a
      0074A1 60 08            [24] 1209 	jz	00127$
      0074A3 BF 01 02         [24] 1210 	cjne	r7,#0x01,00452$
      0074A6 80 19            [24] 1211 	sjmp	00128$
      0074A8                       1212 00452$:
      0074A8 02 76 42         [24] 1213 	ljmp	00181$
                                   1214 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0074AB                       1215 00127$:
                                   1216 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0074AB E5 27            [12] 1217 	mov	a,_process_action_sloc0_1_0
      0074AD 60 05            [24] 1218 	jz	00196$
      0074AF 12 78 4F         [24] 1219 	lcall	_ak820_outline_0129
      0074B2 80 04            [24] 1220 	sjmp	00197$
      0074B4                       1221 00196$:
      0074B4 7E 00            [12] 1222 	mov	r6,#0x00
      0074B6 7F 00            [12] 1223 	mov	r7,#0x00
      0074B8                       1224 00197$:
      0074B8 12 43 84         [24] 1225 	lcall	_ak820_outline_0117
      0074BB 12 6E AA         [24] 1226 	lcall	_host_system_send
                                   1227 ;	quantum/action.c:646: break;
      0074BE 02 76 42         [24] 1228 	ljmp	00181$
                                   1229 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0074C1                       1230 00128$:
                                   1231 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0074C1 E5 27            [12] 1232 	mov	a,_process_action_sloc0_1_0
      0074C3 60 05            [24] 1233 	jz	00198$
      0074C5 12 78 4F         [24] 1234 	lcall	_ak820_outline_0129
      0074C8 80 04            [24] 1235 	sjmp	00199$
      0074CA                       1236 00198$:
      0074CA 7E 00            [12] 1237 	mov	r6,#0x00
      0074CC 7F 00            [12] 1238 	mov	r7,#0x00
      0074CE                       1239 00199$:
      0074CE 12 43 84         [24] 1240 	lcall	_ak820_outline_0117
      0074D1 12 6E D9         [24] 1241 	lcall	_host_consumer_send
                                   1242 ;	quantum/action.c:651: break;
      0074D4 02 76 42         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:658: case ACT_LAYER: {
      0074D7                       1245 00131$:
                                   1246 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      0074D7 90 08 33         [24] 1247 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074DA E0               [24] 1248 	movx	a,@dptr
      0074DB 54 03            [12] 1249 	anl	a,#0x03
      0074DD 90 08 36         [24] 1250 	mov	dptr,#_process_action_on_40000_676
      0074E0 F0               [24] 1251 	movx	@dptr,a
                                   1252 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0074E1 E0               [24] 1253 	movx	a,@dptr
      0074E2 FF               [12] 1254 	mov	r7,a
      0074E3 60 11            [24] 1255 	jz	00200$
      0074E5 E5 27            [12] 1256 	mov	a,_process_action_sloc0_1_0
      0074E7 60 07            [24] 1257 	jz	00202$
      0074E9 8F 06            [24] 1258 	mov	ar6,r7
      0074EB 53 06 01         [24] 1259 	anl	ar6,#0x01
      0074EE 80 10            [24] 1260 	sjmp	00201$
      0074F0                       1261 00202$:
      0074F0 74 02            [12] 1262 	mov	a,#0x02
      0074F2 5F               [12] 1263 	anl	a,r7
      0074F3 FE               [12] 1264 	mov	r6,a
      0074F4 80 0A            [24] 1265 	sjmp	00201$
      0074F6                       1266 00200$:
      0074F6 E5 27            [12] 1267 	mov	a,_process_action_sloc0_1_0
      0074F8 B4 01 00         [24] 1268 	cjne	a,#0x01,00457$
      0074FB                       1269 00457$:
      0074FB 92 1D            [24] 1270 	mov  _process_action_sloc1_1_0,c
      0074FD E4               [12] 1271 	clr	a
      0074FE 33               [12] 1272 	rlc	a
      0074FF FE               [12] 1273 	mov	r6,a
      007500                       1274 00201$:
      007500 EE               [12] 1275 	mov	a,r6
      007501 70 03            [24] 1276 	jnz	00458$
      007503 02 76 42         [24] 1277 	ljmp	00181$
      007506                       1278 00458$:
                                   1279 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007506 12 78 5A         [24] 1280 	lcall	_ak820_outline_0154
      007509 C4               [12] 1281 	swap	a
      00750A 03               [12] 1282 	rr	a
      00750B 54 07            [12] 1283 	anl	a,#0x07
      00750D 25 E0            [12] 1284 	add	a,acc
      00750F 25 E0            [12] 1285 	add	a,acc
      007511 FF               [12] 1286 	mov	r7,a
                                   1287 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007512 12 78 5A         [24] 1288 	lcall	_ak820_outline_0154
      007515 54 0F            [12] 1289 	anl	a,#0x0f
      007517 FE               [12] 1290 	mov	r6,a
      007518 8F F0            [24] 1291 	mov	b,r7
      00751A 05 F0            [12] 1292 	inc	b
      00751C EE               [12] 1293 	mov	a,r6
      00751D 80 02            [24] 1294 	sjmp	00460$
      00751F                       1295 00459$:
      00751F 25 E0            [12] 1296 	add	a,acc
      007521                       1297 00460$:
      007521 D5 F0 FB         [24] 1298 	djnz	b,00459$
      007524 FE               [12] 1299 	mov	r6,a
                                   1300 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007525 12 78 5A         [24] 1301 	lcall	_ak820_outline_0154
      007528 30 E4 11         [24] 1302 	jnb	acc.4,00204$
      00752B 8F F0            [24] 1303 	mov	b,r7
      00752D 05 F0            [12] 1304 	inc	b
      00752F 74 0F            [12] 1305 	mov	a,#0x0f
      007531 80 02            [24] 1306 	sjmp	00463$
      007533                       1307 00462$:
      007533 25 E0            [12] 1308 	add	a,acc
      007535                       1309 00463$:
      007535 D5 F0 FB         [24] 1310 	djnz	b,00462$
      007538 F4               [12] 1311 	cpl	a
      007539 FF               [12] 1312 	mov	r7,a
      00753A 80 02            [24] 1313 	sjmp	00205$
      00753C                       1314 00204$:
      00753C 7F 00            [12] 1315 	mov	r7,#0x00
      00753E                       1316 00205$:
                                   1317 ;	quantum/action.c:666: bits |= mask;
      00753E EE               [12] 1318 	mov	a,r6
      00753F 42 07            [12] 1319 	orl	ar7,a
                                   1320 ;	quantum/action.c:667: if (!on) {
      007541 90 08 36         [24] 1321 	mov	dptr,#_process_action_on_40000_676
      007544 E0               [24] 1322 	movx	a,@dptr
      007545 70 31            [24] 1323 	jnz	00143$
                                   1324 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007547 12 78 38         [24] 1325 	lcall	_ak820_outline_0085
      00754A FE               [12] 1326 	mov	r6,a
      00754B 2E               [12] 1327 	add	a,r6
                                   1328 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      00754C 90 75 50         [24] 1329 	mov	dptr,#00465$
      00754F 73               [24] 1330 	jmp	@a+dptr
      007550                       1331 00465$:
      007550 80 06            [24] 1332 	sjmp	00132$
      007552 80 0C            [24] 1333 	sjmp	00133$
      007554 80 12            [24] 1334 	sjmp	00134$
      007556 80 18            [24] 1335 	sjmp	00135$
      007558                       1336 00132$:
      007558 8F 82            [24] 1337 	mov	dpl, r7
      00755A 12 78 B0         [24] 1338 	lcall	_default_layer_and
      00755D 02 76 42         [24] 1339 	ljmp	00181$
                                   1340 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007560                       1341 00133$:
      007560 8F 82            [24] 1342 	mov	dpl, r7
      007562 12 78 A0         [24] 1343 	lcall	_default_layer_or
      007565 02 76 42         [24] 1344 	ljmp	00181$
                                   1345 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007568                       1346 00134$:
      007568 8F 82            [24] 1347 	mov	dpl, r7
      00756A 12 78 C5         [24] 1348 	lcall	_default_layer_xor
      00756D 02 76 42         [24] 1349 	ljmp	00181$
                                   1350 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007570                       1351 00135$:
      007570 8F 82            [24] 1352 	mov	dpl, r7
      007572 12 78 96         [24] 1353 	lcall	_default_layer_set
                                   1354 ;	quantum/action.c:673: }
      007575 02 76 42         [24] 1355 	ljmp	00181$
      007578                       1356 00143$:
                                   1357 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007578 12 78 38         [24] 1358 	lcall	_ak820_outline_0085
      00757B FE               [12] 1359 	mov	r6,a
      00757C 2E               [12] 1360 	add	a,r6
                                   1361 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00757D 90 75 81         [24] 1362 	mov	dptr,#00466$
      007580 73               [24] 1363 	jmp	@a+dptr
      007581                       1364 00466$:
      007581 80 06            [24] 1365 	sjmp	00137$
      007583 80 0C            [24] 1366 	sjmp	00138$
      007585 80 12            [24] 1367 	sjmp	00139$
      007587 80 18            [24] 1368 	sjmp	00140$
      007589                       1369 00137$:
      007589 8F 82            [24] 1370 	mov	dpl, r7
      00758B 12 7A 3A         [24] 1371 	lcall	_layer_and
      00758E 02 76 42         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007591                       1374 00138$:
      007591 8F 82            [24] 1375 	mov	dpl, r7
      007593 12 7A 2A         [24] 1376 	lcall	_layer_or
      007596 02 76 42         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007599                       1379 00139$:
      007599 8F 82            [24] 1380 	mov	dpl, r7
      00759B 12 7A 4F         [24] 1381 	lcall	_layer_xor
      00759E 02 76 42         [24] 1382 	ljmp	00181$
                                   1383 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0075A1                       1384 00140$:
      0075A1 8F 82            [24] 1385 	mov	dpl, r7
      0075A3 12 79 CC         [24] 1386 	lcall	_layer_state_set
                                   1387 ;	quantum/action.c:683: break;
      0075A6 02 76 42         [24] 1388 	ljmp	00181$
                                   1389 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      0075A9                       1390 00147$:
                                   1391 ;	quantum/action.c:686: if (pressed) {
      0075A9 E5 27            [12] 1392 	mov	a,_process_action_sloc0_1_0
      0075AB 60 11            [24] 1393 	jz	00149$
                                   1394 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      0075AD 12 78 48         [24] 1395 	lcall	_ak820_outline_0110
      0075B0 F5 82            [12] 1396 	mov	dpl,a
      0075B2 12 79 33         [24] 1397 	lcall	_layer_hold_on
                                   1398 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      0075B5 12 78 31         [24] 1399 	lcall	_ak820_outline_0075
      0075B8 12 77 79         [24] 1400 	lcall	_register_mods
      0075BB 02 76 42         [24] 1401 	ljmp	00181$
      0075BE                       1402 00149$:
                                   1403 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      0075BE 12 78 31         [24] 1404 	lcall	_ak820_outline_0075
      0075C1 12 77 8D         [24] 1405 	lcall	_unregister_mods
                                   1406 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      0075C4 12 78 48         [24] 1407 	lcall	_ak820_outline_0110
      0075C7 F5 82            [12] 1408 	mov	dpl,a
      0075C9 12 79 69         [24] 1409 	lcall	_layer_hold_off
                                   1410 ;	quantum/action.c:693: break;
      0075CC 02 76 42         [24] 1411 	ljmp	00181$
                                   1412 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      0075CF                       1413 00152$:
                                   1414 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      0075CF 12 78 5A         [24] 1415 	lcall	_ak820_outline_0154
      0075D2 FF               [12] 1416 	mov	r7,a
      0075D3 BF F1 02         [24] 1417 	cjne	r7,#0xf1,00468$
      0075D6 80 0A            [24] 1418 	sjmp	00154$
      0075D8                       1419 00468$:
      0075D8 BF F2 02         [24] 1420 	cjne	r7,#0xf2,00469$
      0075DB 80 19            [24] 1421 	sjmp	00155$
      0075DD                       1422 00469$:
                                   1423 ;	quantum/action.c:712: momentary_layer_action:
      0075DD BF F3 3B         [24] 1424 	cjne	r7,#0xf3,00160$
      0075E0 80 28            [24] 1425 	sjmp	00156$
      0075E2                       1426 00154$:
                                   1427 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0075E2 E5 27            [12] 1428 	mov	a,_process_action_sloc0_1_0
      0075E4 60 08            [24] 1429 	jz	00206$
      0075E6 12 78 18         [24] 1430 	lcall	_ak820_outline_0039
      0075E9 12 79 33         [24] 1431 	lcall	_layer_hold_on
      0075EC 80 54            [24] 1432 	sjmp	00181$
      0075EE                       1433 00206$:
      0075EE 12 78 18         [24] 1434 	lcall	_ak820_outline_0039
      0075F1 12 79 69         [24] 1435 	lcall	_layer_hold_off
                                   1436 ;	quantum/action.c:714: break;
                                   1437 ;	quantum/action.c:715: case OP_OFF_ON:
      0075F4 80 4C            [24] 1438 	sjmp	00181$
      0075F6                       1439 00155$:
                                   1440 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0075F6 E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      0075F8 60 08            [24] 1442 	jz	00208$
      0075FA 12 78 18         [24] 1443 	lcall	_ak820_outline_0039
      0075FD 12 7A 0D         [24] 1444 	lcall	_layer_off
      007600 80 40            [24] 1445 	sjmp	00181$
      007602                       1446 00208$:
      007602 12 78 18         [24] 1447 	lcall	_ak820_outline_0039
      007605 12 79 F3         [24] 1448 	lcall	_layer_on
                                   1449 ;	quantum/action.c:717: break;
                                   1450 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007608 80 38            [24] 1451 	sjmp	00181$
      00760A                       1452 00156$:
                                   1453 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00760A E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      00760C 60 08            [24] 1455 	jz	00210$
      00760E 12 78 18         [24] 1456 	lcall	_ak820_outline_0039
      007611 12 79 DE         [24] 1457 	lcall	_layer_move
      007614 80 2C            [24] 1458 	sjmp	00181$
      007616                       1459 00210$:
      007616 12 79 D9         [24] 1460 	lcall	_layer_clear
                                   1461 ;	quantum/action.c:720: break;
                                   1462 ;	quantum/action.c:766: default:
      007619 80 27            [24] 1463 	sjmp	00181$
      00761B                       1464 00160$:
                                   1465 ;	quantum/action.c:773: if (pressed) {
      00761B E5 27            [12] 1466 	mov	a,_process_action_sloc0_1_0
      00761D 60 08            [24] 1467 	jz	00163$
                                   1468 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00761F 12 78 31         [24] 1469 	lcall	_ak820_outline_0075
      007622 12 76 59         [24] 1470 	lcall	_register_code
                                   1471 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007625 80 1B            [24] 1472 	sjmp	00181$
      007627                       1473 00163$:
                                   1474 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007627 12 78 5A         [24] 1475 	lcall	_ak820_outline_0154
      00762A FF               [12] 1476 	mov	r7,a
      00762B BF 39 0E         [24] 1477 	cjne	r7,#0x39,00175$
                                   1478 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00762E 7F 50            [12] 1479 	mov	r7,#0x50
      007630                       1480 00187$:
      007630 EF               [12] 1481 	mov	a,r7
      007631 60 09            [24] 1482 	jz	00175$
      007633 90 00 01         [24] 1483 	mov	dptr,#0x0001
      007636 12 59 9E         [24] 1484 	lcall	_mDelaymS
      007639 1F               [12] 1485 	dec	r7
                                   1486 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      00763A 80 F4            [24] 1487 	sjmp	00187$
      00763C                       1488 00175$:
                                   1489 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      00763C 12 78 31         [24] 1490 	lcall	_ak820_outline_0075
      00763F 12 76 C6         [24] 1491 	lcall	_unregister_code
                                   1492 ;	quantum/action.c:866: }
      007642                       1493 00181$:
                                   1494 ;	quantum/action.c:887: switch (action.kind.id) {
      007642 90 08 33         [24] 1495 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007645 E0               [24] 1496 	movx	a,@dptr
      007646 C4               [12] 1497 	swap	a
      007647 54 0F            [12] 1498 	anl	a,#0x0f
      007649 FF               [12] 1499 	mov	r7,a
      00764A BF 08 02         [24] 1500 	cjne	r7,#0x08,00478$
      00764D 80 03            [24] 1501 	sjmp	00183$
      00764F                       1502 00478$:
      00764F BF 09 06         [24] 1503 	cjne	r7,#0x09,00192$
                                   1504 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007652                       1505 00183$:
                                   1506 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007652 12 6E 0F         [24] 1507 	lcall	_host_keyboard_leds
                                   1508 ;	quantum/action.c:898: }
                                   1509 ;	quantum/action.c:951: }
      007655 02 99 35         [24] 1510 	ljmp	_led_set
      007658                       1511 00192$:
      007658 22               [24] 1512 	ret
                                   1513 ;------------------------------------------------------------
                                   1514 ;Allocation info for local variables in function 'register_code'
                                   1515 ;------------------------------------------------------------
                                   1516 ;code          Allocated with name '_register_code_code_10000_710'
                                   1517 ;------------------------------------------------------------
                                   1518 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1519 ;	-----------------------------------------
                                   1520 ;	 function register_code
                                   1521 ;	-----------------------------------------
      007659                       1522 _register_code:
      007659 E5 82            [12] 1523 	mov	a,dpl
      00765B 90 08 37         [24] 1524 	mov	dptr,#_register_code_code_10000_710
      00765E F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action.c:958: if (code == KC_NO) {
      00765F E0               [24] 1527 	movx	a,@dptr
      007660 FF               [12] 1528 	mov	r7,a
      007661 70 01            [24] 1529 	jnz	00123$
                                   1530 ;	quantum/action.c:959: return;
      007663 22               [24] 1531 	ret
      007664                       1532 00123$:
                                   1533 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007664 BF 04 00         [24] 1534 	cjne	r7,#0x04,00186$
      007667                       1535 00186$:
      007667 40 12            [24] 1536 	jc	00119$
      007669 EF               [12] 1537 	mov	a,r7
      00766A 24 5B            [12] 1538 	add	a,#0xff - 0xa4
      00766C 40 0D            [24] 1539 	jc	00119$
                                   1540 ;	free result
                                   1541 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00766E 8F 82            [24] 1542 	mov	dpl, r7
      007670 12 7F 0D         [24] 1543 	lcall	_add_owned_key
      007673 E5 82            [12] 1544 	mov	a, dpl
      007675 70 01            [24] 1545 	jnz	00104$
      007677 22               [24] 1546 	ret
      007678                       1547 00104$:
                                   1548 ;	quantum/action.c:1013: send_keyboard_report();
      007678 02 81 A3         [24] 1549 	ljmp	_send_keyboard_report
      00767B                       1550 00119$:
                                   1551 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      00767B 12 78 5F         [24] 1552 	lcall	_ak820_outline_0162
      00767E BF E0 00         [24] 1553 	cjne	r7,#0xe0,00190$
      007681                       1554 00190$:
      007681 40 1A            [24] 1555 	jc	00115$
      007683 EF               [12] 1556 	mov	a,r7
      007684 24 18            [12] 1557 	add	a,#0xff - 0xe7
      007686 40 15            [24] 1558 	jc	00115$
                                   1559 ;	free result
                                   1560 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007688 74 07            [12] 1561 	mov	a,#0x07
      00768A 5F               [12] 1562 	anl	a,r7
      00768B 12 78 2A         [24] 1563 	lcall	_ak820_outline_0063
      00768E 80 02            [24] 1564 	sjmp	00194$
      007690                       1565 00193$:
      007690 25 E0            [12] 1566 	add	a,acc
      007692                       1567 00194$:
      007692 D5 F0 FB         [24] 1568 	djnz	b,00193$
      007695 F5 82            [12] 1569 	mov	dpl,a
      007697 12 7E 6D         [24] 1570 	lcall	_add_owned_mods
                                   1571 ;	quantum/action.c:1016: send_keyboard_report();
      00769A 02 81 A3         [24] 1572 	ljmp	_send_keyboard_report
      00769D                       1573 00115$:
                                   1574 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00769D 12 78 5F         [24] 1575 	lcall	_ak820_outline_0162
      0076A0 BF A5 00         [24] 1576 	cjne	r7,#0xa5,00195$
      0076A3                       1577 00195$:
      0076A3 40 05            [24] 1578 	jc	00113$
      0076A5 EF               [12] 1579 	mov	a,r7
      0076A6 24 58            [12] 1580 	add	a,#0xff - 0xa7
      0076A8 50 0D            [24] 1581 	jnc	00108$
                                   1582 ;	free result
      0076AA                       1583 00113$:
      0076AA 12 78 5F         [24] 1584 	lcall	_ak820_outline_0162
      0076AD BF A8 00         [24] 1585 	cjne	r7,#0xa8,00198$
      0076B0                       1586 00198$:
      0076B0 40 13            [24] 1587 	jc	00125$
      0076B2 EF               [12] 1588 	mov	a,r7
      0076B3 24 3D            [12] 1589 	add	a,#0xff - 0xc2
      0076B5 40 0E            [24] 1590 	jc	00125$
                                   1591 ;	free result
      0076B7                       1592 00108$:
                                   1593 ;	quantum/action.c:1021: owned_usage_key(code, true);
      0076B7 12 78 5F         [24] 1594 	lcall	_ak820_outline_0162
      0076BA 90 0A 95         [24] 1595 	mov	dptr,#_owned_usage_key_PARM_2
      0076BD 74 01            [12] 1596 	mov	a,#0x01
      0076BF F0               [24] 1597 	movx	@dptr,a
      0076C0 8F 82            [24] 1598 	mov	dpl, r7
                                   1599 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1600 ;	quantum/action.c:1031: }
      0076C2 02 80 4F         [24] 1601 	ljmp	_owned_usage_key
      0076C5                       1602 00125$:
      0076C5 22               [24] 1603 	ret
                                   1604 ;------------------------------------------------------------
                                   1605 ;Allocation info for local variables in function 'unregister_code'
                                   1606 ;------------------------------------------------------------
                                   1607 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1608 ;------------------------------------------------------------
                                   1609 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1610 ;	-----------------------------------------
                                   1611 ;	 function unregister_code
                                   1612 ;	-----------------------------------------
      0076C6                       1613 _unregister_code:
      0076C6 E5 82            [12] 1614 	mov	a,dpl
      0076C8 90 08 38         [24] 1615 	mov	dptr,#_unregister_code_code_10000_724
      0076CB F0               [24] 1616 	movx	@dptr,a
                                   1617 ;	quantum/action.c:1038: if (code == KC_NO) {
      0076CC E0               [24] 1618 	movx	a,@dptr
      0076CD FF               [12] 1619 	mov	r7,a
      0076CE 70 01            [24] 1620 	jnz	00121$
                                   1621 ;	quantum/action.c:1039: return;
      0076D0 22               [24] 1622 	ret
      0076D1                       1623 00121$:
                                   1624 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      0076D1 BF 04 00         [24] 1625 	cjne	r7,#0x04,00184$
      0076D4                       1626 00184$:
      0076D4 40 12            [24] 1627 	jc	00117$
      0076D6 EF               [12] 1628 	mov	a,r7
      0076D7 24 5B            [12] 1629 	add	a,#0xff - 0xa4
      0076D9 40 0D            [24] 1630 	jc	00117$
                                   1631 ;	free result
                                   1632 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      0076DB 8F 82            [24] 1633 	mov	dpl, r7
      0076DD 12 7F 86         [24] 1634 	lcall	_del_owned_key
      0076E0 E5 82            [12] 1635 	mov	a, dpl
      0076E2 70 01            [24] 1636 	jnz	00102$
      0076E4 22               [24] 1637 	ret
      0076E5                       1638 00102$:
                                   1639 ;	quantum/action.c:1080: send_keyboard_report();
      0076E5 02 81 A3         [24] 1640 	ljmp	_send_keyboard_report
      0076E8                       1641 00117$:
                                   1642 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      0076E8 12 78 65         [24] 1643 	lcall	_ak820_outline_0163
      0076EB BF E0 00         [24] 1644 	cjne	r7,#0xe0,00188$
      0076EE                       1645 00188$:
      0076EE 40 1A            [24] 1646 	jc	00113$
      0076F0 EF               [12] 1647 	mov	a,r7
      0076F1 24 18            [12] 1648 	add	a,#0xff - 0xe7
      0076F3 40 15            [24] 1649 	jc	00113$
                                   1650 ;	free result
                                   1651 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0076F5 74 07            [12] 1652 	mov	a,#0x07
      0076F7 5F               [12] 1653 	anl	a,r7
      0076F8 12 78 2A         [24] 1654 	lcall	_ak820_outline_0063
      0076FB 80 02            [24] 1655 	sjmp	00192$
      0076FD                       1656 00191$:
      0076FD 25 E0            [12] 1657 	add	a,acc
      0076FF                       1658 00192$:
      0076FF D5 F0 FB         [24] 1659 	djnz	b,00191$
      007702 F5 82            [12] 1660 	mov	dpl,a
      007704 12 7E 7C         [24] 1661 	lcall	_del_owned_mods
                                   1662 ;	quantum/action.c:1083: send_keyboard_report();
      007707 02 81 A3         [24] 1663 	ljmp	_send_keyboard_report
      00770A                       1664 00113$:
                                   1665 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00770A 12 78 65         [24] 1666 	lcall	_ak820_outline_0163
      00770D BF A5 00         [24] 1667 	cjne	r7,#0xa5,00193$
      007710                       1668 00193$:
      007710 40 05            [24] 1669 	jc	00111$
      007712 EF               [12] 1670 	mov	a,r7
      007713 24 58            [12] 1671 	add	a,#0xff - 0xa7
      007715 50 0D            [24] 1672 	jnc	00106$
                                   1673 ;	free result
      007717                       1674 00111$:
      007717 12 78 65         [24] 1675 	lcall	_ak820_outline_0163
      00771A BF A8 00         [24] 1676 	cjne	r7,#0xa8,00196$
      00771D                       1677 00196$:
      00771D 40 12            [24] 1678 	jc	00123$
      00771F EF               [12] 1679 	mov	a,r7
      007720 24 3D            [12] 1680 	add	a,#0xff - 0xc2
      007722 40 0D            [24] 1681 	jc	00123$
                                   1682 ;	free result
      007724                       1683 00106$:
                                   1684 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007724 12 78 65         [24] 1685 	lcall	_ak820_outline_0163
      007727 90 0A 95         [24] 1686 	mov	dptr,#_owned_usage_key_PARM_2
      00772A E4               [12] 1687 	clr	a
      00772B F0               [24] 1688 	movx	@dptr,a
      00772C 8F 82            [24] 1689 	mov	dpl, r7
                                   1690 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1691 ;	quantum/action.c:1098: }
      00772E 02 80 4F         [24] 1692 	ljmp	_owned_usage_key
      007731                       1693 00123$:
      007731 22               [24] 1694 	ret
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'tap_code_delay'
                                   1697 ;------------------------------------------------------------
                                   1698 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1699 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1700 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1701 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1702 ;------------------------------------------------------------
                                   1703 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1704 ;	-----------------------------------------
                                   1705 ;	 function tap_code_delay
                                   1706 ;	-----------------------------------------
      007732                       1707 _tap_code_delay:
      007732 E5 82            [12] 1708 	mov	a,dpl
      007734 90 08 3B         [24] 1709 	mov	dptr,#_tap_code_delay_code_10000_737
      007737 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	quantum/action.c:1106: register_code(code);
      007738 E0               [24] 1712 	movx	a,@dptr
      007739 FF               [12] 1713 	mov	r7,a
      00773A F5 82            [12] 1714 	mov	dpl,a
      00773C C0 07            [24] 1715 	push	ar7
      00773E D1 59            [12] 1716 	acall	_register_code
      007740 D0 07            [24] 1717 	pop	ar7
                                   1718 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007742 90 08 39         [24] 1719 	mov	dptr,#_tap_code_delay_PARM_2
      007745 12 43 72         [24] 1720 	lcall	_ak820_outline_0097
      007748                       1721 00110$:
      007748 ED               [12] 1722 	mov	a,r5
      007749 4E               [12] 1723 	orl	a,r6
      00774A 60 0D            [24] 1724 	jz	00105$
                                   1725 ;	quantum/action.c:1108: wait_ms(1);
      00774C 90 00 01         [24] 1726 	mov	dptr,#0x0001
      00774F 12 59 9E         [24] 1727 	lcall	_mDelaymS
                                   1728 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007752 1D               [12] 1729 	dec	r5
      007753 BD FF 01         [24] 1730 	cjne	r5,#0xff,00141$
      007756 1E               [12] 1731 	dec	r6
      007757                       1732 00141$:
      007757 80 EF            [24] 1733 	sjmp	00110$
      007759                       1734 00105$:
                                   1735 ;	quantum/action.c:1110: unregister_code(code);
      007759 8F 82            [24] 1736 	mov	dpl, r7
                                   1737 ;	quantum/action.c:1111: }
      00775B C1 C6            [12] 1738 	ajmp	_unregister_code
                                   1739 ;------------------------------------------------------------
                                   1740 ;Allocation info for local variables in function 'tap_code'
                                   1741 ;------------------------------------------------------------
                                   1742 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1743 ;------------------------------------------------------------
                                   1744 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1745 ;	-----------------------------------------
                                   1746 ;	 function tap_code
                                   1747 ;	-----------------------------------------
      00775D                       1748 _tap_code:
      00775D E5 82            [12] 1749 	mov	a,dpl
      00775F 90 08 3C         [24] 1750 	mov	dptr,#_tap_code_code_10000_744
      007762 F0               [24] 1751 	movx	@dptr,a
                                   1752 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007763 E0               [24] 1753 	movx	a,@dptr
      007764 FF               [12] 1754 	mov	r7,a
      007765 BF 39 04         [24] 1755 	cjne	r7,#0x39,00103$
      007768 7E 50            [12] 1756 	mov	r6,#0x50
      00776A 80 02            [24] 1757 	sjmp	00104$
      00776C                       1758 00103$:
      00776C 7E 00            [12] 1759 	mov	r6,#0x00
      00776E                       1760 00104$:
      00776E 90 08 39         [24] 1761 	mov	dptr,#_tap_code_delay_PARM_2
      007771 EE               [12] 1762 	mov	a,r6
      007772 12 38 5C         [24] 1763 	lcall	_ak820_outline_0123
      007775 8F 82            [24] 1764 	mov	dpl, r7
                                   1765 ;	quantum/action.c:1119: }
      007777 E1 32            [12] 1766 	ajmp	_tap_code_delay
                                   1767 ;------------------------------------------------------------
                                   1768 ;Allocation info for local variables in function 'register_mods'
                                   1769 ;------------------------------------------------------------
                                   1770 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1771 ;------------------------------------------------------------
                                   1772 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1773 ;	-----------------------------------------
                                   1774 ;	 function register_mods
                                   1775 ;	-----------------------------------------
      007779                       1776 _register_mods:
      007779 E5 82            [12] 1777 	mov	a,dpl
      00777B 90 08 3D         [24] 1778 	mov	dptr,#_register_mods_mods_10000_746
      00777E F0               [24] 1779 	movx	@dptr,a
                                   1780 ;	quantum/action.c:1126: if (mods) {
      00777F E0               [24] 1781 	movx	a,@dptr
      007780 FF               [12] 1782 	mov	r7,a
      007781 E0               [24] 1783 	movx	a,@dptr
      007782 60 08            [24] 1784 	jz	00103$
                                   1785 ;	quantum/action.c:1127: add_owned_mods(mods);
      007784 8F 82            [24] 1786 	mov	dpl, r7
      007786 12 7E 6D         [24] 1787 	lcall	_add_owned_mods
                                   1788 ;	quantum/action.c:1128: send_keyboard_report();
                                   1789 ;	quantum/action.c:1130: }
      007789 02 81 A3         [24] 1790 	ljmp	_send_keyboard_report
      00778C                       1791 00103$:
      00778C 22               [24] 1792 	ret
                                   1793 ;------------------------------------------------------------
                                   1794 ;Allocation info for local variables in function 'unregister_mods'
                                   1795 ;------------------------------------------------------------
                                   1796 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1797 ;------------------------------------------------------------
                                   1798 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1799 ;	-----------------------------------------
                                   1800 ;	 function unregister_mods
                                   1801 ;	-----------------------------------------
      00778D                       1802 _unregister_mods:
      00778D E5 82            [12] 1803 	mov	a,dpl
      00778F 90 08 3E         [24] 1804 	mov	dptr,#_unregister_mods_mods_10000_750
      007792 F0               [24] 1805 	movx	@dptr,a
                                   1806 ;	quantum/action.c:1137: if (mods) {
      007793 E0               [24] 1807 	movx	a,@dptr
      007794 FF               [12] 1808 	mov	r7,a
      007795 E0               [24] 1809 	movx	a,@dptr
      007796 60 08            [24] 1810 	jz	00103$
                                   1811 ;	quantum/action.c:1138: del_owned_mods(mods);
      007798 8F 82            [24] 1812 	mov	dpl, r7
      00779A 12 7E 7C         [24] 1813 	lcall	_del_owned_mods
                                   1814 ;	quantum/action.c:1139: send_keyboard_report();
                                   1815 ;	quantum/action.c:1141: }
      00779D 02 81 A3         [24] 1816 	ljmp	_send_keyboard_report
      0077A0                       1817 00103$:
      0077A0 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'register_weak_mods'
                                   1821 ;------------------------------------------------------------
                                   1822 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1823 ;------------------------------------------------------------
                                   1824 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1825 ;	-----------------------------------------
                                   1826 ;	 function register_weak_mods
                                   1827 ;	-----------------------------------------
      0077A1                       1828 _register_weak_mods:
      0077A1 E5 82            [12] 1829 	mov	a,dpl
      0077A3 90 08 3F         [24] 1830 	mov	dptr,#_register_weak_mods_mods_10000_754
      0077A6 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	quantum/action.c:1148: if (mods) {
      0077A7 E0               [24] 1833 	movx	a,@dptr
      0077A8 FF               [12] 1834 	mov	r7,a
      0077A9 E0               [24] 1835 	movx	a,@dptr
      0077AA 60 08            [24] 1836 	jz	00103$
                                   1837 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      0077AC 8F 82            [24] 1838 	mov	dpl, r7
      0077AE 12 7E 8A         [24] 1839 	lcall	_add_owned_weak_mods
                                   1840 ;	quantum/action.c:1150: send_keyboard_report();
                                   1841 ;	quantum/action.c:1152: }
      0077B1 02 81 A3         [24] 1842 	ljmp	_send_keyboard_report
      0077B4                       1843 00103$:
      0077B4 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function unregister_weak_mods
                                   1853 ;	-----------------------------------------
      0077B5                       1854 _unregister_weak_mods:
      0077B5 E5 82            [12] 1855 	mov	a,dpl
      0077B7 90 08 40         [24] 1856 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      0077BA F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1159: if (mods) {
      0077BB E0               [24] 1859 	movx	a,@dptr
      0077BC FF               [12] 1860 	mov	r7,a
      0077BD E0               [24] 1861 	movx	a,@dptr
      0077BE 60 08            [24] 1862 	jz	00103$
                                   1863 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      0077C0 8F 82            [24] 1864 	mov	dpl, r7
      0077C2 12 7E 99         [24] 1865 	lcall	_del_owned_weak_mods
                                   1866 ;	quantum/action.c:1161: send_keyboard_report();
                                   1867 ;	quantum/action.c:1163: }
      0077C5 02 81 A3         [24] 1868 	ljmp	_send_keyboard_report
      0077C8                       1869 00103$:
      0077C8 22               [24] 1870 	ret
                                   1871 ;------------------------------------------------------------
                                   1872 ;Allocation info for local variables in function 'clear_keyboard'
                                   1873 ;------------------------------------------------------------
                                   1874 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1875 ;	-----------------------------------------
                                   1876 ;	 function clear_keyboard
                                   1877 ;	-----------------------------------------
      0077C9                       1878 _clear_keyboard:
                                   1879 ;	quantum/action.c:1170: clear_mods();
      0077C9 12 82 78         [24] 1880 	lcall	_clear_mods
                                   1881 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1882 ;	quantum/action.c:1172: }
      0077CC E1 CE            [12] 1883 	ajmp	_clear_keyboard_but_mods
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard_but_mods
                                   1890 ;	-----------------------------------------
      0077CE                       1891 _clear_keyboard_but_mods:
                                   1892 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0077CE 90 0D A1         [24] 1893 	mov	dptr,#_actual_keyboard_report
      0077D1 12 70 CC         [24] 1894 	lcall	_clear_keys_from_report
                                   1895 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1896 ;	quantum/action.c:1181: }
      0077D4 E1 D6            [12] 1897 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function clear_keyboard_but_mods_and_keys
                                   1904 ;	-----------------------------------------
      0077D6                       1905 _clear_keyboard_but_mods_and_keys:
                                   1906 ;	quantum/action.c:1189: ak820_tapping_cancel();
      0077D6 12 47 AA         [24] 1907 	lcall	_ak820_tapping_cancel
                                   1908 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      0077D9 12 2E A4         [24] 1909 	lcall	_ak820_oneshot_cancel
                                   1910 ;	quantum/action.c:1209: ak820_combo_cancel();
      0077DC 12 35 27         [24] 1911 	lcall	_ak820_combo_cancel
                                   1912 ;	quantum/action.c:1212: repeat_key_cancel();
      0077DF 12 A2 32         [24] 1913 	lcall	_repeat_key_cancel
                                   1914 ;	quantum/action.c:1214: clear_owned_mods();
      0077E2 12 7E A8         [24] 1915 	lcall	_clear_owned_mods
                                   1916 ;	quantum/action.c:1215: clear_owned_keys();
      0077E5 12 7E E0         [24] 1917 	lcall	_clear_owned_keys
                                   1918 ;	quantum/action.c:1216: clear_owned_usages();
      0077E8 12 80 17         [24] 1919 	lcall	_clear_owned_usages
                                   1920 ;	quantum/action.c:1217: layer_hold_clear();
      0077EB 12 79 9F         [24] 1921 	lcall	_layer_hold_clear
                                   1922 ;	quantum/action.c:1219: clear_macro_tri_layer();
      0077EE 12 9D BC         [24] 1923 	lcall	_clear_macro_tri_layer
                                   1924 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0077F1 90 0D A1         [24] 1925 	mov	dptr,#_actual_keyboard_report
      0077F4 12 70 CC         [24] 1926 	lcall	_clear_keys_from_report
                                   1927 ;	quantum/action.c:1224: host_system_send(0);
      0077F7 90 00 00         [24] 1928 	mov	dptr,#0x0000
      0077FA 12 6E AA         [24] 1929 	lcall	_host_system_send
                                   1930 ;	quantum/action.c:1225: host_consumer_send(0);
      0077FD 90 00 00         [24] 1931 	mov	dptr,#0x0000
      007800 12 6E D9         [24] 1932 	lcall	_host_consumer_send
                                   1933 ;	quantum/action.c:1227: clear_weak_mods();
      007803 12 82 AD         [24] 1934 	lcall	_clear_weak_mods
                                   1935 ;	quantum/action.c:1228: send_keyboard_report();
                                   1936 ;	quantum/action.c:1236: }
      007806 02 81 A3         [24] 1937 	ljmp	_send_keyboard_report
                                   1938 ;------------------------------------------------------------
                                   1939 ;Allocation info for local variables in function 'is_tap_record'
                                   1940 ;------------------------------------------------------------
                                   1941 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1942 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1945 ;	-----------------------------------------
                                   1946 	.area CSEG    (CODE)
                                   1947 	.area CONST   (CODE)
                                   1948 	.area XINIT   (CODE)
      00C167                       1949 __xinit__disable_action_cache:
      00C167 00                    1950 	.db #0x00	;  0
                                   1951 	.area CABS    (ABS,CODE)
                                   1952 
                                   1953 ; Experimental exact instruction outlining.
                                   1954 	.globl _ak820_outline_0004
                                   1955 	.globl _ak820_outline_0009
                                   1956 	.globl _ak820_outline_0010
                                   1957 	.globl _ak820_outline_0011
                                   1958 	.globl _ak820_outline_0012
                                   1959 	.globl _ak820_outline_0016
                                   1960 	.globl _ak820_outline_0017
                                   1961 	.globl _ak820_outline_0019
                                   1962 	.globl _ak820_outline_0031
                                   1963 	.globl _ak820_outline_0039
                                   1964 	.globl _ak820_outline_0050
                                   1965 	.globl _ak820_outline_0051
                                   1966 	.globl _ak820_outline_0055
                                   1967 	.globl _ak820_outline_0058
                                   1968 	.globl _ak820_outline_0063
                                   1969 	.globl _ak820_outline_0071
                                   1970 	.globl _ak820_outline_0075
                                   1971 	.globl _ak820_outline_0085
                                   1972 	.globl _ak820_outline_0097
                                   1973 	.globl _ak820_outline_0104
                                   1974 	.globl _ak820_outline_0105
                                   1975 	.globl _ak820_outline_0107
                                   1976 	.globl _ak820_outline_0108
                                   1977 	.globl _ak820_outline_0110
                                   1978 	.globl _ak820_outline_0117
                                   1979 	.globl _ak820_outline_0121
                                   1980 	.globl _ak820_outline_0122
                                   1981 	.globl _ak820_outline_0123
                                   1982 	.globl _ak820_outline_0129
                                   1983 	.globl _ak820_outline_0139
                                   1984 	.globl _ak820_outline_0140
                                   1985 	.globl _ak820_outline_0145
                                   1986 	.globl _ak820_outline_0154
                                   1987 	.globl _ak820_outline_0162
                                   1988 	.globl _ak820_outline_0163
                                   1989 	.globl _ak820_outline_0180
                                   1990 	.globl _ak820_outline_0186
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0019
      007809                       1994 _ak820_outline_0019:
      007809 8E 82            [24] 1995 	mov	dpl,r6
      00780B 8F 83            [24] 1996 	mov	dph,r7
      00780D A3               [24] 1997 	inc	dptr
      00780E E0               [24] 1998 	movx	a,@dptr
      00780F FC               [12] 1999 	mov	r4,a
      007810 7D 00            [12] 2000 	mov	r5,#0x00
      007812 8E 82            [24] 2001 	mov	dpl,r6
      007814 8F 83            [24] 2002 	mov	dph,r7
      007816 E0               [24] 2003 	movx	a,@dptr
      007817 22               [24] 2004 	ret
                                   2005 
                                   2006 	.area CSEG (CODE)
                                   2007 ; function ak820_outline_0039
      007818                       2008 _ak820_outline_0039:
      007818 90 08 33         [24] 2009 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00781B E0               [24] 2010 	movx	a,@dptr
      00781C 54 1F            [12] 2011 	anl	a,#0x1f
      00781E F5 82            [12] 2012 	mov	dpl,a
      007820 22               [24] 2013 	ret
                                   2014 
                                   2015 	.area CSEG (CODE)
                                   2016 ; function ak820_outline_0050
      007821                       2017 _ak820_outline_0050:
      007821 A3               [24] 2018 	inc	dptr
      007822 F0               [24] 2019 	movx	@dptr,a
      007823 E4               [12] 2020 	clr	a
      007824 A3               [24] 2021 	inc	dptr
      007825 F0               [24] 2022 	movx	@dptr,a
      007826 90 0D 7F         [24] 2023 	mov	dptr,#___memcpy_PARM_3
      007829 22               [24] 2024 	ret
                                   2025 
                                   2026 	.area CSEG (CODE)
                                   2027 ; function ak820_outline_0063
      00782A                       2028 _ak820_outline_0063:
      00782A F5 F0            [12] 2029 	mov	b,a
      00782C 05 F0            [12] 2030 	inc	b
      00782E 74 01            [12] 2031 	mov	a,#0x01
      007830 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0075
      007831                       2036 _ak820_outline_0075:
      007831 90 08 32         [24] 2037 	mov	dptr,#_process_action_PARM_2
      007834 E0               [24] 2038 	movx	a,@dptr
      007835 F5 82            [12] 2039 	mov	dpl,a
      007837 22               [24] 2040 	ret
                                   2041 
                                   2042 	.area CSEG (CODE)
                                   2043 ; function ak820_outline_0085
      007838                       2044 _ak820_outline_0085:
      007838 90 08 33         [24] 2045 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00783B E0               [24] 2046 	movx	a,@dptr
      00783C 03               [12] 2047 	rr	a
      00783D 03               [12] 2048 	rr	a
      00783E 54 03            [12] 2049 	anl	a,#0x03
      007840 22               [24] 2050 	ret
                                   2051 
                                   2052 	.area CSEG (CODE)
                                   2053 ; function ak820_outline_0108
      007841                       2054 _ak820_outline_0108:
      007841 74 06            [12] 2055 	mov	a,#0x06
      007843 F0               [24] 2056 	movx	@dptr,a
      007844 E4               [12] 2057 	clr	a
      007845 A3               [24] 2058 	inc	dptr
      007846 F0               [24] 2059 	movx	@dptr,a
      007847 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0110
      007848                       2064 _ak820_outline_0110:
      007848 90 08 33         [24] 2065 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00784B E0               [24] 2066 	movx	a,@dptr
      00784C 54 0F            [12] 2067 	anl	a,#0x0f
      00784E 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0129
      00784F                       2072 _ak820_outline_0129:
      00784F 90 08 32         [24] 2073 	mov	dptr,#_process_action_PARM_2
      007852 E0               [24] 2074 	movx	a,@dptr
      007853 FE               [12] 2075 	mov	r6,a
      007854 A3               [24] 2076 	inc	dptr
      007855 E0               [24] 2077 	movx	a,@dptr
      007856 54 03            [12] 2078 	anl	a,#0x03
      007858 FF               [12] 2079 	mov	r7,a
      007859 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0154
      00785A                       2084 _ak820_outline_0154:
      00785A 90 08 32         [24] 2085 	mov	dptr,#_process_action_PARM_2
      00785D E0               [24] 2086 	movx	a,@dptr
      00785E 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0162
      00785F                       2091 _ak820_outline_0162:
      00785F 90 08 37         [24] 2092 	mov	dptr,#_register_code_code_10000_710
      007862 E0               [24] 2093 	movx	a,@dptr
      007863 FF               [12] 2094 	mov	r7,a
      007864 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0163
      007865                       2099 _ak820_outline_0163:
      007865 90 08 38         [24] 2100 	mov	dptr,#_unregister_code_code_10000_724
      007868 E0               [24] 2101 	movx	a,@dptr
      007869 FF               [12] 2102 	mov	r7,a
      00786A 22               [24] 2103 	ret
