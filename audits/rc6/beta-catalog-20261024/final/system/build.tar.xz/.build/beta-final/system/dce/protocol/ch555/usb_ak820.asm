;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module usb_ak820
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_nvm_end
	.globl _ak820_nvm_flush
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_ok
	.globl _ak820_os_indicator_get
	.globl _ak820_os_indicator_set
	.globl _ak820_nvm_diagnostic
	.globl _mDelaymS
	.globl _mDelayuS
	.globl _raw_hid_receive
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_usb_raw_send_PARM_2
	.globl _ak820_usb_try_send_PARM_3
	.globl _ak820_usb_try_send_PARM_2
	.globl _ak820_usb_send_PARM_3
	.globl _ak820_usb_send_PARM_2
	.globl _ak820_main_heartbeat
	.globl _ak820_boot_stage
	.globl _KB_USB_SetReport
	.globl _KB_USB_UpStatus
	.globl _MCU_Sleep_Operate
	.globl _USB_SleepStatus
	.globl _USB_EnumStatus
	.globl _D0UsbConfig
	.globl _pD0Descr
	.globl _D0SetupLen
	.globl _D0SetupReqCode
	.globl _USB_DeviceInterrupt
	.globl _USB_Device_Init
	.globl _USB_WakeUp_PC
	.globl _ak820_usb_send
	.globl _ak820_usb_try_send
	.globl _ak820_usb_raw_send
	.globl _ak820_usb_raw_task
	.globl _ak820_usb_take_keyboard_reset
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_control_setup_sloc1_1_0:
	.ds 1
_control_setup_sloc3_1_0:
	.ds 2
_control_setup_sloc4_1_0:
	.ds 2
_ak820_usb_send_sloc0_1_0:
	.ds 2
_ak820_usb_send_sloc1_1_0:
	.ds 1
_ak820_usb_raw_task_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_control_setup_valid_interface_10000_289:
	.ds 1
_control_setup_zero_index_10000_289:
	.ds 1
_control_setup_zero_value_10000_289:
	.ds 1
_control_setup_zero_length_10000_289:
	.ds 1
_control_setup_sloc0_1_0:
	.ds 1
_control_setup_sloc2_1_0:
	.ds 1
_ak820_usb_try_send_sloc0_1_0:
	.ds 1
_ak820_usb_raw_task_sloc1_1_0:
	.ds 1
_ak820_usb_take_keyboard_reset_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_D0SetupReqCode::
	.ds 1
_D0SetupLen::
	.ds 2
_pD0Descr::
	.ds 3
_D0UsbConfig::
	.ds 1
_USB_EnumStatus::
	.ds 1
_USB_SleepStatus::
	.ds 1
_MCU_Sleep_Operate::
	.ds 1
_KB_USB_UpStatus::
	.ds 1
_KB_USB_SetReport::
	.ds 1
_ak820_boot_stage::
	.ds 1
_ak820_main_heartbeat::
	.ds 1
_raw_state:
	.ds 1
_raw_buffer:
	.ds 32
_raw_reply_without_nvm:
	.ds 1
_keyboard_reset:
	.ds 1
_input_snapshot:
	.ds 46
_control_phase:
	.ds 1
_output_kind:
	.ds 1
_output_report_id:
	.ds 1
_control_zlp:
	.ds 1
_control_pointer:
	.ds 2
_descriptor_select_PARM_2:
	.ds 1
_descriptor_select_PARM_3:
	.ds 2
_descriptor_select_type_10000_271:
	.ds 1
_control_setup_length_10000_289:
	.ds 2
_control_setup_offset_10000_289:
	.ds 1
_ak820_usb_send_PARM_2:
	.ds 2
_ak820_usb_send_PARM_3:
	.ds 1
_ak820_usb_send_endpoint_10000_425:
	.ds 1
_ak820_usb_send_offset_10000_426:
	.ds 1
_ak820_usb_try_send_PARM_2:
	.ds 2
_ak820_usb_try_send_PARM_3:
	.ds 1
_ak820_usb_try_send_endpoint_10000_446:
	.ds 1
_ak820_usb_try_send_sent_10000_447:
	.ds 1
_ak820_usb_raw_send_PARM_2:
	.ds 1
_ak820_usb_raw_send_report_10000_462:
	.ds 3
_ak820_usb_raw_task_length_10000_467:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function raw_abort
;	-----------------------------------------
_raw_abort:
;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00130$
	sjmp	00101$
00130$:
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x04,00131$
	sjmp	00101$
00131$:
;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00132$
	sjmp	00101$
00132$:
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x07,00102$
00101$:
;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
	mov	dptr,#_raw_state
	mov	a,#0x07
	movx	@dptr,a
	sjmp	00103$
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
	mov	dptr,#_raw_state
	clr	a
	movx	@dptr,a
00103$:
;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
	mov	dptr,#_output_kind
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:103: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'raw_complete'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
;	-----------------------------------------
;	 function raw_complete
;	-----------------------------------------
_raw_complete:
;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x04,00104$
	mov	dptr,#_raw_state
	mov	a,#0x06
	movx	@dptr,a
	ret
00104$:
;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x05,00106$
	mov	dptr,#_raw_state
	clr	a
	movx	@dptr,a
00106$:
;	tmk_core/protocol/ch555/usb_ak820.c:108: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'endpoints_reset'
;------------------------------------------------------------
;i             Allocated with name '_endpoints_reset_i_10000_261'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
;	-----------------------------------------
;	 function endpoints_reset
;	-----------------------------------------
_endpoints_reset:
;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
	mov	dptr,#_ak820_os_indicator_mode
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
	mov	dptr,#0x220c
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
	mov	dpl,a
	mov	a,#0x12
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
	mov	dptr,#0x220b
	clr	a
	movx	@dptr,a
	dec	dpl
	movx	@dptr,a
	dec	dpl
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
	mov	r7,a
00103$:
	mov	a,r7
	add	a, #_input_snapshot
	mov	dpl,a
	clr	a
	addc	a, #(_input_snapshot >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x2e,00139$
00139$:
	jc	00103$
;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
	mov	dptr,#(_input_snapshot + 0x0008)
	mov	a,#0x06
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
	mov	dptr,#(_input_snapshot + 0x0028)
	rr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
	mov	dptr,#(_input_snapshot + 0x002b)
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
	mov	r7,#0x00
00105$:
	mov	ar6,r7
	mov	a,#0xc0
	add	a, r6
	mov	dpl,a
	mov	a,#0x10
	add	a, #0x00
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x20,00141$
00141$:
	jc	00105$
;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
;	tmk_core/protocol/ch555/usb_ak820.c:130: }
	ljmp	_raw_abort
;------------------------------------------------------------
;Allocation info for local variables in function 'control_stall'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
;	-----------------------------------------
;	 function control_stall
;	-----------------------------------------
_control_stall:
;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00102$
	mov	dptr,#_raw_state
	clr	a
	movx	@dptr,a
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
	mov	dptr,#_output_kind
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
	mov	dptr,#_D0SetupReqCode
	dec	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
	mov	dptr,#0x2200
	mov	a,#0xcf
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:139: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'control_next'
;------------------------------------------------------------
;i             Allocated with name '_control_next_i_10000_268'
;length        Allocated with name '_control_next_length_10000_268'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
;	-----------------------------------------
;	 function control_next
;	-----------------------------------------
_control_next:
;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	clr	c
	mov	a,#0x40
	subb	a,r6
	clr	a
	subb	a,r7
	jnc	00109$
;	free result
	mov	r6,#0x40
	sjmp	00110$
00109$:
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
00110$:
;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
	mov	r7,#0x00
00105$:
	clr	c
	mov	a,r7
	subb	a,r6
	jnc	00101$
	mov	ar4,r7
	mov	a,#0x10
	add	a, #0x00
	mov	r5,a
	mov	dptr,#_control_pointer
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	clr	a
	movc	a,@a+dptr
	mov	r1,a
	mov	dptr,#_control_pointer
	mov	a,#0x01
	add	a, r2
	movx	@dptr,a
	clr	a
	addc	a, r3
	inc	dptr
	movx	@dptr,a
	mov	dpl,r4
	mov	dph,r5
	mov	a,r1
	movx	@dptr,a
	inc	r7
	sjmp	00105$
00101$:
;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
	mov	ar5,r6
	mov	r7,#0x00
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	a,r3
	clr	c
	subb	a,r5
	mov	r3,a
	mov	a,r4
	subb	a,r7
	mov	r4,a
	mov	dptr,#_D0SetupLen
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
	mov	a,r6
	jnz	00103$
	mov	dptr,#_control_zlp
	clr	a
	movx	@dptr,a
00103$:
;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
	mov	dptr,#0x2208
	mov	a,r6
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
	mov	dptr,#0x2200
	movx	a,@dptr
	anl	a,#0xc0
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:149: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'descriptor_select'
;------------------------------------------------------------
;index         Allocated with name '_descriptor_select_PARM_2'
;interface     Allocated with name '_descriptor_select_PARM_3'
;type          Allocated with name '_descriptor_select_type_10000_271'
;hid           Allocated with name '_descriptor_select_hid_30000_284'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
;	-----------------------------------------
;	 function descriptor_select
;	-----------------------------------------
_descriptor_select:
	mov	a,dpl
	mov	dptr,#_descriptor_select_type_10000_271
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00102$
	mov	dptr,#_descriptor_select_PARM_2
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#_descriptor_select_PARM_3
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00102$
;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
	mov	dptr,#_control_pointer
	mov	a,#_DeviceDescriptor
	movx	@dptr,a
	mov	a,#(_DeviceDescriptor >> 8)
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
	mov	dptr,#0x0012
	ret
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
	mov	dptr,#_descriptor_select_type_10000_271
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x02,00106$
	mov	dptr,#_descriptor_select_PARM_2
	movx	a,@dptr
	jnz	00106$
	mov	dptr,#_descriptor_select_PARM_3
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00106$
;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
	mov	dptr,#_control_pointer
	mov	a,#_ConfigurationDescriptor
	movx	@dptr,a
	mov	a,#(_ConfigurationDescriptor >> 8)
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
	mov	dptr,#0x0054
	ret
00106$:
;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
	mov	dptr,#_descriptor_select_type_10000_271
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00238$
	sjmp	00239$
00238$:
	ljmp	00119$
00239$:
;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
	mov	dptr,#_descriptor_select_PARM_3
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_descriptor_select_PARM_3
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jz	00110$
	cjne	r5,#0x09,00241$
	cjne	r6,#0x04,00241$
	sjmp	00110$
00241$:
	mov	dptr,#0x0000
	ret
00110$:
;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
	mov	dptr,#_descriptor_select_PARM_2
	movx	a,@dptr
	mov  r6,a
	add	a,#0xff - 0x03
	jc	00116$
;	free result
	mov	a,r6
	add	a,r6
;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
	mov	dptr,#00243$
	jmp	@a+dptr
00243$:
	sjmp	00112$
	sjmp	00113$
	sjmp	00114$
	sjmp	00115$
00112$:
	mov	dptr,#_control_pointer
	mov	a,#_LanguageString
	movx	@dptr,a
	mov	a,#(_LanguageString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_LanguageString
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r5
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
00113$:
	mov	dptr,#_control_pointer
	mov	a,#_ManufacturerString
	movx	@dptr,a
	mov	a,#(_ManufacturerString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ManufacturerString
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r5
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
00114$:
	mov	dptr,#_control_pointer
	mov	a,#_ProductString
	movx	@dptr,a
	mov	a,#(_ProductString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ProductString
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r5
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
00115$:
	mov	dptr,#_control_pointer
	mov	a,#_SerialNumberString
	movx	@dptr,a
	mov	a,#(_SerialNumberString >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_SerialNumberString
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r5
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
00116$:
	mov	dptr,#0x0000
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:185: }
00119$:
;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
	mov	dptr,#_descriptor_select_PARM_2
	movx	a,@dptr
	jnz	00120$
	mov	dptr,#_descriptor_select_PARM_3
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	clr	c
	mov	a,r5
	subb	a,#0x03
	mov	a,r6
	subb	a,#0x00
	jc	00121$
00120$:
	mov	dptr,#0x0000
	ret
00121$:
;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
	cjne	r7,#0x22,00246$
	sjmp	00127$
00246$:
	cjne	r7,#0x21,00128$
00127$:
;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
	mov	a,r5
	mov	b,#0x04
	mul	ab
	add	a, #_interface_descriptors
	mov	r6,a
	mov	a,#(_interface_descriptors >> 8)
	addc	a, b
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	r4,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
	mov	r5,a
	orl	a,r4
	jnz	00124$
	mov	dptr,#0x0000
	ret
00124$:
;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
	mov	dptr,#_descriptor_select_type_10000_271
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x22,00126$
;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
	mov	dpl,r6
	mov	dph,r7
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	r7,a
	mov	dptr,#_control_pointer
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
	mov	a,#0x07
	add	a, r4
	mov	dpl,a
	clr	a
	addc	a, r5
	mov	dph,a
	clr	a
	movc	a,@a+dptr
	mov	r6,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	ret
00126$:
;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
	mov	dptr,#_control_pointer
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
	mov	dptr,#0x0009
	ret
00128$:
;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
	mov	dptr,#0x0000
;	tmk_core/protocol/ch555/usb_ak820.c:199: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'control_setup'
;------------------------------------------------------------
;sloc1         Allocated with name '_control_setup_sloc1_1_0'
;sloc3         Allocated with name '_control_setup_sloc3_1_0'
;sloc4         Allocated with name '_control_setup_sloc4_1_0'
;type          Allocated with name '_control_setup_type_10000_289'
;value         Allocated with name '_control_setup_value_10000_289'
;index         Allocated with name '_control_setup_index_10000_289'
;length        Allocated with name '_control_setup_length_10000_289'
;endpoint      Allocated with name '_control_setup_endpoint_10000_289'
;i             Allocated with name '_control_setup_i_10000_289'
;offset        Allocated with name '_control_setup_offset_10000_289'
;report_id     Allocated with name '_control_setup_report_id_10000_289'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
;	-----------------------------------------
;	 function control_setup
;	-----------------------------------------
_control_setup:
;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
	mov	dptr,#0x1000
	movx	a,@dptr
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0x00
	mov	ar3,r6
	mov	r6,#0x00
	mov	a,r5
	orl	a,r3
	mov	r5,a
	mov	a,r4
	orl	a,r6
	mov	r6,a
;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	r3,#0x00
	mov	ar1,r4
	mov	r4,#0x00
	mov	a,r3
	orl	a,r1
	mov	r3,a
	mov	a,r2
	orl	a,r4
	mov	r4,a
;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
	clr	c
	mov	a,r3
	subb	a,#0x03
	mov	a,r4
	subb	a,#0x00
	mov	_control_setup_valid_interface_10000_289,c
;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
	mov	a,r3
	orl	a,r4
	cjne	a,#0x01,01201$
01201$:
	mov	_control_setup_zero_index_10000_289,c
;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
	mov	a,r5
	orl	a,r6
	cjne	a,#0x01,01202$
01202$:
;	assignBit
	mov  _control_setup_sloc0_1_0,c
	mov	_control_setup_zero_value_10000_289,c
;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
	mov	dptr,#_control_setup_offset_10000_289
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x01,00102$
	mov	dptr,#_raw_state
	clr	a
	movx	@dptr,a
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
	push	ar7
	mov	dptr,#_output_kind
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
	mov	dptr,#_control_zlp
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
	mov	dptr,#0x1001
	movx	a,@dptr
	mov	dptr,#_D0SetupReqCode
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
	mov	dptr,#0x1006
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	mov	r0,#0x00
	mov	r7,#0x00
	mov	dptr,#_D0SetupLen
	mov	a,r0
	orl	a,r2
	movx	@dptr,a
	mov	a,r1
	orl	a,r7
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	orl	a,r2
	cjne	a,#0x01,01205$
01205$:
	mov	_control_setup_zero_length_10000_289,c
;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
	mov	dptr,#0x2200
	mov	a,#0xc2
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
	mov	dptr,#0x2208
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	_control_setup_sloc1_1_0,a
	clr	c
	mov	a,#0x0b
	subb	a,_control_setup_sloc1_1_0
	pop	ar7
	jnc	01206$
	ljmp	_control_stall
01206$:
;	free result
	mov	a,_control_setup_sloc1_1_0
	mov	b,a
	add	a,#(01207$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,b
	add	a,#(01208$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
01207$:
	.db	00188$
	.db	00205$
	.db	00282$
	.db	00205$
	.db	00290$
	.db	00116$
	.db	00103$
	.db	00290$
	.db	00150$
	.db	00123$
	.db	00157$
	.db	00173$
01208$:
	.db	00188$>>8
	.db	00205$>>8
	.db	00282$>>8
	.db	00205$>>8
	.db	00290$>>8
	.db	00116$>>8
	.db	00103$>>8
	.db	00290$>>8
	.db	00150$>>8
	.db	00123$>>8
	.db	00157$>>8
	.db	00173$>>8
;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
00103$:
;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
	cjne	r7,#0x80,01209$
	sjmp	00112$
01209$:
	cjne	r7,#0x81,01210$
	sjmp	01211$
01210$:
	ljmp	_control_stall
01211$:
00112$:
;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
	mov	ar1,r6
	cjne	r1,#0x21,01212$
	sjmp	00301$
01212$:
	cjne	r1,#0x22,01213$
	sjmp	00301$
01213$:
;	assignBit
	clr	_control_setup_sloc2_1_0
	sjmp	00302$
00301$:
;	assignBit
	setb	_control_setup_sloc2_1_0
00302$:
	clr	a
	cjne	r7,#0x81,01214$
	inc	a
01214$:
	mov	r2,a
	mov	c,_control_setup_sloc2_1_0
	clr	a
	rlc	a
	cjne	a,ar2,01216$
	sjmp	00105$
01216$:
;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
	ljmp	_control_stall
00105$:
;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
	mov	ar2,r6
	mov	dptr,#_descriptor_select_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	dptr,#_descriptor_select_PARM_3
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	dpl, r2
	lcall	_descriptor_select
	mov	_control_setup_sloc3_1_0,dpl
	mov	(_control_setup_sloc3_1_0 + 1),dph
;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
	mov	a,_control_setup_sloc3_1_0
	orl	a,(_control_setup_sloc3_1_0 + 1)
	jnz	00107$
	ljmp	_control_stall
00107$:
;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	clr	c
	mov	a,_control_setup_sloc3_1_0
	subb	a,r0
	mov	a,(_control_setup_sloc3_1_0 + 1)
	subb	a,r2
	jnc	00303$
	mov	a,_control_setup_sloc3_1_0
	anl	a,#0x3f
	jz	00304$
00303$:
;	assignBit
	clr	_control_setup_sloc2_1_0
	sjmp	00305$
00304$:
;	assignBit
	setb	_control_setup_sloc2_1_0
00305$:
	mov	dptr,#_control_zlp
	mov	c,_control_setup_sloc2_1_0
	clr	a
	rlc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	clr	c
	mov	a,_control_setup_sloc3_1_0
	subb	a,r1
	mov	a,(_control_setup_sloc3_1_0 + 1)
	subb	a,r2
	jnc	00109$
;	free result
	mov	dptr,#_D0SetupLen
	mov	a,_control_setup_sloc3_1_0
	movx	@dptr,a
	mov	a,(_control_setup_sloc3_1_0 + 1)
	inc	dptr
	movx	@dptr,a
00109$:
;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	orl	a,r1
	jz	00306$
	mov	r2,#0x01
	sjmp	00307$
00306$:
	mov	r2,#0x02
00307$:
	mov	dptr,#_control_phase
	mov	a,r2
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	orl	a,r1
	jz	00111$
;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
	ljmp	_control_next
00111$:
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
00116$:
;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
	mov	a,r7
	jnz	00118$
	jnb	_control_setup_zero_index_10000_289,00118$
	jnb	_control_setup_zero_length_10000_289,00118$
	mov	ar1,r5
	mov	ar2,r6
	clr	c
	mov	a,#0x7f
	subb	a,r1
	clr	a
	subb	a,r2
	jc	00118$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
	mov	dptr,#_D0SetupLen
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00118$:
;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
00123$:
;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
	mov	a,r7
	jnz	00145$
	jnb	_control_setup_zero_index_10000_289,00145$
	jnb	_control_setup_zero_length_10000_289,00145$
	mov	ar1,r5
	mov	ar2,r6
	clr	c
	mov	a,#0x01
	subb	a,r1
	clr	a
	subb	a,r2
	jc	00145$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
	push	ar6
	push	ar5
	lcall	_endpoints_reset
	pop	ar5
	pop	ar6
;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
	mov	dptr,#_D0UsbConfig
	mov	a,r5
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
	mov	c,_control_setup_sloc0_1_0
	cpl	c
	mov	_control_setup_sloc2_1_0,c
	mov	dptr,#_USB_EnumStatus
	clr	a
	rlc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
	mov	dptr,#_keyboard_reset
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00145$:
;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
	cjne	r7,#0x21,01231$
	sjmp	01232$
01231$:
	ljmp	_control_stall
01232$:
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jnz	01233$
	ljmp	_control_stall
01233$:
;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
	cjne	r3,#0x01,00135$
	cjne	r4,#0x00,00135$
	mov	ar1,r5
	mov	ar2,r6
	cjne	r1,#0x00,00135$
	cjne	r2,#0x02,00135$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x20,00135$
	cjne	r2,#0x00,00135$
	mov	dptr,#_raw_state
	movx	a,@dptr
	jnz	00135$
;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
	mov	dptr,#_raw_state
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
	mov	dptr,#_output_kind
	movx	@dptr,a
	sjmp	00136$
00135$:
;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
	mov	a,r3
	orl	a,r4
	jnz	00130$
	mov	ar1,r5
	mov	ar2,r6
	cjne	r1,#0x00,00130$
	cjne	r2,#0x02,00130$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x01,00130$
	cjne	r2,#0x00,00130$
;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
	mov	dptr,#_output_kind
	mov	a,#0x02
	movx	@dptr,a
	sjmp	00136$
00130$:
;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
	cjne	r3,#0x02,00125$
	cjne	r4,#0x00,00125$
	mov	ar1,r5
	mov	ar2,r6
	cjne	r1,#0x06,00125$
	cjne	r2,#0x02,00125$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x02,00125$
	cjne	r2,#0x00,00125$
;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
	mov	dptr,#_output_kind
	mov	a,#0x03
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
	mov	dptr,#_output_report_id
	rl	a
	movx	@dptr,a
	sjmp	00136$
00125$:
;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
	ljmp	_control_stall
00136$:
;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
	mov	dptr,#_control_phase
	mov	a,#0x04
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
00150$:
;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
	cjne	r7,#0x80,00152$
	jnb	_control_setup_zero_index_10000_289,00152$
	jnb	_control_setup_zero_value_10000_289,00152$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x01,00152$
	cjne	r2,#0x00,00152$
;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	mov	dptr,#0x1000
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
	mov	dptr,#0x2208
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	inc	a
	movx	@dptr,a
	ljmp	00291$
00152$:
;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
00157$:
;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
	cjne	r7,#0x81,00167$
	jnb	_control_setup_valid_interface_10000_289,00167$
	jnb	_control_setup_zero_value_10000_289,00167$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x01,00167$
	cjne	r2,#0x00,00167$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00167$
;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
	mov	dptr,#0x1000
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
	mov	dptr,#0x2208
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	inc	a
	movx	@dptr,a
	ljmp	00291$
00167$:
;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
	jnb	_control_setup_valid_interface_10000_289,00161$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00161$
	cjne	r7,#0x21,00161$
	jnb	_control_setup_zero_length_10000_289,00161$
;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
	mov	a,r3
	orl	a,r4
	jnz	00159$
	mov	dptr,#_keyboard_idle
	mov	a,r6
	movx	@dptr,a
00159$:
;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00161$:
;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
00173$:
;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
	cjne	r7,#0x01,00182$
	jnb	_control_setup_valid_interface_10000_289,00182$
	jnb	_control_setup_zero_value_10000_289,00182$
	jnb	_control_setup_zero_length_10000_289,00182$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00182$
;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00182$:
;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
	mov	a,r3
	orl	a,r4
	jnz	00175$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00175$
	cjne	r7,#0x21,00175$
	jnb	_control_setup_zero_length_10000_289,00175$
	mov	ar1,r5
	mov	ar2,r6
	clr	c
	mov	a,#0x01
	subb	a,r1
	clr	a
	subb	a,r2
	jc	00175$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
	mov	dptr,#_keyboard_protocol
	mov	a,r5
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
	mov	dptr,#_keyboard_reset
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00175$:
;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
00188$:
;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
	jb	_control_setup_zero_value_10000_289,01283$
	ljmp	_control_stall
01283$:
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x02,01284$
	cjne	r2,#0x00,01284$
	sjmp	01285$
01284$:
	ljmp	_control_stall
01285$:
;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
	clr	a
	cjne	r7,#0x80,01286$
	inc	a
01286$:
	mov	r2,a
	jz	00196$
	jb	_control_setup_zero_index_10000_289,00189$
00196$:
	cjne	r7,#0x81,00202$
	jnb	_control_setup_valid_interface_10000_289,00202$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jnz	00189$
00202$:
;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
	cjne	r7,#0x82,00190$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00190$
	mov	a,r3
	orl	a,r4
	jz	00189$
	mov	ar0,r3
	mov	ar1,r4
	cjne	r0,#0x80,01298$
	cjne	r1,#0x00,01298$
	sjmp	00189$
01298$:
	clr	c
	mov	a,r0
	subb	a,#0x81
	mov	a,r1
	subb	a,#0x00
	jc	00190$
	mov	a,#0x83
	subb	a,r0
	clr	a
	subb	a,r1
	jc	00190$
;	free result
00189$:
;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
	mov	ar1,r3
	anl	ar1,#0x07
;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
	mov	a,r2
	jz	00308$
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	anl	a,#0x01
	add	a,acc
	mov	r2,a
	sjmp	00309$
00308$:
;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
	cjne	r7,#0x82,00310$
	mov	a,r1
	jz	00310$
	mov	ar0,r1
	mov	r1,#0x00
	mov	a,#0x22
	add	a, r1
	mov	r1,a
	mov	dpl,r0
	mov	dph,r1
	movx	a,@dptr
	mov	r1,a
	anl	ar1,#0x03
	cjne	r1,#0x03,00310$
	mov	r1,#0x01
	sjmp	00311$
00310$:
	mov	r1,#0x00
00311$:
	mov	ar2,r1
00309$:
	mov	dptr,#0x1000
	mov	a,r2
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
	inc	dptr
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
	mov	dptr,#0x2208
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	movx	@dptr,a
	ljmp	00291$
00190$:
;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
	ljmp	_control_stall
;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
00205$:
;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
	jb	_control_setup_zero_length_10000_289,01307$
	ljmp	00279$
01307$:
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jnz	01308$
	ljmp	00279$
01308$:
;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
	mov	a,r7
	jnz	00218$
	mov	ar1,r5
	mov	ar2,r6
	cjne	r1,#0x01,00218$
	cjne	r2,#0x00,00218$
	jnb	_control_setup_zero_index_10000_289,00218$
;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x03,00207$
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	orl	acc,#0x01
	movx	@dptr,a
	sjmp	00219$
00207$:
;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	anl	acc,#0xfe
	movx	@dptr,a
	sjmp	00219$
00218$:
;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
	cjne	r7,#0x02,00212$
	jnb	_control_setup_zero_value_10000_289,00212$
	mov	ar1,r3
	mov	ar2,r4
	clr	c
	mov	a,r1
	subb	a,#0x81
	mov	a,r2
	subb	a,#0x00
	jc	00212$
	mov	a,#0x83
	subb	a,r1
	clr	a
	subb	a,r2
	jc	00212$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
	mov	ar2,r3
	anl	ar2,#0x07
;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
	mov	ar0,r2
	mov	r1,#0x00
	mov	a,#0x22
	add	a, r1
	mov	r1,a
	mov	_control_setup_sloc3_1_0,r0
	mov	(_control_setup_sloc3_1_0 + 1),r1
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x03,00318$
	mov	r1,#0x03
	sjmp	00319$
00318$:
	mov	r1,#0x02
00319$:
	orl	ar1,#0x10
	mov	dpl,_control_setup_sloc3_1_0
	mov	dph,(_control_setup_sloc3_1_0 + 1)
	mov	a,r1
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
	cjne	r2,#0x03,00219$
	lcall	_raw_complete
	sjmp	00219$
00212$:
;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
	ljmp	_control_stall
00219$:
;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
	ljmp	00291$
00279$:
;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
	clr	a
	cjne	r7,#0xa1,01324$
	inc	a
01324$:
	mov	r2,a
	jnz	01326$
	ljmp	00273$
01326$:
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x01,01327$
	sjmp	01328$
01327$:
	ljmp	00273$
01328$:
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jnz	01329$
	ljmp	00273$
01329$:
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	orl	a,r0
	jnz	01330$
	ljmp	00273$
01330$:
;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
	push	ar3
	push	ar4
	mov	ar1,r5
;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
	mov	ar0,r6
	cjne	r0,#0x01,01331$
	mov	a,r0
	sjmp	01332$
01331$:
	clr	a
01332$:
	mov	_control_setup_sloc3_1_0,a
	pop	ar4
	pop	ar3
	mov	a,_control_setup_sloc3_1_0
	jz	00251$
	mov	a,r3
	orl	a,r4
	jnz	00251$
	mov	a,r1
	jnz	00251$
;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
	mov	dptr,#_control_setup_length_10000_289
	mov	a,#0x08
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
	mov	dptr,#_control_setup_offset_10000_289
	movx	@dptr,a
	ljmp	00252$
00251$:
;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
	mov	a,_control_setup_sloc3_1_0
	jz	00245$
	cjne	r3,#0x02,00245$
	cjne	r4,#0x00,00245$
;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
	cjne	r1,#0x07,01339$
01339$:
	jnc	00245$
	mov	a,r1
	mov	dptr,#_shared_lengths
	movc	a,@a+dptr
	mov	r0,a
	jz	00245$
;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
	mov	dptr,#_control_setup_length_10000_289
	mov	a,r0
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
	mov	a,r1
	mov	dptr,#_shared_offsets
	movc	a,@a+dptr
	mov	dptr,#_control_setup_offset_10000_289
	movx	@dptr,a
	ljmp	00252$
00245$:
;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
	mov	a,_control_setup_sloc3_1_0
	jz	00240$
	cjne	r3,#0x01,00240$
	cjne	r4,#0x00,00240$
	mov	a,r1
	jnz	00240$
;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,r0
	subb	a,#0x20
	mov	a,r1
	subb	a,#0x00
	jnc	00320$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	sjmp	00321$
00320$:
	mov	r0,#0x20
	mov	r1,#0x00
00321$:
;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
	mov	_control_setup_sloc3_1_0,#0x00
00293$:
	push	ar3
	push	ar4
	mov	r3,_control_setup_sloc3_1_0
	mov	r4,#0x00
	clr	c
	mov	a,r3
	subb	a,r0
	mov	a,r4
	subb	a,r1
	pop	ar4
	pop	ar3
	jnc	00222$
	push	ar0
	push	ar1
	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
	mov	a,#0x10
	add	a, #0x00
	mov	(_control_setup_sloc4_1_0 + 1),a
	mov	r0,_control_setup_sloc3_1_0
	mov	r1,#0x00
	mov	a,#0xc0
	add	a, r0
	mov	r0,a
	clr	a
	addc	a, r1
	mov	r1,a
	mov	dpl,r0
	mov	a,#0x10
	add	a, r1
	mov	dph,a
	movx	a,@dptr
	mov	dpl,_control_setup_sloc4_1_0
	mov	dph,(_control_setup_sloc4_1_0 + 1)
	movx	@dptr,a
	mov	a,_control_setup_sloc3_1_0
	inc	a
	mov	_control_setup_sloc3_1_0,a
	pop	ar1
	pop	ar0
	sjmp	00293$
00222$:
;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
	mov	dptr,#_control_setup_length_10000_289
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ljmp	00252$
00240$:
;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
	mov	ar0,r5
	mov	ar1,r6
	cjne	r0,#0x00,00236$
	cjne	r1,#0x02,00236$
	mov	a,r3
	orl	a,r4
	jnz	00236$
;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
	mov	dptr,#_KB_USB_SetReport
	movx	a,@dptr
	mov	dptr,#0x1000
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
	mov	dptr,#_control_setup_length_10000_289
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
	mov	dptr,#_D0SetupLen
	inc	a
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ljmp	00252$
00236$:
;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
	cjne	r0,#0x06,00232$
	cjne	r1,#0x02,00232$
	cjne	r3,#0x02,00232$
	cjne	r4,#0x00,00232$
;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
	push	ar3
	push	ar4
	mov	dptr,#0x1000
	mov	a,#0x06
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
	mov	dptr,#_KB_USB_SetReport
	movx	a,@dptr
	mov	dptr,#0x1001
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
	mov	dptr,#_control_setup_length_10000_289
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	clr	c
	mov	a,#0x02
	subb	a,r3
	clr	a
	subb	a,r4
	pop	ar4
	pop	ar3
	jnc	00252$
;	free result
	mov	dptr,#_D0SetupLen
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	sjmp	00252$
00232$:
;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
	cjne	r0,#0x00,00228$
	cjne	r1,#0x03,00228$
	cjne	r3,#0x01,00228$
	cjne	r4,#0x00,00228$
;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
	mov	dptr,#0x1000
	mov	a,#0x41
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
	inc	dptr
	mov	a,#0x4b
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
	inc	dptr
	mov	a,#0x42
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
	inc	dptr
	mov	a,#0x54
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
	mov	dptr,#_ak820_boot_stage
	movx	a,@dptr
	mov	dptr,#0x1005
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
	mov	dptr,#_ak820_main_heartbeat
	movx	a,@dptr
	mov	dptr,#0x1006
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jz	00322$
	mov	a,#0x01
00322$:
	mov	r1,a
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	anl	a,#0x02
	mov	r0,a
	mov	a,r1
	orl	ar0,a
	mov	dptr,#0x1007
	mov	a,r0
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
	mov	dptr,#_control_setup_length_10000_289
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,#0x08
	subb	a,r0
	clr	a
	subb	a,r1
	jnc	00252$
;	free result
	mov	dptr,#_D0SetupLen
	mov	a,#0x08
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	sjmp	00252$
00228$:
;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
	ljmp	_control_stall
00252$:
;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
	mov	dptr,#_control_setup_length_10000_289
	movx	a,@dptr
	mov	_control_setup_sloc4_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_control_setup_sloc4_1_0 + 1),a
	mov	a,_control_setup_sloc4_1_0
	orl	a,(_control_setup_sloc4_1_0 + 1)
	jz	00262$
;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,_control_setup_sloc4_1_0
	subb	a,r0
	mov	a,(_control_setup_sloc4_1_0 + 1)
	subb	a,r1
	jnc	00559$
;	free result
	mov	dptr,#_D0SetupLen
	mov	a,_control_setup_sloc4_1_0
	movx	@dptr,a
	mov	a,(_control_setup_sloc4_1_0 + 1)
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
00559$:
	mov	_control_setup_sloc4_1_0,#0x00
00296$:
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	clr	c
	mov	a,_control_setup_sloc4_1_0
	subb	a,r0
	jnc	00263$
	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
	mov	a,#0x10
	add	a, #0x00
	mov	(_control_setup_sloc3_1_0 + 1),a
	mov	dptr,#_control_setup_offset_10000_289
	movx	a,@dptr
	add	a, _control_setup_sloc4_1_0
	add	a, #_input_snapshot
	mov	dpl,a
	clr	a
	addc	a,#(_input_snapshot >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	dpl,_control_setup_sloc3_1_0
	mov	dph,(_control_setup_sloc3_1_0 + 1)
	movx	@dptr,a
	mov	a,_control_setup_sloc4_1_0
	inc	a
	mov	_control_setup_sloc4_1_0,a
	sjmp	00296$
00262$:
;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
	cjne	r3,#0x01,00263$
	cjne	r4,#0x00,00263$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,#0x20
	subb	a,r0
	clr	a
	subb	a,r1
	jnc	00263$
;	free result
	mov	dptr,#_D0SetupLen
	mov	a,#0x20
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
00263$:
;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	dptr,#0x2208
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	mov	a,#0x02
	movx	@dptr,a
	ljmp	00291$
00273$:
;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
	mov	a,r3
	orl	a,r4
	jnz	00265$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00265$
	mov	a,r2
	jz	00265$
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x03,00265$
	jnb	_control_setup_zero_value_10000_289,00265$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	cjne	r1,#0x01,00265$
	cjne	r2,#0x00,00265$
;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	mov	dptr,#0x1000
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
	mov	dptr,#0x2208
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	inc	a
	movx	@dptr,a
	sjmp	00291$
00265$:
;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
	ljmp	_control_stall
00282$:
;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
	jnb	_control_setup_valid_interface_10000_289,00284$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00284$
	cjne	r7,#0xa1,00284$
	mov	ar5,r6
	mov	r6,#0x00
	mov	a,r5
	orl	a,r6
	jnz	00284$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	cjne	r6,#0x01,00284$
	cjne	r7,#0x00,00284$
;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
	mov	a,r3
	orl	a,r4
	jnz	00324$
	mov	dptr,#_keyboard_idle
	movx	a,@dptr
	mov	r7,a
	sjmp	00325$
00324$:
	mov	r7,#0x00
00325$:
	mov	dptr,#0x1000
	mov	a,r7
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
	mov	dptr,#0x2208
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	inc	a
	movx	@dptr,a
	sjmp	00291$
00284$:
;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
	ljmp	_control_stall
00290$:
;	tmk_core/protocol/ch555/usb_ak820.c:380: }
	ljmp	_control_stall
00291$:
;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
	mov	dptr,#0x2200
	mov	a,#0xc0
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:382: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'control_out'
;------------------------------------------------------------
;i             Allocated with name '_control_out_i_10000_373'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
;	-----------------------------------------
;	 function control_out
;	-----------------------------------------
_control_out:
;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
	mov	dptr,#0x220f
	movx	a,@dptr
	jb	acc.6,00102$
	ret
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
	mov	dptr,#_control_phase
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x02,00104$
	mov	dptr,#0x220e
	movx	a,@dptr
	jnz	00104$
;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
	mov	dptr,#0x2200
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
	ret
00104$:
;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
	cjne	r7,#0x04,00106$
	mov	dptr,#0x220e
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	r4,#0x00
	mov	a,r7
	cjne	a,ar5,00209$
	mov	a,r4
	cjne	a,ar6,00209$
	sjmp	00107$
00209$:
00106$:
	ljmp	_control_stall
00107$:
;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
	mov	dptr,#_output_kind
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00118$
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00118$
;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
	mov	r6,#0x00
00121$:
	mov	a,r6
	add	a, #_raw_buffer
	mov	r4,a
	clr	a
	addc	a, #(_raw_buffer >> 8)
	mov	r5,a
	mov	dpl,r6
	mov	a,#0x10
	add	a, #0x00
	mov	dph,a
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
	inc	r6
	cjne	r6,#0x20,00214$
00214$:
	jc	00121$
;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
	mov	dptr,#_raw_state
	mov	a,#0x02
	movx	@dptr,a
	sjmp	00119$
00118$:
;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
	cjne	r7,#0x02,00115$
;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
	mov	dptr,#0x1000
	movx	a,@dptr
	mov	dptr,#_KB_USB_SetReport
	movx	@dptr,a
	sjmp	00119$
00115$:
;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
	cjne	r7,#0x03,00111$
	mov	dptr,#0x1000
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_output_report_id
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00111$
;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
	mov	dptr,#0x1001
	movx	a,@dptr
	mov	dptr,#_KB_USB_SetReport
	movx	@dptr,a
	sjmp	00119$
00111$:
;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
	ljmp	_control_stall
00119$:
;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
	mov	dptr,#_output_kind
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
	mov	dptr,#_D0SetupLen
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
	mov	dptr,#_control_phase
	mov	a,#0x03
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
	mov	dptr,#0x2208
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
	mov	dpl,a
	mov	a,#0x48
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:406: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'control_in'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
;	-----------------------------------------
;	 function control_in
;	-----------------------------------------
_control_in:
;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
	mov	dptr,#_control_phase
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00109$
;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	orl	a,r5
	jnz	00101$
	mov	dptr,#_control_zlp
	movx	a,@dptr
	jz	00102$
00101$:
;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
	mov	dptr,#0x2200
	movx	a,@dptr
	xrl	a,#0x40
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
	ljmp	_control_next
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
	mov	dptr,#_control_phase
	mov	a,#0x02
	movx	@dptr,a
	sjmp	00110$
00109$:
;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
	cjne	r7,#0x03,00110$
;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
	mov	dptr,#_D0SetupReqCode
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x05,00105$
	mov	dptr,#_D0SetupLen
	movx	a,@dptr
	mov	dptr,#0x2207
	movx	@dptr,a
00105$:
;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	clr	a
	movx	@dptr,a
00110$:
;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
	mov	dptr,#0x2200
	mov	a,#0x82
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:421: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'USB_DeviceInterrupt'
;------------------------------------------------------------
;status        Allocated with name '_USB_DeviceInterrupt_status_10000_397'
;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_397'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
;	-----------------------------------------
;	 function USB_DeviceInterrupt
;	-----------------------------------------
_USB_DeviceInterrupt:
;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
00129$:
;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
	mov	dptr,#0x223d
	movx	a,@dptr
	jnb	acc.0,00127$
;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
	lcall	_endpoints_reset
;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
	mov	dptr,#0x2207
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
	mov	dptr,#_USB_SleepStatus
	movx	@dptr,a
	mov	dptr,#_USB_EnumStatus
	movx	@dptr,a
	mov	dptr,#_D0UsbConfig
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
	mov	dptr,#_KB_USB_SetReport
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
	mov	dptr,#_keyboard_protocol
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
	mov	dptr,#_keyboard_idle
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
	mov	dptr,#_keyboard_reset
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
	mov	dptr,#_D0SetupReqCode
	mov	a,#0xff
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
	mov	dptr,#_D0SetupLen
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
	mov	dptr,#0x2200
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
	mov	dptr,#0x220f
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
	mov	dptr,#0x223d
	inc	a
	movx	@dptr,a
	ljmp	00130$
00127$:
;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
	mov	dptr,#0x223d
	movx	a,@dptr
	jnb	acc.5,00124$
;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
	mov	dptr,#0x220f
	movx	a,@dptr
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
	mov	a,#0x07
	anl	a,r7
	mov	r6,a
;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
	mov	a,r7
	anl	a,#0x18
	jnz	00115$
	mov	a,r6
	jnz	00115$
;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
	lcall	_control_out
	sjmp	00116$
00115$:
;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
	mov	ar5,r7
	mov	a,#0x18
	anl	a,r5
	mov	r4,a
	cjne	r4,#0x10,00112$
;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
	mov	a,r6
	jnz	00106$
	lcall	_control_in
	sjmp	00116$
00106$:
;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
	mov	a,r6
	add	a,#0xff - 0x03
	jc	00116$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
	mov	ar4,r6
	mov	r3,#0x00
	mov	a,#0x22
	add	a, r3
	mov	r3,a
	mov	dpl,r4
	mov	dph,r3
	movx	a,@dptr
	mov	r2,a
	mov	a,#0xfc
	anl	a,r2
	orl	a,#0x02
	mov	dpl,r4
	mov	dph,r3
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
	cjne	r6,#0x03,00116$
	lcall	_raw_complete
	sjmp	00116$
00112$:
;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
	anl	ar5,#0x18
	cjne	r5,#0x18,00116$
	mov	a,r7
	jnb	acc.5,00116$
;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
	lcall	_control_setup
00116$:
;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
	mov	dptr,#0x220f
	clr	a
	movx	@dptr,a
	sjmp	00130$
00124$:
;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
	mov	dptr,#0x223d
	movx	a,@dptr
	jnb	acc.2,00130$
;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
	mov	dptr,#_ak820_os_indicator_mode
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
	mov	dptr,#0x223d
	movx	a,@dptr
	jnb	acc.3,00119$
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	orl	acc,#0x02
	movx	@dptr,a
	sjmp	00120$
00119$:
;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	anl	acc,#0xfd
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
	mov	dptr,#_keyboard_reset
	mov	a,#0x01
	movx	@dptr,a
00120$:
;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
	mov	dptr,#0x223d
	mov	a,#0x04
	movx	@dptr,a
00130$:
;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
	mov	dptr,#0x223d
	movx	a,@dptr
	anl	a,#0x25
	jz	00242$
	ljmp	00129$
00242$:
;	tmk_core/protocol/ch555/usb_ak820.c:472: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'USB_Device_Init'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
;	-----------------------------------------
;	 function USB_Device_Init
;	-----------------------------------------
_USB_Device_Init:
;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
;	assignBit
	clr	_IE_USB
;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
	mov	dptr,#0x223c
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
	mov	dptr,#_raw_state
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
	lcall	_endpoints_reset
;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
	mov	dptr,#_USB_SleepStatus
	clr	a
	movx	@dptr,a
	mov	dptr,#_USB_EnumStatus
	movx	@dptr,a
	mov	dptr,#_D0UsbConfig
	movx	@dptr,a
	mov	dptr,#0x2207
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
	mov	dptr,#_MCU_Sleep_Operate
	movx	@dptr,a
	mov	dptr,#_KB_USB_UpStatus
	movx	@dptr,a
	mov	dptr,#_KB_USB_SetReport
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
	mov	dptr,#_keyboard_protocol
	inc	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
	mov	dptr,#_keyboard_idle
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
	mov	dptr,#_keyboard_reset
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
	mov	dptr,#_control_phase
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
	mov	dptr,#_D0SetupReqCode
	dec	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
	mov	dptr,#_D0SetupLen
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
	mov	dptr,#0x2200
	mov	a,#0x02
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
	mov	dptr,#0x2237
	mov	a,#0x7f
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
	mov	dptr,#0x223d
	mov	a,#0xff
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
	mov	dptr,#0x223b
	mov	a,#0x07
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
;	assignBit
	setb	_IE_USB
;	tmk_core/protocol/ch555/usb_ak820.c:494: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'USB_WakeUp_PC'
;------------------------------------------------------------
;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_420'
;i             Allocated with name '_USB_WakeUp_PC_i_30000_423'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
;	-----------------------------------------
;	 function USB_WakeUp_PC
;	-----------------------------------------
_USB_WakeUp_PC:
;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00110$
;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
	mov	dptr,#0x223c
	movx	a,@dptr
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
	movx	a,@dptr
	mov	r6,a
	xrl	ar6,#0xc0
	mov	dptr,#0x223c
	mov	a,r6
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
	mov	r6,#0x0a
00108$:
	mov	a,r6
	jz	00105$
	mov	dptr,#0x0001
	lcall	_mDelaymS
	dec	r6
	sjmp	00108$
00105$:
;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
	mov	dptr,#0x223c
	mov	a,r7
	movx	@dptr,a
00110$:
;	tmk_core/protocol/ch555/usb_ak820.c:503: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_usb_send'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
;report        Allocated with name '_ak820_usb_send_PARM_2'
;length        Allocated with name '_ak820_usb_send_PARM_3'
;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_425'
;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_426'
;i             Allocated with name '_ak820_usb_send_i_10000_426'
;timeout       Allocated with name '_ak820_usb_send_timeout_10000_426'
;offset        Allocated with name '_ak820_usb_send_offset_10000_426'
;report_id     Allocated with name '_ak820_usb_send_report_id_10000_426'
;i             Allocated with name '_ak820_usb_send_i_30000_438'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
;	-----------------------------------------
;	 function ak820_usb_send
;	-----------------------------------------
_ak820_usb_send:
	mov	a,dpl
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
	mov	dptr,#_ak820_usb_send_offset_10000_426
	mov	a,#0x2e
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00306$
00306$:
	jc	00101$
	mov	a,r7
	add	a,#0xff - 0x03
	jc	00101$
;	free result
	mov	dptr,#_ak820_usb_send_PARM_3
	movx	a,@dptr
	mov  r6,a
	add	a,#0xff - 0x40
	jc	00101$
;	free result
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jnz	00102$
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
	cjne	r7,#0x01,00118$
;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
	cjne	r6,#0x08,00313$
	sjmp	00107$
00313$:
	mov	dpl, #0x00
	ret
00107$:
;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
	mov	dptr,#_ak820_usb_send_offset_10000_426
	clr	a
	movx	@dptr,a
	sjmp	00119$
00118$:
;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
	cjne	r7,#0x02,00115$
;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
	mov	dptr,#_ak820_usb_send_PARM_2
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r5
	mov	dph,r7
	movx	a,@dptr
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
	cjne	r7,#0x07,00316$
00316$:
	jnc	00108$
	mov	a,r7
	mov	dptr,#_shared_lengths
	movc	a,@a+dptr
	mov	r5,a
	jz	00108$
	mov	a,r6
	cjne	a,ar5,00319$
	sjmp	00109$
00319$:
00108$:
	mov	dpl, #0x00
	ret
00109$:
;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
	mov	a,r7
	mov	dptr,#_shared_offsets
	movc	a,@a+dptr
	mov	dptr,#_ak820_usb_send_offset_10000_426
	movx	@dptr,a
	sjmp	00119$
00115$:
;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
	cjne	r6,#0x20,00320$
	sjmp	00119$
00320$:
	mov	dpl, #0x00
	ret
00119$:
;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	jnb	acc.1,00184$
	lcall	_USB_WakeUp_PC
	mov	dpl, #0x00
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
00184$:
	mov	r7,#0xfa
00127$:
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0x00
	mov	ar2,r4
	mov	a,#0x22
	add	a, r5
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	anl	a,#0x03
	jnz	00129$
	mov	ar3,r7
	dec	r7
	mov	a,r3
	jz	00129$
	mov	r3,#0x28
00141$:
	mov	a,r3
	jz	00127$
	mov	dptr,#0x0001
	lcall	_mDelayuS
	dec	r3
	sjmp	00141$
00129$:
;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
	mov	c,_EA
	clr	a
	rlc	a
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jz	00130$
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	a,@dptr
	mov	r3,a
	mov	r1,a
	mov	r2,#0x00
	mov	a,#0x22
	add	a, r2
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	mov	r2,a
	anl	ar2,#0x03
	cjne	r2,#0x02,00130$
;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
	cjne	r3,#0x03,00192$
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x03,00331$
	sjmp	00192$
00331$:
00130$:
;	assignBit
	mov	a,r7
	add	a,#0xff
	mov	_EA,c
	mov	dpl, #0x00
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
00192$:
	mov	r3,#0x00
00144$:
	clr	c
	mov	a,r3
	subb	a,r6
	jnc	00137$
;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
	push	ar7
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	a,@dptr
	mov	r1,a
	clr	a
	clr	c
	xch	a,r1
	rrc	a
	xch	a,r1
	rrc	a
	mov	c,acc.0
	xch	a,r1
	rrc	a
	xch	a,r1
	rrc	a
	xch	a,r1
	mov	r2,a
	mov	ar0,r3
	mov	r7,#0x00
	mov	a,r0
	add	a, r1
	mov	r1,a
	mov	a,r7
	addc	a, r2
	add	a,#0x10
	mov	r2,a
	mov	dptr,#_ak820_usb_send_PARM_2
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,r3
	add	a, r0
	mov	_ak820_usb_send_sloc0_1_0,a
	clr	a
	addc	a, r7
	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
	mov	dpl,_ak820_usb_send_sloc0_1_0
	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
	movx	a,@dptr
	mov	dpl,r1
	mov	dph,r2
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
	mov	dptr,#_ak820_usb_send_offset_10000_426
	movx	a,@dptr
	mov	_ak820_usb_send_sloc1_1_0,a
	mov	a,#0x2e
	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
	pop	ar7
	sjmp	00145$
00333$:
	pop	ar7
	mov	a,r3
	add	a, _ak820_usb_send_sloc1_1_0
	add	a, #_input_snapshot
	mov	r1,a
	clr	a
	addc	a,#(_input_snapshot >> 8)
	mov	r2,a
	mov	dpl,_ak820_usb_send_sloc0_1_0
	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
	movx	a,@dptr
	mov	dpl,r1
	mov	dph,r2
	movx	@dptr,a
00145$:
;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
	inc	r3
	sjmp	00144$
00137$:
;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
	mov	dptr,#_ak820_usb_send_endpoint_10000_425
	movx	a,@dptr
	mov	r3,a
	mov	r1,a
	mov	r2,#0x00
	mov	a,#0x08
	add	a, r1
	mov	r1,a
	mov	a,#0x22
	addc	a, r2
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	mov	a,r6
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
	cjne	r3,#0x03,00139$
	mov	dptr,#_raw_state
	mov	a,#0x04
	movx	@dptr,a
00139$:
;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
	mov	a,#0x22
	add	a, r5
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r6,a
	anl	ar6,#0xfc
	mov	dpl,r4
	mov	dph,r5
	mov	a,r6
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
;	assignBit
	mov	a,r7
	add	a,#0xff
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
	mov	dpl, #0x01
;	tmk_core/protocol/ch555/usb_ak820.c:535: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_usb_try_send'
;------------------------------------------------------------
;report        Allocated with name '_ak820_usb_try_send_PARM_2'
;length        Allocated with name '_ak820_usb_try_send_PARM_3'
;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_446'
;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_447'
;sent          Allocated with name '_ak820_usb_try_send_sent_10000_447'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
;	-----------------------------------------
;	 function ak820_usb_try_send
;	-----------------------------------------
_ak820_usb_try_send:
	mov	a,dpl
	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
;	assignBit
	mov	c,_EA
	mov	_ak820_usb_try_send_sloc0_1_0,c
;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
	mov	dptr,#_ak820_usb_try_send_sent_10000_447
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00152$
00152$:
	jc	00102$
	mov	a,r7
	add	a,#0xff - 0x02
	jc	00102$
;	free result
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jz	00102$
;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	jb	acc.1,00102$
	mov	dptr,#_keyboard_reset
	movx	a,@dptr
;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
	jnz	00102$
	mov	ar6,r7
	add	a,#0x22
	mov	r5,a
	mov	dpl,r6
	mov	dph,r5
	movx	a,@dptr
	mov	r6,a
	anl	ar6,#0x03
	cjne	r6,#0x02,00102$
;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
	mov	dptr,#_ak820_usb_try_send_PARM_2
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_ak820_usb_try_send_PARM_3
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_ak820_usb_send_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,r4
	movx	@dptr,a
	mov	dpl, r7
	lcall	_ak820_usb_send
	mov	a, dpl
	mov	dptr,#_ak820_usb_try_send_sent_10000_447
	movx	@dptr,a
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
;	assignBit
	mov	c,_ak820_usb_try_send_sloc0_1_0
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
	mov	dptr,#_ak820_usb_try_send_sent_10000_447
	movx	a,@dptr
;	tmk_core/protocol/ch555/usb_ak820.c:551: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'raw_request_is_nonpersistent'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
;	-----------------------------------------
;	 function raw_request_is_nonpersistent
;	-----------------------------------------
_raw_request_is_nonpersistent:
;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
	mov	dptr,#_raw_buffer
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00302$
	sjmp	00108$
00302$:
	cjne	r7,#0x02,00303$
	sjmp	00109$
00303$:
	cjne	r7,#0x04,00304$
	sjmp	00108$
00304$:
	cjne	r7,#0x08,00305$
	sjmp	00116$
00305$:
	cjne	r7,#0x0b,00306$
	sjmp	00108$
00306$:
	cjne	r7,#0x0c,00307$
	sjmp	00108$
00307$:
	cjne	r7,#0x0d,00308$
	sjmp	00108$
00308$:
	cjne	r7,#0x0e,00309$
	sjmp	00108$
00309$:
	cjne	r7,#0x11,00310$
	sjmp	00108$
00310$:
	cjne	r7,#0x12,00311$
	sjmp	00108$
00311$:
	cjne	r7,#0xfe,00312$
	sjmp	00124$
00312$:
	ljmp	00144$
;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
00108$:
;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
	mov	dpl, #0x01
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
00109$:
;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
	lcall	_ak820_outline_0159
	cjne	r7,#0x01,00313$
	sjmp	00113$
00313$:
	cjne	r7,#0x02,00314$
	sjmp	00113$
00314$:
	cjne	r7,#0x03,00315$
	sjmp	00113$
00315$:
	cjne	r7,#0x04,00114$
;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
00113$:
;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
	mov	dpl, #0x01
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
00114$:
	mov	dpl, #0x00
	ret
;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
00116$:
;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
	lcall	_ak820_outline_0159
	cjne	r7,#0x40,00318$
	sjmp	00121$
00318$:
	cjne	r7,#0x41,00319$
	sjmp	00121$
00319$:
	cjne	r7,#0x42,00320$
	sjmp	00121$
00320$:
	cjne	r7,#0x43,00321$
	sjmp	00121$
00321$:
	cjne	r7,#0x44,00122$
;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
00121$:
;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
	mov	dpl, #0x01
;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
	ret
00122$:
	mov	dpl, #0x00
;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
	ret
00124$:
;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
	lcall	_ak820_outline_0159
	add	a,#0xff - 0x0d
	jc	00142$
;	free result
	mov	a,r7
	add	a,#(00325$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r7
	add	a,#(00326$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00325$:
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00142$
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00134$
	.db	00142$
	.db	00142$
	.db	00135$
00326$:
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00142$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00134$>>8
	.db	00142$>>8
	.db	00142$>>8
	.db	00135$>>8
;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
00134$:
;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
	mov	dpl, #0x01
;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
	ret
00135$:
;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
	mov	dptr,#(_raw_buffer + 0x0002)
	movx	a,@dptr
	mov	r7,a
	jz	00139$
	cjne	r7,#0x01,00328$
	sjmp	00139$
00328$:
	cjne	r7,#0x03,00329$
	sjmp	00139$
00329$:
	cjne	r7,#0x05,00140$
;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
00139$:
;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
	mov	dpl, #0x01
;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
	ret
00140$:
	mov	dpl, #0x00
;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
	ret
00142$:
	mov	dpl, #0x00
;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
	ret
00144$:
	mov	dpl, #0x00
;	tmk_core/protocol/ch555/usb_ak820.c:611: }
;	tmk_core/protocol/ch555/usb_ak820.c:612: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_usb_raw_send'
;------------------------------------------------------------
;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
;report        Allocated with name '_ak820_usb_raw_send_report_10000_462'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
;	-----------------------------------------
;	 function ak820_usb_raw_send
;	-----------------------------------------
_ak820_usb_raw_send:
	lcall	_ak820_outline_0037
	mov	dptr,#_ak820_usb_raw_send_report_10000_462
	lcall	_ak820_outline_0016
;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
	mov	dptr,#_ak820_usb_raw_send_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x20,00106$
;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
	push	ar7
	lcall	_ak820_nvm_flush
	pop	ar7
;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
	mov	dptr,#_raw_reply_without_nvm
	movx	a,@dptr
	jnz	00103$
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00106$
00103$:
	mov	dptr,#_ak820_usb_raw_send_report_10000_462
	lcall	_ak820_outline_0097
	mov	dptr,#_ak820_usb_send_PARM_2
	lcall	_ak820_outline_0157
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,r7
	movx	@dptr,a
	mov	dpl, #0x03
;	tmk_core/protocol/ch555/usb_ak820.c:618: }
	ljmp	_ak820_usb_send
00106$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_usb_raw_task'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
;i             Allocated with name '_ak820_usb_raw_task_i_10000_467'
;length        Allocated with name '_ak820_usb_raw_task_length_10000_467'
;address       Allocated with name '_ak820_usb_raw_task_address_10000_467'
;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_467'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
;	-----------------------------------------
;	 function ak820_usb_raw_task
;	-----------------------------------------
_ak820_usb_raw_task:
;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
	mov	c,_EA
	clr	a
	rlc	a
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jz	00101$
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x02,00427$
	sjmp	00102$
00427$:
00101$:
;	assignBit
	mov	a,r7
	add	a,#0xff
	mov	_EA,c
	ret
00102$:
;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
	mov	dptr,#_raw_state
	mov	a,#0x03
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
;	assignBit
	mov	a,r7
	add	a,#0xff
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
	mov	dptr,#_raw_buffer
	movx	a,@dptr
	mov	r7,a
	clr	a
	cjne	r7,#0xfd,00428$
	inc	a
00428$:
	mov	r7,a
	jnz	00430$
	ljmp	00141$
00430$:
	mov	dptr,#(_raw_buffer + 0x0001)
	movx	a,@dptr
	jz	00431$
	ljmp	00141$
00431$:
;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
	mov	dptr,#(_raw_buffer + 0x0002)
	movx	a,@dptr
	mov	r5,a
	mov	r6,#0x00
	mov	dptr,#(_raw_buffer + 0x0003)
	movx	a,@dptr
	mov	r3,#0x00
	orl	ar6,a
	mov	a,r3
	orl	ar5,a
;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
	mov	dptr,#(_raw_buffer + 0x0004)
	movx	a,@dptr
	mov	r4,a
;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
	mov	r3,#0x05
00151$:
	mov	a,r3
	lcall	_ak820_outline_0040
	inc	r3
	cjne	r3,#0x20,00432$
00432$:
	jc	00151$
;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
	mov	a,r4
	add	a,#0xff - 0x1b
	jc	00106$
;	free result
	mov	a,r4
	jz	00212$
	mov	ar3,r4
	dec	r3
	mov	r2,#0x00
	mov	a,#0xff
	clr	c
	subb	a,r3
	mov	r3,a
	mov	a,#0xff
	subb	a,r2
	mov	r2,a
	mov	ar0,r6
	mov	ar1,r5
	clr	c
	mov	a,r3
	subb	a,r0
	mov	a,r2
	subb	a,r1
	jnc	00212$
;	free result
00106$:
;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
	mov	dptr,#(_raw_buffer + 0x0001)
	mov	a,#0xff
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
	mov	dptr,#(_raw_buffer + 0x0004)
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
	sjmp	00108$
00212$:
	mov	r3,#0x00
00154$:
	clr	c
	mov	a,r3
	subb	a,r4
	jnc	00108$
	push	ar4
	mov	ar2,r3
	mov	a,#0x05
	add	a, r2
	mov	r1,a
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	a,r1
	add	a, #_raw_buffer
	mov	r1,a
	mov	a,r2
	addc	a, #(_raw_buffer >> 8)
	mov	r2,a
	mov	_ak820_usb_raw_task_sloc0_1_0,r3
	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
	mov	ar0,r6
	mov	ar4,r5
	mov	a,_ak820_usb_raw_task_sloc0_1_0
	add	a, r0
	mov	r0,a
	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
	addc	a, r4
	mov	r4,a
	mov	dpl,r0
	mov	dph,r4
	clr	a
	movc	a,@a+dptr
	lcall	_ak820_outline_0136
	inc	r3
	pop	ar4
	sjmp	00154$
00108$:
;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
	lcall	_ak820_outline_0008
	lcall	_ak820_usb_send
	ljmp	00142$
00141$:
;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
	mov	a,r7
	jnz	00438$
	ljmp	00137$
00438$:
	mov	dptr,#(_raw_buffer + 0x0001)
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00439$
	sjmp	00440$
00439$:
	ljmp	00137$
00440$:
;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
	mov	r6,#0x02
00156$:
	mov	a,r6
	lcall	_ak820_outline_0040
	inc	r6
	cjne	r6,#0x20,00441$
00441$:
	jc	00156$
;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
	mov	dptr,#(_raw_buffer + 0x0002)
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
	mov	dptr,#(_raw_buffer + 0x0003)
	mov	a,#0xa8
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
	mov	dptr,#(_raw_buffer + 0x0004)
	lcall	_ak820_nvm_diagnostic
;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
	mov	r6,#0x00
00158$:
	mov	ar5,r6
	mov	a,#0x0b
	add	a, r5
	add	a,#_raw_buffer
	mov	r5,a
	clr	a
	addc	a, #(_raw_buffer >> 8)
	mov	r4,a
	mov	a,r6
	add	a, #_ak820_flash_diagnostic
	mov	dpl,a
	clr	a
	addc	a, #(_ak820_flash_diagnostic >> 8)
	mov	dph,a
	movx	a,@dptr
	lcall	_ak820_outline_0186
	movx	@dptr,a
	inc	r6
	cjne	r6,#0x06,00443$
00443$:
	jc	00158$
;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0011)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0012)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0013)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0014)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0015)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
	lcall	_ak820_outline_0008
	lcall	_ak820_usb_send
	ljmp	00142$
00137$:
;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
	mov	a,r7
	jnz	00445$
	ljmp	00133$
00445$:
	lcall	_ak820_outline_0159
	cjne	r7,#0x02,00446$
	sjmp	00447$
00446$:
	ljmp	00133$
00447$:
;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
	mov	dptr,#_ak820_usb_raw_task_length_10000_467
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
	mov	dptr,#(_raw_buffer + 0x0002)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00235$
	mov	dptr,#(_raw_buffer + 0x0003)
	movx	a,@dptr
	mov  r7,a
	add	a,#0xff - 0x01
	jc	00235$
;	free result
	mov	dptr,#(_raw_buffer + 0x0004)
	movx	a,@dptr
	mov  r6,a
	add	a,#0xff - 0x03
	jc	00235$
;	free result
;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
	mov	a,r7
	jnz	00227$
	mov	a,r6
	jnz	00235$
;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
00227$:
	mov	r5,#0x05
00162$:
	cjne	r5,#0x20,00454$
00454$:
	jnc	00113$
	mov	a,r5
	add	a, #_raw_buffer
	mov	r3,a
	clr	a
	addc	a, #(_raw_buffer >> 8)
	mov	r4,a
	lcall	_ak820_outline_0122
	movx	a,@dptr
	jnz	00113$
	inc	r5
	sjmp	00162$
00113$:
;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
	cjne	r5,#0x20,00235$
;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
;	assignBit
	mov	c,_EA
	mov	_ak820_usb_raw_task_sloc1_1_0,c
;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x03,00117$
	mov	dptr,#_USB_EnumStatus
	movx	a,@dptr
	jz	00117$
	mov	dptr,#_D0UsbConfig
	movx	a,@dptr
	jz	00117$
;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
	mov	dptr,#_USB_SleepStatus
	movx	a,@dptr
	jb	acc.1,00117$
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jnz	00117$
;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
	mov	a,r7
	jz	00115$
	mov	dpl, r6
	lcall	_ak820_os_indicator_set
00115$:
;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
	mov	dptr,#_ak820_usb_raw_task_length_10000_467
	clr	a
	movx	@dptr,a
	sjmp	00118$
00117$:
;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
	mov	dptr,#_ak820_usb_raw_task_length_10000_467
	mov	a,#0x02
	movx	@dptr,a
00118$:
;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
;	assignBit
	mov	c,_ak820_usb_raw_task_sloc1_1_0
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
00235$:
	mov	r7,#0x02
00164$:
	mov	a,r7
	lcall	_ak820_outline_0040
	inc	r7
	cjne	r7,#0x20,00466$
00466$:
	jc	00164$
;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
	mov	dptr,#(_raw_buffer + 0x0002)
	mov	a,#0x01
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
	mov	dptr,#_ak820_usb_raw_task_length_10000_467
	movx	a,@dptr
	mov	dptr,#(_raw_buffer + 0x0003)
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
	lcall	_ak820_os_indicator_get
	mov	r7, dpl
	mov	dptr,#(_raw_buffer + 0x0004)
	mov	a,r7
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
	mov	dptr,#(_raw_buffer + 0x0005)
	mov	a,#0xa8
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
	mov	dptr,#(_raw_buffer + 0x0006)
	mov	a,#0xb8
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
	mov	dptr,#(_raw_buffer + 0x0007)
	mov	a,#0x0b
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
	mov	dptr,#(_raw_buffer + 0x0008)
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
	mov	dptr,#(_raw_buffer + 0x0009)
	mov	a,#0x10
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
	lcall	_ak820_outline_0008
	lcall	_ak820_usb_send
	sjmp	00142$
00133$:
;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
	lcall	_raw_request_is_nonpersistent
	mov	a, dpl
	mov	dptr,#_raw_reply_without_nvm
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
	lcall	_ak820_nvm_begin
;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
	mov	dptr,#_raw_hid_receive_PARM_2
	mov	a,#0x20
	movx	@dptr,a
	mov	dptr,#_raw_buffer
	mov	b, #0x00
	lcall	_raw_hid_receive
;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
	lcall	_ak820_nvm_end
;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
	mov	dptr,#_raw_reply_without_nvm
	clr	a
	movx	@dptr,a
00142$:
;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
;	assignBit
	mov	c,_EA
	mov	_ak820_usb_raw_task_sloc1_1_0,c
;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
	lcall	_ak820_outline_0161
	cjne	r7,#0x04,00149$
	mov	dptr,#_raw_state
	mov	a,#0x05
	movx	@dptr,a
	sjmp	00150$
00149$:
;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
	lcall	_ak820_outline_0161
	cjne	r7,#0x03,00470$
	sjmp	00144$
00470$:
	lcall	_ak820_outline_0161
	cjne	r7,#0x06,00471$
	sjmp	00144$
00471$:
	lcall	_ak820_outline_0161
	cjne	r7,#0x07,00150$
00144$:
	mov	dptr,#_raw_state
	clr	a
	movx	@dptr,a
00150$:
;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
;	assignBit
	mov	c,_ak820_usb_raw_task_sloc1_1_0
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:704: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
;------------------------------------------------------------
;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_497'
;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_497'
;------------------------------------------------------------
;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
;	-----------------------------------------
;	 function ak820_usb_take_keyboard_reset
;	-----------------------------------------
_ak820_usb_take_keyboard_reset:
;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
;	assignBit
	mov	c,_EA
	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
;	assignBit
	clr	_EA
;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
	mov	dptr,#_keyboard_reset
	movx	a,@dptr
	mov	r7,a
;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
	clr	a
	movx	@dptr,a
;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
;	assignBit
	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
	mov	_EA,c
;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
	mov	a,r7
	cjne	a,#0x01,00103$
00103$:
	cpl	c
	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
	lcall	_ak820_outline_0166
;	tmk_core/protocol/ch555/usb_ak820.c:720: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_shared_offsets:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x28	; 40
	.db #0x28	; 40
	.db #0x2b	; 43
	.db #0x00	; 0
	.db #0x08	; 8
	.area CSEG    (CODE)
	.area CONST   (CODE)
_shared_lengths:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x03	; 3
	.db #0x03	; 3
	.db #0x00	; 0
	.db #0x20	; 32
	.area CSEG    (CODE)
	.area CONST   (CODE)
_interface_descriptors:
	.byte _KeyboardReport, (_KeyboardReport >> 8)
	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
	.byte _RawReport, (_RawReport >> 8)
	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
	.byte _SharedReport, (_SharedReport >> 8)
	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0008
	.globl _ak820_outline_0016
	.globl _ak820_outline_0037
	.globl _ak820_outline_0040
	.globl _ak820_outline_0097
	.globl _ak820_outline_0122
	.globl _ak820_outline_0136
	.globl _ak820_outline_0157
	.globl _ak820_outline_0159
	.globl _ak820_outline_0161
	.globl _ak820_outline_0166
	.globl _ak820_outline_0186

	.area CSEG (CODE)
; function ak820_outline_0008
_ak820_outline_0008:
	mov	dptr,#_ak820_usb_send_PARM_2
	mov	a,#_raw_buffer
	movx	@dptr,a
	mov	a,#(_raw_buffer>>8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_send_PARM_3
	mov	a,#0x20
	movx	@dptr,a
	mov	dpl,#0x03
	ret

	.area CSEG (CODE)
; function ak820_outline_0040
_ak820_outline_0040:
	add	a,#_raw_buffer
	mov	dpl,a
	clr	a
	addc	a,#(_raw_buffer>>8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0136
_ak820_outline_0136:
	mov	dpl,r1
	mov	dph,r2
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0159
_ak820_outline_0159:
	mov	dptr,#(_raw_buffer+0x0001)
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0161
_ak820_outline_0161:
	mov	dptr,#_raw_state
	movx	a,@dptr
	mov	r7,a
	ret
