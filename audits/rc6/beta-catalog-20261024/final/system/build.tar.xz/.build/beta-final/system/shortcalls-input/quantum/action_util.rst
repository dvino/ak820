                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_mac_mode
                                    269 	.globl _ak820_gui_process
                                    270 	.globl _ak820_macro_change
                                    271 	.globl _add_owned_mods
                                    272 	.globl _del_owned_mods
                                    273 	.globl _add_owned_weak_mods
                                    274 	.globl _del_owned_weak_mods
                                    275 	.globl _clear_owned_mods
                                    276 	.globl _clear_owned_keys
                                    277 	.globl _add_owned_key
                                    278 	.globl _del_owned_key
                                    279 	.globl _clear_owned_usages
                                    280 	.globl _owned_usage_key
                                    281 	.globl _send_keyboard_report
                                    282 	.globl _get_mods
                                    283 	.globl _clear_mods
                                    284 	.globl _get_weak_mods
                                    285 	.globl _add_weak_mods
                                    286 	.globl _del_weak_mods
                                    287 	.globl _clear_weak_mods
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 	.area	OSEG    (OVR,DATA)
      000054                        554 _change_owned_sloc1_1_0:
      000054                        555 	.ds 1
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      00001E                        569 _ak820_mac_mode::
      00001E                        570 	.ds 1
      00001F                        571 _gui_disabled:
      00001F                        572 	.ds 1
      000020                        573 _ctrl_gui_swapped:
      000020                        574 	.ds 1
      000021                        575 _ak820_gui_process_sloc0_1_0:
      000021                        576 	.ds 1
      000022                        577 _ak820_macro_change_sloc0_1_0:
      000022                        578 	.ds 1
      000023                        579 _change_owned_sloc0_1_0:
      000023                        580 	.ds 1
      000024                        581 _owned_usage_key_sloc0_1_0:
      000024                        582 	.ds 1
                                    583 ;--------------------------------------------------------
                                    584 ; paged external ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area PSEG    (PAG,XDATA)
                                    587 ;--------------------------------------------------------
                                    588 ; uninitialized external ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area XSEG    (XDATA)
      000971                        591 _ak820_gui_process_PARM_2:
      000971                        592 	.ds 1
      000972                        593 _ak820_gui_process_code_10000_294:
      000972                        594 	.ds 2
      000974                        595 _owned_mod_refs:
      000974                        596 	.ds 8
      00097C                        597 _owned_weak_refs:
      00097C                        598 	.ds 8
      000984                        599 _owned_mods:
      000984                        600 	.ds 1
      000985                        601 _owned_weak_mods:
      000985                        602 	.ds 1
      000986                        603 _macro_mods:
      000986                        604 	.ds 2
      000988                        605 _ak820_macro_primitive::
      000988                        606 	.ds 1
      000989                        607 _ak820_macro_cancelled::
      000989                        608 	.ds 1
      00098A                        609 _ak820_macro_change_PARM_2:
      00098A                        610 	.ds 1
      00098B                        611 _ak820_macro_change_PARM_3:
      00098B                        612 	.ds 1
      00098C                        613 _ak820_macro_change_bits_10000_307:
      00098C                        614 	.ds 2
      00098E                        615 _change_owned_PARM_2:
      00098E                        616 	.ds 1
      00098F                        617 _change_owned_mods_10000_312:
      00098F                        618 	.ds 1
      000990                        619 _change_owned_result_10001_316:
      000990                        620 	.ds 1
      000991                        621 _change_owned_bit_20001_317:
      000991                        622 	.ds 1
      000992                        623 _add_owned_mods_mods_10000_325:
      000992                        624 	.ds 1
      000993                        625 _del_owned_mods_mods_10000_327:
      000993                        626 	.ds 1
      000994                        627 _add_owned_weak_mods_mods_10000_329:
      000994                        628 	.ds 1
      000995                        629 _del_owned_weak_mods_mods_10000_331:
      000995                        630 	.ds 1
      000996                        631 _key_refs:
      000996                        632 	.ds 165
      000A3B                        633 _distinct_keys:
      000A3B                        634 	.ds 1
      000A3C                        635 _macro_keys:
      000A3C                        636 	.ds 21
      000A51                        637 _add_owned_key_code_10000_340:
      000A51                        638 	.ds 1
      000A52                        639 _del_owned_key_code_10000_355:
      000A52                        640 	.ds 1
      000A53                        641 _usage_refs:
      000A53                        642 	.ds 30
      000A71                        643 _usage_order:
      000A71                        644 	.ds 30
      000A8F                        645 _usage_lengths:
      000A8F                        646 	.ds 2
      000A91                        647 _macro_usages:
      000A91                        648 	.ds 4
      000A95                        649 _owned_usage_key_PARM_2:
      000A95                        650 	.ds 1
      000A96                        651 _owned_usage_key_code_10000_382:
      000A96                        652 	.ds 1
      000A97                        653 _owned_usage_key___200000085_20000_383:
      000A97                        654 	.ds 2
      000A99                        655 _owned_usage_key_which_10000_383:
      000A99                        656 	.ds 1
      000A9A                        657 _owned_usage_key_count_10000_383:
      000A9A                        658 	.ds 1
      000A9B                        659 _owned_usage_key_pos_30001_390:
      000A9B                        660 	.ds 1
      000A9C                        661 _owned_usage_key_key_40000_395:
      000A9C                        662 	.ds 1
      000A9D                        663 _send_keyboard_report_last_report_10001_407:
      000A9D                        664 	.ds 32
      000ABD                        665 _send_keyboard_report_changed_10001_407:
      000ABD                        666 	.ds 1
      000ABE                        667 _add_weak_mods_mods_10000_425:
      000ABE                        668 	.ds 1
      000ABF                        669 _del_weak_mods_mods_10000_427:
      000ABF                        670 	.ds 1
                                    671 ;--------------------------------------------------------
                                    672 ; absolute external ram data
                                    673 ;--------------------------------------------------------
                                    674 	.area XABS    (ABS,XDATA)
                                    675 ;--------------------------------------------------------
                                    676 ; initialized external ram data
                                    677 ;--------------------------------------------------------
                                    678 	.area XISEG   (XDATA)
      000D9F                        679 _real_mods:
      000D9F                        680 	.ds 1
      000DA0                        681 _weak_mods:
      000DA0                        682 	.ds 1
      000DA1                        683 _actual_keyboard_report::
      000DA1                        684 	.ds 32
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function ak820_gui_process
                                    727 ;	-----------------------------------------
      007CD9                        728 _ak820_gui_process:
      007CD9 12 38 49         [24]  729 	lcall	_ak820_outline_0104
      007CDC 90 09 72         [24]  730 	mov	dptr,#_ak820_gui_process_code_10000_294
      007CDF 12 38 4E         [24]  731 	lcall	_ak820_outline_0105
                                    732 ;	quantum/action_util.c:62: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) {
      007CE2 90 09 72         [24]  733 	mov	dptr,#_ak820_gui_process_code_10000_294
      007CE5 12 38 00         [24]  734 	lcall	_ak820_outline_0051
      007CE8 E4               [12]  735 	clr	a
      007CE9 BE 14 04         [24]  736 	cjne	r6,#0x14,00203$
      007CEC BF 70 01         [24]  737 	cjne	r7,#0x70,00203$
      007CEF 04               [12]  738 	inc	a
      007CF0                        739 00203$:
      007CF0 FD               [12]  740 	mov	r5,a
      007CF1 70 0E            [24]  741 	jnz	00103$
      007CF3 BE 15 05         [24]  742 	cjne	r6,#0x15,00206$
      007CF6 BF 70 02         [24]  743 	cjne	r7,#0x70,00206$
      007CF9 80 06            [24]  744 	sjmp	00103$
      007CFB                        745 00206$:
      007CFB BE 16 27         [24]  746 	cjne	r6,#0x16,00104$
      007CFE BF 70 24         [24]  747 	cjne	r7,#0x70,00104$
      007D01                        748 00103$:
                                    749 ;	quantum/action_util.c:63: if (pressed) {
      007D01 90 09 71         [24]  750 	mov	dptr,#_ak820_gui_process_PARM_2
      007D04 E0               [24]  751 	movx	a,@dptr
      007D05 60 1A            [24]  752 	jz	00102$
                                    753 ;	quantum/action_util.c:64: ak820_mac_mode = code == QK_MAGIC_TOGGLE_ALT_GUI ? !ak820_mac_mode : code == QK_MAGIC_SWAP_ALT_GUI;
      007D07 BE 16 0D         [24]  754 	cjne	r6,#0x16,00120$
      007D0A BF 70 0A         [24]  755 	cjne	r7,#0x70,00120$
      007D0D A2 1E            [12]  756 	mov	c,_ak820_mac_mode
      007D0F B3               [12]  757 	cpl	c
      007D10 92 21            [24]  758 	mov  _ak820_gui_process_sloc0_1_0,c
      007D12 E4               [12]  759 	clr	a
      007D13 33               [12]  760 	rlc	a
      007D14 FC               [12]  761 	mov	r4,a
      007D15 80 02            [24]  762 	sjmp	00121$
      007D17                        763 00120$:
      007D17 8D 04            [24]  764 	mov	ar4,r5
      007D19                        765 00121$:
                                    766 ;	assignBit
      007D19 EC               [12]  767 	mov	a,r4
      007D1A 24 FF            [12]  768 	add	a,#0xff
      007D1C 92 1E            [24]  769 	mov	_ak820_mac_mode,c
                                    770 ;	quantum/action_util.c:65: send_keyboard_report();
      007D1E 12 82 1A         [24]  771 	lcall	_send_keyboard_report
      007D21                        772 00102$:
                                    773 ;	quantum/action_util.c:67: return false;
      007D21 75 82 00         [24]  774 	mov	dpl, #0x00
      007D24 22               [24]  775 	ret
      007D25                        776 00104$:
                                    777 ;	quantum/action_util.c:71: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) {
      007D25 E4               [12]  778 	clr	a
      007D26 BE 1B 04         [24]  779 	cjne	r6,#0x1b,00212$
      007D29 BF 70 01         [24]  780 	cjne	r7,#0x70,00212$
      007D2C 04               [12]  781 	inc	a
      007D2D                        782 00212$:
      007D2D FD               [12]  783 	mov	r5,a
      007D2E 70 0E            [24]  784 	jnz	00109$
      007D30 BE 1C 05         [24]  785 	cjne	r6,#0x1c,00215$
      007D33 BF 70 02         [24]  786 	cjne	r7,#0x70,00215$
      007D36 80 06            [24]  787 	sjmp	00109$
      007D38                        788 00215$:
      007D38 BE 1D 27         [24]  789 	cjne	r6,#0x1d,00110$
      007D3B BF 70 24         [24]  790 	cjne	r7,#0x70,00110$
      007D3E                        791 00109$:
                                    792 ;	quantum/action_util.c:72: if (pressed) {
      007D3E 90 09 71         [24]  793 	mov	dptr,#_ak820_gui_process_PARM_2
      007D41 E0               [24]  794 	movx	a,@dptr
      007D42 60 1A            [24]  795 	jz	00108$
                                    796 ;	quantum/action_util.c:73: ctrl_gui_swapped = code == QK_MAGIC_TOGGLE_CTL_GUI ? !ctrl_gui_swapped : code == QK_MAGIC_SWAP_CTL_GUI;
      007D44 BE 1D 0D         [24]  797 	cjne	r6,#0x1d,00122$
      007D47 BF 70 0A         [24]  798 	cjne	r7,#0x70,00122$
      007D4A A2 20            [12]  799 	mov	c,_ctrl_gui_swapped
      007D4C B3               [12]  800 	cpl	c
      007D4D 92 21            [24]  801 	mov  _ak820_gui_process_sloc0_1_0,c
      007D4F E4               [12]  802 	clr	a
      007D50 33               [12]  803 	rlc	a
      007D51 FC               [12]  804 	mov	r4,a
      007D52 80 02            [24]  805 	sjmp	00123$
      007D54                        806 00122$:
      007D54 8D 04            [24]  807 	mov	ar4,r5
      007D56                        808 00123$:
                                    809 ;	assignBit
      007D56 EC               [12]  810 	mov	a,r4
      007D57 24 FF            [12]  811 	add	a,#0xff
      007D59 92 20            [24]  812 	mov	_ctrl_gui_swapped,c
                                    813 ;	quantum/action_util.c:74: send_keyboard_report();
      007D5B 12 82 1A         [24]  814 	lcall	_send_keyboard_report
      007D5E                        815 00108$:
                                    816 ;	quantum/action_util.c:76: return false;
      007D5E 75 82 00         [24]  817 	mov	dpl, #0x00
      007D61 22               [24]  818 	ret
      007D62                        819 00110$:
                                    820 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007D62 C3               [12]  821 	clr	c
      007D63 EE               [12]  822 	mov	a,r6
      007D64 94 09            [12]  823 	subb	a,#0x09
      007D66 EF               [12]  824 	mov	a,r7
      007D67 94 70            [12]  825 	subb	a,#0x70
      007D69 40 08            [24]  826 	jc	00113$
      007D6B 74 0B            [12]  827 	mov	a,#0x0b
      007D6D 9E               [12]  828 	subb	a,r6
      007D6E 74 70            [12]  829 	mov	a,#0x70
      007D70 9F               [12]  830 	subb	a,r7
      007D71 50 04            [24]  831 	jnc	00114$
                                    832 ;	free result
      007D73                        833 00113$:
      007D73 75 82 01         [24]  834 	mov	dpl, #0x01
      007D76 22               [24]  835 	ret
      007D77                        836 00114$:
                                    837 ;	quantum/action_util.c:81: if (pressed) {
      007D77 90 09 71         [24]  838 	mov	dptr,#_ak820_gui_process_PARM_2
      007D7A E0               [24]  839 	movx	a,@dptr
      007D7B 60 21            [24]  840 	jz	00117$
                                    841 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007D7D BE 0B 0D         [24]  842 	cjne	r6,#0x0b,00124$
      007D80 BF 70 0A         [24]  843 	cjne	r7,#0x70,00124$
      007D83 A2 1F            [12]  844 	mov	c,_gui_disabled
      007D85 B3               [12]  845 	cpl	c
      007D86 92 21            [24]  846 	mov  _ak820_gui_process_sloc0_1_0,c
      007D88 E4               [12]  847 	clr	a
      007D89 33               [12]  848 	rlc	a
      007D8A FD               [12]  849 	mov	r5,a
      007D8B 80 09            [24]  850 	sjmp	00125$
      007D8D                        851 00124$:
      007D8D E4               [12]  852 	clr	a
      007D8E BE 0A 04         [24]  853 	cjne	r6,#0x0a,00226$
      007D91 BF 70 01         [24]  854 	cjne	r7,#0x70,00226$
      007D94 04               [12]  855 	inc	a
      007D95                        856 00226$:
      007D95 FD               [12]  857 	mov	r5,a
      007D96                        858 00125$:
                                    859 ;	assignBit
      007D96 ED               [12]  860 	mov	a,r5
      007D97 24 FF            [12]  861 	add	a,#0xff
      007D99 92 1F            [24]  862 	mov	_gui_disabled,c
                                    863 ;	quantum/action_util.c:83: send_keyboard_report();
      007D9B 12 82 1A         [24]  864 	lcall	_send_keyboard_report
      007D9E                        865 00117$:
                                    866 ;	quantum/action_util.c:85: return false;
      007D9E 75 82 00         [24]  867 	mov	dpl, #0x00
                                    868 ;	quantum/action_util.c:89: }
      007DA1 22               [24]  869 	ret
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'ak820_macro_change'
                                    872 ;------------------------------------------------------------
                                    873 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    874 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    875 ;bits          Allocated with name '_ak820_macro_change_bits_10000_307'
                                    876 ;mask          Allocated with name '_ak820_macro_change_mask_10001_310'
                                    877 ;------------------------------------------------------------
                                    878 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function ak820_macro_change
                                    881 ;	-----------------------------------------
      007DA2                        882 _ak820_macro_change:
      007DA2 12 38 49         [24]  883 	lcall	_ak820_outline_0104
      007DA5 90 09 8C         [24]  884 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007DA8 12 38 4E         [24]  885 	lcall	_ak820_outline_0105
                                    886 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007DAB 90 09 88         [24]  887 	mov	dptr,#_ak820_macro_primitive
      007DAE E0               [24]  888 	movx	a,@dptr
      007DAF 70 04            [24]  889 	jnz	00102$
      007DB1 75 82 01         [24]  890 	mov	dpl, #0x01
      007DB4 22               [24]  891 	ret
      007DB5                        892 00102$:
                                    893 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007DB5 90 09 8A         [24]  894 	mov	dptr,#_ak820_macro_change_PARM_2
      007DB8 E0               [24]  895 	movx	a,@dptr
      007DB9 FF               [12]  896 	mov	r7,a
      007DBA 74 07            [12]  897 	mov	a,#0x07
      007DBC 5F               [12]  898 	anl	a,r7
      007DBD 12 78 7E         [24]  899 	lcall	_ak820_outline_0063
      007DC0 80 02            [24]  900 	sjmp	00123$
      007DC2                        901 00122$:
      007DC2 25 E0            [12]  902 	add	a,acc
      007DC4                        903 00123$:
      007DC4 D5 F0 FB         [24]  904 	djnz	b,00122$
      007DC7 FE               [12]  905 	mov	r6,a
                                    906 ;	quantum/action_util.c:101: bits += index >> 3;
      007DC8 EF               [12]  907 	mov	a,r7
      007DC9 12 58 48         [24]  908 	lcall	_ak820_outline_0168
      007DCC FF               [12]  909 	mov	r7,a
      007DCD 90 09 8C         [24]  910 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007DD0 12 38 1F         [24]  911 	lcall	_ak820_outline_0060
      007DD3 90 09 8C         [24]  912 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007DD6 EF               [12]  913 	mov	a,r7
      007DD7 2C               [12]  914 	add	a, r4
      007DD8 F0               [24]  915 	movx	@dptr,a
      007DD9 E4               [12]  916 	clr	a
      007DDA 3D               [12]  917 	addc	a, r5
      007DDB A3               [24]  918 	inc	dptr
      007DDC F0               [24]  919 	movx	@dptr,a
                                    920 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      007DDD 90 09 8C         [24]  921 	mov	dptr,#_ak820_macro_change_bits_10000_307
      007DE0 E0               [24]  922 	movx	a,@dptr
      007DE1 FD               [12]  923 	mov	r5,a
      007DE2 A3               [24]  924 	inc	dptr
      007DE3 E0               [24]  925 	movx	a,@dptr
      007DE4 FF               [12]  926 	mov	r7,a
      007DE5 12 83 8D         [24]  927 	lcall	_ak820_outline_0187
      007DE8 E0               [24]  928 	movx	a,@dptr
      007DE9 FC               [12]  929 	mov	r4,a
      007DEA EE               [12]  930 	mov	a,r6
      007DEB 5C               [12]  931 	anl	a,r4
      007DEC B4 01 00         [24]  932 	cjne	a,#0x01,00124$
      007DEF                        933 00124$:
      007DEF B3               [12]  934 	cpl	c
      007DF0 92 22            [24]  935 	mov	_ak820_macro_change_sloc0_1_0,c
      007DF2 90 09 8B         [24]  936 	mov	dptr,#_ak820_macro_change_PARM_3
      007DF5 E0               [24]  937 	movx	a,@dptr
      007DF6 FB               [12]  938 	mov	r3,a
      007DF7 A2 22            [12]  939 	mov	c,_ak820_macro_change_sloc0_1_0
      007DF9 E4               [12]  940 	clr	a
      007DFA 33               [12]  941 	rlc	a
      007DFB B5 03 04         [24]  942 	cjne	a,ar3,00104$
      007DFE 75 82 00         [24]  943 	mov	dpl, #0x00
      007E01 22               [24]  944 	ret
      007E02                        945 00104$:
                                    946 ;	quantum/action_util.c:103: *bits ^= mask;
      007E02 EC               [12]  947 	mov	a,r4
      007E03 62 06            [12]  948 	xrl	ar6,a
      007E05 12 83 8D         [24]  949 	lcall	_ak820_outline_0187
      007E08 EE               [12]  950 	mov	a,r6
      007E09 F0               [24]  951 	movx	@dptr,a
                                    952 ;	quantum/action_util.c:104: return true;
      007E0A 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	quantum/action_util.c:105: }
      007E0D 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'change_owned'
                                    958 ;------------------------------------------------------------
                                    959 ;mode          Allocated with name '_change_owned_PARM_2'
                                    960 ;mods          Allocated with name '_change_owned_mods_10000_312'
                                    961 ;kind          Allocated with name '_change_owned_kind_10000_313'
                                    962 ;pressed       Allocated with name '_change_owned_pressed_10000_313'
                                    963 ;refs          Allocated with name '_change_owned_refs_10000_313'
                                    964 ;old           Allocated with name '_change_owned_old_30000_315'
                                    965 ;result        Allocated with name '_change_owned_result_10001_316'
                                    966 ;i             Allocated with name '_change_owned_i_20001_317'
                                    967 ;bit           Allocated with name '_change_owned_bit_20001_317'
                                    968 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    969 ;------------------------------------------------------------
                                    970 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function change_owned
                                    973 ;	-----------------------------------------
      007E0E                        974 _change_owned:
      007E0E E5 82            [12]  975 	mov	a,dpl
      007E10 90 09 8F         [24]  976 	mov	dptr,#_change_owned_mods_10000_312
      007E13 F0               [24]  977 	movx	@dptr,a
                                    978 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      007E14 90 09 8E         [24]  979 	mov	dptr,#_change_owned_PARM_2
      007E17 E0               [24]  980 	movx	a,@dptr
      007E18 FF               [12]  981 	mov	r7,a
      007E19 C3               [12]  982 	clr	c
      007E1A 13               [12]  983 	rrc	a
      007E1B FE               [12]  984 	mov	r6,a
                                    985 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      007E1C 53 07 01         [24]  986 	anl	ar7,#0x01
      007E1F EF               [12]  987 	mov	a,r7
      007E20 B4 01 00         [24]  988 	cjne	a,#0x01,00205$
      007E23                        989 00205$:
      007E23 92 23            [24]  990 	mov  _change_owned_sloc0_1_0,c
      007E25 B3               [12]  991 	cpl	c
      007E26 E4               [12]  992 	clr	a
      007E27 33               [12]  993 	rlc	a
      007E28 F5 54            [12]  994 	mov	_change_owned_sloc1_1_0,a
                                    995 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007E2A EE               [12]  996 	mov	a,r6
      007E2B 60 06            [24]  997 	jz	00121$
      007E2D 7D 7C            [12]  998 	mov	r5,#_owned_weak_refs
      007E2F 7F 09            [12]  999 	mov	r7,#(_owned_weak_refs >> 8)
      007E31 80 04            [24] 1000 	sjmp	00122$
      007E33                       1001 00121$:
      007E33 7D 74            [12] 1002 	mov	r5,#_owned_mod_refs
      007E35 7F 09            [12] 1003 	mov	r7,#(_owned_mod_refs >> 8)
      007E37                       1004 00122$:
                                   1005 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      007E37 90 09 88         [24] 1006 	mov	dptr,#_ak820_macro_primitive
      007E3A E0               [24] 1007 	movx	a,@dptr
      007E3B 60 37            [24] 1008 	jz	00102$
                                   1009 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      007E3D EE               [12] 1010 	mov	a,r6
      007E3E 24 86            [12] 1011 	add	a, #_macro_mods
      007E40 FB               [12] 1012 	mov	r3,a
      007E41 E4               [12] 1013 	clr	a
      007E42 34 09            [12] 1014 	addc	a, #(_macro_mods >> 8)
      007E44 FC               [12] 1015 	mov	r4,a
      007E45 12 49 C6         [24] 1016 	lcall	_ak820_outline_0065
                                   1017 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007E48 E5 54            [12] 1018 	mov	a,_change_owned_sloc1_1_0
      007E4A 60 0A            [24] 1019 	jz	00123$
      007E4C 90 09 8F         [24] 1020 	mov	dptr,#_change_owned_mods_10000_312
      007E4F E0               [24] 1021 	movx	a,@dptr
      007E50 F9               [12] 1022 	mov	r1,a
      007E51 EA               [12] 1023 	mov	a,r2
      007E52 42 01            [12] 1024 	orl	ar1,a
      007E54 80 07            [24] 1025 	sjmp	00124$
      007E56                       1026 00123$:
      007E56 90 09 8F         [24] 1027 	mov	dptr,#_change_owned_mods_10000_312
      007E59 E0               [24] 1028 	movx	a,@dptr
      007E5A F4               [12] 1029 	cpl	a
      007E5B 5A               [12] 1030 	anl	a,r2
      007E5C F9               [12] 1031 	mov	r1,a
      007E5D                       1032 00124$:
      007E5D 12 33 FC         [24] 1033 	lcall	_ak820_outline_0122
      007E60 E9               [12] 1034 	mov	a,r1
      007E61 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      007E62 E5 54            [12] 1037 	mov	a,_change_owned_sloc1_1_0
      007E64 60 06            [24] 1038 	jz	00125$
      007E66 74 FF            [12] 1039 	mov	a,#0xff
      007E68 6A               [12] 1040 	xrl	a,r2
      007E69 FC               [12] 1041 	mov	r4,a
      007E6A 80 02            [24] 1042 	sjmp	00126$
      007E6C                       1043 00125$:
      007E6C 8A 04            [24] 1044 	mov	ar4,r2
      007E6E                       1045 00126$:
      007E6E 90 09 8F         [24] 1046 	mov	dptr,#_change_owned_mods_10000_312
      007E71 E0               [24] 1047 	movx	a,@dptr
      007E72 5C               [12] 1048 	anl	a,r4
      007E73 F0               [24] 1049 	movx	@dptr,a
      007E74                       1050 00102$:
                                   1051 ;	quantum/action_util.c:115: uint8_t result = 0;
      007E74 90 09 90         [24] 1052 	mov	dptr,#_change_owned_result_10001_316
      007E77 E4               [12] 1053 	clr	a
      007E78 F0               [24] 1054 	movx	@dptr,a
                                   1055 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007E79 90 09 91         [24] 1056 	mov	dptr,#_change_owned_bit_20001_317
      007E7C 04               [12] 1057 	inc	a
      007E7D F0               [24] 1058 	movx	@dptr,a
      007E7E 90 09 8F         [24] 1059 	mov	dptr,#_change_owned_mods_10000_312
      007E81 E0               [24] 1060 	movx	a,@dptr
      007E82 FC               [12] 1061 	mov	r4,a
      007E83 7B 00            [12] 1062 	mov	r3,#0x00
      007E85                       1063 00117$:
      007E85 BB 08 00         [24] 1064 	cjne	r3,#0x08,00210$
      007E88                       1065 00210$:
      007E88 50 3F            [24] 1066 	jnc	00112$
                                   1067 ;	quantum/action_util.c:117: if (mods & bit) {
      007E8A 90 09 91         [24] 1068 	mov	dptr,#_change_owned_bit_20001_317
      007E8D E0               [24] 1069 	movx	a,@dptr
      007E8E 5C               [12] 1070 	anl	a,r4
      007E8F 60 1C            [24] 1071 	jz	00109$
                                   1072 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      007E91 E5 54            [12] 1073 	mov	a,_change_owned_sloc1_1_0
      007E93 60 0C            [24] 1074 	jz	00106$
      007E95 EB               [12] 1075 	mov	a,r3
      007E96 2D               [12] 1076 	add	a, r5
      007E97 12 37 D5         [24] 1077 	lcall	_ak820_outline_0014
      007E9A F8               [12] 1078 	mov	r0,a
      007E9B 08               [12] 1079 	inc	r0
      007E9C 12 83 38         [24] 1080 	lcall	_ak820_outline_0064
      007E9F 80 0C            [24] 1081 	sjmp	00109$
      007EA1                       1082 00106$:
                                   1083 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      007EA1 EB               [12] 1084 	mov	a,r3
      007EA2 2D               [12] 1085 	add	a, r5
      007EA3 12 37 D5         [24] 1086 	lcall	_ak820_outline_0014
      007EA6 F8               [12] 1087 	mov	r0,a
      007EA7 60 04            [24] 1088 	jz	00109$
      007EA9 18               [12] 1089 	dec	r0
      007EAA 12 83 38         [24] 1090 	lcall	_ak820_outline_0064
      007EAD                       1091 00109$:
                                   1092 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      007EAD EB               [12] 1093 	mov	a,r3
      007EAE 2D               [12] 1094 	add	a, r5
      007EAF 12 37 D5         [24] 1095 	lcall	_ak820_outline_0014
      007EB2 60 0B            [24] 1096 	jz	00118$
      007EB4 90 09 91         [24] 1097 	mov	dptr,#_change_owned_bit_20001_317
      007EB7 E0               [24] 1098 	movx	a,@dptr
      007EB8 FA               [12] 1099 	mov	r2,a
      007EB9 90 09 90         [24] 1100 	mov	dptr,#_change_owned_result_10001_316
      007EBC E0               [24] 1101 	movx	a,@dptr
      007EBD 4A               [12] 1102 	orl	a,r2
      007EBE F0               [24] 1103 	movx	@dptr,a
      007EBF                       1104 00118$:
                                   1105 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007EBF 0B               [12] 1106 	inc	r3
      007EC0 90 09 91         [24] 1107 	mov	dptr,#_change_owned_bit_20001_317
      007EC3 E0               [24] 1108 	movx	a,@dptr
      007EC4 25 E0            [12] 1109 	add	a,acc
      007EC6 F0               [24] 1110 	movx	@dptr,a
      007EC7 80 BC            [24] 1111 	sjmp	00117$
      007EC9                       1112 00112$:
                                   1113 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      007EC9 EE               [12] 1114 	mov	a,r6
      007ECA 60 09            [24] 1115 	jz	00114$
      007ECC 90 09 90         [24] 1116 	mov	dptr,#_change_owned_result_10001_316
      007ECF E0               [24] 1117 	movx	a,@dptr
      007ED0 90 09 85         [24] 1118 	mov	dptr,#_owned_weak_mods
      007ED3 F0               [24] 1119 	movx	@dptr,a
      007ED4 22               [24] 1120 	ret
      007ED5                       1121 00114$:
                                   1122 ;	quantum/action_util.c:124: else owned_mods = result;
      007ED5 90 09 90         [24] 1123 	mov	dptr,#_change_owned_result_10001_316
      007ED8 E0               [24] 1124 	movx	a,@dptr
      007ED9 90 09 84         [24] 1125 	mov	dptr,#_owned_mods
      007EDC F0               [24] 1126 	movx	@dptr,a
                                   1127 ;	quantum/action_util.c:125: }
      007EDD 22               [24] 1128 	ret
                                   1129 ;------------------------------------------------------------
                                   1130 ;Allocation info for local variables in function 'add_owned_mods'
                                   1131 ;------------------------------------------------------------
                                   1132 ;mods          Allocated with name '_add_owned_mods_mods_10000_325'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function add_owned_mods
                                   1137 ;	-----------------------------------------
      007EDE                       1138 _add_owned_mods:
      007EDE E5 82            [12] 1139 	mov	a,dpl
      007EE0 90 09 92         [24] 1140 	mov	dptr,#_add_owned_mods_mods_10000_325
      007EE3 12 83 58         [24] 1141 	lcall	_ak820_outline_0114
      007EE6 74 01            [12] 1142 	mov	a,#0x01
      007EE8 F0               [24] 1143 	movx	@dptr,a
      007EE9 8F 82            [24] 1144 	mov	dpl, r7
      007EEB 02 7E 0E         [24] 1145 	ljmp	_change_owned
                                   1146 ;------------------------------------------------------------
                                   1147 ;Allocation info for local variables in function 'del_owned_mods'
                                   1148 ;------------------------------------------------------------
                                   1149 ;mods          Allocated with name '_del_owned_mods_mods_10000_327'
                                   1150 ;------------------------------------------------------------
                                   1151 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1152 ;	-----------------------------------------
                                   1153 ;	 function del_owned_mods
                                   1154 ;	-----------------------------------------
      007EEE                       1155 _del_owned_mods:
      007EEE E5 82            [12] 1156 	mov	a,dpl
      007EF0 90 09 93         [24] 1157 	mov	dptr,#_del_owned_mods_mods_10000_327
      007EF3 12 83 58         [24] 1158 	lcall	_ak820_outline_0114
      007EF6 E4               [12] 1159 	clr	a
      007EF7 F0               [24] 1160 	movx	@dptr,a
      007EF8 8F 82            [24] 1161 	mov	dpl, r7
      007EFA 02 7E 0E         [24] 1162 	ljmp	_change_owned
                                   1163 ;------------------------------------------------------------
                                   1164 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1165 ;------------------------------------------------------------
                                   1166 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_329'
                                   1167 ;------------------------------------------------------------
                                   1168 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1169 ;	-----------------------------------------
                                   1170 ;	 function add_owned_weak_mods
                                   1171 ;	-----------------------------------------
      007EFD                       1172 _add_owned_weak_mods:
      007EFD E5 82            [12] 1173 	mov	a,dpl
      007EFF 90 09 94         [24] 1174 	mov	dptr,#_add_owned_weak_mods_mods_10000_329
      007F02 12 83 58         [24] 1175 	lcall	_ak820_outline_0114
      007F05 74 03            [12] 1176 	mov	a,#0x03
      007F07 F0               [24] 1177 	movx	@dptr,a
      007F08 8F 82            [24] 1178 	mov	dpl, r7
      007F0A 02 7E 0E         [24] 1179 	ljmp	_change_owned
                                   1180 ;------------------------------------------------------------
                                   1181 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1182 ;------------------------------------------------------------
                                   1183 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_331'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function del_owned_weak_mods
                                   1188 ;	-----------------------------------------
      007F0D                       1189 _del_owned_weak_mods:
      007F0D E5 82            [12] 1190 	mov	a,dpl
      007F0F 90 09 95         [24] 1191 	mov	dptr,#_del_owned_weak_mods_mods_10000_331
      007F12 12 83 58         [24] 1192 	lcall	_ak820_outline_0114
      007F15 74 02            [12] 1193 	mov	a,#0x02
      007F17 F0               [24] 1194 	movx	@dptr,a
      007F18 8F 82            [24] 1195 	mov	dpl, r7
      007F1A 02 7E 0E         [24] 1196 	ljmp	_change_owned
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1199 ;------------------------------------------------------------
                                   1200 ;i             Allocated with name '_clear_owned_mods_i_20000_335'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function clear_owned_mods
                                   1205 ;	-----------------------------------------
      007F1D                       1206 _clear_owned_mods:
                                   1207 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007F1D 7F 00            [12] 1208 	mov	r7,#0x00
      007F1F                       1209 00103$:
      007F1F BF 08 00         [24] 1210 	cjne	r7,#0x08,00122$
      007F22                       1211 00122$:
      007F22 50 1A            [24] 1212 	jnc	00101$
      007F24 EF               [12] 1213 	mov	a,r7
      007F25 24 74            [12] 1214 	add	a, #_owned_mod_refs
      007F27 FD               [12] 1215 	mov	r5,a
      007F28 E4               [12] 1216 	clr	a
      007F29 34 09            [12] 1217 	addc	a, #(_owned_mod_refs >> 8)
      007F2B FE               [12] 1218 	mov	r6,a
      007F2C EF               [12] 1219 	mov	a,r7
      007F2D 24 7C            [12] 1220 	add	a, #_owned_weak_refs
      007F2F F5 82            [12] 1221 	mov	dpl,a
      007F31 E4               [12] 1222 	clr	a
      007F32 34 09            [12] 1223 	addc	a, #(_owned_weak_refs >> 8)
      007F34 F5 83            [12] 1224 	mov	dph,a
      007F36 E4               [12] 1225 	clr	a
      007F37 F0               [24] 1226 	movx	@dptr,a
      007F38 12 83 5F         [24] 1227 	lcall	_ak820_outline_0119
      007F3B 0F               [12] 1228 	inc	r7
      007F3C 80 E1            [24] 1229 	sjmp	00103$
      007F3E                       1230 00101$:
                                   1231 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007F3E 90 09 87         [24] 1232 	mov	dptr,#(_macro_mods + 0x0001)
      007F41 E4               [12] 1233 	clr	a
      007F42 F0               [24] 1234 	movx	@dptr,a
      007F43 90 09 86         [24] 1235 	mov	dptr,#_macro_mods
      007F46 F0               [24] 1236 	movx	@dptr,a
      007F47 90 09 85         [24] 1237 	mov	dptr,#_owned_weak_mods
      007F4A F0               [24] 1238 	movx	@dptr,a
      007F4B 90 09 84         [24] 1239 	mov	dptr,#_owned_mods
      007F4E F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      007F4F 90 09 89         [24] 1242 	mov	dptr,#_ak820_macro_cancelled
      007F52 04               [12] 1243 	inc	a
      007F53 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:134: }
      007F54 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1249 ;------------------------------------------------------------
                                   1250 ;i             Allocated with name '_clear_owned_keys_i_20000_338'
                                   1251 ;i             Allocated with name '_clear_owned_keys_i_20000_339'
                                   1252 ;------------------------------------------------------------
                                   1253 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1254 ;	-----------------------------------------
                                   1255 ;	 function clear_owned_keys
                                   1256 ;	-----------------------------------------
      007F55                       1257 _clear_owned_keys:
                                   1258 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007F55 7F 00            [12] 1259 	mov	r7,#0x00
      007F57                       1260 00104$:
      007F57 EF               [12] 1261 	mov	a,r7
      007F58 24 5B            [12] 1262 	add	a,#0xff - 0xa4
      007F5A 40 0D            [24] 1263 	jc	00101$
                                   1264 ;	free result
      007F5C EF               [12] 1265 	mov	a,r7
      007F5D 24 96            [12] 1266 	add	a, #_key_refs
      007F5F F5 82            [12] 1267 	mov	dpl,a
      007F61 E4               [12] 1268 	clr	a
      007F62 34 09            [12] 1269 	addc	a, #(_key_refs >> 8)
      007F64 12 7C CA         [24] 1270 	lcall	_ak820_outline_0158
      007F67 80 EE            [24] 1271 	sjmp	00104$
      007F69                       1272 00101$:
                                   1273 ;	quantum/action_util.c:142: distinct_keys = 0;
      007F69 90 0A 3B         [24] 1274 	mov	dptr,#_distinct_keys
      007F6C E4               [12] 1275 	clr	a
      007F6D F0               [24] 1276 	movx	@dptr,a
                                   1277 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007F6E FF               [12] 1278 	mov	r7,a
      007F6F                       1279 00107$:
      007F6F BF 15 00         [24] 1280 	cjne	r7,#0x15,00142$
      007F72                       1281 00142$:
      007F72 50 0D            [24] 1282 	jnc	00109$
      007F74 EF               [12] 1283 	mov	a,r7
      007F75 24 3C            [12] 1284 	add	a, #_macro_keys
      007F77 F5 82            [12] 1285 	mov	dpl,a
      007F79 E4               [12] 1286 	clr	a
      007F7A 34 0A            [12] 1287 	addc	a, #(_macro_keys >> 8)
      007F7C 12 7C CA         [24] 1288 	lcall	_ak820_outline_0158
      007F7F 80 EE            [24] 1289 	sjmp	00107$
      007F81                       1290 00109$:
                                   1291 ;	quantum/action_util.c:144: }
      007F81 22               [24] 1292 	ret
                                   1293 ;------------------------------------------------------------
                                   1294 ;Allocation info for local variables in function 'add_owned_key'
                                   1295 ;------------------------------------------------------------
                                   1296 ;code          Allocated with name '_add_owned_key_code_10000_340'
                                   1297 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_349'
                                   1298 ;key           Allocated with name '_add_owned_key_key_50000_350'
                                   1299 ;i             Allocated with name '_add_owned_key_i_40000_348'
                                   1300 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_352'
                                   1301 ;key           Allocated with name '_add_owned_key_key_40000_353'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function add_owned_key
                                   1306 ;	-----------------------------------------
      007F82                       1307 _add_owned_key:
      007F82 E5 82            [12] 1308 	mov	a,dpl
      007F84 90 0A 51         [24] 1309 	mov	dptr,#_add_owned_key_code_10000_340
      007F87 12 83 70         [24] 1310 	lcall	_ak820_outline_0130
                                   1311 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007F8A 74 01            [12] 1312 	mov	a,#0x01
      007F8C F0               [24] 1313 	movx	@dptr,a
      007F8D 90 0A 3C         [24] 1314 	mov	dptr,#_macro_keys
      007F90 C0 07            [24] 1315 	push	ar7
      007F92 12 7D A2         [24] 1316 	lcall	_ak820_macro_change
      007F95 E5 82            [12] 1317 	mov	a, dpl
      007F97 D0 07            [24] 1318 	pop	ar7
      007F99 70 03            [24] 1319 	jnz	00102$
      007F9B F5 82            [12] 1320 	mov	dpl,a
      007F9D 22               [24] 1321 	ret
      007F9E                       1322 00102$:
                                   1323 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      007F9E 12 83 2A         [24] 1324 	lcall	_ak820_outline_0029
      007FA1 FC               [12] 1325 	mov	r4,a
      007FA2 04               [12] 1326 	inc	a
      007FA3 12 83 5F         [24] 1327 	lcall	_ak820_outline_0119
      007FA6 EC               [12] 1328 	mov	a,r4
      007FA7 60 04            [24] 1329 	jz	00104$
      007FA9 75 82 00         [24] 1330 	mov	dpl, #0x00
      007FAC 22               [24] 1331 	ret
      007FAD                       1332 00104$:
                                   1333 ;	quantum/action_util.c:148: ++distinct_keys;
      007FAD 90 0A 3B         [24] 1334 	mov	dptr,#_distinct_keys
      007FB0 E0               [24] 1335 	movx	a,@dptr
      007FB1 24 01            [12] 1336 	add	a, #0x01
      007FB3 F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007FB4 90 0D 8E         [24] 1339 	mov	dptr,#_keyboard_protocol
      007FB7 E0               [24] 1340 	movx	a,@dptr
      007FB8 60 11            [24] 1341 	jz	00106$
      007FBA 90 0A C0         [24] 1342 	mov	dptr,#_keymap_config
      007FBD E0               [24] 1343 	movx	a,@dptr
      007FBE 30 E7 0A         [24] 1344 	jnb	acc.7,00106$
                                   1345 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007FC1 12 83 84         [24] 1346 	lcall	_ak820_outline_0173
      007FC4 12 70 AB         [24] 1347 	lcall	_add_key_to_report
                                   1348 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007FC7 75 82 01         [24] 1349 	mov	dpl, #0x01
      007FCA 22               [24] 1350 	ret
      007FCB                       1351 00106$:
                                   1352 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007FCB 90 0A 3B         [24] 1353 	mov	dptr,#_distinct_keys
      007FCE E0               [24] 1354 	movx	a,@dptr
      007FCF 24 F9            [12] 1355 	add	a,#0xff - 0x06
      007FD1 50 17            [24] 1356 	jnc	00110$
                                   1357 ;	free result
                                   1358 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007FD3 7F 00            [12] 1359 	mov	r7,#0x00
      007FD5                       1360 00115$:
      007FD5 BF 06 00         [24] 1361 	cjne	r7,#0x06,00174$
      007FD8                       1362 00174$:
      007FD8 50 1E            [24] 1363 	jnc	00111$
      007FDA EF               [12] 1364 	mov	a,r7
      007FDB 24 A3            [12] 1365 	add	a, #(_actual_keyboard_report + 0x0002)
      007FDD F5 82            [12] 1366 	mov	dpl,a
      007FDF E4               [12] 1367 	clr	a
      007FE0 34 0D            [12] 1368 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007FE2 F5 83            [12] 1369 	mov	dph,a
      007FE4 74 01            [12] 1370 	mov	a,#0x01
      007FE6 F0               [24] 1371 	movx	@dptr,a
      007FE7 0F               [12] 1372 	inc	r7
      007FE8 80 EB            [24] 1373 	sjmp	00115$
      007FEA                       1374 00110$:
                                   1375 ;	quantum/action_util.c:154: } else add_key(code);
      007FEA 90 0A 51         [24] 1376 	mov	dptr,#_add_owned_key_code_10000_340
      007FED E0               [24] 1377 	movx	a,@dptr
                                   1378 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007FEE 90 08 04         [24] 1379 	mov	dptr,#_add_key_to_report_PARM_2
      007FF1 F0               [24] 1380 	movx	@dptr,a
      007FF2 90 0D A1         [24] 1381 	mov	dptr,#_actual_keyboard_report
      007FF5 12 70 AB         [24] 1382 	lcall	_add_key_to_report
                                   1383 ;	quantum/action_util.c:154: } else add_key(code);
      007FF8                       1384 00111$:
                                   1385 ;	quantum/action_util.c:155: return true;
      007FF8 75 82 01         [24] 1386 	mov	dpl, #0x01
                                   1387 ;	quantum/action_util.c:156: }
      007FFB 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'del_owned_key'
                                   1391 ;------------------------------------------------------------
                                   1392 ;code          Allocated with name '_del_owned_key_code_10000_355'
                                   1393 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_366'
                                   1394 ;key           Allocated with name '_del_owned_key_key_50000_367'
                                   1395 ;key           Allocated with name '_del_owned_key_key_40000_364'
                                   1396 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_372'
                                   1397 ;key           Allocated with name '_del_owned_key_key_70000_373'
                                   1398 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_375'
                                   1399 ;key           Allocated with name '_del_owned_key_key_40000_376'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function del_owned_key
                                   1404 ;	-----------------------------------------
      007FFC                       1405 _del_owned_key:
      007FFC E5 82            [12] 1406 	mov	a,dpl
      007FFE 90 0A 52         [24] 1407 	mov	dptr,#_del_owned_key_code_10000_355
      008001 12 83 70         [24] 1408 	lcall	_ak820_outline_0130
                                   1409 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008004 E4               [12] 1410 	clr	a
      008005 F0               [24] 1411 	movx	@dptr,a
      008006 90 0A 3C         [24] 1412 	mov	dptr,#_macro_keys
      008009 C0 07            [24] 1413 	push	ar7
      00800B 12 7D A2         [24] 1414 	lcall	_ak820_macro_change
      00800E E5 82            [12] 1415 	mov	a, dpl
      008010 D0 07            [24] 1416 	pop	ar7
      008012 70 03            [24] 1417 	jnz	00102$
      008014 F5 82            [12] 1418 	mov	dpl,a
      008016 22               [24] 1419 	ret
      008017                       1420 00102$:
                                   1421 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      008017 12 83 2A         [24] 1422 	lcall	_ak820_outline_0029
      00801A FC               [12] 1423 	mov	r4,a
      00801B 60 09            [24] 1424 	jz	00103$
      00801D 1C               [12] 1425 	dec	r4
      00801E 12 38 6A         [24] 1426 	lcall	_ak820_outline_0131
      008021 EC               [12] 1427 	mov	a,r4
      008022 F0               [24] 1428 	movx	@dptr,a
      008023 EC               [12] 1429 	mov	a,r4
      008024 60 04            [24] 1430 	jz	00104$
      008026                       1431 00103$:
      008026 75 82 00         [24] 1432 	mov	dpl, #0x00
      008029 22               [24] 1433 	ret
      00802A                       1434 00104$:
                                   1435 ;	quantum/action_util.c:160: --distinct_keys;
      00802A 90 0A 3B         [24] 1436 	mov	dptr,#_distinct_keys
      00802D E0               [24] 1437 	movx	a,@dptr
      00802E 14               [12] 1438 	dec	a
      00802F F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008030 90 0D 8E         [24] 1441 	mov	dptr,#_keyboard_protocol
      008033 E0               [24] 1442 	movx	a,@dptr
      008034 60 16            [24] 1443 	jz	00107$
      008036 90 0A C0         [24] 1444 	mov	dptr,#_keymap_config
      008039 E0               [24] 1445 	movx	a,@dptr
      00803A 30 E7 0F         [24] 1446 	jnb	acc.7,00107$
                                   1447 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00803D 90 08 07         [24] 1448 	mov	dptr,#_del_key_from_report_PARM_2
      008040 EF               [12] 1449 	mov	a,r7
      008041 F0               [24] 1450 	movx	@dptr,a
      008042 90 0D A1         [24] 1451 	mov	dptr,#_actual_keyboard_report
      008045 12 70 E1         [24] 1452 	lcall	_del_key_from_report
                                   1453 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008048 75 82 01         [24] 1454 	mov	dpl, #0x01
      00804B 22               [24] 1455 	ret
      00804C                       1456 00107$:
                                   1457 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00804C 90 0A 3B         [24] 1458 	mov	dptr,#_distinct_keys
      00804F E0               [24] 1459 	movx	a,@dptr
      008050 FF               [12] 1460 	mov  r7,a
      008051 24 F9            [12] 1461 	add	a,#0xff - 0x06
      008053 50 04            [24] 1462 	jnc	00110$
                                   1463 ;	free result
      008055 75 82 01         [24] 1464 	mov	dpl, #0x01
      008058 22               [24] 1465 	ret
      008059                       1466 00110$:
                                   1467 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008059 BF 06 1F         [24] 1468 	cjne	r7,#0x06,00115$
                                   1469 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00805C 90 0D A1         [24] 1470 	mov	dptr,#_actual_keyboard_report
      00805F 12 71 17         [24] 1471 	lcall	_clear_keys_from_report
                                   1472 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008062 7F 04            [12] 1473 	mov	r7,#0x04
      008064                       1474 00122$:
      008064 EF               [12] 1475 	mov	a,r7
      008065 24 5B            [12] 1476 	add	a,#0xff - 0xa4
      008067 40 20            [24] 1477 	jc	00116$
                                   1478 ;	free result
      008069 12 83 2A         [24] 1479 	lcall	_ak820_outline_0029
      00806C 60 0A            [24] 1480 	jz	00123$
                                   1481 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00806E 12 83 84         [24] 1482 	lcall	_ak820_outline_0173
      008071 C0 07            [24] 1483 	push	ar7
      008073 12 70 AB         [24] 1484 	lcall	_add_key_to_report
      008076 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008078                       1487 00123$:
      008078 0F               [12] 1488 	inc	r7
      008079 80 E9            [24] 1489 	sjmp	00122$
      00807B                       1490 00115$:
                                   1491 ;	quantum/action_util.c:169: } else del_key(code);
      00807B 90 0A 52         [24] 1492 	mov	dptr,#_del_owned_key_code_10000_355
      00807E E0               [24] 1493 	movx	a,@dptr
                                   1494 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00807F 90 08 07         [24] 1495 	mov	dptr,#_del_key_from_report_PARM_2
      008082 F0               [24] 1496 	movx	@dptr,a
      008083 90 0D A1         [24] 1497 	mov	dptr,#_actual_keyboard_report
      008086 12 70 E1         [24] 1498 	lcall	_del_key_from_report
                                   1499 ;	quantum/action_util.c:169: } else del_key(code);
      008089                       1500 00116$:
                                   1501 ;	quantum/action_util.c:170: return true;
      008089 75 82 01         [24] 1502 	mov	dpl, #0x01
                                   1503 ;	quantum/action_util.c:171: }
      00808C 22               [24] 1504 	ret
                                   1505 ;------------------------------------------------------------
                                   1506 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1507 ;------------------------------------------------------------
                                   1508 ;i             Allocated with name '_clear_owned_usages_i_20000_380'
                                   1509 ;i             Allocated with name '_clear_owned_usages_i_20000_381'
                                   1510 ;------------------------------------------------------------
                                   1511 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1512 ;	-----------------------------------------
                                   1513 ;	 function clear_owned_usages
                                   1514 ;	-----------------------------------------
      00808D                       1515 _clear_owned_usages:
                                   1516 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      00808D 7F 00            [12] 1517 	mov	r7,#0x00
      00808F                       1518 00104$:
      00808F BF 1E 00         [24] 1519 	cjne	r7,#0x1e,00141$
      008092                       1520 00141$:
      008092 50 14            [24] 1521 	jnc	00101$
      008094 EF               [12] 1522 	mov	a,r7
      008095 24 53            [12] 1523 	add	a, #_usage_refs
      008097 FD               [12] 1524 	mov	r5,a
      008098 E4               [12] 1525 	clr	a
      008099 34 0A            [12] 1526 	addc	a, #(_usage_refs >> 8)
      00809B FE               [12] 1527 	mov	r6,a
      00809C EF               [12] 1528 	mov	a,r7
      00809D 12 83 3F         [24] 1529 	lcall	_ak820_outline_0068
      0080A0 E4               [12] 1530 	clr	a
      0080A1 F0               [24] 1531 	movx	@dptr,a
      0080A2 12 83 5F         [24] 1532 	lcall	_ak820_outline_0119
      0080A5 0F               [12] 1533 	inc	r7
      0080A6 80 E7            [24] 1534 	sjmp	00104$
      0080A8                       1535 00101$:
                                   1536 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      0080A8 90 0A 90         [24] 1537 	mov	dptr,#(_usage_lengths + 0x0001)
      0080AB E4               [12] 1538 	clr	a
      0080AC F0               [24] 1539 	movx	@dptr,a
      0080AD 90 0A 8F         [24] 1540 	mov	dptr,#_usage_lengths
      0080B0 F0               [24] 1541 	movx	@dptr,a
                                   1542 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0080B1 FF               [12] 1543 	mov	r7,a
      0080B2                       1544 00107$:
      0080B2 BF 04 00         [24] 1545 	cjne	r7,#0x04,00143$
      0080B5                       1546 00143$:
      0080B5 50 0D            [24] 1547 	jnc	00109$
      0080B7 EF               [12] 1548 	mov	a,r7
      0080B8 24 91            [12] 1549 	add	a, #_macro_usages
      0080BA F5 82            [12] 1550 	mov	dpl,a
      0080BC E4               [12] 1551 	clr	a
      0080BD 34 0A            [12] 1552 	addc	a, #(_macro_usages >> 8)
      0080BF 12 7C CA         [24] 1553 	lcall	_ak820_outline_0158
      0080C2 80 EE            [24] 1554 	sjmp	00107$
      0080C4                       1555 00109$:
                                   1556 ;	quantum/action_util.c:185: }
      0080C4 22               [24] 1557 	ret
                                   1558 ;------------------------------------------------------------
                                   1559 ;Allocation info for local variables in function 'owned_usage_key'
                                   1560 ;------------------------------------------------------------
                                   1561 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1562 ;code          Allocated with name '_owned_usage_key_code_10000_382'
                                   1563 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_383'
                                   1564 ;which         Allocated with name '_owned_usage_key_which_10000_383'
                                   1565 ;base          Allocated with name '_owned_usage_key_base_10000_383'
                                   1566 ;count         Allocated with name '_owned_usage_key_count_10000_383'
                                   1567 ;index         Allocated with name '_owned_usage_key_index_10000_383'
                                   1568 ;pos           Allocated with name '_owned_usage_key_pos_30001_390'
                                   1569 ;i             Allocated with name '_owned_usage_key_i_40001_391'
                                   1570 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_394'
                                   1571 ;key           Allocated with name '_owned_usage_key_key_40000_395'
                                   1572 ;------------------------------------------------------------
                                   1573 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1574 ;	-----------------------------------------
                                   1575 ;	 function owned_usage_key
                                   1576 ;	-----------------------------------------
      0080C5                       1577 _owned_usage_key:
      0080C5 E5 82            [12] 1578 	mov	a,dpl
      0080C7 90 0A 96         [24] 1579 	mov	dptr,#_owned_usage_key_code_10000_382
      0080CA F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      0080CB E0               [24] 1582 	movx	a,@dptr
      0080CC FF               [12] 1583 	mov	r7,a
      0080CD BF A8 00         [24] 1584 	cjne	r7,#0xa8,00244$
      0080D0                       1585 00244$:
      0080D0 B3               [12] 1586 	cpl	c
      0080D1 92 24            [24] 1587 	mov	_owned_usage_key_sloc0_1_0,c
      0080D3 E4               [12] 1588 	clr	a
      0080D4 33               [12] 1589 	rlc	a
      0080D5 FF               [12] 1590 	mov	r7,a
      0080D6 90 0A 99         [24] 1591 	mov	dptr,#_owned_usage_key_which_10000_383
      0080D9 F0               [24] 1592 	movx	@dptr,a
                                   1593 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      0080DA EF               [12] 1594 	mov	a,r7
      0080DB 60 02            [24] 1595 	jz	00129$
      0080DD 74 03            [12] 1596 	mov	a,#0x03
      0080DF                       1597 00129$:
      0080DF FE               [12] 1598 	mov	r6,a
                                   1599 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      0080E0 EF               [12] 1600 	mov	a,r7
      0080E1 24 8F            [12] 1601 	add	a, #_usage_lengths
      0080E3 FD               [12] 1602 	mov	r5,a
      0080E4 E4               [12] 1603 	clr	a
      0080E5 34 0A            [12] 1604 	addc	a, #(_usage_lengths >> 8)
      0080E7 FF               [12] 1605 	mov	r7,a
      0080E8 12 83 8D         [24] 1606 	lcall	_ak820_outline_0187
      0080EB E0               [24] 1607 	movx	a,@dptr
      0080EC FC               [12] 1608 	mov	r4,a
                                   1609 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      0080ED 90 0A 96         [24] 1610 	mov	dptr,#_owned_usage_key_code_10000_382
      0080F0 E0               [24] 1611 	movx	a,@dptr
      0080F1 24 5B            [12] 1612 	add	a,#0x5b
      0080F3 FB               [12] 1613 	mov	r3,a
                                   1614 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0080F4 90 0A 95         [24] 1615 	mov	dptr,#_owned_usage_key_PARM_2
      0080F7 E0               [24] 1616 	movx	a,@dptr
      0080F8 FA               [12] 1617 	mov	r2,a
      0080F9 90 09 8A         [24] 1618 	mov	dptr,#_ak820_macro_change_PARM_2
      0080FC EB               [12] 1619 	mov	a,r3
      0080FD F0               [24] 1620 	movx	@dptr,a
      0080FE 90 09 8B         [24] 1621 	mov	dptr,#_ak820_macro_change_PARM_3
      008101 EA               [12] 1622 	mov	a,r2
      008102 F0               [24] 1623 	movx	@dptr,a
      008103 90 0A 91         [24] 1624 	mov	dptr,#_macro_usages
      008106 C0 07            [24] 1625 	push	ar7
      008108 C0 06            [24] 1626 	push	ar6
      00810A C0 05            [24] 1627 	push	ar5
      00810C C0 04            [24] 1628 	push	ar4
      00810E C0 03            [24] 1629 	push	ar3
      008110 C0 02            [24] 1630 	push	ar2
      008112 12 7D A2         [24] 1631 	lcall	_ak820_macro_change
      008115 E5 82            [12] 1632 	mov	a, dpl
      008117 D0 02            [24] 1633 	pop	ar2
      008119 D0 03            [24] 1634 	pop	ar3
      00811B D0 04            [24] 1635 	pop	ar4
      00811D D0 05            [24] 1636 	pop	ar5
      00811F D0 06            [24] 1637 	pop	ar6
      008121 D0 07            [24] 1638 	pop	ar7
      008123 70 01            [24] 1639 	jnz	00102$
      008125 22               [24] 1640 	ret
      008126                       1641 00102$:
                                   1642 ;	quantum/action_util.c:192: if (pressed) {
      008126 EA               [12] 1643 	mov	a,r2
      008127 60 1B            [24] 1644 	jz	00115$
                                   1645 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      008129 12 83 49         [24] 1646 	lcall	_ak820_outline_0074
      00812C 04               [12] 1647 	inc	a
      00812D 12 6E 2F         [24] 1648 	lcall	_ak820_outline_0136
      008130 E8               [12] 1649 	mov	a,r0
      008131 60 01            [24] 1650 	jz	00104$
      008133 22               [24] 1651 	ret
      008134                       1652 00104$:
                                   1653 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      008134 90 0A 9A         [24] 1654 	mov	dptr,#_owned_usage_key_count_10000_383
      008137 EC               [12] 1655 	mov	a,r4
      008138 04               [12] 1656 	inc	a
      008139 F0               [24] 1657 	movx	@dptr,a
      00813A EC               [12] 1658 	mov	a,r4
      00813B 2E               [12] 1659 	add	a, r6
      00813C 12 83 3F         [24] 1660 	lcall	_ak820_outline_0068
      00813F EB               [12] 1661 	mov	a,r3
      008140 F0               [24] 1662 	movx	@dptr,a
      008141 02 81 A5         [24] 1663 	ljmp	00116$
      008144                       1664 00115$:
                                   1665 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      008144 12 83 49         [24] 1666 	lcall	_ak820_outline_0074
      008147 60 07            [24] 1667 	jz	00105$
      008149 18               [12] 1668 	dec	r0
      00814A 12 83 38         [24] 1669 	lcall	_ak820_outline_0064
      00814D E8               [12] 1670 	mov	a,r0
      00814E 60 01            [24] 1671 	jz	00106$
      008150                       1672 00105$:
      008150 22               [24] 1673 	ret
      008151                       1674 00106$:
                                   1675 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      008151 7A 00            [12] 1676 	mov	r2,#0x00
      008153                       1677 00108$:
      008153 EA               [12] 1678 	mov	a,r2
      008154 2E               [12] 1679 	add	a, r6
      008155 12 83 3F         [24] 1680 	lcall	_ak820_outline_0068
      008158 E0               [24] 1681 	movx	a,@dptr
      008159 B5 03 02         [24] 1682 	cjne	a,ar3,00251$
      00815C 80 03            [24] 1683 	sjmp	00167$
      00815E                       1684 00251$:
      00815E 0A               [12] 1685 	inc	r2
      00815F 80 F2            [24] 1686 	sjmp	00108$
      008161                       1687 00167$:
      008161 90 0A 9B         [24] 1688 	mov	dptr,#_owned_usage_key_pos_30001_390
      008164 EA               [12] 1689 	mov	a,r2
      008165 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:199: --count;
      008166 1C               [12] 1692 	dec	r4
      008167 90 0A 9A         [24] 1693 	mov	dptr,#_owned_usage_key_count_10000_383
      00816A EC               [12] 1694 	mov	a,r4
      00816B F0               [24] 1695 	movx	@dptr,a
                                   1696 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00816C 8A 03            [24] 1697 	mov	ar3,r2
      00816E                       1698 00125$:
      00816E C3               [12] 1699 	clr	c
      00816F EB               [12] 1700 	mov	a,r3
      008170 9C               [12] 1701 	subb	a,r4
      008171 50 23            [24] 1702 	jnc	00111$
      008173 C0 05            [24] 1703 	push	ar5
      008175 C0 07            [24] 1704 	push	ar7
      008177 EB               [12] 1705 	mov	a,r3
      008178 2E               [12] 1706 	add	a, r6
      008179 FA               [12] 1707 	mov	r2,a
      00817A 24 71            [12] 1708 	add	a, #_usage_order
      00817C F8               [12] 1709 	mov	r0,a
      00817D E4               [12] 1710 	clr	a
      00817E 34 0A            [12] 1711 	addc	a, #(_usage_order >> 8)
      008180 F9               [12] 1712 	mov	r1,a
      008181 0A               [12] 1713 	inc	r2
      008182 EA               [12] 1714 	mov	a,r2
      008183 33               [12] 1715 	rlc	a
      008184 95 E0            [12] 1716 	subb	a,acc
      008186 FF               [12] 1717 	mov	r7,a
      008187 EA               [12] 1718 	mov	a,r2
      008188 12 83 65         [24] 1719 	lcall	_ak820_outline_0124
      00818B 12 38 75         [24] 1720 	lcall	_ak820_outline_0152
      00818E F0               [24] 1721 	movx	@dptr,a
      00818F 0B               [12] 1722 	inc	r3
      008190 D0 07            [24] 1723 	pop	ar7
      008192 D0 05            [24] 1724 	pop	ar5
      008194 80 D8            [24] 1725 	sjmp	00125$
      008196                       1726 00111$:
                                   1727 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      008196 12 83 8D         [24] 1728 	lcall	_ak820_outline_0187
      008199 EC               [12] 1729 	mov	a,r4
      00819A F0               [24] 1730 	movx	@dptr,a
                                   1731 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      00819B 90 0A 9B         [24] 1732 	mov	dptr,#_owned_usage_key_pos_30001_390
      00819E E0               [24] 1733 	movx	a,@dptr
      00819F B5 04 02         [24] 1734 	cjne	a,ar4,00253$
      0081A2 80 01            [24] 1735 	sjmp	00116$
      0081A4                       1736 00253$:
      0081A4 22               [24] 1737 	ret
      0081A5                       1738 00116$:
                                   1739 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      0081A5 90 0A 9A         [24] 1740 	mov	dptr,#_owned_usage_key_count_10000_383
      0081A8 E0               [24] 1741 	movx	a,@dptr
      0081A9 FC               [12] 1742 	mov	r4,a
      0081AA 12 83 8D         [24] 1743 	lcall	_ak820_outline_0187
      0081AD F0               [24] 1744 	movx	@dptr,a
                                   1745 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0081AE EC               [12] 1746 	mov	a,r4
      0081AF 60 15            [24] 1747 	jz	00131$
      0081B1 EC               [12] 1748 	mov	a,r4
      0081B2 2E               [12] 1749 	add	a, r6
      0081B3 FE               [12] 1750 	mov	r6,a
      0081B4 1E               [12] 1751 	dec	r6
      0081B5 EE               [12] 1752 	mov	a,r6
      0081B6 33               [12] 1753 	rlc	a
      0081B7 95 E0            [12] 1754 	subb	a,acc
      0081B9 FF               [12] 1755 	mov	r7,a
      0081BA EE               [12] 1756 	mov	a,r6
      0081BB 12 83 65         [24] 1757 	lcall	_ak820_outline_0124
      0081BE 24 A5            [12] 1758 	add	a,#0xa5
      0081C0 FE               [12] 1759 	mov	r6,a
      0081C1 33               [12] 1760 	rlc	a
      0081C2 95 E0            [12] 1761 	subb	a,acc
      0081C4 80 02            [24] 1762 	sjmp	00132$
      0081C6                       1763 00131$:
      0081C6 7E 00            [12] 1764 	mov	r6,#0x00
      0081C8                       1765 00132$:
      0081C8 90 0A 96         [24] 1766 	mov	dptr,#_owned_usage_key_code_10000_382
      0081CB EE               [12] 1767 	mov	a,r6
      0081CC F0               [24] 1768 	movx	@dptr,a
                                   1769 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0081CD 90 0A 99         [24] 1770 	mov	dptr,#_owned_usage_key_which_10000_383
      0081D0 E0               [24] 1771 	movx	a,@dptr
      0081D1 60 18            [24] 1772 	jz	00118$
      0081D3 EE               [12] 1773 	mov	a,r6
      0081D4 60 0B            [24] 1774 	jz	00133$
      0081D6 8E 82            [24] 1775 	mov	dpl, r6
      0081D8 12 6F 68         [24] 1776 	lcall	_KEYCODE2CONSUMER
      0081DB AD 82            [24] 1777 	mov	r5, dpl
      0081DD AF 83            [24] 1778 	mov	r7, dph
      0081DF 80 04            [24] 1779 	sjmp	00134$
      0081E1                       1780 00133$:
      0081E1 7D 00            [12] 1781 	mov	r5,#0x00
      0081E3 7F 00            [12] 1782 	mov	r7,#0x00
      0081E5                       1783 00134$:
      0081E5 12 83 8D         [24] 1784 	lcall	_ak820_outline_0187
      0081E8 02 6F 22         [24] 1785 	ljmp	_host_consumer_send
      0081EB                       1786 00118$:
                                   1787 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0081EB EE               [12] 1788 	mov	a,r6
      0081EC 60 22            [24] 1789 	jz	00135$
                                   1790 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0081EE BE A5 00         [24] 1791 	cjne	r6,#0xa5,00258$
      0081F1                       1792 00258$:
      0081F1 40 05            [24] 1793 	jc	00121$
      0081F3 EE               [12] 1794 	mov	a,r6
      0081F4 24 58            [12] 1795 	add	a,#0xff - 0xa7
      0081F6 50 08            [24] 1796 	jnc	00122$
                                   1797 ;	free result
      0081F8                       1798 00121$:
      0081F8 90 0A 97         [24] 1799 	mov	dptr,#_owned_usage_key___200000085_20000_383
      0081FB 12 50 65         [24] 1800 	lcall	_ak820_outline_0180
      0081FE 80 09            [24] 1801 	sjmp	00123$
      008200                       1802 00122$:
                                   1803 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008200 74 DC            [12] 1804 	mov	a,#0xdc
      008202 2E               [12] 1805 	add	a, r6
      008203 90 0A 97         [24] 1806 	mov	dptr,#_owned_usage_key___200000085_20000_383
      008206 12 38 65         [24] 1807 	lcall	_ak820_outline_0123
                                   1808 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008209                       1809 00123$:
      008209 90 0A 97         [24] 1810 	mov	dptr,#_owned_usage_key___200000085_20000_383
      00820C E0               [24] 1811 	movx	a,@dptr
      00820D FF               [12] 1812 	mov	r7,a
      00820E 80 02            [24] 1813 	sjmp	00136$
      008210                       1814 00135$:
      008210 7F 00            [12] 1815 	mov	r7,#0x00
      008212                       1816 00136$:
      008212 7E 00            [12] 1817 	mov	r6,#0x00
      008214 12 43 B3         [24] 1818 	lcall	_ak820_outline_0153
                                   1819 ;	quantum/action_util.c:208: }
      008217 02 6E F2         [24] 1820 	ljmp	_host_system_send
                                   1821 ;------------------------------------------------------------
                                   1822 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1823 ;------------------------------------------------------------
                                   1824 ;mods          Allocated with name '_send_keyboard_report_mods_30000_403'
                                   1825 ;mods          Allocated with name '_send_keyboard_report_mods_30000_405'
                                   1826 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_407'
                                   1827 ;changed       Allocated with name '_send_keyboard_report_changed_10001_407'
                                   1828 ;dest          Allocated with name '_send_keyboard_report_dest_10001_407'
                                   1829 ;src           Allocated with name '_send_keyboard_report_src_10001_407'
                                   1830 ;i             Allocated with name '_send_keyboard_report_i_20001_408'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function send_keyboard_report
                                   1835 ;	-----------------------------------------
      00821A                       1836 _send_keyboard_report:
                                   1837 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      00821A 90 0D 9F         [24] 1838 	mov	dptr,#_real_mods
      00821D E0               [24] 1839 	movx	a,@dptr
      00821E FF               [12] 1840 	mov	r7,a
      00821F 90 0D A1         [24] 1841 	mov	dptr,#_actual_keyboard_report
      008222 F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      008223 90 0D A0         [24] 1844 	mov	dptr,#_weak_mods
      008226 E0               [24] 1845 	movx	a,@dptr
      008227 42 07            [12] 1846 	orl	ar7,a
      008229 90 0D A1         [24] 1847 	mov	dptr,#_actual_keyboard_report
      00822C EF               [12] 1848 	mov	a,r7
      00822D F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00822E 90 09 85         [24] 1851 	mov	dptr,#_owned_weak_mods
      008231 E0               [24] 1852 	movx	a,@dptr
      008232 FE               [12] 1853 	mov	r6,a
      008233 90 09 84         [24] 1854 	mov	dptr,#_owned_mods
      008236 E0               [24] 1855 	movx	a,@dptr
      008237 4E               [12] 1856 	orl	a,r6
      008238 42 07            [12] 1857 	orl	ar7,a
      00823A 90 0D A1         [24] 1858 	mov	dptr,#_actual_keyboard_report
      00823D EF               [12] 1859 	mov	a,r7
      00823E F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/action_util.c:463: if (ak820_mac_mode) {
      00823F 30 1E 1F         [24] 1862 	jnb	_ak820_mac_mode,00102$
                                   1863 ;	quantum/action_util.c:464: uint8_t mods = keyboard_report->mods;
      008242 90 0D A1         [24] 1864 	mov	dptr,#_actual_keyboard_report
      008245 E0               [24] 1865 	movx	a,@dptr
      008246 FF               [12] 1866 	mov	r7,a
                                   1867 ;	quantum/action_util.c:465: keyboard_report->mods = (mods & 0x33) | ((mods & 0x44) << 1) | ((mods & 0x88) >> 1);
      008247 74 33            [12] 1868 	mov	a,#0x33
      008249 5F               [12] 1869 	anl	a,r7
      00824A FE               [12] 1870 	mov	r6,a
      00824B 8F 05            [24] 1871 	mov	ar5,r7
      00824D 53 05 44         [24] 1872 	anl	ar5,#0x44
      008250 ED               [12] 1873 	mov	a,r5
      008251 2D               [12] 1874 	add	a,r5
      008252 42 06            [12] 1875 	orl	ar6,a
      008254 53 07 88         [24] 1876 	anl	ar7,#0x88
      008257 E4               [12] 1877 	clr	a
      008258 A2 E7            [12] 1878 	mov	c,acc.7
      00825A 13               [12] 1879 	rrc	a
      00825B CF               [12] 1880 	xch	a,r7
      00825C 13               [12] 1881 	rrc	a
      00825D CF               [12] 1882 	xch	a,r7
      00825E 12 83 7B         [24] 1883 	lcall	_ak820_outline_0170
      008261                       1884 00102$:
                                   1885 ;	quantum/action_util.c:469: if (ctrl_gui_swapped) {
      008261 30 20 2C         [24] 1886 	jnb	_ctrl_gui_swapped,00104$
                                   1887 ;	quantum/action_util.c:470: uint8_t mods = keyboard_report->mods;
      008264 90 0D A1         [24] 1888 	mov	dptr,#_actual_keyboard_report
      008267 E0               [24] 1889 	movx	a,@dptr
      008268 FF               [12] 1890 	mov	r7,a
                                   1891 ;	quantum/action_util.c:471: keyboard_report->mods = (mods & 0x66) | ((mods & 0x11) << 3) | ((mods & 0x88) >> 3);
      008269 74 66            [12] 1892 	mov	a,#0x66
      00826B 5F               [12] 1893 	anl	a,r7
      00826C FE               [12] 1894 	mov	r6,a
      00826D 8F 05            [24] 1895 	mov	ar5,r7
      00826F 53 05 11         [24] 1896 	anl	ar5,#0x11
      008272 ED               [12] 1897 	mov	a,r5
      008273 12 38 90         [24] 1898 	lcall	_ak820_outline_0185
      008276 42 06            [12] 1899 	orl	ar6,a
      008278 53 07 88         [24] 1900 	anl	ar7,#0x88
      00827B E4               [12] 1901 	clr	a
      00827C 23               [12] 1902 	rl	a
      00827D CF               [12] 1903 	xch	a,r7
      00827E 12 58 48         [24] 1904 	lcall	_ak820_outline_0168
      008281 6F               [12] 1905 	xrl	a,r7
      008282 CF               [12] 1906 	xch	a,r7
      008283 54 1F            [12] 1907 	anl	a,#0x1f
      008285 CF               [12] 1908 	xch	a,r7
      008286 6F               [12] 1909 	xrl	a,r7
      008287 CF               [12] 1910 	xch	a,r7
      008288 30 E4 02         [24] 1911 	jnb	acc.4,00169$
      00828B 44 E0            [12] 1912 	orl	a,#0xffffffe0
      00828D                       1913 00169$:
      00828D 12 83 7B         [24] 1914 	lcall	_ak820_outline_0170
      008290                       1915 00104$:
                                   1916 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008290 30 1F 07         [24] 1917 	jnb	_gui_disabled,00106$
      008293 90 0D A1         [24] 1918 	mov	dptr,#_actual_keyboard_report
      008296 E0               [24] 1919 	movx	a,@dptr
      008297 54 77            [12] 1920 	anl	a,#0x77
      008299 F0               [24] 1921 	movx	@dptr,a
      00829A                       1922 00106$:
                                   1923 ;	quantum/action_util.c:515: bool changed = false;
      00829A 90 0A BD         [24] 1924 	mov	dptr,#_send_keyboard_report_changed_10001_407
      00829D E4               [12] 1925 	clr	a
      00829E F0               [24] 1926 	movx	@dptr,a
                                   1927 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1928 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1929 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00829F FF               [12] 1930 	mov	r7,a
      0082A0                       1931 00113$:
      0082A0 BF 20 00         [24] 1932 	cjne	r7,#0x20,00171$
      0082A3                       1933 00171$:
      0082A3 50 2A            [24] 1934 	jnc	00109$
                                   1935 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      0082A5 EF               [12] 1936 	mov	a,r7
      0082A6 24 9D            [12] 1937 	add	a, #_send_keyboard_report_last_report_10001_407
      0082A8 FD               [12] 1938 	mov	r5,a
      0082A9 E4               [12] 1939 	clr	a
      0082AA 34 0A            [12] 1940 	addc	a, #(_send_keyboard_report_last_report_10001_407 >> 8)
      0082AC 12 49 B8         [24] 1941 	lcall	_ak820_outline_0057
      0082AF EF               [12] 1942 	mov	a,r7
      0082B0 24 A1            [12] 1943 	add	a, #_actual_keyboard_report
      0082B2 F5 82            [12] 1944 	mov	dpl,a
      0082B4 E4               [12] 1945 	clr	a
      0082B5 34 0D            [12] 1946 	addc	a, #(_actual_keyboard_report >> 8)
      0082B7 F5 83            [12] 1947 	mov	dph,a
      0082B9 E0               [24] 1948 	movx	a,@dptr
      0082BA FB               [12] 1949 	mov	r3,a
      0082BB EC               [12] 1950 	mov	a,r4
      0082BC B5 03 02         [24] 1951 	cjne	a,ar3,00173$
      0082BF 80 0B            [24] 1952 	sjmp	00114$
      0082C1                       1953 00173$:
                                   1954 ;	quantum/action_util.c:525: dest[i] = src[i];
      0082C1 12 38 6A         [24] 1955 	lcall	_ak820_outline_0131
      0082C4 EB               [12] 1956 	mov	a,r3
      0082C5 F0               [24] 1957 	movx	@dptr,a
                                   1958 ;	quantum/action_util.c:526: changed = true;
      0082C6 90 0A BD         [24] 1959 	mov	dptr,#_send_keyboard_report_changed_10001_407
      0082C9 74 01            [12] 1960 	mov	a,#0x01
      0082CB F0               [24] 1961 	movx	@dptr,a
      0082CC                       1962 00114$:
                                   1963 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0082CC 0F               [12] 1964 	inc	r7
      0082CD 80 D1            [24] 1965 	sjmp	00113$
      0082CF                       1966 00109$:
                                   1967 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      0082CF 90 0A BD         [24] 1968 	mov	dptr,#_send_keyboard_report_changed_10001_407
      0082D2 E0               [24] 1969 	movx	a,@dptr
      0082D3 60 09            [24] 1970 	jz	00115$
      0082D5 90 0D A1         [24] 1971 	mov	dptr,#_actual_keyboard_report
      0082D8 75 F0 00         [24] 1972 	mov	b, #0x00
                                   1973 ;	quantum/action_util.c:538: }
      0082DB 02 6E 67         [24] 1974 	ljmp	_host_keyboard_send
      0082DE                       1975 00115$:
      0082DE 22               [24] 1976 	ret
                                   1977 ;------------------------------------------------------------
                                   1978 ;Allocation info for local variables in function 'get_mods'
                                   1979 ;------------------------------------------------------------
                                   1980 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1981 ;	-----------------------------------------
                                   1982 ;	 function get_mods
                                   1983 ;	-----------------------------------------
      0082DF                       1984 _get_mods:
      0082DF C0 07            [24] 1985 	push	ar7
                                   1986 ;	quantum/action_util.c:549: ;
      0082E1 90 09 84         [24] 1987 	mov	dptr,#_owned_mods
      0082E4 E0               [24] 1988 	movx	a,@dptr
      0082E5 FF               [12] 1989 	mov	r7,a
      0082E6 90 0D 9F         [24] 1990 	mov	dptr,#_real_mods
      0082E9 12 7C C4         [24] 1991 	lcall	_ak820_outline_0138
                                   1992 ;	quantum/action_util.c:550: }
      0082EC D0 07            [24] 1993 	pop	ar7
      0082EE 22               [24] 1994 	ret
                                   1995 ;------------------------------------------------------------
                                   1996 ;Allocation info for local variables in function 'add_mods'
                                   1997 ;------------------------------------------------------------
                                   1998 ;mods          Allocated with name '_add_mods_mods_10000_415'
                                   1999 ;------------------------------------------------------------
                                   2000 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   2001 ;	-----------------------------------------
                                   2002 ;	 function clear_mods
                                   2003 ;	-----------------------------------------
      0082EF                       2004 _clear_mods:
                                   2005 ;	quantum/action_util.c:577: real_mods = 0;
      0082EF 90 0D 9F         [24] 2006 	mov	dptr,#_real_mods
      0082F2 E4               [12] 2007 	clr	a
      0082F3 F0               [24] 2008 	movx	@dptr,a
                                   2009 ;	quantum/action_util.c:578: }
      0082F4 22               [24] 2010 	ret
                                   2011 ;------------------------------------------------------------
                                   2012 ;Allocation info for local variables in function 'get_weak_mods'
                                   2013 ;------------------------------------------------------------
                                   2014 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   2015 ;	-----------------------------------------
                                   2016 ;	 function get_weak_mods
                                   2017 ;	-----------------------------------------
      0082F5                       2018 _get_weak_mods:
      0082F5 C0 07            [24] 2019 	push	ar7
                                   2020 ;	quantum/action_util.c:589: ;
      0082F7 90 09 85         [24] 2021 	mov	dptr,#_owned_weak_mods
      0082FA E0               [24] 2022 	movx	a,@dptr
      0082FB FF               [12] 2023 	mov	r7,a
      0082FC 90 0D A0         [24] 2024 	mov	dptr,#_weak_mods
      0082FF 12 7C C4         [24] 2025 	lcall	_ak820_outline_0138
                                   2026 ;	quantum/action_util.c:590: }
      008302 D0 07            [24] 2027 	pop	ar7
      008304 22               [24] 2028 	ret
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'add_weak_mods'
                                   2031 ;------------------------------------------------------------
                                   2032 ;mods          Allocated with name '_add_weak_mods_mods_10000_425'
                                   2033 ;------------------------------------------------------------
                                   2034 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   2035 ;	-----------------------------------------
                                   2036 ;	 function add_weak_mods
                                   2037 ;	-----------------------------------------
      008305                       2038 _add_weak_mods:
      008305 E5 82            [12] 2039 	mov	a,dpl
      008307 90 0A BE         [24] 2040 	mov	dptr,#_add_weak_mods_mods_10000_425
      00830A F0               [24] 2041 	movx	@dptr,a
                                   2042 ;	quantum/action_util.c:596: weak_mods |= mods;
      00830B E0               [24] 2043 	movx	a,@dptr
      00830C FF               [12] 2044 	mov	r7,a
      00830D 90 0D A0         [24] 2045 	mov	dptr,#_weak_mods
      008310 E0               [24] 2046 	movx	a,@dptr
      008311 4F               [12] 2047 	orl	a,r7
      008312 F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	quantum/action_util.c:597: }
      008313 22               [24] 2050 	ret
                                   2051 ;------------------------------------------------------------
                                   2052 ;Allocation info for local variables in function 'del_weak_mods'
                                   2053 ;------------------------------------------------------------
                                   2054 ;mods          Allocated with name '_del_weak_mods_mods_10000_427'
                                   2055 ;------------------------------------------------------------
                                   2056 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   2057 ;	-----------------------------------------
                                   2058 ;	 function del_weak_mods
                                   2059 ;	-----------------------------------------
      008314                       2060 _del_weak_mods:
      008314 E5 82            [12] 2061 	mov	a,dpl
      008316 90 0A BF         [24] 2062 	mov	dptr,#_del_weak_mods_mods_10000_427
      008319 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      00831A E0               [24] 2065 	movx	a,@dptr
      00831B F4               [12] 2066 	cpl	a
      00831C FF               [12] 2067 	mov	r7,a
      00831D 90 0D A0         [24] 2068 	mov	dptr,#_weak_mods
      008320 E0               [24] 2069 	movx	a,@dptr
      008321 5F               [12] 2070 	anl	a,r7
      008322 F0               [24] 2071 	movx	@dptr,a
                                   2072 ;	quantum/action_util.c:604: }
      008323 22               [24] 2073 	ret
                                   2074 ;------------------------------------------------------------
                                   2075 ;Allocation info for local variables in function 'set_weak_mods'
                                   2076 ;------------------------------------------------------------
                                   2077 ;mods          Allocated with name '_set_weak_mods_mods_10000_429'
                                   2078 ;------------------------------------------------------------
                                   2079 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   2080 ;	-----------------------------------------
                                   2081 ;	 function clear_weak_mods
                                   2082 ;	-----------------------------------------
      008324                       2083 _clear_weak_mods:
                                   2084 ;	quantum/action_util.c:617: weak_mods = 0;
      008324 90 0D A0         [24] 2085 	mov	dptr,#_weak_mods
      008327 E4               [12] 2086 	clr	a
      008328 F0               [24] 2087 	movx	@dptr,a
                                   2088 ;	quantum/action_util.c:618: }
      008329 22               [24] 2089 	ret
                                   2090 ;------------------------------------------------------------
                                   2091 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2092 ;------------------------------------------------------------
                                   2093 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_433'
                                   2094 ;------------------------------------------------------------
                                   2095 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2096 ;	-----------------------------------------
                                   2097 	.area CSEG    (CODE)
                                   2098 	.area CONST   (CODE)
                                   2099 	.area XINIT   (CODE)
      00C25E                       2100 __xinit__real_mods:
      00C25E 00                    2101 	.db #0x00	; 0
      00C25F                       2102 __xinit__weak_mods:
      00C25F 00                    2103 	.db #0x00	; 0
      00C260                       2104 __xinit__actual_keyboard_report:
      00C260 00                    2105 	.db #0x00	; 0
      00C261 00                    2106 	.db #0x00	; 0
      00C262 00                    2107 	.db #0x00	; 0
      00C263 00                    2108 	.db #0x00	; 0
      00C264 00                    2109 	.db #0x00	; 0
      00C265 00                    2110 	.db #0x00	; 0
      00C266 00                    2111 	.db #0x00	; 0
      00C267 00                    2112 	.db #0x00	; 0
      00C268 00                    2113 	.db 0x00
      00C269 00                    2114 	.db 0x00
      00C26A 00                    2115 	.db 0x00
      00C26B 00                    2116 	.db 0x00
      00C26C 00                    2117 	.db 0x00
      00C26D 00                    2118 	.db 0x00
      00C26E 00                    2119 	.db 0x00
      00C26F 00                    2120 	.db 0x00
      00C270 00                    2121 	.db 0x00
      00C271 00                    2122 	.db 0x00
      00C272 00                    2123 	.db 0x00
      00C273 00                    2124 	.db 0x00
      00C274 00                    2125 	.db 0x00
      00C275 00                    2126 	.db 0x00
      00C276 00                    2127 	.db 0x00
      00C277 00                    2128 	.db 0x00
      00C278 00                    2129 	.db 0x00
      00C279 00                    2130 	.db 0x00
      00C27A 00                    2131 	.db 0x00
      00C27B 00                    2132 	.db 0x00
      00C27C 00                    2133 	.db 0x00
      00C27D 00                    2134 	.db 0x00
      00C27E 00                    2135 	.db 0x00
      00C27F 00                    2136 	.db 0x00
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0014
                                   2141 	.globl _ak820_outline_0029
                                   2142 	.globl _ak820_outline_0051
                                   2143 	.globl _ak820_outline_0057
                                   2144 	.globl _ak820_outline_0060
                                   2145 	.globl _ak820_outline_0063
                                   2146 	.globl _ak820_outline_0064
                                   2147 	.globl _ak820_outline_0065
                                   2148 	.globl _ak820_outline_0068
                                   2149 	.globl _ak820_outline_0074
                                   2150 	.globl _ak820_outline_0104
                                   2151 	.globl _ak820_outline_0105
                                   2152 	.globl _ak820_outline_0114
                                   2153 	.globl _ak820_outline_0119
                                   2154 	.globl _ak820_outline_0122
                                   2155 	.globl _ak820_outline_0123
                                   2156 	.globl _ak820_outline_0124
                                   2157 	.globl _ak820_outline_0130
                                   2158 	.globl _ak820_outline_0131
                                   2159 	.globl _ak820_outline_0136
                                   2160 	.globl _ak820_outline_0138
                                   2161 	.globl _ak820_outline_0152
                                   2162 	.globl _ak820_outline_0153
                                   2163 	.globl _ak820_outline_0158
                                   2164 	.globl _ak820_outline_0168
                                   2165 	.globl _ak820_outline_0170
                                   2166 	.globl _ak820_outline_0173
                                   2167 	.globl _ak820_outline_0180
                                   2168 	.globl _ak820_outline_0185
                                   2169 	.globl _ak820_outline_0187
                                   2170 
                                   2171 	.area CSEG (CODE)
                                   2172 ; function ak820_outline_0029
      00832A                       2173 _ak820_outline_0029:
      00832A EF               [12] 2174 	mov	a,r7
      00832B 24 96            [12] 2175 	add	a,#_key_refs
      00832D FD               [12] 2176 	mov	r5,a
      00832E E4               [12] 2177 	clr	a
      00832F 34 09            [12] 2178 	addc	a,#(_key_refs>>8)
      008331 FE               [12] 2179 	mov	r6,a
      008332 8D 82            [24] 2180 	mov	dpl,r5
      008334 8E 83            [24] 2181 	mov	dph,r6
      008336 E0               [24] 2182 	movx	a,@dptr
      008337 22               [24] 2183 	ret
                                   2184 
                                   2185 	.area CSEG (CODE)
                                   2186 ; function ak820_outline_0064
      008338                       2187 _ak820_outline_0064:
      008338 89 82            [24] 2188 	mov	dpl,r1
      00833A 8A 83            [24] 2189 	mov	dph,r2
      00833C E8               [12] 2190 	mov	a,r0
      00833D F0               [24] 2191 	movx	@dptr,a
      00833E 22               [24] 2192 	ret
                                   2193 
                                   2194 	.area CSEG (CODE)
                                   2195 ; function ak820_outline_0068
      00833F                       2196 _ak820_outline_0068:
      00833F 24 71            [12] 2197 	add	a,#_usage_order
      008341 F5 82            [12] 2198 	mov	dpl,a
      008343 E4               [12] 2199 	clr	a
      008344 34 0A            [12] 2200 	addc	a,#(_usage_order>>8)
      008346 F5 83            [12] 2201 	mov	dph,a
      008348 22               [24] 2202 	ret
                                   2203 
                                   2204 	.area CSEG (CODE)
                                   2205 ; function ak820_outline_0074
      008349                       2206 _ak820_outline_0074:
      008349 EB               [12] 2207 	mov	a,r3
      00834A 24 53            [12] 2208 	add	a,#_usage_refs
      00834C F9               [12] 2209 	mov	r1,a
      00834D E4               [12] 2210 	clr	a
      00834E 34 0A            [12] 2211 	addc	a,#(_usage_refs>>8)
      008350 FA               [12] 2212 	mov	r2,a
      008351 89 82            [24] 2213 	mov	dpl,r1
      008353 8A 83            [24] 2214 	mov	dph,r2
      008355 E0               [24] 2215 	movx	a,@dptr
      008356 F8               [12] 2216 	mov	r0,a
      008357 22               [24] 2217 	ret
                                   2218 
                                   2219 	.area CSEG (CODE)
                                   2220 ; function ak820_outline_0114
      008358                       2221 _ak820_outline_0114:
      008358 F0               [24] 2222 	movx	@dptr,a
      008359 E0               [24] 2223 	movx	a,@dptr
      00835A FF               [12] 2224 	mov	r7,a
      00835B 90 09 8E         [24] 2225 	mov	dptr,#_change_owned_PARM_2
      00835E 22               [24] 2226 	ret
                                   2227 
                                   2228 	.area CSEG (CODE)
                                   2229 ; function ak820_outline_0119
      00835F                       2230 _ak820_outline_0119:
      00835F 8D 82            [24] 2231 	mov	dpl,r5
      008361 8E 83            [24] 2232 	mov	dph,r6
      008363 F0               [24] 2233 	movx	@dptr,a
      008364 22               [24] 2234 	ret
                                   2235 
                                   2236 	.area CSEG (CODE)
                                   2237 ; function ak820_outline_0124
      008365                       2238 _ak820_outline_0124:
      008365 24 71            [12] 2239 	add	a,#_usage_order
      008367 F5 82            [12] 2240 	mov	dpl,a
      008369 EF               [12] 2241 	mov	a,r7
      00836A 34 0A            [12] 2242 	addc	a,#(_usage_order>>8)
      00836C F5 83            [12] 2243 	mov	dph,a
      00836E E0               [24] 2244 	movx	a,@dptr
      00836F 22               [24] 2245 	ret
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0130
      008370                       2249 _ak820_outline_0130:
      008370 F0               [24] 2250 	movx	@dptr,a
      008371 E0               [24] 2251 	movx	a,@dptr
      008372 FF               [12] 2252 	mov	r7,a
      008373 90 09 8A         [24] 2253 	mov	dptr,#_ak820_macro_change_PARM_2
      008376 F0               [24] 2254 	movx	@dptr,a
      008377 90 09 8B         [24] 2255 	mov	dptr,#_ak820_macro_change_PARM_3
      00837A 22               [24] 2256 	ret
                                   2257 
                                   2258 	.area CSEG (CODE)
                                   2259 ; function ak820_outline_0170
      00837B                       2260 _ak820_outline_0170:
      00837B EF               [12] 2261 	mov	a,r7
      00837C 42 06            [12] 2262 	orl	ar6,a
      00837E 90 0D A1         [24] 2263 	mov	dptr,#_actual_keyboard_report
      008381 EE               [12] 2264 	mov	a,r6
      008382 F0               [24] 2265 	movx	@dptr,a
      008383 22               [24] 2266 	ret
                                   2267 
                                   2268 	.area CSEG (CODE)
                                   2269 ; function ak820_outline_0173
      008384                       2270 _ak820_outline_0173:
      008384 90 08 04         [24] 2271 	mov	dptr,#_add_key_to_report_PARM_2
      008387 EF               [12] 2272 	mov	a,r7
      008388 F0               [24] 2273 	movx	@dptr,a
      008389 90 0D A1         [24] 2274 	mov	dptr,#_actual_keyboard_report
      00838C 22               [24] 2275 	ret
                                   2276 
                                   2277 	.area CSEG (CODE)
                                   2278 ; function ak820_outline_0187
      00838D                       2279 _ak820_outline_0187:
      00838D 8D 82            [24] 2280 	mov	dpl,r5
      00838F 8F 83            [24] 2281 	mov	dph,r7
      008391 22               [24] 2282 	ret
