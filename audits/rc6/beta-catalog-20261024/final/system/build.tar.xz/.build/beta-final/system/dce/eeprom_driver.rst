                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000683                         85 _eeprom_read_word_addr_10000_91:
      000683                         86 	.ds 3
      000686                         87 _eeprom_read_word_ret_10000_92:
      000686                         88 	.ds 2
      000688                         89 _eeprom_read_dword_addr_10000_93:
      000688                         90 	.ds 3
      00068B                         91 _eeprom_read_dword_ret_10000_94:
      00068B                         92 	.ds 4
      00068F                         93 _eeprom_write_byte_PARM_2:
      00068F                         94 	.ds 1
      000690                         95 _eeprom_write_byte_addr_10000_95:
      000690                         96 	.ds 3
      000693                         97 _eeprom_write_word_PARM_2:
      000693                         98 	.ds 2
      000695                         99 _eeprom_write_word_addr_10000_97:
      000695                        100 	.ds 3
      000698                        101 _eeprom_write_dword_PARM_2:
      000698                        102 	.ds 4
      00069C                        103 _eeprom_write_dword_addr_10000_99:
      00069C                        104 	.ds 3
      00069F                        105 _eeprom_update_byte_PARM_2:
      00069F                        106 	.ds 1
      0006A0                        107 _eeprom_update_byte_addr_10000_107:
      0006A0                        108 	.ds 3
      0006A3                        109 _eeprom_update_word_PARM_2:
      0006A3                        110 	.ds 2
      0006A5                        111 _eeprom_update_word_addr_10000_111:
      0006A5                        112 	.ds 3
      0006A8                        113 _eeprom_update_dword_PARM_2:
      0006A8                        114 	.ds 4
      0006AC                        115 _eeprom_update_dword_addr_10000_115:
      0006AC                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004E48                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004E48 12 43 42         [24]  170 	lcall	_ak820_outline_0037
      004E4B 90 06 83         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E4E 12 37 D6         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004E51 90 06 86         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E54 12 50 53         [24]  175 	lcall	_ak820_outline_0180
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004E57 90 06 83         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E5A 12 50 01         [24]  178 	lcall	_ak820_outline_0021
      004E5D 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E60 ED               [12]  180 	mov	a,r5
      004E61 12 37 D6         [24]  181 	lcall	_ak820_outline_0016
      004E64 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E67 12 50 45         [24]  183 	lcall	_ak820_outline_0107
      004E6A 90 06 86         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E6D 12 40 DE         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004E70 90 06 86         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E73 12 50 3C         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004E76 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004E77                        201 _eeprom_read_dword:
      004E77 12 43 42         [24]  202 	lcall	_ak820_outline_0037
      004E7A 90 06 88         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E7D 12 37 D6         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004E80 90 06 8B         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E83 12 50 11         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004E86 90 06 88         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E89 12 50 01         [24]  210 	lcall	_ak820_outline_0021
      004E8C 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E8F ED               [12]  212 	mov	a,r5
      004E90 12 37 D6         [24]  213 	lcall	_ak820_outline_0016
      004E93 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E96 74 04            [12]  215 	mov	a,#0x04
      004E98 12 38 5C         [24]  216 	lcall	_ak820_outline_0123
      004E9B 90 06 8B         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E9E 12 40 DE         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004EA1 90 06 8B         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004EA4 12 50 1A         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004EA7 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004EA8                        234 _eeprom_write_byte:
      004EA8 12 43 42         [24]  235 	lcall	_ak820_outline_0037
      004EAB 90 06 90         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004EAE 12 37 D6         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004EB1 90 06 90         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004EB4 12 4F DB         [24]  240 	lcall	_ak820_outline_0002
      004EB7 74 01            [12]  241 	mov	a,#0x01
      004EB9 12 38 5C         [24]  242 	lcall	_ak820_outline_0123
      004EBC 90 06 8F         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004EBF 02 41 6A         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004EC2                        256 _eeprom_write_word:
      004EC2 12 43 42         [24]  257 	lcall	_ak820_outline_0037
      004EC5 90 06 95         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EC8 12 37 D6         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004ECB 90 06 95         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004ECE 12 4F DB         [24]  262 	lcall	_ak820_outline_0002
      004ED1 12 50 45         [24]  263 	lcall	_ak820_outline_0107
      004ED4 90 06 93         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004ED7 02 41 6A         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004EDA                        277 _eeprom_write_dword:
      004EDA 12 43 42         [24]  278 	lcall	_ak820_outline_0037
      004EDD 90 06 9C         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EE0 12 37 D6         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004EE3 90 06 9C         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EE6 12 4F DB         [24]  283 	lcall	_ak820_outline_0002
      004EE9 74 04            [12]  284 	mov	a,#0x04
      004EEB 12 38 5C         [24]  285 	lcall	_ak820_outline_0123
      004EEE 90 06 98         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004EF1 02 41 6A         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004EF4                        307 _eeprom_update_byte:
      004EF4 C0 07            [24]  308 	push	ar7
      004EF6 C0 06            [24]  309 	push	ar6
      004EF8 C0 05            [24]  310 	push	ar5
      004EFA C0 04            [24]  311 	push	ar4
      004EFC 12 43 42         [24]  312 	lcall	_ak820_outline_0037
      004EFF 90 06 A0         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F02 12 37 D6         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004F05 90 06 A0         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F08 12 4F F2         [24]  317 	lcall	_ak820_outline_0003
      004F0B 12 40 A3         [24]  318 	lcall	_eeprom_read_byte
      004F0E AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004F10 90 06 9F         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004F13 E0               [24]  322 	movx	a,@dptr
      004F14 FE               [12]  323 	mov	r6,a
      004F15 EF               [12]  324 	mov	a,r7
      004F16 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004F19 80 35            [24]  326 	sjmp	00103$
      004F1B                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004F1B 90 06 A0         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F1E 12 38 16         [24]  330 	lcall	_ak820_outline_0060
      004F21 A3               [24]  331 	inc	dptr
      004F22 E0               [24]  332 	movx	a,@dptr
      004F23 FF               [12]  333 	mov	r7,a
      004F24 90 06 8F         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004F27 EE               [12]  335 	mov	a,r6
      004F28 12 38 28         [24]  336 	lcall	_ak820_outline_0096
      004F2B 8F F0            [24]  337 	mov	b, r7
      004F2D C0 07            [24]  338 	push	ar7
      004F2F C0 06            [24]  339 	push	ar6
      004F31 C0 05            [24]  340 	push	ar5
      004F33 C0 04            [24]  341 	push	ar4
      004F35 C0 03            [24]  342 	push	ar3
      004F37 C0 02            [24]  343 	push	ar2
      004F39 C0 01            [24]  344 	push	ar1
      004F3B C0 00            [24]  345 	push	ar0
      004F3D 12 4E A8         [24]  346 	lcall	_eeprom_write_byte
      004F40 D0 00            [24]  347 	pop	ar0
      004F42 D0 01            [24]  348 	pop	ar1
      004F44 D0 02            [24]  349 	pop	ar2
      004F46 D0 03            [24]  350 	pop	ar3
      004F48 D0 04            [24]  351 	pop	ar4
      004F4A D0 05            [24]  352 	pop	ar5
      004F4C D0 06            [24]  353 	pop	ar6
      004F4E D0 07            [24]  354 	pop	ar7
      004F50                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004F50 D0 04            [24]  357 	pop	ar4
      004F52 D0 05            [24]  358 	pop	ar5
      004F54 D0 06            [24]  359 	pop	ar6
      004F56 D0 07            [24]  360 	pop	ar7
      004F58 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004F59                        373 _eeprom_update_word:
      004F59 12 43 42         [24]  374 	lcall	_ak820_outline_0037
      004F5C 90 06 A5         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F5F 12 37 D6         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004F62 90 06 A5         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F65 12 4F F2         [24]  379 	lcall	_ak820_outline_0003
      004F68 12 4E 48         [24]  380 	lcall	_eeprom_read_word
      004F6B 12 43 8F         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004F6E 90 06 A3         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004F71 12 38 16         [24]  384 	lcall	_ak820_outline_0060
      004F74 EE               [12]  385 	mov	a,r6
      004F75 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004F78 EF               [12]  387 	mov	a,r7
      004F79 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004F7C 22               [24]  389 	ret
      004F7D                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004F7D 90 06 A5         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F80 E0               [24]  393 	movx	a,@dptr
      004F81 FB               [12]  394 	mov	r3,a
      004F82 A3               [24]  395 	inc	dptr
      004F83 12 37 F7         [24]  396 	lcall	_ak820_outline_0051
      004F86 90 06 93         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004F89 12 38 1C         [24]  398 	lcall	_ak820_outline_0071
      004F8C 8B 82            [24]  399 	mov	dpl, r3
      004F8E 8E 83            [24]  400 	mov	dph, r6
      004F90 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004F92 02 4E C2         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004F95                        415 _eeprom_update_dword:
      004F95 12 43 42         [24]  416 	lcall	_ak820_outline_0037
      004F98 90 06 AC         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F9B 12 37 D6         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004F9E 90 06 AC         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FA1 12 4F F2         [24]  421 	lcall	_ak820_outline_0003
      004FA4 12 4E 77         [24]  422 	lcall	_eeprom_read_dword
      004FA7 12 50 2B         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004FAA 90 06 A8         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004FAD E0               [24]  426 	movx	a,@dptr
      004FAE F8               [12]  427 	mov	r0,a
      004FAF A3               [24]  428 	inc	dptr
      004FB0 12 50 33         [24]  429 	lcall	_ak820_outline_0087
      004FB3 EC               [12]  430 	mov	a,r4
      004FB4 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004FB7 ED               [12]  432 	mov	a,r5
      004FB8 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004FBB EE               [12]  434 	mov	a,r6
      004FBC B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004FBF EF               [12]  436 	mov	a,r7
      004FC0 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004FC3 22               [24]  438 	ret
      004FC4                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004FC4 90 06 AC         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FC7 12 50 01         [24]  442 	lcall	_ak820_outline_0021
      004FCA 90 06 98         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004FCD E8               [12]  444 	mov	a,r0
      004FCE F0               [24]  445 	movx	@dptr,a
      004FCF E9               [12]  446 	mov	a,r1
      004FD0 A3               [24]  447 	inc	dptr
      004FD1 12 50 4C         [24]  448 	lcall	_ak820_outline_0151
      004FD4 F0               [24]  449 	movx	@dptr,a
      004FD5 12 50 0A         [24]  450 	lcall	_ak820_outline_0044
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      004FD8 02 4E DA         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0021
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0044
                                    465 	.globl _ak820_outline_0049
                                    466 	.globl _ak820_outline_0051
                                    467 	.globl _ak820_outline_0054
                                    468 	.globl _ak820_outline_0056
                                    469 	.globl _ak820_outline_0060
                                    470 	.globl _ak820_outline_0071
                                    471 	.globl _ak820_outline_0087
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0096
                                    474 	.globl _ak820_outline_0107
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0151
                                    478 	.globl _ak820_outline_0180
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      004FDB                        482 _ak820_outline_0002:
      004FDB E0               [24]  483 	movx	a,@dptr
      004FDC FD               [12]  484 	mov	r5,a
      004FDD A3               [24]  485 	inc	dptr
      004FDE E0               [24]  486 	movx	a,@dptr
      004FDF FE               [12]  487 	mov	r6,a
      004FE0 A3               [24]  488 	inc	dptr
      004FE1 E0               [24]  489 	movx	a,@dptr
      004FE2 FF               [12]  490 	mov	r7,a
      004FE3 90 05 8A         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004FE6 ED               [12]  492 	mov	a,r5
      004FE7 F0               [24]  493 	movx	@dptr,a
      004FE8 EE               [12]  494 	mov	a,r6
      004FE9 A3               [24]  495 	inc	dptr
      004FEA F0               [24]  496 	movx	@dptr,a
      004FEB EF               [12]  497 	mov	a,r7
      004FEC A3               [24]  498 	inc	dptr
      004FED F0               [24]  499 	movx	@dptr,a
      004FEE 90 05 8D         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004FF1 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      004FF2                        505 _ak820_outline_0003:
      004FF2 E0               [24]  506 	movx	a,@dptr
      004FF3 FD               [12]  507 	mov	r5,a
      004FF4 A3               [24]  508 	inc	dptr
      004FF5 E0               [24]  509 	movx	a,@dptr
      004FF6 FE               [12]  510 	mov	r6,a
      004FF7 A3               [24]  511 	inc	dptr
      004FF8 E0               [24]  512 	movx	a,@dptr
      004FF9 FF               [12]  513 	mov	r7,a
      004FFA 8D 82            [24]  514 	mov	dpl,r5
      004FFC 8E 83            [24]  515 	mov	dph,r6
      004FFE 8F F0            [24]  516 	mov	b,r7
      005000 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0021
      005001                        521 _ak820_outline_0021:
      005001 E0               [24]  522 	movx	a,@dptr
      005002 FD               [12]  523 	mov	r5,a
      005003 A3               [24]  524 	inc	dptr
      005004 E0               [24]  525 	movx	a,@dptr
      005005 FE               [12]  526 	mov	r6,a
      005006 A3               [24]  527 	inc	dptr
      005007 E0               [24]  528 	movx	a,@dptr
      005008 FF               [12]  529 	mov	r7,a
      005009 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0044
      00500A                        534 _ak820_outline_0044:
      00500A 8D 82            [24]  535 	mov	dpl,r5
      00500C 8E 83            [24]  536 	mov	dph,r6
      00500E 8F F0            [24]  537 	mov	b,r7
      005010 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0049
      005011                        542 _ak820_outline_0049:
      005011 E4               [12]  543 	clr	a
      005012 F0               [24]  544 	movx	@dptr,a
      005013 A3               [24]  545 	inc	dptr
      005014 F0               [24]  546 	movx	@dptr,a
      005015 A3               [24]  547 	inc	dptr
      005016 F0               [24]  548 	movx	@dptr,a
      005017 A3               [24]  549 	inc	dptr
      005018 F0               [24]  550 	movx	@dptr,a
      005019 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      00501A                        555 _ak820_outline_0054:
      00501A E0               [24]  556 	movx	a,@dptr
      00501B FC               [12]  557 	mov	r4,a
      00501C A3               [24]  558 	inc	dptr
      00501D E0               [24]  559 	movx	a,@dptr
      00501E FD               [12]  560 	mov	r5,a
      00501F A3               [24]  561 	inc	dptr
      005020 E0               [24]  562 	movx	a,@dptr
      005021 FE               [12]  563 	mov	r6,a
      005022 A3               [24]  564 	inc	dptr
      005023 E0               [24]  565 	movx	a,@dptr
      005024 8C 82            [24]  566 	mov	dpl,r4
      005026 8D 83            [24]  567 	mov	dph,r5
      005028 8E F0            [24]  568 	mov	b,r6
      00502A 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      00502B                        573 _ak820_outline_0056:
      00502B AC 82            [24]  574 	mov	r4,dpl
      00502D AD 83            [24]  575 	mov	r5,dph
      00502F AE F0            [24]  576 	mov	r6,b
      005031 FF               [12]  577 	mov	r7,a
      005032 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0087
      005033                        582 _ak820_outline_0087:
      005033 E0               [24]  583 	movx	a,@dptr
      005034 F9               [12]  584 	mov	r1,a
      005035 A3               [24]  585 	inc	dptr
      005036 E0               [24]  586 	movx	a,@dptr
      005037 FA               [12]  587 	mov	r2,a
      005038 A3               [24]  588 	inc	dptr
      005039 E0               [24]  589 	movx	a,@dptr
      00503A FB               [12]  590 	mov	r3,a
      00503B 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0088
      00503C                        595 _ak820_outline_0088:
      00503C E0               [24]  596 	movx	a,@dptr
      00503D FE               [12]  597 	mov	r6,a
      00503E A3               [24]  598 	inc	dptr
      00503F E0               [24]  599 	movx	a,@dptr
      005040 8E 82            [24]  600 	mov	dpl,r6
      005042 F5 83            [12]  601 	mov	dph,a
      005044 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0107
      005045                        606 _ak820_outline_0107:
      005045 74 02            [12]  607 	mov	a,#0x02
      005047 F0               [24]  608 	movx	@dptr,a
      005048 E4               [12]  609 	clr	a
      005049 A3               [24]  610 	inc	dptr
      00504A F0               [24]  611 	movx	@dptr,a
      00504B 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0151
      00504C                        616 _ak820_outline_0151:
      00504C F0               [24]  617 	movx	@dptr,a
      00504D EA               [12]  618 	mov	a,r2
      00504E A3               [24]  619 	inc	dptr
      00504F F0               [24]  620 	movx	@dptr,a
      005050 EB               [12]  621 	mov	a,r3
      005051 A3               [24]  622 	inc	dptr
      005052 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0180
      005053                        627 _ak820_outline_0180:
      005053 E4               [12]  628 	clr	a
      005054 F0               [24]  629 	movx	@dptr,a
      005055 A3               [24]  630 	inc	dptr
      005056 F0               [24]  631 	movx	@dptr,a
      005057 22               [24]  632 	ret
