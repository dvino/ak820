                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000683                         85 _eeprom_read_word_addr_10000_91:
      000683                         86 	.ds 3
      000686                         87 _eeprom_read_word_ret_10000_92:
      000686                         88 	.ds 2
      000688                         89 _eeprom_read_dword_addr_10000_93:
      000688                         90 	.ds 3
      00068B                         91 _eeprom_read_dword_ret_10000_94:
      00068B                         92 	.ds 4
      00068F                         93 _eeprom_write_byte_PARM_2:
      00068F                         94 	.ds 1
      000690                         95 _eeprom_write_byte_addr_10000_95:
      000690                         96 	.ds 3
      000693                         97 _eeprom_write_word_PARM_2:
      000693                         98 	.ds 2
      000695                         99 _eeprom_write_word_addr_10000_97:
      000695                        100 	.ds 3
      000698                        101 _eeprom_write_dword_PARM_2:
      000698                        102 	.ds 4
      00069C                        103 _eeprom_write_dword_addr_10000_99:
      00069C                        104 	.ds 3
      00069F                        105 _eeprom_update_byte_PARM_2:
      00069F                        106 	.ds 1
      0006A0                        107 _eeprom_update_byte_addr_10000_107:
      0006A0                        108 	.ds 3
      0006A3                        109 _eeprom_update_word_PARM_2:
      0006A3                        110 	.ds 2
      0006A5                        111 _eeprom_update_word_addr_10000_111:
      0006A5                        112 	.ds 3
      0006A8                        113 _eeprom_update_dword_PARM_2:
      0006A8                        114 	.ds 4
      0006AC                        115 _eeprom_update_dword_addr_10000_115:
      0006AC                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004E5A                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004E5A 12 43 4B         [24]  170 	lcall	_ak820_outline_0037
      004E5D 90 06 83         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E60 12 37 DF         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004E63 90 06 86         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E66 12 50 65         [24]  175 	lcall	_ak820_outline_0180
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004E69 90 06 83         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E6C 12 50 13         [24]  178 	lcall	_ak820_outline_0021
      004E6F 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E72 ED               [12]  180 	mov	a,r5
      004E73 12 37 DF         [24]  181 	lcall	_ak820_outline_0016
      004E76 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E79 12 50 57         [24]  183 	lcall	_ak820_outline_0107
      004E7C 90 06 86         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E7F 12 40 E7         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004E82 90 06 86         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E85 12 50 4E         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004E88 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004E89                        201 _eeprom_read_dword:
      004E89 12 43 4B         [24]  202 	lcall	_ak820_outline_0037
      004E8C 90 06 88         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E8F 12 37 DF         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004E92 90 06 8B         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E95 12 50 23         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004E98 90 06 88         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E9B 12 50 13         [24]  210 	lcall	_ak820_outline_0021
      004E9E 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004EA1 ED               [12]  212 	mov	a,r5
      004EA2 12 37 DF         [24]  213 	lcall	_ak820_outline_0016
      004EA5 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004EA8 74 04            [12]  215 	mov	a,#0x04
      004EAA 12 38 65         [24]  216 	lcall	_ak820_outline_0123
      004EAD 90 06 8B         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004EB0 12 40 E7         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004EB3 90 06 8B         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004EB6 12 50 2C         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004EB9 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004EBA                        234 _eeprom_write_byte:
      004EBA 12 43 4B         [24]  235 	lcall	_ak820_outline_0037
      004EBD 90 06 90         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004EC0 12 37 DF         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004EC3 90 06 90         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004EC6 12 4F ED         [24]  240 	lcall	_ak820_outline_0002
      004EC9 74 01            [12]  241 	mov	a,#0x01
      004ECB 12 38 65         [24]  242 	lcall	_ak820_outline_0123
      004ECE 90 06 8F         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004ED1 02 41 73         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004ED4                        256 _eeprom_write_word:
      004ED4 12 43 4B         [24]  257 	lcall	_ak820_outline_0037
      004ED7 90 06 95         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EDA 12 37 DF         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004EDD 90 06 95         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EE0 12 4F ED         [24]  262 	lcall	_ak820_outline_0002
      004EE3 12 50 57         [24]  263 	lcall	_ak820_outline_0107
      004EE6 90 06 93         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004EE9 02 41 73         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004EEC                        277 _eeprom_write_dword:
      004EEC 12 43 4B         [24]  278 	lcall	_ak820_outline_0037
      004EEF 90 06 9C         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EF2 12 37 DF         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004EF5 90 06 9C         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EF8 12 4F ED         [24]  283 	lcall	_ak820_outline_0002
      004EFB 74 04            [12]  284 	mov	a,#0x04
      004EFD 12 38 65         [24]  285 	lcall	_ak820_outline_0123
      004F00 90 06 98         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004F03 02 41 73         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004F06                        307 _eeprom_update_byte:
      004F06 C0 07            [24]  308 	push	ar7
      004F08 C0 06            [24]  309 	push	ar6
      004F0A C0 05            [24]  310 	push	ar5
      004F0C C0 04            [24]  311 	push	ar4
      004F0E 12 43 4B         [24]  312 	lcall	_ak820_outline_0037
      004F11 90 06 A0         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F14 12 37 DF         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004F17 90 06 A0         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F1A 12 50 04         [24]  317 	lcall	_ak820_outline_0003
      004F1D 12 40 AC         [24]  318 	lcall	_eeprom_read_byte
      004F20 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004F22 90 06 9F         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004F25 E0               [24]  322 	movx	a,@dptr
      004F26 FE               [12]  323 	mov	r6,a
      004F27 EF               [12]  324 	mov	a,r7
      004F28 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004F2B 80 35            [24]  326 	sjmp	00103$
      004F2D                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004F2D 90 06 A0         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F30 12 38 1F         [24]  330 	lcall	_ak820_outline_0060
      004F33 A3               [24]  331 	inc	dptr
      004F34 E0               [24]  332 	movx	a,@dptr
      004F35 FF               [12]  333 	mov	r7,a
      004F36 90 06 8F         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004F39 EE               [12]  335 	mov	a,r6
      004F3A 12 38 31         [24]  336 	lcall	_ak820_outline_0096
      004F3D 8F F0            [24]  337 	mov	b, r7
      004F3F C0 07            [24]  338 	push	ar7
      004F41 C0 06            [24]  339 	push	ar6
      004F43 C0 05            [24]  340 	push	ar5
      004F45 C0 04            [24]  341 	push	ar4
      004F47 C0 03            [24]  342 	push	ar3
      004F49 C0 02            [24]  343 	push	ar2
      004F4B C0 01            [24]  344 	push	ar1
      004F4D C0 00            [24]  345 	push	ar0
      004F4F 12 4E BA         [24]  346 	lcall	_eeprom_write_byte
      004F52 D0 00            [24]  347 	pop	ar0
      004F54 D0 01            [24]  348 	pop	ar1
      004F56 D0 02            [24]  349 	pop	ar2
      004F58 D0 03            [24]  350 	pop	ar3
      004F5A D0 04            [24]  351 	pop	ar4
      004F5C D0 05            [24]  352 	pop	ar5
      004F5E D0 06            [24]  353 	pop	ar6
      004F60 D0 07            [24]  354 	pop	ar7
      004F62                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004F62 D0 04            [24]  357 	pop	ar4
      004F64 D0 05            [24]  358 	pop	ar5
      004F66 D0 06            [24]  359 	pop	ar6
      004F68 D0 07            [24]  360 	pop	ar7
      004F6A 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004F6B                        373 _eeprom_update_word:
      004F6B 12 43 4B         [24]  374 	lcall	_ak820_outline_0037
      004F6E 90 06 A5         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F71 12 37 DF         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004F74 90 06 A5         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F77 12 50 04         [24]  379 	lcall	_ak820_outline_0003
      004F7A 12 4E 5A         [24]  380 	lcall	_eeprom_read_word
      004F7D 12 43 98         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004F80 90 06 A3         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004F83 12 38 1F         [24]  384 	lcall	_ak820_outline_0060
      004F86 EE               [12]  385 	mov	a,r6
      004F87 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004F8A EF               [12]  387 	mov	a,r7
      004F8B B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004F8E 22               [24]  389 	ret
      004F8F                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004F8F 90 06 A5         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F92 E0               [24]  393 	movx	a,@dptr
      004F93 FB               [12]  394 	mov	r3,a
      004F94 A3               [24]  395 	inc	dptr
      004F95 12 38 00         [24]  396 	lcall	_ak820_outline_0051
      004F98 90 06 93         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004F9B 12 38 25         [24]  398 	lcall	_ak820_outline_0071
      004F9E 8B 82            [24]  399 	mov	dpl, r3
      004FA0 8E 83            [24]  400 	mov	dph, r6
      004FA2 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004FA4 02 4E D4         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004FA7                        415 _eeprom_update_dword:
      004FA7 12 43 4B         [24]  416 	lcall	_ak820_outline_0037
      004FAA 90 06 AC         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FAD 12 37 DF         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004FB0 90 06 AC         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FB3 12 50 04         [24]  421 	lcall	_ak820_outline_0003
      004FB6 12 4E 89         [24]  422 	lcall	_eeprom_read_dword
      004FB9 12 50 3D         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004FBC 90 06 A8         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004FBF E0               [24]  426 	movx	a,@dptr
      004FC0 F8               [12]  427 	mov	r0,a
      004FC1 A3               [24]  428 	inc	dptr
      004FC2 12 50 45         [24]  429 	lcall	_ak820_outline_0087
      004FC5 EC               [12]  430 	mov	a,r4
      004FC6 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004FC9 ED               [12]  432 	mov	a,r5
      004FCA B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004FCD EE               [12]  434 	mov	a,r6
      004FCE B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004FD1 EF               [12]  436 	mov	a,r7
      004FD2 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004FD5 22               [24]  438 	ret
      004FD6                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004FD6 90 06 AC         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FD9 12 50 13         [24]  442 	lcall	_ak820_outline_0021
      004FDC 90 06 98         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004FDF E8               [12]  444 	mov	a,r0
      004FE0 F0               [24]  445 	movx	@dptr,a
      004FE1 E9               [12]  446 	mov	a,r1
      004FE2 A3               [24]  447 	inc	dptr
      004FE3 12 50 5E         [24]  448 	lcall	_ak820_outline_0151
      004FE6 F0               [24]  449 	movx	@dptr,a
      004FE7 12 50 1C         [24]  450 	lcall	_ak820_outline_0044
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      004FEA 02 4E EC         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0021
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0044
                                    465 	.globl _ak820_outline_0049
                                    466 	.globl _ak820_outline_0051
                                    467 	.globl _ak820_outline_0054
                                    468 	.globl _ak820_outline_0056
                                    469 	.globl _ak820_outline_0060
                                    470 	.globl _ak820_outline_0071
                                    471 	.globl _ak820_outline_0087
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0096
                                    474 	.globl _ak820_outline_0107
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0151
                                    478 	.globl _ak820_outline_0180
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      004FED                        482 _ak820_outline_0002:
      004FED E0               [24]  483 	movx	a,@dptr
      004FEE FD               [12]  484 	mov	r5,a
      004FEF A3               [24]  485 	inc	dptr
      004FF0 E0               [24]  486 	movx	a,@dptr
      004FF1 FE               [12]  487 	mov	r6,a
      004FF2 A3               [24]  488 	inc	dptr
      004FF3 E0               [24]  489 	movx	a,@dptr
      004FF4 FF               [12]  490 	mov	r7,a
      004FF5 90 05 8A         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004FF8 ED               [12]  492 	mov	a,r5
      004FF9 F0               [24]  493 	movx	@dptr,a
      004FFA EE               [12]  494 	mov	a,r6
      004FFB A3               [24]  495 	inc	dptr
      004FFC F0               [24]  496 	movx	@dptr,a
      004FFD EF               [12]  497 	mov	a,r7
      004FFE A3               [24]  498 	inc	dptr
      004FFF F0               [24]  499 	movx	@dptr,a
      005000 90 05 8D         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005003 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      005004                        505 _ak820_outline_0003:
      005004 E0               [24]  506 	movx	a,@dptr
      005005 FD               [12]  507 	mov	r5,a
      005006 A3               [24]  508 	inc	dptr
      005007 E0               [24]  509 	movx	a,@dptr
      005008 FE               [12]  510 	mov	r6,a
      005009 A3               [24]  511 	inc	dptr
      00500A E0               [24]  512 	movx	a,@dptr
      00500B FF               [12]  513 	mov	r7,a
      00500C 8D 82            [24]  514 	mov	dpl,r5
      00500E 8E 83            [24]  515 	mov	dph,r6
      005010 8F F0            [24]  516 	mov	b,r7
      005012 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0021
      005013                        521 _ak820_outline_0021:
      005013 E0               [24]  522 	movx	a,@dptr
      005014 FD               [12]  523 	mov	r5,a
      005015 A3               [24]  524 	inc	dptr
      005016 E0               [24]  525 	movx	a,@dptr
      005017 FE               [12]  526 	mov	r6,a
      005018 A3               [24]  527 	inc	dptr
      005019 E0               [24]  528 	movx	a,@dptr
      00501A FF               [12]  529 	mov	r7,a
      00501B 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0044
      00501C                        534 _ak820_outline_0044:
      00501C 8D 82            [24]  535 	mov	dpl,r5
      00501E 8E 83            [24]  536 	mov	dph,r6
      005020 8F F0            [24]  537 	mov	b,r7
      005022 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0049
      005023                        542 _ak820_outline_0049:
      005023 E4               [12]  543 	clr	a
      005024 F0               [24]  544 	movx	@dptr,a
      005025 A3               [24]  545 	inc	dptr
      005026 F0               [24]  546 	movx	@dptr,a
      005027 A3               [24]  547 	inc	dptr
      005028 F0               [24]  548 	movx	@dptr,a
      005029 A3               [24]  549 	inc	dptr
      00502A F0               [24]  550 	movx	@dptr,a
      00502B 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      00502C                        555 _ak820_outline_0054:
      00502C E0               [24]  556 	movx	a,@dptr
      00502D FC               [12]  557 	mov	r4,a
      00502E A3               [24]  558 	inc	dptr
      00502F E0               [24]  559 	movx	a,@dptr
      005030 FD               [12]  560 	mov	r5,a
      005031 A3               [24]  561 	inc	dptr
      005032 E0               [24]  562 	movx	a,@dptr
      005033 FE               [12]  563 	mov	r6,a
      005034 A3               [24]  564 	inc	dptr
      005035 E0               [24]  565 	movx	a,@dptr
      005036 8C 82            [24]  566 	mov	dpl,r4
      005038 8D 83            [24]  567 	mov	dph,r5
      00503A 8E F0            [24]  568 	mov	b,r6
      00503C 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      00503D                        573 _ak820_outline_0056:
      00503D AC 82            [24]  574 	mov	r4,dpl
      00503F AD 83            [24]  575 	mov	r5,dph
      005041 AE F0            [24]  576 	mov	r6,b
      005043 FF               [12]  577 	mov	r7,a
      005044 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0087
      005045                        582 _ak820_outline_0087:
      005045 E0               [24]  583 	movx	a,@dptr
      005046 F9               [12]  584 	mov	r1,a
      005047 A3               [24]  585 	inc	dptr
      005048 E0               [24]  586 	movx	a,@dptr
      005049 FA               [12]  587 	mov	r2,a
      00504A A3               [24]  588 	inc	dptr
      00504B E0               [24]  589 	movx	a,@dptr
      00504C FB               [12]  590 	mov	r3,a
      00504D 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0088
      00504E                        595 _ak820_outline_0088:
      00504E E0               [24]  596 	movx	a,@dptr
      00504F FE               [12]  597 	mov	r6,a
      005050 A3               [24]  598 	inc	dptr
      005051 E0               [24]  599 	movx	a,@dptr
      005052 8E 82            [24]  600 	mov	dpl,r6
      005054 F5 83            [12]  601 	mov	dph,a
      005056 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0107
      005057                        606 _ak820_outline_0107:
      005057 74 02            [12]  607 	mov	a,#0x02
      005059 F0               [24]  608 	movx	@dptr,a
      00505A E4               [12]  609 	clr	a
      00505B A3               [24]  610 	inc	dptr
      00505C F0               [24]  611 	movx	@dptr,a
      00505D 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0151
      00505E                        616 _ak820_outline_0151:
      00505E F0               [24]  617 	movx	@dptr,a
      00505F EA               [12]  618 	mov	a,r2
      005060 A3               [24]  619 	inc	dptr
      005061 F0               [24]  620 	movx	@dptr,a
      005062 EB               [12]  621 	mov	a,r3
      005063 A3               [24]  622 	inc	dptr
      005064 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0180
      005065                        627 _ak820_outline_0180:
      005065 E4               [12]  628 	clr	a
      005066 F0               [24]  629 	movx	@dptr,a
      005067 A3               [24]  630 	inc	dptr
      005068 F0               [24]  631 	movx	@dptr,a
      005069 22               [24]  632 	ret
