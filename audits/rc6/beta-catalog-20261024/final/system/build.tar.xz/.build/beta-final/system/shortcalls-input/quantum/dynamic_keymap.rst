                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000026                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000026                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ADA                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ADA                        628 	.ds 1
      000ADB                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000ADB                        630 	.ds 1
      000ADC                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000ADC                        632 	.ds 1
      000ADD                        633 _dynamic_keymap_get_keycode_PARM_2:
      000ADD                        634 	.ds 1
      000ADE                        635 _dynamic_keymap_get_keycode_PARM_3:
      000ADE                        636 	.ds 1
      000ADF                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000ADF                        638 	.ds 1
      000AE0                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AE0                        640 	.ds 1
      000AE1                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AE1                        642 	.ds 1
      000AE2                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AE2                        644 	.ds 2
      000AE4                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000AE4                        646 	.ds 1
      000AE5                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AE5                        648 	.ds 1
      000AE6                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000AE6                        650 	.ds 1
      000AE7                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE7                        652 	.ds 1
      000AE8                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AE8                        654 	.ds 1
      000AE9                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AE9                        656 	.ds 1
      000AEA                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AEA                        658 	.ds 1
      000AEB                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AEB                        660 	.ds 1
      000AEC                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AEC                        662 	.ds 2
      000AEE                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AEE                        664 	.ds 1
      000AEF                        665 _dynamic_keymap_get_combo_PARM_2:
      000AEF                        666 	.ds 3
      000AF2                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AF2                        668 	.ds 1
      000AF3                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF3                        670 	.ds 3
      000AF6                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AF6                        672 	.ds 1
      000AF7                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AF7                        674 	.ds 10
      000B01                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B01                        676 	.ds 1
      000B02                        677 _dynamic_keymap_reset_combo_10001_408:
      000B02                        678 	.ds 10
      000B0C                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B0C                        680 	.ds 2
      000B0E                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B0E                        682 	.ds 2
      000B10                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B10                        684 	.ds 2
      000B12                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B12                        686 	.ds 3
      000B15                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B15                        688 	.ds 2
      000B17                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B17                        690 	.ds 1
      000B18                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B18                        692 	.ds 2
      000B1A                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B1A                        694 	.ds 3
      000B1D                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B1D                        696 	.ds 2
      000B1F                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B1F                        698 	.ds 2
      000B21                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B21                        700 	.ds 3
      000B24                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B24                        702 	.ds 2
      000B26                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B26                        704 	.ds 1
      000B27                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B27                        706 	.ds 1
      000B28                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B28                        708 	.ds 1
      000B29                        709 _keycode_at_keymap_location_PARM_2:
      000B29                        710 	.ds 1
      000B2A                        711 _keycode_at_keymap_location_PARM_3:
      000B2A                        712 	.ds 1
      000B2B                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B2B                        714 	.ds 1
      000B2C                        715 _keycode_at_encodermap_location_PARM_2:
      000B2C                        716 	.ds 1
      000B2D                        717 _keycode_at_encodermap_location_PARM_3:
      000B2D                        718 	.ds 1
      000B2E                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B2E                        720 	.ds 1
      000B2F                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B2F                        722 	.ds 2
      000B31                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B31                        724 	.ds 3
      000B34                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B34                        726 	.ds 2
      000B36                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B36                        728 	.ds 2
      000B38                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B38                        730 	.ds 3
      000B3B                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B3B                        732 	.ds 2
      000B3D                        733 _decode_keycode_kc_10000_455:
      000B3D                        734 	.ds 2
      000B3F                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B3F                        736 	.ds 1
      000B40                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B40                        738 	.ds 1
      000B41                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B41                        740 	.ds 2
      000B43                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B43                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008622                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008622 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008625 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008626                        810 _dynamic_keymap_key_to_eeprom_address:
      008626 E5 82            [12]  811 	mov	a,dpl
      008628 90 0A DC         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      00862B F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00862C E0               [24]  815 	movx	a,@dptr
      00862D FF               [12]  816 	mov	r7,a
      00862E 7E 00            [12]  817 	mov	r6,#0x00
      008630 74 40            [12]  818 	mov	a,#0x40
      008632 12 43 9D         [24]  819 	lcall	_ak820_outline_0134
      008635 7D 00            [12]  820 	mov	r5,#0x00
      008637 90 0A DA         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00863A E0               [24]  822 	movx	a,@dptr
      00863B 75 F0 10         [24]  823 	mov	b,#0x10
      00863E A4               [48]  824 	mul	ab
      00863F 2E               [12]  825 	add	a, r6
      008640 FE               [12]  826 	mov	r6,a
      008641 EF               [12]  827 	mov	a,r7
      008642 35 F0            [12]  828 	addc	a, b
      008644 FF               [12]  829 	mov	r7,a
      008645 90 0A DB         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008648 E0               [24]  831 	movx	a,@dptr
      008649 7C 00            [12]  832 	mov	r4,#0x00
      00864B 25 E0            [12]  833 	add	a,acc
      00864D FB               [12]  834 	mov	r3,a
      00864E EC               [12]  835 	mov	a,r4
      00864F 33               [12]  836 	rlc	a
      008650 FC               [12]  837 	mov	r4,a
      008651 EB               [12]  838 	mov	a,r3
      008652 2E               [12]  839 	add	a, r6
      008653 FE               [12]  840 	mov	r6,a
      008654 EC               [12]  841 	mov	a,r4
      008655 3F               [12]  842 	addc	a, r7
      008656 FF               [12]  843 	mov	r7,a
      008657 12 43 8D         [24]  844 	lcall	_ak820_outline_0117
      00865A 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      00865C 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      00865D                        861 _dynamic_keymap_get_keycode:
      00865D E5 82            [12]  862 	mov	a,dpl
      00865F 90 0A DF         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      008662 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008663 E0               [24]  866 	movx	a,@dptr
      008664 FF               [12]  867 	mov	r7,a
      008665 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008668                        869 00121$:
      008668 50 14            [24]  870 	jnc	00101$
      00866A 90 0A DD         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00866D E0               [24]  872 	movx	a,@dptr
      00866E FE               [12]  873 	mov	r6,a
      00866F BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008672                        875 00123$:
      008672 50 0A            [24]  876 	jnc	00101$
      008674 90 0A DE         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008677 E0               [24]  878 	movx	a,@dptr
      008678 FD               [12]  879 	mov	r5,a
      008679 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      00867C                        881 00125$:
      00867C 40 04            [24]  882 	jc	00102$
      00867E                        883 00101$:
      00867E 90 00 00         [24]  884 	mov	dptr,#0x0000
      008681 22               [24]  885 	ret
      008682                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008682 12 90 D4         [24]  888 	lcall	_ak820_outline_0095
      008685 12 86 26         [24]  889 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008688 12 90 E1         [24]  891 	lcall	_ak820_outline_0113
      00868B 12 40 AC         [24]  892 	lcall	_eeprom_read_byte
      00868E AB 82            [24]  893 	mov	r3,dpl
      008690 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008692 0D               [12]  896 	inc	r5
      008693 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008696 0E               [12]  898 	inc	r6
      008697                        899 00127$:
      008697 12 50 1C         [24]  900 	lcall	_ak820_outline_0044
      00869A 12 40 AC         [24]  901 	lcall	_eeprom_read_byte
      00869D AF 82            [24]  902 	mov	r7, dpl
      00869F 7E 00            [12]  903 	mov	r6,#0x00
      0086A1 EF               [12]  904 	mov	a,r7
      0086A2 42 04            [12]  905 	orl	ar4,a
      0086A4 EE               [12]  906 	mov	a,r6
      0086A5 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      0086A7 12 43 C9         [24]  909 	lcall	_ak820_outline_0182
                                    910 ;	quantum/dynamic_keymap.c:215: }
      0086AA 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      0086AB                        925 _dynamic_keymap_set_keycode:
      0086AB E5 82            [12]  926 	mov	a,dpl
      0086AD 90 0A E4         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      0086B0 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0086B1 E0               [24]  930 	movx	a,@dptr
      0086B2 FF               [12]  931 	mov	r7,a
      0086B3 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      0086B6                        933 00121$:
      0086B6 50 14            [24]  934 	jnc	00101$
      0086B8 90 0A E0         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0086BB E0               [24]  936 	movx	a,@dptr
      0086BC FE               [12]  937 	mov	r6,a
      0086BD BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      0086C0                        939 00123$:
      0086C0 50 0A            [24]  940 	jnc	00101$
      0086C2 90 0A E1         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0086C5 E0               [24]  942 	movx	a,@dptr
      0086C6 FD               [12]  943 	mov	r5,a
      0086C7 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      0086CA                        945 00125$:
      0086CA 40 01            [24]  946 	jc	00102$
      0086CC                        947 00101$:
      0086CC 22               [24]  948 	ret
      0086CD                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0086CD 12 90 D4         [24]  951 	lcall	_ak820_outline_0095
      0086D0 12 86 26         [24]  952 	lcall	_dynamic_keymap_key_to_eeprom_address
      0086D3 12 90 E1         [24]  953 	lcall	_ak820_outline_0113
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0086D6 90 0A E2         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0086D9 E0               [24]  956 	movx	a,@dptr
      0086DA FB               [12]  957 	mov	r3,a
      0086DB A3               [24]  958 	inc	dptr
      0086DC E0               [24]  959 	movx	a,@dptr
      0086DD 90 06 9F         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      0086E0 F0               [24]  961 	movx	@dptr,a
      0086E1 12 50 1C         [24]  962 	lcall	_ak820_outline_0044
      0086E4 12 4F 06         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0086E7 0D               [12]  965 	inc	r5
      0086E8 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      0086EB 0E               [12]  967 	inc	r6
      0086EC                        968 00127$:
      0086EC 90 06 9F         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      0086EF EB               [12]  970 	mov	a,r3
      0086F0 F0               [24]  971 	movx	@dptr,a
      0086F1 12 50 1C         [24]  972 	lcall	_ak820_outline_0044
                                    973 ;	quantum/dynamic_keymap.c:223: }
      0086F4 02 4F 06         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      0086F7                        985 _dynamic_keymap_encoder_to_eeprom_address:
      0086F7 E5 82            [12]  986 	mov	a,dpl
      0086F9 90 0A E6         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      0086FC F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0086FD E0               [24]  990 	movx	a,@dptr
      0086FE 75 F0 04         [24]  991 	mov	b,#0x04
      008701 A4               [48]  992 	mul	ab
      008702 24 40            [12]  993 	add	a, #0x40
      008704 FD               [12]  994 	mov	r5,a
      008705 74 06            [12]  995 	mov	a,#0x06
      008707 35 F0            [12]  996 	addc	a, b
      008709 FE               [12]  997 	mov	r6,a
      00870A 7F 00            [12]  998 	mov	r7,#0x00
      00870C 90 0A E5         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00870F E0               [24] 1000 	movx	a,@dptr
      008710 75 F0 04         [24] 1001 	mov	b,#0x04
      008713 A4               [48] 1002 	mul	ab
      008714 2D               [12] 1003 	add	a, r5
      008715 FD               [12] 1004 	mov	r5,a
      008716 EE               [12] 1005 	mov	a,r6
      008717 35 F0            [12] 1006 	addc	a, b
      008719 FE               [12] 1007 	mov	r6,a
      00871A 12 50 1C         [24] 1008 	lcall	_ak820_outline_0044
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      00871D 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      00871E                       1024 _dynamic_keymap_get_encoder:
      00871E E5 82            [12] 1025 	mov	a,dpl
      008720 90 0A E9         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008723 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008724 E0               [24] 1029 	movx	a,@dptr
      008725 FF               [12] 1030 	mov	r7,a
      008726 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008729                       1032 00131$:
      008729 50 0A            [24] 1033 	jnc	00101$
      00872B 90 0A E7         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00872E E0               [24] 1035 	movx	a,@dptr
      00872F FE               [12] 1036 	mov	r6,a
      008730 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008733                       1038 00133$:
      008733 40 04            [24] 1039 	jc	00102$
      008735                       1040 00101$:
      008735 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008738 22               [24] 1042 	ret
      008739                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008739 90 0A E5         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00873C E4               [12] 1046 	clr	a
      00873D F0               [24] 1047 	movx	@dptr,a
      00873E 8F 82            [24] 1048 	mov	dpl, r7
      008740 12 86 F7         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008743 12 90 E1         [24] 1050 	lcall	_ak820_outline_0113
                                   1051 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008746 90 0A E8         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008749 E0               [24] 1053 	movx	a,@dptr
      00874A FC               [12] 1054 	mov	r4,a
      00874B E0               [24] 1055 	movx	a,@dptr
      00874C 60 04            [24] 1056 	jz	00106$
      00874E 7B 00            [12] 1057 	mov	r3,#0x00
      008750 80 02            [24] 1058 	sjmp	00107$
      008752                       1059 00106$:
      008752 7B 02            [12] 1060 	mov	r3,#0x02
      008754                       1061 00107$:
      008754 EB               [12] 1062 	mov	a,r3
      008755 12 90 B2         [24] 1063 	lcall	_ak820_outline_0025
      008758 12 40 AC         [24] 1064 	lcall	_eeprom_read_byte
      00875B AA 82            [24] 1065 	mov	r2,dpl
      00875D 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00875F EC               [12] 1068 	mov	a,r4
      008760 60 04            [24] 1069 	jz	00108$
      008762 7C 00            [12] 1070 	mov	r4,#0x00
      008764 80 02            [24] 1071 	sjmp	00109$
      008766                       1072 00108$:
      008766 7C 02            [12] 1073 	mov	r4,#0x02
      008768                       1074 00109$:
      008768 EC               [12] 1075 	mov	a,r4
      008769 12 38 7A         [24] 1076 	lcall	_ak820_outline_0155
      00876C 0D               [12] 1077 	inc	r5
      00876D BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      008770 0E               [12] 1079 	inc	r6
      008771                       1080 00137$:
      008771 12 50 1C         [24] 1081 	lcall	_ak820_outline_0044
      008774 12 40 AC         [24] 1082 	lcall	_eeprom_read_byte
      008777 AF 82            [24] 1083 	mov	r7, dpl
      008779 7E 00            [12] 1084 	mov	r6,#0x00
      00877B EF               [12] 1085 	mov	a,r7
      00877C 42 03            [12] 1086 	orl	ar3,a
      00877E EE               [12] 1087 	mov	a,r6
      00877F 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:236: return keycode;
      008781 8B 82            [24] 1090 	mov	dpl, r3
      008783 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:237: }
      008785 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008786                       1108 _dynamic_keymap_set_encoder:
      008786 E5 82            [12] 1109 	mov	a,dpl
      008788 90 0A EE         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      00878B F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00878C E0               [24] 1113 	movx	a,@dptr
      00878D FF               [12] 1114 	mov	r7,a
      00878E BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      008791                       1116 00131$:
      008791 50 0A            [24] 1117 	jnc	00101$
      008793 90 0A EA         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008796 E0               [24] 1119 	movx	a,@dptr
      008797 FE               [12] 1120 	mov	r6,a
      008798 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      00879B                       1122 00133$:
      00879B 40 01            [24] 1123 	jc	00102$
      00879D                       1124 00101$:
      00879D 22               [24] 1125 	ret
      00879E                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00879E 90 0A E5         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0087A1 E4               [12] 1129 	clr	a
      0087A2 F0               [24] 1130 	movx	@dptr,a
      0087A3 8F 82            [24] 1131 	mov	dpl, r7
      0087A5 12 86 F7         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0087A8 12 90 E1         [24] 1133 	lcall	_ak820_outline_0113
                                   1134 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0087AB 90 0A EB         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0087AE E0               [24] 1136 	movx	a,@dptr
      0087AF FC               [12] 1137 	mov	r4,a
      0087B0 E0               [24] 1138 	movx	a,@dptr
      0087B1 60 04            [24] 1139 	jz	00106$
      0087B3 7B 00            [12] 1140 	mov	r3,#0x00
      0087B5 80 02            [24] 1141 	sjmp	00107$
      0087B7                       1142 00106$:
      0087B7 7B 02            [12] 1143 	mov	r3,#0x02
      0087B9                       1144 00107$:
      0087B9 EB               [12] 1145 	mov	a,r3
      0087BA 12 90 F3         [24] 1146 	lcall	_ak820_outline_0133
      0087BD 8F 03            [24] 1147 	mov	ar3,r7
      0087BF 90 0A EC         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0087C2 E0               [24] 1149 	movx	a,@dptr
      0087C3 F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0087C5 A3               [24] 1151 	inc	dptr
      0087C6 E0               [24] 1152 	movx	a,@dptr
      0087C7 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0087C9 90 06 9F         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      0087CC F0               [24] 1155 	movx	@dptr,a
      0087CD 12 43 C4         [24] 1156 	lcall	_ak820_outline_0181
      0087D0 8B F0            [24] 1157 	mov	b, r3
      0087D2 12 4F 06         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0087D5 EC               [12] 1160 	mov	a,r4
      0087D6 60 04            [24] 1161 	jz	00108$
      0087D8 7C 00            [12] 1162 	mov	r4,#0x00
      0087DA 80 02            [24] 1163 	sjmp	00109$
      0087DC                       1164 00108$:
      0087DC 7C 02            [12] 1165 	mov	r4,#0x02
      0087DE                       1166 00109$:
      0087DE EC               [12] 1167 	mov	a,r4
      0087DF 12 38 7A         [24] 1168 	lcall	_ak820_outline_0155
      0087E2 0D               [12] 1169 	inc	r5
      0087E3 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0087E6 0E               [12] 1171 	inc	r6
      0087E7                       1172 00137$:
      0087E7 90 06 9F         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      0087EA E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0087EC F0               [24] 1175 	movx	@dptr,a
      0087ED 12 50 1C         [24] 1176 	lcall	_ak820_outline_0044
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      0087F0 02 4F 06         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      0087F3                       1193 _dynamic_keymap_get_combo:
      0087F3 E5 82            [12] 1194 	mov	a,dpl
      0087F5 90 0A F2         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      0087F8 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0087F9 90 0A EF         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0087FC 12 38 00         [24] 1199 	lcall	_ak820_outline_0051
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      0087FF 90 0A F2         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008802 E0               [24] 1202 	movx	a,@dptr
      008803 FD               [12] 1203 	mov	r5,a
      008804 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      008807                       1205 00132$:
      008807 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      008809 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      00880C 22               [24] 1209 	ret
      00880D                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00880D 12 90 C0         [24] 1212 	lcall	_ak820_outline_0078
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008810 8E 02            [24] 1214 	mov	ar2,r6
      008812 8F 03            [24] 1215 	mov	ar3,r7
      008814 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008817 12 38 25         [24] 1217 	lcall	_ak820_outline_0071
      00881A E4               [12] 1218 	clr	a
      00881B A3               [24] 1219 	inc	dptr
      00881C F0               [24] 1220 	movx	@dptr,a
      00881D 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008820 74 0A            [12] 1222 	mov	a,#0x0a
      008822 12 38 65         [24] 1223 	lcall	_ak820_outline_0123
      008825 12 43 A9         [24] 1224 	lcall	_ak820_outline_0140
      008828 C0 07            [24] 1225 	push	ar7
      00882A C0 06            [24] 1226 	push	ar6
      00882C 12 40 E7         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      00882F D0 06            [24] 1228 	pop	ar6
      008831 D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008833 74 04            [12] 1231 	mov	a,#0x04
      008835 12 49 67         [24] 1232 	lcall	_ak820_outline_0012
      008838 FA               [12] 1233 	mov	r2,a
      008839 A3               [24] 1234 	inc	dptr
      00883A E0               [24] 1235 	movx	a,@dptr
      00883B FB               [12] 1236 	mov	r3,a
      00883C BA 20 14         [24] 1237 	cjne	r2,#0x20,00108$
      00883F BB 08 11         [24] 1238 	cjne	r3,#0x08,00108$
      008842 74 06            [12] 1239 	mov	a,#0x06
      008844 12 37 E7         [24] 1240 	lcall	_ak820_outline_0017
      008847 FA               [12] 1241 	mov	r2,a
      008848 A3               [24] 1242 	inc	dptr
      008849 E0               [24] 1243 	movx	a,@dptr
      00884A FB               [12] 1244 	mov	r3,a
      00884B BA 01 05         [24] 1245 	cjne	r2,#0x01,00136$
      00884E BB 00 02         [24] 1246 	cjne	r3,#0x00,00136$
      008851 80 05            [24] 1247 	sjmp	00109$
      008853                       1248 00136$:
      008853                       1249 00108$:
      008853 75 2B 00         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008856 80 03            [24] 1251 	sjmp	00110$
      008858                       1252 00109$:
      008858 75 2B 01         [24] 1253 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      00885B                       1254 00110$:
                                   1255 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      00885B 74 06            [12] 1256 	mov	a,#0x06
      00885D 12 37 F0         [24] 1257 	lcall	_ak820_outline_0031
      008860 E4               [12] 1258 	clr	a
      008861 F0               [24] 1259 	movx	@dptr,a
      008862 A3               [24] 1260 	inc	dptr
      008863 12 38 31         [24] 1261 	lcall	_ak820_outline_0096
      008866 F0               [24] 1262 	movx	@dptr,a
      008867 A3               [24] 1263 	inc	dptr
      008868 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008869 E5 2B            [12] 1266 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      00886B 60 12            [24] 1267 	jz	00103$
      00886D 12 43 8D         [24] 1268 	lcall	_ak820_outline_0117
      008870 C0 07            [24] 1269 	push	ar7
      008872 C0 06            [24] 1270 	push	ar6
      008874 12 34 68         [24] 1271 	lcall	_ak820_combo_valid
      008877 E5 82            [12] 1272 	mov	a, dpl
      008879 D0 06            [24] 1273 	pop	ar6
      00887B D0 07            [24] 1274 	pop	ar7
      00887D 70 17            [24] 1275 	jnz	00104$
      00887F                       1276 00103$:
      00887F 7D 00            [12] 1277 	mov	r5,#0x00
      008881 90 0D 84         [24] 1278 	mov	dptr,#_memset_PARM_2
      008884 E4               [12] 1279 	clr	a
      008885 F0               [24] 1280 	movx	@dptr,a
      008886 90 0D 85         [24] 1281 	mov	dptr,#_memset_PARM_3
      008889 74 0A            [12] 1282 	mov	a,#0x0a
      00888B F0               [24] 1283 	movx	@dptr,a
      00888C E4               [12] 1284 	clr	a
      00888D A3               [24] 1285 	inc	dptr
      00888E 12 43 6F         [24] 1286 	lcall	_ak820_outline_0061
      008891 8D F0            [24] 1287 	mov	b, r5
      008893 12 BA 01         [24] 1288 	lcall	_memset
      008896                       1289 00104$:
                                   1290 ;	quantum/dynamic_keymap.c:329: return 0;
      008896 90 00 00         [24] 1291 	mov	dptr,#0x0000
                                   1292 ;	quantum/dynamic_keymap.c:330: }
      008899 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1296 ;------------------------------------------------------------
                                   1297 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1298 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1299 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1300 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1301 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function dynamic_keymap_set_combo
                                   1306 ;	-----------------------------------------
      00889A                       1307 _dynamic_keymap_set_combo:
      00889A E5 82            [12] 1308 	mov	a,dpl
      00889C 90 0A F6         [24] 1309 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      00889F F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0088A0 90 0A F3         [24] 1312 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0088A3 12 37 A0         [24] 1313 	lcall	_ak820_outline_0004
                                   1314 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0088A6 C0 07            [24] 1315 	push	ar7
      0088A8 C0 06            [24] 1316 	push	ar6
      0088AA 12 34 68         [24] 1317 	lcall	_ak820_combo_valid
      0088AD E5 82            [12] 1318 	mov	a, dpl
      0088AF D0 06            [24] 1319 	pop	ar6
      0088B1 D0 07            [24] 1320 	pop	ar7
      0088B3 60 07            [24] 1321 	jz	00101$
      0088B5 12 3E 53         [24] 1322 	lcall	_ak820_nvm_ok
      0088B8 E5 82            [12] 1323 	mov	a, dpl
      0088BA 70 04            [24] 1324 	jnz	00102$
      0088BC                       1325 00101$:
      0088BC 90 FF FF         [24] 1326 	mov	dptr,#0xffff
      0088BF 22               [24] 1327 	ret
      0088C0                       1328 00102$:
                                   1329 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      0088C0 90 0A F6         [24] 1330 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0088C3 E0               [24] 1331 	movx	a,@dptr
      0088C4 FD               [12] 1332 	mov	r5,a
      0088C5 BD 08 00         [24] 1333 	cjne	r5,#0x08,00133$
      0088C8                       1334 00133$:
      0088C8 40 04            [24] 1335 	jc	00105$
                                   1336 ;	quantum/dynamic_keymap.c:342: return -1;
      0088CA 90 FF FF         [24] 1337 	mov	dptr,#0xffff
      0088CD 22               [24] 1338 	ret
      0088CE                       1339 00105$:
                                   1340 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0088CE 12 90 C0         [24] 1341 	lcall	_ak820_outline_0078
                                   1342 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      0088D1 C0 07            [24] 1343 	push	ar7
      0088D3 C0 06            [24] 1344 	push	ar6
      0088D5 C0 05            [24] 1345 	push	ar5
      0088D7 C0 04            [24] 1346 	push	ar4
      0088D9 12 78 1B         [24] 1347 	lcall	_clear_keyboard
      0088DC D0 04            [24] 1348 	pop	ar4
      0088DE D0 05            [24] 1349 	pop	ar5
      0088E0 D0 06            [24] 1350 	pop	ar6
      0088E2 D0 07            [24] 1351 	pop	ar7
                                   1352 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0088E4 90 0D 7C         [24] 1353 	mov	dptr,#___memcpy_PARM_2
      0088E7 12 49 C0         [24] 1354 	lcall	_ak820_outline_0059
      0088EA E4               [12] 1355 	clr	a
      0088EB A3               [24] 1356 	inc	dptr
      0088EC F0               [24] 1357 	movx	@dptr,a
      0088ED 90 0D 7F         [24] 1358 	mov	dptr,#___memcpy_PARM_3
      0088F0 74 0A            [12] 1359 	mov	a,#0x0a
      0088F2 12 38 65         [24] 1360 	lcall	_ak820_outline_0123
      0088F5 90 0A F7         [24] 1361 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      0088F8 F5 F0            [12] 1362 	mov	b,a
      0088FA C0 05            [24] 1363 	push	ar5
      0088FC C0 04            [24] 1364 	push	ar4
      0088FE 12 B9 8B         [24] 1365 	lcall	___memcpy
      008901 D0 04            [24] 1366 	pop	ar4
      008903 D0 05            [24] 1367 	pop	ar5
                                   1368 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008905 90 0A FB         [24] 1369 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008908 74 20            [12] 1370 	mov	a,#0x20
      00890A F0               [24] 1371 	movx	@dptr,a
      00890B 74 08            [12] 1372 	mov	a,#0x08
      00890D A3               [24] 1373 	inc	dptr
      00890E F0               [24] 1374 	movx	@dptr,a
                                   1375 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      00890F 90 0A FD         [24] 1376 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008912 74 01            [12] 1377 	mov	a,#0x01
      008914 12 38 65         [24] 1378 	lcall	_ak820_outline_0123
                                   1379 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008917 90 05 8A         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00891A 12 38 25         [24] 1381 	lcall	_ak820_outline_0071
      00891D E4               [12] 1382 	clr	a
      00891E A3               [24] 1383 	inc	dptr
      00891F F0               [24] 1384 	movx	@dptr,a
      008920 90 05 8D         [24] 1385 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008923 74 0A            [12] 1386 	mov	a,#0x0a
      008925 12 38 65         [24] 1387 	lcall	_ak820_outline_0123
      008928 90 0A F7         [24] 1388 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00892B 12 41 73         [24] 1389 	lcall	_ak820_eeprom_write_block_xdata
                                   1390 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      00892E 12 3E 62         [24] 1391 	lcall	_ak820_nvm_flush
                                   1392 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008931 12 3E 53         [24] 1393 	lcall	_ak820_nvm_ok
      008934 E5 82            [12] 1394 	mov	a, dpl
      008936 70 04            [24] 1395 	jnz	00107$
      008938 90 FF FF         [24] 1396 	mov	dptr,#0xffff
      00893B 22               [24] 1397 	ret
      00893C                       1398 00107$:
                                   1399 ;	quantum/dynamic_keymap.c:360: return 0;
      00893C 90 00 00         [24] 1400 	mov	dptr,#0x0000
                                   1401 ;	quantum/dynamic_keymap.c:361: }
      00893F 22               [24] 1402 	ret
                                   1403 ;------------------------------------------------------------
                                   1404 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1405 ;------------------------------------------------------------
                                   1406 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1407 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1408 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1409 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1410 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1411 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1412 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function dynamic_keymap_reset
                                   1417 ;	-----------------------------------------
      008940                       1418 _dynamic_keymap_reset:
                                   1419 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008940 90 0D FC         [24] 1420 	mov	dptr,#_vial_unlocked
      008943 E0               [24] 1421 	movx	a,@dptr
      008944 90 0B 01         [24] 1422 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008947 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008948 90 0D FC         [24] 1425 	mov	dptr,#_vial_unlocked
      00894B 74 01            [12] 1426 	mov	a,#0x01
      00894D F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00894E 7F 00            [12] 1429 	mov	r7,#0x00
      008950                       1430 00116$:
      008950 BF 06 00         [24] 1431 	cjne	r7,#0x06,00198$
      008953                       1432 00198$:
      008953 40 03            [24] 1433 	jc	00199$
      008955 02 8A 03         [24] 1434 	ljmp	00104$
      008958                       1435 00199$:
                                   1436 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008958 7E 00            [12] 1437 	mov	r6,#0x00
      00895A                       1438 00110$:
      00895A BE 10 00         [24] 1439 	cjne	r6,#0x10,00200$
      00895D                       1440 00200$:
      00895D 50 4D            [24] 1441 	jnc	00102$
                                   1442 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00895F 7D 00            [12] 1443 	mov	r5,#0x00
      008961                       1444 00107$:
      008961 BD 08 00         [24] 1445 	cjne	r5,#0x08,00202$
      008964                       1446 00202$:
      008964 50 43            [24] 1447 	jnc	00111$
                                   1448 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008966 90 0B 9D         [24] 1449 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008969 EE               [12] 1450 	mov	a,r6
      00896A F0               [24] 1451 	movx	@dptr,a
      00896B 90 0B 9E         [24] 1452 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      00896E ED               [12] 1453 	mov	a,r5
      00896F F0               [24] 1454 	movx	@dptr,a
      008970 8F 82            [24] 1455 	mov	dpl, r7
      008972 C0 07            [24] 1456 	push	ar7
      008974 C0 06            [24] 1457 	push	ar6
      008976 C0 05            [24] 1458 	push	ar5
      008978 12 99 09         [24] 1459 	lcall	_keycode_at_keymap_location_raw
      00897B AB 82            [24] 1460 	mov	r3, dpl
      00897D AC 83            [24] 1461 	mov	r4, dph
      00897F D0 05            [24] 1462 	pop	ar5
      008981 D0 06            [24] 1463 	pop	ar6
      008983 D0 07            [24] 1464 	pop	ar7
      008985 90 0A E0         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008988 EE               [12] 1466 	mov	a,r6
      008989 F0               [24] 1467 	movx	@dptr,a
      00898A 90 0A E1         [24] 1468 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00898D ED               [12] 1469 	mov	a,r5
      00898E F0               [24] 1470 	movx	@dptr,a
      00898F 90 0A E2         [24] 1471 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008992 12 38 2B         [24] 1472 	lcall	_ak820_outline_0076
      008995 8F 82            [24] 1473 	mov	dpl, r7
      008997 C0 07            [24] 1474 	push	ar7
      008999 C0 06            [24] 1475 	push	ar6
      00899B C0 05            [24] 1476 	push	ar5
      00899D 12 86 AB         [24] 1477 	lcall	_dynamic_keymap_set_keycode
      0089A0 D0 05            [24] 1478 	pop	ar5
      0089A2 D0 06            [24] 1479 	pop	ar6
      0089A4 D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0089A6 0D               [12] 1482 	inc	r5
      0089A7 80 B8            [24] 1483 	sjmp	00107$
      0089A9                       1484 00111$:
                                   1485 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0089A9 0E               [12] 1486 	inc	r6
      0089AA 80 AE            [24] 1487 	sjmp	00110$
      0089AC                       1488 00102$:
                                   1489 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0089AC 7E 00            [12] 1490 	mov	r6,#0x00
      0089AE                       1491 00113$:
      0089AE BE 01 00         [24] 1492 	cjne	r6,#0x01,00204$
      0089B1                       1493 00204$:
      0089B1 50 4C            [24] 1494 	jnc	00117$
                                   1495 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0089B3 12 91 0F         [24] 1496 	lcall	_ak820_outline_0176
      0089B6 04               [12] 1497 	inc	a
      0089B7 F0               [24] 1498 	movx	@dptr,a
      0089B8 8F 82            [24] 1499 	mov	dpl, r7
      0089BA C0 07            [24] 1500 	push	ar7
      0089BC 12 99 4E         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      0089BF 12 43 AE         [24] 1502 	lcall	_ak820_outline_0145
      0089C2 D0 07            [24] 1503 	pop	ar7
      0089C4 12 91 06         [24] 1504 	lcall	_ak820_outline_0175
      0089C7 04               [12] 1505 	inc	a
      0089C8 F0               [24] 1506 	movx	@dptr,a
      0089C9 90 0A EC         [24] 1507 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0089CC 12 38 25         [24] 1508 	lcall	_ak820_outline_0071
      0089CF 8F 82            [24] 1509 	mov	dpl, r7
      0089D1 C0 07            [24] 1510 	push	ar7
      0089D3 12 87 86         [24] 1511 	lcall	_dynamic_keymap_set_encoder
      0089D6 D0 07            [24] 1512 	pop	ar7
                                   1513 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0089D8 12 91 0F         [24] 1514 	lcall	_ak820_outline_0176
      0089DB F0               [24] 1515 	movx	@dptr,a
      0089DC 8F 82            [24] 1516 	mov	dpl, r7
      0089DE C0 07            [24] 1517 	push	ar7
      0089E0 12 99 4E         [24] 1518 	lcall	_keycode_at_encodermap_location_raw
      0089E3 12 43 AE         [24] 1519 	lcall	_ak820_outline_0145
      0089E6 D0 07            [24] 1520 	pop	ar7
      0089E8 12 91 06         [24] 1521 	lcall	_ak820_outline_0175
      0089EB F0               [24] 1522 	movx	@dptr,a
      0089EC 90 0A EC         [24] 1523 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0089EF 12 38 25         [24] 1524 	lcall	_ak820_outline_0071
      0089F2 8F 82            [24] 1525 	mov	dpl, r7
      0089F4 C0 07            [24] 1526 	push	ar7
      0089F6 12 87 86         [24] 1527 	lcall	_dynamic_keymap_set_encoder
      0089F9 D0 07            [24] 1528 	pop	ar7
                                   1529 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0089FB 7E 01            [12] 1530 	mov	r6,#0x01
      0089FD 80 AF            [24] 1531 	sjmp	00113$
      0089FF                       1532 00117$:
                                   1533 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0089FF 0F               [12] 1534 	inc	r7
      008A00 02 89 50         [24] 1535 	ljmp	00116$
      008A03                       1536 00104$:
                                   1537 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008A03 90 0B 02         [24] 1538 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008A06 12 50 65         [24] 1539 	lcall	_ak820_outline_0180
      008A09 90 0B 04         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008A0C F0               [24] 1541 	movx	@dptr,a
      008A0D A3               [24] 1542 	inc	dptr
      008A0E F0               [24] 1543 	movx	@dptr,a
      008A0F 90 0B 06         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008A12 F0               [24] 1545 	movx	@dptr,a
      008A13 A3               [24] 1546 	inc	dptr
      008A14 F0               [24] 1547 	movx	@dptr,a
      008A15 90 0B 08         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008A18 F0               [24] 1549 	movx	@dptr,a
      008A19 A3               [24] 1550 	inc	dptr
      008A1A F0               [24] 1551 	movx	@dptr,a
      008A1B 90 0B 0A         [24] 1552 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008A1E F0               [24] 1553 	movx	@dptr,a
      008A1F A3               [24] 1554 	inc	dptr
      008A20 F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008A21 FF               [12] 1557 	mov	r7,a
      008A22                       1558 00119$:
      008A22 BF 08 00         [24] 1559 	cjne	r7,#0x08,00206$
      008A25                       1560 00206$:
      008A25 50 17            [24] 1561 	jnc	00105$
                                   1562 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008A27 90 0A F3         [24] 1563 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A2A 74 02            [12] 1564 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008A2C F0               [24] 1565 	movx	@dptr,a
      008A2D 74 0B            [12] 1566 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008A2F 12 38 5A         [24] 1567 	lcall	_ak820_outline_0118
      008A32 8F 82            [24] 1568 	mov	dpl, r7
      008A34 C0 07            [24] 1569 	push	ar7
      008A36 12 88 9A         [24] 1570 	lcall	_dynamic_keymap_set_combo
      008A39 D0 07            [24] 1571 	pop	ar7
                                   1572 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008A3B 0F               [12] 1573 	inc	r7
      008A3C 80 E4            [24] 1574 	sjmp	00119$
      008A3E                       1575 00105$:
                                   1576 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008A3E 90 0B 01         [24] 1577 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008A41 E0               [24] 1578 	movx	a,@dptr
      008A42 90 0D FC         [24] 1579 	mov	dptr,#_vial_unlocked
      008A45 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/dynamic_keymap.c:468: }
      008A46 22               [24] 1582 	ret
                                   1583 ;------------------------------------------------------------
                                   1584 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1585 ;------------------------------------------------------------
                                   1586 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1587 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1588 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1589 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1590 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1591 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1592 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1593 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1594 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1595 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1596 ;------------------------------------------------------------
                                   1597 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1598 ;	-----------------------------------------
                                   1599 ;	 function ak820_dynamic_read_buffer
                                   1600 ;	-----------------------------------------
      008A47                       1601 _ak820_dynamic_read_buffer:
      008A47 12 38 49         [24] 1602 	lcall	_ak820_outline_0104
      008A4A 90 0B 15         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008A4D 12 38 4E         [24] 1604 	lcall	_ak820_outline_0105
                                   1605 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008A50 90 0B 12         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008A53 12 38 00         [24] 1607 	lcall	_ak820_outline_0051
                                   1608 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008A56 90 0B 17         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A59 E4               [12] 1610 	clr	a
      008A5A F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008A5B 90 0B 10         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008A5E 12 38 1F         [24] 1614 	lcall	_ak820_outline_0060
      008A61 8C 02            [24] 1615 	mov	ar2,r4
      008A63 8D 03            [24] 1616 	mov	ar3,r5
      008A65 C3               [12] 1617 	clr	c
      008A66 74 1C            [12] 1618 	mov	a,#0x1c
      008A68 9A               [12] 1619 	subb	a,r2
      008A69 E4               [12] 1620 	clr	a
      008A6A 9B               [12] 1621 	subb	a,r3
      008A6B 50 01            [24] 1622 	jnc	00102$
                                   1623 ;	free result
      008A6D 22               [24] 1624 	ret
      008A6E                       1625 00102$:
                                   1626 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008A6E 90 0B 0E         [24] 1627 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008A71 12 43 92         [24] 1628 	lcall	_ak820_outline_0120
      008A74 90 0B 0C         [24] 1629 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A77 12 38 3D         [24] 1630 	lcall	_ak820_outline_0100
      008A7A C3               [12] 1631 	clr	c
      008A7B EA               [12] 1632 	mov	a,r2
      008A7C 98               [12] 1633 	subb	a,r0
      008A7D EB               [12] 1634 	mov	a,r3
      008A7E 99               [12] 1635 	subb	a,r1
      008A7F 50 17            [24] 1636 	jnc	00104$
                                   1637 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008A81 E8               [12] 1638 	mov	a,r0
      008A82 C3               [12] 1639 	clr	c
      008A83 9A               [12] 1640 	subb	a,r2
      008A84 F8               [12] 1641 	mov	r0,a
      008A85 E9               [12] 1642 	mov	a,r1
      008A86 9B               [12] 1643 	subb	a,r3
      008A87 F9               [12] 1644 	mov	r1,a
                                   1645 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008A88 C3               [12] 1646 	clr	c
      008A89 E8               [12] 1647 	mov	a,r0
      008A8A 9C               [12] 1648 	subb	a,r4
      008A8B E9               [12] 1649 	mov	a,r1
      008A8C 9D               [12] 1650 	subb	a,r5
      008A8D 40 04            [24] 1651 	jc	00114$
      008A8F 8C 00            [24] 1652 	mov	ar0,r4
      008A91 8D 01            [24] 1653 	mov	ar1,r5
      008A93                       1654 00114$:
      008A93 90 0B 17         [24] 1655 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A96 E8               [12] 1656 	mov	a,r0
      008A97 F0               [24] 1657 	movx	@dptr,a
      008A98                       1658 00104$:
                                   1659 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A98 90 0B 17         [24] 1660 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008A9B E0               [24] 1661 	movx	a,@dptr
      008A9C F5 2C            [12] 1662 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008A9E E0               [24] 1663 	movx	a,@dptr
      008A9F 60 42            [24] 1664 	jz	00106$
      008AA1 C0 04            [24] 1665 	push	ar4
      008AA3 C0 05            [24] 1666 	push	ar5
      008AA5 8E 00            [24] 1667 	mov	ar0,r6
      008AA7 8F 05            [24] 1668 	mov	ar5,r7
      008AA9 90 0B 15         [24] 1669 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008AAC E0               [24] 1670 	movx	a,@dptr
      008AAD F9               [12] 1671 	mov	r1,a
      008AAE A3               [24] 1672 	inc	dptr
      008AAF E0               [24] 1673 	movx	a,@dptr
      008AB0 FC               [12] 1674 	mov	r4,a
      008AB1 EA               [12] 1675 	mov	a,r2
      008AB2 29               [12] 1676 	add	a, r1
      008AB3 FA               [12] 1677 	mov	r2,a
      008AB4 EB               [12] 1678 	mov	a,r3
      008AB5 3C               [12] 1679 	addc	a, r4
      008AB6 FB               [12] 1680 	mov	r3,a
      008AB7 90 05 81         [24] 1681 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008ABA EA               [12] 1682 	mov	a,r2
      008ABB F0               [24] 1683 	movx	@dptr,a
      008ABC EB               [12] 1684 	mov	a,r3
      008ABD 12 38 5A         [24] 1685 	lcall	_ak820_outline_0118
      008AC0 90 05 84         [24] 1686 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008AC3 E5 2C            [12] 1687 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008AC5 12 38 65         [24] 1688 	lcall	_ak820_outline_0123
      008AC8 88 82            [24] 1689 	mov	dpl, r0
      008ACA 8D 83            [24] 1690 	mov	dph, r5
      008ACC C0 07            [24] 1691 	push	ar7
      008ACE C0 06            [24] 1692 	push	ar6
      008AD0 C0 05            [24] 1693 	push	ar5
      008AD2 C0 04            [24] 1694 	push	ar4
      008AD4 12 40 E7         [24] 1695 	lcall	_ak820_eeprom_read_block_xdata
      008AD7 D0 04            [24] 1696 	pop	ar4
      008AD9 D0 05            [24] 1697 	pop	ar5
      008ADB D0 06            [24] 1698 	pop	ar6
      008ADD D0 07            [24] 1699 	pop	ar7
                                   1700 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008ADF D0 05            [24] 1701 	pop	ar5
      008AE1 D0 04            [24] 1702 	pop	ar4
                                   1703 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008AE3                       1704 00106$:
                                   1705 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008AE3 90 0B 17         [24] 1706 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008AE6 E0               [24] 1707 	movx	a,@dptr
      008AE7 FB               [12] 1708 	mov	r3,a
      008AE8                       1709 00109$:
      008AE8 8B 01            [24] 1710 	mov	ar1,r3
      008AEA 7A 00            [12] 1711 	mov	r2,#0x00
      008AEC C3               [12] 1712 	clr	c
      008AED E9               [12] 1713 	mov	a,r1
      008AEE 9C               [12] 1714 	subb	a,r4
      008AEF EA               [12] 1715 	mov	a,r2
      008AF0 9D               [12] 1716 	subb	a,r5
      008AF1 50 09            [24] 1717 	jnc	00111$
      008AF3 EB               [12] 1718 	mov	a,r3
      008AF4 12 37 F0         [24] 1719 	lcall	_ak820_outline_0031
      008AF7 E4               [12] 1720 	clr	a
      008AF8 F0               [24] 1721 	movx	@dptr,a
      008AF9 0B               [12] 1722 	inc	r3
      008AFA 80 EC            [24] 1723 	sjmp	00109$
      008AFC                       1724 00111$:
                                   1725 ;	quantum/dynamic_keymap.c:483: }
      008AFC 22               [24] 1726 	ret
                                   1727 ;------------------------------------------------------------
                                   1728 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1729 ;------------------------------------------------------------
                                   1730 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1731 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1732 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function dynamic_keymap_get_buffer
                                   1737 ;	-----------------------------------------
      008AFD                       1738 _dynamic_keymap_get_buffer:
      008AFD 12 38 49         [24] 1739 	lcall	_ak820_outline_0104
      008B00 90 0B 1D         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008B03 12 38 4E         [24] 1741 	lcall	_ak820_outline_0105
                                   1742 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008B06 90 0B 1D         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008B09 12 38 00         [24] 1744 	lcall	_ak820_outline_0051
      008B0C 90 0B 18         [24] 1745 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008B0F 12 38 1F         [24] 1746 	lcall	_ak820_outline_0060
      008B12 90 0B 1A         [24] 1747 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008B15 12 50 45         [24] 1748 	lcall	_ak820_outline_0087
      008B18 90 0B 0C         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008B1B E4               [12] 1750 	clr	a
      008B1C F0               [24] 1751 	movx	@dptr,a
      008B1D 74 06            [12] 1752 	mov	a,#0x06
      008B1F A3               [24] 1753 	inc	dptr
      008B20 F0               [24] 1754 	movx	@dptr,a
      008B21 90 0B 0E         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008B24 12 49 C0         [24] 1756 	lcall	_ak820_outline_0059
      008B27 90 0B 10         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008B2A 12 38 25         [24] 1758 	lcall	_ak820_outline_0071
      008B2D 90 0B 12         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008B30 E9               [12] 1760 	mov	a,r1
      008B31 12 50 5E         [24] 1761 	lcall	_ak820_outline_0151
      008B34 F0               [24] 1762 	movx	@dptr,a
      008B35 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:511: }
      008B38 02 8A 47         [24] 1765 	ljmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      008B3B                       1790 _dynamic_keymap_set_buffer:
      008B3B 12 38 49         [24] 1791 	lcall	_ak820_outline_0104
      008B3E 90 0B 24         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B41 12 38 4E         [24] 1793 	lcall	_ak820_outline_0105
                                   1794 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008B44 90 0B 24         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008B47 12 37 CB         [24] 1796 	lcall	_ak820_outline_0011
      008B4A 74 40            [12] 1797 	mov	a,#0x40
      008B4C 2C               [12] 1798 	add	a, r4
      008B4D FA               [12] 1799 	mov	r2,a
      008B4E E4               [12] 1800 	clr	a
      008B4F 3D               [12] 1801 	addc	a, r5
      008B50 FB               [12] 1802 	mov	r3,a
                                   1803 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008B51 90 0B 21         [24] 1804 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008B54 12 38 3D         [24] 1805 	lcall	_ak820_outline_0100
                                   1806 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008B57 90 0B 1F         [24] 1807 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008B5A E0               [24] 1808 	movx	a,@dptr
      008B5B F5 2D            [12] 1809 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008B5D A3               [24] 1810 	inc	dptr
      008B5E E0               [24] 1811 	movx	a,@dptr
      008B5F F5 2E            [12] 1812 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008B61 E5 2D            [12] 1813 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B63 45 2E            [12] 1814 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B65 70 01            [24] 1815 	jnz	00102$
      008B67 22               [24] 1816 	ret
      008B68                       1817 00102$:
                                   1818 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008B68 85 2D 2F         [24] 1819 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008B6B 85 2E 30         [24] 1820 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B6E C3               [12] 1821 	clr	c
      008B6F 74 1C            [12] 1822 	mov	a,#0x1c
      008B71 95 2F            [12] 1823 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008B73 E4               [12] 1824 	clr	a
      008B74 95 30            [12] 1825 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008B76 50 01            [24] 1826 	jnc	00104$
                                   1827 ;	free result
      008B78 22               [24] 1828 	ret
      008B79                       1829 00104$:
                                   1830 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008B79 85 2D 31         [24] 1831 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1832 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008B7C 74 FA            [12] 1833 	mov	a,#0x100 - 0x06
      008B7E 2F               [12] 1834 	add	a,r7
      008B7F 40 11            [24] 1835 	jc	00105$
      008B81 E4               [12] 1836 	clr	a
      008B82 C3               [12] 1837 	clr	c
      008B83 9E               [12] 1838 	subb	a,r6
      008B84 FE               [12] 1839 	mov	r6,a
      008B85 74 06            [12] 1840 	mov	a,#0x06
      008B87 9F               [12] 1841 	subb	a,r7
      008B88 FF               [12] 1842 	mov	r7,a
      008B89 C3               [12] 1843 	clr	c
      008B8A EE               [12] 1844 	mov	a,r6
      008B8B 95 2D            [12] 1845 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B8D EF               [12] 1846 	mov	a,r7
      008B8E 95 2E            [12] 1847 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B90 50 01            [24] 1848 	jnc	00106$
      008B92                       1849 00105$:
                                   1850 ;	quantum/dynamic_keymap.c:529: return;
      008B92 22               [24] 1851 	ret
      008B93                       1852 00106$:
                                   1853 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008B93 90 0D FC         [24] 1854 	mov	dptr,#_vial_unlocked
      008B96 E0               [24] 1855 	movx	a,@dptr
      008B97 60 03            [24] 1856 	jz	00207$
      008B99 02 8C A7         [24] 1857 	ljmp	00120$
      008B9C                       1858 00207$:
                                   1859 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008B9C 90 0B 26         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008B9F E4               [12] 1861 	clr	a
      008BA0 F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008BA1 90 0B 27         [24] 1864 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008BA4 E5 31            [12] 1865 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008BA6 F0               [24] 1866 	movx	@dptr,a
                                   1867 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008BA7 EC               [12] 1868 	mov	a,r4
      008BA8 30 E0 33         [24] 1869 	jnb	acc.0,00111$
                                   1870 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008BAB EA               [12] 1871 	mov	a,r2
      008BAC 24 FF            [12] 1872 	add	a,#0xff
      008BAE FE               [12] 1873 	mov	r6,a
      008BAF EB               [12] 1874 	mov	a,r3
      008BB0 34 FF            [12] 1875 	addc	a,#0xff
      008BB2 FF               [12] 1876 	mov	r7,a
      008BB3 7D 00            [12] 1877 	mov	r5,#0x00
      008BB5 12 43 8D         [24] 1878 	lcall	_ak820_outline_0117
      008BB8 8D F0            [24] 1879 	mov	b, r5
      008BBA 12 40 AC         [24] 1880 	lcall	_eeprom_read_byte
      008BBD AE 82            [24] 1881 	mov	r6,dpl
      008BBF 7F 00            [12] 1882 	mov	r7,#0x00
      008BC1 12 38 75         [24] 1883 	lcall	_ak820_outline_0152
      008BC4 E0               [24] 1884 	movx	a,@dptr
      008BC5 7C 00            [12] 1885 	mov	r4,#0x00
      008BC7 42 07            [12] 1886 	orl	ar7,a
      008BC9 EC               [12] 1887 	mov	a,r4
      008BCA 42 06            [12] 1888 	orl	ar6,a
                                   1889 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008BCC BF 00 09         [24] 1890 	cjne	r7,#0x00,00109$
      008BCF BE 7C 06         [24] 1891 	cjne	r6,#0x7c,00109$
                                   1892 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008BD2 12 38 75         [24] 1893 	lcall	_ak820_outline_0152
      008BD5 74 FF            [12] 1894 	mov	a,#0xff
      008BD7 F0               [24] 1895 	movx	@dptr,a
      008BD8                       1896 00109$:
                                   1897 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008BD8 90 0B 26         [24] 1898 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008BDB 74 01            [12] 1899 	mov	a,#0x01
      008BDD F0               [24] 1900 	movx	@dptr,a
      008BDE                       1901 00111$:
                                   1902 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008BDE 90 0B 24         [24] 1903 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008BE1 12 38 00         [24] 1904 	lcall	_ak820_outline_0051
      008BE4 E5 2D            [12] 1905 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008BE6 2E               [12] 1906 	add	a, r6
      008BE7 FE               [12] 1907 	mov	r6,a
      008BE8 E5 2E            [12] 1908 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008BEA 3F               [12] 1909 	addc	a, r7
      008BEB EE               [12] 1910 	mov	a,r6
      008BEC 30 E0 5A         [24] 1911 	jnb	acc.0,00115$
                                   1912 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008BEF AE 31            [24] 1913 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008BF1 7F 00            [12] 1914 	mov	r7,#0x00
      008BF3 EE               [12] 1915 	mov	a,r6
      008BF4 24 FF            [12] 1916 	add	a,#0xff
      008BF6 FC               [12] 1917 	mov	r4,a
      008BF7 EF               [12] 1918 	mov	a,r7
      008BF8 34 FF            [12] 1919 	addc	a,#0xff
      008BFA FD               [12] 1920 	mov	r5,a
      008BFB EC               [12] 1921 	mov	a,r4
      008BFC 28               [12] 1922 	add	a, r0
      008BFD F5 82            [12] 1923 	mov	dpl,a
      008BFF ED               [12] 1924 	mov	a,r5
      008C00 39               [12] 1925 	addc	a, r1
      008C01 F5 83            [12] 1926 	mov	dph,a
      008C03 E0               [24] 1927 	movx	a,@dptr
      008C04 FC               [12] 1928 	mov	r4,a
      008C05 7D 00            [12] 1929 	mov	r5,#0x00
      008C07 E5 31            [12] 1930 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008C09 2A               [12] 1931 	add	a, r2
      008C0A FA               [12] 1932 	mov	r2,a
      008C0B E4               [12] 1933 	clr	a
      008C0C 3B               [12] 1934 	addc	a, r3
      008C0D FB               [12] 1935 	mov	r3,a
      008C0E C0 00            [24] 1936 	push	ar0
      008C10 C0 01            [24] 1937 	push	ar1
      008C12 8B 01            [24] 1938 	mov	ar1,r3
      008C14 7B 00            [12] 1939 	mov	r3,#0x00
      008C16 8A 82            [24] 1940 	mov	dpl, r2
      008C18 89 83            [24] 1941 	mov	dph, r1
      008C1A 8B F0            [24] 1942 	mov	b, r3
      008C1C 12 40 AC         [24] 1943 	lcall	_eeprom_read_byte
      008C1F AB 82            [24] 1944 	mov	r3, dpl
      008C21 7A 00            [12] 1945 	mov	r2,#0x00
      008C23 EB               [12] 1946 	mov	a,r3
      008C24 12 43 A3         [24] 1947 	lcall	_ak820_outline_0139
                                   1948 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008C27 BD 00 05         [24] 1949 	cjne	r5,#0x00,00212$
      008C2A BC 7C 02         [24] 1950 	cjne	r4,#0x7c,00212$
      008C2D 80 06            [24] 1951 	sjmp	00213$
      008C2F                       1952 00212$:
      008C2F D0 01            [24] 1953 	pop	ar1
      008C31 D0 00            [24] 1954 	pop	ar0
      008C33 80 0D            [24] 1955 	sjmp	00113$
      008C35                       1956 00213$:
      008C35 D0 01            [24] 1957 	pop	ar1
      008C37 D0 00            [24] 1958 	pop	ar0
                                   1959 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008C39 1E               [12] 1960 	dec	r6
      008C3A BE FF 01         [24] 1961 	cjne	r6,#0xff,00214$
      008C3D 1F               [12] 1962 	dec	r7
      008C3E                       1963 00214$:
      008C3E EE               [12] 1964 	mov	a,r6
      008C3F 12 90 E8         [24] 1965 	lcall	_ak820_outline_0127
      008C42                       1966 00113$:
                                   1967 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008C42 E5 31            [12] 1968 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008C44 14               [12] 1969 	dec	a
      008C45 90 0B 27         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008C48 F0               [24] 1971 	movx	@dptr,a
      008C49                       1972 00115$:
                                   1973 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C49 90 0B 26         [24] 1974 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008C4C E0               [24] 1975 	movx	a,@dptr
      008C4D 90 0B 28         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C50 F0               [24] 1977 	movx	@dptr,a
      008C51                       1978 00122$:
      008C51 90 0B 28         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008C54 E0               [24] 1980 	movx	a,@dptr
      008C55 FF               [12] 1981 	mov	r7,a
      008C56 90 0B 27         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008C59 E0               [24] 1983 	movx	a,@dptr
      008C5A FE               [12] 1984 	mov	r6,a
      008C5B C3               [12] 1985 	clr	c
      008C5C EF               [12] 1986 	mov	a,r7
      008C5D 9E               [12] 1987 	subb	a,r6
      008C5E 50 47            [24] 1988 	jnc	00120$
                                   1989 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008C60 EF               [12] 1990 	mov	a,r7
      008C61 28               [12] 1991 	add	a, r0
      008C62 FD               [12] 1992 	mov	r5,a
      008C63 E4               [12] 1993 	clr	a
      008C64 39               [12] 1994 	addc	a, r1
      008C65 12 49 B8         [24] 1995 	lcall	_ak820_outline_0057
      008C68 7B 00            [12] 1996 	mov	r3,#0x00
      008C6A 8C 2E            [24] 1997 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008C6C 8B 2D            [24] 1998 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008C6E 8F 02            [24] 1999 	mov	ar2,r7
      008C70 7F 00            [12] 2000 	mov	r7,#0x00
      008C72 74 01            [12] 2001 	mov	a,#0x01
      008C74 2A               [12] 2002 	add	a, r2
      008C75 FB               [12] 2003 	mov	r3,a
      008C76 E4               [12] 2004 	clr	a
      008C77 3F               [12] 2005 	addc	a, r7
      008C78 FC               [12] 2006 	mov	r4,a
      008C79 EB               [12] 2007 	mov	a,r3
      008C7A 28               [12] 2008 	add	a, r0
      008C7B F5 82            [12] 2009 	mov	dpl,a
      008C7D EC               [12] 2010 	mov	a,r4
      008C7E 39               [12] 2011 	addc	a, r1
      008C7F F5 83            [12] 2012 	mov	dph,a
      008C81 E0               [24] 2013 	movx	a,@dptr
      008C82 FC               [12] 2014 	mov	r4,a
      008C83 7B 00            [12] 2015 	mov	r3,#0x00
      008C85 E5 2E            [12] 2016 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C87 42 03            [12] 2017 	orl	ar3,a
                                   2018 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008C89 BC 00 12         [24] 2019 	cjne	r4,#0x00,00123$
      008C8C BB 7C 0F         [24] 2020 	cjne	r3,#0x7c,00123$
                                   2021 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008C8F 12 38 6A         [24] 2022 	lcall	_ak820_outline_0131
      008C92 74 FF            [12] 2023 	mov	a,#0xff
      008C94 F0               [24] 2024 	movx	@dptr,a
                                   2025 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008C95 0A               [12] 2026 	inc	r2
      008C96 BA 00 01         [24] 2027 	cjne	r2,#0x00,00218$
      008C99 0F               [12] 2028 	inc	r7
      008C9A                       2029 00218$:
      008C9A EA               [12] 2030 	mov	a,r2
      008C9B 12 90 E8         [24] 2031 	lcall	_ak820_outline_0127
      008C9E                       2032 00123$:
                                   2033 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C9E 90 0B 28         [24] 2034 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008CA1 E0               [24] 2035 	movx	a,@dptr
      008CA2 24 02            [12] 2036 	add	a,#0x02
      008CA4 F0               [24] 2037 	movx	@dptr,a
      008CA5 80 AA            [24] 2038 	sjmp	00122$
      008CA7                       2039 00120$:
                                   2040 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008CA7 90 0B 24         [24] 2041 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008CAA 12 38 00         [24] 2042 	lcall	_ak820_outline_0051
      008CAD 74 40            [12] 2043 	mov	a,#0x40
      008CAF 12 43 9D         [24] 2044 	lcall	_ak820_outline_0134
      008CB2 90 05 8A         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008CB5 12 49 C0         [24] 2046 	lcall	_ak820_outline_0059
      008CB8 E4               [12] 2047 	clr	a
      008CB9 A3               [24] 2048 	inc	dptr
      008CBA F0               [24] 2049 	movx	@dptr,a
      008CBB 90 05 8D         [24] 2050 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008CBE E5 2F            [12] 2051 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008CC0 F0               [24] 2052 	movx	@dptr,a
      008CC1 E5 30            [12] 2053 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008CC3 A3               [24] 2054 	inc	dptr
      008CC4 F0               [24] 2055 	movx	@dptr,a
      008CC5 12 38 75         [24] 2056 	lcall	_ak820_outline_0152
                                   2057 ;	quantum/dynamic_keymap.c:584: }
      008CC8 02 41 73         [24] 2058 	ljmp	_ak820_eeprom_write_block_xdata
                                   2059 ;------------------------------------------------------------
                                   2060 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2061 ;------------------------------------------------------------
                                   2062 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2063 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2064 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2065 ;------------------------------------------------------------
                                   2066 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2067 ;	-----------------------------------------
                                   2068 ;	 function keycode_at_keymap_location
                                   2069 ;	-----------------------------------------
      008CCB                       2070 _keycode_at_keymap_location:
      008CCB E5 82            [12] 2071 	mov	a,dpl
      008CCD 90 0B 2B         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008CD0 F0               [24] 2073 	movx	@dptr,a
                                   2074 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008CD1 E0               [24] 2075 	movx	a,@dptr
      008CD2 FF               [12] 2076 	mov	r7,a
      008CD3 BF 06 00         [24] 2077 	cjne	r7,#0x06,00128$
      008CD6                       2078 00128$:
      008CD6 50 23            [24] 2079 	jnc	00102$
      008CD8 90 0B 29         [24] 2080 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008CDB E0               [24] 2081 	movx	a,@dptr
      008CDC FE               [12] 2082 	mov	r6,a
      008CDD BE 10 00         [24] 2083 	cjne	r6,#0x10,00130$
      008CE0                       2084 00130$:
      008CE0 50 19            [24] 2085 	jnc	00102$
      008CE2 90 0B 2A         [24] 2086 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008CE5 E0               [24] 2087 	movx	a,@dptr
      008CE6 FD               [12] 2088 	mov	r5,a
      008CE7 BD 08 00         [24] 2089 	cjne	r5,#0x08,00132$
      008CEA                       2090 00132$:
      008CEA 50 0F            [24] 2091 	jnc	00102$
                                   2092 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008CEC 90 0A DD         [24] 2093 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008CEF EE               [12] 2094 	mov	a,r6
      008CF0 F0               [24] 2095 	movx	@dptr,a
      008CF1 90 0A DE         [24] 2096 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008CF4 ED               [12] 2097 	mov	a,r5
      008CF5 F0               [24] 2098 	movx	@dptr,a
      008CF6 8F 82            [24] 2099 	mov	dpl, r7
      008CF8 02 86 5D         [24] 2100 	ljmp	_dynamic_keymap_get_keycode
      008CFB                       2101 00102$:
                                   2102 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008CFB 90 00 00         [24] 2103 	mov	dptr,#0x0000
                                   2104 ;	quantum/dynamic_keymap.c:591: }
      008CFE 22               [24] 2105 	ret
                                   2106 ;------------------------------------------------------------
                                   2107 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2108 ;------------------------------------------------------------
                                   2109 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2110 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2111 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2112 ;------------------------------------------------------------
                                   2113 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2114 ;	-----------------------------------------
                                   2115 ;	 function keycode_at_encodermap_location
                                   2116 ;	-----------------------------------------
      008CFF                       2117 _keycode_at_encodermap_location:
      008CFF E5 82            [12] 2118 	mov	a,dpl
      008D01 90 0B 2E         [24] 2119 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008D04 F0               [24] 2120 	movx	@dptr,a
                                   2121 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008D05 E0               [24] 2122 	movx	a,@dptr
      008D06 FF               [12] 2123 	mov	r7,a
      008D07 BF 06 00         [24] 2124 	cjne	r7,#0x06,00120$
      008D0A                       2125 00120$:
      008D0A 50 1E            [24] 2126 	jnc	00102$
      008D0C 90 0B 2C         [24] 2127 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008D0F E0               [24] 2128 	movx	a,@dptr
      008D10 FE               [12] 2129 	mov	r6,a
      008D11 BE 01 00         [24] 2130 	cjne	r6,#0x01,00122$
      008D14                       2131 00122$:
      008D14 50 14            [24] 2132 	jnc	00102$
                                   2133 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008D16 90 0B 2D         [24] 2134 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008D19 E0               [24] 2135 	movx	a,@dptr
      008D1A FE               [12] 2136 	mov	r6,a
      008D1B 90 0A E7         [24] 2137 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008D1E E4               [12] 2138 	clr	a
      008D1F F0               [24] 2139 	movx	@dptr,a
      008D20 90 0A E8         [24] 2140 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008D23 EE               [12] 2141 	mov	a,r6
      008D24 F0               [24] 2142 	movx	@dptr,a
      008D25 8F 82            [24] 2143 	mov	dpl, r7
      008D27 02 87 1E         [24] 2144 	ljmp	_dynamic_keymap_get_encoder
      008D2A                       2145 00102$:
                                   2146 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008D2A 90 00 00         [24] 2147 	mov	dptr,#0x0000
                                   2148 ;	quantum/dynamic_keymap.c:599: }
      008D2D 22               [24] 2149 	ret
                                   2150 ;------------------------------------------------------------
                                   2151 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2152 ;------------------------------------------------------------
                                   2153 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2154 ;	-----------------------------------------
                                   2155 ;	 function dynamic_keymap_macro_get_count
                                   2156 ;	-----------------------------------------
      008D2E                       2157 _dynamic_keymap_macro_get_count:
                                   2158 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008D2E 75 82 10         [24] 2159 	mov	dpl, #0x10
                                   2160 ;	quantum/dynamic_keymap.c:604: }
      008D31 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2168 ;	-----------------------------------------
      008D32                       2169 _dynamic_keymap_macro_get_buffer_size:
                                   2170 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008D32 90 20 00         [24] 2171 	mov	dptr,#0x2000
                                   2172 ;	quantum/dynamic_keymap.c:608: }
      008D35 22               [24] 2173 	ret
                                   2174 ;------------------------------------------------------------
                                   2175 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2176 ;------------------------------------------------------------
                                   2177 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2178 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2179 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2180 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2181 ;------------------------------------------------------------
                                   2182 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2183 ;	-----------------------------------------
                                   2184 ;	 function dynamic_keymap_macro_get_buffer
                                   2185 ;	-----------------------------------------
      008D36                       2186 _dynamic_keymap_macro_get_buffer:
      008D36 12 38 49         [24] 2187 	lcall	_ak820_outline_0104
      008D39 90 0B 34         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008D3C 12 38 4E         [24] 2189 	lcall	_ak820_outline_0105
                                   2190 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008D3F 12 2A DF         [24] 2191 	lcall	_ak820_macro_length
      008D42 12 43 98         [24] 2192 	lcall	_ak820_outline_0132
      008D45 90 0B 34         [24] 2193 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008D48 12 38 1F         [24] 2194 	lcall	_ak820_outline_0060
      008D4B 90 0B 2F         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008D4E E0               [24] 2196 	movx	a,@dptr
      008D4F F5 32            [12] 2197 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008D51 A3               [24] 2198 	inc	dptr
      008D52 E0               [24] 2199 	movx	a,@dptr
      008D53 F5 33            [12] 2200 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008D55 90 0B 31         [24] 2201 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008D58 12 38 3D         [24] 2202 	lcall	_ak820_outline_0100
      008D5B A3               [24] 2203 	inc	dptr
      008D5C E0               [24] 2204 	movx	a,@dptr
      008D5D FB               [12] 2205 	mov	r3,a
      008D5E 90 0B 0C         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D61 12 49 C0         [24] 2207 	lcall	_ak820_outline_0059
      008D64 90 0B 0E         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D67 12 38 25         [24] 2209 	lcall	_ak820_outline_0071
      008D6A 90 0B 10         [24] 2210 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D6D E5 32            [12] 2211 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008D6F F0               [24] 2212 	movx	@dptr,a
      008D70 E5 33            [12] 2213 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008D72 A3               [24] 2214 	inc	dptr
      008D73 F0               [24] 2215 	movx	@dptr,a
      008D74 90 0B 12         [24] 2216 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D77 E8               [12] 2217 	mov	a,r0
      008D78 F0               [24] 2218 	movx	@dptr,a
      008D79 E9               [12] 2219 	mov	a,r1
      008D7A A3               [24] 2220 	inc	dptr
      008D7B F0               [24] 2221 	movx	@dptr,a
      008D7C EB               [12] 2222 	mov	a,r3
      008D7D A3               [24] 2223 	inc	dptr
      008D7E F0               [24] 2224 	movx	@dptr,a
      008D7F 90 08 00         [24] 2225 	mov	dptr,#0x0800
                                   2226 ;	quantum/dynamic_keymap.c:635: }
      008D82 02 8A 47         [24] 2227 	ljmp	_ak820_dynamic_read_buffer
                                   2228 ;------------------------------------------------------------
                                   2229 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2230 ;------------------------------------------------------------
                                   2231 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2232 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2233 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2234 ;------------------------------------------------------------
                                   2235 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2236 ;	-----------------------------------------
                                   2237 ;	 function dynamic_keymap_macro_set_buffer
                                   2238 ;	-----------------------------------------
      008D85                       2239 _dynamic_keymap_macro_set_buffer:
      008D85 12 38 49         [24] 2240 	lcall	_ak820_outline_0104
      008D88 90 0B 3B         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008D8B 12 38 4E         [24] 2242 	lcall	_ak820_outline_0105
                                   2243 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008D8E 90 0B 3B         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008D91 12 38 00         [24] 2245 	lcall	_ak820_outline_0051
      008D94 90 0B 36         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008D97 12 38 1F         [24] 2247 	lcall	_ak820_outline_0060
      008D9A 90 0B 38         [24] 2248 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008D9D 12 50 45         [24] 2249 	lcall	_ak820_outline_0087
      008DA0 90 05 10         [24] 2250 	mov	dptr,#_ak820_macro_write_PARM_2
      008DA3 12 38 25         [24] 2251 	lcall	_ak820_outline_0071
      008DA6 90 05 12         [24] 2252 	mov	dptr,#_ak820_macro_write_PARM_3
      008DA9 E9               [12] 2253 	mov	a,r1
      008DAA 12 50 5E         [24] 2254 	lcall	_ak820_outline_0151
      008DAD 12 43 6F         [24] 2255 	lcall	_ak820_outline_0061
                                   2256 ;	quantum/dynamic_keymap.c:640: }
      008DB0 02 2A F9         [24] 2257 	ljmp	_ak820_macro_write
                                   2258 ;------------------------------------------------------------
                                   2259 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2260 ;------------------------------------------------------------
                                   2261 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2262 ;	-----------------------------------------
                                   2263 ;	 function dynamic_keymap_macro_reset
                                   2264 ;	-----------------------------------------
      008DB3                       2265 _dynamic_keymap_macro_reset:
                                   2266 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2267 ;	quantum/dynamic_keymap.c:666: }
      008DB3 02 2E 18         [24] 2268 	ljmp	_ak820_macro_reset
                                   2269 ;------------------------------------------------------------
                                   2270 ;Allocation info for local variables in function 'decode_keycode'
                                   2271 ;------------------------------------------------------------
                                   2272 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function decode_keycode
                                   2277 ;	-----------------------------------------
      008DB6                       2278 _decode_keycode:
      008DB6 12 38 49         [24] 2279 	lcall	_ak820_outline_0104
      008DB9 90 0B 3D         [24] 2280 	mov	dptr,#_decode_keycode_kc_10000_455
      008DBC 12 38 4E         [24] 2281 	lcall	_ak820_outline_0105
                                   2282 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008DBF 90 0B 3D         [24] 2283 	mov	dptr,#_decode_keycode_kc_10000_455
      008DC2 12 37 CB         [24] 2284 	lcall	_ak820_outline_0011
      008DC5 C3               [12] 2285 	clr	c
      008DC6 E4               [12] 2286 	clr	a
      008DC7 9C               [12] 2287 	subb	a,r4
      008DC8 74 FF            [12] 2288 	mov	a,#0xff
      008DCA 9D               [12] 2289 	subb	a,r5
      008DCB 50 08            [24] 2290 	jnc	00102$
                                   2291 ;	free result
                                   2292 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008DCD 8C 05            [24] 2293 	mov	ar5,r4
      008DCF 7C 00            [12] 2294 	mov	r4,#0x00
      008DD1 12 38 60         [24] 2295 	lcall	_ak820_outline_0121
      008DD4 22               [24] 2296 	ret
      008DD5                       2297 00102$:
                                   2298 ;	quantum/dynamic_keymap.c:672: return kc;
      008DD5 12 43 8D         [24] 2299 	lcall	_ak820_outline_0117
                                   2300 ;	quantum/dynamic_keymap.c:673: }
      008DD8 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2304 ;------------------------------------------------------------
                                   2305 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2306 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2307 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2308 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2309 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2310 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2311 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2312 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2313 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2314 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2315 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function dynamic_keymap_macro_send
                                   2321 ;	-----------------------------------------
      008DD9                       2322 _dynamic_keymap_macro_send:
      008DD9 E5 82            [12] 2323 	mov	a,dpl
      008DDB 90 0B 3F         [24] 2324 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008DDE F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008DDF 90 0B 40         [24] 2327 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008DE2 E0               [24] 2328 	movx	a,@dptr
      008DE3 60 01            [24] 2329 	jz	00102$
      008DE5 22               [24] 2330 	ret
      008DE6                       2331 00102$:
                                   2332 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008DE6 90 0B 3F         [24] 2333 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008DE9 E0               [24] 2334 	movx	a,@dptr
      008DEA FF               [12] 2335 	mov	r7,a
      008DEB BF 10 00         [24] 2336 	cjne	r7,#0x10,00422$
      008DEE                       2337 00422$:
      008DEE 40 01            [24] 2338 	jc	00104$
                                   2339 ;	quantum/dynamic_keymap.c:683: return;
      008DF0 22               [24] 2340 	ret
      008DF1                       2341 00104$:
                                   2342 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008DF1 C0 07            [24] 2343 	push	ar7
      008DF3 12 2A A6         [24] 2344 	lcall	_ak820_macro_ready
      008DF6 E5 82            [12] 2345 	mov	a, dpl
      008DF8 D0 07            [24] 2346 	pop	ar7
      008DFA 70 01            [24] 2347 	jnz	00106$
      008DFC 22               [24] 2348 	ret
      008DFD                       2349 00106$:
                                   2350 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008DFD 90 0B 41         [24] 2351 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E00 E4               [12] 2352 	clr	a
      008E01 F0               [24] 2353 	movx	@dptr,a
      008E02 74 08            [12] 2354 	mov	a,#0x08
      008E04 A3               [24] 2355 	inc	dptr
      008E05 F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008E06 C0 07            [24] 2358 	push	ar7
      008E08 12 2A DF         [24] 2359 	lcall	_ak820_macro_length
      008E0B AD 82            [24] 2360 	mov	r5, dpl
      008E0D AE 83            [24] 2361 	mov	r6, dph
      008E0F D0 07            [24] 2362 	pop	ar7
      008E11 74 08            [12] 2363 	mov	a,#0x08
      008E13 2E               [12] 2364 	add	a, r6
      008E14 FE               [12] 2365 	mov	r6,a
                                   2366 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008E15 7B 00            [12] 2367 	mov	r3,#0x00
      008E17 7C 08            [12] 2368 	mov	r4,#0x08
      008E19                       2369 00111$:
      008E19 EF               [12] 2370 	mov	a,r7
      008E1A 60 31            [24] 2371 	jz	00113$
                                   2372 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008E1C EB               [12] 2373 	mov	a,r3
      008E1D B5 05 05         [24] 2374 	cjne	a,ar5,00108$
      008E20 EC               [12] 2375 	mov	a,r4
      008E21 B5 06 01         [24] 2376 	cjne	a,ar6,00108$
                                   2377 ;	quantum/dynamic_keymap.c:717: return;
      008E24 22               [24] 2378 	ret
      008E25                       2379 00108$:
                                   2380 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008E25 8B 01            [24] 2381 	mov	ar1,r3
      008E27 8C 02            [24] 2382 	mov	ar2,r4
      008E29 8A 00            [24] 2383 	mov	ar0,r2
      008E2B 7A 00            [12] 2384 	mov	r2,#0x00
      008E2D 89 82            [24] 2385 	mov	dpl, r1
      008E2F 88 83            [24] 2386 	mov	dph, r0
      008E31 8A F0            [24] 2387 	mov	b, r2
      008E33 12 40 AC         [24] 2388 	lcall	_eeprom_read_byte
      008E36 E5 82            [12] 2389 	mov	a, dpl
      008E38 70 06            [24] 2390 	jnz	00110$
                                   2391 ;	quantum/dynamic_keymap.c:720: --id;
      008E3A 1F               [12] 2392 	dec	r7
      008E3B 90 0B 3F         [24] 2393 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008E3E EF               [12] 2394 	mov	a,r7
      008E3F F0               [24] 2395 	movx	@dptr,a
      008E40                       2396 00110$:
                                   2397 ;	quantum/dynamic_keymap.c:722: ++p;
      008E40 0B               [12] 2398 	inc	r3
      008E41 BB 00 01         [24] 2399 	cjne	r3,#0x00,00429$
      008E44 0C               [12] 2400 	inc	r4
      008E45                       2401 00429$:
      008E45 90 0B 41         [24] 2402 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E48 12 38 2B         [24] 2403 	lcall	_ak820_outline_0076
      008E4B 80 CC            [24] 2404 	sjmp	00111$
      008E4D                       2405 00113$:
                                   2406 ;	quantum/dynamic_keymap.c:728: sending = true;
      008E4D 90 0B 40         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008E50 74 01            [12] 2408 	mov	a,#0x01
      008E52 F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008E53 12 91 00         [24] 2411 	lcall	_ak820_outline_0160
      008E56 90 09 89         [24] 2412 	mov	dptr,#_ak820_macro_cancelled
      008E59 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008E5A 90 0B 43         [24] 2415 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008E5D F0               [24] 2416 	movx	@dptr,a
      008E5E 90 0B 44         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E61 F0               [24] 2418 	movx	@dptr,a
      008E62 90 0B 45         [24] 2419 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008E65 F0               [24] 2420 	movx	@dptr,a
      008E66 90 0B 46         [24] 2421 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008E69 F0               [24] 2422 	movx	@dptr,a
                                   2423 ;	quantum/dynamic_keymap.c:738: while (p < end
      008E6A                       2424 00167$:
                                   2425 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008E6A 90 0B 41         [24] 2426 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E6D E0               [24] 2427 	movx	a,@dptr
      008E6E FC               [12] 2428 	mov	r4,a
      008E6F A3               [24] 2429 	inc	dptr
      008E70 E0               [24] 2430 	movx	a,@dptr
      008E71 FF               [12] 2431 	mov	r7,a
      008E72 C3               [12] 2432 	clr	c
      008E73 EC               [12] 2433 	mov	a,r4
      008E74 9D               [12] 2434 	subb	a,r5
      008E75 EF               [12] 2435 	mov	a,r7
      008E76 9E               [12] 2436 	subb	a,r6
      008E77 40 03            [24] 2437 	jc	00430$
      008E79 02 90 8E         [24] 2438 	ljmp	00169$
      008E7C                       2439 00430$:
      008E7C 90 09 89         [24] 2440 	mov	dptr,#_ak820_macro_cancelled
      008E7F E0               [24] 2441 	movx	a,@dptr
      008E80 60 03            [24] 2442 	jz	00431$
      008E82 02 90 8E         [24] 2443 	ljmp	00169$
      008E85                       2444 00431$:
                                   2445 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E85 8C 02            [24] 2446 	mov	ar2,r4
      008E87 8F 03            [24] 2447 	mov	ar3,r7
      008E89 90 0B 41         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E8C 74 01            [12] 2449 	mov	a,#0x01
      008E8E 2C               [12] 2450 	add	a, r4
      008E8F F0               [24] 2451 	movx	@dptr,a
      008E90 E4               [12] 2452 	clr	a
      008E91 3F               [12] 2453 	addc	a, r7
      008E92 A3               [24] 2454 	inc	dptr
      008E93 F0               [24] 2455 	movx	@dptr,a
      008E94 7F 00            [12] 2456 	mov	r7,#0x00
      008E96 12 43 A9         [24] 2457 	lcall	_ak820_outline_0140
      008E99 8F F0            [24] 2458 	mov	b, r7
      008E9B 12 40 AC         [24] 2459 	lcall	_eeprom_read_byte
      008E9E AF 82            [24] 2460 	mov	r7, dpl
      008EA0 90 0B 43         [24] 2461 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EA3 EF               [12] 2462 	mov	a,r7
      008EA4 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008EA5 90 0B 44         [24] 2465 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008EA8 E4               [12] 2466 	clr	a
      008EA9 F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008EAA 90 0B 43         [24] 2469 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EAD E0               [24] 2470 	movx	a,@dptr
      008EAE 70 03            [24] 2471 	jnz	00432$
      008EB0 02 90 8E         [24] 2472 	ljmp	00169$
      008EB3                       2473 00432$:
                                   2474 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008EB3 90 0B 43         [24] 2475 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EB6 E0               [24] 2476 	movx	a,@dptr
      008EB7 FF               [12] 2477 	mov	r7,a
      008EB8 BF 01 02         [24] 2478 	cjne	r7,#0x01,00433$
      008EBB 80 03            [24] 2479 	sjmp	00434$
      008EBD                       2480 00433$:
      008EBD 02 90 70         [24] 2481 	ljmp	00164$
      008EC0                       2482 00434$:
                                   2483 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EC0 12 90 96         [24] 2484 	lcall	_ak820_outline_0000
      008EC3 12 40 AC         [24] 2485 	lcall	_eeprom_read_byte
      008EC6 AF 82            [24] 2486 	mov	r7, dpl
      008EC8 90 0B 44         [24] 2487 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008ECB EF               [12] 2488 	mov	a,r7
      008ECC F0               [24] 2489 	movx	@dptr,a
                                   2490 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008ECD EF               [12] 2491 	mov	a,r7
      008ECE 70 03            [24] 2492 	jnz	00435$
      008ED0 02 90 8E         [24] 2493 	ljmp	00169$
      008ED3                       2494 00435$:
                                   2495 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008ED3 12 90 CE         [24] 2496 	lcall	_ak820_outline_0089
      008ED6 BF 01 02         [24] 2497 	cjne	r7,#0x01,00436$
      008ED9 80 13            [24] 2498 	sjmp	00151$
      008EDB                       2499 00436$:
      008EDB 12 90 CE         [24] 2500 	lcall	_ak820_outline_0089
      008EDE BF 02 02         [24] 2501 	cjne	r7,#0x02,00437$
      008EE1 80 0B            [24] 2502 	sjmp	00151$
      008EE3                       2503 00437$:
      008EE3 12 90 CE         [24] 2504 	lcall	_ak820_outline_0089
      008EE6 BF 03 02         [24] 2505 	cjne	r7,#0x03,00438$
      008EE9 80 03            [24] 2506 	sjmp	00439$
      008EEB                       2507 00438$:
      008EEB 02 8F 4F         [24] 2508 	ljmp	00152$
      008EEE                       2509 00439$:
      008EEE                       2510 00151$:
                                   2511 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EEE 12 90 96         [24] 2512 	lcall	_ak820_outline_0000
      008EF1 12 40 AC         [24] 2513 	lcall	_eeprom_read_byte
      008EF4 12 91 18         [24] 2514 	lcall	_ak820_outline_0179
                                   2515 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008EF7 70 03            [24] 2516 	jnz	00440$
      008EF9 02 8E 6A         [24] 2517 	ljmp	00167$
      008EFC                       2518 00440$:
                                   2519 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008EFC 12 90 CE         [24] 2520 	lcall	_ak820_outline_0089
      008EFF BF 01 03         [24] 2521 	cjne	r7,#0x01,00441$
      008F02 D3               [12] 2522 	setb	c
      008F03 80 01            [24] 2523 	sjmp	00442$
      008F05                       2524 00441$:
      008F05 C3               [12] 2525 	clr	c
      008F06                       2526 00442$:
      008F06 92 26            [24] 2527 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008F08 90 09 88         [24] 2528 	mov	dptr,#_ak820_macro_primitive
      008F0B B3               [12] 2529 	cpl	c
      008F0C E4               [12] 2530 	clr	a
      008F0D 33               [12] 2531 	rlc	a
      008F0E F0               [24] 2532 	movx	@dptr,a
                                   2533 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008F0F 12 90 CE         [24] 2534 	lcall	_ak820_outline_0089
      008F12 BF 01 10         [24] 2535 	cjne	r7,#0x01,00122$
      008F15 12 90 F9         [24] 2536 	lcall	_ak820_outline_0147
      008F18 C0 06            [24] 2537 	push	ar6
      008F1A C0 05            [24] 2538 	push	ar5
      008F1C 12 77 AE         [24] 2539 	lcall	_tap_code
      008F1F D0 05            [24] 2540 	pop	ar5
      008F21 D0 06            [24] 2541 	pop	ar6
      008F23 80 24            [24] 2542 	sjmp	00123$
      008F25                       2543 00122$:
                                   2544 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008F25 12 90 CE         [24] 2545 	lcall	_ak820_outline_0089
      008F28 BF 02 10         [24] 2546 	cjne	r7,#0x02,00119$
      008F2B 12 90 F9         [24] 2547 	lcall	_ak820_outline_0147
      008F2E C0 06            [24] 2548 	push	ar6
      008F30 C0 05            [24] 2549 	push	ar5
      008F32 12 76 A8         [24] 2550 	lcall	_register_code
      008F35 D0 05            [24] 2551 	pop	ar5
      008F37 D0 06            [24] 2552 	pop	ar6
      008F39 80 0E            [24] 2553 	sjmp	00123$
      008F3B                       2554 00119$:
                                   2555 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      008F3B 12 90 F9         [24] 2556 	lcall	_ak820_outline_0147
      008F3E C0 06            [24] 2557 	push	ar6
      008F40 C0 05            [24] 2558 	push	ar5
      008F42 12 77 15         [24] 2559 	lcall	_unregister_code
      008F45 D0 05            [24] 2560 	pop	ar5
      008F47 D0 06            [24] 2561 	pop	ar6
      008F49                       2562 00123$:
                                   2563 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      008F49 12 91 00         [24] 2564 	lcall	_ak820_outline_0160
      008F4C 02 8E 6A         [24] 2565 	ljmp	00167$
      008F4F                       2566 00152$:
                                   2567 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008F4F 12 90 CE         [24] 2568 	lcall	_ak820_outline_0089
      008F52 BF 05 02         [24] 2569 	cjne	r7,#0x05,00447$
      008F55 80 13            [24] 2570 	sjmp	00146$
      008F57                       2571 00447$:
      008F57 12 90 CE         [24] 2572 	lcall	_ak820_outline_0089
      008F5A BF 06 02         [24] 2573 	cjne	r7,#0x06,00448$
      008F5D 80 0B            [24] 2574 	sjmp	00146$
      008F5F                       2575 00448$:
      008F5F 12 90 CE         [24] 2576 	lcall	_ak820_outline_0089
      008F62 BF 07 02         [24] 2577 	cjne	r7,#0x07,00449$
      008F65 80 03            [24] 2578 	sjmp	00450$
      008F67                       2579 00449$:
      008F67 02 90 10         [24] 2580 	ljmp	00147$
      008F6A                       2581 00450$:
      008F6A                       2582 00146$:
                                   2583 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F6A 12 90 96         [24] 2584 	lcall	_ak820_outline_0000
      008F6D 12 40 AC         [24] 2585 	lcall	_eeprom_read_byte
      008F70 12 91 18         [24] 2586 	lcall	_ak820_outline_0179
                                   2587 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      008F73 70 03            [24] 2588 	jnz	00451$
      008F75 02 8E 6A         [24] 2589 	ljmp	00167$
      008F78                       2590 00451$:
                                   2591 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F78 12 90 96         [24] 2592 	lcall	_ak820_outline_0000
      008F7B 12 40 AC         [24] 2593 	lcall	_eeprom_read_byte
      008F7E AF 82            [24] 2594 	mov	r7, dpl
      008F80 90 0B 46         [24] 2595 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008F83 EF               [12] 2596 	mov	a,r7
      008F84 F0               [24] 2597 	movx	@dptr,a
                                   2598 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      008F85 EF               [12] 2599 	mov	a,r7
      008F86 70 03            [24] 2600 	jnz	00452$
      008F88 02 8E 6A         [24] 2601 	ljmp	00167$
      008F8B                       2602 00452$:
                                   2603 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008F8B 90 0B 45         [24] 2604 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008F8E E0               [24] 2605 	movx	a,@dptr
      008F8F FF               [12] 2606 	mov	r7,a
      008F90 90 0B 46         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008F93 E0               [24] 2608 	movx	a,@dptr
      008F94 FB               [12] 2609 	mov	r3,a
      008F95 E4               [12] 2610 	clr	a
      008F96 FC               [12] 2611 	mov	r4,a
      008F97 FA               [12] 2612 	mov	r2,a
      008F98 EF               [12] 2613 	mov	a,r7
      008F99 42 04            [12] 2614 	orl	ar4,a
      008F9B EA               [12] 2615 	mov	a,r2
      008F9C 42 03            [12] 2616 	orl	ar3,a
                                   2617 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      008F9E 12 43 C9         [24] 2618 	lcall	_ak820_outline_0182
      008FA1 C0 06            [24] 2619 	push	ar6
      008FA3 C0 05            [24] 2620 	push	ar5
      008FA5 12 8D B6         [24] 2621 	lcall	_decode_keycode
      008FA8 AC 82            [24] 2622 	mov	r4, dpl
      008FAA AF 83            [24] 2623 	mov	r7, dph
      008FAC D0 05            [24] 2624 	pop	ar5
      008FAE D0 06            [24] 2625 	pop	ar6
                                   2626 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008FB0 90 0B 44         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008FB3 E0               [24] 2628 	movx	a,@dptr
      008FB4 FB               [12] 2629 	mov	r3,a
      008FB5 BB 05 03         [24] 2630 	cjne	r3,#0x05,00453$
      008FB8 D3               [12] 2631 	setb	c
      008FB9 80 01            [24] 2632 	sjmp	00454$
      008FBB                       2633 00453$:
      008FBB C3               [12] 2634 	clr	c
      008FBC                       2635 00454$:
      008FBC 92 26            [24] 2636 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008FBE 90 09 88         [24] 2637 	mov	dptr,#_ak820_macro_primitive
      008FC1 B3               [12] 2638 	cpl	c
      008FC2 E4               [12] 2639 	clr	a
      008FC3 33               [12] 2640 	rlc	a
      008FC4 F0               [24] 2641 	movx	@dptr,a
                                   2642 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      008FC5 90 0B 44         [24] 2643 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008FC8 E0               [24] 2644 	movx	a,@dptr
      008FC9 FB               [12] 2645 	mov	r3,a
      008FCA BB 05 02         [24] 2646 	cjne	r3,#0x05,00455$
      008FCD 80 0A            [24] 2647 	sjmp	00126$
      008FCF                       2648 00455$:
      008FCF BB 06 02         [24] 2649 	cjne	r3,#0x06,00456$
      008FD2 80 16            [24] 2650 	sjmp	00127$
      008FD4                       2651 00456$:
                                   2652 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      008FD4 BB 07 33         [24] 2653 	cjne	r3,#0x07,00129$
      008FD7 80 22            [24] 2654 	sjmp	00128$
      008FD9                       2655 00126$:
                                   2656 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      008FD9 8C 82            [24] 2657 	mov	dpl, r4
      008FDB 8F 83            [24] 2658 	mov	dph, r7
      008FDD C0 06            [24] 2659 	push	ar6
      008FDF C0 05            [24] 2660 	push	ar5
      008FE1 12 B3 87         [24] 2661 	lcall	_vial_keycode_tap
      008FE4 D0 05            [24] 2662 	pop	ar5
      008FE6 D0 06            [24] 2663 	pop	ar6
                                   2664 ;	quantum/dynamic_keymap.c:795: break;
                                   2665 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      008FE8 80 20            [24] 2666 	sjmp	00129$
      008FEA                       2667 00127$:
                                   2668 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      008FEA 8C 82            [24] 2669 	mov	dpl, r4
      008FEC 8F 83            [24] 2670 	mov	dph, r7
      008FEE C0 06            [24] 2671 	push	ar6
      008FF0 C0 05            [24] 2672 	push	ar5
      008FF2 12 B2 BC         [24] 2673 	lcall	_vial_keycode_down
      008FF5 D0 05            [24] 2674 	pop	ar5
      008FF7 D0 06            [24] 2675 	pop	ar6
                                   2676 ;	quantum/dynamic_keymap.c:798: break;
                                   2677 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      008FF9 80 0F            [24] 2678 	sjmp	00129$
      008FFB                       2679 00128$:
                                   2680 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      008FFB 8C 82            [24] 2681 	mov	dpl, r4
      008FFD 8F 83            [24] 2682 	mov	dph, r7
      008FFF C0 06            [24] 2683 	push	ar6
      009001 C0 05            [24] 2684 	push	ar5
      009003 12 B3 22         [24] 2685 	lcall	_vial_keycode_up
      009006 D0 05            [24] 2686 	pop	ar5
      009008 D0 06            [24] 2687 	pop	ar6
                                   2688 ;	quantum/dynamic_keymap.c:802: }
      00900A                       2689 00129$:
                                   2690 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      00900A 12 91 00         [24] 2691 	lcall	_ak820_outline_0160
      00900D 02 8E 6A         [24] 2692 	ljmp	00167$
      009010                       2693 00147$:
                                   2694 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      009010 12 90 CE         [24] 2695 	lcall	_ak820_outline_0089
      009013 BF 04 02         [24] 2696 	cjne	r7,#0x04,00458$
      009016 80 03            [24] 2697 	sjmp	00459$
      009018                       2698 00458$:
      009018 02 8E 6A         [24] 2699 	ljmp	00167$
      00901B                       2700 00459$:
                                   2701 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00901B 12 90 96         [24] 2702 	lcall	_ak820_outline_0000
      00901E 12 40 AC         [24] 2703 	lcall	_eeprom_read_byte
      009021 AF 82            [24] 2704 	mov	r7, dpl
                                   2705 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009023 90 0B 41         [24] 2706 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009026 12 38 43         [24] 2707 	lcall	_ak820_outline_0101
      009029 90 0B 41         [24] 2708 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00902C 74 01            [12] 2709 	mov	a,#0x01
      00902E 2B               [12] 2710 	add	a, r3
      00902F F0               [24] 2711 	movx	@dptr,a
      009030 E4               [12] 2712 	clr	a
      009031 3C               [12] 2713 	addc	a, r4
      009032 A3               [24] 2714 	inc	dptr
      009033 F0               [24] 2715 	movx	@dptr,a
      009034 7A 00            [12] 2716 	mov	r2,#0x00
      009036 12 33 FC         [24] 2717 	lcall	_ak820_outline_0122
      009039 8A F0            [24] 2718 	mov	b, r2
      00903B 12 40 AC         [24] 2719 	lcall	_eeprom_read_byte
      00903E AC 82            [24] 2720 	mov	r4, dpl
                                   2721 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      009040 EF               [12] 2722 	mov	a,r7
      009041 60 4B            [24] 2723 	jz	00169$
      009043 EC               [12] 2724 	mov	a,r4
      009044 60 48            [24] 2725 	jz	00169$
                                   2726 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009046 1F               [12] 2727 	dec	r7
      009047 1C               [12] 2728 	dec	r4
      009048 EC               [12] 2729 	mov	a,r4
      009049 75 F0 FF         [24] 2730 	mov	b,#0xff
      00904C A4               [48] 2731 	mul	ab
      00904D FC               [12] 2732 	mov	r4,a
      00904E AB F0            [24] 2733 	mov	r3,b
      009050 7A 00            [12] 2734 	mov	r2,#0x00
      009052 EC               [12] 2735 	mov	a,r4
      009053 2F               [12] 2736 	add	a, r7
      009054 FC               [12] 2737 	mov	r4,a
      009055 EB               [12] 2738 	mov	a,r3
      009056 3A               [12] 2739 	addc	a, r2
      009057 FB               [12] 2740 	mov	r3,a
                                   2741 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009058                       2742 00141$:
      009058 8C 02            [24] 2743 	mov	ar2,r4
      00905A 8B 07            [24] 2744 	mov	ar7,r3
      00905C 1C               [12] 2745 	dec	r4
      00905D BC FF 01         [24] 2746 	cjne	r4,#0xff,00462$
      009060 1B               [12] 2747 	dec	r3
      009061                       2748 00462$:
      009061 EA               [12] 2749 	mov	a,r2
      009062 4F               [12] 2750 	orl	a,r7
      009063 70 03            [24] 2751 	jnz	00463$
      009065 02 8E 6A         [24] 2752 	ljmp	00167$
      009068                       2753 00463$:
      009068 90 00 01         [24] 2754 	mov	dptr,#0x0001
      00906B 12 59 E6         [24] 2755 	lcall	_mDelaymS
      00906E 80 E8            [24] 2756 	sjmp	00141$
      009070                       2757 00164$:
                                   2758 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009070 90 0B 43         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009073 E0               [24] 2760 	movx	a,@dptr
      009074 FF               [12] 2761 	mov	r7,a
      009075 BF 80 00         [24] 2762 	cjne	r7,#0x80,00464$
      009078                       2763 00464$:
      009078 50 14            [24] 2764 	jnc	00169$
                                   2765 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      00907A 90 0B 43         [24] 2766 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00907D E0               [24] 2767 	movx	a,@dptr
      00907E F5 82            [12] 2768 	mov	dpl,a
      009080 C0 06            [24] 2769 	push	ar6
      009082 C0 05            [24] 2770 	push	ar5
      009084 12 A6 24         [24] 2771 	lcall	_send_char
      009087 D0 05            [24] 2772 	pop	ar5
      009089 D0 06            [24] 2773 	pop	ar6
                                   2774 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      00908B 02 8E 6A         [24] 2775 	ljmp	00167$
      00908E                       2776 00169$:
                                   2777 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      00908E 12 91 00         [24] 2778 	lcall	_ak820_outline_0160
                                   2779 ;	quantum/dynamic_keymap.c:837: sending = false;
      009091 90 0B 40         [24] 2780 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      009094 F0               [24] 2781 	movx	@dptr,a
                                   2782 ;	quantum/dynamic_keymap.c:839: }
      009095 22               [24] 2783 	ret
                                   2784 	.area CSEG    (CODE)
                                   2785 	.area CONST   (CODE)
                                   2786 	.area XINIT   (CODE)
                                   2787 	.area CABS    (ABS,CODE)
                                   2788 
                                   2789 ; Experimental exact instruction outlining.
                                   2790 	.globl _ak820_outline_0000
                                   2791 	.globl _ak820_outline_0004
                                   2792 	.globl _ak820_outline_0011
                                   2793 	.globl _ak820_outline_0012
                                   2794 	.globl _ak820_outline_0017
                                   2795 	.globl _ak820_outline_0025
                                   2796 	.globl _ak820_outline_0031
                                   2797 	.globl _ak820_outline_0044
                                   2798 	.globl _ak820_outline_0051
                                   2799 	.globl _ak820_outline_0057
                                   2800 	.globl _ak820_outline_0059
                                   2801 	.globl _ak820_outline_0060
                                   2802 	.globl _ak820_outline_0061
                                   2803 	.globl _ak820_outline_0071
                                   2804 	.globl _ak820_outline_0076
                                   2805 	.globl _ak820_outline_0078
                                   2806 	.globl _ak820_outline_0087
                                   2807 	.globl _ak820_outline_0089
                                   2808 	.globl _ak820_outline_0095
                                   2809 	.globl _ak820_outline_0096
                                   2810 	.globl _ak820_outline_0100
                                   2811 	.globl _ak820_outline_0101
                                   2812 	.globl _ak820_outline_0104
                                   2813 	.globl _ak820_outline_0105
                                   2814 	.globl _ak820_outline_0113
                                   2815 	.globl _ak820_outline_0117
                                   2816 	.globl _ak820_outline_0118
                                   2817 	.globl _ak820_outline_0120
                                   2818 	.globl _ak820_outline_0121
                                   2819 	.globl _ak820_outline_0122
                                   2820 	.globl _ak820_outline_0123
                                   2821 	.globl _ak820_outline_0127
                                   2822 	.globl _ak820_outline_0131
                                   2823 	.globl _ak820_outline_0132
                                   2824 	.globl _ak820_outline_0133
                                   2825 	.globl _ak820_outline_0134
                                   2826 	.globl _ak820_outline_0139
                                   2827 	.globl _ak820_outline_0140
                                   2828 	.globl _ak820_outline_0145
                                   2829 	.globl _ak820_outline_0147
                                   2830 	.globl _ak820_outline_0151
                                   2831 	.globl _ak820_outline_0152
                                   2832 	.globl _ak820_outline_0155
                                   2833 	.globl _ak820_outline_0160
                                   2834 	.globl _ak820_outline_0175
                                   2835 	.globl _ak820_outline_0176
                                   2836 	.globl _ak820_outline_0179
                                   2837 	.globl _ak820_outline_0180
                                   2838 	.globl _ak820_outline_0181
                                   2839 	.globl _ak820_outline_0182
                                   2840 
                                   2841 	.area CSEG (CODE)
                                   2842 ; function ak820_outline_0000
      009096                       2843 _ak820_outline_0000:
      009096 90 0B 41         [24] 2844 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009099 E0               [24] 2845 	movx	a,@dptr
      00909A FC               [12] 2846 	mov	r4,a
      00909B A3               [24] 2847 	inc	dptr
      00909C E0               [24] 2848 	movx	a,@dptr
      00909D FF               [12] 2849 	mov	r7,a
      00909E 90 0B 41         [24] 2850 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0090A1 74 01            [12] 2851 	mov	a,#0x01
      0090A3 2C               [12] 2852 	add	a,r4
      0090A4 F0               [24] 2853 	movx	@dptr,a
      0090A5 E4               [12] 2854 	clr	a
      0090A6 3F               [12] 2855 	addc	a,r7
      0090A7 A3               [24] 2856 	inc	dptr
      0090A8 F0               [24] 2857 	movx	@dptr,a
      0090A9 7B 00            [12] 2858 	mov	r3,#0x00
      0090AB 8C 82            [24] 2859 	mov	dpl,r4
      0090AD 8F 83            [24] 2860 	mov	dph,r7
      0090AF 8B F0            [24] 2861 	mov	b,r3
      0090B1 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0025
      0090B2                       2866 _ak820_outline_0025:
      0090B2 2D               [12] 2867 	add	a,r5
      0090B3 F9               [12] 2868 	mov	r1,a
      0090B4 E4               [12] 2869 	clr	a
      0090B5 3E               [12] 2870 	addc	a,r6
      0090B6 FA               [12] 2871 	mov	r2,a
      0090B7 8F 03            [24] 2872 	mov	ar3,r7
      0090B9 89 82            [24] 2873 	mov	dpl,r1
      0090BB 8A 83            [24] 2874 	mov	dph,r2
      0090BD 8B F0            [24] 2875 	mov	b,r3
      0090BF 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0078
      0090C0                       2880 _ak820_outline_0078:
      0090C0 ED               [12] 2881 	mov	a,r5
      0090C1 75 F0 0A         [24] 2882 	mov	b,#0x0a
      0090C4 A4               [48] 2883 	mul	ab
      0090C5 24 58            [12] 2884 	add	a,#0x58
      0090C7 FC               [12] 2885 	mov	r4,a
      0090C8 74 06            [12] 2886 	mov	a,#0x06
      0090CA 35 F0            [12] 2887 	addc	a,b
      0090CC FD               [12] 2888 	mov	r5,a
      0090CD 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0089
      0090CE                       2893 _ak820_outline_0089:
      0090CE 90 0B 44         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      0090D1 E0               [24] 2895 	movx	a,@dptr
      0090D2 FF               [12] 2896 	mov	r7,a
      0090D3 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0095
      0090D4                       2901 _ak820_outline_0095:
      0090D4 90 0A DA         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0090D7 EE               [12] 2903 	mov	a,r6
      0090D8 F0               [24] 2904 	movx	@dptr,a
      0090D9 90 0A DB         [24] 2905 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0090DC ED               [12] 2906 	mov	a,r5
      0090DD F0               [24] 2907 	movx	@dptr,a
      0090DE 8F 82            [24] 2908 	mov	dpl,r7
      0090E0 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0113
      0090E1                       2913 _ak820_outline_0113:
      0090E1 AD 82            [24] 2914 	mov	r5,dpl
      0090E3 AE 83            [24] 2915 	mov	r6,dph
      0090E5 AF F0            [24] 2916 	mov	r7,b
      0090E7 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0127
      0090E8                       2921 _ak820_outline_0127:
      0090E8 28               [12] 2922 	add	a,r0
      0090E9 F5 82            [12] 2923 	mov	dpl,a
      0090EB EF               [12] 2924 	mov	a,r7
      0090EC 39               [12] 2925 	addc	a,r1
      0090ED F5 83            [12] 2926 	mov	dph,a
      0090EF 74 FF            [12] 2927 	mov	a,#0xff
      0090F1 F0               [24] 2928 	movx	@dptr,a
      0090F2 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0133
      0090F3                       2933 _ak820_outline_0133:
      0090F3 2D               [12] 2934 	add	a,r5
      0090F4 F9               [12] 2935 	mov	r1,a
      0090F5 E4               [12] 2936 	clr	a
      0090F6 3E               [12] 2937 	addc	a,r6
      0090F7 FA               [12] 2938 	mov	r2,a
      0090F8 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0147
      0090F9                       2943 _ak820_outline_0147:
      0090F9 90 0B 45         [24] 2944 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      0090FC E0               [24] 2945 	movx	a,@dptr
      0090FD F5 82            [12] 2946 	mov	dpl,a
      0090FF 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0160
      009100                       2951 _ak820_outline_0160:
      009100 90 09 88         [24] 2952 	mov	dptr,#_ak820_macro_primitive
      009103 E4               [12] 2953 	clr	a
      009104 F0               [24] 2954 	movx	@dptr,a
      009105 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0175
      009106                       2959 _ak820_outline_0175:
      009106 90 0A EA         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009109 E4               [12] 2961 	clr	a
      00910A F0               [24] 2962 	movx	@dptr,a
      00910B 90 0A EB         [24] 2963 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00910E 22               [24] 2964 	ret
                                   2965 
                                   2966 	.area CSEG (CODE)
                                   2967 ; function ak820_outline_0176
      00910F                       2968 _ak820_outline_0176:
      00910F 90 0B A0         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009112 E4               [12] 2970 	clr	a
      009113 F0               [24] 2971 	movx	@dptr,a
      009114 90 0B A1         [24] 2972 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009117 22               [24] 2973 	ret
                                   2974 
                                   2975 	.area CSEG (CODE)
                                   2976 ; function ak820_outline_0179
      009118                       2977 _ak820_outline_0179:
      009118 AF 82            [24] 2978 	mov	r7,dpl
      00911A 90 0B 45         [24] 2979 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00911D EF               [12] 2980 	mov	a,r7
      00911E F0               [24] 2981 	movx	@dptr,a
      00911F EF               [12] 2982 	mov	a,r7
      009120 22               [24] 2983 	ret
