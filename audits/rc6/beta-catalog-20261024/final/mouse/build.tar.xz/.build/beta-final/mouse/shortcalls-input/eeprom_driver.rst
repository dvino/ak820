                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000686                         85 _eeprom_read_word_addr_10000_91:
      000686                         86 	.ds 3
      000689                         87 _eeprom_read_word_ret_10000_92:
      000689                         88 	.ds 2
      00068B                         89 _eeprom_read_dword_addr_10000_93:
      00068B                         90 	.ds 3
      00068E                         91 _eeprom_read_dword_ret_10000_94:
      00068E                         92 	.ds 4
      000692                         93 _eeprom_write_byte_PARM_2:
      000692                         94 	.ds 1
      000693                         95 _eeprom_write_byte_addr_10000_95:
      000693                         96 	.ds 3
      000696                         97 _eeprom_write_word_PARM_2:
      000696                         98 	.ds 2
      000698                         99 _eeprom_write_word_addr_10000_97:
      000698                        100 	.ds 3
      00069B                        101 _eeprom_write_dword_PARM_2:
      00069B                        102 	.ds 4
      00069F                        103 _eeprom_write_dword_addr_10000_99:
      00069F                        104 	.ds 3
      0006A2                        105 _eeprom_update_byte_PARM_2:
      0006A2                        106 	.ds 1
      0006A3                        107 _eeprom_update_byte_addr_10000_107:
      0006A3                        108 	.ds 3
      0006A6                        109 _eeprom_update_word_PARM_2:
      0006A6                        110 	.ds 2
      0006A8                        111 _eeprom_update_word_addr_10000_111:
      0006A8                        112 	.ds 3
      0006AB                        113 _eeprom_update_dword_PARM_2:
      0006AB                        114 	.ds 4
      0006AF                        115 _eeprom_update_dword_addr_10000_115:
      0006AF                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004E2D                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004E2D 12 43 40         [24]  170 	lcall	_ak820_outline_0037
      004E30 90 06 86         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E33 12 37 E0         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004E36 90 06 89         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E39 12 50 39         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004E3C 90 06 86         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E3F 12 4F E7         [24]  178 	lcall	_ak820_outline_0022
      004E42 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E45 ED               [12]  180 	mov	a,r5
      004E46 12 37 E0         [24]  181 	lcall	_ak820_outline_0016
      004E49 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E4C 12 50 2B         [24]  183 	lcall	_ak820_outline_0106
      004E4F 90 06 89         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E52 12 40 DC         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004E55 90 06 89         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E58 12 50 22         [24]  188 	lcall	_ak820_outline_0089
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004E5B 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004E5C                        201 _eeprom_read_dword:
      004E5C 12 43 40         [24]  202 	lcall	_ak820_outline_0037
      004E5F 90 06 8B         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E62 12 37 E0         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004E65 90 06 8E         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E68 12 4F F7         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004E6B 90 06 8B         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E6E 12 4F E7         [24]  210 	lcall	_ak820_outline_0022
      004E71 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E74 ED               [12]  212 	mov	a,r5
      004E75 12 37 E0         [24]  213 	lcall	_ak820_outline_0016
      004E78 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E7B 74 04            [12]  215 	mov	a,#0x04
      004E7D 12 38 60         [24]  216 	lcall	_ak820_outline_0123
      004E80 90 06 8E         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E83 12 40 DC         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004E86 90 06 8E         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E89 12 50 00         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004E8C 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004E8D                        234 _eeprom_write_byte:
      004E8D 12 43 40         [24]  235 	lcall	_ak820_outline_0037
      004E90 90 06 93         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E93 12 37 E0         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004E96 90 06 93         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E99 12 4F C1         [24]  240 	lcall	_ak820_outline_0002
      004E9C 74 01            [12]  241 	mov	a,#0x01
      004E9E 12 38 60         [24]  242 	lcall	_ak820_outline_0123
      004EA1 90 06 92         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004EA4 02 41 68         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004EA7                        256 _eeprom_write_word:
      004EA7 12 43 40         [24]  257 	lcall	_ak820_outline_0037
      004EAA 90 06 98         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EAD 12 37 E0         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004EB0 90 06 98         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EB3 12 4F C1         [24]  262 	lcall	_ak820_outline_0002
      004EB6 12 50 2B         [24]  263 	lcall	_ak820_outline_0106
      004EB9 90 06 96         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004EBC 02 41 68         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004EBF                        277 _eeprom_write_dword:
      004EBF 12 43 40         [24]  278 	lcall	_ak820_outline_0037
      004EC2 90 06 9F         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EC5 12 37 E0         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004EC8 90 06 9F         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004ECB 12 4F C1         [24]  283 	lcall	_ak820_outline_0002
      004ECE 74 04            [12]  284 	mov	a,#0x04
      004ED0 12 38 60         [24]  285 	lcall	_ak820_outline_0123
      004ED3 90 06 9B         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004ED6 02 41 68         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004ED9                        307 _eeprom_update_byte:
      004ED9 C0 07            [24]  308 	push	ar7
      004EDB C0 06            [24]  309 	push	ar6
      004EDD C0 05            [24]  310 	push	ar5
      004EDF C0 04            [24]  311 	push	ar4
      004EE1 12 43 40         [24]  312 	lcall	_ak820_outline_0037
      004EE4 90 06 A3         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004EE7 12 37 E0         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004EEA 90 06 A3         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004EED 12 4F D8         [24]  317 	lcall	_ak820_outline_0003
      004EF0 12 40 A1         [24]  318 	lcall	_eeprom_read_byte
      004EF3 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004EF5 90 06 A2         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004EF8 E0               [24]  322 	movx	a,@dptr
      004EF9 FE               [12]  323 	mov	r6,a
      004EFA EF               [12]  324 	mov	a,r7
      004EFB B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004EFE 80 36            [24]  326 	sjmp	00103$
      004F00                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004F00 90 06 A3         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F03 12 38 20         [24]  330 	lcall	_ak820_outline_0060
      004F06 A3               [24]  331 	inc	dptr
      004F07 E0               [24]  332 	movx	a,@dptr
      004F08 FF               [12]  333 	mov	r7,a
      004F09 90 06 92         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004F0C EE               [12]  335 	mov	a,r6
      004F0D F0               [24]  336 	movx	@dptr,a
      004F0E 12 38 55         [24]  337 	lcall	_ak820_outline_0117
      004F11 8F F0            [24]  338 	mov	b, r7
      004F13 C0 07            [24]  339 	push	ar7
      004F15 C0 06            [24]  340 	push	ar6
      004F17 C0 05            [24]  341 	push	ar5
      004F19 C0 04            [24]  342 	push	ar4
      004F1B C0 03            [24]  343 	push	ar3
      004F1D C0 02            [24]  344 	push	ar2
      004F1F C0 01            [24]  345 	push	ar1
      004F21 C0 00            [24]  346 	push	ar0
      004F23 12 4E 8D         [24]  347 	lcall	_eeprom_write_byte
      004F26 D0 00            [24]  348 	pop	ar0
      004F28 D0 01            [24]  349 	pop	ar1
      004F2A D0 02            [24]  350 	pop	ar2
      004F2C D0 03            [24]  351 	pop	ar3
      004F2E D0 04            [24]  352 	pop	ar4
      004F30 D0 05            [24]  353 	pop	ar5
      004F32 D0 06            [24]  354 	pop	ar6
      004F34 D0 07            [24]  355 	pop	ar7
      004F36                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      004F36 D0 04            [24]  358 	pop	ar4
      004F38 D0 05            [24]  359 	pop	ar5
      004F3A D0 06            [24]  360 	pop	ar6
      004F3C D0 07            [24]  361 	pop	ar7
      004F3E 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      004F3F                        374 _eeprom_update_word:
      004F3F 12 43 40         [24]  375 	lcall	_ak820_outline_0037
      004F42 90 06 A8         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F45 12 37 E0         [24]  377 	lcall	_ak820_outline_0016
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004F48 90 06 A8         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F4B 12 4F D8         [24]  380 	lcall	_ak820_outline_0003
      004F4E 12 4E 2D         [24]  381 	lcall	_eeprom_read_word
      004F51 12 43 94         [24]  382 	lcall	_ak820_outline_0131
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004F54 90 06 A6         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      004F57 12 38 20         [24]  385 	lcall	_ak820_outline_0060
      004F5A EE               [12]  386 	mov	a,r6
      004F5B B5 04 05         [24]  387 	cjne	a,ar4,00112$
      004F5E EF               [12]  388 	mov	a,r7
      004F5F B5 05 01         [24]  389 	cjne	a,ar5,00112$
      004F62 22               [24]  390 	ret
      004F63                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004F63 90 06 A8         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F66 E0               [24]  394 	movx	a,@dptr
      004F67 FB               [12]  395 	mov	r3,a
      004F68 A3               [24]  396 	inc	dptr
      004F69 12 38 01         [24]  397 	lcall	_ak820_outline_0051
      004F6C 90 06 96         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      004F6F 12 38 26         [24]  399 	lcall	_ak820_outline_0071
      004F72 8B 82            [24]  400 	mov	dpl, r3
      004F74 8E 83            [24]  401 	mov	dph, r6
      004F76 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      004F78 02 4E A7         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      004F7B                        416 _eeprom_update_dword:
      004F7B 12 43 40         [24]  417 	lcall	_ak820_outline_0037
      004F7E 90 06 AF         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F81 12 37 E0         [24]  419 	lcall	_ak820_outline_0016
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004F84 90 06 AF         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F87 12 4F D8         [24]  422 	lcall	_ak820_outline_0003
      004F8A 12 4E 5C         [24]  423 	lcall	_eeprom_read_dword
      004F8D 12 50 11         [24]  424 	lcall	_ak820_outline_0057
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004F90 90 06 AB         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      004F93 E0               [24]  427 	movx	a,@dptr
      004F94 F8               [12]  428 	mov	r0,a
      004F95 A3               [24]  429 	inc	dptr
      004F96 12 50 19         [24]  430 	lcall	_ak820_outline_0088
      004F99 EC               [12]  431 	mov	a,r4
      004F9A B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      004F9D ED               [12]  433 	mov	a,r5
      004F9E B5 01 09         [24]  434 	cjne	a,ar1,00112$
      004FA1 EE               [12]  435 	mov	a,r6
      004FA2 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      004FA5 EF               [12]  437 	mov	a,r7
      004FA6 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      004FA9 22               [24]  439 	ret
      004FAA                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004FAA 90 06 AF         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FAD 12 4F E7         [24]  443 	lcall	_ak820_outline_0022
      004FB0 90 06 9B         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      004FB3 E8               [12]  445 	mov	a,r0
      004FB4 F0               [24]  446 	movx	@dptr,a
      004FB5 E9               [12]  447 	mov	a,r1
      004FB6 A3               [24]  448 	inc	dptr
      004FB7 12 50 32         [24]  449 	lcall	_ak820_outline_0154
      004FBA F0               [24]  450 	movx	@dptr,a
      004FBB 12 4F F0         [24]  451 	lcall	_ak820_outline_0044
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      004FBE 02 4E BF         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0016
                                    463 	.globl _ak820_outline_0022
                                    464 	.globl _ak820_outline_0037
                                    465 	.globl _ak820_outline_0044
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0060
                                    471 	.globl _ak820_outline_0071
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0089
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0123
                                    477 	.globl _ak820_outline_0131
                                    478 	.globl _ak820_outline_0154
                                    479 	.globl _ak820_outline_0166
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      004FC1                        483 _ak820_outline_0002:
      004FC1 E0               [24]  484 	movx	a,@dptr
      004FC2 FD               [12]  485 	mov	r5,a
      004FC3 A3               [24]  486 	inc	dptr
      004FC4 E0               [24]  487 	movx	a,@dptr
      004FC5 FE               [12]  488 	mov	r6,a
      004FC6 A3               [24]  489 	inc	dptr
      004FC7 E0               [24]  490 	movx	a,@dptr
      004FC8 FF               [12]  491 	mov	r7,a
      004FC9 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004FCC ED               [12]  493 	mov	a,r5
      004FCD F0               [24]  494 	movx	@dptr,a
      004FCE EE               [12]  495 	mov	a,r6
      004FCF A3               [24]  496 	inc	dptr
      004FD0 F0               [24]  497 	movx	@dptr,a
      004FD1 EF               [12]  498 	mov	a,r7
      004FD2 A3               [24]  499 	inc	dptr
      004FD3 F0               [24]  500 	movx	@dptr,a
      004FD4 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004FD7 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      004FD8                        506 _ak820_outline_0003:
      004FD8 E0               [24]  507 	movx	a,@dptr
      004FD9 FD               [12]  508 	mov	r5,a
      004FDA A3               [24]  509 	inc	dptr
      004FDB E0               [24]  510 	movx	a,@dptr
      004FDC FE               [12]  511 	mov	r6,a
      004FDD A3               [24]  512 	inc	dptr
      004FDE E0               [24]  513 	movx	a,@dptr
      004FDF FF               [12]  514 	mov	r7,a
      004FE0 8D 82            [24]  515 	mov	dpl,r5
      004FE2 8E 83            [24]  516 	mov	dph,r6
      004FE4 8F F0            [24]  517 	mov	b,r7
      004FE6 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0022
      004FE7                        522 _ak820_outline_0022:
      004FE7 E0               [24]  523 	movx	a,@dptr
      004FE8 FD               [12]  524 	mov	r5,a
      004FE9 A3               [24]  525 	inc	dptr
      004FEA E0               [24]  526 	movx	a,@dptr
      004FEB FE               [12]  527 	mov	r6,a
      004FEC A3               [24]  528 	inc	dptr
      004FED E0               [24]  529 	movx	a,@dptr
      004FEE FF               [12]  530 	mov	r7,a
      004FEF 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0044
      004FF0                        535 _ak820_outline_0044:
      004FF0 8D 82            [24]  536 	mov	dpl,r5
      004FF2 8E 83            [24]  537 	mov	dph,r6
      004FF4 8F F0            [24]  538 	mov	b,r7
      004FF6 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0049
      004FF7                        543 _ak820_outline_0049:
      004FF7 E4               [12]  544 	clr	a
      004FF8 F0               [24]  545 	movx	@dptr,a
      004FF9 A3               [24]  546 	inc	dptr
      004FFA F0               [24]  547 	movx	@dptr,a
      004FFB A3               [24]  548 	inc	dptr
      004FFC F0               [24]  549 	movx	@dptr,a
      004FFD A3               [24]  550 	inc	dptr
      004FFE F0               [24]  551 	movx	@dptr,a
      004FFF 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0054
      005000                        556 _ak820_outline_0054:
      005000 E0               [24]  557 	movx	a,@dptr
      005001 FC               [12]  558 	mov	r4,a
      005002 A3               [24]  559 	inc	dptr
      005003 E0               [24]  560 	movx	a,@dptr
      005004 FD               [12]  561 	mov	r5,a
      005005 A3               [24]  562 	inc	dptr
      005006 E0               [24]  563 	movx	a,@dptr
      005007 FE               [12]  564 	mov	r6,a
      005008 A3               [24]  565 	inc	dptr
      005009 E0               [24]  566 	movx	a,@dptr
      00500A 8C 82            [24]  567 	mov	dpl,r4
      00500C 8D 83            [24]  568 	mov	dph,r5
      00500E 8E F0            [24]  569 	mov	b,r6
      005010 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0057
      005011                        574 _ak820_outline_0057:
      005011 AC 82            [24]  575 	mov	r4,dpl
      005013 AD 83            [24]  576 	mov	r5,dph
      005015 AE F0            [24]  577 	mov	r6,b
      005017 FF               [12]  578 	mov	r7,a
      005018 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0088
      005019                        583 _ak820_outline_0088:
      005019 E0               [24]  584 	movx	a,@dptr
      00501A F9               [12]  585 	mov	r1,a
      00501B A3               [24]  586 	inc	dptr
      00501C E0               [24]  587 	movx	a,@dptr
      00501D FA               [12]  588 	mov	r2,a
      00501E A3               [24]  589 	inc	dptr
      00501F E0               [24]  590 	movx	a,@dptr
      005020 FB               [12]  591 	mov	r3,a
      005021 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0089
      005022                        596 _ak820_outline_0089:
      005022 E0               [24]  597 	movx	a,@dptr
      005023 FE               [12]  598 	mov	r6,a
      005024 A3               [24]  599 	inc	dptr
      005025 E0               [24]  600 	movx	a,@dptr
      005026 8E 82            [24]  601 	mov	dpl,r6
      005028 F5 83            [12]  602 	mov	dph,a
      00502A 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      00502B                        607 _ak820_outline_0106:
      00502B 74 02            [12]  608 	mov	a,#0x02
      00502D F0               [24]  609 	movx	@dptr,a
      00502E E4               [12]  610 	clr	a
      00502F A3               [24]  611 	inc	dptr
      005030 F0               [24]  612 	movx	@dptr,a
      005031 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0154
      005032                        617 _ak820_outline_0154:
      005032 F0               [24]  618 	movx	@dptr,a
      005033 EA               [12]  619 	mov	a,r2
      005034 A3               [24]  620 	inc	dptr
      005035 F0               [24]  621 	movx	@dptr,a
      005036 EB               [12]  622 	mov	a,r3
      005037 A3               [24]  623 	inc	dptr
      005038 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0166
      005039                        628 _ak820_outline_0166:
      005039 E4               [12]  629 	clr	a
      00503A F0               [24]  630 	movx	@dptr,a
      00503B A3               [24]  631 	inc	dptr
      00503C F0               [24]  632 	movx	@dptr,a
      00503D 22               [24]  633 	ret
