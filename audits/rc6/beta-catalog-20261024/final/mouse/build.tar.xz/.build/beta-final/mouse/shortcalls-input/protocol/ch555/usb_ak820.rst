                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000014                        578 _control_setup_valid_interface_10000_290:
      000014                        579 	.ds 1
      000015                        580 _control_setup_zero_index_10000_290:
      000015                        581 	.ds 1
      000016                        582 _control_setup_zero_value_10000_290:
      000016                        583 	.ds 1
      000017                        584 _control_setup_zero_length_10000_290:
      000017                        585 	.ds 1
      000018                        586 _control_setup_sloc0_1_0:
      000018                        587 	.ds 1
      000019                        588 _control_setup_sloc2_1_0:
      000019                        589 	.ds 1
      00001A                        590 _ak820_usb_try_send_sloc0_1_0:
      00001A                        591 	.ds 1
      00001B                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001B                        593 	.ds 1
      00001C                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001C                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      00077F                        604 _D0SetupReqCode::
      00077F                        605 	.ds 1
      000780                        606 _D0SetupLen::
      000780                        607 	.ds 2
      000782                        608 _pD0Descr::
      000782                        609 	.ds 3
      000785                        610 _D0UsbConfig::
      000785                        611 	.ds 1
      000786                        612 _USB_EnumStatus::
      000786                        613 	.ds 1
      000787                        614 _USB_SleepStatus::
      000787                        615 	.ds 1
      000788                        616 _MCU_Sleep_Operate::
      000788                        617 	.ds 1
      000789                        618 _KB_USB_UpStatus::
      000789                        619 	.ds 1
      00078A                        620 _KB_USB_SetReport::
      00078A                        621 	.ds 1
      00078B                        622 _ak820_boot_stage::
      00078B                        623 	.ds 1
      00078C                        624 _ak820_main_heartbeat::
      00078C                        625 	.ds 1
      00078D                        626 _raw_state:
      00078D                        627 	.ds 1
      00078E                        628 _raw_buffer:
      00078E                        629 	.ds 32
      0007AE                        630 _raw_reply_without_nvm:
      0007AE                        631 	.ds 1
      0007AF                        632 _keyboard_reset:
      0007AF                        633 	.ds 1
      0007B0                        634 _input_snapshot:
      0007B0                        635 	.ds 52
      0007E4                        636 _control_phase:
      0007E4                        637 	.ds 1
      0007E5                        638 _output_kind:
      0007E5                        639 	.ds 1
      0007E6                        640 _output_report_id:
      0007E6                        641 	.ds 1
      0007E7                        642 _control_zlp:
      0007E7                        643 	.ds 1
      0007E8                        644 _control_pointer:
      0007E8                        645 	.ds 2
      0007EA                        646 _descriptor_select_PARM_2:
      0007EA                        647 	.ds 1
      0007EB                        648 _descriptor_select_PARM_3:
      0007EB                        649 	.ds 2
      0007ED                        650 _descriptor_select_type_10000_272:
      0007ED                        651 	.ds 1
      0007EE                        652 _control_setup_length_10000_290:
      0007EE                        653 	.ds 2
      0007F0                        654 _control_setup_offset_10000_290:
      0007F0                        655 	.ds 1
      0007F1                        656 _ak820_usb_send_PARM_2:
      0007F1                        657 	.ds 2
      0007F3                        658 _ak820_usb_send_PARM_3:
      0007F3                        659 	.ds 1
      0007F4                        660 _ak820_usb_send_endpoint_10000_426:
      0007F4                        661 	.ds 1
      0007F5                        662 _ak820_usb_send_offset_10000_427:
      0007F5                        663 	.ds 1
      0007F6                        664 _ak820_usb_try_send_PARM_2:
      0007F6                        665 	.ds 2
      0007F8                        666 _ak820_usb_try_send_PARM_3:
      0007F8                        667 	.ds 1
      0007F9                        668 _ak820_usb_try_send_endpoint_10000_447:
      0007F9                        669 	.ds 1
      0007FA                        670 _ak820_usb_try_send_sent_10000_448:
      0007FA                        671 	.ds 1
      0007FB                        672 _ak820_usb_raw_send_PARM_2:
      0007FB                        673 	.ds 1
      0007FC                        674 _ak820_usb_raw_send_report_10000_463:
      0007FC                        675 	.ds 3
      0007FF                        676 _ak820_usb_raw_task_length_10000_468:
      0007FF                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005D82                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D82 90 07 8D         [24]  731 	mov	dptr,#_raw_state
      005D85 E0               [24]  732 	movx	a,@dptr
      005D86 FF               [12]  733 	mov	r7,a
      005D87 BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005D8A 80 1C            [24]  735 	sjmp	00101$
      005D8C                        736 00130$:
      005D8C 90 07 8D         [24]  737 	mov	dptr,#_raw_state
      005D8F E0               [24]  738 	movx	a,@dptr
      005D90 FF               [12]  739 	mov	r7,a
      005D91 BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005D94 80 12            [24]  741 	sjmp	00101$
      005D96                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005D96 90 07 8D         [24]  744 	mov	dptr,#_raw_state
      005D99 E0               [24]  745 	movx	a,@dptr
      005D9A FF               [12]  746 	mov	r7,a
      005D9B BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005D9E 80 08            [24]  748 	sjmp	00101$
      005DA0                        749 00132$:
      005DA0 90 07 8D         [24]  750 	mov	dptr,#_raw_state
      005DA3 E0               [24]  751 	movx	a,@dptr
      005DA4 FF               [12]  752 	mov	r7,a
      005DA5 BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      005DA8                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005DA8 90 07 8D         [24]  756 	mov	dptr,#_raw_state
      005DAB 74 07            [12]  757 	mov	a,#0x07
      005DAD F0               [24]  758 	movx	@dptr,a
      005DAE 80 05            [24]  759 	sjmp	00103$
      005DB0                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005DB0 90 07 8D         [24]  762 	mov	dptr,#_raw_state
      005DB3 E4               [12]  763 	clr	a
      005DB4 F0               [24]  764 	movx	@dptr,a
      005DB5                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005DB5 90 07 E5         [24]  767 	mov	dptr,#_output_kind
      005DB8 E4               [12]  768 	clr	a
      005DB9 F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005DBA 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      005DBB                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005DBB 90 07 8D         [24]  781 	mov	dptr,#_raw_state
      005DBE E0               [24]  782 	movx	a,@dptr
      005DBF FF               [12]  783 	mov	r7,a
      005DC0 BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      005DC3 90 07 8D         [24]  785 	mov	dptr,#_raw_state
      005DC6 74 06            [12]  786 	mov	a,#0x06
      005DC8 F0               [24]  787 	movx	@dptr,a
      005DC9 22               [24]  788 	ret
      005DCA                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005DCA 90 07 8D         [24]  791 	mov	dptr,#_raw_state
      005DCD E0               [24]  792 	movx	a,@dptr
      005DCE FF               [12]  793 	mov	r7,a
      005DCF BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      005DD2 90 07 8D         [24]  795 	mov	dptr,#_raw_state
      005DD5 E4               [12]  796 	clr	a
      005DD6 F0               [24]  797 	movx	@dptr,a
      005DD7                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005DD7 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_262'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      005DD8                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      005DD8 90 05 9A         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      005DDB E4               [12]  813 	clr	a
      005DDC F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005DDD 90 22 0C         [24]  816 	mov	dptr,#0x220c
      005DE0 04               [12]  817 	inc	a
      005DE1 F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE2 F5 82            [12]  820 	mov	dpl,a
      005DE4 74 12            [12]  821 	mov	a,#0x12
      005DE6 F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE7 A3               [24]  824 	inc	dptr
      005DE8 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE9 A3               [24]  827 	inc	dptr
      005DEA F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005DEB 90 22 0B         [24]  830 	mov	dptr,#0x220b
      005DEE E4               [12]  831 	clr	a
      005DEF F0               [24]  832 	movx	@dptr,a
      005DF0 15 82            [12]  833 	dec	dpl
      005DF2 F0               [24]  834 	movx	@dptr,a
      005DF3 15 82            [12]  835 	dec	dpl
      005DF5 F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005DF6 FF               [12]  838 	mov	r7,a
      005DF7                        839 00103$:
      005DF7 EF               [12]  840 	mov	a,r7
      005DF8 24 B0            [12]  841 	add	a, #_input_snapshot
      005DFA F5 82            [12]  842 	mov	dpl,a
      005DFC E4               [12]  843 	clr	a
      005DFD 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      005DFF F5 83            [12]  845 	mov	dph,a
      005E01 E4               [12]  846 	clr	a
      005E02 F0               [24]  847 	movx	@dptr,a
      005E03 0F               [12]  848 	inc	r7
      005E04 BF 34 00         [24]  849 	cjne	r7,#0x34,00139$
      005E07                        850 00139$:
      005E07 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005E09 90 07 B8         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      005E0C 74 06            [12]  854 	mov	a,#0x06
      005E0E F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:124: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005E0F 90 07 D8         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      005E12 74 02            [12]  858 	mov	a,#0x02
      005E14 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005E15 90 07 DE         [24]  861 	mov	dptr,#(_input_snapshot + 0x002e)
      005E18 04               [12]  862 	inc	a
      005E19 F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005E1A 90 07 E1         [24]  865 	mov	dptr,#(_input_snapshot + 0x0031)
      005E1D 04               [12]  866 	inc	a
      005E1E F0               [24]  867 	movx	@dptr,a
                                    868 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005E1F 7F 00            [12]  869 	mov	r7,#0x00
      005E21                        870 00105$:
      005E21 8F 06            [24]  871 	mov	ar6,r7
      005E23 74 C0            [12]  872 	mov	a,#0xc0
      005E25 2E               [12]  873 	add	a, r6
      005E26 F5 82            [12]  874 	mov	dpl,a
      005E28 74 10            [12]  875 	mov	a,#0x10
      005E2A 24 00            [12]  876 	add	a, #0x00
      005E2C F5 83            [12]  877 	mov	dph,a
      005E2E E4               [12]  878 	clr	a
      005E2F F0               [24]  879 	movx	@dptr,a
      005E30 0F               [12]  880 	inc	r7
      005E31 BF 20 00         [24]  881 	cjne	r7,#0x20,00141$
      005E34                        882 00141$:
      005E34 40 EB            [24]  883 	jc	00105$
                                    884 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    885 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005E36 02 5D 82         [24]  886 	ljmp	_raw_abort
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'control_stall'
                                    889 ;------------------------------------------------------------
                                    890 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function control_stall
                                    893 ;	-----------------------------------------
      005E39                        894 _control_stall:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005E39 90 07 8D         [24]  896 	mov	dptr,#_raw_state
      005E3C E0               [24]  897 	movx	a,@dptr
      005E3D FF               [12]  898 	mov	r7,a
      005E3E BF 01 05         [24]  899 	cjne	r7,#0x01,00102$
      005E41 90 07 8D         [24]  900 	mov	dptr,#_raw_state
      005E44 E4               [12]  901 	clr	a
      005E45 F0               [24]  902 	movx	@dptr,a
      005E46                        903 00102$:
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005E46 90 07 E5         [24]  905 	mov	dptr,#_output_kind
      005E49 E4               [12]  906 	clr	a
      005E4A F0               [24]  907 	movx	@dptr,a
                                    908 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005E4B 90 07 E4         [24]  909 	mov	dptr,#_control_phase
      005E4E F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005E4F 90 07 7F         [24]  912 	mov	dptr,#_D0SetupReqCode
      005E52 14               [12]  913 	dec	a
      005E53 F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005E54 90 22 00         [24]  916 	mov	dptr,#0x2200
      005E57 74 CF            [12]  917 	mov	a,#0xcf
      005E59 F0               [24]  918 	movx	@dptr,a
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005E5A 22               [24]  920 	ret
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'control_next'
                                    923 ;------------------------------------------------------------
                                    924 ;i             Allocated with name '_control_next_i_10000_269'
                                    925 ;length        Allocated with name '_control_next_length_10000_269'
                                    926 ;------------------------------------------------------------
                                    927 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    928 ;	-----------------------------------------
                                    929 ;	 function control_next
                                    930 ;	-----------------------------------------
      005E5B                        931 _control_next:
                                    932 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005E5B 90 07 80         [24]  933 	mov	dptr,#_D0SetupLen
      005E5E E0               [24]  934 	movx	a,@dptr
      005E5F FE               [12]  935 	mov	r6,a
      005E60 A3               [24]  936 	inc	dptr
      005E61 E0               [24]  937 	movx	a,@dptr
      005E62 FF               [12]  938 	mov	r7,a
      005E63 C3               [12]  939 	clr	c
      005E64 74 40            [12]  940 	mov	a,#0x40
      005E66 9E               [12]  941 	subb	a,r6
      005E67 E4               [12]  942 	clr	a
      005E68 9F               [12]  943 	subb	a,r7
      005E69 50 04            [24]  944 	jnc	00109$
                                    945 ;	free result
      005E6B 7E 40            [12]  946 	mov	r6,#0x40
      005E6D 80 07            [24]  947 	sjmp	00110$
      005E6F                        948 00109$:
      005E6F 90 07 80         [24]  949 	mov	dptr,#_D0SetupLen
      005E72 E0               [24]  950 	movx	a,@dptr
      005E73 FE               [12]  951 	mov	r6,a
      005E74 A3               [24]  952 	inc	dptr
      005E75 E0               [24]  953 	movx	a,@dptr
      005E76                        954 00110$:
                                    955 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E76 7F 00            [12]  956 	mov	r7,#0x00
      005E78                        957 00105$:
      005E78 C3               [12]  958 	clr	c
      005E79 EF               [12]  959 	mov	a,r7
      005E7A 9E               [12]  960 	subb	a,r6
      005E7B 50 2A            [24]  961 	jnc	00101$
      005E7D 8F 04            [24]  962 	mov	ar4,r7
      005E7F 74 10            [12]  963 	mov	a,#0x10
      005E81 24 00            [12]  964 	add	a, #0x00
      005E83 FD               [12]  965 	mov	r5,a
      005E84 90 07 E8         [24]  966 	mov	dptr,#_control_pointer
      005E87 E0               [24]  967 	movx	a,@dptr
      005E88 FA               [12]  968 	mov	r2,a
      005E89 A3               [24]  969 	inc	dptr
      005E8A E0               [24]  970 	movx	a,@dptr
      005E8B FB               [12]  971 	mov	r3,a
      005E8C 8A 82            [24]  972 	mov	dpl,r2
      005E8E 8B 83            [24]  973 	mov	dph,r3
      005E90 E4               [12]  974 	clr	a
      005E91 93               [24]  975 	movc	a,@a+dptr
      005E92 F9               [12]  976 	mov	r1,a
      005E93 90 07 E8         [24]  977 	mov	dptr,#_control_pointer
      005E96 74 01            [12]  978 	mov	a,#0x01
      005E98 2A               [12]  979 	add	a, r2
      005E99 F0               [24]  980 	movx	@dptr,a
      005E9A E4               [12]  981 	clr	a
      005E9B 3B               [12]  982 	addc	a, r3
      005E9C A3               [24]  983 	inc	dptr
      005E9D F0               [24]  984 	movx	@dptr,a
      005E9E 8C 82            [24]  985 	mov	dpl,r4
      005EA0 8D 83            [24]  986 	mov	dph,r5
      005EA2 E9               [12]  987 	mov	a,r1
      005EA3 F0               [24]  988 	movx	@dptr,a
      005EA4 0F               [12]  989 	inc	r7
      005EA5 80 D1            [24]  990 	sjmp	00105$
      005EA7                        991 00101$:
                                    992 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005EA7 8E 05            [24]  993 	mov	ar5,r6
      005EA9 7F 00            [12]  994 	mov	r7,#0x00
      005EAB 90 07 80         [24]  995 	mov	dptr,#_D0SetupLen
      005EAE E0               [24]  996 	movx	a,@dptr
      005EAF FB               [12]  997 	mov	r3,a
      005EB0 A3               [24]  998 	inc	dptr
      005EB1 E0               [24]  999 	movx	a,@dptr
      005EB2 FC               [12] 1000 	mov	r4,a
      005EB3 EB               [12] 1001 	mov	a,r3
      005EB4 C3               [12] 1002 	clr	c
      005EB5 9D               [12] 1003 	subb	a,r5
      005EB6 FB               [12] 1004 	mov	r3,a
      005EB7 EC               [12] 1005 	mov	a,r4
      005EB8 9F               [12] 1006 	subb	a,r7
      005EB9 FC               [12] 1007 	mov	r4,a
      005EBA 90 07 80         [24] 1008 	mov	dptr,#_D0SetupLen
      005EBD EB               [12] 1009 	mov	a,r3
      005EBE F0               [24] 1010 	movx	@dptr,a
      005EBF EC               [12] 1011 	mov	a,r4
      005EC0 A3               [24] 1012 	inc	dptr
      005EC1 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005EC2 EE               [12] 1015 	mov	a,r6
      005EC3 70 05            [24] 1016 	jnz	00103$
      005EC5 90 07 E7         [24] 1017 	mov	dptr,#_control_zlp
      005EC8 E4               [12] 1018 	clr	a
      005EC9 F0               [24] 1019 	movx	@dptr,a
      005ECA                       1020 00103$:
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005ECA 90 22 08         [24] 1022 	mov	dptr,#0x2208
      005ECD EE               [12] 1023 	mov	a,r6
      005ECE F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005ECF 90 22 00         [24] 1026 	mov	dptr,#0x2200
      005ED2 E0               [24] 1027 	movx	a,@dptr
      005ED3 54 C0            [12] 1028 	anl	a,#0xc0
      005ED5 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005ED6 22               [24] 1031 	ret
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'descriptor_select'
                                   1034 ;------------------------------------------------------------
                                   1035 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1036 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1037 ;type          Allocated with name '_descriptor_select_type_10000_272'
                                   1038 ;hid           Allocated with name '_descriptor_select_hid_30000_285'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function descriptor_select
                                   1043 ;	-----------------------------------------
      005ED7                       1044 _descriptor_select:
      005ED7 E5 82            [12] 1045 	mov	a,dpl
      005ED9 90 07 ED         [24] 1046 	mov	dptr,#_descriptor_select_type_10000_272
      005EDC F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005EDD E0               [24] 1049 	movx	a,@dptr
      005EDE FF               [12] 1050 	mov	r7,a
      005EDF BF 01 20         [24] 1051 	cjne	r7,#0x01,00102$
      005EE2 90 07 EA         [24] 1052 	mov	dptr,#_descriptor_select_PARM_2
      005EE5 E0               [24] 1053 	movx	a,@dptr
      005EE6 70 1A            [24] 1054 	jnz	00102$
      005EE8 90 07 EB         [24] 1055 	mov	dptr,#_descriptor_select_PARM_3
      005EEB E0               [24] 1056 	movx	a,@dptr
      005EEC F5 F0            [12] 1057 	mov	b,a
      005EEE A3               [24] 1058 	inc	dptr
      005EEF E0               [24] 1059 	movx	a,@dptr
      005EF0 45 F0            [12] 1060 	orl	a,b
      005EF2 70 0E            [24] 1061 	jnz	00102$
                                   1062 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005EF4 90 07 E8         [24] 1063 	mov	dptr,#_control_pointer
      005EF7 74 22            [12] 1064 	mov	a,#_DeviceDescriptor
      005EF9 F0               [24] 1065 	movx	@dptr,a
      005EFA 74 C3            [12] 1066 	mov	a,#(_DeviceDescriptor >> 8)
      005EFC A3               [24] 1067 	inc	dptr
      005EFD F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005EFE 90 00 12         [24] 1070 	mov	dptr,#0x0012
      005F01 22               [24] 1071 	ret
      005F02                       1072 00102$:
                                   1073 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005F02 90 07 ED         [24] 1074 	mov	dptr,#_descriptor_select_type_10000_272
      005F05 E0               [24] 1075 	movx	a,@dptr
      005F06 FF               [12] 1076 	mov	r7,a
      005F07 BF 02 20         [24] 1077 	cjne	r7,#0x02,00106$
      005F0A 90 07 EA         [24] 1078 	mov	dptr,#_descriptor_select_PARM_2
      005F0D E0               [24] 1079 	movx	a,@dptr
      005F0E 70 1A            [24] 1080 	jnz	00106$
      005F10 90 07 EB         [24] 1081 	mov	dptr,#_descriptor_select_PARM_3
      005F13 E0               [24] 1082 	movx	a,@dptr
      005F14 F5 F0            [12] 1083 	mov	b,a
      005F16 A3               [24] 1084 	inc	dptr
      005F17 E0               [24] 1085 	movx	a,@dptr
      005F18 45 F0            [12] 1086 	orl	a,b
      005F1A 70 0E            [24] 1087 	jnz	00106$
                                   1088 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005F1C 90 07 E8         [24] 1089 	mov	dptr,#_control_pointer
      005F1F 74 34            [12] 1090 	mov	a,#_ConfigurationDescriptor
      005F21 F0               [24] 1091 	movx	@dptr,a
      005F22 74 C3            [12] 1092 	mov	a,#(_ConfigurationDescriptor >> 8)
      005F24 A3               [24] 1093 	inc	dptr
      005F25 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005F26 90 00 54         [24] 1096 	mov	dptr,#0x0054
      005F29 22               [24] 1097 	ret
      005F2A                       1098 00106$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005F2A 90 07 ED         [24] 1100 	mov	dptr,#_descriptor_select_type_10000_272
      005F2D E0               [24] 1101 	movx	a,@dptr
      005F2E FF               [12] 1102 	mov	r7,a
      005F2F BF 03 02         [24] 1103 	cjne	r7,#0x03,00238$
      005F32 80 03            [24] 1104 	sjmp	00239$
      005F34                       1105 00238$:
      005F34 02 5F CE         [24] 1106 	ljmp	00119$
      005F37                       1107 00239$:
                                   1108 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005F37 90 07 EB         [24] 1109 	mov	dptr,#_descriptor_select_PARM_3
      005F3A E0               [24] 1110 	movx	a,@dptr
      005F3B FD               [12] 1111 	mov	r5,a
      005F3C A3               [24] 1112 	inc	dptr
      005F3D E0               [24] 1113 	movx	a,@dptr
      005F3E FE               [12] 1114 	mov	r6,a
      005F3F 90 07 EB         [24] 1115 	mov	dptr,#_descriptor_select_PARM_3
      005F42 E0               [24] 1116 	movx	a,@dptr
      005F43 F5 F0            [12] 1117 	mov	b,a
      005F45 A3               [24] 1118 	inc	dptr
      005F46 E0               [24] 1119 	movx	a,@dptr
      005F47 45 F0            [12] 1120 	orl	a,b
      005F49 60 0C            [24] 1121 	jz	00110$
      005F4B BD 09 05         [24] 1122 	cjne	r5,#0x09,00241$
      005F4E BE 04 02         [24] 1123 	cjne	r6,#0x04,00241$
      005F51 80 04            [24] 1124 	sjmp	00110$
      005F53                       1125 00241$:
      005F53 90 00 00         [24] 1126 	mov	dptr,#0x0000
      005F56 22               [24] 1127 	ret
      005F57                       1128 00110$:
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005F57 90 07 EA         [24] 1130 	mov	dptr,#_descriptor_select_PARM_2
      005F5A E0               [24] 1131 	movx	a,@dptr
      005F5B FE               [12] 1132 	mov  r6,a
      005F5C 24 FC            [12] 1133 	add	a,#0xff - 0x03
      005F5E 40 6A            [24] 1134 	jc	00116$
                                   1135 ;	free result
      005F60 EE               [12] 1136 	mov	a,r6
      005F61 2E               [12] 1137 	add	a,r6
                                   1138 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005F62 90 5F 66         [24] 1139 	mov	dptr,#00243$
      005F65 73               [24] 1140 	jmp	@a+dptr
      005F66                       1141 00243$:
      005F66 80 06            [24] 1142 	sjmp	00112$
      005F68 80 1B            [24] 1143 	sjmp	00113$
      005F6A 80 30            [24] 1144 	sjmp	00114$
      005F6C 80 45            [24] 1145 	sjmp	00115$
      005F6E                       1146 00112$:
      005F6E 90 07 E8         [24] 1147 	mov	dptr,#_control_pointer
      005F71 74 88            [12] 1148 	mov	a,#_LanguageString
      005F73 F0               [24] 1149 	movx	@dptr,a
      005F74 74 C3            [12] 1150 	mov	a,#(_LanguageString >> 8)
      005F76 A3               [24] 1151 	inc	dptr
      005F77 F0               [24] 1152 	movx	@dptr,a
      005F78 90 C3 88         [24] 1153 	mov	dptr,#_LanguageString
      005F7B E4               [12] 1154 	clr	a
      005F7C 93               [24] 1155 	movc	a,@a+dptr
      005F7D FE               [12] 1156 	mov	r6,a
      005F7E 7D 00            [12] 1157 	mov	r5,#0x00
      005F80 8E 82            [24] 1158 	mov	dpl, r6
      005F82 8D 83            [24] 1159 	mov	dph, r5
      005F84 22               [24] 1160 	ret
                                   1161 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F85                       1162 00113$:
      005F85 90 07 E8         [24] 1163 	mov	dptr,#_control_pointer
      005F88 74 8C            [12] 1164 	mov	a,#_ManufacturerString
      005F8A F0               [24] 1165 	movx	@dptr,a
      005F8B 74 C3            [12] 1166 	mov	a,#(_ManufacturerString >> 8)
      005F8D A3               [24] 1167 	inc	dptr
      005F8E F0               [24] 1168 	movx	@dptr,a
      005F8F 90 C3 8C         [24] 1169 	mov	dptr,#_ManufacturerString
      005F92 E4               [12] 1170 	clr	a
      005F93 93               [24] 1171 	movc	a,@a+dptr
      005F94 FE               [12] 1172 	mov	r6,a
      005F95 7D 00            [12] 1173 	mov	r5,#0x00
      005F97 8E 82            [24] 1174 	mov	dpl, r6
      005F99 8D 83            [24] 1175 	mov	dph, r5
      005F9B 22               [24] 1176 	ret
                                   1177 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005F9C                       1178 00114$:
      005F9C 90 07 E8         [24] 1179 	mov	dptr,#_control_pointer
      005F9F 74 9A            [12] 1180 	mov	a,#_ProductString
      005FA1 F0               [24] 1181 	movx	@dptr,a
      005FA2 74 C3            [12] 1182 	mov	a,#(_ProductString >> 8)
      005FA4 A3               [24] 1183 	inc	dptr
      005FA5 F0               [24] 1184 	movx	@dptr,a
      005FA6 90 C3 9A         [24] 1185 	mov	dptr,#_ProductString
      005FA9 E4               [12] 1186 	clr	a
      005FAA 93               [24] 1187 	movc	a,@a+dptr
      005FAB FE               [12] 1188 	mov	r6,a
      005FAC 7D 00            [12] 1189 	mov	r5,#0x00
      005FAE 8E 82            [24] 1190 	mov	dpl, r6
      005FB0 8D 83            [24] 1191 	mov	dph, r5
      005FB2 22               [24] 1192 	ret
                                   1193 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005FB3                       1194 00115$:
      005FB3 90 07 E8         [24] 1195 	mov	dptr,#_control_pointer
      005FB6 74 D2            [12] 1196 	mov	a,#_SerialNumberString
      005FB8 F0               [24] 1197 	movx	@dptr,a
      005FB9 74 C3            [12] 1198 	mov	a,#(_SerialNumberString >> 8)
      005FBB A3               [24] 1199 	inc	dptr
      005FBC F0               [24] 1200 	movx	@dptr,a
      005FBD 90 C3 D2         [24] 1201 	mov	dptr,#_SerialNumberString
      005FC0 E4               [12] 1202 	clr	a
      005FC1 93               [24] 1203 	movc	a,@a+dptr
      005FC2 FE               [12] 1204 	mov	r6,a
      005FC3 7D 00            [12] 1205 	mov	r5,#0x00
      005FC5 8E 82            [24] 1206 	mov	dpl, r6
      005FC7 8D 83            [24] 1207 	mov	dph, r5
      005FC9 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005FCA                       1210 00116$:
      005FCA 90 00 00         [24] 1211 	mov	dptr,#0x0000
      005FCD 22               [24] 1212 	ret
                                   1213 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005FCE                       1214 00119$:
                                   1215 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005FCE 90 07 EA         [24] 1216 	mov	dptr,#_descriptor_select_PARM_2
      005FD1 E0               [24] 1217 	movx	a,@dptr
      005FD2 70 11            [24] 1218 	jnz	00120$
      005FD4 90 07 EB         [24] 1219 	mov	dptr,#_descriptor_select_PARM_3
      005FD7 E0               [24] 1220 	movx	a,@dptr
      005FD8 FD               [12] 1221 	mov	r5,a
      005FD9 A3               [24] 1222 	inc	dptr
      005FDA E0               [24] 1223 	movx	a,@dptr
      005FDB FE               [12] 1224 	mov	r6,a
      005FDC C3               [12] 1225 	clr	c
      005FDD ED               [12] 1226 	mov	a,r5
      005FDE 94 03            [12] 1227 	subb	a,#0x03
      005FE0 EE               [12] 1228 	mov	a,r6
      005FE1 94 00            [12] 1229 	subb	a,#0x00
      005FE3 40 04            [24] 1230 	jc	00121$
      005FE5                       1231 00120$:
      005FE5 90 00 00         [24] 1232 	mov	dptr,#0x0000
      005FE8 22               [24] 1233 	ret
      005FE9                       1234 00121$:
                                   1235 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005FE9 BF 22 02         [24] 1236 	cjne	r7,#0x22,00246$
      005FEC 80 03            [24] 1237 	sjmp	00127$
      005FEE                       1238 00246$:
      005FEE BF 21 5D         [24] 1239 	cjne	r7,#0x21,00128$
      005FF1                       1240 00127$:
                                   1241 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005FF1 ED               [12] 1242 	mov	a,r5
      005FF2 75 F0 04         [24] 1243 	mov	b,#0x04
      005FF5 A4               [48] 1244 	mul	ab
      005FF6 24 5A            [12] 1245 	add	a, #_interface_descriptors
      005FF8 FE               [12] 1246 	mov	r6,a
      005FF9 74 BC            [12] 1247 	mov	a,#(_interface_descriptors >> 8)
      005FFB 35 F0            [12] 1248 	addc	a, b
      005FFD FF               [12] 1249 	mov	r7,a
      005FFE 8E 82            [24] 1250 	mov	dpl,r6
      006000 8F 83            [24] 1251 	mov	dph,r7
      006002 A3               [24] 1252 	inc	dptr
      006003 A3               [24] 1253 	inc	dptr
      006004 E4               [12] 1254 	clr	a
      006005 93               [24] 1255 	movc	a,@a+dptr
      006006 FC               [12] 1256 	mov	r4,a
      006007 A3               [24] 1257 	inc	dptr
      006008 E4               [12] 1258 	clr	a
      006009 93               [24] 1259 	movc	a,@a+dptr
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      00600A FD               [12] 1261 	mov	r5,a
      00600B 4C               [12] 1262 	orl	a,r4
      00600C 70 04            [24] 1263 	jnz	00124$
      00600E 90 00 00         [24] 1264 	mov	dptr,#0x0000
      006011 22               [24] 1265 	ret
      006012                       1266 00124$:
                                   1267 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      006012 90 07 ED         [24] 1268 	mov	dptr,#_descriptor_select_type_10000_272
      006015 E0               [24] 1269 	movx	a,@dptr
      006016 FB               [12] 1270 	mov	r3,a
      006017 BB 22 28         [24] 1271 	cjne	r3,#0x22,00126$
                                   1272 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      00601A 8E 82            [24] 1273 	mov	dpl,r6
      00601C 8F 83            [24] 1274 	mov	dph,r7
      00601E E4               [12] 1275 	clr	a
      00601F 93               [24] 1276 	movc	a,@a+dptr
      006020 FE               [12] 1277 	mov	r6,a
      006021 A3               [24] 1278 	inc	dptr
      006022 E4               [12] 1279 	clr	a
      006023 93               [24] 1280 	movc	a,@a+dptr
      006024 FF               [12] 1281 	mov	r7,a
      006025 90 07 E8         [24] 1282 	mov	dptr,#_control_pointer
      006028 EE               [12] 1283 	mov	a,r6
      006029 F0               [24] 1284 	movx	@dptr,a
      00602A EF               [12] 1285 	mov	a,r7
      00602B A3               [24] 1286 	inc	dptr
      00602C F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      00602D 74 07            [12] 1289 	mov	a,#0x07
      00602F 2C               [12] 1290 	add	a, r4
      006030 F5 82            [12] 1291 	mov	dpl,a
      006032 E4               [12] 1292 	clr	a
      006033 3D               [12] 1293 	addc	a, r5
      006034 F5 83            [12] 1294 	mov	dph,a
      006036 E4               [12] 1295 	clr	a
      006037 93               [24] 1296 	movc	a,@a+dptr
      006038 FE               [12] 1297 	mov	r6,a
      006039 A3               [24] 1298 	inc	dptr
      00603A E4               [12] 1299 	clr	a
      00603B 93               [24] 1300 	movc	a,@a+dptr
      00603C FF               [12] 1301 	mov	r7,a
      00603D 8E 82            [24] 1302 	mov	dpl, r6
      00603F 8F 83            [24] 1303 	mov	dph, r7
      006041 22               [24] 1304 	ret
      006042                       1305 00126$:
                                   1306 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      006042 90 07 E8         [24] 1307 	mov	dptr,#_control_pointer
      006045 EC               [12] 1308 	mov	a,r4
      006046 F0               [24] 1309 	movx	@dptr,a
      006047 ED               [12] 1310 	mov	a,r5
      006048 A3               [24] 1311 	inc	dptr
      006049 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      00604A 90 00 09         [24] 1314 	mov	dptr,#0x0009
      00604D 22               [24] 1315 	ret
      00604E                       1316 00128$:
                                   1317 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      00604E 90 00 00         [24] 1318 	mov	dptr,#0x0000
                                   1319 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      006051 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'control_setup'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1325 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1326 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1327 ;type          Allocated with name '_control_setup_type_10000_290'
                                   1328 ;value         Allocated with name '_control_setup_value_10000_290'
                                   1329 ;index         Allocated with name '_control_setup_index_10000_290'
                                   1330 ;length        Allocated with name '_control_setup_length_10000_290'
                                   1331 ;endpoint      Allocated with name '_control_setup_endpoint_10000_290'
                                   1332 ;i             Allocated with name '_control_setup_i_10000_290'
                                   1333 ;offset        Allocated with name '_control_setup_offset_10000_290'
                                   1334 ;report_id     Allocated with name '_control_setup_report_id_10000_290'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function control_setup
                                   1339 ;	-----------------------------------------
      006052                       1340 _control_setup:
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006052 90 10 00         [24] 1342 	mov	dptr,#0x1000
      006055 E0               [24] 1343 	movx	a,@dptr
      006056 FF               [12] 1344 	mov	r7,a
                                   1345 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006057 A3               [24] 1346 	inc	dptr
      006058 A3               [24] 1347 	inc	dptr
      006059 E0               [24] 1348 	movx	a,@dptr
      00605A FE               [12] 1349 	mov	r6,a
      00605B A3               [24] 1350 	inc	dptr
      00605C E0               [24] 1351 	movx	a,@dptr
      00605D FC               [12] 1352 	mov	r4,a
      00605E 7D 00            [12] 1353 	mov	r5,#0x00
      006060 8E 03            [24] 1354 	mov	ar3,r6
      006062 7E 00            [12] 1355 	mov	r6,#0x00
      006064 ED               [12] 1356 	mov	a,r5
      006065 4B               [12] 1357 	orl	a,r3
      006066 FD               [12] 1358 	mov	r5,a
      006067 EC               [12] 1359 	mov	a,r4
      006068 4E               [12] 1360 	orl	a,r6
      006069 FE               [12] 1361 	mov	r6,a
                                   1362 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      00606A A3               [24] 1363 	inc	dptr
      00606B E0               [24] 1364 	movx	a,@dptr
      00606C FC               [12] 1365 	mov	r4,a
      00606D A3               [24] 1366 	inc	dptr
      00606E E0               [24] 1367 	movx	a,@dptr
      00606F FA               [12] 1368 	mov	r2,a
      006070 7B 00            [12] 1369 	mov	r3,#0x00
      006072 8C 01            [24] 1370 	mov	ar1,r4
      006074 7C 00            [12] 1371 	mov	r4,#0x00
      006076 EB               [12] 1372 	mov	a,r3
      006077 49               [12] 1373 	orl	a,r1
      006078 FB               [12] 1374 	mov	r3,a
      006079 EA               [12] 1375 	mov	a,r2
      00607A 4C               [12] 1376 	orl	a,r4
      00607B FC               [12] 1377 	mov	r4,a
                                   1378 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      00607C C3               [12] 1379 	clr	c
      00607D EB               [12] 1380 	mov	a,r3
      00607E 94 03            [12] 1381 	subb	a,#0x03
      006080 EC               [12] 1382 	mov	a,r4
      006081 94 00            [12] 1383 	subb	a,#0x00
      006083 92 14            [24] 1384 	mov	_control_setup_valid_interface_10000_290,c
                                   1385 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006085 EB               [12] 1386 	mov	a,r3
      006086 4C               [12] 1387 	orl	a,r4
      006087 B4 01 00         [24] 1388 	cjne	a,#0x01,01201$
      00608A                       1389 01201$:
      00608A 92 15            [24] 1390 	mov	_control_setup_zero_index_10000_290,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      00608C ED               [12] 1392 	mov	a,r5
      00608D 4E               [12] 1393 	orl	a,r6
      00608E B4 01 00         [24] 1394 	cjne	a,#0x01,01202$
      006091                       1395 01202$:
                                   1396 ;	assignBit
      006091 92 18            [24] 1397 	mov  _control_setup_sloc0_1_0,c
      006093 92 16            [24] 1398 	mov	_control_setup_zero_value_10000_290,c
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006095 90 07 F0         [24] 1400 	mov	dptr,#_control_setup_offset_10000_290
      006098 E4               [12] 1401 	clr	a
      006099 F0               [24] 1402 	movx	@dptr,a
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      00609A 90 07 8D         [24] 1404 	mov	dptr,#_raw_state
      00609D E0               [24] 1405 	movx	a,@dptr
      00609E FA               [12] 1406 	mov	r2,a
      00609F BA 01 05         [24] 1407 	cjne	r2,#0x01,00102$
      0060A2 90 07 8D         [24] 1408 	mov	dptr,#_raw_state
      0060A5 E4               [12] 1409 	clr	a
      0060A6 F0               [24] 1410 	movx	@dptr,a
      0060A7                       1411 00102$:
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      0060A7 C0 07            [24] 1413 	push	ar7
      0060A9 90 07 E5         [24] 1414 	mov	dptr,#_output_kind
      0060AC E4               [12] 1415 	clr	a
      0060AD F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      0060AE 90 07 E4         [24] 1418 	mov	dptr,#_control_phase
      0060B1 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      0060B2 90 07 E7         [24] 1421 	mov	dptr,#_control_zlp
      0060B5 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0060B6 90 10 01         [24] 1424 	mov	dptr,#0x1001
      0060B9 E0               [24] 1425 	movx	a,@dptr
      0060BA 90 07 7F         [24] 1426 	mov	dptr,#_D0SetupReqCode
      0060BD F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0060BE 90 10 06         [24] 1429 	mov	dptr,#0x1006
      0060C1 E0               [24] 1430 	movx	a,@dptr
      0060C2 FA               [12] 1431 	mov	r2,a
      0060C3 A3               [24] 1432 	inc	dptr
      0060C4 E0               [24] 1433 	movx	a,@dptr
      0060C5 F9               [12] 1434 	mov	r1,a
      0060C6 78 00            [12] 1435 	mov	r0,#0x00
      0060C8 7F 00            [12] 1436 	mov	r7,#0x00
      0060CA 90 07 80         [24] 1437 	mov	dptr,#_D0SetupLen
      0060CD E8               [12] 1438 	mov	a,r0
      0060CE 4A               [12] 1439 	orl	a,r2
      0060CF F0               [24] 1440 	movx	@dptr,a
      0060D0 E9               [12] 1441 	mov	a,r1
      0060D1 4F               [12] 1442 	orl	a,r7
      0060D2 A3               [24] 1443 	inc	dptr
      0060D3 F0               [24] 1444 	movx	@dptr,a
                                   1445 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      0060D4 90 07 80         [24] 1446 	mov	dptr,#_D0SetupLen
      0060D7 E0               [24] 1447 	movx	a,@dptr
      0060D8 FA               [12] 1448 	mov	r2,a
      0060D9 A3               [24] 1449 	inc	dptr
      0060DA E0               [24] 1450 	movx	a,@dptr
      0060DB 4A               [12] 1451 	orl	a,r2
      0060DC B4 01 00         [24] 1452 	cjne	a,#0x01,01205$
      0060DF                       1453 01205$:
      0060DF 92 17            [24] 1454 	mov	_control_setup_zero_length_10000_290,c
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0060E1 90 22 00         [24] 1456 	mov	dptr,#0x2200
      0060E4 74 C2            [12] 1457 	mov	a,#0xc2
      0060E6 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      0060E7 90 22 08         [24] 1460 	mov	dptr,#0x2208
      0060EA E4               [12] 1461 	clr	a
      0060EB F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      0060EC 90 07 7F         [24] 1464 	mov	dptr,#_D0SetupReqCode
      0060EF E0               [24] 1465 	movx	a,@dptr
      0060F0 F5 16            [12] 1466 	mov	_control_setup_sloc1_1_0,a
      0060F2 C3               [12] 1467 	clr	c
      0060F3 74 0B            [12] 1468 	mov	a,#0x0b
      0060F5 95 16            [12] 1469 	subb	a,_control_setup_sloc1_1_0
      0060F7 D0 07            [24] 1470 	pop	ar7
      0060F9 50 03            [24] 1471 	jnc	01206$
      0060FB 02 5E 39         [24] 1472 	ljmp	_control_stall
      0060FE                       1473 01206$:
                                   1474 ;	free result
      0060FE E5 16            [12] 1475 	mov	a,_control_setup_sloc1_1_0
      006100 F5 F0            [12] 1476 	mov	b,a
      006102 24 0B            [12] 1477 	add	a,#(01207$-3-.)
      006104 83               [24] 1478 	movc	a,@a+pc
      006105 F5 82            [12] 1479 	mov	dpl,a
      006107 E5 F0            [12] 1480 	mov	a,b
      006109 24 10            [12] 1481 	add	a,#(01208$-3-.)
      00610B 83               [24] 1482 	movc	a,@a+pc
      00610C F5 83            [12] 1483 	mov	dph,a
      00610E E4               [12] 1484 	clr	a
      00610F 73               [24] 1485 	jmp	@a+dptr
      006110                       1486 01207$:
      006110 B8                    1487 	.db	00188$
      006111 5E                    1488 	.db	00205$
      006112 A1                    1489 	.db	00282$
      006113 5E                    1490 	.db	00205$
      006114 E5                    1491 	.db	00290$
      006115 E2                    1492 	.db	00116$
      006116 28                    1493 	.db	00103$
      006117 E5                    1494 	.db	00290$
      006118 E7                    1495 	.db	00150$
      006119 0B                    1496 	.db	00123$
      00611A 17                    1497 	.db	00157$
      00611B 6A                    1498 	.db	00173$
      00611C                       1499 01208$:
      00611C 63                    1500 	.db	00188$>>8
      00611D 64                    1501 	.db	00205$>>8
      00611E 67                    1502 	.db	00282$>>8
      00611F 64                    1503 	.db	00205$>>8
      006120 67                    1504 	.db	00290$>>8
      006121 61                    1505 	.db	00116$>>8
      006122 61                    1506 	.db	00103$>>8
      006123 67                    1507 	.db	00290$>>8
      006124 62                    1508 	.db	00150$>>8
      006125 62                    1509 	.db	00123$>>8
      006126 63                    1510 	.db	00157$>>8
      006127 63                    1511 	.db	00173$>>8
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006128                       1513 00103$:
                                   1514 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006128 BF 80 02         [24] 1515 	cjne	r7,#0x80,01209$
      00612B 80 08            [24] 1516 	sjmp	00112$
      00612D                       1517 01209$:
      00612D BF 81 02         [24] 1518 	cjne	r7,#0x81,01210$
      006130 80 03            [24] 1519 	sjmp	01211$
      006132                       1520 01210$:
      006132 02 5E 39         [24] 1521 	ljmp	_control_stall
      006135                       1522 01211$:
      006135                       1523 00112$:
                                   1524 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006135 8E 01            [24] 1525 	mov	ar1,r6
      006137 B9 21 02         [24] 1526 	cjne	r1,#0x21,01212$
      00613A 80 09            [24] 1527 	sjmp	00301$
      00613C                       1528 01212$:
      00613C B9 22 02         [24] 1529 	cjne	r1,#0x22,01213$
      00613F 80 04            [24] 1530 	sjmp	00301$
      006141                       1531 01213$:
                                   1532 ;	assignBit
      006141 C2 19            [12] 1533 	clr	_control_setup_sloc2_1_0
      006143 80 02            [24] 1534 	sjmp	00302$
      006145                       1535 00301$:
                                   1536 ;	assignBit
      006145 D2 19            [12] 1537 	setb	_control_setup_sloc2_1_0
      006147                       1538 00302$:
      006147 E4               [12] 1539 	clr	a
      006148 BF 81 01         [24] 1540 	cjne	r7,#0x81,01214$
      00614B 04               [12] 1541 	inc	a
      00614C                       1542 01214$:
      00614C FA               [12] 1543 	mov	r2,a
      00614D A2 19            [12] 1544 	mov	c,_control_setup_sloc2_1_0
      00614F E4               [12] 1545 	clr	a
      006150 33               [12] 1546 	rlc	a
      006151 B5 02 02         [24] 1547 	cjne	a,ar2,01216$
      006154 80 03            [24] 1548 	sjmp	00105$
      006156                       1549 01216$:
                                   1550 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006156 02 5E 39         [24] 1551 	ljmp	_control_stall
      006159                       1552 00105$:
                                   1553 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006159 8E 02            [24] 1554 	mov	ar2,r6
      00615B 90 07 EA         [24] 1555 	mov	dptr,#_descriptor_select_PARM_2
      00615E ED               [12] 1556 	mov	a,r5
      00615F F0               [24] 1557 	movx	@dptr,a
      006160 90 07 EB         [24] 1558 	mov	dptr,#_descriptor_select_PARM_3
      006163 EB               [12] 1559 	mov	a,r3
      006164 F0               [24] 1560 	movx	@dptr,a
      006165 EC               [12] 1561 	mov	a,r4
      006166 A3               [24] 1562 	inc	dptr
      006167 F0               [24] 1563 	movx	@dptr,a
      006168 8A 82            [24] 1564 	mov	dpl, r2
      00616A 12 5E D7         [24] 1565 	lcall	_descriptor_select
      00616D 85 82 17         [24] 1566 	mov	_control_setup_sloc3_1_0,dpl
      006170 85 83 18         [24] 1567 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1568 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      006173 E5 17            [12] 1569 	mov	a,_control_setup_sloc3_1_0
      006175 45 18            [12] 1570 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006177 70 03            [24] 1571 	jnz	00107$
      006179 02 5E 39         [24] 1572 	ljmp	_control_stall
      00617C                       1573 00107$:
                                   1574 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00617C 90 07 80         [24] 1575 	mov	dptr,#_D0SetupLen
      00617F E0               [24] 1576 	movx	a,@dptr
      006180 F8               [12] 1577 	mov	r0,a
      006181 A3               [24] 1578 	inc	dptr
      006182 E0               [24] 1579 	movx	a,@dptr
      006183 FA               [12] 1580 	mov	r2,a
      006184 C3               [12] 1581 	clr	c
      006185 E5 17            [12] 1582 	mov	a,_control_setup_sloc3_1_0
      006187 98               [12] 1583 	subb	a,r0
      006188 E5 18            [12] 1584 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00618A 9A               [12] 1585 	subb	a,r2
      00618B 50 06            [24] 1586 	jnc	00303$
      00618D E5 17            [12] 1587 	mov	a,_control_setup_sloc3_1_0
      00618F 54 3F            [12] 1588 	anl	a,#0x3f
      006191 60 04            [24] 1589 	jz	00304$
      006193                       1590 00303$:
                                   1591 ;	assignBit
      006193 C2 19            [12] 1592 	clr	_control_setup_sloc2_1_0
      006195 80 02            [24] 1593 	sjmp	00305$
      006197                       1594 00304$:
                                   1595 ;	assignBit
      006197 D2 19            [12] 1596 	setb	_control_setup_sloc2_1_0
      006199                       1597 00305$:
      006199 90 07 E7         [24] 1598 	mov	dptr,#_control_zlp
      00619C A2 19            [12] 1599 	mov	c,_control_setup_sloc2_1_0
      00619E E4               [12] 1600 	clr	a
      00619F 33               [12] 1601 	rlc	a
      0061A0 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      0061A1 90 07 80         [24] 1604 	mov	dptr,#_D0SetupLen
      0061A4 E0               [24] 1605 	movx	a,@dptr
      0061A5 F9               [12] 1606 	mov	r1,a
      0061A6 A3               [24] 1607 	inc	dptr
      0061A7 E0               [24] 1608 	movx	a,@dptr
      0061A8 FA               [12] 1609 	mov	r2,a
      0061A9 C3               [12] 1610 	clr	c
      0061AA E5 17            [12] 1611 	mov	a,_control_setup_sloc3_1_0
      0061AC 99               [12] 1612 	subb	a,r1
      0061AD E5 18            [12] 1613 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061AF 9A               [12] 1614 	subb	a,r2
      0061B0 50 0A            [24] 1615 	jnc	00109$
                                   1616 ;	free result
      0061B2 90 07 80         [24] 1617 	mov	dptr,#_D0SetupLen
      0061B5 E5 17            [12] 1618 	mov	a,_control_setup_sloc3_1_0
      0061B7 F0               [24] 1619 	movx	@dptr,a
      0061B8 E5 18            [12] 1620 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061BA A3               [24] 1621 	inc	dptr
      0061BB F0               [24] 1622 	movx	@dptr,a
      0061BC                       1623 00109$:
                                   1624 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0061BC 90 07 80         [24] 1625 	mov	dptr,#_D0SetupLen
      0061BF E0               [24] 1626 	movx	a,@dptr
      0061C0 F9               [12] 1627 	mov	r1,a
      0061C1 A3               [24] 1628 	inc	dptr
      0061C2 E0               [24] 1629 	movx	a,@dptr
      0061C3 49               [12] 1630 	orl	a,r1
      0061C4 60 04            [24] 1631 	jz	00306$
      0061C6 7A 01            [12] 1632 	mov	r2,#0x01
      0061C8 80 02            [24] 1633 	sjmp	00307$
      0061CA                       1634 00306$:
      0061CA 7A 02            [12] 1635 	mov	r2,#0x02
      0061CC                       1636 00307$:
      0061CC 90 07 E4         [24] 1637 	mov	dptr,#_control_phase
      0061CF EA               [12] 1638 	mov	a,r2
      0061D0 F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      0061D1 90 07 80         [24] 1641 	mov	dptr,#_D0SetupLen
      0061D4 E0               [24] 1642 	movx	a,@dptr
      0061D5 F9               [12] 1643 	mov	r1,a
      0061D6 A3               [24] 1644 	inc	dptr
      0061D7 E0               [24] 1645 	movx	a,@dptr
      0061D8 49               [12] 1646 	orl	a,r1
      0061D9 60 03            [24] 1647 	jz	00111$
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      0061DB 02 5E 5B         [24] 1649 	ljmp	_control_next
      0061DE                       1650 00111$:
      0061DE 22               [24] 1651 	ret
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      0061DF 02 5E 39         [24] 1653 	ljmp	_control_stall
                                   1654 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      0061E2                       1655 00116$:
                                   1656 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0061E2 EF               [12] 1657 	mov	a,r7
      0061E3 70 23            [24] 1658 	jnz	00118$
      0061E5 30 15 20         [24] 1659 	jnb	_control_setup_zero_index_10000_290,00118$
      0061E8 30 17 1D         [24] 1660 	jnb	_control_setup_zero_length_10000_290,00118$
      0061EB 8D 01            [24] 1661 	mov	ar1,r5
      0061ED 8E 02            [24] 1662 	mov	ar2,r6
      0061EF C3               [12] 1663 	clr	c
      0061F0 74 7F            [12] 1664 	mov	a,#0x7f
      0061F2 99               [12] 1665 	subb	a,r1
      0061F3 E4               [12] 1666 	clr	a
      0061F4 9A               [12] 1667 	subb	a,r2
      0061F5 40 11            [24] 1668 	jc	00118$
                                   1669 ;	free result
                                   1670 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0061F7 90 07 80         [24] 1671 	mov	dptr,#_D0SetupLen
      0061FA ED               [12] 1672 	mov	a,r5
      0061FB F0               [24] 1673 	movx	@dptr,a
      0061FC EE               [12] 1674 	mov	a,r6
      0061FD A3               [24] 1675 	inc	dptr
      0061FE F0               [24] 1676 	movx	@dptr,a
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0061FF 90 07 E4         [24] 1678 	mov	dptr,#_control_phase
      006202 74 03            [12] 1679 	mov	a,#0x03
      006204 F0               [24] 1680 	movx	@dptr,a
      006205 02 67 E8         [24] 1681 	ljmp	00291$
      006208                       1682 00118$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006208 02 5E 39         [24] 1684 	ljmp	_control_stall
                                   1685 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00620B                       1686 00123$:
                                   1687 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00620B EF               [12] 1688 	mov	a,r7
      00620C 70 3C            [24] 1689 	jnz	00145$
      00620E 30 15 39         [24] 1690 	jnb	_control_setup_zero_index_10000_290,00145$
      006211 30 17 36         [24] 1691 	jnb	_control_setup_zero_length_10000_290,00145$
      006214 8D 01            [24] 1692 	mov	ar1,r5
      006216 8E 02            [24] 1693 	mov	ar2,r6
      006218 C3               [12] 1694 	clr	c
      006219 74 01            [12] 1695 	mov	a,#0x01
      00621B 99               [12] 1696 	subb	a,r1
      00621C E4               [12] 1697 	clr	a
      00621D 9A               [12] 1698 	subb	a,r2
      00621E 40 2A            [24] 1699 	jc	00145$
                                   1700 ;	free result
                                   1701 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006220 C0 06            [24] 1702 	push	ar6
      006222 C0 05            [24] 1703 	push	ar5
      006224 12 5D D8         [24] 1704 	lcall	_endpoints_reset
      006227 D0 05            [24] 1705 	pop	ar5
      006229 D0 06            [24] 1706 	pop	ar6
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      00622B 90 07 85         [24] 1708 	mov	dptr,#_D0UsbConfig
      00622E ED               [12] 1709 	mov	a,r5
      00622F F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006230 A2 18            [12] 1712 	mov	c,_control_setup_sloc0_1_0
      006232 B3               [12] 1713 	cpl	c
      006233 92 19            [24] 1714 	mov	_control_setup_sloc2_1_0,c
      006235 90 07 86         [24] 1715 	mov	dptr,#_USB_EnumStatus
      006238 E4               [12] 1716 	clr	a
      006239 33               [12] 1717 	rlc	a
      00623A F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      00623B 90 07 AF         [24] 1720 	mov	dptr,#_keyboard_reset
      00623E 74 01            [12] 1721 	mov	a,#0x01
      006240 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      006241 90 07 E4         [24] 1724 	mov	dptr,#_control_phase
      006244 74 03            [12] 1725 	mov	a,#0x03
      006246 F0               [24] 1726 	movx	@dptr,a
      006247 02 67 E8         [24] 1727 	ljmp	00291$
      00624A                       1728 00145$:
                                   1729 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      00624A BF 21 02         [24] 1730 	cjne	r7,#0x21,01231$
      00624D 80 03            [24] 1731 	sjmp	01232$
      00624F                       1732 01231$:
      00624F 02 5E 39         [24] 1733 	ljmp	_control_stall
      006252                       1734 01232$:
      006252 90 07 85         [24] 1735 	mov	dptr,#_D0UsbConfig
      006255 E0               [24] 1736 	movx	a,@dptr
      006256 70 03            [24] 1737 	jnz	01233$
      006258 02 5E 39         [24] 1738 	ljmp	_control_stall
      00625B                       1739 01233$:
                                   1740 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00625B BB 01 2D         [24] 1741 	cjne	r3,#0x01,00135$
      00625E BC 00 2A         [24] 1742 	cjne	r4,#0x00,00135$
      006261 8D 01            [24] 1743 	mov	ar1,r5
      006263 8E 02            [24] 1744 	mov	ar2,r6
      006265 B9 00 23         [24] 1745 	cjne	r1,#0x00,00135$
      006268 BA 02 20         [24] 1746 	cjne	r2,#0x02,00135$
      00626B 90 07 80         [24] 1747 	mov	dptr,#_D0SetupLen
      00626E E0               [24] 1748 	movx	a,@dptr
      00626F F9               [12] 1749 	mov	r1,a
      006270 A3               [24] 1750 	inc	dptr
      006271 E0               [24] 1751 	movx	a,@dptr
      006272 FA               [12] 1752 	mov	r2,a
      006273 B9 20 15         [24] 1753 	cjne	r1,#0x20,00135$
      006276 BA 00 12         [24] 1754 	cjne	r2,#0x00,00135$
      006279 90 07 8D         [24] 1755 	mov	dptr,#_raw_state
      00627C E0               [24] 1756 	movx	a,@dptr
      00627D 70 0C            [24] 1757 	jnz	00135$
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      00627F 90 07 8D         [24] 1759 	mov	dptr,#_raw_state
      006282 74 01            [12] 1760 	mov	a,#0x01
      006284 F0               [24] 1761 	movx	@dptr,a
                                   1762 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006285 90 07 E5         [24] 1763 	mov	dptr,#_output_kind
      006288 F0               [24] 1764 	movx	@dptr,a
      006289 80 52            [24] 1765 	sjmp	00136$
      00628B                       1766 00135$:
                                   1767 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      00628B EB               [12] 1768 	mov	a,r3
      00628C 4C               [12] 1769 	orl	a,r4
      00628D 70 20            [24] 1770 	jnz	00130$
      00628F 8D 01            [24] 1771 	mov	ar1,r5
      006291 8E 02            [24] 1772 	mov	ar2,r6
      006293 B9 00 19         [24] 1773 	cjne	r1,#0x00,00130$
      006296 BA 02 16         [24] 1774 	cjne	r2,#0x02,00130$
      006299 90 07 80         [24] 1775 	mov	dptr,#_D0SetupLen
      00629C E0               [24] 1776 	movx	a,@dptr
      00629D F9               [12] 1777 	mov	r1,a
      00629E A3               [24] 1778 	inc	dptr
      00629F E0               [24] 1779 	movx	a,@dptr
      0062A0 FA               [12] 1780 	mov	r2,a
      0062A1 B9 01 0B         [24] 1781 	cjne	r1,#0x01,00130$
      0062A4 BA 00 08         [24] 1782 	cjne	r2,#0x00,00130$
                                   1783 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      0062A7 90 07 E5         [24] 1784 	mov	dptr,#_output_kind
      0062AA 74 02            [12] 1785 	mov	a,#0x02
      0062AC F0               [24] 1786 	movx	@dptr,a
      0062AD 80 2E            [24] 1787 	sjmp	00136$
      0062AF                       1788 00130$:
                                   1789 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0062AF BB 02 28         [24] 1790 	cjne	r3,#0x02,00125$
      0062B2 BC 00 25         [24] 1791 	cjne	r4,#0x00,00125$
      0062B5 8D 01            [24] 1792 	mov	ar1,r5
      0062B7 8E 02            [24] 1793 	mov	ar2,r6
      0062B9 B9 06 1E         [24] 1794 	cjne	r1,#0x06,00125$
      0062BC BA 02 1B         [24] 1795 	cjne	r2,#0x02,00125$
      0062BF 90 07 80         [24] 1796 	mov	dptr,#_D0SetupLen
      0062C2 E0               [24] 1797 	movx	a,@dptr
      0062C3 F9               [12] 1798 	mov	r1,a
      0062C4 A3               [24] 1799 	inc	dptr
      0062C5 E0               [24] 1800 	movx	a,@dptr
      0062C6 FA               [12] 1801 	mov	r2,a
      0062C7 B9 02 10         [24] 1802 	cjne	r1,#0x02,00125$
      0062CA BA 00 0D         [24] 1803 	cjne	r2,#0x00,00125$
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      0062CD 90 07 E5         [24] 1805 	mov	dptr,#_output_kind
      0062D0 74 03            [12] 1806 	mov	a,#0x03
      0062D2 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0062D3 90 07 E6         [24] 1809 	mov	dptr,#_output_report_id
      0062D6 23               [12] 1810 	rl	a
      0062D7 F0               [24] 1811 	movx	@dptr,a
      0062D8 80 03            [24] 1812 	sjmp	00136$
      0062DA                       1813 00125$:
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0062DA 02 5E 39         [24] 1815 	ljmp	_control_stall
      0062DD                       1816 00136$:
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0062DD 90 07 E4         [24] 1818 	mov	dptr,#_control_phase
      0062E0 74 04            [12] 1819 	mov	a,#0x04
      0062E2 F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0062E3 22               [24] 1822 	ret
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0062E4 02 5E 39         [24] 1824 	ljmp	_control_stall
                                   1825 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0062E7                       1826 00150$:
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0062E7 BF 80 2A         [24] 1828 	cjne	r7,#0x80,00152$
      0062EA 30 15 27         [24] 1829 	jnb	_control_setup_zero_index_10000_290,00152$
      0062ED 30 16 24         [24] 1830 	jnb	_control_setup_zero_value_10000_290,00152$
      0062F0 90 07 80         [24] 1831 	mov	dptr,#_D0SetupLen
      0062F3 E0               [24] 1832 	movx	a,@dptr
      0062F4 F9               [12] 1833 	mov	r1,a
      0062F5 A3               [24] 1834 	inc	dptr
      0062F6 E0               [24] 1835 	movx	a,@dptr
      0062F7 FA               [12] 1836 	mov	r2,a
      0062F8 B9 01 19         [24] 1837 	cjne	r1,#0x01,00152$
      0062FB BA 00 16         [24] 1838 	cjne	r2,#0x00,00152$
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0062FE 90 07 85         [24] 1840 	mov	dptr,#_D0UsbConfig
      006301 E0               [24] 1841 	movx	a,@dptr
      006302 90 10 00         [24] 1842 	mov	dptr,#0x1000
      006305 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      006306 90 22 08         [24] 1845 	mov	dptr,#0x2208
      006309 74 01            [12] 1846 	mov	a,#0x01
      00630B F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      00630C 90 07 E4         [24] 1849 	mov	dptr,#_control_phase
      00630F 04               [12] 1850 	inc	a
      006310 F0               [24] 1851 	movx	@dptr,a
      006311 02 67 E8         [24] 1852 	ljmp	00291$
      006314                       1853 00152$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006314 02 5E 39         [24] 1855 	ljmp	_control_stall
                                   1856 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006317                       1857 00157$:
                                   1858 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006317 BF 81 2C         [24] 1859 	cjne	r7,#0x81,00167$
      00631A 30 14 29         [24] 1860 	jnb	_control_setup_valid_interface_10000_290,00167$
      00631D 30 16 26         [24] 1861 	jnb	_control_setup_zero_value_10000_290,00167$
      006320 90 07 80         [24] 1862 	mov	dptr,#_D0SetupLen
      006323 E0               [24] 1863 	movx	a,@dptr
      006324 F9               [12] 1864 	mov	r1,a
      006325 A3               [24] 1865 	inc	dptr
      006326 E0               [24] 1866 	movx	a,@dptr
      006327 FA               [12] 1867 	mov	r2,a
      006328 B9 01 1B         [24] 1868 	cjne	r1,#0x01,00167$
      00632B BA 00 18         [24] 1869 	cjne	r2,#0x00,00167$
      00632E 90 07 85         [24] 1870 	mov	dptr,#_D0UsbConfig
      006331 E0               [24] 1871 	movx	a,@dptr
      006332 60 12            [24] 1872 	jz	00167$
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006334 90 10 00         [24] 1874 	mov	dptr,#0x1000
      006337 E4               [12] 1875 	clr	a
      006338 F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006339 90 22 08         [24] 1878 	mov	dptr,#0x2208
      00633C 04               [12] 1879 	inc	a
      00633D F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00633E 90 07 E4         [24] 1882 	mov	dptr,#_control_phase
      006341 04               [12] 1883 	inc	a
      006342 F0               [24] 1884 	movx	@dptr,a
      006343 02 67 E8         [24] 1885 	ljmp	00291$
      006346                       1886 00167$:
                                   1887 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006346 30 14 1E         [24] 1888 	jnb	_control_setup_valid_interface_10000_290,00161$
      006349 90 07 85         [24] 1889 	mov	dptr,#_D0UsbConfig
      00634C E0               [24] 1890 	movx	a,@dptr
      00634D 60 18            [24] 1891 	jz	00161$
      00634F BF 21 15         [24] 1892 	cjne	r7,#0x21,00161$
      006352 30 17 12         [24] 1893 	jnb	_control_setup_zero_length_10000_290,00161$
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006355 EB               [12] 1895 	mov	a,r3
      006356 4C               [12] 1896 	orl	a,r4
      006357 70 05            [24] 1897 	jnz	00159$
      006359 90 06 47         [24] 1898 	mov	dptr,#_keyboard_idle
      00635C EE               [12] 1899 	mov	a,r6
      00635D F0               [24] 1900 	movx	@dptr,a
      00635E                       1901 00159$:
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      00635E 90 07 E4         [24] 1903 	mov	dptr,#_control_phase
      006361 74 03            [12] 1904 	mov	a,#0x03
      006363 F0               [24] 1905 	movx	@dptr,a
      006364 02 67 E8         [24] 1906 	ljmp	00291$
      006367                       1907 00161$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006367 02 5E 39         [24] 1909 	ljmp	_control_stall
                                   1910 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00636A                       1911 00173$:
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00636A BF 01 18         [24] 1913 	cjne	r7,#0x01,00182$
      00636D 30 14 15         [24] 1914 	jnb	_control_setup_valid_interface_10000_290,00182$
      006370 30 16 12         [24] 1915 	jnb	_control_setup_zero_value_10000_290,00182$
      006373 30 17 0F         [24] 1916 	jnb	_control_setup_zero_length_10000_290,00182$
      006376 90 07 85         [24] 1917 	mov	dptr,#_D0UsbConfig
      006379 E0               [24] 1918 	movx	a,@dptr
      00637A 60 09            [24] 1919 	jz	00182$
                                   1920 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      00637C 90 07 E4         [24] 1921 	mov	dptr,#_control_phase
      00637F 74 03            [12] 1922 	mov	a,#0x03
      006381 F0               [24] 1923 	movx	@dptr,a
      006382 02 67 E8         [24] 1924 	ljmp	00291$
      006385                       1925 00182$:
                                   1926 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006385 EB               [12] 1927 	mov	a,r3
      006386 4C               [12] 1928 	orl	a,r4
      006387 70 2C            [24] 1929 	jnz	00175$
      006389 90 07 85         [24] 1930 	mov	dptr,#_D0UsbConfig
      00638C E0               [24] 1931 	movx	a,@dptr
      00638D 60 26            [24] 1932 	jz	00175$
      00638F BF 21 23         [24] 1933 	cjne	r7,#0x21,00175$
      006392 30 17 20         [24] 1934 	jnb	_control_setup_zero_length_10000_290,00175$
      006395 8D 01            [24] 1935 	mov	ar1,r5
      006397 8E 02            [24] 1936 	mov	ar2,r6
      006399 C3               [12] 1937 	clr	c
      00639A 74 01            [12] 1938 	mov	a,#0x01
      00639C 99               [12] 1939 	subb	a,r1
      00639D E4               [12] 1940 	clr	a
      00639E 9A               [12] 1941 	subb	a,r2
      00639F 40 14            [24] 1942 	jc	00175$
                                   1943 ;	free result
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      0063A1 90 0D A9         [24] 1945 	mov	dptr,#_keyboard_protocol
      0063A4 ED               [12] 1946 	mov	a,r5
      0063A5 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      0063A6 90 07 AF         [24] 1949 	mov	dptr,#_keyboard_reset
      0063A9 74 01            [12] 1950 	mov	a,#0x01
      0063AB F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      0063AC 90 07 E4         [24] 1953 	mov	dptr,#_control_phase
      0063AF 74 03            [12] 1954 	mov	a,#0x03
      0063B1 F0               [24] 1955 	movx	@dptr,a
      0063B2 02 67 E8         [24] 1956 	ljmp	00291$
      0063B5                       1957 00175$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      0063B5 02 5E 39         [24] 1959 	ljmp	_control_stall
                                   1960 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0063B8                       1961 00188$:
                                   1962 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0063B8 20 16 03         [24] 1963 	jb	_control_setup_zero_value_10000_290,01283$
      0063BB 02 5E 39         [24] 1964 	ljmp	_control_stall
      0063BE                       1965 01283$:
      0063BE 90 07 80         [24] 1966 	mov	dptr,#_D0SetupLen
      0063C1 E0               [24] 1967 	movx	a,@dptr
      0063C2 F9               [12] 1968 	mov	r1,a
      0063C3 A3               [24] 1969 	inc	dptr
      0063C4 E0               [24] 1970 	movx	a,@dptr
      0063C5 FA               [12] 1971 	mov	r2,a
      0063C6 B9 02 05         [24] 1972 	cjne	r1,#0x02,01284$
      0063C9 BA 00 02         [24] 1973 	cjne	r2,#0x00,01284$
      0063CC 80 03            [24] 1974 	sjmp	01285$
      0063CE                       1975 01284$:
      0063CE 02 5E 39         [24] 1976 	ljmp	_control_stall
      0063D1                       1977 01285$:
                                   1978 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0063D1 E4               [12] 1979 	clr	a
      0063D2 BF 80 01         [24] 1980 	cjne	r7,#0x80,01286$
      0063D5 04               [12] 1981 	inc	a
      0063D6                       1982 01286$:
      0063D6 FA               [12] 1983 	mov	r2,a
      0063D7 60 03            [24] 1984 	jz	00196$
      0063D9 20 15 35         [24] 1985 	jb	_control_setup_zero_index_10000_290,00189$
      0063DC                       1986 00196$:
      0063DC BF 81 09         [24] 1987 	cjne	r7,#0x81,00202$
      0063DF 30 14 06         [24] 1988 	jnb	_control_setup_valid_interface_10000_290,00202$
      0063E2 90 07 85         [24] 1989 	mov	dptr,#_D0UsbConfig
      0063E5 E0               [24] 1990 	movx	a,@dptr
      0063E6 70 29            [24] 1991 	jnz	00189$
      0063E8                       1992 00202$:
                                   1993 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0063E8 BF 82 70         [24] 1994 	cjne	r7,#0x82,00190$
      0063EB 90 07 85         [24] 1995 	mov	dptr,#_D0UsbConfig
      0063EE E0               [24] 1996 	movx	a,@dptr
      0063EF 60 6A            [24] 1997 	jz	00190$
      0063F1 EB               [12] 1998 	mov	a,r3
      0063F2 4C               [12] 1999 	orl	a,r4
      0063F3 60 1C            [24] 2000 	jz	00189$
      0063F5 8B 00            [24] 2001 	mov	ar0,r3
      0063F7 8C 01            [24] 2002 	mov	ar1,r4
      0063F9 B8 80 05         [24] 2003 	cjne	r0,#0x80,01298$
      0063FC B9 00 02         [24] 2004 	cjne	r1,#0x00,01298$
      0063FF 80 10            [24] 2005 	sjmp	00189$
      006401                       2006 01298$:
      006401 C3               [12] 2007 	clr	c
      006402 E8               [12] 2008 	mov	a,r0
      006403 94 81            [12] 2009 	subb	a,#0x81
      006405 E9               [12] 2010 	mov	a,r1
      006406 94 00            [12] 2011 	subb	a,#0x00
      006408 40 51            [24] 2012 	jc	00190$
      00640A 74 83            [12] 2013 	mov	a,#0x83
      00640C 98               [12] 2014 	subb	a,r0
      00640D E4               [12] 2015 	clr	a
      00640E 99               [12] 2016 	subb	a,r1
      00640F 40 4A            [24] 2017 	jc	00190$
                                   2018 ;	free result
      006411                       2019 00189$:
                                   2020 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      006411 8B 01            [24] 2021 	mov	ar1,r3
      006413 53 01 07         [24] 2022 	anl	ar1,#0x07
                                   2023 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006416 EA               [12] 2024 	mov	a,r2
      006417 60 0B            [24] 2025 	jz	00308$
      006419 90 07 87         [24] 2026 	mov	dptr,#_USB_SleepStatus
      00641C E0               [24] 2027 	movx	a,@dptr
      00641D 54 01            [12] 2028 	anl	a,#0x01
      00641F 25 E0            [12] 2029 	add	a,acc
      006421 FA               [12] 2030 	mov	r2,a
      006422 80 22            [24] 2031 	sjmp	00309$
      006424                       2032 00308$:
                                   2033 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006424 BF 82 1B         [24] 2034 	cjne	r7,#0x82,00310$
      006427 E9               [12] 2035 	mov	a,r1
      006428 60 18            [24] 2036 	jz	00310$
      00642A 89 00            [24] 2037 	mov	ar0,r1
      00642C 79 00            [12] 2038 	mov	r1,#0x00
      00642E 74 22            [12] 2039 	mov	a,#0x22
      006430 29               [12] 2040 	add	a, r1
      006431 F9               [12] 2041 	mov	r1,a
      006432 88 82            [24] 2042 	mov	dpl,r0
      006434 89 83            [24] 2043 	mov	dph,r1
      006436 E0               [24] 2044 	movx	a,@dptr
      006437 F9               [12] 2045 	mov	r1,a
      006438 53 01 03         [24] 2046 	anl	ar1,#0x03
      00643B B9 03 04         [24] 2047 	cjne	r1,#0x03,00310$
      00643E 79 01            [12] 2048 	mov	r1,#0x01
      006440 80 02            [24] 2049 	sjmp	00311$
      006442                       2050 00310$:
      006442 79 00            [12] 2051 	mov	r1,#0x00
      006444                       2052 00311$:
      006444 89 02            [24] 2053 	mov	ar2,r1
      006446                       2054 00309$:
      006446 90 10 00         [24] 2055 	mov	dptr,#0x1000
      006449 EA               [12] 2056 	mov	a,r2
      00644A F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      00644B A3               [24] 2059 	inc	dptr
      00644C E4               [12] 2060 	clr	a
      00644D F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      00644E 90 22 08         [24] 2063 	mov	dptr,#0x2208
      006451 74 02            [12] 2064 	mov	a,#0x02
      006453 F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006454 90 07 E4         [24] 2067 	mov	dptr,#_control_phase
      006457 F0               [24] 2068 	movx	@dptr,a
      006458 02 67 E8         [24] 2069 	ljmp	00291$
      00645B                       2070 00190$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      00645B 02 5E 39         [24] 2072 	ljmp	_control_stall
                                   2073 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00645E                       2074 00205$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      00645E 20 17 03         [24] 2076 	jb	_control_setup_zero_length_10000_290,01307$
      006461 02 64 F1         [24] 2077 	ljmp	00279$
      006464                       2078 01307$:
      006464 90 07 85         [24] 2079 	mov	dptr,#_D0UsbConfig
      006467 E0               [24] 2080 	movx	a,@dptr
      006468 70 03            [24] 2081 	jnz	01308$
      00646A 02 64 F1         [24] 2082 	ljmp	00279$
      00646D                       2083 01308$:
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      00646D EF               [12] 2085 	mov	a,r7
      00646E 70 29            [24] 2086 	jnz	00218$
      006470 8D 01            [24] 2087 	mov	ar1,r5
      006472 8E 02            [24] 2088 	mov	ar2,r6
      006474 B9 01 22         [24] 2089 	cjne	r1,#0x01,00218$
      006477 BA 00 1F         [24] 2090 	cjne	r2,#0x00,00218$
      00647A 30 15 1C         [24] 2091 	jnb	_control_setup_zero_index_10000_290,00218$
                                   2092 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00647D 90 07 7F         [24] 2093 	mov	dptr,#_D0SetupReqCode
      006480 E0               [24] 2094 	movx	a,@dptr
      006481 FA               [12] 2095 	mov	r2,a
      006482 BA 03 0A         [24] 2096 	cjne	r2,#0x03,00207$
      006485 90 07 87         [24] 2097 	mov	dptr,#_USB_SleepStatus
      006488 E0               [24] 2098 	movx	a,@dptr
      006489 43 E0 01         [24] 2099 	orl	acc,#0x01
      00648C F0               [24] 2100 	movx	@dptr,a
      00648D 80 59            [24] 2101 	sjmp	00219$
      00648F                       2102 00207$:
                                   2103 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      00648F 90 07 87         [24] 2104 	mov	dptr,#_USB_SleepStatus
      006492 E0               [24] 2105 	movx	a,@dptr
      006493 53 E0 FE         [24] 2106 	anl	acc,#0xfe
      006496 F0               [24] 2107 	movx	@dptr,a
      006497 80 4F            [24] 2108 	sjmp	00219$
      006499                       2109 00218$:
                                   2110 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006499 BF 02 49         [24] 2111 	cjne	r7,#0x02,00212$
      00649C 30 16 46         [24] 2112 	jnb	_control_setup_zero_value_10000_290,00212$
      00649F 8B 01            [24] 2113 	mov	ar1,r3
      0064A1 8C 02            [24] 2114 	mov	ar2,r4
      0064A3 C3               [12] 2115 	clr	c
      0064A4 E9               [12] 2116 	mov	a,r1
      0064A5 94 81            [12] 2117 	subb	a,#0x81
      0064A7 EA               [12] 2118 	mov	a,r2
      0064A8 94 00            [12] 2119 	subb	a,#0x00
      0064AA 40 39            [24] 2120 	jc	00212$
      0064AC 74 83            [12] 2121 	mov	a,#0x83
      0064AE 99               [12] 2122 	subb	a,r1
      0064AF E4               [12] 2123 	clr	a
      0064B0 9A               [12] 2124 	subb	a,r2
      0064B1 40 32            [24] 2125 	jc	00212$
                                   2126 ;	free result
                                   2127 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      0064B3 8B 02            [24] 2128 	mov	ar2,r3
      0064B5 53 02 07         [24] 2129 	anl	ar2,#0x07
                                   2130 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0064B8 8A 00            [24] 2131 	mov	ar0,r2
      0064BA 79 00            [12] 2132 	mov	r1,#0x00
      0064BC 74 22            [12] 2133 	mov	a,#0x22
      0064BE 29               [12] 2134 	add	a, r1
      0064BF F9               [12] 2135 	mov	r1,a
      0064C0 88 17            [24] 2136 	mov	_control_setup_sloc3_1_0,r0
      0064C2 89 18            [24] 2137 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0064C4 90 07 7F         [24] 2138 	mov	dptr,#_D0SetupReqCode
      0064C7 E0               [24] 2139 	movx	a,@dptr
      0064C8 F9               [12] 2140 	mov	r1,a
      0064C9 B9 03 04         [24] 2141 	cjne	r1,#0x03,00318$
      0064CC 79 03            [12] 2142 	mov	r1,#0x03
      0064CE 80 02            [24] 2143 	sjmp	00319$
      0064D0                       2144 00318$:
      0064D0 79 02            [12] 2145 	mov	r1,#0x02
      0064D2                       2146 00319$:
      0064D2 43 01 10         [24] 2147 	orl	ar1,#0x10
      0064D5 85 17 82         [24] 2148 	mov	dpl,_control_setup_sloc3_1_0
      0064D8 85 18 83         [24] 2149 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0064DB E9               [12] 2150 	mov	a,r1
      0064DC F0               [24] 2151 	movx	@dptr,a
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0064DD BA 03 08         [24] 2153 	cjne	r2,#0x03,00219$
      0064E0 12 5D BB         [24] 2154 	lcall	_raw_complete
      0064E3 80 03            [24] 2155 	sjmp	00219$
      0064E5                       2156 00212$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      0064E5 02 5E 39         [24] 2158 	ljmp	_control_stall
      0064E8                       2159 00219$:
                                   2160 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      0064E8 90 07 E4         [24] 2161 	mov	dptr,#_control_phase
      0064EB 74 03            [12] 2162 	mov	a,#0x03
      0064ED F0               [24] 2163 	movx	@dptr,a
      0064EE 02 67 E8         [24] 2164 	ljmp	00291$
      0064F1                       2165 00279$:
                                   2166 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0064F1 E4               [12] 2167 	clr	a
      0064F2 BF A1 01         [24] 2168 	cjne	r7,#0xa1,01324$
      0064F5 04               [12] 2169 	inc	a
      0064F6                       2170 01324$:
      0064F6 FA               [12] 2171 	mov	r2,a
      0064F7 70 03            [24] 2172 	jnz	01326$
      0064F9 02 67 63         [24] 2173 	ljmp	00273$
      0064FC                       2174 01326$:
      0064FC 90 07 7F         [24] 2175 	mov	dptr,#_D0SetupReqCode
      0064FF E0               [24] 2176 	movx	a,@dptr
      006500 F9               [12] 2177 	mov	r1,a
      006501 B9 01 02         [24] 2178 	cjne	r1,#0x01,01327$
      006504 80 03            [24] 2179 	sjmp	01328$
      006506                       2180 01327$:
      006506 02 67 63         [24] 2181 	ljmp	00273$
      006509                       2182 01328$:
      006509 90 07 85         [24] 2183 	mov	dptr,#_D0UsbConfig
      00650C E0               [24] 2184 	movx	a,@dptr
      00650D 70 03            [24] 2185 	jnz	01329$
      00650F 02 67 63         [24] 2186 	ljmp	00273$
      006512                       2187 01329$:
      006512 90 07 80         [24] 2188 	mov	dptr,#_D0SetupLen
      006515 E0               [24] 2189 	movx	a,@dptr
      006516 F8               [12] 2190 	mov	r0,a
      006517 A3               [24] 2191 	inc	dptr
      006518 E0               [24] 2192 	movx	a,@dptr
      006519 48               [12] 2193 	orl	a,r0
      00651A 70 03            [24] 2194 	jnz	01330$
      00651C 02 67 63         [24] 2195 	ljmp	00273$
      00651F                       2196 01330$:
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      00651F C0 03            [24] 2198 	push	ar3
      006521 C0 04            [24] 2199 	push	ar4
      006523 8D 01            [24] 2200 	mov	ar1,r5
                                   2201 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006525 8E 00            [24] 2202 	mov	ar0,r6
      006527 B8 01 03         [24] 2203 	cjne	r0,#0x01,01331$
      00652A E8               [12] 2204 	mov	a,r0
      00652B 80 01            [24] 2205 	sjmp	01332$
      00652D                       2206 01331$:
      00652D E4               [12] 2207 	clr	a
      00652E                       2208 01332$:
      00652E F5 17            [12] 2209 	mov	_control_setup_sloc3_1_0,a
      006530 D0 04            [24] 2210 	pop	ar4
      006532 D0 03            [24] 2211 	pop	ar3
      006534 E5 17            [12] 2212 	mov	a,_control_setup_sloc3_1_0
      006536 60 17            [24] 2213 	jz	00251$
      006538 EB               [12] 2214 	mov	a,r3
      006539 4C               [12] 2215 	orl	a,r4
      00653A 70 13            [24] 2216 	jnz	00251$
      00653C E9               [12] 2217 	mov	a,r1
      00653D 70 10            [24] 2218 	jnz	00251$
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      00653F 90 07 EE         [24] 2220 	mov	dptr,#_control_setup_length_10000_290
      006542 74 08            [12] 2221 	mov	a,#0x08
      006544 F0               [24] 2222 	movx	@dptr,a
      006545 E4               [12] 2223 	clr	a
      006546 A3               [24] 2224 	inc	dptr
      006547 F0               [24] 2225 	movx	@dptr,a
                                   2226 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006548 90 07 F0         [24] 2227 	mov	dptr,#_control_setup_offset_10000_290
      00654B F0               [24] 2228 	movx	@dptr,a
      00654C 02 66 D3         [24] 2229 	ljmp	00252$
      00654F                       2230 00251$:
                                   2231 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00654F E5 17            [12] 2232 	mov	a,_control_setup_sloc3_1_0
      006551 60 27            [24] 2233 	jz	00245$
      006553 BB 02 24         [24] 2234 	cjne	r3,#0x02,00245$
      006556 BC 00 21         [24] 2235 	cjne	r4,#0x00,00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006559 B9 07 00         [24] 2237 	cjne	r1,#0x07,01339$
      00655C                       2238 01339$:
      00655C 50 1C            [24] 2239 	jnc	00245$
      00655E E9               [12] 2240 	mov	a,r1
      00655F 90 BC 53         [24] 2241 	mov	dptr,#_shared_lengths
      006562 93               [24] 2242 	movc	a,@a+dptr
      006563 F8               [12] 2243 	mov	r0,a
      006564 60 14            [24] 2244 	jz	00245$
                                   2245 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006566 90 07 EE         [24] 2246 	mov	dptr,#_control_setup_length_10000_290
      006569 E8               [12] 2247 	mov	a,r0
      00656A F0               [24] 2248 	movx	@dptr,a
      00656B E4               [12] 2249 	clr	a
      00656C A3               [24] 2250 	inc	dptr
      00656D F0               [24] 2251 	movx	@dptr,a
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      00656E E9               [12] 2253 	mov	a,r1
      00656F 90 BC 4C         [24] 2254 	mov	dptr,#_shared_offsets
      006572 93               [24] 2255 	movc	a,@a+dptr
      006573 90 07 F0         [24] 2256 	mov	dptr,#_control_setup_offset_10000_290
      006576 F0               [24] 2257 	movx	@dptr,a
      006577 02 66 D3         [24] 2258 	ljmp	00252$
      00657A                       2259 00245$:
                                   2260 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00657A E5 17            [12] 2261 	mov	a,_control_setup_sloc3_1_0
      00657C 60 7A            [24] 2262 	jz	00240$
      00657E BB 01 77         [24] 2263 	cjne	r3,#0x01,00240$
      006581 BC 00 74         [24] 2264 	cjne	r4,#0x00,00240$
      006584 E9               [12] 2265 	mov	a,r1
      006585 70 71            [24] 2266 	jnz	00240$
                                   2267 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006587 90 07 80         [24] 2268 	mov	dptr,#_D0SetupLen
      00658A E0               [24] 2269 	movx	a,@dptr
      00658B F8               [12] 2270 	mov	r0,a
      00658C A3               [24] 2271 	inc	dptr
      00658D E0               [24] 2272 	movx	a,@dptr
      00658E F9               [12] 2273 	mov	r1,a
      00658F C3               [12] 2274 	clr	c
      006590 E8               [12] 2275 	mov	a,r0
      006591 94 20            [12] 2276 	subb	a,#0x20
      006593 E9               [12] 2277 	mov	a,r1
      006594 94 00            [12] 2278 	subb	a,#0x00
      006596 50 0A            [24] 2279 	jnc	00320$
      006598 90 07 80         [24] 2280 	mov	dptr,#_D0SetupLen
      00659B E0               [24] 2281 	movx	a,@dptr
      00659C F8               [12] 2282 	mov	r0,a
      00659D A3               [24] 2283 	inc	dptr
      00659E E0               [24] 2284 	movx	a,@dptr
      00659F F9               [12] 2285 	mov	r1,a
      0065A0 80 04            [24] 2286 	sjmp	00321$
      0065A2                       2287 00320$:
      0065A2 78 20            [12] 2288 	mov	r0,#0x20
      0065A4 79 00            [12] 2289 	mov	r1,#0x00
      0065A6                       2290 00321$:
                                   2291 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0065A6 75 17 00         [24] 2292 	mov	_control_setup_sloc3_1_0,#0x00
      0065A9                       2293 00293$:
      0065A9 C0 03            [24] 2294 	push	ar3
      0065AB C0 04            [24] 2295 	push	ar4
      0065AD AB 17            [24] 2296 	mov	r3,_control_setup_sloc3_1_0
      0065AF 7C 00            [12] 2297 	mov	r4,#0x00
      0065B1 C3               [12] 2298 	clr	c
      0065B2 EB               [12] 2299 	mov	a,r3
      0065B3 98               [12] 2300 	subb	a,r0
      0065B4 EC               [12] 2301 	mov	a,r4
      0065B5 99               [12] 2302 	subb	a,r1
      0065B6 D0 04            [24] 2303 	pop	ar4
      0065B8 D0 03            [24] 2304 	pop	ar3
      0065BA 50 32            [24] 2305 	jnc	00222$
      0065BC C0 00            [24] 2306 	push	ar0
      0065BE C0 01            [24] 2307 	push	ar1
      0065C0 85 17 19         [24] 2308 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0065C3 74 10            [12] 2309 	mov	a,#0x10
      0065C5 24 00            [12] 2310 	add	a, #0x00
      0065C7 F5 1A            [12] 2311 	mov	(_control_setup_sloc4_1_0 + 1),a
      0065C9 A8 17            [24] 2312 	mov	r0,_control_setup_sloc3_1_0
      0065CB 79 00            [12] 2313 	mov	r1,#0x00
      0065CD 74 C0            [12] 2314 	mov	a,#0xc0
      0065CF 28               [12] 2315 	add	a, r0
      0065D0 F8               [12] 2316 	mov	r0,a
      0065D1 E4               [12] 2317 	clr	a
      0065D2 39               [12] 2318 	addc	a, r1
      0065D3 F9               [12] 2319 	mov	r1,a
      0065D4 88 82            [24] 2320 	mov	dpl,r0
      0065D6 74 10            [12] 2321 	mov	a,#0x10
      0065D8 29               [12] 2322 	add	a, r1
      0065D9 F5 83            [12] 2323 	mov	dph,a
      0065DB E0               [24] 2324 	movx	a,@dptr
      0065DC 85 19 82         [24] 2325 	mov	dpl,_control_setup_sloc4_1_0
      0065DF 85 1A 83         [24] 2326 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0065E2 F0               [24] 2327 	movx	@dptr,a
      0065E3 E5 17            [12] 2328 	mov	a,_control_setup_sloc3_1_0
      0065E5 04               [12] 2329 	inc	a
      0065E6 F5 17            [12] 2330 	mov	_control_setup_sloc3_1_0,a
      0065E8 D0 01            [24] 2331 	pop	ar1
      0065EA D0 00            [24] 2332 	pop	ar0
      0065EC 80 BB            [24] 2333 	sjmp	00293$
      0065EE                       2334 00222$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0065EE 90 07 EE         [24] 2336 	mov	dptr,#_control_setup_length_10000_290
      0065F1 E4               [12] 2337 	clr	a
      0065F2 F0               [24] 2338 	movx	@dptr,a
      0065F3 A3               [24] 2339 	inc	dptr
      0065F4 F0               [24] 2340 	movx	@dptr,a
      0065F5 02 66 D3         [24] 2341 	ljmp	00252$
      0065F8                       2342 00240$:
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0065F8 8D 00            [24] 2344 	mov	ar0,r5
      0065FA 8E 01            [24] 2345 	mov	ar1,r6
      0065FC B8 00 21         [24] 2346 	cjne	r0,#0x00,00236$
      0065FF B9 02 1E         [24] 2347 	cjne	r1,#0x02,00236$
      006602 EB               [12] 2348 	mov	a,r3
      006603 4C               [12] 2349 	orl	a,r4
      006604 70 1A            [24] 2350 	jnz	00236$
                                   2351 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006606 90 07 8A         [24] 2352 	mov	dptr,#_KB_USB_SetReport
      006609 E0               [24] 2353 	movx	a,@dptr
      00660A 90 10 00         [24] 2354 	mov	dptr,#0x1000
      00660D F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      00660E 90 07 EE         [24] 2357 	mov	dptr,#_control_setup_length_10000_290
      006611 E4               [12] 2358 	clr	a
      006612 F0               [24] 2359 	movx	@dptr,a
      006613 A3               [24] 2360 	inc	dptr
      006614 F0               [24] 2361 	movx	@dptr,a
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006615 90 07 80         [24] 2363 	mov	dptr,#_D0SetupLen
      006618 04               [12] 2364 	inc	a
      006619 F0               [24] 2365 	movx	@dptr,a
      00661A E4               [12] 2366 	clr	a
      00661B A3               [24] 2367 	inc	dptr
      00661C F0               [24] 2368 	movx	@dptr,a
      00661D 02 66 D3         [24] 2369 	ljmp	00252$
      006620                       2370 00236$:
                                   2371 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006620 B8 06 41         [24] 2372 	cjne	r0,#0x06,00232$
      006623 B9 02 3E         [24] 2373 	cjne	r1,#0x02,00232$
      006626 BB 02 3B         [24] 2374 	cjne	r3,#0x02,00232$
      006629 BC 00 38         [24] 2375 	cjne	r4,#0x00,00232$
                                   2376 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00662C C0 03            [24] 2377 	push	ar3
      00662E C0 04            [24] 2378 	push	ar4
      006630 90 10 00         [24] 2379 	mov	dptr,#0x1000
      006633 74 06            [12] 2380 	mov	a,#0x06
      006635 F0               [24] 2381 	movx	@dptr,a
                                   2382 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006636 90 07 8A         [24] 2383 	mov	dptr,#_KB_USB_SetReport
      006639 E0               [24] 2384 	movx	a,@dptr
      00663A 90 10 01         [24] 2385 	mov	dptr,#0x1001
      00663D F0               [24] 2386 	movx	@dptr,a
                                   2387 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00663E 90 07 EE         [24] 2388 	mov	dptr,#_control_setup_length_10000_290
      006641 E4               [12] 2389 	clr	a
      006642 F0               [24] 2390 	movx	@dptr,a
      006643 A3               [24] 2391 	inc	dptr
      006644 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      006645 90 07 80         [24] 2394 	mov	dptr,#_D0SetupLen
      006648 E0               [24] 2395 	movx	a,@dptr
      006649 FB               [12] 2396 	mov	r3,a
      00664A A3               [24] 2397 	inc	dptr
      00664B E0               [24] 2398 	movx	a,@dptr
      00664C FC               [12] 2399 	mov	r4,a
      00664D C3               [12] 2400 	clr	c
      00664E 74 02            [12] 2401 	mov	a,#0x02
      006650 9B               [12] 2402 	subb	a,r3
      006651 E4               [12] 2403 	clr	a
      006652 9C               [12] 2404 	subb	a,r4
      006653 D0 04            [24] 2405 	pop	ar4
      006655 D0 03            [24] 2406 	pop	ar3
      006657 50 7A            [24] 2407 	jnc	00252$
                                   2408 ;	free result
      006659 90 07 80         [24] 2409 	mov	dptr,#_D0SetupLen
      00665C 74 02            [12] 2410 	mov	a,#0x02
      00665E F0               [24] 2411 	movx	@dptr,a
      00665F E4               [12] 2412 	clr	a
      006660 A3               [24] 2413 	inc	dptr
      006661 F0               [24] 2414 	movx	@dptr,a
      006662 80 6F            [24] 2415 	sjmp	00252$
      006664                       2416 00232$:
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006664 B8 00 69         [24] 2418 	cjne	r0,#0x00,00228$
      006667 B9 03 66         [24] 2419 	cjne	r1,#0x03,00228$
      00666A BB 01 63         [24] 2420 	cjne	r3,#0x01,00228$
      00666D BC 00 60         [24] 2421 	cjne	r4,#0x00,00228$
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006670 90 10 00         [24] 2423 	mov	dptr,#0x1000
      006673 74 41            [12] 2424 	mov	a,#0x41
      006675 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006676 A3               [24] 2427 	inc	dptr
      006677 74 4B            [12] 2428 	mov	a,#0x4b
      006679 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      00667A A3               [24] 2431 	inc	dptr
      00667B 74 42            [12] 2432 	mov	a,#0x42
      00667D F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      00667E A3               [24] 2435 	inc	dptr
      00667F 74 54            [12] 2436 	mov	a,#0x54
      006681 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006682 A3               [24] 2439 	inc	dptr
      006683 74 01            [12] 2440 	mov	a,#0x01
      006685 F0               [24] 2441 	movx	@dptr,a
                                   2442 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006686 90 07 8B         [24] 2443 	mov	dptr,#_ak820_boot_stage
      006689 E0               [24] 2444 	movx	a,@dptr
      00668A 90 10 05         [24] 2445 	mov	dptr,#0x1005
      00668D F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00668E 90 07 8C         [24] 2448 	mov	dptr,#_ak820_main_heartbeat
      006691 E0               [24] 2449 	movx	a,@dptr
      006692 90 10 06         [24] 2450 	mov	dptr,#0x1006
      006695 F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006696 90 07 86         [24] 2453 	mov	dptr,#_USB_EnumStatus
      006699 E0               [24] 2454 	movx	a,@dptr
      00669A 60 02            [24] 2455 	jz	00322$
      00669C 74 01            [12] 2456 	mov	a,#0x01
      00669E                       2457 00322$:
      00669E F9               [12] 2458 	mov	r1,a
      00669F 90 07 87         [24] 2459 	mov	dptr,#_USB_SleepStatus
      0066A2 E0               [24] 2460 	movx	a,@dptr
      0066A3 54 02            [12] 2461 	anl	a,#0x02
      0066A5 F8               [12] 2462 	mov	r0,a
      0066A6 E9               [12] 2463 	mov	a,r1
      0066A7 42 00            [12] 2464 	orl	ar0,a
      0066A9 90 10 07         [24] 2465 	mov	dptr,#0x1007
      0066AC E8               [12] 2466 	mov	a,r0
      0066AD F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      0066AE 90 07 EE         [24] 2469 	mov	dptr,#_control_setup_length_10000_290
      0066B1 E4               [12] 2470 	clr	a
      0066B2 F0               [24] 2471 	movx	@dptr,a
      0066B3 A3               [24] 2472 	inc	dptr
      0066B4 F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0066B5 90 07 80         [24] 2475 	mov	dptr,#_D0SetupLen
      0066B8 E0               [24] 2476 	movx	a,@dptr
      0066B9 F8               [12] 2477 	mov	r0,a
      0066BA A3               [24] 2478 	inc	dptr
      0066BB E0               [24] 2479 	movx	a,@dptr
      0066BC F9               [12] 2480 	mov	r1,a
      0066BD C3               [12] 2481 	clr	c
      0066BE 74 08            [12] 2482 	mov	a,#0x08
      0066C0 98               [12] 2483 	subb	a,r0
      0066C1 E4               [12] 2484 	clr	a
      0066C2 99               [12] 2485 	subb	a,r1
      0066C3 50 0E            [24] 2486 	jnc	00252$
                                   2487 ;	free result
      0066C5 90 07 80         [24] 2488 	mov	dptr,#_D0SetupLen
      0066C8 74 08            [12] 2489 	mov	a,#0x08
      0066CA F0               [24] 2490 	movx	@dptr,a
      0066CB E4               [12] 2491 	clr	a
      0066CC A3               [24] 2492 	inc	dptr
      0066CD F0               [24] 2493 	movx	@dptr,a
      0066CE 80 03            [24] 2494 	sjmp	00252$
      0066D0                       2495 00228$:
                                   2496 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      0066D0 02 5E 39         [24] 2497 	ljmp	_control_stall
      0066D3                       2498 00252$:
                                   2499 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      0066D3 90 07 EE         [24] 2500 	mov	dptr,#_control_setup_length_10000_290
      0066D6 E0               [24] 2501 	movx	a,@dptr
      0066D7 F5 19            [12] 2502 	mov	_control_setup_sloc4_1_0,a
      0066D9 A3               [24] 2503 	inc	dptr
      0066DA E0               [24] 2504 	movx	a,@dptr
      0066DB F5 1A            [12] 2505 	mov	(_control_setup_sloc4_1_0 + 1),a
      0066DD E5 19            [12] 2506 	mov	a,_control_setup_sloc4_1_0
      0066DF 45 1A            [12] 2507 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0066E1 60 50            [24] 2508 	jz	00262$
                                   2509 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      0066E3 90 07 80         [24] 2510 	mov	dptr,#_D0SetupLen
      0066E6 E0               [24] 2511 	movx	a,@dptr
      0066E7 F8               [12] 2512 	mov	r0,a
      0066E8 A3               [24] 2513 	inc	dptr
      0066E9 E0               [24] 2514 	movx	a,@dptr
      0066EA F9               [12] 2515 	mov	r1,a
      0066EB C3               [12] 2516 	clr	c
      0066EC E5 19            [12] 2517 	mov	a,_control_setup_sloc4_1_0
      0066EE 98               [12] 2518 	subb	a,r0
      0066EF E5 1A            [12] 2519 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066F1 99               [12] 2520 	subb	a,r1
      0066F2 50 0A            [24] 2521 	jnc	00559$
                                   2522 ;	free result
      0066F4 90 07 80         [24] 2523 	mov	dptr,#_D0SetupLen
      0066F7 E5 19            [12] 2524 	mov	a,_control_setup_sloc4_1_0
      0066F9 F0               [24] 2525 	movx	@dptr,a
      0066FA E5 1A            [12] 2526 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066FC A3               [24] 2527 	inc	dptr
      0066FD F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0066FE                       2530 00559$:
      0066FE 75 19 00         [24] 2531 	mov	_control_setup_sloc4_1_0,#0x00
      006701                       2532 00296$:
      006701 90 07 80         [24] 2533 	mov	dptr,#_D0SetupLen
      006704 E0               [24] 2534 	movx	a,@dptr
      006705 F8               [12] 2535 	mov	r0,a
      006706 C3               [12] 2536 	clr	c
      006707 E5 19            [12] 2537 	mov	a,_control_setup_sloc4_1_0
      006709 98               [12] 2538 	subb	a,r0
      00670A 50 46            [24] 2539 	jnc	00263$
      00670C 85 19 17         [24] 2540 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00670F 74 10            [12] 2541 	mov	a,#0x10
      006711 24 00            [12] 2542 	add	a, #0x00
      006713 F5 18            [12] 2543 	mov	(_control_setup_sloc3_1_0 + 1),a
      006715 90 07 F0         [24] 2544 	mov	dptr,#_control_setup_offset_10000_290
      006718 E0               [24] 2545 	movx	a,@dptr
      006719 25 19            [12] 2546 	add	a, _control_setup_sloc4_1_0
      00671B 24 B0            [12] 2547 	add	a, #_input_snapshot
      00671D F5 82            [12] 2548 	mov	dpl,a
      00671F E4               [12] 2549 	clr	a
      006720 34 07            [12] 2550 	addc	a,#(_input_snapshot >> 8)
      006722 F5 83            [12] 2551 	mov	dph,a
      006724 E0               [24] 2552 	movx	a,@dptr
      006725 85 17 82         [24] 2553 	mov	dpl,_control_setup_sloc3_1_0
      006728 85 18 83         [24] 2554 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00672B F0               [24] 2555 	movx	@dptr,a
      00672C E5 19            [12] 2556 	mov	a,_control_setup_sloc4_1_0
      00672E 04               [12] 2557 	inc	a
      00672F F5 19            [12] 2558 	mov	_control_setup_sloc4_1_0,a
      006731 80 CE            [24] 2559 	sjmp	00296$
      006733                       2560 00262$:
                                   2561 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006733 BB 01 1C         [24] 2562 	cjne	r3,#0x01,00263$
      006736 BC 00 19         [24] 2563 	cjne	r4,#0x00,00263$
      006739 90 07 80         [24] 2564 	mov	dptr,#_D0SetupLen
      00673C E0               [24] 2565 	movx	a,@dptr
      00673D F8               [12] 2566 	mov	r0,a
      00673E A3               [24] 2567 	inc	dptr
      00673F E0               [24] 2568 	movx	a,@dptr
      006740 F9               [12] 2569 	mov	r1,a
      006741 C3               [12] 2570 	clr	c
      006742 74 20            [12] 2571 	mov	a,#0x20
      006744 98               [12] 2572 	subb	a,r0
      006745 E4               [12] 2573 	clr	a
      006746 99               [12] 2574 	subb	a,r1
      006747 50 09            [24] 2575 	jnc	00263$
                                   2576 ;	free result
      006749 90 07 80         [24] 2577 	mov	dptr,#_D0SetupLen
      00674C 74 20            [12] 2578 	mov	a,#0x20
      00674E F0               [24] 2579 	movx	@dptr,a
      00674F E4               [12] 2580 	clr	a
      006750 A3               [24] 2581 	inc	dptr
      006751 F0               [24] 2582 	movx	@dptr,a
      006752                       2583 00263$:
                                   2584 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006752 90 07 80         [24] 2585 	mov	dptr,#_D0SetupLen
      006755 E0               [24] 2586 	movx	a,@dptr
      006756 90 22 08         [24] 2587 	mov	dptr,#0x2208
      006759 F0               [24] 2588 	movx	@dptr,a
                                   2589 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      00675A 90 07 E4         [24] 2590 	mov	dptr,#_control_phase
      00675D 74 02            [12] 2591 	mov	a,#0x02
      00675F F0               [24] 2592 	movx	@dptr,a
      006760 02 67 E8         [24] 2593 	ljmp	00291$
      006763                       2594 00273$:
                                   2595 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006763 EB               [12] 2596 	mov	a,r3
      006764 4C               [12] 2597 	orl	a,r4
      006765 70 37            [24] 2598 	jnz	00265$
      006767 90 07 85         [24] 2599 	mov	dptr,#_D0UsbConfig
      00676A E0               [24] 2600 	movx	a,@dptr
      00676B 60 31            [24] 2601 	jz	00265$
      00676D EA               [12] 2602 	mov	a,r2
      00676E 60 2E            [24] 2603 	jz	00265$
      006770 90 07 7F         [24] 2604 	mov	dptr,#_D0SetupReqCode
      006773 E0               [24] 2605 	movx	a,@dptr
      006774 FA               [12] 2606 	mov	r2,a
      006775 BA 03 26         [24] 2607 	cjne	r2,#0x03,00265$
      006778 30 16 23         [24] 2608 	jnb	_control_setup_zero_value_10000_290,00265$
      00677B 90 07 80         [24] 2609 	mov	dptr,#_D0SetupLen
      00677E E0               [24] 2610 	movx	a,@dptr
      00677F F9               [12] 2611 	mov	r1,a
      006780 A3               [24] 2612 	inc	dptr
      006781 E0               [24] 2613 	movx	a,@dptr
      006782 FA               [12] 2614 	mov	r2,a
      006783 B9 01 18         [24] 2615 	cjne	r1,#0x01,00265$
      006786 BA 00 15         [24] 2616 	cjne	r2,#0x00,00265$
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006789 90 0D A9         [24] 2618 	mov	dptr,#_keyboard_protocol
      00678C E0               [24] 2619 	movx	a,@dptr
      00678D 90 10 00         [24] 2620 	mov	dptr,#0x1000
      006790 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006791 90 22 08         [24] 2623 	mov	dptr,#0x2208
      006794 74 01            [12] 2624 	mov	a,#0x01
      006796 F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006797 90 07 E4         [24] 2627 	mov	dptr,#_control_phase
      00679A 04               [12] 2628 	inc	a
      00679B F0               [24] 2629 	movx	@dptr,a
      00679C 80 4A            [24] 2630 	sjmp	00291$
      00679E                       2631 00265$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2633 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      00679E 02 5E 39         [24] 2634 	ljmp	_control_stall
      0067A1                       2635 00282$:
                                   2636 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0067A1 30 14 3E         [24] 2637 	jnb	_control_setup_valid_interface_10000_290,00284$
      0067A4 90 07 85         [24] 2638 	mov	dptr,#_D0UsbConfig
      0067A7 E0               [24] 2639 	movx	a,@dptr
      0067A8 60 38            [24] 2640 	jz	00284$
      0067AA BF A1 35         [24] 2641 	cjne	r7,#0xa1,00284$
      0067AD 8E 05            [24] 2642 	mov	ar5,r6
      0067AF 7E 00            [12] 2643 	mov	r6,#0x00
      0067B1 ED               [12] 2644 	mov	a,r5
      0067B2 4E               [12] 2645 	orl	a,r6
      0067B3 70 2D            [24] 2646 	jnz	00284$
      0067B5 90 07 80         [24] 2647 	mov	dptr,#_D0SetupLen
      0067B8 E0               [24] 2648 	movx	a,@dptr
      0067B9 FE               [12] 2649 	mov	r6,a
      0067BA A3               [24] 2650 	inc	dptr
      0067BB E0               [24] 2651 	movx	a,@dptr
      0067BC FF               [12] 2652 	mov	r7,a
      0067BD BE 01 22         [24] 2653 	cjne	r6,#0x01,00284$
      0067C0 BF 00 1F         [24] 2654 	cjne	r7,#0x00,00284$
                                   2655 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0067C3 EB               [12] 2656 	mov	a,r3
      0067C4 4C               [12] 2657 	orl	a,r4
      0067C5 70 07            [24] 2658 	jnz	00324$
      0067C7 90 06 47         [24] 2659 	mov	dptr,#_keyboard_idle
      0067CA E0               [24] 2660 	movx	a,@dptr
      0067CB FF               [12] 2661 	mov	r7,a
      0067CC 80 02            [24] 2662 	sjmp	00325$
      0067CE                       2663 00324$:
      0067CE 7F 00            [12] 2664 	mov	r7,#0x00
      0067D0                       2665 00325$:
      0067D0 90 10 00         [24] 2666 	mov	dptr,#0x1000
      0067D3 EF               [12] 2667 	mov	a,r7
      0067D4 F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      0067D5 90 22 08         [24] 2670 	mov	dptr,#0x2208
      0067D8 74 01            [12] 2671 	mov	a,#0x01
      0067DA F0               [24] 2672 	movx	@dptr,a
                                   2673 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      0067DB 90 07 E4         [24] 2674 	mov	dptr,#_control_phase
      0067DE 04               [12] 2675 	inc	a
      0067DF F0               [24] 2676 	movx	@dptr,a
      0067E0 80 06            [24] 2677 	sjmp	00291$
      0067E2                       2678 00284$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2680 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      0067E2 02 5E 39         [24] 2681 	ljmp	_control_stall
      0067E5                       2682 00290$:
                                   2683 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      0067E5 02 5E 39         [24] 2684 	ljmp	_control_stall
      0067E8                       2685 00291$:
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0067E8 90 22 00         [24] 2687 	mov	dptr,#0x2200
      0067EB 74 C0            [12] 2688 	mov	a,#0xc0
      0067ED F0               [24] 2689 	movx	@dptr,a
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      0067EE 22               [24] 2691 	ret
                                   2692 ;------------------------------------------------------------
                                   2693 ;Allocation info for local variables in function 'control_out'
                                   2694 ;------------------------------------------------------------
                                   2695 ;i             Allocated with name '_control_out_i_10000_374'
                                   2696 ;------------------------------------------------------------
                                   2697 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2698 ;	-----------------------------------------
                                   2699 ;	 function control_out
                                   2700 ;	-----------------------------------------
      0067EF                       2701 _control_out:
                                   2702 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0067EF 90 22 0F         [24] 2703 	mov	dptr,#0x220f
      0067F2 E0               [24] 2704 	movx	a,@dptr
      0067F3 20 E6 01         [24] 2705 	jb	acc.6,00102$
      0067F6 22               [24] 2706 	ret
      0067F7                       2707 00102$:
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0067F7 90 07 E4         [24] 2709 	mov	dptr,#_control_phase
      0067FA E0               [24] 2710 	movx	a,@dptr
      0067FB FF               [12] 2711 	mov	r7,a
      0067FC BF 02 12         [24] 2712 	cjne	r7,#0x02,00104$
      0067FF 90 22 0E         [24] 2713 	mov	dptr,#0x220e
      006802 E0               [24] 2714 	movx	a,@dptr
      006803 70 0C            [24] 2715 	jnz	00104$
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006805 90 07 E4         [24] 2717 	mov	dptr,#_control_phase
      006808 E4               [12] 2718 	clr	a
      006809 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00680A 90 22 00         [24] 2721 	mov	dptr,#0x2200
      00680D 74 02            [12] 2722 	mov	a,#0x02
      00680F F0               [24] 2723 	movx	@dptr,a
                                   2724 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006810 22               [24] 2725 	ret
      006811                       2726 00104$:
                                   2727 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006811 BF 04 19         [24] 2728 	cjne	r7,#0x04,00106$
      006814 90 22 0E         [24] 2729 	mov	dptr,#0x220e
      006817 E0               [24] 2730 	movx	a,@dptr
      006818 FF               [12] 2731 	mov	r7,a
      006819 90 07 80         [24] 2732 	mov	dptr,#_D0SetupLen
      00681C E0               [24] 2733 	movx	a,@dptr
      00681D FD               [12] 2734 	mov	r5,a
      00681E A3               [24] 2735 	inc	dptr
      00681F E0               [24] 2736 	movx	a,@dptr
      006820 FE               [12] 2737 	mov	r6,a
      006821 7C 00            [12] 2738 	mov	r4,#0x00
      006823 EF               [12] 2739 	mov	a,r7
      006824 B5 05 06         [24] 2740 	cjne	a,ar5,00209$
      006827 EC               [12] 2741 	mov	a,r4
      006828 B5 06 02         [24] 2742 	cjne	a,ar6,00209$
      00682B 80 03            [24] 2743 	sjmp	00107$
      00682D                       2744 00209$:
      00682D                       2745 00106$:
      00682D 02 5E 39         [24] 2746 	ljmp	_control_stall
      006830                       2747 00107$:
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006830 90 07 E5         [24] 2749 	mov	dptr,#_output_kind
      006833 E0               [24] 2750 	movx	a,@dptr
      006834 FF               [12] 2751 	mov	r7,a
      006835 BF 01 2E         [24] 2752 	cjne	r7,#0x01,00118$
      006838 90 07 8D         [24] 2753 	mov	dptr,#_raw_state
      00683B E0               [24] 2754 	movx	a,@dptr
      00683C FE               [12] 2755 	mov	r6,a
      00683D BE 01 26         [24] 2756 	cjne	r6,#0x01,00118$
                                   2757 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006840 7E 00            [12] 2758 	mov	r6,#0x00
      006842                       2759 00121$:
      006842 EE               [12] 2760 	mov	a,r6
      006843 24 8E            [12] 2761 	add	a, #_raw_buffer
      006845 FC               [12] 2762 	mov	r4,a
      006846 E4               [12] 2763 	clr	a
      006847 34 07            [12] 2764 	addc	a, #(_raw_buffer >> 8)
      006849 FD               [12] 2765 	mov	r5,a
      00684A 8E 82            [24] 2766 	mov	dpl,r6
      00684C 74 10            [12] 2767 	mov	a,#0x10
      00684E 24 00            [12] 2768 	add	a, #0x00
      006850 F5 83            [12] 2769 	mov	dph,a
      006852 E0               [24] 2770 	movx	a,@dptr
      006853 8C 82            [24] 2771 	mov	dpl,r4
      006855 8D 83            [24] 2772 	mov	dph,r5
      006857 F0               [24] 2773 	movx	@dptr,a
      006858 0E               [12] 2774 	inc	r6
      006859 BE 20 00         [24] 2775 	cjne	r6,#0x20,00214$
      00685C                       2776 00214$:
      00685C 40 E4            [24] 2777 	jc	00121$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00685E 90 07 8D         [24] 2779 	mov	dptr,#_raw_state
      006861 74 02            [12] 2780 	mov	a,#0x02
      006863 F0               [24] 2781 	movx	@dptr,a
      006864 80 2B            [24] 2782 	sjmp	00119$
      006866                       2783 00118$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006866 BF 02 0A         [24] 2785 	cjne	r7,#0x02,00115$
                                   2786 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006869 90 10 00         [24] 2787 	mov	dptr,#0x1000
      00686C E0               [24] 2788 	movx	a,@dptr
      00686D 90 07 8A         [24] 2789 	mov	dptr,#_KB_USB_SetReport
      006870 F0               [24] 2790 	movx	@dptr,a
      006871 80 1E            [24] 2791 	sjmp	00119$
      006873                       2792 00115$:
                                   2793 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006873 BF 03 18         [24] 2794 	cjne	r7,#0x03,00111$
      006876 90 10 00         [24] 2795 	mov	dptr,#0x1000
      006879 E0               [24] 2796 	movx	a,@dptr
      00687A FF               [12] 2797 	mov	r7,a
      00687B 90 07 E6         [24] 2798 	mov	dptr,#_output_report_id
      00687E E0               [24] 2799 	movx	a,@dptr
      00687F FE               [12] 2800 	mov	r6,a
      006880 EF               [12] 2801 	mov	a,r7
      006881 B5 06 0A         [24] 2802 	cjne	a,ar6,00111$
                                   2803 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006884 90 10 01         [24] 2804 	mov	dptr,#0x1001
      006887 E0               [24] 2805 	movx	a,@dptr
      006888 90 07 8A         [24] 2806 	mov	dptr,#_KB_USB_SetReport
      00688B F0               [24] 2807 	movx	@dptr,a
      00688C 80 03            [24] 2808 	sjmp	00119$
      00688E                       2809 00111$:
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      00688E 02 5E 39         [24] 2811 	ljmp	_control_stall
      006891                       2812 00119$:
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006891 90 07 E5         [24] 2814 	mov	dptr,#_output_kind
      006894 E4               [12] 2815 	clr	a
      006895 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006896 90 07 80         [24] 2818 	mov	dptr,#_D0SetupLen
      006899 F0               [24] 2819 	movx	@dptr,a
      00689A A3               [24] 2820 	inc	dptr
      00689B F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      00689C 90 07 E4         [24] 2823 	mov	dptr,#_control_phase
      00689F 74 03            [12] 2824 	mov	a,#0x03
      0068A1 F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      0068A2 90 22 08         [24] 2827 	mov	dptr,#0x2208
      0068A5 E4               [12] 2828 	clr	a
      0068A6 F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0068A7 F5 82            [12] 2831 	mov	dpl,a
      0068A9 74 48            [12] 2832 	mov	a,#0x48
      0068AB F0               [24] 2833 	movx	@dptr,a
                                   2834 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      0068AC 22               [24] 2835 	ret
                                   2836 ;------------------------------------------------------------
                                   2837 ;Allocation info for local variables in function 'control_in'
                                   2838 ;------------------------------------------------------------
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2840 ;	-----------------------------------------
                                   2841 ;	 function control_in
                                   2842 ;	-----------------------------------------
      0068AD                       2843 _control_in:
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      0068AD 90 07 E4         [24] 2845 	mov	dptr,#_control_phase
      0068B0 E0               [24] 2846 	movx	a,@dptr
      0068B1 FF               [12] 2847 	mov	r7,a
      0068B2 BF 01 22         [24] 2848 	cjne	r7,#0x01,00109$
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      0068B5 90 07 80         [24] 2850 	mov	dptr,#_D0SetupLen
      0068B8 E0               [24] 2851 	movx	a,@dptr
      0068B9 FD               [12] 2852 	mov	r5,a
      0068BA A3               [24] 2853 	inc	dptr
      0068BB E0               [24] 2854 	movx	a,@dptr
      0068BC 4D               [12] 2855 	orl	a,r5
      0068BD 70 06            [24] 2856 	jnz	00101$
      0068BF 90 07 E7         [24] 2857 	mov	dptr,#_control_zlp
      0068C2 E0               [24] 2858 	movx	a,@dptr
      0068C3 60 0A            [24] 2859 	jz	00102$
      0068C5                       2860 00101$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      0068C5 90 22 00         [24] 2862 	mov	dptr,#0x2200
      0068C8 E0               [24] 2863 	movx	a,@dptr
      0068C9 64 40            [12] 2864 	xrl	a,#0x40
      0068CB F0               [24] 2865 	movx	@dptr,a
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      0068CC 02 5E 5B         [24] 2868 	ljmp	_control_next
      0068CF                       2869 00102$:
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      0068CF 90 07 E4         [24] 2871 	mov	dptr,#_control_phase
      0068D2 74 02            [12] 2872 	mov	a,#0x02
      0068D4 F0               [24] 2873 	movx	@dptr,a
      0068D5 80 18            [24] 2874 	sjmp	00110$
      0068D7                       2875 00109$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      0068D7 BF 03 15         [24] 2877 	cjne	r7,#0x03,00110$
                                   2878 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0068DA 90 07 7F         [24] 2879 	mov	dptr,#_D0SetupReqCode
      0068DD E0               [24] 2880 	movx	a,@dptr
      0068DE FF               [12] 2881 	mov	r7,a
      0068DF BF 05 08         [24] 2882 	cjne	r7,#0x05,00105$
      0068E2 90 07 80         [24] 2883 	mov	dptr,#_D0SetupLen
      0068E5 E0               [24] 2884 	movx	a,@dptr
      0068E6 90 22 07         [24] 2885 	mov	dptr,#0x2207
      0068E9 F0               [24] 2886 	movx	@dptr,a
      0068EA                       2887 00105$:
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      0068EA 90 07 E4         [24] 2889 	mov	dptr,#_control_phase
      0068ED E4               [12] 2890 	clr	a
      0068EE F0               [24] 2891 	movx	@dptr,a
      0068EF                       2892 00110$:
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068EF 90 22 00         [24] 2894 	mov	dptr,#0x2200
      0068F2 74 82            [12] 2895 	mov	a,#0x82
      0068F4 F0               [24] 2896 	movx	@dptr,a
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      0068F5 22               [24] 2898 	ret
                                   2899 ;------------------------------------------------------------
                                   2900 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2901 ;------------------------------------------------------------
                                   2902 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_398'
                                   2903 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_398'
                                   2904 ;------------------------------------------------------------
                                   2905 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2906 ;	-----------------------------------------
                                   2907 ;	 function USB_DeviceInterrupt
                                   2908 ;	-----------------------------------------
      0068F6                       2909 _USB_DeviceInterrupt:
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      0068F6                       2911 00129$:
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      0068F6 90 22 3D         [24] 2913 	mov	dptr,#0x223d
      0068F9 E0               [24] 2914 	movx	a,@dptr
      0068FA 30 E0 4B         [24] 2915 	jnb	acc.0,00127$
                                   2916 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      0068FD 12 5D D8         [24] 2917 	lcall	_endpoints_reset
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006900 90 22 07         [24] 2919 	mov	dptr,#0x2207
      006903 E4               [12] 2920 	clr	a
      006904 F0               [24] 2921 	movx	@dptr,a
                                   2922 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006905 90 07 87         [24] 2923 	mov	dptr,#_USB_SleepStatus
      006908 F0               [24] 2924 	movx	@dptr,a
      006909 90 07 86         [24] 2925 	mov	dptr,#_USB_EnumStatus
      00690C F0               [24] 2926 	movx	@dptr,a
      00690D 90 07 85         [24] 2927 	mov	dptr,#_D0UsbConfig
      006910 F0               [24] 2928 	movx	@dptr,a
                                   2929 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006911 90 07 8A         [24] 2930 	mov	dptr,#_KB_USB_SetReport
      006914 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006915 90 0D A9         [24] 2933 	mov	dptr,#_keyboard_protocol
      006918 04               [12] 2934 	inc	a
      006919 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      00691A 90 06 47         [24] 2937 	mov	dptr,#_keyboard_idle
      00691D E4               [12] 2938 	clr	a
      00691E F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      00691F 90 07 AF         [24] 2941 	mov	dptr,#_keyboard_reset
      006922 04               [12] 2942 	inc	a
      006923 F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006924 90 07 7F         [24] 2945 	mov	dptr,#_D0SetupReqCode
      006927 74 FF            [12] 2946 	mov	a,#0xff
      006929 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      00692A 90 07 80         [24] 2949 	mov	dptr,#_D0SetupLen
      00692D E4               [12] 2950 	clr	a
      00692E F0               [24] 2951 	movx	@dptr,a
      00692F A3               [24] 2952 	inc	dptr
      006930 F0               [24] 2953 	movx	@dptr,a
                                   2954 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006931 90 07 E4         [24] 2955 	mov	dptr,#_control_phase
      006934 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006935 90 22 00         [24] 2958 	mov	dptr,#0x2200
      006938 74 02            [12] 2959 	mov	a,#0x02
      00693A F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      00693B 90 22 0F         [24] 2962 	mov	dptr,#0x220f
      00693E E4               [12] 2963 	clr	a
      00693F F0               [24] 2964 	movx	@dptr,a
                                   2965 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006940 90 22 3D         [24] 2966 	mov	dptr,#0x223d
      006943 04               [12] 2967 	inc	a
      006944 F0               [24] 2968 	movx	@dptr,a
      006945 02 69 E0         [24] 2969 	ljmp	00130$
      006948                       2970 00127$:
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006948 90 22 3D         [24] 2972 	mov	dptr,#0x223d
      00694B E0               [24] 2973 	movx	a,@dptr
      00694C 30 E5 60         [24] 2974 	jnb	acc.5,00124$
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      00694F 90 22 0F         [24] 2976 	mov	dptr,#0x220f
      006952 E0               [24] 2977 	movx	a,@dptr
      006953 FF               [12] 2978 	mov	r7,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006954 74 07            [12] 2980 	mov	a,#0x07
      006956 5F               [12] 2981 	anl	a,r7
      006957 FE               [12] 2982 	mov	r6,a
                                   2983 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006958 EF               [12] 2984 	mov	a,r7
      006959 54 18            [12] 2985 	anl	a,#0x18
      00695B 70 08            [24] 2986 	jnz	00115$
      00695D EE               [12] 2987 	mov	a,r6
      00695E 70 05            [24] 2988 	jnz	00115$
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006960 12 67 EF         [24] 2990 	lcall	_control_out
      006963 80 43            [24] 2991 	sjmp	00116$
      006965                       2992 00115$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006965 8F 05            [24] 2994 	mov	ar5,r7
      006967 74 18            [12] 2995 	mov	a,#0x18
      006969 5D               [12] 2996 	anl	a,r5
      00696A FC               [12] 2997 	mov	r4,a
      00696B BC 10 2D         [24] 2998 	cjne	r4,#0x10,00112$
                                   2999 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      00696E EE               [12] 3000 	mov	a,r6
      00696F 70 05            [24] 3001 	jnz	00106$
      006971 12 68 AD         [24] 3002 	lcall	_control_in
      006974 80 32            [24] 3003 	sjmp	00116$
      006976                       3004 00106$:
                                   3005 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006976 EE               [12] 3006 	mov	a,r6
      006977 24 FC            [12] 3007 	add	a,#0xff - 0x03
      006979 40 2D            [24] 3008 	jc	00116$
                                   3009 ;	free result
                                   3010 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00697B 8E 04            [24] 3011 	mov	ar4,r6
      00697D 7B 00            [12] 3012 	mov	r3,#0x00
      00697F 74 22            [12] 3013 	mov	a,#0x22
      006981 2B               [12] 3014 	add	a, r3
      006982 FB               [12] 3015 	mov	r3,a
      006983 8C 82            [24] 3016 	mov	dpl,r4
      006985 8B 83            [24] 3017 	mov	dph,r3
      006987 E0               [24] 3018 	movx	a,@dptr
      006988 FA               [12] 3019 	mov	r2,a
      006989 74 FC            [12] 3020 	mov	a,#0xfc
      00698B 5A               [12] 3021 	anl	a,r2
      00698C 44 02            [12] 3022 	orl	a,#0x02
      00698E 8C 82            [24] 3023 	mov	dpl,r4
      006990 8B 83            [24] 3024 	mov	dph,r3
      006992 F0               [24] 3025 	movx	@dptr,a
                                   3026 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006993 BE 03 12         [24] 3027 	cjne	r6,#0x03,00116$
      006996 12 5D BB         [24] 3028 	lcall	_raw_complete
      006999 80 0D            [24] 3029 	sjmp	00116$
      00699B                       3030 00112$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00699B 53 05 18         [24] 3032 	anl	ar5,#0x18
      00699E BD 18 07         [24] 3033 	cjne	r5,#0x18,00116$
      0069A1 EF               [12] 3034 	mov	a,r7
      0069A2 30 E5 03         [24] 3035 	jnb	acc.5,00116$
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      0069A5 12 60 52         [24] 3037 	lcall	_control_setup
      0069A8                       3038 00116$:
                                   3039 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      0069A8 90 22 0F         [24] 3040 	mov	dptr,#0x220f
      0069AB E4               [12] 3041 	clr	a
      0069AC F0               [24] 3042 	movx	@dptr,a
      0069AD 80 31            [24] 3043 	sjmp	00130$
      0069AF                       3044 00124$:
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      0069AF 90 22 3D         [24] 3046 	mov	dptr,#0x223d
      0069B2 E0               [24] 3047 	movx	a,@dptr
      0069B3 30 E2 2A         [24] 3048 	jnb	acc.2,00130$
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      0069B6 90 05 9A         [24] 3050 	mov	dptr,#_ak820_os_indicator_mode
      0069B9 E4               [12] 3051 	clr	a
      0069BA F0               [24] 3052 	movx	@dptr,a
                                   3053 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0069BB 90 22 3D         [24] 3054 	mov	dptr,#0x223d
      0069BE E0               [24] 3055 	movx	a,@dptr
      0069BF 30 E3 0A         [24] 3056 	jnb	acc.3,00119$
      0069C2 90 07 87         [24] 3057 	mov	dptr,#_USB_SleepStatus
      0069C5 E0               [24] 3058 	movx	a,@dptr
      0069C6 43 E0 02         [24] 3059 	orl	acc,#0x02
      0069C9 F0               [24] 3060 	movx	@dptr,a
      0069CA 80 0E            [24] 3061 	sjmp	00120$
      0069CC                       3062 00119$:
                                   3063 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      0069CC 90 07 87         [24] 3064 	mov	dptr,#_USB_SleepStatus
      0069CF E0               [24] 3065 	movx	a,@dptr
      0069D0 53 E0 FD         [24] 3066 	anl	acc,#0xfd
      0069D3 F0               [24] 3067 	movx	@dptr,a
                                   3068 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      0069D4 90 07 AF         [24] 3069 	mov	dptr,#_keyboard_reset
      0069D7 74 01            [12] 3070 	mov	a,#0x01
      0069D9 F0               [24] 3071 	movx	@dptr,a
      0069DA                       3072 00120$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      0069DA 90 22 3D         [24] 3074 	mov	dptr,#0x223d
      0069DD 74 04            [12] 3075 	mov	a,#0x04
      0069DF F0               [24] 3076 	movx	@dptr,a
      0069E0                       3077 00130$:
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      0069E0 90 22 3D         [24] 3079 	mov	dptr,#0x223d
      0069E3 E0               [24] 3080 	movx	a,@dptr
      0069E4 54 25            [12] 3081 	anl	a,#0x25
      0069E6 60 03            [24] 3082 	jz	00242$
      0069E8 02 68 F6         [24] 3083 	ljmp	00129$
      0069EB                       3084 00242$:
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      0069EB 22               [24] 3086 	ret
                                   3087 ;------------------------------------------------------------
                                   3088 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3089 ;------------------------------------------------------------
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3091 ;	-----------------------------------------
                                   3092 ;	 function USB_Device_Init
                                   3093 ;	-----------------------------------------
      0069EC                       3094 _USB_Device_Init:
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3096 ;	assignBit
      0069EC C2 E9            [12] 3097 	clr	_IE_USB
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      0069EE 90 22 3C         [24] 3099 	mov	dptr,#0x223c
      0069F1 E4               [12] 3100 	clr	a
      0069F2 F0               [24] 3101 	movx	@dptr,a
                                   3102 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      0069F3 90 07 8D         [24] 3103 	mov	dptr,#_raw_state
      0069F6 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      0069F7 12 5D D8         [24] 3106 	lcall	_endpoints_reset
                                   3107 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0069FA 90 07 87         [24] 3108 	mov	dptr,#_USB_SleepStatus
      0069FD E4               [12] 3109 	clr	a
      0069FE F0               [24] 3110 	movx	@dptr,a
      0069FF 90 07 86         [24] 3111 	mov	dptr,#_USB_EnumStatus
      006A02 F0               [24] 3112 	movx	@dptr,a
      006A03 90 07 85         [24] 3113 	mov	dptr,#_D0UsbConfig
      006A06 F0               [24] 3114 	movx	@dptr,a
      006A07 90 22 07         [24] 3115 	mov	dptr,#0x2207
      006A0A F0               [24] 3116 	movx	@dptr,a
                                   3117 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006A0B 90 07 88         [24] 3118 	mov	dptr,#_MCU_Sleep_Operate
      006A0E F0               [24] 3119 	movx	@dptr,a
      006A0F 90 07 89         [24] 3120 	mov	dptr,#_KB_USB_UpStatus
      006A12 F0               [24] 3121 	movx	@dptr,a
      006A13 90 07 8A         [24] 3122 	mov	dptr,#_KB_USB_SetReport
      006A16 F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006A17 90 0D A9         [24] 3125 	mov	dptr,#_keyboard_protocol
      006A1A 04               [12] 3126 	inc	a
      006A1B F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006A1C 90 06 47         [24] 3129 	mov	dptr,#_keyboard_idle
      006A1F E4               [12] 3130 	clr	a
      006A20 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006A21 90 07 AF         [24] 3133 	mov	dptr,#_keyboard_reset
      006A24 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006A25 90 07 E4         [24] 3136 	mov	dptr,#_control_phase
      006A28 F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006A29 90 07 7F         [24] 3139 	mov	dptr,#_D0SetupReqCode
      006A2C 14               [12] 3140 	dec	a
      006A2D F0               [24] 3141 	movx	@dptr,a
                                   3142 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006A2E 90 07 80         [24] 3143 	mov	dptr,#_D0SetupLen
      006A31 E4               [12] 3144 	clr	a
      006A32 F0               [24] 3145 	movx	@dptr,a
      006A33 A3               [24] 3146 	inc	dptr
      006A34 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A35 90 22 00         [24] 3149 	mov	dptr,#0x2200
      006A38 74 02            [12] 3150 	mov	a,#0x02
      006A3A F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006A3B 90 22 37         [24] 3153 	mov	dptr,#0x2237
      006A3E 74 7F            [12] 3154 	mov	a,#0x7f
      006A40 F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006A41 90 22 3D         [24] 3157 	mov	dptr,#0x223d
      006A44 74 FF            [12] 3158 	mov	a,#0xff
      006A46 F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006A47 90 22 3B         [24] 3161 	mov	dptr,#0x223b
      006A4A 74 07            [12] 3162 	mov	a,#0x07
      006A4C F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006A4D A3               [24] 3165 	inc	dptr
      006A4E 74 80            [12] 3166 	mov	a,#0x80
      006A50 F0               [24] 3167 	movx	@dptr,a
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3169 ;	assignBit
      006A51 D2 E9            [12] 3170 	setb	_IE_USB
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006A53 22               [24] 3172 	ret
                                   3173 ;------------------------------------------------------------
                                   3174 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3175 ;------------------------------------------------------------
                                   3176 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_421'
                                   3177 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_424'
                                   3178 ;------------------------------------------------------------
                                   3179 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3180 ;	-----------------------------------------
                                   3181 ;	 function USB_WakeUp_PC
                                   3182 ;	-----------------------------------------
      006A54                       3183 _USB_WakeUp_PC:
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006A54 90 07 87         [24] 3185 	mov	dptr,#_USB_SleepStatus
      006A57 E0               [24] 3186 	movx	a,@dptr
      006A58 FF               [12] 3187 	mov	r7,a
      006A59 BF 03 22         [24] 3188 	cjne	r7,#0x03,00110$
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006A5C 90 22 3C         [24] 3190 	mov	dptr,#0x223c
      006A5F E0               [24] 3191 	movx	a,@dptr
      006A60 FF               [12] 3192 	mov	r7,a
                                   3193 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006A61 E0               [24] 3194 	movx	a,@dptr
      006A62 FE               [12] 3195 	mov	r6,a
      006A63 63 06 C0         [24] 3196 	xrl	ar6,#0xc0
      006A66 90 22 3C         [24] 3197 	mov	dptr,#0x223c
      006A69 EE               [12] 3198 	mov	a,r6
      006A6A F0               [24] 3199 	movx	@dptr,a
                                   3200 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006A6B 7E 0A            [12] 3201 	mov	r6,#0x0a
      006A6D                       3202 00108$:
      006A6D EE               [12] 3203 	mov	a,r6
      006A6E 60 09            [24] 3204 	jz	00105$
      006A70 90 00 01         [24] 3205 	mov	dptr,#0x0001
      006A73 12 5C 1F         [24] 3206 	lcall	_mDelaymS
      006A76 1E               [12] 3207 	dec	r6
      006A77 80 F4            [24] 3208 	sjmp	00108$
      006A79                       3209 00105$:
                                   3210 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006A79 90 22 3C         [24] 3211 	mov	dptr,#0x223c
      006A7C EF               [12] 3212 	mov	a,r7
      006A7D F0               [24] 3213 	movx	@dptr,a
      006A7E                       3214 00110$:
                                   3215 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006A7E 22               [24] 3216 	ret
                                   3217 ;------------------------------------------------------------
                                   3218 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3219 ;------------------------------------------------------------
                                   3220 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3221 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3222 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3223 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3224 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_426'
                                   3225 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_427'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_10000_427'
                                   3227 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_427'
                                   3228 ;offset        Allocated with name '_ak820_usb_send_offset_10000_427'
                                   3229 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_427'
                                   3230 ;i             Allocated with name '_ak820_usb_send_i_30000_439'
                                   3231 ;------------------------------------------------------------
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3233 ;	-----------------------------------------
                                   3234 ;	 function ak820_usb_send
                                   3235 ;	-----------------------------------------
      006A7F                       3236 _ak820_usb_send:
      006A7F E5 82            [12] 3237 	mov	a,dpl
      006A81 90 07 F4         [24] 3238 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006A84 F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006A85 90 07 F5         [24] 3241 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006A88 74 34            [12] 3242 	mov	a,#0x34
      006A8A F0               [24] 3243 	movx	@dptr,a
                                   3244 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A8B 90 07 F4         [24] 3245 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006A8E E0               [24] 3246 	movx	a,@dptr
      006A8F FF               [12] 3247 	mov	r7,a
      006A90 BF 01 00         [24] 3248 	cjne	r7,#0x01,00306$
      006A93                       3249 00306$:
      006A93 40 14            [24] 3250 	jc	00101$
      006A95 EF               [12] 3251 	mov	a,r7
      006A96 24 FC            [12] 3252 	add	a,#0xff - 0x03
      006A98 40 0F            [24] 3253 	jc	00101$
                                   3254 ;	free result
      006A9A 90 07 F3         [24] 3255 	mov	dptr,#_ak820_usb_send_PARM_3
      006A9D E0               [24] 3256 	movx	a,@dptr
      006A9E FE               [12] 3257 	mov  r6,a
      006A9F 24 BF            [12] 3258 	add	a,#0xff - 0x40
      006AA1 40 06            [24] 3259 	jc	00101$
                                   3260 ;	free result
      006AA3 90 07 86         [24] 3261 	mov	dptr,#_USB_EnumStatus
      006AA6 E0               [24] 3262 	movx	a,@dptr
      006AA7 70 04            [24] 3263 	jnz	00102$
      006AA9                       3264 00101$:
      006AA9 75 82 00         [24] 3265 	mov	dpl, #0x00
      006AAC 22               [24] 3266 	ret
      006AAD                       3267 00102$:
                                   3268 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006AAD BF 01 10         [24] 3269 	cjne	r7,#0x01,00118$
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006AB0 BE 08 02         [24] 3271 	cjne	r6,#0x08,00313$
      006AB3 80 04            [24] 3272 	sjmp	00107$
      006AB5                       3273 00313$:
      006AB5 75 82 00         [24] 3274 	mov	dpl, #0x00
      006AB8 22               [24] 3275 	ret
      006AB9                       3276 00107$:
                                   3277 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006AB9 90 07 F5         [24] 3278 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006ABC E4               [12] 3279 	clr	a
      006ABD F0               [24] 3280 	movx	@dptr,a
      006ABE 80 3C            [24] 3281 	sjmp	00119$
      006AC0                       3282 00118$:
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006AC0 BF 02 30         [24] 3284 	cjne	r7,#0x02,00115$
                                   3285 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006AC3 90 07 F1         [24] 3286 	mov	dptr,#_ak820_usb_send_PARM_2
      006AC6 E0               [24] 3287 	movx	a,@dptr
      006AC7 FD               [12] 3288 	mov	r5,a
      006AC8 A3               [24] 3289 	inc	dptr
      006AC9 E0               [24] 3290 	movx	a,@dptr
      006ACA FF               [12] 3291 	mov	r7,a
      006ACB 8D 82            [24] 3292 	mov	dpl,r5
      006ACD 8F 83            [24] 3293 	mov	dph,r7
      006ACF E0               [24] 3294 	movx	a,@dptr
      006AD0 FF               [12] 3295 	mov	r7,a
                                   3296 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006AD1 BF 07 00         [24] 3297 	cjne	r7,#0x07,00316$
      006AD4                       3298 00316$:
      006AD4 50 0E            [24] 3299 	jnc	00108$
      006AD6 EF               [12] 3300 	mov	a,r7
      006AD7 90 BC 53         [24] 3301 	mov	dptr,#_shared_lengths
      006ADA 93               [24] 3302 	movc	a,@a+dptr
      006ADB FD               [12] 3303 	mov	r5,a
      006ADC 60 06            [24] 3304 	jz	00108$
      006ADE EE               [12] 3305 	mov	a,r6
      006ADF B5 05 02         [24] 3306 	cjne	a,ar5,00319$
      006AE2 80 04            [24] 3307 	sjmp	00109$
      006AE4                       3308 00319$:
      006AE4                       3309 00108$:
      006AE4 75 82 00         [24] 3310 	mov	dpl, #0x00
      006AE7 22               [24] 3311 	ret
      006AE8                       3312 00109$:
                                   3313 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006AE8 EF               [12] 3314 	mov	a,r7
      006AE9 90 BC 4C         [24] 3315 	mov	dptr,#_shared_offsets
      006AEC 93               [24] 3316 	movc	a,@a+dptr
      006AED 90 07 F5         [24] 3317 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006AF0 F0               [24] 3318 	movx	@dptr,a
      006AF1 80 09            [24] 3319 	sjmp	00119$
      006AF3                       3320 00115$:
                                   3321 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006AF3 BE 20 02         [24] 3322 	cjne	r6,#0x20,00320$
      006AF6 80 04            [24] 3323 	sjmp	00119$
      006AF8                       3324 00320$:
      006AF8 75 82 00         [24] 3325 	mov	dpl, #0x00
      006AFB 22               [24] 3326 	ret
      006AFC                       3327 00119$:
                                   3328 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006AFC 90 07 87         [24] 3329 	mov	dptr,#_USB_SleepStatus
      006AFF E0               [24] 3330 	movx	a,@dptr
      006B00 30 E1 07         [24] 3331 	jnb	acc.1,00184$
      006B03 12 6A 54         [24] 3332 	lcall	_USB_WakeUp_PC
      006B06 75 82 00         [24] 3333 	mov	dpl, #0x00
      006B09 22               [24] 3334 	ret
                                   3335 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006B0A                       3336 00184$:
      006B0A 7F FA            [12] 3337 	mov	r7,#0xfa
      006B0C                       3338 00127$:
      006B0C 90 07 F4         [24] 3339 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006B0F E0               [24] 3340 	movx	a,@dptr
      006B10 FC               [12] 3341 	mov	r4,a
      006B11 7D 00            [12] 3342 	mov	r5,#0x00
      006B13 8C 02            [24] 3343 	mov	ar2,r4
      006B15 74 22            [12] 3344 	mov	a,#0x22
      006B17 2D               [12] 3345 	add	a, r5
      006B18 FB               [12] 3346 	mov	r3,a
      006B19 8A 82            [24] 3347 	mov	dpl,r2
      006B1B 8B 83            [24] 3348 	mov	dph,r3
      006B1D E0               [24] 3349 	movx	a,@dptr
      006B1E 54 03            [12] 3350 	anl	a,#0x03
      006B20 70 14            [24] 3351 	jnz	00129$
      006B22 8F 03            [24] 3352 	mov	ar3,r7
      006B24 1F               [12] 3353 	dec	r7
      006B25 EB               [12] 3354 	mov	a,r3
      006B26 60 0E            [24] 3355 	jz	00129$
      006B28 7B 28            [12] 3356 	mov	r3,#0x28
      006B2A                       3357 00141$:
      006B2A EB               [12] 3358 	mov	a,r3
      006B2B 60 DF            [24] 3359 	jz	00127$
      006B2D 90 00 01         [24] 3360 	mov	dptr,#0x0001
      006B30 12 5B DB         [24] 3361 	lcall	_mDelayuS
      006B33 1B               [12] 3362 	dec	r3
      006B34 80 F4            [24] 3363 	sjmp	00141$
      006B36                       3364 00129$:
                                   3365 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006B36 A2 AF            [12] 3366 	mov	c,_EA
      006B38 E4               [12] 3367 	clr	a
      006B39 33               [12] 3368 	rlc	a
      006B3A FF               [12] 3369 	mov	r7,a
                                   3370 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3371 ;	assignBit
      006B3B C2 AF            [12] 3372 	clr	_EA
                                   3373 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006B3D 90 07 86         [24] 3374 	mov	dptr,#_USB_EnumStatus
      006B40 E0               [24] 3375 	movx	a,@dptr
      006B41 60 25            [24] 3376 	jz	00130$
      006B43 90 07 F4         [24] 3377 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006B46 E0               [24] 3378 	movx	a,@dptr
      006B47 FB               [12] 3379 	mov	r3,a
      006B48 F9               [12] 3380 	mov	r1,a
      006B49 7A 00            [12] 3381 	mov	r2,#0x00
      006B4B 74 22            [12] 3382 	mov	a,#0x22
      006B4D 2A               [12] 3383 	add	a, r2
      006B4E FA               [12] 3384 	mov	r2,a
      006B4F 89 82            [24] 3385 	mov	dpl,r1
      006B51 8A 83            [24] 3386 	mov	dph,r2
      006B53 E0               [24] 3387 	movx	a,@dptr
      006B54 FA               [12] 3388 	mov	r2,a
      006B55 53 02 03         [24] 3389 	anl	ar2,#0x03
      006B58 BA 02 0D         [24] 3390 	cjne	r2,#0x02,00130$
                                   3391 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006B5B BB 03 13         [24] 3392 	cjne	r3,#0x03,00192$
      006B5E 90 07 8D         [24] 3393 	mov	dptr,#_raw_state
      006B61 E0               [24] 3394 	movx	a,@dptr
      006B62 FB               [12] 3395 	mov	r3,a
      006B63 BB 03 02         [24] 3396 	cjne	r3,#0x03,00331$
      006B66 80 09            [24] 3397 	sjmp	00192$
      006B68                       3398 00331$:
      006B68                       3399 00130$:
                                   3400 ;	assignBit
      006B68 EF               [12] 3401 	mov	a,r7
      006B69 24 FF            [12] 3402 	add	a,#0xff
      006B6B 92 AF            [24] 3403 	mov	_EA,c
      006B6D 75 82 00         [24] 3404 	mov	dpl, #0x00
      006B70 22               [24] 3405 	ret
                                   3406 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B71                       3407 00192$:
      006B71 7B 00            [12] 3408 	mov	r3,#0x00
      006B73                       3409 00144$:
      006B73 C3               [12] 3410 	clr	c
      006B74 EB               [12] 3411 	mov	a,r3
      006B75 9E               [12] 3412 	subb	a,r6
      006B76 50 67            [24] 3413 	jnc	00137$
                                   3414 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B78 C0 07            [24] 3415 	push	ar7
      006B7A 90 07 F4         [24] 3416 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006B7D E0               [24] 3417 	movx	a,@dptr
      006B7E F9               [12] 3418 	mov	r1,a
      006B7F E4               [12] 3419 	clr	a
      006B80 C3               [12] 3420 	clr	c
      006B81 C9               [12] 3421 	xch	a,r1
      006B82 13               [12] 3422 	rrc	a
      006B83 C9               [12] 3423 	xch	a,r1
      006B84 13               [12] 3424 	rrc	a
      006B85 A2 E0            [12] 3425 	mov	c,acc.0
      006B87 C9               [12] 3426 	xch	a,r1
      006B88 13               [12] 3427 	rrc	a
      006B89 C9               [12] 3428 	xch	a,r1
      006B8A 13               [12] 3429 	rrc	a
      006B8B C9               [12] 3430 	xch	a,r1
      006B8C FA               [12] 3431 	mov	r2,a
      006B8D 8B 00            [24] 3432 	mov	ar0,r3
      006B8F 7F 00            [12] 3433 	mov	r7,#0x00
      006B91 E8               [12] 3434 	mov	a,r0
      006B92 29               [12] 3435 	add	a, r1
      006B93 F9               [12] 3436 	mov	r1,a
      006B94 EF               [12] 3437 	mov	a,r7
      006B95 3A               [12] 3438 	addc	a, r2
      006B96 24 10            [12] 3439 	add	a,#0x10
      006B98 FA               [12] 3440 	mov	r2,a
      006B99 90 07 F1         [24] 3441 	mov	dptr,#_ak820_usb_send_PARM_2
      006B9C E0               [24] 3442 	movx	a,@dptr
      006B9D F8               [12] 3443 	mov	r0,a
      006B9E A3               [24] 3444 	inc	dptr
      006B9F E0               [24] 3445 	movx	a,@dptr
      006BA0 FF               [12] 3446 	mov	r7,a
      006BA1 EB               [12] 3447 	mov	a,r3
      006BA2 28               [12] 3448 	add	a, r0
      006BA3 F5 1B            [12] 3449 	mov	_ak820_usb_send_sloc0_1_0,a
      006BA5 E4               [12] 3450 	clr	a
      006BA6 3F               [12] 3451 	addc	a, r7
      006BA7 F5 1C            [12] 3452 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006BA9 85 1B 82         [24] 3453 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BAC 85 1C 83         [24] 3454 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BAF E0               [24] 3455 	movx	a,@dptr
      006BB0 89 82            [24] 3456 	mov	dpl,r1
      006BB2 8A 83            [24] 3457 	mov	dph,r2
      006BB4 F0               [24] 3458 	movx	@dptr,a
                                   3459 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006BB5 90 07 F5         [24] 3460 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006BB8 E0               [24] 3461 	movx	a,@dptr
      006BB9 F5 1D            [12] 3462 	mov	_ak820_usb_send_sloc1_1_0,a
      006BBB 74 34            [12] 3463 	mov	a,#0x34
      006BBD B5 1D 04         [24] 3464 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006BC0 D0 07            [24] 3465 	pop	ar7
      006BC2 80 18            [24] 3466 	sjmp	00145$
      006BC4                       3467 00333$:
      006BC4 D0 07            [24] 3468 	pop	ar7
      006BC6 EB               [12] 3469 	mov	a,r3
      006BC7 25 1D            [12] 3470 	add	a, _ak820_usb_send_sloc1_1_0
      006BC9 24 B0            [12] 3471 	add	a, #_input_snapshot
      006BCB F9               [12] 3472 	mov	r1,a
      006BCC E4               [12] 3473 	clr	a
      006BCD 34 07            [12] 3474 	addc	a,#(_input_snapshot >> 8)
      006BCF FA               [12] 3475 	mov	r2,a
      006BD0 85 1B 82         [24] 3476 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BD3 85 1C 83         [24] 3477 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BD6 E0               [24] 3478 	movx	a,@dptr
      006BD7 89 82            [24] 3479 	mov	dpl,r1
      006BD9 8A 83            [24] 3480 	mov	dph,r2
      006BDB F0               [24] 3481 	movx	@dptr,a
      006BDC                       3482 00145$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006BDC 0B               [12] 3484 	inc	r3
      006BDD 80 94            [24] 3485 	sjmp	00144$
      006BDF                       3486 00137$:
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006BDF 90 07 F4         [24] 3488 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006BE2 E0               [24] 3489 	movx	a,@dptr
      006BE3 FB               [12] 3490 	mov	r3,a
      006BE4 F9               [12] 3491 	mov	r1,a
      006BE5 7A 00            [12] 3492 	mov	r2,#0x00
      006BE7 74 08            [12] 3493 	mov	a,#0x08
      006BE9 29               [12] 3494 	add	a, r1
      006BEA F9               [12] 3495 	mov	r1,a
      006BEB 74 22            [12] 3496 	mov	a,#0x22
      006BED 3A               [12] 3497 	addc	a, r2
      006BEE FA               [12] 3498 	mov	r2,a
      006BEF 89 82            [24] 3499 	mov	dpl,r1
      006BF1 8A 83            [24] 3500 	mov	dph,r2
      006BF3 EE               [12] 3501 	mov	a,r6
      006BF4 F0               [24] 3502 	movx	@dptr,a
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006BF5 BB 03 06         [24] 3504 	cjne	r3,#0x03,00139$
      006BF8 90 07 8D         [24] 3505 	mov	dptr,#_raw_state
      006BFB 74 04            [12] 3506 	mov	a,#0x04
      006BFD F0               [24] 3507 	movx	@dptr,a
      006BFE                       3508 00139$:
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006BFE 74 22            [12] 3510 	mov	a,#0x22
      006C00 2D               [12] 3511 	add	a, r5
      006C01 FD               [12] 3512 	mov	r5,a
      006C02 8C 82            [24] 3513 	mov	dpl,r4
      006C04 8D 83            [24] 3514 	mov	dph,r5
      006C06 E0               [24] 3515 	movx	a,@dptr
      006C07 FE               [12] 3516 	mov	r6,a
      006C08 53 06 FC         [24] 3517 	anl	ar6,#0xfc
      006C0B 8C 82            [24] 3518 	mov	dpl,r4
      006C0D 8D 83            [24] 3519 	mov	dph,r5
      006C0F EE               [12] 3520 	mov	a,r6
      006C10 F0               [24] 3521 	movx	@dptr,a
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3523 ;	assignBit
      006C11 EF               [12] 3524 	mov	a,r7
      006C12 24 FF            [12] 3525 	add	a,#0xff
      006C14 92 AF            [24] 3526 	mov	_EA,c
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006C16 75 82 01         [24] 3528 	mov	dpl, #0x01
                                   3529 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006C19 22               [24] 3530 	ret
                                   3531 ;------------------------------------------------------------
                                   3532 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3533 ;------------------------------------------------------------
                                   3534 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3535 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3536 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_447'
                                   3537 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_448'
                                   3538 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_448'
                                   3539 ;------------------------------------------------------------
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3541 ;	-----------------------------------------
                                   3542 ;	 function ak820_usb_try_send
                                   3543 ;	-----------------------------------------
      006C1A                       3544 _ak820_usb_try_send:
      006C1A E5 82            [12] 3545 	mov	a,dpl
      006C1C 90 07 F9         [24] 3546 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006C1F F0               [24] 3547 	movx	@dptr,a
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3549 ;	assignBit
      006C20 A2 AF            [12] 3550 	mov	c,_EA
      006C22 92 1A            [24] 3551 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006C24 90 07 FA         [24] 3553 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006C27 E4               [12] 3554 	clr	a
      006C28 F0               [24] 3555 	movx	@dptr,a
                                   3556 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3557 ;	assignBit
      006C29 C2 AF            [12] 3558 	clr	_EA
                                   3559 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006C2B 90 07 F9         [24] 3560 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006C2E E0               [24] 3561 	movx	a,@dptr
      006C2F FF               [12] 3562 	mov	r7,a
      006C30 BF 01 00         [24] 3563 	cjne	r7,#0x01,00152$
      006C33                       3564 00152$:
      006C33 40 4E            [24] 3565 	jc	00102$
      006C35 EF               [12] 3566 	mov	a,r7
      006C36 24 FD            [12] 3567 	add	a,#0xff - 0x02
      006C38 40 49            [24] 3568 	jc	00102$
                                   3569 ;	free result
      006C3A 90 07 86         [24] 3570 	mov	dptr,#_USB_EnumStatus
      006C3D E0               [24] 3571 	movx	a,@dptr
      006C3E 60 43            [24] 3572 	jz	00102$
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006C40 90 07 87         [24] 3574 	mov	dptr,#_USB_SleepStatus
      006C43 E0               [24] 3575 	movx	a,@dptr
      006C44 20 E1 3C         [24] 3576 	jb	acc.1,00102$
      006C47 90 07 AF         [24] 3577 	mov	dptr,#_keyboard_reset
      006C4A E0               [24] 3578 	movx	a,@dptr
                                   3579 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006C4B 70 36            [24] 3580 	jnz	00102$
      006C4D 8F 06            [24] 3581 	mov	ar6,r7
      006C4F 24 22            [12] 3582 	add	a,#0x22
      006C51 FD               [12] 3583 	mov	r5,a
      006C52 8E 82            [24] 3584 	mov	dpl,r6
      006C54 8D 83            [24] 3585 	mov	dph,r5
      006C56 E0               [24] 3586 	movx	a,@dptr
      006C57 FE               [12] 3587 	mov	r6,a
      006C58 53 06 03         [24] 3588 	anl	ar6,#0x03
      006C5B BE 02 25         [24] 3589 	cjne	r6,#0x02,00102$
                                   3590 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006C5E 90 07 F6         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006C61 E0               [24] 3592 	movx	a,@dptr
      006C62 FD               [12] 3593 	mov	r5,a
      006C63 A3               [24] 3594 	inc	dptr
      006C64 E0               [24] 3595 	movx	a,@dptr
      006C65 FE               [12] 3596 	mov	r6,a
      006C66 90 07 F8         [24] 3597 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006C69 E0               [24] 3598 	movx	a,@dptr
      006C6A FC               [12] 3599 	mov	r4,a
      006C6B 90 07 F1         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_2
      006C6E ED               [12] 3601 	mov	a,r5
      006C6F F0               [24] 3602 	movx	@dptr,a
      006C70 EE               [12] 3603 	mov	a,r6
      006C71 A3               [24] 3604 	inc	dptr
      006C72 F0               [24] 3605 	movx	@dptr,a
      006C73 90 07 F3         [24] 3606 	mov	dptr,#_ak820_usb_send_PARM_3
      006C76 EC               [12] 3607 	mov	a,r4
      006C77 F0               [24] 3608 	movx	@dptr,a
      006C78 8F 82            [24] 3609 	mov	dpl, r7
      006C7A 12 6A 7F         [24] 3610 	lcall	_ak820_usb_send
      006C7D E5 82            [12] 3611 	mov	a, dpl
      006C7F 90 07 FA         [24] 3612 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006C82 F0               [24] 3613 	movx	@dptr,a
      006C83                       3614 00102$:
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3616 ;	assignBit
      006C83 A2 1A            [12] 3617 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C85 92 AF            [24] 3618 	mov	_EA,c
                                   3619 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006C87 90 07 FA         [24] 3620 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006C8A E0               [24] 3621 	movx	a,@dptr
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006C8B F5 82            [12] 3623 	mov	dpl,a
      006C8D 22               [24] 3624 	ret
                                   3625 ;------------------------------------------------------------
                                   3626 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3627 ;------------------------------------------------------------
                                   3628 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3629 ;	-----------------------------------------
                                   3630 ;	 function raw_request_is_nonpersistent
                                   3631 ;	-----------------------------------------
      006C8E                       3632 _raw_request_is_nonpersistent:
                                   3633 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006C8E 90 07 8E         [24] 3634 	mov	dptr,#_raw_buffer
      006C91 E0               [24] 3635 	movx	a,@dptr
      006C92 FF               [12] 3636 	mov	r7,a
      006C93 BF 01 02         [24] 3637 	cjne	r7,#0x01,00302$
      006C96 80 35            [24] 3638 	sjmp	00108$
      006C98                       3639 00302$:
      006C98 BF 02 02         [24] 3640 	cjne	r7,#0x02,00303$
      006C9B 80 34            [24] 3641 	sjmp	00109$
      006C9D                       3642 00303$:
      006C9D BF 04 02         [24] 3643 	cjne	r7,#0x04,00304$
      006CA0 80 2B            [24] 3644 	sjmp	00108$
      006CA2                       3645 00304$:
      006CA2 BF 08 02         [24] 3646 	cjne	r7,#0x08,00305$
      006CA5 80 47            [24] 3647 	sjmp	00116$
      006CA7                       3648 00305$:
      006CA7 BF 0B 02         [24] 3649 	cjne	r7,#0x0b,00306$
      006CAA 80 21            [24] 3650 	sjmp	00108$
      006CAC                       3651 00306$:
      006CAC BF 0C 02         [24] 3652 	cjne	r7,#0x0c,00307$
      006CAF 80 1C            [24] 3653 	sjmp	00108$
      006CB1                       3654 00307$:
      006CB1 BF 0D 02         [24] 3655 	cjne	r7,#0x0d,00308$
      006CB4 80 17            [24] 3656 	sjmp	00108$
      006CB6                       3657 00308$:
      006CB6 BF 0E 02         [24] 3658 	cjne	r7,#0x0e,00309$
      006CB9 80 12            [24] 3659 	sjmp	00108$
      006CBB                       3660 00309$:
      006CBB BF 11 02         [24] 3661 	cjne	r7,#0x11,00310$
      006CBE 80 0D            [24] 3662 	sjmp	00108$
      006CC0                       3663 00310$:
      006CC0 BF 12 02         [24] 3664 	cjne	r7,#0x12,00311$
      006CC3 80 08            [24] 3665 	sjmp	00108$
      006CC5                       3666 00311$:
      006CC5 BF FE 02         [24] 3667 	cjne	r7,#0xfe,00312$
      006CC8 80 46            [24] 3668 	sjmp	00124$
      006CCA                       3669 00312$:
      006CCA 02 6D 65         [24] 3670 	ljmp	00144$
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006CCD                       3672 00108$:
                                   3673 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006CCD 75 82 01         [24] 3674 	mov	dpl, #0x01
      006CD0 22               [24] 3675 	ret
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006CD1                       3677 00109$:
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006CD1 12 70 79         [24] 3679 	lcall	_ak820_outline_0161
      006CD4 BF 01 02         [24] 3680 	cjne	r7,#0x01,00313$
      006CD7 80 0D            [24] 3681 	sjmp	00113$
      006CD9                       3682 00313$:
      006CD9 BF 02 02         [24] 3683 	cjne	r7,#0x02,00314$
      006CDC 80 08            [24] 3684 	sjmp	00113$
      006CDE                       3685 00314$:
      006CDE BF 03 02         [24] 3686 	cjne	r7,#0x03,00315$
      006CE1 80 03            [24] 3687 	sjmp	00113$
      006CE3                       3688 00315$:
      006CE3 BF 04 04         [24] 3689 	cjne	r7,#0x04,00114$
                                   3690 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006CE6                       3691 00113$:
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006CE6 75 82 01         [24] 3693 	mov	dpl, #0x01
      006CE9 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006CEA                       3696 00114$:
      006CEA 75 82 00         [24] 3697 	mov	dpl, #0x00
      006CED 22               [24] 3698 	ret
                                   3699 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006CEE                       3700 00116$:
                                   3701 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006CEE 12 70 79         [24] 3702 	lcall	_ak820_outline_0161
      006CF1 BF 40 02         [24] 3703 	cjne	r7,#0x40,00318$
      006CF4 80 12            [24] 3704 	sjmp	00121$
      006CF6                       3705 00318$:
      006CF6 BF 41 02         [24] 3706 	cjne	r7,#0x41,00319$
      006CF9 80 0D            [24] 3707 	sjmp	00121$
      006CFB                       3708 00319$:
      006CFB BF 42 02         [24] 3709 	cjne	r7,#0x42,00320$
      006CFE 80 08            [24] 3710 	sjmp	00121$
      006D00                       3711 00320$:
      006D00 BF 43 02         [24] 3712 	cjne	r7,#0x43,00321$
      006D03 80 03            [24] 3713 	sjmp	00121$
      006D05                       3714 00321$:
      006D05 BF 44 04         [24] 3715 	cjne	r7,#0x44,00122$
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006D08                       3717 00121$:
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006D08 75 82 01         [24] 3719 	mov	dpl, #0x01
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006D0B 22               [24] 3721 	ret
      006D0C                       3722 00122$:
      006D0C 75 82 00         [24] 3723 	mov	dpl, #0x00
                                   3724 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006D0F 22               [24] 3725 	ret
      006D10                       3726 00124$:
                                   3727 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006D10 12 70 79         [24] 3728 	lcall	_ak820_outline_0161
      006D13 24 F2            [12] 3729 	add	a,#0xff - 0x0d
      006D15 40 4A            [24] 3730 	jc	00142$
                                   3731 ;	free result
      006D17 EF               [12] 3732 	mov	a,r7
      006D18 24 0A            [12] 3733 	add	a,#(00325$-3-.)
      006D1A 83               [24] 3734 	movc	a,@a+pc
      006D1B F5 82            [12] 3735 	mov	dpl,a
      006D1D EF               [12] 3736 	mov	a,r7
      006D1E 24 12            [12] 3737 	add	a,#(00326$-3-.)
      006D20 83               [24] 3738 	movc	a,@a+pc
      006D21 F5 83            [12] 3739 	mov	dph,a
      006D23 E4               [12] 3740 	clr	a
      006D24 73               [24] 3741 	jmp	@a+dptr
      006D25                       3742 00325$:
      006D25 41                    3743 	.db	00134$
      006D26 41                    3744 	.db	00134$
      006D27 41                    3745 	.db	00134$
      006D28 41                    3746 	.db	00134$
      006D29 61                    3747 	.db	00142$
      006D2A 41                    3748 	.db	00134$
      006D2B 41                    3749 	.db	00134$
      006D2C 41                    3750 	.db	00134$
      006D2D 41                    3751 	.db	00134$
      006D2E 41                    3752 	.db	00134$
      006D2F 41                    3753 	.db	00134$
      006D30 61                    3754 	.db	00142$
      006D31 61                    3755 	.db	00142$
      006D32 45                    3756 	.db	00135$
      006D33                       3757 00326$:
      006D33 6D                    3758 	.db	00134$>>8
      006D34 6D                    3759 	.db	00134$>>8
      006D35 6D                    3760 	.db	00134$>>8
      006D36 6D                    3761 	.db	00134$>>8
      006D37 6D                    3762 	.db	00142$>>8
      006D38 6D                    3763 	.db	00134$>>8
      006D39 6D                    3764 	.db	00134$>>8
      006D3A 6D                    3765 	.db	00134$>>8
      006D3B 6D                    3766 	.db	00134$>>8
      006D3C 6D                    3767 	.db	00134$>>8
      006D3D 6D                    3768 	.db	00134$>>8
      006D3E 6D                    3769 	.db	00142$>>8
      006D3F 6D                    3770 	.db	00142$>>8
      006D40 6D                    3771 	.db	00135$>>8
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006D41                       3773 00134$:
                                   3774 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006D41 75 82 01         [24] 3775 	mov	dpl, #0x01
                                   3776 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006D44 22               [24] 3777 	ret
      006D45                       3778 00135$:
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006D45 90 07 90         [24] 3780 	mov	dptr,#(_raw_buffer + 0x0002)
      006D48 E0               [24] 3781 	movx	a,@dptr
      006D49 FF               [12] 3782 	mov	r7,a
      006D4A 60 0D            [24] 3783 	jz	00139$
      006D4C BF 01 02         [24] 3784 	cjne	r7,#0x01,00328$
      006D4F 80 08            [24] 3785 	sjmp	00139$
      006D51                       3786 00328$:
      006D51 BF 03 02         [24] 3787 	cjne	r7,#0x03,00329$
      006D54 80 03            [24] 3788 	sjmp	00139$
      006D56                       3789 00329$:
      006D56 BF 05 04         [24] 3790 	cjne	r7,#0x05,00140$
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006D59                       3792 00139$:
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006D59 75 82 01         [24] 3794 	mov	dpl, #0x01
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006D5C 22               [24] 3796 	ret
      006D5D                       3797 00140$:
      006D5D 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006D60 22               [24] 3800 	ret
      006D61                       3801 00142$:
      006D61 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006D64 22               [24] 3804 	ret
      006D65                       3805 00144$:
      006D65 75 82 00         [24] 3806 	mov	dpl, #0x00
                                   3807 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006D68 22               [24] 3809 	ret
                                   3810 ;------------------------------------------------------------
                                   3811 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3812 ;------------------------------------------------------------
                                   3813 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3814 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_463'
                                   3815 ;------------------------------------------------------------
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3817 ;	-----------------------------------------
                                   3818 ;	 function ak820_usb_raw_send
                                   3819 ;	-----------------------------------------
      006D69                       3820 _ak820_usb_raw_send:
      006D69 12 43 40         [24] 3821 	lcall	_ak820_outline_0037
      006D6C 90 07 FC         [24] 3822 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006D6F 12 37 E0         [24] 3823 	lcall	_ak820_outline_0016
                                   3824 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006D72 90 07 FB         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D75 E0               [24] 3826 	movx	a,@dptr
      006D76 FF               [12] 3827 	mov	r7,a
      006D77 BF 20 2B         [24] 3828 	cjne	r7,#0x20,00106$
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006D7A C0 07            [24] 3830 	push	ar7
      006D7C 12 3E 57         [24] 3831 	lcall	_ak820_nvm_flush
      006D7F D0 07            [24] 3832 	pop	ar7
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D81 90 07 AE         [24] 3834 	mov	dptr,#_raw_reply_without_nvm
      006D84 E0               [24] 3835 	movx	a,@dptr
      006D85 70 07            [24] 3836 	jnz	00103$
      006D87 12 3E 48         [24] 3837 	lcall	_ak820_nvm_ok
      006D8A E5 82            [12] 3838 	mov	a, dpl
      006D8C 60 17            [24] 3839 	jz	00106$
      006D8E                       3840 00103$:
      006D8E 90 07 FC         [24] 3841 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006D91 12 43 77         [24] 3842 	lcall	_ak820_outline_0093
      006D94 90 07 F1         [24] 3843 	mov	dptr,#_ak820_usb_send_PARM_2
      006D97 12 43 BA         [24] 3844 	lcall	_ak820_outline_0159
      006D9A 90 07 F3         [24] 3845 	mov	dptr,#_ak820_usb_send_PARM_3
      006D9D EF               [12] 3846 	mov	a,r7
      006D9E F0               [24] 3847 	movx	@dptr,a
      006D9F 75 82 03         [24] 3848 	mov	dpl, #0x03
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006DA2 02 6A 7F         [24] 3850 	ljmp	_ak820_usb_send
      006DA5                       3851 00106$:
      006DA5 22               [24] 3852 	ret
                                   3853 ;------------------------------------------------------------
                                   3854 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3855 ;------------------------------------------------------------
                                   3856 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3857 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_468'
                                   3858 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_468'
                                   3859 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_468'
                                   3860 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_468'
                                   3861 ;------------------------------------------------------------
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3863 ;	-----------------------------------------
                                   3864 ;	 function ak820_usb_raw_task
                                   3865 ;	-----------------------------------------
      006DA6                       3866 _ak820_usb_raw_task:
                                   3867 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006DA6 A2 AF            [12] 3868 	mov	c,_EA
      006DA8 E4               [12] 3869 	clr	a
      006DA9 33               [12] 3870 	rlc	a
      006DAA FF               [12] 3871 	mov	r7,a
                                   3872 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3873 ;	assignBit
      006DAB C2 AF            [12] 3874 	clr	_EA
                                   3875 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006DAD 90 07 86         [24] 3876 	mov	dptr,#_USB_EnumStatus
      006DB0 E0               [24] 3877 	movx	a,@dptr
      006DB1 60 0A            [24] 3878 	jz	00101$
      006DB3 90 07 8D         [24] 3879 	mov	dptr,#_raw_state
      006DB6 E0               [24] 3880 	movx	a,@dptr
      006DB7 FE               [12] 3881 	mov	r6,a
      006DB8 BE 02 02         [24] 3882 	cjne	r6,#0x02,00427$
      006DBB 80 06            [24] 3883 	sjmp	00102$
      006DBD                       3884 00427$:
      006DBD                       3885 00101$:
                                   3886 ;	assignBit
      006DBD EF               [12] 3887 	mov	a,r7
      006DBE 24 FF            [12] 3888 	add	a,#0xff
      006DC0 92 AF            [24] 3889 	mov	_EA,c
      006DC2 22               [24] 3890 	ret
      006DC3                       3891 00102$:
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006DC3 90 07 8D         [24] 3893 	mov	dptr,#_raw_state
      006DC6 74 03            [12] 3894 	mov	a,#0x03
      006DC8 F0               [24] 3895 	movx	@dptr,a
                                   3896 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3897 ;	assignBit
      006DC9 EF               [12] 3898 	mov	a,r7
      006DCA 24 FF            [12] 3899 	add	a,#0xff
      006DCC 92 AF            [24] 3900 	mov	_EA,c
                                   3901 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006DCE 90 07 8E         [24] 3902 	mov	dptr,#_raw_buffer
      006DD1 E0               [24] 3903 	movx	a,@dptr
      006DD2 FF               [12] 3904 	mov	r7,a
      006DD3 E4               [12] 3905 	clr	a
      006DD4 BF FD 01         [24] 3906 	cjne	r7,#0xfd,00428$
      006DD7 04               [12] 3907 	inc	a
      006DD8                       3908 00428$:
      006DD8 FF               [12] 3909 	mov	r7,a
      006DD9 70 03            [24] 3910 	jnz	00430$
      006DDB 02 6E 7B         [24] 3911 	ljmp	00141$
      006DDE                       3912 00430$:
      006DDE 90 07 8F         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0001)
      006DE1 E0               [24] 3914 	movx	a,@dptr
      006DE2 60 03            [24] 3915 	jz	00431$
      006DE4 02 6E 7B         [24] 3916 	ljmp	00141$
      006DE7                       3917 00431$:
                                   3918 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006DE7 90 07 90         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0002)
      006DEA E0               [24] 3920 	movx	a,@dptr
      006DEB FD               [12] 3921 	mov	r5,a
      006DEC 7E 00            [12] 3922 	mov	r6,#0x00
      006DEE 90 07 91         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0003)
      006DF1 E0               [24] 3924 	movx	a,@dptr
      006DF2 7B 00            [12] 3925 	mov	r3,#0x00
      006DF4 42 06            [12] 3926 	orl	ar6,a
      006DF6 EB               [12] 3927 	mov	a,r3
      006DF7 42 05            [12] 3928 	orl	ar5,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006DF9 90 07 92         [24] 3930 	mov	dptr,#(_raw_buffer + 0x0004)
      006DFC E0               [24] 3931 	movx	a,@dptr
      006DFD FC               [12] 3932 	mov	r4,a
                                   3933 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006DFE 7B 05            [12] 3934 	mov	r3,#0x05
      006E00                       3935 00151$:
      006E00 EB               [12] 3936 	mov	a,r3
      006E01 12 70 61         [24] 3937 	lcall	_ak820_outline_0040
      006E04 0B               [12] 3938 	inc	r3
      006E05 BB 20 00         [24] 3939 	cjne	r3,#0x20,00432$
      006E08                       3940 00432$:
      006E08 40 F6            [24] 3941 	jc	00151$
                                   3942 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006E0A EC               [12] 3943 	mov	a,r4
      006E0B 24 E4            [12] 3944 	add	a,#0xff - 0x1b
      006E0D 40 1C            [24] 3945 	jc	00106$
                                   3946 ;	free result
      006E0F EC               [12] 3947 	mov	a,r4
      006E10 60 26            [24] 3948 	jz	00212$
      006E12 8C 03            [24] 3949 	mov	ar3,r4
      006E14 1B               [12] 3950 	dec	r3
      006E15 7A 00            [12] 3951 	mov	r2,#0x00
      006E17 74 FF            [12] 3952 	mov	a,#0xff
      006E19 C3               [12] 3953 	clr	c
      006E1A 9B               [12] 3954 	subb	a,r3
      006E1B FB               [12] 3955 	mov	r3,a
      006E1C 74 FF            [12] 3956 	mov	a,#0xff
      006E1E 9A               [12] 3957 	subb	a,r2
      006E1F FA               [12] 3958 	mov	r2,a
      006E20 8E 00            [24] 3959 	mov	ar0,r6
      006E22 8D 01            [24] 3960 	mov	ar1,r5
      006E24 C3               [12] 3961 	clr	c
      006E25 EB               [12] 3962 	mov	a,r3
      006E26 98               [12] 3963 	subb	a,r0
      006E27 EA               [12] 3964 	mov	a,r2
      006E28 99               [12] 3965 	subb	a,r1
      006E29 50 0D            [24] 3966 	jnc	00212$
                                   3967 ;	free result
      006E2B                       3968 00106$:
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006E2B 90 07 8F         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0001)
      006E2E 74 FF            [12] 3971 	mov	a,#0xff
      006E30 F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006E31 90 07 92         [24] 3974 	mov	dptr,#(_raw_buffer + 0x0004)
      006E34 E4               [12] 3975 	clr	a
      006E35 F0               [24] 3976 	movx	@dptr,a
                                   3977 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006E36 80 3A            [24] 3978 	sjmp	00108$
      006E38                       3979 00212$:
      006E38 7B 00            [12] 3980 	mov	r3,#0x00
      006E3A                       3981 00154$:
      006E3A C3               [12] 3982 	clr	c
      006E3B EB               [12] 3983 	mov	a,r3
      006E3C 9C               [12] 3984 	subb	a,r4
      006E3D 50 33            [24] 3985 	jnc	00108$
      006E3F C0 04            [24] 3986 	push	ar4
      006E41 8B 02            [24] 3987 	mov	ar2,r3
      006E43 74 05            [12] 3988 	mov	a,#0x05
      006E45 2A               [12] 3989 	add	a, r2
      006E46 F9               [12] 3990 	mov	r1,a
      006E47 33               [12] 3991 	rlc	a
      006E48 95 E0            [12] 3992 	subb	a,acc
      006E4A FA               [12] 3993 	mov	r2,a
      006E4B E9               [12] 3994 	mov	a,r1
      006E4C 24 8E            [12] 3995 	add	a, #_raw_buffer
      006E4E F9               [12] 3996 	mov	r1,a
      006E4F EA               [12] 3997 	mov	a,r2
      006E50 34 07            [12] 3998 	addc	a, #(_raw_buffer >> 8)
      006E52 FA               [12] 3999 	mov	r2,a
      006E53 8B 1E            [24] 4000 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006E55 75 1F 00         [24] 4001 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006E58 8E 00            [24] 4002 	mov	ar0,r6
      006E5A 8D 04            [24] 4003 	mov	ar4,r5
      006E5C E5 1E            [12] 4004 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006E5E 28               [12] 4005 	add	a, r0
      006E5F F8               [12] 4006 	mov	r0,a
      006E60 E5 1F            [12] 4007 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006E62 3C               [12] 4008 	addc	a, r4
      006E63 FC               [12] 4009 	mov	r4,a
      006E64 88 82            [24] 4010 	mov	dpl,r0
      006E66 8C 83            [24] 4011 	mov	dph,r4
      006E68 E4               [12] 4012 	clr	a
      006E69 93               [24] 4013 	movc	a,@a+dptr
      006E6A 12 70 73         [24] 4014 	lcall	_ak820_outline_0136
      006E6D 0B               [12] 4015 	inc	r3
      006E6E D0 04            [24] 4016 	pop	ar4
      006E70 80 C8            [24] 4017 	sjmp	00154$
      006E72                       4018 00108$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E72 12 70 4D         [24] 4020 	lcall	_ak820_outline_0008
      006E75 12 6A 7F         [24] 4021 	lcall	_ak820_usb_send
      006E78 02 6F FD         [24] 4022 	ljmp	00142$
      006E7B                       4023 00141$:
                                   4024 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E7B EF               [12] 4025 	mov	a,r7
      006E7C 70 03            [24] 4026 	jnz	00438$
      006E7E 02 6F 00         [24] 4027 	ljmp	00137$
      006E81                       4028 00438$:
      006E81 90 07 8F         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0001)
      006E84 E0               [24] 4030 	movx	a,@dptr
      006E85 FE               [12] 4031 	mov	r6,a
      006E86 BE 01 02         [24] 4032 	cjne	r6,#0x01,00439$
      006E89 80 03            [24] 4033 	sjmp	00440$
      006E8B                       4034 00439$:
      006E8B 02 6F 00         [24] 4035 	ljmp	00137$
      006E8E                       4036 00440$:
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E8E 7E 02            [12] 4038 	mov	r6,#0x02
      006E90                       4039 00156$:
      006E90 EE               [12] 4040 	mov	a,r6
      006E91 12 70 61         [24] 4041 	lcall	_ak820_outline_0040
      006E94 0E               [12] 4042 	inc	r6
      006E95 BE 20 00         [24] 4043 	cjne	r6,#0x20,00441$
      006E98                       4044 00441$:
      006E98 40 F6            [24] 4045 	jc	00156$
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006E9A 90 07 90         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0002)
      006E9D 74 01            [12] 4048 	mov	a,#0x01
      006E9F F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006EA0 90 07 91         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0003)
      006EA3 74 A8            [12] 4052 	mov	a,#0xa8
      006EA5 F0               [24] 4053 	movx	@dptr,a
                                   4054 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006EA6 90 07 92         [24] 4055 	mov	dptr,#(_raw_buffer + 0x0004)
      006EA9 12 3B C6         [24] 4056 	lcall	_ak820_nvm_diagnostic
                                   4057 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006EAC 7E 00            [12] 4058 	mov	r6,#0x00
      006EAE                       4059 00158$:
      006EAE 8E 05            [24] 4060 	mov	ar5,r6
      006EB0 74 0B            [12] 4061 	mov	a,#0x0b
      006EB2 2D               [12] 4062 	add	a, r5
      006EB3 24 8E            [12] 4063 	add	a,#_raw_buffer
      006EB5 FD               [12] 4064 	mov	r5,a
      006EB6 E4               [12] 4065 	clr	a
      006EB7 34 07            [12] 4066 	addc	a, #(_raw_buffer >> 8)
      006EB9 FC               [12] 4067 	mov	r4,a
      006EBA EE               [12] 4068 	mov	a,r6
      006EBB 24 60            [12] 4069 	add	a, #_ak820_flash_diagnostic
      006EBD F5 82            [12] 4070 	mov	dpl,a
      006EBF E4               [12] 4071 	clr	a
      006EC0 34 04            [12] 4072 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006EC2 F5 83            [12] 4073 	mov	dph,a
      006EC4 E0               [24] 4074 	movx	a,@dptr
      006EC5 12 43 CA         [24] 4075 	lcall	_ak820_outline_0185
      006EC8 F0               [24] 4076 	movx	@dptr,a
      006EC9 0E               [12] 4077 	inc	r6
      006ECA BE 06 00         [24] 4078 	cjne	r6,#0x06,00443$
      006ECD                       4079 00443$:
      006ECD 40 DF            [24] 4080 	jc	00158$
                                   4081 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006ECF 90 0E 17         [24] 4082 	mov	dptr,#_vial_unlocked
      006ED2 E0               [24] 4083 	movx	a,@dptr
      006ED3 90 07 9F         [24] 4084 	mov	dptr,#(_raw_buffer + 0x0011)
      006ED6 F0               [24] 4085 	movx	@dptr,a
                                   4086 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006ED7 90 0E 18         [24] 4087 	mov	dptr,#_vial_unlock_in_progress
      006EDA E0               [24] 4088 	movx	a,@dptr
      006EDB 90 07 A0         [24] 4089 	mov	dptr,#(_raw_buffer + 0x0012)
      006EDE F0               [24] 4090 	movx	@dptr,a
                                   4091 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006EDF 90 07 86         [24] 4092 	mov	dptr,#_USB_EnumStatus
      006EE2 E0               [24] 4093 	movx	a,@dptr
      006EE3 90 07 A1         [24] 4094 	mov	dptr,#(_raw_buffer + 0x0013)
      006EE6 F0               [24] 4095 	movx	@dptr,a
                                   4096 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006EE7 90 07 87         [24] 4097 	mov	dptr,#_USB_SleepStatus
      006EEA E0               [24] 4098 	movx	a,@dptr
      006EEB 90 07 A2         [24] 4099 	mov	dptr,#(_raw_buffer + 0x0014)
      006EEE F0               [24] 4100 	movx	@dptr,a
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006EEF 90 07 8D         [24] 4102 	mov	dptr,#_raw_state
      006EF2 E0               [24] 4103 	movx	a,@dptr
      006EF3 90 07 A3         [24] 4104 	mov	dptr,#(_raw_buffer + 0x0015)
      006EF6 F0               [24] 4105 	movx	@dptr,a
                                   4106 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006EF7 12 70 4D         [24] 4107 	lcall	_ak820_outline_0008
      006EFA 12 6A 7F         [24] 4108 	lcall	_ak820_usb_send
      006EFD 02 6F FD         [24] 4109 	ljmp	00142$
      006F00                       4110 00137$:
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      006F00 EF               [12] 4112 	mov	a,r7
      006F01 70 03            [24] 4113 	jnz	00445$
      006F03 02 6F DA         [24] 4114 	ljmp	00133$
      006F06                       4115 00445$:
      006F06 12 70 79         [24] 4116 	lcall	_ak820_outline_0161
      006F09 BF 02 02         [24] 4117 	cjne	r7,#0x02,00446$
      006F0C 80 03            [24] 4118 	sjmp	00447$
      006F0E                       4119 00446$:
      006F0E 02 6F DA         [24] 4120 	ljmp	00133$
      006F11                       4121 00447$:
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      006F11 90 07 FF         [24] 4123 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F14 74 01            [12] 4124 	mov	a,#0x01
      006F16 F0               [24] 4125 	movx	@dptr,a
                                   4126 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      006F17 90 07 90         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0002)
      006F1A E0               [24] 4128 	movx	a,@dptr
      006F1B FF               [12] 4129 	mov	r7,a
      006F1C BF 01 72         [24] 4130 	cjne	r7,#0x01,00235$
      006F1F 90 07 91         [24] 4131 	mov	dptr,#(_raw_buffer + 0x0003)
      006F22 E0               [24] 4132 	movx	a,@dptr
      006F23 FF               [12] 4133 	mov  r7,a
      006F24 24 FE            [12] 4134 	add	a,#0xff - 0x01
      006F26 40 69            [24] 4135 	jc	00235$
                                   4136 ;	free result
      006F28 90 07 92         [24] 4137 	mov	dptr,#(_raw_buffer + 0x0004)
      006F2B E0               [24] 4138 	movx	a,@dptr
      006F2C FE               [12] 4139 	mov  r6,a
      006F2D 24 FC            [12] 4140 	add	a,#0xff - 0x03
      006F2F 40 60            [24] 4141 	jc	00235$
                                   4142 ;	free result
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      006F31 EF               [12] 4144 	mov	a,r7
      006F32 70 03            [24] 4145 	jnz	00227$
      006F34 EE               [12] 4146 	mov	a,r6
      006F35 70 5A            [24] 4147 	jnz	00235$
                                   4148 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      006F37                       4149 00227$:
      006F37 7D 05            [12] 4150 	mov	r5,#0x05
      006F39                       4151 00162$:
      006F39 BD 20 00         [24] 4152 	cjne	r5,#0x20,00454$
      006F3C                       4153 00454$:
      006F3C 50 10            [24] 4154 	jnc	00113$
      006F3E ED               [12] 4155 	mov	a,r5
      006F3F 24 8E            [12] 4156 	add	a, #_raw_buffer
      006F41 FB               [12] 4157 	mov	r3,a
      006F42 E4               [12] 4158 	clr	a
      006F43 34 07            [12] 4159 	addc	a, #(_raw_buffer >> 8)
      006F45 FC               [12] 4160 	mov	r4,a
      006F46 12 70 6D         [24] 4161 	lcall	_ak820_outline_0118
      006F49 70 03            [24] 4162 	jnz	00113$
      006F4B 0D               [12] 4163 	inc	r5
      006F4C 80 EB            [24] 4164 	sjmp	00162$
      006F4E                       4165 00113$:
                                   4166 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      006F4E BD 20 40         [24] 4167 	cjne	r5,#0x20,00235$
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4169 ;	assignBit
      006F51 A2 AF            [12] 4170 	mov	c,_EA
      006F53 92 1B            [24] 4171 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4172 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4173 ;	assignBit
      006F55 C2 AF            [12] 4174 	clr	_EA
                                   4175 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      006F57 90 07 8D         [24] 4176 	mov	dptr,#_raw_state
      006F5A E0               [24] 4177 	movx	a,@dptr
      006F5B FD               [12] 4178 	mov	r5,a
      006F5C BD 03 28         [24] 4179 	cjne	r5,#0x03,00117$
      006F5F 90 07 86         [24] 4180 	mov	dptr,#_USB_EnumStatus
      006F62 E0               [24] 4181 	movx	a,@dptr
      006F63 60 22            [24] 4182 	jz	00117$
      006F65 90 07 85         [24] 4183 	mov	dptr,#_D0UsbConfig
      006F68 E0               [24] 4184 	movx	a,@dptr
      006F69 60 1C            [24] 4185 	jz	00117$
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      006F6B 90 07 87         [24] 4187 	mov	dptr,#_USB_SleepStatus
      006F6E E0               [24] 4188 	movx	a,@dptr
      006F6F 20 E1 15         [24] 4189 	jb	acc.1,00117$
      006F72 90 0E 18         [24] 4190 	mov	dptr,#_vial_unlock_in_progress
      006F75 E0               [24] 4191 	movx	a,@dptr
      006F76 70 0F            [24] 4192 	jnz	00117$
                                   4193 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      006F78 EF               [12] 4194 	mov	a,r7
      006F79 60 05            [24] 4195 	jz	00115$
      006F7B 8E 82            [24] 4196 	mov	dpl, r6
      006F7D 12 43 CF         [24] 4197 	lcall	_ak820_os_indicator_set
      006F80                       4198 00115$:
                                   4199 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      006F80 90 07 FF         [24] 4200 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F83 E4               [12] 4201 	clr	a
      006F84 F0               [24] 4202 	movx	@dptr,a
      006F85 80 06            [24] 4203 	sjmp	00118$
      006F87                       4204 00117$:
                                   4205 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      006F87 90 07 FF         [24] 4206 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F8A 74 02            [12] 4207 	mov	a,#0x02
      006F8C F0               [24] 4208 	movx	@dptr,a
      006F8D                       4209 00118$:
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4211 ;	assignBit
      006F8D A2 1B            [12] 4212 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006F8F 92 AF            [24] 4213 	mov	_EA,c
                                   4214 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F91                       4215 00235$:
      006F91 7F 02            [12] 4216 	mov	r7,#0x02
      006F93                       4217 00164$:
      006F93 EF               [12] 4218 	mov	a,r7
      006F94 12 70 61         [24] 4219 	lcall	_ak820_outline_0040
      006F97 0F               [12] 4220 	inc	r7
      006F98 BF 20 00         [24] 4221 	cjne	r7,#0x20,00466$
      006F9B                       4222 00466$:
      006F9B 40 F6            [24] 4223 	jc	00164$
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      006F9D 90 07 90         [24] 4225 	mov	dptr,#(_raw_buffer + 0x0002)
      006FA0 74 01            [12] 4226 	mov	a,#0x01
      006FA2 F0               [24] 4227 	movx	@dptr,a
                                   4228 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      006FA3 90 07 FF         [24] 4229 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006FA6 E0               [24] 4230 	movx	a,@dptr
      006FA7 90 07 91         [24] 4231 	mov	dptr,#(_raw_buffer + 0x0003)
      006FAA F0               [24] 4232 	movx	@dptr,a
                                   4233 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      006FAB 12 43 F6         [24] 4234 	lcall	_ak820_os_indicator_get
      006FAE AF 82            [24] 4235 	mov	r7, dpl
      006FB0 90 07 92         [24] 4236 	mov	dptr,#(_raw_buffer + 0x0004)
      006FB3 EF               [12] 4237 	mov	a,r7
      006FB4 F0               [24] 4238 	movx	@dptr,a
                                   4239 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      006FB5 90 07 93         [24] 4240 	mov	dptr,#(_raw_buffer + 0x0005)
      006FB8 74 A8            [12] 4241 	mov	a,#0xa8
      006FBA F0               [24] 4242 	movx	@dptr,a
                                   4243 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      006FBB 90 07 94         [24] 4244 	mov	dptr,#(_raw_buffer + 0x0006)
      006FBE 74 B8            [12] 4245 	mov	a,#0xb8
      006FC0 F0               [24] 4246 	movx	@dptr,a
                                   4247 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      006FC1 90 07 95         [24] 4248 	mov	dptr,#(_raw_buffer + 0x0007)
      006FC4 74 0B            [12] 4249 	mov	a,#0x0b
      006FC6 F0               [24] 4250 	movx	@dptr,a
                                   4251 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      006FC7 90 07 96         [24] 4252 	mov	dptr,#(_raw_buffer + 0x0008)
      006FCA E4               [12] 4253 	clr	a
      006FCB F0               [24] 4254 	movx	@dptr,a
                                   4255 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      006FCC 90 07 97         [24] 4256 	mov	dptr,#(_raw_buffer + 0x0009)
      006FCF 74 10            [12] 4257 	mov	a,#0x10
      006FD1 F0               [24] 4258 	movx	@dptr,a
                                   4259 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FD2 12 70 4D         [24] 4260 	lcall	_ak820_outline_0008
      006FD5 12 6A 7F         [24] 4261 	lcall	_ak820_usb_send
      006FD8 80 23            [24] 4262 	sjmp	00142$
      006FDA                       4263 00133$:
                                   4264 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006FDA 12 6C 8E         [24] 4265 	lcall	_raw_request_is_nonpersistent
      006FDD E5 82            [12] 4266 	mov	a, dpl
      006FDF 90 07 AE         [24] 4267 	mov	dptr,#_raw_reply_without_nvm
      006FE2 F0               [24] 4268 	movx	@dptr,a
                                   4269 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006FE3 12 3F A9         [24] 4270 	lcall	_ak820_nvm_begin
                                   4271 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006FE6 90 0C 49         [24] 4272 	mov	dptr,#_raw_hid_receive_PARM_2
      006FE9 74 20            [12] 4273 	mov	a,#0x20
      006FEB F0               [24] 4274 	movx	@dptr,a
      006FEC 90 07 8E         [24] 4275 	mov	dptr,#_raw_buffer
      006FEF 75 F0 00         [24] 4276 	mov	b, #0x00
      006FF2 12 A9 73         [24] 4277 	lcall	_raw_hid_receive
                                   4278 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006FF5 12 3F BE         [24] 4279 	lcall	_ak820_nvm_end
                                   4280 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006FF8 90 07 AE         [24] 4281 	mov	dptr,#_raw_reply_without_nvm
      006FFB E4               [12] 4282 	clr	a
      006FFC F0               [24] 4283 	movx	@dptr,a
      006FFD                       4284 00142$:
                                   4285 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4286 ;	assignBit
      006FFD A2 AF            [12] 4287 	mov	c,_EA
      006FFF 92 1B            [24] 4288 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4289 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4290 ;	assignBit
      007001 C2 AF            [12] 4291 	clr	_EA
                                   4292 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      007003 12 70 7F         [24] 4293 	lcall	_ak820_outline_0163
      007006 BF 04 08         [24] 4294 	cjne	r7,#0x04,00149$
      007009 90 07 8D         [24] 4295 	mov	dptr,#_raw_state
      00700C 74 05            [12] 4296 	mov	a,#0x05
      00700E F0               [24] 4297 	movx	@dptr,a
      00700F 80 1B            [24] 4298 	sjmp	00150$
      007011                       4299 00149$:
                                   4300 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      007011 12 70 7F         [24] 4301 	lcall	_ak820_outline_0163
      007014 BF 03 02         [24] 4302 	cjne	r7,#0x03,00470$
      007017 80 0E            [24] 4303 	sjmp	00144$
      007019                       4304 00470$:
      007019 12 70 7F         [24] 4305 	lcall	_ak820_outline_0163
      00701C BF 06 02         [24] 4306 	cjne	r7,#0x06,00471$
      00701F 80 06            [24] 4307 	sjmp	00144$
      007021                       4308 00471$:
      007021 12 70 7F         [24] 4309 	lcall	_ak820_outline_0163
      007024 BF 07 05         [24] 4310 	cjne	r7,#0x07,00150$
      007027                       4311 00144$:
      007027 90 07 8D         [24] 4312 	mov	dptr,#_raw_state
      00702A E4               [12] 4313 	clr	a
      00702B F0               [24] 4314 	movx	@dptr,a
      00702C                       4315 00150$:
                                   4316 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4317 ;	assignBit
      00702C A2 1B            [12] 4318 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      00702E 92 AF            [24] 4319 	mov	_EA,c
                                   4320 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007030 22               [24] 4321 	ret
                                   4322 ;------------------------------------------------------------
                                   4323 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4324 ;------------------------------------------------------------
                                   4325 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_498'
                                   4326 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_498'
                                   4327 ;------------------------------------------------------------
                                   4328 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4329 ;	-----------------------------------------
                                   4330 ;	 function ak820_usb_take_keyboard_reset
                                   4331 ;	-----------------------------------------
      007031                       4332 _ak820_usb_take_keyboard_reset:
                                   4333 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4334 ;	assignBit
      007031 A2 AF            [12] 4335 	mov	c,_EA
      007033 92 1C            [24] 4336 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4337 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4338 ;	assignBit
      007035 C2 AF            [12] 4339 	clr	_EA
                                   4340 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007037 90 07 AF         [24] 4341 	mov	dptr,#_keyboard_reset
      00703A E0               [24] 4342 	movx	a,@dptr
      00703B FF               [12] 4343 	mov	r7,a
                                   4344 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      00703C E4               [12] 4345 	clr	a
      00703D F0               [24] 4346 	movx	@dptr,a
                                   4347 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4348 ;	assignBit
      00703E A2 1C            [12] 4349 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      007040 92 AF            [24] 4350 	mov	_EA,c
                                   4351 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      007042 EF               [12] 4352 	mov	a,r7
      007043 B4 01 00         [24] 4353 	cjne	a,#0x01,00103$
      007046                       4354 00103$:
      007046 B3               [12] 4355 	cpl	c
      007047 92 1C            [24] 4356 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007049 12 38 81         [24] 4357 	lcall	_ak820_outline_0167
                                   4358 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      00704C 22               [24] 4359 	ret
                                   4360 	.area CSEG    (CODE)
                                   4361 	.area CONST   (CODE)
                                   4362 	.area CONST   (CODE)
      00BC4C                       4363 _shared_offsets:
      00BC4C 00                    4364 	.db #0x00	; 0
      00BC4D 00                    4365 	.db #0x00	; 0
      00BC4E 28                    4366 	.db #0x28	; 40
      00BC4F 2E                    4367 	.db #0x2e	; 46
      00BC50 31                    4368 	.db #0x31	; 49	'1'
      00BC51 00                    4369 	.db #0x00	; 0
      00BC52 08                    4370 	.db #0x08	; 8
                                   4371 	.area CSEG    (CODE)
                                   4372 	.area CONST   (CODE)
      00BC53                       4373 _shared_lengths:
      00BC53 00                    4374 	.db #0x00	; 0
      00BC54 00                    4375 	.db #0x00	; 0
      00BC55 06                    4376 	.db #0x06	; 6
      00BC56 03                    4377 	.db #0x03	; 3
      00BC57 03                    4378 	.db #0x03	; 3
      00BC58 00                    4379 	.db #0x00	; 0
      00BC59 20                    4380 	.db #0x20	; 32
                                   4381 	.area CSEG    (CODE)
                                   4382 	.area CONST   (CODE)
      00BC5A                       4383 _interface_descriptors:
      00BC5A FD C1                 4384 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BC5C 46 C3                 4385 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BC5E F9 C2                 4386 	.byte _RawReport, (_RawReport >> 8)
      00BC60 5F C3                 4387 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BC62 42 C2                 4388 	.byte _SharedReport, (_SharedReport >> 8)
      00BC64 78 C3                 4389 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4390 	.area CSEG    (CODE)
                                   4391 	.area XINIT   (CODE)
                                   4392 	.area CABS    (ABS,CODE)
                                   4393 
                                   4394 ; Experimental exact instruction outlining.
                                   4395 	.globl _ak820_outline_0008
                                   4396 	.globl _ak820_outline_0016
                                   4397 	.globl _ak820_outline_0037
                                   4398 	.globl _ak820_outline_0040
                                   4399 	.globl _ak820_outline_0093
                                   4400 	.globl _ak820_outline_0118
                                   4401 	.globl _ak820_outline_0136
                                   4402 	.globl _ak820_outline_0159
                                   4403 	.globl _ak820_outline_0161
                                   4404 	.globl _ak820_outline_0163
                                   4405 	.globl _ak820_outline_0167
                                   4406 	.globl _ak820_outline_0185
                                   4407 
                                   4408 	.area CSEG (CODE)
                                   4409 ; function ak820_outline_0008
      00704D                       4410 _ak820_outline_0008:
      00704D 90 07 F1         [24] 4411 	mov	dptr,#_ak820_usb_send_PARM_2
      007050 74 8E            [12] 4412 	mov	a,#_raw_buffer
      007052 F0               [24] 4413 	movx	@dptr,a
      007053 74 07            [12] 4414 	mov	a,#(_raw_buffer>>8)
      007055 A3               [24] 4415 	inc	dptr
      007056 F0               [24] 4416 	movx	@dptr,a
      007057 90 07 F3         [24] 4417 	mov	dptr,#_ak820_usb_send_PARM_3
      00705A 74 20            [12] 4418 	mov	a,#0x20
      00705C F0               [24] 4419 	movx	@dptr,a
      00705D 75 82 03         [24] 4420 	mov	dpl,#0x03
      007060 22               [24] 4421 	ret
                                   4422 
                                   4423 	.area CSEG (CODE)
                                   4424 ; function ak820_outline_0040
      007061                       4425 _ak820_outline_0040:
      007061 24 8E            [12] 4426 	add	a,#_raw_buffer
      007063 F5 82            [12] 4427 	mov	dpl,a
      007065 E4               [12] 4428 	clr	a
      007066 34 07            [12] 4429 	addc	a,#(_raw_buffer>>8)
      007068 F5 83            [12] 4430 	mov	dph,a
      00706A E4               [12] 4431 	clr	a
      00706B F0               [24] 4432 	movx	@dptr,a
      00706C 22               [24] 4433 	ret
                                   4434 
                                   4435 	.area CSEG (CODE)
                                   4436 ; function ak820_outline_0118
      00706D                       4437 _ak820_outline_0118:
      00706D 8B 82            [24] 4438 	mov	dpl,r3
      00706F 8C 83            [24] 4439 	mov	dph,r4
      007071 E0               [24] 4440 	movx	a,@dptr
      007072 22               [24] 4441 	ret
                                   4442 
                                   4443 	.area CSEG (CODE)
                                   4444 ; function ak820_outline_0136
      007073                       4445 _ak820_outline_0136:
      007073 89 82            [24] 4446 	mov	dpl,r1
      007075 8A 83            [24] 4447 	mov	dph,r2
      007077 F0               [24] 4448 	movx	@dptr,a
      007078 22               [24] 4449 	ret
                                   4450 
                                   4451 	.area CSEG (CODE)
                                   4452 ; function ak820_outline_0161
      007079                       4453 _ak820_outline_0161:
      007079 90 07 8F         [24] 4454 	mov	dptr,#(_raw_buffer+0x0001)
      00707C E0               [24] 4455 	movx	a,@dptr
      00707D FF               [12] 4456 	mov	r7,a
      00707E 22               [24] 4457 	ret
                                   4458 
                                   4459 	.area CSEG (CODE)
                                   4460 ; function ak820_outline_0163
      00707F                       4461 _ak820_outline_0163:
      00707F 90 07 8D         [24] 4462 	mov	dptr,#_raw_state
      007082 E0               [24] 4463 	movx	a,@dptr
      007083 FF               [12] 4464 	mov	r7,a
      007084 22               [24] 4465 	ret
