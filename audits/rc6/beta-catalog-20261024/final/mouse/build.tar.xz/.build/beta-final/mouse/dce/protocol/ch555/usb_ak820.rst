                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000014                        578 _control_setup_valid_interface_10000_290:
      000014                        579 	.ds 1
      000015                        580 _control_setup_zero_index_10000_290:
      000015                        581 	.ds 1
      000016                        582 _control_setup_zero_value_10000_290:
      000016                        583 	.ds 1
      000017                        584 _control_setup_zero_length_10000_290:
      000017                        585 	.ds 1
      000018                        586 _control_setup_sloc0_1_0:
      000018                        587 	.ds 1
      000019                        588 _control_setup_sloc2_1_0:
      000019                        589 	.ds 1
      00001A                        590 _ak820_usb_try_send_sloc0_1_0:
      00001A                        591 	.ds 1
      00001B                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001B                        593 	.ds 1
      00001C                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001C                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      00077F                        604 _D0SetupReqCode::
      00077F                        605 	.ds 1
      000780                        606 _D0SetupLen::
      000780                        607 	.ds 2
      000782                        608 _pD0Descr::
      000782                        609 	.ds 3
      000785                        610 _D0UsbConfig::
      000785                        611 	.ds 1
      000786                        612 _USB_EnumStatus::
      000786                        613 	.ds 1
      000787                        614 _USB_SleepStatus::
      000787                        615 	.ds 1
      000788                        616 _MCU_Sleep_Operate::
      000788                        617 	.ds 1
      000789                        618 _KB_USB_UpStatus::
      000789                        619 	.ds 1
      00078A                        620 _KB_USB_SetReport::
      00078A                        621 	.ds 1
      00078B                        622 _ak820_boot_stage::
      00078B                        623 	.ds 1
      00078C                        624 _ak820_main_heartbeat::
      00078C                        625 	.ds 1
      00078D                        626 _raw_state:
      00078D                        627 	.ds 1
      00078E                        628 _raw_buffer:
      00078E                        629 	.ds 32
      0007AE                        630 _raw_reply_without_nvm:
      0007AE                        631 	.ds 1
      0007AF                        632 _keyboard_reset:
      0007AF                        633 	.ds 1
      0007B0                        634 _input_snapshot:
      0007B0                        635 	.ds 52
      0007E4                        636 _control_phase:
      0007E4                        637 	.ds 1
      0007E5                        638 _output_kind:
      0007E5                        639 	.ds 1
      0007E6                        640 _output_report_id:
      0007E6                        641 	.ds 1
      0007E7                        642 _control_zlp:
      0007E7                        643 	.ds 1
      0007E8                        644 _control_pointer:
      0007E8                        645 	.ds 2
      0007EA                        646 _descriptor_select_PARM_2:
      0007EA                        647 	.ds 1
      0007EB                        648 _descriptor_select_PARM_3:
      0007EB                        649 	.ds 2
      0007ED                        650 _descriptor_select_type_10000_272:
      0007ED                        651 	.ds 1
      0007EE                        652 _control_setup_length_10000_290:
      0007EE                        653 	.ds 2
      0007F0                        654 _control_setup_offset_10000_290:
      0007F0                        655 	.ds 1
      0007F1                        656 _ak820_usb_send_PARM_2:
      0007F1                        657 	.ds 2
      0007F3                        658 _ak820_usb_send_PARM_3:
      0007F3                        659 	.ds 1
      0007F4                        660 _ak820_usb_send_endpoint_10000_426:
      0007F4                        661 	.ds 1
      0007F5                        662 _ak820_usb_send_offset_10000_427:
      0007F5                        663 	.ds 1
      0007F6                        664 _ak820_usb_try_send_PARM_2:
      0007F6                        665 	.ds 2
      0007F8                        666 _ak820_usb_try_send_PARM_3:
      0007F8                        667 	.ds 1
      0007F9                        668 _ak820_usb_try_send_endpoint_10000_447:
      0007F9                        669 	.ds 1
      0007FA                        670 _ak820_usb_try_send_sent_10000_448:
      0007FA                        671 	.ds 1
      0007FB                        672 _ak820_usb_raw_send_PARM_2:
      0007FB                        673 	.ds 1
      0007FC                        674 _ak820_usb_raw_send_report_10000_463:
      0007FC                        675 	.ds 3
      0007FF                        676 _ak820_usb_raw_task_length_10000_468:
      0007FF                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005D53                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D53 90 07 8D         [24]  731 	mov	dptr,#_raw_state
      005D56 E0               [24]  732 	movx	a,@dptr
      005D57 FF               [12]  733 	mov	r7,a
      005D58 BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005D5B 80 1C            [24]  735 	sjmp	00101$
      005D5D                        736 00130$:
      005D5D 90 07 8D         [24]  737 	mov	dptr,#_raw_state
      005D60 E0               [24]  738 	movx	a,@dptr
      005D61 FF               [12]  739 	mov	r7,a
      005D62 BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005D65 80 12            [24]  741 	sjmp	00101$
      005D67                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005D67 90 07 8D         [24]  744 	mov	dptr,#_raw_state
      005D6A E0               [24]  745 	movx	a,@dptr
      005D6B FF               [12]  746 	mov	r7,a
      005D6C BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005D6F 80 08            [24]  748 	sjmp	00101$
      005D71                        749 00132$:
      005D71 90 07 8D         [24]  750 	mov	dptr,#_raw_state
      005D74 E0               [24]  751 	movx	a,@dptr
      005D75 FF               [12]  752 	mov	r7,a
      005D76 BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      005D79                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005D79 90 07 8D         [24]  756 	mov	dptr,#_raw_state
      005D7C 74 07            [12]  757 	mov	a,#0x07
      005D7E F0               [24]  758 	movx	@dptr,a
      005D7F 80 05            [24]  759 	sjmp	00103$
      005D81                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005D81 90 07 8D         [24]  762 	mov	dptr,#_raw_state
      005D84 E4               [12]  763 	clr	a
      005D85 F0               [24]  764 	movx	@dptr,a
      005D86                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005D86 90 07 E5         [24]  767 	mov	dptr,#_output_kind
      005D89 E4               [12]  768 	clr	a
      005D8A F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005D8B 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      005D8C                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005D8C 90 07 8D         [24]  781 	mov	dptr,#_raw_state
      005D8F E0               [24]  782 	movx	a,@dptr
      005D90 FF               [12]  783 	mov	r7,a
      005D91 BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      005D94 90 07 8D         [24]  785 	mov	dptr,#_raw_state
      005D97 74 06            [12]  786 	mov	a,#0x06
      005D99 F0               [24]  787 	movx	@dptr,a
      005D9A 22               [24]  788 	ret
      005D9B                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005D9B 90 07 8D         [24]  791 	mov	dptr,#_raw_state
      005D9E E0               [24]  792 	movx	a,@dptr
      005D9F FF               [12]  793 	mov	r7,a
      005DA0 BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      005DA3 90 07 8D         [24]  795 	mov	dptr,#_raw_state
      005DA6 E4               [12]  796 	clr	a
      005DA7 F0               [24]  797 	movx	@dptr,a
      005DA8                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005DA8 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_262'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      005DA9                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      005DA9 90 05 9A         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      005DAC E4               [12]  813 	clr	a
      005DAD F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005DAE 90 22 0C         [24]  816 	mov	dptr,#0x220c
      005DB1 04               [12]  817 	inc	a
      005DB2 F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DB3 F5 82            [12]  820 	mov	dpl,a
      005DB5 74 12            [12]  821 	mov	a,#0x12
      005DB7 F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DB8 A3               [24]  824 	inc	dptr
      005DB9 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DBA A3               [24]  827 	inc	dptr
      005DBB F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005DBC 90 22 0B         [24]  830 	mov	dptr,#0x220b
      005DBF E4               [12]  831 	clr	a
      005DC0 F0               [24]  832 	movx	@dptr,a
      005DC1 15 82            [12]  833 	dec	dpl
      005DC3 F0               [24]  834 	movx	@dptr,a
      005DC4 15 82            [12]  835 	dec	dpl
      005DC6 F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005DC7 FF               [12]  838 	mov	r7,a
      005DC8                        839 00103$:
      005DC8 EF               [12]  840 	mov	a,r7
      005DC9 24 B0            [12]  841 	add	a, #_input_snapshot
      005DCB F5 82            [12]  842 	mov	dpl,a
      005DCD E4               [12]  843 	clr	a
      005DCE 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      005DD0 F5 83            [12]  845 	mov	dph,a
      005DD2 E4               [12]  846 	clr	a
      005DD3 F0               [24]  847 	movx	@dptr,a
      005DD4 0F               [12]  848 	inc	r7
      005DD5 BF 34 00         [24]  849 	cjne	r7,#0x34,00139$
      005DD8                        850 00139$:
      005DD8 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005DDA 90 07 B8         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      005DDD 74 06            [12]  854 	mov	a,#0x06
      005DDF F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:124: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005DE0 90 07 D8         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      005DE3 74 02            [12]  858 	mov	a,#0x02
      005DE5 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005DE6 90 07 DE         [24]  861 	mov	dptr,#(_input_snapshot + 0x002e)
      005DE9 04               [12]  862 	inc	a
      005DEA F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005DEB 90 07 E1         [24]  865 	mov	dptr,#(_input_snapshot + 0x0031)
      005DEE 04               [12]  866 	inc	a
      005DEF F0               [24]  867 	movx	@dptr,a
                                    868 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005DF0 7F 00            [12]  869 	mov	r7,#0x00
      005DF2                        870 00105$:
      005DF2 8F 06            [24]  871 	mov	ar6,r7
      005DF4 74 C0            [12]  872 	mov	a,#0xc0
      005DF6 2E               [12]  873 	add	a, r6
      005DF7 F5 82            [12]  874 	mov	dpl,a
      005DF9 74 10            [12]  875 	mov	a,#0x10
      005DFB 24 00            [12]  876 	add	a, #0x00
      005DFD F5 83            [12]  877 	mov	dph,a
      005DFF E4               [12]  878 	clr	a
      005E00 F0               [24]  879 	movx	@dptr,a
      005E01 0F               [12]  880 	inc	r7
      005E02 BF 20 00         [24]  881 	cjne	r7,#0x20,00141$
      005E05                        882 00141$:
      005E05 40 EB            [24]  883 	jc	00105$
                                    884 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    885 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005E07 02 5D 53         [24]  886 	ljmp	_raw_abort
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'control_stall'
                                    889 ;------------------------------------------------------------
                                    890 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function control_stall
                                    893 ;	-----------------------------------------
      005E0A                        894 _control_stall:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005E0A 90 07 8D         [24]  896 	mov	dptr,#_raw_state
      005E0D E0               [24]  897 	movx	a,@dptr
      005E0E FF               [12]  898 	mov	r7,a
      005E0F BF 01 05         [24]  899 	cjne	r7,#0x01,00102$
      005E12 90 07 8D         [24]  900 	mov	dptr,#_raw_state
      005E15 E4               [12]  901 	clr	a
      005E16 F0               [24]  902 	movx	@dptr,a
      005E17                        903 00102$:
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005E17 90 07 E5         [24]  905 	mov	dptr,#_output_kind
      005E1A E4               [12]  906 	clr	a
      005E1B F0               [24]  907 	movx	@dptr,a
                                    908 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005E1C 90 07 E4         [24]  909 	mov	dptr,#_control_phase
      005E1F F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005E20 90 07 7F         [24]  912 	mov	dptr,#_D0SetupReqCode
      005E23 14               [12]  913 	dec	a
      005E24 F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005E25 90 22 00         [24]  916 	mov	dptr,#0x2200
      005E28 74 CF            [12]  917 	mov	a,#0xcf
      005E2A F0               [24]  918 	movx	@dptr,a
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005E2B 22               [24]  920 	ret
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'control_next'
                                    923 ;------------------------------------------------------------
                                    924 ;i             Allocated with name '_control_next_i_10000_269'
                                    925 ;length        Allocated with name '_control_next_length_10000_269'
                                    926 ;------------------------------------------------------------
                                    927 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    928 ;	-----------------------------------------
                                    929 ;	 function control_next
                                    930 ;	-----------------------------------------
      005E2C                        931 _control_next:
                                    932 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005E2C 90 07 80         [24]  933 	mov	dptr,#_D0SetupLen
      005E2F E0               [24]  934 	movx	a,@dptr
      005E30 FE               [12]  935 	mov	r6,a
      005E31 A3               [24]  936 	inc	dptr
      005E32 E0               [24]  937 	movx	a,@dptr
      005E33 FF               [12]  938 	mov	r7,a
      005E34 C3               [12]  939 	clr	c
      005E35 74 40            [12]  940 	mov	a,#0x40
      005E37 9E               [12]  941 	subb	a,r6
      005E38 E4               [12]  942 	clr	a
      005E39 9F               [12]  943 	subb	a,r7
      005E3A 50 04            [24]  944 	jnc	00109$
                                    945 ;	free result
      005E3C 7E 40            [12]  946 	mov	r6,#0x40
      005E3E 80 07            [24]  947 	sjmp	00110$
      005E40                        948 00109$:
      005E40 90 07 80         [24]  949 	mov	dptr,#_D0SetupLen
      005E43 E0               [24]  950 	movx	a,@dptr
      005E44 FE               [12]  951 	mov	r6,a
      005E45 A3               [24]  952 	inc	dptr
      005E46 E0               [24]  953 	movx	a,@dptr
      005E47                        954 00110$:
                                    955 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E47 7F 00            [12]  956 	mov	r7,#0x00
      005E49                        957 00105$:
      005E49 C3               [12]  958 	clr	c
      005E4A EF               [12]  959 	mov	a,r7
      005E4B 9E               [12]  960 	subb	a,r6
      005E4C 50 2A            [24]  961 	jnc	00101$
      005E4E 8F 04            [24]  962 	mov	ar4,r7
      005E50 74 10            [12]  963 	mov	a,#0x10
      005E52 24 00            [12]  964 	add	a, #0x00
      005E54 FD               [12]  965 	mov	r5,a
      005E55 90 07 E8         [24]  966 	mov	dptr,#_control_pointer
      005E58 E0               [24]  967 	movx	a,@dptr
      005E59 FA               [12]  968 	mov	r2,a
      005E5A A3               [24]  969 	inc	dptr
      005E5B E0               [24]  970 	movx	a,@dptr
      005E5C FB               [12]  971 	mov	r3,a
      005E5D 8A 82            [24]  972 	mov	dpl,r2
      005E5F 8B 83            [24]  973 	mov	dph,r3
      005E61 E4               [12]  974 	clr	a
      005E62 93               [24]  975 	movc	a,@a+dptr
      005E63 F9               [12]  976 	mov	r1,a
      005E64 90 07 E8         [24]  977 	mov	dptr,#_control_pointer
      005E67 74 01            [12]  978 	mov	a,#0x01
      005E69 2A               [12]  979 	add	a, r2
      005E6A F0               [24]  980 	movx	@dptr,a
      005E6B E4               [12]  981 	clr	a
      005E6C 3B               [12]  982 	addc	a, r3
      005E6D A3               [24]  983 	inc	dptr
      005E6E F0               [24]  984 	movx	@dptr,a
      005E6F 8C 82            [24]  985 	mov	dpl,r4
      005E71 8D 83            [24]  986 	mov	dph,r5
      005E73 E9               [12]  987 	mov	a,r1
      005E74 F0               [24]  988 	movx	@dptr,a
      005E75 0F               [12]  989 	inc	r7
      005E76 80 D1            [24]  990 	sjmp	00105$
      005E78                        991 00101$:
                                    992 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005E78 8E 05            [24]  993 	mov	ar5,r6
      005E7A 7F 00            [12]  994 	mov	r7,#0x00
      005E7C 90 07 80         [24]  995 	mov	dptr,#_D0SetupLen
      005E7F E0               [24]  996 	movx	a,@dptr
      005E80 FB               [12]  997 	mov	r3,a
      005E81 A3               [24]  998 	inc	dptr
      005E82 E0               [24]  999 	movx	a,@dptr
      005E83 FC               [12] 1000 	mov	r4,a
      005E84 EB               [12] 1001 	mov	a,r3
      005E85 C3               [12] 1002 	clr	c
      005E86 9D               [12] 1003 	subb	a,r5
      005E87 FB               [12] 1004 	mov	r3,a
      005E88 EC               [12] 1005 	mov	a,r4
      005E89 9F               [12] 1006 	subb	a,r7
      005E8A FC               [12] 1007 	mov	r4,a
      005E8B 90 07 80         [24] 1008 	mov	dptr,#_D0SetupLen
      005E8E EB               [12] 1009 	mov	a,r3
      005E8F F0               [24] 1010 	movx	@dptr,a
      005E90 EC               [12] 1011 	mov	a,r4
      005E91 A3               [24] 1012 	inc	dptr
      005E92 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005E93 EE               [12] 1015 	mov	a,r6
      005E94 70 05            [24] 1016 	jnz	00103$
      005E96 90 07 E7         [24] 1017 	mov	dptr,#_control_zlp
      005E99 E4               [12] 1018 	clr	a
      005E9A F0               [24] 1019 	movx	@dptr,a
      005E9B                       1020 00103$:
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005E9B 90 22 08         [24] 1022 	mov	dptr,#0x2208
      005E9E EE               [12] 1023 	mov	a,r6
      005E9F F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005EA0 90 22 00         [24] 1026 	mov	dptr,#0x2200
      005EA3 E0               [24] 1027 	movx	a,@dptr
      005EA4 54 C0            [12] 1028 	anl	a,#0xc0
      005EA6 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005EA7 22               [24] 1031 	ret
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'descriptor_select'
                                   1034 ;------------------------------------------------------------
                                   1035 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1036 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1037 ;type          Allocated with name '_descriptor_select_type_10000_272'
                                   1038 ;hid           Allocated with name '_descriptor_select_hid_30000_285'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function descriptor_select
                                   1043 ;	-----------------------------------------
      005EA8                       1044 _descriptor_select:
      005EA8 E5 82            [12] 1045 	mov	a,dpl
      005EAA 90 07 ED         [24] 1046 	mov	dptr,#_descriptor_select_type_10000_272
      005EAD F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005EAE E0               [24] 1049 	movx	a,@dptr
      005EAF FF               [12] 1050 	mov	r7,a
      005EB0 BF 01 20         [24] 1051 	cjne	r7,#0x01,00102$
      005EB3 90 07 EA         [24] 1052 	mov	dptr,#_descriptor_select_PARM_2
      005EB6 E0               [24] 1053 	movx	a,@dptr
      005EB7 70 1A            [24] 1054 	jnz	00102$
      005EB9 90 07 EB         [24] 1055 	mov	dptr,#_descriptor_select_PARM_3
      005EBC E0               [24] 1056 	movx	a,@dptr
      005EBD F5 F0            [12] 1057 	mov	b,a
      005EBF A3               [24] 1058 	inc	dptr
      005EC0 E0               [24] 1059 	movx	a,@dptr
      005EC1 45 F0            [12] 1060 	orl	a,b
      005EC3 70 0E            [24] 1061 	jnz	00102$
                                   1062 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005EC5 90 07 E8         [24] 1063 	mov	dptr,#_control_pointer
      005EC8 74 40            [12] 1064 	mov	a,#_DeviceDescriptor
      005ECA F0               [24] 1065 	movx	@dptr,a
      005ECB 74 C2            [12] 1066 	mov	a,#(_DeviceDescriptor >> 8)
      005ECD A3               [24] 1067 	inc	dptr
      005ECE F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005ECF 90 00 12         [24] 1070 	mov	dptr,#0x0012
      005ED2 22               [24] 1071 	ret
      005ED3                       1072 00102$:
                                   1073 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005ED3 90 07 ED         [24] 1074 	mov	dptr,#_descriptor_select_type_10000_272
      005ED6 E0               [24] 1075 	movx	a,@dptr
      005ED7 FF               [12] 1076 	mov	r7,a
      005ED8 BF 02 20         [24] 1077 	cjne	r7,#0x02,00106$
      005EDB 90 07 EA         [24] 1078 	mov	dptr,#_descriptor_select_PARM_2
      005EDE E0               [24] 1079 	movx	a,@dptr
      005EDF 70 1A            [24] 1080 	jnz	00106$
      005EE1 90 07 EB         [24] 1081 	mov	dptr,#_descriptor_select_PARM_3
      005EE4 E0               [24] 1082 	movx	a,@dptr
      005EE5 F5 F0            [12] 1083 	mov	b,a
      005EE7 A3               [24] 1084 	inc	dptr
      005EE8 E0               [24] 1085 	movx	a,@dptr
      005EE9 45 F0            [12] 1086 	orl	a,b
      005EEB 70 0E            [24] 1087 	jnz	00106$
                                   1088 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005EED 90 07 E8         [24] 1089 	mov	dptr,#_control_pointer
      005EF0 74 52            [12] 1090 	mov	a,#_ConfigurationDescriptor
      005EF2 F0               [24] 1091 	movx	@dptr,a
      005EF3 74 C2            [12] 1092 	mov	a,#(_ConfigurationDescriptor >> 8)
      005EF5 A3               [24] 1093 	inc	dptr
      005EF6 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005EF7 90 00 54         [24] 1096 	mov	dptr,#0x0054
      005EFA 22               [24] 1097 	ret
      005EFB                       1098 00106$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005EFB 90 07 ED         [24] 1100 	mov	dptr,#_descriptor_select_type_10000_272
      005EFE E0               [24] 1101 	movx	a,@dptr
      005EFF FF               [12] 1102 	mov	r7,a
      005F00 BF 03 02         [24] 1103 	cjne	r7,#0x03,00238$
      005F03 80 03            [24] 1104 	sjmp	00239$
      005F05                       1105 00238$:
      005F05 02 5F 9F         [24] 1106 	ljmp	00119$
      005F08                       1107 00239$:
                                   1108 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005F08 90 07 EB         [24] 1109 	mov	dptr,#_descriptor_select_PARM_3
      005F0B E0               [24] 1110 	movx	a,@dptr
      005F0C FD               [12] 1111 	mov	r5,a
      005F0D A3               [24] 1112 	inc	dptr
      005F0E E0               [24] 1113 	movx	a,@dptr
      005F0F FE               [12] 1114 	mov	r6,a
      005F10 90 07 EB         [24] 1115 	mov	dptr,#_descriptor_select_PARM_3
      005F13 E0               [24] 1116 	movx	a,@dptr
      005F14 F5 F0            [12] 1117 	mov	b,a
      005F16 A3               [24] 1118 	inc	dptr
      005F17 E0               [24] 1119 	movx	a,@dptr
      005F18 45 F0            [12] 1120 	orl	a,b
      005F1A 60 0C            [24] 1121 	jz	00110$
      005F1C BD 09 05         [24] 1122 	cjne	r5,#0x09,00241$
      005F1F BE 04 02         [24] 1123 	cjne	r6,#0x04,00241$
      005F22 80 04            [24] 1124 	sjmp	00110$
      005F24                       1125 00241$:
      005F24 90 00 00         [24] 1126 	mov	dptr,#0x0000
      005F27 22               [24] 1127 	ret
      005F28                       1128 00110$:
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005F28 90 07 EA         [24] 1130 	mov	dptr,#_descriptor_select_PARM_2
      005F2B E0               [24] 1131 	movx	a,@dptr
      005F2C FE               [12] 1132 	mov  r6,a
      005F2D 24 FC            [12] 1133 	add	a,#0xff - 0x03
      005F2F 40 6A            [24] 1134 	jc	00116$
                                   1135 ;	free result
      005F31 EE               [12] 1136 	mov	a,r6
      005F32 2E               [12] 1137 	add	a,r6
                                   1138 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005F33 90 5F 37         [24] 1139 	mov	dptr,#00243$
      005F36 73               [24] 1140 	jmp	@a+dptr
      005F37                       1141 00243$:
      005F37 80 06            [24] 1142 	sjmp	00112$
      005F39 80 1B            [24] 1143 	sjmp	00113$
      005F3B 80 30            [24] 1144 	sjmp	00114$
      005F3D 80 45            [24] 1145 	sjmp	00115$
      005F3F                       1146 00112$:
      005F3F 90 07 E8         [24] 1147 	mov	dptr,#_control_pointer
      005F42 74 A6            [12] 1148 	mov	a,#_LanguageString
      005F44 F0               [24] 1149 	movx	@dptr,a
      005F45 74 C2            [12] 1150 	mov	a,#(_LanguageString >> 8)
      005F47 A3               [24] 1151 	inc	dptr
      005F48 F0               [24] 1152 	movx	@dptr,a
      005F49 90 C2 A6         [24] 1153 	mov	dptr,#_LanguageString
      005F4C E4               [12] 1154 	clr	a
      005F4D 93               [24] 1155 	movc	a,@a+dptr
      005F4E FE               [12] 1156 	mov	r6,a
      005F4F 7D 00            [12] 1157 	mov	r5,#0x00
      005F51 8E 82            [24] 1158 	mov	dpl, r6
      005F53 8D 83            [24] 1159 	mov	dph, r5
      005F55 22               [24] 1160 	ret
                                   1161 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F56                       1162 00113$:
      005F56 90 07 E8         [24] 1163 	mov	dptr,#_control_pointer
      005F59 74 AA            [12] 1164 	mov	a,#_ManufacturerString
      005F5B F0               [24] 1165 	movx	@dptr,a
      005F5C 74 C2            [12] 1166 	mov	a,#(_ManufacturerString >> 8)
      005F5E A3               [24] 1167 	inc	dptr
      005F5F F0               [24] 1168 	movx	@dptr,a
      005F60 90 C2 AA         [24] 1169 	mov	dptr,#_ManufacturerString
      005F63 E4               [12] 1170 	clr	a
      005F64 93               [24] 1171 	movc	a,@a+dptr
      005F65 FE               [12] 1172 	mov	r6,a
      005F66 7D 00            [12] 1173 	mov	r5,#0x00
      005F68 8E 82            [24] 1174 	mov	dpl, r6
      005F6A 8D 83            [24] 1175 	mov	dph, r5
      005F6C 22               [24] 1176 	ret
                                   1177 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005F6D                       1178 00114$:
      005F6D 90 07 E8         [24] 1179 	mov	dptr,#_control_pointer
      005F70 74 B8            [12] 1180 	mov	a,#_ProductString
      005F72 F0               [24] 1181 	movx	@dptr,a
      005F73 74 C2            [12] 1182 	mov	a,#(_ProductString >> 8)
      005F75 A3               [24] 1183 	inc	dptr
      005F76 F0               [24] 1184 	movx	@dptr,a
      005F77 90 C2 B8         [24] 1185 	mov	dptr,#_ProductString
      005F7A E4               [12] 1186 	clr	a
      005F7B 93               [24] 1187 	movc	a,@a+dptr
      005F7C FE               [12] 1188 	mov	r6,a
      005F7D 7D 00            [12] 1189 	mov	r5,#0x00
      005F7F 8E 82            [24] 1190 	mov	dpl, r6
      005F81 8D 83            [24] 1191 	mov	dph, r5
      005F83 22               [24] 1192 	ret
                                   1193 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005F84                       1194 00115$:
      005F84 90 07 E8         [24] 1195 	mov	dptr,#_control_pointer
      005F87 74 F0            [12] 1196 	mov	a,#_SerialNumberString
      005F89 F0               [24] 1197 	movx	@dptr,a
      005F8A 74 C2            [12] 1198 	mov	a,#(_SerialNumberString >> 8)
      005F8C A3               [24] 1199 	inc	dptr
      005F8D F0               [24] 1200 	movx	@dptr,a
      005F8E 90 C2 F0         [24] 1201 	mov	dptr,#_SerialNumberString
      005F91 E4               [12] 1202 	clr	a
      005F92 93               [24] 1203 	movc	a,@a+dptr
      005F93 FE               [12] 1204 	mov	r6,a
      005F94 7D 00            [12] 1205 	mov	r5,#0x00
      005F96 8E 82            [24] 1206 	mov	dpl, r6
      005F98 8D 83            [24] 1207 	mov	dph, r5
      005F9A 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005F9B                       1210 00116$:
      005F9B 90 00 00         [24] 1211 	mov	dptr,#0x0000
      005F9E 22               [24] 1212 	ret
                                   1213 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005F9F                       1214 00119$:
                                   1215 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005F9F 90 07 EA         [24] 1216 	mov	dptr,#_descriptor_select_PARM_2
      005FA2 E0               [24] 1217 	movx	a,@dptr
      005FA3 70 11            [24] 1218 	jnz	00120$
      005FA5 90 07 EB         [24] 1219 	mov	dptr,#_descriptor_select_PARM_3
      005FA8 E0               [24] 1220 	movx	a,@dptr
      005FA9 FD               [12] 1221 	mov	r5,a
      005FAA A3               [24] 1222 	inc	dptr
      005FAB E0               [24] 1223 	movx	a,@dptr
      005FAC FE               [12] 1224 	mov	r6,a
      005FAD C3               [12] 1225 	clr	c
      005FAE ED               [12] 1226 	mov	a,r5
      005FAF 94 03            [12] 1227 	subb	a,#0x03
      005FB1 EE               [12] 1228 	mov	a,r6
      005FB2 94 00            [12] 1229 	subb	a,#0x00
      005FB4 40 04            [24] 1230 	jc	00121$
      005FB6                       1231 00120$:
      005FB6 90 00 00         [24] 1232 	mov	dptr,#0x0000
      005FB9 22               [24] 1233 	ret
      005FBA                       1234 00121$:
                                   1235 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005FBA BF 22 02         [24] 1236 	cjne	r7,#0x22,00246$
      005FBD 80 03            [24] 1237 	sjmp	00127$
      005FBF                       1238 00246$:
      005FBF BF 21 5D         [24] 1239 	cjne	r7,#0x21,00128$
      005FC2                       1240 00127$:
                                   1241 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005FC2 ED               [12] 1242 	mov	a,r5
      005FC3 75 F0 04         [24] 1243 	mov	b,#0x04
      005FC6 A4               [48] 1244 	mul	ab
      005FC7 24 78            [12] 1245 	add	a, #_interface_descriptors
      005FC9 FE               [12] 1246 	mov	r6,a
      005FCA 74 BB            [12] 1247 	mov	a,#(_interface_descriptors >> 8)
      005FCC 35 F0            [12] 1248 	addc	a, b
      005FCE FF               [12] 1249 	mov	r7,a
      005FCF 8E 82            [24] 1250 	mov	dpl,r6
      005FD1 8F 83            [24] 1251 	mov	dph,r7
      005FD3 A3               [24] 1252 	inc	dptr
      005FD4 A3               [24] 1253 	inc	dptr
      005FD5 E4               [12] 1254 	clr	a
      005FD6 93               [24] 1255 	movc	a,@a+dptr
      005FD7 FC               [12] 1256 	mov	r4,a
      005FD8 A3               [24] 1257 	inc	dptr
      005FD9 E4               [12] 1258 	clr	a
      005FDA 93               [24] 1259 	movc	a,@a+dptr
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005FDB FD               [12] 1261 	mov	r5,a
      005FDC 4C               [12] 1262 	orl	a,r4
      005FDD 70 04            [24] 1263 	jnz	00124$
      005FDF 90 00 00         [24] 1264 	mov	dptr,#0x0000
      005FE2 22               [24] 1265 	ret
      005FE3                       1266 00124$:
                                   1267 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005FE3 90 07 ED         [24] 1268 	mov	dptr,#_descriptor_select_type_10000_272
      005FE6 E0               [24] 1269 	movx	a,@dptr
      005FE7 FB               [12] 1270 	mov	r3,a
      005FE8 BB 22 28         [24] 1271 	cjne	r3,#0x22,00126$
                                   1272 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005FEB 8E 82            [24] 1273 	mov	dpl,r6
      005FED 8F 83            [24] 1274 	mov	dph,r7
      005FEF E4               [12] 1275 	clr	a
      005FF0 93               [24] 1276 	movc	a,@a+dptr
      005FF1 FE               [12] 1277 	mov	r6,a
      005FF2 A3               [24] 1278 	inc	dptr
      005FF3 E4               [12] 1279 	clr	a
      005FF4 93               [24] 1280 	movc	a,@a+dptr
      005FF5 FF               [12] 1281 	mov	r7,a
      005FF6 90 07 E8         [24] 1282 	mov	dptr,#_control_pointer
      005FF9 EE               [12] 1283 	mov	a,r6
      005FFA F0               [24] 1284 	movx	@dptr,a
      005FFB EF               [12] 1285 	mov	a,r7
      005FFC A3               [24] 1286 	inc	dptr
      005FFD F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005FFE 74 07            [12] 1289 	mov	a,#0x07
      006000 2C               [12] 1290 	add	a, r4
      006001 F5 82            [12] 1291 	mov	dpl,a
      006003 E4               [12] 1292 	clr	a
      006004 3D               [12] 1293 	addc	a, r5
      006005 F5 83            [12] 1294 	mov	dph,a
      006007 E4               [12] 1295 	clr	a
      006008 93               [24] 1296 	movc	a,@a+dptr
      006009 FE               [12] 1297 	mov	r6,a
      00600A A3               [24] 1298 	inc	dptr
      00600B E4               [12] 1299 	clr	a
      00600C 93               [24] 1300 	movc	a,@a+dptr
      00600D FF               [12] 1301 	mov	r7,a
      00600E 8E 82            [24] 1302 	mov	dpl, r6
      006010 8F 83            [24] 1303 	mov	dph, r7
      006012 22               [24] 1304 	ret
      006013                       1305 00126$:
                                   1306 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      006013 90 07 E8         [24] 1307 	mov	dptr,#_control_pointer
      006016 EC               [12] 1308 	mov	a,r4
      006017 F0               [24] 1309 	movx	@dptr,a
      006018 ED               [12] 1310 	mov	a,r5
      006019 A3               [24] 1311 	inc	dptr
      00601A F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      00601B 90 00 09         [24] 1314 	mov	dptr,#0x0009
      00601E 22               [24] 1315 	ret
      00601F                       1316 00128$:
                                   1317 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      00601F 90 00 00         [24] 1318 	mov	dptr,#0x0000
                                   1319 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      006022 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'control_setup'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1325 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1326 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1327 ;type          Allocated with name '_control_setup_type_10000_290'
                                   1328 ;value         Allocated with name '_control_setup_value_10000_290'
                                   1329 ;index         Allocated with name '_control_setup_index_10000_290'
                                   1330 ;length        Allocated with name '_control_setup_length_10000_290'
                                   1331 ;endpoint      Allocated with name '_control_setup_endpoint_10000_290'
                                   1332 ;i             Allocated with name '_control_setup_i_10000_290'
                                   1333 ;offset        Allocated with name '_control_setup_offset_10000_290'
                                   1334 ;report_id     Allocated with name '_control_setup_report_id_10000_290'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function control_setup
                                   1339 ;	-----------------------------------------
      006023                       1340 _control_setup:
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006023 90 10 00         [24] 1342 	mov	dptr,#0x1000
      006026 E0               [24] 1343 	movx	a,@dptr
      006027 FF               [12] 1344 	mov	r7,a
                                   1345 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006028 A3               [24] 1346 	inc	dptr
      006029 A3               [24] 1347 	inc	dptr
      00602A E0               [24] 1348 	movx	a,@dptr
      00602B FE               [12] 1349 	mov	r6,a
      00602C A3               [24] 1350 	inc	dptr
      00602D E0               [24] 1351 	movx	a,@dptr
      00602E FC               [12] 1352 	mov	r4,a
      00602F 7D 00            [12] 1353 	mov	r5,#0x00
      006031 8E 03            [24] 1354 	mov	ar3,r6
      006033 7E 00            [12] 1355 	mov	r6,#0x00
      006035 ED               [12] 1356 	mov	a,r5
      006036 4B               [12] 1357 	orl	a,r3
      006037 FD               [12] 1358 	mov	r5,a
      006038 EC               [12] 1359 	mov	a,r4
      006039 4E               [12] 1360 	orl	a,r6
      00603A FE               [12] 1361 	mov	r6,a
                                   1362 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      00603B A3               [24] 1363 	inc	dptr
      00603C E0               [24] 1364 	movx	a,@dptr
      00603D FC               [12] 1365 	mov	r4,a
      00603E A3               [24] 1366 	inc	dptr
      00603F E0               [24] 1367 	movx	a,@dptr
      006040 FA               [12] 1368 	mov	r2,a
      006041 7B 00            [12] 1369 	mov	r3,#0x00
      006043 8C 01            [24] 1370 	mov	ar1,r4
      006045 7C 00            [12] 1371 	mov	r4,#0x00
      006047 EB               [12] 1372 	mov	a,r3
      006048 49               [12] 1373 	orl	a,r1
      006049 FB               [12] 1374 	mov	r3,a
      00604A EA               [12] 1375 	mov	a,r2
      00604B 4C               [12] 1376 	orl	a,r4
      00604C FC               [12] 1377 	mov	r4,a
                                   1378 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      00604D C3               [12] 1379 	clr	c
      00604E EB               [12] 1380 	mov	a,r3
      00604F 94 03            [12] 1381 	subb	a,#0x03
      006051 EC               [12] 1382 	mov	a,r4
      006052 94 00            [12] 1383 	subb	a,#0x00
      006054 92 14            [24] 1384 	mov	_control_setup_valid_interface_10000_290,c
                                   1385 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006056 EB               [12] 1386 	mov	a,r3
      006057 4C               [12] 1387 	orl	a,r4
      006058 B4 01 00         [24] 1388 	cjne	a,#0x01,01201$
      00605B                       1389 01201$:
      00605B 92 15            [24] 1390 	mov	_control_setup_zero_index_10000_290,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      00605D ED               [12] 1392 	mov	a,r5
      00605E 4E               [12] 1393 	orl	a,r6
      00605F B4 01 00         [24] 1394 	cjne	a,#0x01,01202$
      006062                       1395 01202$:
                                   1396 ;	assignBit
      006062 92 18            [24] 1397 	mov  _control_setup_sloc0_1_0,c
      006064 92 16            [24] 1398 	mov	_control_setup_zero_value_10000_290,c
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006066 90 07 F0         [24] 1400 	mov	dptr,#_control_setup_offset_10000_290
      006069 E4               [12] 1401 	clr	a
      00606A F0               [24] 1402 	movx	@dptr,a
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      00606B 90 07 8D         [24] 1404 	mov	dptr,#_raw_state
      00606E E0               [24] 1405 	movx	a,@dptr
      00606F FA               [12] 1406 	mov	r2,a
      006070 BA 01 05         [24] 1407 	cjne	r2,#0x01,00102$
      006073 90 07 8D         [24] 1408 	mov	dptr,#_raw_state
      006076 E4               [12] 1409 	clr	a
      006077 F0               [24] 1410 	movx	@dptr,a
      006078                       1411 00102$:
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006078 C0 07            [24] 1413 	push	ar7
      00607A 90 07 E5         [24] 1414 	mov	dptr,#_output_kind
      00607D E4               [12] 1415 	clr	a
      00607E F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      00607F 90 07 E4         [24] 1418 	mov	dptr,#_control_phase
      006082 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006083 90 07 E7         [24] 1421 	mov	dptr,#_control_zlp
      006086 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006087 90 10 01         [24] 1424 	mov	dptr,#0x1001
      00608A E0               [24] 1425 	movx	a,@dptr
      00608B 90 07 7F         [24] 1426 	mov	dptr,#_D0SetupReqCode
      00608E F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00608F 90 10 06         [24] 1429 	mov	dptr,#0x1006
      006092 E0               [24] 1430 	movx	a,@dptr
      006093 FA               [12] 1431 	mov	r2,a
      006094 A3               [24] 1432 	inc	dptr
      006095 E0               [24] 1433 	movx	a,@dptr
      006096 F9               [12] 1434 	mov	r1,a
      006097 78 00            [12] 1435 	mov	r0,#0x00
      006099 7F 00            [12] 1436 	mov	r7,#0x00
      00609B 90 07 80         [24] 1437 	mov	dptr,#_D0SetupLen
      00609E E8               [12] 1438 	mov	a,r0
      00609F 4A               [12] 1439 	orl	a,r2
      0060A0 F0               [24] 1440 	movx	@dptr,a
      0060A1 E9               [12] 1441 	mov	a,r1
      0060A2 4F               [12] 1442 	orl	a,r7
      0060A3 A3               [24] 1443 	inc	dptr
      0060A4 F0               [24] 1444 	movx	@dptr,a
                                   1445 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      0060A5 90 07 80         [24] 1446 	mov	dptr,#_D0SetupLen
      0060A8 E0               [24] 1447 	movx	a,@dptr
      0060A9 FA               [12] 1448 	mov	r2,a
      0060AA A3               [24] 1449 	inc	dptr
      0060AB E0               [24] 1450 	movx	a,@dptr
      0060AC 4A               [12] 1451 	orl	a,r2
      0060AD B4 01 00         [24] 1452 	cjne	a,#0x01,01205$
      0060B0                       1453 01205$:
      0060B0 92 17            [24] 1454 	mov	_control_setup_zero_length_10000_290,c
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0060B2 90 22 00         [24] 1456 	mov	dptr,#0x2200
      0060B5 74 C2            [12] 1457 	mov	a,#0xc2
      0060B7 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      0060B8 90 22 08         [24] 1460 	mov	dptr,#0x2208
      0060BB E4               [12] 1461 	clr	a
      0060BC F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      0060BD 90 07 7F         [24] 1464 	mov	dptr,#_D0SetupReqCode
      0060C0 E0               [24] 1465 	movx	a,@dptr
      0060C1 F5 16            [12] 1466 	mov	_control_setup_sloc1_1_0,a
      0060C3 C3               [12] 1467 	clr	c
      0060C4 74 0B            [12] 1468 	mov	a,#0x0b
      0060C6 95 16            [12] 1469 	subb	a,_control_setup_sloc1_1_0
      0060C8 D0 07            [24] 1470 	pop	ar7
      0060CA 50 03            [24] 1471 	jnc	01206$
      0060CC 02 5E 0A         [24] 1472 	ljmp	_control_stall
      0060CF                       1473 01206$:
                                   1474 ;	free result
      0060CF E5 16            [12] 1475 	mov	a,_control_setup_sloc1_1_0
      0060D1 F5 F0            [12] 1476 	mov	b,a
      0060D3 24 0B            [12] 1477 	add	a,#(01207$-3-.)
      0060D5 83               [24] 1478 	movc	a,@a+pc
      0060D6 F5 82            [12] 1479 	mov	dpl,a
      0060D8 E5 F0            [12] 1480 	mov	a,b
      0060DA 24 10            [12] 1481 	add	a,#(01208$-3-.)
      0060DC 83               [24] 1482 	movc	a,@a+pc
      0060DD F5 83            [12] 1483 	mov	dph,a
      0060DF E4               [12] 1484 	clr	a
      0060E0 73               [24] 1485 	jmp	@a+dptr
      0060E1                       1486 01207$:
      0060E1 89                    1487 	.db	00188$
      0060E2 2F                    1488 	.db	00205$
      0060E3 72                    1489 	.db	00282$
      0060E4 2F                    1490 	.db	00205$
      0060E5 B6                    1491 	.db	00290$
      0060E6 B3                    1492 	.db	00116$
      0060E7 F9                    1493 	.db	00103$
      0060E8 B6                    1494 	.db	00290$
      0060E9 B8                    1495 	.db	00150$
      0060EA DC                    1496 	.db	00123$
      0060EB E8                    1497 	.db	00157$
      0060EC 3B                    1498 	.db	00173$
      0060ED                       1499 01208$:
      0060ED 63                    1500 	.db	00188$>>8
      0060EE 64                    1501 	.db	00205$>>8
      0060EF 67                    1502 	.db	00282$>>8
      0060F0 64                    1503 	.db	00205$>>8
      0060F1 67                    1504 	.db	00290$>>8
      0060F2 61                    1505 	.db	00116$>>8
      0060F3 60                    1506 	.db	00103$>>8
      0060F4 67                    1507 	.db	00290$>>8
      0060F5 62                    1508 	.db	00150$>>8
      0060F6 61                    1509 	.db	00123$>>8
      0060F7 62                    1510 	.db	00157$>>8
      0060F8 63                    1511 	.db	00173$>>8
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      0060F9                       1513 00103$:
                                   1514 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      0060F9 BF 80 02         [24] 1515 	cjne	r7,#0x80,01209$
      0060FC 80 08            [24] 1516 	sjmp	00112$
      0060FE                       1517 01209$:
      0060FE BF 81 02         [24] 1518 	cjne	r7,#0x81,01210$
      006101 80 03            [24] 1519 	sjmp	01211$
      006103                       1520 01210$:
      006103 02 5E 0A         [24] 1521 	ljmp	_control_stall
      006106                       1522 01211$:
      006106                       1523 00112$:
                                   1524 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006106 8E 01            [24] 1525 	mov	ar1,r6
      006108 B9 21 02         [24] 1526 	cjne	r1,#0x21,01212$
      00610B 80 09            [24] 1527 	sjmp	00301$
      00610D                       1528 01212$:
      00610D B9 22 02         [24] 1529 	cjne	r1,#0x22,01213$
      006110 80 04            [24] 1530 	sjmp	00301$
      006112                       1531 01213$:
                                   1532 ;	assignBit
      006112 C2 19            [12] 1533 	clr	_control_setup_sloc2_1_0
      006114 80 02            [24] 1534 	sjmp	00302$
      006116                       1535 00301$:
                                   1536 ;	assignBit
      006116 D2 19            [12] 1537 	setb	_control_setup_sloc2_1_0
      006118                       1538 00302$:
      006118 E4               [12] 1539 	clr	a
      006119 BF 81 01         [24] 1540 	cjne	r7,#0x81,01214$
      00611C 04               [12] 1541 	inc	a
      00611D                       1542 01214$:
      00611D FA               [12] 1543 	mov	r2,a
      00611E A2 19            [12] 1544 	mov	c,_control_setup_sloc2_1_0
      006120 E4               [12] 1545 	clr	a
      006121 33               [12] 1546 	rlc	a
      006122 B5 02 02         [24] 1547 	cjne	a,ar2,01216$
      006125 80 03            [24] 1548 	sjmp	00105$
      006127                       1549 01216$:
                                   1550 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006127 02 5E 0A         [24] 1551 	ljmp	_control_stall
      00612A                       1552 00105$:
                                   1553 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      00612A 8E 02            [24] 1554 	mov	ar2,r6
      00612C 90 07 EA         [24] 1555 	mov	dptr,#_descriptor_select_PARM_2
      00612F ED               [12] 1556 	mov	a,r5
      006130 F0               [24] 1557 	movx	@dptr,a
      006131 90 07 EB         [24] 1558 	mov	dptr,#_descriptor_select_PARM_3
      006134 EB               [12] 1559 	mov	a,r3
      006135 F0               [24] 1560 	movx	@dptr,a
      006136 EC               [12] 1561 	mov	a,r4
      006137 A3               [24] 1562 	inc	dptr
      006138 F0               [24] 1563 	movx	@dptr,a
      006139 8A 82            [24] 1564 	mov	dpl, r2
      00613B 12 5E A8         [24] 1565 	lcall	_descriptor_select
      00613E 85 82 17         [24] 1566 	mov	_control_setup_sloc3_1_0,dpl
      006141 85 83 18         [24] 1567 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1568 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      006144 E5 17            [12] 1569 	mov	a,_control_setup_sloc3_1_0
      006146 45 18            [12] 1570 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006148 70 03            [24] 1571 	jnz	00107$
      00614A 02 5E 0A         [24] 1572 	ljmp	_control_stall
      00614D                       1573 00107$:
                                   1574 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00614D 90 07 80         [24] 1575 	mov	dptr,#_D0SetupLen
      006150 E0               [24] 1576 	movx	a,@dptr
      006151 F8               [12] 1577 	mov	r0,a
      006152 A3               [24] 1578 	inc	dptr
      006153 E0               [24] 1579 	movx	a,@dptr
      006154 FA               [12] 1580 	mov	r2,a
      006155 C3               [12] 1581 	clr	c
      006156 E5 17            [12] 1582 	mov	a,_control_setup_sloc3_1_0
      006158 98               [12] 1583 	subb	a,r0
      006159 E5 18            [12] 1584 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00615B 9A               [12] 1585 	subb	a,r2
      00615C 50 06            [24] 1586 	jnc	00303$
      00615E E5 17            [12] 1587 	mov	a,_control_setup_sloc3_1_0
      006160 54 3F            [12] 1588 	anl	a,#0x3f
      006162 60 04            [24] 1589 	jz	00304$
      006164                       1590 00303$:
                                   1591 ;	assignBit
      006164 C2 19            [12] 1592 	clr	_control_setup_sloc2_1_0
      006166 80 02            [24] 1593 	sjmp	00305$
      006168                       1594 00304$:
                                   1595 ;	assignBit
      006168 D2 19            [12] 1596 	setb	_control_setup_sloc2_1_0
      00616A                       1597 00305$:
      00616A 90 07 E7         [24] 1598 	mov	dptr,#_control_zlp
      00616D A2 19            [12] 1599 	mov	c,_control_setup_sloc2_1_0
      00616F E4               [12] 1600 	clr	a
      006170 33               [12] 1601 	rlc	a
      006171 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006172 90 07 80         [24] 1604 	mov	dptr,#_D0SetupLen
      006175 E0               [24] 1605 	movx	a,@dptr
      006176 F9               [12] 1606 	mov	r1,a
      006177 A3               [24] 1607 	inc	dptr
      006178 E0               [24] 1608 	movx	a,@dptr
      006179 FA               [12] 1609 	mov	r2,a
      00617A C3               [12] 1610 	clr	c
      00617B E5 17            [12] 1611 	mov	a,_control_setup_sloc3_1_0
      00617D 99               [12] 1612 	subb	a,r1
      00617E E5 18            [12] 1613 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006180 9A               [12] 1614 	subb	a,r2
      006181 50 0A            [24] 1615 	jnc	00109$
                                   1616 ;	free result
      006183 90 07 80         [24] 1617 	mov	dptr,#_D0SetupLen
      006186 E5 17            [12] 1618 	mov	a,_control_setup_sloc3_1_0
      006188 F0               [24] 1619 	movx	@dptr,a
      006189 E5 18            [12] 1620 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00618B A3               [24] 1621 	inc	dptr
      00618C F0               [24] 1622 	movx	@dptr,a
      00618D                       1623 00109$:
                                   1624 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00618D 90 07 80         [24] 1625 	mov	dptr,#_D0SetupLen
      006190 E0               [24] 1626 	movx	a,@dptr
      006191 F9               [12] 1627 	mov	r1,a
      006192 A3               [24] 1628 	inc	dptr
      006193 E0               [24] 1629 	movx	a,@dptr
      006194 49               [12] 1630 	orl	a,r1
      006195 60 04            [24] 1631 	jz	00306$
      006197 7A 01            [12] 1632 	mov	r2,#0x01
      006199 80 02            [24] 1633 	sjmp	00307$
      00619B                       1634 00306$:
      00619B 7A 02            [12] 1635 	mov	r2,#0x02
      00619D                       1636 00307$:
      00619D 90 07 E4         [24] 1637 	mov	dptr,#_control_phase
      0061A0 EA               [12] 1638 	mov	a,r2
      0061A1 F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      0061A2 90 07 80         [24] 1641 	mov	dptr,#_D0SetupLen
      0061A5 E0               [24] 1642 	movx	a,@dptr
      0061A6 F9               [12] 1643 	mov	r1,a
      0061A7 A3               [24] 1644 	inc	dptr
      0061A8 E0               [24] 1645 	movx	a,@dptr
      0061A9 49               [12] 1646 	orl	a,r1
      0061AA 60 03            [24] 1647 	jz	00111$
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      0061AC 02 5E 2C         [24] 1649 	ljmp	_control_next
      0061AF                       1650 00111$:
      0061AF 22               [24] 1651 	ret
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      0061B0 02 5E 0A         [24] 1653 	ljmp	_control_stall
                                   1654 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      0061B3                       1655 00116$:
                                   1656 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0061B3 EF               [12] 1657 	mov	a,r7
      0061B4 70 23            [24] 1658 	jnz	00118$
      0061B6 30 15 20         [24] 1659 	jnb	_control_setup_zero_index_10000_290,00118$
      0061B9 30 17 1D         [24] 1660 	jnb	_control_setup_zero_length_10000_290,00118$
      0061BC 8D 01            [24] 1661 	mov	ar1,r5
      0061BE 8E 02            [24] 1662 	mov	ar2,r6
      0061C0 C3               [12] 1663 	clr	c
      0061C1 74 7F            [12] 1664 	mov	a,#0x7f
      0061C3 99               [12] 1665 	subb	a,r1
      0061C4 E4               [12] 1666 	clr	a
      0061C5 9A               [12] 1667 	subb	a,r2
      0061C6 40 11            [24] 1668 	jc	00118$
                                   1669 ;	free result
                                   1670 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0061C8 90 07 80         [24] 1671 	mov	dptr,#_D0SetupLen
      0061CB ED               [12] 1672 	mov	a,r5
      0061CC F0               [24] 1673 	movx	@dptr,a
      0061CD EE               [12] 1674 	mov	a,r6
      0061CE A3               [24] 1675 	inc	dptr
      0061CF F0               [24] 1676 	movx	@dptr,a
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0061D0 90 07 E4         [24] 1678 	mov	dptr,#_control_phase
      0061D3 74 03            [12] 1679 	mov	a,#0x03
      0061D5 F0               [24] 1680 	movx	@dptr,a
      0061D6 02 67 B9         [24] 1681 	ljmp	00291$
      0061D9                       1682 00118$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0061D9 02 5E 0A         [24] 1684 	ljmp	_control_stall
                                   1685 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0061DC                       1686 00123$:
                                   1687 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0061DC EF               [12] 1688 	mov	a,r7
      0061DD 70 3C            [24] 1689 	jnz	00145$
      0061DF 30 15 39         [24] 1690 	jnb	_control_setup_zero_index_10000_290,00145$
      0061E2 30 17 36         [24] 1691 	jnb	_control_setup_zero_length_10000_290,00145$
      0061E5 8D 01            [24] 1692 	mov	ar1,r5
      0061E7 8E 02            [24] 1693 	mov	ar2,r6
      0061E9 C3               [12] 1694 	clr	c
      0061EA 74 01            [12] 1695 	mov	a,#0x01
      0061EC 99               [12] 1696 	subb	a,r1
      0061ED E4               [12] 1697 	clr	a
      0061EE 9A               [12] 1698 	subb	a,r2
      0061EF 40 2A            [24] 1699 	jc	00145$
                                   1700 ;	free result
                                   1701 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0061F1 C0 06            [24] 1702 	push	ar6
      0061F3 C0 05            [24] 1703 	push	ar5
      0061F5 12 5D A9         [24] 1704 	lcall	_endpoints_reset
      0061F8 D0 05            [24] 1705 	pop	ar5
      0061FA D0 06            [24] 1706 	pop	ar6
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0061FC 90 07 85         [24] 1708 	mov	dptr,#_D0UsbConfig
      0061FF ED               [12] 1709 	mov	a,r5
      006200 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006201 A2 18            [12] 1712 	mov	c,_control_setup_sloc0_1_0
      006203 B3               [12] 1713 	cpl	c
      006204 92 19            [24] 1714 	mov	_control_setup_sloc2_1_0,c
      006206 90 07 86         [24] 1715 	mov	dptr,#_USB_EnumStatus
      006209 E4               [12] 1716 	clr	a
      00620A 33               [12] 1717 	rlc	a
      00620B F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      00620C 90 07 AF         [24] 1720 	mov	dptr,#_keyboard_reset
      00620F 74 01            [12] 1721 	mov	a,#0x01
      006211 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      006212 90 07 E4         [24] 1724 	mov	dptr,#_control_phase
      006215 74 03            [12] 1725 	mov	a,#0x03
      006217 F0               [24] 1726 	movx	@dptr,a
      006218 02 67 B9         [24] 1727 	ljmp	00291$
      00621B                       1728 00145$:
                                   1729 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      00621B BF 21 02         [24] 1730 	cjne	r7,#0x21,01231$
      00621E 80 03            [24] 1731 	sjmp	01232$
      006220                       1732 01231$:
      006220 02 5E 0A         [24] 1733 	ljmp	_control_stall
      006223                       1734 01232$:
      006223 90 07 85         [24] 1735 	mov	dptr,#_D0UsbConfig
      006226 E0               [24] 1736 	movx	a,@dptr
      006227 70 03            [24] 1737 	jnz	01233$
      006229 02 5E 0A         [24] 1738 	ljmp	_control_stall
      00622C                       1739 01233$:
                                   1740 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00622C BB 01 2D         [24] 1741 	cjne	r3,#0x01,00135$
      00622F BC 00 2A         [24] 1742 	cjne	r4,#0x00,00135$
      006232 8D 01            [24] 1743 	mov	ar1,r5
      006234 8E 02            [24] 1744 	mov	ar2,r6
      006236 B9 00 23         [24] 1745 	cjne	r1,#0x00,00135$
      006239 BA 02 20         [24] 1746 	cjne	r2,#0x02,00135$
      00623C 90 07 80         [24] 1747 	mov	dptr,#_D0SetupLen
      00623F E0               [24] 1748 	movx	a,@dptr
      006240 F9               [12] 1749 	mov	r1,a
      006241 A3               [24] 1750 	inc	dptr
      006242 E0               [24] 1751 	movx	a,@dptr
      006243 FA               [12] 1752 	mov	r2,a
      006244 B9 20 15         [24] 1753 	cjne	r1,#0x20,00135$
      006247 BA 00 12         [24] 1754 	cjne	r2,#0x00,00135$
      00624A 90 07 8D         [24] 1755 	mov	dptr,#_raw_state
      00624D E0               [24] 1756 	movx	a,@dptr
      00624E 70 0C            [24] 1757 	jnz	00135$
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006250 90 07 8D         [24] 1759 	mov	dptr,#_raw_state
      006253 74 01            [12] 1760 	mov	a,#0x01
      006255 F0               [24] 1761 	movx	@dptr,a
                                   1762 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006256 90 07 E5         [24] 1763 	mov	dptr,#_output_kind
      006259 F0               [24] 1764 	movx	@dptr,a
      00625A 80 52            [24] 1765 	sjmp	00136$
      00625C                       1766 00135$:
                                   1767 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      00625C EB               [12] 1768 	mov	a,r3
      00625D 4C               [12] 1769 	orl	a,r4
      00625E 70 20            [24] 1770 	jnz	00130$
      006260 8D 01            [24] 1771 	mov	ar1,r5
      006262 8E 02            [24] 1772 	mov	ar2,r6
      006264 B9 00 19         [24] 1773 	cjne	r1,#0x00,00130$
      006267 BA 02 16         [24] 1774 	cjne	r2,#0x02,00130$
      00626A 90 07 80         [24] 1775 	mov	dptr,#_D0SetupLen
      00626D E0               [24] 1776 	movx	a,@dptr
      00626E F9               [12] 1777 	mov	r1,a
      00626F A3               [24] 1778 	inc	dptr
      006270 E0               [24] 1779 	movx	a,@dptr
      006271 FA               [12] 1780 	mov	r2,a
      006272 B9 01 0B         [24] 1781 	cjne	r1,#0x01,00130$
      006275 BA 00 08         [24] 1782 	cjne	r2,#0x00,00130$
                                   1783 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006278 90 07 E5         [24] 1784 	mov	dptr,#_output_kind
      00627B 74 02            [12] 1785 	mov	a,#0x02
      00627D F0               [24] 1786 	movx	@dptr,a
      00627E 80 2E            [24] 1787 	sjmp	00136$
      006280                       1788 00130$:
                                   1789 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006280 BB 02 28         [24] 1790 	cjne	r3,#0x02,00125$
      006283 BC 00 25         [24] 1791 	cjne	r4,#0x00,00125$
      006286 8D 01            [24] 1792 	mov	ar1,r5
      006288 8E 02            [24] 1793 	mov	ar2,r6
      00628A B9 06 1E         [24] 1794 	cjne	r1,#0x06,00125$
      00628D BA 02 1B         [24] 1795 	cjne	r2,#0x02,00125$
      006290 90 07 80         [24] 1796 	mov	dptr,#_D0SetupLen
      006293 E0               [24] 1797 	movx	a,@dptr
      006294 F9               [12] 1798 	mov	r1,a
      006295 A3               [24] 1799 	inc	dptr
      006296 E0               [24] 1800 	movx	a,@dptr
      006297 FA               [12] 1801 	mov	r2,a
      006298 B9 02 10         [24] 1802 	cjne	r1,#0x02,00125$
      00629B BA 00 0D         [24] 1803 	cjne	r2,#0x00,00125$
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      00629E 90 07 E5         [24] 1805 	mov	dptr,#_output_kind
      0062A1 74 03            [12] 1806 	mov	a,#0x03
      0062A3 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0062A4 90 07 E6         [24] 1809 	mov	dptr,#_output_report_id
      0062A7 23               [12] 1810 	rl	a
      0062A8 F0               [24] 1811 	movx	@dptr,a
      0062A9 80 03            [24] 1812 	sjmp	00136$
      0062AB                       1813 00125$:
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0062AB 02 5E 0A         [24] 1815 	ljmp	_control_stall
      0062AE                       1816 00136$:
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0062AE 90 07 E4         [24] 1818 	mov	dptr,#_control_phase
      0062B1 74 04            [12] 1819 	mov	a,#0x04
      0062B3 F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0062B4 22               [24] 1822 	ret
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0062B5 02 5E 0A         [24] 1824 	ljmp	_control_stall
                                   1825 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0062B8                       1826 00150$:
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0062B8 BF 80 2A         [24] 1828 	cjne	r7,#0x80,00152$
      0062BB 30 15 27         [24] 1829 	jnb	_control_setup_zero_index_10000_290,00152$
      0062BE 30 16 24         [24] 1830 	jnb	_control_setup_zero_value_10000_290,00152$
      0062C1 90 07 80         [24] 1831 	mov	dptr,#_D0SetupLen
      0062C4 E0               [24] 1832 	movx	a,@dptr
      0062C5 F9               [12] 1833 	mov	r1,a
      0062C6 A3               [24] 1834 	inc	dptr
      0062C7 E0               [24] 1835 	movx	a,@dptr
      0062C8 FA               [12] 1836 	mov	r2,a
      0062C9 B9 01 19         [24] 1837 	cjne	r1,#0x01,00152$
      0062CC BA 00 16         [24] 1838 	cjne	r2,#0x00,00152$
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0062CF 90 07 85         [24] 1840 	mov	dptr,#_D0UsbConfig
      0062D2 E0               [24] 1841 	movx	a,@dptr
      0062D3 90 10 00         [24] 1842 	mov	dptr,#0x1000
      0062D6 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0062D7 90 22 08         [24] 1845 	mov	dptr,#0x2208
      0062DA 74 01            [12] 1846 	mov	a,#0x01
      0062DC F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0062DD 90 07 E4         [24] 1849 	mov	dptr,#_control_phase
      0062E0 04               [12] 1850 	inc	a
      0062E1 F0               [24] 1851 	movx	@dptr,a
      0062E2 02 67 B9         [24] 1852 	ljmp	00291$
      0062E5                       1853 00152$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0062E5 02 5E 0A         [24] 1855 	ljmp	_control_stall
                                   1856 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0062E8                       1857 00157$:
                                   1858 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0062E8 BF 81 2C         [24] 1859 	cjne	r7,#0x81,00167$
      0062EB 30 14 29         [24] 1860 	jnb	_control_setup_valid_interface_10000_290,00167$
      0062EE 30 16 26         [24] 1861 	jnb	_control_setup_zero_value_10000_290,00167$
      0062F1 90 07 80         [24] 1862 	mov	dptr,#_D0SetupLen
      0062F4 E0               [24] 1863 	movx	a,@dptr
      0062F5 F9               [12] 1864 	mov	r1,a
      0062F6 A3               [24] 1865 	inc	dptr
      0062F7 E0               [24] 1866 	movx	a,@dptr
      0062F8 FA               [12] 1867 	mov	r2,a
      0062F9 B9 01 1B         [24] 1868 	cjne	r1,#0x01,00167$
      0062FC BA 00 18         [24] 1869 	cjne	r2,#0x00,00167$
      0062FF 90 07 85         [24] 1870 	mov	dptr,#_D0UsbConfig
      006302 E0               [24] 1871 	movx	a,@dptr
      006303 60 12            [24] 1872 	jz	00167$
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006305 90 10 00         [24] 1874 	mov	dptr,#0x1000
      006308 E4               [12] 1875 	clr	a
      006309 F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      00630A 90 22 08         [24] 1878 	mov	dptr,#0x2208
      00630D 04               [12] 1879 	inc	a
      00630E F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00630F 90 07 E4         [24] 1882 	mov	dptr,#_control_phase
      006312 04               [12] 1883 	inc	a
      006313 F0               [24] 1884 	movx	@dptr,a
      006314 02 67 B9         [24] 1885 	ljmp	00291$
      006317                       1886 00167$:
                                   1887 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006317 30 14 1E         [24] 1888 	jnb	_control_setup_valid_interface_10000_290,00161$
      00631A 90 07 85         [24] 1889 	mov	dptr,#_D0UsbConfig
      00631D E0               [24] 1890 	movx	a,@dptr
      00631E 60 18            [24] 1891 	jz	00161$
      006320 BF 21 15         [24] 1892 	cjne	r7,#0x21,00161$
      006323 30 17 12         [24] 1893 	jnb	_control_setup_zero_length_10000_290,00161$
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006326 EB               [12] 1895 	mov	a,r3
      006327 4C               [12] 1896 	orl	a,r4
      006328 70 05            [24] 1897 	jnz	00159$
      00632A 90 06 47         [24] 1898 	mov	dptr,#_keyboard_idle
      00632D EE               [12] 1899 	mov	a,r6
      00632E F0               [24] 1900 	movx	@dptr,a
      00632F                       1901 00159$:
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      00632F 90 07 E4         [24] 1903 	mov	dptr,#_control_phase
      006332 74 03            [12] 1904 	mov	a,#0x03
      006334 F0               [24] 1905 	movx	@dptr,a
      006335 02 67 B9         [24] 1906 	ljmp	00291$
      006338                       1907 00161$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006338 02 5E 0A         [24] 1909 	ljmp	_control_stall
                                   1910 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00633B                       1911 00173$:
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00633B BF 01 18         [24] 1913 	cjne	r7,#0x01,00182$
      00633E 30 14 15         [24] 1914 	jnb	_control_setup_valid_interface_10000_290,00182$
      006341 30 16 12         [24] 1915 	jnb	_control_setup_zero_value_10000_290,00182$
      006344 30 17 0F         [24] 1916 	jnb	_control_setup_zero_length_10000_290,00182$
      006347 90 07 85         [24] 1917 	mov	dptr,#_D0UsbConfig
      00634A E0               [24] 1918 	movx	a,@dptr
      00634B 60 09            [24] 1919 	jz	00182$
                                   1920 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      00634D 90 07 E4         [24] 1921 	mov	dptr,#_control_phase
      006350 74 03            [12] 1922 	mov	a,#0x03
      006352 F0               [24] 1923 	movx	@dptr,a
      006353 02 67 B9         [24] 1924 	ljmp	00291$
      006356                       1925 00182$:
                                   1926 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006356 EB               [12] 1927 	mov	a,r3
      006357 4C               [12] 1928 	orl	a,r4
      006358 70 2C            [24] 1929 	jnz	00175$
      00635A 90 07 85         [24] 1930 	mov	dptr,#_D0UsbConfig
      00635D E0               [24] 1931 	movx	a,@dptr
      00635E 60 26            [24] 1932 	jz	00175$
      006360 BF 21 23         [24] 1933 	cjne	r7,#0x21,00175$
      006363 30 17 20         [24] 1934 	jnb	_control_setup_zero_length_10000_290,00175$
      006366 8D 01            [24] 1935 	mov	ar1,r5
      006368 8E 02            [24] 1936 	mov	ar2,r6
      00636A C3               [12] 1937 	clr	c
      00636B 74 01            [12] 1938 	mov	a,#0x01
      00636D 99               [12] 1939 	subb	a,r1
      00636E E4               [12] 1940 	clr	a
      00636F 9A               [12] 1941 	subb	a,r2
      006370 40 14            [24] 1942 	jc	00175$
                                   1943 ;	free result
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006372 90 0D A9         [24] 1945 	mov	dptr,#_keyboard_protocol
      006375 ED               [12] 1946 	mov	a,r5
      006376 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006377 90 07 AF         [24] 1949 	mov	dptr,#_keyboard_reset
      00637A 74 01            [12] 1950 	mov	a,#0x01
      00637C F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      00637D 90 07 E4         [24] 1953 	mov	dptr,#_control_phase
      006380 74 03            [12] 1954 	mov	a,#0x03
      006382 F0               [24] 1955 	movx	@dptr,a
      006383 02 67 B9         [24] 1956 	ljmp	00291$
      006386                       1957 00175$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006386 02 5E 0A         [24] 1959 	ljmp	_control_stall
                                   1960 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006389                       1961 00188$:
                                   1962 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006389 20 16 03         [24] 1963 	jb	_control_setup_zero_value_10000_290,01283$
      00638C 02 5E 0A         [24] 1964 	ljmp	_control_stall
      00638F                       1965 01283$:
      00638F 90 07 80         [24] 1966 	mov	dptr,#_D0SetupLen
      006392 E0               [24] 1967 	movx	a,@dptr
      006393 F9               [12] 1968 	mov	r1,a
      006394 A3               [24] 1969 	inc	dptr
      006395 E0               [24] 1970 	movx	a,@dptr
      006396 FA               [12] 1971 	mov	r2,a
      006397 B9 02 05         [24] 1972 	cjne	r1,#0x02,01284$
      00639A BA 00 02         [24] 1973 	cjne	r2,#0x00,01284$
      00639D 80 03            [24] 1974 	sjmp	01285$
      00639F                       1975 01284$:
      00639F 02 5E 0A         [24] 1976 	ljmp	_control_stall
      0063A2                       1977 01285$:
                                   1978 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0063A2 E4               [12] 1979 	clr	a
      0063A3 BF 80 01         [24] 1980 	cjne	r7,#0x80,01286$
      0063A6 04               [12] 1981 	inc	a
      0063A7                       1982 01286$:
      0063A7 FA               [12] 1983 	mov	r2,a
      0063A8 60 03            [24] 1984 	jz	00196$
      0063AA 20 15 35         [24] 1985 	jb	_control_setup_zero_index_10000_290,00189$
      0063AD                       1986 00196$:
      0063AD BF 81 09         [24] 1987 	cjne	r7,#0x81,00202$
      0063B0 30 14 06         [24] 1988 	jnb	_control_setup_valid_interface_10000_290,00202$
      0063B3 90 07 85         [24] 1989 	mov	dptr,#_D0UsbConfig
      0063B6 E0               [24] 1990 	movx	a,@dptr
      0063B7 70 29            [24] 1991 	jnz	00189$
      0063B9                       1992 00202$:
                                   1993 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0063B9 BF 82 70         [24] 1994 	cjne	r7,#0x82,00190$
      0063BC 90 07 85         [24] 1995 	mov	dptr,#_D0UsbConfig
      0063BF E0               [24] 1996 	movx	a,@dptr
      0063C0 60 6A            [24] 1997 	jz	00190$
      0063C2 EB               [12] 1998 	mov	a,r3
      0063C3 4C               [12] 1999 	orl	a,r4
      0063C4 60 1C            [24] 2000 	jz	00189$
      0063C6 8B 00            [24] 2001 	mov	ar0,r3
      0063C8 8C 01            [24] 2002 	mov	ar1,r4
      0063CA B8 80 05         [24] 2003 	cjne	r0,#0x80,01298$
      0063CD B9 00 02         [24] 2004 	cjne	r1,#0x00,01298$
      0063D0 80 10            [24] 2005 	sjmp	00189$
      0063D2                       2006 01298$:
      0063D2 C3               [12] 2007 	clr	c
      0063D3 E8               [12] 2008 	mov	a,r0
      0063D4 94 81            [12] 2009 	subb	a,#0x81
      0063D6 E9               [12] 2010 	mov	a,r1
      0063D7 94 00            [12] 2011 	subb	a,#0x00
      0063D9 40 51            [24] 2012 	jc	00190$
      0063DB 74 83            [12] 2013 	mov	a,#0x83
      0063DD 98               [12] 2014 	subb	a,r0
      0063DE E4               [12] 2015 	clr	a
      0063DF 99               [12] 2016 	subb	a,r1
      0063E0 40 4A            [24] 2017 	jc	00190$
                                   2018 ;	free result
      0063E2                       2019 00189$:
                                   2020 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0063E2 8B 01            [24] 2021 	mov	ar1,r3
      0063E4 53 01 07         [24] 2022 	anl	ar1,#0x07
                                   2023 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0063E7 EA               [12] 2024 	mov	a,r2
      0063E8 60 0B            [24] 2025 	jz	00308$
      0063EA 90 07 87         [24] 2026 	mov	dptr,#_USB_SleepStatus
      0063ED E0               [24] 2027 	movx	a,@dptr
      0063EE 54 01            [12] 2028 	anl	a,#0x01
      0063F0 25 E0            [12] 2029 	add	a,acc
      0063F2 FA               [12] 2030 	mov	r2,a
      0063F3 80 22            [24] 2031 	sjmp	00309$
      0063F5                       2032 00308$:
                                   2033 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0063F5 BF 82 1B         [24] 2034 	cjne	r7,#0x82,00310$
      0063F8 E9               [12] 2035 	mov	a,r1
      0063F9 60 18            [24] 2036 	jz	00310$
      0063FB 89 00            [24] 2037 	mov	ar0,r1
      0063FD 79 00            [12] 2038 	mov	r1,#0x00
      0063FF 74 22            [12] 2039 	mov	a,#0x22
      006401 29               [12] 2040 	add	a, r1
      006402 F9               [12] 2041 	mov	r1,a
      006403 88 82            [24] 2042 	mov	dpl,r0
      006405 89 83            [24] 2043 	mov	dph,r1
      006407 E0               [24] 2044 	movx	a,@dptr
      006408 F9               [12] 2045 	mov	r1,a
      006409 53 01 03         [24] 2046 	anl	ar1,#0x03
      00640C B9 03 04         [24] 2047 	cjne	r1,#0x03,00310$
      00640F 79 01            [12] 2048 	mov	r1,#0x01
      006411 80 02            [24] 2049 	sjmp	00311$
      006413                       2050 00310$:
      006413 79 00            [12] 2051 	mov	r1,#0x00
      006415                       2052 00311$:
      006415 89 02            [24] 2053 	mov	ar2,r1
      006417                       2054 00309$:
      006417 90 10 00         [24] 2055 	mov	dptr,#0x1000
      00641A EA               [12] 2056 	mov	a,r2
      00641B F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      00641C A3               [24] 2059 	inc	dptr
      00641D E4               [12] 2060 	clr	a
      00641E F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      00641F 90 22 08         [24] 2063 	mov	dptr,#0x2208
      006422 74 02            [12] 2064 	mov	a,#0x02
      006424 F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006425 90 07 E4         [24] 2067 	mov	dptr,#_control_phase
      006428 F0               [24] 2068 	movx	@dptr,a
      006429 02 67 B9         [24] 2069 	ljmp	00291$
      00642C                       2070 00190$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      00642C 02 5E 0A         [24] 2072 	ljmp	_control_stall
                                   2073 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00642F                       2074 00205$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      00642F 20 17 03         [24] 2076 	jb	_control_setup_zero_length_10000_290,01307$
      006432 02 64 C2         [24] 2077 	ljmp	00279$
      006435                       2078 01307$:
      006435 90 07 85         [24] 2079 	mov	dptr,#_D0UsbConfig
      006438 E0               [24] 2080 	movx	a,@dptr
      006439 70 03            [24] 2081 	jnz	01308$
      00643B 02 64 C2         [24] 2082 	ljmp	00279$
      00643E                       2083 01308$:
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      00643E EF               [12] 2085 	mov	a,r7
      00643F 70 29            [24] 2086 	jnz	00218$
      006441 8D 01            [24] 2087 	mov	ar1,r5
      006443 8E 02            [24] 2088 	mov	ar2,r6
      006445 B9 01 22         [24] 2089 	cjne	r1,#0x01,00218$
      006448 BA 00 1F         [24] 2090 	cjne	r2,#0x00,00218$
      00644B 30 15 1C         [24] 2091 	jnb	_control_setup_zero_index_10000_290,00218$
                                   2092 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00644E 90 07 7F         [24] 2093 	mov	dptr,#_D0SetupReqCode
      006451 E0               [24] 2094 	movx	a,@dptr
      006452 FA               [12] 2095 	mov	r2,a
      006453 BA 03 0A         [24] 2096 	cjne	r2,#0x03,00207$
      006456 90 07 87         [24] 2097 	mov	dptr,#_USB_SleepStatus
      006459 E0               [24] 2098 	movx	a,@dptr
      00645A 43 E0 01         [24] 2099 	orl	acc,#0x01
      00645D F0               [24] 2100 	movx	@dptr,a
      00645E 80 59            [24] 2101 	sjmp	00219$
      006460                       2102 00207$:
                                   2103 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006460 90 07 87         [24] 2104 	mov	dptr,#_USB_SleepStatus
      006463 E0               [24] 2105 	movx	a,@dptr
      006464 53 E0 FE         [24] 2106 	anl	acc,#0xfe
      006467 F0               [24] 2107 	movx	@dptr,a
      006468 80 4F            [24] 2108 	sjmp	00219$
      00646A                       2109 00218$:
                                   2110 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00646A BF 02 49         [24] 2111 	cjne	r7,#0x02,00212$
      00646D 30 16 46         [24] 2112 	jnb	_control_setup_zero_value_10000_290,00212$
      006470 8B 01            [24] 2113 	mov	ar1,r3
      006472 8C 02            [24] 2114 	mov	ar2,r4
      006474 C3               [12] 2115 	clr	c
      006475 E9               [12] 2116 	mov	a,r1
      006476 94 81            [12] 2117 	subb	a,#0x81
      006478 EA               [12] 2118 	mov	a,r2
      006479 94 00            [12] 2119 	subb	a,#0x00
      00647B 40 39            [24] 2120 	jc	00212$
      00647D 74 83            [12] 2121 	mov	a,#0x83
      00647F 99               [12] 2122 	subb	a,r1
      006480 E4               [12] 2123 	clr	a
      006481 9A               [12] 2124 	subb	a,r2
      006482 40 32            [24] 2125 	jc	00212$
                                   2126 ;	free result
                                   2127 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006484 8B 02            [24] 2128 	mov	ar2,r3
      006486 53 02 07         [24] 2129 	anl	ar2,#0x07
                                   2130 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006489 8A 00            [24] 2131 	mov	ar0,r2
      00648B 79 00            [12] 2132 	mov	r1,#0x00
      00648D 74 22            [12] 2133 	mov	a,#0x22
      00648F 29               [12] 2134 	add	a, r1
      006490 F9               [12] 2135 	mov	r1,a
      006491 88 17            [24] 2136 	mov	_control_setup_sloc3_1_0,r0
      006493 89 18            [24] 2137 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006495 90 07 7F         [24] 2138 	mov	dptr,#_D0SetupReqCode
      006498 E0               [24] 2139 	movx	a,@dptr
      006499 F9               [12] 2140 	mov	r1,a
      00649A B9 03 04         [24] 2141 	cjne	r1,#0x03,00318$
      00649D 79 03            [12] 2142 	mov	r1,#0x03
      00649F 80 02            [24] 2143 	sjmp	00319$
      0064A1                       2144 00318$:
      0064A1 79 02            [12] 2145 	mov	r1,#0x02
      0064A3                       2146 00319$:
      0064A3 43 01 10         [24] 2147 	orl	ar1,#0x10
      0064A6 85 17 82         [24] 2148 	mov	dpl,_control_setup_sloc3_1_0
      0064A9 85 18 83         [24] 2149 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0064AC E9               [12] 2150 	mov	a,r1
      0064AD F0               [24] 2151 	movx	@dptr,a
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0064AE BA 03 08         [24] 2153 	cjne	r2,#0x03,00219$
      0064B1 12 5D 8C         [24] 2154 	lcall	_raw_complete
      0064B4 80 03            [24] 2155 	sjmp	00219$
      0064B6                       2156 00212$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      0064B6 02 5E 0A         [24] 2158 	ljmp	_control_stall
      0064B9                       2159 00219$:
                                   2160 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      0064B9 90 07 E4         [24] 2161 	mov	dptr,#_control_phase
      0064BC 74 03            [12] 2162 	mov	a,#0x03
      0064BE F0               [24] 2163 	movx	@dptr,a
      0064BF 02 67 B9         [24] 2164 	ljmp	00291$
      0064C2                       2165 00279$:
                                   2166 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0064C2 E4               [12] 2167 	clr	a
      0064C3 BF A1 01         [24] 2168 	cjne	r7,#0xa1,01324$
      0064C6 04               [12] 2169 	inc	a
      0064C7                       2170 01324$:
      0064C7 FA               [12] 2171 	mov	r2,a
      0064C8 70 03            [24] 2172 	jnz	01326$
      0064CA 02 67 34         [24] 2173 	ljmp	00273$
      0064CD                       2174 01326$:
      0064CD 90 07 7F         [24] 2175 	mov	dptr,#_D0SetupReqCode
      0064D0 E0               [24] 2176 	movx	a,@dptr
      0064D1 F9               [12] 2177 	mov	r1,a
      0064D2 B9 01 02         [24] 2178 	cjne	r1,#0x01,01327$
      0064D5 80 03            [24] 2179 	sjmp	01328$
      0064D7                       2180 01327$:
      0064D7 02 67 34         [24] 2181 	ljmp	00273$
      0064DA                       2182 01328$:
      0064DA 90 07 85         [24] 2183 	mov	dptr,#_D0UsbConfig
      0064DD E0               [24] 2184 	movx	a,@dptr
      0064DE 70 03            [24] 2185 	jnz	01329$
      0064E0 02 67 34         [24] 2186 	ljmp	00273$
      0064E3                       2187 01329$:
      0064E3 90 07 80         [24] 2188 	mov	dptr,#_D0SetupLen
      0064E6 E0               [24] 2189 	movx	a,@dptr
      0064E7 F8               [12] 2190 	mov	r0,a
      0064E8 A3               [24] 2191 	inc	dptr
      0064E9 E0               [24] 2192 	movx	a,@dptr
      0064EA 48               [12] 2193 	orl	a,r0
      0064EB 70 03            [24] 2194 	jnz	01330$
      0064ED 02 67 34         [24] 2195 	ljmp	00273$
      0064F0                       2196 01330$:
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      0064F0 C0 03            [24] 2198 	push	ar3
      0064F2 C0 04            [24] 2199 	push	ar4
      0064F4 8D 01            [24] 2200 	mov	ar1,r5
                                   2201 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0064F6 8E 00            [24] 2202 	mov	ar0,r6
      0064F8 B8 01 03         [24] 2203 	cjne	r0,#0x01,01331$
      0064FB E8               [12] 2204 	mov	a,r0
      0064FC 80 01            [24] 2205 	sjmp	01332$
      0064FE                       2206 01331$:
      0064FE E4               [12] 2207 	clr	a
      0064FF                       2208 01332$:
      0064FF F5 17            [12] 2209 	mov	_control_setup_sloc3_1_0,a
      006501 D0 04            [24] 2210 	pop	ar4
      006503 D0 03            [24] 2211 	pop	ar3
      006505 E5 17            [12] 2212 	mov	a,_control_setup_sloc3_1_0
      006507 60 17            [24] 2213 	jz	00251$
      006509 EB               [12] 2214 	mov	a,r3
      00650A 4C               [12] 2215 	orl	a,r4
      00650B 70 13            [24] 2216 	jnz	00251$
      00650D E9               [12] 2217 	mov	a,r1
      00650E 70 10            [24] 2218 	jnz	00251$
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006510 90 07 EE         [24] 2220 	mov	dptr,#_control_setup_length_10000_290
      006513 74 08            [12] 2221 	mov	a,#0x08
      006515 F0               [24] 2222 	movx	@dptr,a
      006516 E4               [12] 2223 	clr	a
      006517 A3               [24] 2224 	inc	dptr
      006518 F0               [24] 2225 	movx	@dptr,a
                                   2226 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006519 90 07 F0         [24] 2227 	mov	dptr,#_control_setup_offset_10000_290
      00651C F0               [24] 2228 	movx	@dptr,a
      00651D 02 66 A4         [24] 2229 	ljmp	00252$
      006520                       2230 00251$:
                                   2231 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006520 E5 17            [12] 2232 	mov	a,_control_setup_sloc3_1_0
      006522 60 27            [24] 2233 	jz	00245$
      006524 BB 02 24         [24] 2234 	cjne	r3,#0x02,00245$
      006527 BC 00 21         [24] 2235 	cjne	r4,#0x00,00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00652A B9 07 00         [24] 2237 	cjne	r1,#0x07,01339$
      00652D                       2238 01339$:
      00652D 50 1C            [24] 2239 	jnc	00245$
      00652F E9               [12] 2240 	mov	a,r1
      006530 90 BB 71         [24] 2241 	mov	dptr,#_shared_lengths
      006533 93               [24] 2242 	movc	a,@a+dptr
      006534 F8               [12] 2243 	mov	r0,a
      006535 60 14            [24] 2244 	jz	00245$
                                   2245 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006537 90 07 EE         [24] 2246 	mov	dptr,#_control_setup_length_10000_290
      00653A E8               [12] 2247 	mov	a,r0
      00653B F0               [24] 2248 	movx	@dptr,a
      00653C E4               [12] 2249 	clr	a
      00653D A3               [24] 2250 	inc	dptr
      00653E F0               [24] 2251 	movx	@dptr,a
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      00653F E9               [12] 2253 	mov	a,r1
      006540 90 BB 6A         [24] 2254 	mov	dptr,#_shared_offsets
      006543 93               [24] 2255 	movc	a,@a+dptr
      006544 90 07 F0         [24] 2256 	mov	dptr,#_control_setup_offset_10000_290
      006547 F0               [24] 2257 	movx	@dptr,a
      006548 02 66 A4         [24] 2258 	ljmp	00252$
      00654B                       2259 00245$:
                                   2260 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00654B E5 17            [12] 2261 	mov	a,_control_setup_sloc3_1_0
      00654D 60 7A            [24] 2262 	jz	00240$
      00654F BB 01 77         [24] 2263 	cjne	r3,#0x01,00240$
      006552 BC 00 74         [24] 2264 	cjne	r4,#0x00,00240$
      006555 E9               [12] 2265 	mov	a,r1
      006556 70 71            [24] 2266 	jnz	00240$
                                   2267 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006558 90 07 80         [24] 2268 	mov	dptr,#_D0SetupLen
      00655B E0               [24] 2269 	movx	a,@dptr
      00655C F8               [12] 2270 	mov	r0,a
      00655D A3               [24] 2271 	inc	dptr
      00655E E0               [24] 2272 	movx	a,@dptr
      00655F F9               [12] 2273 	mov	r1,a
      006560 C3               [12] 2274 	clr	c
      006561 E8               [12] 2275 	mov	a,r0
      006562 94 20            [12] 2276 	subb	a,#0x20
      006564 E9               [12] 2277 	mov	a,r1
      006565 94 00            [12] 2278 	subb	a,#0x00
      006567 50 0A            [24] 2279 	jnc	00320$
      006569 90 07 80         [24] 2280 	mov	dptr,#_D0SetupLen
      00656C E0               [24] 2281 	movx	a,@dptr
      00656D F8               [12] 2282 	mov	r0,a
      00656E A3               [24] 2283 	inc	dptr
      00656F E0               [24] 2284 	movx	a,@dptr
      006570 F9               [12] 2285 	mov	r1,a
      006571 80 04            [24] 2286 	sjmp	00321$
      006573                       2287 00320$:
      006573 78 20            [12] 2288 	mov	r0,#0x20
      006575 79 00            [12] 2289 	mov	r1,#0x00
      006577                       2290 00321$:
                                   2291 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006577 75 17 00         [24] 2292 	mov	_control_setup_sloc3_1_0,#0x00
      00657A                       2293 00293$:
      00657A C0 03            [24] 2294 	push	ar3
      00657C C0 04            [24] 2295 	push	ar4
      00657E AB 17            [24] 2296 	mov	r3,_control_setup_sloc3_1_0
      006580 7C 00            [12] 2297 	mov	r4,#0x00
      006582 C3               [12] 2298 	clr	c
      006583 EB               [12] 2299 	mov	a,r3
      006584 98               [12] 2300 	subb	a,r0
      006585 EC               [12] 2301 	mov	a,r4
      006586 99               [12] 2302 	subb	a,r1
      006587 D0 04            [24] 2303 	pop	ar4
      006589 D0 03            [24] 2304 	pop	ar3
      00658B 50 32            [24] 2305 	jnc	00222$
      00658D C0 00            [24] 2306 	push	ar0
      00658F C0 01            [24] 2307 	push	ar1
      006591 85 17 19         [24] 2308 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006594 74 10            [12] 2309 	mov	a,#0x10
      006596 24 00            [12] 2310 	add	a, #0x00
      006598 F5 1A            [12] 2311 	mov	(_control_setup_sloc4_1_0 + 1),a
      00659A A8 17            [24] 2312 	mov	r0,_control_setup_sloc3_1_0
      00659C 79 00            [12] 2313 	mov	r1,#0x00
      00659E 74 C0            [12] 2314 	mov	a,#0xc0
      0065A0 28               [12] 2315 	add	a, r0
      0065A1 F8               [12] 2316 	mov	r0,a
      0065A2 E4               [12] 2317 	clr	a
      0065A3 39               [12] 2318 	addc	a, r1
      0065A4 F9               [12] 2319 	mov	r1,a
      0065A5 88 82            [24] 2320 	mov	dpl,r0
      0065A7 74 10            [12] 2321 	mov	a,#0x10
      0065A9 29               [12] 2322 	add	a, r1
      0065AA F5 83            [12] 2323 	mov	dph,a
      0065AC E0               [24] 2324 	movx	a,@dptr
      0065AD 85 19 82         [24] 2325 	mov	dpl,_control_setup_sloc4_1_0
      0065B0 85 1A 83         [24] 2326 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0065B3 F0               [24] 2327 	movx	@dptr,a
      0065B4 E5 17            [12] 2328 	mov	a,_control_setup_sloc3_1_0
      0065B6 04               [12] 2329 	inc	a
      0065B7 F5 17            [12] 2330 	mov	_control_setup_sloc3_1_0,a
      0065B9 D0 01            [24] 2331 	pop	ar1
      0065BB D0 00            [24] 2332 	pop	ar0
      0065BD 80 BB            [24] 2333 	sjmp	00293$
      0065BF                       2334 00222$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0065BF 90 07 EE         [24] 2336 	mov	dptr,#_control_setup_length_10000_290
      0065C2 E4               [12] 2337 	clr	a
      0065C3 F0               [24] 2338 	movx	@dptr,a
      0065C4 A3               [24] 2339 	inc	dptr
      0065C5 F0               [24] 2340 	movx	@dptr,a
      0065C6 02 66 A4         [24] 2341 	ljmp	00252$
      0065C9                       2342 00240$:
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0065C9 8D 00            [24] 2344 	mov	ar0,r5
      0065CB 8E 01            [24] 2345 	mov	ar1,r6
      0065CD B8 00 21         [24] 2346 	cjne	r0,#0x00,00236$
      0065D0 B9 02 1E         [24] 2347 	cjne	r1,#0x02,00236$
      0065D3 EB               [12] 2348 	mov	a,r3
      0065D4 4C               [12] 2349 	orl	a,r4
      0065D5 70 1A            [24] 2350 	jnz	00236$
                                   2351 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0065D7 90 07 8A         [24] 2352 	mov	dptr,#_KB_USB_SetReport
      0065DA E0               [24] 2353 	movx	a,@dptr
      0065DB 90 10 00         [24] 2354 	mov	dptr,#0x1000
      0065DE F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0065DF 90 07 EE         [24] 2357 	mov	dptr,#_control_setup_length_10000_290
      0065E2 E4               [12] 2358 	clr	a
      0065E3 F0               [24] 2359 	movx	@dptr,a
      0065E4 A3               [24] 2360 	inc	dptr
      0065E5 F0               [24] 2361 	movx	@dptr,a
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0065E6 90 07 80         [24] 2363 	mov	dptr,#_D0SetupLen
      0065E9 04               [12] 2364 	inc	a
      0065EA F0               [24] 2365 	movx	@dptr,a
      0065EB E4               [12] 2366 	clr	a
      0065EC A3               [24] 2367 	inc	dptr
      0065ED F0               [24] 2368 	movx	@dptr,a
      0065EE 02 66 A4         [24] 2369 	ljmp	00252$
      0065F1                       2370 00236$:
                                   2371 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0065F1 B8 06 41         [24] 2372 	cjne	r0,#0x06,00232$
      0065F4 B9 02 3E         [24] 2373 	cjne	r1,#0x02,00232$
      0065F7 BB 02 3B         [24] 2374 	cjne	r3,#0x02,00232$
      0065FA BC 00 38         [24] 2375 	cjne	r4,#0x00,00232$
                                   2376 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0065FD C0 03            [24] 2377 	push	ar3
      0065FF C0 04            [24] 2378 	push	ar4
      006601 90 10 00         [24] 2379 	mov	dptr,#0x1000
      006604 74 06            [12] 2380 	mov	a,#0x06
      006606 F0               [24] 2381 	movx	@dptr,a
                                   2382 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006607 90 07 8A         [24] 2383 	mov	dptr,#_KB_USB_SetReport
      00660A E0               [24] 2384 	movx	a,@dptr
      00660B 90 10 01         [24] 2385 	mov	dptr,#0x1001
      00660E F0               [24] 2386 	movx	@dptr,a
                                   2387 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00660F 90 07 EE         [24] 2388 	mov	dptr,#_control_setup_length_10000_290
      006612 E4               [12] 2389 	clr	a
      006613 F0               [24] 2390 	movx	@dptr,a
      006614 A3               [24] 2391 	inc	dptr
      006615 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      006616 90 07 80         [24] 2394 	mov	dptr,#_D0SetupLen
      006619 E0               [24] 2395 	movx	a,@dptr
      00661A FB               [12] 2396 	mov	r3,a
      00661B A3               [24] 2397 	inc	dptr
      00661C E0               [24] 2398 	movx	a,@dptr
      00661D FC               [12] 2399 	mov	r4,a
      00661E C3               [12] 2400 	clr	c
      00661F 74 02            [12] 2401 	mov	a,#0x02
      006621 9B               [12] 2402 	subb	a,r3
      006622 E4               [12] 2403 	clr	a
      006623 9C               [12] 2404 	subb	a,r4
      006624 D0 04            [24] 2405 	pop	ar4
      006626 D0 03            [24] 2406 	pop	ar3
      006628 50 7A            [24] 2407 	jnc	00252$
                                   2408 ;	free result
      00662A 90 07 80         [24] 2409 	mov	dptr,#_D0SetupLen
      00662D 74 02            [12] 2410 	mov	a,#0x02
      00662F F0               [24] 2411 	movx	@dptr,a
      006630 E4               [12] 2412 	clr	a
      006631 A3               [24] 2413 	inc	dptr
      006632 F0               [24] 2414 	movx	@dptr,a
      006633 80 6F            [24] 2415 	sjmp	00252$
      006635                       2416 00232$:
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006635 B8 00 69         [24] 2418 	cjne	r0,#0x00,00228$
      006638 B9 03 66         [24] 2419 	cjne	r1,#0x03,00228$
      00663B BB 01 63         [24] 2420 	cjne	r3,#0x01,00228$
      00663E BC 00 60         [24] 2421 	cjne	r4,#0x00,00228$
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006641 90 10 00         [24] 2423 	mov	dptr,#0x1000
      006644 74 41            [12] 2424 	mov	a,#0x41
      006646 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006647 A3               [24] 2427 	inc	dptr
      006648 74 4B            [12] 2428 	mov	a,#0x4b
      00664A F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      00664B A3               [24] 2431 	inc	dptr
      00664C 74 42            [12] 2432 	mov	a,#0x42
      00664E F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      00664F A3               [24] 2435 	inc	dptr
      006650 74 54            [12] 2436 	mov	a,#0x54
      006652 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006653 A3               [24] 2439 	inc	dptr
      006654 74 01            [12] 2440 	mov	a,#0x01
      006656 F0               [24] 2441 	movx	@dptr,a
                                   2442 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006657 90 07 8B         [24] 2443 	mov	dptr,#_ak820_boot_stage
      00665A E0               [24] 2444 	movx	a,@dptr
      00665B 90 10 05         [24] 2445 	mov	dptr,#0x1005
      00665E F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00665F 90 07 8C         [24] 2448 	mov	dptr,#_ak820_main_heartbeat
      006662 E0               [24] 2449 	movx	a,@dptr
      006663 90 10 06         [24] 2450 	mov	dptr,#0x1006
      006666 F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006667 90 07 86         [24] 2453 	mov	dptr,#_USB_EnumStatus
      00666A E0               [24] 2454 	movx	a,@dptr
      00666B 60 02            [24] 2455 	jz	00322$
      00666D 74 01            [12] 2456 	mov	a,#0x01
      00666F                       2457 00322$:
      00666F F9               [12] 2458 	mov	r1,a
      006670 90 07 87         [24] 2459 	mov	dptr,#_USB_SleepStatus
      006673 E0               [24] 2460 	movx	a,@dptr
      006674 54 02            [12] 2461 	anl	a,#0x02
      006676 F8               [12] 2462 	mov	r0,a
      006677 E9               [12] 2463 	mov	a,r1
      006678 42 00            [12] 2464 	orl	ar0,a
      00667A 90 10 07         [24] 2465 	mov	dptr,#0x1007
      00667D E8               [12] 2466 	mov	a,r0
      00667E F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      00667F 90 07 EE         [24] 2469 	mov	dptr,#_control_setup_length_10000_290
      006682 E4               [12] 2470 	clr	a
      006683 F0               [24] 2471 	movx	@dptr,a
      006684 A3               [24] 2472 	inc	dptr
      006685 F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006686 90 07 80         [24] 2475 	mov	dptr,#_D0SetupLen
      006689 E0               [24] 2476 	movx	a,@dptr
      00668A F8               [12] 2477 	mov	r0,a
      00668B A3               [24] 2478 	inc	dptr
      00668C E0               [24] 2479 	movx	a,@dptr
      00668D F9               [12] 2480 	mov	r1,a
      00668E C3               [12] 2481 	clr	c
      00668F 74 08            [12] 2482 	mov	a,#0x08
      006691 98               [12] 2483 	subb	a,r0
      006692 E4               [12] 2484 	clr	a
      006693 99               [12] 2485 	subb	a,r1
      006694 50 0E            [24] 2486 	jnc	00252$
                                   2487 ;	free result
      006696 90 07 80         [24] 2488 	mov	dptr,#_D0SetupLen
      006699 74 08            [12] 2489 	mov	a,#0x08
      00669B F0               [24] 2490 	movx	@dptr,a
      00669C E4               [12] 2491 	clr	a
      00669D A3               [24] 2492 	inc	dptr
      00669E F0               [24] 2493 	movx	@dptr,a
      00669F 80 03            [24] 2494 	sjmp	00252$
      0066A1                       2495 00228$:
                                   2496 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      0066A1 02 5E 0A         [24] 2497 	ljmp	_control_stall
      0066A4                       2498 00252$:
                                   2499 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      0066A4 90 07 EE         [24] 2500 	mov	dptr,#_control_setup_length_10000_290
      0066A7 E0               [24] 2501 	movx	a,@dptr
      0066A8 F5 19            [12] 2502 	mov	_control_setup_sloc4_1_0,a
      0066AA A3               [24] 2503 	inc	dptr
      0066AB E0               [24] 2504 	movx	a,@dptr
      0066AC F5 1A            [12] 2505 	mov	(_control_setup_sloc4_1_0 + 1),a
      0066AE E5 19            [12] 2506 	mov	a,_control_setup_sloc4_1_0
      0066B0 45 1A            [12] 2507 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0066B2 60 50            [24] 2508 	jz	00262$
                                   2509 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      0066B4 90 07 80         [24] 2510 	mov	dptr,#_D0SetupLen
      0066B7 E0               [24] 2511 	movx	a,@dptr
      0066B8 F8               [12] 2512 	mov	r0,a
      0066B9 A3               [24] 2513 	inc	dptr
      0066BA E0               [24] 2514 	movx	a,@dptr
      0066BB F9               [12] 2515 	mov	r1,a
      0066BC C3               [12] 2516 	clr	c
      0066BD E5 19            [12] 2517 	mov	a,_control_setup_sloc4_1_0
      0066BF 98               [12] 2518 	subb	a,r0
      0066C0 E5 1A            [12] 2519 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066C2 99               [12] 2520 	subb	a,r1
      0066C3 50 0A            [24] 2521 	jnc	00559$
                                   2522 ;	free result
      0066C5 90 07 80         [24] 2523 	mov	dptr,#_D0SetupLen
      0066C8 E5 19            [12] 2524 	mov	a,_control_setup_sloc4_1_0
      0066CA F0               [24] 2525 	movx	@dptr,a
      0066CB E5 1A            [12] 2526 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066CD A3               [24] 2527 	inc	dptr
      0066CE F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0066CF                       2530 00559$:
      0066CF 75 19 00         [24] 2531 	mov	_control_setup_sloc4_1_0,#0x00
      0066D2                       2532 00296$:
      0066D2 90 07 80         [24] 2533 	mov	dptr,#_D0SetupLen
      0066D5 E0               [24] 2534 	movx	a,@dptr
      0066D6 F8               [12] 2535 	mov	r0,a
      0066D7 C3               [12] 2536 	clr	c
      0066D8 E5 19            [12] 2537 	mov	a,_control_setup_sloc4_1_0
      0066DA 98               [12] 2538 	subb	a,r0
      0066DB 50 46            [24] 2539 	jnc	00263$
      0066DD 85 19 17         [24] 2540 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0066E0 74 10            [12] 2541 	mov	a,#0x10
      0066E2 24 00            [12] 2542 	add	a, #0x00
      0066E4 F5 18            [12] 2543 	mov	(_control_setup_sloc3_1_0 + 1),a
      0066E6 90 07 F0         [24] 2544 	mov	dptr,#_control_setup_offset_10000_290
      0066E9 E0               [24] 2545 	movx	a,@dptr
      0066EA 25 19            [12] 2546 	add	a, _control_setup_sloc4_1_0
      0066EC 24 B0            [12] 2547 	add	a, #_input_snapshot
      0066EE F5 82            [12] 2548 	mov	dpl,a
      0066F0 E4               [12] 2549 	clr	a
      0066F1 34 07            [12] 2550 	addc	a,#(_input_snapshot >> 8)
      0066F3 F5 83            [12] 2551 	mov	dph,a
      0066F5 E0               [24] 2552 	movx	a,@dptr
      0066F6 85 17 82         [24] 2553 	mov	dpl,_control_setup_sloc3_1_0
      0066F9 85 18 83         [24] 2554 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0066FC F0               [24] 2555 	movx	@dptr,a
      0066FD E5 19            [12] 2556 	mov	a,_control_setup_sloc4_1_0
      0066FF 04               [12] 2557 	inc	a
      006700 F5 19            [12] 2558 	mov	_control_setup_sloc4_1_0,a
      006702 80 CE            [24] 2559 	sjmp	00296$
      006704                       2560 00262$:
                                   2561 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006704 BB 01 1C         [24] 2562 	cjne	r3,#0x01,00263$
      006707 BC 00 19         [24] 2563 	cjne	r4,#0x00,00263$
      00670A 90 07 80         [24] 2564 	mov	dptr,#_D0SetupLen
      00670D E0               [24] 2565 	movx	a,@dptr
      00670E F8               [12] 2566 	mov	r0,a
      00670F A3               [24] 2567 	inc	dptr
      006710 E0               [24] 2568 	movx	a,@dptr
      006711 F9               [12] 2569 	mov	r1,a
      006712 C3               [12] 2570 	clr	c
      006713 74 20            [12] 2571 	mov	a,#0x20
      006715 98               [12] 2572 	subb	a,r0
      006716 E4               [12] 2573 	clr	a
      006717 99               [12] 2574 	subb	a,r1
      006718 50 09            [24] 2575 	jnc	00263$
                                   2576 ;	free result
      00671A 90 07 80         [24] 2577 	mov	dptr,#_D0SetupLen
      00671D 74 20            [12] 2578 	mov	a,#0x20
      00671F F0               [24] 2579 	movx	@dptr,a
      006720 E4               [12] 2580 	clr	a
      006721 A3               [24] 2581 	inc	dptr
      006722 F0               [24] 2582 	movx	@dptr,a
      006723                       2583 00263$:
                                   2584 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006723 90 07 80         [24] 2585 	mov	dptr,#_D0SetupLen
      006726 E0               [24] 2586 	movx	a,@dptr
      006727 90 22 08         [24] 2587 	mov	dptr,#0x2208
      00672A F0               [24] 2588 	movx	@dptr,a
                                   2589 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      00672B 90 07 E4         [24] 2590 	mov	dptr,#_control_phase
      00672E 74 02            [12] 2591 	mov	a,#0x02
      006730 F0               [24] 2592 	movx	@dptr,a
      006731 02 67 B9         [24] 2593 	ljmp	00291$
      006734                       2594 00273$:
                                   2595 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006734 EB               [12] 2596 	mov	a,r3
      006735 4C               [12] 2597 	orl	a,r4
      006736 70 37            [24] 2598 	jnz	00265$
      006738 90 07 85         [24] 2599 	mov	dptr,#_D0UsbConfig
      00673B E0               [24] 2600 	movx	a,@dptr
      00673C 60 31            [24] 2601 	jz	00265$
      00673E EA               [12] 2602 	mov	a,r2
      00673F 60 2E            [24] 2603 	jz	00265$
      006741 90 07 7F         [24] 2604 	mov	dptr,#_D0SetupReqCode
      006744 E0               [24] 2605 	movx	a,@dptr
      006745 FA               [12] 2606 	mov	r2,a
      006746 BA 03 26         [24] 2607 	cjne	r2,#0x03,00265$
      006749 30 16 23         [24] 2608 	jnb	_control_setup_zero_value_10000_290,00265$
      00674C 90 07 80         [24] 2609 	mov	dptr,#_D0SetupLen
      00674F E0               [24] 2610 	movx	a,@dptr
      006750 F9               [12] 2611 	mov	r1,a
      006751 A3               [24] 2612 	inc	dptr
      006752 E0               [24] 2613 	movx	a,@dptr
      006753 FA               [12] 2614 	mov	r2,a
      006754 B9 01 18         [24] 2615 	cjne	r1,#0x01,00265$
      006757 BA 00 15         [24] 2616 	cjne	r2,#0x00,00265$
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      00675A 90 0D A9         [24] 2618 	mov	dptr,#_keyboard_protocol
      00675D E0               [24] 2619 	movx	a,@dptr
      00675E 90 10 00         [24] 2620 	mov	dptr,#0x1000
      006761 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006762 90 22 08         [24] 2623 	mov	dptr,#0x2208
      006765 74 01            [12] 2624 	mov	a,#0x01
      006767 F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006768 90 07 E4         [24] 2627 	mov	dptr,#_control_phase
      00676B 04               [12] 2628 	inc	a
      00676C F0               [24] 2629 	movx	@dptr,a
      00676D 80 4A            [24] 2630 	sjmp	00291$
      00676F                       2631 00265$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2633 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      00676F 02 5E 0A         [24] 2634 	ljmp	_control_stall
      006772                       2635 00282$:
                                   2636 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006772 30 14 3E         [24] 2637 	jnb	_control_setup_valid_interface_10000_290,00284$
      006775 90 07 85         [24] 2638 	mov	dptr,#_D0UsbConfig
      006778 E0               [24] 2639 	movx	a,@dptr
      006779 60 38            [24] 2640 	jz	00284$
      00677B BF A1 35         [24] 2641 	cjne	r7,#0xa1,00284$
      00677E 8E 05            [24] 2642 	mov	ar5,r6
      006780 7E 00            [12] 2643 	mov	r6,#0x00
      006782 ED               [12] 2644 	mov	a,r5
      006783 4E               [12] 2645 	orl	a,r6
      006784 70 2D            [24] 2646 	jnz	00284$
      006786 90 07 80         [24] 2647 	mov	dptr,#_D0SetupLen
      006789 E0               [24] 2648 	movx	a,@dptr
      00678A FE               [12] 2649 	mov	r6,a
      00678B A3               [24] 2650 	inc	dptr
      00678C E0               [24] 2651 	movx	a,@dptr
      00678D FF               [12] 2652 	mov	r7,a
      00678E BE 01 22         [24] 2653 	cjne	r6,#0x01,00284$
      006791 BF 00 1F         [24] 2654 	cjne	r7,#0x00,00284$
                                   2655 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006794 EB               [12] 2656 	mov	a,r3
      006795 4C               [12] 2657 	orl	a,r4
      006796 70 07            [24] 2658 	jnz	00324$
      006798 90 06 47         [24] 2659 	mov	dptr,#_keyboard_idle
      00679B E0               [24] 2660 	movx	a,@dptr
      00679C FF               [12] 2661 	mov	r7,a
      00679D 80 02            [24] 2662 	sjmp	00325$
      00679F                       2663 00324$:
      00679F 7F 00            [12] 2664 	mov	r7,#0x00
      0067A1                       2665 00325$:
      0067A1 90 10 00         [24] 2666 	mov	dptr,#0x1000
      0067A4 EF               [12] 2667 	mov	a,r7
      0067A5 F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      0067A6 90 22 08         [24] 2670 	mov	dptr,#0x2208
      0067A9 74 01            [12] 2671 	mov	a,#0x01
      0067AB F0               [24] 2672 	movx	@dptr,a
                                   2673 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      0067AC 90 07 E4         [24] 2674 	mov	dptr,#_control_phase
      0067AF 04               [12] 2675 	inc	a
      0067B0 F0               [24] 2676 	movx	@dptr,a
      0067B1 80 06            [24] 2677 	sjmp	00291$
      0067B3                       2678 00284$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2680 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      0067B3 02 5E 0A         [24] 2681 	ljmp	_control_stall
      0067B6                       2682 00290$:
                                   2683 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      0067B6 02 5E 0A         [24] 2684 	ljmp	_control_stall
      0067B9                       2685 00291$:
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0067B9 90 22 00         [24] 2687 	mov	dptr,#0x2200
      0067BC 74 C0            [12] 2688 	mov	a,#0xc0
      0067BE F0               [24] 2689 	movx	@dptr,a
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      0067BF 22               [24] 2691 	ret
                                   2692 ;------------------------------------------------------------
                                   2693 ;Allocation info for local variables in function 'control_out'
                                   2694 ;------------------------------------------------------------
                                   2695 ;i             Allocated with name '_control_out_i_10000_374'
                                   2696 ;------------------------------------------------------------
                                   2697 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2698 ;	-----------------------------------------
                                   2699 ;	 function control_out
                                   2700 ;	-----------------------------------------
      0067C0                       2701 _control_out:
                                   2702 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0067C0 90 22 0F         [24] 2703 	mov	dptr,#0x220f
      0067C3 E0               [24] 2704 	movx	a,@dptr
      0067C4 20 E6 01         [24] 2705 	jb	acc.6,00102$
      0067C7 22               [24] 2706 	ret
      0067C8                       2707 00102$:
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0067C8 90 07 E4         [24] 2709 	mov	dptr,#_control_phase
      0067CB E0               [24] 2710 	movx	a,@dptr
      0067CC FF               [12] 2711 	mov	r7,a
      0067CD BF 02 12         [24] 2712 	cjne	r7,#0x02,00104$
      0067D0 90 22 0E         [24] 2713 	mov	dptr,#0x220e
      0067D3 E0               [24] 2714 	movx	a,@dptr
      0067D4 70 0C            [24] 2715 	jnz	00104$
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      0067D6 90 07 E4         [24] 2717 	mov	dptr,#_control_phase
      0067D9 E4               [12] 2718 	clr	a
      0067DA F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0067DB 90 22 00         [24] 2721 	mov	dptr,#0x2200
      0067DE 74 02            [12] 2722 	mov	a,#0x02
      0067E0 F0               [24] 2723 	movx	@dptr,a
                                   2724 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      0067E1 22               [24] 2725 	ret
      0067E2                       2726 00104$:
                                   2727 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0067E2 BF 04 19         [24] 2728 	cjne	r7,#0x04,00106$
      0067E5 90 22 0E         [24] 2729 	mov	dptr,#0x220e
      0067E8 E0               [24] 2730 	movx	a,@dptr
      0067E9 FF               [12] 2731 	mov	r7,a
      0067EA 90 07 80         [24] 2732 	mov	dptr,#_D0SetupLen
      0067ED E0               [24] 2733 	movx	a,@dptr
      0067EE FD               [12] 2734 	mov	r5,a
      0067EF A3               [24] 2735 	inc	dptr
      0067F0 E0               [24] 2736 	movx	a,@dptr
      0067F1 FE               [12] 2737 	mov	r6,a
      0067F2 7C 00            [12] 2738 	mov	r4,#0x00
      0067F4 EF               [12] 2739 	mov	a,r7
      0067F5 B5 05 06         [24] 2740 	cjne	a,ar5,00209$
      0067F8 EC               [12] 2741 	mov	a,r4
      0067F9 B5 06 02         [24] 2742 	cjne	a,ar6,00209$
      0067FC 80 03            [24] 2743 	sjmp	00107$
      0067FE                       2744 00209$:
      0067FE                       2745 00106$:
      0067FE 02 5E 0A         [24] 2746 	ljmp	_control_stall
      006801                       2747 00107$:
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006801 90 07 E5         [24] 2749 	mov	dptr,#_output_kind
      006804 E0               [24] 2750 	movx	a,@dptr
      006805 FF               [12] 2751 	mov	r7,a
      006806 BF 01 2E         [24] 2752 	cjne	r7,#0x01,00118$
      006809 90 07 8D         [24] 2753 	mov	dptr,#_raw_state
      00680C E0               [24] 2754 	movx	a,@dptr
      00680D FE               [12] 2755 	mov	r6,a
      00680E BE 01 26         [24] 2756 	cjne	r6,#0x01,00118$
                                   2757 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006811 7E 00            [12] 2758 	mov	r6,#0x00
      006813                       2759 00121$:
      006813 EE               [12] 2760 	mov	a,r6
      006814 24 8E            [12] 2761 	add	a, #_raw_buffer
      006816 FC               [12] 2762 	mov	r4,a
      006817 E4               [12] 2763 	clr	a
      006818 34 07            [12] 2764 	addc	a, #(_raw_buffer >> 8)
      00681A FD               [12] 2765 	mov	r5,a
      00681B 8E 82            [24] 2766 	mov	dpl,r6
      00681D 74 10            [12] 2767 	mov	a,#0x10
      00681F 24 00            [12] 2768 	add	a, #0x00
      006821 F5 83            [12] 2769 	mov	dph,a
      006823 E0               [24] 2770 	movx	a,@dptr
      006824 8C 82            [24] 2771 	mov	dpl,r4
      006826 8D 83            [24] 2772 	mov	dph,r5
      006828 F0               [24] 2773 	movx	@dptr,a
      006829 0E               [12] 2774 	inc	r6
      00682A BE 20 00         [24] 2775 	cjne	r6,#0x20,00214$
      00682D                       2776 00214$:
      00682D 40 E4            [24] 2777 	jc	00121$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00682F 90 07 8D         [24] 2779 	mov	dptr,#_raw_state
      006832 74 02            [12] 2780 	mov	a,#0x02
      006834 F0               [24] 2781 	movx	@dptr,a
      006835 80 2B            [24] 2782 	sjmp	00119$
      006837                       2783 00118$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006837 BF 02 0A         [24] 2785 	cjne	r7,#0x02,00115$
                                   2786 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      00683A 90 10 00         [24] 2787 	mov	dptr,#0x1000
      00683D E0               [24] 2788 	movx	a,@dptr
      00683E 90 07 8A         [24] 2789 	mov	dptr,#_KB_USB_SetReport
      006841 F0               [24] 2790 	movx	@dptr,a
      006842 80 1E            [24] 2791 	sjmp	00119$
      006844                       2792 00115$:
                                   2793 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006844 BF 03 18         [24] 2794 	cjne	r7,#0x03,00111$
      006847 90 10 00         [24] 2795 	mov	dptr,#0x1000
      00684A E0               [24] 2796 	movx	a,@dptr
      00684B FF               [12] 2797 	mov	r7,a
      00684C 90 07 E6         [24] 2798 	mov	dptr,#_output_report_id
      00684F E0               [24] 2799 	movx	a,@dptr
      006850 FE               [12] 2800 	mov	r6,a
      006851 EF               [12] 2801 	mov	a,r7
      006852 B5 06 0A         [24] 2802 	cjne	a,ar6,00111$
                                   2803 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006855 90 10 01         [24] 2804 	mov	dptr,#0x1001
      006858 E0               [24] 2805 	movx	a,@dptr
      006859 90 07 8A         [24] 2806 	mov	dptr,#_KB_USB_SetReport
      00685C F0               [24] 2807 	movx	@dptr,a
      00685D 80 03            [24] 2808 	sjmp	00119$
      00685F                       2809 00111$:
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      00685F 02 5E 0A         [24] 2811 	ljmp	_control_stall
      006862                       2812 00119$:
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006862 90 07 E5         [24] 2814 	mov	dptr,#_output_kind
      006865 E4               [12] 2815 	clr	a
      006866 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006867 90 07 80         [24] 2818 	mov	dptr,#_D0SetupLen
      00686A F0               [24] 2819 	movx	@dptr,a
      00686B A3               [24] 2820 	inc	dptr
      00686C F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      00686D 90 07 E4         [24] 2823 	mov	dptr,#_control_phase
      006870 74 03            [12] 2824 	mov	a,#0x03
      006872 F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006873 90 22 08         [24] 2827 	mov	dptr,#0x2208
      006876 E4               [12] 2828 	clr	a
      006877 F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006878 F5 82            [12] 2831 	mov	dpl,a
      00687A 74 48            [12] 2832 	mov	a,#0x48
      00687C F0               [24] 2833 	movx	@dptr,a
                                   2834 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      00687D 22               [24] 2835 	ret
                                   2836 ;------------------------------------------------------------
                                   2837 ;Allocation info for local variables in function 'control_in'
                                   2838 ;------------------------------------------------------------
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2840 ;	-----------------------------------------
                                   2841 ;	 function control_in
                                   2842 ;	-----------------------------------------
      00687E                       2843 _control_in:
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      00687E 90 07 E4         [24] 2845 	mov	dptr,#_control_phase
      006881 E0               [24] 2846 	movx	a,@dptr
      006882 FF               [12] 2847 	mov	r7,a
      006883 BF 01 22         [24] 2848 	cjne	r7,#0x01,00109$
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006886 90 07 80         [24] 2850 	mov	dptr,#_D0SetupLen
      006889 E0               [24] 2851 	movx	a,@dptr
      00688A FD               [12] 2852 	mov	r5,a
      00688B A3               [24] 2853 	inc	dptr
      00688C E0               [24] 2854 	movx	a,@dptr
      00688D 4D               [12] 2855 	orl	a,r5
      00688E 70 06            [24] 2856 	jnz	00101$
      006890 90 07 E7         [24] 2857 	mov	dptr,#_control_zlp
      006893 E0               [24] 2858 	movx	a,@dptr
      006894 60 0A            [24] 2859 	jz	00102$
      006896                       2860 00101$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006896 90 22 00         [24] 2862 	mov	dptr,#0x2200
      006899 E0               [24] 2863 	movx	a,@dptr
      00689A 64 40            [12] 2864 	xrl	a,#0x40
      00689C F0               [24] 2865 	movx	@dptr,a
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      00689D 02 5E 2C         [24] 2868 	ljmp	_control_next
      0068A0                       2869 00102$:
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      0068A0 90 07 E4         [24] 2871 	mov	dptr,#_control_phase
      0068A3 74 02            [12] 2872 	mov	a,#0x02
      0068A5 F0               [24] 2873 	movx	@dptr,a
      0068A6 80 18            [24] 2874 	sjmp	00110$
      0068A8                       2875 00109$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      0068A8 BF 03 15         [24] 2877 	cjne	r7,#0x03,00110$
                                   2878 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0068AB 90 07 7F         [24] 2879 	mov	dptr,#_D0SetupReqCode
      0068AE E0               [24] 2880 	movx	a,@dptr
      0068AF FF               [12] 2881 	mov	r7,a
      0068B0 BF 05 08         [24] 2882 	cjne	r7,#0x05,00105$
      0068B3 90 07 80         [24] 2883 	mov	dptr,#_D0SetupLen
      0068B6 E0               [24] 2884 	movx	a,@dptr
      0068B7 90 22 07         [24] 2885 	mov	dptr,#0x2207
      0068BA F0               [24] 2886 	movx	@dptr,a
      0068BB                       2887 00105$:
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      0068BB 90 07 E4         [24] 2889 	mov	dptr,#_control_phase
      0068BE E4               [12] 2890 	clr	a
      0068BF F0               [24] 2891 	movx	@dptr,a
      0068C0                       2892 00110$:
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068C0 90 22 00         [24] 2894 	mov	dptr,#0x2200
      0068C3 74 82            [12] 2895 	mov	a,#0x82
      0068C5 F0               [24] 2896 	movx	@dptr,a
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      0068C6 22               [24] 2898 	ret
                                   2899 ;------------------------------------------------------------
                                   2900 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2901 ;------------------------------------------------------------
                                   2902 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_398'
                                   2903 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_398'
                                   2904 ;------------------------------------------------------------
                                   2905 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2906 ;	-----------------------------------------
                                   2907 ;	 function USB_DeviceInterrupt
                                   2908 ;	-----------------------------------------
      0068C7                       2909 _USB_DeviceInterrupt:
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      0068C7                       2911 00129$:
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      0068C7 90 22 3D         [24] 2913 	mov	dptr,#0x223d
      0068CA E0               [24] 2914 	movx	a,@dptr
      0068CB 30 E0 4B         [24] 2915 	jnb	acc.0,00127$
                                   2916 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      0068CE 12 5D A9         [24] 2917 	lcall	_endpoints_reset
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      0068D1 90 22 07         [24] 2919 	mov	dptr,#0x2207
      0068D4 E4               [12] 2920 	clr	a
      0068D5 F0               [24] 2921 	movx	@dptr,a
                                   2922 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0068D6 90 07 87         [24] 2923 	mov	dptr,#_USB_SleepStatus
      0068D9 F0               [24] 2924 	movx	@dptr,a
      0068DA 90 07 86         [24] 2925 	mov	dptr,#_USB_EnumStatus
      0068DD F0               [24] 2926 	movx	@dptr,a
      0068DE 90 07 85         [24] 2927 	mov	dptr,#_D0UsbConfig
      0068E1 F0               [24] 2928 	movx	@dptr,a
                                   2929 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      0068E2 90 07 8A         [24] 2930 	mov	dptr,#_KB_USB_SetReport
      0068E5 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      0068E6 90 0D A9         [24] 2933 	mov	dptr,#_keyboard_protocol
      0068E9 04               [12] 2934 	inc	a
      0068EA F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      0068EB 90 06 47         [24] 2937 	mov	dptr,#_keyboard_idle
      0068EE E4               [12] 2938 	clr	a
      0068EF F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      0068F0 90 07 AF         [24] 2941 	mov	dptr,#_keyboard_reset
      0068F3 04               [12] 2942 	inc	a
      0068F4 F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      0068F5 90 07 7F         [24] 2945 	mov	dptr,#_D0SetupReqCode
      0068F8 74 FF            [12] 2946 	mov	a,#0xff
      0068FA F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      0068FB 90 07 80         [24] 2949 	mov	dptr,#_D0SetupLen
      0068FE E4               [12] 2950 	clr	a
      0068FF F0               [24] 2951 	movx	@dptr,a
      006900 A3               [24] 2952 	inc	dptr
      006901 F0               [24] 2953 	movx	@dptr,a
                                   2954 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006902 90 07 E4         [24] 2955 	mov	dptr,#_control_phase
      006905 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006906 90 22 00         [24] 2958 	mov	dptr,#0x2200
      006909 74 02            [12] 2959 	mov	a,#0x02
      00690B F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      00690C 90 22 0F         [24] 2962 	mov	dptr,#0x220f
      00690F E4               [12] 2963 	clr	a
      006910 F0               [24] 2964 	movx	@dptr,a
                                   2965 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006911 90 22 3D         [24] 2966 	mov	dptr,#0x223d
      006914 04               [12] 2967 	inc	a
      006915 F0               [24] 2968 	movx	@dptr,a
      006916 02 69 B1         [24] 2969 	ljmp	00130$
      006919                       2970 00127$:
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006919 90 22 3D         [24] 2972 	mov	dptr,#0x223d
      00691C E0               [24] 2973 	movx	a,@dptr
      00691D 30 E5 60         [24] 2974 	jnb	acc.5,00124$
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006920 90 22 0F         [24] 2976 	mov	dptr,#0x220f
      006923 E0               [24] 2977 	movx	a,@dptr
      006924 FF               [12] 2978 	mov	r7,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006925 74 07            [12] 2980 	mov	a,#0x07
      006927 5F               [12] 2981 	anl	a,r7
      006928 FE               [12] 2982 	mov	r6,a
                                   2983 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006929 EF               [12] 2984 	mov	a,r7
      00692A 54 18            [12] 2985 	anl	a,#0x18
      00692C 70 08            [24] 2986 	jnz	00115$
      00692E EE               [12] 2987 	mov	a,r6
      00692F 70 05            [24] 2988 	jnz	00115$
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006931 12 67 C0         [24] 2990 	lcall	_control_out
      006934 80 43            [24] 2991 	sjmp	00116$
      006936                       2992 00115$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006936 8F 05            [24] 2994 	mov	ar5,r7
      006938 74 18            [12] 2995 	mov	a,#0x18
      00693A 5D               [12] 2996 	anl	a,r5
      00693B FC               [12] 2997 	mov	r4,a
      00693C BC 10 2D         [24] 2998 	cjne	r4,#0x10,00112$
                                   2999 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      00693F EE               [12] 3000 	mov	a,r6
      006940 70 05            [24] 3001 	jnz	00106$
      006942 12 68 7E         [24] 3002 	lcall	_control_in
      006945 80 32            [24] 3003 	sjmp	00116$
      006947                       3004 00106$:
                                   3005 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006947 EE               [12] 3006 	mov	a,r6
      006948 24 FC            [12] 3007 	add	a,#0xff - 0x03
      00694A 40 2D            [24] 3008 	jc	00116$
                                   3009 ;	free result
                                   3010 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00694C 8E 04            [24] 3011 	mov	ar4,r6
      00694E 7B 00            [12] 3012 	mov	r3,#0x00
      006950 74 22            [12] 3013 	mov	a,#0x22
      006952 2B               [12] 3014 	add	a, r3
      006953 FB               [12] 3015 	mov	r3,a
      006954 8C 82            [24] 3016 	mov	dpl,r4
      006956 8B 83            [24] 3017 	mov	dph,r3
      006958 E0               [24] 3018 	movx	a,@dptr
      006959 FA               [12] 3019 	mov	r2,a
      00695A 74 FC            [12] 3020 	mov	a,#0xfc
      00695C 5A               [12] 3021 	anl	a,r2
      00695D 44 02            [12] 3022 	orl	a,#0x02
      00695F 8C 82            [24] 3023 	mov	dpl,r4
      006961 8B 83            [24] 3024 	mov	dph,r3
      006963 F0               [24] 3025 	movx	@dptr,a
                                   3026 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006964 BE 03 12         [24] 3027 	cjne	r6,#0x03,00116$
      006967 12 5D 8C         [24] 3028 	lcall	_raw_complete
      00696A 80 0D            [24] 3029 	sjmp	00116$
      00696C                       3030 00112$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00696C 53 05 18         [24] 3032 	anl	ar5,#0x18
      00696F BD 18 07         [24] 3033 	cjne	r5,#0x18,00116$
      006972 EF               [12] 3034 	mov	a,r7
      006973 30 E5 03         [24] 3035 	jnb	acc.5,00116$
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006976 12 60 23         [24] 3037 	lcall	_control_setup
      006979                       3038 00116$:
                                   3039 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006979 90 22 0F         [24] 3040 	mov	dptr,#0x220f
      00697C E4               [12] 3041 	clr	a
      00697D F0               [24] 3042 	movx	@dptr,a
      00697E 80 31            [24] 3043 	sjmp	00130$
      006980                       3044 00124$:
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006980 90 22 3D         [24] 3046 	mov	dptr,#0x223d
      006983 E0               [24] 3047 	movx	a,@dptr
      006984 30 E2 2A         [24] 3048 	jnb	acc.2,00130$
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006987 90 05 9A         [24] 3050 	mov	dptr,#_ak820_os_indicator_mode
      00698A E4               [12] 3051 	clr	a
      00698B F0               [24] 3052 	movx	@dptr,a
                                   3053 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      00698C 90 22 3D         [24] 3054 	mov	dptr,#0x223d
      00698F E0               [24] 3055 	movx	a,@dptr
      006990 30 E3 0A         [24] 3056 	jnb	acc.3,00119$
      006993 90 07 87         [24] 3057 	mov	dptr,#_USB_SleepStatus
      006996 E0               [24] 3058 	movx	a,@dptr
      006997 43 E0 02         [24] 3059 	orl	acc,#0x02
      00699A F0               [24] 3060 	movx	@dptr,a
      00699B 80 0E            [24] 3061 	sjmp	00120$
      00699D                       3062 00119$:
                                   3063 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      00699D 90 07 87         [24] 3064 	mov	dptr,#_USB_SleepStatus
      0069A0 E0               [24] 3065 	movx	a,@dptr
      0069A1 53 E0 FD         [24] 3066 	anl	acc,#0xfd
      0069A4 F0               [24] 3067 	movx	@dptr,a
                                   3068 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      0069A5 90 07 AF         [24] 3069 	mov	dptr,#_keyboard_reset
      0069A8 74 01            [12] 3070 	mov	a,#0x01
      0069AA F0               [24] 3071 	movx	@dptr,a
      0069AB                       3072 00120$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      0069AB 90 22 3D         [24] 3074 	mov	dptr,#0x223d
      0069AE 74 04            [12] 3075 	mov	a,#0x04
      0069B0 F0               [24] 3076 	movx	@dptr,a
      0069B1                       3077 00130$:
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      0069B1 90 22 3D         [24] 3079 	mov	dptr,#0x223d
      0069B4 E0               [24] 3080 	movx	a,@dptr
      0069B5 54 25            [12] 3081 	anl	a,#0x25
      0069B7 60 03            [24] 3082 	jz	00242$
      0069B9 02 68 C7         [24] 3083 	ljmp	00129$
      0069BC                       3084 00242$:
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      0069BC 22               [24] 3086 	ret
                                   3087 ;------------------------------------------------------------
                                   3088 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3089 ;------------------------------------------------------------
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3091 ;	-----------------------------------------
                                   3092 ;	 function USB_Device_Init
                                   3093 ;	-----------------------------------------
      0069BD                       3094 _USB_Device_Init:
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3096 ;	assignBit
      0069BD C2 E9            [12] 3097 	clr	_IE_USB
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      0069BF 90 22 3C         [24] 3099 	mov	dptr,#0x223c
      0069C2 E4               [12] 3100 	clr	a
      0069C3 F0               [24] 3101 	movx	@dptr,a
                                   3102 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      0069C4 90 07 8D         [24] 3103 	mov	dptr,#_raw_state
      0069C7 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      0069C8 12 5D A9         [24] 3106 	lcall	_endpoints_reset
                                   3107 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0069CB 90 07 87         [24] 3108 	mov	dptr,#_USB_SleepStatus
      0069CE E4               [12] 3109 	clr	a
      0069CF F0               [24] 3110 	movx	@dptr,a
      0069D0 90 07 86         [24] 3111 	mov	dptr,#_USB_EnumStatus
      0069D3 F0               [24] 3112 	movx	@dptr,a
      0069D4 90 07 85         [24] 3113 	mov	dptr,#_D0UsbConfig
      0069D7 F0               [24] 3114 	movx	@dptr,a
      0069D8 90 22 07         [24] 3115 	mov	dptr,#0x2207
      0069DB F0               [24] 3116 	movx	@dptr,a
                                   3117 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0069DC 90 07 88         [24] 3118 	mov	dptr,#_MCU_Sleep_Operate
      0069DF F0               [24] 3119 	movx	@dptr,a
      0069E0 90 07 89         [24] 3120 	mov	dptr,#_KB_USB_UpStatus
      0069E3 F0               [24] 3121 	movx	@dptr,a
      0069E4 90 07 8A         [24] 3122 	mov	dptr,#_KB_USB_SetReport
      0069E7 F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      0069E8 90 0D A9         [24] 3125 	mov	dptr,#_keyboard_protocol
      0069EB 04               [12] 3126 	inc	a
      0069EC F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      0069ED 90 06 47         [24] 3129 	mov	dptr,#_keyboard_idle
      0069F0 E4               [12] 3130 	clr	a
      0069F1 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      0069F2 90 07 AF         [24] 3133 	mov	dptr,#_keyboard_reset
      0069F5 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      0069F6 90 07 E4         [24] 3136 	mov	dptr,#_control_phase
      0069F9 F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      0069FA 90 07 7F         [24] 3139 	mov	dptr,#_D0SetupReqCode
      0069FD 14               [12] 3140 	dec	a
      0069FE F0               [24] 3141 	movx	@dptr,a
                                   3142 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      0069FF 90 07 80         [24] 3143 	mov	dptr,#_D0SetupLen
      006A02 E4               [12] 3144 	clr	a
      006A03 F0               [24] 3145 	movx	@dptr,a
      006A04 A3               [24] 3146 	inc	dptr
      006A05 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A06 90 22 00         [24] 3149 	mov	dptr,#0x2200
      006A09 74 02            [12] 3150 	mov	a,#0x02
      006A0B F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006A0C 90 22 37         [24] 3153 	mov	dptr,#0x2237
      006A0F 74 7F            [12] 3154 	mov	a,#0x7f
      006A11 F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006A12 90 22 3D         [24] 3157 	mov	dptr,#0x223d
      006A15 74 FF            [12] 3158 	mov	a,#0xff
      006A17 F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006A18 90 22 3B         [24] 3161 	mov	dptr,#0x223b
      006A1B 74 07            [12] 3162 	mov	a,#0x07
      006A1D F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006A1E A3               [24] 3165 	inc	dptr
      006A1F 74 80            [12] 3166 	mov	a,#0x80
      006A21 F0               [24] 3167 	movx	@dptr,a
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3169 ;	assignBit
      006A22 D2 E9            [12] 3170 	setb	_IE_USB
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006A24 22               [24] 3172 	ret
                                   3173 ;------------------------------------------------------------
                                   3174 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3175 ;------------------------------------------------------------
                                   3176 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_421'
                                   3177 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_424'
                                   3178 ;------------------------------------------------------------
                                   3179 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3180 ;	-----------------------------------------
                                   3181 ;	 function USB_WakeUp_PC
                                   3182 ;	-----------------------------------------
      006A25                       3183 _USB_WakeUp_PC:
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006A25 90 07 87         [24] 3185 	mov	dptr,#_USB_SleepStatus
      006A28 E0               [24] 3186 	movx	a,@dptr
      006A29 FF               [12] 3187 	mov	r7,a
      006A2A BF 03 22         [24] 3188 	cjne	r7,#0x03,00110$
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006A2D 90 22 3C         [24] 3190 	mov	dptr,#0x223c
      006A30 E0               [24] 3191 	movx	a,@dptr
      006A31 FF               [12] 3192 	mov	r7,a
                                   3193 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006A32 E0               [24] 3194 	movx	a,@dptr
      006A33 FE               [12] 3195 	mov	r6,a
      006A34 63 06 C0         [24] 3196 	xrl	ar6,#0xc0
      006A37 90 22 3C         [24] 3197 	mov	dptr,#0x223c
      006A3A EE               [12] 3198 	mov	a,r6
      006A3B F0               [24] 3199 	movx	@dptr,a
                                   3200 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006A3C 7E 0A            [12] 3201 	mov	r6,#0x0a
      006A3E                       3202 00108$:
      006A3E EE               [12] 3203 	mov	a,r6
      006A3F 60 09            [24] 3204 	jz	00105$
      006A41 90 00 01         [24] 3205 	mov	dptr,#0x0001
      006A44 12 5B F0         [24] 3206 	lcall	_mDelaymS
      006A47 1E               [12] 3207 	dec	r6
      006A48 80 F4            [24] 3208 	sjmp	00108$
      006A4A                       3209 00105$:
                                   3210 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006A4A 90 22 3C         [24] 3211 	mov	dptr,#0x223c
      006A4D EF               [12] 3212 	mov	a,r7
      006A4E F0               [24] 3213 	movx	@dptr,a
      006A4F                       3214 00110$:
                                   3215 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006A4F 22               [24] 3216 	ret
                                   3217 ;------------------------------------------------------------
                                   3218 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3219 ;------------------------------------------------------------
                                   3220 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3221 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3222 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3223 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3224 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_426'
                                   3225 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_427'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_10000_427'
                                   3227 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_427'
                                   3228 ;offset        Allocated with name '_ak820_usb_send_offset_10000_427'
                                   3229 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_427'
                                   3230 ;i             Allocated with name '_ak820_usb_send_i_30000_439'
                                   3231 ;------------------------------------------------------------
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3233 ;	-----------------------------------------
                                   3234 ;	 function ak820_usb_send
                                   3235 ;	-----------------------------------------
      006A50                       3236 _ak820_usb_send:
      006A50 E5 82            [12] 3237 	mov	a,dpl
      006A52 90 07 F4         [24] 3238 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006A55 F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006A56 90 07 F5         [24] 3241 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006A59 74 34            [12] 3242 	mov	a,#0x34
      006A5B F0               [24] 3243 	movx	@dptr,a
                                   3244 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A5C 90 07 F4         [24] 3245 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006A5F E0               [24] 3246 	movx	a,@dptr
      006A60 FF               [12] 3247 	mov	r7,a
      006A61 BF 01 00         [24] 3248 	cjne	r7,#0x01,00306$
      006A64                       3249 00306$:
      006A64 40 14            [24] 3250 	jc	00101$
      006A66 EF               [12] 3251 	mov	a,r7
      006A67 24 FC            [12] 3252 	add	a,#0xff - 0x03
      006A69 40 0F            [24] 3253 	jc	00101$
                                   3254 ;	free result
      006A6B 90 07 F3         [24] 3255 	mov	dptr,#_ak820_usb_send_PARM_3
      006A6E E0               [24] 3256 	movx	a,@dptr
      006A6F FE               [12] 3257 	mov  r6,a
      006A70 24 BF            [12] 3258 	add	a,#0xff - 0x40
      006A72 40 06            [24] 3259 	jc	00101$
                                   3260 ;	free result
      006A74 90 07 86         [24] 3261 	mov	dptr,#_USB_EnumStatus
      006A77 E0               [24] 3262 	movx	a,@dptr
      006A78 70 04            [24] 3263 	jnz	00102$
      006A7A                       3264 00101$:
      006A7A 75 82 00         [24] 3265 	mov	dpl, #0x00
      006A7D 22               [24] 3266 	ret
      006A7E                       3267 00102$:
                                   3268 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006A7E BF 01 10         [24] 3269 	cjne	r7,#0x01,00118$
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006A81 BE 08 02         [24] 3271 	cjne	r6,#0x08,00313$
      006A84 80 04            [24] 3272 	sjmp	00107$
      006A86                       3273 00313$:
      006A86 75 82 00         [24] 3274 	mov	dpl, #0x00
      006A89 22               [24] 3275 	ret
      006A8A                       3276 00107$:
                                   3277 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006A8A 90 07 F5         [24] 3278 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006A8D E4               [12] 3279 	clr	a
      006A8E F0               [24] 3280 	movx	@dptr,a
      006A8F 80 3C            [24] 3281 	sjmp	00119$
      006A91                       3282 00118$:
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006A91 BF 02 30         [24] 3284 	cjne	r7,#0x02,00115$
                                   3285 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006A94 90 07 F1         [24] 3286 	mov	dptr,#_ak820_usb_send_PARM_2
      006A97 E0               [24] 3287 	movx	a,@dptr
      006A98 FD               [12] 3288 	mov	r5,a
      006A99 A3               [24] 3289 	inc	dptr
      006A9A E0               [24] 3290 	movx	a,@dptr
      006A9B FF               [12] 3291 	mov	r7,a
      006A9C 8D 82            [24] 3292 	mov	dpl,r5
      006A9E 8F 83            [24] 3293 	mov	dph,r7
      006AA0 E0               [24] 3294 	movx	a,@dptr
      006AA1 FF               [12] 3295 	mov	r7,a
                                   3296 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006AA2 BF 07 00         [24] 3297 	cjne	r7,#0x07,00316$
      006AA5                       3298 00316$:
      006AA5 50 0E            [24] 3299 	jnc	00108$
      006AA7 EF               [12] 3300 	mov	a,r7
      006AA8 90 BB 71         [24] 3301 	mov	dptr,#_shared_lengths
      006AAB 93               [24] 3302 	movc	a,@a+dptr
      006AAC FD               [12] 3303 	mov	r5,a
      006AAD 60 06            [24] 3304 	jz	00108$
      006AAF EE               [12] 3305 	mov	a,r6
      006AB0 B5 05 02         [24] 3306 	cjne	a,ar5,00319$
      006AB3 80 04            [24] 3307 	sjmp	00109$
      006AB5                       3308 00319$:
      006AB5                       3309 00108$:
      006AB5 75 82 00         [24] 3310 	mov	dpl, #0x00
      006AB8 22               [24] 3311 	ret
      006AB9                       3312 00109$:
                                   3313 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006AB9 EF               [12] 3314 	mov	a,r7
      006ABA 90 BB 6A         [24] 3315 	mov	dptr,#_shared_offsets
      006ABD 93               [24] 3316 	movc	a,@a+dptr
      006ABE 90 07 F5         [24] 3317 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006AC1 F0               [24] 3318 	movx	@dptr,a
      006AC2 80 09            [24] 3319 	sjmp	00119$
      006AC4                       3320 00115$:
                                   3321 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006AC4 BE 20 02         [24] 3322 	cjne	r6,#0x20,00320$
      006AC7 80 04            [24] 3323 	sjmp	00119$
      006AC9                       3324 00320$:
      006AC9 75 82 00         [24] 3325 	mov	dpl, #0x00
      006ACC 22               [24] 3326 	ret
      006ACD                       3327 00119$:
                                   3328 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006ACD 90 07 87         [24] 3329 	mov	dptr,#_USB_SleepStatus
      006AD0 E0               [24] 3330 	movx	a,@dptr
      006AD1 30 E1 07         [24] 3331 	jnb	acc.1,00184$
      006AD4 12 6A 25         [24] 3332 	lcall	_USB_WakeUp_PC
      006AD7 75 82 00         [24] 3333 	mov	dpl, #0x00
      006ADA 22               [24] 3334 	ret
                                   3335 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006ADB                       3336 00184$:
      006ADB 7F FA            [12] 3337 	mov	r7,#0xfa
      006ADD                       3338 00127$:
      006ADD 90 07 F4         [24] 3339 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006AE0 E0               [24] 3340 	movx	a,@dptr
      006AE1 FC               [12] 3341 	mov	r4,a
      006AE2 7D 00            [12] 3342 	mov	r5,#0x00
      006AE4 8C 02            [24] 3343 	mov	ar2,r4
      006AE6 74 22            [12] 3344 	mov	a,#0x22
      006AE8 2D               [12] 3345 	add	a, r5
      006AE9 FB               [12] 3346 	mov	r3,a
      006AEA 8A 82            [24] 3347 	mov	dpl,r2
      006AEC 8B 83            [24] 3348 	mov	dph,r3
      006AEE E0               [24] 3349 	movx	a,@dptr
      006AEF 54 03            [12] 3350 	anl	a,#0x03
      006AF1 70 14            [24] 3351 	jnz	00129$
      006AF3 8F 03            [24] 3352 	mov	ar3,r7
      006AF5 1F               [12] 3353 	dec	r7
      006AF6 EB               [12] 3354 	mov	a,r3
      006AF7 60 0E            [24] 3355 	jz	00129$
      006AF9 7B 28            [12] 3356 	mov	r3,#0x28
      006AFB                       3357 00141$:
      006AFB EB               [12] 3358 	mov	a,r3
      006AFC 60 DF            [24] 3359 	jz	00127$
      006AFE 90 00 01         [24] 3360 	mov	dptr,#0x0001
      006B01 12 5B AC         [24] 3361 	lcall	_mDelayuS
      006B04 1B               [12] 3362 	dec	r3
      006B05 80 F4            [24] 3363 	sjmp	00141$
      006B07                       3364 00129$:
                                   3365 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006B07 A2 AF            [12] 3366 	mov	c,_EA
      006B09 E4               [12] 3367 	clr	a
      006B0A 33               [12] 3368 	rlc	a
      006B0B FF               [12] 3369 	mov	r7,a
                                   3370 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3371 ;	assignBit
      006B0C C2 AF            [12] 3372 	clr	_EA
                                   3373 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006B0E 90 07 86         [24] 3374 	mov	dptr,#_USB_EnumStatus
      006B11 E0               [24] 3375 	movx	a,@dptr
      006B12 60 25            [24] 3376 	jz	00130$
      006B14 90 07 F4         [24] 3377 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006B17 E0               [24] 3378 	movx	a,@dptr
      006B18 FB               [12] 3379 	mov	r3,a
      006B19 F9               [12] 3380 	mov	r1,a
      006B1A 7A 00            [12] 3381 	mov	r2,#0x00
      006B1C 74 22            [12] 3382 	mov	a,#0x22
      006B1E 2A               [12] 3383 	add	a, r2
      006B1F FA               [12] 3384 	mov	r2,a
      006B20 89 82            [24] 3385 	mov	dpl,r1
      006B22 8A 83            [24] 3386 	mov	dph,r2
      006B24 E0               [24] 3387 	movx	a,@dptr
      006B25 FA               [12] 3388 	mov	r2,a
      006B26 53 02 03         [24] 3389 	anl	ar2,#0x03
      006B29 BA 02 0D         [24] 3390 	cjne	r2,#0x02,00130$
                                   3391 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006B2C BB 03 13         [24] 3392 	cjne	r3,#0x03,00192$
      006B2F 90 07 8D         [24] 3393 	mov	dptr,#_raw_state
      006B32 E0               [24] 3394 	movx	a,@dptr
      006B33 FB               [12] 3395 	mov	r3,a
      006B34 BB 03 02         [24] 3396 	cjne	r3,#0x03,00331$
      006B37 80 09            [24] 3397 	sjmp	00192$
      006B39                       3398 00331$:
      006B39                       3399 00130$:
                                   3400 ;	assignBit
      006B39 EF               [12] 3401 	mov	a,r7
      006B3A 24 FF            [12] 3402 	add	a,#0xff
      006B3C 92 AF            [24] 3403 	mov	_EA,c
      006B3E 75 82 00         [24] 3404 	mov	dpl, #0x00
      006B41 22               [24] 3405 	ret
                                   3406 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B42                       3407 00192$:
      006B42 7B 00            [12] 3408 	mov	r3,#0x00
      006B44                       3409 00144$:
      006B44 C3               [12] 3410 	clr	c
      006B45 EB               [12] 3411 	mov	a,r3
      006B46 9E               [12] 3412 	subb	a,r6
      006B47 50 67            [24] 3413 	jnc	00137$
                                   3414 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B49 C0 07            [24] 3415 	push	ar7
      006B4B 90 07 F4         [24] 3416 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006B4E E0               [24] 3417 	movx	a,@dptr
      006B4F F9               [12] 3418 	mov	r1,a
      006B50 E4               [12] 3419 	clr	a
      006B51 C3               [12] 3420 	clr	c
      006B52 C9               [12] 3421 	xch	a,r1
      006B53 13               [12] 3422 	rrc	a
      006B54 C9               [12] 3423 	xch	a,r1
      006B55 13               [12] 3424 	rrc	a
      006B56 A2 E0            [12] 3425 	mov	c,acc.0
      006B58 C9               [12] 3426 	xch	a,r1
      006B59 13               [12] 3427 	rrc	a
      006B5A C9               [12] 3428 	xch	a,r1
      006B5B 13               [12] 3429 	rrc	a
      006B5C C9               [12] 3430 	xch	a,r1
      006B5D FA               [12] 3431 	mov	r2,a
      006B5E 8B 00            [24] 3432 	mov	ar0,r3
      006B60 7F 00            [12] 3433 	mov	r7,#0x00
      006B62 E8               [12] 3434 	mov	a,r0
      006B63 29               [12] 3435 	add	a, r1
      006B64 F9               [12] 3436 	mov	r1,a
      006B65 EF               [12] 3437 	mov	a,r7
      006B66 3A               [12] 3438 	addc	a, r2
      006B67 24 10            [12] 3439 	add	a,#0x10
      006B69 FA               [12] 3440 	mov	r2,a
      006B6A 90 07 F1         [24] 3441 	mov	dptr,#_ak820_usb_send_PARM_2
      006B6D E0               [24] 3442 	movx	a,@dptr
      006B6E F8               [12] 3443 	mov	r0,a
      006B6F A3               [24] 3444 	inc	dptr
      006B70 E0               [24] 3445 	movx	a,@dptr
      006B71 FF               [12] 3446 	mov	r7,a
      006B72 EB               [12] 3447 	mov	a,r3
      006B73 28               [12] 3448 	add	a, r0
      006B74 F5 1B            [12] 3449 	mov	_ak820_usb_send_sloc0_1_0,a
      006B76 E4               [12] 3450 	clr	a
      006B77 3F               [12] 3451 	addc	a, r7
      006B78 F5 1C            [12] 3452 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006B7A 85 1B 82         [24] 3453 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B7D 85 1C 83         [24] 3454 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B80 E0               [24] 3455 	movx	a,@dptr
      006B81 89 82            [24] 3456 	mov	dpl,r1
      006B83 8A 83            [24] 3457 	mov	dph,r2
      006B85 F0               [24] 3458 	movx	@dptr,a
                                   3459 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006B86 90 07 F5         [24] 3460 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006B89 E0               [24] 3461 	movx	a,@dptr
      006B8A F5 1D            [12] 3462 	mov	_ak820_usb_send_sloc1_1_0,a
      006B8C 74 34            [12] 3463 	mov	a,#0x34
      006B8E B5 1D 04         [24] 3464 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006B91 D0 07            [24] 3465 	pop	ar7
      006B93 80 18            [24] 3466 	sjmp	00145$
      006B95                       3467 00333$:
      006B95 D0 07            [24] 3468 	pop	ar7
      006B97 EB               [12] 3469 	mov	a,r3
      006B98 25 1D            [12] 3470 	add	a, _ak820_usb_send_sloc1_1_0
      006B9A 24 B0            [12] 3471 	add	a, #_input_snapshot
      006B9C F9               [12] 3472 	mov	r1,a
      006B9D E4               [12] 3473 	clr	a
      006B9E 34 07            [12] 3474 	addc	a,#(_input_snapshot >> 8)
      006BA0 FA               [12] 3475 	mov	r2,a
      006BA1 85 1B 82         [24] 3476 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BA4 85 1C 83         [24] 3477 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BA7 E0               [24] 3478 	movx	a,@dptr
      006BA8 89 82            [24] 3479 	mov	dpl,r1
      006BAA 8A 83            [24] 3480 	mov	dph,r2
      006BAC F0               [24] 3481 	movx	@dptr,a
      006BAD                       3482 00145$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006BAD 0B               [12] 3484 	inc	r3
      006BAE 80 94            [24] 3485 	sjmp	00144$
      006BB0                       3486 00137$:
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006BB0 90 07 F4         [24] 3488 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006BB3 E0               [24] 3489 	movx	a,@dptr
      006BB4 FB               [12] 3490 	mov	r3,a
      006BB5 F9               [12] 3491 	mov	r1,a
      006BB6 7A 00            [12] 3492 	mov	r2,#0x00
      006BB8 74 08            [12] 3493 	mov	a,#0x08
      006BBA 29               [12] 3494 	add	a, r1
      006BBB F9               [12] 3495 	mov	r1,a
      006BBC 74 22            [12] 3496 	mov	a,#0x22
      006BBE 3A               [12] 3497 	addc	a, r2
      006BBF FA               [12] 3498 	mov	r2,a
      006BC0 89 82            [24] 3499 	mov	dpl,r1
      006BC2 8A 83            [24] 3500 	mov	dph,r2
      006BC4 EE               [12] 3501 	mov	a,r6
      006BC5 F0               [24] 3502 	movx	@dptr,a
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006BC6 BB 03 06         [24] 3504 	cjne	r3,#0x03,00139$
      006BC9 90 07 8D         [24] 3505 	mov	dptr,#_raw_state
      006BCC 74 04            [12] 3506 	mov	a,#0x04
      006BCE F0               [24] 3507 	movx	@dptr,a
      006BCF                       3508 00139$:
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006BCF 74 22            [12] 3510 	mov	a,#0x22
      006BD1 2D               [12] 3511 	add	a, r5
      006BD2 FD               [12] 3512 	mov	r5,a
      006BD3 8C 82            [24] 3513 	mov	dpl,r4
      006BD5 8D 83            [24] 3514 	mov	dph,r5
      006BD7 E0               [24] 3515 	movx	a,@dptr
      006BD8 FE               [12] 3516 	mov	r6,a
      006BD9 53 06 FC         [24] 3517 	anl	ar6,#0xfc
      006BDC 8C 82            [24] 3518 	mov	dpl,r4
      006BDE 8D 83            [24] 3519 	mov	dph,r5
      006BE0 EE               [12] 3520 	mov	a,r6
      006BE1 F0               [24] 3521 	movx	@dptr,a
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3523 ;	assignBit
      006BE2 EF               [12] 3524 	mov	a,r7
      006BE3 24 FF            [12] 3525 	add	a,#0xff
      006BE5 92 AF            [24] 3526 	mov	_EA,c
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006BE7 75 82 01         [24] 3528 	mov	dpl, #0x01
                                   3529 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006BEA 22               [24] 3530 	ret
                                   3531 ;------------------------------------------------------------
                                   3532 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3533 ;------------------------------------------------------------
                                   3534 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3535 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3536 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_447'
                                   3537 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_448'
                                   3538 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_448'
                                   3539 ;------------------------------------------------------------
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3541 ;	-----------------------------------------
                                   3542 ;	 function ak820_usb_try_send
                                   3543 ;	-----------------------------------------
      006BEB                       3544 _ak820_usb_try_send:
      006BEB E5 82            [12] 3545 	mov	a,dpl
      006BED 90 07 F9         [24] 3546 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006BF0 F0               [24] 3547 	movx	@dptr,a
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3549 ;	assignBit
      006BF1 A2 AF            [12] 3550 	mov	c,_EA
      006BF3 92 1A            [24] 3551 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006BF5 90 07 FA         [24] 3553 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006BF8 E4               [12] 3554 	clr	a
      006BF9 F0               [24] 3555 	movx	@dptr,a
                                   3556 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3557 ;	assignBit
      006BFA C2 AF            [12] 3558 	clr	_EA
                                   3559 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006BFC 90 07 F9         [24] 3560 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006BFF E0               [24] 3561 	movx	a,@dptr
      006C00 FF               [12] 3562 	mov	r7,a
      006C01 BF 01 00         [24] 3563 	cjne	r7,#0x01,00152$
      006C04                       3564 00152$:
      006C04 40 4E            [24] 3565 	jc	00102$
      006C06 EF               [12] 3566 	mov	a,r7
      006C07 24 FD            [12] 3567 	add	a,#0xff - 0x02
      006C09 40 49            [24] 3568 	jc	00102$
                                   3569 ;	free result
      006C0B 90 07 86         [24] 3570 	mov	dptr,#_USB_EnumStatus
      006C0E E0               [24] 3571 	movx	a,@dptr
      006C0F 60 43            [24] 3572 	jz	00102$
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006C11 90 07 87         [24] 3574 	mov	dptr,#_USB_SleepStatus
      006C14 E0               [24] 3575 	movx	a,@dptr
      006C15 20 E1 3C         [24] 3576 	jb	acc.1,00102$
      006C18 90 07 AF         [24] 3577 	mov	dptr,#_keyboard_reset
      006C1B E0               [24] 3578 	movx	a,@dptr
                                   3579 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006C1C 70 36            [24] 3580 	jnz	00102$
      006C1E 8F 06            [24] 3581 	mov	ar6,r7
      006C20 24 22            [12] 3582 	add	a,#0x22
      006C22 FD               [12] 3583 	mov	r5,a
      006C23 8E 82            [24] 3584 	mov	dpl,r6
      006C25 8D 83            [24] 3585 	mov	dph,r5
      006C27 E0               [24] 3586 	movx	a,@dptr
      006C28 FE               [12] 3587 	mov	r6,a
      006C29 53 06 03         [24] 3588 	anl	ar6,#0x03
      006C2C BE 02 25         [24] 3589 	cjne	r6,#0x02,00102$
                                   3590 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006C2F 90 07 F6         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006C32 E0               [24] 3592 	movx	a,@dptr
      006C33 FD               [12] 3593 	mov	r5,a
      006C34 A3               [24] 3594 	inc	dptr
      006C35 E0               [24] 3595 	movx	a,@dptr
      006C36 FE               [12] 3596 	mov	r6,a
      006C37 90 07 F8         [24] 3597 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006C3A E0               [24] 3598 	movx	a,@dptr
      006C3B FC               [12] 3599 	mov	r4,a
      006C3C 90 07 F1         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_2
      006C3F ED               [12] 3601 	mov	a,r5
      006C40 F0               [24] 3602 	movx	@dptr,a
      006C41 EE               [12] 3603 	mov	a,r6
      006C42 A3               [24] 3604 	inc	dptr
      006C43 F0               [24] 3605 	movx	@dptr,a
      006C44 90 07 F3         [24] 3606 	mov	dptr,#_ak820_usb_send_PARM_3
      006C47 EC               [12] 3607 	mov	a,r4
      006C48 F0               [24] 3608 	movx	@dptr,a
      006C49 8F 82            [24] 3609 	mov	dpl, r7
      006C4B 12 6A 50         [24] 3610 	lcall	_ak820_usb_send
      006C4E E5 82            [12] 3611 	mov	a, dpl
      006C50 90 07 FA         [24] 3612 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006C53 F0               [24] 3613 	movx	@dptr,a
      006C54                       3614 00102$:
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3616 ;	assignBit
      006C54 A2 1A            [12] 3617 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C56 92 AF            [24] 3618 	mov	_EA,c
                                   3619 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006C58 90 07 FA         [24] 3620 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006C5B E0               [24] 3621 	movx	a,@dptr
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006C5C F5 82            [12] 3623 	mov	dpl,a
      006C5E 22               [24] 3624 	ret
                                   3625 ;------------------------------------------------------------
                                   3626 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3627 ;------------------------------------------------------------
                                   3628 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3629 ;	-----------------------------------------
                                   3630 ;	 function raw_request_is_nonpersistent
                                   3631 ;	-----------------------------------------
      006C5F                       3632 _raw_request_is_nonpersistent:
                                   3633 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006C5F 90 07 8E         [24] 3634 	mov	dptr,#_raw_buffer
      006C62 E0               [24] 3635 	movx	a,@dptr
      006C63 FF               [12] 3636 	mov	r7,a
      006C64 BF 01 02         [24] 3637 	cjne	r7,#0x01,00302$
      006C67 80 35            [24] 3638 	sjmp	00108$
      006C69                       3639 00302$:
      006C69 BF 02 02         [24] 3640 	cjne	r7,#0x02,00303$
      006C6C 80 34            [24] 3641 	sjmp	00109$
      006C6E                       3642 00303$:
      006C6E BF 04 02         [24] 3643 	cjne	r7,#0x04,00304$
      006C71 80 2B            [24] 3644 	sjmp	00108$
      006C73                       3645 00304$:
      006C73 BF 08 02         [24] 3646 	cjne	r7,#0x08,00305$
      006C76 80 47            [24] 3647 	sjmp	00116$
      006C78                       3648 00305$:
      006C78 BF 0B 02         [24] 3649 	cjne	r7,#0x0b,00306$
      006C7B 80 21            [24] 3650 	sjmp	00108$
      006C7D                       3651 00306$:
      006C7D BF 0C 02         [24] 3652 	cjne	r7,#0x0c,00307$
      006C80 80 1C            [24] 3653 	sjmp	00108$
      006C82                       3654 00307$:
      006C82 BF 0D 02         [24] 3655 	cjne	r7,#0x0d,00308$
      006C85 80 17            [24] 3656 	sjmp	00108$
      006C87                       3657 00308$:
      006C87 BF 0E 02         [24] 3658 	cjne	r7,#0x0e,00309$
      006C8A 80 12            [24] 3659 	sjmp	00108$
      006C8C                       3660 00309$:
      006C8C BF 11 02         [24] 3661 	cjne	r7,#0x11,00310$
      006C8F 80 0D            [24] 3662 	sjmp	00108$
      006C91                       3663 00310$:
      006C91 BF 12 02         [24] 3664 	cjne	r7,#0x12,00311$
      006C94 80 08            [24] 3665 	sjmp	00108$
      006C96                       3666 00311$:
      006C96 BF FE 02         [24] 3667 	cjne	r7,#0xfe,00312$
      006C99 80 46            [24] 3668 	sjmp	00124$
      006C9B                       3669 00312$:
      006C9B 02 6D 36         [24] 3670 	ljmp	00144$
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006C9E                       3672 00108$:
                                   3673 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006C9E 75 82 01         [24] 3674 	mov	dpl, #0x01
      006CA1 22               [24] 3675 	ret
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006CA2                       3677 00109$:
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006CA2 12 70 4A         [24] 3679 	lcall	_ak820_outline_0161
      006CA5 BF 01 02         [24] 3680 	cjne	r7,#0x01,00313$
      006CA8 80 0D            [24] 3681 	sjmp	00113$
      006CAA                       3682 00313$:
      006CAA BF 02 02         [24] 3683 	cjne	r7,#0x02,00314$
      006CAD 80 08            [24] 3684 	sjmp	00113$
      006CAF                       3685 00314$:
      006CAF BF 03 02         [24] 3686 	cjne	r7,#0x03,00315$
      006CB2 80 03            [24] 3687 	sjmp	00113$
      006CB4                       3688 00315$:
      006CB4 BF 04 04         [24] 3689 	cjne	r7,#0x04,00114$
                                   3690 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006CB7                       3691 00113$:
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006CB7 75 82 01         [24] 3693 	mov	dpl, #0x01
      006CBA 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006CBB                       3696 00114$:
      006CBB 75 82 00         [24] 3697 	mov	dpl, #0x00
      006CBE 22               [24] 3698 	ret
                                   3699 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006CBF                       3700 00116$:
                                   3701 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006CBF 12 70 4A         [24] 3702 	lcall	_ak820_outline_0161
      006CC2 BF 40 02         [24] 3703 	cjne	r7,#0x40,00318$
      006CC5 80 12            [24] 3704 	sjmp	00121$
      006CC7                       3705 00318$:
      006CC7 BF 41 02         [24] 3706 	cjne	r7,#0x41,00319$
      006CCA 80 0D            [24] 3707 	sjmp	00121$
      006CCC                       3708 00319$:
      006CCC BF 42 02         [24] 3709 	cjne	r7,#0x42,00320$
      006CCF 80 08            [24] 3710 	sjmp	00121$
      006CD1                       3711 00320$:
      006CD1 BF 43 02         [24] 3712 	cjne	r7,#0x43,00321$
      006CD4 80 03            [24] 3713 	sjmp	00121$
      006CD6                       3714 00321$:
      006CD6 BF 44 04         [24] 3715 	cjne	r7,#0x44,00122$
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006CD9                       3717 00121$:
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006CD9 75 82 01         [24] 3719 	mov	dpl, #0x01
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006CDC 22               [24] 3721 	ret
      006CDD                       3722 00122$:
      006CDD 75 82 00         [24] 3723 	mov	dpl, #0x00
                                   3724 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006CE0 22               [24] 3725 	ret
      006CE1                       3726 00124$:
                                   3727 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006CE1 12 70 4A         [24] 3728 	lcall	_ak820_outline_0161
      006CE4 24 F2            [12] 3729 	add	a,#0xff - 0x0d
      006CE6 40 4A            [24] 3730 	jc	00142$
                                   3731 ;	free result
      006CE8 EF               [12] 3732 	mov	a,r7
      006CE9 24 0A            [12] 3733 	add	a,#(00325$-3-.)
      006CEB 83               [24] 3734 	movc	a,@a+pc
      006CEC F5 82            [12] 3735 	mov	dpl,a
      006CEE EF               [12] 3736 	mov	a,r7
      006CEF 24 12            [12] 3737 	add	a,#(00326$-3-.)
      006CF1 83               [24] 3738 	movc	a,@a+pc
      006CF2 F5 83            [12] 3739 	mov	dph,a
      006CF4 E4               [12] 3740 	clr	a
      006CF5 73               [24] 3741 	jmp	@a+dptr
      006CF6                       3742 00325$:
      006CF6 12                    3743 	.db	00134$
      006CF7 12                    3744 	.db	00134$
      006CF8 12                    3745 	.db	00134$
      006CF9 12                    3746 	.db	00134$
      006CFA 32                    3747 	.db	00142$
      006CFB 12                    3748 	.db	00134$
      006CFC 12                    3749 	.db	00134$
      006CFD 12                    3750 	.db	00134$
      006CFE 12                    3751 	.db	00134$
      006CFF 12                    3752 	.db	00134$
      006D00 12                    3753 	.db	00134$
      006D01 32                    3754 	.db	00142$
      006D02 32                    3755 	.db	00142$
      006D03 16                    3756 	.db	00135$
      006D04                       3757 00326$:
      006D04 6D                    3758 	.db	00134$>>8
      006D05 6D                    3759 	.db	00134$>>8
      006D06 6D                    3760 	.db	00134$>>8
      006D07 6D                    3761 	.db	00134$>>8
      006D08 6D                    3762 	.db	00142$>>8
      006D09 6D                    3763 	.db	00134$>>8
      006D0A 6D                    3764 	.db	00134$>>8
      006D0B 6D                    3765 	.db	00134$>>8
      006D0C 6D                    3766 	.db	00134$>>8
      006D0D 6D                    3767 	.db	00134$>>8
      006D0E 6D                    3768 	.db	00134$>>8
      006D0F 6D                    3769 	.db	00142$>>8
      006D10 6D                    3770 	.db	00142$>>8
      006D11 6D                    3771 	.db	00135$>>8
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006D12                       3773 00134$:
                                   3774 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006D12 75 82 01         [24] 3775 	mov	dpl, #0x01
                                   3776 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006D15 22               [24] 3777 	ret
      006D16                       3778 00135$:
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006D16 90 07 90         [24] 3780 	mov	dptr,#(_raw_buffer + 0x0002)
      006D19 E0               [24] 3781 	movx	a,@dptr
      006D1A FF               [12] 3782 	mov	r7,a
      006D1B 60 0D            [24] 3783 	jz	00139$
      006D1D BF 01 02         [24] 3784 	cjne	r7,#0x01,00328$
      006D20 80 08            [24] 3785 	sjmp	00139$
      006D22                       3786 00328$:
      006D22 BF 03 02         [24] 3787 	cjne	r7,#0x03,00329$
      006D25 80 03            [24] 3788 	sjmp	00139$
      006D27                       3789 00329$:
      006D27 BF 05 04         [24] 3790 	cjne	r7,#0x05,00140$
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006D2A                       3792 00139$:
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006D2A 75 82 01         [24] 3794 	mov	dpl, #0x01
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006D2D 22               [24] 3796 	ret
      006D2E                       3797 00140$:
      006D2E 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006D31 22               [24] 3800 	ret
      006D32                       3801 00142$:
      006D32 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006D35 22               [24] 3804 	ret
      006D36                       3805 00144$:
      006D36 75 82 00         [24] 3806 	mov	dpl, #0x00
                                   3807 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006D39 22               [24] 3809 	ret
                                   3810 ;------------------------------------------------------------
                                   3811 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3812 ;------------------------------------------------------------
                                   3813 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3814 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_463'
                                   3815 ;------------------------------------------------------------
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3817 ;	-----------------------------------------
                                   3818 ;	 function ak820_usb_raw_send
                                   3819 ;	-----------------------------------------
      006D3A                       3820 _ak820_usb_raw_send:
      006D3A 12 43 37         [24] 3821 	lcall	_ak820_outline_0037
      006D3D 90 07 FC         [24] 3822 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006D40 12 37 D7         [24] 3823 	lcall	_ak820_outline_0016
                                   3824 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006D43 90 07 FB         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D46 E0               [24] 3826 	movx	a,@dptr
      006D47 FF               [12] 3827 	mov	r7,a
      006D48 BF 20 2B         [24] 3828 	cjne	r7,#0x20,00106$
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006D4B C0 07            [24] 3830 	push	ar7
      006D4D 12 3E 4E         [24] 3831 	lcall	_ak820_nvm_flush
      006D50 D0 07            [24] 3832 	pop	ar7
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D52 90 07 AE         [24] 3834 	mov	dptr,#_raw_reply_without_nvm
      006D55 E0               [24] 3835 	movx	a,@dptr
      006D56 70 07            [24] 3836 	jnz	00103$
      006D58 12 3E 3F         [24] 3837 	lcall	_ak820_nvm_ok
      006D5B E5 82            [12] 3838 	mov	a, dpl
      006D5D 60 17            [24] 3839 	jz	00106$
      006D5F                       3840 00103$:
      006D5F 90 07 FC         [24] 3841 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006D62 12 43 6E         [24] 3842 	lcall	_ak820_outline_0093
      006D65 90 07 F1         [24] 3843 	mov	dptr,#_ak820_usb_send_PARM_2
      006D68 12 43 B1         [24] 3844 	lcall	_ak820_outline_0159
      006D6B 90 07 F3         [24] 3845 	mov	dptr,#_ak820_usb_send_PARM_3
      006D6E EF               [12] 3846 	mov	a,r7
      006D6F F0               [24] 3847 	movx	@dptr,a
      006D70 75 82 03         [24] 3848 	mov	dpl, #0x03
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006D73 02 6A 50         [24] 3850 	ljmp	_ak820_usb_send
      006D76                       3851 00106$:
      006D76 22               [24] 3852 	ret
                                   3853 ;------------------------------------------------------------
                                   3854 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3855 ;------------------------------------------------------------
                                   3856 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3857 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_468'
                                   3858 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_468'
                                   3859 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_468'
                                   3860 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_468'
                                   3861 ;------------------------------------------------------------
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3863 ;	-----------------------------------------
                                   3864 ;	 function ak820_usb_raw_task
                                   3865 ;	-----------------------------------------
      006D77                       3866 _ak820_usb_raw_task:
                                   3867 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006D77 A2 AF            [12] 3868 	mov	c,_EA
      006D79 E4               [12] 3869 	clr	a
      006D7A 33               [12] 3870 	rlc	a
      006D7B FF               [12] 3871 	mov	r7,a
                                   3872 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3873 ;	assignBit
      006D7C C2 AF            [12] 3874 	clr	_EA
                                   3875 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006D7E 90 07 86         [24] 3876 	mov	dptr,#_USB_EnumStatus
      006D81 E0               [24] 3877 	movx	a,@dptr
      006D82 60 0A            [24] 3878 	jz	00101$
      006D84 90 07 8D         [24] 3879 	mov	dptr,#_raw_state
      006D87 E0               [24] 3880 	movx	a,@dptr
      006D88 FE               [12] 3881 	mov	r6,a
      006D89 BE 02 02         [24] 3882 	cjne	r6,#0x02,00427$
      006D8C 80 06            [24] 3883 	sjmp	00102$
      006D8E                       3884 00427$:
      006D8E                       3885 00101$:
                                   3886 ;	assignBit
      006D8E EF               [12] 3887 	mov	a,r7
      006D8F 24 FF            [12] 3888 	add	a,#0xff
      006D91 92 AF            [24] 3889 	mov	_EA,c
      006D93 22               [24] 3890 	ret
      006D94                       3891 00102$:
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006D94 90 07 8D         [24] 3893 	mov	dptr,#_raw_state
      006D97 74 03            [12] 3894 	mov	a,#0x03
      006D99 F0               [24] 3895 	movx	@dptr,a
                                   3896 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3897 ;	assignBit
      006D9A EF               [12] 3898 	mov	a,r7
      006D9B 24 FF            [12] 3899 	add	a,#0xff
      006D9D 92 AF            [24] 3900 	mov	_EA,c
                                   3901 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006D9F 90 07 8E         [24] 3902 	mov	dptr,#_raw_buffer
      006DA2 E0               [24] 3903 	movx	a,@dptr
      006DA3 FF               [12] 3904 	mov	r7,a
      006DA4 E4               [12] 3905 	clr	a
      006DA5 BF FD 01         [24] 3906 	cjne	r7,#0xfd,00428$
      006DA8 04               [12] 3907 	inc	a
      006DA9                       3908 00428$:
      006DA9 FF               [12] 3909 	mov	r7,a
      006DAA 70 03            [24] 3910 	jnz	00430$
      006DAC 02 6E 4C         [24] 3911 	ljmp	00141$
      006DAF                       3912 00430$:
      006DAF 90 07 8F         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0001)
      006DB2 E0               [24] 3914 	movx	a,@dptr
      006DB3 60 03            [24] 3915 	jz	00431$
      006DB5 02 6E 4C         [24] 3916 	ljmp	00141$
      006DB8                       3917 00431$:
                                   3918 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006DB8 90 07 90         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0002)
      006DBB E0               [24] 3920 	movx	a,@dptr
      006DBC FD               [12] 3921 	mov	r5,a
      006DBD 7E 00            [12] 3922 	mov	r6,#0x00
      006DBF 90 07 91         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0003)
      006DC2 E0               [24] 3924 	movx	a,@dptr
      006DC3 7B 00            [12] 3925 	mov	r3,#0x00
      006DC5 42 06            [12] 3926 	orl	ar6,a
      006DC7 EB               [12] 3927 	mov	a,r3
      006DC8 42 05            [12] 3928 	orl	ar5,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006DCA 90 07 92         [24] 3930 	mov	dptr,#(_raw_buffer + 0x0004)
      006DCD E0               [24] 3931 	movx	a,@dptr
      006DCE FC               [12] 3932 	mov	r4,a
                                   3933 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006DCF 7B 05            [12] 3934 	mov	r3,#0x05
      006DD1                       3935 00151$:
      006DD1 EB               [12] 3936 	mov	a,r3
      006DD2 12 70 32         [24] 3937 	lcall	_ak820_outline_0040
      006DD5 0B               [12] 3938 	inc	r3
      006DD6 BB 20 00         [24] 3939 	cjne	r3,#0x20,00432$
      006DD9                       3940 00432$:
      006DD9 40 F6            [24] 3941 	jc	00151$
                                   3942 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006DDB EC               [12] 3943 	mov	a,r4
      006DDC 24 E4            [12] 3944 	add	a,#0xff - 0x1b
      006DDE 40 1C            [24] 3945 	jc	00106$
                                   3946 ;	free result
      006DE0 EC               [12] 3947 	mov	a,r4
      006DE1 60 26            [24] 3948 	jz	00212$
      006DE3 8C 03            [24] 3949 	mov	ar3,r4
      006DE5 1B               [12] 3950 	dec	r3
      006DE6 7A 00            [12] 3951 	mov	r2,#0x00
      006DE8 74 FF            [12] 3952 	mov	a,#0xff
      006DEA C3               [12] 3953 	clr	c
      006DEB 9B               [12] 3954 	subb	a,r3
      006DEC FB               [12] 3955 	mov	r3,a
      006DED 74 FF            [12] 3956 	mov	a,#0xff
      006DEF 9A               [12] 3957 	subb	a,r2
      006DF0 FA               [12] 3958 	mov	r2,a
      006DF1 8E 00            [24] 3959 	mov	ar0,r6
      006DF3 8D 01            [24] 3960 	mov	ar1,r5
      006DF5 C3               [12] 3961 	clr	c
      006DF6 EB               [12] 3962 	mov	a,r3
      006DF7 98               [12] 3963 	subb	a,r0
      006DF8 EA               [12] 3964 	mov	a,r2
      006DF9 99               [12] 3965 	subb	a,r1
      006DFA 50 0D            [24] 3966 	jnc	00212$
                                   3967 ;	free result
      006DFC                       3968 00106$:
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006DFC 90 07 8F         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0001)
      006DFF 74 FF            [12] 3971 	mov	a,#0xff
      006E01 F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006E02 90 07 92         [24] 3974 	mov	dptr,#(_raw_buffer + 0x0004)
      006E05 E4               [12] 3975 	clr	a
      006E06 F0               [24] 3976 	movx	@dptr,a
                                   3977 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006E07 80 3A            [24] 3978 	sjmp	00108$
      006E09                       3979 00212$:
      006E09 7B 00            [12] 3980 	mov	r3,#0x00
      006E0B                       3981 00154$:
      006E0B C3               [12] 3982 	clr	c
      006E0C EB               [12] 3983 	mov	a,r3
      006E0D 9C               [12] 3984 	subb	a,r4
      006E0E 50 33            [24] 3985 	jnc	00108$
      006E10 C0 04            [24] 3986 	push	ar4
      006E12 8B 02            [24] 3987 	mov	ar2,r3
      006E14 74 05            [12] 3988 	mov	a,#0x05
      006E16 2A               [12] 3989 	add	a, r2
      006E17 F9               [12] 3990 	mov	r1,a
      006E18 33               [12] 3991 	rlc	a
      006E19 95 E0            [12] 3992 	subb	a,acc
      006E1B FA               [12] 3993 	mov	r2,a
      006E1C E9               [12] 3994 	mov	a,r1
      006E1D 24 8E            [12] 3995 	add	a, #_raw_buffer
      006E1F F9               [12] 3996 	mov	r1,a
      006E20 EA               [12] 3997 	mov	a,r2
      006E21 34 07            [12] 3998 	addc	a, #(_raw_buffer >> 8)
      006E23 FA               [12] 3999 	mov	r2,a
      006E24 8B 1E            [24] 4000 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006E26 75 1F 00         [24] 4001 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006E29 8E 00            [24] 4002 	mov	ar0,r6
      006E2B 8D 04            [24] 4003 	mov	ar4,r5
      006E2D E5 1E            [12] 4004 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006E2F 28               [12] 4005 	add	a, r0
      006E30 F8               [12] 4006 	mov	r0,a
      006E31 E5 1F            [12] 4007 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006E33 3C               [12] 4008 	addc	a, r4
      006E34 FC               [12] 4009 	mov	r4,a
      006E35 88 82            [24] 4010 	mov	dpl,r0
      006E37 8C 83            [24] 4011 	mov	dph,r4
      006E39 E4               [12] 4012 	clr	a
      006E3A 93               [24] 4013 	movc	a,@a+dptr
      006E3B 12 70 44         [24] 4014 	lcall	_ak820_outline_0136
      006E3E 0B               [12] 4015 	inc	r3
      006E3F D0 04            [24] 4016 	pop	ar4
      006E41 80 C8            [24] 4017 	sjmp	00154$
      006E43                       4018 00108$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E43 12 70 1E         [24] 4020 	lcall	_ak820_outline_0008
      006E46 12 6A 50         [24] 4021 	lcall	_ak820_usb_send
      006E49 02 6F CE         [24] 4022 	ljmp	00142$
      006E4C                       4023 00141$:
                                   4024 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E4C EF               [12] 4025 	mov	a,r7
      006E4D 70 03            [24] 4026 	jnz	00438$
      006E4F 02 6E D1         [24] 4027 	ljmp	00137$
      006E52                       4028 00438$:
      006E52 90 07 8F         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0001)
      006E55 E0               [24] 4030 	movx	a,@dptr
      006E56 FE               [12] 4031 	mov	r6,a
      006E57 BE 01 02         [24] 4032 	cjne	r6,#0x01,00439$
      006E5A 80 03            [24] 4033 	sjmp	00440$
      006E5C                       4034 00439$:
      006E5C 02 6E D1         [24] 4035 	ljmp	00137$
      006E5F                       4036 00440$:
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E5F 7E 02            [12] 4038 	mov	r6,#0x02
      006E61                       4039 00156$:
      006E61 EE               [12] 4040 	mov	a,r6
      006E62 12 70 32         [24] 4041 	lcall	_ak820_outline_0040
      006E65 0E               [12] 4042 	inc	r6
      006E66 BE 20 00         [24] 4043 	cjne	r6,#0x20,00441$
      006E69                       4044 00441$:
      006E69 40 F6            [24] 4045 	jc	00156$
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006E6B 90 07 90         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0002)
      006E6E 74 01            [12] 4048 	mov	a,#0x01
      006E70 F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006E71 90 07 91         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0003)
      006E74 74 A8            [12] 4052 	mov	a,#0xa8
      006E76 F0               [24] 4053 	movx	@dptr,a
                                   4054 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006E77 90 07 92         [24] 4055 	mov	dptr,#(_raw_buffer + 0x0004)
      006E7A 12 3B BD         [24] 4056 	lcall	_ak820_nvm_diagnostic
                                   4057 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006E7D 7E 00            [12] 4058 	mov	r6,#0x00
      006E7F                       4059 00158$:
      006E7F 8E 05            [24] 4060 	mov	ar5,r6
      006E81 74 0B            [12] 4061 	mov	a,#0x0b
      006E83 2D               [12] 4062 	add	a, r5
      006E84 24 8E            [12] 4063 	add	a,#_raw_buffer
      006E86 FD               [12] 4064 	mov	r5,a
      006E87 E4               [12] 4065 	clr	a
      006E88 34 07            [12] 4066 	addc	a, #(_raw_buffer >> 8)
      006E8A FC               [12] 4067 	mov	r4,a
      006E8B EE               [12] 4068 	mov	a,r6
      006E8C 24 60            [12] 4069 	add	a, #_ak820_flash_diagnostic
      006E8E F5 82            [12] 4070 	mov	dpl,a
      006E90 E4               [12] 4071 	clr	a
      006E91 34 04            [12] 4072 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006E93 F5 83            [12] 4073 	mov	dph,a
      006E95 E0               [24] 4074 	movx	a,@dptr
      006E96 12 43 C1         [24] 4075 	lcall	_ak820_outline_0185
      006E99 F0               [24] 4076 	movx	@dptr,a
      006E9A 0E               [12] 4077 	inc	r6
      006E9B BE 06 00         [24] 4078 	cjne	r6,#0x06,00443$
      006E9E                       4079 00443$:
      006E9E 40 DF            [24] 4080 	jc	00158$
                                   4081 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006EA0 90 0E 17         [24] 4082 	mov	dptr,#_vial_unlocked
      006EA3 E0               [24] 4083 	movx	a,@dptr
      006EA4 90 07 9F         [24] 4084 	mov	dptr,#(_raw_buffer + 0x0011)
      006EA7 F0               [24] 4085 	movx	@dptr,a
                                   4086 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006EA8 90 0E 18         [24] 4087 	mov	dptr,#_vial_unlock_in_progress
      006EAB E0               [24] 4088 	movx	a,@dptr
      006EAC 90 07 A0         [24] 4089 	mov	dptr,#(_raw_buffer + 0x0012)
      006EAF F0               [24] 4090 	movx	@dptr,a
                                   4091 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006EB0 90 07 86         [24] 4092 	mov	dptr,#_USB_EnumStatus
      006EB3 E0               [24] 4093 	movx	a,@dptr
      006EB4 90 07 A1         [24] 4094 	mov	dptr,#(_raw_buffer + 0x0013)
      006EB7 F0               [24] 4095 	movx	@dptr,a
                                   4096 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006EB8 90 07 87         [24] 4097 	mov	dptr,#_USB_SleepStatus
      006EBB E0               [24] 4098 	movx	a,@dptr
      006EBC 90 07 A2         [24] 4099 	mov	dptr,#(_raw_buffer + 0x0014)
      006EBF F0               [24] 4100 	movx	@dptr,a
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006EC0 90 07 8D         [24] 4102 	mov	dptr,#_raw_state
      006EC3 E0               [24] 4103 	movx	a,@dptr
      006EC4 90 07 A3         [24] 4104 	mov	dptr,#(_raw_buffer + 0x0015)
      006EC7 F0               [24] 4105 	movx	@dptr,a
                                   4106 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006EC8 12 70 1E         [24] 4107 	lcall	_ak820_outline_0008
      006ECB 12 6A 50         [24] 4108 	lcall	_ak820_usb_send
      006ECE 02 6F CE         [24] 4109 	ljmp	00142$
      006ED1                       4110 00137$:
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      006ED1 EF               [12] 4112 	mov	a,r7
      006ED2 70 03            [24] 4113 	jnz	00445$
      006ED4 02 6F AB         [24] 4114 	ljmp	00133$
      006ED7                       4115 00445$:
      006ED7 12 70 4A         [24] 4116 	lcall	_ak820_outline_0161
      006EDA BF 02 02         [24] 4117 	cjne	r7,#0x02,00446$
      006EDD 80 03            [24] 4118 	sjmp	00447$
      006EDF                       4119 00446$:
      006EDF 02 6F AB         [24] 4120 	ljmp	00133$
      006EE2                       4121 00447$:
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      006EE2 90 07 FF         [24] 4123 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006EE5 74 01            [12] 4124 	mov	a,#0x01
      006EE7 F0               [24] 4125 	movx	@dptr,a
                                   4126 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      006EE8 90 07 90         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0002)
      006EEB E0               [24] 4128 	movx	a,@dptr
      006EEC FF               [12] 4129 	mov	r7,a
      006EED BF 01 72         [24] 4130 	cjne	r7,#0x01,00235$
      006EF0 90 07 91         [24] 4131 	mov	dptr,#(_raw_buffer + 0x0003)
      006EF3 E0               [24] 4132 	movx	a,@dptr
      006EF4 FF               [12] 4133 	mov  r7,a
      006EF5 24 FE            [12] 4134 	add	a,#0xff - 0x01
      006EF7 40 69            [24] 4135 	jc	00235$
                                   4136 ;	free result
      006EF9 90 07 92         [24] 4137 	mov	dptr,#(_raw_buffer + 0x0004)
      006EFC E0               [24] 4138 	movx	a,@dptr
      006EFD FE               [12] 4139 	mov  r6,a
      006EFE 24 FC            [12] 4140 	add	a,#0xff - 0x03
      006F00 40 60            [24] 4141 	jc	00235$
                                   4142 ;	free result
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      006F02 EF               [12] 4144 	mov	a,r7
      006F03 70 03            [24] 4145 	jnz	00227$
      006F05 EE               [12] 4146 	mov	a,r6
      006F06 70 5A            [24] 4147 	jnz	00235$
                                   4148 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      006F08                       4149 00227$:
      006F08 7D 05            [12] 4150 	mov	r5,#0x05
      006F0A                       4151 00162$:
      006F0A BD 20 00         [24] 4152 	cjne	r5,#0x20,00454$
      006F0D                       4153 00454$:
      006F0D 50 10            [24] 4154 	jnc	00113$
      006F0F ED               [12] 4155 	mov	a,r5
      006F10 24 8E            [12] 4156 	add	a, #_raw_buffer
      006F12 FB               [12] 4157 	mov	r3,a
      006F13 E4               [12] 4158 	clr	a
      006F14 34 07            [12] 4159 	addc	a, #(_raw_buffer >> 8)
      006F16 FC               [12] 4160 	mov	r4,a
      006F17 12 70 3E         [24] 4161 	lcall	_ak820_outline_0118
      006F1A 70 03            [24] 4162 	jnz	00113$
      006F1C 0D               [12] 4163 	inc	r5
      006F1D 80 EB            [24] 4164 	sjmp	00162$
      006F1F                       4165 00113$:
                                   4166 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      006F1F BD 20 40         [24] 4167 	cjne	r5,#0x20,00235$
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4169 ;	assignBit
      006F22 A2 AF            [12] 4170 	mov	c,_EA
      006F24 92 1B            [24] 4171 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4172 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4173 ;	assignBit
      006F26 C2 AF            [12] 4174 	clr	_EA
                                   4175 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      006F28 90 07 8D         [24] 4176 	mov	dptr,#_raw_state
      006F2B E0               [24] 4177 	movx	a,@dptr
      006F2C FD               [12] 4178 	mov	r5,a
      006F2D BD 03 28         [24] 4179 	cjne	r5,#0x03,00117$
      006F30 90 07 86         [24] 4180 	mov	dptr,#_USB_EnumStatus
      006F33 E0               [24] 4181 	movx	a,@dptr
      006F34 60 22            [24] 4182 	jz	00117$
      006F36 90 07 85         [24] 4183 	mov	dptr,#_D0UsbConfig
      006F39 E0               [24] 4184 	movx	a,@dptr
      006F3A 60 1C            [24] 4185 	jz	00117$
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      006F3C 90 07 87         [24] 4187 	mov	dptr,#_USB_SleepStatus
      006F3F E0               [24] 4188 	movx	a,@dptr
      006F40 20 E1 15         [24] 4189 	jb	acc.1,00117$
      006F43 90 0E 18         [24] 4190 	mov	dptr,#_vial_unlock_in_progress
      006F46 E0               [24] 4191 	movx	a,@dptr
      006F47 70 0F            [24] 4192 	jnz	00117$
                                   4193 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      006F49 EF               [12] 4194 	mov	a,r7
      006F4A 60 05            [24] 4195 	jz	00115$
      006F4C 8E 82            [24] 4196 	mov	dpl, r6
      006F4E 12 43 C6         [24] 4197 	lcall	_ak820_os_indicator_set
      006F51                       4198 00115$:
                                   4199 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      006F51 90 07 FF         [24] 4200 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F54 E4               [12] 4201 	clr	a
      006F55 F0               [24] 4202 	movx	@dptr,a
      006F56 80 06            [24] 4203 	sjmp	00118$
      006F58                       4204 00117$:
                                   4205 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      006F58 90 07 FF         [24] 4206 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F5B 74 02            [12] 4207 	mov	a,#0x02
      006F5D F0               [24] 4208 	movx	@dptr,a
      006F5E                       4209 00118$:
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4211 ;	assignBit
      006F5E A2 1B            [12] 4212 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006F60 92 AF            [24] 4213 	mov	_EA,c
                                   4214 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F62                       4215 00235$:
      006F62 7F 02            [12] 4216 	mov	r7,#0x02
      006F64                       4217 00164$:
      006F64 EF               [12] 4218 	mov	a,r7
      006F65 12 70 32         [24] 4219 	lcall	_ak820_outline_0040
      006F68 0F               [12] 4220 	inc	r7
      006F69 BF 20 00         [24] 4221 	cjne	r7,#0x20,00466$
      006F6C                       4222 00466$:
      006F6C 40 F6            [24] 4223 	jc	00164$
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      006F6E 90 07 90         [24] 4225 	mov	dptr,#(_raw_buffer + 0x0002)
      006F71 74 01            [12] 4226 	mov	a,#0x01
      006F73 F0               [24] 4227 	movx	@dptr,a
                                   4228 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      006F74 90 07 FF         [24] 4229 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      006F77 E0               [24] 4230 	movx	a,@dptr
      006F78 90 07 91         [24] 4231 	mov	dptr,#(_raw_buffer + 0x0003)
      006F7B F0               [24] 4232 	movx	@dptr,a
                                   4233 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      006F7C 12 43 ED         [24] 4234 	lcall	_ak820_os_indicator_get
      006F7F AF 82            [24] 4235 	mov	r7, dpl
      006F81 90 07 92         [24] 4236 	mov	dptr,#(_raw_buffer + 0x0004)
      006F84 EF               [12] 4237 	mov	a,r7
      006F85 F0               [24] 4238 	movx	@dptr,a
                                   4239 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      006F86 90 07 93         [24] 4240 	mov	dptr,#(_raw_buffer + 0x0005)
      006F89 74 A8            [12] 4241 	mov	a,#0xa8
      006F8B F0               [24] 4242 	movx	@dptr,a
                                   4243 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      006F8C 90 07 94         [24] 4244 	mov	dptr,#(_raw_buffer + 0x0006)
      006F8F 74 B8            [12] 4245 	mov	a,#0xb8
      006F91 F0               [24] 4246 	movx	@dptr,a
                                   4247 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      006F92 90 07 95         [24] 4248 	mov	dptr,#(_raw_buffer + 0x0007)
      006F95 74 0B            [12] 4249 	mov	a,#0x0b
      006F97 F0               [24] 4250 	movx	@dptr,a
                                   4251 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      006F98 90 07 96         [24] 4252 	mov	dptr,#(_raw_buffer + 0x0008)
      006F9B E4               [12] 4253 	clr	a
      006F9C F0               [24] 4254 	movx	@dptr,a
                                   4255 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      006F9D 90 07 97         [24] 4256 	mov	dptr,#(_raw_buffer + 0x0009)
      006FA0 74 10            [12] 4257 	mov	a,#0x10
      006FA2 F0               [24] 4258 	movx	@dptr,a
                                   4259 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FA3 12 70 1E         [24] 4260 	lcall	_ak820_outline_0008
      006FA6 12 6A 50         [24] 4261 	lcall	_ak820_usb_send
      006FA9 80 23            [24] 4262 	sjmp	00142$
      006FAB                       4263 00133$:
                                   4264 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006FAB 12 6C 5F         [24] 4265 	lcall	_raw_request_is_nonpersistent
      006FAE E5 82            [12] 4266 	mov	a, dpl
      006FB0 90 07 AE         [24] 4267 	mov	dptr,#_raw_reply_without_nvm
      006FB3 F0               [24] 4268 	movx	@dptr,a
                                   4269 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006FB4 12 3F A0         [24] 4270 	lcall	_ak820_nvm_begin
                                   4271 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006FB7 90 0C 49         [24] 4272 	mov	dptr,#_raw_hid_receive_PARM_2
      006FBA 74 20            [12] 4273 	mov	a,#0x20
      006FBC F0               [24] 4274 	movx	@dptr,a
      006FBD 90 07 8E         [24] 4275 	mov	dptr,#_raw_buffer
      006FC0 75 F0 00         [24] 4276 	mov	b, #0x00
      006FC3 12 A8 CF         [24] 4277 	lcall	_raw_hid_receive
                                   4278 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006FC6 12 3F B5         [24] 4279 	lcall	_ak820_nvm_end
                                   4280 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006FC9 90 07 AE         [24] 4281 	mov	dptr,#_raw_reply_without_nvm
      006FCC E4               [12] 4282 	clr	a
      006FCD F0               [24] 4283 	movx	@dptr,a
      006FCE                       4284 00142$:
                                   4285 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4286 ;	assignBit
      006FCE A2 AF            [12] 4287 	mov	c,_EA
      006FD0 92 1B            [24] 4288 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4289 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4290 ;	assignBit
      006FD2 C2 AF            [12] 4291 	clr	_EA
                                   4292 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006FD4 12 70 50         [24] 4293 	lcall	_ak820_outline_0163
      006FD7 BF 04 08         [24] 4294 	cjne	r7,#0x04,00149$
      006FDA 90 07 8D         [24] 4295 	mov	dptr,#_raw_state
      006FDD 74 05            [12] 4296 	mov	a,#0x05
      006FDF F0               [24] 4297 	movx	@dptr,a
      006FE0 80 1B            [24] 4298 	sjmp	00150$
      006FE2                       4299 00149$:
                                   4300 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006FE2 12 70 50         [24] 4301 	lcall	_ak820_outline_0163
      006FE5 BF 03 02         [24] 4302 	cjne	r7,#0x03,00470$
      006FE8 80 0E            [24] 4303 	sjmp	00144$
      006FEA                       4304 00470$:
      006FEA 12 70 50         [24] 4305 	lcall	_ak820_outline_0163
      006FED BF 06 02         [24] 4306 	cjne	r7,#0x06,00471$
      006FF0 80 06            [24] 4307 	sjmp	00144$
      006FF2                       4308 00471$:
      006FF2 12 70 50         [24] 4309 	lcall	_ak820_outline_0163
      006FF5 BF 07 05         [24] 4310 	cjne	r7,#0x07,00150$
      006FF8                       4311 00144$:
      006FF8 90 07 8D         [24] 4312 	mov	dptr,#_raw_state
      006FFB E4               [12] 4313 	clr	a
      006FFC F0               [24] 4314 	movx	@dptr,a
      006FFD                       4315 00150$:
                                   4316 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4317 ;	assignBit
      006FFD A2 1B            [12] 4318 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006FFF 92 AF            [24] 4319 	mov	_EA,c
                                   4320 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007001 22               [24] 4321 	ret
                                   4322 ;------------------------------------------------------------
                                   4323 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4324 ;------------------------------------------------------------
                                   4325 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_498'
                                   4326 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_498'
                                   4327 ;------------------------------------------------------------
                                   4328 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4329 ;	-----------------------------------------
                                   4330 ;	 function ak820_usb_take_keyboard_reset
                                   4331 ;	-----------------------------------------
      007002                       4332 _ak820_usb_take_keyboard_reset:
                                   4333 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4334 ;	assignBit
      007002 A2 AF            [12] 4335 	mov	c,_EA
      007004 92 1C            [24] 4336 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4337 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4338 ;	assignBit
      007006 C2 AF            [12] 4339 	clr	_EA
                                   4340 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007008 90 07 AF         [24] 4341 	mov	dptr,#_keyboard_reset
      00700B E0               [24] 4342 	movx	a,@dptr
      00700C FF               [12] 4343 	mov	r7,a
                                   4344 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      00700D E4               [12] 4345 	clr	a
      00700E F0               [24] 4346 	movx	@dptr,a
                                   4347 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4348 ;	assignBit
      00700F A2 1C            [12] 4349 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      007011 92 AF            [24] 4350 	mov	_EA,c
                                   4351 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      007013 EF               [12] 4352 	mov	a,r7
      007014 B4 01 00         [24] 4353 	cjne	a,#0x01,00103$
      007017                       4354 00103$:
      007017 B3               [12] 4355 	cpl	c
      007018 92 1C            [24] 4356 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      00701A 12 38 78         [24] 4357 	lcall	_ak820_outline_0167
                                   4358 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      00701D 22               [24] 4359 	ret
                                   4360 	.area CSEG    (CODE)
                                   4361 	.area CONST   (CODE)
                                   4362 	.area CONST   (CODE)
      00BB6A                       4363 _shared_offsets:
      00BB6A 00                    4364 	.db #0x00	; 0
      00BB6B 00                    4365 	.db #0x00	; 0
      00BB6C 28                    4366 	.db #0x28	; 40
      00BB6D 2E                    4367 	.db #0x2e	; 46
      00BB6E 31                    4368 	.db #0x31	; 49	'1'
      00BB6F 00                    4369 	.db #0x00	; 0
      00BB70 08                    4370 	.db #0x08	; 8
                                   4371 	.area CSEG    (CODE)
                                   4372 	.area CONST   (CODE)
      00BB71                       4373 _shared_lengths:
      00BB71 00                    4374 	.db #0x00	; 0
      00BB72 00                    4375 	.db #0x00	; 0
      00BB73 06                    4376 	.db #0x06	; 6
      00BB74 03                    4377 	.db #0x03	; 3
      00BB75 03                    4378 	.db #0x03	; 3
      00BB76 00                    4379 	.db #0x00	; 0
      00BB77 20                    4380 	.db #0x20	; 32
                                   4381 	.area CSEG    (CODE)
                                   4382 	.area CONST   (CODE)
      00BB78                       4383 _interface_descriptors:
      00BB78 1B C1                 4384 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BB7A 64 C2                 4385 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BB7C 17 C2                 4386 	.byte _RawReport, (_RawReport >> 8)
      00BB7E 7D C2                 4387 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BB80 60 C1                 4388 	.byte _SharedReport, (_SharedReport >> 8)
      00BB82 96 C2                 4389 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4390 	.area CSEG    (CODE)
                                   4391 	.area XINIT   (CODE)
                                   4392 	.area CABS    (ABS,CODE)
                                   4393 
                                   4394 ; Experimental exact instruction outlining.
                                   4395 	.globl _ak820_outline_0008
                                   4396 	.globl _ak820_outline_0016
                                   4397 	.globl _ak820_outline_0037
                                   4398 	.globl _ak820_outline_0040
                                   4399 	.globl _ak820_outline_0093
                                   4400 	.globl _ak820_outline_0118
                                   4401 	.globl _ak820_outline_0136
                                   4402 	.globl _ak820_outline_0159
                                   4403 	.globl _ak820_outline_0161
                                   4404 	.globl _ak820_outline_0163
                                   4405 	.globl _ak820_outline_0167
                                   4406 	.globl _ak820_outline_0185
                                   4407 
                                   4408 	.area CSEG (CODE)
                                   4409 ; function ak820_outline_0008
      00701E                       4410 _ak820_outline_0008:
      00701E 90 07 F1         [24] 4411 	mov	dptr,#_ak820_usb_send_PARM_2
      007021 74 8E            [12] 4412 	mov	a,#_raw_buffer
      007023 F0               [24] 4413 	movx	@dptr,a
      007024 74 07            [12] 4414 	mov	a,#(_raw_buffer>>8)
      007026 A3               [24] 4415 	inc	dptr
      007027 F0               [24] 4416 	movx	@dptr,a
      007028 90 07 F3         [24] 4417 	mov	dptr,#_ak820_usb_send_PARM_3
      00702B 74 20            [12] 4418 	mov	a,#0x20
      00702D F0               [24] 4419 	movx	@dptr,a
      00702E 75 82 03         [24] 4420 	mov	dpl,#0x03
      007031 22               [24] 4421 	ret
                                   4422 
                                   4423 	.area CSEG (CODE)
                                   4424 ; function ak820_outline_0040
      007032                       4425 _ak820_outline_0040:
      007032 24 8E            [12] 4426 	add	a,#_raw_buffer
      007034 F5 82            [12] 4427 	mov	dpl,a
      007036 E4               [12] 4428 	clr	a
      007037 34 07            [12] 4429 	addc	a,#(_raw_buffer>>8)
      007039 F5 83            [12] 4430 	mov	dph,a
      00703B E4               [12] 4431 	clr	a
      00703C F0               [24] 4432 	movx	@dptr,a
      00703D 22               [24] 4433 	ret
                                   4434 
                                   4435 	.area CSEG (CODE)
                                   4436 ; function ak820_outline_0118
      00703E                       4437 _ak820_outline_0118:
      00703E 8B 82            [24] 4438 	mov	dpl,r3
      007040 8C 83            [24] 4439 	mov	dph,r4
      007042 E0               [24] 4440 	movx	a,@dptr
      007043 22               [24] 4441 	ret
                                   4442 
                                   4443 	.area CSEG (CODE)
                                   4444 ; function ak820_outline_0136
      007044                       4445 _ak820_outline_0136:
      007044 89 82            [24] 4446 	mov	dpl,r1
      007046 8A 83            [24] 4447 	mov	dph,r2
      007048 F0               [24] 4448 	movx	@dptr,a
      007049 22               [24] 4449 	ret
                                   4450 
                                   4451 	.area CSEG (CODE)
                                   4452 ; function ak820_outline_0161
      00704A                       4453 _ak820_outline_0161:
      00704A 90 07 8F         [24] 4454 	mov	dptr,#(_raw_buffer+0x0001)
      00704D E0               [24] 4455 	movx	a,@dptr
      00704E FF               [12] 4456 	mov	r7,a
      00704F 22               [24] 4457 	ret
                                   4458 
                                   4459 	.area CSEG (CODE)
                                   4460 ; function ak820_outline_0163
      007050                       4461 _ak820_outline_0163:
      007050 90 07 8D         [24] 4462 	mov	dptr,#_raw_state
      007053 E0               [24] 4463 	movx	a,@dptr
      007054 FF               [12] 4464 	mov	r7,a
      007055 22               [24] 4465 	ret
