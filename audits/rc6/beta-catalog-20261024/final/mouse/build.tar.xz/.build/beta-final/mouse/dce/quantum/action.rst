                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_oneshot_cancel
                                     15 	.globl _ak820_oneshot_post
                                     16 	.globl _ak820_oneshot_process
                                     17 	.globl _ak820_tapping_source
                                     18 	.globl _ak820_tapping_cancel
                                     19 	.globl _ak820_tapping_process
                                     20 	.globl _ak820_tapping_before
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mousekey_send
                                     56 	.globl _mousekey_clear
                                     57 	.globl _mousekey_off
                                     58 	.globl _mousekey_on
                                     59 	.globl _mDelaymS
                                     60 	.globl _host_consumer_send
                                     61 	.globl _host_system_send
                                     62 	.globl _host_keyboard_leds
                                     63 	.globl _led_set
                                     64 	.globl _clear_keys_from_report
                                     65 	.globl ___memcpy
                                     66 	.globl _ADC_START
                                     67 	.globl _S0_R_FIFO
                                     68 	.globl _S0_T_FIFO
                                     69 	.globl _S0_FREE
                                     70 	.globl _S0_IF_BYTE
                                     71 	.globl _S0_IF_FIRST
                                     72 	.globl _S0_IF_OV
                                     73 	.globl _S0_FST_ACT
                                     74 	.globl _CP_RL2
                                     75 	.globl _C_T2
                                     76 	.globl _TR2
                                     77 	.globl _EXEN2
                                     78 	.globl _TCLK
                                     79 	.globl _RCLK
                                     80 	.globl _EXF2
                                     81 	.globl _CAP1F
                                     82 	.globl _TF2
                                     83 	.globl _RI
                                     84 	.globl _TI
                                     85 	.globl _RB8
                                     86 	.globl _TB8
                                     87 	.globl _REN
                                     88 	.globl _SM2
                                     89 	.globl _SM1
                                     90 	.globl _SM0
                                     91 	.globl _IT0
                                     92 	.globl _IE0
                                     93 	.globl _IT1
                                     94 	.globl _IE1
                                     95 	.globl _TR0
                                     96 	.globl _TF0
                                     97 	.globl _TR1
                                     98 	.globl _TF1
                                     99 	.globl _P4_0
                                    100 	.globl _P4_1
                                    101 	.globl _P4_2
                                    102 	.globl _P4_3
                                    103 	.globl _P4_4
                                    104 	.globl _P4_5
                                    105 	.globl _P4_6
                                    106 	.globl _RXD
                                    107 	.globl _TXD
                                    108 	.globl _INT0
                                    109 	.globl _INT1
                                    110 	.globl _T0
                                    111 	.globl _T1
                                    112 	.globl _MOSI1
                                    113 	.globl _MISO1
                                    114 	.globl _SCK1
                                    115 	.globl _P3_0
                                    116 	.globl _P3_1
                                    117 	.globl _P3_2
                                    118 	.globl _P3_3
                                    119 	.globl _P3_4
                                    120 	.globl _P3_5
                                    121 	.globl _P3_6
                                    122 	.globl _P3_7
                                    123 	.globl _CAP1_
                                    124 	.globl _T2_
                                    125 	.globl _CAP2_
                                    126 	.globl _T2EX_
                                    127 	.globl _RXD1
                                    128 	.globl _TXD1
                                    129 	.globl _P2_0
                                    130 	.globl _P2_1
                                    131 	.globl _P2_2
                                    132 	.globl _P2_3
                                    133 	.globl _P2_4
                                    134 	.globl _P2_5
                                    135 	.globl _P2_6
                                    136 	.globl _P2_7
                                    137 	.globl _AIN0
                                    138 	.globl _AIN1
                                    139 	.globl _AIN2
                                    140 	.globl _AIN3
                                    141 	.globl _AIN4
                                    142 	.globl _AIN5
                                    143 	.globl _AIN6
                                    144 	.globl _AIN7
                                    145 	.globl _CAP1
                                    146 	.globl _T2
                                    147 	.globl _CAP2
                                    148 	.globl _T2EX
                                    149 	.globl _INT0_
                                    150 	.globl _SCS
                                    151 	.globl _MOSI
                                    152 	.globl _MISO
                                    153 	.globl _SCK
                                    154 	.globl _RXD1_
                                    155 	.globl _TXD1_
                                    156 	.globl _P1_0
                                    157 	.globl _P1_1
                                    158 	.globl _P1_2
                                    159 	.globl _P1_3
                                    160 	.globl _P1_4
                                    161 	.globl _P1_5
                                    162 	.globl _P1_6
                                    163 	.globl _P1_7
                                    164 	.globl _AIN8
                                    165 	.globl _AIN9
                                    166 	.globl _AIN10
                                    167 	.globl _AIN11
                                    168 	.globl _AIN12
                                    169 	.globl _AIN13
                                    170 	.globl _RXD_
                                    171 	.globl _TXD_
                                    172 	.globl _SCL0
                                    173 	.globl _SDA0
                                    174 	.globl _P0_0
                                    175 	.globl _P0_1
                                    176 	.globl _P0_2
                                    177 	.globl _P0_3
                                    178 	.globl _P0_4
                                    179 	.globl _P0_5
                                    180 	.globl _P0_6
                                    181 	.globl _P0_7
                                    182 	.globl _IE_SPI0
                                    183 	.globl _IE_USB
                                    184 	.globl _IE_ADC
                                    185 	.globl _IE_UART1
                                    186 	.globl _IE_PWM_I2C
                                    187 	.globl _IE_GPIO
                                    188 	.globl _IE_WDOG
                                    189 	.globl _PX0
                                    190 	.globl _PT0
                                    191 	.globl _PX1
                                    192 	.globl _PT1
                                    193 	.globl _PS
                                    194 	.globl _PT2
                                    195 	.globl _PL_FLAG
                                    196 	.globl _PH_FLAG
                                    197 	.globl _EX0
                                    198 	.globl _ET0
                                    199 	.globl _EX1
                                    200 	.globl _ET1
                                    201 	.globl _ES
                                    202 	.globl _ET2
                                    203 	.globl _E_DIS
                                    204 	.globl _EA
                                    205 	.globl _P
                                    206 	.globl _F1
                                    207 	.globl _OV
                                    208 	.globl _RS0
                                    209 	.globl _RS1
                                    210 	.globl _F0
                                    211 	.globl _AC
                                    212 	.globl _CY
                                    213 	.globl _I2CS_INT_ST
                                    214 	.globl _I2CX_INT
                                    215 	.globl _LED_STATUS
                                    216 	.globl _LED_DMA_H
                                    217 	.globl _LED_DMA_L
                                    218 	.globl _LED_DMA
                                    219 	.globl _LED_PWM_OE
                                    220 	.globl _LED_COMMON
                                    221 	.globl _ADC_CHAN
                                    222 	.globl _ADC_DAT_H
                                    223 	.globl _ADC_DAT_L
                                    224 	.globl _ADC_DAT
                                    225 	.globl _ADC_CTRL
                                    226 	.globl _SPI1_CK_SE
                                    227 	.globl _SPI1_CTRL
                                    228 	.globl _SPI1_DATA
                                    229 	.globl _SPI1_STAT
                                    230 	.globl _SIF1
                                    231 	.globl _SBAUD1
                                    232 	.globl _SBUF1
                                    233 	.globl _SCON1
                                    234 	.globl _SPI0_SETUP
                                    235 	.globl _SPI0_CK_SE
                                    236 	.globl _SPI0_CTRL
                                    237 	.globl _SPI0_DATA
                                    238 	.globl _SPI0_STAT
                                    239 	.globl _T2CAP1H
                                    240 	.globl _T2CAP1L
                                    241 	.globl _T2CAP1
                                    242 	.globl _TH2
                                    243 	.globl _TL2
                                    244 	.globl _T2COUNT
                                    245 	.globl _RCAP2H
                                    246 	.globl _RCAP2L
                                    247 	.globl _RCAP2
                                    248 	.globl _T2MOD
                                    249 	.globl _T2CON
                                    250 	.globl _SBUF
                                    251 	.globl _SCON
                                    252 	.globl _TH1
                                    253 	.globl _TH0
                                    254 	.globl _TL1
                                    255 	.globl _TL0
                                    256 	.globl _TMOD
                                    257 	.globl _TCON
                                    258 	.globl _XBUS_AUX
                                    259 	.globl _P7
                                    260 	.globl _P6_DIR
                                    261 	.globl _P6_OUT_PU
                                    262 	.globl _P6_IN
                                    263 	.globl _P5_DIR
                                    264 	.globl _P5_OUT_PU
                                    265 	.globl _P5_IN
                                    266 	.globl _P4_LED_KEY
                                    267 	.globl _P4_DIR_PU
                                    268 	.globl _P4_MOD_OC
                                    269 	.globl _P4
                                    270 	.globl _P3_DIR_PU
                                    271 	.globl _P3_MOD_OC
                                    272 	.globl _P3
                                    273 	.globl _P2_DIR_PU
                                    274 	.globl _P2_MOD_OC
                                    275 	.globl _P2
                                    276 	.globl _P1_DIR_PU
                                    277 	.globl _P1_MOD_OC
                                    278 	.globl _P1
                                    279 	.globl _P0_DIR_PU
                                    280 	.globl _P0_MOD_OC
                                    281 	.globl _P0
                                    282 	.globl _ROM_CTRL
                                    283 	.globl _ROM_DATA_HH
                                    284 	.globl _ROM_DATA_HL
                                    285 	.globl _ROM_DATA_HI
                                    286 	.globl _ROM_ADDR_H
                                    287 	.globl _ROM_ADDR_L
                                    288 	.globl _ROM_ADDR
                                    289 	.globl _GPIO_IE
                                    290 	.globl _IP_EX
                                    291 	.globl _IE_EX
                                    292 	.globl _IP
                                    293 	.globl _IE
                                    294 	.globl _WDOG_COUNT
                                    295 	.globl _RESET_KEEP
                                    296 	.globl _WAKE_CTRL
                                    297 	.globl _CLOCK_CFG
                                    298 	.globl _POWER_CFG
                                    299 	.globl _PCON
                                    300 	.globl _GLOBAL_CFG
                                    301 	.globl _SAFE_MOD
                                    302 	.globl _DPH
                                    303 	.globl _DPL
                                    304 	.globl _SP
                                    305 	.globl _A_INV
                                    306 	.globl _B
                                    307 	.globl _ACC
                                    308 	.globl _PSW
                                    309 	.globl _disable_action_cache
                                    310 	.globl _tap_code_delay_PARM_2
                                    311 	.globl _process_action_PARM_2
                                    312 	.globl _register_mouse_PARM_2
                                    313 	.globl _action_exec_PARM_1
                                    314 	.globl _tp_buttons
                                    315 	.globl _action_exec
                                    316 	.globl _ak820_action_exec
                                    317 	.globl _process_record
                                    318 	.globl _process_record_handler
                                    319 	.globl _process_action
                                    320 	.globl _register_code
                                    321 	.globl _unregister_code
                                    322 	.globl _tap_code_delay
                                    323 	.globl _tap_code
                                    324 	.globl _register_mods
                                    325 	.globl _unregister_mods
                                    326 	.globl _register_weak_mods
                                    327 	.globl _unregister_weak_mods
                                    328 	.globl _clear_keyboard
                                    329 	.globl _clear_keyboard_but_mods
                                    330 	.globl _clear_keyboard_but_mods_and_keys
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000026                        593 _process_action_sloc0_1_0:
      000026                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; overlayable items in internal ram
                                    597 ;--------------------------------------------------------
                                    598 ;--------------------------------------------------------
                                    599 ; indirectly addressable internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area ISEG    (DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; absolute internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area IABS    (ABS,DATA)
                                    606 	.area IABS    (ABS,DATA)
                                    607 ;--------------------------------------------------------
                                    608 ; bit data
                                    609 ;--------------------------------------------------------
                                    610 	.area BSEG    (BIT)
      00001D                        611 _process_action_sloc1_1_0:
      00001D                        612 	.ds 1
                                    613 ;--------------------------------------------------------
                                    614 ; paged external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area PSEG    (PAG,XDATA)
                                    617 ;--------------------------------------------------------
                                    618 ; uninitialized external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area XSEG    (XDATA)
      00082F                        621 _tp_buttons::
      00082F                        622 	.ds 2
      000831                        623 _action_exec_PARM_1:
      000831                        624 	.ds 6
      000837                        625 _action_exec_record_10001_625:
      000837                        626 	.ds 9
      000840                        627 _ak820_action_exec_event_10000_629:
      000840                        628 	.ds 2
      000842                        629 _ak820_action_exec_snapshot_10000_630:
      000842                        630 	.ds 6
      000848                        631 _process_record_record_argument_10000_633:
      000848                        632 	.ds 2
      00084A                        633 _process_record_handler_record_argument_10000_641:
      00084A                        634 	.ds 2
      00084C                        635 _process_record_handler_action_10000_642:
      00084C                        636 	.ds 2
      00084E                        637 _register_mouse_PARM_2:
      00084E                        638 	.ds 1
      00084F                        639 _register_mouse_mouse_keycode_10000_650:
      00084F                        640 	.ds 1
      000850                        641 _process_action_PARM_2:
      000850                        642 	.ds 2
      000852                        643 _process_action_record_argument_10000_657:
      000852                        644 	.ds 2
      000854                        645 _process_action_on_40000_680:
      000854                        646 	.ds 1
      000855                        647 _register_code_code_10000_714:
      000855                        648 	.ds 1
      000856                        649 _unregister_code_code_10000_728:
      000856                        650 	.ds 1
      000857                        651 _tap_code_delay_PARM_2:
      000857                        652 	.ds 2
      000859                        653 _tap_code_delay_code_10000_741:
      000859                        654 	.ds 1
      00085A                        655 _tap_code_code_10000_748:
      00085A                        656 	.ds 1
      00085B                        657 _register_mods_mods_10000_750:
      00085B                        658 	.ds 1
      00085C                        659 _unregister_mods_mods_10000_754:
      00085C                        660 	.ds 1
      00085D                        661 _register_weak_mods_mods_10000_758:
      00085D                        662 	.ds 1
      00085E                        663 _unregister_weak_mods_mods_10000_762:
      00085E                        664 	.ds 1
                                    665 ;--------------------------------------------------------
                                    666 ; absolute external ram data
                                    667 ;--------------------------------------------------------
                                    668 	.area XABS    (ABS,XDATA)
                                    669 ;--------------------------------------------------------
                                    670 ; initialized external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XISEG   (XDATA)
      000DB7                        673 _disable_action_cache::
      000DB7                        674 	.ds 1
                                    675 	.area HOME    (CODE)
                                    676 	.area GSINIT0 (CODE)
                                    677 	.area GSINIT1 (CODE)
                                    678 	.area GSINIT2 (CODE)
                                    679 	.area GSINIT3 (CODE)
                                    680 	.area GSINIT4 (CODE)
                                    681 	.area GSINIT5 (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area CSEG    (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; global & static initialisations
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area GSINIT  (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; Home
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area HOME    (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; code
                                    699 ;--------------------------------------------------------
                                    700 	.area CSEG    (CODE)
                                    701 ;------------------------------------------------------------
                                    702 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    703 ;------------------------------------------------------------
                                    704 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    705 ;------------------------------------------------------------
                                    706 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    707 ;	-----------------------------------------
                           000007   708 	ar7 = 0x07
                           000006   709 	ar6 = 0x06
                           000005   710 	ar5 = 0x05
                           000004   711 	ar4 = 0x04
                           000003   712 	ar3 = 0x03
                           000002   713 	ar2 = 0x02
                           000001   714 	ar1 = 0x01
                           000000   715 	ar0 = 0x00
                                    716 ;	 function action_exec
                                    717 ;	-----------------------------------------
      007407                        718 _action_exec:
                                    719 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007407 90 08 33         [24]  720 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00740A 12 37 98         [24]  721 	lcall	_ak820_outline_0004
      00740D 12 35 B7         [24]  722 	lcall	_ak820_combo_tick
                                    723 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007410 90 08 31         [24]  724 	mov	dptr,#_action_exec_PARM_1
      007413 12 45 49         [24]  725 	lcall	_ak820_tapping_before
      007416 E5 82            [12]  726 	mov	a, dpl
      007418 70 01            [24]  727 	jnz	00102$
      00741A 22               [24]  728 	ret
      00741B                        729 00102$:
                                    730 ;	quantum/action.c:126: if (event.pressed) {
      00741B 90 08 36         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00741E E0               [24]  732 	movx	a,@dptr
      00741F 60 03            [24]  733 	jz	00104$
                                    734 ;	quantum/action.c:128: clear_weak_mods();
      007421 12 84 4E         [24]  735 	lcall	_clear_weak_mods
      007424                        736 00104$:
                                    737 ;	quantum/action.c:140: record.event = event;
      007424 90 0D 97         [24]  738 	mov	dptr,#___memcpy_PARM_2
      007427 74 31            [12]  739 	mov	a,#_action_exec_PARM_1
      007429 F0               [24]  740 	movx	@dptr,a
      00742A 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      00742C 12 7A DF         [24]  742 	lcall	_ak820_outline_0050
      00742F 12 7A FF         [24]  743 	lcall	_ak820_outline_0107
      007432 90 08 37         [24]  744 	mov	dptr,#_action_exec_record_10001_625
      007435 F5 F0            [12]  745 	mov	b,a
      007437 12 B9 FF         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:142: record.tap.count = 0;
      00743A 90 08 3D         [24]  748 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      00743D E0               [24]  749 	movx	a,@dptr
      00743E 54 0F            [12]  750 	anl	a,#0x0f
      007440 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:147: record.keycode = 0;
      007441 90 08 3E         [24]  753 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007444 12 50 28         [24]  754 	lcall	_ak820_outline_0166
                                    755 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007447 90 08 3B         [24]  756 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      00744A E0               [24]  757 	movx	a,@dptr
      00744B 60 0A            [24]  758 	jz	00107$
      00744D 90 08 37         [24]  759 	mov	dptr,#_action_exec_record_10001_625
      007450 12 A1 80         [24]  760 	lcall	_pre_process_record_quantum
      007453 E5 82            [12]  761 	mov	a, dpl
      007455 60 10            [24]  762 	jz	00110$
      007457                        763 00107$:
                                    764 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007457 90 08 37         [24]  765 	mov	dptr,#_action_exec_record_10001_625
      00745A 12 46 33         [24]  766 	lcall	_ak820_tapping_process
      00745D E5 82            [12]  767 	mov	a, dpl
      00745F 70 01            [24]  768 	jnz	00106$
      007461 22               [24]  769 	ret
      007462                        770 00106$:
                                    771 ;	quantum/action.c:185: process_record(&record);
      007462 90 08 37         [24]  772 	mov	dptr,#_action_exec_record_10001_625
                                    773 ;	quantum/action.c:200: }
      007465 81 A4            [12]  774 	ajmp	_process_record
      007467                        775 00110$:
      007467 22               [24]  776 	ret
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'ak820_action_exec'
                                    779 ;------------------------------------------------------------
                                    780 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    781 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    782 ;------------------------------------------------------------
                                    783 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    784 ;	-----------------------------------------
                                    785 ;	 function ak820_action_exec
                                    786 ;	-----------------------------------------
      007468                        787 _ak820_action_exec:
      007468 12 38 3B         [24]  788 	lcall	_ak820_outline_0103
      00746B 90 08 40         [24]  789 	mov	dptr,#_ak820_action_exec_event_10000_629
      00746E 12 38 40         [24]  790 	lcall	_ak820_outline_0104
                                    791 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007471 90 08 40         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_629
      007474 12 38 0F         [24]  793 	lcall	_ak820_outline_0058
      007477 90 0D 97         [24]  794 	mov	dptr,#___memcpy_PARM_2
      00747A ED               [12]  795 	mov	a,r5
      00747B 12 37 D7         [24]  796 	lcall	_ak820_outline_0016
      00747E 90 0D 9A         [24]  797 	mov	dptr,#___memcpy_PARM_3
      007481 12 7A FF         [24]  798 	lcall	_ak820_outline_0107
      007484 90 08 42         [24]  799 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      007487 F5 F0            [12]  800 	mov	b,a
      007489 12 B9 FF         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:207: action_exec(snapshot);
      00748C 90 0D 97         [24]  803 	mov	dptr,#___memcpy_PARM_2
      00748F 74 42            [12]  804 	mov	a,#_ak820_action_exec_snapshot_10000_630
      007491 F0               [24]  805 	movx	@dptr,a
      007492 74 08            [12]  806 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      007494 12 7A DF         [24]  807 	lcall	_ak820_outline_0050
      007497 12 7A FF         [24]  808 	lcall	_ak820_outline_0107
      00749A 90 08 31         [24]  809 	mov	dptr,#_action_exec_PARM_1
      00749D F5 F0            [12]  810 	mov	b,a
      00749F 12 B9 FF         [24]  811 	lcall	___memcpy
                                    812 ;	quantum/action.c:208: }
      0074A2 81 07            [12]  813 	ajmp	_action_exec
                                    814 ;------------------------------------------------------------
                                    815 ;Allocation info for local variables in function 'process_record_nocache'
                                    816 ;------------------------------------------------------------
                                    817 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function process_record
                                    822 ;	-----------------------------------------
      0074A4                        823 _process_record:
      0074A4 12 38 3B         [24]  824 	lcall	_ak820_outline_0103
      0074A7 90 08 48         [24]  825 	mov	dptr,#_process_record_record_argument_10000_633
      0074AA 12 38 40         [24]  826 	lcall	_ak820_outline_0104
                                    827 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074AD 90 08 48         [24]  828 	mov	dptr,#_process_record_record_argument_10000_633
      0074B0 12 37 F8         [24]  829 	lcall	_ak820_outline_0051
                                    830 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0074B3 74 04            [12]  831 	mov	a,#0x04
      0074B5 12 49 04         [24]  832 	lcall	_ak820_outline_0012
      0074B8 70 01            [24]  833 	jnz	00102$
                                    834 ;	quantum/action.c:354: return;
      0074BA 22               [24]  835 	ret
      0074BB                        836 00102$:
                                    837 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0074BB 8E 04            [24]  838 	mov	ar4,r6
      0074BD 8F 05            [24]  839 	mov	ar5,r7
      0074BF 90 0D 97         [24]  840 	mov	dptr,#___memcpy_PARM_2
      0074C2 EC               [12]  841 	mov	a,r4
      0074C3 F0               [24]  842 	movx	@dptr,a
      0074C4 ED               [12]  843 	mov	a,r5
      0074C5 12 7A DF         [24]  844 	lcall	_ak820_outline_0050
      0074C8 12 50 1A         [24]  845 	lcall	_ak820_outline_0106
      0074CB 90 06 28         [24]  846 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074CE F5 F0            [12]  847 	mov	b,a
      0074D0 C0 07            [24]  848 	push	ar7
      0074D2 C0 06            [24]  849 	push	ar6
      0074D4 12 B9 FF         [24]  850 	lcall	___memcpy
      0074D7 12 44 86         [24]  851 	lcall	_ak820_tapping_source
      0074DA AD 82            [24]  852 	mov	r5, dpl
      0074DC D0 06            [24]  853 	pop	ar6
      0074DE D0 07            [24]  854 	pop	ar7
                                    855 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0074E0 12 43 25         [24]  856 	lcall	_ak820_outline_0011
      0074E3 E0               [24]  857 	movx	a,@dptr
      0074E4 FC               [12]  858 	mov	r4,a
                                    859 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0074E5 74 07            [12]  860 	mov	a,#0x07
      0074E7 2E               [12]  861 	add	a, r6
      0074E8 FA               [12]  862 	mov	r2,a
      0074E9 E4               [12]  863 	clr	a
      0074EA 3F               [12]  864 	addc	a, r7
      0074EB FB               [12]  865 	mov	r3,a
      0074EC 90 0B F9         [24]  866 	mov	dptr,#_get_record_keycode_PARM_2
      0074EF 12 49 4E         [24]  867 	lcall	_ak820_outline_0055
      0074F2 C0 07            [24]  868 	push	ar7
      0074F4 C0 06            [24]  869 	push	ar6
      0074F6 C0 05            [24]  870 	push	ar5
      0074F8 C0 04            [24]  871 	push	ar4
      0074FA C0 03            [24]  872 	push	ar3
      0074FC C0 02            [24]  873 	push	ar2
      0074FE 12 A1 43         [24]  874 	lcall	_get_record_keycode
      007501 A8 82            [24]  875 	mov	r0, dpl
      007503 A9 83            [24]  876 	mov	r1, dph
      007505 D0 02            [24]  877 	pop	ar2
      007507 D0 03            [24]  878 	pop	ar3
      007509 D0 04            [24]  879 	pop	ar4
      00750B D0 05            [24]  880 	pop	ar5
      00750D D0 06            [24]  881 	pop	ar6
      00750F D0 07            [24]  882 	pop	ar7
      007511 12 43 9C         [24]  883 	lcall	_ak820_outline_0142
      007514 E8               [12]  884 	mov	a,r0
      007515 F0               [24]  885 	movx	@dptr,a
      007516 E9               [12]  886 	mov	a,r1
      007517 A3               [24]  887 	inc	dptr
      007518 F0               [24]  888 	movx	@dptr,a
                                    889 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007519 74 07            [12]  890 	mov	a,#0x07
      00751B 12 37 DF         [24]  891 	lcall	_ak820_outline_0017
      00751E FA               [12]  892 	mov	r2,a
      00751F A3               [24]  893 	inc	dptr
      007520 E0               [24]  894 	movx	a,@dptr
      007521 FB               [12]  895 	mov	r3,a
      007522 90 06 38         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007525 ED               [12]  897 	mov	a,r5
      007526 F0               [24]  898 	movx	@dptr,a
      007527 90 06 39         [24]  899 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00752A EC               [12]  900 	mov	a,r4
      00752B F0               [24]  901 	movx	@dptr,a
      00752C 12 43 9C         [24]  902 	lcall	_ak820_outline_0142
      00752F C0 07            [24]  903 	push	ar7
      007531 C0 06            [24]  904 	push	ar6
      007533 C0 05            [24]  905 	push	ar5
      007535 C0 04            [24]  906 	push	ar4
      007537 12 47 CF         [24]  907 	lcall	_ak820_oneshot_process
      00753A E5 82            [12]  908 	mov	a, dpl
      00753C D0 04            [24]  909 	pop	ar4
      00753E D0 05            [24]  910 	pop	ar5
      007540 D0 06            [24]  911 	pop	ar6
      007542 D0 07            [24]  912 	pop	ar7
      007544 70 01            [24]  913 	jnz	00104$
      007546 22               [24]  914 	ret
      007547                        915 00104$:
                                    916 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007547 12 43 80         [24]  917 	lcall	_ak820_outline_0116
      00754A C0 07            [24]  918 	push	ar7
      00754C C0 06            [24]  919 	push	ar6
      00754E C0 05            [24]  920 	push	ar5
      007550 C0 04            [24]  921 	push	ar4
      007552 12 A1 C1         [24]  922 	lcall	_process_record_quantum
      007555 E5 82            [12]  923 	mov	a, dpl
      007557 D0 04            [24]  924 	pop	ar4
      007559 D0 05            [24]  925 	pop	ar5
      00755B D0 06            [24]  926 	pop	ar6
      00755D D0 07            [24]  927 	pop	ar7
      00755F 70 0A            [24]  928 	jnz	00106$
                                    929 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007561 90 05 98         [24]  930 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007564 EC               [12]  931 	mov	a,r4
      007565 F0               [24]  932 	movx	@dptr,a
      007566 8D 82            [24]  933 	mov	dpl, r5
                                    934 ;	quantum/action.c:376: return;
      007568 02 2E 6F         [24]  935 	ljmp	_ak820_oneshot_post
      00756B                        936 00106$:
                                    937 ;	quantum/action.c:382: process_record_handler(record);
      00756B 12 43 80         [24]  938 	lcall	_ak820_outline_0116
      00756E C0 05            [24]  939 	push	ar5
      007570 C0 04            [24]  940 	push	ar4
      007572 B1 82            [24]  941 	acall	_process_record_handler
      007574 D0 04            [24]  942 	pop	ar4
      007576 D0 05            [24]  943 	pop	ar5
                                    944 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007578 90 05 98         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00757B EC               [12]  946 	mov	a,r4
      00757C F0               [24]  947 	movx	@dptr,a
      00757D 8D 82            [24]  948 	mov	dpl, r5
                                    949 ;	quantum/action.c:392: }
      00757F 02 2E 6F         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      007582                        962 _process_record_handler:
      007582 12 38 3B         [24]  963 	lcall	_ak820_outline_0103
      007585 90 08 4A         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007588 12 38 40         [24]  965 	lcall	_ak820_outline_0104
                                    966 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00758B 90 08 4A         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_641
      00758E 12 37 AF         [24]  968 	lcall	_ak820_outline_0009
                                    969 ;	quantum/action.c:405: if (record->keycode) {
      007591 4C               [12]  970 	orl	a,r4
      007592 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007594 12 38 4C         [24]  973 	lcall	_ak820_outline_0117
      007597 C0 07            [24]  974 	push	ar7
      007599 C0 06            [24]  975 	push	ar6
      00759B 12 98 26         [24]  976 	lcall	_action_for_keycode
      00759E 12 43 A1         [24]  977 	lcall	_ak820_outline_0148
      0075A1 D0 06            [24]  978 	pop	ar6
      0075A3 D0 07            [24]  979 	pop	ar7
      0075A5 90 08 4C         [24]  980 	mov	dptr,#_process_record_handler_action_10000_642
      0075A8 12 38 1D         [24]  981 	lcall	_ak820_outline_0071
      0075AB 80 2A            [24]  982 	sjmp	00104$
      0075AD                        983 00102$:
                                    984 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0075AD 12 7A C7         [24]  985 	lcall	_ak820_outline_0020
      0075B0 7A 00            [12]  986 	mov	r2,#0x00
      0075B2 12 43 96         [24]  987 	lcall	_ak820_outline_0141
      0075B5 12 43 25         [24]  988 	lcall	_ak820_outline_0011
      0075B8 E0               [24]  989 	movx	a,@dptr
      0075B9 90 09 89         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      0075BC F0               [24]  991 	movx	@dptr,a
      0075BD 12 43 C1         [24]  992 	lcall	_ak820_outline_0185
      0075C0 C0 07            [24]  993 	push	ar7
      0075C2 C0 06            [24]  994 	push	ar6
      0075C4 12 7E 50         [24]  995 	lcall	_ak820_resolve_key
      0075C7 12 98 26         [24]  996 	lcall	_action_for_keycode
      0075CA 12 43 A1         [24]  997 	lcall	_ak820_outline_0148
      0075CD D0 06            [24]  998 	pop	ar6
      0075CF D0 07            [24]  999 	pop	ar7
      0075D1 90 08 4C         [24] 1000 	mov	dptr,#_process_record_handler_action_10000_642
      0075D4 12 38 1D         [24] 1001 	lcall	_ak820_outline_0071
                                   1002 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0075D7                       1003 00104$:
                                   1004 ;	quantum/action.c:429: process_action(record, action);
      0075D7 90 0D 97         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      0075DA 74 4C            [12] 1006 	mov	a,#_process_record_handler_action_10000_642
      0075DC F0               [24] 1007 	movx	@dptr,a
      0075DD 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      0075DF 12 7A DF         [24] 1009 	lcall	_ak820_outline_0050
      0075E2 12 50 1A         [24] 1010 	lcall	_ak820_outline_0106
      0075E5 90 08 50         [24] 1011 	mov	dptr,#_process_action_PARM_2
      0075E8 F5 F0            [12] 1012 	mov	b,a
      0075EA C0 07            [24] 1013 	push	ar7
      0075EC C0 06            [24] 1014 	push	ar6
      0075EE 12 B9 FF         [24] 1015 	lcall	___memcpy
      0075F1 D0 06            [24] 1016 	pop	ar6
      0075F3 D0 07            [24] 1017 	pop	ar7
      0075F5 12 43 80         [24] 1018 	lcall	_ak820_outline_0116
                                   1019 ;	quantum/action.c:430: }
      0075F8 C1 1D            [24] 1020 	ajmp	_process_action
                                   1021 ;------------------------------------------------------------
                                   1022 ;Allocation info for local variables in function 'register_mouse'
                                   1023 ;------------------------------------------------------------
                                   1024 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1025 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1026 ;------------------------------------------------------------
                                   1027 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1028 ;	-----------------------------------------
                                   1029 ;	 function register_mouse
                                   1030 ;	-----------------------------------------
      0075FA                       1031 _register_mouse:
      0075FA E5 82            [12] 1032 	mov	a,dpl
      0075FC 90 08 4F         [24] 1033 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0075FF F0               [24] 1034 	movx	@dptr,a
                                   1035 ;	quantum/action.c:445: if (pressed) {
      007600 90 08 4E         [24] 1036 	mov	dptr,#_register_mouse_PARM_2
      007603 E0               [24] 1037 	movx	a,@dptr
      007604 60 0B            [24] 1038 	jz	00102$
                                   1039 ;	quantum/action.c:446: mousekey_on(mouse_keycode);
      007606 90 08 4F         [24] 1040 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      007609 E0               [24] 1041 	movx	a,@dptr
      00760A F5 82            [12] 1042 	mov	dpl,a
      00760C 12 50 78         [24] 1043 	lcall	_mousekey_on
      00760F 80 09            [24] 1044 	sjmp	00103$
      007611                       1045 00102$:
                                   1046 ;	quantum/action.c:448: mousekey_off(mouse_keycode);
      007611 90 08 4F         [24] 1047 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      007614 E0               [24] 1048 	movx	a,@dptr
      007615 F5 82            [12] 1049 	mov	dpl,a
      007617 12 50 EC         [24] 1050 	lcall	_mousekey_off
      00761A                       1051 00103$:
                                   1052 ;	quantum/action.c:469: mousekey_send();
                                   1053 ;	quantum/action.c:471: }
                                   1054 ;	quantum/action.c:487: }
      00761A 02 51 4B         [24] 1055 	ljmp	_mousekey_send
                                   1056 ;------------------------------------------------------------
                                   1057 ;Allocation info for local variables in function 'process_action'
                                   1058 ;------------------------------------------------------------
                                   1059 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1060 ;action        Allocated with name '_process_action_PARM_2'
                                   1061 ;record_argument Allocated with name '_process_action_record_argument_10000_657'
                                   1062 ;record        Allocated with name '_process_action_record_10000_658'
                                   1063 ;pressed       Allocated with name '_process_action_pressed_10000_658'
                                   1064 ;mods          Allocated with name '_process_action_mods_10000_658'
                                   1065 ;on            Allocated with name '_process_action_on_40000_680'
                                   1066 ;shift         Allocated with name '_process_action_shift_60000_682'
                                   1067 ;bits          Allocated with name '_process_action_bits_60000_682'
                                   1068 ;mask          Allocated with name '_process_action_mask_60000_682'
                                   1069 ;i             Allocated with name '_process_action_i_110000_706'
                                   1070 ;i             Allocated with name '_process_action_i_110000_710'
                                   1071 ;------------------------------------------------------------
                                   1072 ;	quantum/action.c:493: void process_action(keyrecord_t AK820_RECORD_MEM *record_argument, action_t action) {
                                   1073 ;	-----------------------------------------
                                   1074 ;	 function process_action
                                   1075 ;	-----------------------------------------
      00761D                       1076 _process_action:
      00761D 12 38 3B         [24] 1077 	lcall	_ak820_outline_0103
      007620 90 08 52         [24] 1078 	mov	dptr,#_process_action_record_argument_10000_657
      007623 12 38 40         [24] 1079 	lcall	_ak820_outline_0104
                                   1080 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007626 90 08 52         [24] 1081 	mov	dptr,#_process_action_record_argument_10000_657
      007629 12 37 98         [24] 1082 	lcall	_ak820_outline_0004
                                   1083 ;	quantum/action.c:501: pressed = record->event.pressed;
      00762C A3               [24] 1084 	inc	dptr
      00762D A3               [24] 1085 	inc	dptr
      00762E A3               [24] 1086 	inc	dptr
      00762F A3               [24] 1087 	inc	dptr
      007630 A3               [24] 1088 	inc	dptr
      007631 E0               [24] 1089 	movx	a,@dptr
      007632 F5 26            [12] 1090 	mov	_process_action_sloc0_1_0,a
                                   1091 ;	quantum/action.c:525: switch (action.kind.id) {
      007634 90 08 51         [24] 1092 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007637 E0               [24] 1093 	movx	a,@dptr
      007638 C4               [12] 1094 	swap	a
      007639 54 0F            [12] 1095 	anl	a,#0x0f
      00763B FD               [12] 1096 	mov  r5,a
      00763C 24 F4            [12] 1097 	add	a,#0xff - 0x0b
      00763E 50 03            [24] 1098 	jnc	00434$
      007640 02 78 CE         [24] 1099 	ljmp	00181$
      007643                       1100 00434$:
                                   1101 ;	free result
      007643 ED               [12] 1102 	mov	a,r5
      007644 24 0A            [12] 1103 	add	a,#(00435$-3-.)
      007646 83               [24] 1104 	movc	a,@a+pc
      007647 F5 82            [12] 1105 	mov	dpl,a
      007649 ED               [12] 1106 	mov	a,r5
      00764A 24 10            [12] 1107 	add	a,#(00436$-3-.)
      00764C 83               [24] 1108 	movc	a,@a+pc
      00764D F5 83            [12] 1109 	mov	dph,a
      00764F E4               [12] 1110 	clr	a
      007650 73               [24] 1111 	jmp	@a+dptr
      007651                       1112 00435$:
      007651 69                    1113 	.db	00102$
      007652 69                    1114 	.db	00102$
      007653 CE                    1115 	.db	00181$
      007654 CE                    1116 	.db	00181$
      007655 F1                    1117 	.db	00123$
      007656 51                    1118 	.db	00130$
      007657 CE                    1119 	.db	00181$
      007658 CE                    1120 	.db	00181$
      007659 63                    1121 	.db	00131$
      00765A 35                    1122 	.db	00147$
      00765B 5B                    1123 	.db	00152$
      00765C 5B                    1124 	.db	00152$
      00765D                       1125 00436$:
      00765D 76                    1126 	.db	00102$>>8
      00765E 76                    1127 	.db	00102$>>8
      00765F 78                    1128 	.db	00181$>>8
      007660 78                    1129 	.db	00181$>>8
      007661 76                    1130 	.db	00123$>>8
      007662 77                    1131 	.db	00130$>>8
      007663 78                    1132 	.db	00181$>>8
      007664 78                    1133 	.db	00181$>>8
      007665 77                    1134 	.db	00131$>>8
      007666 78                    1135 	.db	00147$>>8
      007667 78                    1136 	.db	00152$>>8
      007668 78                    1137 	.db	00152$>>8
                                   1138 ;	quantum/action.c:528: case ACT_RMODS: {
      007669                       1139 00102$:
                                   1140 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007669 90 08 51         [24] 1141 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00766C E0               [24] 1142 	movx	a,@dptr
      00766D 54 F0            [12] 1143 	anl	a,#0xf0
      00766F 70 06            [24] 1144 	jnz	00194$
      007671 12 7B 06         [24] 1145 	lcall	_ak820_outline_0109
      007674 FD               [12] 1146 	mov	r5,a
      007675 80 07            [24] 1147 	sjmp	00195$
      007677                       1148 00194$:
      007677 12 7B 06         [24] 1149 	lcall	_ak820_outline_0109
      00767A C4               [12] 1150 	swap	a
      00767B 54 F0            [12] 1151 	anl	a,#0xf0
      00767D FD               [12] 1152 	mov	r5,a
      00767E                       1153 00195$:
                                   1154 ;	quantum/action.c:531: if (pressed) {
      00767E E5 26            [12] 1155 	mov	a,_process_action_sloc0_1_0
      007680 60 34            [24] 1156 	jz	00119$
                                   1157 ;	quantum/action.c:532: if (mods) {
      007682 ED               [12] 1158 	mov	a,r5
      007683 60 28            [24] 1159 	jz	00110$
                                   1160 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007685 12 7B 24         [24] 1161 	lcall	_ak820_outline_0147
      007688 FC               [12] 1162 	mov	r4,a
      007689 BC E0 00         [24] 1163 	cjne	r4,#0xe0,00440$
      00768C                       1164 00440$:
      00768C 40 07            [24] 1165 	jc	00108$
      00768E 12 7B 24         [24] 1166 	lcall	_ak820_outline_0147
      007691 24 18            [12] 1167 	add	a,#0xff - 0xe7
      007693 50 09            [24] 1168 	jnc	00104$
                                   1169 ;	free result
      007695                       1170 00108$:
      007695 7B 50            [12] 1171 	mov	r3,#_process_action_PARM_2
      007697 7C 08            [12] 1172 	mov	r4,#(_process_action_PARM_2 >> 8)
      007699 12 70 3E         [24] 1173 	lcall	_ak820_outline_0118
      00769C 70 07            [24] 1174 	jnz	00105$
      00769E                       1175 00104$:
                                   1176 ;	quantum/action.c:537: add_owned_mods(mods);
      00769E 8D 82            [24] 1177 	mov	dpl, r5
      0076A0 12 80 66         [24] 1178 	lcall	_add_owned_mods
      0076A3 80 05            [24] 1179 	sjmp	00106$
      0076A5                       1180 00105$:
                                   1181 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      0076A5 8D 82            [24] 1182 	mov	dpl, r5
      0076A7 12 80 84         [24] 1183 	lcall	_add_owned_weak_mods
      0076AA                       1184 00106$:
                                   1185 ;	quantum/action.c:541: send_keyboard_report();
      0076AA 12 83 9E         [24] 1186 	lcall	_send_keyboard_report
      0076AD                       1187 00110$:
                                   1188 ;	quantum/action.c:543: register_code(action.key.code);
      0076AD 12 7A EF         [24] 1189 	lcall	_ak820_outline_0076
      0076B0 12 78 E5         [24] 1190 	lcall	_register_code
      0076B3 02 78 CE         [24] 1191 	ljmp	00181$
      0076B6                       1192 00119$:
                                   1193 ;	quantum/action.c:545: unregister_code(action.key.code);
      0076B6 12 7A EF         [24] 1194 	lcall	_ak820_outline_0076
      0076B9 C0 05            [24] 1195 	push	ar5
      0076BB 12 79 6A         [24] 1196 	lcall	_unregister_code
      0076BE D0 05            [24] 1197 	pop	ar5
                                   1198 ;	quantum/action.c:546: if (mods) {
      0076C0 ED               [12] 1199 	mov	a,r5
      0076C1 70 03            [24] 1200 	jnz	00444$
      0076C3 02 78 CE         [24] 1201 	ljmp	00181$
      0076C6                       1202 00444$:
                                   1203 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076C6 12 7B 24         [24] 1204 	lcall	_ak820_outline_0147
      0076C9 FC               [12] 1205 	mov	r4,a
      0076CA BC E0 00         [24] 1206 	cjne	r4,#0xe0,00445$
      0076CD                       1207 00445$:
      0076CD 40 07            [24] 1208 	jc	00115$
      0076CF 12 7B 24         [24] 1209 	lcall	_ak820_outline_0147
      0076D2 24 18            [12] 1210 	add	a,#0xff - 0xe7
      0076D4 50 09            [24] 1211 	jnc	00111$
                                   1212 ;	free result
      0076D6                       1213 00115$:
      0076D6 7B 50            [12] 1214 	mov	r3,#_process_action_PARM_2
      0076D8 7C 08            [12] 1215 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076DA 12 70 3E         [24] 1216 	lcall	_ak820_outline_0118
      0076DD 70 07            [24] 1217 	jnz	00112$
      0076DF                       1218 00111$:
                                   1219 ;	quantum/action.c:548: del_owned_mods(mods);
      0076DF 8D 82            [24] 1220 	mov	dpl, r5
      0076E1 12 80 76         [24] 1221 	lcall	_del_owned_mods
      0076E4 80 05            [24] 1222 	sjmp	00113$
      0076E6                       1223 00112$:
                                   1224 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0076E6 8D 82            [24] 1225 	mov	dpl, r5
      0076E8 12 80 94         [24] 1226 	lcall	_del_owned_weak_mods
      0076EB                       1227 00113$:
                                   1228 ;	quantum/action.c:552: send_keyboard_report();
      0076EB 12 83 9E         [24] 1229 	lcall	_send_keyboard_report
                                   1230 ;	quantum/action.c:555: } break;
      0076EE 02 78 CE         [24] 1231 	ljmp	00181$
                                   1232 ;	quantum/action.c:632: case ACT_USAGE:
      0076F1                       1233 00123$:
                                   1234 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0076F1 74 07            [12] 1235 	mov	a,#0x07
      0076F3 12 37 E8         [24] 1236 	lcall	_ak820_outline_0031
      0076F6 12 37 C3         [24] 1237 	lcall	_ak820_outline_0010
      0076F9 C3               [12] 1238 	clr	c
      0076FA EC               [12] 1239 	mov	a,r4
      0076FB 94 A5            [12] 1240 	subb	a,#0xa5
      0076FD ED               [12] 1241 	mov	a,r5
      0076FE 94 00            [12] 1242 	subb	a,#0x00
      007700 40 15            [24] 1243 	jc	00125$
      007702 74 C2            [12] 1244 	mov	a,#0xc2
      007704 9C               [12] 1245 	subb	a,r4
      007705 E4               [12] 1246 	clr	a
      007706 9D               [12] 1247 	subb	a,r5
      007707 40 0E            [24] 1248 	jc	00125$
                                   1249 ;	free result
                                   1250 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007709 90 0A B0         [24] 1251 	mov	dptr,#_owned_usage_key_PARM_2
      00770C E5 26            [12] 1252 	mov	a,_process_action_sloc0_1_0
      00770E F0               [24] 1253 	movx	@dptr,a
      00770F 8E 82            [24] 1254 	mov	dpl, r6
      007711 12 82 4A         [24] 1255 	lcall	_owned_usage_key
                                   1256 ;	quantum/action.c:640: break;
      007714 02 78 CE         [24] 1257 	ljmp	00181$
      007717                       1258 00125$:
                                   1259 ;	quantum/action.c:643: switch (action.usage.page) {
      007717 12 7A F6         [24] 1260 	lcall	_ak820_outline_0086
      00771A FF               [12] 1261 	mov	r7,a
      00771B 60 08            [24] 1262 	jz	00127$
      00771D BF 01 02         [24] 1263 	cjne	r7,#0x01,00452$
      007720 80 19            [24] 1264 	sjmp	00128$
      007722                       1265 00452$:
      007722 02 78 CE         [24] 1266 	ljmp	00181$
                                   1267 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007725                       1268 00127$:
                                   1269 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007725 E5 26            [12] 1270 	mov	a,_process_action_sloc0_1_0
      007727 60 05            [24] 1271 	jz	00196$
      007729 12 7B 0D         [24] 1272 	lcall	_ak820_outline_0129
      00772C 80 04            [24] 1273 	sjmp	00197$
      00772E                       1274 00196$:
      00772E 7E 00            [12] 1275 	mov	r6,#0x00
      007730 7F 00            [12] 1276 	mov	r7,#0x00
      007732                       1277 00197$:
      007732 12 43 80         [24] 1278 	lcall	_ak820_outline_0116
      007735 12 71 07         [24] 1279 	lcall	_host_system_send
                                   1280 ;	quantum/action.c:646: break;
      007738 02 78 CE         [24] 1281 	ljmp	00181$
                                   1282 ;	quantum/action.c:647: case PAGE_CONSUMER:
      00773B                       1283 00128$:
                                   1284 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      00773B E5 26            [12] 1285 	mov	a,_process_action_sloc0_1_0
      00773D 60 05            [24] 1286 	jz	00198$
      00773F 12 7B 0D         [24] 1287 	lcall	_ak820_outline_0129
      007742 80 04            [24] 1288 	sjmp	00199$
      007744                       1289 00198$:
      007744 7E 00            [12] 1290 	mov	r6,#0x00
      007746 7F 00            [12] 1291 	mov	r7,#0x00
      007748                       1292 00199$:
      007748 12 43 80         [24] 1293 	lcall	_ak820_outline_0116
      00774B 12 71 36         [24] 1294 	lcall	_host_consumer_send
                                   1295 ;	quantum/action.c:651: break;
      00774E 02 78 CE         [24] 1296 	ljmp	00181$
                                   1297 ;	quantum/action.c:654: case ACT_MOUSEKEY:
      007751                       1298 00130$:
                                   1299 ;	quantum/action.c:655: register_mouse(action.key.code, pressed);
      007751 12 7B 24         [24] 1300 	lcall	_ak820_outline_0147
      007754 FF               [12] 1301 	mov	r7,a
      007755 90 08 4E         [24] 1302 	mov	dptr,#_register_mouse_PARM_2
      007758 E5 26            [12] 1303 	mov	a,_process_action_sloc0_1_0
      00775A F0               [24] 1304 	movx	@dptr,a
      00775B 8F 82            [24] 1305 	mov	dpl, r7
      00775D 12 75 FA         [24] 1306 	lcall	_register_mouse
                                   1307 ;	quantum/action.c:656: break;
      007760 02 78 CE         [24] 1308 	ljmp	00181$
                                   1309 ;	quantum/action.c:658: case ACT_LAYER: {
      007763                       1310 00131$:
                                   1311 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007763 90 08 51         [24] 1312 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007766 E0               [24] 1313 	movx	a,@dptr
      007767 54 03            [12] 1314 	anl	a,#0x03
      007769 90 08 54         [24] 1315 	mov	dptr,#_process_action_on_40000_680
      00776C F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00776D E0               [24] 1318 	movx	a,@dptr
      00776E FF               [12] 1319 	mov	r7,a
      00776F 60 11            [24] 1320 	jz	00200$
      007771 E5 26            [12] 1321 	mov	a,_process_action_sloc0_1_0
      007773 60 07            [24] 1322 	jz	00202$
      007775 8F 06            [24] 1323 	mov	ar6,r7
      007777 53 06 01         [24] 1324 	anl	ar6,#0x01
      00777A 80 10            [24] 1325 	sjmp	00201$
      00777C                       1326 00202$:
      00777C 74 02            [12] 1327 	mov	a,#0x02
      00777E 5F               [12] 1328 	anl	a,r7
      00777F FE               [12] 1329 	mov	r6,a
      007780 80 0A            [24] 1330 	sjmp	00201$
      007782                       1331 00200$:
      007782 E5 26            [12] 1332 	mov	a,_process_action_sloc0_1_0
      007784 B4 01 00         [24] 1333 	cjne	a,#0x01,00457$
      007787                       1334 00457$:
      007787 92 1D            [24] 1335 	mov  _process_action_sloc1_1_0,c
      007789 E4               [12] 1336 	clr	a
      00778A 33               [12] 1337 	rlc	a
      00778B FE               [12] 1338 	mov	r6,a
      00778C                       1339 00201$:
      00778C EE               [12] 1340 	mov	a,r6
      00778D 70 03            [24] 1341 	jnz	00458$
      00778F 02 78 CE         [24] 1342 	ljmp	00181$
      007792                       1343 00458$:
                                   1344 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007792 12 7B 24         [24] 1345 	lcall	_ak820_outline_0147
      007795 C4               [12] 1346 	swap	a
      007796 03               [12] 1347 	rr	a
      007797 54 07            [12] 1348 	anl	a,#0x07
      007799 25 E0            [12] 1349 	add	a,acc
      00779B 25 E0            [12] 1350 	add	a,acc
      00779D FF               [12] 1351 	mov	r7,a
                                   1352 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00779E 12 7B 24         [24] 1353 	lcall	_ak820_outline_0147
      0077A1 54 0F            [12] 1354 	anl	a,#0x0f
      0077A3 FE               [12] 1355 	mov	r6,a
      0077A4 8F F0            [24] 1356 	mov	b,r7
      0077A6 05 F0            [12] 1357 	inc	b
      0077A8 EE               [12] 1358 	mov	a,r6
      0077A9 80 02            [24] 1359 	sjmp	00460$
      0077AB                       1360 00459$:
      0077AB 25 E0            [12] 1361 	add	a,acc
      0077AD                       1362 00460$:
      0077AD D5 F0 FB         [24] 1363 	djnz	b,00459$
      0077B0 FE               [12] 1364 	mov	r6,a
                                   1365 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0077B1 12 7B 24         [24] 1366 	lcall	_ak820_outline_0147
      0077B4 30 E4 11         [24] 1367 	jnb	acc.4,00204$
      0077B7 8F F0            [24] 1368 	mov	b,r7
      0077B9 05 F0            [12] 1369 	inc	b
      0077BB 74 0F            [12] 1370 	mov	a,#0x0f
      0077BD 80 02            [24] 1371 	sjmp	00463$
      0077BF                       1372 00462$:
      0077BF 25 E0            [12] 1373 	add	a,acc
      0077C1                       1374 00463$:
      0077C1 D5 F0 FB         [24] 1375 	djnz	b,00462$
      0077C4 F4               [12] 1376 	cpl	a
      0077C5 FF               [12] 1377 	mov	r7,a
      0077C6 80 02            [24] 1378 	sjmp	00205$
      0077C8                       1379 00204$:
      0077C8 7F 00            [12] 1380 	mov	r7,#0x00
      0077CA                       1381 00205$:
                                   1382 ;	quantum/action.c:666: bits |= mask;
      0077CA EE               [12] 1383 	mov	a,r6
      0077CB 42 07            [12] 1384 	orl	ar7,a
                                   1385 ;	quantum/action.c:667: if (!on) {
      0077CD 90 08 54         [24] 1386 	mov	dptr,#_process_action_on_40000_680
      0077D0 E0               [24] 1387 	movx	a,@dptr
      0077D1 70 31            [24] 1388 	jnz	00143$
                                   1389 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0077D3 12 7A F6         [24] 1390 	lcall	_ak820_outline_0086
      0077D6 FE               [12] 1391 	mov	r6,a
      0077D7 2E               [12] 1392 	add	a,r6
                                   1393 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0077D8 90 77 DC         [24] 1394 	mov	dptr,#00465$
      0077DB 73               [24] 1395 	jmp	@a+dptr
      0077DC                       1396 00465$:
      0077DC 80 06            [24] 1397 	sjmp	00132$
      0077DE 80 0C            [24] 1398 	sjmp	00133$
      0077E0 80 12            [24] 1399 	sjmp	00134$
      0077E2 80 18            [24] 1400 	sjmp	00135$
      0077E4                       1401 00132$:
      0077E4 8F 82            [24] 1402 	mov	dpl, r7
      0077E6 12 7B 73         [24] 1403 	lcall	_default_layer_and
      0077E9 02 78 CE         [24] 1404 	ljmp	00181$
                                   1405 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0077EC                       1406 00133$:
      0077EC 8F 82            [24] 1407 	mov	dpl, r7
      0077EE 12 7B 63         [24] 1408 	lcall	_default_layer_or
      0077F1 02 78 CE         [24] 1409 	ljmp	00181$
                                   1410 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0077F4                       1411 00134$:
      0077F4 8F 82            [24] 1412 	mov	dpl, r7
      0077F6 12 7B 88         [24] 1413 	lcall	_default_layer_xor
      0077F9 02 78 CE         [24] 1414 	ljmp	00181$
                                   1415 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0077FC                       1416 00135$:
      0077FC 8F 82            [24] 1417 	mov	dpl, r7
      0077FE 12 7B 59         [24] 1418 	lcall	_default_layer_set
                                   1419 ;	quantum/action.c:673: }
      007801 02 78 CE         [24] 1420 	ljmp	00181$
      007804                       1421 00143$:
                                   1422 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007804 12 7A F6         [24] 1423 	lcall	_ak820_outline_0086
      007807 FE               [12] 1424 	mov	r6,a
      007808 2E               [12] 1425 	add	a,r6
                                   1426 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007809 90 78 0D         [24] 1427 	mov	dptr,#00466$
      00780C 73               [24] 1428 	jmp	@a+dptr
      00780D                       1429 00466$:
      00780D 80 06            [24] 1430 	sjmp	00137$
      00780F 80 0C            [24] 1431 	sjmp	00138$
      007811 80 12            [24] 1432 	sjmp	00139$
      007813 80 18            [24] 1433 	sjmp	00140$
      007815                       1434 00137$:
      007815 8F 82            [24] 1435 	mov	dpl, r7
      007817 12 7C FD         [24] 1436 	lcall	_layer_and
      00781A 02 78 CE         [24] 1437 	ljmp	00181$
                                   1438 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      00781D                       1439 00138$:
      00781D 8F 82            [24] 1440 	mov	dpl, r7
      00781F 12 7C ED         [24] 1441 	lcall	_layer_or
      007822 02 78 CE         [24] 1442 	ljmp	00181$
                                   1443 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007825                       1444 00139$:
      007825 8F 82            [24] 1445 	mov	dpl, r7
      007827 12 7D 12         [24] 1446 	lcall	_layer_xor
      00782A 02 78 CE         [24] 1447 	ljmp	00181$
                                   1448 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      00782D                       1449 00140$:
      00782D 8F 82            [24] 1450 	mov	dpl, r7
      00782F 12 7C 8F         [24] 1451 	lcall	_layer_state_set
                                   1452 ;	quantum/action.c:683: break;
      007832 02 78 CE         [24] 1453 	ljmp	00181$
                                   1454 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007835                       1455 00147$:
                                   1456 ;	quantum/action.c:686: if (pressed) {
      007835 E5 26            [12] 1457 	mov	a,_process_action_sloc0_1_0
      007837 60 11            [24] 1458 	jz	00149$
                                   1459 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007839 12 7B 06         [24] 1460 	lcall	_ak820_outline_0109
      00783C F5 82            [12] 1461 	mov	dpl,a
      00783E 12 7B F6         [24] 1462 	lcall	_layer_hold_on
                                   1463 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007841 12 7A EF         [24] 1464 	lcall	_ak820_outline_0076
      007844 12 7A 32         [24] 1465 	lcall	_register_mods
      007847 02 78 CE         [24] 1466 	ljmp	00181$
      00784A                       1467 00149$:
                                   1468 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      00784A 12 7A EF         [24] 1469 	lcall	_ak820_outline_0076
      00784D 12 7A 46         [24] 1470 	lcall	_unregister_mods
                                   1471 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007850 12 7B 06         [24] 1472 	lcall	_ak820_outline_0109
      007853 F5 82            [12] 1473 	mov	dpl,a
      007855 12 7C 2C         [24] 1474 	lcall	_layer_hold_off
                                   1475 ;	quantum/action.c:693: break;
      007858 02 78 CE         [24] 1476 	ljmp	00181$
                                   1477 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      00785B                       1478 00152$:
                                   1479 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      00785B 12 7B 24         [24] 1480 	lcall	_ak820_outline_0147
      00785E FF               [12] 1481 	mov	r7,a
      00785F BF F1 02         [24] 1482 	cjne	r7,#0xf1,00468$
      007862 80 0A            [24] 1483 	sjmp	00154$
      007864                       1484 00468$:
      007864 BF F2 02         [24] 1485 	cjne	r7,#0xf2,00469$
      007867 80 19            [24] 1486 	sjmp	00155$
      007869                       1487 00469$:
                                   1488 ;	quantum/action.c:712: momentary_layer_action:
      007869 BF F3 3B         [24] 1489 	cjne	r7,#0xf3,00160$
      00786C 80 28            [24] 1490 	sjmp	00156$
      00786E                       1491 00154$:
                                   1492 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00786E E5 26            [12] 1493 	mov	a,_process_action_sloc0_1_0
      007870 60 08            [24] 1494 	jz	00206$
      007872 12 7A D6         [24] 1495 	lcall	_ak820_outline_0039
      007875 12 7B F6         [24] 1496 	lcall	_layer_hold_on
      007878 80 54            [24] 1497 	sjmp	00181$
      00787A                       1498 00206$:
      00787A 12 7A D6         [24] 1499 	lcall	_ak820_outline_0039
      00787D 12 7C 2C         [24] 1500 	lcall	_layer_hold_off
                                   1501 ;	quantum/action.c:714: break;
                                   1502 ;	quantum/action.c:715: case OP_OFF_ON:
      007880 80 4C            [24] 1503 	sjmp	00181$
      007882                       1504 00155$:
                                   1505 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007882 E5 26            [12] 1506 	mov	a,_process_action_sloc0_1_0
      007884 60 08            [24] 1507 	jz	00208$
      007886 12 7A D6         [24] 1508 	lcall	_ak820_outline_0039
      007889 12 7C D0         [24] 1509 	lcall	_layer_off
      00788C 80 40            [24] 1510 	sjmp	00181$
      00788E                       1511 00208$:
      00788E 12 7A D6         [24] 1512 	lcall	_ak820_outline_0039
      007891 12 7C B6         [24] 1513 	lcall	_layer_on
                                   1514 ;	quantum/action.c:717: break;
                                   1515 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007894 80 38            [24] 1516 	sjmp	00181$
      007896                       1517 00156$:
                                   1518 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007896 E5 26            [12] 1519 	mov	a,_process_action_sloc0_1_0
      007898 60 08            [24] 1520 	jz	00210$
      00789A 12 7A D6         [24] 1521 	lcall	_ak820_outline_0039
      00789D 12 7C A1         [24] 1522 	lcall	_layer_move
      0078A0 80 2C            [24] 1523 	sjmp	00181$
      0078A2                       1524 00210$:
      0078A2 12 7C 9C         [24] 1525 	lcall	_layer_clear
                                   1526 ;	quantum/action.c:720: break;
                                   1527 ;	quantum/action.c:766: default:
      0078A5 80 27            [24] 1528 	sjmp	00181$
      0078A7                       1529 00160$:
                                   1530 ;	quantum/action.c:773: if (pressed) {
      0078A7 E5 26            [12] 1531 	mov	a,_process_action_sloc0_1_0
      0078A9 60 08            [24] 1532 	jz	00163$
                                   1533 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      0078AB 12 7A EF         [24] 1534 	lcall	_ak820_outline_0076
      0078AE 12 78 E5         [24] 1535 	lcall	_register_code
                                   1536 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0078B1 80 1B            [24] 1537 	sjmp	00181$
      0078B3                       1538 00163$:
                                   1539 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      0078B3 12 7B 24         [24] 1540 	lcall	_ak820_outline_0147
      0078B6 FF               [12] 1541 	mov	r7,a
      0078B7 BF 39 0E         [24] 1542 	cjne	r7,#0x39,00175$
                                   1543 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      0078BA 7F 50            [12] 1544 	mov	r7,#0x50
      0078BC                       1545 00187$:
      0078BC EF               [12] 1546 	mov	a,r7
      0078BD 60 09            [24] 1547 	jz	00175$
      0078BF 90 00 01         [24] 1548 	mov	dptr,#0x0001
      0078C2 12 5B F0         [24] 1549 	lcall	_mDelaymS
      0078C5 1F               [12] 1550 	dec	r7
                                   1551 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0078C6 80 F4            [24] 1552 	sjmp	00187$
      0078C8                       1553 00175$:
                                   1554 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0078C8 12 7A EF         [24] 1555 	lcall	_ak820_outline_0076
      0078CB 12 79 6A         [24] 1556 	lcall	_unregister_code
                                   1557 ;	quantum/action.c:866: }
      0078CE                       1558 00181$:
                                   1559 ;	quantum/action.c:887: switch (action.kind.id) {
      0078CE 90 08 51         [24] 1560 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078D1 E0               [24] 1561 	movx	a,@dptr
      0078D2 C4               [12] 1562 	swap	a
      0078D3 54 0F            [12] 1563 	anl	a,#0x0f
      0078D5 FF               [12] 1564 	mov	r7,a
      0078D6 BF 08 02         [24] 1565 	cjne	r7,#0x08,00478$
      0078D9 80 03            [24] 1566 	sjmp	00183$
      0078DB                       1567 00478$:
      0078DB BF 09 06         [24] 1568 	cjne	r7,#0x09,00192$
                                   1569 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0078DE                       1570 00183$:
                                   1571 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0078DE 12 70 6C         [24] 1572 	lcall	_host_keyboard_leds
                                   1573 ;	quantum/action.c:898: }
                                   1574 ;	quantum/action.c:951: }
      0078E1 02 9A D9         [24] 1575 	ljmp	_led_set
      0078E4                       1576 00192$:
      0078E4 22               [24] 1577 	ret
                                   1578 ;------------------------------------------------------------
                                   1579 ;Allocation info for local variables in function 'register_code'
                                   1580 ;------------------------------------------------------------
                                   1581 ;code          Allocated with name '_register_code_code_10000_714'
                                   1582 ;------------------------------------------------------------
                                   1583 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1584 ;	-----------------------------------------
                                   1585 ;	 function register_code
                                   1586 ;	-----------------------------------------
      0078E5                       1587 _register_code:
      0078E5 E5 82            [12] 1588 	mov	a,dpl
      0078E7 90 08 55         [24] 1589 	mov	dptr,#_register_code_code_10000_714
      0078EA F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	quantum/action.c:958: if (code == KC_NO) {
      0078EB E0               [24] 1592 	movx	a,@dptr
      0078EC FF               [12] 1593 	mov	r7,a
      0078ED 70 01            [24] 1594 	jnz	00123$
                                   1595 ;	quantum/action.c:959: return;
      0078EF 22               [24] 1596 	ret
      0078F0                       1597 00123$:
                                   1598 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0078F0 BF 04 00         [24] 1599 	cjne	r7,#0x04,00198$
      0078F3                       1600 00198$:
      0078F3 40 12            [24] 1601 	jc	00119$
      0078F5 EF               [12] 1602 	mov	a,r7
      0078F6 24 5B            [12] 1603 	add	a,#0xff - 0xa4
      0078F8 40 0D            [24] 1604 	jc	00119$
                                   1605 ;	free result
                                   1606 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0078FA 8F 82            [24] 1607 	mov	dpl, r7
      0078FC 12 81 09         [24] 1608 	lcall	_add_owned_key
      0078FF E5 82            [12] 1609 	mov	a, dpl
      007901 70 01            [24] 1610 	jnz	00104$
      007903 22               [24] 1611 	ret
      007904                       1612 00104$:
                                   1613 ;	quantum/action.c:1013: send_keyboard_report();
      007904 02 83 9E         [24] 1614 	ljmp	_send_keyboard_report
      007907                       1615 00119$:
                                   1616 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007907 12 7B 18         [24] 1617 	lcall	_ak820_outline_0138
      00790A BF E0 00         [24] 1618 	cjne	r7,#0xe0,00202$
      00790D                       1619 00202$:
      00790D 40 1A            [24] 1620 	jc	00115$
      00790F EF               [12] 1621 	mov	a,r7
      007910 24 18            [12] 1622 	add	a,#0xff - 0xe7
      007912 40 15            [24] 1623 	jc	00115$
                                   1624 ;	free result
                                   1625 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007914 74 07            [12] 1626 	mov	a,#0x07
      007916 5F               [12] 1627 	anl	a,r7
      007917 12 7A E8         [24] 1628 	lcall	_ak820_outline_0063
      00791A 80 02            [24] 1629 	sjmp	00206$
      00791C                       1630 00205$:
      00791C 25 E0            [12] 1631 	add	a,acc
      00791E                       1632 00206$:
      00791E D5 F0 FB         [24] 1633 	djnz	b,00205$
      007921 F5 82            [12] 1634 	mov	dpl,a
      007923 12 80 66         [24] 1635 	lcall	_add_owned_mods
                                   1636 ;	quantum/action.c:1016: send_keyboard_report();
      007926 02 83 9E         [24] 1637 	ljmp	_send_keyboard_report
      007929                       1638 00115$:
                                   1639 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007929 12 7B 18         [24] 1640 	lcall	_ak820_outline_0138
      00792C BF A5 00         [24] 1641 	cjne	r7,#0xa5,00207$
      00792F                       1642 00207$:
      00792F 40 05            [24] 1643 	jc	00113$
      007931 EF               [12] 1644 	mov	a,r7
      007932 24 58            [12] 1645 	add	a,#0xff - 0xa7
      007934 50 0D            [24] 1646 	jnc	00108$
                                   1647 ;	free result
      007936                       1648 00113$:
      007936 12 7B 18         [24] 1649 	lcall	_ak820_outline_0138
      007939 BF A8 00         [24] 1650 	cjne	r7,#0xa8,00210$
      00793C                       1651 00210$:
      00793C 40 13            [24] 1652 	jc	00109$
      00793E EF               [12] 1653 	mov	a,r7
      00793F 24 3D            [12] 1654 	add	a,#0xff - 0xc2
      007941 40 0E            [24] 1655 	jc	00109$
                                   1656 ;	free result
      007943                       1657 00108$:
                                   1658 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007943 12 7B 18         [24] 1659 	lcall	_ak820_outline_0138
      007946 90 0A B0         [24] 1660 	mov	dptr,#_owned_usage_key_PARM_2
      007949 74 01            [12] 1661 	mov	a,#0x01
      00794B F0               [24] 1662 	movx	@dptr,a
      00794C 8F 82            [24] 1663 	mov	dpl, r7
      00794E 02 82 4A         [24] 1664 	ljmp	_owned_usage_key
      007951                       1665 00109$:
                                   1666 ;	quantum/action.c:1028: } else if (IS_MOUSE_KEYCODE(code)) {
      007951 12 7B 18         [24] 1667 	lcall	_ak820_outline_0138
      007954 BF CD 00         [24] 1668 	cjne	r7,#0xcd,00213$
      007957                       1669 00213$:
      007957 40 10            [24] 1670 	jc	00125$
      007959 EF               [12] 1671 	mov	a,r7
      00795A 24 20            [12] 1672 	add	a,#0xff - 0xdf
      00795C 40 0B            [24] 1673 	jc	00125$
                                   1674 ;	free result
                                   1675 ;	quantum/action.c:1029: register_mouse(code, true);
      00795E 90 08 4E         [24] 1676 	mov	dptr,#_register_mouse_PARM_2
      007961 74 01            [12] 1677 	mov	a,#0x01
      007963 F0               [24] 1678 	movx	@dptr,a
      007964 8F 82            [24] 1679 	mov	dpl, r7
                                   1680 ;	quantum/action.c:1031: }
      007966 02 75 FA         [24] 1681 	ljmp	_register_mouse
      007969                       1682 00125$:
      007969 22               [24] 1683 	ret
                                   1684 ;------------------------------------------------------------
                                   1685 ;Allocation info for local variables in function 'unregister_code'
                                   1686 ;------------------------------------------------------------
                                   1687 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1688 ;------------------------------------------------------------
                                   1689 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1690 ;	-----------------------------------------
                                   1691 ;	 function unregister_code
                                   1692 ;	-----------------------------------------
      00796A                       1693 _unregister_code:
      00796A E5 82            [12] 1694 	mov	a,dpl
      00796C 90 08 56         [24] 1695 	mov	dptr,#_unregister_code_code_10000_728
      00796F F0               [24] 1696 	movx	@dptr,a
                                   1697 ;	quantum/action.c:1038: if (code == KC_NO) {
      007970 E0               [24] 1698 	movx	a,@dptr
      007971 FF               [12] 1699 	mov	r7,a
      007972 70 01            [24] 1700 	jnz	00121$
                                   1701 ;	quantum/action.c:1039: return;
      007974 22               [24] 1702 	ret
      007975                       1703 00121$:
                                   1704 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007975 BF 04 00         [24] 1705 	cjne	r7,#0x04,00196$
      007978                       1706 00196$:
      007978 40 12            [24] 1707 	jc	00117$
      00797A EF               [12] 1708 	mov	a,r7
      00797B 24 5B            [12] 1709 	add	a,#0xff - 0xa4
      00797D 40 0D            [24] 1710 	jc	00117$
                                   1711 ;	free result
                                   1712 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      00797F 8F 82            [24] 1713 	mov	dpl, r7
      007981 12 81 83         [24] 1714 	lcall	_del_owned_key
      007984 E5 82            [12] 1715 	mov	a, dpl
      007986 70 01            [24] 1716 	jnz	00102$
      007988 22               [24] 1717 	ret
      007989                       1718 00102$:
                                   1719 ;	quantum/action.c:1080: send_keyboard_report();
      007989 02 83 9E         [24] 1720 	ljmp	_send_keyboard_report
      00798C                       1721 00117$:
                                   1722 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      00798C 12 7B 1E         [24] 1723 	lcall	_ak820_outline_0139
      00798F BF E0 00         [24] 1724 	cjne	r7,#0xe0,00200$
      007992                       1725 00200$:
      007992 40 1A            [24] 1726 	jc	00113$
      007994 EF               [12] 1727 	mov	a,r7
      007995 24 18            [12] 1728 	add	a,#0xff - 0xe7
      007997 40 15            [24] 1729 	jc	00113$
                                   1730 ;	free result
                                   1731 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007999 74 07            [12] 1732 	mov	a,#0x07
      00799B 5F               [12] 1733 	anl	a,r7
      00799C 12 7A E8         [24] 1734 	lcall	_ak820_outline_0063
      00799F 80 02            [24] 1735 	sjmp	00204$
      0079A1                       1736 00203$:
      0079A1 25 E0            [12] 1737 	add	a,acc
      0079A3                       1738 00204$:
      0079A3 D5 F0 FB         [24] 1739 	djnz	b,00203$
      0079A6 F5 82            [12] 1740 	mov	dpl,a
      0079A8 12 80 76         [24] 1741 	lcall	_del_owned_mods
                                   1742 ;	quantum/action.c:1083: send_keyboard_report();
      0079AB 02 83 9E         [24] 1743 	ljmp	_send_keyboard_report
      0079AE                       1744 00113$:
                                   1745 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079AE 12 7B 1E         [24] 1746 	lcall	_ak820_outline_0139
      0079B1 BF A5 00         [24] 1747 	cjne	r7,#0xa5,00205$
      0079B4                       1748 00205$:
      0079B4 40 05            [24] 1749 	jc	00111$
      0079B6 EF               [12] 1750 	mov	a,r7
      0079B7 24 58            [12] 1751 	add	a,#0xff - 0xa7
      0079B9 50 0D            [24] 1752 	jnc	00106$
                                   1753 ;	free result
      0079BB                       1754 00111$:
      0079BB 12 7B 1E         [24] 1755 	lcall	_ak820_outline_0139
      0079BE BF A8 00         [24] 1756 	cjne	r7,#0xa8,00208$
      0079C1                       1757 00208$:
      0079C1 40 11            [24] 1758 	jc	00107$
      0079C3 EF               [12] 1759 	mov	a,r7
      0079C4 24 3D            [12] 1760 	add	a,#0xff - 0xc2
      0079C6 40 0C            [24] 1761 	jc	00107$
                                   1762 ;	free result
      0079C8                       1763 00106$:
                                   1764 ;	quantum/action.c:1088: owned_usage_key(code, false);
      0079C8 12 7B 1E         [24] 1765 	lcall	_ak820_outline_0139
      0079CB 90 0A B0         [24] 1766 	mov	dptr,#_owned_usage_key_PARM_2
      0079CE 12 7B 29         [24] 1767 	lcall	_ak820_outline_0184
      0079D1 02 82 4A         [24] 1768 	ljmp	_owned_usage_key
      0079D4                       1769 00107$:
                                   1770 ;	quantum/action.c:1095: } else if (IS_MOUSE_KEYCODE(code)) {
      0079D4 12 7B 1E         [24] 1771 	lcall	_ak820_outline_0139
      0079D7 BF CD 00         [24] 1772 	cjne	r7,#0xcd,00211$
      0079DA                       1773 00211$:
      0079DA 40 0E            [24] 1774 	jc	00123$
      0079DC EF               [12] 1775 	mov	a,r7
      0079DD 24 20            [12] 1776 	add	a,#0xff - 0xdf
      0079DF 40 09            [24] 1777 	jc	00123$
                                   1778 ;	free result
                                   1779 ;	quantum/action.c:1096: register_mouse(code, false);
      0079E1 90 08 4E         [24] 1780 	mov	dptr,#_register_mouse_PARM_2
      0079E4 12 7B 29         [24] 1781 	lcall	_ak820_outline_0184
                                   1782 ;	quantum/action.c:1098: }
      0079E7 02 75 FA         [24] 1783 	ljmp	_register_mouse
      0079EA                       1784 00123$:
      0079EA 22               [24] 1785 	ret
                                   1786 ;------------------------------------------------------------
                                   1787 ;Allocation info for local variables in function 'tap_code_delay'
                                   1788 ;------------------------------------------------------------
                                   1789 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1790 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1791 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1792 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1793 ;------------------------------------------------------------
                                   1794 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1795 ;	-----------------------------------------
                                   1796 ;	 function tap_code_delay
                                   1797 ;	-----------------------------------------
      0079EB                       1798 _tap_code_delay:
      0079EB E5 82            [12] 1799 	mov	a,dpl
      0079ED 90 08 59         [24] 1800 	mov	dptr,#_tap_code_delay_code_10000_741
      0079F0 F0               [24] 1801 	movx	@dptr,a
                                   1802 ;	quantum/action.c:1106: register_code(code);
      0079F1 E0               [24] 1803 	movx	a,@dptr
      0079F2 FF               [12] 1804 	mov	r7,a
      0079F3 F5 82            [12] 1805 	mov	dpl,a
      0079F5 C0 07            [24] 1806 	push	ar7
      0079F7 11 E5            [12] 1807 	acall	_register_code
      0079F9 D0 07            [24] 1808 	pop	ar7
                                   1809 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0079FB 90 08 57         [24] 1810 	mov	dptr,#_tap_code_delay_PARM_2
      0079FE 12 43 6E         [24] 1811 	lcall	_ak820_outline_0093
      007A01                       1812 00110$:
      007A01 ED               [12] 1813 	mov	a,r5
      007A02 4E               [12] 1814 	orl	a,r6
      007A03 60 0D            [24] 1815 	jz	00105$
                                   1816 ;	quantum/action.c:1108: wait_ms(1);
      007A05 90 00 01         [24] 1817 	mov	dptr,#0x0001
      007A08 12 5B F0         [24] 1818 	lcall	_mDelaymS
                                   1819 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007A0B 1D               [12] 1820 	dec	r5
      007A0C BD FF 01         [24] 1821 	cjne	r5,#0xff,00141$
      007A0F 1E               [12] 1822 	dec	r6
      007A10                       1823 00141$:
      007A10 80 EF            [24] 1824 	sjmp	00110$
      007A12                       1825 00105$:
                                   1826 ;	quantum/action.c:1110: unregister_code(code);
      007A12 8F 82            [24] 1827 	mov	dpl, r7
                                   1828 ;	quantum/action.c:1111: }
      007A14 21 6A            [12] 1829 	ajmp	_unregister_code
                                   1830 ;------------------------------------------------------------
                                   1831 ;Allocation info for local variables in function 'tap_code'
                                   1832 ;------------------------------------------------------------
                                   1833 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1834 ;------------------------------------------------------------
                                   1835 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1836 ;	-----------------------------------------
                                   1837 ;	 function tap_code
                                   1838 ;	-----------------------------------------
      007A16                       1839 _tap_code:
      007A16 E5 82            [12] 1840 	mov	a,dpl
      007A18 90 08 5A         [24] 1841 	mov	dptr,#_tap_code_code_10000_748
      007A1B F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A1C E0               [24] 1844 	movx	a,@dptr
      007A1D FF               [12] 1845 	mov	r7,a
      007A1E BF 39 04         [24] 1846 	cjne	r7,#0x39,00103$
      007A21 7E 50            [12] 1847 	mov	r6,#0x50
      007A23 80 02            [24] 1848 	sjmp	00104$
      007A25                       1849 00103$:
      007A25 7E 00            [12] 1850 	mov	r6,#0x00
      007A27                       1851 00104$:
      007A27 90 08 57         [24] 1852 	mov	dptr,#_tap_code_delay_PARM_2
      007A2A EE               [12] 1853 	mov	a,r6
      007A2B 12 38 57         [24] 1854 	lcall	_ak820_outline_0123
      007A2E 8F 82            [24] 1855 	mov	dpl, r7
                                   1856 ;	quantum/action.c:1119: }
      007A30 21 EB            [12] 1857 	ajmp	_tap_code_delay
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'register_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function register_mods
                                   1866 ;	-----------------------------------------
      007A32                       1867 _register_mods:
      007A32 E5 82            [12] 1868 	mov	a,dpl
      007A34 90 08 5B         [24] 1869 	mov	dptr,#_register_mods_mods_10000_750
      007A37 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1126: if (mods) {
      007A38 E0               [24] 1872 	movx	a,@dptr
      007A39 FF               [12] 1873 	mov	r7,a
      007A3A E0               [24] 1874 	movx	a,@dptr
      007A3B 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1127: add_owned_mods(mods);
      007A3D 8F 82            [24] 1877 	mov	dpl, r7
      007A3F 12 80 66         [24] 1878 	lcall	_add_owned_mods
                                   1879 ;	quantum/action.c:1128: send_keyboard_report();
                                   1880 ;	quantum/action.c:1130: }
      007A42 02 83 9E         [24] 1881 	ljmp	_send_keyboard_report
      007A45                       1882 00103$:
      007A45 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'unregister_mods'
                                   1886 ;------------------------------------------------------------
                                   1887 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1888 ;------------------------------------------------------------
                                   1889 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1890 ;	-----------------------------------------
                                   1891 ;	 function unregister_mods
                                   1892 ;	-----------------------------------------
      007A46                       1893 _unregister_mods:
      007A46 E5 82            [12] 1894 	mov	a,dpl
      007A48 90 08 5C         [24] 1895 	mov	dptr,#_unregister_mods_mods_10000_754
      007A4B F0               [24] 1896 	movx	@dptr,a
                                   1897 ;	quantum/action.c:1137: if (mods) {
      007A4C E0               [24] 1898 	movx	a,@dptr
      007A4D FF               [12] 1899 	mov	r7,a
      007A4E E0               [24] 1900 	movx	a,@dptr
      007A4F 60 08            [24] 1901 	jz	00103$
                                   1902 ;	quantum/action.c:1138: del_owned_mods(mods);
      007A51 8F 82            [24] 1903 	mov	dpl, r7
      007A53 12 80 76         [24] 1904 	lcall	_del_owned_mods
                                   1905 ;	quantum/action.c:1139: send_keyboard_report();
                                   1906 ;	quantum/action.c:1141: }
      007A56 02 83 9E         [24] 1907 	ljmp	_send_keyboard_report
      007A59                       1908 00103$:
      007A59 22               [24] 1909 	ret
                                   1910 ;------------------------------------------------------------
                                   1911 ;Allocation info for local variables in function 'register_weak_mods'
                                   1912 ;------------------------------------------------------------
                                   1913 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function register_weak_mods
                                   1918 ;	-----------------------------------------
      007A5A                       1919 _register_weak_mods:
      007A5A E5 82            [12] 1920 	mov	a,dpl
      007A5C 90 08 5D         [24] 1921 	mov	dptr,#_register_weak_mods_mods_10000_758
      007A5F F0               [24] 1922 	movx	@dptr,a
                                   1923 ;	quantum/action.c:1148: if (mods) {
      007A60 E0               [24] 1924 	movx	a,@dptr
      007A61 FF               [12] 1925 	mov	r7,a
      007A62 E0               [24] 1926 	movx	a,@dptr
      007A63 60 08            [24] 1927 	jz	00103$
                                   1928 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007A65 8F 82            [24] 1929 	mov	dpl, r7
      007A67 12 80 84         [24] 1930 	lcall	_add_owned_weak_mods
                                   1931 ;	quantum/action.c:1150: send_keyboard_report();
                                   1932 ;	quantum/action.c:1152: }
      007A6A 02 83 9E         [24] 1933 	ljmp	_send_keyboard_report
      007A6D                       1934 00103$:
      007A6D 22               [24] 1935 	ret
                                   1936 ;------------------------------------------------------------
                                   1937 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1938 ;------------------------------------------------------------
                                   1939 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1940 ;------------------------------------------------------------
                                   1941 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1942 ;	-----------------------------------------
                                   1943 ;	 function unregister_weak_mods
                                   1944 ;	-----------------------------------------
      007A6E                       1945 _unregister_weak_mods:
      007A6E E5 82            [12] 1946 	mov	a,dpl
      007A70 90 08 5E         [24] 1947 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      007A73 F0               [24] 1948 	movx	@dptr,a
                                   1949 ;	quantum/action.c:1159: if (mods) {
      007A74 E0               [24] 1950 	movx	a,@dptr
      007A75 FF               [12] 1951 	mov	r7,a
      007A76 E0               [24] 1952 	movx	a,@dptr
      007A77 60 08            [24] 1953 	jz	00103$
                                   1954 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007A79 8F 82            [24] 1955 	mov	dpl, r7
      007A7B 12 80 94         [24] 1956 	lcall	_del_owned_weak_mods
                                   1957 ;	quantum/action.c:1161: send_keyboard_report();
                                   1958 ;	quantum/action.c:1163: }
      007A7E 02 83 9E         [24] 1959 	ljmp	_send_keyboard_report
      007A81                       1960 00103$:
      007A81 22               [24] 1961 	ret
                                   1962 ;------------------------------------------------------------
                                   1963 ;Allocation info for local variables in function 'clear_keyboard'
                                   1964 ;------------------------------------------------------------
                                   1965 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1966 ;	-----------------------------------------
                                   1967 ;	 function clear_keyboard
                                   1968 ;	-----------------------------------------
      007A82                       1969 _clear_keyboard:
                                   1970 ;	quantum/action.c:1170: clear_mods();
      007A82 12 84 19         [24] 1971 	lcall	_clear_mods
                                   1972 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1973 ;	quantum/action.c:1172: }
      007A85 41 87            [12] 1974 	ajmp	_clear_keyboard_but_mods
                                   1975 ;------------------------------------------------------------
                                   1976 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1979 ;	-----------------------------------------
                                   1980 ;	 function clear_keyboard_but_mods
                                   1981 ;	-----------------------------------------
      007A87                       1982 _clear_keyboard_but_mods:
                                   1983 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A87 90 0D BC         [24] 1984 	mov	dptr,#_actual_keyboard_report
      007A8A 12 73 25         [24] 1985 	lcall	_clear_keys_from_report
                                   1986 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1987 ;	quantum/action.c:1181: }
      007A8D 41 8F            [12] 1988 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function clear_keyboard_but_mods_and_keys
                                   1995 ;	-----------------------------------------
      007A8F                       1996 _clear_keyboard_but_mods_and_keys:
                                   1997 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007A8F 12 47 AE         [24] 1998 	lcall	_ak820_tapping_cancel
                                   1999 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007A92 12 2E A4         [24] 2000 	lcall	_ak820_oneshot_cancel
                                   2001 ;	quantum/action.c:1209: ak820_combo_cancel();
      007A95 12 35 27         [24] 2002 	lcall	_ak820_combo_cancel
                                   2003 ;	quantum/action.c:1212: repeat_key_cancel();
      007A98 12 A3 AB         [24] 2004 	lcall	_repeat_key_cancel
                                   2005 ;	quantum/action.c:1214: clear_owned_mods();
      007A9B 12 80 A4         [24] 2006 	lcall	_clear_owned_mods
                                   2007 ;	quantum/action.c:1215: clear_owned_keys();
      007A9E 12 80 DC         [24] 2008 	lcall	_clear_owned_keys
                                   2009 ;	quantum/action.c:1216: clear_owned_usages();
      007AA1 12 82 12         [24] 2010 	lcall	_clear_owned_usages
                                   2011 ;	quantum/action.c:1217: layer_hold_clear();
      007AA4 91 62            [12] 2012 	acall	_layer_hold_clear
                                   2013 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007AA6 12 9F 5F         [24] 2014 	lcall	_clear_macro_tri_layer
                                   2015 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AA9 90 0D BC         [24] 2016 	mov	dptr,#_actual_keyboard_report
      007AAC 12 73 25         [24] 2017 	lcall	_clear_keys_from_report
                                   2018 ;	quantum/action.c:1224: host_system_send(0);
      007AAF 90 00 00         [24] 2019 	mov	dptr,#0x0000
      007AB2 12 71 07         [24] 2020 	lcall	_host_system_send
                                   2021 ;	quantum/action.c:1225: host_consumer_send(0);
      007AB5 90 00 00         [24] 2022 	mov	dptr,#0x0000
      007AB8 12 71 36         [24] 2023 	lcall	_host_consumer_send
                                   2024 ;	quantum/action.c:1227: clear_weak_mods();
      007ABB 12 84 4E         [24] 2025 	lcall	_clear_weak_mods
                                   2026 ;	quantum/action.c:1228: send_keyboard_report();
      007ABE 12 83 9E         [24] 2027 	lcall	_send_keyboard_report
                                   2028 ;	quantum/action.c:1230: mousekey_clear();
      007AC1 12 52 83         [24] 2029 	lcall	_mousekey_clear
                                   2030 ;	quantum/action.c:1231: mousekey_send();
                                   2031 ;	quantum/action.c:1236: }
      007AC4 02 51 4B         [24] 2032 	ljmp	_mousekey_send
                                   2033 ;------------------------------------------------------------
                                   2034 ;Allocation info for local variables in function 'is_tap_record'
                                   2035 ;------------------------------------------------------------
                                   2036 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   2037 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   2038 ;------------------------------------------------------------
                                   2039 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2040 ;	-----------------------------------------
                                   2041 	.area CSEG    (CODE)
                                   2042 	.area CONST   (CODE)
                                   2043 	.area XINIT   (CODE)
      00C320                       2044 __xinit__disable_action_cache:
      00C320 00                    2045 	.db #0x00	;  0
                                   2046 	.area CABS    (ABS,CODE)
                                   2047 
                                   2048 ; Experimental exact instruction outlining.
                                   2049 	.globl _ak820_outline_0004
                                   2050 	.globl _ak820_outline_0009
                                   2051 	.globl _ak820_outline_0010
                                   2052 	.globl _ak820_outline_0011
                                   2053 	.globl _ak820_outline_0012
                                   2054 	.globl _ak820_outline_0016
                                   2055 	.globl _ak820_outline_0017
                                   2056 	.globl _ak820_outline_0020
                                   2057 	.globl _ak820_outline_0031
                                   2058 	.globl _ak820_outline_0039
                                   2059 	.globl _ak820_outline_0050
                                   2060 	.globl _ak820_outline_0051
                                   2061 	.globl _ak820_outline_0055
                                   2062 	.globl _ak820_outline_0058
                                   2063 	.globl _ak820_outline_0063
                                   2064 	.globl _ak820_outline_0071
                                   2065 	.globl _ak820_outline_0076
                                   2066 	.globl _ak820_outline_0086
                                   2067 	.globl _ak820_outline_0093
                                   2068 	.globl _ak820_outline_0103
                                   2069 	.globl _ak820_outline_0104
                                   2070 	.globl _ak820_outline_0106
                                   2071 	.globl _ak820_outline_0107
                                   2072 	.globl _ak820_outline_0109
                                   2073 	.globl _ak820_outline_0116
                                   2074 	.globl _ak820_outline_0117
                                   2075 	.globl _ak820_outline_0118
                                   2076 	.globl _ak820_outline_0123
                                   2077 	.globl _ak820_outline_0129
                                   2078 	.globl _ak820_outline_0138
                                   2079 	.globl _ak820_outline_0139
                                   2080 	.globl _ak820_outline_0141
                                   2081 	.globl _ak820_outline_0142
                                   2082 	.globl _ak820_outline_0147
                                   2083 	.globl _ak820_outline_0148
                                   2084 	.globl _ak820_outline_0166
                                   2085 	.globl _ak820_outline_0184
                                   2086 	.globl _ak820_outline_0185
                                   2087 
                                   2088 	.area CSEG (CODE)
                                   2089 ; function ak820_outline_0020
      007AC7                       2090 _ak820_outline_0020:
      007AC7 8E 82            [24] 2091 	mov	dpl,r6
      007AC9 8F 83            [24] 2092 	mov	dph,r7
      007ACB A3               [24] 2093 	inc	dptr
      007ACC E0               [24] 2094 	movx	a,@dptr
      007ACD FC               [12] 2095 	mov	r4,a
      007ACE 7D 00            [12] 2096 	mov	r5,#0x00
      007AD0 8E 82            [24] 2097 	mov	dpl,r6
      007AD2 8F 83            [24] 2098 	mov	dph,r7
      007AD4 E0               [24] 2099 	movx	a,@dptr
      007AD5 22               [24] 2100 	ret
                                   2101 
                                   2102 	.area CSEG (CODE)
                                   2103 ; function ak820_outline_0039
      007AD6                       2104 _ak820_outline_0039:
      007AD6 90 08 51         [24] 2105 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AD9 E0               [24] 2106 	movx	a,@dptr
      007ADA 54 1F            [12] 2107 	anl	a,#0x1f
      007ADC F5 82            [12] 2108 	mov	dpl,a
      007ADE 22               [24] 2109 	ret
                                   2110 
                                   2111 	.area CSEG (CODE)
                                   2112 ; function ak820_outline_0050
      007ADF                       2113 _ak820_outline_0050:
      007ADF A3               [24] 2114 	inc	dptr
      007AE0 F0               [24] 2115 	movx	@dptr,a
      007AE1 E4               [12] 2116 	clr	a
      007AE2 A3               [24] 2117 	inc	dptr
      007AE3 F0               [24] 2118 	movx	@dptr,a
      007AE4 90 0D 9A         [24] 2119 	mov	dptr,#___memcpy_PARM_3
      007AE7 22               [24] 2120 	ret
                                   2121 
                                   2122 	.area CSEG (CODE)
                                   2123 ; function ak820_outline_0063
      007AE8                       2124 _ak820_outline_0063:
      007AE8 F5 F0            [12] 2125 	mov	b,a
      007AEA 05 F0            [12] 2126 	inc	b
      007AEC 74 01            [12] 2127 	mov	a,#0x01
      007AEE 22               [24] 2128 	ret
                                   2129 
                                   2130 	.area CSEG (CODE)
                                   2131 ; function ak820_outline_0076
      007AEF                       2132 _ak820_outline_0076:
      007AEF 90 08 50         [24] 2133 	mov	dptr,#_process_action_PARM_2
      007AF2 E0               [24] 2134 	movx	a,@dptr
      007AF3 F5 82            [12] 2135 	mov	dpl,a
      007AF5 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0086
      007AF6                       2140 _ak820_outline_0086:
      007AF6 90 08 51         [24] 2141 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AF9 E0               [24] 2142 	movx	a,@dptr
      007AFA 03               [12] 2143 	rr	a
      007AFB 03               [12] 2144 	rr	a
      007AFC 54 03            [12] 2145 	anl	a,#0x03
      007AFE 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0107
      007AFF                       2150 _ak820_outline_0107:
      007AFF 74 06            [12] 2151 	mov	a,#0x06
      007B01 F0               [24] 2152 	movx	@dptr,a
      007B02 E4               [12] 2153 	clr	a
      007B03 A3               [24] 2154 	inc	dptr
      007B04 F0               [24] 2155 	movx	@dptr,a
      007B05 22               [24] 2156 	ret
                                   2157 
                                   2158 	.area CSEG (CODE)
                                   2159 ; function ak820_outline_0109
      007B06                       2160 _ak820_outline_0109:
      007B06 90 08 51         [24] 2161 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B09 E0               [24] 2162 	movx	a,@dptr
      007B0A 54 0F            [12] 2163 	anl	a,#0x0f
      007B0C 22               [24] 2164 	ret
                                   2165 
                                   2166 	.area CSEG (CODE)
                                   2167 ; function ak820_outline_0129
      007B0D                       2168 _ak820_outline_0129:
      007B0D 90 08 50         [24] 2169 	mov	dptr,#_process_action_PARM_2
      007B10 E0               [24] 2170 	movx	a,@dptr
      007B11 FE               [12] 2171 	mov	r6,a
      007B12 A3               [24] 2172 	inc	dptr
      007B13 E0               [24] 2173 	movx	a,@dptr
      007B14 54 03            [12] 2174 	anl	a,#0x03
      007B16 FF               [12] 2175 	mov	r7,a
      007B17 22               [24] 2176 	ret
                                   2177 
                                   2178 	.area CSEG (CODE)
                                   2179 ; function ak820_outline_0138
      007B18                       2180 _ak820_outline_0138:
      007B18 90 08 55         [24] 2181 	mov	dptr,#_register_code_code_10000_714
      007B1B E0               [24] 2182 	movx	a,@dptr
      007B1C FF               [12] 2183 	mov	r7,a
      007B1D 22               [24] 2184 	ret
                                   2185 
                                   2186 	.area CSEG (CODE)
                                   2187 ; function ak820_outline_0139
      007B1E                       2188 _ak820_outline_0139:
      007B1E 90 08 56         [24] 2189 	mov	dptr,#_unregister_code_code_10000_728
      007B21 E0               [24] 2190 	movx	a,@dptr
      007B22 FF               [12] 2191 	mov	r7,a
      007B23 22               [24] 2192 	ret
                                   2193 
                                   2194 	.area CSEG (CODE)
                                   2195 ; function ak820_outline_0147
      007B24                       2196 _ak820_outline_0147:
      007B24 90 08 50         [24] 2197 	mov	dptr,#_process_action_PARM_2
      007B27 E0               [24] 2198 	movx	a,@dptr
      007B28 22               [24] 2199 	ret
                                   2200 
                                   2201 	.area CSEG (CODE)
                                   2202 ; function ak820_outline_0184
      007B29                       2203 _ak820_outline_0184:
      007B29 E4               [12] 2204 	clr	a
      007B2A F0               [24] 2205 	movx	@dptr,a
      007B2B 8F 82            [24] 2206 	mov	dpl,r7
      007B2D 22               [24] 2207 	ret
