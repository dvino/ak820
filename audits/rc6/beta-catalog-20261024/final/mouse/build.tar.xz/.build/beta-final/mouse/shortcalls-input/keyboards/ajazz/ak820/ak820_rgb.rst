                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      00000F                        595 _suspended:
      00000F                        596 	.ds 1
      000010                        597 _dirty:
      000010                        598 	.ds 1
      000011                        599 _rendering:
      000011                        600 	.ds 1
      000012                        601 _rgb_matrix_task_sloc0_1_0:
      000012                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006C5                        611 _rgb_matrix_config::
      0006C5                        612 	.ds 8
      0006CD                        613 _changed_at:
      0006CD                        614 	.ds 2
      0006CF                        615 _frame_at:
      0006CF                        616 	.ds 2
      0006D1                        617 _phase:
      0006D1                        618 	.ds 2
      0006D3                        619 _led_index:
      0006D3                        620 	.ds 1
      0006D4                        621 _frame_mode:
      0006D4                        622 	.ds 1
      0006D5                        623 _frame_hue:
      0006D5                        624 	.ds 1
      0006D6                        625 _frame_sat:
      0006D6                        626 	.ds 1
      0006D7                        627 _frame_val:
      0006D7                        628 	.ds 1
      0006D8                        629 _frame_flags:
      0006D8                        630 	.ds 1
      0006D9                        631 _frame_phase:
      0006D9                        632 	.ds 1
      0006DA                        633 _reactive_age:
      0006DA                        634 	.ds 82
      00072C                        635 _reactive_at:
      00072C                        636 	.ds 2
      00072E                        637 _add_sat_PARM_2:
      00072E                        638 	.ds 1
      00072F                        639 _add_sat_x_10000_266:
      00072F                        640 	.ds 1
      000730                        641 _sub_sat_PARM_2:
      000730                        642 	.ds 1
      000731                        643 _sub_sat_x_10000_268:
      000731                        644 	.ds 1
      000732                        645 _rgb_matrix_set_color_PARM_2:
      000732                        646 	.ds 1
      000733                        647 _rgb_matrix_set_color_PARM_3:
      000733                        648 	.ds 1
      000734                        649 _rgb_matrix_set_color_PARM_4:
      000734                        650 	.ds 1
      000735                        651 _rgb_matrix_set_color_index_10000_284:
      000735                        652 	.ds 2
      000737                        653 _rgb_matrix_set_color_all_PARM_2:
      000737                        654 	.ds 1
      000738                        655 _rgb_matrix_set_color_all_PARM_3:
      000738                        656 	.ds 1
      000739                        657 _rgb_matrix_set_color_all_r_10000_287:
      000739                        658 	.ds 1
      00073A                        659 _sine8_theta_10000_289:
      00073A                        660 	.ds 1
      00073B                        661 _sine8_offset_10000_290:
      00073B                        662 	.ds 1
      00073C                        663 _sine8_fraction_10000_290:
      00073C                        664 	.ds 1
      00073D                        665 _breathing_cie_value_10000_293:
      00073D                        666 	.ds 1
      00073E                        667 _rgb_matrix_task_end_10000_298:
      00073E                        668 	.ds 1
      00073F                        669 _rgb_matrix_task_hsv_10000_298:
      00073F                        670 	.ds 3
      000742                        671 _rgb_matrix_task_rgb_10000_298:
      000742                        672 	.ds 3
      000745                        673 _process_rgb_matrix_PARM_2:
      000745                        674 	.ds 1
      000746                        675 _process_rgb_matrix_PARM_3:
      000746                        676 	.ds 1
      000747                        677 _process_rgb_matrix_row_10000_319:
      000747                        678 	.ds 1
      000748                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000748                        680 	.ds 1
      000749                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000749                        682 	.ds 1
      00074A                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      00074A                        684 	.ds 1
      00074B                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      00074B                        686 	.ds 1
      00074C                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      00074C                        688 	.ds 2
      00074E                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00074E                        690 	.ds 1
      00074F                        691 _rgb_matrix_mode_mode_10000_411:
      00074F                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      0052A2                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      0052A2 12 5A 8A         [24]  746 	lcall	_ak820_outline_0176
      0052A5 74 52            [12]  747 	mov	a,#0x52
      0052A7 12 38 60         [24]  748 	lcall	_ak820_outline_0123
      0052AA 90 06 DA         [24]  749 	mov	dptr,#_reactive_age
      0052AD F5 F0            [12]  750 	mov	b,a
      0052AF 12 BB 57         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      0052B2 12 4A 07         [24]  753 	lcall	_timer_read
      0052B5 12 38 6A         [24]  754 	lcall	_ak820_outline_0135
      0052B8 90 07 2C         [24]  755 	mov	dptr,#_reactive_at
      0052BB 12 5A 76         [24]  756 	lcall	_ak820_outline_0164
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      0052BE 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      0052BF                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      0052BF 90 07 2C         [24]  772 	mov	dptr,#_reactive_at
      0052C2 12 37 A1         [24]  773 	lcall	_ak820_outline_0004
      0052C5 12 4A 0A         [24]  774 	lcall	_timer_elapsed
      0052C8 AE 82            [24]  775 	mov	r6, dpl
      0052CA E5 83            [12]  776 	mov	a,dph
      0052CC C4               [12]  777 	swap	a
      0052CD CE               [12]  778 	xch	a,r6
      0052CE C4               [12]  779 	swap	a
      0052CF 54 0F            [12]  780 	anl	a,#0x0f
      0052D1 6E               [12]  781 	xrl	a,r6
      0052D2 CE               [12]  782 	xch	a,r6
      0052D3 54 0F            [12]  783 	anl	a,#0x0f
      0052D5 CE               [12]  784 	xch	a,r6
      0052D6 6E               [12]  785 	xrl	a,r6
      0052D7 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      0052D8 FF               [12]  788 	mov	r7,a
      0052D9 4E               [12]  789 	orl	a,r6
      0052DA 70 01            [24]  790 	jnz	00102$
      0052DC 22               [24]  791 	ret
      0052DD                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      0052DD 8E 04            [24]  794 	mov	ar4,r6
      0052DF EF               [12]  795 	mov	a,r7
      0052E0 C4               [12]  796 	swap	a
      0052E1 54 F0            [12]  797 	anl	a,#0xf0
      0052E3 CC               [12]  798 	xch	a,r4
      0052E4 C4               [12]  799 	swap	a
      0052E5 CC               [12]  800 	xch	a,r4
      0052E6 6C               [12]  801 	xrl	a,r4
      0052E7 CC               [12]  802 	xch	a,r4
      0052E8 54 F0            [12]  803 	anl	a,#0xf0
      0052EA CC               [12]  804 	xch	a,r4
      0052EB 6C               [12]  805 	xrl	a,r4
      0052EC FD               [12]  806 	mov	r5,a
      0052ED 90 07 2C         [24]  807 	mov	dptr,#_reactive_at
      0052F0 12 43 8E         [24]  808 	lcall	_ak820_outline_0120
      0052F3 90 07 2C         [24]  809 	mov	dptr,#_reactive_at
      0052F6 EC               [12]  810 	mov	a,r4
      0052F7 2A               [12]  811 	add	a, r2
      0052F8 F0               [24]  812 	movx	@dptr,a
      0052F9 ED               [12]  813 	mov	a,r5
      0052FA 3B               [12]  814 	addc	a, r3
      0052FB A3               [24]  815 	inc	dptr
      0052FC F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      0052FD 8E 04            [24]  818 	mov	ar4,r6
      0052FF 8F 05            [24]  819 	mov	ar5,r7
      005301 C3               [12]  820 	clr	c
      005302 74 FF            [12]  821 	mov	a,#0xff
      005304 9C               [12]  822 	subb	a,r4
      005305 E4               [12]  823 	clr	a
      005306 9D               [12]  824 	subb	a,r5
      005307 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005309 7D FF            [12]  827 	mov	r5,#0xff
      00530B 80 02            [24]  828 	sjmp	00109$
      00530D                        829 00108$:
      00530D 8E 05            [24]  830 	mov	ar5,r6
      00530F                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00530F 7F 00            [12]  833 	mov	r7,#0x00
      005311                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      005311 EF               [12]  836 	mov	a,r7
      005312 24 DA            [12]  837 	add	a, #_reactive_age
      005314 FC               [12]  838 	mov	r4,a
      005315 E4               [12]  839 	clr	a
      005316 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      005318 FE               [12]  841 	mov	r6,a
      005319 8C 82            [24]  842 	mov	dpl,r4
      00531B 8E 83            [24]  843 	mov	dph,r6
      00531D E0               [24]  844 	movx	a,@dptr
      00531E FB               [12]  845 	mov	r3,a
      00531F C3               [12]  846 	clr	c
      005320 ED               [12]  847 	mov	a,r5
      005321 9B               [12]  848 	subb	a,r3
      005322 40 04            [24]  849 	jc	00110$
      005324 7B 00            [12]  850 	mov	r3,#0x00
      005326 80 08            [24]  851 	sjmp	00111$
      005328                        852 00110$:
      005328 8C 82            [24]  853 	mov	dpl,r4
      00532A 8E 83            [24]  854 	mov	dph,r6
      00532C E0               [24]  855 	movx	a,@dptr
      00532D C3               [12]  856 	clr	c
      00532E 9D               [12]  857 	subb	a,r5
      00532F FB               [12]  858 	mov	r3,a
      005330                        859 00111$:
      005330 8C 82            [24]  860 	mov	dpl,r4
      005332 8E 83            [24]  861 	mov	dph,r6
      005334 EB               [12]  862 	mov	a,r3
      005335 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005336 0F               [12]  865 	inc	r7
      005337 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      00533A                        867 00144$:
      00533A 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      00533C 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      00533D                        881 _add_sat:
      00533D E5 82            [12]  882 	mov	a,dpl
      00533F 90 07 2F         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      005342 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      005343 90 07 2E         [24]  886 	mov	dptr,#_add_sat_PARM_2
      005346 E0               [24]  887 	movx	a,@dptr
      005347 FF               [12]  888 	mov	r7,a
      005348 FE               [12]  889 	mov	r6,a
      005349 74 FF            [12]  890 	mov	a,#0xff
      00534B C3               [12]  891 	clr	c
      00534C 9E               [12]  892 	subb	a,r6
      00534D FE               [12]  893 	mov	r6,a
      00534E 90 07 2F         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      005351 E0               [24]  895 	movx	a,@dptr
      005352 FD               [12]  896 	mov	r5,a
      005353 C3               [12]  897 	clr	c
      005354 EE               [12]  898 	mov	a,r6
      005355 9D               [12]  899 	subb	a,r5
      005356 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      005358 7E FF            [12]  902 	mov	r6,#0xff
      00535A 80 03            [24]  903 	sjmp	00104$
      00535C                        904 00103$:
      00535C EF               [12]  905 	mov	a,r7
      00535D 2D               [12]  906 	add	a, r5
      00535E FE               [12]  907 	mov	r6,a
      00535F                        908 00104$:
      00535F 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      005361 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      005362                        922 _sub_sat:
      005362 E5 82            [12]  923 	mov	a,dpl
      005364 90 07 31         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      005367 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      005368 E0               [24]  927 	movx	a,@dptr
      005369 FF               [12]  928 	mov	r7,a
      00536A 90 07 30         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      00536D E0               [24]  930 	movx	a,@dptr
      00536E FE               [12]  931 	mov	r6,a
      00536F C3               [12]  932 	clr	c
      005370 EF               [12]  933 	mov	a,r7
      005371 9E               [12]  934 	subb	a,r6
      005372 50 04            [24]  935 	jnc	00103$
      005374 7D 00            [12]  936 	mov	r5,#0x00
      005376 80 04            [24]  937 	sjmp	00104$
      005378                        938 00103$:
      005378 EF               [12]  939 	mov	a,r7
      005379 C3               [12]  940 	clr	c
      00537A 9E               [12]  941 	subb	a,r6
      00537B FD               [12]  942 	mov	r5,a
      00537C                        943 00104$:
      00537C 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      00537E 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      00537F                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      00537F D2 10            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005381 12 4A 07         [24]  959 	lcall	_timer_read
      005384 12 38 6A         [24]  960 	lcall	_ak820_outline_0135
      005387 90 06 CD         [24]  961 	mov	dptr,#_changed_at
      00538A 12 5A 76         [24]  962 	lcall	_ak820_outline_0164
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      00538D 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      00538E                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      00538E 90 06 CC         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      005391 E4               [12]  978 	clr	a
      005392 F0               [24]  979 	movx	@dptr,a
      005393 90 06 CB         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      005396 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005397 90 05 91         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00539A 12 5A 59         [24]  984 	lcall	_ak820_outline_0083
      00539D 90 05 94         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0053A0 12 5A 40         [24]  986 	lcall	_ak820_outline_0070
      0053A3 12 42 4B         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      0053A6 C2 10            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      0053A8 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      0053A9                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      0053A9 12 5A 8A         [24] 1002 	lcall	_ak820_outline_0176
      0053AC 12 5A 40         [24] 1003 	lcall	_ak820_outline_0070
      0053AF F5 F0            [12] 1004 	mov	b,a
      0053B1 12 BB 57         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      0053B4 12 5A 69         [24] 1007 	lcall	_ak820_outline_0111
      0053B7 44 01            [12] 1008 	orl	a,#0x01
      0053B9 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      0053BA 12 5A 39         [24] 1011 	lcall	_ak820_outline_0066
      0053BD 44 04            [12] 1012 	orl	a,#0x04
      0053BF F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      0053C0 90 06 C6         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0053C3 E4               [12] 1016 	clr	a
      0053C4 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      0053C5 90 06 C7         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0053C8 14               [12] 1020 	dec	a
      0053C9 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      0053CA 90 06 C8         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0053CD 74 50            [12] 1024 	mov	a,#0x50
      0053CF F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      0053D0 90 06 C9         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0053D3 74 60            [12] 1028 	mov	a,#0x60
      0053D5 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      0053D6 90 06 CA         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0053D9 74 FF            [12] 1032 	mov	a,#0xff
      0053DB F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      0053DC 02 53 8E         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      0053DF                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0053DF 90 05 81         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0053E2 12 5A 59         [24] 1047 	lcall	_ak820_outline_0083
      0053E5 90 05 84         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0053E8 12 5A 40         [24] 1049 	lcall	_ak820_outline_0070
      0053EB 12 40 DC         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      0053EE 12 5A 69         [24] 1052 	lcall	_ak820_outline_0111
      0053F1 60 11            [24] 1053 	jz	00101$
      0053F3 12 5A 1A         [24] 1054 	lcall	_ak820_outline_0018
      0053F6 C3               [12] 1055 	clr	c
      0053F7 64 80            [12] 1056 	xrl	a,#0x80
      0053F9 94 87            [12] 1057 	subb	a,#0x87
      0053FB 50 07            [24] 1058 	jnc	00101$
      0053FD 12 5A 39         [24] 1059 	lcall	_ak820_outline_0066
      005400 24 FE            [12] 1060 	add	a,#0xff - 0x01
      005402 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005404                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005404 12 53 A9         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      005407                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005407 90 06 C8         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00540A E0               [24] 1069 	movx	a,@dptr
      00540B 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      00540D 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00540F 90 06 C8         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005412 74 A0            [12] 1075 	mov	a,#0xa0
      005414 F0               [24] 1076 	movx	@dptr,a
      005415                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      005415 C2 10            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005417 C2 11            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005419 02 52 A2         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      00541C                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      00541C 12 53 DF         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      00541F 12 4A 07         [24] 1098 	lcall	_timer_read
      005422 12 43 94         [24] 1099 	lcall	_ak820_outline_0131
      005425 EE               [12] 1100 	mov	a,r6
      005426 24 F0            [12] 1101 	add	a,#0xf0
      005428 FE               [12] 1102 	mov	r6,a
      005429 EF               [12] 1103 	mov	a,r7
      00542A 34 FF            [12] 1104 	addc	a,#0xff
      00542C FF               [12] 1105 	mov	r7,a
      00542D 90 06 CF         [24] 1106 	mov	dptr,#_frame_at
      005430 12 49 6F         [24] 1107 	lcall	_ak820_outline_0059
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      005433 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      005434                       1122 _rgb_matrix_set_color:
      005434 12 38 44         [24] 1123 	lcall	_ak820_outline_0103
      005437 90 07 35         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      00543A 12 38 49         [24] 1125 	lcall	_ak820_outline_0104
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      00543D 90 07 35         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005440 12 38 01         [24] 1128 	lcall	_ak820_outline_0051
      005443 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      005446 C3               [12] 1130 	clr	c
      005447 EE               [12] 1131 	mov	a,r6
      005448 94 52            [12] 1132 	subb	a,#0x52
      00544A EF               [12] 1133 	mov	a,r7
      00544B 64 80            [12] 1134 	xrl	a,#0x80
      00544D 94 80            [12] 1135 	subb	a,#0x80
      00544F 50 23            [24] 1136 	jnc	00104$
      005451 90 07 32         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005454 E0               [24] 1138 	movx	a,@dptr
      005455 FF               [12] 1139 	mov	r7,a
      005456 90 07 33         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005459 E0               [24] 1141 	movx	a,@dptr
      00545A FD               [12] 1142 	mov	r5,a
      00545B 90 07 34         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00545E E0               [24] 1144 	movx	a,@dptr
      00545F FC               [12] 1145 	mov	r4,a
      005460 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005463 EF               [12] 1147 	mov	a,r7
      005464 F0               [24] 1148 	movx	@dptr,a
      005465 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      005468 ED               [12] 1150 	mov	a,r5
      005469 F0               [24] 1151 	movx	@dptr,a
      00546A 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      00546D EC               [12] 1153 	mov	a,r4
      00546E F0               [24] 1154 	movx	@dptr,a
      00546F 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      005471 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      005474                       1158 00104$:
      005474 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      005475                       1171 _rgb_matrix_set_color_all:
      005475 E5 82            [12] 1172 	mov	a,dpl
      005477 90 07 39         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      00547A F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      00547B E0               [24] 1176 	movx	a,@dptr
      00547C FF               [12] 1177 	mov	r7,a
      00547D 90 07 37         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005480 E0               [24] 1179 	movx	a,@dptr
      005481 FE               [12] 1180 	mov	r6,a
      005482 90 07 38         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005485 E0               [24] 1182 	movx	a,@dptr
      005486 FD               [12] 1183 	mov	r5,a
      005487 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      00548A EE               [12] 1185 	mov	a,r6
      00548B F0               [24] 1186 	movx	@dptr,a
      00548C 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      00548F ED               [12] 1188 	mov	a,r5
      005490 F0               [24] 1189 	movx	@dptr,a
      005491 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005493 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      005496                       1206 _sine8:
      005496 E5 82            [12] 1207 	mov	a,dpl
      005498 90 07 3A         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      00549B F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      00549C E0               [24] 1211 	movx	a,@dptr
      00549D FF               [12] 1212 	mov	r7,a
      00549E 90 07 3B         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      0054A1 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      0054A2 EF               [12] 1216 	mov	a,r7
      0054A3 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      0054A6 90 07 3B         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      0054A9 74 FF            [12] 1219 	mov	a,#0xff
      0054AB C3               [12] 1220 	clr	c
      0054AC 9F               [12] 1221 	subb	a,r7
      0054AD F0               [24] 1222 	movx	@dptr,a
      0054AE                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      0054AE 90 07 3B         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      0054B1 E0               [24] 1226 	movx	a,@dptr
      0054B2 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      0054B5 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      0054B6 90 07 3B         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      0054B9 E0               [24] 1231 	movx	a,@dptr
      0054BA 54 0F            [12] 1232 	anl	a,#0x0f
      0054BC FF               [12] 1233 	mov	r7,a
      0054BD 90 07 3C         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      0054C0 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      0054C1 90 07 3A         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      0054C4 E0               [24] 1238 	movx	a,@dptr
      0054C5 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      0054C8 90 07 3C         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      0054CB EF               [12] 1241 	mov	a,r7
      0054CC 04               [12] 1242 	inc	a
      0054CD F0               [24] 1243 	movx	@dptr,a
      0054CE                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      0054CE 90 07 3B         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      0054D1 E0               [24] 1247 	movx	a,@dptr
      0054D2 C4               [12] 1248 	swap	a
      0054D3 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      0054D5 25 E0            [12] 1251 	add	a,acc
      0054D7 FF               [12] 1252 	mov	r7,a
      0054D8 90 BC 3C         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      0054DB 93               [24] 1254 	movc	a,@a+dptr
      0054DC FE               [12] 1255 	mov	r6,a
      0054DD 0F               [12] 1256 	inc	r7
      0054DE EF               [12] 1257 	mov	a,r7
      0054DF 90 BC 3C         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      0054E2 93               [24] 1259 	movc	a,@a+dptr
      0054E3 FF               [12] 1260 	mov	r7,a
      0054E4 90 07 3C         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      0054E7 E0               [24] 1262 	movx	a,@dptr
      0054E8 8F F0            [24] 1263 	mov	b,r7
      0054EA A4               [48] 1264 	mul	ab
      0054EB FF               [12] 1265 	mov	r7,a
      0054EC E5 F0            [12] 1266 	mov	a,b
      0054EE C4               [12] 1267 	swap	a
      0054EF CF               [12] 1268 	xch	a,r7
      0054F0 C4               [12] 1269 	swap	a
      0054F1 54 0F            [12] 1270 	anl	a,#0x0f
      0054F3 6F               [12] 1271 	xrl	a,r7
      0054F4 CF               [12] 1272 	xch	a,r7
      0054F5 54 0F            [12] 1273 	anl	a,#0x0f
      0054F7 CF               [12] 1274 	xch	a,r7
      0054F8 6F               [12] 1275 	xrl	a,r7
      0054F9 CF               [12] 1276 	xch	a,r7
      0054FA EF               [12] 1277 	mov	a,r7
      0054FB 2E               [12] 1278 	add	a, r6
      0054FC FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      0054FD 90 07 3A         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      005500 E0               [24] 1282 	movx	a,@dptr
      005501 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005504 8F 06            [24] 1284 	mov	ar6,r7
      005506 74 80            [12] 1285 	mov	a,#0x80
      005508 C3               [12] 1286 	clr	c
      005509 9E               [12] 1287 	subb	a,r6
      00550A FE               [12] 1288 	mov	r6,a
      00550B 80 04            [24] 1289 	sjmp	00108$
      00550D                       1290 00107$:
      00550D 74 80            [12] 1291 	mov	a,#0x80
      00550F 2F               [12] 1292 	add	a, r7
      005510 FE               [12] 1293 	mov	r6,a
      005511                       1294 00108$:
      005511 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005513 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005514                       1312 _breathing_cie:
      005514 E5 82            [12] 1313 	mov	a,dpl
      005516 90 07 3D         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005519 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      00551A E0               [24] 1317 	movx	a,@dptr
      00551B FF               [12] 1318 	mov	r7,a
      00551C 12 5A 98         [24] 1319 	lcall	_ak820_outline_0183
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00551F FE               [12] 1321 	mov	r6,a
      005520 90 BF 48         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      005523 93               [24] 1323 	movc	a,@a+dptr
      005524 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      005525 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      005528 8D 82            [24] 1327 	mov	dpl, r5
      00552A 22               [24] 1328 	ret
      00552B                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      00552B EE               [12] 1331 	mov	a,r6
      00552C 04               [12] 1332 	inc	a
      00552D 90 BF 48         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      005530 93               [24] 1334 	movc	a,@a+dptr
      005531 C3               [12] 1335 	clr	c
      005532 9D               [12] 1336 	subb	a,r5
      005533 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005534 74 07            [12] 1339 	mov	a,#0x07
      005536 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005537 F5 F0            [12] 1342 	mov	b,a
      005539 EE               [12] 1343 	mov	a,r6
      00553A A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      00553B 12 5A 98         [24] 1346 	lcall	_ak820_outline_0183
      00553E 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      00553F F5 82            [12] 1349 	mov	dpl,a
      005541 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      005542                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      005542 12 52 BF         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005545 30 10 18         [24] 1369 	jnb	_dirty,00102$
      005548 90 06 CD         [24] 1370 	mov	dptr,#_changed_at
      00554B 12 37 A1         [24] 1371 	lcall	_ak820_outline_0004
      00554E 12 4A 0A         [24] 1372 	lcall	_timer_elapsed
      005551 12 43 94         [24] 1373 	lcall	_ak820_outline_0131
      005554 C3               [12] 1374 	clr	c
      005555 EE               [12] 1375 	mov	a,r6
      005556 94 E8            [12] 1376 	subb	a,#0xe8
      005558 EF               [12] 1377 	mov	a,r7
      005559 94 03            [12] 1378 	subb	a,#0x03
      00555B 40 03            [24] 1379 	jc	00102$
      00555D 12 53 8E         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      005560                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      005560 30 11 03         [24] 1383 	jnb	_rendering,00254$
      005563 02 56 1B         [24] 1384 	ljmp	00109$
      005566                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005566 90 06 CF         [24] 1387 	mov	dptr,#_frame_at
      005569 12 37 A1         [24] 1388 	lcall	_ak820_outline_0004
      00556C 12 4A 0A         [24] 1389 	lcall	_timer_elapsed
      00556F 12 43 94         [24] 1390 	lcall	_ak820_outline_0131
      005572 C3               [12] 1391 	clr	c
      005573 EE               [12] 1392 	mov	a,r6
      005574 94 10            [12] 1393 	subb	a,#0x10
      005576 EF               [12] 1394 	mov	a,r7
      005577 94 00            [12] 1395 	subb	a,#0x00
      005579 50 01            [24] 1396 	jnc	00105$
      00557B 22               [24] 1397 	ret
      00557C                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      00557C 12 4A 07         [24] 1400 	lcall	_timer_read
      00557F 12 38 6A         [24] 1401 	lcall	_ak820_outline_0135
      005582 90 06 CF         [24] 1402 	mov	dptr,#_frame_at
      005585 12 5A 76         [24] 1403 	lcall	_ak820_outline_0164
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      005588 90 06 C9         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00558B E0               [24] 1406 	movx	a,@dptr
      00558C FF               [12] 1407 	mov	r7,a
      00558D 7E 00            [12] 1408 	mov	r6,#0x00
      00558F 74 20            [12] 1409 	mov	a,#0x20
      005591 2F               [12] 1410 	add	a, r7
      005592 FF               [12] 1411 	mov	r7,a
      005593 E4               [12] 1412 	clr	a
      005594 3E               [12] 1413 	addc	a, r6
      005595 FE               [12] 1414 	mov	r6,a
      005596 90 06 D1         [24] 1415 	mov	dptr,#_phase
      005599 12 38 20         [24] 1416 	lcall	_ak820_outline_0060
      00559C EF               [12] 1417 	mov	a,r7
      00559D 2C               [12] 1418 	add	a, r4
      00559E FF               [12] 1419 	mov	r7,a
      00559F EE               [12] 1420 	mov	a,r6
      0055A0 3D               [12] 1421 	addc	a, r5
      0055A1 FE               [12] 1422 	mov	r6,a
      0055A2 90 06 D1         [24] 1423 	mov	dptr,#_phase
      0055A5 EF               [12] 1424 	mov	a,r7
      0055A6 F0               [24] 1425 	movx	@dptr,a
      0055A7 EE               [12] 1426 	mov	a,r6
      0055A8 A3               [24] 1427 	inc	dptr
      0055A9 F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      0055AA 90 06 D1         [24] 1430 	mov	dptr,#_phase
      0055AD E0               [24] 1431 	movx	a,@dptr
      0055AE A3               [24] 1432 	inc	dptr
      0055AF E0               [24] 1433 	movx	a,@dptr
      0055B0 FF               [12] 1434 	mov	r7,a
      0055B1 90 06 D9         [24] 1435 	mov	dptr,#_frame_phase
      0055B4 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      0055B5 20 0F 05         [24] 1438 	jb	_suspended,00135$
      0055B8 12 5A 39         [24] 1439 	lcall	_ak820_outline_0066
      0055BB 70 04            [24] 1440 	jnz	00132$
      0055BD                       1441 00135$:
      0055BD 7E 00            [12] 1442 	mov	r6,#0x00
      0055BF 80 04            [24] 1443 	sjmp	00133$
      0055C1                       1444 00132$:
      0055C1 12 5A 1A         [24] 1445 	lcall	_ak820_outline_0018
      0055C4 FE               [12] 1446 	mov	r6,a
      0055C5                       1447 00133$:
      0055C5 90 06 D4         [24] 1448 	mov	dptr,#_frame_mode
      0055C8 EE               [12] 1449 	mov	a,r6
      0055C9 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      0055CA 90 06 C6         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055CD E0               [24] 1453 	movx	a,@dptr
      0055CE 90 06 D5         [24] 1454 	mov	dptr,#_frame_hue
      0055D1 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      0055D2 90 06 C7         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055D5 E0               [24] 1458 	movx	a,@dptr
      0055D6 90 06 D6         [24] 1459 	mov	dptr,#_frame_sat
      0055D9 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      0055DA 90 06 C8         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055DD E0               [24] 1463 	movx	a,@dptr
      0055DE FD               [12] 1464 	mov	r5,a
      0055DF 90 06 D7         [24] 1465 	mov	dptr,#_frame_val
      0055E2 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      0055E3 90 06 CA         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0055E6 E0               [24] 1469 	movx	a,@dptr
      0055E7 90 06 D8         [24] 1470 	mov	dptr,#_frame_flags
      0055EA F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      0055EB BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      0055EE EF               [12] 1475 	mov	a,r7
      0055EF 24 C0            [12] 1476 	add	a,#0xc0
      0055F1 F5 82            [12] 1477 	mov	dpl,a
      0055F3 C0 05            [24] 1478 	push	ar5
      0055F5 12 54 96         [24] 1479 	lcall	_sine8
      0055F8 AF 82            [24] 1480 	mov	r7, dpl
      0055FA D0 05            [24] 1481 	pop	ar5
      0055FC 8D F0            [24] 1482 	mov	b,r5
      0055FE EF               [12] 1483 	mov	a,r7
      0055FF A4               [48] 1484 	mul	ab
      005600 AE F0            [24] 1485 	mov	r6,b
      005602 8E 05            [24] 1486 	mov	ar5,r6
      005604 90 06 D7         [24] 1487 	mov	dptr,#_frame_val
      005607 ED               [12] 1488 	mov	a,r5
      005608 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005609 8D 82            [24] 1491 	mov	dpl, r5
      00560B 12 55 14         [24] 1492 	lcall	_breathing_cie
      00560E E5 82            [12] 1493 	mov	a, dpl
      005610 90 06 D7         [24] 1494 	mov	dptr,#_frame_val
      005613 F0               [24] 1495 	movx	@dptr,a
      005614                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005614 90 06 D3         [24] 1498 	mov	dptr,#_led_index
      005617 E4               [12] 1499 	clr	a
      005618 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005619 D2 11            [12] 1503 	setb	_rendering
      00561B                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00561B 12 5A 93         [24] 1506 	lcall	_ak820_outline_0182
      00561E 24 08            [12] 1507 	add	a,#0x08
      005620 FF               [12] 1508 	mov	r7,a
      005621 90 07 3E         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005624 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005625 EF               [12] 1512 	mov	a,r7
      005626 24 AD            [12] 1513 	add	a,#0xff - 0x52
      005628 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      00562A 90 07 3E         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00562D 74 52            [12] 1517 	mov	a,#0x52
      00562F F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005630                       1520 00125$:
      005630 12 5A 93         [24] 1521 	lcall	_ak820_outline_0182
      005633 FF               [12] 1522 	mov	r7,a
      005634 90 07 3E         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005637 E0               [24] 1524 	movx	a,@dptr
      005638 FE               [12] 1525 	mov	r6,a
      005639 C3               [12] 1526 	clr	c
      00563A EF               [12] 1527 	mov	a,r7
      00563B 9E               [12] 1528 	subb	a,r6
      00563C 40 03            [24] 1529 	jc	00261$
      00563E 02 57 A2         [24] 1530 	ljmp	00127$
      005641                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      005641 12 5A 70         [24] 1533 	lcall	_ak820_outline_0137
      005644 E0               [24] 1534 	movx	a,@dptr
      005645 60 07            [24] 1535 	jz	00121$
      005647 90 06 D8         [24] 1536 	mov	dptr,#_frame_flags
      00564A E0               [24] 1537 	movx	a,@dptr
      00564B 20 E2 1C         [24] 1538 	jb	acc.2,00122$
      00564E                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      00564E 12 5A 93         [24] 1541 	lcall	_ak820_outline_0182
      005651 FC               [12] 1542 	mov	r4,a
      005652 7D 00            [12] 1543 	mov	r5,#0x00
      005654 90 07 32         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005657 E4               [12] 1545 	clr	a
      005658 F0               [24] 1546 	movx	@dptr,a
      005659 90 07 33         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00565C F0               [24] 1548 	movx	@dptr,a
      00565D 90 07 34         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005660 F0               [24] 1550 	movx	@dptr,a
      005661 12 38 55         [24] 1551 	lcall	_ak820_outline_0117
      005664 12 54 34         [24] 1552 	lcall	_rgb_matrix_set_color
      005667 02 57 99         [24] 1553 	ljmp	00123$
      00566A                       1554 00122$:
                                   1555 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      00566A BE 05 21         [24] 1556 	cjne	r6,#0x05,00119$
                                   1557 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00566D EF               [12] 1558 	mov	a,r7
      00566E 75 F0 03         [24] 1559 	mov	b,#0x03
      005671 A4               [48] 1560 	mul	ab
      005672 24 83            [12] 1561 	add	a, #_g_direct_mode_colors
      005674 FD               [12] 1562 	mov	r5,a
      005675 74 0C            [12] 1563 	mov	a,#(_g_direct_mode_colors >> 8)
      005677 35 F0            [12] 1564 	addc	a, b
      005679 FE               [12] 1565 	mov	r6,a
      00567A 90 0D 97         [24] 1566 	mov	dptr,#___memcpy_PARM_2
      00567D ED               [12] 1567 	mov	a,r5
      00567E F0               [24] 1568 	movx	@dptr,a
      00567F EE               [12] 1569 	mov	a,r6
      005680 12 5A 4A         [24] 1570 	lcall	_ak820_outline_0072
      005683 90 07 3F         [24] 1571 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005686 F5 F0            [12] 1572 	mov	b,a
      005688 12 BA E1         [24] 1573 	lcall	___memcpy
      00568B 02 57 3D         [24] 1574 	ljmp	00120$
      00568E                       1575 00119$:
                                   1576 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      00568E 90 06 D5         [24] 1577 	mov	dptr,#_frame_hue
      005691 E0               [24] 1578 	movx	a,@dptr
      005692 90 07 3F         [24] 1579 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005695 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005696 90 06 D6         [24] 1582 	mov	dptr,#_frame_sat
      005699 E0               [24] 1583 	movx	a,@dptr
      00569A 90 07 40         [24] 1584 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      00569D F0               [24] 1585 	movx	@dptr,a
                                   1586 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      00569E 90 06 D7         [24] 1587 	mov	dptr,#_frame_val
      0056A1 E0               [24] 1588 	movx	a,@dptr
      0056A2 90 07 41         [24] 1589 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0056A5 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      0056A6 12 5A 70         [24] 1592 	lcall	_ak820_outline_0137
      0056A9 BE 03 0E         [24] 1593 	cjne	r6,#0x03,00113$
      0056AC 90 07 3F         [24] 1594 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0056AF E0               [24] 1595 	movx	a,@dptr
      0056B0 FE               [12] 1596 	mov	r6,a
      0056B1 90 06 D9         [24] 1597 	mov	dptr,#_frame_phase
      0056B4 E0               [24] 1598 	movx	a,@dptr
      0056B5 2E               [12] 1599 	add	a, r6
      0056B6 90 07 3F         [24] 1600 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0056B9 F0               [24] 1601 	movx	@dptr,a
      0056BA                       1602 00113$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      0056BA 12 5A 70         [24] 1604 	lcall	_ak820_outline_0137
      0056BD BE 04 23         [24] 1605 	cjne	r6,#0x04,00115$
      0056C0 90 07 3F         [24] 1606 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0056C3 E0               [24] 1607 	movx	a,@dptr
      0056C4 FE               [12] 1608 	mov	r6,a
      0056C5 12 5A 93         [24] 1609 	lcall	_ak820_outline_0182
      0056C8 75 F0 02         [24] 1610 	mov	b,#0x02
      0056CB A4               [48] 1611 	mul	ab
      0056CC 24 A4            [12] 1612 	add	a, #_ak820_led_points
      0056CE F5 82            [12] 1613 	mov	dpl,a
      0056D0 74 BE            [12] 1614 	mov	a,#(_ak820_led_points >> 8)
      0056D2 12 5A 62         [24] 1615 	lcall	_ak820_outline_0105
      0056D5 FD               [12] 1616 	mov	r5,a
      0056D6 90 06 D9         [24] 1617 	mov	dptr,#_frame_phase
      0056D9 E0               [24] 1618 	movx	a,@dptr
      0056DA FC               [12] 1619 	mov	r4,a
      0056DB ED               [12] 1620 	mov	a,r5
      0056DC C3               [12] 1621 	clr	c
      0056DD 9C               [12] 1622 	subb	a,r4
      0056DE 2E               [12] 1623 	add	a, r6
      0056DF 90 07 3F         [24] 1624 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0056E2 F0               [24] 1625 	movx	@dptr,a
      0056E3                       1626 00115$:
                                   1627 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      0056E3 12 5A 70         [24] 1628 	lcall	_ak820_outline_0137
      0056E6 BE 06 54         [24] 1629 	cjne	r6,#0x06,00120$
                                   1630 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      0056E9 12 5A 81         [24] 1631 	lcall	_ak820_outline_0170
      0056EC FE               [12] 1632 	mov	r6,a
      0056ED 74 07            [12] 1633 	mov	a,#0x07
      0056EF C3               [12] 1634 	clr	c
      0056F0 9E               [12] 1635 	subb	a,r6
      0056F1 FE               [12] 1636 	mov	r6,a
                                   1637 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      0056F2 8E F0            [24] 1638 	mov	b,r6
      0056F4 05 F0            [12] 1639 	inc	b
      0056F6 74 01            [12] 1640 	mov	a,#0x01
      0056F8 80 02            [24] 1641 	sjmp	00273$
      0056FA                       1642 00272$:
      0056FA 25 E0            [12] 1643 	add	a,acc
      0056FC                       1644 00273$:
      0056FC D5 F0 FB         [24] 1645 	djnz	b,00272$
      0056FF FD               [12] 1646 	mov	r5,a
                                   1647 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      005700 12 5A 93         [24] 1648 	lcall	_ak820_outline_0182
      005703 24 DA            [12] 1649 	add	a, #_reactive_age
      005705 F5 82            [12] 1650 	mov	dpl,a
      005707 E4               [12] 1651 	clr	a
      005708 34 06            [12] 1652 	addc	a, #(_reactive_age >> 8)
      00570A F5 83            [12] 1653 	mov	dph,a
      00570C E0               [24] 1654 	movx	a,@dptr
                                   1655 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      00570D FC               [12] 1656 	mov	r4,a
      00570E C3               [12] 1657 	clr	c
      00570F 9D               [12] 1658 	subb	a,r5
      005710 40 07            [24] 1659 	jc	00137$
      005712 90 06 D7         [24] 1660 	mov	dptr,#_frame_val
      005715 E0               [24] 1661 	movx	a,@dptr
      005716 FB               [12] 1662 	mov	r3,a
      005717 80 1F            [24] 1663 	sjmp	00138$
      005719                       1664 00137$:
      005719 90 06 D7         [24] 1665 	mov	dptr,#_frame_val
      00571C E0               [24] 1666 	movx	a,@dptr
      00571D F5 F0            [12] 1667 	mov	b, a
      00571F EC               [12] 1668 	mov	a,r4
      005720 A4               [48] 1669 	mul	ab
      005721 FC               [12] 1670 	mov	r4,a
      005722 AA F0            [24] 1671 	mov	r2,b
      005724 8E F0            [24] 1672 	mov	b,r6
      005726 05 F0            [12] 1673 	inc	b
      005728 AB 04            [24] 1674 	mov	r3,ar4
      00572A AD 02            [24] 1675 	mov	r5,ar2
      00572C 80 07            [24] 1676 	sjmp	00276$
      00572E                       1677 00275$:
      00572E C3               [12] 1678 	clr	c
      00572F ED               [12] 1679 	mov	a,r5
      005730 13               [12] 1680 	rrc	a
      005731 FD               [12] 1681 	mov	r5,a
      005732 EB               [12] 1682 	mov	a,r3
      005733 13               [12] 1683 	rrc	a
      005734 FB               [12] 1684 	mov	r3,a
      005735                       1685 00276$:
      005735 D5 F0 F6         [24] 1686 	djnz	b,00275$
      005738                       1687 00138$:
      005738 90 07 41         [24] 1688 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00573B EB               [12] 1689 	mov	a,r3
      00573C F0               [24] 1690 	movx	@dptr,a
      00573D                       1691 00120$:
                                   1692 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      00573D 12 5A 70         [24] 1693 	lcall	_ak820_outline_0137
      005740 BE 02 03         [24] 1694 	cjne	r6,#0x02,00277$
      005743 D3               [12] 1695 	setb	c
      005744 80 01            [24] 1696 	sjmp	00278$
      005746                       1697 00277$:
      005746 C3               [12] 1698 	clr	c
      005747                       1699 00278$:
      005747 B3               [12] 1700 	cpl	c
      005748 92 12            [24] 1701 	mov	_rgb_matrix_task_sloc0_1_0,c
      00574A 90 0D 97         [24] 1702 	mov	dptr,#___memcpy_PARM_2
      00574D 74 3F            [12] 1703 	mov	a,#_rgb_matrix_task_hsv_10000_298
      00574F F0               [24] 1704 	movx	@dptr,a
      005750 74 07            [12] 1705 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      005752 12 5A 4A         [24] 1706 	lcall	_ak820_outline_0072
      005755 90 0A E0         [24] 1707 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005758 F5 F0            [12] 1708 	mov	b,a
      00575A 12 BA E1         [24] 1709 	lcall	___memcpy
      00575D 90 0A E3         [24] 1710 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      005760 74 42            [12] 1711 	mov	a,#_rgb_matrix_task_rgb_10000_298
      005762 F0               [24] 1712 	movx	@dptr,a
      005763 74 07            [12] 1713 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005765 A3               [24] 1714 	inc	dptr
      005766 F0               [24] 1715 	movx	@dptr,a
      005767 A2 12            [12] 1716 	mov	c,_rgb_matrix_task_sloc0_1_0
      005769 12 38 81         [24] 1717 	lcall	_ak820_outline_0167
      00576C 12 85 7A         [24] 1718 	lcall	_hsv_to_rgb_into
                                   1719 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00576F 12 5A 93         [24] 1720 	lcall	_ak820_outline_0182
      005772 FD               [12] 1721 	mov	r5,a
      005773 7E 00            [12] 1722 	mov	r6,#0x00
      005775 90 07 43         [24] 1723 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005778 E0               [24] 1724 	movx	a,@dptr
      005779 FC               [12] 1725 	mov	r4,a
      00577A 90 07 42         [24] 1726 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      00577D E0               [24] 1727 	movx	a,@dptr
      00577E FB               [12] 1728 	mov	r3,a
      00577F 90 07 44         [24] 1729 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005782 E0               [24] 1730 	movx	a,@dptr
      005783 FA               [12] 1731 	mov	r2,a
      005784 90 07 32         [24] 1732 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005787 EC               [12] 1733 	mov	a,r4
      005788 F0               [24] 1734 	movx	@dptr,a
      005789 90 07 33         [24] 1735 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00578C EB               [12] 1736 	mov	a,r3
      00578D F0               [24] 1737 	movx	@dptr,a
      00578E 90 07 34         [24] 1738 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005791 EA               [12] 1739 	mov	a,r2
      005792 F0               [24] 1740 	movx	@dptr,a
      005793 12 38 65         [24] 1741 	lcall	_ak820_outline_0132
      005796 12 54 34         [24] 1742 	lcall	_rgb_matrix_set_color
      005799                       1743 00123$:
                                   1744 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005799 12 5A 93         [24] 1745 	lcall	_ak820_outline_0182
      00579C 24 01            [12] 1746 	add	a, #0x01
      00579E F0               [24] 1747 	movx	@dptr,a
      00579F 02 56 30         [24] 1748 	ljmp	00125$
      0057A2                       1749 00127$:
                                   1750 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      0057A2 BF 52 02         [24] 1751 	cjne	r7,#0x52,00130$
                                   1752 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1753 ;	assignBit
      0057A5 C2 11            [12] 1754 	clr	_rendering
      0057A7                       1755 00130$:
                                   1756 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      0057A7 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1760 ;------------------------------------------------------------
                                   1761 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1762 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1763 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1764 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1765 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function process_rgb_matrix
                                   1770 ;	-----------------------------------------
      0057A8                       1771 _process_rgb_matrix:
      0057A8 E5 82            [12] 1772 	mov	a,dpl
      0057AA 90 07 47         [24] 1773 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0057AD F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      0057AE 90 07 46         [24] 1776 	mov	dptr,#_process_rgb_matrix_PARM_3
      0057B1 E0               [24] 1777 	movx	a,@dptr
      0057B2 60 23            [24] 1778 	jz	00101$
      0057B4 20 0F 20         [24] 1779 	jb	_suspended,00101$
      0057B7 12 5A 39         [24] 1780 	lcall	_ak820_outline_0066
      0057BA 60 1B            [24] 1781 	jz	00101$
                                   1782 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      0057BC 12 5A 1A         [24] 1783 	lcall	_ak820_outline_0018
      0057BF FF               [12] 1784 	mov	r7,a
      0057C0 BF 06 14         [24] 1785 	cjne	r7,#0x06,00101$
      0057C3 90 07 47         [24] 1786 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0057C6 E0               [24] 1787 	movx	a,@dptr
      0057C7 FF               [12] 1788 	mov	r7,a
      0057C8 BF 10 00         [24] 1789 	cjne	r7,#0x10,00169$
      0057CB                       1790 00169$:
      0057CB 50 0A            [24] 1791 	jnc	00101$
      0057CD 90 07 45         [24] 1792 	mov	dptr,#_process_rgb_matrix_PARM_2
      0057D0 E0               [24] 1793 	movx	a,@dptr
      0057D1 FE               [12] 1794 	mov	r6,a
      0057D2 BE 08 00         [24] 1795 	cjne	r6,#0x08,00171$
      0057D5                       1796 00171$:
      0057D5 40 01            [24] 1797 	jc	00102$
      0057D7                       1798 00101$:
      0057D7 22               [24] 1799 	ret
      0057D8                       1800 00102$:
                                   1801 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      0057D8 C0 07            [24] 1802 	push	ar7
      0057DA C0 06            [24] 1803 	push	ar6
      0057DC 12 52 BF         [24] 1804 	lcall	_age_reactive
      0057DF D0 06            [24] 1805 	pop	ar6
      0057E1 D0 07            [24] 1806 	pop	ar7
                                   1807 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      0057E3 EF               [12] 1808 	mov	a,r7
      0057E4 12 38 8B         [24] 1809 	lcall	_ak820_outline_0187
      0057E7 2E               [12] 1810 	add	a,r6
      0057E8 FF               [12] 1811 	mov	r7,a
                                   1812 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0057E9 7E 00            [12] 1813 	mov	r6,#0x00
      0057EB                       1814 00111$:
                                   1815 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      0057EB EE               [12] 1816 	mov	a,r6
      0057EC 90 BB EA         [24] 1817 	mov	dptr,#_ak820_rgb_slots
      0057EF 93               [24] 1818 	movc	a,@a+dptr
      0057F0 B5 07 29         [24] 1819 	cjne	a,ar7,00112$
                                   1820 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      0057F3 EE               [12] 1821 	mov	a,r6
      0057F4 24 DA            [12] 1822 	add	a, #_reactive_age
      0057F6 FC               [12] 1823 	mov	r4,a
      0057F7 E4               [12] 1824 	clr	a
      0057F8 34 06            [12] 1825 	addc	a, #(_reactive_age >> 8)
      0057FA FD               [12] 1826 	mov	r5,a
      0057FB 12 5A 81         [24] 1827 	lcall	_ak820_outline_0170
      0057FE F5 F0            [12] 1828 	mov	b, a
      005800 05 F0            [12] 1829 	inc	b
      005802 7B 80            [12] 1830 	mov	r3,#0x80
      005804 E4               [12] 1831 	clr	a
      005805 FA               [12] 1832 	mov	r2,a
      005806 33               [12] 1833 	rlc	a
      005807 92 D2            [24] 1834 	mov	ov,c
      005809 80 08            [24] 1835 	sjmp	00176$
      00580B                       1836 00175$:
      00580B A2 D2            [12] 1837 	mov	c,ov
      00580D EA               [12] 1838 	mov	a,r2
      00580E 13               [12] 1839 	rrc	a
      00580F FA               [12] 1840 	mov	r2,a
      005810 EB               [12] 1841 	mov	a,r3
      005811 13               [12] 1842 	rrc	a
      005812 FB               [12] 1843 	mov	r3,a
      005813                       1844 00176$:
      005813 D5 F0 F5         [24] 1845 	djnz	b,00175$
      005816 12 38 55         [24] 1846 	lcall	_ak820_outline_0117
      005819 EB               [12] 1847 	mov	a,r3
      00581A F0               [24] 1848 	movx	@dptr,a
                                   1849 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      00581B 22               [24] 1850 	ret
      00581C                       1851 00112$:
                                   1852 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00581C 0E               [12] 1853 	inc	r6
      00581D BE 52 00         [24] 1854 	cjne	r6,#0x52,00177$
      005820                       1855 00177$:
      005820 40 C9            [24] 1856 	jc	00111$
                                   1857 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005822 22               [24] 1858 	ret
                                   1859 ;------------------------------------------------------------
                                   1860 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1861 ;------------------------------------------------------------
                                   1862 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1863 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function rgb_matrix_set_suspend_state
                                   1868 ;	-----------------------------------------
      005823                       1869 _rgb_matrix_set_suspend_state:
      005823 E5 82            [12] 1870 	mov	a,dpl
      005825 90 07 48         [24] 1871 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005828 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005829 E0               [24] 1874 	movx	a,@dptr
                                   1875 ;	assignBit
      00582A F5 15            [12] 1876 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      00582C 13               [12] 1877 	rrc	a
      00582D 92 0F            [24] 1878 	mov	_suspended,c
                                   1879 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1880 ;	assignBit
      00582F C2 11            [12] 1881 	clr	_rendering
                                   1882 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005831 12 52 A2         [24] 1883 	lcall	_clear_reactive
                                   1884 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005834 E5 15            [12] 1885 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005836 60 0F            [24] 1886 	jz	00103$
                                   1887 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005838 90 07 37         [24] 1888 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      00583B E4               [12] 1889 	clr	a
      00583C F0               [24] 1890 	movx	@dptr,a
      00583D 90 07 38         [24] 1891 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005840 F0               [24] 1892 	movx	@dptr,a
      005841 75 82 00         [24] 1893 	mov	dpl, #0x00
                                   1894 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005844 02 54 75         [24] 1895 	ljmp	_rgb_matrix_set_color_all
      005847                       1896 00103$:
      005847 22               [24] 1897 	ret
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function rgb_matrix_is_enabled
                                   1904 ;	-----------------------------------------
      005848                       1905 _rgb_matrix_is_enabled:
      005848 12 5A 39         [24] 1906 	lcall	_ak820_outline_0066
      00584B F5 82            [12] 1907 	mov	dpl,a
      00584D 22               [24] 1908 	ret
                                   1909 ;------------------------------------------------------------
                                   1910 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1911 ;------------------------------------------------------------
                                   1912 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1913 ;	-----------------------------------------
                                   1914 ;	 function rgb_matrix_get_mode
                                   1915 ;	-----------------------------------------
      00584E                       1916 _rgb_matrix_get_mode:
      00584E 12 5A 1A         [24] 1917 	lcall	_ak820_outline_0018
      005851 F5 82            [12] 1918 	mov	dpl,a
      005853 22               [24] 1919 	ret
                                   1920 ;------------------------------------------------------------
                                   1921 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1922 ;------------------------------------------------------------
                                   1923 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1924 ;	-----------------------------------------
                                   1925 ;	 function rgb_matrix_get_hue
                                   1926 ;	-----------------------------------------
      005854                       1927 _rgb_matrix_get_hue:
      005854 90 06 C6         [24] 1928 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005857 E0               [24] 1929 	movx	a,@dptr
      005858 F5 82            [12] 1930 	mov	dpl,a
      00585A 22               [24] 1931 	ret
                                   1932 ;------------------------------------------------------------
                                   1933 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function rgb_matrix_get_sat
                                   1938 ;	-----------------------------------------
      00585B                       1939 _rgb_matrix_get_sat:
      00585B 90 06 C7         [24] 1940 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00585E E0               [24] 1941 	movx	a,@dptr
      00585F F5 82            [12] 1942 	mov	dpl,a
      005861 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function rgb_matrix_get_val
                                   1950 ;	-----------------------------------------
      005862                       1951 _rgb_matrix_get_val:
      005862 90 06 C8         [24] 1952 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005865 E0               [24] 1953 	movx	a,@dptr
      005866 F5 82            [12] 1954 	mov	dpl,a
      005868 22               [24] 1955 	ret
                                   1956 ;------------------------------------------------------------
                                   1957 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1960 ;	-----------------------------------------
                                   1961 ;	 function rgb_matrix_get_speed
                                   1962 ;	-----------------------------------------
      005869                       1963 _rgb_matrix_get_speed:
      005869 90 06 C9         [24] 1964 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00586C E0               [24] 1965 	movx	a,@dptr
      00586D F5 82            [12] 1966 	mov	dpl,a
      00586F 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1970 ;------------------------------------------------------------
                                   1971 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1972 ;	-----------------------------------------
                                   1973 ;	 function rgb_matrix_toggle_noeeprom
                                   1974 ;	-----------------------------------------
      005870                       1975 _rgb_matrix_toggle_noeeprom:
      005870 12 5A 39         [24] 1976 	lcall	_ak820_outline_0066
      005873 FF               [12] 1977 	mov	r7,a
      005874 63 07 01         [24] 1978 	xrl	ar7,#0x01
      005877 90 06 C5         [24] 1979 	mov	dptr,#_rgb_matrix_config
      00587A EF               [12] 1980 	mov	a,r7
      00587B 54 03            [12] 1981 	anl	a,#0x03
      00587D F5 F0            [12] 1982 	mov	b,a
      00587F E0               [24] 1983 	movx	a,@dptr
      005880 54 FC            [12] 1984 	anl	a,#0xfc
      005882 45 F0            [12] 1985 	orl	a,b
      005884 F0               [24] 1986 	movx	@dptr,a
                                   1987 ;	assignBit
      005885 C2 11            [12] 1988 	clr	_rendering
      005887 02 52 A2         [24] 1989 	ljmp	_clear_reactive
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function rgb_matrix_enable_noeeprom
                                   1996 ;	-----------------------------------------
      00588A                       1997 _rgb_matrix_enable_noeeprom:
      00588A 12 5A 39         [24] 1998 	lcall	_ak820_outline_0066
      00588D 70 03            [24] 1999 	jnz	00102$
      00588F 12 52 A2         [24] 2000 	lcall	_clear_reactive
      005892                       2001 00102$:
      005892 12 5A 69         [24] 2002 	lcall	_ak820_outline_0111
      005895 44 01            [12] 2003 	orl	a,#0x01
      005897 F0               [24] 2004 	movx	@dptr,a
                                   2005 ;	assignBit
      005898 C2 11            [12] 2006 	clr	_rendering
      00589A 22               [24] 2007 	ret
                                   2008 ;------------------------------------------------------------
                                   2009 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2010 ;------------------------------------------------------------
                                   2011 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2012 ;	-----------------------------------------
                                   2013 ;	 function rgb_matrix_disable_noeeprom
                                   2014 ;	-----------------------------------------
      00589B                       2015 _rgb_matrix_disable_noeeprom:
      00589B 12 5A 69         [24] 2016 	lcall	_ak820_outline_0111
      00589E F0               [24] 2017 	movx	@dptr,a
                                   2018 ;	assignBit
      00589F C2 11            [12] 2019 	clr	_rendering
      0058A1 02 52 A2         [24] 2020 	ljmp	_clear_reactive
                                   2021 ;------------------------------------------------------------
                                   2022 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2023 ;------------------------------------------------------------
                                   2024 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2025 ;------------------------------------------------------------
                                   2026 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2027 ;	-----------------------------------------
                                   2028 ;	 function rgb_matrix_mode_noeeprom
                                   2029 ;	-----------------------------------------
      0058A4                       2030 _rgb_matrix_mode_noeeprom:
      0058A4 E5 82            [12] 2031 	mov	a,dpl
      0058A6 90 07 49         [24] 2032 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0058A9 F0               [24] 2033 	movx	@dptr,a
                                   2034 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      0058AA E0               [24] 2035 	movx	a,@dptr
      0058AB FF               [12] 2036 	mov	r7,a
      0058AC 60 05            [24] 2037 	jz	00101$
      0058AE BF 07 00         [24] 2038 	cjne	r7,#0x07,00123$
      0058B1                       2039 00123$:
      0058B1 40 01            [24] 2040 	jc	00102$
      0058B3                       2041 00101$:
      0058B3 22               [24] 2042 	ret
      0058B4                       2043 00102$:
                                   2044 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      0058B4 12 5A 1A         [24] 2045 	lcall	_ak820_outline_0018
      0058B7 FE               [12] 2046 	mov	r6,a
      0058B8 EF               [12] 2047 	mov	a,r7
      0058B9 B5 06 02         [24] 2048 	cjne	a,ar6,00125$
      0058BC 80 03            [24] 2049 	sjmp	00105$
      0058BE                       2050 00125$:
      0058BE 12 52 A2         [24] 2051 	lcall	_clear_reactive
      0058C1                       2052 00105$:
                                   2053 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      0058C1 90 07 49         [24] 2054 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0058C4 E0               [24] 2055 	movx	a,@dptr
      0058C5 90 06 C5         [24] 2056 	mov	dptr,#_rgb_matrix_config
      0058C8 25 E0            [12] 2057 	add	a,acc
      0058CA 25 E0            [12] 2058 	add	a,acc
      0058CC 54 FC            [12] 2059 	anl	a,#0xfc
      0058CE F5 F0            [12] 2060 	mov	b,a
      0058D0 E0               [24] 2061 	movx	a,@dptr
      0058D1 54 03            [12] 2062 	anl	a,#0x03
      0058D3 45 F0            [12] 2063 	orl	a,b
      0058D5 F0               [24] 2064 	movx	@dptr,a
                                   2065 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2066 ;	assignBit
      0058D6 C2 11            [12] 2067 	clr	_rendering
                                   2068 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      0058D8 22               [24] 2069 	ret
                                   2070 ;------------------------------------------------------------
                                   2071 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2072 ;------------------------------------------------------------
                                   2073 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2074 ;	-----------------------------------------
                                   2075 ;	 function rgb_matrix_step_noeeprom
                                   2076 ;	-----------------------------------------
      0058D9                       2077 _rgb_matrix_step_noeeprom:
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      0058D9 12 5A 1A         [24] 2079 	lcall	_ak820_outline_0018
      0058DC FF               [12] 2080 	mov	r7,a
      0058DD 0F               [12] 2081 	inc	r7
      0058DE BF 07 00         [24] 2082 	cjne	r7,#0x07,00112$
      0058E1                       2083 00112$:
      0058E1 40 04            [24] 2084 	jc	00103$
      0058E3 7F 01            [12] 2085 	mov	r7,#0x01
      0058E5 80 07            [24] 2086 	sjmp	00104$
      0058E7                       2087 00103$:
      0058E7 12 5A 1A         [24] 2088 	lcall	_ak820_outline_0018
      0058EA FE               [12] 2089 	mov	r6,a
      0058EB 0E               [12] 2090 	inc	r6
      0058EC 8E 07            [24] 2091 	mov	ar7,r6
      0058EE                       2092 00104$:
      0058EE 8F 82            [24] 2093 	mov	dpl, r7
                                   2094 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      0058F0 02 58 A4         [24] 2095 	ljmp	_rgb_matrix_mode_noeeprom
                                   2096 ;------------------------------------------------------------
                                   2097 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2098 ;------------------------------------------------------------
                                   2099 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2100 ;	-----------------------------------------
                                   2101 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2102 ;	-----------------------------------------
      0058F3                       2103 _rgb_matrix_step_reverse_noeeprom:
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      0058F3 12 5A 1A         [24] 2105 	lcall	_ak820_outline_0018
      0058F6 24 FE            [12] 2106 	add	a,#0xff - 0x01
      0058F8 40 04            [24] 2107 	jc	00103$
                                   2108 ;	free result
      0058FA 7F 06            [12] 2109 	mov	r7,#0x06
      0058FC 80 05            [24] 2110 	sjmp	00104$
      0058FE                       2111 00103$:
      0058FE 12 5A 1A         [24] 2112 	lcall	_ak820_outline_0018
      005901 14               [12] 2113 	dec	a
      005902 FF               [12] 2114 	mov	r7,a
      005903                       2115 00104$:
      005903 8F 82            [24] 2116 	mov	dpl, r7
                                   2117 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005905 02 58 A4         [24] 2118 	ljmp	_rgb_matrix_mode_noeeprom
                                   2119 ;------------------------------------------------------------
                                   2120 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2121 ;------------------------------------------------------------
                                   2122 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2123 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2124 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2125 ;------------------------------------------------------------
                                   2126 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2127 ;	-----------------------------------------
                                   2128 ;	 function rgb_matrix_sethsv_noeeprom
                                   2129 ;	-----------------------------------------
      005908                       2130 _rgb_matrix_sethsv_noeeprom:
      005908 12 38 44         [24] 2131 	lcall	_ak820_outline_0103
      00590B 90 07 4C         [24] 2132 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      00590E 12 38 49         [24] 2133 	lcall	_ak820_outline_0104
                                   2134 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005911 90 07 4C         [24] 2135 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005914 E0               [24] 2136 	movx	a,@dptr
      005915 90 06 C6         [24] 2137 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005918 F0               [24] 2138 	movx	@dptr,a
                                   2139 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005919 90 07 4A         [24] 2140 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00591C E0               [24] 2141 	movx	a,@dptr
      00591D FF               [12] 2142 	mov	r7,a
      00591E 90 06 C7         [24] 2143 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005921 F0               [24] 2144 	movx	@dptr,a
                                   2145 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005922 90 07 4B         [24] 2146 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005925 E0               [24] 2147 	movx	a,@dptr
      005926 FF               [12] 2148 	mov  r7,a
      005927 24 5F            [12] 2149 	add	a,#0xff - 0xa0
      005929 50 04            [24] 2150 	jnc	00103$
                                   2151 ;	free result
      00592B 7E A0            [12] 2152 	mov	r6,#0xa0
      00592D 80 02            [24] 2153 	sjmp	00104$
      00592F                       2154 00103$:
      00592F 8F 06            [24] 2155 	mov	ar6,r7
      005931                       2156 00104$:
      005931 90 06 C8         [24] 2157 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005934 EE               [12] 2158 	mov	a,r6
      005935 F0               [24] 2159 	movx	@dptr,a
                                   2160 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005936 22               [24] 2161 	ret
                                   2162 ;------------------------------------------------------------
                                   2163 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2164 ;------------------------------------------------------------
                                   2165 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2166 ;------------------------------------------------------------
                                   2167 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2168 ;	-----------------------------------------
                                   2169 ;	 function rgb_matrix_set_speed_noeeprom
                                   2170 ;	-----------------------------------------
      005937                       2171 _rgb_matrix_set_speed_noeeprom:
      005937 E5 82            [12] 2172 	mov	a,dpl
      005939 90 07 4E         [24] 2173 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      00593C F0               [24] 2174 	movx	@dptr,a
      00593D E0               [24] 2175 	movx	a,@dptr
      00593E 90 06 C9         [24] 2176 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005941 F0               [24] 2177 	movx	@dptr,a
      005942 22               [24] 2178 	ret
                                   2179 ;------------------------------------------------------------
                                   2180 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2181 ;------------------------------------------------------------
                                   2182 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2183 ;------------------------------------------------------------
                                   2184 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2185 ;	-----------------------------------------
                                   2186 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2187 ;	-----------------------------------------
      005943                       2188 _rgb_matrix_increase_hue_noeeprom:
      005943 90 06 C6         [24] 2189 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005946 E0               [24] 2190 	movx	a,@dptr
      005947 24 08            [12] 2191 	add	a,#0x08
      005949 90 06 C6         [24] 2192 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00594C F0               [24] 2193 	movx	@dptr,a
      00594D 22               [24] 2194 	ret
                                   2195 ;------------------------------------------------------------
                                   2196 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2197 ;------------------------------------------------------------
                                   2198 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2199 ;	-----------------------------------------
                                   2200 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2201 ;	-----------------------------------------
      00594E                       2202 _rgb_matrix_decrease_hue_noeeprom:
      00594E 90 06 C6         [24] 2203 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005951 E0               [24] 2204 	movx	a,@dptr
      005952 24 F8            [12] 2205 	add	a,#0xf8
      005954 90 06 C6         [24] 2206 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005957 F0               [24] 2207 	movx	@dptr,a
      005958 22               [24] 2208 	ret
                                   2209 ;------------------------------------------------------------
                                   2210 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2211 ;------------------------------------------------------------
                                   2212 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2213 ;	-----------------------------------------
                                   2214 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2215 ;	-----------------------------------------
      005959                       2216 _rgb_matrix_increase_sat_noeeprom:
      005959 90 06 C7         [24] 2217 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00595C 12 5A 23         [24] 2218 	lcall	_ak820_outline_0047
      00595F 12 53 3D         [24] 2219 	lcall	_add_sat
      005962 AF 82            [24] 2220 	mov	r7, dpl
      005964 90 06 C7         [24] 2221 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005967 EF               [12] 2222 	mov	a,r7
      005968 F0               [24] 2223 	movx	@dptr,a
      005969 22               [24] 2224 	ret
                                   2225 ;------------------------------------------------------------
                                   2226 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2227 ;------------------------------------------------------------
                                   2228 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2229 ;	-----------------------------------------
                                   2230 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2231 ;	-----------------------------------------
      00596A                       2232 _rgb_matrix_decrease_sat_noeeprom:
      00596A 90 06 C7         [24] 2233 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00596D 12 5A 2E         [24] 2234 	lcall	_ak820_outline_0048
      005970 12 53 62         [24] 2235 	lcall	_sub_sat
      005973 AF 82            [24] 2236 	mov	r7, dpl
      005975 90 06 C7         [24] 2237 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005978 EF               [12] 2238 	mov	a,r7
      005979 F0               [24] 2239 	movx	@dptr,a
      00597A 22               [24] 2240 	ret
                                   2241 ;------------------------------------------------------------
                                   2242 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2243 ;------------------------------------------------------------
                                   2244 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2245 ;------------------------------------------------------------
                                   2246 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2247 ;	-----------------------------------------
                                   2248 ;	 function rgb_matrix_increase_val_noeeprom
                                   2249 ;	-----------------------------------------
      00597B                       2250 _rgb_matrix_increase_val_noeeprom:
                                   2251 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      00597B 90 06 C8         [24] 2252 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00597E 12 5A 23         [24] 2253 	lcall	_ak820_outline_0047
      005981 12 53 3D         [24] 2254 	lcall	_add_sat
                                   2255 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005984 E5 82            [12] 2256 	mov	a,dpl
      005986 FF               [12] 2257 	mov	r7,a
      005987 24 5F            [12] 2258 	add	a,#0xff - 0xa0
      005989 50 04            [24] 2259 	jnc	00103$
                                   2260 ;	free result
      00598B 7E A0            [12] 2261 	mov	r6,#0xa0
      00598D 80 02            [24] 2262 	sjmp	00104$
      00598F                       2263 00103$:
      00598F 8F 06            [24] 2264 	mov	ar6,r7
      005991                       2265 00104$:
      005991 90 06 C8         [24] 2266 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005994 EE               [12] 2267 	mov	a,r6
      005995 F0               [24] 2268 	movx	@dptr,a
                                   2269 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005996 22               [24] 2270 	ret
                                   2271 ;------------------------------------------------------------
                                   2272 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2273 ;------------------------------------------------------------
                                   2274 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2275 ;	-----------------------------------------
                                   2276 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2277 ;	-----------------------------------------
      005997                       2278 _rgb_matrix_decrease_val_noeeprom:
      005997 90 06 C8         [24] 2279 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00599A 12 5A 2E         [24] 2280 	lcall	_ak820_outline_0048
      00599D 12 53 62         [24] 2281 	lcall	_sub_sat
      0059A0 AF 82            [24] 2282 	mov	r7, dpl
      0059A2 90 06 C8         [24] 2283 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0059A5 EF               [12] 2284 	mov	a,r7
      0059A6 F0               [24] 2285 	movx	@dptr,a
      0059A7 22               [24] 2286 	ret
                                   2287 ;------------------------------------------------------------
                                   2288 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2289 ;------------------------------------------------------------
                                   2290 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2291 ;	-----------------------------------------
                                   2292 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2293 ;	-----------------------------------------
      0059A8                       2294 _rgb_matrix_increase_speed_noeeprom:
      0059A8 90 06 C9         [24] 2295 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059AB 12 5A 23         [24] 2296 	lcall	_ak820_outline_0047
      0059AE 12 53 3D         [24] 2297 	lcall	_add_sat
      0059B1 AF 82            [24] 2298 	mov	r7, dpl
      0059B3 90 06 C9         [24] 2299 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059B6 EF               [12] 2300 	mov	a,r7
      0059B7 F0               [24] 2301 	movx	@dptr,a
      0059B8 22               [24] 2302 	ret
                                   2303 ;------------------------------------------------------------
                                   2304 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2305 ;------------------------------------------------------------
                                   2306 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2307 ;	-----------------------------------------
                                   2308 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2309 ;	-----------------------------------------
      0059B9                       2310 _rgb_matrix_decrease_speed_noeeprom:
      0059B9 90 06 C9         [24] 2311 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059BC 12 5A 2E         [24] 2312 	lcall	_ak820_outline_0048
      0059BF 12 53 62         [24] 2313 	lcall	_sub_sat
      0059C2 AF 82            [24] 2314 	mov	r7, dpl
      0059C4 90 06 C9         [24] 2315 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059C7 EF               [12] 2316 	mov	a,r7
      0059C8 F0               [24] 2317 	movx	@dptr,a
      0059C9 22               [24] 2318 	ret
                                   2319 ;------------------------------------------------------------
                                   2320 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2321 ;------------------------------------------------------------
                                   2322 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2323 ;	-----------------------------------------
                                   2324 ;	 function rgb_matrix_toggle
                                   2325 ;	-----------------------------------------
      0059CA                       2326 _rgb_matrix_toggle:
      0059CA 12 58 70         [24] 2327 	lcall	_rgb_matrix_toggle_noeeprom
      0059CD 02 53 7F         [24] 2328 	ljmp	_mark_dirty
                                   2329 ;------------------------------------------------------------
                                   2330 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2331 ;------------------------------------------------------------
                                   2332 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2333 ;	-----------------------------------------
                                   2334 ;	 function rgb_matrix_step
                                   2335 ;	-----------------------------------------
      0059D0                       2336 _rgb_matrix_step:
      0059D0 12 58 D9         [24] 2337 	lcall	_rgb_matrix_step_noeeprom
      0059D3 02 53 7F         [24] 2338 	ljmp	_mark_dirty
                                   2339 ;------------------------------------------------------------
                                   2340 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2341 ;------------------------------------------------------------
                                   2342 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2343 ;	-----------------------------------------
                                   2344 ;	 function rgb_matrix_step_reverse
                                   2345 ;	-----------------------------------------
      0059D6                       2346 _rgb_matrix_step_reverse:
      0059D6 12 58 F3         [24] 2347 	lcall	_rgb_matrix_step_reverse_noeeprom
      0059D9 02 53 7F         [24] 2348 	ljmp	_mark_dirty
                                   2349 ;------------------------------------------------------------
                                   2350 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2351 ;------------------------------------------------------------
                                   2352 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2353 ;	-----------------------------------------
                                   2354 ;	 function rgb_matrix_increase_hue
                                   2355 ;	-----------------------------------------
      0059DC                       2356 _rgb_matrix_increase_hue:
      0059DC 12 59 43         [24] 2357 	lcall	_rgb_matrix_increase_hue_noeeprom
      0059DF 02 53 7F         [24] 2358 	ljmp	_mark_dirty
                                   2359 ;------------------------------------------------------------
                                   2360 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2361 ;------------------------------------------------------------
                                   2362 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2363 ;	-----------------------------------------
                                   2364 ;	 function rgb_matrix_decrease_hue
                                   2365 ;	-----------------------------------------
      0059E2                       2366 _rgb_matrix_decrease_hue:
      0059E2 12 59 4E         [24] 2367 	lcall	_rgb_matrix_decrease_hue_noeeprom
      0059E5 02 53 7F         [24] 2368 	ljmp	_mark_dirty
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_increase_sat
                                   2375 ;	-----------------------------------------
      0059E8                       2376 _rgb_matrix_increase_sat:
      0059E8 12 59 59         [24] 2377 	lcall	_rgb_matrix_increase_sat_noeeprom
      0059EB 02 53 7F         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_decrease_sat
                                   2385 ;	-----------------------------------------
      0059EE                       2386 _rgb_matrix_decrease_sat:
      0059EE 12 59 6A         [24] 2387 	lcall	_rgb_matrix_decrease_sat_noeeprom
      0059F1 02 53 7F         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_increase_val
                                   2395 ;	-----------------------------------------
      0059F4                       2396 _rgb_matrix_increase_val:
      0059F4 12 59 7B         [24] 2397 	lcall	_rgb_matrix_increase_val_noeeprom
      0059F7 02 53 7F         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_decrease_val
                                   2405 ;	-----------------------------------------
      0059FA                       2406 _rgb_matrix_decrease_val:
      0059FA 12 59 97         [24] 2407 	lcall	_rgb_matrix_decrease_val_noeeprom
      0059FD 02 53 7F         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_increase_speed
                                   2415 ;	-----------------------------------------
      005A00                       2416 _rgb_matrix_increase_speed:
      005A00 12 59 A8         [24] 2417 	lcall	_rgb_matrix_increase_speed_noeeprom
      005A03 02 53 7F         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_decrease_speed
                                   2425 ;	-----------------------------------------
      005A06                       2426 _rgb_matrix_decrease_speed:
      005A06 12 59 B9         [24] 2427 	lcall	_rgb_matrix_decrease_speed_noeeprom
      005A09 02 53 7F         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2431 ;------------------------------------------------------------
                                   2432 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2433 ;------------------------------------------------------------
                                   2434 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2435 ;	-----------------------------------------
                                   2436 ;	 function rgb_matrix_mode
                                   2437 ;	-----------------------------------------
      005A0C                       2438 _rgb_matrix_mode:
      005A0C E5 82            [12] 2439 	mov	a,dpl
      005A0E 90 07 4F         [24] 2440 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005A11 12 5A 7C         [24] 2441 	lcall	_ak820_outline_0168
      005A14 12 58 A4         [24] 2442 	lcall	_rgb_matrix_mode_noeeprom
      005A17 02 53 7F         [24] 2443 	ljmp	_mark_dirty
                                   2444 ;------------------------------------------------------------
                                   2445 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2446 ;------------------------------------------------------------
                                   2447 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2448 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2449 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2450 ;------------------------------------------------------------
                                   2451 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2452 ;	-----------------------------------------
                                   2453 	.area CSEG    (CODE)
                                   2454 	.area CONST   (CODE)
                                   2455 	.area CONST   (CODE)
      00BC3C                       2456 _sine8_coefficients_10000_290:
      00BC3C 00                    2457 	.db #0x00	; 0
      00BC3D 31                    2458 	.db #0x31	; 49	'1'
      00BC3E 31                    2459 	.db #0x31	; 49	'1'
      00BC3F 29                    2460 	.db #0x29	; 41
      00BC40 5A                    2461 	.db #0x5a	; 90	'Z'
      00BC41 1B                    2462 	.db #0x1b	; 27
      00BC42 75                    2463 	.db #0x75	; 117	'u'
      00BC43 0A                    2464 	.db #0x0a	; 10
                                   2465 	.area CSEG    (CODE)
                                   2466 	.area XINIT   (CODE)
                                   2467 	.area CABS    (ABS,CODE)
                                   2468 
                                   2469 ; Experimental exact instruction outlining.
                                   2470 	.globl _ak820_outline_0004
                                   2471 	.globl _ak820_outline_0018
                                   2472 	.globl _ak820_outline_0047
                                   2473 	.globl _ak820_outline_0048
                                   2474 	.globl _ak820_outline_0051
                                   2475 	.globl _ak820_outline_0059
                                   2476 	.globl _ak820_outline_0060
                                   2477 	.globl _ak820_outline_0066
                                   2478 	.globl _ak820_outline_0070
                                   2479 	.globl _ak820_outline_0072
                                   2480 	.globl _ak820_outline_0083
                                   2481 	.globl _ak820_outline_0103
                                   2482 	.globl _ak820_outline_0104
                                   2483 	.globl _ak820_outline_0105
                                   2484 	.globl _ak820_outline_0111
                                   2485 	.globl _ak820_outline_0117
                                   2486 	.globl _ak820_outline_0120
                                   2487 	.globl _ak820_outline_0123
                                   2488 	.globl _ak820_outline_0131
                                   2489 	.globl _ak820_outline_0132
                                   2490 	.globl _ak820_outline_0135
                                   2491 	.globl _ak820_outline_0137
                                   2492 	.globl _ak820_outline_0164
                                   2493 	.globl _ak820_outline_0167
                                   2494 	.globl _ak820_outline_0168
                                   2495 	.globl _ak820_outline_0170
                                   2496 	.globl _ak820_outline_0176
                                   2497 	.globl _ak820_outline_0182
                                   2498 	.globl _ak820_outline_0183
                                   2499 	.globl _ak820_outline_0187
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0018
      005A1A                       2503 _ak820_outline_0018:
      005A1A 90 06 C5         [24] 2504 	mov	dptr,#_rgb_matrix_config
      005A1D E0               [24] 2505 	movx	a,@dptr
      005A1E 03               [12] 2506 	rr	a
      005A1F 03               [12] 2507 	rr	a
      005A20 54 3F            [12] 2508 	anl	a,#0x3f
      005A22 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0047
      005A23                       2513 _ak820_outline_0047:
      005A23 E0               [24] 2514 	movx	a,@dptr
      005A24 FF               [12] 2515 	mov	r7,a
      005A25 90 07 2E         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      005A28 74 10            [12] 2517 	mov	a,#0x10
      005A2A F0               [24] 2518 	movx	@dptr,a
      005A2B 8F 82            [24] 2519 	mov	dpl,r7
      005A2D 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0048
      005A2E                       2524 _ak820_outline_0048:
      005A2E E0               [24] 2525 	movx	a,@dptr
      005A2F FF               [12] 2526 	mov	r7,a
      005A30 90 07 30         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005A33 74 10            [12] 2528 	mov	a,#0x10
      005A35 F0               [24] 2529 	movx	@dptr,a
      005A36 8F 82            [24] 2530 	mov	dpl,r7
      005A38 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0066
      005A39                       2535 _ak820_outline_0066:
      005A39 90 06 C5         [24] 2536 	mov	dptr,#_rgb_matrix_config
      005A3C E0               [24] 2537 	movx	a,@dptr
      005A3D 54 03            [12] 2538 	anl	a,#0x03
      005A3F 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0070
      005A40                       2543 _ak820_outline_0070:
      005A40 74 08            [12] 2544 	mov	a,#0x08
      005A42 F0               [24] 2545 	movx	@dptr,a
      005A43 E4               [12] 2546 	clr	a
      005A44 A3               [24] 2547 	inc	dptr
      005A45 F0               [24] 2548 	movx	@dptr,a
      005A46 90 06 C5         [24] 2549 	mov	dptr,#_rgb_matrix_config
      005A49 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0072
      005A4A                       2554 _ak820_outline_0072:
      005A4A A3               [24] 2555 	inc	dptr
      005A4B F0               [24] 2556 	movx	@dptr,a
      005A4C E4               [12] 2557 	clr	a
      005A4D A3               [24] 2558 	inc	dptr
      005A4E F0               [24] 2559 	movx	@dptr,a
      005A4F 90 0D 9A         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      005A52 74 03            [12] 2561 	mov	a,#0x03
      005A54 F0               [24] 2562 	movx	@dptr,a
      005A55 E4               [12] 2563 	clr	a
      005A56 A3               [24] 2564 	inc	dptr
      005A57 F0               [24] 2565 	movx	@dptr,a
      005A58 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0083
      005A59                       2570 _ak820_outline_0083:
      005A59 74 18            [12] 2571 	mov	a,#0x18
      005A5B F0               [24] 2572 	movx	@dptr,a
      005A5C E4               [12] 2573 	clr	a
      005A5D A3               [24] 2574 	inc	dptr
      005A5E F0               [24] 2575 	movx	@dptr,a
      005A5F A3               [24] 2576 	inc	dptr
      005A60 F0               [24] 2577 	movx	@dptr,a
      005A61 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0105
      005A62                       2582 _ak820_outline_0105:
      005A62 35 F0            [12] 2583 	addc	a,b
      005A64 F5 83            [12] 2584 	mov	dph,a
      005A66 E4               [12] 2585 	clr	a
      005A67 93               [24] 2586 	movc	a,@a+dptr
      005A68 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0111
      005A69                       2591 _ak820_outline_0111:
      005A69 90 06 C5         [24] 2592 	mov	dptr,#_rgb_matrix_config
      005A6C E0               [24] 2593 	movx	a,@dptr
      005A6D 54 FC            [12] 2594 	anl	a,#0xfc
      005A6F 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0137
      005A70                       2599 _ak820_outline_0137:
      005A70 90 06 D4         [24] 2600 	mov	dptr,#_frame_mode
      005A73 E0               [24] 2601 	movx	a,@dptr
      005A74 FE               [12] 2602 	mov	r6,a
      005A75 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0164
      005A76                       2607 _ak820_outline_0164:
      005A76 F0               [24] 2608 	movx	@dptr,a
      005A77 E5 F0            [12] 2609 	mov	a,b
      005A79 A3               [24] 2610 	inc	dptr
      005A7A F0               [24] 2611 	movx	@dptr,a
      005A7B 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0168
      005A7C                       2616 _ak820_outline_0168:
      005A7C F0               [24] 2617 	movx	@dptr,a
      005A7D E0               [24] 2618 	movx	a,@dptr
      005A7E F5 82            [12] 2619 	mov	dpl,a
      005A80 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0170
      005A81                       2624 _ak820_outline_0170:
      005A81 90 06 C9         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005A84 E0               [24] 2626 	movx	a,@dptr
      005A85 23               [12] 2627 	rl	a
      005A86 23               [12] 2628 	rl	a
      005A87 54 03            [12] 2629 	anl	a,#0x03
      005A89 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0176
      005A8A                       2634 _ak820_outline_0176:
      005A8A 90 0D 9F         [24] 2635 	mov	dptr,#_memset_PARM_2
      005A8D E4               [12] 2636 	clr	a
      005A8E F0               [24] 2637 	movx	@dptr,a
      005A8F 90 0D A0         [24] 2638 	mov	dptr,#_memset_PARM_3
      005A92 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0182
      005A93                       2643 _ak820_outline_0182:
      005A93 90 06 D3         [24] 2644 	mov	dptr,#_led_index
      005A96 E0               [24] 2645 	movx	a,@dptr
      005A97 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0183
      005A98                       2650 _ak820_outline_0183:
      005A98 C4               [12] 2651 	swap	a
      005A99 23               [12] 2652 	rl	a
      005A9A 54 1F            [12] 2653 	anl	a,#0x1f
      005A9C 22               [24] 2654 	ret
