;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_nvm
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _eeprom_driver_erase
	.globl _eeprom_write_block
	.globl _eeprom_read_block
	.globl _eeprom_read_byte
	.globl _eeprom_driver_init
	.globl _ak820_macro_init
	.globl _ak820_flash_program_page
	.globl _ak820_flash_program
	.globl _ak820_flash_erase
	.globl _ak820_flash_read
	.globl _ak820_eeprom_update_block_xdata_PARM_3
	.globl _ak820_eeprom_update_block_xdata_PARM_2
	.globl _ak820_eeprom_write_block_xdata_PARM_3
	.globl _ak820_eeprom_write_block_xdata_PARM_2
	.globl _ak820_eeprom_read_block_xdata_PARM_3
	.globl _ak820_eeprom_read_block_xdata_PARM_2
	.globl _eeprom_write_block_PARM_3
	.globl _eeprom_write_block_PARM_2
	.globl _eeprom_read_block_PARM_3
	.globl _eeprom_read_block_PARM_2
	.globl _ak820_nvm_diagnostic
	.globl _ak820_nvm_ok
	.globl _ak820_nvm_schema_fault
	.globl _ak820_nvm_flush
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_end
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_eeprom_write_block_xdata
	.globl _ak820_eeprom_update_block_xdata
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; overlayable bit register bank
;--------------------------------------------------------
	.area BIT_BANK	(REL,OVR,DATA)
bits:
	.ds 1
	b0 = bits[0]
	b1 = bits[1]
	b2 = bits[2]
	b3 = bits[3]
	b4 = bits[4]
	b5 = bits[5]
	b6 = bits[6]
	b7 = bits[7]
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_load_page_sloc1_1_0:
	.ds 2
_eeprom_write_block_sloc0_1_0:
	.ds 2
_ak820_eeprom_write_block_xdata_sloc0_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc0_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc1_1_0:
	.ds 2
_ak820_eeprom_update_block_xdata_sloc2_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_nvm_ok_sloc0_1_0:
	.ds 1
_load_page_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_page_data:
	.ds 64
_cached_page:
	.ds 2
_page_valid:
	.ds 1
_page_dirty:
	.ds 1
_storage_failed:
	.ds 1
_batch_depth:
	.ds 1
_first_failure_stage:
	.ds 1
_nvm_fail_stage_10000_20:
	.ds 1
_ak820_nvm_diagnostic_out_10000_23:
	.ds 2
_crc_byte_PARM_2:
	.ds 1
_crc_byte_crc_10000_25:
	.ds 2
_page_crc_crc_10000_30:
	.ds 2
_write_page_address_10000_32:
	.ds 2
_journal_header_valid_header_10000_39:
	.ds 2
_recover_journal_header_10000_46:
	.ds 9
_ak820_nvm_flush_header_10000_62:
	.ds 9
_ak820_nvm_flush_stage_10000_62:
	.ds 1
_load_page_page_10000_87:
	.ds 2
_read_offset_offset_10000_93:
	.ds 2
_eeprom_read_byte_addr_10000_97:
	.ds 3
_eeprom_read_block_PARM_2:
	.ds 3
_eeprom_read_block_PARM_3:
	.ds 2
_eeprom_read_block_buf_10000_99:
	.ds 3
_eeprom_read_block_out_10000_100:
	.ds 3
_eeprom_write_block_PARM_2:
	.ds 3
_eeprom_write_block_PARM_3:
	.ds 2
_eeprom_write_block_buf_10000_104:
	.ds 3
_ak820_eeprom_read_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_read_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_read_block_xdata_buf_10000_113:
	.ds 2
_ak820_eeprom_read_block_xdata_out_10000_114:
	.ds 2
_ak820_eeprom_write_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_write_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_write_block_xdata_buf_10000_118:
	.ds 2
_ak820_eeprom_update_block_xdata_PARM_2:
	.ds 3
_ak820_eeprom_update_block_xdata_PARM_3:
	.ds 2
_ak820_eeprom_update_block_xdata_buf_10000_127:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'nvm_fail'
;------------------------------------------------------------
;stage         Allocated with name '_nvm_fail_stage_10000_20'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:22: static void nvm_fail(uint8_t stage) {
;	-----------------------------------------
;	 function nvm_fail
;	-----------------------------------------
_nvm_fail:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_nvm_fail_stage_10000_20
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:23: if (!storage_failed) first_failure_stage = stage;
	mov	dptr,#_storage_failed
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#_nvm_fail_stage_10000_20
	movx	a,@dptr
	mov	dptr,#_first_failure_stage
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:24: storage_failed = true;
	mov	dptr,#_storage_failed
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:25: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_diagnostic'
;------------------------------------------------------------
;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:27: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
;	-----------------------------------------
;	 function ak820_nvm_diagnostic
;	-----------------------------------------
_ak820_nvm_diagnostic:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:28: out[0] = storage_failed;
	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_storage_failed
	movx	a,@dptr
	mov	dpl,r6
	mov	dph,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:29: out[1] = page_valid;
	mov	a,#0x01
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dptr,#_page_valid
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:30: out[2] = page_dirty;
	mov	a,#0x02
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dptr,#_page_dirty
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:31: out[3] = batch_depth;
	mov	a,#0x03
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dptr,#_batch_depth
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:32: out[4] = (uint8_t)cached_page;
	mov	a,#0x04
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:33: out[5] = (uint8_t)(cached_page >> 8);
	mov	a,#0x05
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dptr,#_cached_page
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:34: out[6] = first_failure_stage;
	mov	a,#0x06
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dptr,#_first_failure_stage
	movx	a,@dptr
	mov	dpl,r6
	mov	dph,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:35: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'crc_byte'
;------------------------------------------------------------
;value         Allocated with name '_crc_byte_PARM_2'
;crc           Allocated with name '_crc_byte_crc_10000_25'
;bit           Allocated with name '_crc_byte_bit_10000_26'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:37: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
;	-----------------------------------------
;	 function crc_byte
;	-----------------------------------------
_crc_byte:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_crc_byte_crc_10000_25
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:39: crc ^= (uint16_t)value << 8;
	mov	dptr,#_crc_byte_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	dptr,#_crc_byte_crc_10000_25
	movx	a,@dptr
	xrl	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	xrl	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:40: for (bit = 0; bit != 8; ++bit) {
	mov	r7,#0x00
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:41: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
	mov	dptr,#_crc_byte_crc_10000_25
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	jnb	acc.7,00106$
	mov	a,r5
	add	a,r5
	mov	r3,a
	mov	a,r6
	rlc	a
	mov	r4,a
	xrl	ar3,#0x21
	xrl	ar4,#0x10
	sjmp	00107$
00106$:
	mov	a,r5
	add	a,r5
	mov	r3,a
	mov	a,r6
	rlc	a
	mov	r4,a
00107$:
	mov	dptr,#_crc_byte_crc_10000_25
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:40: for (bit = 0; bit != 8; ++bit) {
	inc	r7
	cjne	r7,#0x08,00102$
;	keyboards/ajazz/ak820/ak820_nvm.c:43: return crc;
	mov	dpl, r3
	mov	dph, r4
;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'page_crc'
;------------------------------------------------------------
;crc           Allocated with name '_page_crc_crc_10000_30'
;i             Allocated with name '_page_crc_i_10000_30'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t page_crc(void) {
;	-----------------------------------------
;	 function page_crc
;	-----------------------------------------
_page_crc:
;	keyboards/ajazz/ak820/ak820_nvm.c:47: uint16_t crc = 0xFFFFu;
	mov	dptr,#_page_crc_crc_10000_30
	mov	a,#0xff
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
	mov	r7,#0x00
00102$:
	mov	dptr,#_page_crc_crc_10000_30
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	add	a, #_page_data
	mov	dpl,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	dptr,#_crc_byte_PARM_2
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	push	ar7
	lcall	_crc_byte
	mov	r5, dpl
	mov	r6, dph
	pop	ar7
	mov	dptr,#_page_crc_crc_10000_30
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x40,00102$
;	keyboards/ajazz/ak820/ak820_nvm.c:50: return crc;
	mov	dpl, r5
	mov	dph, r6
;	keyboards/ajazz/ak820/ak820_nvm.c:51: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'write_page'
;------------------------------------------------------------
;address       Allocated with name '_write_page_address_10000_32'
;i             Allocated with name '_write_page_i_10000_33'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:53: static bool write_page(uint16_t address) {
;	-----------------------------------------
;	 function write_page
;	-----------------------------------------
_write_page:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_write_page_address_10000_32
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:55: if (!ak820_flash_erase(address)) return false;
	mov	dptr,#_write_page_address_10000_32
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	lcall	_ak820_flash_erase
	mov	a, dpl
	pop	ar6
	pop	ar7
	jnz	00102$
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:56: if (!ak820_flash_program_page(address, page_data)) return false;
	mov	dptr,#_ak820_flash_program_page_PARM_2
	mov	a,#_page_data
	movx	@dptr,a
	mov	a,#(_page_data >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_ak820_flash_program_page
	mov	a, dpl
	jnz	00120$
	mov	dpl,a
;	keyboards/ajazz/ak820/ak820_nvm.c:57: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00120$:
	mov	r7,#0x00
00108$:
;	keyboards/ajazz/ak820/ak820_nvm.c:58: if (ak820_flash_read(address + i) != page_data[i]) return false;
	mov	ar5,r7
	mov	r6,#0x00
	mov	dptr,#_write_page_address_10000_32
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	add	a, r3
	mov	r3,a
	mov	a,r6
	addc	a, r4
	mov	r4,a
	mov	dpl, r3
	mov	dph, r4
	lcall	_ak820_flash_read
	mov	r6, dpl
	mov	a,r7
	add	a, #_page_data
	mov	dpl,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	cjne	a,ar5,00149$
	sjmp	00109$
00149$:
	mov	dpl, #0x00
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_nvm.c:57: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00108$
;	keyboards/ajazz/ak820/ak820_nvm.c:60: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:61: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'journal_header_valid'
;------------------------------------------------------------
;header        Allocated with name '_journal_header_valid_header_10000_39'
;i             Allocated with name '_journal_header_valid_i_10000_40'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:63: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
;	-----------------------------------------
;	 function journal_header_valid
;	-----------------------------------------
_journal_header_valid:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_journal_header_valid_header_10000_39
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (header[0] != 0xA5u) return false;
	mov	dptr,#_journal_header_valid_header_10000_39
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0xa5,00138$
	sjmp	00116$
00138$:
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 1; i != 5; ++i) {
	ret
00116$:
	mov	r5,#0x01
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:67: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
	mov	a,r5
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	ar2,r5
	mov	r3,#0x00
	mov	a,#0x04
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	mov	a,r2
	add	a, r6
	mov	dpl,a
	mov	a,r3
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	xrl	ar4,a
	cjne	r4,#0xff,00139$
	sjmp	00107$
00139$:
	mov	dpl, #0x00
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 1; i != 5; ++i) {
	inc	r5
	cjne	r5,#0x05,00106$
;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'recover_journal'
;------------------------------------------------------------
;header        Allocated with name '_recover_journal_header_10000_46'
;i             Allocated with name '_recover_journal_i_10000_46'
;page          Allocated with name '_recover_journal_page_10000_46'
;crc           Allocated with name '_recover_journal_crc_10000_46'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:72: static void recover_journal(void) {
;	-----------------------------------------
;	 function recover_journal
;	-----------------------------------------
_recover_journal:
;	keyboards/ajazz/ak820/ak820_nvm.c:76: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
	mov	r7,#0x00
00115$:
	mov	a,r7
	add	a, #_recover_journal_header_10000_46
	mov	r5,a
	clr	a
	addc	a, #(_recover_journal_header_10000_46 >> 8)
	mov	r6,a
	mov	ar4,r7
	mov	r3,#0x00
	mov	a,#0x40
	add	a, r4
	mov	r4,a
	mov	a,#0xef
	addc	a, r3
	mov	r3,a
	mov	dpl, r4
	mov	dph, r3
	lcall	_ak820_flash_read
	mov	r4, dpl
	mov	dpl,r5
	mov	dph,r6
	mov	a,r4
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x09,00115$
;	keyboards/ajazz/ak820/ak820_nvm.c:79: if (!journal_header_valid(header)) return;
	mov	dptr,#_recover_journal_header_10000_46
	lcall	_journal_header_valid
	mov	a, dpl
	jnz	00103$
	ret
00103$:
;	keyboards/ajazz/ak820/ak820_nvm.c:80: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
	movx	a,@dptr
	mov	r4,a
	clr	a
	orl	ar7,a
	mov	a,r4
	orl	ar6,a
;	keyboards/ajazz/ak820/ak820_nvm.c:81: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
	movx	a,@dptr
	mov	r2,a
	clr	a
	orl	ar5,a
	mov	a,r2
	orl	ar4,a
;	keyboards/ajazz/ak820/ak820_nvm.c:82: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
	clr	c
	mov	a,r7
	subb	a,#0xa0
	mov	a,r6
	subb	a,#0x00
	jc	00134$
;	keyboards/ajazz/ak820/ak820_nvm.c:83: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:84: return;
	ljmp	_nvm_fail
;	keyboards/ajazz/ak820/ak820_nvm.c:86: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
00134$:
	mov	r3,#0x00
00117$:
	push	ar5
	push	ar4
	mov	a,r3
	add	a, #_page_data
	mov	r1,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r2,a
	mov	ar0,r3
	mov	r5,#0x00
	mov	a,#0xef
	add	a, r5
	mov	r5,a
	mov	dpl, r0
	mov	dph, r5
	lcall	_ak820_flash_read
	mov	r5, dpl
	mov	dpl,r1
	mov	dph,r2
	mov	a,r5
	movx	@dptr,a
	inc	r3
	cjne	r3,#0x40,00190$
	sjmp	00191$
00190$:
	pop	ar4
	pop	ar5
	sjmp	00117$
00191$:
	pop	ar4
	pop	ar5
;	keyboards/ajazz/ak820/ak820_nvm.c:87: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_page_crc
	mov	r2, dpl
	mov	r3, dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	a,r2
	cjne	a,ar5,00192$
	mov	a,r3
	cjne	a,ar4,00192$
	sjmp	00113$
00192$:
	mov	dpl, #0x02
	ljmp	_nvm_fail
00113$:
;	keyboards/ajazz/ak820/ak820_nvm.c:88: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
	mov	a,r6
	anl	a,#0x03
	mov	c,acc.0
	xch	a,r7
	rrc	a
	xch	a,r7
	rrc	a
	mov	c,acc.0
	xch	a,r7
	rrc	a
	xch	a,r7
	rrc	a
	xch	a,r7
	add	a,#0xc7
	mov	r6,a
	mov	dpl, r7
	mov	dph, r6
	lcall	_write_page
	mov	a, dpl
	jnz	00110$
	mov	dpl, #0x03
	ljmp	_nvm_fail
00110$:
;	keyboards/ajazz/ak820/ak820_nvm.c:89: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jnz	00119$
	mov	dpl, #0x04
;	keyboards/ajazz/ak820/ak820_nvm.c:90: }
	ljmp	_nvm_fail
00119$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_driver_init'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:92: void eeprom_driver_init(void) {
;	-----------------------------------------
;	 function eeprom_driver_init
;	-----------------------------------------
_eeprom_driver_init:
;	keyboards/ajazz/ak820/ak820_nvm.c:93: storage_failed = false;
	mov	dptr,#_storage_failed
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:94: first_failure_stage = AK820_NVM_FAULT_NONE;
	mov	dptr,#_first_failure_stage
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:95: page_valid = page_dirty = false;
	mov	dptr,#_page_dirty
	movx	@dptr,a
	mov	dptr,#_page_valid
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:96: batch_depth = 0;
	mov	dptr,#_batch_depth
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:97: recover_journal();
	lcall	_recover_journal
;	keyboards/ajazz/ak820/ak820_nvm.c:99: ak820_macro_init();
;	keyboards/ajazz/ak820/ak820_nvm.c:101: }
	ljmp	_ak820_macro_init
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_ok'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:103: bool ak820_nvm_ok(void) { return !storage_failed; }
;	-----------------------------------------
;	 function ak820_nvm_ok
;	-----------------------------------------
_ak820_nvm_ok:
	push	ar7
	mov	dptr,#_storage_failed
	movx	a,@dptr
	cjne	a,#0x01,00103$
00103$:
	mov  _ak820_nvm_ok_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_schema_fault'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:105: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
;	-----------------------------------------
;	 function ak820_nvm_schema_fault
;	-----------------------------------------
_ak820_nvm_schema_fault:
	mov	dpl, #0x10
	ljmp	_nvm_fail
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_flush'
;------------------------------------------------------------
;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:107: void ak820_nvm_flush(void) {
;	-----------------------------------------
;	 function ak820_nvm_flush
;	-----------------------------------------
_ak820_nvm_flush:
;	keyboards/ajazz/ak820/ak820_nvm.c:112: if (!page_dirty || storage_failed) return;
	mov	dptr,#_page_dirty
	movx	a,@dptr
	jz	00101$
	mov	dptr,#_storage_failed
	movx	a,@dptr
	jz	00102$
00101$:
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:113: crc = page_crc();
	lcall	_page_crc
	mov	r6, dpl
	mov	r7, dph
;	keyboards/ajazz/ak820/ak820_nvm.c:114: header[0] = 0xA5u;
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	mov	a,#0xa5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:115: header[1] = (uint8_t)cached_page;
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:116: header[2] = (uint8_t)(cached_page >> 8);
	mov	dptr,#_cached_page
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:117: header[3] = (uint8_t)crc;
	mov	ar5,r6
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:118: header[4] = (uint8_t)(crc >> 8);
	mov	ar6,r7
	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:119: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
	mov	r7,#0x01
00128$:
	mov	ar6,r7
	mov	a,r6
	add	a,#0x04
	mov	r6,a
	rlc	a
	subb	a,acc
	mov	r5,a
	mov	a,r6
	add	a, #_ak820_nvm_flush_header_10000_62
	mov	r6,a
	mov	a,r5
	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
	mov	r5,a
	mov	a,r7
	add	a, #_ak820_nvm_flush_header_10000_62
	mov	dpl,a
	clr	a
	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	xrl	ar4,#0xff
	mov	dpl,r6
	mov	dph,r5
	mov	a,r4
	movx	@dptr,a
	inc	r7
	cjne	r7,#0x05,00128$
;	keyboards/ajazz/ak820/ak820_nvm.c:122: stage = AK820_NVM_FAULT_HEADER_ERASE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x05
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:123: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jnz	00269$
	ljmp	00127$
00269$:
;	keyboards/ajazz/ak820/ak820_nvm.c:124: stage = AK820_NVM_FAULT_HEADER_ZERO;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x06
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:125: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	mov	r7,#0x00
00130$:
;	keyboards/ajazz/ak820/ak820_nvm.c:126: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
	mov	ar6,r7
	mov	r5,#0x00
	mov	a,#0x40
	add	a, r6
	mov	r6,a
	mov	a,#0xef
	addc	a, r5
	mov	r5,a
	mov	dpl, r6
	mov	dph, r5
	lcall	_ak820_flash_read
	mov	a, dpl
	jz	00270$
	ljmp	00127$
00270$:
;	keyboards/ajazz/ak820/ak820_nvm.c:125: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00130$
;	keyboards/ajazz/ak820/ak820_nvm.c:128: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x07
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:129: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
	mov	dptr,#0xef00
	lcall	_write_page
	mov	a, dpl
	jnz	00273$
	ljmp	00127$
00273$:
;	keyboards/ajazz/ak820/ak820_nvm.c:130: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x08
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:131: for (i = 1; i != sizeof(header); ++i) {
	mov	r7,#0x01
00132$:
;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
	mov	a,r7
	add	a, #_ak820_nvm_flush_header_10000_62
	mov	dpl,a
	clr	a
	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	jz	00133$
	mov	ar5,r7
	mov	r4,#0x00
	mov	a,#0x40
	add	a, r5
	mov	r5,a
	mov	a,#0xef
	addc	a, r4
	mov	r4,a
	mov	dptr,#_ak820_flash_program_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r4
	push	ar7
	lcall	_ak820_flash_program
	mov	a, dpl
	pop	ar7
	jnz	00275$
	ljmp	00127$
00275$:
00133$:
;	keyboards/ajazz/ak820/ak820_nvm.c:131: for (i = 1; i != sizeof(header); ++i) {
	inc	r7
	cjne	r7,#0x09,00132$
;	keyboards/ajazz/ak820/ak820_nvm.c:134: stage = AK820_NVM_FAULT_METADATA_READBACK;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x09
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:135: for (i = 1; i != sizeof(header); ++i) {
	mov	r7,#0x01
00134$:
;	keyboards/ajazz/ak820/ak820_nvm.c:136: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
	mov	ar6,r7
	mov	r5,#0x00
	mov	a,#0x40
	add	a, r6
	mov	r6,a
	mov	a,#0xef
	addc	a, r5
	mov	r5,a
	mov	dpl, r6
	mov	dph, r5
	lcall	_ak820_flash_read
	mov	r6, dpl
	mov	a,r7
	add	a, #_ak820_nvm_flush_header_10000_62
	mov	dpl,a
	clr	a
	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	cjne	a,ar5,00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:135: for (i = 1; i != sizeof(header); ++i) {
	inc	r7
	cjne	r7,#0x09,00134$
;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:140: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	movx	a,@dptr
	mov	dptr,#_ak820_flash_program_PARM_2
	movx	@dptr,a
	mov	dptr,#0xef40
	lcall	_ak820_flash_program
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:141: stage = AK820_NVM_FAULT_COMMIT_READBACK;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0b
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:142: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_read
	mov	r7, dpl
	mov	dptr,#_ak820_nvm_flush_header_10000_62
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_TARGET_WRITE;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0c
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:144: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	anl	a,#0x03
	mov	c,acc.0
	xch	a,r6
	rrc	a
	xch	a,r6
	rrc	a
	mov	c,acc.0
	xch	a,r6
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	add	a,#0xc7
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_write_page
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:145: stage = AK820_NVM_FAULT_CLEANUP;
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	mov	a,#0x0d
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:146: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
	mov	dptr,#0xef40
	lcall	_ak820_flash_erase
	mov	a, dpl
	jz	00127$
;	keyboards/ajazz/ak820/ak820_nvm.c:147: page_dirty = false;
	mov	dptr,#_page_dirty
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:148: return;
;	keyboards/ajazz/ak820/ak820_nvm.c:149: failed:
	ret
00127$:
;	keyboards/ajazz/ak820/ak820_nvm.c:150: nvm_fail(stage);
	mov	dptr,#_ak820_nvm_flush_stage_10000_62
	movx	a,@dptr
	mov	dpl,a
;	keyboards/ajazz/ak820/ak820_nvm.c:151: }
	ljmp	_nvm_fail
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_begin'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:153: void ak820_nvm_begin(void) {
;	-----------------------------------------
;	 function ak820_nvm_begin
;	-----------------------------------------
_ak820_nvm_begin:
;	keyboards/ajazz/ak820/ak820_nvm.c:154: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
	mov	dptr,#_batch_depth
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00102$
	mov	dpl, #0x0f
	ljmp	_nvm_fail
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:155: else ++batch_depth;
	mov	dptr,#_batch_depth
	mov	a,r7
	inc	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:156: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_nvm_end'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:158: void ak820_nvm_end(void) {
;	-----------------------------------------
;	 function ak820_nvm_end
;	-----------------------------------------
_ak820_nvm_end:
;	keyboards/ajazz/ak820/ak820_nvm.c:159: if (batch_depth) --batch_depth;
	mov	dptr,#_batch_depth
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00102$
	mov	a,r7
	dec	a
	mov	dptr,#_batch_depth
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:160: if (!batch_depth) ak820_nvm_flush();
	mov	dptr,#_batch_depth
	movx	a,@dptr
	jnz	00105$
;	keyboards/ajazz/ak820/ak820_nvm.c:161: }
	ljmp	_ak820_nvm_flush
00105$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'load_page'
;------------------------------------------------------------
;sloc1         Allocated with name '_load_page_sloc1_1_0'
;page          Allocated with name '_load_page_page_10000_87'
;i             Allocated with name '_load_page_i_10000_88'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:163: static bool load_page(uint16_t page) {
;	-----------------------------------------
;	 function load_page
;	-----------------------------------------
_load_page:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_load_page_page_10000_87
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:165: if (page_valid && cached_page == page) return !storage_failed;
	mov	dptr,#_page_valid
	movx	a,@dptr
	jz	00102$
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_load_page_page_10000_87
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	cjne	a,ar4,00102$
	mov	a,r7
	cjne	a,ar5,00102$
	mov	dptr,#_storage_failed
	movx	a,@dptr
	cjne	a,#0x01,00150$
00150$:
	mov  _load_page_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:166: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	keyboards/ajazz/ak820/ak820_nvm.c:167: if (storage_failed) return false;
	mov	dptr,#_storage_failed
	movx	a,@dptr
	jz	00119$
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_nvm.c:168: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00119$:
	mov	r7,#0x00
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:169: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
	mov	a,r7
	add	a, #_page_data
	mov	r5,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r6,a
	mov	dptr,#_load_page_page_10000_87
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	ar1,r3
	mov	ar2,r4
	mov	a,r2
	anl	a,#0x03
	mov	c,acc.0
	xch	a,r1
	rrc	a
	xch	a,r1
	rrc	a
	mov	c,acc.0
	xch	a,r1
	rrc	a
	xch	a,r1
	rrc	a
	xch	a,r1
	mov	r2,a
	mov	_load_page_sloc1_1_0,r1
	mov	a,#0xc7
	add	a, r2
	mov	(_load_page_sloc1_1_0 + 1),a
	mov	ar0,r7
	mov	r2,#0x00
	mov	a,r0
	add	a, _load_page_sloc1_1_0
	mov	r0,a
	mov	a,r2
	addc	a, (_load_page_sloc1_1_0 + 1)
	mov	r2,a
	mov	dpl, r0
	mov	dph, r2
	lcall	_ak820_flash_read
	mov	r2, dpl
	mov	dpl,r5
	mov	dph,r6
	mov	a,r2
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:168: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r7
	cjne	r7,#0x40,00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:171: cached_page = page;
	mov	dptr,#_cached_page
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:172: page_valid = true;
	mov	dptr,#_page_valid
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:173: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_nvm.c:174: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'read_offset'
;------------------------------------------------------------
;offset        Allocated with name '_read_offset_offset_10000_93'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:176: static uint8_t read_offset(uint16_t offset) {
;	-----------------------------------------
;	 function read_offset
;	-----------------------------------------
_read_offset:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_read_offset_offset_10000_93
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:177: if (offset >= AK820_NVM_SIZE) return 0;
	mov	dptr,#_read_offset_offset_10000_93
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	clr	c
	subb	a,#0x28
	jc	00102$
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:178: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
	mov	dptr,#_page_valid
	movx	a,@dptr
	jz	00104$
	mov	ar4,r6
	mov	a,r7
	mov	c,acc.7
	xch	a,r4
	rlc	a
	xch	a,r4
	rlc	a
	mov	c,acc.7
	xch	a,r4
	rlc	a
	xch	a,r4
	rlc	a
	xch	a,r4
	anl	a,#0x03
	mov	r5,a
	mov	dptr,#_cached_page
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,r4
	cjne	a,ar2,00104$
	mov	a,r5
	cjne	a,ar3,00104$
;	keyboards/ajazz/ak820/ak820_nvm.c:179: return page_data[offset % AK820_FLASH_PAGE];
	mov	a,#0x3f
	anl	a,r6
	mov	r5,#0x00
	add	a, #_page_data
	mov	dpl,a
	mov	a,r5
	addc	a, #(_page_data >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	dpl,a
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_nvm.c:180: return ak820_flash_read(AK820_NVM_BASE + offset);
	mov	a,#0xc7
	add	a, r7
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
;	keyboards/ajazz/ak820/ak820_nvm.c:181: }
	ljmp	_ak820_flash_read
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_byte'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:184: uint8_t eeprom_read_byte(const uint8_t *addr) {
;	-----------------------------------------
;	 function eeprom_read_byte
;	-----------------------------------------
_eeprom_read_byte:
	push	ar7
	push	ar6
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_eeprom_read_byte_addr_10000_97
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:185: return read_offset((uint16_t)(uintptr_t)addr);
	mov	dptr,#_eeprom_read_byte_addr_10000_97
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_read_offset
	mov	r7, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_nvm.c:186: }
	pop	ar6
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_block'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_block_PARM_2'
;len           Allocated with name '_eeprom_read_block_PARM_3'
;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
;out           Allocated with name '_eeprom_read_block_out_10000_100'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:190: void eeprom_read_block(void *buf, const void *addr, size_t len) {
;	-----------------------------------------
;	 function eeprom_read_block
;	-----------------------------------------
_eeprom_read_block:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_eeprom_read_block_buf_10000_99
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:191: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_eeprom_read_block_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_nvm.c:192: uint8_t *out = (uint8_t *)buf;
	mov	dptr,#_eeprom_read_block_buf_10000_99
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_eeprom_read_block_out_10000_100
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:193: while (len--) {
	mov	dptr,#_eeprom_read_block_PARM_3
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
00103$:
	mov	ar2,r4
	mov	ar3,r5
	dec	r4
	cjne	r4,#0xff,00130$
	dec	r5
00130$:
	mov	a,r2
	orl	a,r3
	jnz	00131$
	ret
00131$:
;	keyboards/ajazz/ak820/ak820_nvm.c:194: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
	mov	ar2,r6
	mov	ar3,r7
	mov	a,#0x100 - 0x28
	add	a,r3
	jnc	00102$
	mov	dptr,#_eeprom_read_block_out_10000_100
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	clr	a
	lcall	__gptrput
	mov	dptr,#_eeprom_read_block_out_10000_100
	inc	a
	add	a, r1
	movx	@dptr,a
	clr	a
	addc	a, r2
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	sjmp	00103$
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:195: *out++ = read_offset(offset);
	mov	dptr,#_eeprom_read_block_out_10000_100
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	lcall	_read_offset
	mov	r0, dpl
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	mov	a,r0
	lcall	__gptrput
	mov	dptr,#_eeprom_read_block_out_10000_100
	mov	a,#0x01
	add	a, r1
	movx	@dptr,a
	clr	a
	addc	a, r2
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:196: ++offset;
	inc	r6
	cjne	r6,#0x00,00133$
	inc	r7
00133$:
;	keyboards/ajazz/ak820/ak820_nvm.c:198: }
	ljmp	00103$
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_write_block'
;------------------------------------------------------------
;sloc0         Allocated with name '_eeprom_write_block_sloc0_1_0'
;addr          Allocated with name '_eeprom_write_block_PARM_2'
;len           Allocated with name '_eeprom_write_block_PARM_3'
;buf           Allocated with name '_eeprom_write_block_buf_10000_104'
;offset        Allocated with name '_eeprom_write_block_offset_10000_105'
;in            Allocated with name '_eeprom_write_block_in_10000_105'
;value         Allocated with name '_eeprom_write_block_value_20000_108'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:200: void eeprom_write_block(const void *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function eeprom_write_block
;	-----------------------------------------
_eeprom_write_block:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_eeprom_write_block_buf_10000_104
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:201: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_eeprom_write_block_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_nvm.c:202: const uint8_t *in = (const uint8_t *)buf;
	mov	dptr,#_eeprom_write_block_buf_10000_104
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_nvm.c:204: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
	mov	ar1,r6
	mov	ar2,r7
	clr	c
	clr	a
	subb	a,r1
	mov	a,#0x28
	subb	a,r2
	jc	00101$
;	free result
	push	ar3
	push	ar4
	push	ar5
	clr	a
	clr	c
	subb	a,r6
	mov	r1,a
	mov	a,#0x28
	subb	a,r7
	mov	r2,a
	mov	dptr,#_eeprom_write_block_PARM_3
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,r1
	subb	a,r0
	mov	a,r2
	subb	a,r5
	pop	ar5
	pop	ar4
	pop	ar3
	jnc	00125$
;	free result
00101$:
;	keyboards/ajazz/ak820/ak820_nvm.c:205: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
	mov	dpl, #0x0e
;	keyboards/ajazz/ak820/ak820_nvm.c:206: return;
	ljmp	_nvm_fail
;	keyboards/ajazz/ak820/ak820_nvm.c:208: while (len--) {
00125$:
	mov	_eeprom_write_block_sloc0_1_0,r6
	mov	(_eeprom_write_block_sloc0_1_0 + 1),r7
	mov	dptr,#_eeprom_write_block_PARM_3
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
00108$:
	mov	ar0,r1
	mov	ar7,r2
	dec	r1
	cjne	r1,#0xff,00159$
	dec	r2
00159$:
	mov	a,r0
	orl	a,r7
	jnz	00160$
	ljmp	00110$
00160$:
;	keyboards/ajazz/ak820/ak820_nvm.c:209: uint8_t value = *in++;
	push	ar1
	push	ar2
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r7,a
	inc	dptr
	mov	r3,dpl
	mov	r4,dph
;	keyboards/ajazz/ak820/ak820_nvm.c:210: if (!load_page(offset / AK820_FLASH_PAGE)) return;
	mov	r0,_eeprom_write_block_sloc0_1_0
	mov	r6,(_eeprom_write_block_sloc0_1_0 + 1)
	mov	ar1,r0
	mov	a,r6
	mov	c,acc.7
	xch	a,r1
	rlc	a
	xch	a,r1
	rlc	a
	mov	c,acc.7
	xch	a,r1
	rlc	a
	xch	a,r1
	rlc	a
	xch	a,r1
	anl	a,#0x03
	mov	r2,a
	mov	dpl, r1
	mov	dph, r2
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_load_page
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	ar2
	pop	ar1
	jnz	00105$
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_nvm.c:211: if (page_data[offset % AK820_FLASH_PAGE] != value) {
	push	ar1
	push	ar2
	anl	ar0,#0x3f
	mov	r6,#0x00
	mov	a,r0
	add	a, #_page_data
	mov	r0,a
	mov	a,r6
	addc	a, #(_page_data >> 8)
	mov	r6,a
	mov	dpl,r0
	mov	dph,r6
	movx	a,@dptr
	cjne	a,ar7,00162$
	pop	ar2
	pop	ar1
	sjmp	00107$
00162$:
	pop	ar2
	pop	ar1
;	keyboards/ajazz/ak820/ak820_nvm.c:212: page_data[offset % AK820_FLASH_PAGE] = value;
	mov	dpl,r0
	mov	dph,r6
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:213: page_dirty = true;
	mov	dptr,#_page_dirty
	mov	a,#0x01
	movx	@dptr,a
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:215: ++offset;
	inc	_eeprom_write_block_sloc0_1_0
	clr	a
	cjne	a,_eeprom_write_block_sloc0_1_0,00163$
	inc	(_eeprom_write_block_sloc0_1_0 + 1)
00163$:
	ljmp	00108$
00110$:
;	keyboards/ajazz/ak820/ak820_nvm.c:217: if (!batch_depth) ak820_nvm_flush();
	mov	dptr,#_batch_depth
	movx	a,@dptr
	jnz	00113$
;	keyboards/ajazz/ak820/ak820_nvm.c:218: }
	ljmp	_ak820_nvm_flush
00113$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_eeprom_read_block_xdata'
;------------------------------------------------------------
;addr          Allocated with name '_ak820_eeprom_read_block_xdata_PARM_2'
;len           Allocated with name '_ak820_eeprom_read_block_xdata_PARM_3'
;buf           Allocated with name '_ak820_eeprom_read_block_xdata_buf_10000_113'
;offset        Allocated with name '_ak820_eeprom_read_block_xdata_offset_10000_114'
;out           Allocated with name '_ak820_eeprom_read_block_xdata_out_10000_114'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:220: void ak820_eeprom_read_block_xdata(void AK820_XDATA *buf, const void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_read_block_xdata
;	-----------------------------------------
_ak820_eeprom_read_block_xdata:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:221: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_nvm.c:222: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:223: while (len--) {
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
00103$:
	mov	ar2,r4
	mov	ar3,r5
	dec	r4
	cjne	r4,#0xff,00130$
	dec	r5
00130$:
	mov	a,r2
	orl	a,r3
	jz	00106$
;	keyboards/ajazz/ak820/ak820_nvm.c:224: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
	mov	ar2,r6
	mov	ar3,r7
	mov	a,#0x100 - 0x28
	add	a,r3
	jnc	00102$
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	clr	a
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	inc	a
	add	a, r2
	movx	@dptr,a
	clr	a
	addc	a, r3
	inc	dptr
	movx	@dptr,a
	sjmp	00103$
00102$:
;	keyboards/ajazz/ak820/ak820_nvm.c:225: *out++ = read_offset(offset);
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_read_offset
	mov	r1, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	dpl,r2
	mov	dph,r3
	mov	a,r1
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
	mov	a,#0x01
	add	a, r2
	movx	@dptr,a
	clr	a
	addc	a, r3
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:226: ++offset;
	inc	r6
	cjne	r6,#0x00,00103$
	inc	r7
	sjmp	00103$
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:228: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:230: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_write_block_xdata
;	-----------------------------------------
_ak820_eeprom_write_block_xdata:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_nvm.c:232: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_nvm.c:234: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
	mov	ar2,r6
	mov	ar3,r7
	clr	c
	clr	a
	subb	a,r2
	mov	a,#0x28
	subb	a,r3
	jc	00101$
;	free result
	clr	a
	clr	c
	subb	a,r6
	mov	r2,a
	mov	a,#0x28
	subb	a,r7
	mov	r3,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,r2
	subb	a,r0
	mov	a,r3
	subb	a,r1
	jnc	00125$
;	free result
00101$:
;	keyboards/ajazz/ak820/ak820_nvm.c:235: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
	mov	dpl, #0x0e
;	keyboards/ajazz/ak820/ak820_nvm.c:236: return;
	ljmp	_nvm_fail
;	keyboards/ajazz/ak820/ak820_nvm.c:238: while (len--) {
00125$:
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
00108$:
	mov	ar0,r2
	mov	ar1,r3
	dec	r2
	cjne	r2,#0xff,00159$
	dec	r3
00159$:
	mov	a,r0
	orl	a,r1
	jnz	00160$
	ljmp	00110$
00160$:
;	keyboards/ajazz/ak820/ak820_nvm.c:239: uint8_t value = *in++;
	push	ar2
	push	ar3
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	mov	r4,dpl
	mov	r5,dph
;	keyboards/ajazz/ak820/ak820_nvm.c:240: if (!load_page(offset / AK820_FLASH_PAGE)) return;
	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	mov	c,acc.7
	xch	a,r0
	rlc	a
	xch	a,r0
	rlc	a
	mov	c,acc.7
	xch	a,r0
	rlc	a
	xch	a,r0
	rlc	a
	xch	a,r0
	anl	a,#0x03
	mov	r3,a
	mov	dpl, r0
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	lcall	_load_page
	mov	a, dpl
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	ar3
	pop	ar2
	jnz	00105$
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_nvm.c:241: if (page_data[offset % AK820_FLASH_PAGE] != value) {
	push	ar6
	push	ar7
	mov	a,#0x3f
	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	r7,#0x00
	add	a, #_page_data
	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
	mov	a,r7
	addc	a, #(_page_data >> 8)
	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	movx	a,@dptr
	cjne	a,ar1,00162$
	pop	ar7
	pop	ar6
	sjmp	00107$
00162$:
	pop	ar7
	pop	ar6
;	keyboards/ajazz/ak820/ak820_nvm.c:242: page_data[offset % AK820_FLASH_PAGE] = value;
	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
	mov	a,r1
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:243: page_dirty = true;
	mov	dptr,#_page_dirty
	mov	a,#0x01
	movx	@dptr,a
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:245: ++offset;
	inc	r6
	cjne	r6,#0x00,00163$
	inc	r7
00163$:
	ljmp	00108$
00110$:
;	keyboards/ajazz/ak820/ak820_nvm.c:247: if (!batch_depth) ak820_nvm_flush();
	mov	dptr,#_batch_depth
	movx	a,@dptr
	jnz	00113$
;	keyboards/ajazz/ak820/ak820_nvm.c:248: }
	ljmp	_ak820_nvm_flush
00113$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:250: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function ak820_eeprom_update_block_xdata
;	-----------------------------------------
_ak820_eeprom_update_block_xdata:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_nvm.c:251: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_nvm.c:252: uint16_t offset = (uint16_t)(uintptr_t)addr;
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	movx	a,@dptr
	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
;	keyboards/ajazz/ak820/ak820_nvm.c:254: for (i = 0; i < len; ++i) {
	clr	a
	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
00105$:
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	movx	a,@dptr
	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
	clr	c
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
	jnc	00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:255: if (read_offset(offset + i) != source[i]) {
	mov	ar0,r1
	mov	ar5,r2
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	add	a, r0
	mov	r0,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	addc	a, r5
	mov	r5,a
	mov	dpl, r0
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar2
	push	ar1
	lcall	_read_offset
	mov	r5, dpl
	pop	ar1
	pop	ar2
	pop	ar6
	pop	ar7
	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
	add	a, r6
	mov	dpl,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	cjne	a,ar4,00131$
	sjmp	00106$
00131$:
;	keyboards/ajazz/ak820/ak820_nvm.c:256: ak820_eeprom_write_block_xdata(buf, addr, len);
	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
	movx	@dptr,a
	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dpl, r0
	mov	dph, r5
;	keyboards/ajazz/ak820/ak820_nvm.c:257: return;
	ljmp	_ak820_eeprom_write_block_xdata
00106$:
;	keyboards/ajazz/ak820/ak820_nvm.c:254: for (i = 0; i < len; ++i) {
	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
	clr	a
	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
	sjmp	00105$
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:260: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_driver_erase'
;------------------------------------------------------------
;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_nvm.c:262: void eeprom_driver_erase(void) {
;	-----------------------------------------
;	 function eeprom_driver_erase
;	-----------------------------------------
_eeprom_driver_erase:
;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	keyboards/ajazz/ak820/ak820_nvm.c:266: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
	mov	r6,#0x00
	mov	r7,#0x00
00111$:
	mov	ar4,r6
	mov	ar5,r7
	cjne	r4,#0xa0,00165$
	cjne	r5,#0x00,00165$
	ret
00165$:
	mov	dptr,#_storage_failed
	movx	a,@dptr
	jnz	00113$
;	keyboards/ajazz/ak820/ak820_nvm.c:267: if (!load_page(page)) return;
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	lcall	_load_page
	mov	a, dpl
	pop	ar6
	pop	ar7
	jnz	00126$
;	keyboards/ajazz/ak820/ak820_nvm.c:268: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	ret
00126$:
	mov	r5,#0x00
00107$:
;	keyboards/ajazz/ak820/ak820_nvm.c:269: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
	mov	a,r5
	add	a, #_page_data
	mov	r3,a
	clr	a
	addc	a, #(_page_data >> 8)
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jz	00108$
	mov	dpl,r3
	mov	dph,r4
	clr	a
	movx	@dptr,a
	mov	dptr,#_page_dirty
	inc	a
	movx	@dptr,a
00108$:
;	keyboards/ajazz/ak820/ak820_nvm.c:268: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
	inc	r5
	cjne	r5,#0x40,00107$
;	keyboards/ajazz/ak820/ak820_nvm.c:271: ak820_nvm_flush();
	push	ar7
	push	ar6
	lcall	_ak820_nvm_flush
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_nvm.c:266: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
	inc	r6
	cjne	r6,#0x00,00111$
	inc	r7
	sjmp	00111$
00113$:
;	keyboards/ajazz/ak820/ak820_nvm.c:273: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
