;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_macro
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _eeprom_update_byte
	.globl _eeprom_read_byte
	.globl _ak820_eeprom_write_block_xdata
	.globl _ak820_nvm_end
	.globl _ak820_nvm_flush
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_ok
	.globl _ak820_macro_write_PARM_3
	.globl _ak820_macro_write_PARM_2
	.globl _ak820_macro_init
	.globl _ak820_macro_ready
	.globl _ak820_macro_length
	.globl _ak820_macro_write
	.globl _ak820_macro_reset
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_macro_write_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_parse_byte_sloc1_1_0:
	.ds 2
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_parse_byte_sloc0_1_0:
	.ds 1
_ak820_macro_ready_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_parsed:
	.ds 2
_covered:
	.ds 2
_used_length:
	.ds 2
_uploading:
	.ds 1
_macro_byte_offset_10000_67:
	.ds 2
_busy_write_value_10000_69:
	.ds 1
_commit_length_length_10000_71:
	.ds 2
_commit_length_metadata_10000_72:
	.ds 3
_parse_byte_PARM_2:
	.ds 1
_parse_byte_state_10000_74:
	.ds 2
_matches_PARM_2:
	.ds 2
_matches_PARM_3:
	.ds 2
_matches_offset_10000_89:
	.ds 2
_ak820_macro_write_PARM_2:
	.ds 2
_ak820_macro_write_PARM_3:
	.ds 3
_ak820_macro_write_offset_10000_99:
	.ds 2
_ak820_macro_write_next_10000_100:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area AK820LOW(CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'macro_byte'
;------------------------------------------------------------
;offset        Allocated with name '_macro_byte_offset_10000_67'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:34: static uint8_t macro_byte(uint16_t offset) {
;	-----------------------------------------
;	 function macro_byte
;	-----------------------------------------
_macro_byte:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_macro_byte_offset_10000_67
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:35: return eeprom_read_byte((const uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset));
	mov	dptr,#_macro_byte_offset_10000_67
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	add	a,#0x08
	mov	r7,a
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r7
	mov	b, r5
;	keyboards/ajazz/ak820/ak820_macro.c:36: }
	ljmp	_eeprom_read_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'busy_write'
;------------------------------------------------------------
;value         Allocated with name '_busy_write_value_10000_69'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:38: static void busy_write(uint8_t value) {
;	-----------------------------------------
;	 function busy_write
;	-----------------------------------------
_busy_write:
	mov	a,dpl
	mov	dptr,#_busy_write_value_10000_69
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:39: eeprom_update_byte((uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR, value);
	movx	a,@dptr
	mov	dptr,#_eeprom_update_byte_PARM_2
	movx	@dptr,a
	mov	dptr,#0x07f0
	mov	b, #0x00
	lcall	_eeprom_update_byte
;	keyboards/ajazz/ak820/ak820_macro.c:40: ak820_nvm_flush();
;	keyboards/ajazz/ak820/ak820_macro.c:41: }
	ljmp	_ak820_nvm_flush
;------------------------------------------------------------
;Allocation info for local variables in function 'commit_length'
;------------------------------------------------------------
;length        Allocated with name '_commit_length_length_10000_71'
;metadata      Allocated with name '_commit_length_metadata_10000_72'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:43: static void commit_length(uint16_t length) {
;	-----------------------------------------
;	 function commit_length
;	-----------------------------------------
_commit_length:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_commit_length_length_10000_71
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:45: metadata[0] = 0;
	mov	dptr,#_commit_length_metadata_10000_72
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:46: metadata[1] = (uint8_t)length;
	mov	dptr,#_commit_length_length_10000_71
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar5,r6
	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0001)
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:47: metadata[2] = (uint8_t)(length >> 8);
	mov	ar5,r7
	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0002)
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:48: ak820_eeprom_write_block_xdata(metadata, (void *)(uintptr_t)AK820_MACRO_BUSY_ADDR, sizeof(metadata));
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	mov	a,#0xf0
	movx	@dptr,a
	mov	a,#0x07
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	mov	a,#0x03
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_commit_length_metadata_10000_72
	push	ar7
	push	ar6
	lcall	_ak820_eeprom_write_block_xdata
;	keyboards/ajazz/ak820/ak820_macro.c:49: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_macro.c:50: if (ak820_nvm_ok()) used_length = length;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00103$
	mov	dptr,#_used_length
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
00103$:
;	keyboards/ajazz/ak820/ak820_macro.c:51: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'parse_byte'
;------------------------------------------------------------
;value         Allocated with name '_parse_byte_PARM_2'
;state         Allocated with name '_parse_byte_state_10000_74'
;sloc1         Allocated with name '_parse_byte_sloc1_1_0'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:55: static bool parse_byte(macro_parse_t AK820_XDATA *state, uint8_t value) {
;	-----------------------------------------
;	 function parse_byte
;	-----------------------------------------
_parse_byte:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_parse_byte_state_10000_74
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:56: if (state->terminated == DYNAMIC_KEYMAP_MACRO_COUNT) return value == 0;
	mov	dptr,#_parse_byte_state_10000_74
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x10,00102$
	mov	dptr,#_parse_byte_PARM_2
	movx	a,@dptr
	cjne	a,#0x01,00191$
00191$:
	mov  _parse_byte_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_macro.c:57: if (state->arguments == 3) {
	inc	r6
	cjne	r6,#0x00,00192$
	inc	r7
00192$:
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0x03,00120$
;	keyboards/ajazz/ak820/ak820_macro.c:58: if (value < 1 || value > 7) return false;
	mov	dptr,#_parse_byte_PARM_2
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x01,00195$
00195$:
	jc	00103$
	mov	a,r1
	add	a,#0xff - 0x07
	jnc	00104$
;	free result
00103$:
	mov	dpl, #0x00
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_macro.c:59: state->arguments = value <= 3 ? 1 : 2;
	mov	_parse_byte_sloc1_1_0,r6
	mov	(_parse_byte_sloc1_1_0 + 1),r7
	mov	a,r1
	add	a,#0xff - 0x03
	jc	00124$
;	free result
	mov	r1,#0x01
	sjmp	00125$
00124$:
	mov	r1,#0x02
00125$:
	mov	dpl,_parse_byte_sloc1_1_0
	mov	dph,(_parse_byte_sloc1_1_0 + 1)
	mov	a,r1
	movx	@dptr,a
	sjmp	00121$
00120$:
;	keyboards/ajazz/ak820/ak820_macro.c:60: } else if (state->arguments) {
	mov	a,r2
	jz	00117$
;	keyboards/ajazz/ak820/ak820_macro.c:61: if (!value) return false;
	mov	dptr,#_parse_byte_PARM_2
	movx	a,@dptr
	jnz	00107$
	mov	dpl,a
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_macro.c:62: --state->arguments;
	dec	r2
	mov	dpl,r6
	mov	dph,r7
	mov	a,r2
	movx	@dptr,a
	sjmp	00121$
00117$:
;	keyboards/ajazz/ak820/ak820_macro.c:63: } else if (!value) {
	mov	dptr,#_parse_byte_PARM_2
	movx	a,@dptr
	mov	r2,a
	jnz	00114$
;	keyboards/ajazz/ak820/ak820_macro.c:64: ++state->terminated;
	inc	r3
	mov	dpl,r4
	mov	dph,r5
	mov	a,r3
	movx	@dptr,a
	sjmp	00121$
00114$:
;	keyboards/ajazz/ak820/ak820_macro.c:65: } else if (value == 1) {
	cjne	r2,#0x01,00111$
;	keyboards/ajazz/ak820/ak820_macro.c:66: state->arguments = 3;
	mov	dpl,r6
	mov	dph,r7
	mov	a,#0x03
	movx	@dptr,a
	sjmp	00121$
00111$:
;	keyboards/ajazz/ak820/ak820_macro.c:67: } else if (value >= 128) {
	cjne	r2,#0x80,00204$
00204$:
	jc	00121$
;	keyboards/ajazz/ak820/ak820_macro.c:70: return false;
	mov	dpl, #0x00
	ret
00121$:
;	keyboards/ajazz/ak820/ak820_macro.c:72: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_macro.c:73: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'matches'
;------------------------------------------------------------
;size          Allocated with name '_matches_PARM_2'
;data          Allocated with name '_matches_PARM_3'
;offset        Allocated with name '_matches_offset_10000_89'
;value         Allocated with name '_matches_value_20000_91'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:75: static bool matches(uint16_t offset, uint16_t size, const uint8_t AK820_XDATA *data) {
;	-----------------------------------------
;	 function matches
;	-----------------------------------------
_matches:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_matches_offset_10000_89
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:76: while (size--) {
	mov	dptr,#_matches_PARM_3
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_matches_offset_10000_89
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_matches_PARM_2
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
00103$:
	mov	ar0,r2
	mov	ar1,r3
	dec	r2
	cjne	r2,#0xff,00147$
	dec	r3
00147$:
	mov	a,r0
	orl	a,r1
	jz	00105$
;	keyboards/ajazz/ak820/ak820_macro.c:77: uint8_t value = !uploading && offset >= used_length ? 0 : macro_byte(offset);
	mov	dptr,#_uploading
	movx	a,@dptr
	jnz	00108$
	mov	dptr,#_used_length
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	clr	c
	mov	a,r4
	subb	a,r0
	mov	a,r5
	subb	a,r1
	jc	00108$
	mov	r1,#0x00
	sjmp	00109$
00108$:
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_macro_byte
	mov	r0, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	ar1,r0
00109$:
;	keyboards/ajazz/ak820/ak820_macro.c:78: if (value != *data++) return false;
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	mov	r6,dpl
	mov	r7,dph
	mov	a,r1
	cjne	a,ar0,00151$
	sjmp	00102$
00151$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_macro.c:79: ++offset;
	inc	r4
	cjne	r4,#0x00,00152$
	inc	r5
00152$:
	mov	dptr,#_matches_offset_10000_89
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	sjmp	00103$
00105$:
;	keyboards/ajazz/ak820/ak820_macro.c:81: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_macro.c:82: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_macro_init'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:84: void ak820_macro_init(void) {
;	-----------------------------------------
;	 function ak820_macro_init
;	-----------------------------------------
_ak820_macro_init:
;	keyboards/ajazz/ak820/ak820_macro.c:85: covered = 0;
	mov	dptr,#_covered
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:86: uploading = false;
	mov	dptr,#_uploading
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:87: parsed.terminated = parsed.arguments = 0;
	mov	dptr,#(_parsed + 0x0001)
	movx	@dptr,a
	mov	dptr,#_parsed
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:88: used_length = eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_LENGTH_ADDR);
	mov	dptr,#0x07f1
	mov	b,a
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	dptr,#_used_length
	mov	a,r7
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:89: used_length |= (uint16_t)eeprom_read_byte((const uint8_t *)(uintptr_t)(AK820_MACRO_LENGTH_ADDR + 1)) << 8;
	mov	dptr,#0x07f2
	mov	b,a
	lcall	_eeprom_read_byte
	mov	r6,dpl
	mov	r7,#0x00
	mov	dptr,#_used_length
	movx	a,@dptr
	orl	a,r7
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	orl	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:90: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_macro_ready'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:92: bool ak820_macro_ready(void) {
;	-----------------------------------------
;	 function ak820_macro_ready
;	-----------------------------------------
_ak820_macro_ready:
;	keyboards/ajazz/ak820/ak820_macro.c:93: return ak820_nvm_ok() && used_length >= DYNAMIC_KEYMAP_MACRO_COUNT &&
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00103$
	mov	dptr,#_used_length
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,#0x10
	mov	a,r7
	subb	a,#0x00
;	keyboards/ajazz/ak820/ak820_macro.c:94: used_length <= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE &&
	jc	00103$
	clr	a
	subb	a,r6
	mov	a,#0x20
	subb	a,r7
	jc	00103$
;	free result
;	keyboards/ajazz/ak820/ak820_macro.c:95: eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR) == 0;
	mov	dptr,#0x07f0
	mov	b, #0x00
	lcall	_eeprom_read_byte
	mov	a, dpl
	jz	00104$
00103$:
;	assignBit
	clr	_ak820_macro_ready_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_ak820_macro_ready_sloc0_1_0
00105$:
	mov	c,_ak820_macro_ready_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
;	keyboards/ajazz/ak820/ak820_macro.c:96: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_macro_length'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:98: uint16_t ak820_macro_length(void) { return ak820_macro_ready() ? used_length : 0; }
;	-----------------------------------------
;	 function ak820_macro_length
;	-----------------------------------------
_ak820_macro_length:
	lcall	_ak820_macro_ready
	mov	a, dpl
	jz	00103$
	mov	dptr,#_used_length
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	sjmp	00104$
00103$:
	mov	r6,#0x00
	mov	r7,#0x00
00104$:
	mov	dpl, r6
	mov	dph, r7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_macro_write'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_macro_write_sloc0_1_0'
;size          Allocated with name '_ak820_macro_write_PARM_2'
;packet        Allocated with name '_ak820_macro_write_PARM_3'
;offset        Allocated with name '_ak820_macro_write_offset_10000_99'
;data          Allocated with name '_ak820_macro_write_data_10000_100'
;next          Allocated with name '_ak820_macro_write_next_10000_100'
;i             Allocated with name '_ak820_macro_write_i_10000_100'
;end           Allocated with name '_ak820_macro_write_end_10000_100'
;complete      Allocated with name '_ak820_macro_write_complete_10000_100'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:100: bool ak820_macro_write(uint16_t offset, uint16_t size, const uint8_t *packet) {
;	-----------------------------------------
;	 function ak820_macro_write
;	-----------------------------------------
_ak820_macro_write:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:103: const uint8_t AK820_XDATA *data = (const uint8_t AK820_XDATA *)packet;
	mov	dptr,#_ak820_macro_write_PARM_3
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_macro.c:109: if (!ak820_nvm_ok() || !size || offset >= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE ||
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00101$
	mov	dptr,#_ak820_macro_write_PARM_2
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	orl	a,r4
	jz	00101$
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	ar0,r2
	mov	ar1,r3
	mov	a,#0x100 - 0x20
	add	a,r1
	jc	00101$
;	keyboards/ajazz/ak820/ak820_macro.c:110: size > DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE - offset) return false;
	clr	a
	clr	c
	subb	a,r2
	mov	r0,a
	mov	a,#0x20
	subb	a,r3
	mov	r1,a
	clr	c
	mov	a,r0
	subb	a,r4
	mov	a,r1
	subb	a,r5
	jnc	00102$
;	free result
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_macro.c:111: end = offset + size;
	mov	a,r4
	add	a, r2
	mov	r0,a
	mov	a,r5
	addc	a, r3
	mov	r1,a
;	keyboards/ajazz/ak820/ak820_macro.c:114: if (end <= covered && (uploading || offset || end == covered) && matches(offset, size, data)) return true;
	mov	dptr,#_covered
	movx	a,@dptr
	mov	_ak820_macro_write_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
	clr	c
	mov	a,_ak820_macro_write_sloc0_1_0
	subb	a,r0
	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
	subb	a,r1
	jc	00107$
;	free result
	mov	dptr,#_uploading
	movx	a,@dptr
	jnz	00111$
	mov	a,r2
	orl	a,r3
	jnz	00111$
	mov	a,r0
	cjne	a,_ak820_macro_write_sloc0_1_0,00107$
	mov	a,r1
	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00107$
00111$:
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_matches_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_matches_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dpl, r2
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar1
	push	ar0
	lcall	_matches
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jz	00107$
	mov	dpl, #0x01
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_macro.c:116: if (!uploading) {
	mov	dptr,#_uploading
	movx	a,@dptr
	jz	00371$
	ljmp	00130$
00371$:
;	keyboards/ajazz/ak820/ak820_macro.c:117: if (offset) {
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jz	00120$
;	keyboards/ajazz/ak820/ak820_macro.c:121: if (!covered || offset != covered || !ak820_macro_ready()) return false;
	mov	dptr,#_covered
	movx	a,@dptr
	mov	_ak820_macro_write_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
	mov	dptr,#_covered
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jz	00112$
	mov	a,r2
	cjne	a,_ak820_macro_write_sloc0_1_0,00112$
	mov	a,r3
	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00112$
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar1
	push	ar0
	lcall	_ak820_macro_ready
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00200$
00112$:
	mov	dpl, #0x00
	ret
;	keyboards/ajazz/ak820/ak820_macro.c:122: for (i = 0; i < size; ++i) if (data[i]) return false;
00200$:
	mov	r2,#0x00
	mov	r3,#0x00
00148$:
	clr	c
	mov	a,r2
	subb	a,r4
	mov	a,r3
	subb	a,r5
	jnc	00118$
	push	ar0
	push	ar1
	mov	a,r2
	add	a, r6
	mov	r0,a
	mov	a,r3
	addc	a, r7
	mov	r1,a
	mov	dpl,r0
	mov	dph,r1
	movx	a,@dptr
	pop	ar1
	pop	ar0
	jz	00149$
	mov	dpl, #0x00
	ret
00149$:
	inc	r2
	cjne	r2,#0x00,00148$
	inc	r3
	sjmp	00148$
00118$:
;	keyboards/ajazz/ak820/ak820_macro.c:123: covered = end;
	mov	dptr,#_covered
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:124: return true;
	mov	dpl, #0x01
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_macro.c:126: next.terminated = next.arguments = 0;
	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
	clr	a
	movx	@dptr,a
	mov	dptr,#_ak820_macro_write_next_10000_100
	movx	@dptr,a
	ljmp	00208$
00130$:
;	keyboards/ajazz/ak820/ak820_macro.c:128: if (offset > covered) return false; /* A hole is never old EEPROM data. */
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_covered
	movx	a,@dptr
	mov	_ak820_macro_write_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
	clr	c
	mov	a,_ak820_macro_write_sloc0_1_0
	subb	a,r2
	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
	subb	a,r3
	jnc	00122$
;	free result
	mov	dpl, #0x00
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_macro.c:129: if (offset == covered) {
	mov	a,r2
	cjne	a,_ak820_macro_write_sloc0_1_0,00127$
	mov	a,r3
	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00127$
;	keyboards/ajazz/ak820/ak820_macro.c:130: next.terminated = parsed.terminated;
	mov	dptr,#_parsed
	movx	a,@dptr
	mov	dptr,#_ak820_macro_write_next_10000_100
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:131: next.arguments = parsed.arguments;
	mov	dptr,#(_parsed + 0x0001)
	movx	a,@dptr
	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
	movx	@dptr,a
	sjmp	00208$
00127$:
;	keyboards/ajazz/ak820/ak820_macro.c:136: next.terminated = next.arguments = 0;
	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
	clr	a
	movx	@dptr,a
	mov	dptr,#_ak820_macro_write_next_10000_100
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:137: for (i = 0; i < offset; ++i) if (!parse_byte(&next, macro_byte(i))) return false;
	mov	_ak820_macro_write_sloc0_1_0,a
	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
00151$:
	clr	c
	mov	a,_ak820_macro_write_sloc0_1_0
	subb	a,r2
	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
	subb	a,r3
	jnc	00208$
	mov	dpl, _ak820_macro_write_sloc0_1_0
	mov	dph, (_ak820_macro_write_sloc0_1_0 + 1)
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_macro_byte
	mov	a, dpl
	mov	dptr,#_parse_byte_PARM_2
	movx	@dptr,a
	mov	dptr,#_ak820_macro_write_next_10000_100
	lcall	_parse_byte
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00152$
	mov	dpl,a
	ret
00152$:
	inc	_ak820_macro_write_sloc0_1_0
	clr	a
;	keyboards/ajazz/ak820/ak820_macro.c:140: for (i = 0; i < size; ++i) if (!parse_byte(&next, data[i])) return false;
	cjne	a,_ak820_macro_write_sloc0_1_0,00151$
	inc	(_ak820_macro_write_sloc0_1_0 + 1)
	sjmp	00151$
00208$:
	mov	r2,#0x00
	mov	r3,#0x00
00154$:
	clr	c
	mov	a,r2
	subb	a,r4
	mov	a,r3
	subb	a,r5
	jnc	00134$
	push	ar0
	push	ar1
	mov	a,r2
	add	a, r6
	mov	dpl,a
	mov	a,r3
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r1,a
	mov	dptr,#_parse_byte_PARM_2
	movx	@dptr,a
	mov	dptr,#_ak820_macro_write_next_10000_100
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_parse_byte
	mov	a, dpl
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	pop	ar1
	pop	ar0
	jnz	00155$
	mov	dpl,a
	ret
00155$:
	inc	r2
	cjne	r2,#0x00,00154$
	inc	r3
	sjmp	00154$
00134$:
;	keyboards/ajazz/ak820/ak820_macro.c:141: complete = next.terminated == DYNAMIC_KEYMAP_MACRO_COUNT;
	mov	dptr,#_ak820_macro_write_next_10000_100
	movx	a,@dptr
	mov	r3,a
	clr	a
	cjne	r3,#0x10,00389$
	inc	a
00389$:
;	keyboards/ajazz/ak820/ak820_macro.c:142: if (!complete && end == DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE) return false;
	mov	_ak820_macro_write_sloc0_1_0,a
	jnz	00136$
	mov	ar2,r0
	mov	ar3,r1
	cjne	r2,#0x00,00136$
	cjne	r3,#0x20,00136$
	mov	dpl, #0x00
	ret
00136$:
;	keyboards/ajazz/ak820/ak820_macro.c:144: ak820_nvm_begin();
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar1
	push	ar0
	lcall	_ak820_nvm_begin
	pop	ar0
	pop	ar1
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_macro.c:145: if (!uploading) {
	mov	dptr,#_uploading
	movx	a,@dptr
	jnz	00141$
;	keyboards/ajazz/ak820/ak820_macro.c:147: busy_write(1);
	mov	dpl, #0x01
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar1
	push	ar0
	lcall	_busy_write
	pop	ar0
	pop	ar1
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_macro.c:148: if (!ak820_nvm_ok()) { ak820_nvm_end(); return false; }
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00141$
	lcall	_ak820_nvm_end
	mov	dpl, #0x00
	ret
00141$:
;	keyboards/ajazz/ak820/ak820_macro.c:150: ak820_eeprom_write_block_xdata(data, (void *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset), size);
	mov	dptr,#_ak820_macro_write_offset_10000_99
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	add	a,#0x08
	mov	r3,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
	push	ar1
	push	ar0
	lcall	_ak820_eeprom_write_block_xdata
;	keyboards/ajazz/ak820/ak820_macro.c:151: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
	pop	ar0
	pop	ar1
;	keyboards/ajazz/ak820/ak820_macro.c:152: if (complete && ak820_nvm_ok()) commit_length(end);
	mov	a,_ak820_macro_write_sloc0_1_0
	jz	00143$
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00143$
	mov	dpl, r0
	mov	dph, r1
	push	ar1
	push	ar0
	lcall	_commit_length
	pop	ar0
	pop	ar1
00143$:
;	keyboards/ajazz/ak820/ak820_macro.c:153: ak820_nvm_end();
	push	ar1
	push	ar0
	lcall	_ak820_nvm_end
	pop	ar0
	pop	ar1
;	keyboards/ajazz/ak820/ak820_macro.c:154: if (!ak820_nvm_ok()) return false;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00146$
	mov	dpl,a
	ret
00146$:
;	keyboards/ajazz/ak820/ak820_macro.c:155: covered = end;
	mov	dptr,#_covered
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:156: parsed.terminated = next.terminated;
	mov	dptr,#_ak820_macro_write_next_10000_100
	movx	a,@dptr
	mov	dptr,#_parsed
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:157: parsed.arguments = next.arguments;
	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
	movx	a,@dptr
	mov	dptr,#(_parsed + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:158: uploading = !complete;
	mov	dptr,#_uploading
	mov	a,_ak820_macro_write_sloc0_1_0
	cjne	a,#0x01,00399$
00399$:
	clr	a
	rlc	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_macro.c:159: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_macro.c:160: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_macro_reset'
;------------------------------------------------------------
;i             Allocated with name '_ak820_macro_reset_i_10000_127'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_macro.c:162: bool ak820_macro_reset(void) {
;	-----------------------------------------
;	 function ak820_macro_reset
;	-----------------------------------------
_ak820_macro_reset:
;	keyboards/ajazz/ak820/ak820_macro.c:164: ak820_nvm_begin();
	lcall	_ak820_nvm_begin
;	keyboards/ajazz/ak820/ak820_macro.c:165: busy_write(1);
	mov	dpl, #0x01
	lcall	_busy_write
;	keyboards/ajazz/ak820/ak820_macro.c:166: if (ak820_nvm_ok()) {
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00105$
;	keyboards/ajazz/ak820/ak820_macro.c:167: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
	mov	r6,#0x00
	mov	r7,#0x00
00106$:
;	keyboards/ajazz/ak820/ak820_macro.c:168: eeprom_update_byte((uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + i), 0);
	mov	ar4,r6
	mov	ar5,r7
	mov	a,#0x08
	add	a, r5
	mov	r5,a
	mov	r3,#0x00
	mov	dptr,#_eeprom_update_byte_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	mov	b, r3
	lcall	_eeprom_update_byte
;	keyboards/ajazz/ak820/ak820_macro.c:167: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
	inc	r6
	cjne	r6,#0x00,00140$
	inc	r7
00140$:
	mov	ar4,r6
	mov	ar5,r7
	clr	c
	mov	a,r4
	subb	a,#0x10
	mov	a,r5
	subb	a,#0x00
	jc	00106$
;	keyboards/ajazz/ak820/ak820_macro.c:169: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	keyboards/ajazz/ak820/ak820_macro.c:170: if (ak820_nvm_ok()) commit_length(DYNAMIC_KEYMAP_MACRO_COUNT);
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jz	00105$
	mov	dptr,#0x0010
	lcall	_commit_length
00105$:
;	keyboards/ajazz/ak820/ak820_macro.c:172: ak820_nvm_end();
	lcall	_ak820_nvm_end
;	keyboards/ajazz/ak820/ak820_macro.c:173: ak820_macro_init();
	lcall	_ak820_macro_init
;	keyboards/ajazz/ak820/ak820_macro.c:174: return ak820_nvm_ok();
;	keyboards/ajazz/ak820/ak820_macro.c:175: }
	ljmp	_ak820_nvm_ok
	.area AK820LOW(CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
