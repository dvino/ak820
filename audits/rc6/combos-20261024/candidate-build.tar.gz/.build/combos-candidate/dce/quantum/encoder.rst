                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoder
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _encoder_wait_pullup_charge
                                     12 	.globl _tap_code_delay
                                     13 	.globl _action_exec
                                     14 	.globl _is_keyboard_master
                                     15 	.globl _timer_read
                                     16 	.globl _mDelayuS
                                     17 	.globl _readPin
                                     18 	.globl _pinModeInputHighQMK
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _encoder_init
                                    263 	.globl _encoder_read
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000B47                        550 _thisCount:
      000B47                        551 	.ds 1
      000B48                        552 _encoder_exec_mapping_PARM_2:
      000B48                        553 	.ds 1
      000B49                        554 _encoder_exec_mapping_index_10000_165:
      000B49                        555 	.ds 1
      000B4A                        556 _encoder_exec_mapping_dummy_event_30000_168:
      000B4A                        557 	.ds 6
      000B50                        558 _encoder_exec_mapping_dummy_event_30000_169:
      000B50                        559 	.ds 6
      000B56                        560 _encoder_exec_mapping_dummy_event_30000_171:
      000B56                        561 	.ds 6
      000B5C                        562 _encoder_exec_mapping_dummy_event_30000_172:
      000B5C                        563 	.ds 6
      000B62                        564 _encoder_update_PARM_2:
      000B62                        565 	.ds 1
      000B63                        566 _encoder_update_index_10000_173:
      000B63                        567 	.ds 1
      000B64                        568 _encoder_update_changed_10000_174:
      000B64                        569 	.ds 1
      000B65                        570 _encoder_read_changed_10000_180:
      000B65                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000DFB                        580 _encoders_pad_a:
      000DFB                        581 	.ds 1
      000DFC                        582 _encoders_pad_b:
      000DFC                        583 	.ds 1
      000DFD                        584 _encoder_LUT:
      000DFD                        585 	.ds 16
      000E0D                        586 _encoder_state:
      000E0D                        587 	.ds 1
      000E0E                        588 _encoder_pulses:
      000E0E                        589 	.ds 1
      000E0F                        590 _encoder_value:
      000E0F                        591 	.ds 1
                                    592 	.area HOME    (CODE)
                                    593 	.area GSINIT0 (CODE)
                                    594 	.area GSINIT1 (CODE)
                                    595 	.area GSINIT2 (CODE)
                                    596 	.area GSINIT3 (CODE)
                                    597 	.area GSINIT4 (CODE)
                                    598 	.area GSINIT5 (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area CSEG    (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; global & static initialisations
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area GSINIT  (CODE)
                                    607 	.area GSFINAL (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 ;--------------------------------------------------------
                                    610 ; Home
                                    611 ;--------------------------------------------------------
                                    612 	.area HOME    (CODE)
                                    613 	.area HOME    (CODE)
                                    614 ;--------------------------------------------------------
                                    615 ; code
                                    616 ;--------------------------------------------------------
                                    617 	.area CSEG    (CODE)
                                    618 ;------------------------------------------------------------
                                    619 ;Allocation info for local variables in function 'encoder_wait_pullup_charge'
                                    620 ;------------------------------------------------------------
                                    621 ;i             Allocated with name '_encoder_wait_pullup_charge_i_30000_146'
                                    622 ;------------------------------------------------------------
                                    623 ;	quantum/encoder.c:77: __attribute__((weak)) void encoder_wait_pullup_charge(void) {
                                    624 ;	-----------------------------------------
                                    625 ;	 function encoder_wait_pullup_charge
                                    626 ;	-----------------------------------------
      009108                        627 _encoder_wait_pullup_charge:
                           000007   628 	ar7 = 0x07
                           000006   629 	ar6 = 0x06
                           000005   630 	ar5 = 0x05
                           000004   631 	ar4 = 0x04
                           000003   632 	ar3 = 0x03
                           000002   633 	ar2 = 0x02
                           000001   634 	ar1 = 0x01
                           000000   635 	ar0 = 0x00
                                    636 ;	quantum/encoder.c:78: wait_us(100);
      009108 7F 64            [12]  637 	mov	r7,#0x64
      00910A                        638 00106$:
      00910A EF               [12]  639 	mov	a,r7
      00910B 60 0D            [24]  640 	jz	00108$
      00910D 90 00 01         [24]  641 	mov	dptr,#0x0001
      009110 C0 07            [24]  642 	push	ar7
      009112 12 58 7C         [24]  643 	lcall	_mDelayuS
      009115 D0 07            [24]  644 	pop	ar7
      009117 1F               [12]  645 	dec	r7
      009118 80 F0            [24]  646 	sjmp	00106$
      00911A                        647 00108$:
                                    648 ;	quantum/encoder.c:79: }
      00911A 22               [24]  649 	ret
                                    650 ;------------------------------------------------------------
                                    651 ;Allocation info for local variables in function 'encoder_update_user'
                                    652 ;------------------------------------------------------------
                                    653 ;clockwise     Allocated with name '_encoder_update_user_PARM_2'
                                    654 ;index         Allocated with name '_encoder_update_user_index_10000_148'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/encoder.c:81: __attribute__((weak)) bool encoder_update_user(uint8_t index, bool clockwise) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function encoder_init
                                    659 ;	-----------------------------------------
      00911B                        660 _encoder_init:
                                    661 ;	quantum/encoder.c:122: thisCount                = NUM_ENCODERS;
      00911B 90 0B 47         [24]  662 	mov	dptr,#_thisCount
      00911E 74 01            [12]  663 	mov	a,#0x01
      009120 F0               [24]  664 	movx	@dptr,a
                                    665 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      009121 7F 00            [12]  666 	mov	r7,#0x00
      009123                        667 00104$:
      009123 12 93 D1         [24]  668 	lcall	_ak820_outline_0069
      009126 50 17            [24]  669 	jnc	00101$
                                    670 ;	quantum/encoder.c:166: setPinInputHigh(encoders_pad_a[i]);
      009128 12 93 B5         [24]  671 	lcall	_ak820_outline_0029
      00912B C0 07            [24]  672 	push	ar7
      00912D 12 57 3E         [24]  673 	lcall	_pinModeInputHighQMK
      009130 D0 07            [24]  674 	pop	ar7
                                    675 ;	quantum/encoder.c:167: setPinInputHigh(encoders_pad_b[i]);
      009132 12 93 C3         [24]  676 	lcall	_ak820_outline_0030
      009135 C0 07            [24]  677 	push	ar7
      009137 12 57 3E         [24]  678 	lcall	_pinModeInputHighQMK
      00913A D0 07            [24]  679 	pop	ar7
                                    680 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      00913C 0F               [12]  681 	inc	r7
      00913D 80 E4            [24]  682 	sjmp	00104$
      00913F                        683 00101$:
                                    684 ;	quantum/encoder.c:169: encoder_wait_pullup_charge();
      00913F 12 91 08         [24]  685 	lcall	_encoder_wait_pullup_charge
                                    686 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      009142 7F 00            [12]  687 	mov	r7,#0x00
      009144                        688 00107$:
      009144 12 93 D1         [24]  689 	lcall	_ak820_outline_0069
      009147 50 24            [24]  690 	jnc	00109$
                                    691 ;	quantum/encoder.c:171: encoder_state[i] = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009149 EF               [12]  692 	mov	a,r7
      00914A 24 0D            [12]  693 	add	a, #_encoder_state
      00914C FD               [12]  694 	mov	r5,a
      00914D E4               [12]  695 	clr	a
      00914E 34 0E            [12]  696 	addc	a, #(_encoder_state >> 8)
      009150 FE               [12]  697 	mov	r6,a
      009151 12 93 B5         [24]  698 	lcall	_ak820_outline_0029
      009154 12 57 8A         [24]  699 	lcall	_readPin
      009157 AC 82            [24]  700 	mov	r4, dpl
      009159 12 93 C3         [24]  701 	lcall	_ak820_outline_0030
      00915C 12 57 8A         [24]  702 	lcall	_readPin
      00915F E5 82            [12]  703 	mov	a,dpl
      009161 25 82            [12]  704 	add	a,dpl
      009163 42 04            [12]  705 	orl	ar4,a
      009165 12 43 F4         [24]  706 	lcall	_ak820_outline_0012
      009168 EC               [12]  707 	mov	a,r4
      009169 F0               [24]  708 	movx	@dptr,a
                                    709 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      00916A 0F               [12]  710 	inc	r7
      00916B 80 D7            [24]  711 	sjmp	00107$
      00916D                        712 00109$:
                                    713 ;	quantum/encoder.c:173: }
      00916D 22               [24]  714 	ret
                                    715 ;------------------------------------------------------------
                                    716 ;Allocation info for local variables in function 'encoder_exec_mapping'
                                    717 ;------------------------------------------------------------
                                    718 ;clockwise     Allocated with name '_encoder_exec_mapping_PARM_2'
                                    719 ;index         Allocated with name '_encoder_exec_mapping_index_10000_165'
                                    720 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_168'
                                    721 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_169'
                                    722 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_171'
                                    723 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_172'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/encoder.c:176: static void encoder_exec_mapping(uint8_t index, bool clockwise) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function encoder_exec_mapping
                                    728 ;	-----------------------------------------
      00916E                        729 _encoder_exec_mapping:
      00916E E5 82            [12]  730 	mov	a,dpl
      009170 90 0B 49         [24]  731 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      009173 F0               [24]  732 	movx	@dptr,a
                                    733 ;	quantum/encoder.c:179: if (clockwise) {
      009174 90 0B 48         [24]  734 	mov	dptr,#_encoder_exec_mapping_PARM_2
      009177 E0               [24]  735 	movx	a,@dptr
      009178 FF               [12]  736 	mov	r7,a
      009179 E0               [24]  737 	movx	a,@dptr
      00917A 60 47            [24]  738 	jz	00102$
                                    739 ;	quantum/encoder.c:180: MAKE_ENCODER_CW_EVENT(index, true);
      00917C 90 0B 49         [24]  740 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      00917F E0               [24]  741 	movx	a,@dptr
      009180 90 0B 4A         [24]  742 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_168
      009183 F0               [24]  743 	movx	@dptr,a
      009184 90 0B 4B         [24]  744 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0001)
      009187 74 FD            [12]  745 	mov	a,#0xfd
      009189 F0               [24]  746 	movx	@dptr,a
      00918A 12 48 CB         [24]  747 	lcall	_timer_read
      00918D AD 82            [24]  748 	mov	r5, dpl
      00918F AE 83            [24]  749 	mov	r6, dph
      009191 90 0B 4C         [24]  750 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0002)
      009194 12 44 56         [24]  751 	lcall	_ak820_outline_0071
      009197 90 0B 4E         [24]  752 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0004)
      00919A 74 02            [12]  753 	mov	a,#0x02
      00919C F0               [24]  754 	movx	@dptr,a
      00919D 90 0B 4F         [24]  755 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0005)
      0091A0 14               [12]  756 	dec	a
      0091A1 F0               [24]  757 	movx	@dptr,a
                                    758 ;	quantum/encoder.c:181: action_exec(dummy_event);
      0091A2 90 0D B3         [24]  759 	mov	dptr,#___memcpy_PARM_2
      0091A5 74 4A            [12]  760 	mov	a,#_encoder_exec_mapping_dummy_event_30000_168
      0091A7 F0               [24]  761 	movx	@dptr,a
      0091A8 74 0B            [12]  762 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_168 >> 8)
      0091AA A3               [24]  763 	inc	dptr
      0091AB 12 4E 60         [24]  764 	lcall	_ak820_outline_0003
      0091AE 12 93 E6         [24]  765 	lcall	_ak820_outline_0122
      0091B1 12 4E 60         [24]  766 	lcall	_ak820_outline_0003
      0091B4 12 93 EC         [24]  767 	lcall	_ak820_outline_0123
      0091B7 C0 07            [24]  768 	push	ar7
      0091B9 12 BD 3B         [24]  769 	lcall	___memcpy
      0091BC 12 70 A5         [24]  770 	lcall	_action_exec
      0091BF D0 07            [24]  771 	pop	ar7
      0091C1 80 46            [24]  772 	sjmp	00103$
      0091C3                        773 00102$:
                                    774 ;	quantum/encoder.c:183: MAKE_ENCODER_CCW_EVENT(index, true);
      0091C3 90 0B 49         [24]  775 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      0091C6 E0               [24]  776 	movx	a,@dptr
      0091C7 90 0B 50         [24]  777 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_169
      0091CA F0               [24]  778 	movx	@dptr,a
      0091CB 90 0B 51         [24]  779 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0001)
      0091CE 74 FC            [12]  780 	mov	a,#0xfc
      0091D0 F0               [24]  781 	movx	@dptr,a
      0091D1 12 48 CB         [24]  782 	lcall	_timer_read
      0091D4 AD 82            [24]  783 	mov	r5, dpl
      0091D6 AE 83            [24]  784 	mov	r6, dph
      0091D8 90 0B 52         [24]  785 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0002)
      0091DB 12 44 56         [24]  786 	lcall	_ak820_outline_0071
      0091DE 90 0B 54         [24]  787 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0004)
      0091E1 74 03            [12]  788 	mov	a,#0x03
      0091E3 F0               [24]  789 	movx	@dptr,a
      0091E4 90 0B 55         [24]  790 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0005)
      0091E7 74 01            [12]  791 	mov	a,#0x01
      0091E9 F0               [24]  792 	movx	@dptr,a
                                    793 ;	quantum/encoder.c:184: action_exec(dummy_event);
      0091EA 90 0D B3         [24]  794 	mov	dptr,#___memcpy_PARM_2
      0091ED 74 50            [12]  795 	mov	a,#_encoder_exec_mapping_dummy_event_30000_169
      0091EF F0               [24]  796 	movx	@dptr,a
      0091F0 74 0B            [12]  797 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_169 >> 8)
      0091F2 A3               [24]  798 	inc	dptr
      0091F3 12 4E 60         [24]  799 	lcall	_ak820_outline_0003
      0091F6 12 93 E6         [24]  800 	lcall	_ak820_outline_0122
      0091F9 12 4E 60         [24]  801 	lcall	_ak820_outline_0003
      0091FC 12 93 EC         [24]  802 	lcall	_ak820_outline_0123
      0091FF C0 07            [24]  803 	push	ar7
      009201 12 BD 3B         [24]  804 	lcall	___memcpy
      009204 12 70 A5         [24]  805 	lcall	_action_exec
      009207 D0 07            [24]  806 	pop	ar7
      009209                        807 00103$:
                                    808 ;	quantum/encoder.c:191: if (clockwise) {
      009209 EF               [12]  809 	mov	a,r7
      00920A 60 41            [24]  810 	jz	00105$
                                    811 ;	quantum/encoder.c:192: MAKE_ENCODER_CW_EVENT(index, false);
      00920C 90 0B 49         [24]  812 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      00920F E0               [24]  813 	movx	a,@dptr
      009210 90 0B 56         [24]  814 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_171
      009213 F0               [24]  815 	movx	@dptr,a
      009214 90 0B 57         [24]  816 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0001)
      009217 74 FD            [12]  817 	mov	a,#0xfd
      009219 F0               [24]  818 	movx	@dptr,a
      00921A 12 48 CB         [24]  819 	lcall	_timer_read
      00921D 12 44 1D         [24]  820 	lcall	_ak820_outline_0027
      009220 90 0B 58         [24]  821 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0002)
      009223 EE               [12]  822 	mov	a,r6
      009224 12 43 E5         [24]  823 	lcall	_ak820_outline_0007
      009227 90 0B 5A         [24]  824 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0004)
      00922A 74 02            [12]  825 	mov	a,#0x02
      00922C F0               [24]  826 	movx	@dptr,a
      00922D 90 0B 5B         [24]  827 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0005)
      009230 E4               [12]  828 	clr	a
      009231 F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/encoder.c:193: action_exec(dummy_event);
      009232 90 0D B3         [24]  831 	mov	dptr,#___memcpy_PARM_2
      009235 74 56            [12]  832 	mov	a,#_encoder_exec_mapping_dummy_event_30000_171
      009237 F0               [24]  833 	movx	@dptr,a
      009238 74 0B            [12]  834 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_171 >> 8)
      00923A A3               [24]  835 	inc	dptr
      00923B 12 4E 60         [24]  836 	lcall	_ak820_outline_0003
      00923E 12 93 E6         [24]  837 	lcall	_ak820_outline_0122
      009241 12 4E 60         [24]  838 	lcall	_ak820_outline_0003
      009244 12 93 EC         [24]  839 	lcall	_ak820_outline_0123
      009247 12 BD 3B         [24]  840 	lcall	___memcpy
      00924A 02 70 A5         [24]  841 	ljmp	_action_exec
      00924D                        842 00105$:
                                    843 ;	quantum/encoder.c:195: MAKE_ENCODER_CCW_EVENT(index, false);
      00924D 90 0B 49         [24]  844 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      009250 E0               [24]  845 	movx	a,@dptr
      009251 90 0B 5C         [24]  846 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_172
      009254 F0               [24]  847 	movx	@dptr,a
      009255 90 0B 5D         [24]  848 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0001)
      009258 74 FC            [12]  849 	mov	a,#0xfc
      00925A F0               [24]  850 	movx	@dptr,a
      00925B 12 48 CB         [24]  851 	lcall	_timer_read
      00925E 12 44 1D         [24]  852 	lcall	_ak820_outline_0027
      009261 90 0B 5E         [24]  853 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0002)
      009264 EE               [12]  854 	mov	a,r6
      009265 12 43 E5         [24]  855 	lcall	_ak820_outline_0007
      009268 90 0B 60         [24]  856 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0004)
      00926B 74 03            [12]  857 	mov	a,#0x03
      00926D F0               [24]  858 	movx	@dptr,a
      00926E 90 0B 61         [24]  859 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0005)
      009271 E4               [12]  860 	clr	a
      009272 F0               [24]  861 	movx	@dptr,a
                                    862 ;	quantum/encoder.c:196: action_exec(dummy_event);
      009273 90 0D B3         [24]  863 	mov	dptr,#___memcpy_PARM_2
      009276 74 5C            [12]  864 	mov	a,#_encoder_exec_mapping_dummy_event_30000_172
      009278 F0               [24]  865 	movx	@dptr,a
      009279 74 0B            [12]  866 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_172 >> 8)
      00927B A3               [24]  867 	inc	dptr
      00927C 12 4E 60         [24]  868 	lcall	_ak820_outline_0003
      00927F 12 93 E6         [24]  869 	lcall	_ak820_outline_0122
      009282 12 4E 60         [24]  870 	lcall	_ak820_outline_0003
      009285 12 93 EC         [24]  871 	lcall	_ak820_outline_0123
      009288 12 BD 3B         [24]  872 	lcall	___memcpy
                                    873 ;	quantum/encoder.c:201: }
      00928B 02 70 A5         [24]  874 	ljmp	_action_exec
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'encoder_update'
                                    877 ;------------------------------------------------------------
                                    878 ;state         Allocated with name '_encoder_update_PARM_2'
                                    879 ;index         Allocated with name '_encoder_update_index_10000_173'
                                    880 ;changed       Allocated with name '_encoder_update_changed_10000_174'
                                    881 ;i             Allocated with name '_encoder_update_i_10000_174'
                                    882 ;resolution    Allocated with name '_encoder_update_resolution_10000_174'
                                    883 ;------------------------------------------------------------
                                    884 ;	quantum/encoder.c:204: static bool encoder_update(uint8_t index, uint8_t state) {
                                    885 ;	-----------------------------------------
                                    886 ;	 function encoder_update
                                    887 ;	-----------------------------------------
      00928E                        888 _encoder_update:
      00928E E5 82            [12]  889 	mov	a,dpl
      009290 90 0B 63         [24]  890 	mov	dptr,#_encoder_update_index_10000_173
      009293 F0               [24]  891 	movx	@dptr,a
                                    892 ;	quantum/encoder.c:205: bool    changed = false;
      009294 90 0B 64         [24]  893 	mov	dptr,#_encoder_update_changed_10000_174
      009297 E4               [12]  894 	clr	a
      009298 F0               [24]  895 	movx	@dptr,a
                                    896 ;	quantum/encoder.c:206: uint8_t i       = index;
      009299 90 0B 63         [24]  897 	mov	dptr,#_encoder_update_index_10000_173
      00929C E0               [24]  898 	movx	a,@dptr
                                    899 ;	quantum/encoder.c:217: encoder_pulses[i] += encoder_LUT[state & 0xF];
      00929D FF               [12]  900 	mov	r7,a
      00929E 24 0E            [12]  901 	add	a, #_encoder_pulses
      0092A0 FD               [12]  902 	mov	r5,a
      0092A1 E4               [12]  903 	clr	a
      0092A2 34 0E            [12]  904 	addc	a, #(_encoder_pulses >> 8)
      0092A4 FE               [12]  905 	mov	r6,a
      0092A5 12 43 F4         [24]  906 	lcall	_ak820_outline_0012
      0092A8 E0               [24]  907 	movx	a,@dptr
      0092A9 FC               [12]  908 	mov	r4,a
      0092AA 90 0B 62         [24]  909 	mov	dptr,#_encoder_update_PARM_2
      0092AD E0               [24]  910 	movx	a,@dptr
      0092AE FB               [12]  911 	mov	r3,a
      0092AF 74 0F            [12]  912 	mov	a,#0x0f
      0092B1 5B               [12]  913 	anl	a,r3
      0092B2 24 FD            [12]  914 	add	a, #_encoder_LUT
      0092B4 F5 82            [12]  915 	mov	dpl,a
      0092B6 E4               [12]  916 	clr	a
      0092B7 34 0D            [12]  917 	addc	a,#(_encoder_LUT >> 8)
      0092B9 F5 83            [12]  918 	mov	dph,a
      0092BB E0               [24]  919 	movx	a,@dptr
      0092BC 2C               [12]  920 	add	a, r4
      0092BD FC               [12]  921 	mov	r4,a
      0092BE 12 43 F4         [24]  922 	lcall	_ak820_outline_0012
      0092C1 F0               [24]  923 	movx	@dptr,a
                                    924 ;	quantum/encoder.c:223: if (encoder_pulses[i] >= resolution) {
      0092C2 EC               [12]  925 	mov	a,r4
      0092C3 33               [12]  926 	rlc	a
      0092C4 95 E0            [12]  927 	subb	a,acc
      0092C6 FB               [12]  928 	mov	r3,a
      0092C7 C3               [12]  929 	clr	c
      0092C8 EC               [12]  930 	mov	a,r4
      0092C9 94 02            [12]  931 	subb	a,#0x02
      0092CB EB               [12]  932 	mov	a,r3
      0092CC 64 80            [12]  933 	xrl	a,#0x80
      0092CE 94 80            [12]  934 	subb	a,#0x80
      0092D0 40 23            [24]  935 	jc	00102$
                                    936 ;	quantum/encoder.c:226: encoder_value[index]++;
      0092D2 EF               [12]  937 	mov	a,r7
      0092D3 24 0F            [12]  938 	add	a, #_encoder_value
      0092D5 FB               [12]  939 	mov	r3,a
      0092D6 E4               [12]  940 	clr	a
      0092D7 34 0E            [12]  941 	addc	a, #(_encoder_value >> 8)
      0092D9 FC               [12]  942 	mov	r4,a
      0092DA 12 43 F9         [24]  943 	lcall	_ak820_outline_0014
      0092DD E0               [24]  944 	movx	a,@dptr
      0092DE FA               [12]  945 	mov	r2,a
      0092DF 0A               [12]  946 	inc	r2
      0092E0 12 43 F9         [24]  947 	lcall	_ak820_outline_0014
      0092E3 12 93 DA         [24]  948 	lcall	_ak820_outline_0082
                                    949 ;	quantum/encoder.c:227: changed = true;
                                    950 ;	quantum/encoder.c:232: encoder_exec_mapping(index, ENCODER_COUNTER_CLOCKWISE);
      0092E6 E4               [12]  951 	clr	a
      0092E7 F0               [24]  952 	movx	@dptr,a
      0092E8 8F 82            [24]  953 	mov	dpl, r7
      0092EA C0 06            [24]  954 	push	ar6
      0092EC C0 05            [24]  955 	push	ar5
      0092EE 12 91 6E         [24]  956 	lcall	_encoder_exec_mapping
      0092F1 D0 05            [24]  957 	pop	ar5
      0092F3 D0 06            [24]  958 	pop	ar6
      0092F5                        959 00102$:
                                    960 ;	quantum/encoder.c:241: if (encoder_pulses[i] <= -resolution) { // direction is arbitrary here, but this clockwise
      0092F5 12 43 F4         [24]  961 	lcall	_ak820_outline_0012
      0092F8 E0               [24]  962 	movx	a,@dptr
      0092F9 FF               [12]  963 	mov	r7,a
      0092FA 33               [12]  964 	rlc	a
      0092FB 95 E0            [12]  965 	subb	a,acc
      0092FD FC               [12]  966 	mov	r4,a
      0092FE C3               [12]  967 	clr	c
      0092FF 74 FE            [12]  968 	mov	a,#0xfe
      009301 9F               [12]  969 	subb	a,r7
      009302 74 7F            [12]  970 	mov	a,#(0xff ^ 0x80)
      009304 8C F0            [24]  971 	mov	b,r4
      009306 63 F0 80         [24]  972 	xrl	b,#0x80
      009309 95 F0            [12]  973 	subb	a,b
      00930B 40 26            [24]  974 	jc	00104$
                                    975 ;	free result
                                    976 ;	quantum/encoder.c:243: encoder_value[index]--;
      00930D 90 0B 63         [24]  977 	mov	dptr,#_encoder_update_index_10000_173
      009310 E0               [24]  978 	movx	a,@dptr
      009311 FF               [12]  979 	mov	r7,a
      009312 24 0F            [12]  980 	add	a, #_encoder_value
      009314 FB               [12]  981 	mov	r3,a
      009315 E4               [12]  982 	clr	a
      009316 34 0E            [12]  983 	addc	a, #(_encoder_value >> 8)
      009318 FC               [12]  984 	mov	r4,a
      009319 12 43 F9         [24]  985 	lcall	_ak820_outline_0014
      00931C E0               [24]  986 	movx	a,@dptr
      00931D FA               [12]  987 	mov	r2,a
      00931E 1A               [12]  988 	dec	r2
      00931F 12 43 F9         [24]  989 	lcall	_ak820_outline_0014
      009322 12 93 DA         [24]  990 	lcall	_ak820_outline_0082
                                    991 ;	quantum/encoder.c:244: changed = true;
                                    992 ;	quantum/encoder.c:249: encoder_exec_mapping(index, ENCODER_CLOCKWISE);
      009325 F0               [24]  993 	movx	@dptr,a
      009326 8F 82            [24]  994 	mov	dpl, r7
      009328 C0 06            [24]  995 	push	ar6
      00932A C0 05            [24]  996 	push	ar5
      00932C 12 91 6E         [24]  997 	lcall	_encoder_exec_mapping
      00932F D0 05            [24]  998 	pop	ar5
      009331 D0 06            [24]  999 	pop	ar6
      009333                       1000 00104$:
                                   1001 ;	quantum/encoder.c:254: encoder_pulses[i] %= resolution;
      009333 12 43 F4         [24] 1002 	lcall	_ak820_outline_0012
      009336 E0               [24] 1003 	movx	a,@dptr
      009337 A2 E7            [12] 1004 	mov	c,acc.7
      009339 54 01            [12] 1005 	anl	a,#0x01
      00933B 60 04            [24] 1006 	jz	00123$
      00933D 50 02            [24] 1007 	jnc	00123$
      00933F 44 FE            [12] 1008 	orl	a,#0xfe
      009341                       1009 00123$:
      009341 12 43 F4         [24] 1010 	lcall	_ak820_outline_0012
      009344 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/encoder.c:259: return changed;
      009345 90 0B 64         [24] 1013 	mov	dptr,#_encoder_update_changed_10000_174
      009348 E0               [24] 1014 	movx	a,@dptr
                                   1015 ;	quantum/encoder.c:260: }
      009349 F5 82            [12] 1016 	mov	dpl,a
      00934B 22               [24] 1017 	ret
                                   1018 ;------------------------------------------------------------
                                   1019 ;Allocation info for local variables in function 'encoder_read'
                                   1020 ;------------------------------------------------------------
                                   1021 ;changed       Allocated with name '_encoder_read_changed_10000_180'
                                   1022 ;i             Allocated with name '_encoder_read_i_20000_181'
                                   1023 ;new_status    Allocated with name '_encoder_read_new_status_30000_182'
                                   1024 ;------------------------------------------------------------
                                   1025 ;	quantum/encoder.c:262: bool encoder_read(void) {
                                   1026 ;	-----------------------------------------
                                   1027 ;	 function encoder_read
                                   1028 ;	-----------------------------------------
      00934C                       1029 _encoder_read:
                                   1030 ;	quantum/encoder.c:263: bool changed = false;
      00934C 90 0B 65         [24] 1031 	mov	dptr,#_encoder_read_changed_10000_180
      00934F E4               [12] 1032 	clr	a
      009350 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      009351 FF               [12] 1035 	mov	r7,a
      009352                       1036 00105$:
      009352 12 93 D1         [24] 1037 	lcall	_ak820_outline_0069
      009355 50 57            [24] 1038 	jnc	00103$
                                   1039 ;	quantum/encoder.c:265: uint8_t new_status = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009357 12 93 B5         [24] 1040 	lcall	_ak820_outline_0029
      00935A 12 57 8A         [24] 1041 	lcall	_readPin
      00935D AE 82            [24] 1042 	mov	r6, dpl
      00935F 12 93 C3         [24] 1043 	lcall	_ak820_outline_0030
      009362 12 57 8A         [24] 1044 	lcall	_readPin
      009365 E5 82            [12] 1045 	mov	a,dpl
      009367 25 82            [12] 1046 	add	a,dpl
      009369 42 06            [12] 1047 	orl	ar6,a
                                   1048 ;	quantum/encoder.c:266: if ((encoder_state[i] & 0x3) != new_status) {
      00936B EF               [12] 1049 	mov	a,r7
      00936C 24 0D            [12] 1050 	add	a, #_encoder_state
      00936E FC               [12] 1051 	mov	r4,a
      00936F E4               [12] 1052 	clr	a
      009370 34 0E            [12] 1053 	addc	a, #(_encoder_state >> 8)
      009372 FD               [12] 1054 	mov	r5,a
      009373 12 43 EF         [24] 1055 	lcall	_ak820_outline_0011
      009376 E0               [24] 1056 	movx	a,@dptr
      009377 FB               [12] 1057 	mov	r3,a
      009378 FA               [12] 1058 	mov	r2,a
      009379 53 02 03         [24] 1059 	anl	ar2,#0x03
      00937C 8E 01            [24] 1060 	mov	ar1,r6
      00937E EA               [12] 1061 	mov	a,r2
      00937F B5 01 02         [24] 1062 	cjne	a,ar1,00132$
      009382 80 27            [24] 1063 	sjmp	00106$
      009384                       1064 00132$:
                                   1065 ;	quantum/encoder.c:267: encoder_state[i] <<= 2;
      009384 EB               [12] 1066 	mov	a,r3
      009385 2B               [12] 1067 	add	a,r3
      009386 25 E0            [12] 1068 	add	a,acc
      009388 FB               [12] 1069 	mov	r3,a
      009389 12 43 EF         [24] 1070 	lcall	_ak820_outline_0011
      00938C F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	quantum/encoder.c:268: encoder_state[i] |= new_status;
      00938D EB               [12] 1073 	mov	a,r3
      00938E 42 06            [12] 1074 	orl	ar6,a
      009390 12 43 EF         [24] 1075 	lcall	_ak820_outline_0011
      009393 EE               [12] 1076 	mov	a,r6
      009394 F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	quantum/encoder.c:269: changed |= encoder_update(i, encoder_state[i]);
      009395 90 0B 62         [24] 1079 	mov	dptr,#_encoder_update_PARM_2
      009398 EE               [12] 1080 	mov	a,r6
      009399 F0               [24] 1081 	movx	@dptr,a
      00939A 8F 82            [24] 1082 	mov	dpl, r7
      00939C C0 07            [24] 1083 	push	ar7
      00939E 12 92 8E         [24] 1084 	lcall	_encoder_update
      0093A1 AE 82            [24] 1085 	mov	r6, dpl
      0093A3 D0 07            [24] 1086 	pop	ar7
      0093A5 90 0B 65         [24] 1087 	mov	dptr,#_encoder_read_changed_10000_180
      0093A8 E0               [24] 1088 	movx	a,@dptr
      0093A9 4E               [12] 1089 	orl	a,r6
      0093AA F0               [24] 1090 	movx	@dptr,a
      0093AB                       1091 00106$:
                                   1092 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      0093AB 0F               [12] 1093 	inc	r7
      0093AC 80 A4            [24] 1094 	sjmp	00105$
      0093AE                       1095 00103$:
                                   1096 ;	quantum/encoder.c:272: return changed;
      0093AE 90 0B 65         [24] 1097 	mov	dptr,#_encoder_read_changed_10000_180
      0093B1 E0               [24] 1098 	movx	a,@dptr
                                   1099 ;	quantum/encoder.c:273: }
      0093B2 F5 82            [12] 1100 	mov	dpl,a
      0093B4 22               [24] 1101 	ret
                                   1102 	.area CSEG    (CODE)
                                   1103 	.area CONST   (CODE)
                                   1104 	.area XINIT   (CODE)
      00C646                       1105 __xinit__encoders_pad_a:
      00C646 39                    1106 	.db #0x39	; 57	'9'
      00C647                       1107 __xinit__encoders_pad_b:
      00C647 38                    1108 	.db #0x38	; 56	'8'
      00C648                       1109 __xinit__encoder_LUT:
      00C648 00                    1110 	.db #0x00	;  0
      00C649 FF                    1111 	.db #0xff	; -1
      00C64A 01                    1112 	.db #0x01	;  1
      00C64B 00                    1113 	.db #0x00	;  0
      00C64C 01                    1114 	.db #0x01	;  1
      00C64D 00                    1115 	.db #0x00	;  0
      00C64E 00                    1116 	.db #0x00	;  0
      00C64F FF                    1117 	.db #0xff	; -1
      00C650 FF                    1118 	.db #0xff	; -1
      00C651 00                    1119 	.db #0x00	;  0
      00C652 00                    1120 	.db #0x00	;  0
      00C653 01                    1121 	.db #0x01	;  1
      00C654 00                    1122 	.db #0x00	;  0
      00C655 01                    1123 	.db #0x01	;  1
      00C656 FF                    1124 	.db #0xff	; -1
      00C657 00                    1125 	.db #0x00	;  0
      00C658                       1126 __xinit__encoder_state:
      00C658 00                    1127 	.db #0x00	; 0
      00C659                       1128 __xinit__encoder_pulses:
      00C659 00                    1129 	.db #0x00	;  0
      00C65A                       1130 __xinit__encoder_value:
      00C65A 00                    1131 	.db #0x00	; 0
                                   1132 	.area CABS    (ABS,CODE)
                                   1133 
                                   1134 ; Experimental exact instruction outlining.
                                   1135 	.globl _ak820_outline_0003
                                   1136 	.globl _ak820_outline_0007
                                   1137 	.globl _ak820_outline_0011
                                   1138 	.globl _ak820_outline_0012
                                   1139 	.globl _ak820_outline_0014
                                   1140 	.globl _ak820_outline_0027
                                   1141 	.globl _ak820_outline_0029
                                   1142 	.globl _ak820_outline_0030
                                   1143 	.globl _ak820_outline_0069
                                   1144 	.globl _ak820_outline_0071
                                   1145 	.globl _ak820_outline_0082
                                   1146 	.globl _ak820_outline_0122
                                   1147 	.globl _ak820_outline_0123
                                   1148 
                                   1149 	.area CSEG (CODE)
                                   1150 ; function ak820_outline_0029
      0093B5                       1151 _ak820_outline_0029:
      0093B5 EF               [12] 1152 	mov	a,r7
      0093B6 24 FB            [12] 1153 	add	a,#_encoders_pad_a
      0093B8 F5 82            [12] 1154 	mov	dpl,a
      0093BA E4               [12] 1155 	clr	a
      0093BB 34 0D            [12] 1156 	addc	a,#(_encoders_pad_a>>8)
      0093BD F5 83            [12] 1157 	mov	dph,a
      0093BF E0               [24] 1158 	movx	a,@dptr
      0093C0 F5 82            [12] 1159 	mov	dpl,a
      0093C2 22               [24] 1160 	ret
                                   1161 
                                   1162 	.area CSEG (CODE)
                                   1163 ; function ak820_outline_0030
      0093C3                       1164 _ak820_outline_0030:
      0093C3 EF               [12] 1165 	mov	a,r7
      0093C4 24 FC            [12] 1166 	add	a,#_encoders_pad_b
      0093C6 F5 82            [12] 1167 	mov	dpl,a
      0093C8 E4               [12] 1168 	clr	a
      0093C9 34 0D            [12] 1169 	addc	a,#(_encoders_pad_b>>8)
      0093CB F5 83            [12] 1170 	mov	dph,a
      0093CD E0               [24] 1171 	movx	a,@dptr
      0093CE F5 82            [12] 1172 	mov	dpl,a
      0093D0 22               [24] 1173 	ret
                                   1174 
                                   1175 	.area CSEG (CODE)
                                   1176 ; function ak820_outline_0069
      0093D1                       1177 _ak820_outline_0069:
      0093D1 90 0B 47         [24] 1178 	mov	dptr,#_thisCount
      0093D4 E0               [24] 1179 	movx	a,@dptr
      0093D5 FE               [12] 1180 	mov	r6,a
      0093D6 C3               [12] 1181 	clr	c
      0093D7 EF               [12] 1182 	mov	a,r7
      0093D8 9E               [12] 1183 	subb	a,r6
      0093D9 22               [24] 1184 	ret
                                   1185 
                                   1186 	.area CSEG (CODE)
                                   1187 ; function ak820_outline_0082
      0093DA                       1188 _ak820_outline_0082:
      0093DA EA               [12] 1189 	mov	a,r2
      0093DB F0               [24] 1190 	movx	@dptr,a
      0093DC 90 0B 64         [24] 1191 	mov	dptr,#_encoder_update_changed_10000_174
      0093DF 74 01            [12] 1192 	mov	a,#0x01
      0093E1 F0               [24] 1193 	movx	@dptr,a
      0093E2 90 0B 48         [24] 1194 	mov	dptr,#_encoder_exec_mapping_PARM_2
      0093E5 22               [24] 1195 	ret
                                   1196 
                                   1197 	.area CSEG (CODE)
                                   1198 ; function ak820_outline_0122
      0093E6                       1199 _ak820_outline_0122:
      0093E6 90 0D B6         [24] 1200 	mov	dptr,#___memcpy_PARM_3
      0093E9 74 06            [12] 1201 	mov	a,#0x06
      0093EB 22               [24] 1202 	ret
                                   1203 
                                   1204 	.area CSEG (CODE)
                                   1205 ; function ak820_outline_0123
      0093EC                       1206 _ak820_outline_0123:
      0093EC 90 08 07         [24] 1207 	mov	dptr,#_action_exec_PARM_1
      0093EF F5 F0            [12] 1208 	mov	b,a
      0093F1 22               [24] 1209 	ret
