                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _action_exec
                                     28 	.globl _print_set_sendchar
                                     29 	.globl _sendchar
                                     30 	.globl _led_task
                                     31 	.globl _led_init_ports
                                     32 	.globl _magic
                                     33 	.globl _matrix_print
                                     34 	.globl _matrix_get_row
                                     35 	.globl _matrix_scan
                                     36 	.globl _matrix_init
                                     37 	.globl _keyboard_post_init_user
                                     38 	.globl _timer_elapsed32
                                     39 	.globl _timer_read32
                                     40 	.globl _timer_read
                                     41 	.globl _timer_init
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _switch_events_PARM_3
                                    286 	.globl _switch_events_PARM_2
                                    287 	.globl _keyboard_post_init_kb
                                    288 	.globl _matrix_can_read
                                    289 	.globl _keyboard_setup
                                    290 	.globl _is_keyboard_master
                                    291 	.globl _housekeeping_task
                                    292 	.globl _keyboard_init
                                    293 	.globl _keyboard_task
                                    294 ;--------------------------------------------------------
                                    295 ; special function registers
                                    296 ;--------------------------------------------------------
                                    297 	.area RSEG    (ABS,DATA)
      000000                        298 	.org 0x0000
                           0000D0   299 _PSW	=	0x00d0
                           0000E0   300 _ACC	=	0x00e0
                           0000F0   301 _B	=	0x00f0
                           0000FD   302 _A_INV	=	0x00fd
                           000081   303 _SP	=	0x0081
                           000082   304 _DPL	=	0x0082
                           000083   305 _DPH	=	0x0083
                           0000A1   306 _SAFE_MOD	=	0x00a1
                           0000B1   307 _GLOBAL_CFG	=	0x00b1
                           000087   308 _PCON	=	0x0087
                           0000BA   309 _POWER_CFG	=	0x00ba
                           0000B9   310 _CLOCK_CFG	=	0x00b9
                           0000A9   311 _WAKE_CTRL	=	0x00a9
                           0000FE   312 _RESET_KEEP	=	0x00fe
                           0000FF   313 _WDOG_COUNT	=	0x00ff
                           0000A8   314 _IE	=	0x00a8
                           0000B8   315 _IP	=	0x00b8
                           0000E8   316 _IE_EX	=	0x00e8
                           0000E9   317 _IP_EX	=	0x00e9
                           0000B2   318 _GPIO_IE	=	0x00b2
                           008584   319 _ROM_ADDR	=	0x8584
                           000084   320 _ROM_ADDR_L	=	0x0084
                           000085   321 _ROM_ADDR_H	=	0x0085
                           008F8E   322 _ROM_DATA_HI	=	0x8f8e
                           00008E   323 _ROM_DATA_HL	=	0x008e
                           00008F   324 _ROM_DATA_HH	=	0x008f
                           000086   325 _ROM_CTRL	=	0x0086
                           000080   326 _P0	=	0x0080
                           0000C4   327 _P0_MOD_OC	=	0x00c4
                           0000C5   328 _P0_DIR_PU	=	0x00c5
                           000090   329 _P1	=	0x0090
                           000092   330 _P1_MOD_OC	=	0x0092
                           000093   331 _P1_DIR_PU	=	0x0093
                           0000A0   332 _P2	=	0x00a0
                           000094   333 _P2_MOD_OC	=	0x0094
                           000095   334 _P2_DIR_PU	=	0x0095
                           0000B0   335 _P3	=	0x00b0
                           000096   336 _P3_MOD_OC	=	0x0096
                           000097   337 _P3_DIR_PU	=	0x0097
                           0000C0   338 _P4	=	0x00c0
                           0000C2   339 _P4_MOD_OC	=	0x00c2
                           0000C3   340 _P4_DIR_PU	=	0x00c3
                           0000C1   341 _P4_LED_KEY	=	0x00c1
                           0000AA   342 _P5_IN	=	0x00aa
                           0000AB   343 _P5_OUT_PU	=	0x00ab
                           0000AC   344 _P5_DIR	=	0x00ac
                           0000AD   345 _P6_IN	=	0x00ad
                           0000AE   346 _P6_OUT_PU	=	0x00ae
                           0000AF   347 _P6_DIR	=	0x00af
                           0000F1   348 _P7	=	0x00f1
                           0000A2   349 _XBUS_AUX	=	0x00a2
                           000088   350 _TCON	=	0x0088
                           000089   351 _TMOD	=	0x0089
                           00008A   352 _TL0	=	0x008a
                           00008B   353 _TL1	=	0x008b
                           00008C   354 _TH0	=	0x008c
                           00008D   355 _TH1	=	0x008d
                           000098   356 _SCON	=	0x0098
                           000099   357 _SBUF	=	0x0099
                           0000C8   358 _T2CON	=	0x00c8
                           0000C9   359 _T2MOD	=	0x00c9
                           00CBCA   360 _RCAP2	=	0xcbca
                           0000CA   361 _RCAP2L	=	0x00ca
                           0000CB   362 _RCAP2H	=	0x00cb
                           00CDCC   363 _T2COUNT	=	0xcdcc
                           0000CC   364 _TL2	=	0x00cc
                           0000CD   365 _TH2	=	0x00cd
                           00CFCE   366 _T2CAP1	=	0xcfce
                           0000CE   367 _T2CAP1L	=	0x00ce
                           0000CF   368 _T2CAP1H	=	0x00cf
                           0000F8   369 _SPI0_STAT	=	0x00f8
                           0000F9   370 _SPI0_DATA	=	0x00f9
                           0000FA   371 _SPI0_CTRL	=	0x00fa
                           0000FB   372 _SPI0_CK_SE	=	0x00fb
                           0000FC   373 _SPI0_SETUP	=	0x00fc
                           0000BC   374 _SCON1	=	0x00bc
                           0000BD   375 _SBUF1	=	0x00bd
                           0000BE   376 _SBAUD1	=	0x00be
                           0000BF   377 _SIF1	=	0x00bf
                           0000B4   378 _SPI1_STAT	=	0x00b4
                           0000B5   379 _SPI1_DATA	=	0x00b5
                           0000B6   380 _SPI1_CTRL	=	0x00b6
                           0000B7   381 _SPI1_CK_SE	=	0x00b7
                           0000F3   382 _ADC_CTRL	=	0x00f3
                           00F5F4   383 _ADC_DAT	=	0xf5f4
                           0000F4   384 _ADC_DAT_L	=	0x00f4
                           0000F5   385 _ADC_DAT_H	=	0x00f5
                           0000F6   386 _ADC_CHAN	=	0x00f6
                           0000A6   387 _LED_COMMON	=	0x00a6
                           0000A7   388 _LED_PWM_OE	=	0x00a7
                           00C7C6   389 _LED_DMA	=	0xc7c6
                           0000C6   390 _LED_DMA_L	=	0x00c6
                           0000C7   391 _LED_DMA_H	=	0x00c7
                           0000F7   392 _LED_STATUS	=	0x00f7
                           0000B3   393 _I2CX_INT	=	0x00b3
                           0000BB   394 _I2CS_INT_ST	=	0x00bb
                                    395 ;--------------------------------------------------------
                                    396 ; special function bits
                                    397 ;--------------------------------------------------------
                                    398 	.area RSEG    (ABS,DATA)
      000000                        399 	.org 0x0000
                           0000D7   400 _CY	=	0x00d7
                           0000D6   401 _AC	=	0x00d6
                           0000D5   402 _F0	=	0x00d5
                           0000D4   403 _RS1	=	0x00d4
                           0000D3   404 _RS0	=	0x00d3
                           0000D2   405 _OV	=	0x00d2
                           0000D1   406 _F1	=	0x00d1
                           0000D0   407 _P	=	0x00d0
                           0000AF   408 _EA	=	0x00af
                           0000AE   409 _E_DIS	=	0x00ae
                           0000AD   410 _ET2	=	0x00ad
                           0000AC   411 _ES	=	0x00ac
                           0000AB   412 _ET1	=	0x00ab
                           0000AA   413 _EX1	=	0x00aa
                           0000A9   414 _ET0	=	0x00a9
                           0000A8   415 _EX0	=	0x00a8
                           0000BF   416 _PH_FLAG	=	0x00bf
                           0000BE   417 _PL_FLAG	=	0x00be
                           0000BD   418 _PT2	=	0x00bd
                           0000BC   419 _PS	=	0x00bc
                           0000BB   420 _PT1	=	0x00bb
                           0000BA   421 _PX1	=	0x00ba
                           0000B9   422 _PT0	=	0x00b9
                           0000B8   423 _PX0	=	0x00b8
                           0000EF   424 _IE_WDOG	=	0x00ef
                           0000EE   425 _IE_GPIO	=	0x00ee
                           0000ED   426 _IE_PWM_I2C	=	0x00ed
                           0000EC   427 _IE_UART1	=	0x00ec
                           0000EB   428 _IE_ADC	=	0x00eb
                           0000E9   429 _IE_USB	=	0x00e9
                           0000E8   430 _IE_SPI0	=	0x00e8
                           000087   431 _P0_7	=	0x0087
                           000086   432 _P0_6	=	0x0086
                           000085   433 _P0_5	=	0x0085
                           000084   434 _P0_4	=	0x0084
                           000083   435 _P0_3	=	0x0083
                           000082   436 _P0_2	=	0x0082
                           000081   437 _P0_1	=	0x0081
                           000080   438 _P0_0	=	0x0080
                           000081   439 _SDA0	=	0x0081
                           000080   440 _SCL0	=	0x0080
                           000083   441 _TXD_	=	0x0083
                           000082   442 _RXD_	=	0x0082
                           000085   443 _AIN13	=	0x0085
                           000084   444 _AIN12	=	0x0084
                           000083   445 _AIN11	=	0x0083
                           000082   446 _AIN10	=	0x0082
                           000081   447 _AIN9	=	0x0081
                           000080   448 _AIN8	=	0x0080
                           000097   449 _P1_7	=	0x0097
                           000096   450 _P1_6	=	0x0096
                           000095   451 _P1_5	=	0x0095
                           000094   452 _P1_4	=	0x0094
                           000093   453 _P1_3	=	0x0093
                           000092   454 _P1_2	=	0x0092
                           000091   455 _P1_1	=	0x0091
                           000090   456 _P1_0	=	0x0090
                           000097   457 _TXD1_	=	0x0097
                           000096   458 _RXD1_	=	0x0096
                           000097   459 _SCK	=	0x0097
                           000096   460 _MISO	=	0x0096
                           000095   461 _MOSI	=	0x0095
                           000094   462 _SCS	=	0x0094
                           000092   463 _INT0_	=	0x0092
                           000091   464 _T2EX	=	0x0091
                           000091   465 _CAP2	=	0x0091
                           000090   466 _T2	=	0x0090
                           000090   467 _CAP1	=	0x0090
                           000097   468 _AIN7	=	0x0097
                           000096   469 _AIN6	=	0x0096
                           000095   470 _AIN5	=	0x0095
                           000094   471 _AIN4	=	0x0094
                           000093   472 _AIN3	=	0x0093
                           000092   473 _AIN2	=	0x0092
                           000091   474 _AIN1	=	0x0091
                           000090   475 _AIN0	=	0x0090
                           0000A7   476 _P2_7	=	0x00a7
                           0000A6   477 _P2_6	=	0x00a6
                           0000A5   478 _P2_5	=	0x00a5
                           0000A4   479 _P2_4	=	0x00a4
                           0000A3   480 _P2_3	=	0x00a3
                           0000A2   481 _P2_2	=	0x00a2
                           0000A1   482 _P2_1	=	0x00a1
                           0000A0   483 _P2_0	=	0x00a0
                           0000A7   484 _TXD1	=	0x00a7
                           0000A6   485 _RXD1	=	0x00a6
                           0000A5   486 _T2EX_	=	0x00a5
                           0000A5   487 _CAP2_	=	0x00a5
                           0000A4   488 _T2_	=	0x00a4
                           0000A4   489 _CAP1_	=	0x00a4
                           0000B7   490 _P3_7	=	0x00b7
                           0000B6   491 _P3_6	=	0x00b6
                           0000B5   492 _P3_5	=	0x00b5
                           0000B4   493 _P3_4	=	0x00b4
                           0000B3   494 _P3_3	=	0x00b3
                           0000B2   495 _P3_2	=	0x00b2
                           0000B1   496 _P3_1	=	0x00b1
                           0000B0   497 _P3_0	=	0x00b0
                           0000B7   498 _SCK1	=	0x00b7
                           0000B6   499 _MISO1	=	0x00b6
                           0000B5   500 _MOSI1	=	0x00b5
                           0000B5   501 _T1	=	0x00b5
                           0000B4   502 _T0	=	0x00b4
                           0000B3   503 _INT1	=	0x00b3
                           0000B2   504 _INT0	=	0x00b2
                           0000B1   505 _TXD	=	0x00b1
                           0000B0   506 _RXD	=	0x00b0
                           0000C6   507 _P4_6	=	0x00c6
                           0000C5   508 _P4_5	=	0x00c5
                           0000C4   509 _P4_4	=	0x00c4
                           0000C3   510 _P4_3	=	0x00c3
                           0000C2   511 _P4_2	=	0x00c2
                           0000C1   512 _P4_1	=	0x00c1
                           0000C0   513 _P4_0	=	0x00c0
                           00008F   514 _TF1	=	0x008f
                           00008E   515 _TR1	=	0x008e
                           00008D   516 _TF0	=	0x008d
                           00008C   517 _TR0	=	0x008c
                           00008B   518 _IE1	=	0x008b
                           00008A   519 _IT1	=	0x008a
                           000089   520 _IE0	=	0x0089
                           000088   521 _IT0	=	0x0088
                           00009F   522 _SM0	=	0x009f
                           00009E   523 _SM1	=	0x009e
                           00009D   524 _SM2	=	0x009d
                           00009C   525 _REN	=	0x009c
                           00009B   526 _TB8	=	0x009b
                           00009A   527 _RB8	=	0x009a
                           000099   528 _TI	=	0x0099
                           000098   529 _RI	=	0x0098
                           0000CF   530 _TF2	=	0x00cf
                           0000CF   531 _CAP1F	=	0x00cf
                           0000CE   532 _EXF2	=	0x00ce
                           0000CD   533 _RCLK	=	0x00cd
                           0000CC   534 _TCLK	=	0x00cc
                           0000CB   535 _EXEN2	=	0x00cb
                           0000CA   536 _TR2	=	0x00ca
                           0000C9   537 _C_T2	=	0x00c9
                           0000C8   538 _CP_RL2	=	0x00c8
                           0000FF   539 _S0_FST_ACT	=	0x00ff
                           0000FE   540 _S0_IF_OV	=	0x00fe
                           0000FD   541 _S0_IF_FIRST	=	0x00fd
                           0000FC   542 _S0_IF_BYTE	=	0x00fc
                           0000FB   543 _S0_FREE	=	0x00fb
                           0000FA   544 _S0_T_FIFO	=	0x00fa
                           0000F8   545 _S0_R_FIFO	=	0x00f8
                           0000F7   546 _ADC_START	=	0x00f7
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable register banks
                                    549 ;--------------------------------------------------------
                                    550 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        551 	.ds 8
                                    552 ;--------------------------------------------------------
                                    553 ; internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area DSEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 	.area	OSEG    (OVR,DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; indirectly addressable internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area ISEG    (DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; absolute internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area IABS    (ABS,DATA)
                                    568 	.area IABS    (ABS,DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; bit data
                                    571 ;--------------------------------------------------------
                                    572 	.area BSEG    (BIT)
                                    573 ;--------------------------------------------------------
                                    574 ; paged external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area PSEG    (PAG,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; uninitialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XSEG    (XDATA)
      000B66                        581 _switch_events_PARM_2:
      000B66                        582 	.ds 1
      000B67                        583 _switch_events_PARM_3:
      000B67                        584 	.ds 1
      000B68                        585 _switch_events_row_10000_486:
      000B68                        586 	.ds 1
      000B69                        587 _generate_tick_event_last_tick_10000_489:
      000B69                        588 	.ds 2
      000B6B                        589 _matrix_task_last_tick_60000_518:
      000B6B                        590 	.ds 2
      000B6D                        591 _matrix_task_dummy_event_70000_519:
      000B6D                        592 	.ds 6
      000B73                        593 _matrix_task_matrix_previous_10001_496:
      000B73                        594 	.ds 16
      000B83                        595 _matrix_task_matrix_changed_10002_497:
      000B83                        596 	.ds 1
      000B84                        597 _matrix_task_last_tick_60002_522:
      000B84                        598 	.ds 2
      000B86                        599 _matrix_task_dummy_event_70002_523:
      000B86                        600 	.ds 6
      000B8C                        601 _matrix_task_row_changes_30003_506:
      000B8C                        602 	.ds 1
      000B8D                        603 _matrix_task_col_mask_30004_509:
      000B8D                        604 	.ds 1
      000B8E                        605 _matrix_task_dummy_event_90004_515:
      000B8E                        606 	.ds 6
                                    607 ;--------------------------------------------------------
                                    608 ; absolute external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XABS    (ABS,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; initialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XISEG   (XDATA)
      000E10                        615 _last_input_modification_time:
      000E10                        616 	.ds 4
      000E14                        617 _last_matrix_modification_time:
      000E14                        618 	.ds 4
      000E18                        619 _last_encoder_modification_time:
      000E18                        620 	.ds 4
      000E1C                        621 _last_pointing_device_modification_time:
      000E1C                        622 	.ds 4
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT0 (CODE)
                                    625 	.area GSINIT1 (CODE)
                                    626 	.area GSINIT2 (CODE)
                                    627 	.area GSINIT3 (CODE)
                                    628 	.area GSINIT4 (CODE)
                                    629 	.area GSINIT5 (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area CSEG    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; global & static initialisations
                                    635 ;--------------------------------------------------------
                                    636 	.area HOME    (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 	.area GSFINAL (CODE)
                                    639 	.area GSINIT  (CODE)
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'generate_tick_event'
                                    642 ;------------------------------------------------------------
                                    643 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_489'
                                    644 ;now           Allocated with name '_generate_tick_event_now_10000_489'
                                    645 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_491'
                                    646 ;------------------------------------------------------------
                                    647 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      003108 90 0B 69         [24]  648 	mov	dptr,#_generate_tick_event_last_tick_10000_489
      00310B E4               [12]  649 	clr	a
      00310C F0               [24]  650 	movx	@dptr,a
      00310D A3               [24]  651 	inc	dptr
      00310E F0               [24]  652 	movx	@dptr,a
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'matrix_task'
                                    655 ;------------------------------------------------------------
                                    656 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_518'
                                    657 ;now           Allocated with name '_matrix_task_now_60000_518'
                                    658 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_519'
                                    659 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_496'
                                    660 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_497'
                                    661 ;row           Allocated with name '_matrix_task_row_20002_498'
                                    662 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_522'
                                    663 ;now           Allocated with name '_matrix_task_now_60002_522'
                                    664 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_523'
                                    665 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_504'
                                    666 ;row           Allocated with name '_matrix_task_row_20003_505'
                                    667 ;__400030089   Allocated with name '_matrix_task___400030089_40003_506'
                                    668 ;current_row   Allocated with name '_matrix_task_current_row_30003_506'
                                    669 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_506'
                                    670 ;__500030090   Allocated with name '_matrix_task___500030090_50003_524'
                                    671 ;__500030091   Allocated with name '_matrix_task___500030091_50003_524'
                                    672 ;row           Allocated with name '_matrix_task_row_60003_525'
                                    673 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_525'
                                    674 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_509'
                                    675 ;col           Allocated with name '_matrix_task_col_40004_510'
                                    676 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_513'
                                    677 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_515'
                                    678 ;------------------------------------------------------------
                                    679 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      00310F 90 0B 6B         [24]  680 	mov	dptr,#_matrix_task_last_tick_60000_518
      003112 E4               [12]  681 	clr	a
      003113 F0               [24]  682 	movx	@dptr,a
      003114 A3               [24]  683 	inc	dptr
      003115 F0               [24]  684 	movx	@dptr,a
      003116 90 0B 84         [24]  685 	mov	dptr,#_matrix_task_last_tick_60002_522
      003119 F0               [24]  686 	movx	@dptr,a
      00311A A3               [24]  687 	inc	dptr
      00311B F0               [24]  688 	movx	@dptr,a
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    700 ;------------------------------------------------------------
                                    701 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    702 ;------------------------------------------------------------
                                    703 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function last_matrix_activity_trigger
                                    714 ;	-----------------------------------------
      0093F2                        715 _last_matrix_activity_trigger:
                                    716 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      0093F2 12 48 9A         [24]  717 	lcall	_timer_read32
      0093F5 12 4E 6C         [24]  718 	lcall	_ak820_outline_0041
      0093F8 90 0E 10         [24]  719 	mov	dptr,#_last_input_modification_time
      0093FB 12 8F 18         [24]  720 	lcall	_ak820_outline_0091
      0093FE 12 43 CB         [24]  721 	lcall	_ak820_outline_0001
      009401 90 0E 14         [24]  722 	mov	dptr,#_last_matrix_modification_time
      009404 12 8F 18         [24]  723 	lcall	_ak820_outline_0091
      009407 12 43 CB         [24]  724 	lcall	_ak820_outline_0001
                                    725 ;	quantum/keyboard.c:191: }
      00940A 22               [24]  726 	ret
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    729 ;------------------------------------------------------------
                                    730 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    731 ;	-----------------------------------------
                                    732 ;	 function last_encoder_activity_trigger
                                    733 ;	-----------------------------------------
      00940B                        734 _last_encoder_activity_trigger:
                                    735 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      00940B 12 48 9A         [24]  736 	lcall	_timer_read32
      00940E 12 4E 6C         [24]  737 	lcall	_ak820_outline_0041
      009411 90 0E 10         [24]  738 	mov	dptr,#_last_input_modification_time
      009414 12 8F 18         [24]  739 	lcall	_ak820_outline_0091
      009417 12 43 CB         [24]  740 	lcall	_ak820_outline_0001
      00941A 90 0E 18         [24]  741 	mov	dptr,#_last_encoder_modification_time
      00941D 12 8F 18         [24]  742 	lcall	_ak820_outline_0091
      009420 12 43 CB         [24]  743 	lcall	_ak820_outline_0001
                                    744 ;	quantum/keyboard.c:202: }
      009423 22               [24]  745 	ret
                                    746 ;------------------------------------------------------------
                                    747 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    748 ;------------------------------------------------------------
                                    749 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function keyboard_post_init_kb
                                    752 ;	-----------------------------------------
      009424                        753 _keyboard_post_init_kb:
                                    754 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    755 ;	quantum/keyboard.c:346: }
      009424 02 98 C3         [24]  756 	ljmp	_keyboard_post_init_user
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'matrix_can_read'
                                    759 ;------------------------------------------------------------
                                    760 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    761 ;	-----------------------------------------
                                    762 ;	 function matrix_can_read
                                    763 ;	-----------------------------------------
      009427                        764 _matrix_can_read:
                                    765 ;	quantum/keyboard.c:353: return true;
      009427 75 82 01         [24]  766 	mov	dpl, #0x01
                                    767 ;	quantum/keyboard.c:354: }
      00942A 22               [24]  768 	ret
                                    769 ;------------------------------------------------------------
                                    770 ;Allocation info for local variables in function 'keyboard_setup'
                                    771 ;------------------------------------------------------------
                                    772 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    773 ;	-----------------------------------------
                                    774 ;	 function keyboard_setup
                                    775 ;	-----------------------------------------
      00942B                        776 _keyboard_setup:
                                    777 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      00942B 90 9A 37         [24]  778 	mov	dptr,#_sendchar
      00942E 12 9A 0A         [24]  779 	lcall	_print_set_sendchar
                                    780 ;	quantum/keyboard.c:363: eeprom_driver_init();
      009431 12 3E 61         [24]  781 	lcall	_eeprom_driver_init
                                    782 ;	quantum/keyboard.c:366: vial_init();
                                    783 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    784 ;	quantum/keyboard.c:373: }
      009434 02 B1 A6         [24]  785 	ljmp	_vial_init
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'is_keyboard_master'
                                    788 ;------------------------------------------------------------
                                    789 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    790 ;	-----------------------------------------
                                    791 ;	 function is_keyboard_master
                                    792 ;	-----------------------------------------
      009437                        793 _is_keyboard_master:
                                    794 ;	quantum/keyboard.c:382: return true;
      009437 75 82 01         [24]  795 	mov	dpl, #0x01
                                    796 ;	quantum/keyboard.c:383: }
      00943A 22               [24]  797 	ret
                                    798 ;------------------------------------------------------------
                                    799 ;Allocation info for local variables in function 'is_keyboard_left'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function should_process_keypress
                                    804 ;	-----------------------------------------
      00943B                        805 _should_process_keypress:
                                    806 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    807 ;	quantum/keyboard.c:402: }
      00943B 02 94 37         [24]  808 	ljmp	_is_keyboard_master
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    813 ;	-----------------------------------------
                                    814 ;	 function housekeeping_task
                                    815 ;	-----------------------------------------
      00943E                        816 _housekeeping_task:
                                    817 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    818 ;	quantum/keyboard.c:425: }
      00943E 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'quantum_init'
                                    822 ;------------------------------------------------------------
                                    823 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    824 ;	-----------------------------------------
                                    825 ;	 function quantum_init
                                    826 ;	-----------------------------------------
      00943F                        827 _quantum_init:
                                    828 ;	quantum/keyboard.c:432: magic();
      00943F 12 81 A5         [24]  829 	lcall	_magic
                                    830 ;	quantum/keyboard.c:433: led_init_ports();
      009442 12 99 9F         [24]  831 	lcall	_led_init_ports
                                    832 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    833 ;	quantum/keyboard.c:452: }
      009445 02 50 2D         [24]  834 	ljmp	_rgb_matrix_init
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'keyboard_init'
                                    837 ;------------------------------------------------------------
                                    838 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    839 ;	-----------------------------------------
                                    840 ;	 function keyboard_init
                                    841 ;	-----------------------------------------
      009448                        842 _keyboard_init:
                                    843 ;	quantum/keyboard.c:459: timer_init();
      009448 12 48 5C         [24]  844 	lcall	_timer_init
                                    845 ;	quantum/keyboard.c:462: via_init();
      00944B 12 A9 EB         [24]  846 	lcall	_via_init
                                    847 ;	quantum/keyboard.c:468: encoder_init();
      00944E 12 91 1B         [24]  848 	lcall	_encoder_init
                                    849 ;	quantum/keyboard.c:470: matrix_init();
      009451 12 59 E4         [24]  850 	lcall	_matrix_init
                                    851 ;	quantum/keyboard.c:471: quantum_init();
      009454 12 94 3F         [24]  852 	lcall	_quantum_init
                                    853 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    854 ;	quantum/keyboard.c:522: }
      009457 02 94 24         [24]  855 	ljmp	_keyboard_post_init_kb
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'switch_events'
                                    858 ;------------------------------------------------------------
                                    859 ;col           Allocated with name '_switch_events_PARM_2'
                                    860 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    861 ;row           Allocated with name '_switch_events_row_10000_486'
                                    862 ;------------------------------------------------------------
                                    863 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    864 ;	-----------------------------------------
                                    865 ;	 function switch_events
                                    866 ;	-----------------------------------------
      00945A                        867 _switch_events:
      00945A E5 82            [12]  868 	mov	a,dpl
      00945C 90 0B 68         [24]  869 	mov	dptr,#_switch_events_row_10000_486
      00945F F0               [24]  870 	movx	@dptr,a
                                    871 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      009460 E0               [24]  872 	movx	a,@dptr
      009461 FF               [12]  873 	mov	r7,a
      009462 90 0B 66         [24]  874 	mov	dptr,#_switch_events_PARM_2
      009465 E0               [24]  875 	movx	a,@dptr
      009466 FE               [12]  876 	mov	r6,a
      009467 90 0B 67         [24]  877 	mov	dptr,#_switch_events_PARM_3
      00946A E0               [24]  878 	movx	a,@dptr
      00946B FD               [12]  879 	mov	r5,a
      00946C 90 07 1B         [24]  880 	mov	dptr,#_process_rgb_matrix_PARM_2
      00946F EE               [12]  881 	mov	a,r6
      009470 F0               [24]  882 	movx	@dptr,a
      009471 90 07 1C         [24]  883 	mov	dptr,#_process_rgb_matrix_PARM_3
      009474 ED               [12]  884 	mov	a,r5
      009475 F0               [24]  885 	movx	@dptr,a
      009476 8F 82            [24]  886 	mov	dpl, r7
                                    887 ;	quantum/keyboard.c:536: }
      009478 02 54 32         [24]  888 	ljmp	_process_rgb_matrix
                                    889 ;------------------------------------------------------------
                                    890 ;Allocation info for local variables in function 'generate_tick_event'
                                    891 ;------------------------------------------------------------
                                    892 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_489'
                                    893 ;now           Allocated with name '_generate_tick_event_now_10000_489'
                                    894 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_491'
                                    895 ;------------------------------------------------------------
                                    896 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    897 ;	-----------------------------------------
                                    898 ;	 function matrix_task
                                    899 ;	-----------------------------------------
      00947B                        900 _matrix_task:
                                    901 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      00947B 12 94 27         [24]  902 	lcall	_matrix_can_read
      00947E E5 82            [12]  903 	mov	a, dpl
      009480 70 65            [24]  904 	jnz	00102$
                                    905 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      009482 12 48 CB         [24]  906 	lcall	_timer_read
      009485 12 44 1D         [24]  907 	lcall	_ak820_outline_0027
                                    908 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009488 90 0B 6B         [24]  909 	mov	dptr,#_matrix_task_last_tick_60000_518
      00948B 12 43 DF         [24]  910 	lcall	_ak820_outline_0006
      00948E EE               [12]  911 	mov	a,r6
      00948F C3               [12]  912 	clr	c
      009490 9C               [12]  913 	subb	a,r4
      009491 FC               [12]  914 	mov	r4,a
      009492 EF               [12]  915 	mov	a,r7
      009493 9D               [12]  916 	subb	a,r5
      009494 4C               [12]  917 	orl	a,r4
      009495 60 4C            [24]  918 	jz	00120$
                                    919 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009497 90 0B 6D         [24]  920 	mov	dptr,#_matrix_task_dummy_event_70000_519
      00949A E4               [12]  921 	clr	a
      00949B F0               [24]  922 	movx	@dptr,a
      00949C 90 0B 6E         [24]  923 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0001)
      00949F F0               [24]  924 	movx	@dptr,a
      0094A0 12 48 CB         [24]  925 	lcall	_timer_read
      0094A3 12 44 83         [24]  926 	lcall	_ak820_outline_0132
      0094A6 90 0B 6F         [24]  927 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0002)
      0094A9 12 44 0B         [24]  928 	lcall	_ak820_outline_0023
      0094AC 90 0B 71         [24]  929 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0004)
      0094AF E4               [12]  930 	clr	a
      0094B0 F0               [24]  931 	movx	@dptr,a
      0094B1 90 0B 72         [24]  932 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0005)
      0094B4 F0               [24]  933 	movx	@dptr,a
                                    934 ;	quantum/keyboard.c:549: action_exec(dummy_event);
      0094B5 90 0D B3         [24]  935 	mov	dptr,#___memcpy_PARM_2
      0094B8 74 6D            [12]  936 	mov	a,#_matrix_task_dummy_event_70000_519
      0094BA F0               [24]  937 	movx	@dptr,a
      0094BB 74 0B            [12]  938 	mov	a,#(_matrix_task_dummy_event_70000_519 >> 8)
      0094BD A3               [24]  939 	inc	dptr
      0094BE 12 4E 60         [24]  940 	lcall	_ak820_outline_0003
      0094C1 90 0D B6         [24]  941 	mov	dptr,#___memcpy_PARM_3
      0094C4 74 06            [12]  942 	mov	a,#0x06
      0094C6 12 4E 60         [24]  943 	lcall	_ak820_outline_0003
      0094C9 90 08 07         [24]  944 	mov	dptr,#_action_exec_PARM_1
      0094CC F5 F0            [12]  945 	mov	b,a
      0094CE C0 07            [24]  946 	push	ar7
      0094D0 C0 06            [24]  947 	push	ar6
      0094D2 12 BD 3B         [24]  948 	lcall	___memcpy
      0094D5 12 70 A5         [24]  949 	lcall	_action_exec
      0094D8 D0 06            [24]  950 	pop	ar6
      0094DA D0 07            [24]  951 	pop	ar7
                                    952 ;	quantum/keyboard.c:550: last_tick = now;
      0094DC 90 0B 6B         [24]  953 	mov	dptr,#_matrix_task_last_tick_60000_518
      0094DF EE               [12]  954 	mov	a,r6
      0094E0 12 43 E5         [24]  955 	lcall	_ak820_outline_0007
                                    956 ;	quantum/keyboard.c:563: generate_tick_event();
      0094E3                        957 00120$:
                                    958 ;	quantum/keyboard.c:564: return false;
      0094E3 75 82 00         [24]  959 	mov	dpl, #0x00
      0094E6 22               [24]  960 	ret
      0094E7                        961 00102$:
                                    962 ;	quantum/keyboard.c:569: matrix_scan();
      0094E7 12 5A 0D         [24]  963 	lcall	_matrix_scan
                                    964 ;	quantum/keyboard.c:573: vial_unlock_task();
      0094EA 12 B1 04         [24]  965 	lcall	_vial_unlock_task
                                    966 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      0094ED 90 0B 83         [24]  967 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      0094F0 E4               [12]  968 	clr	a
      0094F1 F0               [24]  969 	movx	@dptr,a
                                    970 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      0094F2 FF               [12]  971 	mov	r7,a
      0094F3                        972 00127$:
      0094F3 BF 10 00         [24]  973 	cjne	r7,#0x10,00247$
      0094F6                        974 00247$:
      0094F6 50 1F            [24]  975 	jnc	00103$
      0094F8 90 0B 83         [24]  976 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      0094FB E0               [24]  977 	movx	a,@dptr
      0094FC 70 19            [24]  978 	jnz	00103$
                                    979 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      0094FE EF               [12]  980 	mov	a,r7
      0094FF 12 96 90         [24]  981 	lcall	_ak820_outline_0053
      009502 E0               [24]  982 	movx	a,@dptr
      009503 FE               [12]  983 	mov	r6,a
      009504 8F 82            [24]  984 	mov	dpl, r7
      009506 12 59 99         [24]  985 	lcall	_matrix_get_row
      009509 E5 82            [12]  986 	mov	a,dpl
      00950B 6E               [12]  987 	xrl	a,r6
                                    988 ;	assignBit
      00950C 90 0B 83         [24]  989 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      00950F 24 FF            [12]  990 	add	a,#0xff
      009511 E4               [12]  991 	clr	a
      009512 33               [12]  992 	rlc	a
      009513 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009514 0F               [12]  995 	inc	r7
      009515 80 DC            [24]  996 	sjmp	00127$
      009517                        997 00103$:
                                    998 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      009517 90 0B 83         [24]  999 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      00951A E0               [24] 1000 	movx	a,@dptr
      00951B 70 65            [24] 1001 	jnz	00105$
                                   1002 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      00951D 12 48 CB         [24] 1003 	lcall	_timer_read
      009520 12 44 1D         [24] 1004 	lcall	_ak820_outline_0027
                                   1005 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009523 90 0B 84         [24] 1006 	mov	dptr,#_matrix_task_last_tick_60002_522
      009526 12 43 DF         [24] 1007 	lcall	_ak820_outline_0006
      009529 EE               [12] 1008 	mov	a,r6
      00952A C3               [12] 1009 	clr	c
      00952B 9C               [12] 1010 	subb	a,r4
      00952C FC               [12] 1011 	mov	r4,a
      00952D EF               [12] 1012 	mov	a,r7
      00952E 9D               [12] 1013 	subb	a,r5
      00952F 4C               [12] 1014 	orl	a,r4
      009530 60 4C            [24] 1015 	jz	00123$
                                   1016 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009532 90 0B 86         [24] 1017 	mov	dptr,#_matrix_task_dummy_event_70002_523
      009535 E4               [12] 1018 	clr	a
      009536 F0               [24] 1019 	movx	@dptr,a
      009537 90 0B 87         [24] 1020 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0001)
      00953A F0               [24] 1021 	movx	@dptr,a
      00953B 12 48 CB         [24] 1022 	lcall	_timer_read
      00953E 12 44 83         [24] 1023 	lcall	_ak820_outline_0132
      009541 90 0B 88         [24] 1024 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0002)
      009544 12 44 0B         [24] 1025 	lcall	_ak820_outline_0023
      009547 90 0B 8A         [24] 1026 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0004)
      00954A E4               [12] 1027 	clr	a
      00954B F0               [24] 1028 	movx	@dptr,a
      00954C 90 0B 8B         [24] 1029 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0005)
      00954F F0               [24] 1030 	movx	@dptr,a
                                   1031 ;	quantum/keyboard.c:549: action_exec(dummy_event);
      009550 90 0D B3         [24] 1032 	mov	dptr,#___memcpy_PARM_2
      009553 74 86            [12] 1033 	mov	a,#_matrix_task_dummy_event_70002_523
      009555 F0               [24] 1034 	movx	@dptr,a
      009556 74 0B            [12] 1035 	mov	a,#(_matrix_task_dummy_event_70002_523 >> 8)
      009558 A3               [24] 1036 	inc	dptr
      009559 12 4E 60         [24] 1037 	lcall	_ak820_outline_0003
      00955C 90 0D B6         [24] 1038 	mov	dptr,#___memcpy_PARM_3
      00955F 74 06            [12] 1039 	mov	a,#0x06
      009561 12 4E 60         [24] 1040 	lcall	_ak820_outline_0003
      009564 90 08 07         [24] 1041 	mov	dptr,#_action_exec_PARM_1
      009567 F5 F0            [12] 1042 	mov	b,a
      009569 C0 07            [24] 1043 	push	ar7
      00956B C0 06            [24] 1044 	push	ar6
      00956D 12 BD 3B         [24] 1045 	lcall	___memcpy
      009570 12 70 A5         [24] 1046 	lcall	_action_exec
      009573 D0 06            [24] 1047 	pop	ar6
      009575 D0 07            [24] 1048 	pop	ar7
                                   1049 ;	quantum/keyboard.c:550: last_tick = now;
      009577 90 0B 84         [24] 1050 	mov	dptr,#_matrix_task_last_tick_60002_522
      00957A EE               [12] 1051 	mov	a,r6
      00957B 12 43 E5         [24] 1052 	lcall	_ak820_outline_0007
                                   1053 ;	quantum/keyboard.c:584: generate_tick_event();
      00957E                       1054 00123$:
                                   1055 ;	quantum/keyboard.c:585: return matrix_changed;
      00957E 75 82 00         [24] 1056 	mov	dpl, #0x00
      009581 22               [24] 1057 	ret
      009582                       1058 00105$:
                                   1059 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      009582 90 0E 24         [24] 1060 	mov	dptr,#_debug_config
      009585 E0               [24] 1061 	movx	a,@dptr
      009586 30 E1 03         [24] 1062 	jnb	acc.1,00107$
                                   1063 ;	quantum/keyboard.c:589: matrix_print();
      009589 12 5A 39         [24] 1064 	lcall	_matrix_print
      00958C                       1065 00107$:
                                   1066 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      00958C 12 94 3B         [24] 1067 	lcall	_should_process_keypress
      00958F AF 82            [24] 1068 	mov	r7, dpl
                                   1069 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009591 7E 00            [12] 1070 	mov	r6,#0x00
      009593                       1071 00133$:
      009593 BE 10 00         [24] 1072 	cjne	r6,#0x10,00253$
      009596                       1073 00253$:
      009596 40 03            [24] 1074 	jc	00254$
      009598 02 96 6C         [24] 1075 	ljmp	00117$
      00959B                       1076 00254$:
                                   1077 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      00959B 8E 82            [24] 1078 	mov	dpl, r6
      00959D 12 59 99         [24] 1079 	lcall	_matrix_get_row
      0095A0 AD 82            [24] 1080 	mov	r5, dpl
                                   1081 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      0095A2 EE               [12] 1082 	mov	a,r6
      0095A3 12 96 90         [24] 1083 	lcall	_ak820_outline_0053
      0095A6 E0               [24] 1084 	movx	a,@dptr
      0095A7 FC               [12] 1085 	mov	r4,a
      0095A8 ED               [12] 1086 	mov	a,r5
      0095A9 62 04            [12] 1087 	xrl	ar4,a
      0095AB 90 0B 8C         [24] 1088 	mov	dptr,#_matrix_task_row_changes_30003_506
      0095AE EC               [12] 1089 	mov	a,r4
      0095AF F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      0095B0 EC               [12] 1092 	mov	a,r4
      0095B1 70 03            [24] 1093 	jnz	00255$
      0095B3 02 96 68         [24] 1094 	ljmp	00116$
      0095B6                       1095 00255$:
                                   1096 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      0095B6 90 0B 8D         [24] 1097 	mov	dptr,#_matrix_task_col_mask_30004_509
      0095B9 74 01            [12] 1098 	mov	a,#0x01
      0095BB F0               [24] 1099 	movx	@dptr,a
                                   1100 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      0095BC 7C 00            [12] 1101 	mov	r4,#0x00
      0095BE                       1102 00130$:
      0095BE BC 08 00         [24] 1103 	cjne	r4,#0x08,00256$
      0095C1                       1104 00256$:
      0095C1 40 03            [24] 1105 	jc	00257$
      0095C3 02 96 62         [24] 1106 	ljmp	00115$
      0095C6                       1107 00257$:
                                   1108 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      0095C6 90 0B 8C         [24] 1109 	mov	dptr,#_matrix_task_row_changes_30003_506
      0095C9 E0               [24] 1110 	movx	a,@dptr
      0095CA FB               [12] 1111 	mov	r3,a
      0095CB 90 0B 8D         [24] 1112 	mov	dptr,#_matrix_task_col_mask_30004_509
      0095CE E0               [24] 1113 	movx	a,@dptr
      0095CF FA               [12] 1114 	mov	r2,a
      0095D0 5B               [12] 1115 	anl	a,r3
      0095D1 70 03            [24] 1116 	jnz	00258$
      0095D3 02 96 57         [24] 1117 	ljmp	00131$
      0095D6                       1118 00258$:
                                   1119 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      0095D6 ED               [12] 1120 	mov	a,r5
      0095D7 52 02            [12] 1121 	anl	ar2,a
                                   1122 ;	assignBit
      0095D9 EA               [12] 1123 	mov	a,r2
      0095DA 24 FF            [12] 1124 	add	a,#0xff
      0095DC E4               [12] 1125 	clr	a
      0095DD 33               [12] 1126 	rlc	a
      0095DE FA               [12] 1127 	mov	r2,a
                                   1128 ;	quantum/keyboard.c:607: if (process_keypress) {
      0095DF EF               [12] 1129 	mov	a,r7
      0095E0 60 56            [24] 1130 	jz	00112$
                                   1131 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      0095E2 90 0B 8E         [24] 1132 	mov	dptr,#_matrix_task_dummy_event_90004_515
      0095E5 EC               [12] 1133 	mov	a,r4
      0095E6 F0               [24] 1134 	movx	@dptr,a
      0095E7 90 0B 8F         [24] 1135 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0001)
      0095EA EE               [12] 1136 	mov	a,r6
      0095EB F0               [24] 1137 	movx	@dptr,a
      0095EC 12 48 CB         [24] 1138 	lcall	_timer_read
      0095EF A9 82            [24] 1139 	mov	r1, dpl
      0095F1 AB 83            [24] 1140 	mov	r3, dph
      0095F3 90 0B 90         [24] 1141 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0002)
      0095F6 E9               [12] 1142 	mov	a,r1
      0095F7 12 8F 56         [24] 1143 	lcall	_ak820_outline_0149
      0095FA 90 0B 92         [24] 1144 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0004)
      0095FD 74 01            [12] 1145 	mov	a,#0x01
      0095FF F0               [24] 1146 	movx	@dptr,a
      009600 90 0B 93         [24] 1147 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0005)
      009603 EA               [12] 1148 	mov	a,r2
      009604 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/keyboard.c:610: action_exec(dummy_event);
      009605 90 0D B3         [24] 1151 	mov	dptr,#___memcpy_PARM_2
      009608 74 8E            [12] 1152 	mov	a,#_matrix_task_dummy_event_90004_515
      00960A F0               [24] 1153 	movx	@dptr,a
      00960B 74 0B            [12] 1154 	mov	a,#(_matrix_task_dummy_event_90004_515 >> 8)
      00960D A3               [24] 1155 	inc	dptr
      00960E 12 4E 60         [24] 1156 	lcall	_ak820_outline_0003
      009611 90 0D B6         [24] 1157 	mov	dptr,#___memcpy_PARM_3
      009614 74 06            [12] 1158 	mov	a,#0x06
      009616 12 4E 60         [24] 1159 	lcall	_ak820_outline_0003
      009619 90 08 07         [24] 1160 	mov	dptr,#_action_exec_PARM_1
      00961C F5 F0            [12] 1161 	mov	b,a
      00961E C0 07            [24] 1162 	push	ar7
      009620 C0 06            [24] 1163 	push	ar6
      009622 C0 05            [24] 1164 	push	ar5
      009624 C0 04            [24] 1165 	push	ar4
      009626 C0 02            [24] 1166 	push	ar2
      009628 12 BD 3B         [24] 1167 	lcall	___memcpy
      00962B 12 70 A5         [24] 1168 	lcall	_action_exec
      00962E D0 02            [24] 1169 	pop	ar2
      009630 D0 04            [24] 1170 	pop	ar4
      009632 D0 05            [24] 1171 	pop	ar5
      009634 D0 06            [24] 1172 	pop	ar6
      009636 D0 07            [24] 1173 	pop	ar7
      009638                       1174 00112$:
                                   1175 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      009638 90 0B 66         [24] 1176 	mov	dptr,#_switch_events_PARM_2
      00963B EC               [12] 1177 	mov	a,r4
      00963C F0               [24] 1178 	movx	@dptr,a
      00963D 90 0B 67         [24] 1179 	mov	dptr,#_switch_events_PARM_3
      009640 EA               [12] 1180 	mov	a,r2
      009641 F0               [24] 1181 	movx	@dptr,a
      009642 8E 82            [24] 1182 	mov	dpl, r6
      009644 C0 07            [24] 1183 	push	ar7
      009646 C0 06            [24] 1184 	push	ar6
      009648 C0 05            [24] 1185 	push	ar5
      00964A C0 04            [24] 1186 	push	ar4
      00964C 12 94 5A         [24] 1187 	lcall	_switch_events
      00964F D0 04            [24] 1188 	pop	ar4
      009651 D0 05            [24] 1189 	pop	ar5
      009653 D0 06            [24] 1190 	pop	ar6
      009655 D0 07            [24] 1191 	pop	ar7
      009657                       1192 00131$:
                                   1193 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009657 0C               [12] 1194 	inc	r4
      009658 90 0B 8D         [24] 1195 	mov	dptr,#_matrix_task_col_mask_30004_509
      00965B E0               [24] 1196 	movx	a,@dptr
      00965C 25 E0            [12] 1197 	add	a,acc
      00965E F0               [24] 1198 	movx	@dptr,a
      00965F 02 95 BE         [24] 1199 	ljmp	00130$
      009662                       1200 00115$:
                                   1201 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      009662 EE               [12] 1202 	mov	a,r6
      009663 12 96 90         [24] 1203 	lcall	_ak820_outline_0053
      009666 ED               [12] 1204 	mov	a,r5
      009667 F0               [24] 1205 	movx	@dptr,a
      009668                       1206 00116$:
                                   1207 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009668 0E               [12] 1208 	inc	r6
      009669 02 95 93         [24] 1209 	ljmp	00133$
      00966C                       1210 00117$:
                                   1211 ;	quantum/keyboard.c:620: return matrix_changed;
      00966C 75 82 01         [24] 1212 	mov	dpl, #0x01
                                   1213 ;	quantum/keyboard.c:621: }
      00966F 22               [24] 1214 	ret
                                   1215 ;------------------------------------------------------------
                                   1216 ;Allocation info for local variables in function 'quantum_task'
                                   1217 ;------------------------------------------------------------
                                   1218 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1219 ;	-----------------------------------------
                                   1220 ;	 function quantum_task
                                   1221 ;	-----------------------------------------
      009670                       1222 _quantum_task:
                                   1223 ;	quantum/keyboard.c:694: caps_word_task();
                                   1224 ;	quantum/keyboard.c:700: }
      009670 02 2E CC         [24] 1225 	ljmp	_caps_word_task
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'keyboard_task'
                                   1228 ;------------------------------------------------------------
                                   1229 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_530'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function keyboard_task
                                   1234 ;	-----------------------------------------
      009673                       1235 _keyboard_task:
                                   1236 ;	quantum/keyboard.c:705: if (matrix_task()) {
      009673 12 94 7B         [24] 1237 	lcall	_matrix_task
      009676 E5 82            [12] 1238 	mov	a, dpl
      009678 60 03            [24] 1239 	jz	00102$
                                   1240 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      00967A 12 93 F2         [24] 1241 	lcall	_last_matrix_activity_trigger
                                   1242 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      00967D                       1243 00102$:
                                   1244 ;	quantum/keyboard.c:710: quantum_task();
      00967D 12 96 70         [24] 1245 	lcall	_quantum_task
                                   1246 ;	quantum/keyboard.c:724: rgb_matrix_task();
      009680 12 51 91         [24] 1247 	lcall	_rgb_matrix_task
                                   1248 ;	quantum/keyboard.c:734: if (encoder_read()) {
      009683 12 93 4C         [24] 1249 	lcall	_encoder_read
      009686 E5 82            [12] 1250 	mov	a, dpl
      009688 60 03            [24] 1251 	jz	00104$
                                   1252 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      00968A 12 94 0B         [24] 1253 	lcall	_last_encoder_activity_trigger
                                   1254 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      00968D                       1255 00104$:
                                   1256 ;	quantum/keyboard.c:790: led_task();
                                   1257 ;	quantum/keyboard.c:791: }
      00968D 02 99 C9         [24] 1258 	ljmp	_led_task
                                   1259 	.area CSEG    (CODE)
                                   1260 	.area CONST   (CODE)
                                   1261 	.area XINIT   (CODE)
      00C65B                       1262 __xinit__last_input_modification_time:
      00C65B 00 00 00 00           1263 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C65F                       1264 __xinit__last_matrix_modification_time:
      00C65F 00 00 00 00           1265 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C663                       1266 __xinit__last_encoder_modification_time:
      00C663 00 00 00 00           1267 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C667                       1268 __xinit__last_pointing_device_modification_time:
      00C667 00 00 00 00           1269 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1270 	.area CABS    (ABS,CODE)
                                   1271 
                                   1272 ; Experimental exact instruction outlining.
                                   1273 	.globl _ak820_outline_0001
                                   1274 	.globl _ak820_outline_0003
                                   1275 	.globl _ak820_outline_0006
                                   1276 	.globl _ak820_outline_0007
                                   1277 	.globl _ak820_outline_0023
                                   1278 	.globl _ak820_outline_0027
                                   1279 	.globl _ak820_outline_0041
                                   1280 	.globl _ak820_outline_0053
                                   1281 	.globl _ak820_outline_0091
                                   1282 	.globl _ak820_outline_0132
                                   1283 	.globl _ak820_outline_0149
                                   1284 
                                   1285 	.area CSEG (CODE)
                                   1286 ; function ak820_outline_0053
      009690                       1287 _ak820_outline_0053:
      009690 24 73            [12] 1288 	add	a,#_matrix_task_matrix_previous_10001_496
      009692 F5 82            [12] 1289 	mov	dpl,a
      009694 E4               [12] 1290 	clr	a
      009695 34 0B            [12] 1291 	addc	a,#(_matrix_task_matrix_previous_10001_496>>8)
      009697 F5 83            [12] 1292 	mov	dph,a
      009699 22               [24] 1293 	ret
