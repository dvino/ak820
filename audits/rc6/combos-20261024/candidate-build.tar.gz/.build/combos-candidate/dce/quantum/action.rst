                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _layer_switch_get_action
                                     35 	.globl _store_or_get_action
                                     36 	.globl _layer_xor
                                     37 	.globl _layer_and
                                     38 	.globl _layer_or
                                     39 	.globl _layer_off
                                     40 	.globl _layer_on
                                     41 	.globl _layer_move
                                     42 	.globl _layer_clear
                                     43 	.globl _layer_state_set
                                     44 	.globl _default_layer_xor
                                     45 	.globl _default_layer_and
                                     46 	.globl _default_layer_or
                                     47 	.globl _default_layer_set
                                     48 	.globl _post_process_record_quantum
                                     49 	.globl _process_record_quantum
                                     50 	.globl _action_for_keycode
                                     51 	.globl _mDelaymS
                                     52 	.globl _host_consumer_send
                                     53 	.globl _host_system_send
                                     54 	.globl _host_keyboard_leds
                                     55 	.globl _led_set
                                     56 	.globl _clear_keys_from_report
                                     57 	.globl _ADC_START
                                     58 	.globl _S0_R_FIFO
                                     59 	.globl _S0_T_FIFO
                                     60 	.globl _S0_FREE
                                     61 	.globl _S0_IF_BYTE
                                     62 	.globl _S0_IF_FIRST
                                     63 	.globl _S0_IF_OV
                                     64 	.globl _S0_FST_ACT
                                     65 	.globl _CP_RL2
                                     66 	.globl _C_T2
                                     67 	.globl _TR2
                                     68 	.globl _EXEN2
                                     69 	.globl _TCLK
                                     70 	.globl _RCLK
                                     71 	.globl _EXF2
                                     72 	.globl _CAP1F
                                     73 	.globl _TF2
                                     74 	.globl _RI
                                     75 	.globl _TI
                                     76 	.globl _RB8
                                     77 	.globl _TB8
                                     78 	.globl _REN
                                     79 	.globl _SM2
                                     80 	.globl _SM1
                                     81 	.globl _SM0
                                     82 	.globl _IT0
                                     83 	.globl _IE0
                                     84 	.globl _IT1
                                     85 	.globl _IE1
                                     86 	.globl _TR0
                                     87 	.globl _TF0
                                     88 	.globl _TR1
                                     89 	.globl _TF1
                                     90 	.globl _P4_0
                                     91 	.globl _P4_1
                                     92 	.globl _P4_2
                                     93 	.globl _P4_3
                                     94 	.globl _P4_4
                                     95 	.globl _P4_5
                                     96 	.globl _P4_6
                                     97 	.globl _RXD
                                     98 	.globl _TXD
                                     99 	.globl _INT0
                                    100 	.globl _INT1
                                    101 	.globl _T0
                                    102 	.globl _T1
                                    103 	.globl _MOSI1
                                    104 	.globl _MISO1
                                    105 	.globl _SCK1
                                    106 	.globl _P3_0
                                    107 	.globl _P3_1
                                    108 	.globl _P3_2
                                    109 	.globl _P3_3
                                    110 	.globl _P3_4
                                    111 	.globl _P3_5
                                    112 	.globl _P3_6
                                    113 	.globl _P3_7
                                    114 	.globl _CAP1_
                                    115 	.globl _T2_
                                    116 	.globl _CAP2_
                                    117 	.globl _T2EX_
                                    118 	.globl _RXD1
                                    119 	.globl _TXD1
                                    120 	.globl _P2_0
                                    121 	.globl _P2_1
                                    122 	.globl _P2_2
                                    123 	.globl _P2_3
                                    124 	.globl _P2_4
                                    125 	.globl _P2_5
                                    126 	.globl _P2_6
                                    127 	.globl _P2_7
                                    128 	.globl _AIN0
                                    129 	.globl _AIN1
                                    130 	.globl _AIN2
                                    131 	.globl _AIN3
                                    132 	.globl _AIN4
                                    133 	.globl _AIN5
                                    134 	.globl _AIN6
                                    135 	.globl _AIN7
                                    136 	.globl _CAP1
                                    137 	.globl _T2
                                    138 	.globl _CAP2
                                    139 	.globl _T2EX
                                    140 	.globl _INT0_
                                    141 	.globl _SCS
                                    142 	.globl _MOSI
                                    143 	.globl _MISO
                                    144 	.globl _SCK
                                    145 	.globl _RXD1_
                                    146 	.globl _TXD1_
                                    147 	.globl _P1_0
                                    148 	.globl _P1_1
                                    149 	.globl _P1_2
                                    150 	.globl _P1_3
                                    151 	.globl _P1_4
                                    152 	.globl _P1_5
                                    153 	.globl _P1_6
                                    154 	.globl _P1_7
                                    155 	.globl _AIN8
                                    156 	.globl _AIN9
                                    157 	.globl _AIN10
                                    158 	.globl _AIN11
                                    159 	.globl _AIN12
                                    160 	.globl _AIN13
                                    161 	.globl _RXD_
                                    162 	.globl _TXD_
                                    163 	.globl _SCL0
                                    164 	.globl _SDA0
                                    165 	.globl _P0_0
                                    166 	.globl _P0_1
                                    167 	.globl _P0_2
                                    168 	.globl _P0_3
                                    169 	.globl _P0_4
                                    170 	.globl _P0_5
                                    171 	.globl _P0_6
                                    172 	.globl _P0_7
                                    173 	.globl _IE_SPI0
                                    174 	.globl _IE_USB
                                    175 	.globl _IE_ADC
                                    176 	.globl _IE_UART1
                                    177 	.globl _IE_PWM_I2C
                                    178 	.globl _IE_GPIO
                                    179 	.globl _IE_WDOG
                                    180 	.globl _PX0
                                    181 	.globl _PT0
                                    182 	.globl _PX1
                                    183 	.globl _PT1
                                    184 	.globl _PS
                                    185 	.globl _PT2
                                    186 	.globl _PL_FLAG
                                    187 	.globl _PH_FLAG
                                    188 	.globl _EX0
                                    189 	.globl _ET0
                                    190 	.globl _EX1
                                    191 	.globl _ET1
                                    192 	.globl _ES
                                    193 	.globl _ET2
                                    194 	.globl _E_DIS
                                    195 	.globl _EA
                                    196 	.globl _P
                                    197 	.globl _F1
                                    198 	.globl _OV
                                    199 	.globl _RS0
                                    200 	.globl _RS1
                                    201 	.globl _F0
                                    202 	.globl _AC
                                    203 	.globl _CY
                                    204 	.globl _I2CS_INT_ST
                                    205 	.globl _I2CX_INT
                                    206 	.globl _LED_STATUS
                                    207 	.globl _LED_DMA_H
                                    208 	.globl _LED_DMA_L
                                    209 	.globl _LED_DMA
                                    210 	.globl _LED_PWM_OE
                                    211 	.globl _LED_COMMON
                                    212 	.globl _ADC_CHAN
                                    213 	.globl _ADC_DAT_H
                                    214 	.globl _ADC_DAT_L
                                    215 	.globl _ADC_DAT
                                    216 	.globl _ADC_CTRL
                                    217 	.globl _SPI1_CK_SE
                                    218 	.globl _SPI1_CTRL
                                    219 	.globl _SPI1_DATA
                                    220 	.globl _SPI1_STAT
                                    221 	.globl _SIF1
                                    222 	.globl _SBAUD1
                                    223 	.globl _SBUF1
                                    224 	.globl _SCON1
                                    225 	.globl _SPI0_SETUP
                                    226 	.globl _SPI0_CK_SE
                                    227 	.globl _SPI0_CTRL
                                    228 	.globl _SPI0_DATA
                                    229 	.globl _SPI0_STAT
                                    230 	.globl _T2CAP1H
                                    231 	.globl _T2CAP1L
                                    232 	.globl _T2CAP1
                                    233 	.globl _TH2
                                    234 	.globl _TL2
                                    235 	.globl _T2COUNT
                                    236 	.globl _RCAP2H
                                    237 	.globl _RCAP2L
                                    238 	.globl _RCAP2
                                    239 	.globl _T2MOD
                                    240 	.globl _T2CON
                                    241 	.globl _SBUF
                                    242 	.globl _SCON
                                    243 	.globl _TH1
                                    244 	.globl _TH0
                                    245 	.globl _TL1
                                    246 	.globl _TL0
                                    247 	.globl _TMOD
                                    248 	.globl _TCON
                                    249 	.globl _XBUS_AUX
                                    250 	.globl _P7
                                    251 	.globl _P6_DIR
                                    252 	.globl _P6_OUT_PU
                                    253 	.globl _P6_IN
                                    254 	.globl _P5_DIR
                                    255 	.globl _P5_OUT_PU
                                    256 	.globl _P5_IN
                                    257 	.globl _P4_LED_KEY
                                    258 	.globl _P4_DIR_PU
                                    259 	.globl _P4_MOD_OC
                                    260 	.globl _P4
                                    261 	.globl _P3_DIR_PU
                                    262 	.globl _P3_MOD_OC
                                    263 	.globl _P3
                                    264 	.globl _P2_DIR_PU
                                    265 	.globl _P2_MOD_OC
                                    266 	.globl _P2
                                    267 	.globl _P1_DIR_PU
                                    268 	.globl _P1_MOD_OC
                                    269 	.globl _P1
                                    270 	.globl _P0_DIR_PU
                                    271 	.globl _P0_MOD_OC
                                    272 	.globl _P0
                                    273 	.globl _ROM_CTRL
                                    274 	.globl _ROM_DATA_HH
                                    275 	.globl _ROM_DATA_HL
                                    276 	.globl _ROM_DATA_HI
                                    277 	.globl _ROM_ADDR_H
                                    278 	.globl _ROM_ADDR_L
                                    279 	.globl _ROM_ADDR
                                    280 	.globl _GPIO_IE
                                    281 	.globl _IP_EX
                                    282 	.globl _IE_EX
                                    283 	.globl _IP
                                    284 	.globl _IE
                                    285 	.globl _WDOG_COUNT
                                    286 	.globl _RESET_KEEP
                                    287 	.globl _WAKE_CTRL
                                    288 	.globl _CLOCK_CFG
                                    289 	.globl _POWER_CFG
                                    290 	.globl _PCON
                                    291 	.globl _GLOBAL_CFG
                                    292 	.globl _SAFE_MOD
                                    293 	.globl _DPH
                                    294 	.globl _DPL
                                    295 	.globl _SP
                                    296 	.globl _A_INV
                                    297 	.globl _B
                                    298 	.globl _ACC
                                    299 	.globl _PSW
                                    300 	.globl _disable_action_cache
                                    301 	.globl _tap_code_delay_PARM_2
                                    302 	.globl _process_action_PARM_2
                                    303 	.globl _action_exec_PARM_1
                                    304 	.globl _tp_buttons
                                    305 	.globl _action_exec
                                    306 	.globl _process_record
                                    307 	.globl _process_record_handler
                                    308 	.globl _process_action
                                    309 	.globl _register_code
                                    310 	.globl _unregister_code
                                    311 	.globl _tap_code_delay
                                    312 	.globl _tap_code
                                    313 	.globl _register_mods
                                    314 	.globl _unregister_mods
                                    315 	.globl _register_weak_mods
                                    316 	.globl _unregister_weak_mods
                                    317 	.globl _clear_keyboard
                                    318 	.globl _clear_keyboard_but_mods
                                    319 	.globl _clear_keyboard_but_mods_and_keys
                                    320 ;--------------------------------------------------------
                                    321 ; special function registers
                                    322 ;--------------------------------------------------------
                                    323 	.area RSEG    (ABS,DATA)
      000000                        324 	.org 0x0000
                           0000D0   325 _PSW	=	0x00d0
                           0000E0   326 _ACC	=	0x00e0
                           0000F0   327 _B	=	0x00f0
                           0000FD   328 _A_INV	=	0x00fd
                           000081   329 _SP	=	0x0081
                           000082   330 _DPL	=	0x0082
                           000083   331 _DPH	=	0x0083
                           0000A1   332 _SAFE_MOD	=	0x00a1
                           0000B1   333 _GLOBAL_CFG	=	0x00b1
                           000087   334 _PCON	=	0x0087
                           0000BA   335 _POWER_CFG	=	0x00ba
                           0000B9   336 _CLOCK_CFG	=	0x00b9
                           0000A9   337 _WAKE_CTRL	=	0x00a9
                           0000FE   338 _RESET_KEEP	=	0x00fe
                           0000FF   339 _WDOG_COUNT	=	0x00ff
                           0000A8   340 _IE	=	0x00a8
                           0000B8   341 _IP	=	0x00b8
                           0000E8   342 _IE_EX	=	0x00e8
                           0000E9   343 _IP_EX	=	0x00e9
                           0000B2   344 _GPIO_IE	=	0x00b2
                           008584   345 _ROM_ADDR	=	0x8584
                           000084   346 _ROM_ADDR_L	=	0x0084
                           000085   347 _ROM_ADDR_H	=	0x0085
                           008F8E   348 _ROM_DATA_HI	=	0x8f8e
                           00008E   349 _ROM_DATA_HL	=	0x008e
                           00008F   350 _ROM_DATA_HH	=	0x008f
                           000086   351 _ROM_CTRL	=	0x0086
                           000080   352 _P0	=	0x0080
                           0000C4   353 _P0_MOD_OC	=	0x00c4
                           0000C5   354 _P0_DIR_PU	=	0x00c5
                           000090   355 _P1	=	0x0090
                           000092   356 _P1_MOD_OC	=	0x0092
                           000093   357 _P1_DIR_PU	=	0x0093
                           0000A0   358 _P2	=	0x00a0
                           000094   359 _P2_MOD_OC	=	0x0094
                           000095   360 _P2_DIR_PU	=	0x0095
                           0000B0   361 _P3	=	0x00b0
                           000096   362 _P3_MOD_OC	=	0x0096
                           000097   363 _P3_DIR_PU	=	0x0097
                           0000C0   364 _P4	=	0x00c0
                           0000C2   365 _P4_MOD_OC	=	0x00c2
                           0000C3   366 _P4_DIR_PU	=	0x00c3
                           0000C1   367 _P4_LED_KEY	=	0x00c1
                           0000AA   368 _P5_IN	=	0x00aa
                           0000AB   369 _P5_OUT_PU	=	0x00ab
                           0000AC   370 _P5_DIR	=	0x00ac
                           0000AD   371 _P6_IN	=	0x00ad
                           0000AE   372 _P6_OUT_PU	=	0x00ae
                           0000AF   373 _P6_DIR	=	0x00af
                           0000F1   374 _P7	=	0x00f1
                           0000A2   375 _XBUS_AUX	=	0x00a2
                           000088   376 _TCON	=	0x0088
                           000089   377 _TMOD	=	0x0089
                           00008A   378 _TL0	=	0x008a
                           00008B   379 _TL1	=	0x008b
                           00008C   380 _TH0	=	0x008c
                           00008D   381 _TH1	=	0x008d
                           000098   382 _SCON	=	0x0098
                           000099   383 _SBUF	=	0x0099
                           0000C8   384 _T2CON	=	0x00c8
                           0000C9   385 _T2MOD	=	0x00c9
                           00CBCA   386 _RCAP2	=	0xcbca
                           0000CA   387 _RCAP2L	=	0x00ca
                           0000CB   388 _RCAP2H	=	0x00cb
                           00CDCC   389 _T2COUNT	=	0xcdcc
                           0000CC   390 _TL2	=	0x00cc
                           0000CD   391 _TH2	=	0x00cd
                           00CFCE   392 _T2CAP1	=	0xcfce
                           0000CE   393 _T2CAP1L	=	0x00ce
                           0000CF   394 _T2CAP1H	=	0x00cf
                           0000F8   395 _SPI0_STAT	=	0x00f8
                           0000F9   396 _SPI0_DATA	=	0x00f9
                           0000FA   397 _SPI0_CTRL	=	0x00fa
                           0000FB   398 _SPI0_CK_SE	=	0x00fb
                           0000FC   399 _SPI0_SETUP	=	0x00fc
                           0000BC   400 _SCON1	=	0x00bc
                           0000BD   401 _SBUF1	=	0x00bd
                           0000BE   402 _SBAUD1	=	0x00be
                           0000BF   403 _SIF1	=	0x00bf
                           0000B4   404 _SPI1_STAT	=	0x00b4
                           0000B5   405 _SPI1_DATA	=	0x00b5
                           0000B6   406 _SPI1_CTRL	=	0x00b6
                           0000B7   407 _SPI1_CK_SE	=	0x00b7
                           0000F3   408 _ADC_CTRL	=	0x00f3
                           00F5F4   409 _ADC_DAT	=	0xf5f4
                           0000F4   410 _ADC_DAT_L	=	0x00f4
                           0000F5   411 _ADC_DAT_H	=	0x00f5
                           0000F6   412 _ADC_CHAN	=	0x00f6
                           0000A6   413 _LED_COMMON	=	0x00a6
                           0000A7   414 _LED_PWM_OE	=	0x00a7
                           00C7C6   415 _LED_DMA	=	0xc7c6
                           0000C6   416 _LED_DMA_L	=	0x00c6
                           0000C7   417 _LED_DMA_H	=	0x00c7
                           0000F7   418 _LED_STATUS	=	0x00f7
                           0000B3   419 _I2CX_INT	=	0x00b3
                           0000BB   420 _I2CS_INT_ST	=	0x00bb
                                    421 ;--------------------------------------------------------
                                    422 ; special function bits
                                    423 ;--------------------------------------------------------
                                    424 	.area RSEG    (ABS,DATA)
      000000                        425 	.org 0x0000
                           0000D7   426 _CY	=	0x00d7
                           0000D6   427 _AC	=	0x00d6
                           0000D5   428 _F0	=	0x00d5
                           0000D4   429 _RS1	=	0x00d4
                           0000D3   430 _RS0	=	0x00d3
                           0000D2   431 _OV	=	0x00d2
                           0000D1   432 _F1	=	0x00d1
                           0000D0   433 _P	=	0x00d0
                           0000AF   434 _EA	=	0x00af
                           0000AE   435 _E_DIS	=	0x00ae
                           0000AD   436 _ET2	=	0x00ad
                           0000AC   437 _ES	=	0x00ac
                           0000AB   438 _ET1	=	0x00ab
                           0000AA   439 _EX1	=	0x00aa
                           0000A9   440 _ET0	=	0x00a9
                           0000A8   441 _EX0	=	0x00a8
                           0000BF   442 _PH_FLAG	=	0x00bf
                           0000BE   443 _PL_FLAG	=	0x00be
                           0000BD   444 _PT2	=	0x00bd
                           0000BC   445 _PS	=	0x00bc
                           0000BB   446 _PT1	=	0x00bb
                           0000BA   447 _PX1	=	0x00ba
                           0000B9   448 _PT0	=	0x00b9
                           0000B8   449 _PX0	=	0x00b8
                           0000EF   450 _IE_WDOG	=	0x00ef
                           0000EE   451 _IE_GPIO	=	0x00ee
                           0000ED   452 _IE_PWM_I2C	=	0x00ed
                           0000EC   453 _IE_UART1	=	0x00ec
                           0000EB   454 _IE_ADC	=	0x00eb
                           0000E9   455 _IE_USB	=	0x00e9
                           0000E8   456 _IE_SPI0	=	0x00e8
                           000087   457 _P0_7	=	0x0087
                           000086   458 _P0_6	=	0x0086
                           000085   459 _P0_5	=	0x0085
                           000084   460 _P0_4	=	0x0084
                           000083   461 _P0_3	=	0x0083
                           000082   462 _P0_2	=	0x0082
                           000081   463 _P0_1	=	0x0081
                           000080   464 _P0_0	=	0x0080
                           000081   465 _SDA0	=	0x0081
                           000080   466 _SCL0	=	0x0080
                           000083   467 _TXD_	=	0x0083
                           000082   468 _RXD_	=	0x0082
                           000085   469 _AIN13	=	0x0085
                           000084   470 _AIN12	=	0x0084
                           000083   471 _AIN11	=	0x0083
                           000082   472 _AIN10	=	0x0082
                           000081   473 _AIN9	=	0x0081
                           000080   474 _AIN8	=	0x0080
                           000097   475 _P1_7	=	0x0097
                           000096   476 _P1_6	=	0x0096
                           000095   477 _P1_5	=	0x0095
                           000094   478 _P1_4	=	0x0094
                           000093   479 _P1_3	=	0x0093
                           000092   480 _P1_2	=	0x0092
                           000091   481 _P1_1	=	0x0091
                           000090   482 _P1_0	=	0x0090
                           000097   483 _TXD1_	=	0x0097
                           000096   484 _RXD1_	=	0x0096
                           000097   485 _SCK	=	0x0097
                           000096   486 _MISO	=	0x0096
                           000095   487 _MOSI	=	0x0095
                           000094   488 _SCS	=	0x0094
                           000092   489 _INT0_	=	0x0092
                           000091   490 _T2EX	=	0x0091
                           000091   491 _CAP2	=	0x0091
                           000090   492 _T2	=	0x0090
                           000090   493 _CAP1	=	0x0090
                           000097   494 _AIN7	=	0x0097
                           000096   495 _AIN6	=	0x0096
                           000095   496 _AIN5	=	0x0095
                           000094   497 _AIN4	=	0x0094
                           000093   498 _AIN3	=	0x0093
                           000092   499 _AIN2	=	0x0092
                           000091   500 _AIN1	=	0x0091
                           000090   501 _AIN0	=	0x0090
                           0000A7   502 _P2_7	=	0x00a7
                           0000A6   503 _P2_6	=	0x00a6
                           0000A5   504 _P2_5	=	0x00a5
                           0000A4   505 _P2_4	=	0x00a4
                           0000A3   506 _P2_3	=	0x00a3
                           0000A2   507 _P2_2	=	0x00a2
                           0000A1   508 _P2_1	=	0x00a1
                           0000A0   509 _P2_0	=	0x00a0
                           0000A7   510 _TXD1	=	0x00a7
                           0000A6   511 _RXD1	=	0x00a6
                           0000A5   512 _T2EX_	=	0x00a5
                           0000A5   513 _CAP2_	=	0x00a5
                           0000A4   514 _T2_	=	0x00a4
                           0000A4   515 _CAP1_	=	0x00a4
                           0000B7   516 _P3_7	=	0x00b7
                           0000B6   517 _P3_6	=	0x00b6
                           0000B5   518 _P3_5	=	0x00b5
                           0000B4   519 _P3_4	=	0x00b4
                           0000B3   520 _P3_3	=	0x00b3
                           0000B2   521 _P3_2	=	0x00b2
                           0000B1   522 _P3_1	=	0x00b1
                           0000B0   523 _P3_0	=	0x00b0
                           0000B7   524 _SCK1	=	0x00b7
                           0000B6   525 _MISO1	=	0x00b6
                           0000B5   526 _MOSI1	=	0x00b5
                           0000B5   527 _T1	=	0x00b5
                           0000B4   528 _T0	=	0x00b4
                           0000B3   529 _INT1	=	0x00b3
                           0000B2   530 _INT0	=	0x00b2
                           0000B1   531 _TXD	=	0x00b1
                           0000B0   532 _RXD	=	0x00b0
                           0000C6   533 _P4_6	=	0x00c6
                           0000C5   534 _P4_5	=	0x00c5
                           0000C4   535 _P4_4	=	0x00c4
                           0000C3   536 _P4_3	=	0x00c3
                           0000C2   537 _P4_2	=	0x00c2
                           0000C1   538 _P4_1	=	0x00c1
                           0000C0   539 _P4_0	=	0x00c0
                           00008F   540 _TF1	=	0x008f
                           00008E   541 _TR1	=	0x008e
                           00008D   542 _TF0	=	0x008d
                           00008C   543 _TR0	=	0x008c
                           00008B   544 _IE1	=	0x008b
                           00008A   545 _IT1	=	0x008a
                           000089   546 _IE0	=	0x0089
                           000088   547 _IT0	=	0x0088
                           00009F   548 _SM0	=	0x009f
                           00009E   549 _SM1	=	0x009e
                           00009D   550 _SM2	=	0x009d
                           00009C   551 _REN	=	0x009c
                           00009B   552 _TB8	=	0x009b
                           00009A   553 _RB8	=	0x009a
                           000099   554 _TI	=	0x0099
                           000098   555 _RI	=	0x0098
                           0000CF   556 _TF2	=	0x00cf
                           0000CF   557 _CAP1F	=	0x00cf
                           0000CE   558 _EXF2	=	0x00ce
                           0000CD   559 _RCLK	=	0x00cd
                           0000CC   560 _TCLK	=	0x00cc
                           0000CB   561 _EXEN2	=	0x00cb
                           0000CA   562 _TR2	=	0x00ca
                           0000C9   563 _C_T2	=	0x00c9
                           0000C8   564 _CP_RL2	=	0x00c8
                           0000FF   565 _S0_FST_ACT	=	0x00ff
                           0000FE   566 _S0_IF_OV	=	0x00fe
                           0000FD   567 _S0_IF_FIRST	=	0x00fd
                           0000FC   568 _S0_IF_BYTE	=	0x00fc
                           0000FB   569 _S0_FREE	=	0x00fb
                           0000FA   570 _S0_T_FIFO	=	0x00fa
                           0000F8   571 _S0_R_FIFO	=	0x00f8
                           0000F7   572 _ADC_START	=	0x00f7
                                    573 ;--------------------------------------------------------
                                    574 ; overlayable register banks
                                    575 ;--------------------------------------------------------
                                    576 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        577 	.ds 8
                                    578 ;--------------------------------------------------------
                                    579 ; internal ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area DSEG    (DATA)
      000019                        582 _process_action_sloc0_1_0:
      000019                        583 	.ds 1
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable items in internal ram
                                    586 ;--------------------------------------------------------
                                    587 ;--------------------------------------------------------
                                    588 ; indirectly addressable internal ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area ISEG    (DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; absolute internal ram data
                                    593 ;--------------------------------------------------------
                                    594 	.area IABS    (ABS,DATA)
                                    595 	.area IABS    (ABS,DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; bit data
                                    598 ;--------------------------------------------------------
                                    599 	.area BSEG    (BIT)
      000018                        600 _process_action_sloc1_1_0:
      000018                        601 	.ds 1
                                    602 ;--------------------------------------------------------
                                    603 ; paged external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area PSEG    (PAG,XDATA)
                                    606 ;--------------------------------------------------------
                                    607 ; uninitialized external ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area XSEG    (XDATA)
      000805                        610 _tp_buttons::
      000805                        611 	.ds 2
      000807                        612 _action_exec_PARM_1:
      000807                        613 	.ds 6
      00080D                        614 _action_exec_record_10001_613:
      00080D                        615 	.ds 9
      000816                        616 _process_record_record_10000_619:
      000816                        617 	.ds 3
      000819                        618 _process_record_handler_record_10000_625:
      000819                        619 	.ds 3
      00081C                        620 _process_record_handler_action_10000_626:
      00081C                        621 	.ds 2
      00081E                        622 _process_action_PARM_2:
      00081E                        623 	.ds 2
      000820                        624 _process_action_record_10000_637:
      000820                        625 	.ds 3
      000823                        626 _process_action_on_40000_660:
      000823                        627 	.ds 1
      000824                        628 _register_code_code_10000_694:
      000824                        629 	.ds 1
      000825                        630 _unregister_code_code_10000_708:
      000825                        631 	.ds 1
      000826                        632 _tap_code_delay_PARM_2:
      000826                        633 	.ds 2
      000828                        634 _tap_code_delay_code_10000_721:
      000828                        635 	.ds 1
      000829                        636 _tap_code_code_10000_728:
      000829                        637 	.ds 1
      00082A                        638 _register_mods_mods_10000_730:
      00082A                        639 	.ds 1
      00082B                        640 _unregister_mods_mods_10000_734:
      00082B                        641 	.ds 1
      00082C                        642 _register_weak_mods_mods_10000_738:
      00082C                        643 	.ds 1
      00082D                        644 _unregister_weak_mods_mods_10000_742:
      00082D                        645 	.ds 1
                                    646 ;--------------------------------------------------------
                                    647 ; absolute external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XABS    (ABS,XDATA)
                                    650 ;--------------------------------------------------------
                                    651 ; initialized external ram data
                                    652 ;--------------------------------------------------------
                                    653 	.area XISEG   (XDATA)
      000DD2                        654 _disable_action_cache::
      000DD2                        655 	.ds 1
                                    656 	.area HOME    (CODE)
                                    657 	.area GSINIT0 (CODE)
                                    658 	.area GSINIT1 (CODE)
                                    659 	.area GSINIT2 (CODE)
                                    660 	.area GSINIT3 (CODE)
                                    661 	.area GSINIT4 (CODE)
                                    662 	.area GSINIT5 (CODE)
                                    663 	.area GSINIT  (CODE)
                                    664 	.area GSFINAL (CODE)
                                    665 	.area CSEG    (CODE)
                                    666 ;--------------------------------------------------------
                                    667 ; global & static initialisations
                                    668 ;--------------------------------------------------------
                                    669 	.area HOME    (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 	.area GSFINAL (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 ;--------------------------------------------------------
                                    674 ; Home
                                    675 ;--------------------------------------------------------
                                    676 	.area HOME    (CODE)
                                    677 	.area HOME    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; code
                                    680 ;--------------------------------------------------------
                                    681 	.area CSEG    (CODE)
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    684 ;------------------------------------------------------------
                                    685 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    686 ;------------------------------------------------------------
                                    687 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    688 ;	-----------------------------------------
                           000007   689 	ar7 = 0x07
                           000006   690 	ar6 = 0x06
                           000005   691 	ar5 = 0x05
                           000004   692 	ar4 = 0x04
                           000003   693 	ar3 = 0x03
                           000002   694 	ar2 = 0x02
                           000001   695 	ar1 = 0x01
                           000000   696 	ar0 = 0x00
                                    697 ;	 function action_exec
                                    698 ;	-----------------------------------------
      0070A5                        699 _action_exec:
                                    700 ;	quantum/action.c:83: ak820_combo_tick(event.time);
      0070A5 90 08 09         [24]  701 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0070A8 12 43 C5         [24]  702 	lcall	_ak820_outline_0000
      0070AB 12 43 D3         [24]  703 	lcall	_ak820_outline_0002
      0070AE 12 36 BC         [24]  704 	lcall	_ak820_combo_tick
                                    705 ;	quantum/action.c:86: if (!ak820_tapping_before(&event)) return;
      0070B1 90 08 07         [24]  706 	mov	dptr,#_action_exec_PARM_1
      0070B4 12 45 73         [24]  707 	lcall	_ak820_tapping_before
      0070B7 E5 82            [12]  708 	mov	a, dpl
      0070B9 70 01            [24]  709 	jnz	00102$
      0070BB 22               [24]  710 	ret
      0070BC                        711 00102$:
                                    712 ;	quantum/action.c:101: if (event.pressed) {
      0070BC 90 08 0C         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0070BF E0               [24]  714 	movx	a,@dptr
      0070C0 60 03            [24]  715 	jz	00104$
                                    716 ;	quantum/action.c:103: clear_weak_mods();
      0070C2 12 81 22         [24]  717 	lcall	_clear_weak_mods
      0070C5                        718 00104$:
                                    719 ;	quantum/action.c:115: record.event = event;
      0070C5 90 0D B3         [24]  720 	mov	dptr,#___memcpy_PARM_2
      0070C8 74 07            [12]  721 	mov	a,#_action_exec_PARM_1
      0070CA F0               [24]  722 	movx	@dptr,a
      0070CB 74 08            [12]  723 	mov	a,#(_action_exec_PARM_1 >> 8)
      0070CD A3               [24]  724 	inc	dptr
      0070CE 12 4E 60         [24]  725 	lcall	_ak820_outline_0003
      0070D1 90 0D B6         [24]  726 	mov	dptr,#___memcpy_PARM_3
      0070D4 74 06            [12]  727 	mov	a,#0x06
      0070D6 12 4E 60         [24]  728 	lcall	_ak820_outline_0003
      0070D9 90 08 0D         [24]  729 	mov	dptr,#_action_exec_record_10001_613
      0070DC F5 F0            [12]  730 	mov	b,a
      0070DE 12 BD 3B         [24]  731 	lcall	___memcpy
                                    732 ;	quantum/action.c:117: record.tap.count = 0;
      0070E1 90 08 13         [24]  733 	mov	dptr,#(_action_exec_record_10001_613 + 0x0006)
      0070E4 E0               [24]  734 	movx	a,@dptr
      0070E5 54 0F            [12]  735 	anl	a,#0x0f
      0070E7 F0               [24]  736 	movx	@dptr,a
                                    737 ;	quantum/action.c:122: record.keycode = 0;
      0070E8 90 08 14         [24]  738 	mov	dptr,#(_action_exec_record_10001_613 + 0x0007)
      0070EB 12 4E 8D         [24]  739 	lcall	_ak820_outline_0098
                                    740 ;	quantum/action.c:153: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0070EE 90 08 11         [24]  741 	mov	dptr,#(_action_exec_record_10001_613 + 0x0004)
      0070F1 E0               [24]  742 	movx	a,@dptr
      0070F2 60 0D            [24]  743 	jz	00107$
      0070F4 90 08 0D         [24]  744 	mov	dptr,#_action_exec_record_10001_613
      0070F7 75 F0 00         [24]  745 	mov	b, #0x00
      0070FA 12 A2 EA         [24]  746 	lcall	_pre_process_record_quantum
      0070FD E5 82            [12]  747 	mov	a, dpl
      0070FF 60 14            [24]  748 	jz	00110$
      007101                        749 00107$:
                                    750 ;	quantum/action.c:155: if (!ak820_tapping_process(&record)) return;
      007101 90 08 0D         [24]  751 	mov	dptr,#_action_exec_record_10001_613
      007104 12 46 C7         [24]  752 	lcall	_ak820_tapping_process
      007107 E5 82            [12]  753 	mov	a, dpl
      007109 70 01            [24]  754 	jnz	00106$
      00710B 22               [24]  755 	ret
      00710C                        756 00106$:
                                    757 ;	quantum/action.c:157: process_record(&record);
      00710C 90 08 0D         [24]  758 	mov	dptr,#_action_exec_record_10001_613
      00710F 75 F0 00         [24]  759 	mov	b, #0x00
                                    760 ;	quantum/action.c:167: }
      007112 02 71 16         [24]  761 	ljmp	_process_record
      007115                        762 00110$:
      007115 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'process_record_nocache'
                                    766 ;------------------------------------------------------------
                                    767 ;record        Allocated with name '_process_record_nocache_record_10000_617'
                                    768 ;------------------------------------------------------------
                                    769 ;	quantum/action.c:251: void process_record_nocache(keyrecord_t *record) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function process_record
                                    772 ;	-----------------------------------------
      007116                        773 _process_record:
      007116 12 43 D8         [24]  774 	lcall	_ak820_outline_0004
      007119 90 08 16         [24]  775 	mov	dptr,#_process_record_record_10000_619
      00711C 12 43 CB         [24]  776 	lcall	_ak820_outline_0001
                                    777 ;	quantum/action.c:305: if (IS_NOEVENT(record->event)) {
      00711F 90 08 16         [24]  778 	mov	dptr,#_process_record_record_10000_619
      007122 E0               [24]  779 	movx	a,@dptr
      007123 FD               [12]  780 	mov	r5,a
      007124 A3               [24]  781 	inc	dptr
      007125 12 43 C5         [24]  782 	lcall	_ak820_outline_0000
      007128 74 04            [12]  783 	mov	a,#0x04
      00712A 12 76 A5         [24]  784 	lcall	_ak820_outline_0009
      00712D 12 BE 14         [24]  785 	lcall	__gptrget
      007130 70 01            [24]  786 	jnz	00102$
                                    787 ;	quantum/action.c:306: return;
      007132 22               [24]  788 	ret
      007133                        789 00102$:
                                    790 ;	quantum/action.c:309: if (!process_record_quantum(record)) {
      007133 12 4E 65         [24]  791 	lcall	_ak820_outline_0005
      007136 C0 07            [24]  792 	push	ar7
      007138 C0 06            [24]  793 	push	ar6
      00713A C0 05            [24]  794 	push	ar5
      00713C 12 A3 8A         [24]  795 	lcall	_process_record_quantum
      00713F E5 82            [12]  796 	mov	a, dpl
      007141 D0 05            [24]  797 	pop	ar5
      007143 D0 06            [24]  798 	pop	ar6
      007145 D0 07            [24]  799 	pop	ar7
      007147 70 01            [24]  800 	jnz	00104$
                                    801 ;	quantum/action.c:315: return;
      007149 22               [24]  802 	ret
      00714A                        803 00104$:
                                    804 ;	quantum/action.c:318: process_record_handler(record);
      00714A 12 4E 65         [24]  805 	lcall	_ak820_outline_0005
      00714D 12 71 5F         [24]  806 	lcall	_process_record_handler
                                    807 ;	quantum/action.c:319: post_process_record_quantum(record);
      007150 90 08 16         [24]  808 	mov	dptr,#_process_record_record_10000_619
      007153 E0               [24]  809 	movx	a,@dptr
      007154 FD               [12]  810 	mov	r5,a
      007155 A3               [24]  811 	inc	dptr
      007156 12 43 C5         [24]  812 	lcall	_ak820_outline_0000
      007159 12 4E 65         [24]  813 	lcall	_ak820_outline_0005
                                    814 ;	quantum/action.c:320: }
      00715C 02 A3 55         [24]  815 	ljmp	_post_process_record_quantum
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'process_record_handler'
                                    818 ;------------------------------------------------------------
                                    819 ;record        Allocated with name '_process_record_handler_record_10000_625'
                                    820 ;action        Allocated with name '_process_record_handler_action_10000_626'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/action.c:322: void process_record_handler(keyrecord_t *record) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function process_record_handler
                                    825 ;	-----------------------------------------
      00715F                        826 _process_record_handler:
      00715F 12 43 D8         [24]  827 	lcall	_ak820_outline_0004
      007162 90 08 19         [24]  828 	mov	dptr,#_process_record_handler_record_10000_625
      007165 12 43 CB         [24]  829 	lcall	_ak820_outline_0001
                                    830 ;	quantum/action.c:326: if (record->keycode) {
      007168 90 08 19         [24]  831 	mov	dptr,#_process_record_handler_record_10000_625
      00716B E0               [24]  832 	movx	a,@dptr
      00716C FD               [12]  833 	mov	r5,a
      00716D A3               [24]  834 	inc	dptr
      00716E 12 43 C5         [24]  835 	lcall	_ak820_outline_0000
      007171 12 76 C1         [24]  836 	lcall	_ak820_outline_0052
      007174 12 BE 14         [24]  837 	lcall	__gptrget
      007177 FB               [12]  838 	mov	r3,a
      007178 A3               [24]  839 	inc	dptr
      007179 12 BE 14         [24]  840 	lcall	__gptrget
      00717C FC               [12]  841 	mov	r4,a
      00717D 4B               [12]  842 	orl	a,r3
      00717E 60 12            [24]  843 	jz	00102$
                                    844 ;	quantum/action.c:327: action.code = action_for_keycode(record->keycode);
      007180 12 43 F9         [24]  845 	lcall	_ak820_outline_0014
      007183 12 96 CC         [24]  846 	lcall	_action_for_keycode
      007186 AB 82            [24]  847 	mov	r3, dpl
      007188 AC 83            [24]  848 	mov	r4, dph
      00718A 90 08 1C         [24]  849 	mov	dptr,#_process_record_handler_action_10000_626
      00718D 12 44 50         [24]  850 	lcall	_ak820_outline_0060
      007190 80 33            [24]  851 	sjmp	00104$
      007192                        852 00102$:
                                    853 ;	quantum/action.c:329: action.code = store_or_get_action(record->event.pressed, record->event.key);
      007192 74 05            [12]  854 	mov	a,#0x05
      007194 12 76 A5         [24]  855 	lcall	_ak820_outline_0009
      007197 12 BE 14         [24]  856 	lcall	__gptrget
      00719A FA               [12]  857 	mov	r2,a
      00719B 90 0D B3         [24]  858 	mov	dptr,#___memcpy_PARM_2
      00719E ED               [12]  859 	mov	a,r5
      00719F 12 43 CB         [24]  860 	lcall	_ak820_outline_0001
      0071A2 90 0D B6         [24]  861 	mov	dptr,#___memcpy_PARM_3
      0071A5 74 02            [12]  862 	mov	a,#0x02
      0071A7 12 4E 60         [24]  863 	lcall	_ak820_outline_0003
      0071AA 90 09 58         [24]  864 	mov	dptr,#_store_or_get_action_PARM_2
      0071AD F5 F0            [12]  865 	mov	b,a
      0071AF C0 02            [24]  866 	push	ar2
      0071B1 12 BD 3B         [24]  867 	lcall	___memcpy
      0071B4 D0 02            [24]  868 	pop	ar2
      0071B6 8A 82            [24]  869 	mov	dpl, r2
      0071B8 12 7A 5E         [24]  870 	lcall	_store_or_get_action
      0071BB 12 44 1D         [24]  871 	lcall	_ak820_outline_0027
      0071BE 90 08 1C         [24]  872 	mov	dptr,#_process_record_handler_action_10000_626
      0071C1 EE               [12]  873 	mov	a,r6
      0071C2 12 43 E5         [24]  874 	lcall	_ak820_outline_0007
                                    875 ;	quantum/action.c:335: ac_dprintf("ACTION: ");
      0071C5                        876 00104$:
                                    877 ;	quantum/action.c:346: process_action(record, action);
      0071C5 90 08 19         [24]  878 	mov	dptr,#_process_record_handler_record_10000_625
      0071C8 E0               [24]  879 	movx	a,@dptr
      0071C9 FD               [12]  880 	mov	r5,a
      0071CA A3               [24]  881 	inc	dptr
      0071CB 12 43 C5         [24]  882 	lcall	_ak820_outline_0000
      0071CE 90 0D B3         [24]  883 	mov	dptr,#___memcpy_PARM_2
      0071D1 74 1C            [12]  884 	mov	a,#_process_record_handler_action_10000_626
      0071D3 F0               [24]  885 	movx	@dptr,a
      0071D4 74 08            [12]  886 	mov	a,#(_process_record_handler_action_10000_626 >> 8)
      0071D6 A3               [24]  887 	inc	dptr
      0071D7 12 4E 60         [24]  888 	lcall	_ak820_outline_0003
      0071DA 90 0D B6         [24]  889 	mov	dptr,#___memcpy_PARM_3
      0071DD 74 02            [12]  890 	mov	a,#0x02
      0071DF 12 4E 60         [24]  891 	lcall	_ak820_outline_0003
      0071E2 90 08 1E         [24]  892 	mov	dptr,#_process_action_PARM_2
      0071E5 F5 F0            [12]  893 	mov	b,a
      0071E7 C0 07            [24]  894 	push	ar7
      0071E9 C0 06            [24]  895 	push	ar6
      0071EB C0 05            [24]  896 	push	ar5
      0071ED 12 BD 3B         [24]  897 	lcall	___memcpy
      0071F0 D0 05            [24]  898 	pop	ar5
      0071F2 D0 06            [24]  899 	pop	ar6
      0071F4 D0 07            [24]  900 	pop	ar7
      0071F6 12 4E 65         [24]  901 	lcall	_ak820_outline_0005
                                    902 ;	quantum/action.c:347: }
      0071F9 02 71 FC         [24]  903 	ljmp	_process_action
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'register_mouse'
                                    906 ;------------------------------------------------------------
                                    907 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    908 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_634'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/action.c:359: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function process_action
                                    913 ;	-----------------------------------------
      0071FC                        914 _process_action:
      0071FC 12 43 D8         [24]  915 	lcall	_ak820_outline_0004
      0071FF 90 08 20         [24]  916 	mov	dptr,#_process_action_record_10000_637
      007202 12 43 CB         [24]  917 	lcall	_ak820_outline_0001
                                    918 ;	quantum/action.c:413: pressed = record->event.pressed;
      007205 90 08 20         [24]  919 	mov	dptr,#_process_action_record_10000_637
      007208 E0               [24]  920 	movx	a,@dptr
      007209 FE               [12]  921 	mov	r6,a
      00720A A3               [24]  922 	inc	dptr
      00720B E0               [24]  923 	movx	a,@dptr
      00720C FD               [12]  924 	mov	r5,a
      00720D A3               [24]  925 	inc	dptr
      00720E E0               [24]  926 	movx	a,@dptr
      00720F FF               [12]  927 	mov	r7,a
      007210 74 05            [12]  928 	mov	a,#0x05
      007212 2E               [12]  929 	add	a, r6
      007213 FA               [12]  930 	mov	r2,a
      007214 E4               [12]  931 	clr	a
      007215 3D               [12]  932 	addc	a, r5
      007216 FB               [12]  933 	mov	r3,a
      007217 8F 04            [24]  934 	mov	ar4,r7
      007219 12 44 22         [24]  935 	lcall	_ak820_outline_0033
      00721C 8C F0            [24]  936 	mov	b,r4
      00721E 12 BE 14         [24]  937 	lcall	__gptrget
      007221 F5 19            [12]  938 	mov	_process_action_sloc0_1_0,a
                                    939 ;	quantum/action.c:437: switch (action.kind.id) {
      007223 90 08 1F         [24]  940 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007226 E0               [24]  941 	movx	a,@dptr
      007227 C4               [12]  942 	swap	a
      007228 54 0F            [12]  943 	anl	a,#0x0f
      00722A FC               [12]  944 	mov  r4,a
      00722B 24 F4            [12]  945 	add	a,#0xff - 0x0b
      00722D 50 03            [24]  946 	jnc	00434$
      00722F 02 74 D6         [24]  947 	ljmp	00181$
      007232                        948 00434$:
                                    949 ;	free result
      007232 EC               [12]  950 	mov	a,r4
      007233 24 0A            [12]  951 	add	a,#(00435$-3-.)
      007235 83               [24]  952 	movc	a,@a+pc
      007236 F5 82            [12]  953 	mov	dpl,a
      007238 EC               [12]  954 	mov	a,r4
      007239 24 10            [12]  955 	add	a,#(00436$-3-.)
      00723B 83               [24]  956 	movc	a,@a+pc
      00723C F5 83            [12]  957 	mov	dph,a
      00723E E4               [12]  958 	clr	a
      00723F 73               [24]  959 	jmp	@a+dptr
      007240                        960 00435$:
      007240 58                     961 	.db	00102$
      007241 58                     962 	.db	00102$
      007242 D6                     963 	.db	00181$
      007243 D6                     964 	.db	00181$
      007244 E6                     965 	.db	00123$
      007245 D6                     966 	.db	00181$
      007246 D6                     967 	.db	00181$
      007247 D6                     968 	.db	00181$
      007248 63                     969 	.db	00131$
      007249 35                     970 	.db	00147$
      00724A 5F                     971 	.db	00152$
      00724B 5F                     972 	.db	00152$
      00724C                        973 00436$:
      00724C 72                     974 	.db	00102$>>8
      00724D 72                     975 	.db	00102$>>8
      00724E 74                     976 	.db	00181$>>8
      00724F 74                     977 	.db	00181$>>8
      007250 72                     978 	.db	00123$>>8
      007251 74                     979 	.db	00181$>>8
      007252 74                     980 	.db	00181$>>8
      007253 74                     981 	.db	00181$>>8
      007254 73                     982 	.db	00131$>>8
      007255 74                     983 	.db	00147$>>8
      007256 74                     984 	.db	00152$>>8
      007257 74                     985 	.db	00152$>>8
                                    986 ;	quantum/action.c:440: case ACT_RMODS: {
      007258                        987 00102$:
                                    988 ;	quantum/action.c:441: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007258 90 08 1F         [24]  989 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00725B E0               [24]  990 	movx	a,@dptr
      00725C 54 F0            [12]  991 	anl	a,#0xf0
      00725E 70 06            [24]  992 	jnz	00194$
      007260 12 76 DA         [24]  993 	lcall	_ak820_outline_0076
      007263 FC               [12]  994 	mov	r4,a
      007264 80 07            [24]  995 	sjmp	00195$
      007266                        996 00194$:
      007266 12 76 DA         [24]  997 	lcall	_ak820_outline_0076
      007269 C4               [12]  998 	swap	a
      00726A 54 F0            [12]  999 	anl	a,#0xf0
      00726C FC               [12] 1000 	mov	r4,a
      00726D                       1001 00195$:
                                   1002 ;	quantum/action.c:443: if (pressed) {
      00726D E5 19            [12] 1003 	mov	a,_process_action_sloc0_1_0
      00726F 60 37            [24] 1004 	jz	00119$
                                   1005 ;	quantum/action.c:444: if (mods) {
      007271 EC               [12] 1006 	mov	a,r4
      007272 60 29            [24] 1007 	jz	00110$
                                   1008 ;	quantum/action.c:445: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007274 12 76 BC         [24] 1009 	lcall	_ak820_outline_0044
      007277 FB               [12] 1010 	mov	r3,a
      007278 BB E0 00         [24] 1011 	cjne	r3,#0xe0,00440$
      00727B                       1012 00440$:
      00727B 40 07            [24] 1013 	jc	00108$
      00727D 12 76 BC         [24] 1014 	lcall	_ak820_outline_0044
      007280 24 18            [12] 1015 	add	a,#0xff - 0xe7
      007282 50 0A            [24] 1016 	jnc	00104$
                                   1017 ;	free result
      007284                       1018 00108$:
      007284 7A 1E            [12] 1019 	mov	r2,#_process_action_PARM_2
      007286 7B 08            [12] 1020 	mov	r3,#(_process_action_PARM_2 >> 8)
      007288 12 44 22         [24] 1021 	lcall	_ak820_outline_0033
      00728B E0               [24] 1022 	movx	a,@dptr
      00728C 70 07            [24] 1023 	jnz	00105$
      00728E                       1024 00104$:
                                   1025 ;	quantum/action.c:449: add_owned_mods(mods);
      00728E 8C 82            [24] 1026 	mov	dpl, r4
      007290 12 7D 11         [24] 1027 	lcall	_add_owned_mods
      007293 80 05            [24] 1028 	sjmp	00106$
      007295                       1029 00105$:
                                   1030 ;	quantum/action.c:451: add_owned_weak_mods(mods);
      007295 8C 82            [24] 1031 	mov	dpl, r4
      007297 12 7D 30         [24] 1032 	lcall	_add_owned_weak_mods
      00729A                       1033 00106$:
                                   1034 ;	quantum/action.c:453: send_keyboard_report();
      00729A 12 80 73         [24] 1035 	lcall	_send_keyboard_report
      00729D                       1036 00110$:
                                   1037 ;	quantum/action.c:455: register_code(action.key.code);
      00729D 12 76 BC         [24] 1038 	lcall	_ak820_outline_0044
      0072A0 F5 82            [12] 1039 	mov	dpl,a
      0072A2 12 74 ED         [24] 1040 	lcall	_register_code
      0072A5 02 74 D6         [24] 1041 	ljmp	00181$
      0072A8                       1042 00119$:
                                   1043 ;	quantum/action.c:457: unregister_code(action.key.code);
      0072A8 12 76 BC         [24] 1044 	lcall	_ak820_outline_0044
      0072AB F5 82            [12] 1045 	mov	dpl,a
      0072AD C0 04            [24] 1046 	push	ar4
      0072AF 12 75 5A         [24] 1047 	lcall	_unregister_code
      0072B2 D0 04            [24] 1048 	pop	ar4
                                   1049 ;	quantum/action.c:458: if (mods) {
      0072B4 EC               [12] 1050 	mov	a,r4
      0072B5 70 03            [24] 1051 	jnz	00444$
      0072B7 02 74 D6         [24] 1052 	ljmp	00181$
      0072BA                       1053 00444$:
                                   1054 ;	quantum/action.c:459: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072BA 12 76 BC         [24] 1055 	lcall	_ak820_outline_0044
      0072BD FB               [12] 1056 	mov	r3,a
      0072BE BB E0 00         [24] 1057 	cjne	r3,#0xe0,00445$
      0072C1                       1058 00445$:
      0072C1 40 07            [24] 1059 	jc	00115$
      0072C3 12 76 BC         [24] 1060 	lcall	_ak820_outline_0044
      0072C6 24 18            [12] 1061 	add	a,#0xff - 0xe7
      0072C8 50 0A            [24] 1062 	jnc	00111$
                                   1063 ;	free result
      0072CA                       1064 00115$:
      0072CA 7A 1E            [12] 1065 	mov	r2,#_process_action_PARM_2
      0072CC 7B 08            [12] 1066 	mov	r3,#(_process_action_PARM_2 >> 8)
      0072CE 12 44 22         [24] 1067 	lcall	_ak820_outline_0033
      0072D1 E0               [24] 1068 	movx	a,@dptr
      0072D2 70 07            [24] 1069 	jnz	00112$
      0072D4                       1070 00111$:
                                   1071 ;	quantum/action.c:460: del_owned_mods(mods);
      0072D4 8C 82            [24] 1072 	mov	dpl, r4
      0072D6 12 7D 21         [24] 1073 	lcall	_del_owned_mods
      0072D9 80 05            [24] 1074 	sjmp	00113$
      0072DB                       1075 00112$:
                                   1076 ;	quantum/action.c:462: del_owned_weak_mods(mods);
      0072DB 8C 82            [24] 1077 	mov	dpl, r4
      0072DD 12 7D 40         [24] 1078 	lcall	_del_owned_weak_mods
      0072E0                       1079 00113$:
                                   1080 ;	quantum/action.c:464: send_keyboard_report();
      0072E0 12 80 73         [24] 1081 	lcall	_send_keyboard_report
                                   1082 ;	quantum/action.c:467: } break;
      0072E3 02 74 D6         [24] 1083 	ljmp	00181$
                                   1084 ;	quantum/action.c:544: case ACT_USAGE:
      0072E6                       1085 00123$:
                                   1086 ;	quantum/action.c:550: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0072E6 74 07            [12] 1087 	mov	a,#0x07
      0072E8 2E               [12] 1088 	add	a, r6
      0072E9 FE               [12] 1089 	mov	r6,a
      0072EA E4               [12] 1090 	clr	a
      0072EB 3D               [12] 1091 	addc	a, r5
      0072EC FD               [12] 1092 	mov	r5,a
      0072ED 8E 82            [24] 1093 	mov	dpl,r6
      0072EF 8D 83            [24] 1094 	mov	dph,r5
      0072F1 8F F0            [24] 1095 	mov	b,r7
      0072F3 12 BE 14         [24] 1096 	lcall	__gptrget
      0072F6 FE               [12] 1097 	mov	r6,a
      0072F7 A3               [24] 1098 	inc	dptr
      0072F8 12 BE 14         [24] 1099 	lcall	__gptrget
      0072FB FF               [12] 1100 	mov	r7,a
      0072FC 12 44 62         [24] 1101 	lcall	_ak820_outline_0073
      0072FF C3               [12] 1102 	clr	c
      007300 EC               [12] 1103 	mov	a,r4
      007301 94 A5            [12] 1104 	subb	a,#0xa5
      007303 ED               [12] 1105 	mov	a,r5
      007304 94 00            [12] 1106 	subb	a,#0x00
      007306 40 15            [24] 1107 	jc	00125$
      007308 74 C2            [12] 1108 	mov	a,#0xc2
      00730A 9C               [12] 1109 	subb	a,r4
      00730B E4               [12] 1110 	clr	a
      00730C 9D               [12] 1111 	subb	a,r5
      00730D 40 0E            [24] 1112 	jc	00125$
                                   1113 ;	free result
                                   1114 ;	quantum/action.c:551: owned_usage_key((uint8_t)record->keycode, pressed);
      00730F 90 0A 83         [24] 1115 	mov	dptr,#_owned_usage_key_PARM_2
      007312 E5 19            [12] 1116 	mov	a,_process_action_sloc0_1_0
      007314 F0               [24] 1117 	movx	@dptr,a
      007315 8E 82            [24] 1118 	mov	dpl, r6
      007317 12 7F 11         [24] 1119 	lcall	_owned_usage_key
                                   1120 ;	quantum/action.c:552: break;
      00731A 02 74 D6         [24] 1121 	ljmp	00181$
      00731D                       1122 00125$:
                                   1123 ;	quantum/action.c:555: switch (action.usage.page) {
      00731D 12 76 D1         [24] 1124 	lcall	_ak820_outline_0068
      007320 FF               [12] 1125 	mov	r7,a
      007321 60 08            [24] 1126 	jz	00127$
      007323 BF 01 02         [24] 1127 	cjne	r7,#0x01,00452$
      007326 80 1F            [24] 1128 	sjmp	00128$
      007328                       1129 00452$:
      007328 02 74 D6         [24] 1130 	ljmp	00181$
                                   1131 ;	quantum/action.c:556: case PAGE_SYSTEM:
      00732B                       1132 00127$:
                                   1133 ;	quantum/action.c:557: host_system_send(pressed ? action.usage.code : 0);
      00732B E5 19            [12] 1134 	mov	a,_process_action_sloc0_1_0
      00732D 60 0B            [24] 1135 	jz	00196$
      00732F 12 76 BC         [24] 1136 	lcall	_ak820_outline_0044
      007332 FE               [12] 1137 	mov	r6,a
      007333 A3               [24] 1138 	inc	dptr
      007334 E0               [24] 1139 	movx	a,@dptr
      007335 54 03            [12] 1140 	anl	a,#0x03
      007337 FF               [12] 1141 	mov	r7,a
      007338 80 04            [24] 1142 	sjmp	00197$
      00733A                       1143 00196$:
      00733A 7E 00            [12] 1144 	mov	r6,#0x00
      00733C 7F 00            [12] 1145 	mov	r7,#0x00
      00733E                       1146 00197$:
      00733E 12 43 D3         [24] 1147 	lcall	_ak820_outline_0002
      007341 12 6D 71         [24] 1148 	lcall	_host_system_send
                                   1149 ;	quantum/action.c:558: break;
      007344 02 74 D6         [24] 1150 	ljmp	00181$
                                   1151 ;	quantum/action.c:559: case PAGE_CONSUMER:
      007347                       1152 00128$:
                                   1153 ;	quantum/action.c:560: host_consumer_send(pressed ? action.usage.code : 0);
      007347 E5 19            [12] 1154 	mov	a,_process_action_sloc0_1_0
      007349 60 0B            [24] 1155 	jz	00198$
      00734B 12 76 BC         [24] 1156 	lcall	_ak820_outline_0044
      00734E FE               [12] 1157 	mov	r6,a
      00734F A3               [24] 1158 	inc	dptr
      007350 E0               [24] 1159 	movx	a,@dptr
      007351 54 03            [12] 1160 	anl	a,#0x03
      007353 FF               [12] 1161 	mov	r7,a
      007354 80 04            [24] 1162 	sjmp	00199$
      007356                       1163 00198$:
      007356 7E 00            [12] 1164 	mov	r6,#0x00
      007358 7F 00            [12] 1165 	mov	r7,#0x00
      00735A                       1166 00199$:
      00735A 12 43 D3         [24] 1167 	lcall	_ak820_outline_0002
      00735D 12 6D A3         [24] 1168 	lcall	_host_consumer_send
                                   1169 ;	quantum/action.c:563: break;
      007360 02 74 D6         [24] 1170 	ljmp	00181$
                                   1171 ;	quantum/action.c:570: case ACT_LAYER: {
      007363                       1172 00131$:
                                   1173 ;	quantum/action.c:571: uint8_t on = action.layer_bitop.on;
      007363 90 08 1F         [24] 1174 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007366 E0               [24] 1175 	movx	a,@dptr
      007367 54 03            [12] 1176 	anl	a,#0x03
      007369 90 08 23         [24] 1177 	mov	dptr,#_process_action_on_40000_660
      00736C F0               [24] 1178 	movx	@dptr,a
                                   1179 ;	quantum/action.c:574: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00736D E0               [24] 1180 	movx	a,@dptr
      00736E FF               [12] 1181 	mov	r7,a
      00736F 60 11            [24] 1182 	jz	00200$
      007371 E5 19            [12] 1183 	mov	a,_process_action_sloc0_1_0
      007373 60 07            [24] 1184 	jz	00202$
      007375 8F 06            [24] 1185 	mov	ar6,r7
      007377 53 06 01         [24] 1186 	anl	ar6,#0x01
      00737A 80 10            [24] 1187 	sjmp	00201$
      00737C                       1188 00202$:
      00737C 74 02            [12] 1189 	mov	a,#0x02
      00737E 5F               [12] 1190 	anl	a,r7
      00737F FE               [12] 1191 	mov	r6,a
      007380 80 0A            [24] 1192 	sjmp	00201$
      007382                       1193 00200$:
      007382 E5 19            [12] 1194 	mov	a,_process_action_sloc0_1_0
      007384 B4 01 00         [24] 1195 	cjne	a,#0x01,00457$
      007387                       1196 00457$:
      007387 92 18            [24] 1197 	mov  _process_action_sloc1_1_0,c
      007389 E4               [12] 1198 	clr	a
      00738A 33               [12] 1199 	rlc	a
      00738B FE               [12] 1200 	mov	r6,a
      00738C                       1201 00201$:
      00738C EE               [12] 1202 	mov	a,r6
      00738D 70 03            [24] 1203 	jnz	00458$
      00738F 02 74 D6         [24] 1204 	ljmp	00181$
      007392                       1205 00458$:
                                   1206 ;	quantum/action.c:575: uint8_t shift = action.layer_bitop.part * 4;
      007392 12 76 BC         [24] 1207 	lcall	_ak820_outline_0044
      007395 C4               [12] 1208 	swap	a
      007396 03               [12] 1209 	rr	a
      007397 54 07            [12] 1210 	anl	a,#0x07
      007399 25 E0            [12] 1211 	add	a,acc
      00739B 25 E0            [12] 1212 	add	a,acc
      00739D FF               [12] 1213 	mov	r7,a
                                   1214 ;	quantum/action.c:576: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00739E 12 76 BC         [24] 1215 	lcall	_ak820_outline_0044
      0073A1 54 0F            [12] 1216 	anl	a,#0x0f
      0073A3 FE               [12] 1217 	mov	r6,a
      0073A4 8F F0            [24] 1218 	mov	b,r7
      0073A6 05 F0            [12] 1219 	inc	b
      0073A8 EE               [12] 1220 	mov	a,r6
      0073A9 80 02            [24] 1221 	sjmp	00460$
      0073AB                       1222 00459$:
      0073AB 25 E0            [12] 1223 	add	a,acc
      0073AD                       1224 00460$:
      0073AD D5 F0 FB         [24] 1225 	djnz	b,00459$
      0073B0 FE               [12] 1226 	mov	r6,a
                                   1227 ;	quantum/action.c:577: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0073B1 12 76 BC         [24] 1228 	lcall	_ak820_outline_0044
      0073B4 30 E4 11         [24] 1229 	jnb	acc.4,00204$
      0073B7 8F F0            [24] 1230 	mov	b,r7
      0073B9 05 F0            [12] 1231 	inc	b
      0073BB 74 0F            [12] 1232 	mov	a,#0x0f
      0073BD 80 02            [24] 1233 	sjmp	00463$
      0073BF                       1234 00462$:
      0073BF 25 E0            [12] 1235 	add	a,acc
      0073C1                       1236 00463$:
      0073C1 D5 F0 FB         [24] 1237 	djnz	b,00462$
      0073C4 F4               [12] 1238 	cpl	a
      0073C5 FF               [12] 1239 	mov	r7,a
      0073C6 80 02            [24] 1240 	sjmp	00205$
      0073C8                       1241 00204$:
      0073C8 7F 00            [12] 1242 	mov	r7,#0x00
      0073CA                       1243 00205$:
                                   1244 ;	quantum/action.c:578: bits |= mask;
      0073CA EE               [12] 1245 	mov	a,r6
      0073CB 42 07            [12] 1246 	orl	ar7,a
                                   1247 ;	quantum/action.c:579: if (!on) {
      0073CD 90 08 23         [24] 1248 	mov	dptr,#_process_action_on_40000_660
      0073D0 E0               [24] 1249 	movx	a,@dptr
      0073D1 70 31            [24] 1250 	jnz	00143$
                                   1251 ;	quantum/action.c:580: switch (action.layer_bitop.op) {
      0073D3 12 76 D1         [24] 1252 	lcall	_ak820_outline_0068
      0073D6 FE               [12] 1253 	mov	r6,a
      0073D7 2E               [12] 1254 	add	a,r6
                                   1255 ;	quantum/action.c:581: case OP_BIT_AND: default_layer_and(bits); break;
      0073D8 90 73 DC         [24] 1256 	mov	dptr,#00465$
      0073DB 73               [24] 1257 	jmp	@a+dptr
      0073DC                       1258 00465$:
      0073DC 80 06            [24] 1259 	sjmp	00132$
      0073DE 80 0C            [24] 1260 	sjmp	00133$
      0073E0 80 12            [24] 1261 	sjmp	00134$
      0073E2 80 18            [24] 1262 	sjmp	00135$
      0073E4                       1263 00132$:
      0073E4 8F 82            [24] 1264 	mov	dpl, r7
      0073E6 12 77 37         [24] 1265 	lcall	_default_layer_and
      0073E9 02 74 D6         [24] 1266 	ljmp	00181$
                                   1267 ;	quantum/action.c:582: case OP_BIT_OR: default_layer_or(bits); break;
      0073EC                       1268 00133$:
      0073EC 8F 82            [24] 1269 	mov	dpl, r7
      0073EE 12 77 26         [24] 1270 	lcall	_default_layer_or
      0073F1 02 74 D6         [24] 1271 	ljmp	00181$
                                   1272 ;	quantum/action.c:583: case OP_BIT_XOR: default_layer_xor(bits); break;
      0073F4                       1273 00134$:
      0073F4 8F 82            [24] 1274 	mov	dpl, r7
      0073F6 12 77 4D         [24] 1275 	lcall	_default_layer_xor
      0073F9 02 74 D6         [24] 1276 	ljmp	00181$
                                   1277 ;	quantum/action.c:584: case OP_BIT_SET: default_layer_set(bits); break;
      0073FC                       1278 00135$:
      0073FC 8F 82            [24] 1279 	mov	dpl, r7
      0073FE 12 77 1B         [24] 1280 	lcall	_default_layer_set
                                   1281 ;	quantum/action.c:585: }
      007401 02 74 D6         [24] 1282 	ljmp	00181$
      007404                       1283 00143$:
                                   1284 ;	quantum/action.c:587: switch (action.layer_bitop.op) {
      007404 12 76 D1         [24] 1285 	lcall	_ak820_outline_0068
      007407 FE               [12] 1286 	mov	r6,a
      007408 2E               [12] 1287 	add	a,r6
                                   1288 ;	quantum/action.c:588: case OP_BIT_AND: layer_and(bits); break;
      007409 90 74 0D         [24] 1289 	mov	dptr,#00466$
      00740C 73               [24] 1290 	jmp	@a+dptr
      00740D                       1291 00466$:
      00740D 80 06            [24] 1292 	sjmp	00137$
      00740F 80 0C            [24] 1293 	sjmp	00138$
      007411 80 12            [24] 1294 	sjmp	00139$
      007413 80 18            [24] 1295 	sjmp	00140$
      007415                       1296 00137$:
      007415 8F 82            [24] 1297 	mov	dpl, r7
      007417 12 78 D1         [24] 1298 	lcall	_layer_and
      00741A 02 74 D6         [24] 1299 	ljmp	00181$
                                   1300 ;	quantum/action.c:589: case OP_BIT_OR: layer_or(bits); break;
      00741D                       1301 00138$:
      00741D 8F 82            [24] 1302 	mov	dpl, r7
      00741F 12 78 C0         [24] 1303 	lcall	_layer_or
      007422 02 74 D6         [24] 1304 	ljmp	00181$
                                   1305 ;	quantum/action.c:590: case OP_BIT_XOR: layer_xor(bits); break;
      007425                       1306 00139$:
      007425 8F 82            [24] 1307 	mov	dpl, r7
      007427 12 78 E7         [24] 1308 	lcall	_layer_xor
      00742A 02 74 D6         [24] 1309 	ljmp	00181$
                                   1310 ;	quantum/action.c:591: case OP_BIT_SET: layer_state_set(bits); break;
      00742D                       1311 00140$:
      00742D 8F 82            [24] 1312 	mov	dpl, r7
      00742F 12 78 5D         [24] 1313 	lcall	_layer_state_set
                                   1314 ;	quantum/action.c:595: break;
      007432 02 74 D6         [24] 1315 	ljmp	00181$
                                   1316 ;	quantum/action.c:597: case ACT_LAYER_MODS:
      007435                       1317 00147$:
                                   1318 ;	quantum/action.c:598: if (pressed) {
      007435 E5 19            [12] 1319 	mov	a,_process_action_sloc0_1_0
      007437 60 13            [24] 1320 	jz	00149$
                                   1321 ;	quantum/action.c:599: layer_hold_on(action.layer_mods.layer);
      007439 12 76 DA         [24] 1322 	lcall	_ak820_outline_0076
      00743C F5 82            [12] 1323 	mov	dpl,a
      00743E 12 77 BD         [24] 1324 	lcall	_layer_hold_on
                                   1325 ;	quantum/action.c:600: register_mods(action.layer_mods.mods);
      007441 12 76 BC         [24] 1326 	lcall	_ak820_outline_0044
      007444 F5 82            [12] 1327 	mov	dpl,a
      007446 12 76 10         [24] 1328 	lcall	_register_mods
      007449 02 74 D6         [24] 1329 	ljmp	00181$
      00744C                       1330 00149$:
                                   1331 ;	quantum/action.c:602: unregister_mods(action.layer_mods.mods);
      00744C 12 76 BC         [24] 1332 	lcall	_ak820_outline_0044
      00744F F5 82            [12] 1333 	mov	dpl,a
      007451 12 76 24         [24] 1334 	lcall	_unregister_mods
                                   1335 ;	quantum/action.c:603: layer_hold_off(action.layer_mods.layer);
      007454 12 76 DA         [24] 1336 	lcall	_ak820_outline_0076
      007457 F5 82            [12] 1337 	mov	dpl,a
      007459 12 77 F5         [24] 1338 	lcall	_layer_hold_off
                                   1339 ;	quantum/action.c:605: break;
      00745C 02 74 D6         [24] 1340 	ljmp	00181$
                                   1341 ;	quantum/action.c:607: case ACT_LAYER_TAP_EXT:
      00745F                       1342 00152$:
                                   1343 ;	quantum/action.c:608: switch (action.layer_tap.code) {
      00745F 12 76 BC         [24] 1344 	lcall	_ak820_outline_0044
      007462 FF               [12] 1345 	mov	r7,a
      007463 BF F1 02         [24] 1346 	cjne	r7,#0xf1,00468$
      007466 80 0A            [24] 1347 	sjmp	00154$
      007468                       1348 00468$:
      007468 BF F2 02         [24] 1349 	cjne	r7,#0xf2,00469$
      00746B 80 19            [24] 1350 	sjmp	00155$
      00746D                       1351 00469$:
                                   1352 ;	quantum/action.c:624: momentary_layer_action:
      00746D BF F3 3B         [24] 1353 	cjne	r7,#0xf3,00160$
      007470 80 28            [24] 1354 	sjmp	00156$
      007472                       1355 00154$:
                                   1356 ;	quantum/action.c:625: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007472 E5 19            [12] 1357 	mov	a,_process_action_sloc0_1_0
      007474 60 08            [24] 1358 	jz	00206$
      007476 12 76 B3         [24] 1359 	lcall	_ak820_outline_0031
      007479 12 77 BD         [24] 1360 	lcall	_layer_hold_on
      00747C 80 58            [24] 1361 	sjmp	00181$
      00747E                       1362 00206$:
      00747E 12 76 B3         [24] 1363 	lcall	_ak820_outline_0031
      007481 12 77 F5         [24] 1364 	lcall	_layer_hold_off
                                   1365 ;	quantum/action.c:626: break;
                                   1366 ;	quantum/action.c:627: case OP_OFF_ON:
      007484 80 50            [24] 1367 	sjmp	00181$
      007486                       1368 00155$:
                                   1369 ;	quantum/action.c:628: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007486 E5 19            [12] 1370 	mov	a,_process_action_sloc0_1_0
      007488 60 08            [24] 1371 	jz	00208$
      00748A 12 76 B3         [24] 1372 	lcall	_ak820_outline_0031
      00748D 12 78 A2         [24] 1373 	lcall	_layer_off
      007490 80 44            [24] 1374 	sjmp	00181$
      007492                       1375 00208$:
      007492 12 76 B3         [24] 1376 	lcall	_ak820_outline_0031
      007495 12 78 87         [24] 1377 	lcall	_layer_on
                                   1378 ;	quantum/action.c:629: break;
                                   1379 ;	quantum/action.c:630: case OP_SET_CLEAR:
      007498 80 3C            [24] 1380 	sjmp	00181$
      00749A                       1381 00156$:
                                   1382 ;	quantum/action.c:631: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00749A E5 19            [12] 1383 	mov	a,_process_action_sloc0_1_0
      00749C 60 08            [24] 1384 	jz	00210$
      00749E 12 76 B3         [24] 1385 	lcall	_ak820_outline_0031
      0074A1 12 78 71         [24] 1386 	lcall	_layer_move
      0074A4 80 30            [24] 1387 	sjmp	00181$
      0074A6                       1388 00210$:
      0074A6 12 78 6B         [24] 1389 	lcall	_layer_clear
                                   1390 ;	quantum/action.c:632: break;
                                   1391 ;	quantum/action.c:678: default:
      0074A9 80 2B            [24] 1392 	sjmp	00181$
      0074AB                       1393 00160$:
                                   1394 ;	quantum/action.c:685: if (pressed) {
      0074AB E5 19            [12] 1395 	mov	a,_process_action_sloc0_1_0
      0074AD 60 0A            [24] 1396 	jz	00163$
                                   1397 ;	quantum/action.c:687: register_code(action.layer_tap.code);
      0074AF 12 76 BC         [24] 1398 	lcall	_ak820_outline_0044
      0074B2 F5 82            [12] 1399 	mov	dpl,a
      0074B4 12 74 ED         [24] 1400 	lcall	_register_code
                                   1401 ;	quantum/action.c:689: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0074B7 80 1D            [24] 1402 	sjmp	00181$
      0074B9                       1403 00163$:
                                   1404 ;	quantum/action.c:690: if (action.layer_tap.code == KC_CAPS) {
      0074B9 12 76 BC         [24] 1405 	lcall	_ak820_outline_0044
      0074BC FF               [12] 1406 	mov	r7,a
      0074BD BF 39 0E         [24] 1407 	cjne	r7,#0x39,00175$
                                   1408 ;	quantum/action.c:691: wait_ms(TAP_HOLD_CAPS_DELAY);
      0074C0 7F 50            [12] 1409 	mov	r7,#0x50
      0074C2                       1410 00187$:
      0074C2 EF               [12] 1411 	mov	a,r7
      0074C3 60 09            [24] 1412 	jz	00175$
      0074C5 90 00 01         [24] 1413 	mov	dptr,#0x0001
      0074C8 12 58 B8         [24] 1414 	lcall	_mDelaymS
      0074CB 1F               [12] 1415 	dec	r7
                                   1416 ;	quantum/action.c:693: wait_ms(TAP_CODE_DELAY);
      0074CC 80 F4            [24] 1417 	sjmp	00187$
      0074CE                       1418 00175$:
                                   1419 ;	quantum/action.c:695: unregister_code(action.layer_tap.code);
      0074CE 12 76 BC         [24] 1420 	lcall	_ak820_outline_0044
      0074D1 F5 82            [12] 1421 	mov	dpl,a
      0074D3 12 75 5A         [24] 1422 	lcall	_unregister_code
                                   1423 ;	quantum/action.c:778: }
      0074D6                       1424 00181$:
                                   1425 ;	quantum/action.c:799: switch (action.kind.id) {
      0074D6 90 08 1F         [24] 1426 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074D9 E0               [24] 1427 	movx	a,@dptr
      0074DA C4               [12] 1428 	swap	a
      0074DB 54 0F            [12] 1429 	anl	a,#0x0f
      0074DD FF               [12] 1430 	mov	r7,a
      0074DE BF 08 02         [24] 1431 	cjne	r7,#0x08,00478$
      0074E1 80 03            [24] 1432 	sjmp	00183$
      0074E3                       1433 00478$:
      0074E3 BF 09 06         [24] 1434 	cjne	r7,#0x09,00192$
                                   1435 ;	quantum/action.c:801: case ACT_LAYER_MODS:
      0074E6                       1436 00183$:
                                   1437 ;	quantum/action.c:806: led_set(host_keyboard_leds());
      0074E6 12 6C 7E         [24] 1438 	lcall	_host_keyboard_leds
                                   1439 ;	quantum/action.c:810: }
                                   1440 ;	quantum/action.c:863: }
      0074E9 02 99 A0         [24] 1441 	ljmp	_led_set
      0074EC                       1442 00192$:
      0074EC 22               [24] 1443 	ret
                                   1444 ;------------------------------------------------------------
                                   1445 ;Allocation info for local variables in function 'register_code'
                                   1446 ;------------------------------------------------------------
                                   1447 ;code          Allocated with name '_register_code_code_10000_694'
                                   1448 ;------------------------------------------------------------
                                   1449 ;	quantum/action.c:869: __attribute__((weak)) void register_code(uint8_t code) {
                                   1450 ;	-----------------------------------------
                                   1451 ;	 function register_code
                                   1452 ;	-----------------------------------------
      0074ED                       1453 _register_code:
      0074ED E5 82            [12] 1454 	mov	a,dpl
      0074EF 90 08 24         [24] 1455 	mov	dptr,#_register_code_code_10000_694
      0074F2 F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	quantum/action.c:870: if (code == KC_NO) {
      0074F3 E0               [24] 1458 	movx	a,@dptr
      0074F4 FF               [12] 1459 	mov	r7,a
      0074F5 70 01            [24] 1460 	jnz	00123$
                                   1461 ;	quantum/action.c:871: return;
      0074F7 22               [24] 1462 	ret
      0074F8                       1463 00123$:
                                   1464 ;	quantum/action.c:906: } else if (IS_BASIC_KEYCODE(code)) {
      0074F8 BF 04 00         [24] 1465 	cjne	r7,#0x04,00186$
      0074FB                       1466 00186$:
      0074FB 40 12            [24] 1467 	jc	00119$
      0074FD EF               [12] 1468 	mov	a,r7
      0074FE 24 5B            [12] 1469 	add	a,#0xff - 0xa4
      007500 40 0D            [24] 1470 	jc	00119$
                                   1471 ;	free result
                                   1472 ;	quantum/action.c:911: if (!add_owned_key(code)) return;
      007502 8F 82            [24] 1473 	mov	dpl, r7
      007504 12 7D B6         [24] 1474 	lcall	_add_owned_key
      007507 E5 82            [12] 1475 	mov	a, dpl
      007509 70 01            [24] 1476 	jnz	00104$
      00750B 22               [24] 1477 	ret
      00750C                       1478 00104$:
                                   1479 ;	quantum/action.c:922: send_keyboard_report();
      00750C 02 80 73         [24] 1480 	ljmp	_send_keyboard_report
      00750F                       1481 00119$:
                                   1482 ;	quantum/action.c:923: } else if (IS_MODIFIER_KEYCODE(code)) {
      00750F 12 76 E1         [24] 1483 	lcall	_ak820_outline_0126
      007512 BF E0 00         [24] 1484 	cjne	r7,#0xe0,00190$
      007515                       1485 00190$:
      007515 40 1A            [24] 1486 	jc	00115$
      007517 EF               [12] 1487 	mov	a,r7
      007518 24 18            [12] 1488 	add	a,#0xff - 0xe7
      00751A 40 15            [24] 1489 	jc	00115$
                                   1490 ;	free result
                                   1491 ;	quantum/action.c:924: add_owned_mods(MOD_BIT(code));
      00751C 74 07            [12] 1492 	mov	a,#0x07
      00751E 5F               [12] 1493 	anl	a,r7
      00751F 12 70 13         [24] 1494 	lcall	_ak820_outline_0021
      007522 80 02            [24] 1495 	sjmp	00194$
      007524                       1496 00193$:
      007524 25 E0            [12] 1497 	add	a,acc
      007526                       1498 00194$:
      007526 D5 F0 FB         [24] 1499 	djnz	b,00193$
      007529 F5 82            [12] 1500 	mov	dpl,a
      00752B 12 7D 11         [24] 1501 	lcall	_add_owned_mods
                                   1502 ;	quantum/action.c:925: send_keyboard_report();
      00752E 02 80 73         [24] 1503 	ljmp	_send_keyboard_report
      007531                       1504 00115$:
                                   1505 ;	quantum/action.c:928: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007531 12 76 E1         [24] 1506 	lcall	_ak820_outline_0126
      007534 BF A5 00         [24] 1507 	cjne	r7,#0xa5,00195$
      007537                       1508 00195$:
      007537 40 05            [24] 1509 	jc	00113$
      007539 EF               [12] 1510 	mov	a,r7
      00753A 24 58            [12] 1511 	add	a,#0xff - 0xa7
      00753C 50 0D            [24] 1512 	jnc	00108$
                                   1513 ;	free result
      00753E                       1514 00113$:
      00753E 12 76 E1         [24] 1515 	lcall	_ak820_outline_0126
      007541 BF A8 00         [24] 1516 	cjne	r7,#0xa8,00198$
      007544                       1517 00198$:
      007544 40 13            [24] 1518 	jc	00125$
      007546 EF               [12] 1519 	mov	a,r7
      007547 24 3D            [12] 1520 	add	a,#0xff - 0xc2
      007549 40 0E            [24] 1521 	jc	00125$
                                   1522 ;	free result
      00754B                       1523 00108$:
                                   1524 ;	quantum/action.c:930: owned_usage_key(code, true);
      00754B 12 76 E1         [24] 1525 	lcall	_ak820_outline_0126
      00754E 90 0A 83         [24] 1526 	mov	dptr,#_owned_usage_key_PARM_2
      007551 74 01            [12] 1527 	mov	a,#0x01
      007553 F0               [24] 1528 	movx	@dptr,a
      007554 8F 82            [24] 1529 	mov	dpl, r7
                                   1530 ;	quantum/action.c:938: register_mouse(code, true);
                                   1531 ;	quantum/action.c:940: }
      007556 02 7F 11         [24] 1532 	ljmp	_owned_usage_key
      007559                       1533 00125$:
      007559 22               [24] 1534 	ret
                                   1535 ;------------------------------------------------------------
                                   1536 ;Allocation info for local variables in function 'unregister_code'
                                   1537 ;------------------------------------------------------------
                                   1538 ;code          Allocated with name '_unregister_code_code_10000_708'
                                   1539 ;------------------------------------------------------------
                                   1540 ;	quantum/action.c:946: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1541 ;	-----------------------------------------
                                   1542 ;	 function unregister_code
                                   1543 ;	-----------------------------------------
      00755A                       1544 _unregister_code:
      00755A E5 82            [12] 1545 	mov	a,dpl
      00755C 90 08 25         [24] 1546 	mov	dptr,#_unregister_code_code_10000_708
      00755F F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/action.c:947: if (code == KC_NO) {
      007560 E0               [24] 1549 	movx	a,@dptr
      007561 FF               [12] 1550 	mov	r7,a
      007562 70 01            [24] 1551 	jnz	00121$
                                   1552 ;	quantum/action.c:948: return;
      007564 22               [24] 1553 	ret
      007565                       1554 00121$:
                                   1555 ;	quantum/action.c:980: } else if (IS_BASIC_KEYCODE(code)) {
      007565 BF 04 00         [24] 1556 	cjne	r7,#0x04,00184$
      007568                       1557 00184$:
      007568 40 12            [24] 1558 	jc	00117$
      00756A EF               [12] 1559 	mov	a,r7
      00756B 24 5B            [12] 1560 	add	a,#0xff - 0xa4
      00756D 40 0D            [24] 1561 	jc	00117$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:982: if (!del_owned_key(code)) return;
      00756F 8F 82            [24] 1564 	mov	dpl, r7
      007571 12 7E 3A         [24] 1565 	lcall	_del_owned_key
      007574 E5 82            [12] 1566 	mov	a, dpl
      007576 70 01            [24] 1567 	jnz	00102$
      007578 22               [24] 1568 	ret
      007579                       1569 00102$:
                                   1570 ;	quantum/action.c:986: send_keyboard_report();
      007579 02 80 73         [24] 1571 	ljmp	_send_keyboard_report
      00757C                       1572 00117$:
                                   1573 ;	quantum/action.c:987: } else if (IS_MODIFIER_KEYCODE(code)) {
      00757C 12 76 E7         [24] 1574 	lcall	_ak820_outline_0127
      00757F BF E0 00         [24] 1575 	cjne	r7,#0xe0,00188$
      007582                       1576 00188$:
      007582 40 1A            [24] 1577 	jc	00113$
      007584 EF               [12] 1578 	mov	a,r7
      007585 24 18            [12] 1579 	add	a,#0xff - 0xe7
      007587 40 15            [24] 1580 	jc	00113$
                                   1581 ;	free result
                                   1582 ;	quantum/action.c:988: del_owned_mods(MOD_BIT(code));
      007589 74 07            [12] 1583 	mov	a,#0x07
      00758B 5F               [12] 1584 	anl	a,r7
      00758C 12 70 13         [24] 1585 	lcall	_ak820_outline_0021
      00758F 80 02            [24] 1586 	sjmp	00192$
      007591                       1587 00191$:
      007591 25 E0            [12] 1588 	add	a,acc
      007593                       1589 00192$:
      007593 D5 F0 FB         [24] 1590 	djnz	b,00191$
      007596 F5 82            [12] 1591 	mov	dpl,a
      007598 12 7D 21         [24] 1592 	lcall	_del_owned_mods
                                   1593 ;	quantum/action.c:989: send_keyboard_report();
      00759B 02 80 73         [24] 1594 	ljmp	_send_keyboard_report
      00759E                       1595 00113$:
                                   1596 ;	quantum/action.c:992: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00759E 12 76 E7         [24] 1597 	lcall	_ak820_outline_0127
      0075A1 BF A5 00         [24] 1598 	cjne	r7,#0xa5,00193$
      0075A4                       1599 00193$:
      0075A4 40 05            [24] 1600 	jc	00111$
      0075A6 EF               [12] 1601 	mov	a,r7
      0075A7 24 58            [12] 1602 	add	a,#0xff - 0xa7
      0075A9 50 0D            [24] 1603 	jnc	00106$
                                   1604 ;	free result
      0075AB                       1605 00111$:
      0075AB 12 76 E7         [24] 1606 	lcall	_ak820_outline_0127
      0075AE BF A8 00         [24] 1607 	cjne	r7,#0xa8,00196$
      0075B1                       1608 00196$:
      0075B1 40 12            [24] 1609 	jc	00123$
      0075B3 EF               [12] 1610 	mov	a,r7
      0075B4 24 3D            [12] 1611 	add	a,#0xff - 0xc2
      0075B6 40 0D            [24] 1612 	jc	00123$
                                   1613 ;	free result
      0075B8                       1614 00106$:
                                   1615 ;	quantum/action.c:994: owned_usage_key(code, false);
      0075B8 12 76 E7         [24] 1616 	lcall	_ak820_outline_0127
      0075BB 90 0A 83         [24] 1617 	mov	dptr,#_owned_usage_key_PARM_2
      0075BE E4               [12] 1618 	clr	a
      0075BF F0               [24] 1619 	movx	@dptr,a
      0075C0 8F 82            [24] 1620 	mov	dpl, r7
                                   1621 ;	quantum/action.c:1002: register_mouse(code, false);
                                   1622 ;	quantum/action.c:1004: }
      0075C2 02 7F 11         [24] 1623 	ljmp	_owned_usage_key
      0075C5                       1624 00123$:
      0075C5 22               [24] 1625 	ret
                                   1626 ;------------------------------------------------------------
                                   1627 ;Allocation info for local variables in function 'tap_code_delay'
                                   1628 ;------------------------------------------------------------
                                   1629 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1630 ;code          Allocated with name '_tap_code_delay_code_10000_721'
                                   1631 ;i             Allocated with name '_tap_code_delay_i_20000_723'
                                   1632 ;i             Allocated with name '_tap_code_delay_i_50000_726'
                                   1633 ;------------------------------------------------------------
                                   1634 ;	quantum/action.c:1011: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1635 ;	-----------------------------------------
                                   1636 ;	 function tap_code_delay
                                   1637 ;	-----------------------------------------
      0075C6                       1638 _tap_code_delay:
      0075C6 E5 82            [12] 1639 	mov	a,dpl
      0075C8 90 08 28         [24] 1640 	mov	dptr,#_tap_code_delay_code_10000_721
      0075CB F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/action.c:1012: register_code(code);
      0075CC E0               [24] 1643 	movx	a,@dptr
      0075CD FF               [12] 1644 	mov	r7,a
      0075CE F5 82            [12] 1645 	mov	dpl,a
      0075D0 C0 07            [24] 1646 	push	ar7
      0075D2 12 74 ED         [24] 1647 	lcall	_register_code
      0075D5 D0 07            [24] 1648 	pop	ar7
                                   1649 ;	quantum/action.c:1013: for (uint16_t i = delay; i > 0; i--) {
      0075D7 90 08 26         [24] 1650 	mov	dptr,#_tap_code_delay_PARM_2
      0075DA 12 44 17         [24] 1651 	lcall	_ak820_outline_0025
      0075DD                       1652 00110$:
      0075DD ED               [12] 1653 	mov	a,r5
      0075DE 4E               [12] 1654 	orl	a,r6
      0075DF 60 0D            [24] 1655 	jz	00105$
                                   1656 ;	quantum/action.c:1014: wait_ms(1);
      0075E1 90 00 01         [24] 1657 	mov	dptr,#0x0001
      0075E4 12 58 B8         [24] 1658 	lcall	_mDelaymS
                                   1659 ;	quantum/action.c:1013: for (uint16_t i = delay; i > 0; i--) {
      0075E7 1D               [12] 1660 	dec	r5
      0075E8 BD FF 01         [24] 1661 	cjne	r5,#0xff,00141$
      0075EB 1E               [12] 1662 	dec	r6
      0075EC                       1663 00141$:
      0075EC 80 EF            [24] 1664 	sjmp	00110$
      0075EE                       1665 00105$:
                                   1666 ;	quantum/action.c:1016: unregister_code(code);
      0075EE 8F 82            [24] 1667 	mov	dpl, r7
                                   1668 ;	quantum/action.c:1017: }
      0075F0 02 75 5A         [24] 1669 	ljmp	_unregister_code
                                   1670 ;------------------------------------------------------------
                                   1671 ;Allocation info for local variables in function 'tap_code'
                                   1672 ;------------------------------------------------------------
                                   1673 ;code          Allocated with name '_tap_code_code_10000_728'
                                   1674 ;------------------------------------------------------------
                                   1675 ;	quantum/action.c:1023: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1676 ;	-----------------------------------------
                                   1677 ;	 function tap_code
                                   1678 ;	-----------------------------------------
      0075F3                       1679 _tap_code:
      0075F3 E5 82            [12] 1680 	mov	a,dpl
      0075F5 90 08 29         [24] 1681 	mov	dptr,#_tap_code_code_10000_728
      0075F8 F0               [24] 1682 	movx	@dptr,a
                                   1683 ;	quantum/action.c:1024: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0075F9 E0               [24] 1684 	movx	a,@dptr
      0075FA FF               [12] 1685 	mov	r7,a
      0075FB BF 39 04         [24] 1686 	cjne	r7,#0x39,00103$
      0075FE 7E 50            [12] 1687 	mov	r6,#0x50
      007600 80 02            [24] 1688 	sjmp	00104$
      007602                       1689 00103$:
      007602 7E 00            [12] 1690 	mov	r6,#0x00
      007604                       1691 00104$:
      007604 90 08 26         [24] 1692 	mov	dptr,#_tap_code_delay_PARM_2
      007607 EE               [12] 1693 	mov	a,r6
      007608 12 4E 60         [24] 1694 	lcall	_ak820_outline_0003
      00760B 8F 82            [24] 1695 	mov	dpl, r7
                                   1696 ;	quantum/action.c:1025: }
      00760D 02 75 C6         [24] 1697 	ljmp	_tap_code_delay
                                   1698 ;------------------------------------------------------------
                                   1699 ;Allocation info for local variables in function 'register_mods'
                                   1700 ;------------------------------------------------------------
                                   1701 ;mods          Allocated with name '_register_mods_mods_10000_730'
                                   1702 ;------------------------------------------------------------
                                   1703 ;	quantum/action.c:1031: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1704 ;	-----------------------------------------
                                   1705 ;	 function register_mods
                                   1706 ;	-----------------------------------------
      007610                       1707 _register_mods:
      007610 E5 82            [12] 1708 	mov	a,dpl
      007612 90 08 2A         [24] 1709 	mov	dptr,#_register_mods_mods_10000_730
      007615 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	quantum/action.c:1032: if (mods) {
      007616 E0               [24] 1712 	movx	a,@dptr
      007617 FF               [12] 1713 	mov	r7,a
      007618 E0               [24] 1714 	movx	a,@dptr
      007619 60 08            [24] 1715 	jz	00103$
                                   1716 ;	quantum/action.c:1033: add_owned_mods(mods);
      00761B 8F 82            [24] 1717 	mov	dpl, r7
      00761D 12 7D 11         [24] 1718 	lcall	_add_owned_mods
                                   1719 ;	quantum/action.c:1034: send_keyboard_report();
                                   1720 ;	quantum/action.c:1036: }
      007620 02 80 73         [24] 1721 	ljmp	_send_keyboard_report
      007623                       1722 00103$:
      007623 22               [24] 1723 	ret
                                   1724 ;------------------------------------------------------------
                                   1725 ;Allocation info for local variables in function 'unregister_mods'
                                   1726 ;------------------------------------------------------------
                                   1727 ;mods          Allocated with name '_unregister_mods_mods_10000_734'
                                   1728 ;------------------------------------------------------------
                                   1729 ;	quantum/action.c:1042: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1730 ;	-----------------------------------------
                                   1731 ;	 function unregister_mods
                                   1732 ;	-----------------------------------------
      007624                       1733 _unregister_mods:
      007624 E5 82            [12] 1734 	mov	a,dpl
      007626 90 08 2B         [24] 1735 	mov	dptr,#_unregister_mods_mods_10000_734
      007629 F0               [24] 1736 	movx	@dptr,a
                                   1737 ;	quantum/action.c:1043: if (mods) {
      00762A E0               [24] 1738 	movx	a,@dptr
      00762B FF               [12] 1739 	mov	r7,a
      00762C E0               [24] 1740 	movx	a,@dptr
      00762D 60 08            [24] 1741 	jz	00103$
                                   1742 ;	quantum/action.c:1044: del_owned_mods(mods);
      00762F 8F 82            [24] 1743 	mov	dpl, r7
      007631 12 7D 21         [24] 1744 	lcall	_del_owned_mods
                                   1745 ;	quantum/action.c:1045: send_keyboard_report();
                                   1746 ;	quantum/action.c:1047: }
      007634 02 80 73         [24] 1747 	ljmp	_send_keyboard_report
      007637                       1748 00103$:
      007637 22               [24] 1749 	ret
                                   1750 ;------------------------------------------------------------
                                   1751 ;Allocation info for local variables in function 'register_weak_mods'
                                   1752 ;------------------------------------------------------------
                                   1753 ;mods          Allocated with name '_register_weak_mods_mods_10000_738'
                                   1754 ;------------------------------------------------------------
                                   1755 ;	quantum/action.c:1053: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1756 ;	-----------------------------------------
                                   1757 ;	 function register_weak_mods
                                   1758 ;	-----------------------------------------
      007638                       1759 _register_weak_mods:
      007638 E5 82            [12] 1760 	mov	a,dpl
      00763A 90 08 2C         [24] 1761 	mov	dptr,#_register_weak_mods_mods_10000_738
      00763D F0               [24] 1762 	movx	@dptr,a
                                   1763 ;	quantum/action.c:1054: if (mods) {
      00763E E0               [24] 1764 	movx	a,@dptr
      00763F FF               [12] 1765 	mov	r7,a
      007640 E0               [24] 1766 	movx	a,@dptr
      007641 60 08            [24] 1767 	jz	00103$
                                   1768 ;	quantum/action.c:1055: add_owned_weak_mods(mods);
      007643 8F 82            [24] 1769 	mov	dpl, r7
      007645 12 7D 30         [24] 1770 	lcall	_add_owned_weak_mods
                                   1771 ;	quantum/action.c:1056: send_keyboard_report();
                                   1772 ;	quantum/action.c:1058: }
      007648 02 80 73         [24] 1773 	ljmp	_send_keyboard_report
      00764B                       1774 00103$:
      00764B 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_742'
                                   1780 ;------------------------------------------------------------
                                   1781 ;	quantum/action.c:1064: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1782 ;	-----------------------------------------
                                   1783 ;	 function unregister_weak_mods
                                   1784 ;	-----------------------------------------
      00764C                       1785 _unregister_weak_mods:
      00764C E5 82            [12] 1786 	mov	a,dpl
      00764E 90 08 2D         [24] 1787 	mov	dptr,#_unregister_weak_mods_mods_10000_742
      007651 F0               [24] 1788 	movx	@dptr,a
                                   1789 ;	quantum/action.c:1065: if (mods) {
      007652 E0               [24] 1790 	movx	a,@dptr
      007653 FF               [12] 1791 	mov	r7,a
      007654 E0               [24] 1792 	movx	a,@dptr
      007655 60 08            [24] 1793 	jz	00103$
                                   1794 ;	quantum/action.c:1066: del_owned_weak_mods(mods);
      007657 8F 82            [24] 1795 	mov	dpl, r7
      007659 12 7D 40         [24] 1796 	lcall	_del_owned_weak_mods
                                   1797 ;	quantum/action.c:1067: send_keyboard_report();
                                   1798 ;	quantum/action.c:1069: }
      00765C 02 80 73         [24] 1799 	ljmp	_send_keyboard_report
      00765F                       1800 00103$:
      00765F 22               [24] 1801 	ret
                                   1802 ;------------------------------------------------------------
                                   1803 ;Allocation info for local variables in function 'clear_keyboard'
                                   1804 ;------------------------------------------------------------
                                   1805 ;	quantum/action.c:1075: void clear_keyboard(void) {
                                   1806 ;	-----------------------------------------
                                   1807 ;	 function clear_keyboard
                                   1808 ;	-----------------------------------------
      007660                       1809 _clear_keyboard:
                                   1810 ;	quantum/action.c:1076: clear_mods();
      007660 12 80 ED         [24] 1811 	lcall	_clear_mods
                                   1812 ;	quantum/action.c:1077: clear_keyboard_but_mods();
                                   1813 ;	quantum/action.c:1078: }
      007663 02 76 66         [24] 1814 	ljmp	_clear_keyboard_but_mods
                                   1815 ;------------------------------------------------------------
                                   1816 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1817 ;------------------------------------------------------------
                                   1818 ;	quantum/action.c:1084: void clear_keyboard_but_mods(void) {
                                   1819 ;	-----------------------------------------
                                   1820 ;	 function clear_keyboard_but_mods
                                   1821 ;	-----------------------------------------
      007666                       1822 _clear_keyboard_but_mods:
                                   1823 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007666 90 0D D7         [24] 1824 	mov	dptr,#_actual_keyboard_report
      007669 75 F0 00         [24] 1825 	mov	b, #0x00
      00766C 12 6F C9         [24] 1826 	lcall	_clear_keys_from_report
                                   1827 ;	quantum/action.c:1086: clear_keyboard_but_mods_and_keys();
                                   1828 ;	quantum/action.c:1087: }
      00766F 02 76 72         [24] 1829 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1830 ;------------------------------------------------------------
                                   1831 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1832 ;------------------------------------------------------------
                                   1833 ;	quantum/action.c:1093: void clear_keyboard_but_mods_and_keys(void) {
                                   1834 ;	-----------------------------------------
                                   1835 ;	 function clear_keyboard_but_mods_and_keys
                                   1836 ;	-----------------------------------------
      007672                       1837 _clear_keyboard_but_mods_and_keys:
                                   1838 ;	quantum/action.c:1095: ak820_tapping_cancel();
      007672 12 48 25         [24] 1839 	lcall	_ak820_tapping_cancel
                                   1840 ;	quantum/action.c:1097: ak820_combo_cancel();
      007675 12 36 1A         [24] 1841 	lcall	_ak820_combo_cancel
                                   1842 ;	quantum/action.c:1100: repeat_key_cancel();
      007678 12 A5 3C         [24] 1843 	lcall	_repeat_key_cancel
                                   1844 ;	quantum/action.c:1102: clear_owned_mods();
      00767B 12 7D 50         [24] 1845 	lcall	_clear_owned_mods
                                   1846 ;	quantum/action.c:1103: clear_owned_keys();
      00767E 12 7D 89         [24] 1847 	lcall	_clear_owned_keys
                                   1848 ;	quantum/action.c:1104: clear_owned_usages();
      007681 12 7E D8         [24] 1849 	lcall	_clear_owned_usages
                                   1850 ;	quantum/action.c:1105: layer_hold_clear();
      007684 12 78 2E         [24] 1851 	lcall	_layer_hold_clear
                                   1852 ;	quantum/action.c:1107: clear_macro_tri_layer();
      007687 12 9F 72         [24] 1853 	lcall	_clear_macro_tri_layer
                                   1854 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      00768A 90 0D D7         [24] 1855 	mov	dptr,#_actual_keyboard_report
      00768D 75 F0 00         [24] 1856 	mov	b, #0x00
      007690 12 6F C9         [24] 1857 	lcall	_clear_keys_from_report
                                   1858 ;	quantum/action.c:1112: host_system_send(0);
      007693 90 00 00         [24] 1859 	mov	dptr,#0x0000
      007696 12 6D 71         [24] 1860 	lcall	_host_system_send
                                   1861 ;	quantum/action.c:1113: host_consumer_send(0);
      007699 90 00 00         [24] 1862 	mov	dptr,#0x0000
      00769C 12 6D A3         [24] 1863 	lcall	_host_consumer_send
                                   1864 ;	quantum/action.c:1115: clear_weak_mods();
      00769F 12 81 22         [24] 1865 	lcall	_clear_weak_mods
                                   1866 ;	quantum/action.c:1116: send_keyboard_report();
                                   1867 ;	quantum/action.c:1124: }
      0076A2 02 80 73         [24] 1868 	ljmp	_send_keyboard_report
                                   1869 ;------------------------------------------------------------
                                   1870 ;Allocation info for local variables in function 'is_tap_record'
                                   1871 ;------------------------------------------------------------
                                   1872 ;record        Allocated with name '_is_tap_record_record_10000_758'
                                   1873 ;action        Allocated with name '_is_tap_record_action_10001_762'
                                   1874 ;------------------------------------------------------------
                                   1875 ;	quantum/action.c:1130: bool is_tap_record(keyrecord_t *record) {
                                   1876 ;	-----------------------------------------
                                   1877 	.area CSEG    (CODE)
                                   1878 	.area CONST   (CODE)
                                   1879 	.area XINIT   (CODE)
      00C61D                       1880 __xinit__disable_action_cache:
      00C61D 00                    1881 	.db #0x00	;  0
                                   1882 	.area CABS    (ABS,CODE)
                                   1883 
                                   1884 ; Experimental exact instruction outlining.
                                   1885 	.globl _ak820_outline_0000
                                   1886 	.globl _ak820_outline_0001
                                   1887 	.globl _ak820_outline_0002
                                   1888 	.globl _ak820_outline_0003
                                   1889 	.globl _ak820_outline_0004
                                   1890 	.globl _ak820_outline_0005
                                   1891 	.globl _ak820_outline_0007
                                   1892 	.globl _ak820_outline_0009
                                   1893 	.globl _ak820_outline_0014
                                   1894 	.globl _ak820_outline_0021
                                   1895 	.globl _ak820_outline_0025
                                   1896 	.globl _ak820_outline_0027
                                   1897 	.globl _ak820_outline_0031
                                   1898 	.globl _ak820_outline_0033
                                   1899 	.globl _ak820_outline_0044
                                   1900 	.globl _ak820_outline_0052
                                   1901 	.globl _ak820_outline_0060
                                   1902 	.globl _ak820_outline_0068
                                   1903 	.globl _ak820_outline_0073
                                   1904 	.globl _ak820_outline_0076
                                   1905 	.globl _ak820_outline_0098
                                   1906 	.globl _ak820_outline_0126
                                   1907 	.globl _ak820_outline_0127
                                   1908 
                                   1909 	.area CSEG (CODE)
                                   1910 ; function ak820_outline_0009
      0076A5                       1911 _ak820_outline_0009:
      0076A5 2D               [12] 1912 	add	a,r5
      0076A6 FA               [12] 1913 	mov	r2,a
      0076A7 E4               [12] 1914 	clr	a
      0076A8 3E               [12] 1915 	addc	a,r6
      0076A9 FB               [12] 1916 	mov	r3,a
      0076AA 8F 04            [24] 1917 	mov	ar4,r7
      0076AC 8A 82            [24] 1918 	mov	dpl,r2
      0076AE 8B 83            [24] 1919 	mov	dph,r3
      0076B0 8C F0            [24] 1920 	mov	b,r4
      0076B2 22               [24] 1921 	ret
                                   1922 
                                   1923 	.area CSEG (CODE)
                                   1924 ; function ak820_outline_0031
      0076B3                       1925 _ak820_outline_0031:
      0076B3 90 08 1F         [24] 1926 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076B6 E0               [24] 1927 	movx	a,@dptr
      0076B7 54 1F            [12] 1928 	anl	a,#0x1f
      0076B9 F5 82            [12] 1929 	mov	dpl,a
      0076BB 22               [24] 1930 	ret
                                   1931 
                                   1932 	.area CSEG (CODE)
                                   1933 ; function ak820_outline_0044
      0076BC                       1934 _ak820_outline_0044:
      0076BC 90 08 1E         [24] 1935 	mov	dptr,#_process_action_PARM_2
      0076BF E0               [24] 1936 	movx	a,@dptr
      0076C0 22               [24] 1937 	ret
                                   1938 
                                   1939 	.area CSEG (CODE)
                                   1940 ; function ak820_outline_0052
      0076C1                       1941 _ak820_outline_0052:
      0076C1 74 07            [12] 1942 	mov	a,#0x07
      0076C3 2D               [12] 1943 	add	a,r5
      0076C4 FB               [12] 1944 	mov	r3,a
      0076C5 E4               [12] 1945 	clr	a
      0076C6 3E               [12] 1946 	addc	a,r6
      0076C7 FA               [12] 1947 	mov	r2,a
      0076C8 8F 04            [24] 1948 	mov	ar4,r7
      0076CA 8B 82            [24] 1949 	mov	dpl,r3
      0076CC 8A 83            [24] 1950 	mov	dph,r2
      0076CE 8C F0            [24] 1951 	mov	b,r4
      0076D0 22               [24] 1952 	ret
                                   1953 
                                   1954 	.area CSEG (CODE)
                                   1955 ; function ak820_outline_0068
      0076D1                       1956 _ak820_outline_0068:
      0076D1 90 08 1F         [24] 1957 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076D4 E0               [24] 1958 	movx	a,@dptr
      0076D5 03               [12] 1959 	rr	a
      0076D6 03               [12] 1960 	rr	a
      0076D7 54 03            [12] 1961 	anl	a,#0x03
      0076D9 22               [24] 1962 	ret
                                   1963 
                                   1964 	.area CSEG (CODE)
                                   1965 ; function ak820_outline_0076
      0076DA                       1966 _ak820_outline_0076:
      0076DA 90 08 1F         [24] 1967 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076DD E0               [24] 1968 	movx	a,@dptr
      0076DE 54 0F            [12] 1969 	anl	a,#0x0f
      0076E0 22               [24] 1970 	ret
                                   1971 
                                   1972 	.area CSEG (CODE)
                                   1973 ; function ak820_outline_0126
      0076E1                       1974 _ak820_outline_0126:
      0076E1 90 08 24         [24] 1975 	mov	dptr,#_register_code_code_10000_694
      0076E4 E0               [24] 1976 	movx	a,@dptr
      0076E5 FF               [12] 1977 	mov	r7,a
      0076E6 22               [24] 1978 	ret
                                   1979 
                                   1980 	.area CSEG (CODE)
                                   1981 ; function ak820_outline_0127
      0076E7                       1982 _ak820_outline_0127:
      0076E7 90 08 25         [24] 1983 	mov	dptr,#_unregister_code_code_10000_708
      0076EA E0               [24] 1984 	movx	a,@dptr
      0076EB FF               [12] 1985 	mov	r7,a
      0076EC 22               [24] 1986 	ret
