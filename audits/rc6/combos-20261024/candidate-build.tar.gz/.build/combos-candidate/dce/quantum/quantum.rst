                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _layer_switch_get_layer
                                     24 	.globl _read_source_keycode_cache
                                     25 	.globl _update_source_layers_cache
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _keymap_key_to_keycode
                                     36 	.globl _rgb_matrix_set_suspend_state
                                     37 	.globl _rgb_matrix_task
                                     38 	.globl _mDelaymS
                                     39 	.globl _ADC_START
                                     40 	.globl _S0_R_FIFO
                                     41 	.globl _S0_T_FIFO
                                     42 	.globl _S0_FREE
                                     43 	.globl _S0_IF_BYTE
                                     44 	.globl _S0_IF_FIRST
                                     45 	.globl _S0_IF_OV
                                     46 	.globl _S0_FST_ACT
                                     47 	.globl _CP_RL2
                                     48 	.globl _C_T2
                                     49 	.globl _TR2
                                     50 	.globl _EXEN2
                                     51 	.globl _TCLK
                                     52 	.globl _RCLK
                                     53 	.globl _EXF2
                                     54 	.globl _CAP1F
                                     55 	.globl _TF2
                                     56 	.globl _RI
                                     57 	.globl _TI
                                     58 	.globl _RB8
                                     59 	.globl _TB8
                                     60 	.globl _REN
                                     61 	.globl _SM2
                                     62 	.globl _SM1
                                     63 	.globl _SM0
                                     64 	.globl _IT0
                                     65 	.globl _IE0
                                     66 	.globl _IT1
                                     67 	.globl _IE1
                                     68 	.globl _TR0
                                     69 	.globl _TF0
                                     70 	.globl _TR1
                                     71 	.globl _TF1
                                     72 	.globl _P4_0
                                     73 	.globl _P4_1
                                     74 	.globl _P4_2
                                     75 	.globl _P4_3
                                     76 	.globl _P4_4
                                     77 	.globl _P4_5
                                     78 	.globl _P4_6
                                     79 	.globl _RXD
                                     80 	.globl _TXD
                                     81 	.globl _INT0
                                     82 	.globl _INT1
                                     83 	.globl _T0
                                     84 	.globl _T1
                                     85 	.globl _MOSI1
                                     86 	.globl _MISO1
                                     87 	.globl _SCK1
                                     88 	.globl _P3_0
                                     89 	.globl _P3_1
                                     90 	.globl _P3_2
                                     91 	.globl _P3_3
                                     92 	.globl _P3_4
                                     93 	.globl _P3_5
                                     94 	.globl _P3_6
                                     95 	.globl _P3_7
                                     96 	.globl _CAP1_
                                     97 	.globl _T2_
                                     98 	.globl _CAP2_
                                     99 	.globl _T2EX_
                                    100 	.globl _RXD1
                                    101 	.globl _TXD1
                                    102 	.globl _P2_0
                                    103 	.globl _P2_1
                                    104 	.globl _P2_2
                                    105 	.globl _P2_3
                                    106 	.globl _P2_4
                                    107 	.globl _P2_5
                                    108 	.globl _P2_6
                                    109 	.globl _P2_7
                                    110 	.globl _AIN0
                                    111 	.globl _AIN1
                                    112 	.globl _AIN2
                                    113 	.globl _AIN3
                                    114 	.globl _AIN4
                                    115 	.globl _AIN5
                                    116 	.globl _AIN6
                                    117 	.globl _AIN7
                                    118 	.globl _CAP1
                                    119 	.globl _T2
                                    120 	.globl _CAP2
                                    121 	.globl _T2EX
                                    122 	.globl _INT0_
                                    123 	.globl _SCS
                                    124 	.globl _MOSI
                                    125 	.globl _MISO
                                    126 	.globl _SCK
                                    127 	.globl _RXD1_
                                    128 	.globl _TXD1_
                                    129 	.globl _P1_0
                                    130 	.globl _P1_1
                                    131 	.globl _P1_2
                                    132 	.globl _P1_3
                                    133 	.globl _P1_4
                                    134 	.globl _P1_5
                                    135 	.globl _P1_6
                                    136 	.globl _P1_7
                                    137 	.globl _AIN8
                                    138 	.globl _AIN9
                                    139 	.globl _AIN10
                                    140 	.globl _AIN11
                                    141 	.globl _AIN12
                                    142 	.globl _AIN13
                                    143 	.globl _RXD_
                                    144 	.globl _TXD_
                                    145 	.globl _SCL0
                                    146 	.globl _SDA0
                                    147 	.globl _P0_0
                                    148 	.globl _P0_1
                                    149 	.globl _P0_2
                                    150 	.globl _P0_3
                                    151 	.globl _P0_4
                                    152 	.globl _P0_5
                                    153 	.globl _P0_6
                                    154 	.globl _P0_7
                                    155 	.globl _IE_SPI0
                                    156 	.globl _IE_USB
                                    157 	.globl _IE_ADC
                                    158 	.globl _IE_UART1
                                    159 	.globl _IE_PWM_I2C
                                    160 	.globl _IE_GPIO
                                    161 	.globl _IE_WDOG
                                    162 	.globl _PX0
                                    163 	.globl _PT0
                                    164 	.globl _PX1
                                    165 	.globl _PT1
                                    166 	.globl _PS
                                    167 	.globl _PT2
                                    168 	.globl _PL_FLAG
                                    169 	.globl _PH_FLAG
                                    170 	.globl _EX0
                                    171 	.globl _ET0
                                    172 	.globl _EX1
                                    173 	.globl _ET1
                                    174 	.globl _ES
                                    175 	.globl _ET2
                                    176 	.globl _E_DIS
                                    177 	.globl _EA
                                    178 	.globl _P
                                    179 	.globl _F1
                                    180 	.globl _OV
                                    181 	.globl _RS0
                                    182 	.globl _RS1
                                    183 	.globl _F0
                                    184 	.globl _AC
                                    185 	.globl _CY
                                    186 	.globl _I2CS_INT_ST
                                    187 	.globl _I2CX_INT
                                    188 	.globl _LED_STATUS
                                    189 	.globl _LED_DMA_H
                                    190 	.globl _LED_DMA_L
                                    191 	.globl _LED_DMA
                                    192 	.globl _LED_PWM_OE
                                    193 	.globl _LED_COMMON
                                    194 	.globl _ADC_CHAN
                                    195 	.globl _ADC_DAT_H
                                    196 	.globl _ADC_DAT_L
                                    197 	.globl _ADC_DAT
                                    198 	.globl _ADC_CTRL
                                    199 	.globl _SPI1_CK_SE
                                    200 	.globl _SPI1_CTRL
                                    201 	.globl _SPI1_DATA
                                    202 	.globl _SPI1_STAT
                                    203 	.globl _SIF1
                                    204 	.globl _SBAUD1
                                    205 	.globl _SBUF1
                                    206 	.globl _SCON1
                                    207 	.globl _SPI0_SETUP
                                    208 	.globl _SPI0_CK_SE
                                    209 	.globl _SPI0_CTRL
                                    210 	.globl _SPI0_DATA
                                    211 	.globl _SPI0_STAT
                                    212 	.globl _T2CAP1H
                                    213 	.globl _T2CAP1L
                                    214 	.globl _T2CAP1
                                    215 	.globl _TH2
                                    216 	.globl _TL2
                                    217 	.globl _T2COUNT
                                    218 	.globl _RCAP2H
                                    219 	.globl _RCAP2L
                                    220 	.globl _RCAP2
                                    221 	.globl _T2MOD
                                    222 	.globl _T2CON
                                    223 	.globl _SBUF
                                    224 	.globl _SCON
                                    225 	.globl _TH1
                                    226 	.globl _TH0
                                    227 	.globl _TL1
                                    228 	.globl _TL0
                                    229 	.globl _TMOD
                                    230 	.globl _TCON
                                    231 	.globl _XBUS_AUX
                                    232 	.globl _P7
                                    233 	.globl _P6_DIR
                                    234 	.globl _P6_OUT_PU
                                    235 	.globl _P6_IN
                                    236 	.globl _P5_DIR
                                    237 	.globl _P5_OUT_PU
                                    238 	.globl _P5_IN
                                    239 	.globl _P4_LED_KEY
                                    240 	.globl _P4_DIR_PU
                                    241 	.globl _P4_MOD_OC
                                    242 	.globl _P4
                                    243 	.globl _P3_DIR_PU
                                    244 	.globl _P3_MOD_OC
                                    245 	.globl _P3
                                    246 	.globl _P2_DIR_PU
                                    247 	.globl _P2_MOD_OC
                                    248 	.globl _P2
                                    249 	.globl _P1_DIR_PU
                                    250 	.globl _P1_MOD_OC
                                    251 	.globl _P1
                                    252 	.globl _P0_DIR_PU
                                    253 	.globl _P0_MOD_OC
                                    254 	.globl _P0
                                    255 	.globl _ROM_CTRL
                                    256 	.globl _ROM_DATA_HH
                                    257 	.globl _ROM_DATA_HL
                                    258 	.globl _ROM_DATA_HI
                                    259 	.globl _ROM_ADDR_H
                                    260 	.globl _ROM_ADDR_L
                                    261 	.globl _ROM_ADDR
                                    262 	.globl _GPIO_IE
                                    263 	.globl _IP_EX
                                    264 	.globl _IE_EX
                                    265 	.globl _IP
                                    266 	.globl _IE
                                    267 	.globl _WDOG_COUNT
                                    268 	.globl _RESET_KEEP
                                    269 	.globl _WAKE_CTRL
                                    270 	.globl _CLOCK_CFG
                                    271 	.globl _POWER_CFG
                                    272 	.globl _PCON
                                    273 	.globl _GLOBAL_CFG
                                    274 	.globl _SAFE_MOD
                                    275 	.globl _DPH
                                    276 	.globl _DPL
                                    277 	.globl _SP
                                    278 	.globl _A_INV
                                    279 	.globl _B
                                    280 	.globl _ACC
                                    281 	.globl _PSW
                                    282 	.globl _process_record_quantum_helper_PARM_2
                                    283 	.globl _get_event_keycode_PARM_1
                                    284 	.globl _get_record_keycode_PARM_2
                                    285 	.globl _post_process_record_user_PARM_2
                                    286 	.globl _post_process_record_kb_PARM_2
                                    287 	.globl _process_record_user_PARM_2
                                    288 	.globl _process_record_kb_PARM_2
                                    289 	.globl _pre_process_record_user_PARM_2
                                    290 	.globl _pre_process_record_kb_PARM_2
                                    291 	.globl _register_code16
                                    292 	.globl _unregister_code16
                                    293 	.globl _pre_process_record_kb
                                    294 	.globl _pre_process_record_user
                                    295 	.globl _process_action_kb
                                    296 	.globl _process_record_kb
                                    297 	.globl _process_record_user
                                    298 	.globl _post_process_record_kb
                                    299 	.globl _post_process_record_user
                                    300 	.globl _reset_keyboard
                                    301 	.globl _soft_reset_keyboard
                                    302 	.globl _get_record_keycode
                                    303 	.globl _get_event_keycode
                                    304 	.globl _pre_process_record_quantum
                                    305 	.globl _post_process_record_quantum
                                    306 	.globl _process_record_quantum
                                    307 	.globl _process_record_quantum_helper
                                    308 	.globl _shutdown_user
                                    309 ;--------------------------------------------------------
                                    310 ; special function registers
                                    311 ;--------------------------------------------------------
                                    312 	.area RSEG    (ABS,DATA)
      000000                        313 	.org 0x0000
                           0000D0   314 _PSW	=	0x00d0
                           0000E0   315 _ACC	=	0x00e0
                           0000F0   316 _B	=	0x00f0
                           0000FD   317 _A_INV	=	0x00fd
                           000081   318 _SP	=	0x0081
                           000082   319 _DPL	=	0x0082
                           000083   320 _DPH	=	0x0083
                           0000A1   321 _SAFE_MOD	=	0x00a1
                           0000B1   322 _GLOBAL_CFG	=	0x00b1
                           000087   323 _PCON	=	0x0087
                           0000BA   324 _POWER_CFG	=	0x00ba
                           0000B9   325 _CLOCK_CFG	=	0x00b9
                           0000A9   326 _WAKE_CTRL	=	0x00a9
                           0000FE   327 _RESET_KEEP	=	0x00fe
                           0000FF   328 _WDOG_COUNT	=	0x00ff
                           0000A8   329 _IE	=	0x00a8
                           0000B8   330 _IP	=	0x00b8
                           0000E8   331 _IE_EX	=	0x00e8
                           0000E9   332 _IP_EX	=	0x00e9
                           0000B2   333 _GPIO_IE	=	0x00b2
                           008584   334 _ROM_ADDR	=	0x8584
                           000084   335 _ROM_ADDR_L	=	0x0084
                           000085   336 _ROM_ADDR_H	=	0x0085
                           008F8E   337 _ROM_DATA_HI	=	0x8f8e
                           00008E   338 _ROM_DATA_HL	=	0x008e
                           00008F   339 _ROM_DATA_HH	=	0x008f
                           000086   340 _ROM_CTRL	=	0x0086
                           000080   341 _P0	=	0x0080
                           0000C4   342 _P0_MOD_OC	=	0x00c4
                           0000C5   343 _P0_DIR_PU	=	0x00c5
                           000090   344 _P1	=	0x0090
                           000092   345 _P1_MOD_OC	=	0x0092
                           000093   346 _P1_DIR_PU	=	0x0093
                           0000A0   347 _P2	=	0x00a0
                           000094   348 _P2_MOD_OC	=	0x0094
                           000095   349 _P2_DIR_PU	=	0x0095
                           0000B0   350 _P3	=	0x00b0
                           000096   351 _P3_MOD_OC	=	0x0096
                           000097   352 _P3_DIR_PU	=	0x0097
                           0000C0   353 _P4	=	0x00c0
                           0000C2   354 _P4_MOD_OC	=	0x00c2
                           0000C3   355 _P4_DIR_PU	=	0x00c3
                           0000C1   356 _P4_LED_KEY	=	0x00c1
                           0000AA   357 _P5_IN	=	0x00aa
                           0000AB   358 _P5_OUT_PU	=	0x00ab
                           0000AC   359 _P5_DIR	=	0x00ac
                           0000AD   360 _P6_IN	=	0x00ad
                           0000AE   361 _P6_OUT_PU	=	0x00ae
                           0000AF   362 _P6_DIR	=	0x00af
                           0000F1   363 _P7	=	0x00f1
                           0000A2   364 _XBUS_AUX	=	0x00a2
                           000088   365 _TCON	=	0x0088
                           000089   366 _TMOD	=	0x0089
                           00008A   367 _TL0	=	0x008a
                           00008B   368 _TL1	=	0x008b
                           00008C   369 _TH0	=	0x008c
                           00008D   370 _TH1	=	0x008d
                           000098   371 _SCON	=	0x0098
                           000099   372 _SBUF	=	0x0099
                           0000C8   373 _T2CON	=	0x00c8
                           0000C9   374 _T2MOD	=	0x00c9
                           00CBCA   375 _RCAP2	=	0xcbca
                           0000CA   376 _RCAP2L	=	0x00ca
                           0000CB   377 _RCAP2H	=	0x00cb
                           00CDCC   378 _T2COUNT	=	0xcdcc
                           0000CC   379 _TL2	=	0x00cc
                           0000CD   380 _TH2	=	0x00cd
                           00CFCE   381 _T2CAP1	=	0xcfce
                           0000CE   382 _T2CAP1L	=	0x00ce
                           0000CF   383 _T2CAP1H	=	0x00cf
                           0000F8   384 _SPI0_STAT	=	0x00f8
                           0000F9   385 _SPI0_DATA	=	0x00f9
                           0000FA   386 _SPI0_CTRL	=	0x00fa
                           0000FB   387 _SPI0_CK_SE	=	0x00fb
                           0000FC   388 _SPI0_SETUP	=	0x00fc
                           0000BC   389 _SCON1	=	0x00bc
                           0000BD   390 _SBUF1	=	0x00bd
                           0000BE   391 _SBAUD1	=	0x00be
                           0000BF   392 _SIF1	=	0x00bf
                           0000B4   393 _SPI1_STAT	=	0x00b4
                           0000B5   394 _SPI1_DATA	=	0x00b5
                           0000B6   395 _SPI1_CTRL	=	0x00b6
                           0000B7   396 _SPI1_CK_SE	=	0x00b7
                           0000F3   397 _ADC_CTRL	=	0x00f3
                           00F5F4   398 _ADC_DAT	=	0xf5f4
                           0000F4   399 _ADC_DAT_L	=	0x00f4
                           0000F5   400 _ADC_DAT_H	=	0x00f5
                           0000F6   401 _ADC_CHAN	=	0x00f6
                           0000A6   402 _LED_COMMON	=	0x00a6
                           0000A7   403 _LED_PWM_OE	=	0x00a7
                           00C7C6   404 _LED_DMA	=	0xc7c6
                           0000C6   405 _LED_DMA_L	=	0x00c6
                           0000C7   406 _LED_DMA_H	=	0x00c7
                           0000F7   407 _LED_STATUS	=	0x00f7
                           0000B3   408 _I2CX_INT	=	0x00b3
                           0000BB   409 _I2CS_INT_ST	=	0x00bb
                                    410 ;--------------------------------------------------------
                                    411 ; special function bits
                                    412 ;--------------------------------------------------------
                                    413 	.area RSEG    (ABS,DATA)
      000000                        414 	.org 0x0000
                           0000D7   415 _CY	=	0x00d7
                           0000D6   416 _AC	=	0x00d6
                           0000D5   417 _F0	=	0x00d5
                           0000D4   418 _RS1	=	0x00d4
                           0000D3   419 _RS0	=	0x00d3
                           0000D2   420 _OV	=	0x00d2
                           0000D1   421 _F1	=	0x00d1
                           0000D0   422 _P	=	0x00d0
                           0000AF   423 _EA	=	0x00af
                           0000AE   424 _E_DIS	=	0x00ae
                           0000AD   425 _ET2	=	0x00ad
                           0000AC   426 _ES	=	0x00ac
                           0000AB   427 _ET1	=	0x00ab
                           0000AA   428 _EX1	=	0x00aa
                           0000A9   429 _ET0	=	0x00a9
                           0000A8   430 _EX0	=	0x00a8
                           0000BF   431 _PH_FLAG	=	0x00bf
                           0000BE   432 _PL_FLAG	=	0x00be
                           0000BD   433 _PT2	=	0x00bd
                           0000BC   434 _PS	=	0x00bc
                           0000BB   435 _PT1	=	0x00bb
                           0000BA   436 _PX1	=	0x00ba
                           0000B9   437 _PT0	=	0x00b9
                           0000B8   438 _PX0	=	0x00b8
                           0000EF   439 _IE_WDOG	=	0x00ef
                           0000EE   440 _IE_GPIO	=	0x00ee
                           0000ED   441 _IE_PWM_I2C	=	0x00ed
                           0000EC   442 _IE_UART1	=	0x00ec
                           0000EB   443 _IE_ADC	=	0x00eb
                           0000E9   444 _IE_USB	=	0x00e9
                           0000E8   445 _IE_SPI0	=	0x00e8
                           000087   446 _P0_7	=	0x0087
                           000086   447 _P0_6	=	0x0086
                           000085   448 _P0_5	=	0x0085
                           000084   449 _P0_4	=	0x0084
                           000083   450 _P0_3	=	0x0083
                           000082   451 _P0_2	=	0x0082
                           000081   452 _P0_1	=	0x0081
                           000080   453 _P0_0	=	0x0080
                           000081   454 _SDA0	=	0x0081
                           000080   455 _SCL0	=	0x0080
                           000083   456 _TXD_	=	0x0083
                           000082   457 _RXD_	=	0x0082
                           000085   458 _AIN13	=	0x0085
                           000084   459 _AIN12	=	0x0084
                           000083   460 _AIN11	=	0x0083
                           000082   461 _AIN10	=	0x0082
                           000081   462 _AIN9	=	0x0081
                           000080   463 _AIN8	=	0x0080
                           000097   464 _P1_7	=	0x0097
                           000096   465 _P1_6	=	0x0096
                           000095   466 _P1_5	=	0x0095
                           000094   467 _P1_4	=	0x0094
                           000093   468 _P1_3	=	0x0093
                           000092   469 _P1_2	=	0x0092
                           000091   470 _P1_1	=	0x0091
                           000090   471 _P1_0	=	0x0090
                           000097   472 _TXD1_	=	0x0097
                           000096   473 _RXD1_	=	0x0096
                           000097   474 _SCK	=	0x0097
                           000096   475 _MISO	=	0x0096
                           000095   476 _MOSI	=	0x0095
                           000094   477 _SCS	=	0x0094
                           000092   478 _INT0_	=	0x0092
                           000091   479 _T2EX	=	0x0091
                           000091   480 _CAP2	=	0x0091
                           000090   481 _T2	=	0x0090
                           000090   482 _CAP1	=	0x0090
                           000097   483 _AIN7	=	0x0097
                           000096   484 _AIN6	=	0x0096
                           000095   485 _AIN5	=	0x0095
                           000094   486 _AIN4	=	0x0094
                           000093   487 _AIN3	=	0x0093
                           000092   488 _AIN2	=	0x0092
                           000091   489 _AIN1	=	0x0091
                           000090   490 _AIN0	=	0x0090
                           0000A7   491 _P2_7	=	0x00a7
                           0000A6   492 _P2_6	=	0x00a6
                           0000A5   493 _P2_5	=	0x00a5
                           0000A4   494 _P2_4	=	0x00a4
                           0000A3   495 _P2_3	=	0x00a3
                           0000A2   496 _P2_2	=	0x00a2
                           0000A1   497 _P2_1	=	0x00a1
                           0000A0   498 _P2_0	=	0x00a0
                           0000A7   499 _TXD1	=	0x00a7
                           0000A6   500 _RXD1	=	0x00a6
                           0000A5   501 _T2EX_	=	0x00a5
                           0000A5   502 _CAP2_	=	0x00a5
                           0000A4   503 _T2_	=	0x00a4
                           0000A4   504 _CAP1_	=	0x00a4
                           0000B7   505 _P3_7	=	0x00b7
                           0000B6   506 _P3_6	=	0x00b6
                           0000B5   507 _P3_5	=	0x00b5
                           0000B4   508 _P3_4	=	0x00b4
                           0000B3   509 _P3_3	=	0x00b3
                           0000B2   510 _P3_2	=	0x00b2
                           0000B1   511 _P3_1	=	0x00b1
                           0000B0   512 _P3_0	=	0x00b0
                           0000B7   513 _SCK1	=	0x00b7
                           0000B6   514 _MISO1	=	0x00b6
                           0000B5   515 _MOSI1	=	0x00b5
                           0000B5   516 _T1	=	0x00b5
                           0000B4   517 _T0	=	0x00b4
                           0000B3   518 _INT1	=	0x00b3
                           0000B2   519 _INT0	=	0x00b2
                           0000B1   520 _TXD	=	0x00b1
                           0000B0   521 _RXD	=	0x00b0
                           0000C6   522 _P4_6	=	0x00c6
                           0000C5   523 _P4_5	=	0x00c5
                           0000C4   524 _P4_4	=	0x00c4
                           0000C3   525 _P4_3	=	0x00c3
                           0000C2   526 _P4_2	=	0x00c2
                           0000C1   527 _P4_1	=	0x00c1
                           0000C0   528 _P4_0	=	0x00c0
                           00008F   529 _TF1	=	0x008f
                           00008E   530 _TR1	=	0x008e
                           00008D   531 _TF0	=	0x008d
                           00008C   532 _TR0	=	0x008c
                           00008B   533 _IE1	=	0x008b
                           00008A   534 _IT1	=	0x008a
                           000089   535 _IE0	=	0x0089
                           000088   536 _IT0	=	0x0088
                           00009F   537 _SM0	=	0x009f
                           00009E   538 _SM1	=	0x009e
                           00009D   539 _SM2	=	0x009d
                           00009C   540 _REN	=	0x009c
                           00009B   541 _TB8	=	0x009b
                           00009A   542 _RB8	=	0x009a
                           000099   543 _TI	=	0x0099
                           000098   544 _RI	=	0x0098
                           0000CF   545 _TF2	=	0x00cf
                           0000CF   546 _CAP1F	=	0x00cf
                           0000CE   547 _EXF2	=	0x00ce
                           0000CD   548 _RCLK	=	0x00cd
                           0000CC   549 _TCLK	=	0x00cc
                           0000CB   550 _EXEN2	=	0x00cb
                           0000CA   551 _TR2	=	0x00ca
                           0000C9   552 _C_T2	=	0x00c9
                           0000C8   553 _CP_RL2	=	0x00c8
                           0000FF   554 _S0_FST_ACT	=	0x00ff
                           0000FE   555 _S0_IF_OV	=	0x00fe
                           0000FD   556 _S0_IF_FIRST	=	0x00fd
                           0000FC   557 _S0_IF_BYTE	=	0x00fc
                           0000FB   558 _S0_FREE	=	0x00fb
                           0000FA   559 _S0_T_FIFO	=	0x00fa
                           0000F8   560 _S0_R_FIFO	=	0x00f8
                           0000F7   561 _ADC_START	=	0x00f7
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable register banks
                                    564 ;--------------------------------------------------------
                                    565 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        566 	.ds 8
                                    567 ;--------------------------------------------------------
                                    568 ; internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area DSEG    (DATA)
                                    571 ;--------------------------------------------------------
                                    572 ; overlayable items in internal ram
                                    573 ;--------------------------------------------------------
                                    574 ;--------------------------------------------------------
                                    575 ; indirectly addressable internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area ISEG    (DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; absolute internal ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area IABS    (ABS,DATA)
                                    582 	.area IABS    (ABS,DATA)
                                    583 ;--------------------------------------------------------
                                    584 ; bit data
                                    585 ;--------------------------------------------------------
                                    586 	.area BSEG    (BIT)
      00001E                        587 _pre_process_record_quantum_sloc0_1_0:
      00001E                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000BDF                        597 _extract_mod_bits_code_10000_592:
      000BDF                        598 	.ds 2
      000BE1                        599 _register_code16_code_10000_598:
      000BE1                        600 	.ds 2
      000BE3                        601 _unregister_code16_code_10000_603:
      000BE3                        602 	.ds 2
      000BE5                        603 _pre_process_record_kb_PARM_2:
      000BE5                        604 	.ds 3
      000BE8                        605 _pre_process_record_kb_keycode_10000_617:
      000BE8                        606 	.ds 2
      000BEA                        607 _pre_process_record_user_PARM_2:
      000BEA                        608 	.ds 3
      000BED                        609 _process_record_kb_PARM_2:
      000BED                        610 	.ds 3
      000BF0                        611 _process_record_kb_keycode_10000_623:
      000BF0                        612 	.ds 2
      000BF2                        613 _process_record_user_PARM_2:
      000BF2                        614 	.ds 3
      000BF5                        615 _post_process_record_kb_PARM_2:
      000BF5                        616 	.ds 3
      000BF8                        617 _post_process_record_kb_keycode_10000_627:
      000BF8                        618 	.ds 2
      000BFA                        619 _post_process_record_user_PARM_2:
      000BFA                        620 	.ds 3
      000BFD                        621 _get_record_keycode_PARM_2:
      000BFD                        622 	.ds 1
      000BFE                        623 _get_record_keycode_record_10000_641:
      000BFE                        624 	.ds 3
      000C01                        625 _get_event_keycode_PARM_1:
      000C01                        626 	.ds 6
      000C07                        627 _get_event_keycode_update_layer_cache_10000_645:
      000C07                        628 	.ds 1
      000C08                        629 _pre_process_record_quantum_record_10000_651:
      000C08                        630 	.ds 3
      000C0B                        631 _post_process_record_quantum_record_10000_653:
      000C0B                        632 	.ds 3
      000C0E                        633 _process_record_quantum_record_10000_655:
      000C0E                        634 	.ds 3
      000C11                        635 _process_record_quantum_helper_PARM_2:
      000C11                        636 	.ds 3
      000C14                        637 _process_record_quantum_helper_keycode_10000_657:
      000C14                        638 	.ds 2
      000C16                        639 _get_u8_str_buf_10000_683:
      000C16                        640 	.ds 4
      000C1A                        641 _get_u8_str_last_num_10000_683:
      000C1A                        642 	.ds 1
      000C1B                        643 _get_u8_str_last_pad_10000_683:
      000C1B                        644 	.ds 1
      000C1C                        645 _get_u16_str_buf_10000_687:
      000C1C                        646 	.ds 6
      000C22                        647 _get_u16_str_last_num_10000_687:
      000C22                        648 	.ds 2
      000C24                        649 _get_u16_str_last_pad_10000_687:
      000C24                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
                                    659 	.area HOME    (CODE)
                                    660 	.area GSINIT0 (CODE)
                                    661 	.area GSINIT1 (CODE)
                                    662 	.area GSINIT2 (CODE)
                                    663 	.area GSINIT3 (CODE)
                                    664 	.area GSINIT4 (CODE)
                                    665 	.area GSINIT5 (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 	.area GSFINAL (CODE)
                                    668 	.area CSEG    (CODE)
                                    669 ;--------------------------------------------------------
                                    670 ; global & static initialisations
                                    671 ;--------------------------------------------------------
                                    672 	.area HOME    (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 ;------------------------------------------------------------
                                    677 ;Allocation info for local variables in function 'get_u8_str'
                                    678 ;------------------------------------------------------------
                                    679 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    680 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_682'
                                    681 ;buf           Allocated with name '_get_u8_str_buf_10000_683'
                                    682 ;last_num      Allocated with name '_get_u8_str_last_num_10000_683'
                                    683 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_683'
                                    684 ;------------------------------------------------------------
                                    685 ;	quantum/quantum.c:691: static char    buf[4]   = {0};
      003121 90 0C 16         [24]  686 	mov	dptr,#_get_u8_str_buf_10000_683
      003124 E4               [12]  687 	clr	a
      003125 F0               [24]  688 	movx	@dptr,a
      003126 90 0C 17         [24]  689 	mov	dptr,#(_get_u8_str_buf_10000_683 + 0x0001)
      003129 F0               [24]  690 	movx	@dptr,a
      00312A 90 0C 18         [24]  691 	mov	dptr,#(_get_u8_str_buf_10000_683 + 0x0002)
      00312D F0               [24]  692 	movx	@dptr,a
      00312E 90 0C 19         [24]  693 	mov	dptr,#(_get_u8_str_buf_10000_683 + 0x0003)
      003131 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/quantum.c:692: static uint8_t last_num = 0xFF;
      003132 90 0C 1A         [24]  696 	mov	dptr,#_get_u8_str_last_num_10000_683
      003135 14               [12]  697 	dec	a
      003136 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/quantum.c:693: static char    last_pad = '\0';
      003137 90 0C 1B         [24]  700 	mov	dptr,#_get_u8_str_last_pad_10000_683
      00313A E4               [12]  701 	clr	a
      00313B F0               [24]  702 	movx	@dptr,a
                                    703 ;------------------------------------------------------------
                                    704 ;Allocation info for local variables in function 'get_u16_str'
                                    705 ;------------------------------------------------------------
                                    706 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    707 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_686'
                                    708 ;buf           Allocated with name '_get_u16_str_buf_10000_687'
                                    709 ;last_num      Allocated with name '_get_u16_str_last_num_10000_687'
                                    710 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_687'
                                    711 ;------------------------------------------------------------
                                    712 ;	quantum/quantum.c:711: static char     buf[6]   = {0};
      00313C 90 0C 1C         [24]  713 	mov	dptr,#_get_u16_str_buf_10000_687
      00313F E4               [12]  714 	clr	a
      003140 F0               [24]  715 	movx	@dptr,a
      003141 90 0C 1D         [24]  716 	mov	dptr,#(_get_u16_str_buf_10000_687 + 0x0001)
      003144 F0               [24]  717 	movx	@dptr,a
      003145 90 0C 1E         [24]  718 	mov	dptr,#(_get_u16_str_buf_10000_687 + 0x0002)
      003148 F0               [24]  719 	movx	@dptr,a
      003149 90 0C 1F         [24]  720 	mov	dptr,#(_get_u16_str_buf_10000_687 + 0x0003)
      00314C F0               [24]  721 	movx	@dptr,a
      00314D 90 0C 20         [24]  722 	mov	dptr,#(_get_u16_str_buf_10000_687 + 0x0004)
      003150 F0               [24]  723 	movx	@dptr,a
      003151 90 0C 21         [24]  724 	mov	dptr,#(_get_u16_str_buf_10000_687 + 0x0005)
      003154 F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/quantum.c:712: static uint16_t last_num = 0xFF;
      003155 90 0C 22         [24]  727 	mov	dptr,#_get_u16_str_last_num_10000_687
      003158 14               [12]  728 	dec	a
      003159 F0               [24]  729 	movx	@dptr,a
      00315A E4               [12]  730 	clr	a
      00315B A3               [24]  731 	inc	dptr
      00315C F0               [24]  732 	movx	@dptr,a
                                    733 ;	quantum/quantum.c:713: static char     last_pad = '\0';
      00315D 90 0C 24         [24]  734 	mov	dptr,#_get_u16_str_last_pad_10000_687
      003160 F0               [24]  735 	movx	@dptr,a
                                    736 ;--------------------------------------------------------
                                    737 ; Home
                                    738 ;--------------------------------------------------------
                                    739 	.area HOME    (CODE)
                                    740 	.area HOME    (CODE)
                                    741 ;--------------------------------------------------------
                                    742 ; code
                                    743 ;--------------------------------------------------------
                                    744 	.area CSEG    (CODE)
                                    745 ;------------------------------------------------------------
                                    746 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    747 ;------------------------------------------------------------
                                    748 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    749 ;------------------------------------------------------------
                                    750 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    751 ;	-----------------------------------------
                           000007   752 	ar7 = 0x07
                           000006   753 	ar6 = 0x06
                           000005   754 	ar5 = 0x05
                           000004   755 	ar4 = 0x04
                           000003   756 	ar3 = 0x03
                           000002   757 	ar2 = 0x02
                           000001   758 	ar1 = 0x01
                           000000   759 	ar0 = 0x00
                                    760 ;	 function extract_mod_bits
                                    761 ;	-----------------------------------------
      00A0AC                        762 _extract_mod_bits:
      00A0AC 12 43 EA         [24]  763 	lcall	_ak820_outline_0010
      00A0AF 90 0B DF         [24]  764 	mov	dptr,#_extract_mod_bits_code_10000_592
      00A0B2 12 43 E5         [24]  765 	lcall	_ak820_outline_0007
                                    766 ;	quantum/quantum.c:104: uint8_t mods = (uint8_t)(code >> 8);
      00A0B5 90 0B DF         [24]  767 	mov	dptr,#_extract_mod_bits_code_10000_592
      00A0B8 E0               [24]  768 	movx	a,@dptr
      00A0B9 A3               [24]  769 	inc	dptr
      00A0BA E0               [24]  770 	movx	a,@dptr
                                    771 ;	quantum/quantum.c:105: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A0BB FF               [12]  772 	mov	r7,a
      00A0BC 60 05            [24]  773 	jz	00101$
      00A0BE EF               [12]  774 	mov	a,r7
      00A0BF 24 E0            [12]  775 	add	a,#0xff - 0x1f
      00A0C1 50 04            [24]  776 	jnc	00102$
                                    777 ;	free result
      00A0C3                        778 00101$:
      00A0C3 75 82 00         [24]  779 	mov	dpl, #0x00
      00A0C6 22               [24]  780 	ret
      00A0C7                        781 00102$:
                                    782 ;	quantum/quantum.c:106: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A0C7 EF               [12]  783 	mov	a,r7
      00A0C8 30 E4 07         [24]  784 	jnb	acc.4,00106$
      00A0CB EF               [12]  785 	mov	a,r7
      00A0CC C4               [12]  786 	swap	a
      00A0CD 54 F0            [12]  787 	anl	a,#0xf0
      00A0CF FE               [12]  788 	mov	r6,a
      00A0D0 80 02            [24]  789 	sjmp	00107$
      00A0D2                        790 00106$:
      00A0D2 8F 06            [24]  791 	mov	ar6,r7
      00A0D4                        792 00107$:
      00A0D4 8E 82            [24]  793 	mov	dpl, r6
                                    794 ;	quantum/quantum.c:134: }
      00A0D6 22               [24]  795 	ret
                                    796 ;------------------------------------------------------------
                                    797 ;Allocation info for local variables in function 'do_code16'
                                    798 ;------------------------------------------------------------
                                    799 ;f             Allocated with name '_do_code16_PARM_2'
                                    800 ;code          Allocated with name '_do_code16_code_10000_595'
                                    801 ;------------------------------------------------------------
                                    802 ;	quantum/quantum.c:136: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function register_code16
                                    805 ;	-----------------------------------------
      00A0D7                        806 _register_code16:
      00A0D7 12 43 EA         [24]  807 	lcall	_ak820_outline_0010
      00A0DA 90 0B E1         [24]  808 	mov	dptr,#_register_code16_code_10000_598
      00A0DD 12 43 E5         [24]  809 	lcall	_ak820_outline_0007
                                    810 ;	quantum/quantum.c:142: uint8_t mods = extract_mod_bits(code);
      00A0E0 90 0B E1         [24]  811 	mov	dptr,#_register_code16_code_10000_598
      00A0E3 12 43 C5         [24]  812 	lcall	_ak820_outline_0000
      00A0E6 12 43 D3         [24]  813 	lcall	_ak820_outline_0002
      00A0E9 C0 07            [24]  814 	push	ar7
      00A0EB C0 06            [24]  815 	push	ar6
      00A0ED 12 A0 AC         [24]  816 	lcall	_extract_mod_bits
      00A0F0 AD 82            [24]  817 	mov	r5, dpl
      00A0F2 D0 06            [24]  818 	pop	ar6
      00A0F4 D0 07            [24]  819 	pop	ar7
                                    820 ;	quantum/quantum.c:143: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A0F6 12 9E 51         [24]  821 	lcall	_ak820_outline_0085
      00A0F9 40 07            [24]  822 	jc	00105$
      00A0FB 74 E7            [12]  823 	mov	a,#0xe7
      00A0FD 9E               [12]  824 	subb	a,r6
      00A0FE E4               [12]  825 	clr	a
      00A0FF 9F               [12]  826 	subb	a,r7
      00A100 50 08            [24]  827 	jnc	00101$
                                    828 ;	free result
      00A102                        829 00105$:
      00A102 90 0B E1         [24]  830 	mov	dptr,#_register_code16_code_10000_598
      00A105 12 6D E3         [24]  831 	lcall	_ak820_outline_0018
      00A108 70 07            [24]  832 	jnz	00102$
      00A10A                        833 00101$:
                                    834 ;	quantum/quantum.c:144: register_mods(mods);
      00A10A 8D 82            [24]  835 	mov	dpl, r5
      00A10C 12 76 10         [24]  836 	lcall	_register_mods
      00A10F 80 05            [24]  837 	sjmp	00103$
      00A111                        838 00102$:
                                    839 ;	quantum/quantum.c:146: register_weak_mods(mods);
      00A111 8D 82            [24]  840 	mov	dpl, r5
      00A113 12 76 38         [24]  841 	lcall	_register_weak_mods
      00A116                        842 00103$:
                                    843 ;	quantum/quantum.c:148: register_code(code);
      00A116 90 0B E1         [24]  844 	mov	dptr,#_register_code16_code_10000_598
      00A119 E0               [24]  845 	movx	a,@dptr
      00A11A F5 82            [12]  846 	mov	dpl,a
                                    847 ;	quantum/quantum.c:158: }
      00A11C 02 74 ED         [24]  848 	ljmp	_register_code
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'unregister_code16'
                                    851 ;------------------------------------------------------------
                                    852 ;code          Allocated with name '_unregister_code16_code_10000_603'
                                    853 ;mods          Allocated with name '_unregister_code16_mods_10000_604'
                                    854 ;------------------------------------------------------------
                                    855 ;	quantum/quantum.c:160: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    856 ;	-----------------------------------------
                                    857 ;	 function unregister_code16
                                    858 ;	-----------------------------------------
      00A11F                        859 _unregister_code16:
      00A11F 12 43 EA         [24]  860 	lcall	_ak820_outline_0010
      00A122 90 0B E3         [24]  861 	mov	dptr,#_unregister_code16_code_10000_603
      00A125 12 43 E5         [24]  862 	lcall	_ak820_outline_0007
                                    863 ;	quantum/quantum.c:162: uint8_t mods = extract_mod_bits(code);
      00A128 90 0B E3         [24]  864 	mov	dptr,#_unregister_code16_code_10000_603
      00A12B 12 43 C5         [24]  865 	lcall	_ak820_outline_0000
      00A12E 12 43 D3         [24]  866 	lcall	_ak820_outline_0002
      00A131 C0 07            [24]  867 	push	ar7
      00A133 C0 06            [24]  868 	push	ar6
      00A135 12 A0 AC         [24]  869 	lcall	_extract_mod_bits
      00A138 AD 82            [24]  870 	mov	r5, dpl
      00A13A D0 06            [24]  871 	pop	ar6
                                    872 ;	quantum/quantum.c:163: unregister_code(code);
      00A13C 8E 04            [24]  873 	mov	ar4,r6
      00A13E 8C 82            [24]  874 	mov	dpl, r4
      00A140 C0 06            [24]  875 	push	ar6
      00A142 C0 05            [24]  876 	push	ar5
      00A144 12 75 5A         [24]  877 	lcall	_unregister_code
      00A147 D0 05            [24]  878 	pop	ar5
      00A149 D0 06            [24]  879 	pop	ar6
      00A14B D0 07            [24]  880 	pop	ar7
                                    881 ;	quantum/quantum.c:164: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A14D 12 9E 51         [24]  882 	lcall	_ak820_outline_0085
      00A150 40 07            [24]  883 	jc	00105$
      00A152 74 E7            [12]  884 	mov	a,#0xe7
      00A154 9E               [12]  885 	subb	a,r6
      00A155 E4               [12]  886 	clr	a
      00A156 9F               [12]  887 	subb	a,r7
      00A157 50 08            [24]  888 	jnc	00101$
                                    889 ;	free result
      00A159                        890 00105$:
      00A159 90 0B E3         [24]  891 	mov	dptr,#_unregister_code16_code_10000_603
      00A15C 12 6D E3         [24]  892 	lcall	_ak820_outline_0018
      00A15F 70 05            [24]  893 	jnz	00102$
      00A161                        894 00101$:
                                    895 ;	quantum/quantum.c:165: unregister_mods(mods);
      00A161 8D 82            [24]  896 	mov	dpl, r5
      00A163 02 76 24         [24]  897 	ljmp	_unregister_mods
      00A166                        898 00102$:
                                    899 ;	quantum/quantum.c:167: unregister_weak_mods(mods);
      00A166 8D 82            [24]  900 	mov	dpl, r5
                                    901 ;	quantum/quantum.c:178: }
      00A168 02 76 4C         [24]  902 	ljmp	_unregister_weak_mods
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'tap_code16_delay'
                                    905 ;------------------------------------------------------------
                                    906 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    907 ;code          Allocated with name '_tap_code16_delay_code_10000_608'
                                    908 ;i             Allocated with name '_tap_code16_delay_i_20000_610'
                                    909 ;i             Allocated with name '_tap_code16_delay_i_50000_613'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/quantum.c:185: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function pre_process_record_kb
                                    914 ;	-----------------------------------------
      00A16B                        915 _pre_process_record_kb:
      00A16B 12 43 EA         [24]  916 	lcall	_ak820_outline_0010
      00A16E 90 0B E8         [24]  917 	mov	dptr,#_pre_process_record_kb_keycode_10000_617
      00A171 12 43 E5         [24]  918 	lcall	_ak820_outline_0007
                                    919 ;	quantum/quantum.c:202: return pre_process_record_user(keycode, record);
      00A174 90 0B E8         [24]  920 	mov	dptr,#_pre_process_record_kb_keycode_10000_617
      00A177 12 43 C5         [24]  921 	lcall	_ak820_outline_0000
      00A17A 90 0B E5         [24]  922 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A17D E0               [24]  923 	movx	a,@dptr
      00A17E FB               [12]  924 	mov	r3,a
      00A17F A3               [24]  925 	inc	dptr
      00A180 12 43 DF         [24]  926 	lcall	_ak820_outline_0006
      00A183 90 0B EA         [24]  927 	mov	dptr,#_pre_process_record_user_PARM_2
      00A186 12 99 F3         [24]  928 	lcall	_ak820_outline_0008
      00A189 12 43 D3         [24]  929 	lcall	_ak820_outline_0002
                                    930 ;	quantum/quantum.c:203: }
      00A18C 02 A1 8F         [24]  931 	ljmp	_pre_process_record_user
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'pre_process_record_user'
                                    934 ;------------------------------------------------------------
                                    935 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    936 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_619'
                                    937 ;------------------------------------------------------------
                                    938 ;	quantum/quantum.c:205: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function pre_process_record_user
                                    941 ;	-----------------------------------------
      00A18F                        942 _pre_process_record_user:
                                    943 ;	quantum/quantum.c:206: return true;
      00A18F 75 82 01         [24]  944 	mov	dpl, #0x01
                                    945 ;	quantum/quantum.c:207: }
      00A192 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'process_action_kb'
                                    949 ;------------------------------------------------------------
                                    950 ;record        Allocated with name '_process_action_kb_record_10000_621'
                                    951 ;------------------------------------------------------------
                                    952 ;	quantum/quantum.c:209: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    953 ;	-----------------------------------------
                                    954 ;	 function process_action_kb
                                    955 ;	-----------------------------------------
      00A193                        956 _process_action_kb:
                                    957 ;	quantum/quantum.c:210: return true;
      00A193 75 82 01         [24]  958 	mov	dpl, #0x01
                                    959 ;	quantum/quantum.c:211: }
      00A196 22               [24]  960 	ret
                                    961 ;------------------------------------------------------------
                                    962 ;Allocation info for local variables in function 'process_record_kb'
                                    963 ;------------------------------------------------------------
                                    964 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    965 ;keycode       Allocated with name '_process_record_kb_keycode_10000_623'
                                    966 ;------------------------------------------------------------
                                    967 ;	quantum/quantum.c:213: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function process_record_kb
                                    970 ;	-----------------------------------------
      00A197                        971 _process_record_kb:
      00A197 12 43 EA         [24]  972 	lcall	_ak820_outline_0010
      00A19A 90 0B F0         [24]  973 	mov	dptr,#_process_record_kb_keycode_10000_623
      00A19D 12 43 E5         [24]  974 	lcall	_ak820_outline_0007
                                    975 ;	quantum/quantum.c:214: return process_record_user(keycode, record);
      00A1A0 90 0B F0         [24]  976 	mov	dptr,#_process_record_kb_keycode_10000_623
      00A1A3 12 43 C5         [24]  977 	lcall	_ak820_outline_0000
      00A1A6 90 0B ED         [24]  978 	mov	dptr,#_process_record_kb_PARM_2
      00A1A9 E0               [24]  979 	movx	a,@dptr
      00A1AA FB               [12]  980 	mov	r3,a
      00A1AB A3               [24]  981 	inc	dptr
      00A1AC 12 43 DF         [24]  982 	lcall	_ak820_outline_0006
      00A1AF 90 0B F2         [24]  983 	mov	dptr,#_process_record_user_PARM_2
      00A1B2 12 99 F3         [24]  984 	lcall	_ak820_outline_0008
      00A1B5 12 43 D3         [24]  985 	lcall	_ak820_outline_0002
                                    986 ;	quantum/quantum.c:215: }
      00A1B8 02 A1 BB         [24]  987 	ljmp	_process_record_user
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'process_record_user'
                                    990 ;------------------------------------------------------------
                                    991 ;record        Allocated with name '_process_record_user_PARM_2'
                                    992 ;keycode       Allocated with name '_process_record_user_keycode_10000_625'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:217: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function process_record_user
                                    997 ;	-----------------------------------------
      00A1BB                        998 _process_record_user:
                                    999 ;	quantum/quantum.c:218: return true;
      00A1BB 75 82 01         [24] 1000 	mov	dpl, #0x01
                                   1001 ;	quantum/quantum.c:219: }
      00A1BE 22               [24] 1002 	ret
                                   1003 ;------------------------------------------------------------
                                   1004 ;Allocation info for local variables in function 'post_process_record_kb'
                                   1005 ;------------------------------------------------------------
                                   1006 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                   1007 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_627'
                                   1008 ;------------------------------------------------------------
                                   1009 ;	quantum/quantum.c:221: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                   1010 ;	-----------------------------------------
                                   1011 ;	 function post_process_record_kb
                                   1012 ;	-----------------------------------------
      00A1BF                       1013 _post_process_record_kb:
      00A1BF 12 43 EA         [24] 1014 	lcall	_ak820_outline_0010
      00A1C2 90 0B F8         [24] 1015 	mov	dptr,#_post_process_record_kb_keycode_10000_627
      00A1C5 12 43 E5         [24] 1016 	lcall	_ak820_outline_0007
                                   1017 ;	quantum/quantum.c:222: post_process_record_user(keycode, record);
      00A1C8 90 0B F8         [24] 1018 	mov	dptr,#_post_process_record_kb_keycode_10000_627
      00A1CB 12 43 C5         [24] 1019 	lcall	_ak820_outline_0000
      00A1CE 90 0B F5         [24] 1020 	mov	dptr,#_post_process_record_kb_PARM_2
      00A1D1 E0               [24] 1021 	movx	a,@dptr
      00A1D2 FB               [12] 1022 	mov	r3,a
      00A1D3 A3               [24] 1023 	inc	dptr
      00A1D4 12 43 DF         [24] 1024 	lcall	_ak820_outline_0006
      00A1D7 90 0B FA         [24] 1025 	mov	dptr,#_post_process_record_user_PARM_2
      00A1DA 12 99 F3         [24] 1026 	lcall	_ak820_outline_0008
      00A1DD 12 43 D3         [24] 1027 	lcall	_ak820_outline_0002
                                   1028 ;	quantum/quantum.c:223: }
      00A1E0 02 A1 E3         [24] 1029 	ljmp	_post_process_record_user
                                   1030 ;------------------------------------------------------------
                                   1031 ;Allocation info for local variables in function 'post_process_record_user'
                                   1032 ;------------------------------------------------------------
                                   1033 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                   1034 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_629'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	quantum/quantum.c:225: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function post_process_record_user
                                   1039 ;	-----------------------------------------
      00A1E3                       1040 _post_process_record_user:
      00A1E3 22               [24] 1041 	ret
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 'shutdown_quantum'
                                   1044 ;------------------------------------------------------------
                                   1045 ;i             Allocated with name '_shutdown_quantum_i_30000_635'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/quantum.c:227: void shutdown_quantum(void) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function shutdown_quantum
                                   1050 ;	-----------------------------------------
      00A1E4                       1051 _shutdown_quantum:
                                   1052 ;	quantum/quantum.c:228: clear_keyboard();
      00A1E4 12 76 60         [24] 1053 	lcall	_clear_keyboard
                                   1054 ;	quantum/quantum.c:243: shutdown_user();
      00A1E7 12 A5 1D         [24] 1055 	lcall	_shutdown_user
                                   1056 ;	quantum/quantum.c:244: wait_ms(250);
      00A1EA 7F FA            [12] 1057 	mov	r7,#0xfa
      00A1EC                       1058 00106$:
      00A1EC EF               [12] 1059 	mov	a,r7
      00A1ED 60 09            [24] 1060 	jz	00108$
      00A1EF 90 00 01         [24] 1061 	mov	dptr,#0x0001
      00A1F2 12 58 B8         [24] 1062 	lcall	_mDelaymS
      00A1F5 1F               [12] 1063 	dec	r7
      00A1F6 80 F4            [24] 1064 	sjmp	00106$
      00A1F8                       1065 00108$:
                                   1066 ;	quantum/quantum.c:249: }
      00A1F8 22               [24] 1067 	ret
                                   1068 ;------------------------------------------------------------
                                   1069 ;Allocation info for local variables in function 'reset_keyboard'
                                   1070 ;------------------------------------------------------------
                                   1071 ;	quantum/quantum.c:251: void reset_keyboard(void) {
                                   1072 ;	-----------------------------------------
                                   1073 ;	 function reset_keyboard
                                   1074 ;	-----------------------------------------
      00A1F9                       1075 _reset_keyboard:
                                   1076 ;	quantum/quantum.c:252: shutdown_quantum();
      00A1F9 12 A1 E4         [24] 1077 	lcall	_shutdown_quantum
                                   1078 ;	quantum/quantum.c:253: bootloader_jump();
                                   1079 ;	quantum/quantum.c:254: }
      00A1FC 02 34 89         [24] 1080 	ljmp	_bootloader_jump
                                   1081 ;------------------------------------------------------------
                                   1082 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1083 ;------------------------------------------------------------
                                   1084 ;	quantum/quantum.c:256: void soft_reset_keyboard(void) {
                                   1085 ;	-----------------------------------------
                                   1086 ;	 function soft_reset_keyboard
                                   1087 ;	-----------------------------------------
      00A1FF                       1088 _soft_reset_keyboard:
                                   1089 ;	quantum/quantum.c:257: shutdown_quantum();
      00A1FF 12 A1 E4         [24] 1090 	lcall	_shutdown_quantum
                                   1091 ;	quantum/quantum.c:258: mcu_reset();
                                   1092 ;	quantum/quantum.c:259: }
      00A202 02 34 7C         [24] 1093 	ljmp	_mcu_reset
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'get_record_keycode'
                                   1096 ;------------------------------------------------------------
                                   1097 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1098 ;record        Allocated with name '_get_record_keycode_record_10000_641'
                                   1099 ;------------------------------------------------------------
                                   1100 ;	quantum/quantum.c:262: uint16_t get_record_keycode(keyrecord_t *record, bool update_layer_cache) {
                                   1101 ;	-----------------------------------------
                                   1102 ;	 function get_record_keycode
                                   1103 ;	-----------------------------------------
      00A205                       1104 _get_record_keycode:
      00A205 12 43 D8         [24] 1105 	lcall	_ak820_outline_0004
      00A208 90 0B FE         [24] 1106 	mov	dptr,#_get_record_keycode_record_10000_641
      00A20B 12 43 CB         [24] 1107 	lcall	_ak820_outline_0001
                                   1108 ;	quantum/quantum.c:264: if (record->keycode) {
      00A20E 90 0B FE         [24] 1109 	mov	dptr,#_get_record_keycode_record_10000_641
      00A211 E0               [24] 1110 	movx	a,@dptr
      00A212 FD               [12] 1111 	mov	r5,a
      00A213 A3               [24] 1112 	inc	dptr
      00A214 12 43 C5         [24] 1113 	lcall	_ak820_outline_0000
      00A217 12 76 C1         [24] 1114 	lcall	_ak820_outline_0052
      00A21A 12 BE 14         [24] 1115 	lcall	__gptrget
      00A21D FB               [12] 1116 	mov	r3,a
      00A21E A3               [24] 1117 	inc	dptr
      00A21F 12 BE 14         [24] 1118 	lcall	__gptrget
      00A222 FC               [12] 1119 	mov	r4,a
      00A223 4B               [12] 1120 	orl	a,r3
      00A224 60 04            [24] 1121 	jz	00102$
                                   1122 ;	quantum/quantum.c:265: return record->keycode;
      00A226 12 43 F9         [24] 1123 	lcall	_ak820_outline_0014
      00A229 22               [24] 1124 	ret
      00A22A                       1125 00102$:
                                   1126 ;	quantum/quantum.c:268: return get_event_keycode(record->event, update_layer_cache);
      00A22A 90 0B FD         [24] 1127 	mov	dptr,#_get_record_keycode_PARM_2
      00A22D E0               [24] 1128 	movx	a,@dptr
      00A22E FC               [12] 1129 	mov	r4,a
      00A22F 90 0D B3         [24] 1130 	mov	dptr,#___memcpy_PARM_2
      00A232 ED               [12] 1131 	mov	a,r5
      00A233 12 43 CB         [24] 1132 	lcall	_ak820_outline_0001
      00A236 90 0D B6         [24] 1133 	mov	dptr,#___memcpy_PARM_3
      00A239 74 06            [12] 1134 	mov	a,#0x06
      00A23B 12 4E 60         [24] 1135 	lcall	_ak820_outline_0003
      00A23E 90 0C 01         [24] 1136 	mov	dptr,#_get_event_keycode_PARM_1
      00A241 F5 F0            [12] 1137 	mov	b,a
      00A243 C0 04            [24] 1138 	push	ar4
      00A245 12 BD 3B         [24] 1139 	lcall	___memcpy
      00A248 D0 04            [24] 1140 	pop	ar4
      00A24A 8C 82            [24] 1141 	mov	dpl, r4
                                   1142 ;	quantum/quantum.c:269: }
      00A24C 02 A2 4F         [24] 1143 	ljmp	_get_event_keycode
                                   1144 ;------------------------------------------------------------
                                   1145 ;Allocation info for local variables in function 'get_event_keycode'
                                   1146 ;------------------------------------------------------------
                                   1147 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1148 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_645'
                                   1149 ;layer         Allocated with name '_get_event_keycode_layer_30000_648'
                                   1150 ;------------------------------------------------------------
                                   1151 ;	quantum/quantum.c:277: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1152 ;	-----------------------------------------
                                   1153 ;	 function get_event_keycode
                                   1154 ;	-----------------------------------------
      00A24F                       1155 _get_event_keycode:
      00A24F E5 82            [12] 1156 	mov	a,dpl
      00A251 90 0C 07         [24] 1157 	mov	dptr,#_get_event_keycode_update_layer_cache_10000_645
      00A254 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/quantum.c:280: if (!disable_action_cache) {
      00A255 90 0D D2         [24] 1160 	mov	dptr,#_disable_action_cache
      00A258 E0               [24] 1161 	movx	a,@dptr
      00A259 70 59            [24] 1162 	jnz	00105$
                                   1163 ;	quantum/quantum.c:283: if (event.pressed && update_layer_cache) {
      00A25B 90 0C 06         [24] 1164 	mov	dptr,#(_get_event_keycode_PARM_1 + 0x0005)
      00A25E E0               [24] 1165 	movx	a,@dptr
      00A25F 60 3C            [24] 1166 	jz	00102$
      00A261 90 0C 07         [24] 1167 	mov	dptr,#_get_event_keycode_update_layer_cache_10000_645
      00A264 E0               [24] 1168 	movx	a,@dptr
      00A265 60 36            [24] 1169 	jz	00102$
                                   1170 ;	quantum/quantum.c:284: layer = layer_switch_get_layer(event.key);
      00A267 12 A5 1E         [24] 1171 	lcall	_ak820_outline_0019
      00A26A 12 4E 60         [24] 1172 	lcall	_ak820_outline_0003
      00A26D 12 A5 36         [24] 1173 	lcall	_ak820_outline_0087
      00A270 12 4E 60         [24] 1174 	lcall	_ak820_outline_0003
      00A273 90 09 5B         [24] 1175 	mov	dptr,#_layer_switch_get_layer_PARM_1
      00A276 F5 F0            [12] 1176 	mov	b,a
      00A278 12 BD 3B         [24] 1177 	lcall	___memcpy
      00A27B 12 7A D9         [24] 1178 	lcall	_layer_switch_get_layer
      00A27E AF 82            [24] 1179 	mov	r7, dpl
                                   1180 ;	quantum/quantum.c:285: update_source_layers_cache(event.key, layer);
      00A280 12 A5 1E         [24] 1181 	lcall	_ak820_outline_0019
      00A283 12 4E 60         [24] 1182 	lcall	_ak820_outline_0003
      00A286 12 A5 36         [24] 1183 	lcall	_ak820_outline_0087
      00A289 12 4E 60         [24] 1184 	lcall	_ak820_outline_0003
      00A28C 90 09 53         [24] 1185 	mov	dptr,#_update_source_layers_cache_PARM_1
      00A28F F5 F0            [12] 1186 	mov	b,a
      00A291 C0 07            [24] 1187 	push	ar7
      00A293 12 BD 3B         [24] 1188 	lcall	___memcpy
      00A296 D0 07            [24] 1189 	pop	ar7
      00A298 8F 82            [24] 1190 	mov	dpl, r7
      00A29A 12 79 A5         [24] 1191 	lcall	_update_source_layers_cache
      00A29D                       1192 00102$:
                                   1193 ;	quantum/quantum.c:288: return read_source_keycode_cache(event.key);
      00A29D 12 A5 1E         [24] 1194 	lcall	_ak820_outline_0019
      00A2A0 12 4E 60         [24] 1195 	lcall	_ak820_outline_0003
      00A2A3 12 A5 36         [24] 1196 	lcall	_ak820_outline_0087
      00A2A6 12 4E 60         [24] 1197 	lcall	_ak820_outline_0003
      00A2A9 90 09 56         [24] 1198 	mov	dptr,#_read_source_keycode_cache_PARM_1
      00A2AC F5 F0            [12] 1199 	mov	b,a
      00A2AE 12 BD 3B         [24] 1200 	lcall	___memcpy
      00A2B1 02 7A 06         [24] 1201 	ljmp	_read_source_keycode_cache
      00A2B4                       1202 00105$:
                                   1203 ;	quantum/quantum.c:300: return keymap_key_to_keycode(layer_switch_get_layer(event.key), event.key);
      00A2B4 12 A5 1E         [24] 1204 	lcall	_ak820_outline_0019
      00A2B7 12 4E 60         [24] 1205 	lcall	_ak820_outline_0003
      00A2BA 12 A5 36         [24] 1206 	lcall	_ak820_outline_0087
      00A2BD 12 4E 60         [24] 1207 	lcall	_ak820_outline_0003
      00A2C0 90 09 5B         [24] 1208 	mov	dptr,#_layer_switch_get_layer_PARM_1
      00A2C3 F5 F0            [12] 1209 	mov	b,a
      00A2C5 12 BD 3B         [24] 1210 	lcall	___memcpy
      00A2C8 12 7A D9         [24] 1211 	lcall	_layer_switch_get_layer
      00A2CB AF 82            [24] 1212 	mov	r7, dpl
      00A2CD 12 A5 1E         [24] 1213 	lcall	_ak820_outline_0019
      00A2D0 12 4E 60         [24] 1214 	lcall	_ak820_outline_0003
      00A2D3 12 A5 36         [24] 1215 	lcall	_ak820_outline_0087
      00A2D6 12 4E 60         [24] 1216 	lcall	_ak820_outline_0003
      00A2D9 90 0B 9E         [24] 1217 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      00A2DC F5 F0            [12] 1218 	mov	b,a
      00A2DE C0 07            [24] 1219 	push	ar7
      00A2E0 12 BD 3B         [24] 1220 	lcall	___memcpy
      00A2E3 D0 07            [24] 1221 	pop	ar7
      00A2E5 8F 82            [24] 1222 	mov	dpl, r7
                                   1223 ;	quantum/quantum.c:301: }
      00A2E7 02 98 32         [24] 1224 	ljmp	_keymap_key_to_keycode
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'pre_process_record_quantum'
                                   1227 ;------------------------------------------------------------
                                   1228 ;record        Allocated with name '_pre_process_record_quantum_record_10000_651'
                                   1229 ;keycode       Allocated with name '_pre_process_record_quantum_keycode_10000_652'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/quantum.c:304: bool pre_process_record_quantum(keyrecord_t *record) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function pre_process_record_quantum
                                   1234 ;	-----------------------------------------
      00A2EA                       1235 _pre_process_record_quantum:
      00A2EA 12 43 D8         [24] 1236 	lcall	_ak820_outline_0004
      00A2ED 90 0C 08         [24] 1237 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A2F0 12 43 CB         [24] 1238 	lcall	_ak820_outline_0001
                                   1239 ;	quantum/quantum.c:305: uint16_t keycode = get_record_keycode(record, true);
      00A2F3 90 0C 08         [24] 1240 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A2F6 E0               [24] 1241 	movx	a,@dptr
      00A2F7 FD               [12] 1242 	mov	r5,a
      00A2F8 A3               [24] 1243 	inc	dptr
      00A2F9 12 43 C5         [24] 1244 	lcall	_ak820_outline_0000
      00A2FC 90 0B FD         [24] 1245 	mov	dptr,#_get_record_keycode_PARM_2
      00A2FF 74 01            [12] 1246 	mov	a,#0x01
      00A301 F0               [24] 1247 	movx	@dptr,a
      00A302 12 4E 65         [24] 1248 	lcall	_ak820_outline_0005
      00A305 12 A2 05         [24] 1249 	lcall	_get_record_keycode
      00A308 12 44 1D         [24] 1250 	lcall	_ak820_outline_0027
                                   1251 ;	quantum/quantum.c:307: record->keycode = keycode;
      00A30B 90 0C 08         [24] 1252 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A30E E0               [24] 1253 	movx	a,@dptr
      00A30F FB               [12] 1254 	mov	r3,a
      00A310 A3               [24] 1255 	inc	dptr
      00A311 12 43 DF         [24] 1256 	lcall	_ak820_outline_0006
      00A314 74 07            [12] 1257 	mov	a,#0x07
      00A316 2B               [12] 1258 	add	a, r3
      00A317 F8               [12] 1259 	mov	r0,a
      00A318 E4               [12] 1260 	clr	a
      00A319 3C               [12] 1261 	addc	a, r4
      00A31A F9               [12] 1262 	mov	r1,a
      00A31B 8D 02            [24] 1263 	mov	ar2,r5
      00A31D 12 A5 2F         [24] 1264 	lcall	_ak820_outline_0028
      00A320 EE               [12] 1265 	mov	a,r6
      00A321 12 BD D9         [24] 1266 	lcall	__gptrput
      00A324 A3               [24] 1267 	inc	dptr
      00A325 EF               [12] 1268 	mov	a,r7
      00A326 12 BD D9         [24] 1269 	lcall	__gptrput
                                   1270 ;	quantum/quantum.c:309: return pre_process_record_kb(keycode, record) &&
      00A329 90 0B E5         [24] 1271 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A32C 12 99 F3         [24] 1272 	lcall	_ak820_outline_0008
      00A32F 12 43 D3         [24] 1273 	lcall	_ak820_outline_0002
      00A332 12 A1 6B         [24] 1274 	lcall	_pre_process_record_kb
      00A335 E5 82            [12] 1275 	mov	a, dpl
      00A337 60 10            [24] 1276 	jz	00103$
                                   1277 ;	quantum/quantum.c:312: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A339 90 0C 08         [24] 1278 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A33C 12 43 C5         [24] 1279 	lcall	_ak820_outline_0000
      00A33F 12 43 D3         [24] 1280 	lcall	_ak820_outline_0002
      00A342 12 36 FA         [24] 1281 	lcall	_ak820_combo_process
      00A345 E5 82            [12] 1282 	mov	a, dpl
      00A347 70 04            [24] 1283 	jnz	00104$
                                   1284 ;	quantum/quantum.c:317: true;
      00A349                       1285 00103$:
                                   1286 ;	assignBit
      00A349 C2 1E            [12] 1287 	clr	_pre_process_record_quantum_sloc0_1_0
      00A34B 80 02            [24] 1288 	sjmp	00105$
      00A34D                       1289 00104$:
                                   1290 ;	assignBit
      00A34D D2 1E            [12] 1291 	setb	_pre_process_record_quantum_sloc0_1_0
      00A34F                       1292 00105$:
      00A34F A2 1E            [12] 1293 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A351 12 44 91         [24] 1294 	lcall	_ak820_outline_0146
                                   1295 ;	quantum/quantum.c:318: }
      00A354 22               [24] 1296 	ret
                                   1297 ;------------------------------------------------------------
                                   1298 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1299 ;------------------------------------------------------------
                                   1300 ;record        Allocated with name '_post_process_record_quantum_record_10000_653'
                                   1301 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_654'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:321: void post_process_record_quantum(keyrecord_t *record) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function post_process_record_quantum
                                   1306 ;	-----------------------------------------
      00A355                       1307 _post_process_record_quantum:
      00A355 12 43 D8         [24] 1308 	lcall	_ak820_outline_0004
      00A358 90 0C 0B         [24] 1309 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A35B 12 43 CB         [24] 1310 	lcall	_ak820_outline_0001
                                   1311 ;	quantum/quantum.c:322: uint16_t keycode = get_record_keycode(record, false);
      00A35E 90 0C 0B         [24] 1312 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A361 E0               [24] 1313 	movx	a,@dptr
      00A362 FD               [12] 1314 	mov	r5,a
      00A363 A3               [24] 1315 	inc	dptr
      00A364 12 43 C5         [24] 1316 	lcall	_ak820_outline_0000
      00A367 90 0B FD         [24] 1317 	mov	dptr,#_get_record_keycode_PARM_2
      00A36A E4               [12] 1318 	clr	a
      00A36B F0               [24] 1319 	movx	@dptr,a
      00A36C 12 4E 65         [24] 1320 	lcall	_ak820_outline_0005
      00A36F 12 A2 05         [24] 1321 	lcall	_get_record_keycode
      00A372 12 44 1D         [24] 1322 	lcall	_ak820_outline_0027
                                   1323 ;	quantum/quantum.c:323: post_process_record_kb(keycode, record);
      00A375 90 0C 0B         [24] 1324 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A378 E0               [24] 1325 	movx	a,@dptr
      00A379 FB               [12] 1326 	mov	r3,a
      00A37A A3               [24] 1327 	inc	dptr
      00A37B 12 43 DF         [24] 1328 	lcall	_ak820_outline_0006
      00A37E 90 0B F5         [24] 1329 	mov	dptr,#_post_process_record_kb_PARM_2
      00A381 12 99 F3         [24] 1330 	lcall	_ak820_outline_0008
      00A384 12 43 D3         [24] 1331 	lcall	_ak820_outline_0002
                                   1332 ;	quantum/quantum.c:324: }
      00A387 02 A1 BF         [24] 1333 	ljmp	_post_process_record_kb
                                   1334 ;------------------------------------------------------------
                                   1335 ;Allocation info for local variables in function 'process_record_quantum'
                                   1336 ;------------------------------------------------------------
                                   1337 ;record        Allocated with name '_process_record_quantum_record_10000_655'
                                   1338 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_656'
                                   1339 ;------------------------------------------------------------
                                   1340 ;	quantum/quantum.c:326: bool process_record_quantum(keyrecord_t *record) {
                                   1341 ;	-----------------------------------------
                                   1342 ;	 function process_record_quantum
                                   1343 ;	-----------------------------------------
      00A38A                       1344 _process_record_quantum:
      00A38A 12 43 D8         [24] 1345 	lcall	_ak820_outline_0004
      00A38D 90 0C 0E         [24] 1346 	mov	dptr,#_process_record_quantum_record_10000_655
      00A390 12 43 CB         [24] 1347 	lcall	_ak820_outline_0001
                                   1348 ;	quantum/quantum.c:328: uint16_t keycode = get_record_keycode(record, false);
      00A393 90 0C 0E         [24] 1349 	mov	dptr,#_process_record_quantum_record_10000_655
      00A396 E0               [24] 1350 	movx	a,@dptr
      00A397 FD               [12] 1351 	mov	r5,a
      00A398 A3               [24] 1352 	inc	dptr
      00A399 12 43 C5         [24] 1353 	lcall	_ak820_outline_0000
      00A39C 90 0B FD         [24] 1354 	mov	dptr,#_get_record_keycode_PARM_2
      00A39F E4               [12] 1355 	clr	a
      00A3A0 F0               [24] 1356 	movx	@dptr,a
      00A3A1 12 4E 65         [24] 1357 	lcall	_ak820_outline_0005
      00A3A4 12 A2 05         [24] 1358 	lcall	_get_record_keycode
      00A3A7 12 44 1D         [24] 1359 	lcall	_ak820_outline_0027
                                   1360 ;	quantum/quantum.c:332: return process_record_quantum_helper(keycode, record);
      00A3AA 90 0C 0E         [24] 1361 	mov	dptr,#_process_record_quantum_record_10000_655
      00A3AD E0               [24] 1362 	movx	a,@dptr
      00A3AE FB               [12] 1363 	mov	r3,a
      00A3AF A3               [24] 1364 	inc	dptr
      00A3B0 12 43 DF         [24] 1365 	lcall	_ak820_outline_0006
      00A3B3 90 0C 11         [24] 1366 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A3B6 12 99 F3         [24] 1367 	lcall	_ak820_outline_0008
      00A3B9 12 43 D3         [24] 1368 	lcall	_ak820_outline_0002
                                   1369 ;	quantum/quantum.c:333: }
      00A3BC 02 A3 BF         [24] 1370 	ljmp	_process_record_quantum_helper
                                   1371 ;------------------------------------------------------------
                                   1372 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1373 ;------------------------------------------------------------
                                   1374 ;record        Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1375 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_657'
                                   1376 ;------------------------------------------------------------
                                   1377 ;	quantum/quantum.c:337: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record) {
                                   1378 ;	-----------------------------------------
                                   1379 ;	 function process_record_quantum_helper
                                   1380 ;	-----------------------------------------
      00A3BF                       1381 _process_record_quantum_helper:
      00A3BF 12 43 EA         [24] 1382 	lcall	_ak820_outline_0010
      00A3C2 90 0C 14         [24] 1383 	mov	dptr,#_process_record_quantum_helper_keycode_10000_657
      00A3C5 12 43 E5         [24] 1384 	lcall	_ak820_outline_0007
                                   1385 ;	quantum/quantum.c:382: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A3C8 90 0C 14         [24] 1386 	mov	dptr,#_process_record_quantum_helper_keycode_10000_657
      00A3CB 12 43 C5         [24] 1387 	lcall	_ak820_outline_0000
      00A3CE 12 A5 28         [24] 1388 	lcall	_ak820_outline_0022
      00A3D1 12 43 DF         [24] 1389 	lcall	_ak820_outline_0006
      00A3D4 90 0B C8         [24] 1390 	mov	dptr,#_process_last_key_PARM_2
      00A3D7 12 99 F3         [24] 1391 	lcall	_ak820_outline_0008
      00A3DA 12 43 D3         [24] 1392 	lcall	_ak820_outline_0002
      00A3DD C0 07            [24] 1393 	push	ar7
      00A3DF C0 06            [24] 1394 	push	ar6
      00A3E1 12 9D 7A         [24] 1395 	lcall	_process_last_key
      00A3E4 E5 82            [12] 1396 	mov	a, dpl
      00A3E6 D0 06            [24] 1397 	pop	ar6
      00A3E8 D0 07            [24] 1398 	pop	ar7
      00A3EA 70 03            [24] 1399 	jnz	00196$
      00A3EC 02 A4 CA         [24] 1400 	ljmp	00101$
      00A3EF                       1401 00196$:
      00A3EF 12 A5 28         [24] 1402 	lcall	_ak820_outline_0022
      00A3F2 12 43 DF         [24] 1403 	lcall	_ak820_outline_0006
      00A3F5 90 0B CE         [24] 1404 	mov	dptr,#_process_repeat_key_PARM_2
      00A3F8 12 99 F3         [24] 1405 	lcall	_ak820_outline_0008
      00A3FB 12 43 D3         [24] 1406 	lcall	_ak820_outline_0002
      00A3FE C0 07            [24] 1407 	push	ar7
      00A400 C0 06            [24] 1408 	push	ar6
      00A402 12 9D FF         [24] 1409 	lcall	_process_repeat_key
      00A405 E5 82            [12] 1410 	mov	a, dpl
      00A407 D0 06            [24] 1411 	pop	ar6
      00A409 D0 07            [24] 1412 	pop	ar7
      00A40B 70 03            [24] 1413 	jnz	00197$
      00A40D 02 A4 CA         [24] 1414 	ljmp	00101$
      00A410                       1415 00197$:
                                   1416 ;	quantum/quantum.c:391: process_record_via(keycode, record) &&
      00A410 12 A5 28         [24] 1417 	lcall	_ak820_outline_0022
      00A413 12 43 DF         [24] 1418 	lcall	_ak820_outline_0006
      00A416 90 0C 5C         [24] 1419 	mov	dptr,#_process_record_via_PARM_2
      00A419 12 99 F3         [24] 1420 	lcall	_ak820_outline_0008
      00A41C 12 43 D3         [24] 1421 	lcall	_ak820_outline_0002
      00A41F C0 07            [24] 1422 	push	ar7
      00A421 C0 06            [24] 1423 	push	ar6
      00A423 12 AA 47         [24] 1424 	lcall	_process_record_via
      00A426 E5 82            [12] 1425 	mov	a, dpl
      00A428 D0 06            [24] 1426 	pop	ar6
      00A42A D0 07            [24] 1427 	pop	ar7
      00A42C 70 03            [24] 1428 	jnz	00198$
      00A42E 02 A4 CA         [24] 1429 	ljmp	00101$
      00A431                       1430 00198$:
                                   1431 ;	quantum/quantum.c:401: process_record_kb(keycode, record) &&
      00A431 12 A5 28         [24] 1432 	lcall	_ak820_outline_0022
      00A434 12 43 DF         [24] 1433 	lcall	_ak820_outline_0006
      00A437 90 0B ED         [24] 1434 	mov	dptr,#_process_record_kb_PARM_2
      00A43A 12 99 F3         [24] 1435 	lcall	_ak820_outline_0008
      00A43D 12 43 D3         [24] 1436 	lcall	_ak820_outline_0002
      00A440 C0 07            [24] 1437 	push	ar7
      00A442 C0 06            [24] 1438 	push	ar6
      00A444 12 A1 97         [24] 1439 	lcall	_process_record_kb
      00A447 E5 82            [12] 1440 	mov	a, dpl
      00A449 D0 06            [24] 1441 	pop	ar6
      00A44B D0 07            [24] 1442 	pop	ar7
      00A44D 70 03            [24] 1443 	jnz	00199$
      00A44F 02 A4 CA         [24] 1444 	ljmp	00101$
      00A452                       1445 00199$:
                                   1446 ;	quantum/quantum.c:424: process_caps_word(keycode, record) &&
      00A452 12 A5 28         [24] 1447 	lcall	_ak820_outline_0022
      00A455 12 43 DF         [24] 1448 	lcall	_ak820_outline_0006
      00A458 90 0B B0         [24] 1449 	mov	dptr,#_process_caps_word_PARM_2
      00A45B 12 99 F3         [24] 1450 	lcall	_ak820_outline_0008
      00A45E 12 43 D3         [24] 1451 	lcall	_ak820_outline_0002
      00A461 C0 07            [24] 1452 	push	ar7
      00A463 C0 06            [24] 1453 	push	ar6
      00A465 12 9A 61         [24] 1454 	lcall	_process_caps_word
      00A468 E5 82            [12] 1455 	mov	a, dpl
      00A46A D0 06            [24] 1456 	pop	ar6
      00A46C D0 07            [24] 1457 	pop	ar7
      00A46E 60 5A            [24] 1458 	jz	00101$
                                   1459 ;	quantum/quantum.c:451: process_grave_esc(keycode, record) &&
      00A470 12 A5 28         [24] 1460 	lcall	_ak820_outline_0022
      00A473 12 43 DF         [24] 1461 	lcall	_ak820_outline_0006
      00A476 90 0B B5         [24] 1462 	mov	dptr,#_process_grave_esc_PARM_2
      00A479 12 99 F3         [24] 1463 	lcall	_ak820_outline_0008
      00A47C 12 43 D3         [24] 1464 	lcall	_ak820_outline_0002
      00A47F C0 07            [24] 1465 	push	ar7
      00A481 C0 06            [24] 1466 	push	ar6
      00A483 12 9B 87         [24] 1467 	lcall	_process_grave_esc
      00A486 E5 82            [12] 1468 	mov	a, dpl
      00A488 D0 06            [24] 1469 	pop	ar6
      00A48A D0 07            [24] 1470 	pop	ar7
      00A48C 60 3C            [24] 1471 	jz	00101$
                                   1472 ;	quantum/quantum.c:454: process_rgb(keycode, record) &&
      00A48E 12 A5 28         [24] 1473 	lcall	_ak820_outline_0022
      00A491 12 43 DF         [24] 1474 	lcall	_ak820_outline_0006
      00A494 90 0B D3         [24] 1475 	mov	dptr,#_process_rgb_PARM_2
      00A497 12 99 F3         [24] 1476 	lcall	_ak820_outline_0008
      00A49A 12 43 D3         [24] 1477 	lcall	_ak820_outline_0002
      00A49D C0 07            [24] 1478 	push	ar7
      00A49F C0 06            [24] 1479 	push	ar6
      00A4A1 12 9E 59         [24] 1480 	lcall	_process_rgb
      00A4A4 E5 82            [12] 1481 	mov	a, dpl
      00A4A6 D0 06            [24] 1482 	pop	ar6
      00A4A8 D0 07            [24] 1483 	pop	ar7
      00A4AA 60 1E            [24] 1484 	jz	00101$
                                   1485 ;	quantum/quantum.c:466: process_tri_layer(keycode, record) &&
      00A4AC 12 A5 28         [24] 1486 	lcall	_ak820_outline_0022
      00A4AF 12 43 DF         [24] 1487 	lcall	_ak820_outline_0006
      00A4B2 90 0B D9         [24] 1488 	mov	dptr,#_process_tri_layer_PARM_2
      00A4B5 12 99 F3         [24] 1489 	lcall	_ak820_outline_0008
      00A4B8 12 43 D3         [24] 1490 	lcall	_ak820_outline_0002
      00A4BB C0 07            [24] 1491 	push	ar7
      00A4BD C0 06            [24] 1492 	push	ar6
      00A4BF 12 9F 7D         [24] 1493 	lcall	_process_tri_layer
      00A4C2 E5 82            [12] 1494 	mov	a, dpl
      00A4C4 D0 06            [24] 1495 	pop	ar6
      00A4C6 D0 07            [24] 1496 	pop	ar7
      00A4C8 70 04            [24] 1497 	jnz	00102$
                                   1498 ;	quantum/quantum.c:468: true)) {
      00A4CA                       1499 00101$:
                                   1500 ;	quantum/quantum.c:469: return false;
      00A4CA 75 82 00         [24] 1501 	mov	dpl, #0x00
      00A4CD 22               [24] 1502 	ret
      00A4CE                       1503 00102$:
                                   1504 ;	quantum/quantum.c:472: if (record->event.pressed) {
      00A4CE 12 A5 28         [24] 1505 	lcall	_ak820_outline_0022
      00A4D1 12 43 DF         [24] 1506 	lcall	_ak820_outline_0006
      00A4D4 74 05            [12] 1507 	mov	a,#0x05
      00A4D6 2B               [12] 1508 	add	a, r3
      00A4D7 F8               [12] 1509 	mov	r0,a
      00A4D8 E4               [12] 1510 	clr	a
      00A4D9 3C               [12] 1511 	addc	a, r4
      00A4DA F9               [12] 1512 	mov	r1,a
      00A4DB 8D 02            [24] 1513 	mov	ar2,r5
      00A4DD 12 A5 2F         [24] 1514 	lcall	_ak820_outline_0028
      00A4E0 12 BE 14         [24] 1515 	lcall	__gptrget
      00A4E3 60 30            [24] 1516 	jz	00116$
                                   1517 ;	quantum/quantum.c:473: switch (keycode) {
      00A4E5 BE 00 05         [24] 1518 	cjne	r6,#0x00,00205$
      00A4E8 BF 7C 02         [24] 1519 	cjne	r7,#0x7c,00205$
      00A4EB 80 10            [24] 1520 	sjmp	00111$
      00A4ED                       1521 00205$:
      00A4ED BE 01 05         [24] 1522 	cjne	r6,#0x01,00206$
      00A4F0 BF 7C 02         [24] 1523 	cjne	r7,#0x7c,00206$
      00A4F3 80 0F            [24] 1524 	sjmp	00112$
      00A4F5                       1525 00206$:
                                   1526 ;	quantum/quantum.c:475: case QK_BOOTLOADER:
      00A4F5 BE 03 1D         [24] 1527 	cjne	r6,#0x03,00116$
      00A4F8 BF 7C 1A         [24] 1528 	cjne	r7,#0x7c,00116$
      00A4FB 80 0E            [24] 1529 	sjmp	00113$
      00A4FD                       1530 00111$:
                                   1531 ;	quantum/quantum.c:476: reset_keyboard();
      00A4FD 12 A1 F9         [24] 1532 	lcall	_reset_keyboard
                                   1533 ;	quantum/quantum.c:477: return false;
      00A500 75 82 00         [24] 1534 	mov	dpl, #0x00
                                   1535 ;	quantum/quantum.c:478: case QK_REBOOT:
      00A503 22               [24] 1536 	ret
      00A504                       1537 00112$:
                                   1538 ;	quantum/quantum.c:479: soft_reset_keyboard();
      00A504 12 A1 FF         [24] 1539 	lcall	_soft_reset_keyboard
                                   1540 ;	quantum/quantum.c:480: return false;
      00A507 75 82 00         [24] 1541 	mov	dpl, #0x00
                                   1542 ;	quantum/quantum.c:492: case QK_CLEAR_EEPROM:
      00A50A 22               [24] 1543 	ret
      00A50B                       1544 00113$:
                                   1545 ;	quantum/quantum.c:499: eeconfig_disable();
      00A50B 12 90 3F         [24] 1546 	lcall	_eeconfig_disable
                                   1547 ;	quantum/quantum.c:500: soft_reset_keyboard();
      00A50E 12 A1 FF         [24] 1548 	lcall	_soft_reset_keyboard
                                   1549 ;	quantum/quantum.c:502: return false;
      00A511 75 82 00         [24] 1550 	mov	dpl, #0x00
                                   1551 ;	quantum/quantum.c:557: }
      00A514 22               [24] 1552 	ret
      00A515                       1553 00116$:
                                   1554 ;	quantum/quantum.c:560: return process_action_kb(record);
      00A515 12 43 F9         [24] 1555 	lcall	_ak820_outline_0014
      00A518 8D F0            [24] 1556 	mov	b, r5
                                   1557 ;	quantum/quantum.c:561: }
      00A51A 02 A1 93         [24] 1558 	ljmp	_process_action_kb
                                   1559 ;------------------------------------------------------------
                                   1560 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1561 ;------------------------------------------------------------
                                   1562 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_665'
                                   1563 ;------------------------------------------------------------
                                   1564 ;	quantum/quantum.c:563: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1565 ;	-----------------------------------------
                                   1566 ;	 function shutdown_user
                                   1567 ;	-----------------------------------------
      00A51D                       1568 _shutdown_user:
      00A51D 22               [24] 1569 	ret
                                   1570 ;------------------------------------------------------------
                                   1571 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1572 ;------------------------------------------------------------
                                   1573 ;	quantum/quantum.c:579: void suspend_power_down_quantum(void) {
                                   1574 ;	-----------------------------------------
                                   1575 	.area CSEG    (CODE)
                                   1576 	.area CONST   (CODE)
                                   1577 	.area XINIT   (CODE)
                                   1578 	.area CABS    (ABS,CODE)
                                   1579 
                                   1580 ; Experimental exact instruction outlining.
                                   1581 	.globl _ak820_outline_0000
                                   1582 	.globl _ak820_outline_0001
                                   1583 	.globl _ak820_outline_0002
                                   1584 	.globl _ak820_outline_0003
                                   1585 	.globl _ak820_outline_0004
                                   1586 	.globl _ak820_outline_0005
                                   1587 	.globl _ak820_outline_0006
                                   1588 	.globl _ak820_outline_0007
                                   1589 	.globl _ak820_outline_0008
                                   1590 	.globl _ak820_outline_0010
                                   1591 	.globl _ak820_outline_0014
                                   1592 	.globl _ak820_outline_0018
                                   1593 	.globl _ak820_outline_0019
                                   1594 	.globl _ak820_outline_0022
                                   1595 	.globl _ak820_outline_0027
                                   1596 	.globl _ak820_outline_0028
                                   1597 	.globl _ak820_outline_0052
                                   1598 	.globl _ak820_outline_0085
                                   1599 	.globl _ak820_outline_0087
                                   1600 	.globl _ak820_outline_0146
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0019
      00A51E                       1604 _ak820_outline_0019:
      00A51E 90 0D B3         [24] 1605 	mov	dptr,#___memcpy_PARM_2
      00A521 74 01            [12] 1606 	mov	a,#_get_event_keycode_PARM_1
      00A523 F0               [24] 1607 	movx	@dptr,a
      00A524 74 0C            [12] 1608 	mov	a,#(_get_event_keycode_PARM_1>>8)
      00A526 A3               [24] 1609 	inc	dptr
      00A527 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0022
      00A528                       1614 _ak820_outline_0022:
      00A528 90 0C 11         [24] 1615 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A52B E0               [24] 1616 	movx	a,@dptr
      00A52C FB               [12] 1617 	mov	r3,a
      00A52D A3               [24] 1618 	inc	dptr
      00A52E 22               [24] 1619 	ret
                                   1620 
                                   1621 	.area CSEG (CODE)
                                   1622 ; function ak820_outline_0028
      00A52F                       1623 _ak820_outline_0028:
      00A52F 88 82            [24] 1624 	mov	dpl,r0
      00A531 89 83            [24] 1625 	mov	dph,r1
      00A533 8A F0            [24] 1626 	mov	b,r2
      00A535 22               [24] 1627 	ret
                                   1628 
                                   1629 	.area CSEG (CODE)
                                   1630 ; function ak820_outline_0087
      00A536                       1631 _ak820_outline_0087:
      00A536 90 0D B6         [24] 1632 	mov	dptr,#___memcpy_PARM_3
      00A539 74 02            [12] 1633 	mov	a,#0x02
      00A53B 22               [24] 1634 	ret
