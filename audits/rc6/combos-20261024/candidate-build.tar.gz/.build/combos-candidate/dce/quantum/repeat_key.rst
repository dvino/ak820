                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000C25                        554 _last_record:
      000C25                        555 	.ds 9
      000C2E                        556 _registered_record:
      000C2E                        557 	.ds 9
      000C37                        558 _registered_repeat_count:
      000C37                        559 	.ds 1
      000C38                        560 _registered_mods:
      000C38                        561 	.ds 1
      000C39                        562 _set_last_mods_mods_10000_169:
      000C39                        563 	.ds 1
      000C3A                        564 _set_last_record_PARM_2:
      000C3A                        565 	.ds 3
      000C3D                        566 _set_last_record_keycode_10000_171:
      000C3D                        567 	.ds 2
      000C3F                        568 _update_last_repeat_count_dir_10000_173:
      000C3F                        569 	.ds 1
      000C40                        570 _repeat_invoke_PARM_2:
      000C40                        571 	.ds 1
      000C41                        572 _repeat_invoke_event_10000_181:
      000C41                        573 	.ds 3
      000C44                        574 _repeat_key_invoke_event_10000_195:
      000C44                        575 	.ds 3
      000C47                        576 _find_alt_keycode_PARM_2:
      000C47                        577 	.ds 1
      000C48                        578 _find_alt_keycode_PARM_3:
      000C48                        579 	.ds 1
      000C49                        580 _find_alt_keycode_table_10000_197:
      000C49                        581 	.ds 3
      000C4C                        582 _get_alt_repeat_key_keycode_keycode_10000_204:
      000C4C                        583 	.ds 2
      000C4E                        584 _get_alt_repeat_key_keycode_mods_10000_204:
      000C4E                        585 	.ds 1
      000C4F                        586 _get_alt_repeat_key_keycode_alt_keycode_10000_204:
      000C4F                        587 	.ds 2
      000C51                        588 _alt_repeat_key_invoke_event_10000_218:
      000C51                        589 	.ds 3
      000C54                        590 _get_alt_repeat_key_keycode_user_PARM_2:
      000C54                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; absolute external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XABS    (ABS,XDATA)
                                    596 ;--------------------------------------------------------
                                    597 ; initialized external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area XISEG   (XDATA)
      000E2A                        600 _last_mods:
      000E2A                        601 	.ds 1
      000E2B                        602 _last_repeat_count:
      000E2B                        603 	.ds 1
      000E2C                        604 _processing_repeat_count:
      000E2C                        605 	.ds 1
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT0 (CODE)
                                    608 	.area GSINIT1 (CODE)
                                    609 	.area GSINIT2 (CODE)
                                    610 	.area GSINIT3 (CODE)
                                    611 	.area GSINIT4 (CODE)
                                    612 	.area GSINIT5 (CODE)
                                    613 	.area GSINIT  (CODE)
                                    614 	.area GSFINAL (CODE)
                                    615 	.area CSEG    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; global & static initialisations
                                    618 ;--------------------------------------------------------
                                    619 	.area HOME    (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; Home
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area HOME    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; code
                                    630 ;--------------------------------------------------------
                                    631 	.area CSEG    (CODE)
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    634 ;------------------------------------------------------------
                                    635 ;	quantum/repeat_key.c:41: void repeat_key_cancel(void) {
                                    636 ;	-----------------------------------------
                                    637 ;	 function repeat_key_cancel
                                    638 ;	-----------------------------------------
      00A53C                        639 _repeat_key_cancel:
                           000007   640 	ar7 = 0x07
                           000006   641 	ar6 = 0x06
                           000005   642 	ar5 = 0x05
                           000004   643 	ar4 = 0x04
                           000003   644 	ar3 = 0x03
                           000002   645 	ar2 = 0x02
                           000001   646 	ar1 = 0x01
                           000000   647 	ar0 = 0x00
                                    648 ;	quantum/repeat_key.c:42: registered_record.keycode = 0;
      00A53C 90 0C 35         [24]  649 	mov	dptr,#(_registered_record + 0x0007)
      00A53F 12 4E 8D         [24]  650 	lcall	_ak820_outline_0098
                                    651 ;	quantum/repeat_key.c:43: }
      00A542 22               [24]  652 	ret
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'get_last_keycode'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/repeat_key.c:45: uint16_t get_last_keycode(void) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function set_last_mods
                                    659 ;	-----------------------------------------
      00A543                        660 _set_last_mods:
      00A543 E5 82            [12]  661 	mov	a,dpl
      00A545 90 0C 39         [24]  662 	mov	dptr,#_set_last_mods_mods_10000_169
      00A548 F0               [24]  663 	movx	@dptr,a
                                    664 ;	quantum/repeat_key.c:63: last_mods = mods;
      00A549 E0               [24]  665 	movx	a,@dptr
      00A54A 90 0E 2A         [24]  666 	mov	dptr,#_last_mods
      00A54D F0               [24]  667 	movx	@dptr,a
                                    668 ;	quantum/repeat_key.c:64: }
      00A54E 22               [24]  669 	ret
                                    670 ;------------------------------------------------------------
                                    671 ;Allocation info for local variables in function 'set_last_record'
                                    672 ;------------------------------------------------------------
                                    673 ;record        Allocated with name '_set_last_record_PARM_2'
                                    674 ;keycode       Allocated with name '_set_last_record_keycode_10000_171'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/repeat_key.c:66: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    677 ;	-----------------------------------------
                                    678 ;	 function set_last_record
                                    679 ;	-----------------------------------------
      00A54F                        680 _set_last_record:
      00A54F 12 43 EA         [24]  681 	lcall	_ak820_outline_0010
      00A552 90 0C 3D         [24]  682 	mov	dptr,#_set_last_record_keycode_10000_171
      00A555 12 43 E5         [24]  683 	lcall	_ak820_outline_0007
                                    684 ;	quantum/repeat_key.c:67: last_record         = *record;
      00A558 90 0C 3A         [24]  685 	mov	dptr,#_set_last_record_PARM_2
      00A55B E0               [24]  686 	movx	a,@dptr
      00A55C FD               [12]  687 	mov	r5,a
      00A55D A3               [24]  688 	inc	dptr
      00A55E 12 43 C5         [24]  689 	lcall	_ak820_outline_0000
      00A561 90 0D B3         [24]  690 	mov	dptr,#___memcpy_PARM_2
      00A564 ED               [12]  691 	mov	a,r5
      00A565 12 43 CB         [24]  692 	lcall	_ak820_outline_0001
      00A568 90 0D B6         [24]  693 	mov	dptr,#___memcpy_PARM_3
      00A56B 74 09            [12]  694 	mov	a,#0x09
      00A56D 12 4E 60         [24]  695 	lcall	_ak820_outline_0003
      00A570 90 0C 25         [24]  696 	mov	dptr,#_last_record
      00A573 F5 F0            [12]  697 	mov	b,a
      00A575 12 BD 3B         [24]  698 	lcall	___memcpy
                                    699 ;	quantum/repeat_key.c:68: last_record.keycode = keycode;
      00A578 90 0C 3D         [24]  700 	mov	dptr,#_set_last_record_keycode_10000_171
      00A57B 12 43 C5         [24]  701 	lcall	_ak820_outline_0000
      00A57E 90 0C 2C         [24]  702 	mov	dptr,#(_last_record + 0x0007)
      00A581 EE               [12]  703 	mov	a,r6
      00A582 12 43 E5         [24]  704 	lcall	_ak820_outline_0007
                                    705 ;	quantum/repeat_key.c:69: last_repeat_count   = 0;
      00A585 90 0E 2B         [24]  706 	mov	dptr,#_last_repeat_count
      00A588 E4               [12]  707 	clr	a
      00A589 F0               [24]  708 	movx	@dptr,a
                                    709 ;	quantum/repeat_key.c:70: }
      00A58A 22               [24]  710 	ret
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    713 ;------------------------------------------------------------
                                    714 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_173'
                                    715 ;------------------------------------------------------------
                                    716 ;	quantum/repeat_key.c:73: static void update_last_repeat_count(int8_t dir) {
                                    717 ;	-----------------------------------------
                                    718 ;	 function update_last_repeat_count
                                    719 ;	-----------------------------------------
      00A58B                        720 _update_last_repeat_count:
      00A58B E5 82            [12]  721 	mov	a,dpl
      00A58D 90 0C 3F         [24]  722 	mov	dptr,#_update_last_repeat_count_dir_10000_173
      00A590 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/repeat_key.c:74: if ((dir < 0) != (last_repeat_count < 0)) {
      00A591 E0               [24]  725 	movx	a,@dptr
      00A592 FF               [12]  726 	mov	r7,a
      00A593 33               [12]  727 	rlc	a
      00A594 E4               [12]  728 	clr	a
      00A595 33               [12]  729 	rlc	a
      00A596 FE               [12]  730 	mov	r6,a
      00A597 90 0E 2B         [24]  731 	mov	dptr,#_last_repeat_count
      00A59A E0               [24]  732 	movx	a,@dptr
      00A59B FD               [12]  733 	mov	r5,a
      00A59C 33               [12]  734 	rlc	a
      00A59D E4               [12]  735 	clr	a
      00A59E 33               [12]  736 	rlc	a
      00A59F FC               [12]  737 	mov	r4,a
      00A5A0 EE               [12]  738 	mov	a,r6
      00A5A1 B5 04 02         [24]  739 	cjne	a,ar4,00131$
      00A5A4 80 06            [24]  740 	sjmp	00104$
      00A5A6                        741 00131$:
                                    742 ;	quantum/repeat_key.c:75: last_repeat_count = dir;
      00A5A6 90 0E 2B         [24]  743 	mov	dptr,#_last_repeat_count
      00A5A9 EF               [12]  744 	mov	a,r7
      00A5AA F0               [24]  745 	movx	@dptr,a
      00A5AB 22               [24]  746 	ret
      00A5AC                        747 00104$:
                                    748 ;	quantum/repeat_key.c:76: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A5AC EE               [12]  749 	mov	a,r6
      00A5AD 60 0F            [24]  750 	jz	00108$
      00A5AF C3               [12]  751 	clr	c
      00A5B0 74 01            [12]  752 	mov	a,#(0x81 ^ 0x80)
      00A5B2 8D F0            [24]  753 	mov	b,r5
      00A5B4 63 F0 80         [24]  754 	xrl	b,#0x80
      00A5B7 95 F0            [12]  755 	subb	a,b
      00A5B9 E4               [12]  756 	clr	a
      00A5BA 33               [12]  757 	rlc	a
      00A5BB FF               [12]  758 	mov	r7,a
                                    759 ;	free result
      00A5BC 80 09            [24]  760 	sjmp	00109$
      00A5BE                        761 00108$:
      00A5BE C3               [12]  762 	clr	c
      00A5BF ED               [12]  763 	mov	a,r5
      00A5C0 64 80            [12]  764 	xrl	a,#0x80
      00A5C2 94 FF            [12]  765 	subb	a,#0xff
      00A5C4 E4               [12]  766 	clr	a
      00A5C5 33               [12]  767 	rlc	a
      00A5C6 FF               [12]  768 	mov	r7,a
      00A5C7                        769 00109$:
      00A5C7 EF               [12]  770 	mov	a,r7
      00A5C8 60 09            [24]  771 	jz	00106$
                                    772 ;	quantum/repeat_key.c:77: last_repeat_count += dir;
      00A5CA 90 0C 3F         [24]  773 	mov	dptr,#_update_last_repeat_count_dir_10000_173
      00A5CD E0               [24]  774 	movx	a,@dptr
      00A5CE 90 0E 2B         [24]  775 	mov	dptr,#_last_repeat_count
      00A5D1 2D               [12]  776 	add	a, r5
      00A5D2 F0               [24]  777 	movx	@dptr,a
      00A5D3                        778 00106$:
                                    779 ;	quantum/repeat_key.c:79: }
      00A5D3 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/repeat_key.c:81: int8_t get_repeat_key_count(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function get_repeat_key_count
                                    787 ;	-----------------------------------------
      00A5D4                        788 _get_repeat_key_count:
                                    789 ;	quantum/repeat_key.c:82: return processing_repeat_count;
      00A5D4 90 0E 2C         [24]  790 	mov	dptr,#_processing_repeat_count
      00A5D7 E0               [24]  791 	movx	a,@dptr
                                    792 ;	quantum/repeat_key.c:83: }
      00A5D8 F5 82            [12]  793 	mov	dpl,a
      00A5DA 22               [24]  794 	ret
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'repeat_invoke'
                                    797 ;------------------------------------------------------------
                                    798 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    799 ;event         Allocated with name '_repeat_invoke_event_10000_181'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/repeat_key.c:85: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function repeat_invoke
                                    804 ;	-----------------------------------------
      00A5DB                        805 _repeat_invoke:
      00A5DB 12 43 D8         [24]  806 	lcall	_ak820_outline_0004
      00A5DE 90 0C 41         [24]  807 	mov	dptr,#_repeat_invoke_event_10000_181
      00A5E1 12 43 CB         [24]  808 	lcall	_ak820_outline_0001
                                    809 ;	quantum/repeat_key.c:93: if (processing_repeat_count) {
      00A5E4 90 0E 2C         [24]  810 	mov	dptr,#_processing_repeat_count
      00A5E7 E0               [24]  811 	movx	a,@dptr
      00A5E8 60 01            [24]  812 	jz	00102$
                                    813 ;	quantum/repeat_key.c:94: return;
      00A5EA 22               [24]  814 	ret
      00A5EB                        815 00102$:
                                    816 ;	quantum/repeat_key.c:97: if (event->pressed) {
      00A5EB 90 0C 41         [24]  817 	mov	dptr,#_repeat_invoke_event_10000_181
      00A5EE E0               [24]  818 	movx	a,@dptr
      00A5EF FD               [12]  819 	mov	r5,a
      00A5F0 A3               [24]  820 	inc	dptr
      00A5F1 12 43 C5         [24]  821 	lcall	_ak820_outline_0000
      00A5F4 74 05            [12]  822 	mov	a,#0x05
      00A5F6 12 76 A5         [24]  823 	lcall	_ak820_outline_0009
      00A5F9 12 BE 14         [24]  824 	lcall	__gptrget
      00A5FC 70 03            [24]  825 	jnz	00187$
      00A5FE 02 A6 7A         [24]  826 	ljmp	00115$
      00A601                        827 00187$:
                                    828 ;	quantum/repeat_key.c:100: if (registered_record.keycode || !last_record.keycode) return;
      00A601 12 A8 96         [24]  829 	lcall	_ak820_outline_0136
      00A604 70 0A            [24]  830 	jnz	00103$
      00A606 90 0C 2C         [24]  831 	mov	dptr,#(_last_record + 0x0007)
      00A609 E0               [24]  832 	movx	a,@dptr
      00A60A FB               [12]  833 	mov	r3,a
      00A60B A3               [24]  834 	inc	dptr
      00A60C E0               [24]  835 	movx	a,@dptr
      00A60D 4B               [12]  836 	orl	a,r3
      00A60E 70 01            [24]  837 	jnz	00104$
      00A610                        838 00103$:
      00A610 22               [24]  839 	ret
      00A611                        840 00104$:
                                    841 ;	quantum/repeat_key.c:101: registered_record = last_record;
      00A611 90 0D B3         [24]  842 	mov	dptr,#___memcpy_PARM_2
      00A614 74 25            [12]  843 	mov	a,#_last_record
      00A616 F0               [24]  844 	movx	@dptr,a
      00A617 74 0C            [12]  845 	mov	a,#(_last_record >> 8)
      00A619 A3               [24]  846 	inc	dptr
      00A61A 12 4E 60         [24]  847 	lcall	_ak820_outline_0003
      00A61D 90 0D B6         [24]  848 	mov	dptr,#___memcpy_PARM_3
      00A620 74 09            [12]  849 	mov	a,#0x09
      00A622 12 4E 60         [24]  850 	lcall	_ak820_outline_0003
      00A625 90 0C 2E         [24]  851 	mov	dptr,#_registered_record
      00A628 F5 F0            [12]  852 	mov	b,a
      00A62A 12 BD 3B         [24]  853 	lcall	___memcpy
                                    854 ;	quantum/repeat_key.c:102: registered_mods = last_mods;
      00A62D 90 0E 2A         [24]  855 	mov	dptr,#_last_mods
      00A630 E0               [24]  856 	movx	a,@dptr
      00A631 90 0C 38         [24]  857 	mov	dptr,#_registered_mods
      00A634 F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/repeat_key.c:104: if (alternate) {
      00A635 90 0C 40         [24]  860 	mov	dptr,#_repeat_invoke_PARM_2
      00A638 E0               [24]  861 	movx	a,@dptr
      00A639 FC               [12]  862 	mov	r4,a
      00A63A E0               [24]  863 	movx	a,@dptr
      00A63B 60 1C            [24]  864 	jz	00109$
                                    865 ;	quantum/repeat_key.c:105: registered_record.keycode = get_alt_repeat_key_keycode();
      00A63D C0 04            [24]  866 	push	ar4
      00A63F 12 A7 5B         [24]  867 	lcall	_get_alt_repeat_key_keycode
      00A642 AA 82            [24]  868 	mov	r2, dpl
      00A644 AB 83            [24]  869 	mov	r3, dph
      00A646 D0 04            [24]  870 	pop	ar4
      00A648 90 0C 35         [24]  871 	mov	dptr,#(_registered_record + 0x0007)
      00A64B EA               [12]  872 	mov	a,r2
      00A64C 12 8F 56         [24]  873 	lcall	_ak820_outline_0149
                                    874 ;	quantum/repeat_key.c:106: if (!registered_record.keycode) return;
      00A64F EA               [12]  875 	mov	a,r2
      00A650 4B               [12]  876 	orl	a,r3
      00A651 70 01            [24]  877 	jnz	00107$
      00A653 22               [24]  878 	ret
      00A654                        879 00107$:
                                    880 ;	quantum/repeat_key.c:108: registered_mods = 0;
      00A654 90 0C 38         [24]  881 	mov	dptr,#_registered_mods
      00A657 E4               [12]  882 	clr	a
      00A658 F0               [24]  883 	movx	@dptr,a
      00A659                        884 00109$:
                                    885 ;	quantum/repeat_key.c:111: update_last_repeat_count(alternate ? -1 : 1);
      00A659 EC               [12]  886 	mov	a,r4
      00A65A 60 04            [24]  887 	jz	00121$
      00A65C 7C FF            [12]  888 	mov	r4,#0xff
      00A65E 80 02            [24]  889 	sjmp	00122$
      00A660                        890 00121$:
      00A660 7C 01            [12]  891 	mov	r4,#0x01
      00A662                        892 00122$:
      00A662 8C 82            [24]  893 	mov	dpl, r4
      00A664 12 A5 8B         [24]  894 	lcall	_update_last_repeat_count
                                    895 ;	quantum/repeat_key.c:112: register_weak_mods(registered_mods);
      00A667 90 0C 38         [24]  896 	mov	dptr,#_registered_mods
      00A66A E0               [24]  897 	movx	a,@dptr
      00A66B F5 82            [12]  898 	mov	dpl,a
      00A66D 12 76 38         [24]  899 	lcall	_register_weak_mods
                                    900 ;	quantum/repeat_key.c:113: registered_repeat_count = last_repeat_count;
      00A670 90 0E 2B         [24]  901 	mov	dptr,#_last_repeat_count
      00A673 E0               [24]  902 	movx	a,@dptr
      00A674 90 0C 37         [24]  903 	mov	dptr,#_registered_repeat_count
      00A677 F0               [24]  904 	movx	@dptr,a
      00A678 80 2A            [24]  905 	sjmp	00116$
      00A67A                        906 00115$:
                                    907 ;	quantum/repeat_key.c:116: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A67A 12 A8 96         [24]  908 	lcall	_ak820_outline_0136
      00A67D 60 24            [24]  909 	jz	00110$
      00A67F 74 01            [12]  910 	mov	a,#0x01
      00A681 12 76 A5         [24]  911 	lcall	_ak820_outline_0009
      00A684 12 BE 14         [24]  912 	lcall	__gptrget
      00A687 FA               [12]  913 	mov	r2,a
      00A688 90 0C 2F         [24]  914 	mov	dptr,#(_registered_record + 0x0001)
      00A68B E0               [24]  915 	movx	a,@dptr
      00A68C FC               [12]  916 	mov	r4,a
      00A68D EA               [12]  917 	mov	a,r2
      00A68E B5 04 12         [24]  918 	cjne	a,ar4,00110$
                                    919 ;	quantum/repeat_key.c:117: event->key.col != registered_record.event.key.col) return;
      00A691 12 4E 65         [24]  920 	lcall	_ak820_outline_0005
      00A694 12 BE 14         [24]  921 	lcall	__gptrget
      00A697 FD               [12]  922 	mov	r5,a
      00A698 90 0C 2E         [24]  923 	mov	dptr,#_registered_record
      00A69B E0               [24]  924 	movx	a,@dptr
      00A69C FF               [12]  925 	mov	r7,a
      00A69D ED               [12]  926 	mov	a,r5
      00A69E B5 07 02         [24]  927 	cjne	a,ar7,00196$
      00A6A1 80 01            [24]  928 	sjmp	00116$
      00A6A3                        929 00196$:
      00A6A3                        930 00110$:
      00A6A3 22               [24]  931 	ret
      00A6A4                        932 00116$:
                                    933 ;	quantum/repeat_key.c:121: registered_record.event = *event;
      00A6A4 90 0C 41         [24]  934 	mov	dptr,#_repeat_invoke_event_10000_181
      00A6A7 E0               [24]  935 	movx	a,@dptr
      00A6A8 FD               [12]  936 	mov	r5,a
      00A6A9 A3               [24]  937 	inc	dptr
      00A6AA 12 43 C5         [24]  938 	lcall	_ak820_outline_0000
      00A6AD 90 0D B3         [24]  939 	mov	dptr,#___memcpy_PARM_2
      00A6B0 ED               [12]  940 	mov	a,r5
      00A6B1 12 43 CB         [24]  941 	lcall	_ak820_outline_0001
      00A6B4 90 0D B6         [24]  942 	mov	dptr,#___memcpy_PARM_3
      00A6B7 74 06            [12]  943 	mov	a,#0x06
      00A6B9 12 4E 60         [24]  944 	lcall	_ak820_outline_0003
      00A6BC 90 0C 2E         [24]  945 	mov	dptr,#_registered_record
      00A6BF F5 F0            [12]  946 	mov	b,a
      00A6C1 12 BD 3B         [24]  947 	lcall	___memcpy
                                    948 ;	quantum/repeat_key.c:122: processing_repeat_count = registered_repeat_count;
      00A6C4 90 0C 37         [24]  949 	mov	dptr,#_registered_repeat_count
      00A6C7 E0               [24]  950 	movx	a,@dptr
      00A6C8 90 0E 2C         [24]  951 	mov	dptr,#_processing_repeat_count
      00A6CB F0               [24]  952 	movx	@dptr,a
                                    953 ;	quantum/repeat_key.c:123: process_record(&registered_record);
      00A6CC 90 0C 2E         [24]  954 	mov	dptr,#_registered_record
      00A6CF 75 F0 00         [24]  955 	mov	b, #0x00
      00A6D2 12 71 16         [24]  956 	lcall	_process_record
                                    957 ;	quantum/repeat_key.c:124: processing_repeat_count = 0;
      00A6D5 90 0E 2C         [24]  958 	mov	dptr,#_processing_repeat_count
      00A6D8 E4               [12]  959 	clr	a
      00A6D9 F0               [24]  960 	movx	@dptr,a
                                    961 ;	quantum/repeat_key.c:130: if (!registered_record.event.pressed) {
      00A6DA 90 0C 33         [24]  962 	mov	dptr,#(_registered_record + 0x0005)
      00A6DD E0               [24]  963 	movx	a,@dptr
      00A6DE 70 0F            [24]  964 	jnz	00119$
                                    965 ;	quantum/repeat_key.c:131: unregister_weak_mods(registered_mods);
      00A6E0 90 0C 38         [24]  966 	mov	dptr,#_registered_mods
      00A6E3 E0               [24]  967 	movx	a,@dptr
      00A6E4 F5 82            [12]  968 	mov	dpl,a
      00A6E6 12 76 4C         [24]  969 	lcall	_unregister_weak_mods
                                    970 ;	quantum/repeat_key.c:132: registered_record.keycode = 0;
      00A6E9 90 0C 35         [24]  971 	mov	dptr,#(_registered_record + 0x0007)
      00A6EC 12 4E 8D         [24]  972 	lcall	_ak820_outline_0098
      00A6EF                        973 00119$:
                                    974 ;	quantum/repeat_key.c:134: }
      00A6EF 22               [24]  975 	ret
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    978 ;------------------------------------------------------------
                                    979 ;event         Allocated with name '_repeat_key_invoke_event_10000_195'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/repeat_key.c:136: void repeat_key_invoke(const keyevent_t* event) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function repeat_key_invoke
                                    984 ;	-----------------------------------------
      00A6F0                        985 _repeat_key_invoke:
      00A6F0 12 43 D8         [24]  986 	lcall	_ak820_outline_0004
      00A6F3 90 0C 44         [24]  987 	mov	dptr,#_repeat_key_invoke_event_10000_195
      00A6F6 12 43 CB         [24]  988 	lcall	_ak820_outline_0001
                                    989 ;	quantum/repeat_key.c:137: repeat_invoke(event, false);
      00A6F9 90 0C 44         [24]  990 	mov	dptr,#_repeat_key_invoke_event_10000_195
      00A6FC E0               [24]  991 	movx	a,@dptr
      00A6FD FD               [12]  992 	mov	r5,a
      00A6FE A3               [24]  993 	inc	dptr
      00A6FF 12 43 C5         [24]  994 	lcall	_ak820_outline_0000
      00A702 90 0C 40         [24]  995 	mov	dptr,#_repeat_invoke_PARM_2
      00A705 E4               [12]  996 	clr	a
      00A706 F0               [24]  997 	movx	@dptr,a
      00A707 12 4E 65         [24]  998 	lcall	_ak820_outline_0005
                                    999 ;	quantum/repeat_key.c:138: }
      00A70A 02 A5 DB         [24] 1000 	ljmp	_repeat_invoke
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1003 ;------------------------------------------------------------
                                   1004 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1005 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1006 ;table         Allocated with name '_find_alt_keycode_table_10000_197'
                                   1007 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_198'
                                   1008 ;i             Allocated with name '_find_alt_keycode_i_20000_199'
                                   1009 ;------------------------------------------------------------
                                   1010 ;	quantum/repeat_key.c:154: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1011 ;	-----------------------------------------
                                   1012 ;	 function find_alt_keycode
                                   1013 ;	-----------------------------------------
      00A70D                       1014 _find_alt_keycode:
      00A70D 12 43 D8         [24] 1015 	lcall	_ak820_outline_0004
      00A710 90 0C 49         [24] 1016 	mov	dptr,#_find_alt_keycode_table_10000_197
      00A713 12 43 CB         [24] 1017 	lcall	_ak820_outline_0001
                                   1018 ;	quantum/repeat_key.c:155: const uint8_t* keycodes = (const uint8_t*)table;
      00A716 90 0C 49         [24] 1019 	mov	dptr,#_find_alt_keycode_table_10000_197
      00A719 E0               [24] 1020 	movx	a,@dptr
      00A71A FD               [12] 1021 	mov	r5,a
      00A71B A3               [24] 1022 	inc	dptr
      00A71C 12 43 C5         [24] 1023 	lcall	_ak820_outline_0000
                                   1024 ;	quantum/repeat_key.c:156: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A71F 7C 00            [12] 1025 	mov	r4,#0x00
      00A721                       1026 00105$:
      00A721 90 0C 47         [24] 1027 	mov	dptr,#_find_alt_keycode_PARM_2
      00A724 E0               [24] 1028 	movx	a,@dptr
      00A725 FB               [12] 1029 	mov	r3,a
      00A726 C3               [12] 1030 	clr	c
      00A727 EC               [12] 1031 	mov	a,r4
      00A728 9B               [12] 1032 	subb	a,r3
      00A729 50 2C            [24] 1033 	jnc	00103$
                                   1034 ;	quantum/repeat_key.c:157: if (target == pgm_read_byte(keycodes + i)) {
      00A72B EC               [12] 1035 	mov	a,r4
      00A72C 12 8E E9         [24] 1036 	lcall	_ak820_outline_0049
      00A72F 8F 03            [24] 1037 	mov	ar3,r7
      00A731 12 44 06         [24] 1038 	lcall	_ak820_outline_0016
      00A734 8B F0            [24] 1039 	mov	b,r3
      00A736 12 BE 14         [24] 1040 	lcall	__gptrget
      00A739 F9               [12] 1041 	mov	r1,a
      00A73A 90 0C 48         [24] 1042 	mov	dptr,#_find_alt_keycode_PARM_3
      00A73D E0               [24] 1043 	movx	a,@dptr
      00A73E B5 01 13         [24] 1044 	cjne	a,ar1,00106$
                                   1045 ;	quantum/repeat_key.c:159: return pgm_read_byte(keycodes + (i ^ 1));
      00A741 74 01            [12] 1046 	mov	a,#0x01
      00A743 6C               [12] 1047 	xrl	a,r4
      00A744 12 8E E9         [24] 1048 	lcall	_ak820_outline_0049
      00A747 8F 03            [24] 1049 	mov	ar3,r7
      00A749 12 44 06         [24] 1050 	lcall	_ak820_outline_0016
      00A74C 8B F0            [24] 1051 	mov	b,r3
      00A74E 12 BE 14         [24] 1052 	lcall	__gptrget
      00A751 F5 82            [12] 1053 	mov	dpl,a
      00A753 22               [24] 1054 	ret
      00A754                       1055 00106$:
                                   1056 ;	quantum/repeat_key.c:156: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A754 0C               [12] 1057 	inc	r4
      00A755 80 CA            [24] 1058 	sjmp	00105$
      00A757                       1059 00103$:
                                   1060 ;	quantum/repeat_key.c:162: return KC_NO;
      00A757 75 82 00         [24] 1061 	mov	dpl, #0x00
                                   1062 ;	quantum/repeat_key.c:163: }
      00A75A 22               [24] 1063 	ret
                                   1064 ;------------------------------------------------------------
                                   1065 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1066 ;------------------------------------------------------------
                                   1067 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_204'
                                   1068 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_204'
                                   1069 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_204'
                                   1070 ;------------------------------------------------------------
                                   1071 ;	quantum/repeat_key.c:165: uint16_t get_alt_repeat_key_keycode(void) {
                                   1072 ;	-----------------------------------------
                                   1073 ;	 function get_alt_repeat_key_keycode
                                   1074 ;	-----------------------------------------
      00A75B                       1075 _get_alt_repeat_key_keycode:
                                   1076 ;	quantum/repeat_key.c:166: uint16_t keycode = last_record.keycode;
      00A75B 90 0C 2C         [24] 1077 	mov	dptr,#(_last_record + 0x0007)
      00A75E 12 43 C5         [24] 1078 	lcall	_ak820_outline_0000
      00A761 90 0C 4C         [24] 1079 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_204
      00A764 EE               [12] 1080 	mov	a,r6
      00A765 12 43 E5         [24] 1081 	lcall	_ak820_outline_0007
                                   1082 ;	quantum/repeat_key.c:167: uint8_t  mods    = last_mods;
      00A768 90 0E 2A         [24] 1083 	mov	dptr,#_last_mods
      00A76B E0               [24] 1084 	movx	a,@dptr
      00A76C FD               [12] 1085 	mov	r5,a
      00A76D 90 0C 4E         [24] 1086 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A770 F0               [24] 1087 	movx	@dptr,a
                                   1088 ;	quantum/repeat_key.c:171: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A771 90 0C 54         [24] 1089 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A774 ED               [12] 1090 	mov	a,r5
      00A775 F0               [24] 1091 	movx	@dptr,a
      00A776 12 43 D3         [24] 1092 	lcall	_ak820_outline_0002
      00A779 C0 07            [24] 1093 	push	ar7
      00A77B C0 06            [24] 1094 	push	ar6
      00A77D 12 A8 92         [24] 1095 	lcall	_get_alt_repeat_key_keycode_user
      00A780 12 44 83         [24] 1096 	lcall	_ak820_outline_0132
      00A783 D0 06            [24] 1097 	pop	ar6
      00A785 D0 07            [24] 1098 	pop	ar7
                                   1099 ;	quantum/repeat_key.c:173: if (alt_keycode != KC_TRANSPARENT) {
      00A787 8C 02            [24] 1100 	mov	ar2,r4
      00A789 8D 03            [24] 1101 	mov	ar3,r5
      00A78B BA 01 05         [24] 1102 	cjne	r2,#0x01,00176$
      00A78E BB 00 02         [24] 1103 	cjne	r3,#0x00,00176$
      00A791 80 04            [24] 1104 	sjmp	00102$
      00A793                       1105 00176$:
                                   1106 ;	quantum/repeat_key.c:174: return alt_keycode;
      00A793 12 43 EF         [24] 1107 	lcall	_ak820_outline_0011
      00A796 22               [24] 1108 	ret
      00A797                       1109 00102$:
                                   1110 ;	quantum/repeat_key.c:179: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A797 90 0C 4E         [24] 1111 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A79A E0               [24] 1112 	movx	a,@dptr
      00A79B 54 F0            [12] 1113 	anl	a,#0xf0
      00A79D 60 02            [24] 1114 	jz	00118$
      00A79F 74 10            [12] 1115 	mov	a,#0x10
      00A7A1                       1116 00118$:
      00A7A1 FD               [12] 1117 	mov	r5,a
                                   1118 ;	quantum/repeat_key.c:181: | (((mods >> 4) | mods) & 0xf);
      00A7A2 90 0C 4E         [24] 1119 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A7A5 E0               [24] 1120 	movx	a,@dptr
      00A7A6 FC               [12] 1121 	mov	r4,a
      00A7A7 C4               [12] 1122 	swap	a
      00A7A8 54 0F            [12] 1123 	anl	a,#0x0f
      00A7AA 4C               [12] 1124 	orl	a,r4
      00A7AB 54 0F            [12] 1125 	anl	a,#0x0f
      00A7AD 4D               [12] 1126 	orl	a,r5
      00A7AE F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	quantum/repeat_key.c:184: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A7AF 12 44 62         [24] 1129 	lcall	_ak820_outline_0073
      00A7B2 74 FF            [12] 1130 	mov	a,#0x100 - 0x01
      00A7B4 2D               [12] 1131 	add	a,r5
      00A7B5 50 1C            [24] 1132 	jnc	00115$
      00A7B7 C3               [12] 1133 	clr	c
      00A7B8 74 FF            [12] 1134 	mov	a,#0xff
      00A7BA 9C               [12] 1135 	subb	a,r4
      00A7BB 74 1F            [12] 1136 	mov	a,#0x1f
      00A7BD 9D               [12] 1137 	subb	a,r5
      00A7BE 40 13            [24] 1138 	jc	00115$
                                   1139 ;	free result
                                   1140 ;	quantum/repeat_key.c:185: mods |= QK_MODS_GET_MODS(keycode);
      00A7C0 8F 06            [24] 1141 	mov	ar6,r7
      00A7C2 53 06 1F         [24] 1142 	anl	ar6,#0x1f
      00A7C5 90 0C 4E         [24] 1143 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A7C8 E0               [24] 1144 	movx	a,@dptr
      00A7C9 4E               [12] 1145 	orl	a,r6
      00A7CA F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/repeat_key.c:186: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A7CB 7D 00            [12] 1148 	mov	r5,#0x00
      00A7CD 90 0C 4C         [24] 1149 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_204
      00A7D0 12 44 0B         [24] 1150 	lcall	_ak820_outline_0023
                                   1151 ;	quantum/repeat_key.c:202: if (IS_QK_BASIC(keycode)) {
      00A7D3                       1152 00115$:
      00A7D3 90 0C 4C         [24] 1153 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_204
      00A7D6 12 43 C5         [24] 1154 	lcall	_ak820_outline_0000
      00A7D9 12 56 D7         [24] 1155 	lcall	_ak820_outline_0045
      00A7DC E4               [12] 1156 	clr	a
      00A7DD 9D               [12] 1157 	subb	a,r5
      00A7DE 50 03            [24] 1158 	jnc	00180$
      00A7E0 02 A8 70         [24] 1159 	ljmp	00114$
      00A7E3                       1160 00180$:
                                   1161 ;	free result
                                   1162 ;	quantum/repeat_key.c:203: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A7E3 90 0C 4E         [24] 1163 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A7E6 E0               [24] 1164 	movx	a,@dptr
      00A7E7 54 0D            [12] 1165 	anl	a,#0x0d
      00A7E9 60 21            [24] 1166 	jz	00107$
                                   1167 ;	quantum/repeat_key.c:218: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A7EB 8E 05            [24] 1168 	mov	ar5,r6
      00A7ED 90 0C 47         [24] 1169 	mov	dptr,#_find_alt_keycode_PARM_2
      00A7F0 74 0A            [12] 1170 	mov	a,#0x0a
      00A7F2 F0               [24] 1171 	movx	@dptr,a
      00A7F3 90 0C 48         [24] 1172 	mov	dptr,#_find_alt_keycode_PARM_3
      00A7F6 ED               [12] 1173 	mov	a,r5
      00A7F7 F0               [24] 1174 	movx	@dptr,a
      00A7F8 90 C1 DE         [24] 1175 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_212
      00A7FB 75 F0 80         [24] 1176 	mov	b, #0x80
      00A7FE 12 A7 0D         [24] 1177 	lcall	_find_alt_keycode
      00A801 AD 82            [24] 1178 	mov	r5, dpl
      00A803 90 0C 4F         [24] 1179 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A806 ED               [12] 1180 	mov	a,r5
      00A807 12 4E 60         [24] 1181 	lcall	_ak820_outline_0003
      00A80A 80 1D            [24] 1182 	sjmp	00108$
      00A80C                       1183 00107$:
                                   1184 ;	quantum/repeat_key.c:231: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A80C 90 0C 47         [24] 1185 	mov	dptr,#_find_alt_keycode_PARM_2
      00A80F 74 08            [12] 1186 	mov	a,#0x08
      00A811 F0               [24] 1187 	movx	@dptr,a
      00A812 90 0C 48         [24] 1188 	mov	dptr,#_find_alt_keycode_PARM_3
      00A815 EE               [12] 1189 	mov	a,r6
      00A816 F0               [24] 1190 	movx	@dptr,a
      00A817 90 C1 E8         [24] 1191 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_213
      00A81A 75 F0 80         [24] 1192 	mov	b, #0x80
      00A81D 12 A7 0D         [24] 1193 	lcall	_find_alt_keycode
      00A820 AF 82            [24] 1194 	mov	r7, dpl
      00A822 90 0C 4F         [24] 1195 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A825 EF               [12] 1196 	mov	a,r7
      00A826 12 4E 60         [24] 1197 	lcall	_ak820_outline_0003
      00A829                       1198 00108$:
                                   1199 ;	quantum/repeat_key.c:234: if (!alt_keycode) {
      00A829 90 0C 4F         [24] 1200 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A82C 12 6D E3         [24] 1201 	lcall	_ak820_outline_0018
      00A82F 70 22            [24] 1202 	jnz	00110$
                                   1203 ;	quantum/repeat_key.c:259: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A831 90 0C 4C         [24] 1204 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_204
      00A834 E0               [24] 1205 	movx	a,@dptr
      00A835 FF               [12] 1206 	mov	r7,a
      00A836 90 0C 47         [24] 1207 	mov	dptr,#_find_alt_keycode_PARM_2
      00A839 74 16            [12] 1208 	mov	a,#0x16
      00A83B F0               [24] 1209 	movx	@dptr,a
      00A83C 90 0C 48         [24] 1210 	mov	dptr,#_find_alt_keycode_PARM_3
      00A83F EF               [12] 1211 	mov	a,r7
      00A840 F0               [24] 1212 	movx	@dptr,a
      00A841 90 C1 F0         [24] 1213 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A844 75 F0 80         [24] 1214 	mov	b, #0x80
      00A847 12 A7 0D         [24] 1215 	lcall	_find_alt_keycode
      00A84A AF 82            [24] 1216 	mov	r7, dpl
      00A84C 90 0C 4F         [24] 1217 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A84F EF               [12] 1218 	mov	a,r7
      00A850 12 4E 60         [24] 1219 	lcall	_ak820_outline_0003
      00A853                       1220 00110$:
                                   1221 ;	quantum/repeat_key.c:262: if (alt_keycode) {
      00A853 90 0C 4F         [24] 1222 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A856 12 43 C5         [24] 1223 	lcall	_ak820_outline_0000
      00A859 90 0C 4F         [24] 1224 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_204
      00A85C 12 6D E3         [24] 1225 	lcall	_ak820_outline_0018
      00A85F 60 0F            [24] 1226 	jz	00114$
                                   1227 ;	quantum/repeat_key.c:264: return (mods << 8) | alt_keycode;
      00A861 90 0C 4E         [24] 1228 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_204
      00A864 E0               [24] 1229 	movx	a,@dptr
      00A865 FD               [12] 1230 	mov	r5,a
      00A866 E4               [12] 1231 	clr	a
      00A867 42 06            [12] 1232 	orl	ar6,a
      00A869 ED               [12] 1233 	mov	a,r5
      00A86A 42 07            [12] 1234 	orl	ar7,a
      00A86C 12 43 D3         [24] 1235 	lcall	_ak820_outline_0002
      00A86F 22               [24] 1236 	ret
      00A870                       1237 00114$:
                                   1238 ;	quantum/repeat_key.c:268: return KC_NO; // No alternate key found.
      00A870 90 00 00         [24] 1239 	mov	dptr,#0x0000
                                   1240 ;	quantum/repeat_key.c:269: }
      00A873 22               [24] 1241 	ret
                                   1242 ;------------------------------------------------------------
                                   1243 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1244 ;------------------------------------------------------------
                                   1245 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_218'
                                   1246 ;------------------------------------------------------------
                                   1247 ;	quantum/repeat_key.c:271: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1248 ;	-----------------------------------------
                                   1249 ;	 function alt_repeat_key_invoke
                                   1250 ;	-----------------------------------------
      00A874                       1251 _alt_repeat_key_invoke:
      00A874 12 43 D8         [24] 1252 	lcall	_ak820_outline_0004
      00A877 90 0C 51         [24] 1253 	mov	dptr,#_alt_repeat_key_invoke_event_10000_218
      00A87A 12 43 CB         [24] 1254 	lcall	_ak820_outline_0001
                                   1255 ;	quantum/repeat_key.c:273: repeat_invoke(event, true);
      00A87D 90 0C 51         [24] 1256 	mov	dptr,#_alt_repeat_key_invoke_event_10000_218
      00A880 E0               [24] 1257 	movx	a,@dptr
      00A881 FD               [12] 1258 	mov	r5,a
      00A882 A3               [24] 1259 	inc	dptr
      00A883 12 43 C5         [24] 1260 	lcall	_ak820_outline_0000
      00A886 90 0C 40         [24] 1261 	mov	dptr,#_repeat_invoke_PARM_2
      00A889 74 01            [12] 1262 	mov	a,#0x01
      00A88B F0               [24] 1263 	movx	@dptr,a
      00A88C 12 4E 65         [24] 1264 	lcall	_ak820_outline_0005
                                   1265 ;	quantum/repeat_key.c:274: }
      00A88F 02 A5 DB         [24] 1266 	ljmp	_repeat_invoke
                                   1267 ;------------------------------------------------------------
                                   1268 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1269 ;------------------------------------------------------------
                                   1270 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1271 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_220'
                                   1272 ;------------------------------------------------------------
                                   1273 ;	quantum/repeat_key.c:277: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1274 ;	-----------------------------------------
                                   1275 ;	 function get_alt_repeat_key_keycode_user
                                   1276 ;	-----------------------------------------
      00A892                       1277 _get_alt_repeat_key_keycode_user:
                                   1278 ;	quantum/repeat_key.c:278: return KC_TRANSPARENT;
      00A892 90 00 01         [24] 1279 	mov	dptr,#0x0001
                                   1280 ;	quantum/repeat_key.c:279: }
      00A895 22               [24] 1281 	ret
                                   1282 	.area CSEG    (CODE)
                                   1283 	.area CONST   (CODE)
                                   1284 	.area CONST   (CODE)
      00C1DE                       1285 _get_alt_repeat_key_keycode_pairs_50000_212:
      00C1DE 09                    1286 	.db #0x09	; 9
      00C1DF 05                    1287 	.db #0x05	; 5
      00C1E0 07                    1288 	.db #0x07	; 7
      00C1E1 18                    1289 	.db #0x18	; 24
      00C1E2 11                    1290 	.db #0x11	; 17
      00C1E3 13                    1291 	.db #0x13	; 19
      00C1E4 04                    1292 	.db #0x04	; 4
      00C1E5 08                    1293 	.db #0x08	; 8
      00C1E6 12                    1294 	.db #0x12	; 18
      00C1E7 0C                    1295 	.db #0x0c	; 12
                                   1296 	.area CSEG    (CODE)
                                   1297 	.area CONST   (CODE)
      00C1E8                       1298 _get_alt_repeat_key_keycode_pairs_50000_213:
      00C1E8 0D                    1299 	.db #0x0d	; 13
      00C1E9 0E                    1300 	.db #0x0e	; 14
      00C1EA 0B                    1301 	.db #0x0b	; 11
      00C1EB 0F                    1302 	.db #0x0f	; 15
      00C1EC 1A                    1303 	.db #0x1a	; 26
      00C1ED 05                    1304 	.db #0x05	; 5
      00C1EE 08                    1305 	.db #0x08	; 8
      00C1EF 05                    1306 	.db #0x05	; 5
                                   1307 	.area CSEG    (CODE)
                                   1308 	.area CONST   (CODE)
      00C1F0                       1309 _get_alt_repeat_key_keycode_pairs_50000_215:
      00C1F0 50                    1310 	.db #0x50	; 80	'P'
      00C1F1 4F                    1311 	.db #0x4f	; 79	'O'
      00C1F2 52                    1312 	.db #0x52	; 82	'R'
      00C1F3 51                    1313 	.db #0x51	; 81	'Q'
      00C1F4 4A                    1314 	.db #0x4a	; 74	'J'
      00C1F5 4D                    1315 	.db #0x4d	; 77	'M'
      00C1F6 4B                    1316 	.db #0x4b	; 75	'K'
      00C1F7 4E                    1317 	.db #0x4e	; 78	'N'
      00C1F8 2A                    1318 	.db #0x2a	; 42
      00C1F9 4C                    1319 	.db #0x4c	; 76	'L'
      00C1FA 2F                    1320 	.db #0x2f	; 47
      00C1FB 30                    1321 	.db #0x30	; 48	'0'
      00C1FC B6                    1322 	.db #0xb6	; 182
      00C1FD B7                    1323 	.db #0xb7	; 183
      00C1FE AB                    1324 	.db #0xab	; 171
      00C1FF AC                    1325 	.db #0xac	; 172
      00C200 BB                    1326 	.db #0xbb	; 187
      00C201 BC                    1327 	.db #0xbc	; 188
      00C202 A9                    1328 	.db #0xa9	; 169
      00C203 AA                    1329 	.db #0xaa	; 170
      00C204 BD                    1330 	.db #0xbd	; 189
      00C205 BE                    1331 	.db #0xbe	; 190
                                   1332 	.area CSEG    (CODE)
                                   1333 	.area XINIT   (CODE)
      00C675                       1334 __xinit__last_mods:
      00C675 00                    1335 	.db #0x00	; 0
      00C676                       1336 __xinit__last_repeat_count:
      00C676 00                    1337 	.db #0x00	;  0
      00C677                       1338 __xinit__processing_repeat_count:
      00C677 00                    1339 	.db #0x00	;  0
                                   1340 	.area CABS    (ABS,CODE)
                                   1341 
                                   1342 ; Experimental exact instruction outlining.
                                   1343 	.globl _ak820_outline_0000
                                   1344 	.globl _ak820_outline_0001
                                   1345 	.globl _ak820_outline_0002
                                   1346 	.globl _ak820_outline_0003
                                   1347 	.globl _ak820_outline_0004
                                   1348 	.globl _ak820_outline_0005
                                   1349 	.globl _ak820_outline_0007
                                   1350 	.globl _ak820_outline_0009
                                   1351 	.globl _ak820_outline_0010
                                   1352 	.globl _ak820_outline_0011
                                   1353 	.globl _ak820_outline_0016
                                   1354 	.globl _ak820_outline_0018
                                   1355 	.globl _ak820_outline_0023
                                   1356 	.globl _ak820_outline_0045
                                   1357 	.globl _ak820_outline_0049
                                   1358 	.globl _ak820_outline_0073
                                   1359 	.globl _ak820_outline_0098
                                   1360 	.globl _ak820_outline_0132
                                   1361 	.globl _ak820_outline_0136
                                   1362 	.globl _ak820_outline_0149
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0136
      00A896                       1366 _ak820_outline_0136:
      00A896 90 0C 35         [24] 1367 	mov	dptr,#(_registered_record+0x0007)
      00A899 E0               [24] 1368 	movx	a,@dptr
      00A89A FB               [12] 1369 	mov	r3,a
      00A89B A3               [24] 1370 	inc	dptr
      00A89C E0               [24] 1371 	movx	a,@dptr
      00A89D 4B               [12] 1372 	orl	a,r3
      00A89E 22               [24] 1373 	ret
