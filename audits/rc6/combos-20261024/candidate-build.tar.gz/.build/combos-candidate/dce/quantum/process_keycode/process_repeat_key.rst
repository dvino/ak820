                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_weak_mods
                                     12 	.globl _get_mods
                                     13 	.globl _alt_repeat_key_invoke
                                     14 	.globl _repeat_key_invoke
                                     15 	.globl _get_repeat_key_count
                                     16 	.globl _set_last_record
                                     17 	.globl _set_last_mods
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _process_repeat_key_PARM_2
                                    262 	.globl _process_last_key_PARM_2
                                    263 	.globl _remember_last_key_user_PARM_3
                                    264 	.globl _remember_last_key_user_PARM_2
                                    265 	.globl _remember_last_key_user
                                    266 	.globl _process_last_key
                                    267 	.globl _process_repeat_key
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BBA                        554 _remember_last_key_user_PARM_2:
      000BBA                        555 	.ds 3
      000BBD                        556 _remember_last_key_user_PARM_3:
      000BBD                        557 	.ds 3
      000BC0                        558 _remember_last_key_PARM_2:
      000BC0                        559 	.ds 3
      000BC3                        560 _remember_last_key_PARM_3:
      000BC3                        561 	.ds 3
      000BC6                        562 _remember_last_key_keycode_10000_238:
      000BC6                        563 	.ds 2
      000BC8                        564 _process_last_key_PARM_2:
      000BC8                        565 	.ds 3
      000BCB                        566 _process_last_key_keycode_10000_241:
      000BCB                        567 	.ds 2
      000BCD                        568 _process_last_key_remembered_mods_30000_246:
      000BCD                        569 	.ds 1
      000BCE                        570 _process_repeat_key_PARM_2:
      000BCE                        571 	.ds 3
      000BD1                        572 _process_repeat_key_keycode_10000_249:
      000BD1                        573 	.ds 2
                                    574 ;--------------------------------------------------------
                                    575 ; absolute external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area XABS    (ABS,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; initialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XISEG   (XDATA)
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    610 ;------------------------------------------------------------
                                    611 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_164'
                                    612 ;------------------------------------------------------------
                                    613 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function remember_last_key_user
                                    624 ;	-----------------------------------------
      009C78                        625 _remember_last_key_user:
                                    626 ;	quantum/process_keycode/process_repeat_key.c:23: return true;
      009C78 75 82 01         [24]  627 	mov	dpl, #0x01
                                    628 ;	quantum/process_keycode/process_repeat_key.c:24: }
      009C7B 22               [24]  629 	ret
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'remember_last_key'
                                    632 ;------------------------------------------------------------
                                    633 ;record        Allocated with name '_remember_last_key_PARM_2'
                                    634 ;remembered_mods Allocated with name '_remember_last_key_PARM_3'
                                    635 ;keycode       Allocated with name '_remember_last_key_keycode_10000_238'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/process_keycode/process_repeat_key.c:26: static bool remember_last_key(uint16_t keycode, keyrecord_t* record, uint8_t* remembered_mods) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function remember_last_key
                                    640 ;	-----------------------------------------
      009C7C                        641 _remember_last_key:
      009C7C 12 43 EA         [24]  642 	lcall	_ak820_outline_0010
      009C7F 90 0B C6         [24]  643 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C82 12 43 E5         [24]  644 	lcall	_ak820_outline_0007
                                    645 ;	quantum/process_keycode/process_repeat_key.c:29: if (keycode == KC_NO || keycode == KC_TRANSPARENT ||
      009C85 90 0B C6         [24]  646 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C88 12 43 C5         [24]  647 	lcall	_ak820_outline_0000
      009C8B 90 0B C6         [24]  648 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C8E 12 6D E3         [24]  649 	lcall	_ak820_outline_0018
      009C91 70 03            [24]  650 	jnz	00224$
      009C93 02 9D 4D         [24]  651 	ljmp	00101$
      009C96                        652 00224$:
      009C96 BE 01 06         [24]  653 	cjne	r6,#0x01,00225$
      009C99 BF 00 03         [24]  654 	cjne	r7,#0x00,00225$
      009C9C 02 9D 4D         [24]  655 	ljmp	00101$
      009C9F                        656 00225$:
                                    657 ;	quantum/process_keycode/process_repeat_key.c:30: (keycode >= QK_MOMENTARY && keycode <= QK_MOMENTARY_MAX) ||
      009C9F C3               [12]  658 	clr	c
      009CA0 EE               [12]  659 	mov	a,r6
      009CA1 94 20            [12]  660 	subb	a,#0x20
      009CA3 EF               [12]  661 	mov	a,r7
      009CA4 94 52            [12]  662 	subb	a,#0x52
      009CA6 40 0B            [24]  663 	jc	00107$
      009CA8 74 3F            [12]  664 	mov	a,#0x3f
      009CAA 9E               [12]  665 	subb	a,r6
      009CAB 74 52            [12]  666 	mov	a,#0x52
      009CAD 9F               [12]  667 	subb	a,r7
      009CAE 40 03            [24]  668 	jc	00227$
      009CB0 02 9D 4D         [24]  669 	ljmp	00101$
      009CB3                        670 00227$:
                                    671 ;	free result
      009CB3                        672 00107$:
                                    673 ;	quantum/process_keycode/process_repeat_key.c:31: (keycode >= QK_LAYER_MOD && keycode <= QK_LAYER_MOD_MAX) ||
      009CB3 90 0B C6         [24]  674 	mov	dptr,#_remember_last_key_keycode_10000_238
      009CB6 12 43 C5         [24]  675 	lcall	_ak820_outline_0000
      009CB9 C3               [12]  676 	clr	c
      009CBA 94 50            [12]  677 	subb	a,#0x50
      009CBC 40 0B            [24]  678 	jc	00109$
      009CBE 74 FF            [12]  679 	mov	a,#0xff
      009CC0 9E               [12]  680 	subb	a,r6
      009CC1 74 51            [12]  681 	mov	a,#0x51
      009CC3 9F               [12]  682 	subb	a,r7
      009CC4 40 03            [24]  683 	jc	00229$
      009CC6 02 9D 4D         [24]  684 	ljmp	00101$
      009CC9                        685 00229$:
                                    686 ;	free result
      009CC9                        687 00109$:
                                    688 ;	quantum/process_keycode/process_repeat_key.c:32: (keycode >= QK_DEF_LAYER && keycode <= QK_DEF_LAYER_MAX) ||
      009CC9 C3               [12]  689 	clr	c
      009CCA EE               [12]  690 	mov	a,r6
      009CCB 94 40            [12]  691 	subb	a,#0x40
      009CCD EF               [12]  692 	mov	a,r7
      009CCE 94 52            [12]  693 	subb	a,#0x52
      009CD0 40 08            [24]  694 	jc	00111$
      009CD2 74 5F            [12]  695 	mov	a,#0x5f
      009CD4 9E               [12]  696 	subb	a,r6
      009CD5 74 52            [12]  697 	mov	a,#0x52
      009CD7 9F               [12]  698 	subb	a,r7
      009CD8 50 73            [24]  699 	jnc	00101$
                                    700 ;	free result
      009CDA                        701 00111$:
                                    702 ;	quantum/process_keycode/process_repeat_key.c:33: (keycode >= QK_TO && keycode <= QK_TO_MAX) ||
      009CDA 74 AE            [12]  703 	mov	a,#0x100 - 0x52
      009CDC 2F               [12]  704 	add	a,r7
      009CDD 50 09            [24]  705 	jnc	00113$
      009CDF C3               [12]  706 	clr	c
      009CE0 74 1F            [12]  707 	mov	a,#0x1f
      009CE2 9E               [12]  708 	subb	a,r6
      009CE3 74 52            [12]  709 	mov	a,#0x52
      009CE5 9F               [12]  710 	subb	a,r7
      009CE6 50 65            [24]  711 	jnc	00101$
                                    712 ;	free result
      009CE8                        713 00113$:
                                    714 ;	quantum/process_keycode/process_repeat_key.c:34: (keycode >= QK_TOGGLE_LAYER && keycode <= QK_TOGGLE_LAYER_MAX) ||
      009CE8 C3               [12]  715 	clr	c
      009CE9 EE               [12]  716 	mov	a,r6
      009CEA 94 60            [12]  717 	subb	a,#0x60
      009CEC EF               [12]  718 	mov	a,r7
      009CED 94 52            [12]  719 	subb	a,#0x52
      009CEF 40 08            [24]  720 	jc	00115$
      009CF1 74 7F            [12]  721 	mov	a,#0x7f
      009CF3 9E               [12]  722 	subb	a,r6
      009CF4 74 52            [12]  723 	mov	a,#0x52
      009CF6 9F               [12]  724 	subb	a,r7
      009CF7 50 54            [24]  725 	jnc	00101$
                                    726 ;	free result
      009CF9                        727 00115$:
                                    728 ;	quantum/process_keycode/process_repeat_key.c:35: (keycode >= QK_LAYER_TAP_TOGGLE && keycode <= QK_LAYER_TAP_TOGGLE_MAX) ||
      009CF9 C3               [12]  729 	clr	c
      009CFA EE               [12]  730 	mov	a,r6
      009CFB 94 C0            [12]  731 	subb	a,#0xc0
      009CFD EF               [12]  732 	mov	a,r7
      009CFE 94 52            [12]  733 	subb	a,#0x52
      009D00 40 08            [24]  734 	jc	00117$
      009D02 74 DF            [12]  735 	mov	a,#0xdf
      009D04 9E               [12]  736 	subb	a,r6
      009D05 74 52            [12]  737 	mov	a,#0x52
      009D07 9F               [12]  738 	subb	a,r7
      009D08 50 43            [24]  739 	jnc	00101$
                                    740 ;	free result
      009D0A                        741 00117$:
                                    742 ;	quantum/process_keycode/process_repeat_key.c:36: (keycode >= KC_LCTL && keycode <= KC_RGUI) ||
      009D0A 12 9E 51         [24]  743 	lcall	_ak820_outline_0085
      009D0D 40 07            [24]  744 	jc	00118$
      009D0F 74 E7            [12]  745 	mov	a,#0xe7
      009D11 9E               [12]  746 	subb	a,r6
      009D12 E4               [12]  747 	clr	a
      009D13 9F               [12]  748 	subb	a,r7
      009D14 50 37            [24]  749 	jnc	00101$
                                    750 ;	free result
      009D16                        751 00118$:
                                    752 ;	quantum/process_keycode/process_repeat_key.c:37: keycode == KC_HYPR || keycode == KC_MEH || keycode == QK_REPEAT_KEY
      009D16 90 0B C6         [24]  753 	mov	dptr,#_remember_last_key_keycode_10000_238
      009D19 12 43 C5         [24]  754 	lcall	_ak820_outline_0000
      009D1C 12 44 62         [24]  755 	lcall	_ak820_outline_0073
      009D1F BC 00 05         [24]  756 	cjne	r4,#0x00,00240$
      009D22 BD 0F 02         [24]  757 	cjne	r5,#0x0f,00240$
      009D25 80 26            [24]  758 	sjmp	00101$
      009D27                        759 00240$:
      009D27 BC 00 05         [24]  760 	cjne	r4,#0x00,00241$
      009D2A BD 07 02         [24]  761 	cjne	r5,#0x07,00241$
      009D2D 80 1E            [24]  762 	sjmp	00101$
      009D2F                        763 00241$:
                                    764 ;	quantum/process_keycode/process_repeat_key.c:39: || keycode == QK_ALT_REPEAT_KEY
      009D2F BC 79 05         [24]  765 	cjne	r4,#0x79,00242$
      009D32 BD 7C 02         [24]  766 	cjne	r5,#0x7c,00242$
      009D35 80 16            [24]  767 	sjmp	00101$
      009D37                        768 00242$:
                                    769 ;	quantum/process_keycode/process_repeat_key.c:46: || keycode == QK_TRI_LAYER_LOWER || keycode == QK_TRI_LAYER_UPPER
      009D37 BC 7A 05         [24]  770 	cjne	r4,#0x7a,00243$
      009D3A BD 7C 02         [24]  771 	cjne	r5,#0x7c,00243$
      009D3D 80 0E            [24]  772 	sjmp	00101$
      009D3F                        773 00243$:
      009D3F BC 77 05         [24]  774 	cjne	r4,#0x77,00244$
      009D42 BD 7C 02         [24]  775 	cjne	r5,#0x7c,00244$
      009D45 80 06            [24]  776 	sjmp	00101$
      009D47                        777 00244$:
                                    778 ;	quantum/process_keycode/process_repeat_key.c:48: ) return false;
      009D47 BC 78 07         [24]  779 	cjne	r4,#0x78,00102$
      009D4A BD 7C 04         [24]  780 	cjne	r5,#0x7c,00102$
      009D4D                        781 00101$:
      009D4D 75 82 00         [24]  782 	mov	dpl, #0x00
      009D50 22               [24]  783 	ret
      009D51                        784 00102$:
                                    785 ;	quantum/process_keycode/process_repeat_key.c:61: return remember_last_key_user(keycode, record, remembered_mods);
      009D51 90 0B C0         [24]  786 	mov	dptr,#_remember_last_key_PARM_2
      009D54 E0               [24]  787 	movx	a,@dptr
      009D55 FB               [12]  788 	mov	r3,a
      009D56 A3               [24]  789 	inc	dptr
      009D57 12 43 DF         [24]  790 	lcall	_ak820_outline_0006
      009D5A 90 0B C3         [24]  791 	mov	dptr,#_remember_last_key_PARM_3
      009D5D 12 44 5C         [24]  792 	lcall	_ak820_outline_0072
      009D60 A3               [24]  793 	inc	dptr
      009D61 E0               [24]  794 	movx	a,@dptr
      009D62 FA               [12]  795 	mov	r2,a
      009D63 90 0B BA         [24]  796 	mov	dptr,#_remember_last_key_user_PARM_2
      009D66 12 99 F3         [24]  797 	lcall	_ak820_outline_0008
      009D69 90 0B BD         [24]  798 	mov	dptr,#_remember_last_key_user_PARM_3
      009D6C E8               [12]  799 	mov	a,r0
      009D6D F0               [24]  800 	movx	@dptr,a
      009D6E E9               [12]  801 	mov	a,r1
      009D6F A3               [24]  802 	inc	dptr
      009D70 F0               [24]  803 	movx	@dptr,a
      009D71 EA               [12]  804 	mov	a,r2
      009D72 A3               [24]  805 	inc	dptr
      009D73 F0               [24]  806 	movx	@dptr,a
      009D74 12 43 D3         [24]  807 	lcall	_ak820_outline_0002
                                    808 ;	quantum/process_keycode/process_repeat_key.c:62: }
      009D77 02 9C 78         [24]  809 	ljmp	_remember_last_key_user
                                    810 ;------------------------------------------------------------
                                    811 ;Allocation info for local variables in function 'process_last_key'
                                    812 ;------------------------------------------------------------
                                    813 ;record        Allocated with name '_process_last_key_PARM_2'
                                    814 ;keycode       Allocated with name '_process_last_key_keycode_10000_241'
                                    815 ;remembered_mods Allocated with name '_process_last_key_remembered_mods_30000_246'
                                    816 ;------------------------------------------------------------
                                    817 ;	quantum/process_keycode/process_repeat_key.c:64: bool process_last_key(uint16_t keycode, keyrecord_t* record) {
                                    818 ;	-----------------------------------------
                                    819 ;	 function process_last_key
                                    820 ;	-----------------------------------------
      009D7A                        821 _process_last_key:
      009D7A 12 43 EA         [24]  822 	lcall	_ak820_outline_0010
      009D7D 90 0B CB         [24]  823 	mov	dptr,#_process_last_key_keycode_10000_241
      009D80 12 43 E5         [24]  824 	lcall	_ak820_outline_0007
                                    825 ;	quantum/process_keycode/process_repeat_key.c:65: if (get_repeat_key_count()) {
      009D83 12 A5 D4         [24]  826 	lcall	_get_repeat_key_count
      009D86 E5 82            [12]  827 	mov	a, dpl
      009D88 60 04            [24]  828 	jz	00102$
                                    829 ;	quantum/process_keycode/process_repeat_key.c:66: return true;
      009D8A 75 82 01         [24]  830 	mov	dpl, #0x01
      009D8D 22               [24]  831 	ret
      009D8E                        832 00102$:
                                    833 ;	quantum/process_keycode/process_repeat_key.c:69: if (record->event.pressed) {
      009D8E 90 0B C8         [24]  834 	mov	dptr,#_process_last_key_PARM_2
      009D91 E0               [24]  835 	movx	a,@dptr
      009D92 FD               [12]  836 	mov	r5,a
      009D93 A3               [24]  837 	inc	dptr
      009D94 12 43 C5         [24]  838 	lcall	_ak820_outline_0000
      009D97 74 05            [12]  839 	mov	a,#0x05
      009D99 12 76 A5         [24]  840 	lcall	_ak820_outline_0009
      009D9C 12 BE 14         [24]  841 	lcall	__gptrget
      009D9F 60 5A            [24]  842 	jz	00106$
                                    843 ;	quantum/process_keycode/process_repeat_key.c:70: uint8_t remembered_mods = get_mods() | get_weak_mods();
      009DA1 12 80 DD         [24]  844 	lcall	_get_mods
      009DA4 AC 82            [24]  845 	mov	r4, dpl
      009DA6 12 80 F3         [24]  846 	lcall	_get_weak_mods
      009DA9 AB 82            [24]  847 	mov	r3, dpl
      009DAB 90 0B CD         [24]  848 	mov	dptr,#_process_last_key_remembered_mods_30000_246
      009DAE EB               [12]  849 	mov	a,r3
      009DAF 4C               [12]  850 	orl	a,r4
      009DB0 F0               [24]  851 	movx	@dptr,a
                                    852 ;	quantum/process_keycode/process_repeat_key.c:75: if (remember_last_key(keycode, record, &remembered_mods)) {
      009DB1 90 0B CB         [24]  853 	mov	dptr,#_process_last_key_keycode_10000_241
      009DB4 12 44 73         [24]  854 	lcall	_ak820_outline_0089
      009DB7 90 0B C0         [24]  855 	mov	dptr,#_remember_last_key_PARM_2
      009DBA ED               [12]  856 	mov	a,r5
      009DBB 12 43 CB         [24]  857 	lcall	_ak820_outline_0001
      009DBE 90 0B C3         [24]  858 	mov	dptr,#_remember_last_key_PARM_3
      009DC1 74 CD            [12]  859 	mov	a,#_process_last_key_remembered_mods_30000_246
      009DC3 F0               [24]  860 	movx	@dptr,a
      009DC4 74 0B            [12]  861 	mov	a,#(_process_last_key_remembered_mods_30000_246 >> 8)
      009DC6 A3               [24]  862 	inc	dptr
      009DC7 12 4E 60         [24]  863 	lcall	_ak820_outline_0003
      009DCA 12 43 F9         [24]  864 	lcall	_ak820_outline_0014
      009DCD C0 04            [24]  865 	push	ar4
      009DCF C0 03            [24]  866 	push	ar3
      009DD1 12 9C 7C         [24]  867 	lcall	_remember_last_key
      009DD4 E5 82            [12]  868 	mov	a, dpl
      009DD6 D0 03            [24]  869 	pop	ar3
      009DD8 D0 04            [24]  870 	pop	ar4
      009DDA 60 1F            [24]  871 	jz	00106$
                                    872 ;	quantum/process_keycode/process_repeat_key.c:76: set_last_record(keycode, record);
      009DDC 90 0B C8         [24]  873 	mov	dptr,#_process_last_key_PARM_2
      009DDF E0               [24]  874 	movx	a,@dptr
      009DE0 FD               [12]  875 	mov	r5,a
      009DE1 A3               [24]  876 	inc	dptr
      009DE2 12 43 C5         [24]  877 	lcall	_ak820_outline_0000
      009DE5 90 0C 3A         [24]  878 	mov	dptr,#_set_last_record_PARM_2
      009DE8 ED               [12]  879 	mov	a,r5
      009DE9 12 43 CB         [24]  880 	lcall	_ak820_outline_0001
      009DEC 12 43 F9         [24]  881 	lcall	_ak820_outline_0014
      009DEF 12 A5 4F         [24]  882 	lcall	_set_last_record
                                    883 ;	quantum/process_keycode/process_repeat_key.c:77: set_last_mods(remembered_mods);
      009DF2 90 0B CD         [24]  884 	mov	dptr,#_process_last_key_remembered_mods_30000_246
      009DF5 E0               [24]  885 	movx	a,@dptr
      009DF6 F5 82            [12]  886 	mov	dpl,a
      009DF8 12 A5 43         [24]  887 	lcall	_set_last_mods
      009DFB                        888 00106$:
                                    889 ;	quantum/process_keycode/process_repeat_key.c:81: return true;
      009DFB 75 82 01         [24]  890 	mov	dpl, #0x01
                                    891 ;	quantum/process_keycode/process_repeat_key.c:82: }
      009DFE 22               [24]  892 	ret
                                    893 ;------------------------------------------------------------
                                    894 ;Allocation info for local variables in function 'process_repeat_key'
                                    895 ;------------------------------------------------------------
                                    896 ;record        Allocated with name '_process_repeat_key_PARM_2'
                                    897 ;keycode       Allocated with name '_process_repeat_key_keycode_10000_249'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/process_keycode/process_repeat_key.c:84: bool process_repeat_key(uint16_t keycode, keyrecord_t* record) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function process_repeat_key
                                    902 ;	-----------------------------------------
      009DFF                        903 _process_repeat_key:
      009DFF 12 43 EA         [24]  904 	lcall	_ak820_outline_0010
      009E02 90 0B D1         [24]  905 	mov	dptr,#_process_repeat_key_keycode_10000_249
      009E05 12 43 E5         [24]  906 	lcall	_ak820_outline_0007
                                    907 ;	quantum/process_keycode/process_repeat_key.c:85: if (get_repeat_key_count()) {
      009E08 12 A5 D4         [24]  908 	lcall	_get_repeat_key_count
      009E0B E5 82            [12]  909 	mov	a, dpl
      009E0D 60 04            [24]  910 	jz	00102$
                                    911 ;	quantum/process_keycode/process_repeat_key.c:86: return true;
      009E0F 75 82 01         [24]  912 	mov	dpl, #0x01
      009E12 22               [24]  913 	ret
      009E13                        914 00102$:
                                    915 ;	quantum/process_keycode/process_repeat_key.c:89: if (keycode == QK_REPEAT_KEY) {
      009E13 90 0B D1         [24]  916 	mov	dptr,#_process_repeat_key_keycode_10000_249
      009E16 12 43 C5         [24]  917 	lcall	_ak820_outline_0000
      009E19 BE 79 18         [24]  918 	cjne	r6,#0x79,00106$
      009E1C BF 7C 15         [24]  919 	cjne	r7,#0x7c,00106$
                                    920 ;	quantum/process_keycode/process_repeat_key.c:90: repeat_key_invoke(&record->event);
      009E1F 90 0B CE         [24]  921 	mov	dptr,#_process_repeat_key_PARM_2
      009E22 E0               [24]  922 	movx	a,@dptr
      009E23 FB               [12]  923 	mov	r3,a
      009E24 A3               [24]  924 	inc	dptr
      009E25 12 43 DF         [24]  925 	lcall	_ak820_outline_0006
      009E28 12 43 F9         [24]  926 	lcall	_ak820_outline_0014
      009E2B 8D F0            [24]  927 	mov	b, r5
      009E2D 12 A6 F0         [24]  928 	lcall	_repeat_key_invoke
                                    929 ;	quantum/process_keycode/process_repeat_key.c:91: return false;
      009E30 75 82 00         [24]  930 	mov	dpl, #0x00
      009E33 22               [24]  931 	ret
      009E34                        932 00106$:
                                    933 ;	quantum/process_keycode/process_repeat_key.c:93: } else if (keycode == QK_ALT_REPEAT_KEY) {
      009E34 BE 7A 16         [24]  934 	cjne	r6,#0x7a,00107$
      009E37 BF 7C 13         [24]  935 	cjne	r7,#0x7c,00107$
                                    936 ;	quantum/process_keycode/process_repeat_key.c:94: alt_repeat_key_invoke(&record->event);
      009E3A 90 0B CE         [24]  937 	mov	dptr,#_process_repeat_key_PARM_2
      009E3D E0               [24]  938 	movx	a,@dptr
      009E3E FD               [12]  939 	mov	r5,a
      009E3F A3               [24]  940 	inc	dptr
      009E40 12 43 C5         [24]  941 	lcall	_ak820_outline_0000
      009E43 12 4E 65         [24]  942 	lcall	_ak820_outline_0005
      009E46 12 A8 74         [24]  943 	lcall	_alt_repeat_key_invoke
                                    944 ;	quantum/process_keycode/process_repeat_key.c:95: return false;
      009E49 75 82 00         [24]  945 	mov	dpl, #0x00
      009E4C 22               [24]  946 	ret
      009E4D                        947 00107$:
                                    948 ;	quantum/process_keycode/process_repeat_key.c:99: return true;
      009E4D 75 82 01         [24]  949 	mov	dpl, #0x01
                                    950 ;	quantum/process_keycode/process_repeat_key.c:100: }
      009E50 22               [24]  951 	ret
                                    952 	.area CSEG    (CODE)
                                    953 	.area CONST   (CODE)
                                    954 	.area XINIT   (CODE)
                                    955 	.area CABS    (ABS,CODE)
                                    956 
                                    957 ; Experimental exact instruction outlining.
                                    958 	.globl _ak820_outline_0000
                                    959 	.globl _ak820_outline_0001
                                    960 	.globl _ak820_outline_0002
                                    961 	.globl _ak820_outline_0003
                                    962 	.globl _ak820_outline_0005
                                    963 	.globl _ak820_outline_0006
                                    964 	.globl _ak820_outline_0007
                                    965 	.globl _ak820_outline_0008
                                    966 	.globl _ak820_outline_0009
                                    967 	.globl _ak820_outline_0010
                                    968 	.globl _ak820_outline_0014
                                    969 	.globl _ak820_outline_0018
                                    970 	.globl _ak820_outline_0072
                                    971 	.globl _ak820_outline_0073
                                    972 	.globl _ak820_outline_0085
                                    973 	.globl _ak820_outline_0089
                                    974 
                                    975 	.area CSEG (CODE)
                                    976 ; function ak820_outline_0085
      009E51                        977 _ak820_outline_0085:
      009E51 C3               [12]  978 	clr	c
      009E52 EE               [12]  979 	mov	a,r6
      009E53 94 E0            [12]  980 	subb	a,#0xe0
      009E55 EF               [12]  981 	mov	a,r7
      009E56 94 00            [12]  982 	subb	a,#0x00
      009E58 22               [24]  983 	ret
