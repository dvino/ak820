                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      00005A                        551 _change_owned_sloc1_1_0:
      00005A                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000019                        566 _ak820_macro_change_sloc0_1_0:
      000019                        567 	.ds 1
      00001A                        568 _change_owned_sloc0_1_0:
      00001A                        569 	.ds 1
      00001B                        570 _owned_usage_key_sloc0_1_0:
      00001B                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000962                        580 _owned_mod_refs:
      000962                        581 	.ds 8
      00096A                        582 _owned_weak_refs:
      00096A                        583 	.ds 8
      000972                        584 _owned_mods:
      000972                        585 	.ds 1
      000973                        586 _owned_weak_mods:
      000973                        587 	.ds 1
      000974                        588 _macro_mods:
      000974                        589 	.ds 2
      000976                        590 _ak820_macro_primitive::
      000976                        591 	.ds 1
      000977                        592 _ak820_macro_cancelled::
      000977                        593 	.ds 1
      000978                        594 _ak820_macro_change_PARM_2:
      000978                        595 	.ds 1
      000979                        596 _ak820_macro_change_PARM_3:
      000979                        597 	.ds 1
      00097A                        598 _ak820_macro_change_bits_10000_287:
      00097A                        599 	.ds 2
      00097C                        600 _change_owned_PARM_2:
      00097C                        601 	.ds 1
      00097D                        602 _change_owned_mods_10000_292:
      00097D                        603 	.ds 1
      00097E                        604 _change_owned_result_10001_296:
      00097E                        605 	.ds 1
      00097F                        606 _change_owned_bit_20001_297:
      00097F                        607 	.ds 1
      000980                        608 _add_owned_mods_mods_10000_305:
      000980                        609 	.ds 1
      000981                        610 _del_owned_mods_mods_10000_307:
      000981                        611 	.ds 1
      000982                        612 _add_owned_weak_mods_mods_10000_309:
      000982                        613 	.ds 1
      000983                        614 _del_owned_weak_mods_mods_10000_311:
      000983                        615 	.ds 1
      000984                        616 _key_refs:
      000984                        617 	.ds 165
      000A29                        618 _distinct_keys:
      000A29                        619 	.ds 1
      000A2A                        620 _macro_keys:
      000A2A                        621 	.ds 21
      000A3F                        622 _add_owned_key_code_10000_320:
      000A3F                        623 	.ds 1
      000A40                        624 _del_owned_key_code_10000_335:
      000A40                        625 	.ds 1
      000A41                        626 _usage_refs:
      000A41                        627 	.ds 30
      000A5F                        628 _usage_order:
      000A5F                        629 	.ds 30
      000A7D                        630 _usage_lengths:
      000A7D                        631 	.ds 2
      000A7F                        632 _macro_usages:
      000A7F                        633 	.ds 4
      000A83                        634 _owned_usage_key_PARM_2:
      000A83                        635 	.ds 1
      000A84                        636 _owned_usage_key_code_10000_362:
      000A84                        637 	.ds 1
      000A85                        638 _owned_usage_key___200000085_20000_363:
      000A85                        639 	.ds 2
      000A87                        640 _owned_usage_key_which_10000_363:
      000A87                        641 	.ds 1
      000A88                        642 _owned_usage_key_count_10000_363:
      000A88                        643 	.ds 1
      000A89                        644 _owned_usage_key_pos_30001_370:
      000A89                        645 	.ds 1
      000A8A                        646 _owned_usage_key_key_40000_375:
      000A8A                        647 	.ds 1
      000A8B                        648 _send_keyboard_report_last_report_10001_382:
      000A8B                        649 	.ds 32
      000AAB                        650 _send_keyboard_report_changed_10001_382:
      000AAB                        651 	.ds 1
      000AAC                        652 _add_weak_mods_mods_10000_400:
      000AAC                        653 	.ds 1
      000AAD                        654 _del_weak_mods_mods_10000_402:
      000AAD                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DD5                        664 _real_mods:
      000DD5                        665 	.ds 1
      000DD6                        666 _weak_mods:
      000DD6                        667 	.ds 1
      000DD7                        668 _actual_keyboard_report::
      000DD7                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007BC9                        713 _ak820_macro_change:
      007BC9 12 43 EA         [24]  714 	lcall	_ak820_outline_0010
      007BCC 90 09 7A         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007BCF 12 43 E5         [24]  716 	lcall	_ak820_outline_0007
                                    717 ;	quantum/action_util.c:40: if (!ak820_macro_primitive) return true;
      007BD2 90 09 76         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007BD5 E0               [24]  719 	movx	a,@dptr
      007BD6 70 04            [24]  720 	jnz	00102$
      007BD8 75 82 01         [24]  721 	mov	dpl, #0x01
      007BDB 22               [24]  722 	ret
      007BDC                        723 00102$:
                                    724 ;	quantum/action_util.c:41: uint8_t mask = 1u << (index & 7);
      007BDC 90 09 78         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007BDF E0               [24]  726 	movx	a,@dptr
      007BE0 FF               [12]  727 	mov	r7,a
      007BE1 74 07            [12]  728 	mov	a,#0x07
      007BE3 5F               [12]  729 	anl	a,r7
      007BE4 12 70 13         [24]  730 	lcall	_ak820_outline_0021
      007BE7 80 02            [24]  731 	sjmp	00123$
      007BE9                        732 00122$:
      007BE9 25 E0            [12]  733 	add	a,acc
      007BEB                        734 00123$:
      007BEB D5 F0 FB         [24]  735 	djnz	b,00122$
      007BEE FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:42: bits += index >> 3;
      007BEF EF               [12]  738 	mov	a,r7
      007BF0 12 57 27         [24]  739 	lcall	_ak820_outline_0133
      007BF3 FF               [12]  740 	mov	r7,a
      007BF4 90 09 7A         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007BF7 12 43 DF         [24]  742 	lcall	_ak820_outline_0006
      007BFA 90 09 7A         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007BFD EF               [12]  744 	mov	a,r7
      007BFE 2C               [12]  745 	add	a, r4
      007BFF F0               [24]  746 	movx	@dptr,a
      007C00 E4               [12]  747 	clr	a
      007C01 3D               [12]  748 	addc	a, r5
      007C02 A3               [24]  749 	inc	dptr
      007C03 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:43: if (((*bits & mask) != 0) == pressed) return false;
      007C04 90 09 7A         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007C07 E0               [24]  753 	movx	a,@dptr
      007C08 FD               [12]  754 	mov	r5,a
      007C09 A3               [24]  755 	inc	dptr
      007C0A E0               [24]  756 	movx	a,@dptr
      007C0B FF               [12]  757 	mov	r7,a
      007C0C 12 81 74         [24]  758 	lcall	_ak820_outline_0148
      007C0F E0               [24]  759 	movx	a,@dptr
      007C10 FC               [12]  760 	mov	r4,a
      007C11 EE               [12]  761 	mov	a,r6
      007C12 5C               [12]  762 	anl	a,r4
      007C13 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007C16                        764 00124$:
      007C16 B3               [12]  765 	cpl	c
      007C17 92 19            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007C19 90 09 79         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007C1C E0               [24]  768 	movx	a,@dptr
      007C1D FB               [12]  769 	mov	r3,a
      007C1E A2 19            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007C20 E4               [12]  771 	clr	a
      007C21 33               [12]  772 	rlc	a
      007C22 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007C25 75 82 00         [24]  774 	mov	dpl, #0x00
      007C28 22               [24]  775 	ret
      007C29                        776 00104$:
                                    777 ;	quantum/action_util.c:44: *bits ^= mask;
      007C29 EC               [12]  778 	mov	a,r4
      007C2A 62 06            [12]  779 	xrl	ar6,a
      007C2C 12 81 74         [24]  780 	lcall	_ak820_outline_0148
      007C2F EE               [12]  781 	mov	a,r6
      007C30 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:45: return true;
      007C31 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:46: }
      007C34 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_292'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_293'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_293'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_293'
                                    795 ;old           Allocated with name '_change_owned_old_30000_295'
                                    796 ;result        Allocated with name '_change_owned_result_10001_296'
                                    797 ;i             Allocated with name '_change_owned_i_20001_297'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_297'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:47: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007C35                        805 _change_owned:
      007C35 E5 82            [12]  806 	mov	a,dpl
      007C37 90 09 7D         [24]  807 	mov	dptr,#_change_owned_mods_10000_292
      007C3A F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:48: uint8_t kind = mode >> 1;
      007C3B 90 09 7C         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007C3E E0               [24]  811 	movx	a,@dptr
      007C3F FF               [12]  812 	mov	r7,a
      007C40 C3               [12]  813 	clr	c
      007C41 13               [12]  814 	rrc	a
      007C42 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:49: bool pressed = (mode & 1) != 0;
      007C43 53 07 01         [24]  817 	anl	ar7,#0x01
      007C46 EF               [12]  818 	mov	a,r7
      007C47 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007C4A                        820 00205$:
      007C4A 92 1A            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007C4C B3               [12]  822 	cpl	c
      007C4D E4               [12]  823 	clr	a
      007C4E 33               [12]  824 	rlc	a
      007C4F F5 5A            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:50: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007C51 EE               [12]  827 	mov	a,r6
      007C52 60 06            [24]  828 	jz	00121$
      007C54 7D 6A            [12]  829 	mov	r5,#_owned_weak_refs
      007C56 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007C58 80 04            [24]  831 	sjmp	00122$
      007C5A                        832 00121$:
      007C5A 7D 62            [12]  833 	mov	r5,#_owned_mod_refs
      007C5C 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007C5E                        835 00122$:
                                    836 ;	quantum/action_util.c:51: if (ak820_macro_primitive) {
      007C5E 90 09 76         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007C61 E0               [24]  838 	movx	a,@dptr
      007C62 60 39            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:52: uint8_t old = macro_mods[kind];
      007C64 EE               [12]  841 	mov	a,r6
      007C65 24 74            [12]  842 	add	a, #_macro_mods
      007C67 FB               [12]  843 	mov	r3,a
      007C68 E4               [12]  844 	clr	a
      007C69 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007C6B FC               [12]  846 	mov	r4,a
      007C6C 12 43 F9         [24]  847 	lcall	_ak820_outline_0014
      007C6F E0               [24]  848 	movx	a,@dptr
      007C70 FA               [12]  849 	mov	r2,a
                                    850 ;	quantum/action_util.c:53: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007C71 E5 5A            [12]  851 	mov	a,_change_owned_sloc1_1_0
      007C73 60 0A            [24]  852 	jz	00123$
      007C75 90 09 7D         [24]  853 	mov	dptr,#_change_owned_mods_10000_292
      007C78 E0               [24]  854 	movx	a,@dptr
      007C79 F9               [12]  855 	mov	r1,a
      007C7A EA               [12]  856 	mov	a,r2
      007C7B 42 01            [12]  857 	orl	ar1,a
      007C7D 80 07            [24]  858 	sjmp	00124$
      007C7F                        859 00123$:
      007C7F 90 09 7D         [24]  860 	mov	dptr,#_change_owned_mods_10000_292
      007C82 E0               [24]  861 	movx	a,@dptr
      007C83 F4               [12]  862 	cpl	a
      007C84 5A               [12]  863 	anl	a,r2
      007C85 F9               [12]  864 	mov	r1,a
      007C86                        865 00124$:
      007C86 12 43 F9         [24]  866 	lcall	_ak820_outline_0014
      007C89 E9               [12]  867 	mov	a,r1
      007C8A F0               [24]  868 	movx	@dptr,a
                                    869 ;	quantum/action_util.c:54: mods &= pressed ? ~old : old;
      007C8B E5 5A            [12]  870 	mov	a,_change_owned_sloc1_1_0
      007C8D 60 06            [24]  871 	jz	00125$
      007C8F 74 FF            [12]  872 	mov	a,#0xff
      007C91 6A               [12]  873 	xrl	a,r2
      007C92 FC               [12]  874 	mov	r4,a
      007C93 80 02            [24]  875 	sjmp	00126$
      007C95                        876 00125$:
      007C95 8A 04            [24]  877 	mov	ar4,r2
      007C97                        878 00126$:
      007C97 90 09 7D         [24]  879 	mov	dptr,#_change_owned_mods_10000_292
      007C9A E0               [24]  880 	movx	a,@dptr
      007C9B 5C               [12]  881 	anl	a,r4
      007C9C F0               [24]  882 	movx	@dptr,a
      007C9D                        883 00102$:
                                    884 ;	quantum/action_util.c:56: uint8_t result = 0;
      007C9D 90 09 7E         [24]  885 	mov	dptr,#_change_owned_result_10001_296
      007CA0 E4               [12]  886 	clr	a
      007CA1 F0               [24]  887 	movx	@dptr,a
                                    888 ;	quantum/action_util.c:57: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CA2 90 09 7F         [24]  889 	mov	dptr,#_change_owned_bit_20001_297
      007CA5 04               [12]  890 	inc	a
      007CA6 F0               [24]  891 	movx	@dptr,a
      007CA7 90 09 7D         [24]  892 	mov	dptr,#_change_owned_mods_10000_292
      007CAA E0               [24]  893 	movx	a,@dptr
      007CAB FC               [12]  894 	mov	r4,a
      007CAC 7B 00            [12]  895 	mov	r3,#0x00
      007CAE                        896 00117$:
      007CAE BB 08 00         [24]  897 	cjne	r3,#0x08,00210$
      007CB1                        898 00210$:
      007CB1 50 49            [24]  899 	jnc	00112$
                                    900 ;	quantum/action_util.c:58: if (mods & bit) {
      007CB3 90 09 7F         [24]  901 	mov	dptr,#_change_owned_bit_20001_297
      007CB6 E0               [24]  902 	movx	a,@dptr
      007CB7 5C               [12]  903 	anl	a,r4
      007CB8 60 24            [24]  904 	jz	00109$
                                    905 ;	quantum/action_util.c:59: if (pressed) ++refs[i];
      007CBA E5 5A            [12]  906 	mov	a,_change_owned_sloc1_1_0
      007CBC 60 10            [24]  907 	jz	00106$
      007CBE 12 81 64         [24]  908 	lcall	_ak820_outline_0112
      007CC1 12 44 06         [24]  909 	lcall	_ak820_outline_0016
      007CC4 E0               [24]  910 	movx	a,@dptr
      007CC5 F8               [12]  911 	mov	r0,a
      007CC6 08               [12]  912 	inc	r0
      007CC7 12 44 06         [24]  913 	lcall	_ak820_outline_0016
      007CCA E8               [12]  914 	mov	a,r0
      007CCB F0               [24]  915 	movx	@dptr,a
      007CCC 80 10            [24]  916 	sjmp	00109$
      007CCE                        917 00106$:
                                    918 ;	quantum/action_util.c:60: else if (refs[i]) --refs[i];
      007CCE 12 81 64         [24]  919 	lcall	_ak820_outline_0112
      007CD1 12 44 06         [24]  920 	lcall	_ak820_outline_0016
      007CD4 E0               [24]  921 	movx	a,@dptr
      007CD5 F8               [12]  922 	mov	r0,a
      007CD6 60 06            [24]  923 	jz	00109$
      007CD8 18               [12]  924 	dec	r0
      007CD9 12 44 06         [24]  925 	lcall	_ak820_outline_0016
      007CDC E8               [12]  926 	mov	a,r0
      007CDD F0               [24]  927 	movx	@dptr,a
      007CDE                        928 00109$:
                                    929 ;	quantum/action_util.c:62: if (refs[i]) result |= bit;
      007CDE 12 81 64         [24]  930 	lcall	_ak820_outline_0112
      007CE1 12 44 06         [24]  931 	lcall	_ak820_outline_0016
      007CE4 E0               [24]  932 	movx	a,@dptr
      007CE5 60 0B            [24]  933 	jz	00118$
      007CE7 90 09 7F         [24]  934 	mov	dptr,#_change_owned_bit_20001_297
      007CEA E0               [24]  935 	movx	a,@dptr
      007CEB FA               [12]  936 	mov	r2,a
      007CEC 90 09 7E         [24]  937 	mov	dptr,#_change_owned_result_10001_296
      007CEF E0               [24]  938 	movx	a,@dptr
      007CF0 4A               [12]  939 	orl	a,r2
      007CF1 F0               [24]  940 	movx	@dptr,a
      007CF2                        941 00118$:
                                    942 ;	quantum/action_util.c:57: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CF2 0B               [12]  943 	inc	r3
      007CF3 90 09 7F         [24]  944 	mov	dptr,#_change_owned_bit_20001_297
      007CF6 E0               [24]  945 	movx	a,@dptr
      007CF7 25 E0            [12]  946 	add	a,acc
      007CF9 F0               [24]  947 	movx	@dptr,a
      007CFA 80 B2            [24]  948 	sjmp	00117$
      007CFC                        949 00112$:
                                    950 ;	quantum/action_util.c:64: if (kind) owned_weak_mods = result;
      007CFC EE               [12]  951 	mov	a,r6
      007CFD 60 09            [24]  952 	jz	00114$
      007CFF 90 09 7E         [24]  953 	mov	dptr,#_change_owned_result_10001_296
      007D02 E0               [24]  954 	movx	a,@dptr
      007D03 90 09 73         [24]  955 	mov	dptr,#_owned_weak_mods
      007D06 F0               [24]  956 	movx	@dptr,a
      007D07 22               [24]  957 	ret
      007D08                        958 00114$:
                                    959 ;	quantum/action_util.c:65: else owned_mods = result;
      007D08 90 09 7E         [24]  960 	mov	dptr,#_change_owned_result_10001_296
      007D0B E0               [24]  961 	movx	a,@dptr
      007D0C 90 09 72         [24]  962 	mov	dptr,#_owned_mods
      007D0F F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:66: }
      007D10 22               [24]  965 	ret
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'add_owned_mods'
                                    968 ;------------------------------------------------------------
                                    969 ;mods          Allocated with name '_add_owned_mods_mods_10000_305'
                                    970 ;------------------------------------------------------------
                                    971 ;	quantum/action_util.c:67: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    972 ;	-----------------------------------------
                                    973 ;	 function add_owned_mods
                                    974 ;	-----------------------------------------
      007D11                        975 _add_owned_mods:
      007D11 E5 82            [12]  976 	mov	a,dpl
      007D13 90 09 80         [24]  977 	mov	dptr,#_add_owned_mods_mods_10000_305
      007D16 12 81 42         [24]  978 	lcall	_ak820_outline_0080
      007D19 74 01            [12]  979 	mov	a,#0x01
      007D1B F0               [24]  980 	movx	@dptr,a
      007D1C 8F 82            [24]  981 	mov	dpl, r7
      007D1E 02 7C 35         [24]  982 	ljmp	_change_owned
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'del_owned_mods'
                                    985 ;------------------------------------------------------------
                                    986 ;mods          Allocated with name '_del_owned_mods_mods_10000_307'
                                    987 ;------------------------------------------------------------
                                    988 ;	quantum/action_util.c:68: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    989 ;	-----------------------------------------
                                    990 ;	 function del_owned_mods
                                    991 ;	-----------------------------------------
      007D21                        992 _del_owned_mods:
      007D21 E5 82            [12]  993 	mov	a,dpl
      007D23 90 09 81         [24]  994 	mov	dptr,#_del_owned_mods_mods_10000_307
      007D26 12 81 42         [24]  995 	lcall	_ak820_outline_0080
      007D29 E4               [12]  996 	clr	a
      007D2A F0               [24]  997 	movx	@dptr,a
      007D2B 8F 82            [24]  998 	mov	dpl, r7
      007D2D 02 7C 35         [24]  999 	ljmp	_change_owned
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1002 ;------------------------------------------------------------
                                   1003 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_309'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	quantum/action_util.c:69: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function add_owned_weak_mods
                                   1008 ;	-----------------------------------------
      007D30                       1009 _add_owned_weak_mods:
      007D30 E5 82            [12] 1010 	mov	a,dpl
      007D32 90 09 82         [24] 1011 	mov	dptr,#_add_owned_weak_mods_mods_10000_309
      007D35 12 81 42         [24] 1012 	lcall	_ak820_outline_0080
      007D38 74 03            [12] 1013 	mov	a,#0x03
      007D3A F0               [24] 1014 	movx	@dptr,a
      007D3B 8F 82            [24] 1015 	mov	dpl, r7
      007D3D 02 7C 35         [24] 1016 	ljmp	_change_owned
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1019 ;------------------------------------------------------------
                                   1020 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_311'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/action_util.c:70: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function del_owned_weak_mods
                                   1025 ;	-----------------------------------------
      007D40                       1026 _del_owned_weak_mods:
      007D40 E5 82            [12] 1027 	mov	a,dpl
      007D42 90 09 83         [24] 1028 	mov	dptr,#_del_owned_weak_mods_mods_10000_311
      007D45 12 81 42         [24] 1029 	lcall	_ak820_outline_0080
      007D48 74 02            [12] 1030 	mov	a,#0x02
      007D4A F0               [24] 1031 	movx	@dptr,a
      007D4B 8F 82            [24] 1032 	mov	dpl, r7
      007D4D 02 7C 35         [24] 1033 	ljmp	_change_owned
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1036 ;------------------------------------------------------------
                                   1037 ;i             Allocated with name '_clear_owned_mods_i_20000_315'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	quantum/action_util.c:71: void clear_owned_mods(void) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function clear_owned_mods
                                   1042 ;	-----------------------------------------
      007D50                       1043 _clear_owned_mods:
                                   1044 ;	quantum/action_util.c:72: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007D50 7F 00            [12] 1045 	mov	r7,#0x00
      007D52                       1046 00103$:
      007D52 BF 08 00         [24] 1047 	cjne	r7,#0x08,00122$
      007D55                       1048 00122$:
      007D55 50 1B            [24] 1049 	jnc	00101$
      007D57 EF               [12] 1050 	mov	a,r7
      007D58 24 62            [12] 1051 	add	a, #_owned_mod_refs
      007D5A FD               [12] 1052 	mov	r5,a
      007D5B E4               [12] 1053 	clr	a
      007D5C 34 09            [12] 1054 	addc	a, #(_owned_mod_refs >> 8)
      007D5E FE               [12] 1055 	mov	r6,a
      007D5F EF               [12] 1056 	mov	a,r7
      007D60 24 6A            [12] 1057 	add	a, #_owned_weak_refs
      007D62 F5 82            [12] 1058 	mov	dpl,a
      007D64 E4               [12] 1059 	clr	a
      007D65 34 09            [12] 1060 	addc	a, #(_owned_weak_refs >> 8)
      007D67 F5 83            [12] 1061 	mov	dph,a
      007D69 E4               [12] 1062 	clr	a
      007D6A F0               [24] 1063 	movx	@dptr,a
      007D6B 12 43 F4         [24] 1064 	lcall	_ak820_outline_0012
      007D6E F0               [24] 1065 	movx	@dptr,a
      007D6F 0F               [12] 1066 	inc	r7
      007D70 80 E0            [24] 1067 	sjmp	00103$
      007D72                       1068 00101$:
                                   1069 ;	quantum/action_util.c:73: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007D72 90 09 75         [24] 1070 	mov	dptr,#(_macro_mods + 0x0001)
      007D75 E4               [12] 1071 	clr	a
      007D76 F0               [24] 1072 	movx	@dptr,a
      007D77 90 09 74         [24] 1073 	mov	dptr,#_macro_mods
      007D7A F0               [24] 1074 	movx	@dptr,a
      007D7B 90 09 73         [24] 1075 	mov	dptr,#_owned_weak_mods
      007D7E F0               [24] 1076 	movx	@dptr,a
      007D7F 90 09 72         [24] 1077 	mov	dptr,#_owned_mods
      007D82 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/action_util.c:74: ak820_macro_cancelled = true;
      007D83 90 09 77         [24] 1080 	mov	dptr,#_ak820_macro_cancelled
      007D86 04               [12] 1081 	inc	a
      007D87 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	quantum/action_util.c:75: }
      007D88 22               [24] 1084 	ret
                                   1085 ;------------------------------------------------------------
                                   1086 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1087 ;------------------------------------------------------------
                                   1088 ;i             Allocated with name '_clear_owned_keys_i_20000_318'
                                   1089 ;i             Allocated with name '_clear_owned_keys_i_20000_319'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	quantum/action_util.c:81: void clear_owned_keys(void) {
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function clear_owned_keys
                                   1094 ;	-----------------------------------------
      007D89                       1095 _clear_owned_keys:
                                   1096 ;	quantum/action_util.c:82: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007D89 7F 00            [12] 1097 	mov	r7,#0x00
      007D8B                       1098 00104$:
      007D8B EF               [12] 1099 	mov	a,r7
      007D8C 24 5B            [12] 1100 	add	a,#0xff - 0xa4
      007D8E 40 0D            [24] 1101 	jc	00101$
                                   1102 ;	free result
      007D90 EF               [12] 1103 	mov	a,r7
      007D91 24 84            [12] 1104 	add	a, #_key_refs
      007D93 F5 82            [12] 1105 	mov	dpl,a
      007D95 E4               [12] 1106 	clr	a
      007D96 34 09            [12] 1107 	addc	a, #(_key_refs >> 8)
      007D98 12 7B BA         [24] 1108 	lcall	_ak820_outline_0120
      007D9B 80 EE            [24] 1109 	sjmp	00104$
      007D9D                       1110 00101$:
                                   1111 ;	quantum/action_util.c:83: distinct_keys = 0;
      007D9D 90 0A 29         [24] 1112 	mov	dptr,#_distinct_keys
      007DA0 E4               [12] 1113 	clr	a
      007DA1 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	quantum/action_util.c:84: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007DA2 FF               [12] 1116 	mov	r7,a
      007DA3                       1117 00107$:
      007DA3 BF 15 00         [24] 1118 	cjne	r7,#0x15,00142$
      007DA6                       1119 00142$:
      007DA6 50 0D            [24] 1120 	jnc	00109$
      007DA8 EF               [12] 1121 	mov	a,r7
      007DA9 24 2A            [12] 1122 	add	a, #_macro_keys
      007DAB F5 82            [12] 1123 	mov	dpl,a
      007DAD E4               [12] 1124 	clr	a
      007DAE 34 0A            [12] 1125 	addc	a, #(_macro_keys >> 8)
      007DB0 12 7B BA         [24] 1126 	lcall	_ak820_outline_0120
      007DB3 80 EE            [24] 1127 	sjmp	00107$
      007DB5                       1128 00109$:
                                   1129 ;	quantum/action_util.c:85: }
      007DB5 22               [24] 1130 	ret
                                   1131 ;------------------------------------------------------------
                                   1132 ;Allocation info for local variables in function 'add_owned_key'
                                   1133 ;------------------------------------------------------------
                                   1134 ;code          Allocated with name '_add_owned_key_code_10000_320'
                                   1135 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_329'
                                   1136 ;key           Allocated with name '_add_owned_key_key_50000_330'
                                   1137 ;i             Allocated with name '_add_owned_key_i_40000_328'
                                   1138 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_332'
                                   1139 ;key           Allocated with name '_add_owned_key_key_40000_333'
                                   1140 ;------------------------------------------------------------
                                   1141 ;	quantum/action_util.c:86: bool add_owned_key(uint8_t code) {
                                   1142 ;	-----------------------------------------
                                   1143 ;	 function add_owned_key
                                   1144 ;	-----------------------------------------
      007DB6                       1145 _add_owned_key:
      007DB6 E5 82            [12] 1146 	mov	a,dpl
      007DB8 90 0A 3F         [24] 1147 	mov	dptr,#_add_owned_key_code_10000_320
      007DBB 12 81 54         [24] 1148 	lcall	_ak820_outline_0097
                                   1149 ;	quantum/action_util.c:87: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007DBE 74 01            [12] 1150 	mov	a,#0x01
      007DC0 F0               [24] 1151 	movx	@dptr,a
      007DC1 90 0A 2A         [24] 1152 	mov	dptr,#_macro_keys
      007DC4 C0 07            [24] 1153 	push	ar7
      007DC6 12 7B C9         [24] 1154 	lcall	_ak820_macro_change
      007DC9 E5 82            [12] 1155 	mov	a, dpl
      007DCB D0 07            [24] 1156 	pop	ar7
      007DCD 70 03            [24] 1157 	jnz	00102$
      007DCF F5 82            [12] 1158 	mov	dpl,a
      007DD1 22               [24] 1159 	ret
      007DD2                       1160 00102$:
                                   1161 ;	quantum/action_util.c:88: if (key_refs[code]++) return false;
      007DD2 12 81 39         [24] 1162 	lcall	_ak820_outline_0067
      007DD5 12 43 F4         [24] 1163 	lcall	_ak820_outline_0012
      007DD8 E0               [24] 1164 	movx	a,@dptr
      007DD9 FC               [12] 1165 	mov	r4,a
      007DDA 04               [12] 1166 	inc	a
      007DDB 12 43 F4         [24] 1167 	lcall	_ak820_outline_0012
      007DDE F0               [24] 1168 	movx	@dptr,a
      007DDF EC               [12] 1169 	mov	a,r4
      007DE0 60 04            [24] 1170 	jz	00104$
      007DE2 75 82 00         [24] 1171 	mov	dpl, #0x00
      007DE5 22               [24] 1172 	ret
      007DE6                       1173 00104$:
                                   1174 ;	quantum/action_util.c:89: ++distinct_keys;
      007DE6 90 0A 29         [24] 1175 	mov	dptr,#_distinct_keys
      007DE9 E0               [24] 1176 	movx	a,@dptr
      007DEA 24 01            [12] 1177 	add	a, #0x01
      007DEC F0               [24] 1178 	movx	@dptr,a
                                   1179 ;	quantum/action_util.c:91: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007DED 90 0D C4         [24] 1180 	mov	dptr,#_keyboard_protocol
      007DF0 E0               [24] 1181 	movx	a,@dptr
      007DF1 60 16            [24] 1182 	jz	00106$
      007DF3 90 0A AE         [24] 1183 	mov	dptr,#_keymap_config
      007DF6 E0               [24] 1184 	movx	a,@dptr
      007DF7 30 E7 0F         [24] 1185 	jnb	acc.7,00106$
                                   1186 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007DFA 90 07 F3         [24] 1187 	mov	dptr,#_add_key_to_report_PARM_2
      007DFD EF               [12] 1188 	mov	a,r7
      007DFE F0               [24] 1189 	movx	@dptr,a
      007DFF 12 81 28         [24] 1190 	lcall	_ak820_outline_0035
      007E02 12 6F 41         [24] 1191 	lcall	_add_key_to_report
                                   1192 ;	quantum/action_util.c:91: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E05 75 82 01         [24] 1193 	mov	dpl, #0x01
      007E08 22               [24] 1194 	ret
      007E09                       1195 00106$:
                                   1196 ;	quantum/action_util.c:93: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007E09 90 0A 29         [24] 1197 	mov	dptr,#_distinct_keys
      007E0C E0               [24] 1198 	movx	a,@dptr
      007E0D 24 F9            [12] 1199 	add	a,#0xff - 0x06
      007E0F 50 17            [24] 1200 	jnc	00110$
                                   1201 ;	free result
                                   1202 ;	quantum/action_util.c:94: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007E11 7F 00            [12] 1203 	mov	r7,#0x00
      007E13                       1204 00115$:
      007E13 BF 06 00         [24] 1205 	cjne	r7,#0x06,00174$
      007E16                       1206 00174$:
      007E16 50 1E            [24] 1207 	jnc	00111$
      007E18 EF               [12] 1208 	mov	a,r7
      007E19 24 D9            [12] 1209 	add	a, #(_actual_keyboard_report + 0x0002)
      007E1B F5 82            [12] 1210 	mov	dpl,a
      007E1D E4               [12] 1211 	clr	a
      007E1E 34 0D            [12] 1212 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007E20 F5 83            [12] 1213 	mov	dph,a
      007E22 74 01            [12] 1214 	mov	a,#0x01
      007E24 F0               [24] 1215 	movx	@dptr,a
      007E25 0F               [12] 1216 	inc	r7
      007E26 80 EB            [24] 1217 	sjmp	00115$
      007E28                       1218 00110$:
                                   1219 ;	quantum/action_util.c:95: } else add_key(code);
      007E28 90 0A 3F         [24] 1220 	mov	dptr,#_add_owned_key_code_10000_320
      007E2B E0               [24] 1221 	movx	a,@dptr
                                   1222 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007E2C 90 07 F3         [24] 1223 	mov	dptr,#_add_key_to_report_PARM_2
      007E2F F0               [24] 1224 	movx	@dptr,a
      007E30 12 81 28         [24] 1225 	lcall	_ak820_outline_0035
      007E33 12 6F 41         [24] 1226 	lcall	_add_key_to_report
                                   1227 ;	quantum/action_util.c:95: } else add_key(code);
      007E36                       1228 00111$:
                                   1229 ;	quantum/action_util.c:96: return true;
      007E36 75 82 01         [24] 1230 	mov	dpl, #0x01
                                   1231 ;	quantum/action_util.c:97: }
      007E39 22               [24] 1232 	ret
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'del_owned_key'
                                   1235 ;------------------------------------------------------------
                                   1236 ;code          Allocated with name '_del_owned_key_code_10000_335'
                                   1237 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_346'
                                   1238 ;key           Allocated with name '_del_owned_key_key_50000_347'
                                   1239 ;key           Allocated with name '_del_owned_key_key_40000_344'
                                   1240 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_352'
                                   1241 ;key           Allocated with name '_del_owned_key_key_70000_353'
                                   1242 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_355'
                                   1243 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1244 ;------------------------------------------------------------
                                   1245 ;	quantum/action_util.c:98: bool del_owned_key(uint8_t code) {
                                   1246 ;	-----------------------------------------
                                   1247 ;	 function del_owned_key
                                   1248 ;	-----------------------------------------
      007E3A                       1249 _del_owned_key:
      007E3A E5 82            [12] 1250 	mov	a,dpl
      007E3C 90 0A 40         [24] 1251 	mov	dptr,#_del_owned_key_code_10000_335
      007E3F 12 81 54         [24] 1252 	lcall	_ak820_outline_0097
                                   1253 ;	quantum/action_util.c:99: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007E42 E4               [12] 1254 	clr	a
      007E43 F0               [24] 1255 	movx	@dptr,a
      007E44 90 0A 2A         [24] 1256 	mov	dptr,#_macro_keys
      007E47 C0 07            [24] 1257 	push	ar7
      007E49 12 7B C9         [24] 1258 	lcall	_ak820_macro_change
      007E4C E5 82            [12] 1259 	mov	a, dpl
      007E4E D0 07            [24] 1260 	pop	ar7
      007E50 70 03            [24] 1261 	jnz	00102$
      007E52 F5 82            [12] 1262 	mov	dpl,a
      007E54 22               [24] 1263 	ret
      007E55                       1264 00102$:
                                   1265 ;	quantum/action_util.c:100: if (!key_refs[code] || --key_refs[code]) return false;
      007E55 12 81 39         [24] 1266 	lcall	_ak820_outline_0067
      007E58 12 43 F4         [24] 1267 	lcall	_ak820_outline_0012
      007E5B E0               [24] 1268 	movx	a,@dptr
      007E5C FC               [12] 1269 	mov	r4,a
      007E5D 60 09            [24] 1270 	jz	00103$
      007E5F 1C               [12] 1271 	dec	r4
      007E60 12 43 F4         [24] 1272 	lcall	_ak820_outline_0012
      007E63 EC               [12] 1273 	mov	a,r4
      007E64 F0               [24] 1274 	movx	@dptr,a
      007E65 EC               [12] 1275 	mov	a,r4
      007E66 60 04            [24] 1276 	jz	00104$
      007E68                       1277 00103$:
      007E68 75 82 00         [24] 1278 	mov	dpl, #0x00
      007E6B 22               [24] 1279 	ret
      007E6C                       1280 00104$:
                                   1281 ;	quantum/action_util.c:101: --distinct_keys;
      007E6C 90 0A 29         [24] 1282 	mov	dptr,#_distinct_keys
      007E6F E0               [24] 1283 	movx	a,@dptr
      007E70 14               [12] 1284 	dec	a
      007E71 F0               [24] 1285 	movx	@dptr,a
                                   1286 ;	quantum/action_util.c:103: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E72 90 0D C4         [24] 1287 	mov	dptr,#_keyboard_protocol
      007E75 E0               [24] 1288 	movx	a,@dptr
      007E76 60 16            [24] 1289 	jz	00107$
      007E78 90 0A AE         [24] 1290 	mov	dptr,#_keymap_config
      007E7B E0               [24] 1291 	movx	a,@dptr
      007E7C 30 E7 0F         [24] 1292 	jnb	acc.7,00107$
                                   1293 ;	quantum/action_util.h:43: del_key_from_report(keyboard_report, key);
      007E7F 90 07 F7         [24] 1294 	mov	dptr,#_del_key_from_report_PARM_2
      007E82 EF               [12] 1295 	mov	a,r7
      007E83 F0               [24] 1296 	movx	@dptr,a
      007E84 12 81 28         [24] 1297 	lcall	_ak820_outline_0035
      007E87 12 6F 85         [24] 1298 	lcall	_del_key_from_report
                                   1299 ;	quantum/action_util.c:103: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E8A 75 82 01         [24] 1300 	mov	dpl, #0x01
      007E8D 22               [24] 1301 	ret
      007E8E                       1302 00107$:
                                   1303 ;	quantum/action_util.c:105: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007E8E 90 0A 29         [24] 1304 	mov	dptr,#_distinct_keys
      007E91 E0               [24] 1305 	movx	a,@dptr
      007E92 FF               [12] 1306 	mov  r7,a
      007E93 24 F9            [12] 1307 	add	a,#0xff - 0x06
      007E95 50 04            [24] 1308 	jnc	00110$
                                   1309 ;	free result
      007E97 75 82 01         [24] 1310 	mov	dpl, #0x01
      007E9A 22               [24] 1311 	ret
      007E9B                       1312 00110$:
                                   1313 ;	quantum/action_util.c:106: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007E9B BF 06 28         [24] 1314 	cjne	r7,#0x06,00115$
                                   1315 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007E9E 12 81 28         [24] 1316 	lcall	_ak820_outline_0035
      007EA1 12 6F C9         [24] 1317 	lcall	_clear_keys_from_report
                                   1318 ;	quantum/action_util.c:109: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007EA4 7F 04            [12] 1319 	mov	r7,#0x04
      007EA6                       1320 00122$:
      007EA6 EF               [12] 1321 	mov	a,r7
      007EA7 24 5B            [12] 1322 	add	a,#0xff - 0xa4
      007EA9 40 29            [24] 1323 	jc	00116$
                                   1324 ;	free result
      007EAB 12 81 39         [24] 1325 	lcall	_ak820_outline_0067
      007EAE 12 43 F4         [24] 1326 	lcall	_ak820_outline_0012
      007EB1 E0               [24] 1327 	movx	a,@dptr
      007EB2 60 0F            [24] 1328 	jz	00123$
                                   1329 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007EB4 90 07 F3         [24] 1330 	mov	dptr,#_add_key_to_report_PARM_2
      007EB7 EF               [12] 1331 	mov	a,r7
      007EB8 F0               [24] 1332 	movx	@dptr,a
      007EB9 12 81 28         [24] 1333 	lcall	_ak820_outline_0035
      007EBC C0 07            [24] 1334 	push	ar7
      007EBE 12 6F 41         [24] 1335 	lcall	_add_key_to_report
      007EC1 D0 07            [24] 1336 	pop	ar7
                                   1337 ;	quantum/action_util.c:109: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007EC3                       1338 00123$:
      007EC3 0F               [12] 1339 	inc	r7
      007EC4 80 E0            [24] 1340 	sjmp	00122$
      007EC6                       1341 00115$:
                                   1342 ;	quantum/action_util.c:110: } else del_key(code);
      007EC6 90 0A 40         [24] 1343 	mov	dptr,#_del_owned_key_code_10000_335
      007EC9 E0               [24] 1344 	movx	a,@dptr
                                   1345 ;	quantum/action_util.h:43: del_key_from_report(keyboard_report, key);
      007ECA 90 07 F7         [24] 1346 	mov	dptr,#_del_key_from_report_PARM_2
      007ECD F0               [24] 1347 	movx	@dptr,a
      007ECE 12 81 28         [24] 1348 	lcall	_ak820_outline_0035
      007ED1 12 6F 85         [24] 1349 	lcall	_del_key_from_report
                                   1350 ;	quantum/action_util.c:110: } else del_key(code);
      007ED4                       1351 00116$:
                                   1352 ;	quantum/action_util.c:111: return true;
      007ED4 75 82 01         [24] 1353 	mov	dpl, #0x01
                                   1354 ;	quantum/action_util.c:112: }
      007ED7 22               [24] 1355 	ret
                                   1356 ;------------------------------------------------------------
                                   1357 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1358 ;------------------------------------------------------------
                                   1359 ;i             Allocated with name '_clear_owned_usages_i_20000_360'
                                   1360 ;i             Allocated with name '_clear_owned_usages_i_20000_361'
                                   1361 ;------------------------------------------------------------
                                   1362 ;	quantum/action_util.c:122: void clear_owned_usages(void) {
                                   1363 ;	-----------------------------------------
                                   1364 ;	 function clear_owned_usages
                                   1365 ;	-----------------------------------------
      007ED8                       1366 _clear_owned_usages:
                                   1367 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007ED8 7F 00            [12] 1368 	mov	r7,#0x00
      007EDA                       1369 00104$:
      007EDA BF 1E 00         [24] 1370 	cjne	r7,#0x1e,00141$
      007EDD                       1371 00141$:
      007EDD 50 15            [24] 1372 	jnc	00101$
      007EDF EF               [12] 1373 	mov	a,r7
      007EE0 24 41            [12] 1374 	add	a, #_usage_refs
      007EE2 FD               [12] 1375 	mov	r5,a
      007EE3 E4               [12] 1376 	clr	a
      007EE4 34 0A            [12] 1377 	addc	a, #(_usage_refs >> 8)
      007EE6 FE               [12] 1378 	mov	r6,a
      007EE7 EF               [12] 1379 	mov	a,r7
      007EE8 12 81 2F         [24] 1380 	lcall	_ak820_outline_0054
      007EEB E4               [12] 1381 	clr	a
      007EEC F0               [24] 1382 	movx	@dptr,a
      007EED 12 43 F4         [24] 1383 	lcall	_ak820_outline_0012
      007EF0 F0               [24] 1384 	movx	@dptr,a
      007EF1 0F               [12] 1385 	inc	r7
      007EF2 80 E6            [24] 1386 	sjmp	00104$
      007EF4                       1387 00101$:
                                   1388 ;	quantum/action_util.c:124: usage_lengths[0] = usage_lengths[1] = 0;
      007EF4 90 0A 7E         [24] 1389 	mov	dptr,#(_usage_lengths + 0x0001)
      007EF7 E4               [12] 1390 	clr	a
      007EF8 F0               [24] 1391 	movx	@dptr,a
      007EF9 90 0A 7D         [24] 1392 	mov	dptr,#_usage_lengths
      007EFC F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/action_util.c:125: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007EFD FF               [12] 1395 	mov	r7,a
      007EFE                       1396 00107$:
      007EFE BF 04 00         [24] 1397 	cjne	r7,#0x04,00143$
      007F01                       1398 00143$:
      007F01 50 0D            [24] 1399 	jnc	00109$
      007F03 EF               [12] 1400 	mov	a,r7
      007F04 24 7F            [12] 1401 	add	a, #_macro_usages
      007F06 F5 82            [12] 1402 	mov	dpl,a
      007F08 E4               [12] 1403 	clr	a
      007F09 34 0A            [12] 1404 	addc	a, #(_macro_usages >> 8)
      007F0B 12 7B BA         [24] 1405 	lcall	_ak820_outline_0120
      007F0E 80 EE            [24] 1406 	sjmp	00107$
      007F10                       1407 00109$:
                                   1408 ;	quantum/action_util.c:126: }
      007F10 22               [24] 1409 	ret
                                   1410 ;------------------------------------------------------------
                                   1411 ;Allocation info for local variables in function 'owned_usage_key'
                                   1412 ;------------------------------------------------------------
                                   1413 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1414 ;code          Allocated with name '_owned_usage_key_code_10000_362'
                                   1415 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_363'
                                   1416 ;which         Allocated with name '_owned_usage_key_which_10000_363'
                                   1417 ;base          Allocated with name '_owned_usage_key_base_10000_363'
                                   1418 ;count         Allocated with name '_owned_usage_key_count_10000_363'
                                   1419 ;index         Allocated with name '_owned_usage_key_index_10000_363'
                                   1420 ;pos           Allocated with name '_owned_usage_key_pos_30001_370'
                                   1421 ;i             Allocated with name '_owned_usage_key_i_40001_371'
                                   1422 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_374'
                                   1423 ;key           Allocated with name '_owned_usage_key_key_40000_375'
                                   1424 ;------------------------------------------------------------
                                   1425 ;	quantum/action_util.c:127: void owned_usage_key(uint8_t code, bool pressed) {
                                   1426 ;	-----------------------------------------
                                   1427 ;	 function owned_usage_key
                                   1428 ;	-----------------------------------------
      007F11                       1429 _owned_usage_key:
      007F11 E5 82            [12] 1430 	mov	a,dpl
      007F13 90 0A 84         [24] 1431 	mov	dptr,#_owned_usage_key_code_10000_362
      007F16 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	quantum/action_util.c:128: uint8_t which = code >= KC_AUDIO_MUTE;
      007F17 E0               [24] 1434 	movx	a,@dptr
      007F18 FF               [12] 1435 	mov	r7,a
      007F19 BF A8 00         [24] 1436 	cjne	r7,#0xa8,00244$
      007F1C                       1437 00244$:
      007F1C B3               [12] 1438 	cpl	c
      007F1D 92 1B            [24] 1439 	mov	_owned_usage_key_sloc0_1_0,c
      007F1F E4               [12] 1440 	clr	a
      007F20 33               [12] 1441 	rlc	a
      007F21 FF               [12] 1442 	mov	r7,a
      007F22 90 0A 87         [24] 1443 	mov	dptr,#_owned_usage_key_which_10000_363
      007F25 F0               [24] 1444 	movx	@dptr,a
                                   1445 ;	quantum/action_util.c:129: uint8_t base = which ? SYSTEM_COUNT : 0;
      007F26 EF               [12] 1446 	mov	a,r7
      007F27 60 02            [24] 1447 	jz	00129$
      007F29 74 03            [12] 1448 	mov	a,#0x03
      007F2B                       1449 00129$:
      007F2B FE               [12] 1450 	mov	r6,a
                                   1451 ;	quantum/action_util.c:130: uint8_t count = usage_lengths[which];
      007F2C EF               [12] 1452 	mov	a,r7
      007F2D 24 7D            [12] 1453 	add	a, #_usage_lengths
      007F2F FD               [12] 1454 	mov	r5,a
      007F30 E4               [12] 1455 	clr	a
      007F31 34 0A            [12] 1456 	addc	a, #(_usage_lengths >> 8)
      007F33 FF               [12] 1457 	mov	r7,a
      007F34 12 81 74         [24] 1458 	lcall	_ak820_outline_0148
      007F37 E0               [24] 1459 	movx	a,@dptr
      007F38 FC               [12] 1460 	mov	r4,a
                                   1461 ;	quantum/action_util.c:131: uint8_t index = code - KC_SYSTEM_POWER;
      007F39 90 0A 84         [24] 1462 	mov	dptr,#_owned_usage_key_code_10000_362
      007F3C E0               [24] 1463 	movx	a,@dptr
      007F3D 24 5B            [12] 1464 	add	a,#0x5b
      007F3F FB               [12] 1465 	mov	r3,a
                                   1466 ;	quantum/action_util.c:132: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007F40 90 0A 83         [24] 1467 	mov	dptr,#_owned_usage_key_PARM_2
      007F43 E0               [24] 1468 	movx	a,@dptr
      007F44 FA               [12] 1469 	mov	r2,a
      007F45 90 09 78         [24] 1470 	mov	dptr,#_ak820_macro_change_PARM_2
      007F48 EB               [12] 1471 	mov	a,r3
      007F49 F0               [24] 1472 	movx	@dptr,a
      007F4A 90 09 79         [24] 1473 	mov	dptr,#_ak820_macro_change_PARM_3
      007F4D EA               [12] 1474 	mov	a,r2
      007F4E F0               [24] 1475 	movx	@dptr,a
      007F4F 90 0A 7F         [24] 1476 	mov	dptr,#_macro_usages
      007F52 C0 07            [24] 1477 	push	ar7
      007F54 C0 06            [24] 1478 	push	ar6
      007F56 C0 05            [24] 1479 	push	ar5
      007F58 C0 04            [24] 1480 	push	ar4
      007F5A C0 03            [24] 1481 	push	ar3
      007F5C C0 02            [24] 1482 	push	ar2
      007F5E 12 7B C9         [24] 1483 	lcall	_ak820_macro_change
      007F61 E5 82            [12] 1484 	mov	a, dpl
      007F63 D0 02            [24] 1485 	pop	ar2
      007F65 D0 03            [24] 1486 	pop	ar3
      007F67 D0 04            [24] 1487 	pop	ar4
      007F69 D0 05            [24] 1488 	pop	ar5
      007F6B D0 06            [24] 1489 	pop	ar6
      007F6D D0 07            [24] 1490 	pop	ar7
      007F6F 70 01            [24] 1491 	jnz	00102$
      007F71 22               [24] 1492 	ret
      007F72                       1493 00102$:
                                   1494 ;	quantum/action_util.c:133: if (pressed) {
      007F72 EA               [12] 1495 	mov	a,r2
      007F73 60 21            [24] 1496 	jz	00115$
                                   1497 ;	quantum/action_util.c:134: if (usage_refs[index]++) return;
      007F75 12 81 6B         [24] 1498 	lcall	_ak820_outline_0135
      007F78 12 44 06         [24] 1499 	lcall	_ak820_outline_0016
      007F7B E0               [24] 1500 	movx	a,@dptr
      007F7C F8               [12] 1501 	mov	r0,a
      007F7D 04               [12] 1502 	inc	a
      007F7E 12 44 06         [24] 1503 	lcall	_ak820_outline_0016
      007F81 F0               [24] 1504 	movx	@dptr,a
      007F82 E8               [12] 1505 	mov	a,r0
      007F83 60 01            [24] 1506 	jz	00104$
      007F85 22               [24] 1507 	ret
      007F86                       1508 00104$:
                                   1509 ;	quantum/action_util.c:135: usage_order[base + count++] = index;
      007F86 90 0A 88         [24] 1510 	mov	dptr,#_owned_usage_key_count_10000_363
      007F89 EC               [12] 1511 	mov	a,r4
      007F8A 04               [12] 1512 	inc	a
      007F8B F0               [24] 1513 	movx	@dptr,a
      007F8C EC               [12] 1514 	mov	a,r4
      007F8D 2E               [12] 1515 	add	a, r6
      007F8E 12 81 2F         [24] 1516 	lcall	_ak820_outline_0054
      007F91 EB               [12] 1517 	mov	a,r3
      007F92 F0               [24] 1518 	movx	@dptr,a
      007F93 02 7F FE         [24] 1519 	ljmp	00116$
      007F96                       1520 00115$:
                                   1521 ;	quantum/action_util.c:137: if (!usage_refs[index] || --usage_refs[index]) return;
      007F96 12 81 6B         [24] 1522 	lcall	_ak820_outline_0135
      007F99 12 44 06         [24] 1523 	lcall	_ak820_outline_0016
      007F9C E0               [24] 1524 	movx	a,@dptr
      007F9D F8               [12] 1525 	mov	r0,a
      007F9E 60 09            [24] 1526 	jz	00105$
      007FA0 18               [12] 1527 	dec	r0
      007FA1 12 44 06         [24] 1528 	lcall	_ak820_outline_0016
      007FA4 E8               [12] 1529 	mov	a,r0
      007FA5 F0               [24] 1530 	movx	@dptr,a
      007FA6 E8               [12] 1531 	mov	a,r0
      007FA7 60 01            [24] 1532 	jz	00106$
      007FA9                       1533 00105$:
      007FA9 22               [24] 1534 	ret
      007FAA                       1535 00106$:
                                   1536 ;	quantum/action_util.c:139: while (usage_order[base + pos] != index) ++pos;
      007FAA 7A 00            [12] 1537 	mov	r2,#0x00
      007FAC                       1538 00108$:
      007FAC EA               [12] 1539 	mov	a,r2
      007FAD 2E               [12] 1540 	add	a, r6
      007FAE 12 81 2F         [24] 1541 	lcall	_ak820_outline_0054
      007FB1 E0               [24] 1542 	movx	a,@dptr
      007FB2 B5 03 02         [24] 1543 	cjne	a,ar3,00251$
      007FB5 80 03            [24] 1544 	sjmp	00167$
      007FB7                       1545 00251$:
      007FB7 0A               [12] 1546 	inc	r2
      007FB8 80 F2            [24] 1547 	sjmp	00108$
      007FBA                       1548 00167$:
      007FBA 90 0A 89         [24] 1549 	mov	dptr,#_owned_usage_key_pos_30001_370
      007FBD EA               [12] 1550 	mov	a,r2
      007FBE F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/action_util.c:140: --count;
      007FBF 1C               [12] 1553 	dec	r4
      007FC0 90 0A 88         [24] 1554 	mov	dptr,#_owned_usage_key_count_10000_363
      007FC3 EC               [12] 1555 	mov	a,r4
      007FC4 F0               [24] 1556 	movx	@dptr,a
                                   1557 ;	quantum/action_util.c:141: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007FC5 8A 03            [24] 1558 	mov	ar3,r2
      007FC7                       1559 00125$:
      007FC7 C3               [12] 1560 	clr	c
      007FC8 EB               [12] 1561 	mov	a,r3
      007FC9 9C               [12] 1562 	subb	a,r4
      007FCA 50 23            [24] 1563 	jnc	00111$
      007FCC C0 05            [24] 1564 	push	ar5
      007FCE C0 07            [24] 1565 	push	ar7
      007FD0 EB               [12] 1566 	mov	a,r3
      007FD1 2E               [12] 1567 	add	a, r6
      007FD2 FA               [12] 1568 	mov	r2,a
      007FD3 24 5F            [12] 1569 	add	a, #_usage_order
      007FD5 F8               [12] 1570 	mov	r0,a
      007FD6 E4               [12] 1571 	clr	a
      007FD7 34 0A            [12] 1572 	addc	a, #(_usage_order >> 8)
      007FD9 F9               [12] 1573 	mov	r1,a
      007FDA 0A               [12] 1574 	inc	r2
      007FDB EA               [12] 1575 	mov	a,r2
      007FDC 33               [12] 1576 	rlc	a
      007FDD 95 E0            [12] 1577 	subb	a,acc
      007FDF FF               [12] 1578 	mov	r7,a
      007FE0 EA               [12] 1579 	mov	a,r2
      007FE1 12 81 49         [24] 1580 	lcall	_ak820_outline_0092
      007FE4 12 81 5F         [24] 1581 	lcall	_ak820_outline_0100
      007FE7 F0               [24] 1582 	movx	@dptr,a
      007FE8 0B               [12] 1583 	inc	r3
      007FE9 D0 07            [24] 1584 	pop	ar7
      007FEB D0 05            [24] 1585 	pop	ar5
      007FED 80 D8            [24] 1586 	sjmp	00125$
      007FEF                       1587 00111$:
                                   1588 ;	quantum/action_util.c:142: usage_lengths[which] = count;
      007FEF 12 81 74         [24] 1589 	lcall	_ak820_outline_0148
      007FF2 EC               [12] 1590 	mov	a,r4
      007FF3 F0               [24] 1591 	movx	@dptr,a
                                   1592 ;	quantum/action_util.c:143: if (pos != count) return; /* A non-winning owner changed only storage. */
      007FF4 90 0A 89         [24] 1593 	mov	dptr,#_owned_usage_key_pos_30001_370
      007FF7 E0               [24] 1594 	movx	a,@dptr
      007FF8 B5 04 02         [24] 1595 	cjne	a,ar4,00253$
      007FFB 80 01            [24] 1596 	sjmp	00116$
      007FFD                       1597 00253$:
      007FFD 22               [24] 1598 	ret
      007FFE                       1599 00116$:
                                   1600 ;	quantum/action_util.c:145: usage_lengths[which] = count;
      007FFE 90 0A 88         [24] 1601 	mov	dptr,#_owned_usage_key_count_10000_363
      008001 E0               [24] 1602 	movx	a,@dptr
      008002 FC               [12] 1603 	mov	r4,a
      008003 12 81 74         [24] 1604 	lcall	_ak820_outline_0148
      008006 F0               [24] 1605 	movx	@dptr,a
                                   1606 ;	quantum/action_util.c:146: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008007 EC               [12] 1607 	mov	a,r4
      008008 60 15            [24] 1608 	jz	00131$
      00800A EC               [12] 1609 	mov	a,r4
      00800B 2E               [12] 1610 	add	a, r6
      00800C FE               [12] 1611 	mov	r6,a
      00800D 1E               [12] 1612 	dec	r6
      00800E EE               [12] 1613 	mov	a,r6
      00800F 33               [12] 1614 	rlc	a
      008010 95 E0            [12] 1615 	subb	a,acc
      008012 FF               [12] 1616 	mov	r7,a
      008013 EE               [12] 1617 	mov	a,r6
      008014 12 81 49         [24] 1618 	lcall	_ak820_outline_0092
      008017 24 A5            [12] 1619 	add	a,#0xa5
      008019 FE               [12] 1620 	mov	r6,a
      00801A 33               [12] 1621 	rlc	a
      00801B 95 E0            [12] 1622 	subb	a,acc
      00801D 80 02            [24] 1623 	sjmp	00132$
      00801F                       1624 00131$:
      00801F 7E 00            [12] 1625 	mov	r6,#0x00
      008021                       1626 00132$:
      008021 90 0A 84         [24] 1627 	mov	dptr,#_owned_usage_key_code_10000_362
      008024 EE               [12] 1628 	mov	a,r6
      008025 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action_util.c:147: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008026 90 0A 87         [24] 1631 	mov	dptr,#_owned_usage_key_which_10000_363
      008029 E0               [24] 1632 	movx	a,@dptr
      00802A 60 18            [24] 1633 	jz	00118$
      00802C EE               [12] 1634 	mov	a,r6
      00802D 60 0B            [24] 1635 	jz	00133$
      00802F 8E 82            [24] 1636 	mov	dpl, r6
      008031 12 6D EB         [24] 1637 	lcall	_KEYCODE2CONSUMER
      008034 AD 82            [24] 1638 	mov	r5, dpl
      008036 AF 83            [24] 1639 	mov	r7, dph
      008038 80 04            [24] 1640 	sjmp	00134$
      00803A                       1641 00133$:
      00803A 7D 00            [12] 1642 	mov	r5,#0x00
      00803C 7F 00            [12] 1643 	mov	r7,#0x00
      00803E                       1644 00134$:
      00803E 12 81 74         [24] 1645 	lcall	_ak820_outline_0148
      008041 02 6D A3         [24] 1646 	ljmp	_host_consumer_send
      008044                       1647 00118$:
                                   1648 ;	quantum/action_util.c:148: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008044 EE               [12] 1649 	mov	a,r6
      008045 60 22            [24] 1650 	jz	00135$
                                   1651 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008047 BE A5 00         [24] 1652 	cjne	r6,#0xa5,00258$
      00804A                       1653 00258$:
      00804A 40 05            [24] 1654 	jc	00121$
      00804C EE               [12] 1655 	mov	a,r6
      00804D 24 58            [12] 1656 	add	a,#0xff - 0xa7
      00804F 50 08            [24] 1657 	jnc	00122$
                                   1658 ;	free result
      008051                       1659 00121$:
      008051 90 0A 85         [24] 1660 	mov	dptr,#_owned_usage_key___200000085_20000_363
      008054 12 4E 8D         [24] 1661 	lcall	_ak820_outline_0098
      008057 80 09            [24] 1662 	sjmp	00123$
      008059                       1663 00122$:
                                   1664 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008059 74 DC            [12] 1665 	mov	a,#0xdc
      00805B 2E               [12] 1666 	add	a, r6
      00805C 90 0A 85         [24] 1667 	mov	dptr,#_owned_usage_key___200000085_20000_363
      00805F 12 4E 60         [24] 1668 	lcall	_ak820_outline_0003
                                   1669 ;	quantum/action_util.c:148: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008062                       1670 00123$:
      008062 90 0A 85         [24] 1671 	mov	dptr,#_owned_usage_key___200000085_20000_363
      008065 E0               [24] 1672 	movx	a,@dptr
      008066 FF               [12] 1673 	mov	r7,a
      008067 80 02            [24] 1674 	sjmp	00136$
      008069                       1675 00135$:
      008069 7F 00            [12] 1676 	mov	r7,#0x00
      00806B                       1677 00136$:
      00806B 7E 00            [12] 1678 	mov	r6,#0x00
      00806D 12 44 79         [24] 1679 	lcall	_ak820_outline_0129
                                   1680 ;	quantum/action_util.c:149: }
      008070 02 6D 71         [24] 1681 	ljmp	_host_system_send
                                   1682 ;------------------------------------------------------------
                                   1683 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1684 ;------------------------------------------------------------
                                   1685 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_382'
                                   1686 ;changed       Allocated with name '_send_keyboard_report_changed_10001_382'
                                   1687 ;dest          Allocated with name '_send_keyboard_report_dest_10001_382'
                                   1688 ;src           Allocated with name '_send_keyboard_report_src_10001_382'
                                   1689 ;i             Allocated with name '_send_keyboard_report_i_20001_383'
                                   1690 ;------------------------------------------------------------
                                   1691 ;	quantum/action_util.c:371: void send_keyboard_report(void) {
                                   1692 ;	-----------------------------------------
                                   1693 ;	 function send_keyboard_report
                                   1694 ;	-----------------------------------------
      008073                       1695 _send_keyboard_report:
                                   1696 ;	quantum/action_util.c:372: keyboard_report->mods = real_mods;
      008073 90 0D D5         [24] 1697 	mov	dptr,#_real_mods
      008076 E0               [24] 1698 	movx	a,@dptr
      008077 FF               [12] 1699 	mov	r7,a
      008078 90 0D D7         [24] 1700 	mov	dptr,#_actual_keyboard_report
      00807B F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	quantum/action_util.c:373: keyboard_report->mods |= weak_mods;
      00807C 90 0D D6         [24] 1703 	mov	dptr,#_weak_mods
      00807F E0               [24] 1704 	movx	a,@dptr
      008080 42 07            [12] 1705 	orl	ar7,a
      008082 90 0D D7         [24] 1706 	mov	dptr,#_actual_keyboard_report
      008085 EF               [12] 1707 	mov	a,r7
      008086 F0               [24] 1708 	movx	@dptr,a
                                   1709 ;	quantum/action_util.c:375: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008087 90 09 73         [24] 1710 	mov	dptr,#_owned_weak_mods
      00808A E0               [24] 1711 	movx	a,@dptr
      00808B FE               [12] 1712 	mov	r6,a
      00808C 90 09 72         [24] 1713 	mov	dptr,#_owned_mods
      00808F E0               [24] 1714 	movx	a,@dptr
      008090 4E               [12] 1715 	orl	a,r6
      008091 42 07            [12] 1716 	orl	ar7,a
      008093 90 0D D7         [24] 1717 	mov	dptr,#_actual_keyboard_report
      008096 EF               [12] 1718 	mov	a,r7
      008097 F0               [24] 1719 	movx	@dptr,a
                                   1720 ;	quantum/action_util.c:406: bool changed = false;
      008098 90 0A AB         [24] 1721 	mov	dptr,#_send_keyboard_report_changed_10001_382
      00809B E4               [12] 1722 	clr	a
      00809C F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action_util.c:408: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1725 ;	quantum/action_util.c:409: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1726 ;	quantum/action_util.c:414: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00809D FF               [12] 1727 	mov	r7,a
      00809E                       1728 00107$:
      00809E BF 20 00         [24] 1729 	cjne	r7,#0x20,00140$
      0080A1                       1730 00140$:
      0080A1 50 2D            [24] 1731 	jnc	00103$
                                   1732 ;	quantum/action_util.c:415: if (dest[i] != src[i]) {
      0080A3 EF               [12] 1733 	mov	a,r7
      0080A4 24 8B            [12] 1734 	add	a, #_send_keyboard_report_last_report_10001_382
      0080A6 FD               [12] 1735 	mov	r5,a
      0080A7 E4               [12] 1736 	clr	a
      0080A8 34 0A            [12] 1737 	addc	a, #(_send_keyboard_report_last_report_10001_382 >> 8)
      0080AA FE               [12] 1738 	mov	r6,a
      0080AB 12 43 F4         [24] 1739 	lcall	_ak820_outline_0012
      0080AE E0               [24] 1740 	movx	a,@dptr
      0080AF FC               [12] 1741 	mov	r4,a
      0080B0 EF               [12] 1742 	mov	a,r7
      0080B1 24 D7            [12] 1743 	add	a, #_actual_keyboard_report
      0080B3 F5 82            [12] 1744 	mov	dpl,a
      0080B5 E4               [12] 1745 	clr	a
      0080B6 34 0D            [12] 1746 	addc	a, #(_actual_keyboard_report >> 8)
      0080B8 F5 83            [12] 1747 	mov	dph,a
      0080BA E0               [24] 1748 	movx	a,@dptr
      0080BB FB               [12] 1749 	mov	r3,a
      0080BC EC               [12] 1750 	mov	a,r4
      0080BD B5 03 02         [24] 1751 	cjne	a,ar3,00142$
      0080C0 80 0B            [24] 1752 	sjmp	00108$
      0080C2                       1753 00142$:
                                   1754 ;	quantum/action_util.c:416: dest[i] = src[i];
      0080C2 12 43 F4         [24] 1755 	lcall	_ak820_outline_0012
      0080C5 EB               [12] 1756 	mov	a,r3
      0080C6 F0               [24] 1757 	movx	@dptr,a
                                   1758 ;	quantum/action_util.c:417: changed = true;
      0080C7 90 0A AB         [24] 1759 	mov	dptr,#_send_keyboard_report_changed_10001_382
      0080CA 74 01            [12] 1760 	mov	a,#0x01
      0080CC F0               [24] 1761 	movx	@dptr,a
      0080CD                       1762 00108$:
                                   1763 ;	quantum/action_util.c:414: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0080CD 0F               [12] 1764 	inc	r7
      0080CE 80 CE            [24] 1765 	sjmp	00107$
      0080D0                       1766 00103$:
                                   1767 ;	quantum/action_util.c:420: if (changed) host_keyboard_send(keyboard_report);
      0080D0 90 0A AB         [24] 1768 	mov	dptr,#_send_keyboard_report_changed_10001_382
      0080D3 E0               [24] 1769 	movx	a,@dptr
      0080D4 60 06            [24] 1770 	jz	00109$
      0080D6 12 81 28         [24] 1771 	lcall	_ak820_outline_0035
                                   1772 ;	quantum/action_util.c:428: }
      0080D9 02 6C 9F         [24] 1773 	ljmp	_host_keyboard_send
      0080DC                       1774 00109$:
      0080DC 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:434: uint8_t get_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_mods
                                   1782 ;	-----------------------------------------
      0080DD                       1783 _get_mods:
      0080DD C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:439: ;
      0080DF 90 09 72         [24] 1786 	mov	dptr,#_owned_mods
      0080E2 E0               [24] 1787 	movx	a,@dptr
      0080E3 FF               [12] 1788 	mov	r7,a
      0080E4 90 0D D5         [24] 1789 	mov	dptr,#_real_mods
      0080E7 12 7B A0         [24] 1790 	lcall	_ak820_outline_0090
                                   1791 ;	quantum/action_util.c:440: }
      0080EA D0 07            [24] 1792 	pop	ar7
      0080EC 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_mods_mods_10000_390'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:445: void add_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function clear_mods
                                   1802 ;	-----------------------------------------
      0080ED                       1803 _clear_mods:
                                   1804 ;	quantum/action_util.c:467: real_mods = 0;
      0080ED 90 0D D5         [24] 1805 	mov	dptr,#_real_mods
      0080F0 E4               [12] 1806 	clr	a
      0080F1 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:468: }
      0080F2 22               [24] 1809 	ret
                                   1810 ;------------------------------------------------------------
                                   1811 ;Allocation info for local variables in function 'get_weak_mods'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action_util.c:474: uint8_t get_weak_mods(void) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function get_weak_mods
                                   1816 ;	-----------------------------------------
      0080F3                       1817 _get_weak_mods:
      0080F3 C0 07            [24] 1818 	push	ar7
                                   1819 ;	quantum/action_util.c:479: ;
      0080F5 90 09 73         [24] 1820 	mov	dptr,#_owned_weak_mods
      0080F8 E0               [24] 1821 	movx	a,@dptr
      0080F9 FF               [12] 1822 	mov	r7,a
      0080FA 90 0D D6         [24] 1823 	mov	dptr,#_weak_mods
      0080FD 12 7B A0         [24] 1824 	lcall	_ak820_outline_0090
                                   1825 ;	quantum/action_util.c:480: }
      008100 D0 07            [24] 1826 	pop	ar7
      008102 22               [24] 1827 	ret
                                   1828 ;------------------------------------------------------------
                                   1829 ;Allocation info for local variables in function 'add_weak_mods'
                                   1830 ;------------------------------------------------------------
                                   1831 ;mods          Allocated with name '_add_weak_mods_mods_10000_400'
                                   1832 ;------------------------------------------------------------
                                   1833 ;	quantum/action_util.c:485: void add_weak_mods(uint8_t mods) {
                                   1834 ;	-----------------------------------------
                                   1835 ;	 function add_weak_mods
                                   1836 ;	-----------------------------------------
      008103                       1837 _add_weak_mods:
      008103 E5 82            [12] 1838 	mov	a,dpl
      008105 90 0A AC         [24] 1839 	mov	dptr,#_add_weak_mods_mods_10000_400
      008108 F0               [24] 1840 	movx	@dptr,a
                                   1841 ;	quantum/action_util.c:486: weak_mods |= mods;
      008109 E0               [24] 1842 	movx	a,@dptr
      00810A FF               [12] 1843 	mov	r7,a
      00810B 90 0D D6         [24] 1844 	mov	dptr,#_weak_mods
      00810E E0               [24] 1845 	movx	a,@dptr
      00810F 4F               [12] 1846 	orl	a,r7
      008110 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	quantum/action_util.c:487: }
      008111 22               [24] 1849 	ret
                                   1850 ;------------------------------------------------------------
                                   1851 ;Allocation info for local variables in function 'del_weak_mods'
                                   1852 ;------------------------------------------------------------
                                   1853 ;mods          Allocated with name '_del_weak_mods_mods_10000_402'
                                   1854 ;------------------------------------------------------------
                                   1855 ;	quantum/action_util.c:492: void del_weak_mods(uint8_t mods) {
                                   1856 ;	-----------------------------------------
                                   1857 ;	 function del_weak_mods
                                   1858 ;	-----------------------------------------
      008112                       1859 _del_weak_mods:
      008112 E5 82            [12] 1860 	mov	a,dpl
      008114 90 0A AD         [24] 1861 	mov	dptr,#_del_weak_mods_mods_10000_402
      008117 F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/action_util.c:493: weak_mods &= ~mods;
      008118 E0               [24] 1864 	movx	a,@dptr
      008119 F4               [12] 1865 	cpl	a
      00811A FF               [12] 1866 	mov	r7,a
      00811B 90 0D D6         [24] 1867 	mov	dptr,#_weak_mods
      00811E E0               [24] 1868 	movx	a,@dptr
      00811F 5F               [12] 1869 	anl	a,r7
      008120 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action_util.c:494: }
      008121 22               [24] 1872 	ret
                                   1873 ;------------------------------------------------------------
                                   1874 ;Allocation info for local variables in function 'set_weak_mods'
                                   1875 ;------------------------------------------------------------
                                   1876 ;mods          Allocated with name '_set_weak_mods_mods_10000_404'
                                   1877 ;------------------------------------------------------------
                                   1878 ;	quantum/action_util.c:499: void set_weak_mods(uint8_t mods) {
                                   1879 ;	-----------------------------------------
                                   1880 ;	 function clear_weak_mods
                                   1881 ;	-----------------------------------------
      008122                       1882 _clear_weak_mods:
                                   1883 ;	quantum/action_util.c:507: weak_mods = 0;
      008122 90 0D D6         [24] 1884 	mov	dptr,#_weak_mods
      008125 E4               [12] 1885 	clr	a
      008126 F0               [24] 1886 	movx	@dptr,a
                                   1887 ;	quantum/action_util.c:508: }
      008127 22               [24] 1888 	ret
                                   1889 ;------------------------------------------------------------
                                   1890 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1891 ;------------------------------------------------------------
                                   1892 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_408'
                                   1893 ;------------------------------------------------------------
                                   1894 ;	quantum/action_util.c:590: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1895 ;	-----------------------------------------
                                   1896 	.area CSEG    (CODE)
                                   1897 	.area CONST   (CODE)
                                   1898 	.area XINIT   (CODE)
      00C620                       1899 __xinit__real_mods:
      00C620 00                    1900 	.db #0x00	; 0
      00C621                       1901 __xinit__weak_mods:
      00C621 00                    1902 	.db #0x00	; 0
      00C622                       1903 __xinit__actual_keyboard_report:
      00C622 00                    1904 	.db #0x00	; 0
      00C623 00                    1905 	.db #0x00	; 0
      00C624 00                    1906 	.db #0x00	; 0
      00C625 00                    1907 	.db #0x00	; 0
      00C626 00                    1908 	.db #0x00	; 0
      00C627 00                    1909 	.db #0x00	; 0
      00C628 00                    1910 	.db #0x00	; 0
      00C629 00                    1911 	.db #0x00	; 0
      00C62A 00                    1912 	.db 0x00
      00C62B 00                    1913 	.db 0x00
      00C62C 00                    1914 	.db 0x00
      00C62D 00                    1915 	.db 0x00
      00C62E 00                    1916 	.db 0x00
      00C62F 00                    1917 	.db 0x00
      00C630 00                    1918 	.db 0x00
      00C631 00                    1919 	.db 0x00
      00C632 00                    1920 	.db 0x00
      00C633 00                    1921 	.db 0x00
      00C634 00                    1922 	.db 0x00
      00C635 00                    1923 	.db 0x00
      00C636 00                    1924 	.db 0x00
      00C637 00                    1925 	.db 0x00
      00C638 00                    1926 	.db 0x00
      00C639 00                    1927 	.db 0x00
      00C63A 00                    1928 	.db 0x00
      00C63B 00                    1929 	.db 0x00
      00C63C 00                    1930 	.db 0x00
      00C63D 00                    1931 	.db 0x00
      00C63E 00                    1932 	.db 0x00
      00C63F 00                    1933 	.db 0x00
      00C640 00                    1934 	.db 0x00
      00C641 00                    1935 	.db 0x00
                                   1936 	.area CABS    (ABS,CODE)
                                   1937 
                                   1938 ; Experimental exact instruction outlining.
                                   1939 	.globl _ak820_outline_0003
                                   1940 	.globl _ak820_outline_0006
                                   1941 	.globl _ak820_outline_0007
                                   1942 	.globl _ak820_outline_0010
                                   1943 	.globl _ak820_outline_0012
                                   1944 	.globl _ak820_outline_0014
                                   1945 	.globl _ak820_outline_0016
                                   1946 	.globl _ak820_outline_0021
                                   1947 	.globl _ak820_outline_0035
                                   1948 	.globl _ak820_outline_0054
                                   1949 	.globl _ak820_outline_0067
                                   1950 	.globl _ak820_outline_0080
                                   1951 	.globl _ak820_outline_0090
                                   1952 	.globl _ak820_outline_0092
                                   1953 	.globl _ak820_outline_0097
                                   1954 	.globl _ak820_outline_0098
                                   1955 	.globl _ak820_outline_0100
                                   1956 	.globl _ak820_outline_0112
                                   1957 	.globl _ak820_outline_0120
                                   1958 	.globl _ak820_outline_0129
                                   1959 	.globl _ak820_outline_0133
                                   1960 	.globl _ak820_outline_0135
                                   1961 	.globl _ak820_outline_0148
                                   1962 
                                   1963 	.area CSEG (CODE)
                                   1964 ; function ak820_outline_0035
      008128                       1965 _ak820_outline_0035:
      008128 90 0D D7         [24] 1966 	mov	dptr,#_actual_keyboard_report
      00812B 75 F0 00         [24] 1967 	mov	b,#0x00
      00812E 22               [24] 1968 	ret
                                   1969 
                                   1970 	.area CSEG (CODE)
                                   1971 ; function ak820_outline_0054
      00812F                       1972 _ak820_outline_0054:
      00812F 24 5F            [12] 1973 	add	a,#_usage_order
      008131 F5 82            [12] 1974 	mov	dpl,a
      008133 E4               [12] 1975 	clr	a
      008134 34 0A            [12] 1976 	addc	a,#(_usage_order>>8)
      008136 F5 83            [12] 1977 	mov	dph,a
      008138 22               [24] 1978 	ret
                                   1979 
                                   1980 	.area CSEG (CODE)
                                   1981 ; function ak820_outline_0067
      008139                       1982 _ak820_outline_0067:
      008139 EF               [12] 1983 	mov	a,r7
      00813A 24 84            [12] 1984 	add	a,#_key_refs
      00813C FD               [12] 1985 	mov	r5,a
      00813D E4               [12] 1986 	clr	a
      00813E 34 09            [12] 1987 	addc	a,#(_key_refs>>8)
      008140 FE               [12] 1988 	mov	r6,a
      008141 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0080
      008142                       1993 _ak820_outline_0080:
      008142 F0               [24] 1994 	movx	@dptr,a
      008143 E0               [24] 1995 	movx	a,@dptr
      008144 FF               [12] 1996 	mov	r7,a
      008145 90 09 7C         [24] 1997 	mov	dptr,#_change_owned_PARM_2
      008148 22               [24] 1998 	ret
                                   1999 
                                   2000 	.area CSEG (CODE)
                                   2001 ; function ak820_outline_0092
      008149                       2002 _ak820_outline_0092:
      008149 24 5F            [12] 2003 	add	a,#_usage_order
      00814B F5 82            [12] 2004 	mov	dpl,a
      00814D EF               [12] 2005 	mov	a,r7
      00814E 34 0A            [12] 2006 	addc	a,#(_usage_order>>8)
      008150 F5 83            [12] 2007 	mov	dph,a
      008152 E0               [24] 2008 	movx	a,@dptr
      008153 22               [24] 2009 	ret
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0097
      008154                       2013 _ak820_outline_0097:
      008154 F0               [24] 2014 	movx	@dptr,a
      008155 E0               [24] 2015 	movx	a,@dptr
      008156 FF               [12] 2016 	mov	r7,a
      008157 90 09 78         [24] 2017 	mov	dptr,#_ak820_macro_change_PARM_2
      00815A F0               [24] 2018 	movx	@dptr,a
      00815B 90 09 79         [24] 2019 	mov	dptr,#_ak820_macro_change_PARM_3
      00815E 22               [24] 2020 	ret
                                   2021 
                                   2022 	.area CSEG (CODE)
                                   2023 ; function ak820_outline_0100
      00815F                       2024 _ak820_outline_0100:
      00815F 88 82            [24] 2025 	mov	dpl,r0
      008161 89 83            [24] 2026 	mov	dph,r1
      008163 22               [24] 2027 	ret
                                   2028 
                                   2029 	.area CSEG (CODE)
                                   2030 ; function ak820_outline_0112
      008164                       2031 _ak820_outline_0112:
      008164 EB               [12] 2032 	mov	a,r3
      008165 2D               [12] 2033 	add	a,r5
      008166 F9               [12] 2034 	mov	r1,a
      008167 E4               [12] 2035 	clr	a
      008168 3F               [12] 2036 	addc	a,r7
      008169 FA               [12] 2037 	mov	r2,a
      00816A 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0135
      00816B                       2042 _ak820_outline_0135:
      00816B EB               [12] 2043 	mov	a,r3
      00816C 24 41            [12] 2044 	add	a,#_usage_refs
      00816E F9               [12] 2045 	mov	r1,a
      00816F E4               [12] 2046 	clr	a
      008170 34 0A            [12] 2047 	addc	a,#(_usage_refs>>8)
      008172 FA               [12] 2048 	mov	r2,a
      008173 22               [24] 2049 	ret
                                   2050 
                                   2051 	.area CSEG (CODE)
                                   2052 ; function ak820_outline_0148
      008174                       2053 _ak820_outline_0148:
      008174 8D 82            [24] 2054 	mov	dpl,r5
      008176 8F 83            [24] 2055 	mov	dph,r7
      008178 22               [24] 2056 	ret
