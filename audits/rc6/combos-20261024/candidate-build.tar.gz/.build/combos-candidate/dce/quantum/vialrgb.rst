                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      000050                        535 _fast_set_leds_sloc0_1_0:
      000050                        536 	.ds 2
      000052                        537 _fast_set_leds_sloc1_1_0:
      000052                        538 	.ds 2
      000054                        539 _vialrgb_get_value_sloc0_1_0:
      000054                        540 	.ds 2
      000056                        541 _vialrgb_get_value_sloc1_1_0:
      000056                        542 	.ds 2
      000058                        543 _vialrgb_set_value_sloc0_1_0:
      000058                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C9F                        569 _g_direct_mode_colors::
      000C9F                        570 	.ds 246
      000D95                        571 _get_supported_PARM_2:
      000D95                        572 	.ds 1
      000D96                        573 _get_supported_args_10000_252:
      000D96                        574 	.ds 2
      000D98                        575 _qmk_id_to_vialrgb_id_id_10000_259:
      000D98                        576 	.ds 2
      000D9A                        577 _vialrgb_id_to_qmk_id_id_10000_264:
      000D9A                        578 	.ds 2
      000D9C                        579 _set_mode_mode_10000_272:
      000D9C                        580 	.ds 2
      000D9E                        581 _get_matrix_pos_for_led_PARM_2:
      000D9E                        582 	.ds 2
      000DA0                        583 _get_matrix_pos_for_led_led_10000_277:
      000DA0                        584 	.ds 2
      000DA2                        585 _fast_set_leds_PARM_2:
      000DA2                        586 	.ds 1
      000DA3                        587 _fast_set_leds_args_10000_279:
      000DA3                        588 	.ds 2
      000DA5                        589 _fast_set_leds_first_index_10001_282:
      000DA5                        590 	.ds 2
      000DA7                        591 _fast_set_leds_num_leds_10001_282:
      000DA7                        592 	.ds 1
      000DA8                        593 _vialrgb_get_value_PARM_2:
      000DA8                        594 	.ds 1
      000DA9                        595 _vialrgb_get_value_data_10000_288:
      000DA9                        596 	.ds 3
      000DAC                        597 _vialrgb_set_value_PARM_2:
      000DAC                        598 	.ds 1
      000DAD                        599 _vialrgb_set_value_data_10000_299:
      000DAD                        600 	.ds 3
      000DB0                        601 _vialrgb_save_PARM_2:
      000DB0                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B766                        654 _get_supported:
      00B766 12 43 EA         [24]  655 	lcall	_ak820_outline_0010
      00B769 90 0D 96         [24]  656 	mov	dptr,#_get_supported_args_10000_252
      00B76C 12 43 E5         [24]  657 	lcall	_ak820_outline_0007
                                    658 ;	quantum/vialrgb.c:29: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B76F 90 0D 96         [24]  659 	mov	dptr,#_get_supported_args_10000_252
      00B772 12 43 C5         [24]  660 	lcall	_ak820_outline_0000
      00B775 12 43 D3         [24]  661 	lcall	_ak820_outline_0002
      00B778 E0               [24]  662 	movx	a,@dptr
      00B779 FD               [12]  663 	mov	r5,a
      00B77A 7C 00            [12]  664 	mov	r4,#0x00
      00B77C 12 43 D3         [24]  665 	lcall	_ak820_outline_0002
      00B77F A3               [24]  666 	inc	dptr
      00B780 12 44 88         [24]  667 	lcall	_ak820_outline_0145
                                    668 ;	quantum/vialrgb.c:30: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B783 90 0D 95         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B786 E0               [24]  670 	movx	a,@dptr
      00B787 FB               [12]  671 	mov	r3,a
      00B788 7A 00            [12]  672 	mov	r2,#0x00
      00B78A                        673 00107$:
      00B78A C3               [12]  674 	clr	c
      00B78B EA               [12]  675 	mov	a,r2
      00B78C 9B               [12]  676 	subb	a,r3
      00B78D 50 0A            [24]  677 	jnc	00101$
      00B78F EA               [12]  678 	mov	a,r2
      00B790 12 43 FE         [24]  679 	lcall	_ak820_outline_0015
      00B793 74 FF            [12]  680 	mov	a,#0xff
      00B795 F0               [24]  681 	movx	@dptr,a
      00B796 0A               [12]  682 	inc	r2
      00B797 80 F1            [24]  683 	sjmp	00107$
      00B799                        684 00101$:
                                    685 ;	quantum/vialrgb.c:31: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B799 8D 06            [24]  686 	mov	ar6,r5
      00B79B 8C 07            [24]  687 	mov	ar7,r4
      00B79D 8B 05            [24]  688 	mov	ar5,r3
      00B79F 90 0D 96         [24]  689 	mov	dptr,#_get_supported_args_10000_252
      00B7A2 12 44 73         [24]  690 	lcall	_ak820_outline_0089
      00B7A5 7A 00            [12]  691 	mov	r2,#0x00
      00B7A7                        692 00110$:
      00B7A7 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B7AA                        694 00159$:
      00B7AA 50 48            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:32: uint16_t id = pgm_read_word(&supported_modes[i].vialrgb_id);
      00B7AC EA               [12]  697 	mov	a,r2
      00B7AD 75 F0 04         [24]  698 	mov	b,#0x04
      00B7B0 A4               [48]  699 	mul	ab
      00B7B1 24 42            [12]  700 	add	a, #_supported_modes
      00B7B3 F5 82            [12]  701 	mov	dpl,a
      00B7B5 74 C4            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B7B7 12 57 0F         [24]  703 	lcall	_ak820_outline_0111
      00B7BA F8               [12]  704 	mov	r0,a
      00B7BB A3               [24]  705 	inc	dptr
      00B7BC E4               [12]  706 	clr	a
      00B7BD 93               [24]  707 	movc	a,@a+dptr
      00B7BE F9               [12]  708 	mov	r1,a
                                    709 ;	quantum/vialrgb.c:33: if (id > gt && length >= sizeof(id)) {
      00B7BF C3               [12]  710 	clr	c
      00B7C0 EE               [12]  711 	mov	a,r6
      00B7C1 98               [12]  712 	subb	a,r0
      00B7C2 EF               [12]  713 	mov	a,r7
      00B7C3 99               [12]  714 	subb	a,r1
      00B7C4 50 2B            [24]  715 	jnc	00111$
                                    716 ;	free result
      00B7C6 BD 02 00         [24]  717 	cjne	r5,#0x02,00162$
      00B7C9                        718 00162$:
      00B7C9 40 26            [24]  719 	jc	00111$
                                    720 ;	quantum/vialrgb.c:34: args[0] = id;
      00B7CB C0 06            [24]  721 	push	ar6
      00B7CD C0 07            [24]  722 	push	ar7
      00B7CF 88 07            [24]  723 	mov	ar7,r0
      00B7D1 12 43 F9         [24]  724 	lcall	_ak820_outline_0014
      00B7D4 EF               [12]  725 	mov	a,r7
      00B7D5 F0               [24]  726 	movx	@dptr,a
                                    727 ;	quantum/vialrgb.c:35: args[1] = id >> 8;
      00B7D6 12 43 F9         [24]  728 	lcall	_ak820_outline_0014
      00B7D9 A3               [24]  729 	inc	dptr
      00B7DA 89 00            [24]  730 	mov	ar0,r1
      00B7DC E8               [12]  731 	mov	a,r0
      00B7DD F0               [24]  732 	movx	@dptr,a
                                    733 ;	quantum/vialrgb.c:36: length -= sizeof(id);
      00B7DE 1D               [12]  734 	dec	r5
      00B7DF 1D               [12]  735 	dec	r5
                                    736 ;	quantum/vialrgb.c:37: args += sizeof(id);
      00B7E0 74 02            [12]  737 	mov	a,#0x02
      00B7E2 2B               [12]  738 	add	a, r3
      00B7E3 FB               [12]  739 	mov	r3,a
      00B7E4 E4               [12]  740 	clr	a
      00B7E5 3C               [12]  741 	addc	a, r4
      00B7E6 FC               [12]  742 	mov	r4,a
      00B7E7 90 0D 96         [24]  743 	mov	dptr,#_get_supported_args_10000_252
      00B7EA 12 44 50         [24]  744 	lcall	_ak820_outline_0060
                                    745 ;	quantum/vialrgb.c:31: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7ED D0 07            [24]  746 	pop	ar7
      00B7EF D0 06            [24]  747 	pop	ar6
                                    748 ;	quantum/vialrgb.c:37: args += sizeof(id);
      00B7F1                        749 00111$:
                                    750 ;	quantum/vialrgb.c:31: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7F1 0A               [12]  751 	inc	r2
      00B7F2 80 B3            [24]  752 	sjmp	00110$
      00B7F4                        753 00127$:
      00B7F4 90 0D 96         [24]  754 	mov	dptr,#_get_supported_args_10000_252
      00B7F7 12 44 50         [24]  755 	lcall	_ak820_outline_0060
                                    756 ;	quantum/vialrgb.c:40: }
      00B7FA 22               [24]  757 	ret
                                    758 ;------------------------------------------------------------
                                    759 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    760 ;------------------------------------------------------------
                                    761 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_259'
                                    762 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_261'
                                    763 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_262'
                                    764 ;vialrgb_id    Allocated with name '_qmk_id_to_vialrgb_id_vialrgb_id_30000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	quantum/vialrgb.c:42: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function qmk_id_to_vialrgb_id
                                    769 ;	-----------------------------------------
      00B7FB                        770 _qmk_id_to_vialrgb_id:
      00B7FB 12 43 EA         [24]  771 	lcall	_ak820_outline_0010
      00B7FE 90 0D 98         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_259
      00B801 12 43 E5         [24]  773 	lcall	_ak820_outline_0007
                                    774 ;	quantum/vialrgb.c:43: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B804 90 0D 98         [24]  775 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_259
      00B807 12 43 C5         [24]  776 	lcall	_ak820_outline_0000
      00B80A 7D 00            [12]  777 	mov	r5,#0x00
      00B80C                        778 00105$:
      00B80C BD 07 00         [24]  779 	cjne	r5,#0x07,00130$
      00B80F                        780 00130$:
      00B80F 50 22            [24]  781 	jnc	00103$
                                    782 ;	quantum/vialrgb.c:44: uint16_t qmk_id = pgm_read_word(&supported_modes[i].qmk_id);
      00B811 12 BC 60         [24]  783 	lcall	_ak820_outline_0062
      00B814 12 43 F9         [24]  784 	lcall	_ak820_outline_0014
      00B817 12 BC 88         [24]  785 	lcall	_ak820_outline_0102
                                    786 ;	quantum/vialrgb.c:45: uint16_t vialrgb_id = pgm_read_word(&supported_modes[i].vialrgb_id);
      00B81A 12 43 F9         [24]  787 	lcall	_ak820_outline_0014
      00B81D E4               [12]  788 	clr	a
      00B81E 93               [24]  789 	movc	a,@a+dptr
      00B81F FB               [12]  790 	mov	r3,a
      00B820 A3               [24]  791 	inc	dptr
      00B821 E4               [12]  792 	clr	a
      00B822 93               [24]  793 	movc	a,@a+dptr
      00B823 FC               [12]  794 	mov	r4,a
                                    795 ;	quantum/vialrgb.c:46: if (qmk_id == id)
      00B824 E9               [12]  796 	mov	a,r1
      00B825 B5 06 08         [24]  797 	cjne	a,ar6,00106$
      00B828 EA               [12]  798 	mov	a,r2
      00B829 B5 07 04         [24]  799 	cjne	a,ar7,00106$
                                    800 ;	quantum/vialrgb.c:47: return vialrgb_id;
      00B82C 12 43 F9         [24]  801 	lcall	_ak820_outline_0014
      00B82F 22               [24]  802 	ret
      00B830                        803 00106$:
                                    804 ;	quantum/vialrgb.c:43: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B830 0D               [12]  805 	inc	r5
      00B831 80 D9            [24]  806 	sjmp	00105$
      00B833                        807 00103$:
                                    808 ;	quantum/vialrgb.c:49: return 0;
      00B833 90 00 00         [24]  809 	mov	dptr,#0x0000
                                    810 ;	quantum/vialrgb.c:50: }
      00B836 22               [24]  811 	ret
                                    812 ;------------------------------------------------------------
                                    813 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    814 ;------------------------------------------------------------
                                    815 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_264'
                                    816 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_266'
                                    817 ;qmk_id        Allocated with name '_vialrgb_id_to_qmk_id_qmk_id_30000_267'
                                    818 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_267'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/vialrgb.c:52: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function vialrgb_id_to_qmk_id
                                    823 ;	-----------------------------------------
      00B837                        824 _vialrgb_id_to_qmk_id:
      00B837 12 43 EA         [24]  825 	lcall	_ak820_outline_0010
      00B83A 90 0D 9A         [24]  826 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_264
      00B83D 12 43 E5         [24]  827 	lcall	_ak820_outline_0007
                                    828 ;	quantum/vialrgb.c:53: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B840 90 0D 9A         [24]  829 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_264
      00B843 12 43 C5         [24]  830 	lcall	_ak820_outline_0000
      00B846 7D 00            [12]  831 	mov	r5,#0x00
      00B848                        832 00105$:
      00B848 BD 07 00         [24]  833 	cjne	r5,#0x07,00130$
      00B84B                        834 00130$:
      00B84B 50 22            [24]  835 	jnc	00103$
                                    836 ;	quantum/vialrgb.c:54: uint16_t qmk_id = pgm_read_word(&supported_modes[i].qmk_id);
      00B84D 12 BC 60         [24]  837 	lcall	_ak820_outline_0062
      00B850 12 43 F9         [24]  838 	lcall	_ak820_outline_0014
      00B853 12 BC 88         [24]  839 	lcall	_ak820_outline_0102
                                    840 ;	quantum/vialrgb.c:55: uint16_t vialrgb_id = pgm_read_word(&supported_modes[i].vialrgb_id);
      00B856 12 43 F9         [24]  841 	lcall	_ak820_outline_0014
      00B859 E4               [12]  842 	clr	a
      00B85A 93               [24]  843 	movc	a,@a+dptr
      00B85B FB               [12]  844 	mov	r3,a
      00B85C A3               [24]  845 	inc	dptr
      00B85D E4               [12]  846 	clr	a
      00B85E 93               [24]  847 	movc	a,@a+dptr
      00B85F FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/vialrgb.c:56: if (vialrgb_id == id)
      00B860 EB               [12]  850 	mov	a,r3
      00B861 B5 06 08         [24]  851 	cjne	a,ar6,00106$
      00B864 EC               [12]  852 	mov	a,r4
      00B865 B5 07 04         [24]  853 	cjne	a,ar7,00106$
                                    854 ;	quantum/vialrgb.c:57: return qmk_id;
      00B868 12 44 06         [24]  855 	lcall	_ak820_outline_0016
      00B86B 22               [24]  856 	ret
      00B86C                        857 00106$:
                                    858 ;	quantum/vialrgb.c:53: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B86C 0D               [12]  859 	inc	r5
      00B86D 80 D9            [24]  860 	sjmp	00105$
      00B86F                        861 00103$:
                                    862 ;	quantum/vialrgb.c:59: return 0;
      00B86F 90 00 00         [24]  863 	mov	dptr,#0x0000
                                    864 ;	quantum/vialrgb.c:60: }
      00B872 22               [24]  865 	ret
                                    866 ;------------------------------------------------------------
                                    867 ;Allocation info for local variables in function 'get_mode'
                                    868 ;------------------------------------------------------------
                                    869 ;	quantum/vialrgb.c:62: static uint16_t get_mode(void) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function get_mode
                                    872 ;	-----------------------------------------
      00B873                        873 _get_mode:
                                    874 ;	quantum/vialrgb.c:64: if (!rgb_matrix_is_enabled())
      00B873 12 54 ED         [24]  875 	lcall	_rgb_matrix_is_enabled
      00B876 E5 82            [12]  876 	mov	a, dpl
      00B878 70 04            [24]  877 	jnz	00102$
                                    878 ;	quantum/vialrgb.c:65: return VIALRGB_EFFECT_OFF;
      00B87A 90 00 00         [24]  879 	mov	dptr,#0x0000
      00B87D 22               [24]  880 	ret
      00B87E                        881 00102$:
                                    882 ;	quantum/vialrgb.c:66: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B87E 12 54 F3         [24]  883 	lcall	_rgb_matrix_get_mode
      00B881 7E 00            [12]  884 	mov	r6,#0x00
      00B883 8E 83            [24]  885 	mov	dph, r6
                                    886 ;	quantum/vialrgb.c:67: }
      00B885 02 B7 FB         [24]  887 	ljmp	_qmk_id_to_vialrgb_id
                                    888 ;------------------------------------------------------------
                                    889 ;Allocation info for local variables in function 'set_mode'
                                    890 ;------------------------------------------------------------
                                    891 ;mode          Allocated with name '_set_mode_mode_10000_272'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/vialrgb.c:69: static void set_mode(uint16_t mode) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function set_mode
                                    896 ;	-----------------------------------------
      00B888                        897 _set_mode:
      00B888 12 43 EA         [24]  898 	lcall	_ak820_outline_0010
      00B88B 90 0D 9C         [24]  899 	mov	dptr,#_set_mode_mode_10000_272
      00B88E 12 43 E5         [24]  900 	lcall	_ak820_outline_0007
                                    901 ;	quantum/vialrgb.c:71: if (mode == VIALRGB_EFFECT_OFF) {
      00B891 90 0D 9C         [24]  902 	mov	dptr,#_set_mode_mode_10000_272
      00B894 12 43 C5         [24]  903 	lcall	_ak820_outline_0000
      00B897 90 0D 9C         [24]  904 	mov	dptr,#_set_mode_mode_10000_272
      00B89A 12 6D E3         [24]  905 	lcall	_ak820_outline_0018
      00B89D 70 03            [24]  906 	jnz	00102$
                                    907 ;	quantum/vialrgb.c:72: rgb_matrix_disable_noeeprom();
      00B89F 02 55 40         [24]  908 	ljmp	_rgb_matrix_disable_noeeprom
      00B8A2                        909 00102$:
                                    910 ;	quantum/vialrgb.c:74: rgb_matrix_enable_noeeprom();
      00B8A2 C0 07            [24]  911 	push	ar7
      00B8A4 C0 06            [24]  912 	push	ar6
      00B8A6 12 55 2F         [24]  913 	lcall	_rgb_matrix_enable_noeeprom
      00B8A9 D0 06            [24]  914 	pop	ar6
      00B8AB D0 07            [24]  915 	pop	ar7
                                    916 ;	quantum/vialrgb.c:75: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B8AD 12 43 D3         [24]  917 	lcall	_ak820_outline_0002
      00B8B0 12 B8 37         [24]  918 	lcall	_vialrgb_id_to_qmk_id
                                    919 ;	quantum/vialrgb.c:77: }
      00B8B3 02 55 49         [24]  920 	ljmp	_rgb_matrix_mode_noeeprom
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    923 ;------------------------------------------------------------
                                    924 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    925 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_277'
                                    926 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_278'
                                    927 ;------------------------------------------------------------
                                    928 ;	quantum/vialrgb.c:80: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    929 ;	-----------------------------------------
                                    930 ;	 function get_matrix_pos_for_led
                                    931 ;	-----------------------------------------
      00B8B6                        932 _get_matrix_pos_for_led:
      00B8B6 12 43 EA         [24]  933 	lcall	_ak820_outline_0010
      00B8B9 90 0D A0         [24]  934 	mov	dptr,#_get_matrix_pos_for_led_led_10000_277
      00B8BC 12 43 E5         [24]  935 	lcall	_ak820_outline_0007
                                    936 ;	quantum/vialrgb.c:82: uint8_t slot = ak820_rgb_slots[led];
      00B8BF 90 0D A0         [24]  937 	mov	dptr,#_get_matrix_pos_for_led_led_10000_277
      00B8C2 12 43 C5         [24]  938 	lcall	_ak820_outline_0000
      00B8C5 EE               [12]  939 	mov	a,r6
      00B8C6 24 44            [12]  940 	add	a, #_ak820_rgb_slots
      00B8C8 F5 82            [12]  941 	mov	dpl,a
      00B8CA EF               [12]  942 	mov	a,r7
      00B8CB 34 BE            [12]  943 	addc	a, #(_ak820_rgb_slots >> 8)
      00B8CD F5 83            [12]  944 	mov	dph,a
      00B8CF E4               [12]  945 	clr	a
      00B8D0 93               [24]  946 	movc	a,@a+dptr
      00B8D1 FF               [12]  947 	mov	r7,a
                                    948 ;	quantum/vialrgb.c:83: output[0] = slot >> 3;
      00B8D2 90 0D 9E         [24]  949 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8D5 12 44 17         [24]  950 	lcall	_ak820_outline_0025
      00B8D8 EF               [12]  951 	mov	a,r7
      00B8D9 12 57 27         [24]  952 	lcall	_ak820_outline_0133
      00B8DC 12 43 F4         [24]  953 	lcall	_ak820_outline_0012
      00B8DF F0               [24]  954 	movx	@dptr,a
                                    955 ;	quantum/vialrgb.c:84: output[1] = slot & 7;
      00B8E0 12 43 F4         [24]  956 	lcall	_ak820_outline_0012
      00B8E3 A3               [24]  957 	inc	dptr
      00B8E4 53 07 07         [24]  958 	anl	ar7,#0x07
      00B8E7 EF               [12]  959 	mov	a,r7
      00B8E8 F0               [24]  960 	movx	@dptr,a
                                    961 ;	quantum/vialrgb.c:97: }
      00B8E9 22               [24]  962 	ret
                                    963 ;------------------------------------------------------------
                                    964 ;Allocation info for local variables in function 'fast_set_leds'
                                    965 ;------------------------------------------------------------
                                    966 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    967 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    968 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    969 ;args          Allocated with name '_fast_set_leds_args_10000_279'
                                    970 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_282'
                                    971 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_282'
                                    972 ;i             Allocated with name '_fast_set_leds_i_20001_285'
                                    973 ;color         Allocated with name '_fast_set_leds_color_30001_286'
                                    974 ;val           Allocated with name '_fast_set_leds_val_30002_287'
                                    975 ;------------------------------------------------------------
                                    976 ;	quantum/vialrgb.c:99: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function fast_set_leds
                                    979 ;	-----------------------------------------
      00B8EA                        980 _fast_set_leds:
      00B8EA 12 43 EA         [24]  981 	lcall	_ak820_outline_0010
      00B8ED 90 0D A3         [24]  982 	mov	dptr,#_fast_set_leds_args_10000_279
      00B8F0 12 43 E5         [24]  983 	lcall	_ak820_outline_0007
                                    984 ;	quantum/vialrgb.c:102: if (length < 3) return;
      00B8F3 90 0D A2         [24]  985 	mov	dptr,#_fast_set_leds_PARM_2
      00B8F6 E0               [24]  986 	movx	a,@dptr
      00B8F7 FF               [12]  987 	mov	r7,a
      00B8F8 BF 03 00         [24]  988 	cjne	r7,#0x03,00159$
      00B8FB                        989 00159$:
      00B8FB 50 01            [24]  990 	jnc	00102$
      00B8FD 22               [24]  991 	ret
      00B8FE                        992 00102$:
                                    993 ;	quantum/vialrgb.c:104: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8FE 90 0D A3         [24]  994 	mov	dptr,#_fast_set_leds_args_10000_279
      00B901 12 44 17         [24]  995 	lcall	_ak820_outline_0025
      00B904 12 43 F4         [24]  996 	lcall	_ak820_outline_0012
      00B907 E0               [24]  997 	movx	a,@dptr
      00B908 FC               [12]  998 	mov	r4,a
      00B909 7B 00            [12]  999 	mov	r3,#0x00
      00B90B 12 43 F4         [24] 1000 	lcall	_ak820_outline_0012
      00B90E A3               [24] 1001 	inc	dptr
      00B90F E0               [24] 1002 	movx	a,@dptr
      00B910 FA               [12] 1003 	mov	r2,a
      00B911 79 00            [12] 1004 	mov	r1,#0x00
      00B913 90 0D A5         [24] 1005 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B916 E9               [12] 1006 	mov	a,r1
      00B917 4C               [12] 1007 	orl	a,r4
      00B918 F0               [24] 1008 	movx	@dptr,a
      00B919 EA               [12] 1009 	mov	a,r2
      00B91A 4B               [12] 1010 	orl	a,r3
      00B91B A3               [24] 1011 	inc	dptr
      00B91C F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	quantum/vialrgb.c:105: uint8_t num_leds = args[2];
      00B91D 12 43 F4         [24] 1014 	lcall	_ak820_outline_0012
      00B920 A3               [24] 1015 	inc	dptr
      00B921 A3               [24] 1016 	inc	dptr
      00B922 E0               [24] 1017 	movx	a,@dptr
      00B923 90 0D A7         [24] 1018 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B926 F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	quantum/vialrgb.c:106: length -= 3;
      00B927 EF               [12] 1021 	mov	a,r7
      00B928 24 FD            [12] 1022 	add	a,#0xfd
      00B92A 90 0D A2         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00B92D F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/vialrgb.c:107: args += 3;
      00B92E 90 0D A3         [24] 1026 	mov	dptr,#_fast_set_leds_args_10000_279
      00B931 74 03            [12] 1027 	mov	a,#0x03
      00B933 2D               [12] 1028 	add	a, r5
      00B934 F0               [24] 1029 	movx	@dptr,a
      00B935 E4               [12] 1030 	clr	a
      00B936 3E               [12] 1031 	addc	a, r6
      00B937 A3               [24] 1032 	inc	dptr
      00B938 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	quantum/vialrgb.c:110: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B939 90 0D A7         [24] 1035 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B93C E0               [24] 1036 	movx	a,@dptr
      00B93D FF               [12] 1037 	mov	r7,a
      00B93E 75 F0 03         [24] 1038 	mov	b,#0x03
      00B941 A4               [48] 1039 	mul	ab
      00B942 FE               [12] 1040 	mov	r6,a
      00B943 AD F0            [24] 1041 	mov	r5,b
      00B945 90 0D A2         [24] 1042 	mov	dptr,#_fast_set_leds_PARM_2
      00B948 E0               [24] 1043 	movx	a,@dptr
      00B949 FB               [12] 1044 	mov	r3,a
      00B94A 7C 00            [12] 1045 	mov	r4,#0x00
      00B94C C3               [12] 1046 	clr	c
      00B94D EB               [12] 1047 	mov	a,r3
      00B94E 9E               [12] 1048 	subb	a,r6
      00B94F EC               [12] 1049 	mov	a,r4
      00B950 9D               [12] 1050 	subb	a,r5
      00B951 40 13            [24] 1051 	jc	00103$
                                   1052 ;	free result
      00B953 90 0D A5         [24] 1053 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B956 12 44 17         [24] 1054 	lcall	_ak820_outline_0025
      00B959 8D 03            [24] 1055 	mov	ar3,r5
      00B95B 8E 04            [24] 1056 	mov	ar4,r6
      00B95D C3               [12] 1057 	clr	c
      00B95E EB               [12] 1058 	mov	a,r3
      00B95F 94 52            [12] 1059 	subb	a,#0x52
      00B961 EC               [12] 1060 	mov	a,r4
      00B962 94 00            [12] 1061 	subb	a,#0x00
      00B964 40 01            [24] 1062 	jc	00104$
      00B966                       1063 00103$:
      00B966 22               [24] 1064 	ret
      00B967                       1065 00104$:
                                   1066 ;	quantum/vialrgb.c:111: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B967 74 52            [12] 1067 	mov	a,#0x52
      00B969 C3               [12] 1068 	clr	c
      00B96A 9D               [12] 1069 	subb	a,r5
      00B96B FB               [12] 1070 	mov	r3,a
      00B96C E4               [12] 1071 	clr	a
      00B96D 9E               [12] 1072 	subb	a,r6
      00B96E FC               [12] 1073 	mov	r4,a
      00B96F 7A 00            [12] 1074 	mov	r2,#0x00
      00B971 C3               [12] 1075 	clr	c
      00B972 EB               [12] 1076 	mov	a,r3
      00B973 9F               [12] 1077 	subb	a,r7
      00B974 EC               [12] 1078 	mov	a,r4
      00B975 9A               [12] 1079 	subb	a,r2
      00B976 50 08            [24] 1080 	jnc	00127$
                                   1081 ;	free result
      00B978 90 0D A7         [24] 1082 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B97B 74 52            [12] 1083 	mov	a,#0x52
      00B97D C3               [12] 1084 	clr	c
      00B97E 9D               [12] 1085 	subb	a,r5
      00B97F F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	quantum/vialrgb.c:113: for (uint8_t i = 0; i < num_leds; ++i) {
      00B980                       1088 00127$:
      00B980 90 0D A7         [24] 1089 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B983 E0               [24] 1090 	movx	a,@dptr
      00B984 FF               [12] 1091 	mov	r7,a
      00B985 90 0D A5         [24] 1092 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B988 12 44 17         [24] 1093 	lcall	_ak820_outline_0025
      00B98B 7C 00            [12] 1094 	mov	r4,#0x00
      00B98D                       1095 00110$:
      00B98D C3               [12] 1096 	clr	c
      00B98E EC               [12] 1097 	mov	a,r4
      00B98F 9F               [12] 1098 	subb	a,r7
      00B990 40 01            [24] 1099 	jc	00164$
      00B992 22               [24] 1100 	ret
      00B993                       1101 00164$:
                                   1102 ;	quantum/vialrgb.c:114: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B993 C0 07            [24] 1103 	push	ar7
      00B995 90 0D BF         [24] 1104 	mov	dptr,#__mulint_PARM_2
      00B998 12 44 56         [24] 1105 	lcall	_ak820_outline_0071
      00B99B 90 00 03         [24] 1106 	mov	dptr,#0x0003
      00B99E C0 07            [24] 1107 	push	ar7
      00B9A0 C0 06            [24] 1108 	push	ar6
      00B9A2 C0 05            [24] 1109 	push	ar5
      00B9A4 C0 04            [24] 1110 	push	ar4
      00B9A6 12 BD F4         [24] 1111 	lcall	__mulint
      00B9A9 AA 82            [24] 1112 	mov	r2, dpl
      00B9AB AB 83            [24] 1113 	mov	r3, dph
      00B9AD D0 04            [24] 1114 	pop	ar4
      00B9AF D0 05            [24] 1115 	pop	ar5
      00B9B1 D0 06            [24] 1116 	pop	ar6
      00B9B3 D0 07            [24] 1117 	pop	ar7
      00B9B5 0D               [12] 1118 	inc	r5
      00B9B6 BD 00 01         [24] 1119 	cjne	r5,#0x00,00165$
      00B9B9 0E               [12] 1120 	inc	r6
      00B9BA                       1121 00165$:
      00B9BA EA               [12] 1122 	mov	a,r2
      00B9BB 24 9F            [12] 1123 	add	a, #_g_direct_mode_colors
      00B9BD FA               [12] 1124 	mov	r2,a
      00B9BE EB               [12] 1125 	mov	a,r3
      00B9BF 34 0C            [12] 1126 	addc	a, #(_g_direct_mode_colors >> 8)
      00B9C1 FB               [12] 1127 	mov	r3,a
                                   1128 ;	quantum/vialrgb.c:115: color->h = *args++;
      00B9C2 8A 50            [24] 1129 	mov	_fast_set_leds_sloc0_1_0,r2
      00B9C4 8B 51            [24] 1130 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B9C6 12 BC 6E         [24] 1131 	lcall	_ak820_outline_0064
      00B9C9 F8               [12] 1132 	mov	r0,a
      00B9CA 12 BC 7C         [24] 1133 	lcall	_ak820_outline_0084
      00B9CD 85 50 82         [24] 1134 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9D0 85 51 83         [24] 1135 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9D3 E8               [12] 1136 	mov	a,r0
      00B9D4 F0               [24] 1137 	movx	@dptr,a
                                   1138 ;	quantum/vialrgb.c:116: color->s = *args++;
      00B9D5 74 01            [12] 1139 	mov	a,#0x01
      00B9D7 2A               [12] 1140 	add	a, r2
      00B9D8 F5 50            [12] 1141 	mov	_fast_set_leds_sloc0_1_0,a
      00B9DA E4               [12] 1142 	clr	a
      00B9DB 3B               [12] 1143 	addc	a, r3
      00B9DC F5 51            [12] 1144 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B9DE 90 0D A3         [24] 1145 	mov	dptr,#_fast_set_leds_args_10000_279
      00B9E1 E0               [24] 1146 	movx	a,@dptr
      00B9E2 F8               [12] 1147 	mov	r0,a
      00B9E3 A3               [24] 1148 	inc	dptr
      00B9E4 E0               [24] 1149 	movx	a,@dptr
      00B9E5 FF               [12] 1150 	mov	r7,a
      00B9E6 88 82            [24] 1151 	mov	dpl,r0
      00B9E8 8F 83            [24] 1152 	mov	dph,r7
      00B9EA E0               [24] 1153 	movx	a,@dptr
      00B9EB F9               [12] 1154 	mov	r1,a
      00B9EC 90 0D A3         [24] 1155 	mov	dptr,#_fast_set_leds_args_10000_279
      00B9EF 74 01            [12] 1156 	mov	a,#0x01
      00B9F1 28               [12] 1157 	add	a, r0
      00B9F2 F0               [24] 1158 	movx	@dptr,a
      00B9F3 E4               [12] 1159 	clr	a
      00B9F4 3F               [12] 1160 	addc	a, r7
      00B9F5 A3               [24] 1161 	inc	dptr
      00B9F6 F0               [24] 1162 	movx	@dptr,a
      00B9F7 85 50 82         [24] 1163 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9FA 85 51 83         [24] 1164 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9FD E9               [12] 1165 	mov	a,r1
      00B9FE F0               [24] 1166 	movx	@dptr,a
                                   1167 ;	quantum/vialrgb.c:117: uint8_t val = *args++;
      00B9FF 12 BC 6E         [24] 1168 	lcall	_ak820_outline_0064
      00BA02 F5 50            [12] 1169 	mov	_fast_set_leds_sloc0_1_0,a
      00BA04 12 BC 7C         [24] 1170 	lcall	_ak820_outline_0084
                                   1171 ;	quantum/vialrgb.c:118: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BA07 74 02            [12] 1172 	mov	a,#0x02
      00BA09 2A               [12] 1173 	add	a, r2
      00BA0A F5 52            [12] 1174 	mov	_fast_set_leds_sloc1_1_0,a
      00BA0C E4               [12] 1175 	clr	a
      00BA0D 3B               [12] 1176 	addc	a, r3
      00BA0E F5 53            [12] 1177 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BA10 C3               [12] 1178 	clr	c
      00BA11 74 A0            [12] 1179 	mov	a,#0xa0
      00BA13 95 50            [12] 1180 	subb	a,_fast_set_leds_sloc0_1_0
      00BA15 D0 07            [24] 1181 	pop	ar7
      00BA17 50 04            [24] 1182 	jnc	00114$
                                   1183 ;	free result
      00BA19 7B A0            [12] 1184 	mov	r3,#0xa0
      00BA1B 80 04            [24] 1185 	sjmp	00115$
      00BA1D                       1186 00114$:
      00BA1D AA 50            [24] 1187 	mov	r2,_fast_set_leds_sloc0_1_0
      00BA1F 8A 03            [24] 1188 	mov	ar3,r2
      00BA21                       1189 00115$:
      00BA21 85 52 82         [24] 1190 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BA24 85 53 83         [24] 1191 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BA27 EB               [12] 1192 	mov	a,r3
      00BA28 F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/vialrgb.c:113: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA29 0C               [12] 1195 	inc	r4
                                   1196 ;	quantum/vialrgb.c:120: }
      00BA2A 02 B9 8D         [24] 1197 	ljmp	00110$
                                   1198 ;------------------------------------------------------------
                                   1199 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1200 ;------------------------------------------------------------
                                   1201 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1202 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1203 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1204 ;data          Allocated with name '_vialrgb_get_value_data_10000_288'
                                   1205 ;args          Allocated with name '_vialrgb_get_value_args_10001_291'
                                   1206 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_291'
                                   1207 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_294'
                                   1208 ;led           Allocated with name '_vialrgb_get_value_led_40001_297'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/vialrgb.c:123: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function vialrgb_get_value
                                   1213 ;	-----------------------------------------
      00BA2D                       1214 _vialrgb_get_value:
      00BA2D 12 43 D8         [24] 1215 	lcall	_ak820_outline_0004
      00BA30 90 0D A9         [24] 1216 	mov	dptr,#_vialrgb_get_value_data_10000_288
      00BA33 12 43 CB         [24] 1217 	lcall	_ak820_outline_0001
                                   1218 ;	quantum/vialrgb.c:124: if (length != VIAL_RAW_EPSIZE) return;
      00BA36 90 0D A8         [24] 1219 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA39 E0               [24] 1220 	movx	a,@dptr
      00BA3A FF               [12] 1221 	mov	r7,a
      00BA3B BF 20 02         [24] 1222 	cjne	r7,#0x20,00162$
      00BA3E 80 01            [24] 1223 	sjmp	00102$
      00BA40                       1224 00162$:
      00BA40 22               [24] 1225 	ret
      00BA41                       1226 00102$:
                                   1227 ;	quantum/vialrgb.c:127: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA41 90 0D A9         [24] 1228 	mov	dptr,#_vialrgb_get_value_data_10000_288
      00BA44 12 44 17         [24] 1229 	lcall	_ak820_outline_0025
      00BA47 74 02            [12] 1230 	mov	a,#0x02
      00BA49 2D               [12] 1231 	add	a, r5
      00BA4A FB               [12] 1232 	mov	r3,a
      00BA4B E4               [12] 1233 	clr	a
      00BA4C 3E               [12] 1234 	addc	a, r6
      00BA4D FC               [12] 1235 	mov	r4,a
                                   1236 ;	quantum/vialrgb.c:128: uint8_t cmd = args[-1];
      00BA4E 12 43 F4         [24] 1237 	lcall	_ak820_outline_0012
      00BA51 A3               [24] 1238 	inc	dptr
      00BA52 E0               [24] 1239 	movx	a,@dptr
      00BA53 FA               [12] 1240 	mov	r2,a
                                   1241 ;	quantum/vialrgb.c:129: switch (cmd) {
      00BA54 BA 40 02         [24] 1242 	cjne	r2,#0x40,00163$
      00BA57 80 18            [24] 1243 	sjmp	00103$
      00BA59                       1244 00163$:
      00BA59 BA 41 02         [24] 1245 	cjne	r2,#0x41,00164$
      00BA5C 80 2B            [24] 1246 	sjmp	00104$
      00BA5E                       1247 00164$:
      00BA5E BA 42 03         [24] 1248 	cjne	r2,#0x42,00165$
      00BA61 02 BB 26         [24] 1249 	ljmp	00105$
      00BA64                       1250 00165$:
      00BA64 BA 43 03         [24] 1251 	cjne	r2,#0x43,00166$
      00BA67 02 BB 33         [24] 1252 	ljmp	00106$
      00BA6A                       1253 00166$:
      00BA6A BA 44 03         [24] 1254 	cjne	r2,#0x44,00167$
      00BA6D 02 BB 42         [24] 1255 	ljmp	00107$
      00BA70                       1256 00167$:
      00BA70 22               [24] 1257 	ret
                                   1258 ;	quantum/vialrgb.c:130: case vialrgb_get_info:
      00BA71                       1259 00103$:
                                   1260 ;	quantum/vialrgb.c:131: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA71 12 43 F9         [24] 1261 	lcall	_ak820_outline_0014
      00BA74 74 01            [12] 1262 	mov	a,#0x01
      00BA76 F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/vialrgb.c:132: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA77 12 43 F4         [24] 1265 	lcall	_ak820_outline_0012
      00BA7A A3               [24] 1266 	inc	dptr
      00BA7B A3               [24] 1267 	inc	dptr
      00BA7C A3               [24] 1268 	inc	dptr
      00BA7D E4               [12] 1269 	clr	a
      00BA7E F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vialrgb.c:133: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA7F 12 43 F4         [24] 1272 	lcall	_ak820_outline_0012
      00BA82 12 B0 F8         [24] 1273 	lcall	_ak820_outline_0099
      00BA85 74 A0            [12] 1274 	mov	a,#0xa0
      00BA87 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	quantum/vialrgb.c:134: break;
      00BA88 22               [24] 1277 	ret
                                   1278 ;	quantum/vialrgb.c:135: case vialrgb_get_mode: {
      00BA89                       1279 00104$:
                                   1280 ;	quantum/vialrgb.c:136: uint16_t vialrgb_id = get_mode();
      00BA89 C0 06            [24] 1281 	push	ar6
      00BA8B C0 05            [24] 1282 	push	ar5
      00BA8D C0 04            [24] 1283 	push	ar4
      00BA8F C0 03            [24] 1284 	push	ar3
      00BA91 12 B8 73         [24] 1285 	lcall	_get_mode
      00BA94 A9 82            [24] 1286 	mov	r1, dpl
      00BA96 AA 83            [24] 1287 	mov	r2, dph
      00BA98 D0 03            [24] 1288 	pop	ar3
      00BA9A D0 04            [24] 1289 	pop	ar4
      00BA9C D0 05            [24] 1290 	pop	ar5
      00BA9E D0 06            [24] 1291 	pop	ar6
                                   1292 ;	quantum/vialrgb.c:137: args[0] = vialrgb_id & 0xFF;
      00BAA0 89 00            [24] 1293 	mov	ar0,r1
      00BAA2 12 43 F9         [24] 1294 	lcall	_ak820_outline_0014
      00BAA5 E8               [12] 1295 	mov	a,r0
      00BAA6 F0               [24] 1296 	movx	@dptr,a
                                   1297 ;	quantum/vialrgb.c:138: args[1] = vialrgb_id >> 8;
      00BAA7 12 43 F4         [24] 1298 	lcall	_ak820_outline_0012
      00BAAA A3               [24] 1299 	inc	dptr
      00BAAB A3               [24] 1300 	inc	dptr
      00BAAC A3               [24] 1301 	inc	dptr
      00BAAD 8A 01            [24] 1302 	mov	ar1,r2
      00BAAF E9               [12] 1303 	mov	a,r1
      00BAB0 F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	quantum/vialrgb.c:139: args[2] = rgb_matrix_get_speed();
      00BAB1 74 04            [12] 1306 	mov	a,#0x04
      00BAB3 12 8E E9         [24] 1307 	lcall	_ak820_outline_0049
      00BAB6 C0 06            [24] 1308 	push	ar6
      00BAB8 C0 05            [24] 1309 	push	ar5
      00BABA C0 02            [24] 1310 	push	ar2
      00BABC C0 01            [24] 1311 	push	ar1
      00BABE 12 55 0E         [24] 1312 	lcall	_rgb_matrix_get_speed
      00BAC1 A8 82            [24] 1313 	mov	r0, dpl
      00BAC3 D0 01            [24] 1314 	pop	ar1
      00BAC5 D0 02            [24] 1315 	pop	ar2
      00BAC7 D0 05            [24] 1316 	pop	ar5
      00BAC9 D0 06            [24] 1317 	pop	ar6
      00BACB 12 44 06         [24] 1318 	lcall	_ak820_outline_0016
      00BACE E8               [12] 1319 	mov	a,r0
      00BACF F0               [24] 1320 	movx	@dptr,a
                                   1321 ;	quantum/vialrgb.c:140: args[3] = rgb_matrix_get_hue();
      00BAD0 74 05            [12] 1322 	mov	a,#0x05
      00BAD2 12 8E E9         [24] 1323 	lcall	_ak820_outline_0049
      00BAD5 C0 06            [24] 1324 	push	ar6
      00BAD7 C0 05            [24] 1325 	push	ar5
      00BAD9 C0 02            [24] 1326 	push	ar2
      00BADB C0 01            [24] 1327 	push	ar1
      00BADD 12 54 F9         [24] 1328 	lcall	_rgb_matrix_get_hue
      00BAE0 A8 82            [24] 1329 	mov	r0, dpl
      00BAE2 D0 01            [24] 1330 	pop	ar1
      00BAE4 D0 02            [24] 1331 	pop	ar2
      00BAE6 D0 05            [24] 1332 	pop	ar5
      00BAE8 D0 06            [24] 1333 	pop	ar6
      00BAEA 12 44 06         [24] 1334 	lcall	_ak820_outline_0016
      00BAED E8               [12] 1335 	mov	a,r0
      00BAEE F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:141: args[4] = rgb_matrix_get_sat();
      00BAEF 74 06            [12] 1338 	mov	a,#0x06
      00BAF1 12 8E E9         [24] 1339 	lcall	_ak820_outline_0049
      00BAF4 C0 06            [24] 1340 	push	ar6
      00BAF6 C0 05            [24] 1341 	push	ar5
      00BAF8 C0 02            [24] 1342 	push	ar2
      00BAFA C0 01            [24] 1343 	push	ar1
      00BAFC 12 55 00         [24] 1344 	lcall	_rgb_matrix_get_sat
      00BAFF A8 82            [24] 1345 	mov	r0, dpl
      00BB01 D0 01            [24] 1346 	pop	ar1
      00BB03 D0 02            [24] 1347 	pop	ar2
      00BB05 D0 05            [24] 1348 	pop	ar5
      00BB07 D0 06            [24] 1349 	pop	ar6
      00BB09 12 44 06         [24] 1350 	lcall	_ak820_outline_0016
      00BB0C E8               [12] 1351 	mov	a,r0
      00BB0D F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vialrgb.c:142: args[5] = rgb_matrix_get_val();
      00BB0E 74 07            [12] 1354 	mov	a,#0x07
      00BB10 12 8E E9         [24] 1355 	lcall	_ak820_outline_0049
      00BB13 C0 02            [24] 1356 	push	ar2
      00BB15 C0 01            [24] 1357 	push	ar1
      00BB17 12 55 07         [24] 1358 	lcall	_rgb_matrix_get_val
      00BB1A A8 82            [24] 1359 	mov	r0, dpl
      00BB1C D0 01            [24] 1360 	pop	ar1
      00BB1E D0 02            [24] 1361 	pop	ar2
      00BB20 12 44 06         [24] 1362 	lcall	_ak820_outline_0016
      00BB23 E8               [12] 1363 	mov	a,r0
      00BB24 F0               [24] 1364 	movx	@dptr,a
                                   1365 ;	quantum/vialrgb.c:143: break;
      00BB25 22               [24] 1366 	ret
                                   1367 ;	quantum/vialrgb.c:145: case vialrgb_get_supported: {
      00BB26                       1368 00105$:
                                   1369 ;	quantum/vialrgb.c:146: get_supported(args, length - 2);
      00BB26 EF               [12] 1370 	mov	a,r7
      00BB27 24 FE            [12] 1371 	add	a,#0xfe
      00BB29 90 0D 95         [24] 1372 	mov	dptr,#_get_supported_PARM_2
      00BB2C F0               [24] 1373 	movx	@dptr,a
      00BB2D 12 43 F9         [24] 1374 	lcall	_ak820_outline_0014
                                   1375 ;	quantum/vialrgb.c:147: break;
      00BB30 02 B7 66         [24] 1376 	ljmp	_get_supported
                                   1377 ;	quantum/vialrgb.c:150: case vialrgb_get_number_leds: {
      00BB33                       1378 00106$:
                                   1379 ;	quantum/vialrgb.c:151: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BB33 12 43 F9         [24] 1380 	lcall	_ak820_outline_0014
      00BB36 74 52            [12] 1381 	mov	a,#0x52
      00BB38 F0               [24] 1382 	movx	@dptr,a
                                   1383 ;	quantum/vialrgb.c:152: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BB39 12 43 F4         [24] 1384 	lcall	_ak820_outline_0012
      00BB3C A3               [24] 1385 	inc	dptr
      00BB3D A3               [24] 1386 	inc	dptr
      00BB3E A3               [24] 1387 	inc	dptr
      00BB3F E4               [12] 1388 	clr	a
      00BB40 F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vialrgb.c:153: break;
      00BB41 22               [24] 1391 	ret
                                   1392 ;	quantum/vialrgb.c:155: case vialrgb_get_led_info: {
      00BB42                       1393 00107$:
                                   1394 ;	quantum/vialrgb.c:156: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BB42 12 43 F9         [24] 1395 	lcall	_ak820_outline_0014
      00BB45 E0               [24] 1396 	movx	a,@dptr
      00BB46 FF               [12] 1397 	mov	r7,a
      00BB47 7A 00            [12] 1398 	mov	r2,#0x00
      00BB49 74 03            [12] 1399 	mov	a,#0x03
      00BB4B 2D               [12] 1400 	add	a, r5
      00BB4C F8               [12] 1401 	mov	r0,a
      00BB4D E4               [12] 1402 	clr	a
      00BB4E 3E               [12] 1403 	addc	a, r6
      00BB4F F9               [12] 1404 	mov	r1,a
      00BB50 C0 03            [24] 1405 	push	ar3
      00BB52 C0 04            [24] 1406 	push	ar4
      00BB54 12 81 5F         [24] 1407 	lcall	_ak820_outline_0100
      00BB57 E0               [24] 1408 	movx	a,@dptr
      00BB58 FB               [12] 1409 	mov	r3,a
      00BB59 E4               [12] 1410 	clr	a
      00BB5A 4F               [12] 1411 	orl	a,r7
      00BB5B F5 54            [12] 1412 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB5D EB               [12] 1413 	mov	a,r3
      00BB5E 4A               [12] 1414 	orl	a,r2
      00BB5F F5 55            [12] 1415 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1416 ;	quantum/vialrgb.c:157: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB61 AC 54            [24] 1417 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB63 AF 55            [24] 1418 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB65 C3               [12] 1419 	clr	c
      00BB66 EC               [12] 1420 	mov	a,r4
      00BB67 94 52            [12] 1421 	subb	a,#0x52
      00BB69 EF               [12] 1422 	mov	a,r7
      00BB6A 94 00            [12] 1423 	subb	a,#0x00
      00BB6C D0 04            [24] 1424 	pop	ar4
      00BB6E D0 03            [24] 1425 	pop	ar3
      00BB70 40 01            [24] 1426 	jc	00109$
      00BB72 22               [24] 1427 	ret
      00BB73                       1428 00109$:
                                   1429 ;	quantum/vialrgb.c:159: args[0] = ak820_led_points[led].x;
      00BB73 E5 54            [12] 1430 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB75 25 54            [12] 1431 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB77 FA               [12] 1432 	mov	r2,a
      00BB78 E5 55            [12] 1433 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB7A 33               [12] 1434 	rlc	a
      00BB7B FF               [12] 1435 	mov	r7,a
      00BB7C EA               [12] 1436 	mov	a,r2
      00BB7D 24 06            [12] 1437 	add	a, #_ak820_led_points
      00BB7F F5 56            [12] 1438 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB81 EF               [12] 1439 	mov	a,r7
      00BB82 34 C1            [12] 1440 	addc	a, #(_ak820_led_points >> 8)
      00BB84 F5 57            [12] 1441 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB86 85 56 82         [24] 1442 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB89 85 57 83         [24] 1443 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB8C E4               [12] 1444 	clr	a
      00BB8D 93               [24] 1445 	movc	a,@a+dptr
      00BB8E 12 43 F9         [24] 1446 	lcall	_ak820_outline_0014
      00BB91 F0               [24] 1447 	movx	@dptr,a
                                   1448 ;	quantum/vialrgb.c:160: args[1] = ak820_led_points[led].y;
      00BB92 85 56 82         [24] 1449 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB95 85 57 83         [24] 1450 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB98 A3               [24] 1451 	inc	dptr
      00BB99 E4               [12] 1452 	clr	a
      00BB9A 93               [24] 1453 	movc	a,@a+dptr
      00BB9B 12 81 5F         [24] 1454 	lcall	_ak820_outline_0100
      00BB9E F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	quantum/vialrgb.c:161: args[2] = LED_FLAG_KEYLIGHT;
      00BB9F 12 43 F4         [24] 1457 	lcall	_ak820_outline_0012
      00BBA2 12 B0 F8         [24] 1458 	lcall	_ak820_outline_0099
      00BBA5 74 04            [12] 1459 	mov	a,#0x04
      00BBA7 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	quantum/vialrgb.c:170: get_matrix_pos_for_led(led, &args[3]);
      00BBA8 90 0D 9E         [24] 1462 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BBAB 04               [12] 1463 	inc	a
      00BBAC 2D               [12] 1464 	add	a, r5
      00BBAD F0               [24] 1465 	movx	@dptr,a
      00BBAE E4               [12] 1466 	clr	a
      00BBAF 3E               [12] 1467 	addc	a, r6
      00BBB0 A3               [24] 1468 	inc	dptr
      00BBB1 F0               [24] 1469 	movx	@dptr,a
      00BBB2 85 54 82         [24] 1470 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BBB5 85 55 83         [24] 1471 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1472 ;	quantum/vialrgb.c:174: }
                                   1473 ;	quantum/vialrgb.c:175: }
      00BBB8 02 B8 B6         [24] 1474 	ljmp	_get_matrix_pos_for_led
                                   1475 ;------------------------------------------------------------
                                   1476 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1477 ;------------------------------------------------------------
                                   1478 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1479 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1480 ;data          Allocated with name '_vialrgb_set_value_data_10000_299'
                                   1481 ;args          Allocated with name '_vialrgb_set_value_args_10001_302'
                                   1482 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_302'
                                   1483 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_305'
                                   1484 ;------------------------------------------------------------
                                   1485 ;	quantum/vialrgb.c:177: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1486 ;	-----------------------------------------
                                   1487 ;	 function vialrgb_set_value
                                   1488 ;	-----------------------------------------
      00BBBB                       1489 _vialrgb_set_value:
      00BBBB 12 43 D8         [24] 1490 	lcall	_ak820_outline_0004
      00BBBE 90 0D AD         [24] 1491 	mov	dptr,#_vialrgb_set_value_data_10000_299
      00BBC1 12 43 CB         [24] 1492 	lcall	_ak820_outline_0001
                                   1493 ;	quantum/vialrgb.c:178: if (length != VIAL_RAW_EPSIZE) return;
      00BBC4 90 0D AC         [24] 1494 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BBC7 E0               [24] 1495 	movx	a,@dptr
      00BBC8 FF               [12] 1496 	mov	r7,a
      00BBC9 BF 20 02         [24] 1497 	cjne	r7,#0x20,00129$
      00BBCC 80 01            [24] 1498 	sjmp	00102$
      00BBCE                       1499 00129$:
      00BBCE 22               [24] 1500 	ret
      00BBCF                       1501 00102$:
                                   1502 ;	quantum/vialrgb.c:181: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BBCF 90 0D AD         [24] 1503 	mov	dptr,#_vialrgb_set_value_data_10000_299
      00BBD2 12 44 17         [24] 1504 	lcall	_ak820_outline_0025
      00BBD5 74 02            [12] 1505 	mov	a,#0x02
      00BBD7 2D               [12] 1506 	add	a, r5
      00BBD8 FB               [12] 1507 	mov	r3,a
      00BBD9 E4               [12] 1508 	clr	a
      00BBDA 3E               [12] 1509 	addc	a, r6
      00BBDB FC               [12] 1510 	mov	r4,a
                                   1511 ;	quantum/vialrgb.c:182: uint8_t cmd = args[-1];
      00BBDC 12 43 F4         [24] 1512 	lcall	_ak820_outline_0012
      00BBDF A3               [24] 1513 	inc	dptr
      00BBE0 E0               [24] 1514 	movx	a,@dptr
      00BBE1 FA               [12] 1515 	mov	r2,a
                                   1516 ;	quantum/vialrgb.c:183: switch (cmd) {
      00BBE2 BA 41 02         [24] 1517 	cjne	r2,#0x41,00130$
      00BBE5 80 06            [24] 1518 	sjmp	00103$
      00BBE7                       1519 00130$:
      00BBE7 BA 42 02         [24] 1520 	cjne	r2,#0x42,00131$
      00BBEA 80 64            [24] 1521 	sjmp	00104$
      00BBEC                       1522 00131$:
      00BBEC 22               [24] 1523 	ret
                                   1524 ;	quantum/vialrgb.c:184: case vialrgb_set_mode: {
      00BBED                       1525 00103$:
                                   1526 ;	quantum/vialrgb.c:185: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BBED 12 43 F9         [24] 1527 	lcall	_ak820_outline_0014
      00BBF0 E0               [24] 1528 	movx	a,@dptr
      00BBF1 FA               [12] 1529 	mov	r2,a
      00BBF2 12 43 F4         [24] 1530 	lcall	_ak820_outline_0012
      00BBF5 12 B0 C5         [24] 1531 	lcall	_ak820_outline_0026
      00BBF8 F8               [12] 1532 	mov	r0,a
      00BBF9 79 00            [12] 1533 	mov	r1,#0x00
      00BBFB 88 59            [24] 1534 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BBFD 89 58            [24] 1535 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BBFF 8A 01            [24] 1536 	mov	ar1,r2
      00BC01 7A 00            [12] 1537 	mov	r2,#0x00
      00BC03 E5 59            [12] 1538 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BC05 42 02            [12] 1539 	orl	ar2,a
                                   1540 ;	quantum/vialrgb.c:186: set_mode(vialrgb_id);
      00BC07 12 44 06         [24] 1541 	lcall	_ak820_outline_0016
      00BC0A C0 06            [24] 1542 	push	ar6
      00BC0C C0 05            [24] 1543 	push	ar5
      00BC0E 12 B8 88         [24] 1544 	lcall	_set_mode
      00BC11 D0 05            [24] 1545 	pop	ar5
      00BC13 D0 06            [24] 1546 	pop	ar6
                                   1547 ;	quantum/vialrgb.c:187: rgb_matrix_set_speed_noeeprom(args[2]);
      00BC15 12 43 F4         [24] 1548 	lcall	_ak820_outline_0012
      00BC18 A3               [24] 1549 	inc	dptr
      00BC19 12 B0 C5         [24] 1550 	lcall	_ak820_outline_0026
      00BC1C F5 82            [12] 1551 	mov	dpl,a
      00BC1E C0 06            [24] 1552 	push	ar6
      00BC20 C0 05            [24] 1553 	push	ar5
      00BC22 12 55 DC         [24] 1554 	lcall	_rgb_matrix_set_speed_noeeprom
      00BC25 D0 05            [24] 1555 	pop	ar5
      00BC27 D0 06            [24] 1556 	pop	ar6
                                   1557 ;	quantum/vialrgb.c:188: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BC29 12 43 F4         [24] 1558 	lcall	_ak820_outline_0012
      00BC2C A3               [24] 1559 	inc	dptr
      00BC2D A3               [24] 1560 	inc	dptr
      00BC2E 12 B0 C5         [24] 1561 	lcall	_ak820_outline_0026
      00BC31 F9               [12] 1562 	mov	r1,a
      00BC32 7A 00            [12] 1563 	mov	r2,#0x00
      00BC34 74 06            [12] 1564 	mov	a,#0x06
      00BC36 12 BC 92         [24] 1565 	lcall	_ak820_outline_0134
      00BC39 F8               [12] 1566 	mov	r0,a
      00BC3A 74 07            [12] 1567 	mov	a,#0x07
      00BC3C 12 BC 92         [24] 1568 	lcall	_ak820_outline_0134
      00BC3F FE               [12] 1569 	mov	r6,a
      00BC40 90 07 20         [24] 1570 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BC43 E8               [12] 1571 	mov	a,r0
      00BC44 F0               [24] 1572 	movx	@dptr,a
      00BC45 90 07 21         [24] 1573 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BC48 EE               [12] 1574 	mov	a,r6
      00BC49 F0               [24] 1575 	movx	@dptr,a
      00BC4A 12 44 06         [24] 1576 	lcall	_ak820_outline_0016
                                   1577 ;	quantum/vialrgb.c:189: break;
                                   1578 ;	quantum/vialrgb.c:192: case vialrgb_direct_fastset: {
      00BC4D 02 55 AD         [24] 1579 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BC50                       1580 00104$:
                                   1581 ;	quantum/vialrgb.c:193: fast_set_leds(args, length - 2);
      00BC50 EF               [12] 1582 	mov	a,r7
      00BC51 24 FE            [12] 1583 	add	a,#0xfe
      00BC53 90 0D A2         [24] 1584 	mov	dptr,#_fast_set_leds_PARM_2
      00BC56 F0               [24] 1585 	movx	@dptr,a
      00BC57 12 43 F9         [24] 1586 	lcall	_ak820_outline_0014
                                   1587 ;	quantum/vialrgb.c:197: }
                                   1588 ;	quantum/vialrgb.c:198: }
      00BC5A 02 B8 EA         [24] 1589 	ljmp	_fast_set_leds
                                   1590 ;------------------------------------------------------------
                                   1591 ;Allocation info for local variables in function 'vialrgb_save'
                                   1592 ;------------------------------------------------------------
                                   1593 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1594 ;data          Allocated with name '_vialrgb_save_data_10000_307'
                                   1595 ;------------------------------------------------------------
                                   1596 ;	quantum/vialrgb.c:200: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1597 ;	-----------------------------------------
                                   1598 ;	 function vialrgb_save
                                   1599 ;	-----------------------------------------
      00BC5D                       1600 _vialrgb_save:
                                   1601 ;	quantum/vialrgb.c:204: eeconfig_update_rgb_matrix();
                                   1602 ;	quantum/vialrgb.c:205: }
      00BC5D 02 4F 80         [24] 1603 	ljmp	_eeconfig_update_rgb_matrix
                                   1604 	.area CSEG    (CODE)
                                   1605 	.area CONST   (CODE)
                                   1606 	.area CONST   (CODE)
      00C442                       1607 _supported_modes:
      00C442 00 00                 1608 	.byte #0x00, #0x00	; 0
      00C444 00 00                 1609 	.byte #0x00, #0x00	; 0
      00C446 01 00                 1610 	.byte #0x01, #0x00	; 1
      00C448 05 00                 1611 	.byte #0x05, #0x00	; 5
      00C44A 02 00                 1612 	.byte #0x02, #0x00	; 2
      00C44C 01 00                 1613 	.byte #0x01, #0x00	; 1
      00C44E 06 00                 1614 	.byte #0x06, #0x00	; 6
      00C450 02 00                 1615 	.byte #0x02, #0x00	; 2
      00C452 0D 00                 1616 	.byte #0x0d, #0x00	; 13
      00C454 03 00                 1617 	.byte #0x03, #0x00	; 3
      00C456 0E 00                 1618 	.byte #0x0e, #0x00	; 14
      00C458 04 00                 1619 	.byte #0x04, #0x00	; 4
      00C45A 1F 00                 1620 	.byte #0x1f, #0x00	; 31
      00C45C 06 00                 1621 	.byte #0x06, #0x00	; 6
                                   1622 	.area CSEG    (CODE)
                                   1623 	.area XINIT   (CODE)
                                   1624 	.area CABS    (ABS,CODE)
                                   1625 
                                   1626 ; Experimental exact instruction outlining.
                                   1627 	.globl _ak820_outline_0000
                                   1628 	.globl _ak820_outline_0001
                                   1629 	.globl _ak820_outline_0002
                                   1630 	.globl _ak820_outline_0004
                                   1631 	.globl _ak820_outline_0007
                                   1632 	.globl _ak820_outline_0010
                                   1633 	.globl _ak820_outline_0012
                                   1634 	.globl _ak820_outline_0014
                                   1635 	.globl _ak820_outline_0015
                                   1636 	.globl _ak820_outline_0016
                                   1637 	.globl _ak820_outline_0018
                                   1638 	.globl _ak820_outline_0025
                                   1639 	.globl _ak820_outline_0026
                                   1640 	.globl _ak820_outline_0049
                                   1641 	.globl _ak820_outline_0060
                                   1642 	.globl _ak820_outline_0062
                                   1643 	.globl _ak820_outline_0064
                                   1644 	.globl _ak820_outline_0071
                                   1645 	.globl _ak820_outline_0084
                                   1646 	.globl _ak820_outline_0089
                                   1647 	.globl _ak820_outline_0099
                                   1648 	.globl _ak820_outline_0100
                                   1649 	.globl _ak820_outline_0102
                                   1650 	.globl _ak820_outline_0111
                                   1651 	.globl _ak820_outline_0133
                                   1652 	.globl _ak820_outline_0134
                                   1653 	.globl _ak820_outline_0145
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0062
      00BC60                       1657 _ak820_outline_0062:
      00BC60 ED               [12] 1658 	mov	a,r5
      00BC61 75 F0 04         [24] 1659 	mov	b,#0x04
      00BC64 A4               [48] 1660 	mul	ab
      00BC65 24 42            [12] 1661 	add	a,#_supported_modes
      00BC67 FB               [12] 1662 	mov	r3,a
      00BC68 74 C4            [12] 1663 	mov	a,#(_supported_modes>>8)
      00BC6A 35 F0            [12] 1664 	addc	a,b
      00BC6C FC               [12] 1665 	mov	r4,a
      00BC6D 22               [24] 1666 	ret
                                   1667 
                                   1668 	.area CSEG (CODE)
                                   1669 ; function ak820_outline_0064
      00BC6E                       1670 _ak820_outline_0064:
      00BC6E 90 0D A3         [24] 1671 	mov	dptr,#_fast_set_leds_args_10000_279
      00BC71 E0               [24] 1672 	movx	a,@dptr
      00BC72 F9               [12] 1673 	mov	r1,a
      00BC73 A3               [24] 1674 	inc	dptr
      00BC74 E0               [24] 1675 	movx	a,@dptr
      00BC75 FF               [12] 1676 	mov	r7,a
      00BC76 89 82            [24] 1677 	mov	dpl,r1
      00BC78 8F 83            [24] 1678 	mov	dph,r7
      00BC7A E0               [24] 1679 	movx	a,@dptr
      00BC7B 22               [24] 1680 	ret
                                   1681 
                                   1682 	.area CSEG (CODE)
                                   1683 ; function ak820_outline_0084
      00BC7C                       1684 _ak820_outline_0084:
      00BC7C 90 0D A3         [24] 1685 	mov	dptr,#_fast_set_leds_args_10000_279
      00BC7F 74 01            [12] 1686 	mov	a,#0x01
      00BC81 29               [12] 1687 	add	a,r1
      00BC82 F0               [24] 1688 	movx	@dptr,a
      00BC83 E4               [12] 1689 	clr	a
      00BC84 3F               [12] 1690 	addc	a,r7
      00BC85 A3               [24] 1691 	inc	dptr
      00BC86 F0               [24] 1692 	movx	@dptr,a
      00BC87 22               [24] 1693 	ret
                                   1694 
                                   1695 	.area CSEG (CODE)
                                   1696 ; function ak820_outline_0102
      00BC88                       1697 _ak820_outline_0102:
      00BC88 A3               [24] 1698 	inc	dptr
      00BC89 A3               [24] 1699 	inc	dptr
      00BC8A E4               [12] 1700 	clr	a
      00BC8B 93               [24] 1701 	movc	a,@a+dptr
      00BC8C F9               [12] 1702 	mov	r1,a
      00BC8D A3               [24] 1703 	inc	dptr
      00BC8E E4               [12] 1704 	clr	a
      00BC8F 93               [24] 1705 	movc	a,@a+dptr
      00BC90 FA               [12] 1706 	mov	r2,a
      00BC91 22               [24] 1707 	ret
                                   1708 
                                   1709 	.area CSEG (CODE)
                                   1710 ; function ak820_outline_0134
      00BC92                       1711 _ak820_outline_0134:
      00BC92 2D               [12] 1712 	add	a,r5
      00BC93 F5 82            [12] 1713 	mov	dpl,a
      00BC95 E4               [12] 1714 	clr	a
      00BC96 3E               [12] 1715 	addc	a,r6
      00BC97 F5 83            [12] 1716 	mov	dph,a
      00BC99 E0               [24] 1717 	movx	a,@dptr
      00BC9A 22               [24] 1718 	ret
