                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003E                        553 _raw_hid_receive_sloc0_1_0:
      00003E                        554 	.ds 4
      000042                        555 _raw_hid_receive_sloc1_1_0:
      000042                        556 	.ds 1
      000043                        557 _raw_hid_receive_sloc2_1_0:
      000043                        558 	.ds 1
      000044                        559 _raw_hid_receive_sloc3_1_0:
      000044                        560 	.ds 2
      000046                        561 _raw_hid_receive_sloc4_1_0:
      000046                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000020                        579 _via_eeprom_is_valid_sloc0_1_0:
      000020                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C57                        589 _via_eeprom_set_valid_valid_10000_602:
      000C57                        590 	.ds 1
      000C58                        591 _via_set_layout_options_value_10000_618:
      000C58                        592 	.ds 4
      000C5C                        593 _process_record_via_PARM_2:
      000C5C                        594 	.ds 3
      000C5F                        595 _process_record_via_keycode_10000_620:
      000C5F                        596 	.ds 2
      000C61                        597 _raw_hid_receive_kb_PARM_2:
      000C61                        598 	.ds 1
      000C62                        599 _raw_hid_receive_kb_data_10000_626:
      000C62                        600 	.ds 3
      000C65                        601 _raw_hid_receive_PARM_2:
      000C65                        602 	.ds 1
      000C66                        603 _raw_hid_receive_packet_10000_628:
      000C66                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A962                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A962 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A965 75 F0 00         [24]  659 	mov	b, #0x00
      00A968 12 41 13         [24]  660 	lcall	_eeprom_read_byte
      00A96B AF 82            [24]  661 	mov	r7, dpl
      00A96D BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A970 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A973 75 F0 00         [24]  664 	mov	b, #0x00
      00A976 12 41 13         [24]  665 	lcall	_eeprom_read_byte
      00A979 AF 82            [24]  666 	mov	r7, dpl
      00A97B BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A97E 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A981 75 F0 00         [24]  669 	mov	b, #0x00
      00A984 12 41 13         [24]  670 	lcall	_eeprom_read_byte
      00A987 AF 82            [24]  671 	mov	r7, dpl
      00A989 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A98C 80 04            [24]  673 	sjmp	00104$
      00A98E                        674 00126$:
      00A98E                        675 00103$:
                                    676 ;	assignBit
      00A98E C2 20            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A990 80 02            [24]  678 	sjmp	00105$
      00A992                        679 00104$:
                                    680 ;	assignBit
      00A992 D2 20            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A994                        682 00105$:
      00A994 A2 20            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A996 12 44 91         [24]  684 	lcall	_ak820_outline_0146
                                    685 ;	quantum/via.c:104: }
      00A999 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_602'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_603'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_603'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_603'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A99A                        699 _via_eeprom_set_valid:
      00A99A E5 82            [12]  700 	mov	a,dpl
      00A99C 90 0C 57         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_602
      00A99F F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A9A0 E0               [24]  704 	movx	a,@dptr
      00A9A1 60 04            [24]  705 	jz	00103$
      00A9A3 7F 02            [12]  706 	mov	r7,#0x02
      00A9A5 80 02            [24]  707 	sjmp	00104$
      00A9A7                        708 00103$:
      00A9A7 7F FF            [12]  709 	mov	r7,#0xff
      00A9A9                        710 00104$:
      00A9A9 90 06 88         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A9AC EF               [12]  712 	mov	a,r7
      00A9AD F0               [24]  713 	movx	@dptr,a
      00A9AE 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A9B1 75 F0 00         [24]  715 	mov	b, #0x00
      00A9B4 12 4D 63         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A9B7 90 0C 57         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_602
      00A9BA E0               [24]  719 	movx	a,@dptr
      00A9BB 60 04            [24]  720 	jz	00105$
      00A9BD 7F 20            [12]  721 	mov	r7,#0x20
      00A9BF 80 02            [24]  722 	sjmp	00106$
      00A9C1                        723 00105$:
      00A9C1 7F FF            [12]  724 	mov	r7,#0xff
      00A9C3                        725 00106$:
      00A9C3 90 06 88         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A9C6 EF               [12]  727 	mov	a,r7
      00A9C7 F0               [24]  728 	movx	@dptr,a
      00A9C8 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A9CB 75 F0 00         [24]  730 	mov	b, #0x00
      00A9CE 12 4D 63         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A9D1 90 0C 57         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_602
      00A9D4 E0               [24]  734 	movx	a,@dptr
      00A9D5 60 04            [24]  735 	jz	00107$
      00A9D7 7F 08            [12]  736 	mov	r7,#0x08
      00A9D9 80 02            [24]  737 	sjmp	00108$
      00A9DB                        738 00107$:
      00A9DB 7F FF            [12]  739 	mov	r7,#0xff
      00A9DD                        740 00108$:
      00A9DD 90 06 88         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A9E0 EF               [12]  742 	mov	a,r7
      00A9E1 F0               [24]  743 	movx	@dptr,a
      00A9E2 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A9E5 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A9E8 02 4D 63         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A9EB                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A9EB 12 AA 14         [24]  757 	lcall	_via_get_layout_options
      00A9EE 12 AA 2C         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A9F1 12 A9 62         [24]  760 	lcall	_via_eeprom_is_valid
      00A9F4 E5 82            [12]  761 	mov	a, dpl
      00A9F6 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A9F8 02 3E 8C         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A9FB                        766 00103$:
      00A9FB 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A9FC                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A9FC 75 82 00         [24]  777 	mov	dpl, #0x00
      00A9FF 12 A9 9A         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AA02 12 90 FA         [24]  780 	lcall	_ak820_outline_0115
      00AA05 12 AA 2D         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AA08 12 87 47         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AA0B 12 8B CD         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AA0E 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AA11 02 A9 9A         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AA14                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AA14 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AA17 75 F0 00         [24]  800 	mov	b, #0x00
      00AA1A 12 41 13         [24]  801 	lcall	_eeprom_read_byte
      00AA1D AF 82            [24]  802 	mov	r7, dpl
      00AA1F 7E 00            [12]  803 	mov	r6,#0x00
      00AA21 7D 00            [12]  804 	mov	r5,#0x00
      00AA23 7C 00            [12]  805 	mov	r4,#0x00
      00AA25 12 44 79         [24]  806 	lcall	_ak820_outline_0129
      00AA28 8D F0            [24]  807 	mov	b, r5
      00AA2A EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00AA2B 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_615'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00AA2C                        820 _via_set_layout_options_kb:
      00AA2C 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_618'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00AA2D                        831 _via_set_layout_options:
      00AA2D 12 90 F2         [24]  832 	lcall	_ak820_outline_0086
      00AA30 90 0C 58         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_618
      00AA33 12 90 E0         [24]  834 	lcall	_ak820_outline_0040
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00AA36 90 0C 58         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_618
      00AA39 E0               [24]  837 	movx	a,@dptr
      00AA3A 90 06 88         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AA3D F0               [24]  839 	movx	@dptr,a
      00AA3E 90 00 28         [24]  840 	mov	dptr,#0x0028
      00AA41 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00AA44 02 4D 63         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_620'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_625'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00AA47                        855 _process_record_via:
      00AA47 12 43 EA         [24]  856 	lcall	_ak820_outline_0010
      00AA4A 90 0C 5F         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_620
      00AA4D 12 43 E5         [24]  858 	lcall	_ak820_outline_0007
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00AA50 90 0C 5C         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00AA53 E0               [24]  861 	movx	a,@dptr
      00AA54 FD               [12]  862 	mov	r5,a
      00AA55 A3               [24]  863 	inc	dptr
      00AA56 12 43 C5         [24]  864 	lcall	_ak820_outline_0000
      00AA59 74 05            [12]  865 	mov	a,#0x05
      00AA5B 12 8F 2F         [24]  866 	lcall	_ak820_outline_0117
      00AA5E 12 4E 65         [24]  867 	lcall	_ak820_outline_0005
      00AA61 12 BE 14         [24]  868 	lcall	__gptrget
      00AA64 60 20            [24]  869 	jz	00105$
                                    870 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00AA66 90 0C 5F         [24]  871 	mov	dptr,#_process_record_via_keycode_10000_620
      00AA69 12 43 C5         [24]  872 	lcall	_ak820_outline_0000
      00AA6C 12 44 62         [24]  873 	lcall	_ak820_outline_0073
      00AA6F 74 89            [12]  874 	mov	a,#0x100 - 0x77
      00AA71 2D               [12]  875 	add	a,r5
      00AA72 50 12            [24]  876 	jnc	00105$
      00AA74 C3               [12]  877 	clr	c
      00AA75 74 7F            [12]  878 	mov	a,#0x7f
      00AA77 9C               [12]  879 	subb	a,r4
      00AA78 74 77            [12]  880 	mov	a,#0x77
      00AA7A 9D               [12]  881 	subb	a,r5
      00AA7B 40 09            [24]  882 	jc	00105$
                                    883 ;	free result
                                    884 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    885 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00AA7D 8E 82            [24]  886 	mov	dpl, r6
      00AA7F 12 8B F6         [24]  887 	lcall	_dynamic_keymap_macro_send
                                    888 ;	quantum/via.c:211: return false;
      00AA82 75 82 00         [24]  889 	mov	dpl, #0x00
      00AA85 22               [24]  890 	ret
      00AA86                        891 00105$:
                                    892 ;	quantum/via.c:215: return true;
      00AA86 75 82 01         [24]  893 	mov	dpl, #0x01
                                    894 ;	quantum/via.c:216: }
      00AA89 22               [24]  895 	ret
                                    896 ;------------------------------------------------------------
                                    897 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    898 ;------------------------------------------------------------
                                    899 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    900 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_626'
                                    901 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_627'
                                    902 ;------------------------------------------------------------
                                    903 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    904 ;	-----------------------------------------
                                    905 ;	 function raw_hid_receive_kb
                                    906 ;	-----------------------------------------
      00AA8A                        907 _raw_hid_receive_kb:
      00AA8A 12 43 D8         [24]  908 	lcall	_ak820_outline_0004
      00AA8D 90 0C 62         [24]  909 	mov	dptr,#_raw_hid_receive_kb_data_10000_626
      00AA90 12 43 CB         [24]  910 	lcall	_ak820_outline_0001
                                    911 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AA93 90 0C 62         [24]  912 	mov	dptr,#_raw_hid_receive_kb_data_10000_626
      00AA96 E0               [24]  913 	movx	a,@dptr
      00AA97 FD               [12]  914 	mov	r5,a
      00AA98 A3               [24]  915 	inc	dptr
      00AA99 12 43 C5         [24]  916 	lcall	_ak820_outline_0000
                                    917 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AA9C 12 4E 65         [24]  918 	lcall	_ak820_outline_0005
      00AA9F 74 FF            [12]  919 	mov	a,#0xff
                                    920 ;	quantum/via.c:224: }
      00AAA1 02 BD D9         [24]  921 	ljmp	__gptrput
                                    922 ;------------------------------------------------------------
                                    923 ;Allocation info for local variables in function 'raw_hid_receive'
                                    924 ;------------------------------------------------------------
                                    925 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    926 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    927 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    928 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    929 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    930 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    931 ;packet        Allocated with name '_raw_hid_receive_packet_10000_628'
                                    932 ;data          Allocated with name '_raw_hid_receive_data_10000_629'
                                    933 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_629'
                                    934 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_629'
                                    935 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_635'
                                    936 ;value         Allocated with name '_raw_hid_receive_value_70000_643'
                                    937 ;value         Allocated with name '_raw_hid_receive_value_70000_644'
                                    938 ;i             Allocated with name '_raw_hid_receive_i_70001_647'
                                    939 ;row           Allocated with name '_raw_hid_receive_row_80001_648'
                                    940 ;value         Allocated with name '_raw_hid_receive_value_90001_649'
                                    941 ;value         Allocated with name '_raw_hid_receive_value_70000_654'
                                    942 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_656'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_665'
                                    944 ;offset        Allocated with name '_raw_hid_receive_offset_40000_666'
                                    945 ;size          Allocated with name '_raw_hid_receive_size_40000_666'
                                    946 ;offset        Allocated with name '_raw_hid_receive_offset_40001_671'
                                    947 ;size          Allocated with name '_raw_hid_receive_size_40001_671'
                                    948 ;offset        Allocated with name '_raw_hid_receive_offset_40000_676'
                                    949 ;size          Allocated with name '_raw_hid_receive_size_40000_676'
                                    950 ;offset        Allocated with name '_raw_hid_receive_offset_40000_678'
                                    951 ;size          Allocated with name '_raw_hid_receive_size_40000_678'
                                    952 ;i             Allocated with name '_raw_hid_receive_i_60000_683'
                                    953 ;------------------------------------------------------------
                                    954 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    955 ;	-----------------------------------------
                                    956 ;	 function raw_hid_receive
                                    957 ;	-----------------------------------------
      00AAA4                        958 _raw_hid_receive:
      00AAA4 12 43 D8         [24]  959 	lcall	_ak820_outline_0004
      00AAA7 90 0C 66         [24]  960 	mov	dptr,#_raw_hid_receive_packet_10000_628
      00AAAA 12 43 CB         [24]  961 	lcall	_ak820_outline_0001
                                    962 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AAAD 90 0C 66         [24]  963 	mov	dptr,#_raw_hid_receive_packet_10000_628
      00AAB0 12 43 C5         [24]  964 	lcall	_ak820_outline_0000
                                    965 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AAB3 74 01            [12]  966 	mov	a,#0x01
      00AAB5 12 44 33         [24]  967 	lcall	_ak820_outline_0043
                                    968 ;	quantum/via.c:245: if (length != 32) return;
      00AAB8 90 0C 65         [24]  969 	mov	dptr,#_raw_hid_receive_PARM_2
      00AABB E0               [24]  970 	movx	a,@dptr
      00AABC FB               [12]  971 	mov	r3,a
      00AABD BB 20 02         [24]  972 	cjne	r3,#0x20,00520$
      00AAC0 80 01            [24]  973 	sjmp	00102$
      00AAC2                        974 00520$:
      00AAC2 22               [24]  975 	ret
      00AAC3                        976 00102$:
                                    977 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AAC3 90 0E 33         [24]  978 	mov	dptr,#_vial_unlock_in_progress
      00AAC6 E0               [24]  979 	movx	a,@dptr
      00AAC7 60 33            [24]  980 	jz	00114$
                                    981 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AAC9 12 43 D3         [24]  982 	lcall	_ak820_outline_0002
      00AACC E0               [24]  983 	movx	a,@dptr
      00AACD FA               [12]  984 	mov	r2,a
      00AACE BA FE 02         [24]  985 	cjne	r2,#0xfe,00522$
      00AAD1 80 01            [24]  986 	sjmp	00104$
      00AAD3                        987 00522$:
                                    988 ;	quantum/via.c:252: return;
      00AAD3 22               [24]  989 	ret
      00AAD4                        990 00104$:
                                    991 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AAD4 12 43 EF         [24]  992 	lcall	_ak820_outline_0011
      00AAD7 E0               [24]  993 	movx	a,@dptr
                                    994 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AAD8 FA               [12]  995 	mov	r2,a
      00AAD9 60 21            [24]  996 	jz	00114$
      00AADB BA 01 02         [24]  997 	cjne	r2,#0x01,00524$
      00AADE 80 1C            [24]  998 	sjmp	00114$
      00AAE0                        999 00524$:
      00AAE0 BA 02 02         [24] 1000 	cjne	r2,#0x02,00525$
      00AAE3 80 17            [24] 1001 	sjmp	00114$
      00AAE5                       1002 00525$:
      00AAE5 BA 05 02         [24] 1003 	cjne	r2,#0x05,00526$
      00AAE8 80 12            [24] 1004 	sjmp	00114$
      00AAEA                       1005 00526$:
      00AAEA BA 06 02         [24] 1006 	cjne	r2,#0x06,00527$
      00AAED 80 0D            [24] 1007 	sjmp	00114$
      00AAEF                       1008 00527$:
      00AAEF BA 07 02         [24] 1009 	cjne	r2,#0x07,00528$
      00AAF2 80 08            [24] 1010 	sjmp	00114$
      00AAF4                       1011 00528$:
      00AAF4 BA 08 02         [24] 1012 	cjne	r2,#0x08,00529$
      00AAF7 80 03            [24] 1013 	sjmp	00530$
      00AAF9                       1014 00529$:
      00AAF9 02 B0 B6         [24] 1015 	ljmp	00171$
      00AAFC                       1016 00530$:
                                   1017 ;	quantum/via.c:259: goto skip;
      00AAFC                       1018 00114$:
                                   1019 ;	quantum/via.c:263: switch (*command_id) {
      00AAFC 12 43 D3         [24] 1020 	lcall	_ak820_outline_0002
      00AAFF E0               [24] 1021 	movx	a,@dptr
      00AB00 FA               [12] 1022 	mov	r2,a
      00AB01 BA 01 02         [24] 1023 	cjne	r2,#0x01,00531$
      00AB04 80 6E            [24] 1024 	sjmp	00115$
      00AB06                       1025 00531$:
      00AB06 BA 02 02         [24] 1026 	cjne	r2,#0x02,00532$
      00AB09 80 79            [24] 1027 	sjmp	00116$
      00AB0B                       1028 00532$:
      00AB0B BA 03 03         [24] 1029 	cjne	r2,#0x03,00533$
      00AB0E 02 AC 5D         [24] 1030 	ljmp	00125$
      00AB11                       1031 00533$:
      00AB11 BA 04 03         [24] 1032 	cjne	r2,#0x04,00534$
      00AB14 02 AD 02         [24] 1033 	ljmp	00129$
      00AB17                       1034 00534$:
      00AB17 BA 05 03         [24] 1035 	cjne	r2,#0x05,00535$
      00AB1A 02 AD 4A         [24] 1036 	ljmp	00130$
      00AB1D                       1037 00535$:
      00AB1D BA 06 03         [24] 1038 	cjne	r2,#0x06,00536$
      00AB20 02 AD CC         [24] 1039 	ljmp	00135$
      00AB23                       1040 00536$:
      00AB23 BA 07 03         [24] 1041 	cjne	r2,#0x07,00537$
      00AB26 02 AD DE         [24] 1042 	ljmp	00136$
      00AB29                       1043 00537$:
      00AB29 BA 08 03         [24] 1044 	cjne	r2,#0x08,00538$
      00AB2C 02 AD FB         [24] 1045 	ljmp	00137$
      00AB2F                       1046 00538$:
      00AB2F BA 09 03         [24] 1047 	cjne	r2,#0x09,00539$
      00AB32 02 AE 18         [24] 1048 	ljmp	00138$
      00AB35                       1049 00539$:
      00AB35 BA 0B 03         [24] 1050 	cjne	r2,#0x0b,00540$
      00AB38 02 B0 44         [24] 1051 	ljmp	00161$
      00AB3B                       1052 00540$:
      00AB3B BA 0C 03         [24] 1053 	cjne	r2,#0x0c,00541$
      00AB3E 02 AE 35         [24] 1054 	ljmp	00139$
      00AB41                       1055 00541$:
      00AB41 BA 0D 03         [24] 1056 	cjne	r2,#0x0d,00542$
      00AB44 02 AE 56         [24] 1057 	ljmp	00140$
      00AB47                       1058 00542$:
      00AB47 BA 0E 03         [24] 1059 	cjne	r2,#0x0e,00543$
      00AB4A 02 AE 82         [24] 1060 	ljmp	00141$
      00AB4D                       1061 00543$:
      00AB4D BA 0F 03         [24] 1062 	cjne	r2,#0x0f,00544$
      00AB50 02 AE D7         [24] 1063 	ljmp	00144$
      00AB53                       1064 00544$:
      00AB53 BA 10 03         [24] 1065 	cjne	r2,#0x10,00545$
      00AB56 02 AF 53         [24] 1066 	ljmp	00151$
      00AB59                       1067 00545$:
      00AB59 BA 11 03         [24] 1068 	cjne	r2,#0x11,00546$
      00AB5C 02 AF 6C         [24] 1069 	ljmp	00154$
      00AB5F                       1070 00546$:
      00AB5F BA 12 03         [24] 1071 	cjne	r2,#0x12,00547$
      00AB62 02 AF 8D         [24] 1072 	ljmp	00155$
      00AB65                       1073 00547$:
      00AB65 BA 13 03         [24] 1074 	cjne	r2,#0x13,00548$
      00AB68 02 AF E2         [24] 1075 	ljmp	00158$
      00AB6B                       1076 00548$:
      00AB6B BA FE 03         [24] 1077 	cjne	r2,#0xfe,00549$
      00AB6E 02 B0 84         [24] 1078 	ljmp	00168$
      00AB71                       1079 00549$:
      00AB71 02 B0 9E         [24] 1080 	ljmp	00169$
                                   1081 ;	quantum/via.c:264: case id_get_protocol_version: {
      00AB74                       1082 00115$:
                                   1083 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00AB74 12 43 EF         [24] 1084 	lcall	_ak820_outline_0011
      00AB77 E4               [12] 1085 	clr	a
      00AB78 F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00AB79 12 43 D3         [24] 1088 	lcall	_ak820_outline_0002
      00AB7C A3               [24] 1089 	inc	dptr
      00AB7D A3               [24] 1090 	inc	dptr
      00AB7E 74 09            [12] 1091 	mov	a,#0x09
      00AB80 F0               [24] 1092 	movx	@dptr,a
                                   1093 ;	quantum/via.c:267: break;
      00AB81 02 B0 B6         [24] 1094 	ljmp	00171$
                                   1095 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00AB84                       1096 00116$:
                                   1097 ;	quantum/via.c:270: switch (command_data[0]) {
      00AB84 12 43 EF         [24] 1098 	lcall	_ak820_outline_0011
      00AB87 E0               [24] 1099 	movx	a,@dptr
      00AB88 FA               [12] 1100 	mov	r2,a
      00AB89 BA 01 02         [24] 1101 	cjne	r2,#0x01,00550$
      00AB8C 80 0E            [24] 1102 	sjmp	00117$
      00AB8E                       1103 00550$:
      00AB8E BA 02 02         [24] 1104 	cjne	r2,#0x02,00551$
      00AB91 80 3E            [24] 1105 	sjmp	00118$
      00AB93                       1106 00551$:
      00AB93 BA 03 03         [24] 1107 	cjne	r2,#0x03,00552$
      00AB96 02 AC 16         [24] 1108 	ljmp	00119$
      00AB99                       1109 00552$:
      00AB99 02 AC 40         [24] 1110 	ljmp	00123$
                                   1111 ;	quantum/via.c:271: case id_uptime: {
      00AB9C                       1112 00117$:
                                   1113 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AB9C 12 48 9A         [24] 1114 	lcall	_timer_read32
      00AB9F 85 82 3E         [24] 1115 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00ABA2 85 83 3F         [24] 1116 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00ABA5 85 F0 40         [24] 1117 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00ABA8 F5 41            [12] 1118 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1119 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00ABAA 12 43 D3         [24] 1120 	lcall	_ak820_outline_0002
      00ABAD A3               [24] 1121 	inc	dptr
      00ABAE A3               [24] 1122 	inc	dptr
      00ABAF E5 41            [12] 1123 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ABB1 F0               [24] 1124 	movx	@dptr,a
                                   1125 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00ABB2 12 43 D3         [24] 1126 	lcall	_ak820_outline_0002
      00ABB5 A3               [24] 1127 	inc	dptr
      00ABB6 A3               [24] 1128 	inc	dptr
      00ABB7 A3               [24] 1129 	inc	dptr
      00ABB8 E5 40            [12] 1130 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ABBA F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00ABBB 12 43 D3         [24] 1133 	lcall	_ak820_outline_0002
      00ABBE 12 B0 F8         [24] 1134 	lcall	_ak820_outline_0099
      00ABC1 E5 3F            [12] 1135 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ABC3 F0               [24] 1136 	movx	@dptr,a
                                   1137 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00ABC4 12 43 D3         [24] 1138 	lcall	_ak820_outline_0002
      00ABC7 12 B0 F8         [24] 1139 	lcall	_ak820_outline_0099
      00ABCA A3               [24] 1140 	inc	dptr
      00ABCB E5 3E            [12] 1141 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABCD F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	quantum/via.c:277: break;
      00ABCE 02 B0 B6         [24] 1144 	ljmp	00171$
                                   1145 ;	quantum/via.c:279: case id_layout_options: {
      00ABD1                       1146 00118$:
                                   1147 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00ABD1 C0 03            [24] 1148 	push	ar3
      00ABD3 C0 07            [24] 1149 	push	ar7
      00ABD5 C0 06            [24] 1150 	push	ar6
      00ABD7 C0 03            [24] 1151 	push	ar3
      00ABD9 12 AA 14         [24] 1152 	lcall	_via_get_layout_options
      00ABDC 85 82 3E         [24] 1153 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00ABDF 85 83 3F         [24] 1154 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00ABE2 85 F0 40         [24] 1155 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00ABE5 F5 41            [12] 1156 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ABE7 D0 03            [24] 1157 	pop	ar3
      00ABE9 D0 06            [24] 1158 	pop	ar6
      00ABEB D0 07            [24] 1159 	pop	ar7
                                   1160 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00ABED 12 43 D3         [24] 1161 	lcall	_ak820_outline_0002
      00ABF0 A3               [24] 1162 	inc	dptr
      00ABF1 A3               [24] 1163 	inc	dptr
      00ABF2 E5 41            [12] 1164 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ABF4 F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00ABF5 12 43 D3         [24] 1167 	lcall	_ak820_outline_0002
      00ABF8 A3               [24] 1168 	inc	dptr
      00ABF9 A3               [24] 1169 	inc	dptr
      00ABFA A3               [24] 1170 	inc	dptr
      00ABFB E5 40            [12] 1171 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ABFD F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00ABFE 12 43 D3         [24] 1174 	lcall	_ak820_outline_0002
      00AC01 12 B0 F8         [24] 1175 	lcall	_ak820_outline_0099
      00AC04 E5 3F            [12] 1176 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AC06 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AC07 12 43 D3         [24] 1179 	lcall	_ak820_outline_0002
      00AC0A 12 B0 F8         [24] 1180 	lcall	_ak820_outline_0099
      00AC0D A3               [24] 1181 	inc	dptr
      00AC0E E5 3E            [12] 1182 	mov	a,_raw_hid_receive_sloc0_1_0
      00AC10 F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	quantum/via.c:285: break;
      00AC11 D0 03            [24] 1185 	pop	ar3
      00AC13 02 B0 B6         [24] 1186 	ljmp	00171$
                                   1187 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AC16                       1188 00119$:
                                   1189 ;	quantum/via.c:290: if (!vial_unlocked)
      00AC16 90 0E 32         [24] 1190 	mov	dptr,#_vial_unlocked
      00AC19 E0               [24] 1191 	movx	a,@dptr
      00AC1A 70 03            [24] 1192 	jnz	00553$
      00AC1C 02 B0 B6         [24] 1193 	ljmp	00171$
      00AC1F                       1194 00553$:
                                   1195 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AC1F 7A 01            [12] 1196 	mov	r2,#0x01
      00AC21 79 00            [12] 1197 	mov	r1,#0x00
      00AC23                       1198 00173$:
      00AC23 B9 10 00         [24] 1199 	cjne	r1,#0x10,00554$
      00AC26                       1200 00554$:
      00AC26 40 03            [24] 1201 	jc	00555$
      00AC28 02 B0 B6         [24] 1202 	ljmp	00171$
      00AC2B                       1203 00555$:
                                   1204 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AC2B 89 82            [24] 1205 	mov	dpl, r1
      00AC2D 12 59 99         [24] 1206 	lcall	_matrix_get_row
      00AC30 A8 82            [24] 1207 	mov	r0, dpl
                                   1208 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AC32 EA               [12] 1209 	mov	a,r2
      00AC33 2C               [12] 1210 	add	a, r4
      00AC34 F5 82            [12] 1211 	mov	dpl,a
      00AC36 E4               [12] 1212 	clr	a
      00AC37 3D               [12] 1213 	addc	a, r5
      00AC38 F5 83            [12] 1214 	mov	dph,a
      00AC3A 0A               [12] 1215 	inc	r2
      00AC3B E8               [12] 1216 	mov	a,r0
      00AC3C F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AC3D 09               [12] 1219 	inc	r1
                                   1220 ;	quantum/via.c:312: default: {
      00AC3E 80 E3            [24] 1221 	sjmp	00173$
      00AC40                       1222 00123$:
                                   1223 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AC40 12 B0 DF         [24] 1224 	lcall	_ak820_outline_0057
      00AC43 90 0C 61         [24] 1225 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AC46 EB               [12] 1226 	mov	a,r3
      00AC47 F0               [24] 1227 	movx	@dptr,a
      00AC48 12 A5 2F         [24] 1228 	lcall	_ak820_outline_0028
      00AC4B C0 07            [24] 1229 	push	ar7
      00AC4D C0 06            [24] 1230 	push	ar6
      00AC4F C0 03            [24] 1231 	push	ar3
      00AC51 12 AA 8A         [24] 1232 	lcall	_raw_hid_receive_kb
      00AC54 D0 03            [24] 1233 	pop	ar3
      00AC56 D0 06            [24] 1234 	pop	ar6
      00AC58 D0 07            [24] 1235 	pop	ar7
                                   1236 ;	quantum/via.c:317: break;
      00AC5A 02 B0 B6         [24] 1237 	ljmp	00171$
                                   1238 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AC5D                       1239 00125$:
                                   1240 ;	quantum/via.c:320: switch (command_data[0]) {
      00AC5D 12 43 EF         [24] 1241 	lcall	_ak820_outline_0011
      00AC60 E0               [24] 1242 	movx	a,@dptr
      00AC61 FA               [12] 1243 	mov	r2,a
      00AC62 BA 02 02         [24] 1244 	cjne	r2,#0x02,00556$
      00AC65 80 03            [24] 1245 	sjmp	00557$
      00AC67                       1246 00556$:
      00AC67 02 AC E5         [24] 1247 	ljmp	00127$
      00AC6A                       1248 00557$:
                                   1249 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AC6A C0 03            [24] 1250 	push	ar3
      00AC6C 12 43 D3         [24] 1251 	lcall	_ak820_outline_0002
      00AC6F A3               [24] 1252 	inc	dptr
      00AC70 A3               [24] 1253 	inc	dptr
      00AC71 E0               [24] 1254 	movx	a,@dptr
      00AC72 F8               [12] 1255 	mov	r0,a
      00AC73 79 00            [12] 1256 	mov	r1,#0x00
      00AC75 7B 00            [12] 1257 	mov	r3,#0x00
      00AC77 88 41            [24] 1258 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AC79 8B 3E            [24] 1259 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AC7B 8B 3F            [24] 1260 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AC7D 8B 40            [24] 1261 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AC7F 12 43 D3         [24] 1262 	lcall	_ak820_outline_0002
      00AC82 12 B0 C5         [24] 1263 	lcall	_ak820_outline_0026
      00AC85 F8               [12] 1264 	mov	r0,a
      00AC86 89 03            [24] 1265 	mov	ar3,r1
      00AC88 88 02            [24] 1266 	mov	ar2,r0
      00AC8A E4               [12] 1267 	clr	a
      00AC8B 42 3E            [12] 1268 	orl	_raw_hid_receive_sloc0_1_0,a
      00AC8D E9               [12] 1269 	mov	a,r1
      00AC8E 42 3F            [12] 1270 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AC90 EA               [12] 1271 	mov	a,r2
      00AC91 42 40            [12] 1272 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AC93 EB               [12] 1273 	mov	a,r3
      00AC94 42 41            [12] 1274 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AC96 12 43 D3         [24] 1275 	lcall	_ak820_outline_0002
      00AC99 A3               [24] 1276 	inc	dptr
      00AC9A 12 B0 C5         [24] 1277 	lcall	_ak820_outline_0026
      00AC9D F8               [12] 1278 	mov	r0,a
      00AC9E 79 00            [12] 1279 	mov	r1,#0x00
      00ACA0 7A 00            [12] 1280 	mov	r2,#0x00
      00ACA2 8A 03            [24] 1281 	mov	ar3,r2
      00ACA4 89 02            [24] 1282 	mov	ar2,r1
      00ACA6 88 01            [24] 1283 	mov	ar1,r0
      00ACA8 E4               [12] 1284 	clr	a
      00ACA9 42 3E            [12] 1285 	orl	_raw_hid_receive_sloc0_1_0,a
      00ACAB E9               [12] 1286 	mov	a,r1
      00ACAC 42 3F            [12] 1287 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ACAE EA               [12] 1288 	mov	a,r2
      00ACAF 42 40            [12] 1289 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ACB1 EB               [12] 1290 	mov	a,r3
      00ACB2 42 41            [12] 1291 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ACB4 12 43 D3         [24] 1292 	lcall	_ak820_outline_0002
      00ACB7 A3               [24] 1293 	inc	dptr
      00ACB8 A3               [24] 1294 	inc	dptr
      00ACB9 12 B0 C5         [24] 1295 	lcall	_ak820_outline_0026
      00ACBC F8               [12] 1296 	mov	r0,a
      00ACBD E4               [12] 1297 	clr	a
      00ACBE F9               [12] 1298 	mov	r1,a
      00ACBF FA               [12] 1299 	mov	r2,a
      00ACC0 FB               [12] 1300 	mov	r3,a
      00ACC1 E5 3F            [12] 1301 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00ACC3 42 01            [12] 1302 	orl	ar1,a
      00ACC5 E5 40            [12] 1303 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00ACC7 42 02            [12] 1304 	orl	ar2,a
      00ACC9 E5 41            [12] 1305 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00ACCB 42 03            [12] 1306 	orl	ar3,a
                                   1307 ;	quantum/via.c:323: via_set_layout_options(value);
      00ACCD 12 A5 2F         [24] 1308 	lcall	_ak820_outline_0028
      00ACD0 EB               [12] 1309 	mov	a, r3
      00ACD1 C0 07            [24] 1310 	push	ar7
      00ACD3 C0 06            [24] 1311 	push	ar6
      00ACD5 C0 03            [24] 1312 	push	ar3
      00ACD7 12 AA 2D         [24] 1313 	lcall	_via_set_layout_options
      00ACDA D0 03            [24] 1314 	pop	ar3
      00ACDC D0 06            [24] 1315 	pop	ar6
      00ACDE D0 07            [24] 1316 	pop	ar7
                                   1317 ;	quantum/via.c:324: break;
      00ACE0 D0 03            [24] 1318 	pop	ar3
      00ACE2 02 B0 B6         [24] 1319 	ljmp	00171$
                                   1320 ;	quantum/via.c:326: default: {
      00ACE5                       1321 00127$:
                                   1322 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00ACE5 12 B0 DF         [24] 1323 	lcall	_ak820_outline_0057
      00ACE8 90 0C 61         [24] 1324 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ACEB EB               [12] 1325 	mov	a,r3
      00ACEC F0               [24] 1326 	movx	@dptr,a
      00ACED 12 A5 2F         [24] 1327 	lcall	_ak820_outline_0028
      00ACF0 C0 07            [24] 1328 	push	ar7
      00ACF2 C0 06            [24] 1329 	push	ar6
      00ACF4 C0 03            [24] 1330 	push	ar3
      00ACF6 12 AA 8A         [24] 1331 	lcall	_raw_hid_receive_kb
      00ACF9 D0 03            [24] 1332 	pop	ar3
      00ACFB D0 06            [24] 1333 	pop	ar6
      00ACFD D0 07            [24] 1334 	pop	ar7
                                   1335 ;	quantum/via.c:331: break;
      00ACFF 02 B0 B6         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AD02                       1338 00129$:
                                   1339 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AD02 12 43 EF         [24] 1340 	lcall	_ak820_outline_0011
      00AD05 E0               [24] 1341 	movx	a,@dptr
      00AD06 FA               [12] 1342 	mov	r2,a
      00AD07 12 43 D3         [24] 1343 	lcall	_ak820_outline_0002
      00AD0A A3               [24] 1344 	inc	dptr
      00AD0B A3               [24] 1345 	inc	dptr
      00AD0C E0               [24] 1346 	movx	a,@dptr
      00AD0D F9               [12] 1347 	mov	r1,a
      00AD0E 12 43 D3         [24] 1348 	lcall	_ak820_outline_0002
      00AD11 12 B0 C5         [24] 1349 	lcall	_ak820_outline_0026
      00AD14 F8               [12] 1350 	mov	r0,a
      00AD15 90 0A CB         [24] 1351 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AD18 E9               [12] 1352 	mov	a,r1
      00AD19 F0               [24] 1353 	movx	@dptr,a
      00AD1A 90 0A CC         [24] 1354 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AD1D E8               [12] 1355 	mov	a,r0
      00AD1E F0               [24] 1356 	movx	@dptr,a
      00AD1F 8A 82            [24] 1357 	mov	dpl, r2
      00AD21 C0 07            [24] 1358 	push	ar7
      00AD23 C0 06            [24] 1359 	push	ar6
      00AD25 C0 03            [24] 1360 	push	ar3
      00AD27 12 84 58         [24] 1361 	lcall	_dynamic_keymap_get_keycode
      00AD2A A9 82            [24] 1362 	mov	r1, dpl
      00AD2C AA 83            [24] 1363 	mov	r2, dph
      00AD2E D0 03            [24] 1364 	pop	ar3
      00AD30 D0 06            [24] 1365 	pop	ar6
      00AD32 D0 07            [24] 1366 	pop	ar7
                                   1367 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AD34 12 43 D3         [24] 1368 	lcall	_ak820_outline_0002
      00AD37 12 B0 F8         [24] 1369 	lcall	_ak820_outline_0099
      00AD3A 8A 00            [24] 1370 	mov	ar0,r2
      00AD3C E8               [12] 1371 	mov	a,r0
      00AD3D F0               [24] 1372 	movx	@dptr,a
                                   1373 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AD3E 12 43 D3         [24] 1374 	lcall	_ak820_outline_0002
      00AD41 12 B0 F8         [24] 1375 	lcall	_ak820_outline_0099
      00AD44 A3               [24] 1376 	inc	dptr
      00AD45 E9               [12] 1377 	mov	a,r1
      00AD46 F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/via.c:337: break;
      00AD47 02 B0 B6         [24] 1380 	ljmp	00171$
                                   1381 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AD4A                       1382 00130$:
                                   1383 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AD4A 90 0E 32         [24] 1384 	mov	dptr,#_vial_unlocked
      00AD4D E0               [24] 1385 	movx	a,@dptr
      00AD4E 70 21            [24] 1386 	jnz	00132$
      00AD50 12 43 D3         [24] 1387 	lcall	_ak820_outline_0002
      00AD53 A3               [24] 1388 	inc	dptr
      00AD54 12 B0 C5         [24] 1389 	lcall	_ak820_outline_0026
      00AD57 FA               [12] 1390 	mov	r2,a
      00AD58 BA 7C 16         [24] 1391 	cjne	r2,#0x7c,00132$
      00AD5B 74 05            [12] 1392 	mov	a,#0x05
      00AD5D 2E               [12] 1393 	add	a, r6
      00AD5E F9               [12] 1394 	mov	r1,a
      00AD5F E4               [12] 1395 	clr	a
      00AD60 3F               [12] 1396 	addc	a, r7
      00AD61 FA               [12] 1397 	mov	r2,a
      00AD62 12 44 06         [24] 1398 	lcall	_ak820_outline_0016
      00AD65 E0               [24] 1399 	movx	a,@dptr
      00AD66 70 09            [24] 1400 	jnz	00132$
                                   1401 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AD68 12 43 D3         [24] 1402 	lcall	_ak820_outline_0002
      00AD6B 74 FF            [12] 1403 	mov	a,#0xff
      00AD6D F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	quantum/via.c:345: break;
      00AD6E 02 B0 B6         [24] 1406 	ljmp	00171$
      00AD71                       1407 00132$:
                                   1408 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AD71 C0 03            [24] 1409 	push	ar3
      00AD73 12 43 EF         [24] 1410 	lcall	_ak820_outline_0011
      00AD76 E0               [24] 1411 	movx	a,@dptr
      00AD77 F5 43            [12] 1412 	mov	_raw_hid_receive_sloc2_1_0,a
      00AD79 12 43 D3         [24] 1413 	lcall	_ak820_outline_0002
      00AD7C A3               [24] 1414 	inc	dptr
      00AD7D A3               [24] 1415 	inc	dptr
      00AD7E E0               [24] 1416 	movx	a,@dptr
      00AD7F F5 42            [12] 1417 	mov	_raw_hid_receive_sloc1_1_0,a
      00AD81 12 43 D3         [24] 1418 	lcall	_ak820_outline_0002
      00AD84 12 B0 C5         [24] 1419 	lcall	_ak820_outline_0026
      00AD87 F5 3E            [12] 1420 	mov	_raw_hid_receive_sloc0_1_0,a
      00AD89 12 43 D3         [24] 1421 	lcall	_ak820_outline_0002
      00AD8C A3               [24] 1422 	inc	dptr
      00AD8D 12 B0 C5         [24] 1423 	lcall	_ak820_outline_0026
      00AD90 FB               [12] 1424 	mov	r3,a
      00AD91 78 00            [12] 1425 	mov	r0,#0x00
      00AD93 12 43 D3         [24] 1426 	lcall	_ak820_outline_0002
      00AD96 A3               [24] 1427 	inc	dptr
      00AD97 A3               [24] 1428 	inc	dptr
      00AD98 12 B0 C5         [24] 1429 	lcall	_ak820_outline_0026
      00AD9B 7A 00            [12] 1430 	mov	r2,#0x00
      00AD9D 42 00            [12] 1431 	orl	ar0,a
      00AD9F EA               [12] 1432 	mov	a,r2
      00ADA0 42 03            [12] 1433 	orl	ar3,a
      00ADA2 90 0A CE         [24] 1434 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00ADA5 E5 42            [12] 1435 	mov	a,_raw_hid_receive_sloc1_1_0
      00ADA7 F0               [24] 1436 	movx	@dptr,a
      00ADA8 90 0A CF         [24] 1437 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00ADAB E5 3E            [12] 1438 	mov	a,_raw_hid_receive_sloc0_1_0
      00ADAD F0               [24] 1439 	movx	@dptr,a
      00ADAE 90 0A D0         [24] 1440 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00ADB1 E8               [12] 1441 	mov	a,r0
      00ADB2 12 8F 56         [24] 1442 	lcall	_ak820_outline_0149
      00ADB5 85 43 82         [24] 1443 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00ADB8 C0 07            [24] 1444 	push	ar7
      00ADBA C0 06            [24] 1445 	push	ar6
      00ADBC C0 03            [24] 1446 	push	ar3
      00ADBE 12 84 A6         [24] 1447 	lcall	_dynamic_keymap_set_keycode
      00ADC1 D0 03            [24] 1448 	pop	ar3
      00ADC3 D0 06            [24] 1449 	pop	ar6
      00ADC5 D0 07            [24] 1450 	pop	ar7
                                   1451 ;	quantum/via.c:349: break;
      00ADC7 D0 03            [24] 1452 	pop	ar3
      00ADC9 02 B0 B6         [24] 1453 	ljmp	00171$
                                   1454 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00ADCC                       1455 00135$:
                                   1456 ;	quantum/via.c:352: dynamic_keymap_reset();
      00ADCC C0 07            [24] 1457 	push	ar7
      00ADCE C0 06            [24] 1458 	push	ar6
      00ADD0 C0 03            [24] 1459 	push	ar3
      00ADD2 12 87 47         [24] 1460 	lcall	_dynamic_keymap_reset
      00ADD5 D0 03            [24] 1461 	pop	ar3
      00ADD7 D0 06            [24] 1462 	pop	ar6
      00ADD9 D0 07            [24] 1463 	pop	ar7
                                   1464 ;	quantum/via.c:353: break;
      00ADDB 02 B0 B6         [24] 1465 	ljmp	00171$
                                   1466 ;	quantum/via.c:355: case id_lighting_set_value: {
      00ADDE                       1467 00136$:
                                   1468 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00ADDE 12 B0 DF         [24] 1469 	lcall	_ak820_outline_0057
      00ADE1 90 0D AC         [24] 1470 	mov	dptr,#_vialrgb_set_value_PARM_2
      00ADE4 EB               [12] 1471 	mov	a,r3
      00ADE5 F0               [24] 1472 	movx	@dptr,a
      00ADE6 12 A5 2F         [24] 1473 	lcall	_ak820_outline_0028
      00ADE9 C0 07            [24] 1474 	push	ar7
      00ADEB C0 06            [24] 1475 	push	ar6
      00ADED C0 03            [24] 1476 	push	ar3
      00ADEF 12 BB BB         [24] 1477 	lcall	_vialrgb_set_value
      00ADF2 D0 03            [24] 1478 	pop	ar3
      00ADF4 D0 06            [24] 1479 	pop	ar6
      00ADF6 D0 07            [24] 1480 	pop	ar7
                                   1481 ;	quantum/via.c:375: break;
      00ADF8 02 B0 B6         [24] 1482 	ljmp	00171$
                                   1483 ;	quantum/via.c:377: case id_lighting_get_value: {
      00ADFB                       1484 00137$:
                                   1485 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00ADFB 12 B0 DF         [24] 1486 	lcall	_ak820_outline_0057
      00ADFE 90 0D A8         [24] 1487 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AE01 EB               [12] 1488 	mov	a,r3
      00AE02 F0               [24] 1489 	movx	@dptr,a
      00AE03 12 A5 2F         [24] 1490 	lcall	_ak820_outline_0028
      00AE06 C0 07            [24] 1491 	push	ar7
      00AE08 C0 06            [24] 1492 	push	ar6
      00AE0A C0 03            [24] 1493 	push	ar3
      00AE0C 12 BA 2D         [24] 1494 	lcall	_vialrgb_get_value
      00AE0F D0 03            [24] 1495 	pop	ar3
      00AE11 D0 06            [24] 1496 	pop	ar6
      00AE13 D0 07            [24] 1497 	pop	ar7
                                   1498 ;	quantum/via.c:397: break;
      00AE15 02 B0 B6         [24] 1499 	ljmp	00171$
                                   1500 ;	quantum/via.c:399: case id_lighting_save: {
      00AE18                       1501 00138$:
                                   1502 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AE18 12 B0 DF         [24] 1503 	lcall	_ak820_outline_0057
      00AE1B 90 0D B0         [24] 1504 	mov	dptr,#_vialrgb_save_PARM_2
      00AE1E EB               [12] 1505 	mov	a,r3
      00AE1F F0               [24] 1506 	movx	@dptr,a
      00AE20 12 A5 2F         [24] 1507 	lcall	_ak820_outline_0028
      00AE23 C0 07            [24] 1508 	push	ar7
      00AE25 C0 06            [24] 1509 	push	ar6
      00AE27 C0 03            [24] 1510 	push	ar3
      00AE29 12 BC 5D         [24] 1511 	lcall	_vialrgb_save
      00AE2C D0 03            [24] 1512 	pop	ar3
      00AE2E D0 06            [24] 1513 	pop	ar6
      00AE30 D0 07            [24] 1514 	pop	ar7
                                   1515 ;	quantum/via.c:419: break;
      00AE32 02 B0 B6         [24] 1516 	ljmp	00171$
                                   1517 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AE35                       1518 00139$:
                                   1519 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AE35 C0 07            [24] 1520 	push	ar7
      00AE37 C0 06            [24] 1521 	push	ar6
      00AE39 C0 05            [24] 1522 	push	ar5
      00AE3B C0 04            [24] 1523 	push	ar4
      00AE3D C0 03            [24] 1524 	push	ar3
      00AE3F 12 8B 45         [24] 1525 	lcall	_dynamic_keymap_macro_get_count
      00AE42 AA 82            [24] 1526 	mov	r2, dpl
      00AE44 D0 03            [24] 1527 	pop	ar3
      00AE46 D0 04            [24] 1528 	pop	ar4
      00AE48 D0 05            [24] 1529 	pop	ar5
      00AE4A D0 06            [24] 1530 	pop	ar6
      00AE4C D0 07            [24] 1531 	pop	ar7
      00AE4E 12 43 EF         [24] 1532 	lcall	_ak820_outline_0011
      00AE51 EA               [12] 1533 	mov	a,r2
      00AE52 F0               [24] 1534 	movx	@dptr,a
                                   1535 ;	quantum/via.c:430: break;
      00AE53 02 B0 B6         [24] 1536 	ljmp	00171$
                                   1537 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AE56                       1538 00140$:
                                   1539 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AE56 C0 07            [24] 1540 	push	ar7
      00AE58 C0 06            [24] 1541 	push	ar6
      00AE5A C0 05            [24] 1542 	push	ar5
      00AE5C C0 04            [24] 1543 	push	ar4
      00AE5E C0 03            [24] 1544 	push	ar3
      00AE60 12 8B 49         [24] 1545 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AE63 A9 82            [24] 1546 	mov	r1, dpl
      00AE65 AA 83            [24] 1547 	mov	r2, dph
      00AE67 D0 03            [24] 1548 	pop	ar3
      00AE69 D0 04            [24] 1549 	pop	ar4
      00AE6B D0 05            [24] 1550 	pop	ar5
      00AE6D D0 06            [24] 1551 	pop	ar6
      00AE6F D0 07            [24] 1552 	pop	ar7
                                   1553 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AE71 8A 00            [24] 1554 	mov	ar0,r2
      00AE73 12 43 EF         [24] 1555 	lcall	_ak820_outline_0011
      00AE76 E8               [12] 1556 	mov	a,r0
      00AE77 F0               [24] 1557 	movx	@dptr,a
                                   1558 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AE78 12 43 D3         [24] 1559 	lcall	_ak820_outline_0002
      00AE7B A3               [24] 1560 	inc	dptr
      00AE7C A3               [24] 1561 	inc	dptr
      00AE7D E9               [12] 1562 	mov	a,r1
      00AE7E F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/via.c:436: break;
      00AE7F 02 B0 B6         [24] 1565 	ljmp	00171$
                                   1566 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AE82                       1567 00141$:
                                   1568 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AE82 C0 03            [24] 1569 	push	ar3
      00AE84 12 43 EF         [24] 1570 	lcall	_ak820_outline_0011
      00AE87 E0               [24] 1571 	movx	a,@dptr
      00AE88 FA               [12] 1572 	mov	r2,a
      00AE89 79 00            [12] 1573 	mov	r1,#0x00
      00AE8B 12 43 D3         [24] 1574 	lcall	_ak820_outline_0002
      00AE8E 12 B0 CA         [24] 1575 	lcall	_ak820_outline_0046
      00AE91 89 3E            [24] 1576 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AE93 8A 3F            [24] 1577 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1578 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AE95 12 43 D3         [24] 1579 	lcall	_ak820_outline_0002
      00AE98 12 B0 C5         [24] 1580 	lcall	_ak820_outline_0026
      00AE9B FB               [12] 1581 	mov	r3,a
                                   1582 ;	quantum/via.c:441: if (size <= 28)
      00AE9C 8B 44            [24] 1583 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AE9E 75 45 00         [24] 1584 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AEA1 C3               [12] 1585 	clr	c
      00AEA2 74 1C            [12] 1586 	mov	a,#0x1c
      00AEA4 9B               [12] 1587 	subb	a,r3
      00AEA5 D0 03            [24] 1588 	pop	ar3
      00AEA7 50 03            [24] 1589 	jnc	00562$
      00AEA9 02 B0 B6         [24] 1590 	ljmp	00171$
      00AEAC                       1591 00562$:
                                   1592 ;	free result
                                   1593 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AEAC 12 B0 D5         [24] 1594 	lcall	_ak820_outline_0055
      00AEAF 90 0B 1D         [24] 1595 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AEB2 E5 44            [12] 1596 	mov	a,_raw_hid_receive_sloc3_1_0
      00AEB4 F0               [24] 1597 	movx	@dptr,a
      00AEB5 E5 45            [12] 1598 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AEB7 A3               [24] 1599 	inc	dptr
      00AEB8 F0               [24] 1600 	movx	@dptr,a
      00AEB9 90 0B 1F         [24] 1601 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AEBC 12 B0 E6         [24] 1602 	lcall	_ak820_outline_0065
      00AEBF 85 3E 82         [24] 1603 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AEC2 85 3F 83         [24] 1604 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AEC5 C0 07            [24] 1605 	push	ar7
      00AEC7 C0 06            [24] 1606 	push	ar6
      00AEC9 C0 03            [24] 1607 	push	ar3
      00AECB 12 8B 4D         [24] 1608 	lcall	_dynamic_keymap_macro_get_buffer
      00AECE D0 03            [24] 1609 	pop	ar3
      00AED0 D0 06            [24] 1610 	pop	ar6
      00AED2 D0 07            [24] 1611 	pop	ar7
                                   1612 ;	quantum/via.c:443: break;
      00AED4 02 B0 B6         [24] 1613 	ljmp	00171$
                                   1614 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AED7                       1615 00144$:
                                   1616 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AED7 90 0E 32         [24] 1617 	mov	dptr,#_vial_unlocked
      00AEDA E0               [24] 1618 	movx	a,@dptr
      00AEDB 70 01            [24] 1619 	jnz	00146$
                                   1620 ;	quantum/via.c:450: return;
      00AEDD 22               [24] 1621 	ret
      00AEDE                       1622 00146$:
                                   1623 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AEDE C0 03            [24] 1624 	push	ar3
      00AEE0 12 43 EF         [24] 1625 	lcall	_ak820_outline_0011
      00AEE3 E0               [24] 1626 	movx	a,@dptr
      00AEE4 FA               [12] 1627 	mov	r2,a
      00AEE5 79 00            [12] 1628 	mov	r1,#0x00
      00AEE7 12 43 D3         [24] 1629 	lcall	_ak820_outline_0002
      00AEEA 12 B0 CA         [24] 1630 	lcall	_ak820_outline_0046
      00AEED 89 44            [24] 1631 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AEEF 8A 45            [24] 1632 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1633 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AEF1 12 43 D3         [24] 1634 	lcall	_ak820_outline_0002
      00AEF4 12 B0 C5         [24] 1635 	lcall	_ak820_outline_0026
      00AEF7 F5 3E            [12] 1636 	mov	_raw_hid_receive_sloc0_1_0, a
      00AEF9 75 3F 00         [24] 1637 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1638 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AEFC 85 3E 46         [24] 1639 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AEFF 85 3F 47         [24] 1640 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AF02 C3               [12] 1641 	clr	c
      00AF03 74 1C            [12] 1642 	mov	a,#0x1c
      00AF05 95 46            [12] 1643 	subb	a,_raw_hid_receive_sloc4_1_0
      00AF07 E4               [12] 1644 	clr	a
      00AF08 95 47            [12] 1645 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AF0A D0 03            [24] 1646 	pop	ar3
      00AF0C 40 44            [24] 1647 	jc	00147$
                                   1648 ;	free result
      00AF0E 8B 01            [24] 1649 	mov	ar1,r3
      00AF10 7A 00            [12] 1650 	mov	r2,#0x00
      00AF12 E9               [12] 1651 	mov	a,r1
      00AF13 24 FC            [12] 1652 	add	a,#0xfc
      00AF15 F9               [12] 1653 	mov	r1,a
      00AF16 EA               [12] 1654 	mov	a,r2
      00AF17 34 FF            [12] 1655 	addc	a,#0xff
      00AF19 FA               [12] 1656 	mov	r2,a
      00AF1A C3               [12] 1657 	clr	c
      00AF1B E9               [12] 1658 	mov	a,r1
      00AF1C 95 46            [12] 1659 	subb	a,_raw_hid_receive_sloc4_1_0
      00AF1E EA               [12] 1660 	mov	a,r2
      00AF1F 95 47            [12] 1661 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AF21 40 2F            [24] 1662 	jc	00147$
                                   1663 ;	free result
      00AF23 12 B0 D5         [24] 1664 	lcall	_ak820_outline_0055
      00AF26 90 0B 24         [24] 1665 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AF29 E5 3E            [12] 1666 	mov	a,_raw_hid_receive_sloc0_1_0
      00AF2B F0               [24] 1667 	movx	@dptr,a
      00AF2C E5 3F            [12] 1668 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AF2E A3               [24] 1669 	inc	dptr
      00AF2F F0               [24] 1670 	movx	@dptr,a
      00AF30 90 0B 26         [24] 1671 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AF33 12 B0 E6         [24] 1672 	lcall	_ak820_outline_0065
      00AF36 85 44 82         [24] 1673 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AF39 85 45 83         [24] 1674 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AF3C C0 07            [24] 1675 	push	ar7
      00AF3E C0 06            [24] 1676 	push	ar6
      00AF40 C0 03            [24] 1677 	push	ar3
      00AF42 12 8B 9C         [24] 1678 	lcall	_dynamic_keymap_macro_set_buffer
      00AF45 E5 82            [12] 1679 	mov	a, dpl
      00AF47 D0 03            [24] 1680 	pop	ar3
      00AF49 D0 06            [24] 1681 	pop	ar6
      00AF4B D0 07            [24] 1682 	pop	ar7
      00AF4D 60 03            [24] 1683 	jz	00566$
      00AF4F 02 B0 B6         [24] 1684 	ljmp	00171$
      00AF52                       1685 00566$:
      00AF52                       1686 00147$:
      00AF52 22               [24] 1687 	ret
                                   1688 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AF53                       1689 00151$:
                                   1690 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AF53 90 0E 32         [24] 1691 	mov	dptr,#_vial_unlocked
      00AF56 E0               [24] 1692 	movx	a,@dptr
      00AF57 70 01            [24] 1693 	jnz	00153$
      00AF59 22               [24] 1694 	ret
      00AF5A                       1695 00153$:
                                   1696 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AF5A C0 07            [24] 1697 	push	ar7
      00AF5C C0 06            [24] 1698 	push	ar6
      00AF5E C0 03            [24] 1699 	push	ar3
      00AF60 12 8B CD         [24] 1700 	lcall	_dynamic_keymap_macro_reset
      00AF63 D0 03            [24] 1701 	pop	ar3
      00AF65 D0 06            [24] 1702 	pop	ar6
      00AF67 D0 07            [24] 1703 	pop	ar7
                                   1704 ;	quantum/via.c:473: break;
      00AF69 02 B0 B6         [24] 1705 	ljmp	00171$
                                   1706 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AF6C                       1707 00154$:
                                   1708 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AF6C C0 07            [24] 1709 	push	ar7
      00AF6E C0 06            [24] 1710 	push	ar6
      00AF70 C0 05            [24] 1711 	push	ar5
      00AF72 C0 04            [24] 1712 	push	ar4
      00AF74 C0 03            [24] 1713 	push	ar3
      00AF76 12 84 1D         [24] 1714 	lcall	_dynamic_keymap_get_layer_count
      00AF79 AA 82            [24] 1715 	mov	r2, dpl
      00AF7B D0 03            [24] 1716 	pop	ar3
      00AF7D D0 04            [24] 1717 	pop	ar4
      00AF7F D0 05            [24] 1718 	pop	ar5
      00AF81 D0 06            [24] 1719 	pop	ar6
      00AF83 D0 07            [24] 1720 	pop	ar7
      00AF85 12 43 EF         [24] 1721 	lcall	_ak820_outline_0011
      00AF88 EA               [12] 1722 	mov	a,r2
      00AF89 F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/via.c:477: break;
      00AF8A 02 B0 B6         [24] 1725 	ljmp	00171$
                                   1726 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AF8D                       1727 00155$:
                                   1728 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF8D C0 03            [24] 1729 	push	ar3
      00AF8F 12 43 EF         [24] 1730 	lcall	_ak820_outline_0011
      00AF92 E0               [24] 1731 	movx	a,@dptr
      00AF93 FA               [12] 1732 	mov	r2,a
      00AF94 79 00            [12] 1733 	mov	r1,#0x00
      00AF96 12 43 D3         [24] 1734 	lcall	_ak820_outline_0002
      00AF99 12 B0 CA         [24] 1735 	lcall	_ak820_outline_0046
      00AF9C 89 46            [24] 1736 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AF9E 8A 47            [24] 1737 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1738 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AFA0 12 43 D3         [24] 1739 	lcall	_ak820_outline_0002
      00AFA3 12 B0 C5         [24] 1740 	lcall	_ak820_outline_0026
      00AFA6 FB               [12] 1741 	mov	r3,a
                                   1742 ;	quantum/via.c:482: if (size <= 28)
      00AFA7 8B 44            [24] 1743 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AFA9 75 45 00         [24] 1744 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AFAC C3               [12] 1745 	clr	c
      00AFAD 74 1C            [12] 1746 	mov	a,#0x1c
      00AFAF 9B               [12] 1747 	subb	a,r3
      00AFB0 D0 03            [24] 1748 	pop	ar3
      00AFB2 50 03            [24] 1749 	jnc	00568$
      00AFB4 02 B0 B6         [24] 1750 	ljmp	00171$
      00AFB7                       1751 00568$:
                                   1752 ;	free result
                                   1753 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AFB7 12 B0 D5         [24] 1754 	lcall	_ak820_outline_0055
      00AFBA 90 0B 06         [24] 1755 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AFBD E5 44            [12] 1756 	mov	a,_raw_hid_receive_sloc3_1_0
      00AFBF F0               [24] 1757 	movx	@dptr,a
      00AFC0 E5 45            [12] 1758 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AFC2 A3               [24] 1759 	inc	dptr
      00AFC3 F0               [24] 1760 	movx	@dptr,a
      00AFC4 90 0B 08         [24] 1761 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AFC7 12 B0 E6         [24] 1762 	lcall	_ak820_outline_0065
      00AFCA 85 46 82         [24] 1763 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AFCD 85 47 83         [24] 1764 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AFD0 C0 07            [24] 1765 	push	ar7
      00AFD2 C0 06            [24] 1766 	push	ar6
      00AFD4 C0 03            [24] 1767 	push	ar3
      00AFD6 12 89 08         [24] 1768 	lcall	_dynamic_keymap_get_buffer
      00AFD9 D0 03            [24] 1769 	pop	ar3
      00AFDB D0 06            [24] 1770 	pop	ar6
      00AFDD D0 07            [24] 1771 	pop	ar7
                                   1772 ;	quantum/via.c:484: break;
      00AFDF 02 B0 B6         [24] 1773 	ljmp	00171$
                                   1774 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AFE2                       1775 00158$:
                                   1776 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFE2 12 43 EF         [24] 1777 	lcall	_ak820_outline_0011
      00AFE5 E0               [24] 1778 	movx	a,@dptr
      00AFE6 FD               [12] 1779 	mov	r5,a
      00AFE7 7C 00            [12] 1780 	mov	r4,#0x00
      00AFE9 12 43 D3         [24] 1781 	lcall	_ak820_outline_0002
      00AFEC A3               [24] 1782 	inc	dptr
      00AFED A3               [24] 1783 	inc	dptr
      00AFEE E0               [24] 1784 	movx	a,@dptr
      00AFEF 7A 00            [12] 1785 	mov	r2,#0x00
      00AFF1 42 04            [12] 1786 	orl	ar4,a
      00AFF3 EA               [12] 1787 	mov	a,r2
      00AFF4 42 05            [12] 1788 	orl	ar5,a
      00AFF6 8C 46            [24] 1789 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AFF8 8D 47            [24] 1790 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1791 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AFFA 12 43 D3         [24] 1792 	lcall	_ak820_outline_0002
      00AFFD 12 B0 C5         [24] 1793 	lcall	_ak820_outline_0026
      00B000 F9               [12] 1794 	mov	r1,a
      00B001 7A 00            [12] 1795 	mov	r2,#0x00
                                   1796 ;	quantum/via.c:489: if (size <= 28)
      00B003 89 00            [24] 1797 	mov	ar0,r1
      00B005 E8               [12] 1798 	mov	a,r0
      00B006 24 E3            [12] 1799 	add	a,#0xff - 0x1c
      00B008 50 03            [24] 1800 	jnc	00569$
      00B00A 02 B0 B6         [24] 1801 	ljmp	00171$
      00B00D                       1802 00569$:
                                   1803 ;	free result
                                   1804 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B00D C0 03            [24] 1805 	push	ar3
      00B00F 74 04            [12] 1806 	mov	a,#0x04
      00B011 2E               [12] 1807 	add	a, r6
      00B012 F8               [12] 1808 	mov	r0,a
      00B013 E4               [12] 1809 	clr	a
      00B014 3F               [12] 1810 	addc	a, r7
      00B015 FB               [12] 1811 	mov	r3,a
      00B016 7D 00            [12] 1812 	mov	r5,#0x00
      00B018 90 0B 0D         [24] 1813 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B01B E9               [12] 1814 	mov	a,r1
      00B01C F0               [24] 1815 	movx	@dptr,a
      00B01D EA               [12] 1816 	mov	a,r2
      00B01E A3               [24] 1817 	inc	dptr
      00B01F F0               [24] 1818 	movx	@dptr,a
      00B020 90 0B 0F         [24] 1819 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B023 E8               [12] 1820 	mov	a,r0
      00B024 12 8F 56         [24] 1821 	lcall	_ak820_outline_0149
      00B027 ED               [12] 1822 	mov	a,r5
      00B028 A3               [24] 1823 	inc	dptr
      00B029 F0               [24] 1824 	movx	@dptr,a
      00B02A 85 46 82         [24] 1825 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B02D 85 47 83         [24] 1826 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B030 C0 07            [24] 1827 	push	ar7
      00B032 C0 06            [24] 1828 	push	ar6
      00B034 C0 03            [24] 1829 	push	ar3
      00B036 12 89 49         [24] 1830 	lcall	_dynamic_keymap_set_buffer
      00B039 D0 03            [24] 1831 	pop	ar3
      00B03B D0 06            [24] 1832 	pop	ar6
      00B03D D0 07            [24] 1833 	pop	ar7
                                   1834 ;	quantum/via.c:491: break;
      00B03F D0 03            [24] 1835 	pop	ar3
      00B041 02 B0 B6         [24] 1836 	ljmp	00171$
                                   1837 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B044                       1838 00161$:
                                   1839 ;	quantum/via.c:497: if (!vial_unlocked)
      00B044 90 0E 32         [24] 1840 	mov	dptr,#_vial_unlocked
      00B047 E0               [24] 1841 	movx	a,@dptr
      00B048 70 03            [24] 1842 	jnz	00570$
      00B04A 02 B0 B6         [24] 1843 	ljmp	00171$
      00B04D                       1844 00570$:
                                   1845 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B04D 12 B0 FD         [24] 1846 	lcall	_ak820_outline_0113
      00B050 90 06 62         [24] 1847 	mov	dptr,#_raw_hid_send_PARM_2
      00B053 12 B0 EF         [24] 1848 	lcall	_ak820_outline_0066
      00B056 C0 07            [24] 1849 	push	ar7
      00B058 C0 06            [24] 1850 	push	ar6
      00B05A C0 03            [24] 1851 	push	ar3
      00B05C 12 4A 3B         [24] 1852 	lcall	_raw_hid_send
      00B05F D0 03            [24] 1853 	pop	ar3
      00B061 D0 06            [24] 1854 	pop	ar6
      00B063 D0 07            [24] 1855 	pop	ar7
                                   1856 ;	quantum/via.c:503: wait_ms(100);
      00B065 7D 64            [12] 1857 	mov	r5,#0x64
      00B067                       1858 00176$:
      00B067 ED               [12] 1859 	mov	a,r5
      00B068 60 09            [24] 1860 	jz	00166$
      00B06A 90 00 01         [24] 1861 	mov	dptr,#0x0001
      00B06D 12 58 B8         [24] 1862 	lcall	_mDelaymS
      00B070 1D               [12] 1863 	dec	r5
      00B071 80 F4            [24] 1864 	sjmp	00176$
      00B073                       1865 00166$:
                                   1866 ;	quantum/via.c:504: bootloader_jump();
      00B073 C0 07            [24] 1867 	push	ar7
      00B075 C0 06            [24] 1868 	push	ar6
      00B077 C0 03            [24] 1869 	push	ar3
      00B079 12 34 89         [24] 1870 	lcall	_bootloader_jump
      00B07C D0 03            [24] 1871 	pop	ar3
      00B07E D0 06            [24] 1872 	pop	ar6
      00B080 D0 07            [24] 1873 	pop	ar7
                                   1874 ;	quantum/via.c:505: break;
                                   1875 ;	quantum/via.c:509: case id_vial_prefix: {
      00B082 80 32            [24] 1876 	sjmp	00171$
      00B084                       1877 00168$:
                                   1878 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B084 12 B0 FD         [24] 1879 	lcall	_ak820_outline_0113
      00B087 90 0C 73         [24] 1880 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B08A 12 B0 EF         [24] 1881 	lcall	_ak820_outline_0066
      00B08D C0 07            [24] 1882 	push	ar7
      00B08F C0 06            [24] 1883 	push	ar6
      00B091 C0 03            [24] 1884 	push	ar3
      00B093 12 B1 FA         [24] 1885 	lcall	_vial_handle_cmd
      00B096 D0 03            [24] 1886 	pop	ar3
      00B098 D0 06            [24] 1887 	pop	ar6
      00B09A D0 07            [24] 1888 	pop	ar7
                                   1889 ;	quantum/via.c:511: break;
                                   1890 ;	quantum/via.c:514: default: {
      00B09C 80 18            [24] 1891 	sjmp	00171$
      00B09E                       1892 00169$:
                                   1893 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B09E 12 B0 FD         [24] 1894 	lcall	_ak820_outline_0113
      00B0A1 90 0C 61         [24] 1895 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B0A4 12 B0 EF         [24] 1896 	lcall	_ak820_outline_0066
      00B0A7 C0 07            [24] 1897 	push	ar7
      00B0A9 C0 06            [24] 1898 	push	ar6
      00B0AB C0 03            [24] 1899 	push	ar3
      00B0AD 12 AA 8A         [24] 1900 	lcall	_raw_hid_receive_kb
      00B0B0 D0 03            [24] 1901 	pop	ar3
      00B0B2 D0 06            [24] 1902 	pop	ar6
      00B0B4 D0 07            [24] 1903 	pop	ar7
                                   1904 ;	quantum/via.c:521: skip:
      00B0B6                       1905 00171$:
                                   1906 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B0B6 7D 00            [12] 1907 	mov	r5,#0x00
      00B0B8 90 06 62         [24] 1908 	mov	dptr,#_raw_hid_send_PARM_2
      00B0BB EB               [12] 1909 	mov	a,r3
      00B0BC F0               [24] 1910 	movx	@dptr,a
      00B0BD 12 43 D3         [24] 1911 	lcall	_ak820_outline_0002
      00B0C0 8D F0            [24] 1912 	mov	b, r5
                                   1913 ;	quantum/via.c:526: }
      00B0C2 02 4A 3B         [24] 1914 	ljmp	_raw_hid_send
                                   1915 	.area CSEG    (CODE)
                                   1916 	.area CONST   (CODE)
                                   1917 	.area XINIT   (CODE)
                                   1918 	.area CABS    (ABS,CODE)
                                   1919 
                                   1920 ; Experimental exact instruction outlining.
                                   1921 	.globl _ak820_outline_0000
                                   1922 	.globl _ak820_outline_0001
                                   1923 	.globl _ak820_outline_0002
                                   1924 	.globl _ak820_outline_0004
                                   1925 	.globl _ak820_outline_0005
                                   1926 	.globl _ak820_outline_0007
                                   1927 	.globl _ak820_outline_0010
                                   1928 	.globl _ak820_outline_0011
                                   1929 	.globl _ak820_outline_0016
                                   1930 	.globl _ak820_outline_0026
                                   1931 	.globl _ak820_outline_0028
                                   1932 	.globl _ak820_outline_0040
                                   1933 	.globl _ak820_outline_0043
                                   1934 	.globl _ak820_outline_0046
                                   1935 	.globl _ak820_outline_0055
                                   1936 	.globl _ak820_outline_0057
                                   1937 	.globl _ak820_outline_0065
                                   1938 	.globl _ak820_outline_0066
                                   1939 	.globl _ak820_outline_0073
                                   1940 	.globl _ak820_outline_0086
                                   1941 	.globl _ak820_outline_0099
                                   1942 	.globl _ak820_outline_0113
                                   1943 	.globl _ak820_outline_0115
                                   1944 	.globl _ak820_outline_0117
                                   1945 	.globl _ak820_outline_0129
                                   1946 	.globl _ak820_outline_0146
                                   1947 	.globl _ak820_outline_0149
                                   1948 
                                   1949 	.area CSEG (CODE)
                                   1950 ; function ak820_outline_0026
      00B0C5                       1951 _ak820_outline_0026:
      00B0C5 A3               [24] 1952 	inc	dptr
      00B0C6 A3               [24] 1953 	inc	dptr
      00B0C7 A3               [24] 1954 	inc	dptr
      00B0C8 E0               [24] 1955 	movx	a,@dptr
      00B0C9 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0046
      00B0CA                       1960 _ak820_outline_0046:
      00B0CA A3               [24] 1961 	inc	dptr
      00B0CB A3               [24] 1962 	inc	dptr
      00B0CC E0               [24] 1963 	movx	a,@dptr
      00B0CD 7B 00            [12] 1964 	mov	r3,#0x00
      00B0CF 42 01            [12] 1965 	orl	ar1,a
      00B0D1 EB               [12] 1966 	mov	a,r3
      00B0D2 42 02            [12] 1967 	orl	ar2,a
      00B0D4 22               [24] 1968 	ret
                                   1969 
                                   1970 	.area CSEG (CODE)
                                   1971 ; function ak820_outline_0055
      00B0D5                       1972 _ak820_outline_0055:
      00B0D5 74 04            [12] 1973 	mov	a,#0x04
      00B0D7 2E               [12] 1974 	add	a,r6
      00B0D8 F9               [12] 1975 	mov	r1,a
      00B0D9 E4               [12] 1976 	clr	a
      00B0DA 3F               [12] 1977 	addc	a,r7
      00B0DB F8               [12] 1978 	mov	r0,a
      00B0DC 7A 00            [12] 1979 	mov	r2,#0x00
      00B0DE 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0057
      00B0DF                       1984 _ak820_outline_0057:
      00B0DF 8E 00            [24] 1985 	mov	ar0,r6
      00B0E1 8F 01            [24] 1986 	mov	ar1,r7
      00B0E3 7A 00            [12] 1987 	mov	r2,#0x00
      00B0E5 22               [24] 1988 	ret
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0065
      00B0E6                       1992 _ak820_outline_0065:
      00B0E6 E9               [12] 1993 	mov	a,r1
      00B0E7 F0               [24] 1994 	movx	@dptr,a
      00B0E8 E8               [12] 1995 	mov	a,r0
      00B0E9 A3               [24] 1996 	inc	dptr
      00B0EA F0               [24] 1997 	movx	@dptr,a
      00B0EB EA               [12] 1998 	mov	a,r2
      00B0EC A3               [24] 1999 	inc	dptr
      00B0ED F0               [24] 2000 	movx	@dptr,a
      00B0EE 22               [24] 2001 	ret
                                   2002 
                                   2003 	.area CSEG (CODE)
                                   2004 ; function ak820_outline_0066
      00B0EF                       2005 _ak820_outline_0066:
      00B0EF EB               [12] 2006 	mov	a,r3
      00B0F0 F0               [24] 2007 	movx	@dptr,a
      00B0F1 8A 82            [24] 2008 	mov	dpl,r2
      00B0F3 8C 83            [24] 2009 	mov	dph,r4
      00B0F5 8D F0            [24] 2010 	mov	b,r5
      00B0F7 22               [24] 2011 	ret
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0099
      00B0F8                       2015 _ak820_outline_0099:
      00B0F8 A3               [24] 2016 	inc	dptr
      00B0F9 A3               [24] 2017 	inc	dptr
      00B0FA A3               [24] 2018 	inc	dptr
      00B0FB A3               [24] 2019 	inc	dptr
      00B0FC 22               [24] 2020 	ret
                                   2021 
                                   2022 	.area CSEG (CODE)
                                   2023 ; function ak820_outline_0113
      00B0FD                       2024 _ak820_outline_0113:
      00B0FD 8E 02            [24] 2025 	mov	ar2,r6
      00B0FF 8F 04            [24] 2026 	mov	ar4,r7
      00B101 7D 00            [12] 2027 	mov	r5,#0x00
      00B103 22               [24] 2028 	ret
