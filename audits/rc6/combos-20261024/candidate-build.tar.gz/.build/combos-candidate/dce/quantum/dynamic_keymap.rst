                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000030                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000030                        588 	.ds 2
      000032                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      000032                        590 	.ds 1
      000033                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      000033                        592 	.ds 1
      000034                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      000034                        594 	.ds 2
      000036                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000036                        596 	.ds 2
      000038                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000038                        598 	.ds 1
      000039                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000039                        600 	.ds 2
      00003B                        601 _dynamic_keymap_macro_send_sloc0_1_0:
      00003B                        602 	.ds 3
                                    603 ;--------------------------------------------------------
                                    604 ; overlayable items in internal ram
                                    605 ;--------------------------------------------------------
                                    606 ;--------------------------------------------------------
                                    607 ; indirectly addressable internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area ISEG    (DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; absolute internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area IABS    (ABS,DATA)
                                    614 	.area IABS    (ABS,DATA)
                                    615 ;--------------------------------------------------------
                                    616 ; bit data
                                    617 ;--------------------------------------------------------
                                    618 	.area BSEG    (BIT)
      00001D                        619 _dynamic_keymap_macro_send_sloc1_1_0:
      00001D                        620 	.ds 1
                                    621 ;--------------------------------------------------------
                                    622 ; paged external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area PSEG    (PAG,XDATA)
                                    625 ;--------------------------------------------------------
                                    626 ; uninitialized external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area XSEG    (XDATA)
      000AC8                        629 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AC8                        630 	.ds 1
      000AC9                        631 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AC9                        632 	.ds 1
      000ACA                        633 _dynamic_keymap_key_to_eeprom_address_layer_10000_363:
      000ACA                        634 	.ds 1
      000ACB                        635 _dynamic_keymap_get_keycode_PARM_2:
      000ACB                        636 	.ds 1
      000ACC                        637 _dynamic_keymap_get_keycode_PARM_3:
      000ACC                        638 	.ds 1
      000ACD                        639 _dynamic_keymap_get_keycode_layer_10000_365:
      000ACD                        640 	.ds 1
      000ACE                        641 _dynamic_keymap_set_keycode_PARM_2:
      000ACE                        642 	.ds 1
      000ACF                        643 _dynamic_keymap_set_keycode_PARM_3:
      000ACF                        644 	.ds 1
      000AD0                        645 _dynamic_keymap_set_keycode_PARM_4:
      000AD0                        646 	.ds 2
      000AD2                        647 _dynamic_keymap_set_keycode_layer_10000_369:
      000AD2                        648 	.ds 1
      000AD3                        649 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AD3                        650 	.ds 1
      000AD4                        651 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_373:
      000AD4                        652 	.ds 1
      000AD5                        653 _dynamic_keymap_get_encoder_PARM_2:
      000AD5                        654 	.ds 1
      000AD6                        655 _dynamic_keymap_get_encoder_PARM_3:
      000AD6                        656 	.ds 1
      000AD7                        657 _dynamic_keymap_get_encoder_layer_10000_375:
      000AD7                        658 	.ds 1
      000AD8                        659 _dynamic_keymap_set_encoder_PARM_2:
      000AD8                        660 	.ds 1
      000AD9                        661 _dynamic_keymap_set_encoder_PARM_3:
      000AD9                        662 	.ds 1
      000ADA                        663 _dynamic_keymap_set_encoder_PARM_4:
      000ADA                        664 	.ds 2
      000ADC                        665 _dynamic_keymap_set_encoder_layer_10000_379:
      000ADC                        666 	.ds 1
      000ADD                        667 _dynamic_keymap_get_combo_PARM_2:
      000ADD                        668 	.ds 3
      000AE0                        669 _dynamic_keymap_get_combo_index_10000_383:
      000AE0                        670 	.ds 1
      000AE1                        671 _dynamic_keymap_set_combo_PARM_2:
      000AE1                        672 	.ds 3
      000AE4                        673 _dynamic_keymap_set_combo_index_10000_389:
      000AE4                        674 	.ds 1
      000AE5                        675 _dynamic_keymap_set_combo_stored_10002_394:
      000AE5                        676 	.ds 10
      000AEF                        677 _dynamic_keymap_reset_vial_unlocked_prev_10000_397:
      000AEF                        678 	.ds 1
      000AF0                        679 _dynamic_keymap_reset_combo_10001_406:
      000AF0                        680 	.ds 10
      000AFA                        681 _ak820_dynamic_read_buffer_PARM_2:
      000AFA                        682 	.ds 2
      000AFC                        683 _ak820_dynamic_read_buffer_PARM_3:
      000AFC                        684 	.ds 2
      000AFE                        685 _ak820_dynamic_read_buffer_PARM_4:
      000AFE                        686 	.ds 2
      000B00                        687 _ak820_dynamic_read_buffer_PARM_5:
      000B00                        688 	.ds 3
      000B03                        689 _ak820_dynamic_read_buffer_base_10000_408:
      000B03                        690 	.ds 2
      000B05                        691 _ak820_dynamic_read_buffer_available_10000_409:
      000B05                        692 	.ds 1
      000B06                        693 _dynamic_keymap_get_buffer_PARM_2:
      000B06                        694 	.ds 2
      000B08                        695 _dynamic_keymap_get_buffer_PARM_3:
      000B08                        696 	.ds 3
      000B0B                        697 _dynamic_keymap_get_buffer_offset_10000_415:
      000B0B                        698 	.ds 2
      000B0D                        699 _dynamic_keymap_set_buffer_PARM_2:
      000B0D                        700 	.ds 2
      000B0F                        701 _dynamic_keymap_set_buffer_PARM_3:
      000B0F                        702 	.ds 3
      000B12                        703 _dynamic_keymap_set_buffer_offset_10000_417:
      000B12                        704 	.ds 2
      000B14                        705 _dynamic_keymap_set_buffer_chk_offset_30001_424:
      000B14                        706 	.ds 1
      000B15                        707 _dynamic_keymap_set_buffer_chk_sz_30001_424:
      000B15                        708 	.ds 1
      000B16                        709 _dynamic_keymap_set_buffer_i_40001_431:
      000B16                        710 	.ds 1
      000B17                        711 _keycode_at_keymap_location_PARM_2:
      000B17                        712 	.ds 1
      000B18                        713 _keycode_at_keymap_location_PARM_3:
      000B18                        714 	.ds 1
      000B19                        715 _keycode_at_keymap_location_layer_num_10000_435:
      000B19                        716 	.ds 1
      000B1A                        717 _keycode_at_encodermap_location_PARM_2:
      000B1A                        718 	.ds 1
      000B1B                        719 _keycode_at_encodermap_location_PARM_3:
      000B1B                        720 	.ds 1
      000B1C                        721 _keycode_at_encodermap_location_layer_num_10000_439:
      000B1C                        722 	.ds 1
      000B1D                        723 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B1D                        724 	.ds 2
      000B1F                        725 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B1F                        726 	.ds 3
      000B22                        727 _dynamic_keymap_macro_get_buffer_offset_10000_447:
      000B22                        728 	.ds 2
      000B24                        729 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B24                        730 	.ds 2
      000B26                        731 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B26                        732 	.ds 3
      000B29                        733 _dynamic_keymap_macro_set_buffer_offset_10000_449:
      000B29                        734 	.ds 2
      000B2B                        735 _decode_keycode_kc_10000_453:
      000B2B                        736 	.ds 2
      000B2D                        737 _dynamic_keymap_macro_send_id_10000_456:
      000B2D                        738 	.ds 1
      000B2E                        739 _dynamic_keymap_macro_send_sending_10000_457:
      000B2E                        740 	.ds 1
      000B2F                        741 _dynamic_keymap_macro_send_p_10001_462:
      000B2F                        742 	.ds 3
      000B32                        743 _dynamic_keymap_macro_send_data_10003_469:
      000B32                        744 	.ds 4
                                    745 ;--------------------------------------------------------
                                    746 ; absolute external ram data
                                    747 ;--------------------------------------------------------
                                    748 	.area XABS    (ABS,XDATA)
                                    749 ;--------------------------------------------------------
                                    750 ; initialized external ram data
                                    751 ;--------------------------------------------------------
                                    752 	.area XISEG   (XDATA)
                                    753 	.area HOME    (CODE)
                                    754 	.area GSINIT0 (CODE)
                                    755 	.area GSINIT1 (CODE)
                                    756 	.area GSINIT2 (CODE)
                                    757 	.area GSINIT3 (CODE)
                                    758 	.area GSINIT4 (CODE)
                                    759 	.area GSINIT5 (CODE)
                                    760 	.area GSINIT  (CODE)
                                    761 	.area GSFINAL (CODE)
                                    762 	.area CSEG    (CODE)
                                    763 ;--------------------------------------------------------
                                    764 ; global & static initialisations
                                    765 ;--------------------------------------------------------
                                    766 	.area HOME    (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 	.area GSFINAL (CODE)
                                    769 	.area GSINIT  (CODE)
                                    770 ;--------------------------------------------------------
                                    771 ; Home
                                    772 ;--------------------------------------------------------
                                    773 	.area HOME    (CODE)
                                    774 	.area HOME    (CODE)
                                    775 ;--------------------------------------------------------
                                    776 ; code
                                    777 ;--------------------------------------------------------
                                    778 	.area CSEG    (CODE)
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    781 ;------------------------------------------------------------
                                    782 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_229'
                                    783 ;------------------------------------------------------------
                                    784 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    785 ;	-----------------------------------------
                           000007   786 	ar7 = 0x07
                           000006   787 	ar6 = 0x06
                           000005   788 	ar5 = 0x05
                           000004   789 	ar4 = 0x04
                           000003   790 	ar3 = 0x03
                           000002   791 	ar2 = 0x02
                           000001   792 	ar1 = 0x01
                           000000   793 	ar0 = 0x00
                                    794 ;	 function dynamic_keymap_get_layer_count
                                    795 ;	-----------------------------------------
      00841D                        796 _dynamic_keymap_get_layer_count:
                                    797 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      00841D 75 82 06         [24]  798 	mov	dpl, #0x06
                                    799 ;	quantum/dynamic_keymap.c:179: }
      008420 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    803 ;------------------------------------------------------------
                                    804 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    805 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    806 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_363'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function dynamic_keymap_key_to_eeprom_address
                                    811 ;	-----------------------------------------
      008421                        812 _dynamic_keymap_key_to_eeprom_address:
      008421 E5 82            [12]  813 	mov	a,dpl
      008423 90 0A CA         [24]  814 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_363
      008426 F0               [24]  815 	movx	@dptr,a
                                    816 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008427 E0               [24]  817 	movx	a,@dptr
      008428 FF               [12]  818 	mov	r7,a
      008429 7E 00            [12]  819 	mov	r6,#0x00
      00842B 74 40            [12]  820 	mov	a,#0x40
      00842D 12 44 39         [24]  821 	lcall	_ak820_outline_0050
      008430 7D 00            [12]  822 	mov	r5,#0x00
      008432 90 0A C8         [24]  823 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008435 E0               [24]  824 	movx	a,@dptr
      008436 75 F0 10         [24]  825 	mov	b,#0x10
      008439 A4               [48]  826 	mul	ab
      00843A 2E               [12]  827 	add	a, r6
      00843B FE               [12]  828 	mov	r6,a
      00843C EF               [12]  829 	mov	a,r7
      00843D 35 F0            [12]  830 	addc	a, b
      00843F FF               [12]  831 	mov	r7,a
      008440 90 0A C9         [24]  832 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008443 E0               [24]  833 	movx	a,@dptr
      008444 7C 00            [12]  834 	mov	r4,#0x00
      008446 25 E0            [12]  835 	add	a,acc
      008448 FB               [12]  836 	mov	r3,a
      008449 EC               [12]  837 	mov	a,r4
      00844A 33               [12]  838 	rlc	a
      00844B FC               [12]  839 	mov	r4,a
      00844C EB               [12]  840 	mov	a,r3
      00844D 2E               [12]  841 	add	a, r6
      00844E FE               [12]  842 	mov	r6,a
      00844F EC               [12]  843 	mov	a,r4
      008450 3F               [12]  844 	addc	a, r7
      008451 FF               [12]  845 	mov	r7,a
      008452 12 43 D3         [24]  846 	lcall	_ak820_outline_0002
      008455 8D F0            [24]  847 	mov	b, r5
                                    848 ;	quantum/dynamic_keymap.c:184: }
      008457 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    852 ;------------------------------------------------------------
                                    853 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    854 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    855 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_365'
                                    856 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_368'
                                    857 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_368'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function dynamic_keymap_get_keycode
                                    862 ;	-----------------------------------------
      008458                        863 _dynamic_keymap_get_keycode:
      008458 E5 82            [12]  864 	mov	a,dpl
      00845A 90 0A CD         [24]  865 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_365
      00845D F0               [24]  866 	movx	@dptr,a
                                    867 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      00845E E0               [24]  868 	movx	a,@dptr
      00845F FF               [12]  869 	mov	r7,a
      008460 BF 06 00         [24]  870 	cjne	r7,#0x06,00121$
      008463                        871 00121$:
      008463 50 14            [24]  872 	jnc	00101$
      008465 90 0A CB         [24]  873 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008468 E0               [24]  874 	movx	a,@dptr
      008469 FE               [12]  875 	mov	r6,a
      00846A BE 10 00         [24]  876 	cjne	r6,#0x10,00123$
      00846D                        877 00123$:
      00846D 50 0A            [24]  878 	jnc	00101$
      00846F 90 0A CC         [24]  879 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008472 E0               [24]  880 	movx	a,@dptr
      008473 FD               [12]  881 	mov	r5,a
      008474 BD 08 00         [24]  882 	cjne	r5,#0x08,00125$
      008477                        883 00125$:
      008477 40 04            [24]  884 	jc	00102$
      008479                        885 00101$:
      008479 90 00 00         [24]  886 	mov	dptr,#0x0000
      00847C 22               [24]  887 	ret
      00847D                        888 00102$:
                                    889 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00847D 12 8F 04         [24]  890 	lcall	_ak820_outline_0075
      008480 12 84 21         [24]  891 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    892 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008483 12 8F 11         [24]  893 	lcall	_ak820_outline_0079
      008486 12 41 13         [24]  894 	lcall	_eeprom_read_byte
      008489 AB 82            [24]  895 	mov	r3,dpl
      00848B 7C 00            [12]  896 	mov	r4,#0x00
                                    897 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      00848D 0D               [12]  898 	inc	r5
      00848E BD 00 01         [24]  899 	cjne	r5,#0x00,00127$
      008491 0E               [12]  900 	inc	r6
      008492                        901 00127$:
      008492 12 4E 65         [24]  902 	lcall	_ak820_outline_0005
      008495 12 41 13         [24]  903 	lcall	_eeprom_read_byte
      008498 AF 82            [24]  904 	mov	r7, dpl
      00849A 7E 00            [12]  905 	mov	r6,#0x00
      00849C EF               [12]  906 	mov	a,r7
      00849D 42 04            [12]  907 	orl	ar4,a
      00849F EE               [12]  908 	mov	a,r6
      0084A0 42 03            [12]  909 	orl	ar3,a
                                    910 ;	quantum/dynamic_keymap.c:192: return keycode;
      0084A2 12 44 96         [24]  911 	lcall	_ak820_outline_0147
                                    912 ;	quantum/dynamic_keymap.c:193: }
      0084A5 22               [24]  913 	ret
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    916 ;------------------------------------------------------------
                                    917 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    918 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    919 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    920 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_369'
                                    921 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_372'
                                    922 ;------------------------------------------------------------
                                    923 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function dynamic_keymap_set_keycode
                                    926 ;	-----------------------------------------
      0084A6                        927 _dynamic_keymap_set_keycode:
      0084A6 E5 82            [12]  928 	mov	a,dpl
      0084A8 90 0A D2         [24]  929 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_369
      0084AB F0               [24]  930 	movx	@dptr,a
                                    931 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0084AC E0               [24]  932 	movx	a,@dptr
      0084AD FF               [12]  933 	mov	r7,a
      0084AE BF 06 00         [24]  934 	cjne	r7,#0x06,00121$
      0084B1                        935 00121$:
      0084B1 50 14            [24]  936 	jnc	00101$
      0084B3 90 0A CE         [24]  937 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0084B6 E0               [24]  938 	movx	a,@dptr
      0084B7 FE               [12]  939 	mov	r6,a
      0084B8 BE 10 00         [24]  940 	cjne	r6,#0x10,00123$
      0084BB                        941 00123$:
      0084BB 50 0A            [24]  942 	jnc	00101$
      0084BD 90 0A CF         [24]  943 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0084C0 E0               [24]  944 	movx	a,@dptr
      0084C1 FD               [12]  945 	mov	r5,a
      0084C2 BD 08 00         [24]  946 	cjne	r5,#0x08,00125$
      0084C5                        947 00125$:
      0084C5 40 01            [24]  948 	jc	00102$
      0084C7                        949 00101$:
      0084C7 22               [24]  950 	ret
      0084C8                        951 00102$:
                                    952 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0084C8 12 8F 04         [24]  953 	lcall	_ak820_outline_0075
      0084CB 12 84 21         [24]  954 	lcall	_dynamic_keymap_key_to_eeprom_address
      0084CE 12 8F 11         [24]  955 	lcall	_ak820_outline_0079
                                    956 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0084D1 90 0A D0         [24]  957 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0084D4 E0               [24]  958 	movx	a,@dptr
      0084D5 FB               [12]  959 	mov	r3,a
      0084D6 A3               [24]  960 	inc	dptr
      0084D7 E0               [24]  961 	movx	a,@dptr
      0084D8 90 06 88         [24]  962 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084DB F0               [24]  963 	movx	@dptr,a
      0084DC 12 4E 65         [24]  964 	lcall	_ak820_outline_0005
      0084DF 12 4D 63         [24]  965 	lcall	_eeprom_update_byte
                                    966 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0084E2 0D               [12]  967 	inc	r5
      0084E3 BD 00 01         [24]  968 	cjne	r5,#0x00,00127$
      0084E6 0E               [12]  969 	inc	r6
      0084E7                        970 00127$:
      0084E7 90 06 88         [24]  971 	mov	dptr,#_eeprom_update_byte_PARM_2
      0084EA EB               [12]  972 	mov	a,r3
      0084EB F0               [24]  973 	movx	@dptr,a
      0084EC 12 4E 65         [24]  974 	lcall	_ak820_outline_0005
                                    975 ;	quantum/dynamic_keymap.c:201: }
      0084EF 02 4D 63         [24]  976 	ljmp	_eeprom_update_byte
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    979 ;------------------------------------------------------------
                                    980 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    981 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_373'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    986 ;	-----------------------------------------
      0084F2                        987 _dynamic_keymap_encoder_to_eeprom_address:
      0084F2 E5 82            [12]  988 	mov	a,dpl
      0084F4 90 0A D4         [24]  989 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_373
      0084F7 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0084F8 E0               [24]  992 	movx	a,@dptr
      0084F9 75 F0 04         [24]  993 	mov	b,#0x04
      0084FC A4               [48]  994 	mul	ab
      0084FD 24 40            [12]  995 	add	a, #0x40
      0084FF FD               [12]  996 	mov	r5,a
      008500 74 06            [12]  997 	mov	a,#0x06
      008502 35 F0            [12]  998 	addc	a, b
      008504 FE               [12]  999 	mov	r6,a
      008505 7F 00            [12] 1000 	mov	r7,#0x00
      008507 90 0A D3         [24] 1001 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00850A E0               [24] 1002 	movx	a,@dptr
      00850B 75 F0 04         [24] 1003 	mov	b,#0x04
      00850E A4               [48] 1004 	mul	ab
      00850F 2D               [12] 1005 	add	a, r5
      008510 FD               [12] 1006 	mov	r5,a
      008511 EE               [12] 1007 	mov	a,r6
      008512 35 F0            [12] 1008 	addc	a, b
      008514 FE               [12] 1009 	mov	r6,a
      008515 12 4E 65         [24] 1010 	lcall	_ak820_outline_0005
                                   1011 ;	quantum/dynamic_keymap.c:206: }
      008518 22               [24] 1012 	ret
                                   1013 ;------------------------------------------------------------
                                   1014 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1015 ;------------------------------------------------------------
                                   1016 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1017 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1018 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_375'
                                   1019 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_378'
                                   1020 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_378'
                                   1021 ;------------------------------------------------------------
                                   1022 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1023 ;	-----------------------------------------
                                   1024 ;	 function dynamic_keymap_get_encoder
                                   1025 ;	-----------------------------------------
      008519                       1026 _dynamic_keymap_get_encoder:
      008519 E5 82            [12] 1027 	mov	a,dpl
      00851B 90 0A D7         [24] 1028 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_375
      00851E F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00851F E0               [24] 1031 	movx	a,@dptr
      008520 FF               [12] 1032 	mov	r7,a
      008521 BF 06 00         [24] 1033 	cjne	r7,#0x06,00131$
      008524                       1034 00131$:
      008524 50 0A            [24] 1035 	jnc	00101$
      008526 90 0A D5         [24] 1036 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008529 E0               [24] 1037 	movx	a,@dptr
      00852A FE               [12] 1038 	mov	r6,a
      00852B BE 01 00         [24] 1039 	cjne	r6,#0x01,00133$
      00852E                       1040 00133$:
      00852E 40 04            [24] 1041 	jc	00102$
      008530                       1042 00101$:
      008530 90 00 00         [24] 1043 	mov	dptr,#0x0000
      008533 22               [24] 1044 	ret
      008534                       1045 00102$:
                                   1046 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008534 90 0A D3         [24] 1047 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008537 E4               [12] 1048 	clr	a
      008538 F0               [24] 1049 	movx	@dptr,a
      008539 8F 82            [24] 1050 	mov	dpl, r7
      00853B 12 84 F2         [24] 1051 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00853E 12 8F 11         [24] 1052 	lcall	_ak820_outline_0079
                                   1053 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008541 90 0A D6         [24] 1054 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008544 E0               [24] 1055 	movx	a,@dptr
      008545 FC               [12] 1056 	mov	r4,a
      008546 E0               [24] 1057 	movx	a,@dptr
      008547 60 04            [24] 1058 	jz	00106$
      008549 7B 00            [12] 1059 	mov	r3,#0x00
      00854B 80 02            [24] 1060 	sjmp	00107$
      00854D                       1061 00106$:
      00854D 7B 02            [12] 1062 	mov	r3,#0x02
      00854F                       1063 00107$:
      00854F EB               [12] 1064 	mov	a,r3
      008550 12 8E E9         [24] 1065 	lcall	_ak820_outline_0049
      008553 8F 03            [24] 1066 	mov	ar3,r7
      008555 12 44 06         [24] 1067 	lcall	_ak820_outline_0016
      008558 8B F0            [24] 1068 	mov	b, r3
      00855A 12 41 13         [24] 1069 	lcall	_eeprom_read_byte
      00855D AA 82            [24] 1070 	mov	r2,dpl
      00855F 7B 00            [12] 1071 	mov	r3,#0x00
                                   1072 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008561 EC               [12] 1073 	mov	a,r4
      008562 60 04            [24] 1074 	jz	00108$
      008564 7C 00            [12] 1075 	mov	r4,#0x00
      008566 80 02            [24] 1076 	sjmp	00109$
      008568                       1077 00108$:
      008568 7C 02            [12] 1078 	mov	r4,#0x02
      00856A                       1079 00109$:
      00856A EC               [12] 1080 	mov	a,r4
      00856B 12 8F 2F         [24] 1081 	lcall	_ak820_outline_0117
      00856E 0D               [12] 1082 	inc	r5
      00856F BD 00 01         [24] 1083 	cjne	r5,#0x00,00137$
      008572 0E               [12] 1084 	inc	r6
      008573                       1085 00137$:
      008573 12 4E 65         [24] 1086 	lcall	_ak820_outline_0005
      008576 12 41 13         [24] 1087 	lcall	_eeprom_read_byte
      008579 AF 82            [24] 1088 	mov	r7, dpl
      00857B 7E 00            [12] 1089 	mov	r6,#0x00
      00857D EF               [12] 1090 	mov	a,r7
      00857E 42 03            [12] 1091 	orl	ar3,a
      008580 EE               [12] 1092 	mov	a,r6
      008581 42 02            [12] 1093 	orl	ar2,a
                                   1094 ;	quantum/dynamic_keymap.c:214: return keycode;
      008583 8B 82            [24] 1095 	mov	dpl, r3
      008585 8A 83            [24] 1096 	mov	dph, r2
                                   1097 ;	quantum/dynamic_keymap.c:215: }
      008587 22               [24] 1098 	ret
                                   1099 ;------------------------------------------------------------
                                   1100 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1101 ;------------------------------------------------------------
                                   1102 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1103 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1104 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1105 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1106 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_379'
                                   1107 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_382'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function dynamic_keymap_set_encoder
                                   1112 ;	-----------------------------------------
      008588                       1113 _dynamic_keymap_set_encoder:
      008588 E5 82            [12] 1114 	mov	a,dpl
      00858A 90 0A DC         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_379
      00858D F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00858E E0               [24] 1118 	movx	a,@dptr
      00858F FF               [12] 1119 	mov	r7,a
      008590 BF 06 00         [24] 1120 	cjne	r7,#0x06,00131$
      008593                       1121 00131$:
      008593 50 0A            [24] 1122 	jnc	00101$
      008595 90 0A D8         [24] 1123 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008598 E0               [24] 1124 	movx	a,@dptr
      008599 FE               [12] 1125 	mov	r6,a
      00859A BE 01 00         [24] 1126 	cjne	r6,#0x01,00133$
      00859D                       1127 00133$:
      00859D 40 01            [24] 1128 	jc	00102$
      00859F                       1129 00101$:
      00859F 22               [24] 1130 	ret
      0085A0                       1131 00102$:
                                   1132 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0085A0 90 0A D3         [24] 1133 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0085A3 E4               [12] 1134 	clr	a
      0085A4 F0               [24] 1135 	movx	@dptr,a
      0085A5 8F 82            [24] 1136 	mov	dpl, r7
      0085A7 12 84 F2         [24] 1137 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0085AA 12 8F 11         [24] 1138 	lcall	_ak820_outline_0079
                                   1139 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0085AD 90 0A D9         [24] 1140 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0085B0 E0               [24] 1141 	movx	a,@dptr
      0085B1 FC               [12] 1142 	mov	r4,a
      0085B2 E0               [24] 1143 	movx	a,@dptr
      0085B3 60 04            [24] 1144 	jz	00106$
      0085B5 7B 00            [12] 1145 	mov	r3,#0x00
      0085B7 80 02            [24] 1146 	sjmp	00107$
      0085B9                       1147 00106$:
      0085B9 7B 02            [12] 1148 	mov	r3,#0x02
      0085BB                       1149 00107$:
      0085BB EB               [12] 1150 	mov	a,r3
      0085BC 12 8E E9         [24] 1151 	lcall	_ak820_outline_0049
      0085BF 8F 03            [24] 1152 	mov	ar3,r7
      0085C1 90 0A DA         [24] 1153 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0085C4 E0               [24] 1154 	movx	a,@dptr
      0085C5 F5 30            [12] 1155 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0085C7 A3               [24] 1156 	inc	dptr
      0085C8 E0               [24] 1157 	movx	a,@dptr
      0085C9 F5 31            [12] 1158 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0085CB 90 06 88         [24] 1159 	mov	dptr,#_eeprom_update_byte_PARM_2
      0085CE F0               [24] 1160 	movx	@dptr,a
      0085CF 12 44 06         [24] 1161 	lcall	_ak820_outline_0016
      0085D2 8B F0            [24] 1162 	mov	b, r3
      0085D4 12 4D 63         [24] 1163 	lcall	_eeprom_update_byte
                                   1164 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0085D7 EC               [12] 1165 	mov	a,r4
      0085D8 60 04            [24] 1166 	jz	00108$
      0085DA 7C 00            [12] 1167 	mov	r4,#0x00
      0085DC 80 02            [24] 1168 	sjmp	00109$
      0085DE                       1169 00108$:
      0085DE 7C 02            [12] 1170 	mov	r4,#0x02
      0085E0                       1171 00109$:
      0085E0 EC               [12] 1172 	mov	a,r4
      0085E1 12 8F 2F         [24] 1173 	lcall	_ak820_outline_0117
      0085E4 0D               [12] 1174 	inc	r5
      0085E5 BD 00 01         [24] 1175 	cjne	r5,#0x00,00137$
      0085E8 0E               [12] 1176 	inc	r6
      0085E9                       1177 00137$:
      0085E9 90 06 88         [24] 1178 	mov	dptr,#_eeprom_update_byte_PARM_2
      0085EC E5 30            [12] 1179 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0085EE F0               [24] 1180 	movx	@dptr,a
      0085EF 12 4E 65         [24] 1181 	lcall	_ak820_outline_0005
                                   1182 ;	quantum/dynamic_keymap.c:223: }
      0085F2 02 4D 63         [24] 1183 	ljmp	_eeprom_update_byte
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1186 ;------------------------------------------------------------
                                   1187 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1188 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1189 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_383'
                                   1190 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_384'
                                   1191 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_386'
                                   1192 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_387'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function dynamic_keymap_get_combo
                                   1197 ;	-----------------------------------------
      0085F5                       1198 _dynamic_keymap_get_combo:
      0085F5 E5 82            [12] 1199 	mov	a,dpl
      0085F7 90 0A E0         [24] 1200 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_383
      0085FA F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0085FB 90 0A DD         [24] 1203 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0085FE 12 43 C5         [24] 1204 	lcall	_ak820_outline_0000
                                   1205 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008601 90 0A E0         [24] 1206 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_383
      008604 E0               [24] 1207 	movx	a,@dptr
      008605 FD               [12] 1208 	mov	r5,a
      008606 BD 08 00         [24] 1209 	cjne	r5,#0x08,00132$
      008609                       1210 00132$:
      008609 40 04            [24] 1211 	jc	00102$
                                   1212 ;	quantum/dynamic_keymap.c:275: return -1;
      00860B 90 FF FF         [24] 1213 	mov	dptr,#0xffff
      00860E 22               [24] 1214 	ret
      00860F                       1215 00102$:
                                   1216 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00860F 12 8E F6         [24] 1217 	lcall	_ak820_outline_0063
                                   1218 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008612 8E 02            [24] 1219 	mov	ar2,r6
      008614 8F 03            [24] 1220 	mov	ar3,r7
      008616 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008619 12 8F 18         [24] 1222 	lcall	_ak820_outline_0091
      00861C 12 4E 60         [24] 1223 	lcall	_ak820_outline_0003
      00861F 90 05 87         [24] 1224 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008622 74 0A            [12] 1225 	mov	a,#0x0a
      008624 12 4E 60         [24] 1226 	lcall	_ak820_outline_0003
      008627 12 44 22         [24] 1227 	lcall	_ak820_outline_0033
      00862A C0 07            [24] 1228 	push	ar7
      00862C C0 06            [24] 1229 	push	ar6
      00862E 12 41 51         [24] 1230 	lcall	_ak820_eeprom_read_block_xdata
      008631 D0 06            [24] 1231 	pop	ar6
      008633 D0 07            [24] 1232 	pop	ar7
                                   1233 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008635 74 04            [12] 1234 	mov	a,#0x04
      008637 12 44 33         [24] 1235 	lcall	_ak820_outline_0043
      00863A 12 43 EF         [24] 1236 	lcall	_ak820_outline_0011
      00863D 12 44 11         [24] 1237 	lcall	_ak820_outline_0024
      008640 BA 20 13         [24] 1238 	cjne	r2,#0x20,00108$
      008643 BB 08 10         [24] 1239 	cjne	r3,#0x08,00108$
      008646 74 06            [12] 1240 	mov	a,#0x06
      008648 12 43 FE         [24] 1241 	lcall	_ak820_outline_0015
      00864B 12 44 11         [24] 1242 	lcall	_ak820_outline_0024
      00864E BA 01 05         [24] 1243 	cjne	r2,#0x01,00136$
      008651 BB 00 02         [24] 1244 	cjne	r3,#0x00,00136$
      008654 80 05            [24] 1245 	sjmp	00109$
      008656                       1246 00136$:
      008656                       1247 00108$:
      008656 75 32 00         [24] 1248 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008659 80 03            [24] 1249 	sjmp	00110$
      00865B                       1250 00109$:
      00865B 75 32 01         [24] 1251 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      00865E                       1252 00110$:
                                   1253 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      00865E 74 06            [12] 1254 	mov	a,#0x06
      008660 12 43 FE         [24] 1255 	lcall	_ak820_outline_0015
      008663 12 4E 8D         [24] 1256 	lcall	_ak820_outline_0098
      008666 12 43 EF         [24] 1257 	lcall	_ak820_outline_0011
      008669 F0               [24] 1258 	movx	@dptr,a
      00866A A3               [24] 1259 	inc	dptr
      00866B F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      00866C E5 32            [12] 1262 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      00866E 60 12            [24] 1263 	jz	00103$
      008670 12 43 D3         [24] 1264 	lcall	_ak820_outline_0002
      008673 C0 07            [24] 1265 	push	ar7
      008675 C0 06            [24] 1266 	push	ar6
      008677 12 35 57         [24] 1267 	lcall	_ak820_combo_valid
      00867A E5 82            [12] 1268 	mov	a, dpl
      00867C D0 06            [24] 1269 	pop	ar6
      00867E D0 07            [24] 1270 	pop	ar7
      008680 70 17            [24] 1271 	jnz	00104$
      008682                       1272 00103$:
      008682 7D 00            [12] 1273 	mov	r5,#0x00
      008684 90 0D BB         [24] 1274 	mov	dptr,#_memset_PARM_2
      008687 E4               [12] 1275 	clr	a
      008688 F0               [24] 1276 	movx	@dptr,a
      008689 90 0D BC         [24] 1277 	mov	dptr,#_memset_PARM_3
      00868C 74 0A            [12] 1278 	mov	a,#0x0a
      00868E 12 4E 60         [24] 1279 	lcall	_ak820_outline_0003
      008691 12 43 D3         [24] 1280 	lcall	_ak820_outline_0002
      008694 8D F0            [24] 1281 	mov	b, r5
      008696 12 BD B1         [24] 1282 	lcall	_memset
      008699                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:289: return 0;
      008699 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:290: }
      00869C 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_389'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_390'
                                   1294 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_393'
                                   1295 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_394'
                                   1296 ;------------------------------------------------------------
                                   1297 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1298 ;	-----------------------------------------
                                   1299 ;	 function dynamic_keymap_set_combo
                                   1300 ;	-----------------------------------------
      00869D                       1301 _dynamic_keymap_set_combo:
      00869D E5 82            [12] 1302 	mov	a,dpl
      00869F 90 0A E4         [24] 1303 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_389
      0086A2 F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0086A3 90 0A E1         [24] 1306 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0086A6 12 43 C5         [24] 1307 	lcall	_ak820_outline_0000
                                   1308 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0086A9 12 43 D3         [24] 1309 	lcall	_ak820_outline_0002
      0086AC C0 07            [24] 1310 	push	ar7
      0086AE C0 06            [24] 1311 	push	ar6
      0086B0 12 35 57         [24] 1312 	lcall	_ak820_combo_valid
      0086B3 E5 82            [12] 1313 	mov	a, dpl
      0086B5 D0 06            [24] 1314 	pop	ar6
      0086B7 D0 07            [24] 1315 	pop	ar7
      0086B9 60 07            [24] 1316 	jz	00101$
      0086BB 12 3E 7C         [24] 1317 	lcall	_ak820_nvm_ok
      0086BE E5 82            [12] 1318 	mov	a, dpl
      0086C0 70 04            [24] 1319 	jnz	00102$
      0086C2                       1320 00101$:
      0086C2 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      0086C5 22               [24] 1322 	ret
      0086C6                       1323 00102$:
                                   1324 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      0086C6 90 0A E4         [24] 1325 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_389
      0086C9 E0               [24] 1326 	movx	a,@dptr
      0086CA FD               [12] 1327 	mov	r5,a
      0086CB BD 08 00         [24] 1328 	cjne	r5,#0x08,00133$
      0086CE                       1329 00133$:
      0086CE 40 04            [24] 1330 	jc	00105$
                                   1331 ;	quantum/dynamic_keymap.c:302: return -1;
      0086D0 90 FF FF         [24] 1332 	mov	dptr,#0xffff
      0086D3 22               [24] 1333 	ret
      0086D4                       1334 00105$:
                                   1335 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0086D4 12 8E F6         [24] 1336 	lcall	_ak820_outline_0063
                                   1337 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      0086D7 C0 07            [24] 1338 	push	ar7
      0086D9 C0 06            [24] 1339 	push	ar6
      0086DB C0 05            [24] 1340 	push	ar5
      0086DD C0 04            [24] 1341 	push	ar4
      0086DF 12 76 60         [24] 1342 	lcall	_clear_keyboard
      0086E2 D0 04            [24] 1343 	pop	ar4
      0086E4 D0 05            [24] 1344 	pop	ar5
      0086E6 D0 06            [24] 1345 	pop	ar6
      0086E8 D0 07            [24] 1346 	pop	ar7
                                   1347 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      0086EA 90 0D B3         [24] 1348 	mov	dptr,#___memcpy_PARM_2
      0086ED EE               [12] 1349 	mov	a,r6
      0086EE F0               [24] 1350 	movx	@dptr,a
      0086EF EF               [12] 1351 	mov	a,r7
      0086F0 A3               [24] 1352 	inc	dptr
      0086F1 12 4E 60         [24] 1353 	lcall	_ak820_outline_0003
      0086F4 90 0D B6         [24] 1354 	mov	dptr,#___memcpy_PARM_3
      0086F7 74 0A            [12] 1355 	mov	a,#0x0a
      0086F9 12 4E 60         [24] 1356 	lcall	_ak820_outline_0003
      0086FC 90 0A E5         [24] 1357 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_394
      0086FF F5 F0            [12] 1358 	mov	b,a
      008701 C0 05            [24] 1359 	push	ar5
      008703 C0 04            [24] 1360 	push	ar4
      008705 12 BD 3B         [24] 1361 	lcall	___memcpy
      008708 D0 04            [24] 1362 	pop	ar4
      00870A D0 05            [24] 1363 	pop	ar5
                                   1364 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      00870C 90 0A E9         [24] 1365 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_394 + 0x0004)
      00870F 74 20            [12] 1366 	mov	a,#0x20
      008711 F0               [24] 1367 	movx	@dptr,a
      008712 74 08            [12] 1368 	mov	a,#0x08
      008714 A3               [24] 1369 	inc	dptr
      008715 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008716 90 0A EB         [24] 1372 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_394 + 0x0006)
      008719 74 01            [12] 1373 	mov	a,#0x01
      00871B 12 4E 60         [24] 1374 	lcall	_ak820_outline_0003
                                   1375 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      00871E 90 05 8D         [24] 1376 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008721 12 8F 18         [24] 1377 	lcall	_ak820_outline_0091
      008724 12 4E 60         [24] 1378 	lcall	_ak820_outline_0003
      008727 90 05 90         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00872A 74 0A            [12] 1380 	mov	a,#0x0a
      00872C 12 4E 60         [24] 1381 	lcall	_ak820_outline_0003
      00872F 90 0A E5         [24] 1382 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_394
      008732 12 41 DD         [24] 1383 	lcall	_ak820_eeprom_write_block_xdata
                                   1384 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008735 12 3E 92         [24] 1385 	lcall	_ak820_nvm_flush
                                   1386 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008738 12 3E 7C         [24] 1387 	lcall	_ak820_nvm_ok
      00873B E5 82            [12] 1388 	mov	a, dpl
      00873D 70 04            [24] 1389 	jnz	00107$
      00873F 90 FF FF         [24] 1390 	mov	dptr,#0xffff
      008742 22               [24] 1391 	ret
      008743                       1392 00107$:
                                   1393 ;	quantum/dynamic_keymap.c:320: return 0;
      008743 90 00 00         [24] 1394 	mov	dptr,#0x0000
                                   1395 ;	quantum/dynamic_keymap.c:321: }
      008746 22               [24] 1396 	ret
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1399 ;------------------------------------------------------------
                                   1400 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_397'
                                   1401 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_398'
                                   1402 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_400'
                                   1403 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_402'
                                   1404 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_404'
                                   1405 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_406'
                                   1406 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_407'
                                   1407 ;------------------------------------------------------------
                                   1408 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1409 ;	-----------------------------------------
                                   1410 ;	 function dynamic_keymap_reset
                                   1411 ;	-----------------------------------------
      008747                       1412 _dynamic_keymap_reset:
                                   1413 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008747 90 0E 32         [24] 1414 	mov	dptr,#_vial_unlocked
      00874A E0               [24] 1415 	movx	a,@dptr
      00874B 90 0A EF         [24] 1416 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_397
      00874E F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      00874F 90 0E 32         [24] 1419 	mov	dptr,#_vial_unlocked
      008752 74 01            [12] 1420 	mov	a,#0x01
      008754 F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008755 7F 00            [12] 1423 	mov	r7,#0x00
      008757                       1424 00116$:
      008757 BF 06 00         [24] 1425 	cjne	r7,#0x06,00198$
      00875A                       1426 00198$:
      00875A 40 03            [24] 1427 	jc	00199$
      00875C 02 88 0A         [24] 1428 	ljmp	00104$
      00875F                       1429 00199$:
                                   1430 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      00875F 7E 00            [12] 1431 	mov	r6,#0x00
      008761                       1432 00110$:
      008761 BE 10 00         [24] 1433 	cjne	r6,#0x10,00200$
      008764                       1434 00200$:
      008764 50 4D            [24] 1435 	jnc	00102$
                                   1436 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008766 7D 00            [12] 1437 	mov	r5,#0x00
      008768                       1438 00107$:
      008768 BD 08 00         [24] 1439 	cjne	r5,#0x08,00202$
      00876B                       1440 00202$:
      00876B 50 43            [24] 1441 	jnc	00111$
                                   1442 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      00876D 90 0B A1         [24] 1443 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008770 EE               [12] 1444 	mov	a,r6
      008771 F0               [24] 1445 	movx	@dptr,a
      008772 90 0B A2         [24] 1446 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008775 ED               [12] 1447 	mov	a,r5
      008776 F0               [24] 1448 	movx	@dptr,a
      008777 8F 82            [24] 1449 	mov	dpl, r7
      008779 C0 07            [24] 1450 	push	ar7
      00877B C0 06            [24] 1451 	push	ar6
      00877D C0 05            [24] 1452 	push	ar5
      00877F 12 98 C4         [24] 1453 	lcall	_keycode_at_keymap_location_raw
      008782 AB 82            [24] 1454 	mov	r3, dpl
      008784 AC 83            [24] 1455 	mov	r4, dph
      008786 D0 05            [24] 1456 	pop	ar5
      008788 D0 06            [24] 1457 	pop	ar6
      00878A D0 07            [24] 1458 	pop	ar7
      00878C 90 0A CE         [24] 1459 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00878F EE               [12] 1460 	mov	a,r6
      008790 F0               [24] 1461 	movx	@dptr,a
      008791 90 0A CF         [24] 1462 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008794 ED               [12] 1463 	mov	a,r5
      008795 F0               [24] 1464 	movx	@dptr,a
      008796 90 0A D0         [24] 1465 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008799 12 44 50         [24] 1466 	lcall	_ak820_outline_0060
      00879C 8F 82            [24] 1467 	mov	dpl, r7
      00879E C0 07            [24] 1468 	push	ar7
      0087A0 C0 06            [24] 1469 	push	ar6
      0087A2 C0 05            [24] 1470 	push	ar5
      0087A4 12 84 A6         [24] 1471 	lcall	_dynamic_keymap_set_keycode
      0087A7 D0 05            [24] 1472 	pop	ar5
      0087A9 D0 06            [24] 1473 	pop	ar6
      0087AB D0 07            [24] 1474 	pop	ar7
                                   1475 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0087AD 0D               [12] 1476 	inc	r5
      0087AE 80 B8            [24] 1477 	sjmp	00107$
      0087B0                       1478 00111$:
                                   1479 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0087B0 0E               [12] 1480 	inc	r6
      0087B1 80 AE            [24] 1481 	sjmp	00110$
      0087B3                       1482 00102$:
                                   1483 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0087B3 7E 00            [12] 1484 	mov	r6,#0x00
      0087B5                       1485 00113$:
      0087B5 BE 01 00         [24] 1486 	cjne	r6,#0x01,00204$
      0087B8                       1487 00204$:
      0087B8 50 4C            [24] 1488 	jnc	00117$
                                   1489 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0087BA 12 8F 44         [24] 1490 	lcall	_ak820_outline_0141
      0087BD 04               [12] 1491 	inc	a
      0087BE F0               [24] 1492 	movx	@dptr,a
      0087BF 8F 82            [24] 1493 	mov	dpl, r7
      0087C1 C0 07            [24] 1494 	push	ar7
      0087C3 12 99 0E         [24] 1495 	lcall	_keycode_at_encodermap_location_raw
      0087C6 12 44 83         [24] 1496 	lcall	_ak820_outline_0132
      0087C9 D0 07            [24] 1497 	pop	ar7
      0087CB 12 8F 3B         [24] 1498 	lcall	_ak820_outline_0139
      0087CE 04               [12] 1499 	inc	a
      0087CF F0               [24] 1500 	movx	@dptr,a
      0087D0 90 0A DA         [24] 1501 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0087D3 12 44 0B         [24] 1502 	lcall	_ak820_outline_0023
      0087D6 8F 82            [24] 1503 	mov	dpl, r7
      0087D8 C0 07            [24] 1504 	push	ar7
      0087DA 12 85 88         [24] 1505 	lcall	_dynamic_keymap_set_encoder
      0087DD D0 07            [24] 1506 	pop	ar7
                                   1507 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0087DF 12 8F 44         [24] 1508 	lcall	_ak820_outline_0141
      0087E2 F0               [24] 1509 	movx	@dptr,a
      0087E3 8F 82            [24] 1510 	mov	dpl, r7
      0087E5 C0 07            [24] 1511 	push	ar7
      0087E7 12 99 0E         [24] 1512 	lcall	_keycode_at_encodermap_location_raw
      0087EA 12 44 83         [24] 1513 	lcall	_ak820_outline_0132
      0087ED D0 07            [24] 1514 	pop	ar7
      0087EF 12 8F 3B         [24] 1515 	lcall	_ak820_outline_0139
      0087F2 F0               [24] 1516 	movx	@dptr,a
      0087F3 90 0A DA         [24] 1517 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0087F6 12 44 0B         [24] 1518 	lcall	_ak820_outline_0023
      0087F9 8F 82            [24] 1519 	mov	dpl, r7
      0087FB C0 07            [24] 1520 	push	ar7
      0087FD 12 85 88         [24] 1521 	lcall	_dynamic_keymap_set_encoder
      008800 D0 07            [24] 1522 	pop	ar7
                                   1523 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008802 7E 01            [12] 1524 	mov	r6,#0x01
      008804 80 AF            [24] 1525 	sjmp	00113$
      008806                       1526 00117$:
                                   1527 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008806 0F               [12] 1528 	inc	r7
      008807 02 87 57         [24] 1529 	ljmp	00116$
      00880A                       1530 00104$:
                                   1531 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      00880A 90 0A F0         [24] 1532 	mov	dptr,#_dynamic_keymap_reset_combo_10001_406
      00880D 12 4E 8D         [24] 1533 	lcall	_ak820_outline_0098
      008810 90 0A F2         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0002)
      008813 F0               [24] 1535 	movx	@dptr,a
      008814 A3               [24] 1536 	inc	dptr
      008815 F0               [24] 1537 	movx	@dptr,a
      008816 90 0A F4         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0004)
      008819 F0               [24] 1539 	movx	@dptr,a
      00881A A3               [24] 1540 	inc	dptr
      00881B F0               [24] 1541 	movx	@dptr,a
      00881C 90 0A F6         [24] 1542 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0006)
      00881F F0               [24] 1543 	movx	@dptr,a
      008820 A3               [24] 1544 	inc	dptr
      008821 F0               [24] 1545 	movx	@dptr,a
      008822 90 0A F8         [24] 1546 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0008)
      008825 F0               [24] 1547 	movx	@dptr,a
      008826 A3               [24] 1548 	inc	dptr
      008827 F0               [24] 1549 	movx	@dptr,a
                                   1550 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008828 FF               [12] 1551 	mov	r7,a
      008829                       1552 00119$:
      008829 BF 08 00         [24] 1553 	cjne	r7,#0x08,00206$
      00882C                       1554 00206$:
      00882C 50 1A            [24] 1555 	jnc	00105$
                                   1556 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      00882E 8F 06            [24] 1557 	mov	ar6,r7
      008830 90 0A E1         [24] 1558 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008833 74 F0            [12] 1559 	mov	a,#_dynamic_keymap_reset_combo_10001_406
      008835 F0               [24] 1560 	movx	@dptr,a
      008836 74 0A            [12] 1561 	mov	a,#(_dynamic_keymap_reset_combo_10001_406 >> 8)
      008838 A3               [24] 1562 	inc	dptr
      008839 12 4E 60         [24] 1563 	lcall	_ak820_outline_0003
      00883C 8E 82            [24] 1564 	mov	dpl, r6
      00883E C0 07            [24] 1565 	push	ar7
      008840 12 86 9D         [24] 1566 	lcall	_dynamic_keymap_set_combo
      008843 D0 07            [24] 1567 	pop	ar7
                                   1568 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008845 0F               [12] 1569 	inc	r7
      008846 80 E1            [24] 1570 	sjmp	00119$
      008848                       1571 00105$:
                                   1572 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008848 90 0A EF         [24] 1573 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_397
      00884B E0               [24] 1574 	movx	a,@dptr
      00884C 90 0E 32         [24] 1575 	mov	dptr,#_vial_unlocked
      00884F F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/dynamic_keymap.c:405: }
      008850 22               [24] 1578 	ret
                                   1579 ;------------------------------------------------------------
                                   1580 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1581 ;------------------------------------------------------------
                                   1582 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1583 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1584 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1585 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1586 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1587 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_408'
                                   1588 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_409'
                                   1589 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_409'
                                   1590 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_412'
                                   1591 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_414'
                                   1592 ;------------------------------------------------------------
                                   1593 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1594 ;	-----------------------------------------
                                   1595 ;	 function ak820_dynamic_read_buffer
                                   1596 ;	-----------------------------------------
      008851                       1597 _ak820_dynamic_read_buffer:
      008851 12 43 EA         [24] 1598 	lcall	_ak820_outline_0010
      008854 90 0B 03         [24] 1599 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_408
      008857 12 43 E5         [24] 1600 	lcall	_ak820_outline_0007
                                   1601 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      00885A 90 0B 00         [24] 1602 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00885D 12 43 C5         [24] 1603 	lcall	_ak820_outline_0000
                                   1604 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008860 90 0B 05         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      008863 E4               [12] 1606 	clr	a
      008864 F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008865 90 0A FE         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008868 12 43 DF         [24] 1610 	lcall	_ak820_outline_0006
      00886B 8C 02            [24] 1611 	mov	ar2,r4
      00886D 8D 03            [24] 1612 	mov	ar3,r5
      00886F C3               [12] 1613 	clr	c
      008870 74 1C            [12] 1614 	mov	a,#0x1c
      008872 9A               [12] 1615 	subb	a,r2
      008873 E4               [12] 1616 	clr	a
      008874 9B               [12] 1617 	subb	a,r3
      008875 50 01            [24] 1618 	jnc	00102$
                                   1619 ;	free result
      008877 22               [24] 1620 	ret
      008878                       1621 00102$:
                                   1622 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008878 90 0A FC         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00887B 12 44 11         [24] 1624 	lcall	_ak820_outline_0024
      00887E 90 0A FA         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008881 12 44 5C         [24] 1626 	lcall	_ak820_outline_0072
      008884 C3               [12] 1627 	clr	c
      008885 EA               [12] 1628 	mov	a,r2
      008886 98               [12] 1629 	subb	a,r0
      008887 EB               [12] 1630 	mov	a,r3
      008888 99               [12] 1631 	subb	a,r1
      008889 50 17            [24] 1632 	jnc	00104$
                                   1633 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      00888B E8               [12] 1634 	mov	a,r0
      00888C C3               [12] 1635 	clr	c
      00888D 9A               [12] 1636 	subb	a,r2
      00888E F8               [12] 1637 	mov	r0,a
      00888F E9               [12] 1638 	mov	a,r1
      008890 9B               [12] 1639 	subb	a,r3
      008891 F9               [12] 1640 	mov	r1,a
                                   1641 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008892 C3               [12] 1642 	clr	c
      008893 E8               [12] 1643 	mov	a,r0
      008894 9C               [12] 1644 	subb	a,r4
      008895 E9               [12] 1645 	mov	a,r1
      008896 9D               [12] 1646 	subb	a,r5
      008897 40 04            [24] 1647 	jc	00114$
      008899 8C 00            [24] 1648 	mov	ar0,r4
      00889B 8D 01            [24] 1649 	mov	ar1,r5
      00889D                       1650 00114$:
      00889D 90 0B 05         [24] 1651 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      0088A0 E8               [12] 1652 	mov	a,r0
      0088A1 F0               [24] 1653 	movx	@dptr,a
      0088A2                       1654 00104$:
                                   1655 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0088A2 90 0B 05         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      0088A5 E0               [24] 1657 	movx	a,@dptr
      0088A6 F5 33            [12] 1658 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0088A8 E0               [24] 1659 	movx	a,@dptr
      0088A9 60 43            [24] 1660 	jz	00106$
      0088AB C0 04            [24] 1661 	push	ar4
      0088AD C0 05            [24] 1662 	push	ar5
      0088AF 8E 00            [24] 1663 	mov	ar0,r6
      0088B1 8F 05            [24] 1664 	mov	ar5,r7
      0088B3 90 0B 03         [24] 1665 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_408
      0088B6 E0               [24] 1666 	movx	a,@dptr
      0088B7 F9               [12] 1667 	mov	r1,a
      0088B8 A3               [24] 1668 	inc	dptr
      0088B9 E0               [24] 1669 	movx	a,@dptr
      0088BA FC               [12] 1670 	mov	r4,a
      0088BB EA               [12] 1671 	mov	a,r2
      0088BC 29               [12] 1672 	add	a, r1
      0088BD FA               [12] 1673 	mov	r2,a
      0088BE EB               [12] 1674 	mov	a,r3
      0088BF 3C               [12] 1675 	addc	a, r4
      0088C0 FB               [12] 1676 	mov	r3,a
      0088C1 90 05 84         [24] 1677 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0088C4 EA               [12] 1678 	mov	a,r2
      0088C5 F0               [24] 1679 	movx	@dptr,a
      0088C6 EB               [12] 1680 	mov	a,r3
      0088C7 A3               [24] 1681 	inc	dptr
      0088C8 12 4E 60         [24] 1682 	lcall	_ak820_outline_0003
      0088CB 90 05 87         [24] 1683 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0088CE E5 33            [12] 1684 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0088D0 12 4E 60         [24] 1685 	lcall	_ak820_outline_0003
      0088D3 88 82            [24] 1686 	mov	dpl, r0
      0088D5 8D 83            [24] 1687 	mov	dph, r5
      0088D7 C0 07            [24] 1688 	push	ar7
      0088D9 C0 06            [24] 1689 	push	ar6
      0088DB C0 05            [24] 1690 	push	ar5
      0088DD C0 04            [24] 1691 	push	ar4
      0088DF 12 41 51         [24] 1692 	lcall	_ak820_eeprom_read_block_xdata
      0088E2 D0 04            [24] 1693 	pop	ar4
      0088E4 D0 05            [24] 1694 	pop	ar5
      0088E6 D0 06            [24] 1695 	pop	ar6
      0088E8 D0 07            [24] 1696 	pop	ar7
                                   1697 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0088EA D0 05            [24] 1698 	pop	ar5
      0088EC D0 04            [24] 1699 	pop	ar4
                                   1700 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0088EE                       1701 00106$:
                                   1702 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0088EE 90 0B 05         [24] 1703 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      0088F1 E0               [24] 1704 	movx	a,@dptr
      0088F2 FB               [12] 1705 	mov	r3,a
      0088F3                       1706 00109$:
      0088F3 8B 01            [24] 1707 	mov	ar1,r3
      0088F5 7A 00            [12] 1708 	mov	r2,#0x00
      0088F7 C3               [12] 1709 	clr	c
      0088F8 E9               [12] 1710 	mov	a,r1
      0088F9 9C               [12] 1711 	subb	a,r4
      0088FA EA               [12] 1712 	mov	a,r2
      0088FB 9D               [12] 1713 	subb	a,r5
      0088FC 50 09            [24] 1714 	jnc	00111$
      0088FE EB               [12] 1715 	mov	a,r3
      0088FF 12 43 FE         [24] 1716 	lcall	_ak820_outline_0015
      008902 E4               [12] 1717 	clr	a
      008903 F0               [24] 1718 	movx	@dptr,a
      008904 0B               [12] 1719 	inc	r3
      008905 80 EC            [24] 1720 	sjmp	00109$
      008907                       1721 00111$:
                                   1722 ;	quantum/dynamic_keymap.c:420: }
      008907 22               [24] 1723 	ret
                                   1724 ;------------------------------------------------------------
                                   1725 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1726 ;------------------------------------------------------------
                                   1727 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1728 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1729 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_415'
                                   1730 ;------------------------------------------------------------
                                   1731 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1732 ;	-----------------------------------------
                                   1733 ;	 function dynamic_keymap_get_buffer
                                   1734 ;	-----------------------------------------
      008908                       1735 _dynamic_keymap_get_buffer:
      008908 12 43 EA         [24] 1736 	lcall	_ak820_outline_0010
      00890B 90 0B 0B         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_415
      00890E 12 43 E5         [24] 1738 	lcall	_ak820_outline_0007
                                   1739 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008911 90 0B 0B         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_415
      008914 12 43 C5         [24] 1741 	lcall	_ak820_outline_0000
      008917 90 0B 06         [24] 1742 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00891A 12 43 DF         [24] 1743 	lcall	_ak820_outline_0006
      00891D 90 0B 08         [24] 1744 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008920 E0               [24] 1745 	movx	a,@dptr
      008921 F9               [12] 1746 	mov	r1,a
      008922 A3               [24] 1747 	inc	dptr
      008923 12 44 11         [24] 1748 	lcall	_ak820_outline_0024
      008926 90 0A FA         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008929 E4               [12] 1750 	clr	a
      00892A F0               [24] 1751 	movx	@dptr,a
      00892B 74 06            [12] 1752 	mov	a,#0x06
      00892D A3               [24] 1753 	inc	dptr
      00892E F0               [24] 1754 	movx	@dptr,a
      00892F 90 0A FC         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008932 EE               [12] 1756 	mov	a,r6
      008933 12 43 E5         [24] 1757 	lcall	_ak820_outline_0007
      008936 90 0A FE         [24] 1758 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008939 12 44 0B         [24] 1759 	lcall	_ak820_outline_0023
      00893C 90 0B 00         [24] 1760 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00893F E9               [12] 1761 	mov	a,r1
      008940 12 4E 7C         [24] 1762 	lcall	_ak820_outline_0056
      008943 90 00 40         [24] 1763 	mov	dptr,#0x0040
                                   1764 ;	quantum/dynamic_keymap.c:448: }
      008946 02 88 51         [24] 1765 	ljmp	_ak820_dynamic_read_buffer
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1768 ;------------------------------------------------------------
                                   1769 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1770 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1771 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1772 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1773 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1774 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_417'
                                   1775 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_418'
                                   1776 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_418'
                                   1777 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_418'
                                   1778 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_421'
                                   1779 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_424'
                                   1780 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_424'
                                   1781 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_426'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
                                   1783 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_431'
                                   1784 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function dynamic_keymap_set_buffer
                                   1789 ;	-----------------------------------------
      008949                       1790 _dynamic_keymap_set_buffer:
      008949 12 43 EA         [24] 1791 	lcall	_ak820_outline_0010
      00894C 90 0B 12         [24] 1792 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      00894F 12 43 E5         [24] 1793 	lcall	_ak820_outline_0007
                                   1794 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008952 90 0B 12         [24] 1795 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      008955 12 43 C5         [24] 1796 	lcall	_ak820_outline_0000
      008958 12 44 62         [24] 1797 	lcall	_ak820_outline_0073
      00895B 74 40            [12] 1798 	mov	a,#0x40
      00895D 2C               [12] 1799 	add	a, r4
      00895E FA               [12] 1800 	mov	r2,a
      00895F E4               [12] 1801 	clr	a
      008960 3D               [12] 1802 	addc	a, r5
      008961 FB               [12] 1803 	mov	r3,a
                                   1804 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008962 90 0B 0F         [24] 1805 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008965 12 44 5C         [24] 1806 	lcall	_ak820_outline_0072
                                   1807 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008968 90 0B 0D         [24] 1808 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00896B E0               [24] 1809 	movx	a,@dptr
      00896C F5 34            [12] 1810 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      00896E A3               [24] 1811 	inc	dptr
      00896F E0               [24] 1812 	movx	a,@dptr
      008970 F5 35            [12] 1813 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008972 E5 34            [12] 1814 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008974 45 35            [12] 1815 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008976 70 01            [24] 1816 	jnz	00102$
      008978 22               [24] 1817 	ret
      008979                       1818 00102$:
                                   1819 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008979 85 34 36         [24] 1820 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      00897C 85 35 37         [24] 1821 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00897F C3               [12] 1822 	clr	c
      008980 74 1C            [12] 1823 	mov	a,#0x1c
      008982 95 36            [12] 1824 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008984 E4               [12] 1825 	clr	a
      008985 95 37            [12] 1826 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008987 50 01            [24] 1827 	jnc	00104$
                                   1828 ;	free result
      008989 22               [24] 1829 	ret
      00898A                       1830 00104$:
                                   1831 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      00898A 85 34 38         [24] 1832 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1833 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      00898D 74 FA            [12] 1834 	mov	a,#0x100 - 0x06
      00898F 2F               [12] 1835 	add	a,r7
      008990 40 11            [24] 1836 	jc	00105$
      008992 E4               [12] 1837 	clr	a
      008993 C3               [12] 1838 	clr	c
      008994 9E               [12] 1839 	subb	a,r6
      008995 FE               [12] 1840 	mov	r6,a
      008996 74 06            [12] 1841 	mov	a,#0x06
      008998 9F               [12] 1842 	subb	a,r7
      008999 FF               [12] 1843 	mov	r7,a
      00899A C3               [12] 1844 	clr	c
      00899B EE               [12] 1845 	mov	a,r6
      00899C 95 34            [12] 1846 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00899E EF               [12] 1847 	mov	a,r7
      00899F 95 35            [12] 1848 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089A1 50 01            [24] 1849 	jnc	00106$
      0089A3                       1850 00105$:
                                   1851 ;	quantum/dynamic_keymap.c:466: return;
      0089A3 22               [24] 1852 	ret
      0089A4                       1853 00106$:
                                   1854 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      0089A4 90 0E 32         [24] 1855 	mov	dptr,#_vial_unlocked
      0089A7 E0               [24] 1856 	movx	a,@dptr
      0089A8 60 03            [24] 1857 	jz	00207$
      0089AA 02 8A BD         [24] 1858 	ljmp	00120$
      0089AD                       1859 00207$:
                                   1860 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      0089AD 90 0B 14         [24] 1861 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      0089B0 E4               [12] 1862 	clr	a
      0089B1 F0               [24] 1863 	movx	@dptr,a
                                   1864 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      0089B2 90 0B 15         [24] 1865 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      0089B5 E5 38            [12] 1866 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0089B7 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      0089B8 EC               [12] 1869 	mov	a,r4
      0089B9 30 E0 33         [24] 1870 	jnb	acc.0,00111$
                                   1871 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      0089BC EA               [12] 1872 	mov	a,r2
      0089BD 24 FF            [12] 1873 	add	a,#0xff
      0089BF FE               [12] 1874 	mov	r6,a
      0089C0 EB               [12] 1875 	mov	a,r3
      0089C1 34 FF            [12] 1876 	addc	a,#0xff
      0089C3 FF               [12] 1877 	mov	r7,a
      0089C4 7D 00            [12] 1878 	mov	r5,#0x00
      0089C6 12 43 D3         [24] 1879 	lcall	_ak820_outline_0002
      0089C9 8D F0            [24] 1880 	mov	b, r5
      0089CB 12 41 13         [24] 1881 	lcall	_eeprom_read_byte
      0089CE AE 82            [24] 1882 	mov	r6,dpl
      0089D0 7F 00            [12] 1883 	mov	r7,#0x00
      0089D2 12 81 5F         [24] 1884 	lcall	_ak820_outline_0100
      0089D5 E0               [24] 1885 	movx	a,@dptr
      0089D6 7C 00            [12] 1886 	mov	r4,#0x00
      0089D8 42 07            [12] 1887 	orl	ar7,a
      0089DA EC               [12] 1888 	mov	a,r4
      0089DB 42 06            [12] 1889 	orl	ar6,a
                                   1890 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      0089DD BF 00 09         [24] 1891 	cjne	r7,#0x00,00109$
      0089E0 BE 7C 06         [24] 1892 	cjne	r6,#0x7c,00109$
                                   1893 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      0089E3 12 81 5F         [24] 1894 	lcall	_ak820_outline_0100
      0089E6 74 FF            [12] 1895 	mov	a,#0xff
      0089E8 F0               [24] 1896 	movx	@dptr,a
      0089E9                       1897 00109$:
                                   1898 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      0089E9 90 0B 14         [24] 1899 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      0089EC 74 01            [12] 1900 	mov	a,#0x01
      0089EE F0               [24] 1901 	movx	@dptr,a
      0089EF                       1902 00111$:
                                   1903 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      0089EF 90 0B 12         [24] 1904 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      0089F2 12 43 C5         [24] 1905 	lcall	_ak820_outline_0000
      0089F5 E5 34            [12] 1906 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0089F7 2E               [12] 1907 	add	a, r6
      0089F8 FE               [12] 1908 	mov	r6,a
      0089F9 E5 35            [12] 1909 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089FB 3F               [12] 1910 	addc	a, r7
      0089FC EE               [12] 1911 	mov	a,r6
      0089FD 30 E0 5C         [24] 1912 	jnb	acc.0,00115$
                                   1913 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008A00 AE 38            [24] 1914 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008A02 7F 00            [12] 1915 	mov	r7,#0x00
      008A04 EE               [12] 1916 	mov	a,r6
      008A05 24 FF            [12] 1917 	add	a,#0xff
      008A07 FC               [12] 1918 	mov	r4,a
      008A08 EF               [12] 1919 	mov	a,r7
      008A09 34 FF            [12] 1920 	addc	a,#0xff
      008A0B FD               [12] 1921 	mov	r5,a
      008A0C EC               [12] 1922 	mov	a,r4
      008A0D 28               [12] 1923 	add	a, r0
      008A0E F5 82            [12] 1924 	mov	dpl,a
      008A10 ED               [12] 1925 	mov	a,r5
      008A11 39               [12] 1926 	addc	a, r1
      008A12 F5 83            [12] 1927 	mov	dph,a
      008A14 E0               [24] 1928 	movx	a,@dptr
      008A15 FC               [12] 1929 	mov	r4,a
      008A16 7D 00            [12] 1930 	mov	r5,#0x00
      008A18 E5 38            [12] 1931 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A1A 2A               [12] 1932 	add	a, r2
      008A1B FA               [12] 1933 	mov	r2,a
      008A1C E4               [12] 1934 	clr	a
      008A1D 3B               [12] 1935 	addc	a, r3
      008A1E FB               [12] 1936 	mov	r3,a
      008A1F C0 00            [24] 1937 	push	ar0
      008A21 C0 01            [24] 1938 	push	ar1
      008A23 8B 01            [24] 1939 	mov	ar1,r3
      008A25 7B 00            [12] 1940 	mov	r3,#0x00
      008A27 8A 82            [24] 1941 	mov	dpl, r2
      008A29 89 83            [24] 1942 	mov	dph, r1
      008A2B 8B F0            [24] 1943 	mov	b, r3
      008A2D 12 41 13         [24] 1944 	lcall	_eeprom_read_byte
      008A30 AB 82            [24] 1945 	mov	r3, dpl
      008A32 7A 00            [12] 1946 	mov	r2,#0x00
      008A34 EB               [12] 1947 	mov	a,r3
      008A35 42 05            [12] 1948 	orl	ar5,a
      008A37 EA               [12] 1949 	mov	a,r2
      008A38 42 04            [12] 1950 	orl	ar4,a
                                   1951 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008A3A BD 00 05         [24] 1952 	cjne	r5,#0x00,00212$
      008A3D BC 7C 02         [24] 1953 	cjne	r4,#0x7c,00212$
      008A40 80 06            [24] 1954 	sjmp	00213$
      008A42                       1955 00212$:
      008A42 D0 01            [24] 1956 	pop	ar1
      008A44 D0 00            [24] 1957 	pop	ar0
      008A46 80 0D            [24] 1958 	sjmp	00113$
      008A48                       1959 00213$:
      008A48 D0 01            [24] 1960 	pop	ar1
      008A4A D0 00            [24] 1961 	pop	ar0
                                   1962 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008A4C 1E               [12] 1963 	dec	r6
      008A4D BE FF 01         [24] 1964 	cjne	r6,#0xff,00214$
      008A50 1F               [12] 1965 	dec	r7
      008A51                       1966 00214$:
      008A51 EE               [12] 1967 	mov	a,r6
      008A52 12 8F 1D         [24] 1968 	lcall	_ak820_outline_0095
      008A55                       1969 00113$:
                                   1970 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008A55 E5 38            [12] 1971 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A57 14               [12] 1972 	dec	a
      008A58 90 0B 15         [24] 1973 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      008A5B F0               [24] 1974 	movx	@dptr,a
      008A5C                       1975 00115$:
                                   1976 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008A5C 90 0B 14         [24] 1977 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      008A5F E0               [24] 1978 	movx	a,@dptr
      008A60 90 0B 16         [24] 1979 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008A63 F0               [24] 1980 	movx	@dptr,a
      008A64                       1981 00122$:
      008A64 90 0B 16         [24] 1982 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008A67 E0               [24] 1983 	movx	a,@dptr
      008A68 FF               [12] 1984 	mov	r7,a
      008A69 90 0B 15         [24] 1985 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      008A6C E0               [24] 1986 	movx	a,@dptr
      008A6D FE               [12] 1987 	mov	r6,a
      008A6E C3               [12] 1988 	clr	c
      008A6F EF               [12] 1989 	mov	a,r7
      008A70 9E               [12] 1990 	subb	a,r6
      008A71 50 4A            [24] 1991 	jnc	00120$
                                   1992 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008A73 EF               [12] 1993 	mov	a,r7
      008A74 28               [12] 1994 	add	a, r0
      008A75 FD               [12] 1995 	mov	r5,a
      008A76 E4               [12] 1996 	clr	a
      008A77 39               [12] 1997 	addc	a, r1
      008A78 FE               [12] 1998 	mov	r6,a
      008A79 12 43 F4         [24] 1999 	lcall	_ak820_outline_0012
      008A7C E0               [24] 2000 	movx	a,@dptr
      008A7D FC               [12] 2001 	mov	r4,a
      008A7E 7B 00            [12] 2002 	mov	r3,#0x00
      008A80 8C 35            [24] 2003 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008A82 8B 34            [24] 2004 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008A84 8F 02            [24] 2005 	mov	ar2,r7
      008A86 7F 00            [12] 2006 	mov	r7,#0x00
      008A88 74 01            [12] 2007 	mov	a,#0x01
      008A8A 2A               [12] 2008 	add	a, r2
      008A8B FB               [12] 2009 	mov	r3,a
      008A8C E4               [12] 2010 	clr	a
      008A8D 3F               [12] 2011 	addc	a, r7
      008A8E FC               [12] 2012 	mov	r4,a
      008A8F EB               [12] 2013 	mov	a,r3
      008A90 28               [12] 2014 	add	a, r0
      008A91 F5 82            [12] 2015 	mov	dpl,a
      008A93 EC               [12] 2016 	mov	a,r4
      008A94 39               [12] 2017 	addc	a, r1
      008A95 F5 83            [12] 2018 	mov	dph,a
      008A97 E0               [24] 2019 	movx	a,@dptr
      008A98 FC               [12] 2020 	mov	r4,a
      008A99 7B 00            [12] 2021 	mov	r3,#0x00
      008A9B E5 35            [12] 2022 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A9D 42 03            [12] 2023 	orl	ar3,a
                                   2024 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008A9F BC 00 12         [24] 2025 	cjne	r4,#0x00,00123$
      008AA2 BB 7C 0F         [24] 2026 	cjne	r3,#0x7c,00123$
                                   2027 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008AA5 12 43 F4         [24] 2028 	lcall	_ak820_outline_0012
      008AA8 74 FF            [12] 2029 	mov	a,#0xff
      008AAA F0               [24] 2030 	movx	@dptr,a
                                   2031 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008AAB 0A               [12] 2032 	inc	r2
      008AAC BA 00 01         [24] 2033 	cjne	r2,#0x00,00218$
      008AAF 0F               [12] 2034 	inc	r7
      008AB0                       2035 00218$:
      008AB0 EA               [12] 2036 	mov	a,r2
      008AB1 12 8F 1D         [24] 2037 	lcall	_ak820_outline_0095
      008AB4                       2038 00123$:
                                   2039 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008AB4 90 0B 16         [24] 2040 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008AB7 E0               [24] 2041 	movx	a,@dptr
      008AB8 24 02            [12] 2042 	add	a,#0x02
      008ABA F0               [24] 2043 	movx	@dptr,a
      008ABB 80 A7            [24] 2044 	sjmp	00122$
      008ABD                       2045 00120$:
                                   2046 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008ABD 90 0B 12         [24] 2047 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      008AC0 12 43 C5         [24] 2048 	lcall	_ak820_outline_0000
      008AC3 74 40            [12] 2049 	mov	a,#0x40
      008AC5 12 44 39         [24] 2050 	lcall	_ak820_outline_0050
      008AC8 90 05 8D         [24] 2051 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008ACB EE               [12] 2052 	mov	a,r6
      008ACC F0               [24] 2053 	movx	@dptr,a
      008ACD EF               [12] 2054 	mov	a,r7
      008ACE A3               [24] 2055 	inc	dptr
      008ACF 12 4E 60         [24] 2056 	lcall	_ak820_outline_0003
      008AD2 90 05 90         [24] 2057 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008AD5 E5 36            [12] 2058 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008AD7 F0               [24] 2059 	movx	@dptr,a
      008AD8 E5 37            [12] 2060 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008ADA A3               [24] 2061 	inc	dptr
      008ADB F0               [24] 2062 	movx	@dptr,a
      008ADC 12 81 5F         [24] 2063 	lcall	_ak820_outline_0100
                                   2064 ;	quantum/dynamic_keymap.c:521: }
      008ADF 02 41 DD         [24] 2065 	ljmp	_ak820_eeprom_write_block_xdata
                                   2066 ;------------------------------------------------------------
                                   2067 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2068 ;------------------------------------------------------------
                                   2069 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2070 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2071 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_435'
                                   2072 ;------------------------------------------------------------
                                   2073 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2074 ;	-----------------------------------------
                                   2075 ;	 function keycode_at_keymap_location
                                   2076 ;	-----------------------------------------
      008AE2                       2077 _keycode_at_keymap_location:
      008AE2 E5 82            [12] 2078 	mov	a,dpl
      008AE4 90 0B 19         [24] 2079 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_435
      008AE7 F0               [24] 2080 	movx	@dptr,a
                                   2081 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008AE8 E0               [24] 2082 	movx	a,@dptr
      008AE9 FF               [12] 2083 	mov	r7,a
      008AEA BF 06 00         [24] 2084 	cjne	r7,#0x06,00128$
      008AED                       2085 00128$:
      008AED 50 23            [24] 2086 	jnc	00102$
      008AEF 90 0B 17         [24] 2087 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008AF2 E0               [24] 2088 	movx	a,@dptr
      008AF3 FE               [12] 2089 	mov	r6,a
      008AF4 BE 10 00         [24] 2090 	cjne	r6,#0x10,00130$
      008AF7                       2091 00130$:
      008AF7 50 19            [24] 2092 	jnc	00102$
      008AF9 90 0B 18         [24] 2093 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008AFC E0               [24] 2094 	movx	a,@dptr
      008AFD FD               [12] 2095 	mov	r5,a
      008AFE BD 08 00         [24] 2096 	cjne	r5,#0x08,00132$
      008B01                       2097 00132$:
      008B01 50 0F            [24] 2098 	jnc	00102$
                                   2099 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008B03 90 0A CB         [24] 2100 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008B06 EE               [12] 2101 	mov	a,r6
      008B07 F0               [24] 2102 	movx	@dptr,a
      008B08 90 0A CC         [24] 2103 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008B0B ED               [12] 2104 	mov	a,r5
      008B0C F0               [24] 2105 	movx	@dptr,a
      008B0D 8F 82            [24] 2106 	mov	dpl, r7
      008B0F 02 84 58         [24] 2107 	ljmp	_dynamic_keymap_get_keycode
      008B12                       2108 00102$:
                                   2109 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008B12 90 00 00         [24] 2110 	mov	dptr,#0x0000
                                   2111 ;	quantum/dynamic_keymap.c:528: }
      008B15 22               [24] 2112 	ret
                                   2113 ;------------------------------------------------------------
                                   2114 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2115 ;------------------------------------------------------------
                                   2116 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2117 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2118 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_439'
                                   2119 ;------------------------------------------------------------
                                   2120 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2121 ;	-----------------------------------------
                                   2122 ;	 function keycode_at_encodermap_location
                                   2123 ;	-----------------------------------------
      008B16                       2124 _keycode_at_encodermap_location:
      008B16 E5 82            [12] 2125 	mov	a,dpl
      008B18 90 0B 1C         [24] 2126 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_439
      008B1B F0               [24] 2127 	movx	@dptr,a
                                   2128 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008B1C E0               [24] 2129 	movx	a,@dptr
      008B1D FF               [12] 2130 	mov	r7,a
      008B1E BF 06 00         [24] 2131 	cjne	r7,#0x06,00120$
      008B21                       2132 00120$:
      008B21 50 1E            [24] 2133 	jnc	00102$
      008B23 90 0B 1A         [24] 2134 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008B26 E0               [24] 2135 	movx	a,@dptr
      008B27 FE               [12] 2136 	mov	r6,a
      008B28 BE 01 00         [24] 2137 	cjne	r6,#0x01,00122$
      008B2B                       2138 00122$:
      008B2B 50 14            [24] 2139 	jnc	00102$
                                   2140 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008B2D 90 0B 1B         [24] 2141 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008B30 E0               [24] 2142 	movx	a,@dptr
      008B31 FE               [12] 2143 	mov	r6,a
      008B32 90 0A D5         [24] 2144 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008B35 E4               [12] 2145 	clr	a
      008B36 F0               [24] 2146 	movx	@dptr,a
      008B37 90 0A D6         [24] 2147 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008B3A EE               [12] 2148 	mov	a,r6
      008B3B F0               [24] 2149 	movx	@dptr,a
      008B3C 8F 82            [24] 2150 	mov	dpl, r7
      008B3E 02 85 19         [24] 2151 	ljmp	_dynamic_keymap_get_encoder
      008B41                       2152 00102$:
                                   2153 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008B41 90 00 00         [24] 2154 	mov	dptr,#0x0000
                                   2155 ;	quantum/dynamic_keymap.c:536: }
      008B44 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2159 ;------------------------------------------------------------
                                   2160 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2161 ;	-----------------------------------------
                                   2162 ;	 function dynamic_keymap_macro_get_count
                                   2163 ;	-----------------------------------------
      008B45                       2164 _dynamic_keymap_macro_get_count:
                                   2165 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008B45 75 82 10         [24] 2166 	mov	dpl, #0x10
                                   2167 ;	quantum/dynamic_keymap.c:541: }
      008B48 22               [24] 2168 	ret
                                   2169 ;------------------------------------------------------------
                                   2170 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2171 ;------------------------------------------------------------
                                   2172 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2173 ;	-----------------------------------------
                                   2174 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2175 ;	-----------------------------------------
      008B49                       2176 _dynamic_keymap_macro_get_buffer_size:
                                   2177 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008B49 90 20 00         [24] 2178 	mov	dptr,#0x2000
                                   2179 ;	quantum/dynamic_keymap.c:545: }
      008B4C 22               [24] 2180 	ret
                                   2181 ;------------------------------------------------------------
                                   2182 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2183 ;------------------------------------------------------------
                                   2184 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2185 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2186 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2187 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_447'
                                   2188 ;------------------------------------------------------------
                                   2189 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2190 ;	-----------------------------------------
                                   2191 ;	 function dynamic_keymap_macro_get_buffer
                                   2192 ;	-----------------------------------------
      008B4D                       2193 _dynamic_keymap_macro_get_buffer:
      008B4D 12 43 EA         [24] 2194 	lcall	_ak820_outline_0010
      008B50 90 0B 22         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_447
      008B53 12 43 E5         [24] 2196 	lcall	_ak820_outline_0007
                                   2197 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008B56 12 2B 2F         [24] 2198 	lcall	_ak820_macro_length
      008B59 12 44 1D         [24] 2199 	lcall	_ak820_outline_0027
      008B5C 90 0B 22         [24] 2200 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_447
      008B5F 12 43 DF         [24] 2201 	lcall	_ak820_outline_0006
      008B62 90 0B 1D         [24] 2202 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008B65 E0               [24] 2203 	movx	a,@dptr
      008B66 F5 39            [12] 2204 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008B68 A3               [24] 2205 	inc	dptr
      008B69 E0               [24] 2206 	movx	a,@dptr
      008B6A F5 3A            [12] 2207 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008B6C 90 0B 1F         [24] 2208 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008B6F 12 44 5C         [24] 2209 	lcall	_ak820_outline_0072
      008B72 A3               [24] 2210 	inc	dptr
      008B73 E0               [24] 2211 	movx	a,@dptr
      008B74 FB               [12] 2212 	mov	r3,a
      008B75 90 0A FA         [24] 2213 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008B78 EE               [12] 2214 	mov	a,r6
      008B79 12 43 E5         [24] 2215 	lcall	_ak820_outline_0007
      008B7C 90 0A FC         [24] 2216 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008B7F 12 44 0B         [24] 2217 	lcall	_ak820_outline_0023
      008B82 90 0A FE         [24] 2218 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008B85 E5 39            [12] 2219 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008B87 F0               [24] 2220 	movx	@dptr,a
      008B88 E5 3A            [12] 2221 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008B8A A3               [24] 2222 	inc	dptr
      008B8B F0               [24] 2223 	movx	@dptr,a
      008B8C 90 0B 00         [24] 2224 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008B8F E8               [12] 2225 	mov	a,r0
      008B90 F0               [24] 2226 	movx	@dptr,a
      008B91 E9               [12] 2227 	mov	a,r1
      008B92 A3               [24] 2228 	inc	dptr
      008B93 12 8F 56         [24] 2229 	lcall	_ak820_outline_0149
      008B96 90 08 00         [24] 2230 	mov	dptr,#0x0800
                                   2231 ;	quantum/dynamic_keymap.c:572: }
      008B99 02 88 51         [24] 2232 	ljmp	_ak820_dynamic_read_buffer
                                   2233 ;------------------------------------------------------------
                                   2234 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2235 ;------------------------------------------------------------
                                   2236 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2237 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2238 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_449'
                                   2239 ;------------------------------------------------------------
                                   2240 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2241 ;	-----------------------------------------
                                   2242 ;	 function dynamic_keymap_macro_set_buffer
                                   2243 ;	-----------------------------------------
      008B9C                       2244 _dynamic_keymap_macro_set_buffer:
      008B9C 12 43 EA         [24] 2245 	lcall	_ak820_outline_0010
      008B9F 90 0B 29         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_449
      008BA2 12 43 E5         [24] 2247 	lcall	_ak820_outline_0007
                                   2248 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008BA5 90 0B 29         [24] 2249 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_449
      008BA8 12 43 C5         [24] 2250 	lcall	_ak820_outline_0000
      008BAB 90 0B 24         [24] 2251 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008BAE 12 43 DF         [24] 2252 	lcall	_ak820_outline_0006
      008BB1 90 0B 26         [24] 2253 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008BB4 E0               [24] 2254 	movx	a,@dptr
      008BB5 F9               [12] 2255 	mov	r1,a
      008BB6 A3               [24] 2256 	inc	dptr
      008BB7 12 44 11         [24] 2257 	lcall	_ak820_outline_0024
      008BBA 90 05 0E         [24] 2258 	mov	dptr,#_ak820_macro_write_PARM_2
      008BBD 12 44 0B         [24] 2259 	lcall	_ak820_outline_0023
      008BC0 90 05 10         [24] 2260 	mov	dptr,#_ak820_macro_write_PARM_3
      008BC3 E9               [12] 2261 	mov	a,r1
      008BC4 12 4E 7C         [24] 2262 	lcall	_ak820_outline_0056
      008BC7 12 43 D3         [24] 2263 	lcall	_ak820_outline_0002
                                   2264 ;	quantum/dynamic_keymap.c:577: }
      008BCA 02 2B 49         [24] 2265 	ljmp	_ak820_macro_write
                                   2266 ;------------------------------------------------------------
                                   2267 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2268 ;------------------------------------------------------------
                                   2269 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2270 ;	-----------------------------------------
                                   2271 ;	 function dynamic_keymap_macro_reset
                                   2272 ;	-----------------------------------------
      008BCD                       2273 _dynamic_keymap_macro_reset:
                                   2274 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2275 ;	quantum/dynamic_keymap.c:603: }
      008BCD 02 2E 75         [24] 2276 	ljmp	_ak820_macro_reset
                                   2277 ;------------------------------------------------------------
                                   2278 ;Allocation info for local variables in function 'decode_keycode'
                                   2279 ;------------------------------------------------------------
                                   2280 ;kc            Allocated with name '_decode_keycode_kc_10000_453'
                                   2281 ;------------------------------------------------------------
                                   2282 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2283 ;	-----------------------------------------
                                   2284 ;	 function decode_keycode
                                   2285 ;	-----------------------------------------
      008BD0                       2286 _decode_keycode:
      008BD0 12 43 EA         [24] 2287 	lcall	_ak820_outline_0010
      008BD3 90 0B 2B         [24] 2288 	mov	dptr,#_decode_keycode_kc_10000_453
      008BD6 12 43 E5         [24] 2289 	lcall	_ak820_outline_0007
                                   2290 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008BD9 90 0B 2B         [24] 2291 	mov	dptr,#_decode_keycode_kc_10000_453
      008BDC 12 43 C5         [24] 2292 	lcall	_ak820_outline_0000
      008BDF 12 44 62         [24] 2293 	lcall	_ak820_outline_0073
      008BE2 C3               [12] 2294 	clr	c
      008BE3 E4               [12] 2295 	clr	a
      008BE4 9C               [12] 2296 	subb	a,r4
      008BE5 74 FF            [12] 2297 	mov	a,#0xff
      008BE7 9D               [12] 2298 	subb	a,r5
      008BE8 50 08            [24] 2299 	jnc	00102$
                                   2300 ;	free result
                                   2301 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008BEA 8C 05            [24] 2302 	mov	ar5,r4
      008BEC 7C 00            [12] 2303 	mov	r4,#0x00
      008BEE 12 43 EF         [24] 2304 	lcall	_ak820_outline_0011
      008BF1 22               [24] 2305 	ret
      008BF2                       2306 00102$:
                                   2307 ;	quantum/dynamic_keymap.c:609: return kc;
      008BF2 12 43 D3         [24] 2308 	lcall	_ak820_outline_0002
                                   2309 ;	quantum/dynamic_keymap.c:610: }
      008BF5 22               [24] 2310 	ret
                                   2311 ;------------------------------------------------------------
                                   2312 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2313 ;------------------------------------------------------------
                                   2314 ;sloc0         Allocated with name '_dynamic_keymap_macro_send_sloc0_1_0'
                                   2315 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_456'
                                   2316 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_457'
                                   2317 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_462'
                                   2318 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_463'
                                   2319 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_469'
                                   2320 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_487'
                                   2321 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_491'
                                   2322 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_491'
                                   2323 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_493'
                                   2324 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_495'
                                   2325 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_499'
                                   2326 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_501'
                                   2327 ;------------------------------------------------------------
                                   2328 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2329 ;	-----------------------------------------
                                   2330 ;	 function dynamic_keymap_macro_send
                                   2331 ;	-----------------------------------------
      008BF6                       2332 _dynamic_keymap_macro_send:
      008BF6 E5 82            [12] 2333 	mov	a,dpl
      008BF8 90 0B 2D         [24] 2334 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008BFB F0               [24] 2335 	movx	@dptr,a
                                   2336 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008BFC 90 0B 2E         [24] 2337 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008BFF E0               [24] 2338 	movx	a,@dptr
      008C00 60 01            [24] 2339 	jz	00102$
      008C02 22               [24] 2340 	ret
      008C03                       2341 00102$:
                                   2342 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008C03 90 0B 2D         [24] 2343 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008C06 E0               [24] 2344 	movx	a,@dptr
      008C07 FF               [12] 2345 	mov	r7,a
      008C08 BF 10 00         [24] 2346 	cjne	r7,#0x10,00422$
      008C0B                       2347 00422$:
      008C0B 40 01            [24] 2348 	jc	00104$
                                   2349 ;	quantum/dynamic_keymap.c:620: return;
      008C0D 22               [24] 2350 	ret
      008C0E                       2351 00104$:
                                   2352 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008C0E C0 07            [24] 2353 	push	ar7
      008C10 12 2A F6         [24] 2354 	lcall	_ak820_macro_ready
      008C13 E5 82            [12] 2355 	mov	a, dpl
      008C15 D0 07            [24] 2356 	pop	ar7
      008C17 70 01            [24] 2357 	jnz	00106$
      008C19 22               [24] 2358 	ret
      008C1A                       2359 00106$:
                                   2360 ;	quantum/dynamic_keymap.c:641: p         = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR);
      008C1A 90 0B 2F         [24] 2361 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008C1D E4               [12] 2362 	clr	a
      008C1E F0               [24] 2363 	movx	@dptr,a
      008C1F 74 08            [12] 2364 	mov	a,#0x08
      008C21 A3               [24] 2365 	inc	dptr
      008C22 12 4E 60         [24] 2366 	lcall	_ak820_outline_0003
                                   2367 ;	quantum/dynamic_keymap.c:643: uint8_t *end = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length());
      008C25 C0 07            [24] 2368 	push	ar7
      008C27 12 2B 2F         [24] 2369 	lcall	_ak820_macro_length
      008C2A AD 82            [24] 2370 	mov	r5, dpl
      008C2C AE 83            [24] 2371 	mov	r6, dph
      008C2E D0 07            [24] 2372 	pop	ar7
      008C30 74 08            [12] 2373 	mov	a,#0x08
      008C32 2E               [12] 2374 	add	a, r6
      008C33 FE               [12] 2375 	mov	r6,a
      008C34 8D 3B            [24] 2376 	mov	_dynamic_keymap_macro_send_sloc0_1_0,r5
      008C36 8E 3C            [24] 2377 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 1),r6
      008C38 75 3D 00         [24] 2378 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 2),#0x00
                                   2379 ;	quantum/dynamic_keymap.c:647: while (id > 0) {
      008C3B 79 00            [12] 2380 	mov	r1,#0x00
      008C3D 7A 08            [12] 2381 	mov	r2,#0x08
      008C3F 7B 00            [12] 2382 	mov	r3,#0x00
      008C41                       2383 00111$:
      008C41 EF               [12] 2384 	mov	a,r7
      008C42 60 37            [24] 2385 	jz	00113$
                                   2386 ;	quantum/dynamic_keymap.c:651: if (p == end) {
      008C44 C0 3B            [24] 2387 	push	_dynamic_keymap_macro_send_sloc0_1_0
      008C46 C0 3C            [24] 2388 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      008C48 C0 3D            [24] 2389 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      008C4A 12 44 06         [24] 2390 	lcall	_ak820_outline_0016
      008C4D 8B F0            [24] 2391 	mov	b,r3
      008C4F 12 30 77         [24] 2392 	lcall	___gptr_cmp
      008C52 15 81            [12] 2393 	dec	sp
      008C54 15 81            [12] 2394 	dec	sp
      008C56 15 81            [12] 2395 	dec	sp
      008C58 70 01            [24] 2396 	jnz	00108$
                                   2397 ;	quantum/dynamic_keymap.c:652: return;
      008C5A 22               [24] 2398 	ret
      008C5B                       2399 00108$:
                                   2400 ;	quantum/dynamic_keymap.c:654: if (eeprom_read_byte(p) == 0) {
      008C5B 12 44 06         [24] 2401 	lcall	_ak820_outline_0016
      008C5E 8B F0            [24] 2402 	mov	b, r3
      008C60 12 41 13         [24] 2403 	lcall	_eeprom_read_byte
      008C63 E5 82            [12] 2404 	mov	a, dpl
      008C65 70 06            [24] 2405 	jnz	00110$
                                   2406 ;	quantum/dynamic_keymap.c:655: --id;
      008C67 1F               [12] 2407 	dec	r7
      008C68 90 0B 2D         [24] 2408 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008C6B EF               [12] 2409 	mov	a,r7
      008C6C F0               [24] 2410 	movx	@dptr,a
      008C6D                       2411 00110$:
                                   2412 ;	quantum/dynamic_keymap.c:657: ++p;
      008C6D 09               [12] 2413 	inc	r1
      008C6E B9 00 01         [24] 2414 	cjne	r1,#0x00,00429$
      008C71 0A               [12] 2415 	inc	r2
      008C72                       2416 00429$:
      008C72 90 0B 2F         [24] 2417 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008C75 E9               [12] 2418 	mov	a,r1
      008C76 12 4E 7C         [24] 2419 	lcall	_ak820_outline_0056
      008C79 80 C6            [24] 2420 	sjmp	00111$
      008C7B                       2421 00113$:
                                   2422 ;	quantum/dynamic_keymap.c:663: sending = true;
      008C7B 90 0B 2E         [24] 2423 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008C7E 74 01            [12] 2424 	mov	a,#0x01
      008C80 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	quantum/dynamic_keymap.c:665: ak820_macro_cancelled = ak820_macro_primitive = false;
      008C81 12 8F 35         [24] 2427 	lcall	_ak820_outline_0124
      008C84 90 09 77         [24] 2428 	mov	dptr,#_ak820_macro_cancelled
      008C87 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	quantum/dynamic_keymap.c:670: char data[4] = {0, 0, 0, 0};
      008C88 90 0B 32         [24] 2431 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008C8B F0               [24] 2432 	movx	@dptr,a
      008C8C 90 0B 33         [24] 2433 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008C8F F0               [24] 2434 	movx	@dptr,a
      008C90 90 0B 34         [24] 2435 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0002)
      008C93 F0               [24] 2436 	movx	@dptr,a
      008C94 90 0B 35         [24] 2437 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008C97 F0               [24] 2438 	movx	@dptr,a
                                   2439 ;	quantum/dynamic_keymap.c:673: while (p < end
      008C98                       2440 00167$:
                                   2441 ;	quantum/dynamic_keymap.c:675: && !ak820_macro_cancelled
      008C98 90 0B 2F         [24] 2442 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008C9B 12 44 11         [24] 2443 	lcall	_ak820_outline_0024
      008C9E A3               [24] 2444 	inc	dptr
      008C9F E0               [24] 2445 	movx	a,@dptr
      008CA0 FF               [12] 2446 	mov	r7,a
      008CA1 A8 3B            [24] 2447 	mov	r0,_dynamic_keymap_macro_send_sloc0_1_0
      008CA3 A9 3C            [24] 2448 	mov	r1,(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      008CA5 AE 3D            [24] 2449 	mov	r6,(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      008CA7 C0 00            [24] 2450 	push	ar0
      008CA9 C0 01            [24] 2451 	push	ar1
      008CAB C0 06            [24] 2452 	push	ar6
      008CAD 12 44 22         [24] 2453 	lcall	_ak820_outline_0033
      008CB0 8F F0            [24] 2454 	mov	b,r7
      008CB2 12 30 77         [24] 2455 	lcall	___gptr_cmp
      008CB5 15 81            [12] 2456 	dec	sp
      008CB7 15 81            [12] 2457 	dec	sp
      008CB9 15 81            [12] 2458 	dec	sp
      008CBB 40 03            [24] 2459 	jc	00430$
      008CBD 02 8E D0         [24] 2460 	ljmp	00169$
      008CC0                       2461 00430$:
      008CC0 90 09 77         [24] 2462 	mov	dptr,#_ak820_macro_cancelled
      008CC3 E0               [24] 2463 	movx	a,@dptr
      008CC4 60 03            [24] 2464 	jz	00431$
      008CC6 02 8E D0         [24] 2465 	ljmp	00169$
      008CC9                       2466 00431$:
                                   2467 ;	quantum/dynamic_keymap.c:678: data[0] = eeprom_read_byte(p++);
      008CC9 8A 04            [24] 2468 	mov	ar4,r2
      008CCB 8B 05            [24] 2469 	mov	ar5,r3
      008CCD 8F 06            [24] 2470 	mov	ar6,r7
      008CCF 90 0B 2F         [24] 2471 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008CD2 74 01            [12] 2472 	mov	a,#0x01
      008CD4 2A               [12] 2473 	add	a, r2
      008CD5 F0               [24] 2474 	movx	@dptr,a
      008CD6 E4               [12] 2475 	clr	a
      008CD7 3B               [12] 2476 	addc	a, r3
      008CD8 A3               [24] 2477 	inc	dptr
      008CD9 12 43 E5         [24] 2478 	lcall	_ak820_outline_0007
      008CDC 12 43 EF         [24] 2479 	lcall	_ak820_outline_0011
      008CDF 8E F0            [24] 2480 	mov	b, r6
      008CE1 12 41 13         [24] 2481 	lcall	_eeprom_read_byte
      008CE4 AF 82            [24] 2482 	mov	r7, dpl
      008CE6 90 0B 32         [24] 2483 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008CE9 EF               [12] 2484 	mov	a,r7
      008CEA F0               [24] 2485 	movx	@dptr,a
                                   2486 ;	quantum/dynamic_keymap.c:679: data[1] = 0;
      008CEB 90 0B 33         [24] 2487 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008CEE E4               [12] 2488 	clr	a
      008CEF F0               [24] 2489 	movx	@dptr,a
                                   2490 ;	quantum/dynamic_keymap.c:681: if (data[0] == 0) {
      008CF0 90 0B 32         [24] 2491 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008CF3 E0               [24] 2492 	movx	a,@dptr
      008CF4 70 03            [24] 2493 	jnz	00432$
      008CF6 02 8E D0         [24] 2494 	ljmp	00169$
      008CF9                       2495 00432$:
                                   2496 ;	quantum/dynamic_keymap.c:684: if (data[0] == SS_QMK_PREFIX) {
      008CF9 90 0B 32         [24] 2497 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008CFC E0               [24] 2498 	movx	a,@dptr
      008CFD FF               [12] 2499 	mov	r7,a
      008CFE BF 01 02         [24] 2500 	cjne	r7,#0x01,00433$
      008D01 80 03            [24] 2501 	sjmp	00434$
      008D03                       2502 00433$:
      008D03 02 8E BA         [24] 2503 	ljmp	00164$
      008D06                       2504 00434$:
                                   2505 ;	quantum/dynamic_keymap.c:687: data[1] = eeprom_read_byte(p++);
      008D06 12 8E EF         [24] 2506 	lcall	_ak820_outline_0058
      008D09 12 43 C5         [24] 2507 	lcall	_ak820_outline_0000
      008D0C 12 8E D8         [24] 2508 	lcall	_ak820_outline_0017
      008D0F 12 43 E5         [24] 2509 	lcall	_ak820_outline_0007
      008D12 12 4E 65         [24] 2510 	lcall	_ak820_outline_0005
      008D15 12 41 13         [24] 2511 	lcall	_eeprom_read_byte
      008D18 AF 82            [24] 2512 	mov	r7, dpl
      008D1A 90 0B 33         [24] 2513 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008D1D EF               [12] 2514 	mov	a,r7
      008D1E F0               [24] 2515 	movx	@dptr,a
                                   2516 ;	quantum/dynamic_keymap.c:688: if (data[1] == 0)
      008D1F EF               [12] 2517 	mov	a,r7
      008D20 70 03            [24] 2518 	jnz	00435$
      008D22 02 8E D0         [24] 2519 	ljmp	00169$
      008D25                       2520 00435$:
                                   2521 ;	quantum/dynamic_keymap.c:690: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008D25 12 8E E3         [24] 2522 	lcall	_ak820_outline_0037
      008D28 BF 01 02         [24] 2523 	cjne	r7,#0x01,00436$
      008D2B 80 12            [24] 2524 	sjmp	00151$
      008D2D                       2525 00436$:
      008D2D 12 8E E3         [24] 2526 	lcall	_ak820_outline_0037
      008D30 BF 02 02         [24] 2527 	cjne	r7,#0x02,00437$
      008D33 80 0A            [24] 2528 	sjmp	00151$
      008D35                       2529 00437$:
      008D35 12 8E E3         [24] 2530 	lcall	_ak820_outline_0037
      008D38 BF 03 02         [24] 2531 	cjne	r7,#0x03,00438$
      008D3B 80 02            [24] 2532 	sjmp	00439$
      008D3D                       2533 00438$:
      008D3D 80 55            [24] 2534 	sjmp	00152$
      008D3F                       2535 00439$:
      008D3F                       2536 00151$:
                                   2537 ;	quantum/dynamic_keymap.c:692: data[2] = eeprom_read_byte(p++);
      008D3F 12 8E EF         [24] 2538 	lcall	_ak820_outline_0058
      008D42 12 43 C5         [24] 2539 	lcall	_ak820_outline_0000
      008D45 12 8E D8         [24] 2540 	lcall	_ak820_outline_0017
      008D48 12 43 E5         [24] 2541 	lcall	_ak820_outline_0007
      008D4B 12 4E 65         [24] 2542 	lcall	_ak820_outline_0005
      008D4E 12 41 13         [24] 2543 	lcall	_eeprom_read_byte
      008D51 12 8F 4D         [24] 2544 	lcall	_ak820_outline_0144
                                   2545 ;	quantum/dynamic_keymap.c:696: if (data[2] != 0) {
      008D54 70 03            [24] 2546 	jnz	00440$
      008D56 02 8C 98         [24] 2547 	ljmp	00167$
      008D59                       2548 00440$:
                                   2549 ;	quantum/dynamic_keymap.c:698: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008D59 12 8E E3         [24] 2550 	lcall	_ak820_outline_0037
      008D5C BF 01 03         [24] 2551 	cjne	r7,#0x01,00441$
      008D5F D3               [12] 2552 	setb	c
      008D60 80 01            [24] 2553 	sjmp	00442$
      008D62                       2554 00441$:
      008D62 C3               [12] 2555 	clr	c
      008D63                       2556 00442$:
      008D63 92 1D            [24] 2557 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      008D65 90 09 76         [24] 2558 	mov	dptr,#_ak820_macro_primitive
      008D68 B3               [12] 2559 	cpl	c
      008D69 E4               [12] 2560 	clr	a
      008D6A 33               [12] 2561 	rlc	a
      008D6B F0               [24] 2562 	movx	@dptr,a
                                   2563 ;	quantum/dynamic_keymap.c:700: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008D6C 12 8E E3         [24] 2564 	lcall	_ak820_outline_0037
      008D6F BF 01 08         [24] 2565 	cjne	r7,#0x01,00122$
      008D72 12 8F 28         [24] 2566 	lcall	_ak820_outline_0114
      008D75 12 75 F3         [24] 2567 	lcall	_tap_code
      008D78 80 14            [24] 2568 	sjmp	00123$
      008D7A                       2569 00122$:
                                   2570 ;	quantum/dynamic_keymap.c:701: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008D7A 12 8E E3         [24] 2571 	lcall	_ak820_outline_0037
      008D7D BF 02 08         [24] 2572 	cjne	r7,#0x02,00119$
      008D80 12 8F 28         [24] 2573 	lcall	_ak820_outline_0114
      008D83 12 74 ED         [24] 2574 	lcall	_register_code
      008D86 80 06            [24] 2575 	sjmp	00123$
      008D88                       2576 00119$:
                                   2577 ;	quantum/dynamic_keymap.c:702: else unregister_code((uint8_t)data[2]);
      008D88 12 8F 28         [24] 2578 	lcall	_ak820_outline_0114
      008D8B 12 75 5A         [24] 2579 	lcall	_unregister_code
      008D8E                       2580 00123$:
                                   2581 ;	quantum/dynamic_keymap.c:704: ak820_macro_primitive = false;
      008D8E 12 8F 35         [24] 2582 	lcall	_ak820_outline_0124
      008D91 02 8C 98         [24] 2583 	ljmp	00167$
      008D94                       2584 00152$:
                                   2585 ;	quantum/dynamic_keymap.c:712: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008D94 12 8E E3         [24] 2586 	lcall	_ak820_outline_0037
      008D97 BF 05 02         [24] 2587 	cjne	r7,#0x05,00447$
      008D9A 80 13            [24] 2588 	sjmp	00146$
      008D9C                       2589 00447$:
      008D9C 12 8E E3         [24] 2590 	lcall	_ak820_outline_0037
      008D9F BF 06 02         [24] 2591 	cjne	r7,#0x06,00448$
      008DA2 80 0B            [24] 2592 	sjmp	00146$
      008DA4                       2593 00448$:
      008DA4 12 8E E3         [24] 2594 	lcall	_ak820_outline_0037
      008DA7 BF 07 02         [24] 2595 	cjne	r7,#0x07,00449$
      008DAA 80 03            [24] 2596 	sjmp	00450$
      008DAC                       2597 00449$:
      008DAC 02 8E 4A         [24] 2598 	ljmp	00147$
      008DAF                       2599 00450$:
      008DAF                       2600 00146$:
                                   2601 ;	quantum/dynamic_keymap.c:713: data[2] = eeprom_read_byte(p++);
      008DAF 12 8E EF         [24] 2602 	lcall	_ak820_outline_0058
      008DB2 12 43 C5         [24] 2603 	lcall	_ak820_outline_0000
      008DB5 12 8E D8         [24] 2604 	lcall	_ak820_outline_0017
      008DB8 12 43 E5         [24] 2605 	lcall	_ak820_outline_0007
      008DBB 12 4E 65         [24] 2606 	lcall	_ak820_outline_0005
      008DBE 12 41 13         [24] 2607 	lcall	_eeprom_read_byte
      008DC1 12 8F 4D         [24] 2608 	lcall	_ak820_outline_0144
                                   2609 ;	quantum/dynamic_keymap.c:714: if (data[2] != 0) {
      008DC4 70 03            [24] 2610 	jnz	00451$
      008DC6 02 8C 98         [24] 2611 	ljmp	00167$
      008DC9                       2612 00451$:
                                   2613 ;	quantum/dynamic_keymap.c:715: data[3] = eeprom_read_byte(p++);
      008DC9 12 8E EF         [24] 2614 	lcall	_ak820_outline_0058
      008DCC 12 43 C5         [24] 2615 	lcall	_ak820_outline_0000
      008DCF 12 8E D8         [24] 2616 	lcall	_ak820_outline_0017
      008DD2 12 43 E5         [24] 2617 	lcall	_ak820_outline_0007
      008DD5 12 4E 65         [24] 2618 	lcall	_ak820_outline_0005
      008DD8 12 41 13         [24] 2619 	lcall	_eeprom_read_byte
      008DDB AF 82            [24] 2620 	mov	r7, dpl
      008DDD 90 0B 35         [24] 2621 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008DE0 EF               [12] 2622 	mov	a,r7
      008DE1 F0               [24] 2623 	movx	@dptr,a
                                   2624 ;	quantum/dynamic_keymap.c:716: if (data[3] != 0) {
      008DE2 EF               [12] 2625 	mov	a,r7
      008DE3 70 03            [24] 2626 	jnz	00452$
      008DE5 02 8C 98         [24] 2627 	ljmp	00167$
      008DE8                       2628 00452$:
                                   2629 ;	quantum/dynamic_keymap.c:719: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008DE8 90 0B 34         [24] 2630 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0002)
      008DEB E0               [24] 2631 	movx	a,@dptr
      008DEC FF               [12] 2632 	mov	r7,a
      008DED 90 0B 35         [24] 2633 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008DF0 E0               [24] 2634 	movx	a,@dptr
      008DF1 FD               [12] 2635 	mov	r5,a
      008DF2 E4               [12] 2636 	clr	a
      008DF3 FE               [12] 2637 	mov	r6,a
      008DF4 FC               [12] 2638 	mov	r4,a
      008DF5 EF               [12] 2639 	mov	a,r7
      008DF6 42 06            [12] 2640 	orl	ar6,a
      008DF8 EC               [12] 2641 	mov	a,r4
      008DF9 42 05            [12] 2642 	orl	ar5,a
                                   2643 ;	quantum/dynamic_keymap.c:723: kc = decode_keycode(kc);
      008DFB 8E 82            [24] 2644 	mov	dpl, r6
      008DFD 8D 83            [24] 2645 	mov	dph, r5
      008DFF 12 8B D0         [24] 2646 	lcall	_decode_keycode
      008E02 12 44 1D         [24] 2647 	lcall	_ak820_outline_0027
                                   2648 ;	quantum/dynamic_keymap.c:725: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008E05 90 0B 33         [24] 2649 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008E08 E0               [24] 2650 	movx	a,@dptr
      008E09 FD               [12] 2651 	mov	r5,a
      008E0A BD 05 03         [24] 2652 	cjne	r5,#0x05,00453$
      008E0D D3               [12] 2653 	setb	c
      008E0E 80 01            [24] 2654 	sjmp	00454$
      008E10                       2655 00453$:
      008E10 C3               [12] 2656 	clr	c
      008E11                       2657 00454$:
      008E11 92 1D            [24] 2658 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      008E13 90 09 76         [24] 2659 	mov	dptr,#_ak820_macro_primitive
      008E16 B3               [12] 2660 	cpl	c
      008E17 E4               [12] 2661 	clr	a
      008E18 33               [12] 2662 	rlc	a
      008E19 F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	quantum/dynamic_keymap.c:727: switch (data[1]) {
      008E1A 90 0B 33         [24] 2665 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008E1D E0               [24] 2666 	movx	a,@dptr
      008E1E FD               [12] 2667 	mov	r5,a
      008E1F BD 05 02         [24] 2668 	cjne	r5,#0x05,00455$
      008E22 80 0A            [24] 2669 	sjmp	00126$
      008E24                       2670 00455$:
      008E24 BD 06 02         [24] 2671 	cjne	r5,#0x06,00456$
      008E27 80 0D            [24] 2672 	sjmp	00127$
      008E29                       2673 00456$:
                                   2674 ;	quantum/dynamic_keymap.c:728: case VIAL_MACRO_EXT_TAP:
      008E29 BD 07 18         [24] 2675 	cjne	r5,#0x07,00129$
      008E2C 80 10            [24] 2676 	sjmp	00128$
      008E2E                       2677 00126$:
                                   2678 ;	quantum/dynamic_keymap.c:729: vial_keycode_tap(kc);
      008E2E 12 43 D3         [24] 2679 	lcall	_ak820_outline_0002
      008E31 12 B7 2D         [24] 2680 	lcall	_vial_keycode_tap
                                   2681 ;	quantum/dynamic_keymap.c:730: break;
                                   2682 ;	quantum/dynamic_keymap.c:731: case VIAL_MACRO_EXT_DOWN:
      008E34 80 0E            [24] 2683 	sjmp	00129$
      008E36                       2684 00127$:
                                   2685 ;	quantum/dynamic_keymap.c:732: vial_keycode_down(kc);
      008E36 12 43 D3         [24] 2686 	lcall	_ak820_outline_0002
      008E39 12 B6 0E         [24] 2687 	lcall	_vial_keycode_down
                                   2688 ;	quantum/dynamic_keymap.c:733: break;
                                   2689 ;	quantum/dynamic_keymap.c:734: case VIAL_MACRO_EXT_UP:
      008E3C 80 06            [24] 2690 	sjmp	00129$
      008E3E                       2691 00128$:
                                   2692 ;	quantum/dynamic_keymap.c:735: vial_keycode_up(kc);
      008E3E 12 43 D3         [24] 2693 	lcall	_ak820_outline_0002
      008E41 12 B6 9E         [24] 2694 	lcall	_vial_keycode_up
                                   2695 ;	quantum/dynamic_keymap.c:737: }
      008E44                       2696 00129$:
                                   2697 ;	quantum/dynamic_keymap.c:739: ak820_macro_primitive = false;
      008E44 12 8F 35         [24] 2698 	lcall	_ak820_outline_0124
      008E47 02 8C 98         [24] 2699 	ljmp	00167$
      008E4A                       2700 00147$:
                                   2701 ;	quantum/dynamic_keymap.c:743: } else if (data[1] == SS_DELAY_CODE) {
      008E4A 12 8E E3         [24] 2702 	lcall	_ak820_outline_0037
      008E4D BF 04 02         [24] 2703 	cjne	r7,#0x04,00458$
      008E50 80 03            [24] 2704 	sjmp	00459$
      008E52                       2705 00458$:
      008E52 02 8C 98         [24] 2706 	ljmp	00167$
      008E55                       2707 00459$:
                                   2708 ;	quantum/dynamic_keymap.c:745: uint8_t d0 = eeprom_read_byte(p++);
      008E55 12 8E EF         [24] 2709 	lcall	_ak820_outline_0058
      008E58 12 43 C5         [24] 2710 	lcall	_ak820_outline_0000
      008E5B 12 8E D8         [24] 2711 	lcall	_ak820_outline_0017
      008E5E 12 43 E5         [24] 2712 	lcall	_ak820_outline_0007
      008E61 12 4E 65         [24] 2713 	lcall	_ak820_outline_0005
      008E64 12 41 13         [24] 2714 	lcall	_eeprom_read_byte
      008E67 AF 82            [24] 2715 	mov	r7, dpl
                                   2716 ;	quantum/dynamic_keymap.c:746: uint8_t d1 = eeprom_read_byte(p++);
      008E69 90 0B 2F         [24] 2717 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008E6C 12 43 DF         [24] 2718 	lcall	_ak820_outline_0006
      008E6F A3               [24] 2719 	inc	dptr
      008E70 E0               [24] 2720 	movx	a,@dptr
      008E71 FE               [12] 2721 	mov	r6,a
      008E72 90 0B 2F         [24] 2722 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008E75 74 01            [12] 2723 	mov	a,#0x01
      008E77 2C               [12] 2724 	add	a, r4
      008E78 F0               [24] 2725 	movx	@dptr,a
      008E79 E4               [12] 2726 	clr	a
      008E7A 3D               [12] 2727 	addc	a, r5
      008E7B A3               [24] 2728 	inc	dptr
      008E7C F0               [24] 2729 	movx	@dptr,a
      008E7D EE               [12] 2730 	mov	a,r6
      008E7E A3               [24] 2731 	inc	dptr
      008E7F F0               [24] 2732 	movx	@dptr,a
      008E80 12 43 EF         [24] 2733 	lcall	_ak820_outline_0011
      008E83 8E F0            [24] 2734 	mov	b, r6
      008E85 12 41 13         [24] 2735 	lcall	_eeprom_read_byte
      008E88 AE 82            [24] 2736 	mov	r6, dpl
                                   2737 ;	quantum/dynamic_keymap.c:747: if (d0 == 0 || d1 == 0)
      008E8A EF               [12] 2738 	mov	a,r7
      008E8B 60 43            [24] 2739 	jz	00169$
      008E8D EE               [12] 2740 	mov	a,r6
      008E8E 60 40            [24] 2741 	jz	00169$
                                   2742 ;	quantum/dynamic_keymap.c:750: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008E90 1F               [12] 2743 	dec	r7
      008E91 1E               [12] 2744 	dec	r6
      008E92 EE               [12] 2745 	mov	a,r6
      008E93 75 F0 FF         [24] 2746 	mov	b,#0xff
      008E96 A4               [48] 2747 	mul	ab
      008E97 FE               [12] 2748 	mov	r6,a
      008E98 AD F0            [24] 2749 	mov	r5,b
      008E9A 7C 00            [12] 2750 	mov	r4,#0x00
      008E9C EE               [12] 2751 	mov	a,r6
      008E9D 2F               [12] 2752 	add	a, r7
      008E9E FE               [12] 2753 	mov	r6,a
      008E9F ED               [12] 2754 	mov	a,r5
      008EA0 3C               [12] 2755 	addc	a, r4
      008EA1 FD               [12] 2756 	mov	r5,a
                                   2757 ;	quantum/dynamic_keymap.c:751: while (ms--) wait_ms(1);
      008EA2                       2758 00141$:
      008EA2 8E 04            [24] 2759 	mov	ar4,r6
      008EA4 8D 07            [24] 2760 	mov	ar7,r5
      008EA6 1E               [12] 2761 	dec	r6
      008EA7 BE FF 01         [24] 2762 	cjne	r6,#0xff,00462$
      008EAA 1D               [12] 2763 	dec	r5
      008EAB                       2764 00462$:
      008EAB EC               [12] 2765 	mov	a,r4
      008EAC 4F               [12] 2766 	orl	a,r7
      008EAD 70 03            [24] 2767 	jnz	00463$
      008EAF 02 8C 98         [24] 2768 	ljmp	00167$
      008EB2                       2769 00463$:
      008EB2 90 00 01         [24] 2770 	mov	dptr,#0x0001
      008EB5 12 58 B8         [24] 2771 	lcall	_mDelaymS
      008EB8 80 E8            [24] 2772 	sjmp	00141$
      008EBA                       2773 00164$:
                                   2774 ;	quantum/dynamic_keymap.c:757: if ((uint8_t)data[0] >= 128) break;
      008EBA 90 0B 32         [24] 2775 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008EBD E0               [24] 2776 	movx	a,@dptr
      008EBE FF               [12] 2777 	mov	r7,a
      008EBF BF 80 00         [24] 2778 	cjne	r7,#0x80,00464$
      008EC2                       2779 00464$:
      008EC2 50 0C            [24] 2780 	jnc	00169$
                                   2781 ;	quantum/dynamic_keymap.c:761: send_char(data[0]);
      008EC4 90 0B 32         [24] 2782 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008EC7 E0               [24] 2783 	movx	a,@dptr
      008EC8 F5 82            [12] 2784 	mov	dpl,a
      008ECA 12 A8 9F         [24] 2785 	lcall	_send_char
                                   2786 ;	quantum/dynamic_keymap.c:762: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008ECD 02 8C 98         [24] 2787 	ljmp	00167$
      008ED0                       2788 00169$:
                                   2789 ;	quantum/dynamic_keymap.c:770: ak820_macro_primitive = false;
      008ED0 12 8F 35         [24] 2790 	lcall	_ak820_outline_0124
                                   2791 ;	quantum/dynamic_keymap.c:772: sending = false;
      008ED3 90 0B 2E         [24] 2792 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008ED6 F0               [24] 2793 	movx	@dptr,a
                                   2794 ;	quantum/dynamic_keymap.c:774: }
      008ED7 22               [24] 2795 	ret
                                   2796 	.area CSEG    (CODE)
                                   2797 	.area CONST   (CODE)
                                   2798 	.area XINIT   (CODE)
                                   2799 	.area CABS    (ABS,CODE)
                                   2800 
                                   2801 ; Experimental exact instruction outlining.
                                   2802 	.globl _ak820_outline_0000
                                   2803 	.globl _ak820_outline_0002
                                   2804 	.globl _ak820_outline_0003
                                   2805 	.globl _ak820_outline_0005
                                   2806 	.globl _ak820_outline_0006
                                   2807 	.globl _ak820_outline_0007
                                   2808 	.globl _ak820_outline_0010
                                   2809 	.globl _ak820_outline_0011
                                   2810 	.globl _ak820_outline_0012
                                   2811 	.globl _ak820_outline_0015
                                   2812 	.globl _ak820_outline_0016
                                   2813 	.globl _ak820_outline_0017
                                   2814 	.globl _ak820_outline_0023
                                   2815 	.globl _ak820_outline_0024
                                   2816 	.globl _ak820_outline_0027
                                   2817 	.globl _ak820_outline_0033
                                   2818 	.globl _ak820_outline_0037
                                   2819 	.globl _ak820_outline_0043
                                   2820 	.globl _ak820_outline_0049
                                   2821 	.globl _ak820_outline_0050
                                   2822 	.globl _ak820_outline_0056
                                   2823 	.globl _ak820_outline_0058
                                   2824 	.globl _ak820_outline_0060
                                   2825 	.globl _ak820_outline_0063
                                   2826 	.globl _ak820_outline_0072
                                   2827 	.globl _ak820_outline_0073
                                   2828 	.globl _ak820_outline_0075
                                   2829 	.globl _ak820_outline_0079
                                   2830 	.globl _ak820_outline_0091
                                   2831 	.globl _ak820_outline_0095
                                   2832 	.globl _ak820_outline_0098
                                   2833 	.globl _ak820_outline_0100
                                   2834 	.globl _ak820_outline_0114
                                   2835 	.globl _ak820_outline_0117
                                   2836 	.globl _ak820_outline_0124
                                   2837 	.globl _ak820_outline_0132
                                   2838 	.globl _ak820_outline_0139
                                   2839 	.globl _ak820_outline_0141
                                   2840 	.globl _ak820_outline_0144
                                   2841 	.globl _ak820_outline_0147
                                   2842 	.globl _ak820_outline_0149
                                   2843 
                                   2844 	.area CSEG (CODE)
                                   2845 ; function ak820_outline_0017
      008ED8                       2846 _ak820_outline_0017:
      008ED8 90 0B 2F         [24] 2847 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008EDB 74 01            [12] 2848 	mov	a,#0x01
      008EDD 2D               [12] 2849 	add	a,r5
      008EDE F0               [24] 2850 	movx	@dptr,a
      008EDF E4               [12] 2851 	clr	a
      008EE0 3E               [12] 2852 	addc	a,r6
      008EE1 A3               [24] 2853 	inc	dptr
      008EE2 22               [24] 2854 	ret
                                   2855 
                                   2856 	.area CSEG (CODE)
                                   2857 ; function ak820_outline_0037
      008EE3                       2858 _ak820_outline_0037:
      008EE3 90 0B 33         [24] 2859 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0001)
      008EE6 E0               [24] 2860 	movx	a,@dptr
      008EE7 FF               [12] 2861 	mov	r7,a
      008EE8 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0049
      008EE9                       2866 _ak820_outline_0049:
      008EE9 2D               [12] 2867 	add	a,r5
      008EEA F9               [12] 2868 	mov	r1,a
      008EEB E4               [12] 2869 	clr	a
      008EEC 3E               [12] 2870 	addc	a,r6
      008EED FA               [12] 2871 	mov	r2,a
      008EEE 22               [24] 2872 	ret
                                   2873 
                                   2874 	.area CSEG (CODE)
                                   2875 ; function ak820_outline_0058
      008EEF                       2876 _ak820_outline_0058:
      008EEF 90 0B 2F         [24] 2877 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008EF2 E0               [24] 2878 	movx	a,@dptr
      008EF3 FD               [12] 2879 	mov	r5,a
      008EF4 A3               [24] 2880 	inc	dptr
      008EF5 22               [24] 2881 	ret
                                   2882 
                                   2883 	.area CSEG (CODE)
                                   2884 ; function ak820_outline_0063
      008EF6                       2885 _ak820_outline_0063:
      008EF6 ED               [12] 2886 	mov	a,r5
      008EF7 75 F0 0A         [24] 2887 	mov	b,#0x0a
      008EFA A4               [48] 2888 	mul	ab
      008EFB 24 58            [12] 2889 	add	a,#0x58
      008EFD FC               [12] 2890 	mov	r4,a
      008EFE 74 06            [12] 2891 	mov	a,#0x06
      008F00 35 F0            [12] 2892 	addc	a,b
      008F02 FD               [12] 2893 	mov	r5,a
      008F03 22               [24] 2894 	ret
                                   2895 
                                   2896 	.area CSEG (CODE)
                                   2897 ; function ak820_outline_0075
      008F04                       2898 _ak820_outline_0075:
      008F04 90 0A C8         [24] 2899 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008F07 EE               [12] 2900 	mov	a,r6
      008F08 F0               [24] 2901 	movx	@dptr,a
      008F09 90 0A C9         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008F0C ED               [12] 2903 	mov	a,r5
      008F0D F0               [24] 2904 	movx	@dptr,a
      008F0E 8F 82            [24] 2905 	mov	dpl,r7
      008F10 22               [24] 2906 	ret
                                   2907 
                                   2908 	.area CSEG (CODE)
                                   2909 ; function ak820_outline_0079
      008F11                       2910 _ak820_outline_0079:
      008F11 AD 82            [24] 2911 	mov	r5,dpl
      008F13 AE 83            [24] 2912 	mov	r6,dph
      008F15 AF F0            [24] 2913 	mov	r7,b
      008F17 22               [24] 2914 	ret
                                   2915 
                                   2916 	.area CSEG (CODE)
                                   2917 ; function ak820_outline_0091
      008F18                       2918 _ak820_outline_0091:
      008F18 EC               [12] 2919 	mov	a,r4
      008F19 F0               [24] 2920 	movx	@dptr,a
      008F1A ED               [12] 2921 	mov	a,r5
      008F1B A3               [24] 2922 	inc	dptr
      008F1C 22               [24] 2923 	ret
                                   2924 
                                   2925 	.area CSEG (CODE)
                                   2926 ; function ak820_outline_0095
      008F1D                       2927 _ak820_outline_0095:
      008F1D 28               [12] 2928 	add	a,r0
      008F1E F5 82            [12] 2929 	mov	dpl,a
      008F20 EF               [12] 2930 	mov	a,r7
      008F21 39               [12] 2931 	addc	a,r1
      008F22 F5 83            [12] 2932 	mov	dph,a
      008F24 74 FF            [12] 2933 	mov	a,#0xff
      008F26 F0               [24] 2934 	movx	@dptr,a
      008F27 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0114
      008F28                       2939 _ak820_outline_0114:
      008F28 90 0B 34         [24] 2940 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0002)
      008F2B E0               [24] 2941 	movx	a,@dptr
      008F2C F5 82            [12] 2942 	mov	dpl,a
      008F2E 22               [24] 2943 	ret
                                   2944 
                                   2945 	.area CSEG (CODE)
                                   2946 ; function ak820_outline_0117
      008F2F                       2947 _ak820_outline_0117:
      008F2F 2D               [12] 2948 	add	a,r5
      008F30 FD               [12] 2949 	mov	r5,a
      008F31 E4               [12] 2950 	clr	a
      008F32 3E               [12] 2951 	addc	a,r6
      008F33 FE               [12] 2952 	mov	r6,a
      008F34 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0124
      008F35                       2957 _ak820_outline_0124:
      008F35 90 09 76         [24] 2958 	mov	dptr,#_ak820_macro_primitive
      008F38 E4               [12] 2959 	clr	a
      008F39 F0               [24] 2960 	movx	@dptr,a
      008F3A 22               [24] 2961 	ret
                                   2962 
                                   2963 	.area CSEG (CODE)
                                   2964 ; function ak820_outline_0139
      008F3B                       2965 _ak820_outline_0139:
      008F3B 90 0A D8         [24] 2966 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008F3E E4               [12] 2967 	clr	a
      008F3F F0               [24] 2968 	movx	@dptr,a
      008F40 90 0A D9         [24] 2969 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008F43 22               [24] 2970 	ret
                                   2971 
                                   2972 	.area CSEG (CODE)
                                   2973 ; function ak820_outline_0141
      008F44                       2974 _ak820_outline_0141:
      008F44 90 0B A4         [24] 2975 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008F47 E4               [12] 2976 	clr	a
      008F48 F0               [24] 2977 	movx	@dptr,a
      008F49 90 0B A5         [24] 2978 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008F4C 22               [24] 2979 	ret
                                   2980 
                                   2981 	.area CSEG (CODE)
                                   2982 ; function ak820_outline_0144
      008F4D                       2983 _ak820_outline_0144:
      008F4D AF 82            [24] 2984 	mov	r7,dpl
      008F4F 90 0B 34         [24] 2985 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0002)
      008F52 EF               [12] 2986 	mov	a,r7
      008F53 F0               [24] 2987 	movx	@dptr,a
      008F54 EF               [12] 2988 	mov	a,r7
      008F55 22               [24] 2989 	ret
                                   2990 
                                   2991 	.area CSEG (CODE)
                                   2992 ; function ak820_outline_0149
      008F56                       2993 _ak820_outline_0149:
      008F56 F0               [24] 2994 	movx	@dptr,a
      008F57 EB               [12] 2995 	mov	a,r3
      008F58 A3               [24] 2996 	inc	dptr
      008F59 F0               [24] 2997 	movx	@dptr,a
      008F5A 22               [24] 2998 	ret
