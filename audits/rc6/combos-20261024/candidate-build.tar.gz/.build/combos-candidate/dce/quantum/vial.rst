                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000048                        541 _vial_handle_cmd_sloc0_1_0:
      000048                        542 	.ds 2
      00004A                        543 _vial_handle_cmd_sloc1_1_0:
      00004A                        544 	.ds 2
      00004C                        545 _vial_handle_cmd_sloc2_1_0:
      00004C                        546 	.ds 2
      00004E                        547 _vial_handle_cmd_sloc3_1_0:
      00004E                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C69                        573 _vial_unlock_timer:
      000C69                        574 	.ds 4
      000C6D                        575 _vial_unlock_holding:
      000C6D                        576 	.ds 1
      000C6E                        577 _vial_keycode_firewall_in_10000_602:
      000C6E                        578 	.ds 2
      000C70                        579 _vial_fill_packet_PARM_2:
      000C70                        580 	.ds 1
      000C71                        581 _vial_fill_packet_msg_10000_605:
      000C71                        582 	.ds 2
      000C73                        583 _vial_handle_cmd_PARM_2:
      000C73                        584 	.ds 1
      000C74                        585 _vial_handle_cmd_data_10000_610:
      000C74                        586 	.ds 3
      000C77                        587 _vial_handle_cmd_entry_70000_638:
      000C77                        588 	.ds 10
      000C81                        589 _vial_handle_cmd_entry_70000_639:
      000C81                        590 	.ds 10
      000C8B                        591 _g_vial_magic_keycode_override::
      000C8B                        592 	.ds 2
      000C8D                        593 _vial_keycode_down_keycode_10000_641:
      000C8D                        594 	.ds 2
      000C8F                        595 _vial_keycode_down_dummy_event_30000_648:
      000C8F                        596 	.ds 6
      000C95                        597 _vial_keycode_up_keycode_10000_649:
      000C95                        598 	.ds 2
      000C97                        599 _vial_keycode_up_dummy_event_30000_656:
      000C97                        600 	.ds 6
      000C9D                        601 _vial_keycode_tap_keycode_10000_657:
      000C9D                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E32                        611 _vial_unlocked::
      000E32                        612 	.ds 1
      000E33                        613 _vial_unlock_in_progress::
      000E33                        614 	.ds 1
      000E34                        615 _vial_unlock_counter:
      000E34                        616 	.ds 1
      000E35                        617 _vial_unlock_combo_rows:
      000E35                        618 	.ds 2
      000E37                        619 _vial_unlock_combo_cols:
      000E37                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_175'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00B104                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B104 90 0E 33         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00B107 E0               [24]  667 	movx	a,@dptr
      00B108 70 01            [24]  668 	jnz	00131$
      00B10A 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B10B                        671 00131$:
      00B10B 7F 00            [12]  672 	mov	r7,#0x00
      00B10D                        673 00115$:
      00B10D BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00B110                        675 00184$:
      00B110 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B112 EF               [12]  678 	mov	a,r7
      00B113 12 B7 5B         [24]  679 	lcall	_ak820_outline_0094
      00B116 FE               [12]  680 	mov	r6,a
      00B117 EF               [12]  681 	mov	a,r7
      00B118 12 B7 50         [24]  682 	lcall	_ak820_outline_0093
      00B11B 90 07 4F         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00B11E F0               [24]  684 	movx	@dptr,a
      00B11F 8E 82            [24]  685 	mov	dpl, r6
      00B121 C0 07            [24]  686 	push	ar7
      00B123 12 59 4A         [24]  687 	lcall	_matrix_is_on
      00B126 E5 82            [12]  688 	mov	a, dpl
      00B128 D0 07            [24]  689 	pop	ar7
      00B12A 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B12C 90 0C 6D         [24]  692 	mov	dptr,#_vial_unlock_holding
      00B12F E4               [12]  693 	clr	a
      00B130 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B131 90 0E 34         [24]  696 	mov	dptr,#_vial_unlock_counter
      00B134 74 1E            [12]  697 	mov	a,#0x1e
      00B136 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00B137 22               [24]  700 	ret
      00B138                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B138 0F               [12]  703 	inc	r7
      00B139 80 D2            [24]  704 	sjmp	00115$
      00B13B                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B13B 90 0C 6D         [24]  707 	mov	dptr,#_vial_unlock_holding
      00B13E E0               [24]  708 	movx	a,@dptr
      00B13F 70 15            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B141 90 0C 6D         [24]  711 	mov	dptr,#_vial_unlock_holding
      00B144 74 01            [12]  712 	mov	a,#0x01
      00B146 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B147 12 48 9A         [24]  715 	lcall	_timer_read32
      00B14A 12 4E 6C         [24]  716 	lcall	_ak820_outline_0041
      00B14D 90 0C 69         [24]  717 	mov	dptr,#_vial_unlock_timer
      00B150 12 8F 18         [24]  718 	lcall	_ak820_outline_0091
      00B153 12 43 CB         [24]  719 	lcall	_ak820_outline_0001
      00B156                        720 00107$:
                                    721 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B156 90 0C 69         [24]  722 	mov	dptr,#_vial_unlock_timer
      00B159 12 43 DF         [24]  723 	lcall	_ak820_outline_0006
      00B15C A3               [24]  724 	inc	dptr
      00B15D E0               [24]  725 	movx	a,@dptr
      00B15E FE               [12]  726 	mov	r6,a
      00B15F A3               [24]  727 	inc	dptr
      00B160 E0               [24]  728 	movx	a,@dptr
      00B161 12 43 EF         [24]  729 	lcall	_ak820_outline_0011
      00B164 8E F0            [24]  730 	mov	b,r6
      00B166 12 48 F3         [24]  731 	lcall	_timer_elapsed32
      00B169 12 4E 6C         [24]  732 	lcall	_ak820_outline_0041
                                    733 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B16C 7B 1E            [12]  734 	mov	r3,#0x1e
      00B16E                        735 00109$:
      00B16E EB               [12]  736 	mov	a,r3
      00B16F 60 22            [24]  737 	jz	00111$
      00B171 C3               [12]  738 	clr	c
      00B172 EC               [12]  739 	mov	a,r4
      00B173 94 64            [12]  740 	subb	a,#0x64
      00B175 ED               [12]  741 	mov	a,r5
      00B176 94 00            [12]  742 	subb	a,#0x00
      00B178 EE               [12]  743 	mov	a,r6
      00B179 94 00            [12]  744 	subb	a,#0x00
      00B17B EF               [12]  745 	mov	a,r7
      00B17C 94 00            [12]  746 	subb	a,#0x00
      00B17E 40 13            [24]  747 	jc	00111$
                                    748 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B180 EC               [12]  749 	mov	a,r4
      00B181 24 9C            [12]  750 	add	a,#0x9c
      00B183 FC               [12]  751 	mov	r4,a
      00B184 ED               [12]  752 	mov	a,r5
      00B185 34 FF            [12]  753 	addc	a,#0xff
      00B187 FD               [12]  754 	mov	r5,a
      00B188 EE               [12]  755 	mov	a,r6
      00B189 34 FF            [12]  756 	addc	a,#0xff
      00B18B FE               [12]  757 	mov	r6,a
      00B18C EF               [12]  758 	mov	a,r7
      00B18D 34 FF            [12]  759 	addc	a,#0xff
      00B18F FF               [12]  760 	mov	r7,a
                                    761 ;	quantum/vial.c:82: --counter;
      00B190 1B               [12]  762 	dec	r3
      00B191 80 DB            [24]  763 	sjmp	00109$
      00B193                        764 00111$:
                                    765 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B193 90 0E 34         [24]  766 	mov	dptr,#_vial_unlock_counter
      00B196 EB               [12]  767 	mov	a,r3
      00B197 F0               [24]  768 	movx	@dptr,a
                                    769 ;	quantum/vial.c:85: if (!counter) {
      00B198 EB               [12]  770 	mov	a,r3
      00B199 70 0A            [24]  771 	jnz	00117$
                                    772 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B19B 90 0E 33         [24]  773 	mov	dptr,#_vial_unlock_in_progress
      00B19E E4               [12]  774 	clr	a
      00B19F F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B1A0 90 0E 32         [24]  777 	mov	dptr,#_vial_unlocked
      00B1A3 04               [12]  778 	inc	a
      00B1A4 F0               [24]  779 	movx	@dptr,a
      00B1A5                        780 00117$:
                                    781 ;	quantum/vial.c:90: }
      00B1A5 22               [24]  782 	ret
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'vial_init'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/vial.c:108: void vial_init(void) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function vial_init
                                    789 ;	-----------------------------------------
      00B1A6                        790 _vial_init:
                                    791 ;	quantum/vial.c:113: reload_combo();
                                    792 ;	quantum/vial.c:118: }
      00B1A6 02 36 2A         [24]  793 	ljmp	_ak820_combo_reload
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    796 ;------------------------------------------------------------
                                    797 ;in            Allocated with name '_vial_keycode_firewall_in_10000_602'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function vial_keycode_firewall
                                    802 ;	-----------------------------------------
      00B1A9                        803 _vial_keycode_firewall:
      00B1A9 12 43 EA         [24]  804 	lcall	_ak820_outline_0010
      00B1AC 90 0C 6E         [24]  805 	mov	dptr,#_vial_keycode_firewall_in_10000_602
      00B1AF 12 43 E5         [24]  806 	lcall	_ak820_outline_0007
                                    807 ;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
      00B1B2 90 0C 6E         [24]  808 	mov	dptr,#_vial_keycode_firewall_in_10000_602
      00B1B5 12 43 C5         [24]  809 	lcall	_ak820_outline_0000
      00B1B8 12 44 62         [24]  810 	lcall	_ak820_outline_0073
      00B1BB BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00B1BE BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00B1C1 90 0E 32         [24]  813 	mov	dptr,#_vial_unlocked
      00B1C4 E0               [24]  814 	movx	a,@dptr
      00B1C5 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:122: return 0;
      00B1C7 90 00 00         [24]  817 	mov	dptr,#0x0000
      00B1CA 22               [24]  818 	ret
      00B1CB                        819 00102$:
                                    820 ;	quantum/vial.c:123: return in;
      00B1CB 12 43 D3         [24]  821 	lcall	_ak820_outline_0002
                                    822 ;	quantum/vial.c:124: }
      00B1CE 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_605'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_607'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00B1CF                        835 _vial_fill_packet:
      00B1CF 12 43 EA         [24]  836 	lcall	_ak820_outline_0010
      00B1D2 90 0C 71         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_605
      00B1D5 12 43 E5         [24]  838 	lcall	_ak820_outline_0007
                                    839 ;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B1D8 90 0C 71         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_605
      00B1DB 12 43 C5         [24]  841 	lcall	_ak820_outline_0000
      00B1DE 90 0C 70         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1E1 E0               [24]  843 	movx	a,@dptr
      00B1E2 FD               [12]  844 	mov	r5,a
      00B1E3 7C 00            [12]  845 	mov	r4,#0x00
      00B1E5                        846 00103$:
      00B1E5 BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00B1E8                        848 00122$:
      00B1E8 50 09            [24]  849 	jnc	00105$
      00B1EA EC               [12]  850 	mov	a,r4
      00B1EB 12 43 FE         [24]  851 	lcall	_ak820_outline_0015
      00B1EE ED               [12]  852 	mov	a,r5
      00B1EF F0               [24]  853 	movx	@dptr,a
      00B1F0 0C               [12]  854 	inc	r4
      00B1F1 80 F2            [24]  855 	sjmp	00103$
      00B1F3                        856 00105$:
                                    857 ;	quantum/vial.c:129: }
      00B1F3 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:140: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00B1F4                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:162: repeat_key_cancel();
      00B1F4 12 A5 3C         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:164: clear_keyboard();
                                    870 ;	quantum/vial.c:165: }
      00B1F7 02 76 60         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_610'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_611'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_616'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_617'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_620'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_622'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_622'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_622'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_623'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_624'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_624'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_624'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_627'
                                    893 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_638'
                                    894 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_638'
                                    895 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_639'
                                    896 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_639'
                                    897 ;------------------------------------------------------------
                                    898 ;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    899 ;	-----------------------------------------
                                    900 ;	 function vial_handle_cmd
                                    901 ;	-----------------------------------------
      00B1FA                        902 _vial_handle_cmd:
      00B1FA 12 43 D8         [24]  903 	lcall	_ak820_outline_0004
      00B1FD 90 0C 74         [24]  904 	mov	dptr,#_vial_handle_cmd_data_10000_610
      00B200 12 43 CB         [24]  905 	lcall	_ak820_outline_0001
                                    906 ;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B203 90 0C 74         [24]  907 	mov	dptr,#_vial_handle_cmd_data_10000_610
      00B206 12 43 C5         [24]  908 	lcall	_ak820_outline_0000
                                    909 ;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
      00B209 90 0C 73         [24]  910 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B20C E0               [24]  911 	movx	a,@dptr
      00B20D FD               [12]  912 	mov	r5,a
      00B20E BD 20 02         [24]  913 	cjne	r5,#0x20,00258$
      00B211 80 01            [24]  914 	sjmp	00102$
      00B213                        915 00258$:
                                    916 ;	quantum/vial.c:178: return;
      00B213 22               [24]  917 	ret
      00B214                        918 00102$:
                                    919 ;	quantum/vial.c:181: switch (msg[1]) {
      00B214 74 01            [12]  920 	mov	a,#0x01
      00B216 12 44 33         [24]  921 	lcall	_ak820_outline_0043
      00B219 12 43 EF         [24]  922 	lcall	_ak820_outline_0011
      00B21C E0               [24]  923 	movx	a,@dptr
      00B21D FB               [12]  924 	mov  r3,a
      00B21E 24 F2            [12]  925 	add	a,#0xff - 0x0d
      00B220 50 01            [24]  926 	jnc	00259$
      00B222 22               [24]  927 	ret
      00B223                        928 00259$:
                                    929 ;	free result
      00B223 EB               [12]  930 	mov	a,r3
      00B224 24 0A            [12]  931 	add	a,#(00260$-3-.)
      00B226 83               [24]  932 	movc	a,@a+pc
      00B227 F5 82            [12]  933 	mov	dpl,a
      00B229 EB               [12]  934 	mov	a,r3
      00B22A 24 12            [12]  935 	add	a,#(00261$-3-.)
      00B22C 83               [24]  936 	movc	a,@a+pc
      00B22D F5 83            [12]  937 	mov	dph,a
      00B22F E4               [12]  938 	clr	a
      00B230 73               [24]  939 	jmp	@a+dptr
      00B231                        940 00260$:
      00B231 4D                     941 	.db	00103$
      00B232 9E                     942 	.db	00105$
      00B233 B9                     943 	.db	00106$
      00B234 52                     944 	.db	00112$
      00B235 DC                     945 	.db	00113$
      00B236 34                     946 	.db	00114$
      00B237 A3                     947 	.db	00116$
      00B238 BE                     948 	.db	00119$
      00B239 DC                     949 	.db	00120$
      00B23A EA                     950 	.db	00121$
      00B23B 0D                     951 	.db	00139$
      00B23C 0D                     952 	.db	00139$
      00B23D 0D                     953 	.db	00139$
      00B23E F6                     954 	.db	00122$
      00B23F                        955 00261$:
      00B23F B2                     956 	.db	00103$>>8
      00B240 B2                     957 	.db	00105$>>8
      00B241 B2                     958 	.db	00106$>>8
      00B242 B3                     959 	.db	00112$>>8
      00B243 B3                     960 	.db	00113$>>8
      00B244 B4                     961 	.db	00114$>>8
      00B245 B4                     962 	.db	00116$>>8
      00B246 B4                     963 	.db	00119$>>8
      00B247 B4                     964 	.db	00120$>>8
      00B248 B4                     965 	.db	00121$>>8
      00B249 B6                     966 	.db	00139$>>8
      00B24A B6                     967 	.db	00139$>>8
      00B24B B6                     968 	.db	00139$>>8
      00B24C B4                     969 	.db	00122$>>8
                                    970 ;	quantum/vial.c:183: case vial_get_keyboard_id: {
      00B24D                        971 00103$:
                                    972 ;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
      00B24D 90 0C 70         [24]  973 	mov	dptr,#_vial_fill_packet_PARM_2
      00B250 E4               [12]  974 	clr	a
      00B251 F0               [24]  975 	movx	@dptr,a
      00B252 12 43 D3         [24]  976 	lcall	_ak820_outline_0002
      00B255 C0 07            [24]  977 	push	ar7
      00B257 C0 06            [24]  978 	push	ar6
      00B259 12 B1 CF         [24]  979 	lcall	_vial_fill_packet
      00B25C D0 06            [24]  980 	pop	ar6
      00B25E D0 07            [24]  981 	pop	ar7
                                    982 ;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B260 12 43 D3         [24]  983 	lcall	_ak820_outline_0002
      00B263 74 06            [12]  984 	mov	a,#0x06
      00B265 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B266 12 43 D3         [24]  987 	lcall	_ak820_outline_0002
      00B269 A3               [24]  988 	inc	dptr
      00B26A E4               [12]  989 	clr	a
      00B26B F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B26C 12 43 D3         [24]  992 	lcall	_ak820_outline_0002
      00B26F A3               [24]  993 	inc	dptr
      00B270 A3               [24]  994 	inc	dptr
      00B271 F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B272 12 43 D3         [24]  997 	lcall	_ak820_outline_0002
      00B275 A3               [24]  998 	inc	dptr
      00B276 A3               [24]  999 	inc	dptr
      00B277 A3               [24] 1000 	inc	dptr
      00B278 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B279 FB               [12] 1003 	mov	r3,a
      00B27A                       1004 00131$:
      00B27A BB 08 00         [24] 1005 	cjne	r3,#0x08,00262$
      00B27D                       1006 00262$:
      00B27D 50 16            [24] 1007 	jnc	00104$
      00B27F 8B 02            [24] 1008 	mov	ar2,r3
      00B281 74 04            [12] 1009 	mov	a,#0x04
      00B283 2A               [12] 1010 	add	a, r2
      00B284 2E               [12] 1011 	add	a, r6
      00B285 F9               [12] 1012 	mov	r1,a
      00B286 E4               [12] 1013 	clr	a
      00B287 3F               [12] 1014 	addc	a,r7
      00B288 FA               [12] 1015 	mov	r2,a
      00B289 EB               [12] 1016 	mov	a,r3
      00B28A 90 C4 3A         [24] 1017 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_615
      00B28D 93               [24] 1018 	movc	a,@a+dptr
      00B28E 12 44 06         [24] 1019 	lcall	_ak820_outline_0016
      00B291 F0               [24] 1020 	movx	@dptr,a
      00B292 0B               [12] 1021 	inc	r3
      00B293 80 E5            [24] 1022 	sjmp	00131$
      00B295                       1023 00104$:
                                   1024 ;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B295 74 0C            [12] 1025 	mov	a,#0x0c
      00B297 12 43 FE         [24] 1026 	lcall	_ak820_outline_0015
      00B29A 74 01            [12] 1027 	mov	a,#0x01
      00B29C F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	quantum/vial.c:195: break;
      00B29D 22               [24] 1030 	ret
                                   1031 ;	quantum/vial.c:198: case vial_get_size: {
      00B29E                       1032 00105$:
                                   1033 ;	quantum/vial.c:200: msg[0] = sz & 0xFF;
      00B29E 12 43 D3         [24] 1034 	lcall	_ak820_outline_0002
      00B2A1 74 7C            [12] 1035 	mov	a,#0x7c
      00B2A3 F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
      00B2A4 12 43 EF         [24] 1038 	lcall	_ak820_outline_0011
      00B2A7 74 01            [12] 1039 	mov	a,#0x01
      00B2A9 F0               [24] 1040 	movx	@dptr,a
                                   1041 ;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
      00B2AA 12 43 D3         [24] 1042 	lcall	_ak820_outline_0002
      00B2AD A3               [24] 1043 	inc	dptr
      00B2AE A3               [24] 1044 	inc	dptr
      00B2AF E4               [12] 1045 	clr	a
      00B2B0 F0               [24] 1046 	movx	@dptr,a
                                   1047 ;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
      00B2B1 12 43 D3         [24] 1048 	lcall	_ak820_outline_0002
      00B2B4 A3               [24] 1049 	inc	dptr
      00B2B5 A3               [24] 1050 	inc	dptr
      00B2B6 A3               [24] 1051 	inc	dptr
      00B2B7 F0               [24] 1052 	movx	@dptr,a
                                   1053 ;	quantum/vial.c:204: break;
      00B2B8 22               [24] 1054 	ret
                                   1055 ;	quantum/vial.c:207: case vial_get_def: {
      00B2B9                       1056 00106$:
                                   1057 ;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
      00B2B9 12 43 D3         [24] 1058 	lcall	_ak820_outline_0002
      00B2BC A3               [24] 1059 	inc	dptr
      00B2BD 12 B0 C5         [24] 1060 	lcall	_ak820_outline_0026
      00B2C0 FB               [12] 1061 	mov	r3,a
      00B2C1 12 43 D3         [24] 1062 	lcall	_ak820_outline_0002
      00B2C4 A3               [24] 1063 	inc	dptr
      00B2C5 A3               [24] 1064 	inc	dptr
      00B2C6 12 B0 C5         [24] 1065 	lcall	_ak820_outline_0026
      00B2C9 4B               [12] 1066 	orl	a,r3
      00B2CA 60 01            [24] 1067 	jz	00108$
      00B2CC 22               [24] 1068 	ret
      00B2CD                       1069 00108$:
                                   1070 ;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B2CD 12 43 D3         [24] 1071 	lcall	_ak820_outline_0002
      00B2D0 A3               [24] 1072 	inc	dptr
      00B2D1 A3               [24] 1073 	inc	dptr
      00B2D2 E0               [24] 1074 	movx	a,@dptr
      00B2D3 FB               [12] 1075 	mov	r3,a
      00B2D4 7A 00            [12] 1076 	mov	r2,#0x00
      00B2D6 12 43 D3         [24] 1077 	lcall	_ak820_outline_0002
      00B2D9 12 B0 C5         [24] 1078 	lcall	_ak820_outline_0026
      00B2DC F9               [12] 1079 	mov	r1,a
      00B2DD E4               [12] 1080 	clr	a
      00B2DE 42 03            [12] 1081 	orl	ar3,a
      00B2E0 E9               [12] 1082 	mov	a,r1
      00B2E1 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B2E3 C3               [12] 1085 	clr	c
      00B2E4 EB               [12] 1086 	mov	a,r3
      00B2E5 94 0C            [12] 1087 	subb	a,#0x0c
      00B2E7 EA               [12] 1088 	mov	a,r2
      00B2E8 94 00            [12] 1089 	subb	a,#0x00
      00B2EA 40 01            [24] 1090 	jc	00110$
      00B2EC 22               [24] 1091 	ret
      00B2ED                       1092 00110$:
                                   1093 ;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B2ED EA               [12] 1094 	mov	a,r2
      00B2EE C4               [12] 1095 	swap	a
      00B2EF 23               [12] 1096 	rl	a
      00B2F0 54 E0            [12] 1097 	anl	a,#0xe0
      00B2F2 CB               [12] 1098 	xch	a,r3
      00B2F3 C4               [12] 1099 	swap	a
      00B2F4 23               [12] 1100 	rl	a
      00B2F5 CB               [12] 1101 	xch	a,r3
      00B2F6 6B               [12] 1102 	xrl	a,r3
      00B2F7 CB               [12] 1103 	xch	a,r3
      00B2F8 54 E0            [12] 1104 	anl	a,#0xe0
      00B2FA CB               [12] 1105 	xch	a,r3
      00B2FB 6B               [12] 1106 	xrl	a,r3
      00B2FC FA               [12] 1107 	mov	r2,a
      00B2FD 8B 48            [24] 1108 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B2FF 8A 49            [24] 1109 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1110 ;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B301 74 7C            [12] 1111 	mov	a,#0x7c
      00B303 C3               [12] 1112 	clr	c
      00B304 95 48            [12] 1113 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B306 F8               [12] 1114 	mov	r0,a
      00B307 74 01            [12] 1115 	mov	a,#0x01
      00B309 95 49            [12] 1116 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B30B F9               [12] 1117 	mov	r1,a
                                   1118 ;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B30C C3               [12] 1119 	clr	c
      00B30D E8               [12] 1120 	mov	a,r0
      00B30E 94 20            [12] 1121 	subb	a,#0x20
      00B310 E9               [12] 1122 	mov	a,r1
      00B311 94 00            [12] 1123 	subb	a,#0x00
      00B313 40 02            [24] 1124 	jc	00142$
      00B315 78 20            [12] 1125 	mov	r0,#0x20
      00B317                       1126 00142$:
                                   1127 ;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B317 79 00            [12] 1128 	mov	r1,#0x00
      00B319                       1129 00134$:
      00B319 C3               [12] 1130 	clr	c
      00B31A E9               [12] 1131 	mov	a,r1
      00B31B 98               [12] 1132 	subb	a,r0
      00B31C 40 01            [24] 1133 	jc	00267$
      00B31E 22               [24] 1134 	ret
      00B31F                       1135 00267$:
      00B31F C0 00            [24] 1136 	push	ar0
      00B321 E9               [12] 1137 	mov	a,r1
      00B322 2E               [12] 1138 	add	a, r6
      00B323 F5 4A            [12] 1139 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B325 E4               [12] 1140 	clr	a
      00B326 3F               [12] 1141 	addc	a, r7
      00B327 F5 4B            [12] 1142 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B329 89 4C            [24] 1143 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B32B 75 4D 00         [24] 1144 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B32E A8 48            [24] 1145 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B330 AB 49            [24] 1146 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B332 E5 4C            [12] 1147 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B334 28               [12] 1148 	add	a, r0
      00B335 F8               [12] 1149 	mov	r0,a
      00B336 E5 4D            [12] 1150 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B338 3B               [12] 1151 	addc	a, r3
      00B339 FB               [12] 1152 	mov	r3,a
      00B33A E8               [12] 1153 	mov	a,r0
      00B33B 24 BE            [12] 1154 	add	a, #_keyboard_definition
      00B33D F5 82            [12] 1155 	mov	dpl,a
      00B33F EB               [12] 1156 	mov	a,r3
      00B340 34 C2            [12] 1157 	addc	a, #(_keyboard_definition >> 8)
      00B342 F5 83            [12] 1158 	mov	dph,a
      00B344 E4               [12] 1159 	clr	a
      00B345 93               [24] 1160 	movc	a,@a+dptr
      00B346 85 4A 82         [24] 1161 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B349 85 4B 83         [24] 1162 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B34C F0               [24] 1163 	movx	@dptr,a
      00B34D 09               [12] 1164 	inc	r1
      00B34E D0 00            [24] 1165 	pop	ar0
                                   1166 ;	quantum/vial.c:234: case vial_get_encoder: {
      00B350 80 C7            [24] 1167 	sjmp	00134$
      00B352                       1168 00112$:
                                   1169 ;	quantum/vial.c:235: uint8_t layer = msg[2];
      00B352 74 02            [12] 1170 	mov	a,#0x02
      00B354 12 9B 81         [24] 1171 	lcall	_ak820_outline_0118
      00B357 12 44 22         [24] 1172 	lcall	_ak820_outline_0033
      00B35A E0               [24] 1173 	movx	a,@dptr
      00B35B F5 4C            [12] 1174 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1175 ;	quantum/vial.c:236: uint8_t idx = msg[3];
      00B35D 74 03            [12] 1176 	mov	a,#0x03
      00B35F 2E               [12] 1177 	add	a, r6
      00B360 F5 4A            [12] 1178 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B362 E4               [12] 1179 	clr	a
      00B363 3F               [12] 1180 	addc	a, r7
      00B364 F5 4B            [12] 1181 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B366 85 4A 82         [24] 1182 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B369 85 4B 83         [24] 1183 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B36C E0               [24] 1184 	movx	a,@dptr
                                   1185 ;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B36D F5 48            [12] 1186 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B36F 90 0A D5         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B372 F0               [24] 1188 	movx	@dptr,a
      00B373 90 0A D6         [24] 1189 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B376 E4               [12] 1190 	clr	a
      00B377 F0               [24] 1191 	movx	@dptr,a
      00B378 85 4C 82         [24] 1192 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B37B C0 07            [24] 1193 	push	ar7
      00B37D C0 06            [24] 1194 	push	ar6
      00B37F C0 05            [24] 1195 	push	ar5
      00B381 C0 04            [24] 1196 	push	ar4
      00B383 C0 03            [24] 1197 	push	ar3
      00B385 C0 02            [24] 1198 	push	ar2
      00B387 12 85 19         [24] 1199 	lcall	_dynamic_keymap_get_encoder
      00B38A 85 82 4E         [24] 1200 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B38D 85 83 4F         [24] 1201 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B390 D0 02            [24] 1202 	pop	ar2
      00B392 D0 03            [24] 1203 	pop	ar3
      00B394 D0 04            [24] 1204 	pop	ar4
      00B396 D0 05            [24] 1205 	pop	ar5
      00B398 D0 06            [24] 1206 	pop	ar6
      00B39A D0 07            [24] 1207 	pop	ar7
                                   1208 ;	quantum/vial.c:238: msg[0]  = keycode >> 8;
      00B39C A9 4F            [24] 1209 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B39E 12 43 D3         [24] 1210 	lcall	_ak820_outline_0002
      00B3A1 E9               [12] 1211 	mov	a,r1
      00B3A2 F0               [24] 1212 	movx	@dptr,a
                                   1213 ;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
      00B3A3 A8 4E            [24] 1214 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B3A5 12 43 EF         [24] 1215 	lcall	_ak820_outline_0011
      00B3A8 E8               [12] 1216 	mov	a,r0
      00B3A9 F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B3AA 90 0A D5         [24] 1219 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B3AD E5 48            [12] 1220 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B3AF F0               [24] 1221 	movx	@dptr,a
      00B3B0 90 0A D6         [24] 1222 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B3B3 74 01            [12] 1223 	mov	a,#0x01
      00B3B5 F0               [24] 1224 	movx	@dptr,a
      00B3B6 85 4C 82         [24] 1225 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B3B9 C0 03            [24] 1226 	push	ar3
      00B3BB C0 02            [24] 1227 	push	ar2
      00B3BD 12 85 19         [24] 1228 	lcall	_dynamic_keymap_get_encoder
      00B3C0 85 82 4E         [24] 1229 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B3C3 85 83 4F         [24] 1230 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B3C6 D0 02            [24] 1231 	pop	ar2
      00B3C8 D0 03            [24] 1232 	pop	ar3
                                   1233 ;	quantum/vial.c:241: msg[2] = keycode >> 8;
      00B3CA A9 4F            [24] 1234 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B3CC 12 44 22         [24] 1235 	lcall	_ak820_outline_0033
      00B3CF E9               [12] 1236 	mov	a,r1
      00B3D0 F0               [24] 1237 	movx	@dptr,a
                                   1238 ;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
      00B3D1 A8 4E            [24] 1239 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B3D3 85 4A 82         [24] 1240 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3D6 85 4B 83         [24] 1241 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3D9 E8               [12] 1242 	mov	a,r0
      00B3DA F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vial.c:243: break;
      00B3DB 22               [24] 1245 	ret
                                   1246 ;	quantum/vial.c:245: case vial_set_encoder: {
      00B3DC                       1247 00113$:
                                   1248 ;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B3DC 12 43 D3         [24] 1249 	lcall	_ak820_outline_0002
      00B3DF A3               [24] 1250 	inc	dptr
      00B3E0 A3               [24] 1251 	inc	dptr
      00B3E1 E0               [24] 1252 	movx	a,@dptr
      00B3E2 F5 4A            [12] 1253 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3E4 12 43 D3         [24] 1254 	lcall	_ak820_outline_0002
      00B3E7 12 B0 C5         [24] 1255 	lcall	_ak820_outline_0026
      00B3EA F5 4C            [12] 1256 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B3EC 12 43 D3         [24] 1257 	lcall	_ak820_outline_0002
      00B3EF A3               [24] 1258 	inc	dptr
      00B3F0 12 B0 C5         [24] 1259 	lcall	_ak820_outline_0026
                                   1260 ;	assignBit
      00B3F3 24 FF            [12] 1261 	add	a,#0xff
      00B3F5 E4               [12] 1262 	clr	a
      00B3F6 33               [12] 1263 	rlc	a
      00B3F7 F5 4E            [12] 1264 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B3F9 12 43 D3         [24] 1265 	lcall	_ak820_outline_0002
      00B3FC A3               [24] 1266 	inc	dptr
      00B3FD A3               [24] 1267 	inc	dptr
      00B3FE 12 B0 C5         [24] 1268 	lcall	_ak820_outline_0026
      00B401 F9               [12] 1269 	mov	r1,a
      00B402 78 00            [12] 1270 	mov	r0,#0x00
      00B404 74 06            [12] 1271 	mov	a,#0x06
      00B406 12 43 FE         [24] 1272 	lcall	_ak820_outline_0015
      00B409 E0               [24] 1273 	movx	a,@dptr
      00B40A 7B 00            [12] 1274 	mov	r3,#0x00
      00B40C 42 00            [12] 1275 	orl	ar0,a
      00B40E EB               [12] 1276 	mov	a,r3
      00B40F 42 01            [12] 1277 	orl	ar1,a
      00B411 12 81 5F         [24] 1278 	lcall	_ak820_outline_0100
      00B414 12 B1 A9         [24] 1279 	lcall	_vial_keycode_firewall
      00B417 AA 82            [24] 1280 	mov	r2, dpl
      00B419 AB 83            [24] 1281 	mov	r3, dph
      00B41B 90 0A D8         [24] 1282 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B41E E5 4C            [12] 1283 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B420 F0               [24] 1284 	movx	@dptr,a
      00B421 90 0A D9         [24] 1285 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B424 E5 4E            [12] 1286 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B426 F0               [24] 1287 	movx	@dptr,a
      00B427 90 0A DA         [24] 1288 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B42A EA               [12] 1289 	mov	a,r2
      00B42B 12 8F 56         [24] 1290 	lcall	_ak820_outline_0149
      00B42E 85 4A 82         [24] 1291 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1292 ;	quantum/vial.c:247: break;
      00B431 02 85 88         [24] 1293 	ljmp	_dynamic_keymap_set_encoder
                                   1294 ;	quantum/vial.c:250: case vial_get_unlock_status: {
      00B434                       1295 00114$:
                                   1296 ;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B434 90 0C 70         [24] 1297 	mov	dptr,#_vial_fill_packet_PARM_2
      00B437 74 FF            [12] 1298 	mov	a,#0xff
      00B439 F0               [24] 1299 	movx	@dptr,a
      00B43A 12 43 D3         [24] 1300 	lcall	_ak820_outline_0002
      00B43D C0 07            [24] 1301 	push	ar7
      00B43F C0 06            [24] 1302 	push	ar6
      00B441 12 B1 CF         [24] 1303 	lcall	_vial_fill_packet
      00B444 D0 06            [24] 1304 	pop	ar6
      00B446 D0 07            [24] 1305 	pop	ar7
                                   1306 ;	quantum/vial.c:254: msg[0] = vial_unlocked;
      00B448 90 0E 32         [24] 1307 	mov	dptr,#_vial_unlocked
      00B44B E0               [24] 1308 	movx	a,@dptr
      00B44C 12 43 D3         [24] 1309 	lcall	_ak820_outline_0002
      00B44F F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
      00B450 74 01            [12] 1312 	mov	a,#0x01
      00B452 12 9B 81         [24] 1313 	lcall	_ak820_outline_0118
      00B455 90 0E 33         [24] 1314 	mov	dptr,#_vial_unlock_in_progress
      00B458 E0               [24] 1315 	movx	a,@dptr
      00B459 12 44 22         [24] 1316 	lcall	_ak820_outline_0033
      00B45C F0               [24] 1317 	movx	@dptr,a
                                   1318 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B45D 7B 00            [12] 1319 	mov	r3,#0x00
      00B45F                       1320 00137$:
      00B45F BB 02 00         [24] 1321 	cjne	r3,#0x02,00268$
      00B462                       1322 00268$:
      00B462 40 01            [24] 1323 	jc	00269$
      00B464 22               [24] 1324 	ret
      00B465                       1325 00269$:
                                   1326 ;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B465 8B 01            [24] 1327 	mov	ar1,r3
      00B467 7A 00            [12] 1328 	mov	r2,#0x00
      00B469 E9               [12] 1329 	mov	a,r1
      00B46A 29               [12] 1330 	add	a,r1
      00B46B F5 4E            [12] 1331 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B46D EA               [12] 1332 	mov	a,r2
      00B46E 33               [12] 1333 	rlc	a
      00B46F F5 4F            [12] 1334 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B471 74 02            [12] 1335 	mov	a,#0x02
      00B473 25 4E            [12] 1336 	add	a, _vial_handle_cmd_sloc3_1_0
      00B475 F8               [12] 1337 	mov	r0,a
      00B476 E4               [12] 1338 	clr	a
      00B477 35 4F            [12] 1339 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B479 FA               [12] 1340 	mov	r2,a
      00B47A E8               [12] 1341 	mov	a,r0
      00B47B 2E               [12] 1342 	add	a, r6
      00B47C F8               [12] 1343 	mov	r0,a
      00B47D EA               [12] 1344 	mov	a,r2
      00B47E 3F               [12] 1345 	addc	a, r7
      00B47F FA               [12] 1346 	mov	r2,a
      00B480 EB               [12] 1347 	mov	a,r3
      00B481 12 B7 5B         [24] 1348 	lcall	_ak820_outline_0094
      00B484 88 82            [24] 1349 	mov	dpl,r0
      00B486 8A 83            [24] 1350 	mov	dph,r2
      00B488 F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B489 74 03            [12] 1353 	mov	a,#0x03
      00B48B 25 4E            [12] 1354 	add	a, _vial_handle_cmd_sloc3_1_0
      00B48D F9               [12] 1355 	mov	r1,a
      00B48E E4               [12] 1356 	clr	a
      00B48F 35 4F            [12] 1357 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B491 FA               [12] 1358 	mov	r2,a
      00B492 E9               [12] 1359 	mov	a,r1
      00B493 2E               [12] 1360 	add	a, r6
      00B494 F9               [12] 1361 	mov	r1,a
      00B495 EA               [12] 1362 	mov	a,r2
      00B496 3F               [12] 1363 	addc	a, r7
      00B497 FA               [12] 1364 	mov	r2,a
      00B498 EB               [12] 1365 	mov	a,r3
      00B499 12 B7 50         [24] 1366 	lcall	_ak820_outline_0093
      00B49C 12 44 06         [24] 1367 	lcall	_ak820_outline_0016
      00B49F F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4A0 0B               [12] 1370 	inc	r3
                                   1371 ;	quantum/vial.c:266: case vial_unlock_start: {
      00B4A1 80 BC            [24] 1372 	sjmp	00137$
      00B4A3                       1373 00116$:
                                   1374 ;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
      00B4A3 90 0E 33         [24] 1375 	mov	dptr,#_vial_unlock_in_progress
      00B4A6 E0               [24] 1376 	movx	a,@dptr
      00B4A7 70 03            [24] 1377 	jnz	00118$
      00B4A9 12 B1 F4         [24] 1378 	lcall	_vial_release_held_state
      00B4AC                       1379 00118$:
                                   1380 ;	quantum/vial.c:270: vial_unlock_in_progress = 1;
      00B4AC 90 0E 33         [24] 1381 	mov	dptr,#_vial_unlock_in_progress
      00B4AF 74 01            [12] 1382 	mov	a,#0x01
      00B4B1 F0               [24] 1383 	movx	@dptr,a
                                   1384 ;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B4B2 90 0E 34         [24] 1385 	mov	dptr,#_vial_unlock_counter
      00B4B5 74 1E            [12] 1386 	mov	a,#0x1e
      00B4B7 F0               [24] 1387 	movx	@dptr,a
                                   1388 ;	quantum/vial.c:273: vial_unlock_holding = false;
      00B4B8 90 0C 6D         [24] 1389 	mov	dptr,#_vial_unlock_holding
      00B4BB E4               [12] 1390 	clr	a
      00B4BC F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:275: break;
      00B4BD 22               [24] 1393 	ret
                                   1394 ;	quantum/vial.c:277: case vial_unlock_poll: {
      00B4BE                       1395 00119$:
                                   1396 ;	quantum/vial.c:278: msg[0] = vial_unlocked;
      00B4BE 90 0E 32         [24] 1397 	mov	dptr,#_vial_unlocked
      00B4C1 E0               [24] 1398 	movx	a,@dptr
      00B4C2 12 43 D3         [24] 1399 	lcall	_ak820_outline_0002
      00B4C5 F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
      00B4C6 90 0E 33         [24] 1402 	mov	dptr,#_vial_unlock_in_progress
      00B4C9 E0               [24] 1403 	movx	a,@dptr
      00B4CA 12 43 EF         [24] 1404 	lcall	_ak820_outline_0011
      00B4CD F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
      00B4CE 74 02            [12] 1407 	mov	a,#0x02
      00B4D0 12 9B 81         [24] 1408 	lcall	_ak820_outline_0118
      00B4D3 90 0E 34         [24] 1409 	mov	dptr,#_vial_unlock_counter
      00B4D6 E0               [24] 1410 	movx	a,@dptr
      00B4D7 12 44 22         [24] 1411 	lcall	_ak820_outline_0033
      00B4DA F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vial.c:281: break;
      00B4DB 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:283: case vial_lock: {
      00B4DC                       1416 00120$:
                                   1417 ;	quantum/vial.c:285: vial_unlocked = 0;
      00B4DC 90 0E 32         [24] 1418 	mov	dptr,#_vial_unlocked
      00B4DF E4               [12] 1419 	clr	a
      00B4E0 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/vial.c:286: vial_unlock_in_progress = 0;
      00B4E1 90 0E 33         [24] 1422 	mov	dptr,#_vial_unlock_in_progress
      00B4E4 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/vial.c:287: vial_unlock_holding = false;
      00B4E5 90 0C 6D         [24] 1425 	mov	dptr,#_vial_unlock_holding
      00B4E8 F0               [24] 1426 	movx	@dptr,a
                                   1427 ;	quantum/vial.c:289: break;
      00B4E9 22               [24] 1428 	ret
                                   1429 ;	quantum/vial.c:291: case vial_qmk_settings_query: {
      00B4EA                       1430 00121$:
                                   1431 ;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B4EA 90 0C 70         [24] 1432 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4ED 74 FF            [12] 1433 	mov	a,#0xff
      00B4EF F0               [24] 1434 	movx	@dptr,a
      00B4F0 12 43 D3         [24] 1435 	lcall	_ak820_outline_0002
                                   1436 ;	quantum/vial.c:298: break;
      00B4F3 02 B1 CF         [24] 1437 	ljmp	_vial_fill_packet
                                   1438 ;	quantum/vial.c:318: case vial_dynamic_entry_op: {
      00B4F6                       1439 00122$:
                                   1440 ;	quantum/vial.c:319: switch (msg[2]) {
      00B4F6 12 43 D3         [24] 1441 	lcall	_ak820_outline_0002
      00B4F9 A3               [24] 1442 	inc	dptr
      00B4FA A3               [24] 1443 	inc	dptr
      00B4FB E0               [24] 1444 	movx	a,@dptr
      00B4FC FB               [12] 1445 	mov	r3,a
      00B4FD 60 0C            [24] 1446 	jz	00123$
      00B4FF BB 03 02         [24] 1447 	cjne	r3,#0x03,00272$
      00B502 80 36            [24] 1448 	sjmp	00124$
      00B504                       1449 00272$:
      00B504 BB 04 03         [24] 1450 	cjne	r3,#0x04,00273$
      00B507 02 B5 A5         [24] 1451 	ljmp	00125$
      00B50A                       1452 00273$:
      00B50A 22               [24] 1453 	ret
                                   1454 ;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
      00B50B                       1455 00123$:
                                   1456 ;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
      00B50B 90 0C 70         [24] 1457 	mov	dptr,#_vial_fill_packet_PARM_2
      00B50E E4               [12] 1458 	clr	a
      00B50F F0               [24] 1459 	movx	@dptr,a
      00B510 12 43 D3         [24] 1460 	lcall	_ak820_outline_0002
      00B513 C0 07            [24] 1461 	push	ar7
      00B515 C0 06            [24] 1462 	push	ar6
      00B517 12 B1 CF         [24] 1463 	lcall	_vial_fill_packet
      00B51A D0 06            [24] 1464 	pop	ar6
      00B51C D0 07            [24] 1465 	pop	ar7
                                   1466 ;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B51E 12 43 D3         [24] 1467 	lcall	_ak820_outline_0002
      00B521 E4               [12] 1468 	clr	a
      00B522 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
      00B523 12 43 D3         [24] 1471 	lcall	_ak820_outline_0002
      00B526 A3               [24] 1472 	inc	dptr
      00B527 74 08            [12] 1473 	mov	a,#0x08
      00B529 F0               [24] 1474 	movx	@dptr,a
                                   1475 ;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B52A 12 43 D3         [24] 1476 	lcall	_ak820_outline_0002
      00B52D A3               [24] 1477 	inc	dptr
      00B52E A3               [24] 1478 	inc	dptr
      00B52F E4               [12] 1479 	clr	a
      00B530 F0               [24] 1480 	movx	@dptr,a
                                   1481 ;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B531 74 1F            [12] 1482 	mov	a,#0x1f
      00B533 12 43 FE         [24] 1483 	lcall	_ak820_outline_0015
      00B536 74 01            [12] 1484 	mov	a,#0x01
      00B538 F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	quantum/vial.c:328: break;
      00B539 22               [24] 1487 	ret
                                   1488 ;	quantum/vial.c:352: case dynamic_vial_combo_get: {
      00B53A                       1489 00124$:
                                   1490 ;	quantum/vial.c:353: uint8_t idx = msg[3];
      00B53A 12 43 D3         [24] 1491 	lcall	_ak820_outline_0002
      00B53D 12 B0 C5         [24] 1492 	lcall	_ak820_outline_0026
      00B540 FB               [12] 1493 	mov	r3,a
                                   1494 ;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
      00B541 90 0C 77         [24] 1495 	mov	dptr,#_vial_handle_cmd_entry_70000_638
      00B544 12 4E 8D         [24] 1496 	lcall	_ak820_outline_0098
      00B547 90 0C 79         [24] 1497 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0002)
      00B54A F0               [24] 1498 	movx	@dptr,a
      00B54B A3               [24] 1499 	inc	dptr
      00B54C F0               [24] 1500 	movx	@dptr,a
      00B54D 90 0C 7B         [24] 1501 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0004)
      00B550 F0               [24] 1502 	movx	@dptr,a
      00B551 A3               [24] 1503 	inc	dptr
      00B552 F0               [24] 1504 	movx	@dptr,a
      00B553 90 0C 7D         [24] 1505 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0006)
      00B556 F0               [24] 1506 	movx	@dptr,a
      00B557 A3               [24] 1507 	inc	dptr
      00B558 F0               [24] 1508 	movx	@dptr,a
      00B559 90 0C 7F         [24] 1509 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0008)
      00B55C F0               [24] 1510 	movx	@dptr,a
      00B55D A3               [24] 1511 	inc	dptr
      00B55E F0               [24] 1512 	movx	@dptr,a
                                   1513 ;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B55F 90 0A DD         [24] 1514 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B562 74 77            [12] 1515 	mov	a,#_vial_handle_cmd_entry_70000_638
      00B564 F0               [24] 1516 	movx	@dptr,a
      00B565 74 0C            [12] 1517 	mov	a,#(_vial_handle_cmd_entry_70000_638 >> 8)
      00B567 A3               [24] 1518 	inc	dptr
      00B568 12 4E 60         [24] 1519 	lcall	_ak820_outline_0003
      00B56B 8B 82            [24] 1520 	mov	dpl, r3
      00B56D C0 07            [24] 1521 	push	ar7
      00B56F C0 06            [24] 1522 	push	ar6
      00B571 C0 05            [24] 1523 	push	ar5
      00B573 C0 04            [24] 1524 	push	ar4
      00B575 12 85 F5         [24] 1525 	lcall	_dynamic_keymap_get_combo
      00B578 AA 82            [24] 1526 	mov	r2, dpl
      00B57A D0 04            [24] 1527 	pop	ar4
      00B57C D0 05            [24] 1528 	pop	ar5
      00B57E D0 06            [24] 1529 	pop	ar6
      00B580 D0 07            [24] 1530 	pop	ar7
      00B582 12 43 D3         [24] 1531 	lcall	_ak820_outline_0002
      00B585 EA               [12] 1532 	mov	a,r2
      00B586 F0               [24] 1533 	movx	@dptr,a
                                   1534 ;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
      00B587 7B 00            [12] 1535 	mov	r3,#0x00
      00B589 90 0D B3         [24] 1536 	mov	dptr,#___memcpy_PARM_2
      00B58C 74 77            [12] 1537 	mov	a,#_vial_handle_cmd_entry_70000_638
      00B58E F0               [24] 1538 	movx	@dptr,a
      00B58F 74 0C            [12] 1539 	mov	a,#(_vial_handle_cmd_entry_70000_638 >> 8)
      00B591 A3               [24] 1540 	inc	dptr
      00B592 12 4E 60         [24] 1541 	lcall	_ak820_outline_0003
      00B595 90 0D B6         [24] 1542 	mov	dptr,#___memcpy_PARM_3
      00B598 74 0A            [12] 1543 	mov	a,#0x0a
      00B59A 12 4E 60         [24] 1544 	lcall	_ak820_outline_0003
      00B59D 12 43 EF         [24] 1545 	lcall	_ak820_outline_0011
      00B5A0 8B F0            [24] 1546 	mov	b, r3
                                   1547 ;	quantum/vial.c:357: break;
      00B5A2 02 BD 3B         [24] 1548 	ljmp	___memcpy
                                   1549 ;	quantum/vial.c:359: case dynamic_vial_combo_set: {
      00B5A5                       1550 00125$:
                                   1551 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B5A5 12 43 D3         [24] 1552 	lcall	_ak820_outline_0002
      00B5A8 12 B0 C5         [24] 1553 	lcall	_ak820_outline_0026
      00B5AB FD               [12] 1554 	mov	r5,a
                                   1555 ;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
      00B5AC 74 04            [12] 1556 	mov	a,#0x04
      00B5AE 2E               [12] 1557 	add	a, r6
      00B5AF FB               [12] 1558 	mov	r3,a
      00B5B0 E4               [12] 1559 	clr	a
      00B5B1 3F               [12] 1560 	addc	a, r7
      00B5B2 FC               [12] 1561 	mov	r4,a
      00B5B3 90 0D B3         [24] 1562 	mov	dptr,#___memcpy_PARM_2
      00B5B6 EB               [12] 1563 	mov	a,r3
      00B5B7 F0               [24] 1564 	movx	@dptr,a
      00B5B8 EC               [12] 1565 	mov	a,r4
      00B5B9 A3               [24] 1566 	inc	dptr
      00B5BA 12 4E 60         [24] 1567 	lcall	_ak820_outline_0003
      00B5BD 90 0D B6         [24] 1568 	mov	dptr,#___memcpy_PARM_3
      00B5C0 74 0A            [12] 1569 	mov	a,#0x0a
      00B5C2 12 4E 60         [24] 1570 	lcall	_ak820_outline_0003
      00B5C5 90 0C 81         [24] 1571 	mov	dptr,#_vial_handle_cmd_entry_70000_639
      00B5C8 F5 F0            [12] 1572 	mov	b,a
      00B5CA C0 07            [24] 1573 	push	ar7
      00B5CC C0 06            [24] 1574 	push	ar6
      00B5CE C0 05            [24] 1575 	push	ar5
      00B5D0 12 BD 3B         [24] 1576 	lcall	___memcpy
                                   1577 ;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
      00B5D3 90 0C 89         [24] 1578 	mov	dptr,#(_vial_handle_cmd_entry_70000_639 + 0x0008)
      00B5D6 12 44 73         [24] 1579 	lcall	_ak820_outline_0089
      00B5D9 12 43 F9         [24] 1580 	lcall	_ak820_outline_0014
      00B5DC 12 B1 A9         [24] 1581 	lcall	_vial_keycode_firewall
      00B5DF AB 82            [24] 1582 	mov	r3, dpl
      00B5E1 AC 83            [24] 1583 	mov	r4, dph
      00B5E3 D0 05            [24] 1584 	pop	ar5
      00B5E5 90 0C 89         [24] 1585 	mov	dptr,#(_vial_handle_cmd_entry_70000_639 + 0x0008)
      00B5E8 12 44 50         [24] 1586 	lcall	_ak820_outline_0060
                                   1587 ;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B5EB 90 0A E1         [24] 1588 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B5EE 74 81            [12] 1589 	mov	a,#_vial_handle_cmd_entry_70000_639
      00B5F0 F0               [24] 1590 	movx	@dptr,a
      00B5F1 74 0C            [12] 1591 	mov	a,#(_vial_handle_cmd_entry_70000_639 >> 8)
      00B5F3 A3               [24] 1592 	inc	dptr
      00B5F4 12 4E 60         [24] 1593 	lcall	_ak820_outline_0003
      00B5F7 8D 82            [24] 1594 	mov	dpl, r5
      00B5F9 12 86 9D         [24] 1595 	lcall	_dynamic_keymap_set_combo
      00B5FC AC 82            [24] 1596 	mov	r4, dpl
      00B5FE D0 06            [24] 1597 	pop	ar6
      00B600 D0 07            [24] 1598 	pop	ar7
      00B602 12 43 D3         [24] 1599 	lcall	_ak820_outline_0002
      00B605 EC               [12] 1600 	mov	a,r4
      00B606 F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	quantum/vial.c:365: if (!msg[0]) reload_combo();
      00B607 EC               [12] 1603 	mov	a,r4
      00B608 70 03            [24] 1604 	jnz	00139$
                                   1605 ;	quantum/vial.c:391: }
                                   1606 ;	quantum/vial.c:392: }
      00B60A 02 36 2A         [24] 1607 	ljmp	_ak820_combo_reload
      00B60D                       1608 00139$:
      00B60D 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1612 ;------------------------------------------------------------
                                   1613 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_641'
                                   1614 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_648'
                                   1615 ;------------------------------------------------------------
                                   1616 ;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
                                   1617 ;	-----------------------------------------
                                   1618 ;	 function vial_keycode_down
                                   1619 ;	-----------------------------------------
      00B60E                       1620 _vial_keycode_down:
      00B60E 12 43 EA         [24] 1621 	lcall	_ak820_outline_0010
      00B611 90 0C 8D         [24] 1622 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B614 12 43 E5         [24] 1623 	lcall	_ak820_outline_0007
                                   1624 ;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B617 90 0C 8D         [24] 1625 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B61A 12 43 C5         [24] 1626 	lcall	_ak820_outline_0000
      00B61D 12 44 62         [24] 1627 	lcall	_ak820_outline_0073
      00B620 74 E0            [12] 1628 	mov	a,#0x100 - 0x20
      00B622 2D               [12] 1629 	add	a,r5
      00B623 50 19            [24] 1630 	jnc	00104$
      00B625 C3               [12] 1631 	clr	c
      00B626 74 FF            [12] 1632 	mov	a,#0xff
      00B628 9C               [12] 1633 	subb	a,r4
      00B629 74 4F            [12] 1634 	mov	a,#0x4f
      00B62B 9D               [12] 1635 	subb	a,r5
      00B62C 40 10            [24] 1636 	jc	00104$
                                   1637 ;	free result
                                   1638 ;	quantum/vial.c:401: keycode = (uint8_t)keycode;
      00B62E 90 0C 8D         [24] 1639 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B631 EE               [12] 1640 	mov	a,r6
      00B632 12 4E 60         [24] 1641 	lcall	_ak820_outline_0003
                                   1642 ;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
      00B635 90 0C 8D         [24] 1643 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B638 E0               [24] 1644 	movx	a,@dptr
      00B639 24 FE            [12] 1645 	add	a,#0xff - 0x01
      00B63B 40 01            [24] 1646 	jc	00104$
                                   1647 ;	free result
      00B63D 22               [24] 1648 	ret
      00B63E                       1649 00104$:
                                   1650 ;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
      00B63E 90 0C 8D         [24] 1651 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B641 12 43 C5         [24] 1652 	lcall	_ak820_outline_0000
      00B644 90 0C 8B         [24] 1653 	mov	dptr,#_g_vial_magic_keycode_override
      00B647 EE               [12] 1654 	mov	a,r6
      00B648 12 43 E5         [24] 1655 	lcall	_ak820_outline_0007
                                   1656 ;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
      00B64B 12 56 D7         [24] 1657 	lcall	_ak820_outline_0045
      00B64E 74 1F            [12] 1658 	mov	a,#0x1f
      00B650 9D               [12] 1659 	subb	a,r5
      00B651 40 06            [24] 1660 	jc	00107$
                                   1661 ;	free result
                                   1662 ;	quantum/vial.c:408: register_code16(keycode);
      00B653 12 43 D3         [24] 1663 	lcall	_ak820_outline_0002
      00B656 02 A0 D7         [24] 1664 	ljmp	_register_code16
      00B659                       1665 00107$:
                                   1666 ;	quantum/vial.c:410: keyevent_t dummy_event = {
      00B659 90 0C 93         [24] 1667 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0004)
      00B65C 74 01            [12] 1668 	mov	a,#0x01
      00B65E F0               [24] 1669 	movx	@dptr,a
      00B65F 90 0C 90         [24] 1670 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0001)
      00B662 74 F0            [12] 1671 	mov	a,#0xf0
      00B664 F0               [24] 1672 	movx	@dptr,a
      00B665 90 0C 8F         [24] 1673 	mov	dptr,#_vial_keycode_down_dummy_event_30000_648
      00B668 F0               [24] 1674 	movx	@dptr,a
      00B669 90 0C 94         [24] 1675 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0005)
      00B66C 74 01            [12] 1676 	mov	a,#0x01
      00B66E F0               [24] 1677 	movx	@dptr,a
      00B66F 12 48 CB         [24] 1678 	lcall	_timer_read
      00B672 12 44 1D         [24] 1679 	lcall	_ak820_outline_0027
      00B675 43 06 01         [24] 1680 	orl	ar6,#0x01
      00B678 90 0C 91         [24] 1681 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0002)
      00B67B EE               [12] 1682 	mov	a,r6
      00B67C 12 43 E5         [24] 1683 	lcall	_ak820_outline_0007
                                   1684 ;	quantum/vial.c:414: action_exec(dummy_event);
      00B67F 90 0D B3         [24] 1685 	mov	dptr,#___memcpy_PARM_2
      00B682 74 8F            [12] 1686 	mov	a,#_vial_keycode_down_dummy_event_30000_648
      00B684 F0               [24] 1687 	movx	@dptr,a
      00B685 74 0C            [12] 1688 	mov	a,#(_vial_keycode_down_dummy_event_30000_648 >> 8)
      00B687 A3               [24] 1689 	inc	dptr
      00B688 12 4E 60         [24] 1690 	lcall	_ak820_outline_0003
      00B68B 90 0D B6         [24] 1691 	mov	dptr,#___memcpy_PARM_3
      00B68E 74 06            [12] 1692 	mov	a,#0x06
      00B690 12 4E 60         [24] 1693 	lcall	_ak820_outline_0003
      00B693 90 08 07         [24] 1694 	mov	dptr,#_action_exec_PARM_1
      00B696 F5 F0            [12] 1695 	mov	b,a
      00B698 12 BD 3B         [24] 1696 	lcall	___memcpy
                                   1697 ;	quantum/vial.c:416: }
      00B69B 02 70 A5         [24] 1698 	ljmp	_action_exec
                                   1699 ;------------------------------------------------------------
                                   1700 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1701 ;------------------------------------------------------------
                                   1702 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_649'
                                   1703 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_656'
                                   1704 ;------------------------------------------------------------
                                   1705 ;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
                                   1706 ;	-----------------------------------------
                                   1707 ;	 function vial_keycode_up
                                   1708 ;	-----------------------------------------
      00B69E                       1709 _vial_keycode_up:
      00B69E 12 43 EA         [24] 1710 	lcall	_ak820_outline_0010
      00B6A1 90 0C 95         [24] 1711 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B6A4 12 43 E5         [24] 1712 	lcall	_ak820_outline_0007
                                   1713 ;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B6A7 90 0C 95         [24] 1714 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B6AA 12 43 C5         [24] 1715 	lcall	_ak820_outline_0000
      00B6AD 12 44 62         [24] 1716 	lcall	_ak820_outline_0073
      00B6B0 74 E0            [12] 1717 	mov	a,#0x100 - 0x20
      00B6B2 2D               [12] 1718 	add	a,r5
      00B6B3 50 19            [24] 1719 	jnc	00104$
      00B6B5 C3               [12] 1720 	clr	c
      00B6B6 74 FF            [12] 1721 	mov	a,#0xff
      00B6B8 9C               [12] 1722 	subb	a,r4
      00B6B9 74 4F            [12] 1723 	mov	a,#0x4f
      00B6BB 9D               [12] 1724 	subb	a,r5
      00B6BC 40 10            [24] 1725 	jc	00104$
                                   1726 ;	free result
                                   1727 ;	quantum/vial.c:423: keycode = (uint8_t)keycode;
      00B6BE 90 0C 95         [24] 1728 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B6C1 EE               [12] 1729 	mov	a,r6
      00B6C2 12 4E 60         [24] 1730 	lcall	_ak820_outline_0003
                                   1731 ;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
      00B6C5 90 0C 95         [24] 1732 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B6C8 E0               [24] 1733 	movx	a,@dptr
      00B6C9 24 FE            [12] 1734 	add	a,#0xff - 0x01
      00B6CB 40 01            [24] 1735 	jc	00104$
                                   1736 ;	free result
      00B6CD 22               [24] 1737 	ret
      00B6CE                       1738 00104$:
                                   1739 ;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
      00B6CE 90 0C 95         [24] 1740 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B6D1 12 43 C5         [24] 1741 	lcall	_ak820_outline_0000
      00B6D4 90 0C 8B         [24] 1742 	mov	dptr,#_g_vial_magic_keycode_override
      00B6D7 EE               [12] 1743 	mov	a,r6
      00B6D8 12 43 E5         [24] 1744 	lcall	_ak820_outline_0007
                                   1745 ;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
      00B6DB 12 56 D7         [24] 1746 	lcall	_ak820_outline_0045
      00B6DE 74 1F            [12] 1747 	mov	a,#0x1f
      00B6E0 9D               [12] 1748 	subb	a,r5
      00B6E1 40 06            [24] 1749 	jc	00107$
                                   1750 ;	free result
                                   1751 ;	quantum/vial.c:430: unregister_code16(keycode);
      00B6E3 12 43 D3         [24] 1752 	lcall	_ak820_outline_0002
      00B6E6 02 A1 1F         [24] 1753 	ljmp	_unregister_code16
      00B6E9                       1754 00107$:
                                   1755 ;	quantum/vial.c:432: keyevent_t dummy_event = {
      00B6E9 90 0C 9B         [24] 1756 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0004)
      00B6EC 74 01            [12] 1757 	mov	a,#0x01
      00B6EE F0               [24] 1758 	movx	@dptr,a
      00B6EF 90 0C 98         [24] 1759 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0001)
      00B6F2 74 F0            [12] 1760 	mov	a,#0xf0
      00B6F4 F0               [24] 1761 	movx	@dptr,a
      00B6F5 90 0C 97         [24] 1762 	mov	dptr,#_vial_keycode_up_dummy_event_30000_656
      00B6F8 F0               [24] 1763 	movx	@dptr,a
      00B6F9 90 0C 9C         [24] 1764 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0005)
      00B6FC E4               [12] 1765 	clr	a
      00B6FD F0               [24] 1766 	movx	@dptr,a
      00B6FE 12 48 CB         [24] 1767 	lcall	_timer_read
      00B701 12 44 1D         [24] 1768 	lcall	_ak820_outline_0027
      00B704 43 06 01         [24] 1769 	orl	ar6,#0x01
      00B707 90 0C 99         [24] 1770 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0002)
      00B70A EE               [12] 1771 	mov	a,r6
      00B70B 12 43 E5         [24] 1772 	lcall	_ak820_outline_0007
                                   1773 ;	quantum/vial.c:436: action_exec(dummy_event);
      00B70E 90 0D B3         [24] 1774 	mov	dptr,#___memcpy_PARM_2
      00B711 74 97            [12] 1775 	mov	a,#_vial_keycode_up_dummy_event_30000_656
      00B713 F0               [24] 1776 	movx	@dptr,a
      00B714 74 0C            [12] 1777 	mov	a,#(_vial_keycode_up_dummy_event_30000_656 >> 8)
      00B716 A3               [24] 1778 	inc	dptr
      00B717 12 4E 60         [24] 1779 	lcall	_ak820_outline_0003
      00B71A 90 0D B6         [24] 1780 	mov	dptr,#___memcpy_PARM_3
      00B71D 74 06            [12] 1781 	mov	a,#0x06
      00B71F 12 4E 60         [24] 1782 	lcall	_ak820_outline_0003
      00B722 90 08 07         [24] 1783 	mov	dptr,#_action_exec_PARM_1
      00B725 F5 F0            [12] 1784 	mov	b,a
      00B727 12 BD 3B         [24] 1785 	lcall	___memcpy
                                   1786 ;	quantum/vial.c:438: }
      00B72A 02 70 A5         [24] 1787 	ljmp	_action_exec
                                   1788 ;------------------------------------------------------------
                                   1789 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1790 ;------------------------------------------------------------
                                   1791 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_657'
                                   1792 ;i             Allocated with name '_vial_keycode_tap_i_30000_660'
                                   1793 ;------------------------------------------------------------
                                   1794 ;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
                                   1795 ;	-----------------------------------------
                                   1796 ;	 function vial_keycode_tap
                                   1797 ;	-----------------------------------------
      00B72D                       1798 _vial_keycode_tap:
      00B72D 12 43 EA         [24] 1799 	lcall	_ak820_outline_0010
      00B730 90 0C 9D         [24] 1800 	mov	dptr,#_vial_keycode_tap_keycode_10000_657
      00B733 12 43 E5         [24] 1801 	lcall	_ak820_outline_0007
                                   1802 ;	quantum/vial.c:441: vial_keycode_down(keycode);
      00B736 90 0C 9D         [24] 1803 	mov	dptr,#_vial_keycode_tap_keycode_10000_657
      00B739 12 43 C5         [24] 1804 	lcall	_ak820_outline_0000
      00B73C 12 43 D3         [24] 1805 	lcall	_ak820_outline_0002
      00B73F C0 07            [24] 1806 	push	ar7
      00B741 C0 06            [24] 1807 	push	ar6
      00B743 12 B6 0E         [24] 1808 	lcall	_vial_keycode_down
      00B746 D0 06            [24] 1809 	pop	ar6
      00B748 D0 07            [24] 1810 	pop	ar7
                                   1811 ;	quantum/vial.c:443: vial_keycode_up(keycode);
      00B74A 12 43 D3         [24] 1812 	lcall	_ak820_outline_0002
                                   1813 ;	quantum/vial.c:444: }
      00B74D 02 B6 9E         [24] 1814 	ljmp	_vial_keycode_up
                                   1815 ;------------------------------------------------------------
                                   1816 ;Allocation info for local variables in function 'process_record_vial'
                                   1817 ;------------------------------------------------------------
                                   1818 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1819 ;keycode       Allocated with name '_process_record_vial_keycode_10000_662'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1822 ;	-----------------------------------------
                                   1823 	.area CSEG    (CODE)
                                   1824 	.area CONST   (CODE)
                                   1825 	.area CONST   (CODE)
      00C2BE                       1826 _keyboard_definition:
      00C2BE FD                    1827 	.db #0xfd	; 253
      00C2BF 37                    1828 	.db #0x37	; 55	'7'
      00C2C0 7A                    1829 	.db #0x7a	; 122	'z'
      00C2C1 58                    1830 	.db #0x58	; 88	'X'
      00C2C2 5A                    1831 	.db #0x5a	; 90	'Z'
      00C2C3 00                    1832 	.db #0x00	; 0
      00C2C4 00                    1833 	.db #0x00	; 0
      00C2C5 04                    1834 	.db #0x04	; 4
      00C2C6 E6                    1835 	.db #0xe6	; 230
      00C2C7 D6                    1836 	.db #0xd6	; 214
      00C2C8 B4                    1837 	.db #0xb4	; 180
      00C2C9 46                    1838 	.db #0x46	; 70	'F'
      00C2CA 02                    1839 	.db #0x02	; 2
      00C2CB 00                    1840 	.db #0x00	; 0
      00C2CC 21                    1841 	.db #0x21	; 33
      00C2CD 01                    1842 	.db #0x01	; 1
      00C2CE 00                    1843 	.db #0x00	; 0
      00C2CF 00                    1844 	.db #0x00	; 0
      00C2D0 00                    1845 	.db #0x00	; 0
      00C2D1 00                    1846 	.db #0x00	; 0
      00C2D2 37                    1847 	.db #0x37	; 55	'7'
      00C2D3 27                    1848 	.db #0x27	; 39
      00C2D4 97                    1849 	.db #0x97	; 151
      00C2D5 D6                    1850 	.db #0xd6	; 214
      00C2D6 E0                    1851 	.db #0xe0	; 224
      00C2D7 03                    1852 	.db #0x03	; 3
      00C2D8 CB                    1853 	.db #0xcb	; 203
      00C2D9 01                    1854 	.db #0x01	; 1
      00C2DA 3C                    1855 	.db #0x3c	; 60
      00C2DB 00                    1856 	.db #0x00	; 0
      00C2DC 00                    1857 	.db #0x00	; 0
      00C2DD 3D                    1858 	.db #0x3d	; 61
      00C2DE 88                    1859 	.db #0x88	; 136
      00C2DF CD                    1860 	.db #0xcd	; 205
      00C2E0 A5                    1861 	.db #0xa5	; 165
      00C2E1 AA                    1862 	.db #0xaa	; 170
      00C2E2 E5                    1863 	.db #0xe5	; 229
      00C2E3 A8                    1864 	.db #0xa8	; 168
      00C2E4 76                    1865 	.db #0x76	; 118	'v'
      00C2E5 F6                    1866 	.db #0xf6	; 246
      00C2E6 43                    1867 	.db #0x43	; 67	'C'
      00C2E7 0E                    1868 	.db #0x0e	; 14
      00C2E8 D2                    1869 	.db #0xd2	; 210
      00C2E9 90                    1870 	.db #0x90	; 144
      00C2EA 7D                    1871 	.db #0x7d	; 125
      00C2EB 94                    1872 	.db #0x94	; 148
      00C2EC 79                    1873 	.db #0x79	; 121	'y'
      00C2ED 78                    1874 	.db #0x78	; 120	'x'
      00C2EE EF                    1875 	.db #0xef	; 239
      00C2EF 49                    1876 	.db #0x49	; 73	'I'
      00C2F0 3E                    1877 	.db #0x3e	; 62
      00C2F1 EF                    1878 	.db #0xef	; 239
      00C2F2 FD                    1879 	.db #0xfd	; 253
      00C2F3 8F                    1880 	.db #0x8f	; 143
      00C2F4 EF                    1881 	.db #0xef	; 239
      00C2F5 00                    1882 	.db #0x00	; 0
      00C2F6 C6                    1883 	.db #0xc6	; 198
      00C2F7 D1                    1884 	.db #0xd1	; 209
      00C2F8 DB                    1885 	.db #0xdb	; 219
      00C2F9 FB                    1886 	.db #0xfb	; 251
      00C2FA EB                    1887 	.db #0xeb	; 235
      00C2FB DE                    1888 	.db #0xde	; 222
      00C2FC 66                    1889 	.db #0x66	; 102	'f'
      00C2FD 63                    1890 	.db #0x63	; 99	'c'
      00C2FE 0C                    1891 	.db #0x0c	; 12
      00C2FF 92                    1892 	.db #0x92	; 146
      00C300 7B                    1893 	.db #0x7b	; 123
      00C301 F9                    1894 	.db #0xf9	; 249
      00C302 D4                    1895 	.db #0xd4	; 212
      00C303 7A                    1896 	.db #0x7a	; 122	'z'
      00C304 4F                    1897 	.db #0x4f	; 79	'O'
      00C305 83                    1898 	.db #0x83	; 131
      00C306 4B                    1899 	.db #0x4b	; 75	'K'
      00C307 86                    1900 	.db #0x86	; 134
      00C308 0E                    1901 	.db #0x0e	; 14
      00C309 6A                    1902 	.db #0x6a	; 106	'j'
      00C30A F2                    1903 	.db #0xf2	; 242
      00C30B 22                    1904 	.db #0x22	; 34
      00C30C 22                    1905 	.db #0x22	; 34
      00C30D 0B                    1906 	.db #0x0b	; 11
      00C30E 03                    1907 	.db #0x03	; 3
      00C30F BA                    1908 	.db #0xba	; 186
      00C310 67                    1909 	.db #0x67	; 103	'g'
      00C311 9B                    1910 	.db #0x9b	; 155
      00C312 7A                    1911 	.db #0x7a	; 122	'z'
      00C313 E1                    1912 	.db #0xe1	; 225
      00C314 BC                    1913 	.db #0xbc	; 188
      00C315 37                    1914 	.db #0x37	; 55	'7'
      00C316 26                    1915 	.db #0x26	; 38
      00C317 46                    1916 	.db #0x46	; 70	'F'
      00C318 78                    1917 	.db #0x78	; 120	'x'
      00C319 05                    1918 	.db #0x05	; 5
      00C31A 0D                    1919 	.db #0x0d	; 13
      00C31B 95                    1920 	.db #0x95	; 149
      00C31C 02                    1921 	.db #0x02	; 2
      00C31D E4                    1922 	.db #0xe4	; 228
      00C31E 18                    1923 	.db #0x18	; 24
      00C31F CA                    1924 	.db #0xca	; 202
      00C320 33                    1925 	.db #0x33	; 51	'3'
      00C321 EA                    1926 	.db #0xea	; 234
      00C322 24                    1927 	.db #0x24	; 36
      00C323 C8                    1928 	.db #0xc8	; 200
      00C324 81                    1929 	.db #0x81	; 129
      00C325 4E                    1930 	.db #0x4e	; 78	'N'
      00C326 47                    1931 	.db #0x47	; 71	'G'
      00C327 A8                    1932 	.db #0xa8	; 168
      00C328 44                    1933 	.db #0x44	; 68	'D'
      00C329 DD                    1934 	.db #0xdd	; 221
      00C32A 91                    1935 	.db #0x91	; 145
      00C32B 6D                    1936 	.db #0x6d	; 109	'm'
      00C32C 69                    1937 	.db #0x69	; 105	'i'
      00C32D DB                    1938 	.db #0xdb	; 219
      00C32E 4F                    1939 	.db #0x4f	; 79	'O'
      00C32F 3A                    1940 	.db #0x3a	; 58
      00C330 43                    1941 	.db #0x43	; 67	'C'
      00C331 9D                    1942 	.db #0x9d	; 157
      00C332 26                    1943 	.db #0x26	; 38
      00C333 49                    1944 	.db #0x49	; 73	'I'
      00C334 4C                    1945 	.db #0x4c	; 76	'L'
      00C335 EF                    1946 	.db #0xef	; 239
      00C336 2B                    1947 	.db #0x2b	; 43
      00C337 D8                    1948 	.db #0xd8	; 216
      00C338 55                    1949 	.db #0x55	; 85	'U'
      00C339 95                    1950 	.db #0x95	; 149
      00C33A 70                    1951 	.db #0x70	; 112	'p'
      00C33B B1                    1952 	.db #0xb1	; 177
      00C33C CC                    1953 	.db #0xcc	; 204
      00C33D CF                    1954 	.db #0xcf	; 207
      00C33E 13                    1955 	.db #0x13	; 19
      00C33F 32                    1956 	.db #0x32	; 50	'2'
      00C340 6A                    1957 	.db #0x6a	; 106	'j'
      00C341 A1                    1958 	.db #0xa1	; 161
      00C342 FF                    1959 	.db #0xff	; 255
      00C343 99                    1960 	.db #0x99	; 153
      00C344 61                    1961 	.db #0x61	; 97	'a'
      00C345 95                    1962 	.db #0x95	; 149
      00C346 B1                    1963 	.db #0xb1	; 177
      00C347 89                    1964 	.db #0x89	; 137
      00C348 9B                    1965 	.db #0x9b	; 155
      00C349 11                    1966 	.db #0x11	; 17
      00C34A D9                    1967 	.db #0xd9	; 217
      00C34B 35                    1968 	.db #0x35	; 53	'5'
      00C34C 78                    1969 	.db #0x78	; 120	'x'
      00C34D ED                    1970 	.db #0xed	; 237
      00C34E CD                    1971 	.db #0xcd	; 205
      00C34F 94                    1972 	.db #0x94	; 148
      00C350 6E                    1973 	.db #0x6e	; 110	'n'
      00C351 60                    1974 	.db #0x60	; 96
      00C352 8E                    1975 	.db #0x8e	; 142
      00C353 63                    1976 	.db #0x63	; 99	'c'
      00C354 8B                    1977 	.db #0x8b	; 139
      00C355 FF                    1978 	.db #0xff	; 255
      00C356 4E                    1979 	.db #0x4e	; 78	'N'
      00C357 20                    1980 	.db #0x20	; 32
      00C358 7A                    1981 	.db #0x7a	; 122	'z'
      00C359 B5                    1982 	.db #0xb5	; 181
      00C35A 87                    1983 	.db #0x87	; 135
      00C35B C2                    1984 	.db #0xc2	; 194
      00C35C 35                    1985 	.db #0x35	; 53	'5'
      00C35D A4                    1986 	.db #0xa4	; 164
      00C35E 6D                    1987 	.db #0x6d	; 109	'm'
      00C35F 18                    1988 	.db #0x18	; 24
      00C360 C1                    1989 	.db #0xc1	; 193
      00C361 A3                    1990 	.db #0xa3	; 163
      00C362 DB                    1991 	.db #0xdb	; 219
      00C363 53                    1992 	.db #0x53	; 83	'S'
      00C364 1D                    1993 	.db #0x1d	; 29
      00C365 EC                    1994 	.db #0xec	; 236
      00C366 F0                    1995 	.db #0xf0	; 240
      00C367 BF                    1996 	.db #0xbf	; 191
      00C368 4A                    1997 	.db #0x4a	; 74	'J'
      00C369 4C                    1998 	.db #0x4c	; 76	'L'
      00C36A 4A                    1999 	.db #0x4a	; 74	'J'
      00C36B C4                    2000 	.db #0xc4	; 196
      00C36C AA                    2001 	.db #0xaa	; 170
      00C36D 37                    2002 	.db #0x37	; 55	'7'
      00C36E 19                    2003 	.db #0x19	; 25
      00C36F 34                    2004 	.db #0x34	; 52	'4'
      00C370 3F                    2005 	.db #0x3f	; 63
      00C371 A1                    2006 	.db #0xa1	; 161
      00C372 D3                    2007 	.db #0xd3	; 211
      00C373 1A                    2008 	.db #0x1a	; 26
      00C374 5C                    2009 	.db #0x5c	; 92
      00C375 03                    2010 	.db #0x03	; 3
      00C376 4D                    2011 	.db #0x4d	; 77	'M'
      00C377 BC                    2012 	.db #0xbc	; 188
      00C378 10                    2013 	.db #0x10	; 16
      00C379 2E                    2014 	.db #0x2e	; 46
      00C37A 80                    2015 	.db #0x80	; 128
      00C37B F7                    2016 	.db #0xf7	; 247
      00C37C D6                    2017 	.db #0xd6	; 214
      00C37D 82                    2018 	.db #0x82	; 130
      00C37E 24                    2019 	.db #0x24	; 36
      00C37F 4C                    2020 	.db #0x4c	; 76	'L'
      00C380 87                    2021 	.db #0x87	; 135
      00C381 B9                    2022 	.db #0xb9	; 185
      00C382 F8                    2023 	.db #0xf8	; 248
      00C383 BE                    2024 	.db #0xbe	; 190
      00C384 67                    2025 	.db #0x67	; 103	'g'
      00C385 96                    2026 	.db #0x96	; 150
      00C386 89                    2027 	.db #0x89	; 137
      00C387 30                    2028 	.db #0x30	; 48	'0'
      00C388 C8                    2029 	.db #0xc8	; 200
      00C389 8D                    2030 	.db #0x8d	; 141
      00C38A 2C                    2031 	.db #0x2c	; 44
      00C38B F5                    2032 	.db #0xf5	; 245
      00C38C 06                    2033 	.db #0x06	; 6
      00C38D 05                    2034 	.db #0x05	; 5
      00C38E 7C                    2035 	.db #0x7c	; 124
      00C38F 48                    2036 	.db #0x48	; 72	'H'
      00C390 1B                    2037 	.db #0x1b	; 27
      00C391 76                    2038 	.db #0x76	; 118	'v'
      00C392 AA                    2039 	.db #0xaa	; 170
      00C393 3D                    2040 	.db #0x3d	; 61
      00C394 28                    2041 	.db #0x28	; 40
      00C395 FC                    2042 	.db #0xfc	; 252
      00C396 80                    2043 	.db #0x80	; 128
      00C397 75                    2044 	.db #0x75	; 117	'u'
      00C398 EB                    2045 	.db #0xeb	; 235
      00C399 78                    2046 	.db #0x78	; 120	'x'
      00C39A D0                    2047 	.db #0xd0	; 208
      00C39B 8A                    2048 	.db #0x8a	; 138
      00C39C 8F                    2049 	.db #0x8f	; 143
      00C39D 27                    2050 	.db #0x27	; 39
      00C39E F7                    2051 	.db #0xf7	; 247
      00C39F F2                    2052 	.db #0xf2	; 242
      00C3A0 EB                    2053 	.db #0xeb	; 235
      00C3A1 58                    2054 	.db #0x58	; 88	'X'
      00C3A2 37                    2055 	.db #0x37	; 55	'7'
      00C3A3 3C                    2056 	.db #0x3c	; 60
      00C3A4 2B                    2057 	.db #0x2b	; 43
      00C3A5 6F                    2058 	.db #0x6f	; 111	'o'
      00C3A6 0E                    2059 	.db #0x0e	; 14
      00C3A7 C7                    2060 	.db #0xc7	; 199
      00C3A8 E2                    2061 	.db #0xe2	; 226
      00C3A9 A0                    2062 	.db #0xa0	; 160
      00C3AA 97                    2063 	.db #0x97	; 151
      00C3AB EE                    2064 	.db #0xee	; 238
      00C3AC FD                    2065 	.db #0xfd	; 253
      00C3AD 9F                    2066 	.db #0x9f	; 159
      00C3AE 45                    2067 	.db #0x45	; 69	'E'
      00C3AF 17                    2068 	.db #0x17	; 23
      00C3B0 94                    2069 	.db #0x94	; 148
      00C3B1 E6                    2070 	.db #0xe6	; 230
      00C3B2 E7                    2071 	.db #0xe7	; 231
      00C3B3 FA                    2072 	.db #0xfa	; 250
      00C3B4 4C                    2073 	.db #0x4c	; 76	'L'
      00C3B5 7A                    2074 	.db #0x7a	; 122	'z'
      00C3B6 D6                    2075 	.db #0xd6	; 214
      00C3B7 7A                    2076 	.db #0x7a	; 122	'z'
      00C3B8 7B                    2077 	.db #0x7b	; 123
      00C3B9 ED                    2078 	.db #0xed	; 237
      00C3BA 10                    2079 	.db #0x10	; 16
      00C3BB C5                    2080 	.db #0xc5	; 197
      00C3BC BC                    2081 	.db #0xbc	; 188
      00C3BD E3                    2082 	.db #0xe3	; 227
      00C3BE A9                    2083 	.db #0xa9	; 169
      00C3BF 1F                    2084 	.db #0x1f	; 31
      00C3C0 CF                    2085 	.db #0xcf	; 207
      00C3C1 C4                    2086 	.db #0xc4	; 196
      00C3C2 9D                    2087 	.db #0x9d	; 157
      00C3C3 DC                    2088 	.db #0xdc	; 220
      00C3C4 45                    2089 	.db #0x45	; 69	'E'
      00C3C5 2A                    2090 	.db #0x2a	; 42
      00C3C6 69                    2091 	.db #0x69	; 105	'i'
      00C3C7 57                    2092 	.db #0x57	; 87	'W'
      00C3C8 8F                    2093 	.db #0x8f	; 143
      00C3C9 EC                    2094 	.db #0xec	; 236
      00C3CA 85                    2095 	.db #0x85	; 133
      00C3CB 6C                    2096 	.db #0x6c	; 108	'l'
      00C3CC 43                    2097 	.db #0x43	; 67	'C'
      00C3CD 1C                    2098 	.db #0x1c	; 28
      00C3CE BA                    2099 	.db #0xba	; 186
      00C3CF 89                    2100 	.db #0x89	; 137
      00C3D0 68                    2101 	.db #0x68	; 104	'h'
      00C3D1 4A                    2102 	.db #0x4a	; 74	'J'
      00C3D2 1C                    2103 	.db #0x1c	; 28
      00C3D3 91                    2104 	.db #0x91	; 145
      00C3D4 3F                    2105 	.db #0x3f	; 63
      00C3D5 D1                    2106 	.db #0xd1	; 209
      00C3D6 B3                    2107 	.db #0xb3	; 179
      00C3D7 96                    2108 	.db #0x96	; 150
      00C3D8 1D                    2109 	.db #0x1d	; 29
      00C3D9 7C                    2110 	.db #0x7c	; 124
      00C3DA 14                    2111 	.db #0x14	; 20
      00C3DB 77                    2112 	.db #0x77	; 119	'w'
      00C3DC 9C                    2113 	.db #0x9c	; 156
      00C3DD 74                    2114 	.db #0x74	; 116	't'
      00C3DE 36                    2115 	.db #0x36	; 54	'6'
      00C3DF FF                    2116 	.db #0xff	; 255
      00C3E0 2C                    2117 	.db #0x2c	; 44
      00C3E1 66                    2118 	.db #0x66	; 102	'f'
      00C3E2 AF                    2119 	.db #0xaf	; 175
      00C3E3 0F                    2120 	.db #0x0f	; 15
      00C3E4 3C                    2121 	.db #0x3c	; 60
      00C3E5 A2                    2122 	.db #0xa2	; 162
      00C3E6 23                    2123 	.db #0x23	; 35
      00C3E7 85                    2124 	.db #0x85	; 133
      00C3E8 05                    2125 	.db #0x05	; 5
      00C3E9 87                    2126 	.db #0x87	; 135
      00C3EA DA                    2127 	.db #0xda	; 218
      00C3EB 61                    2128 	.db #0x61	; 97	'a'
      00C3EC 5E                    2129 	.db #0x5e	; 94
      00C3ED 42                    2130 	.db #0x42	; 66	'B'
      00C3EE 54                    2131 	.db #0x54	; 84	'T'
      00C3EF 60                    2132 	.db #0x60	; 96
      00C3F0 23                    2133 	.db #0x23	; 35
      00C3F1 CA                    2134 	.db #0xca	; 202
      00C3F2 BC                    2135 	.db #0xbc	; 188
      00C3F3 B3                    2136 	.db #0xb3	; 179
      00C3F4 18                    2137 	.db #0x18	; 24
      00C3F5 1D                    2138 	.db #0x1d	; 29
      00C3F6 F8                    2139 	.db #0xf8	; 248
      00C3F7 0A                    2140 	.db #0x0a	; 10
      00C3F8 55                    2141 	.db #0x55	; 85	'U'
      00C3F9 CD                    2142 	.db #0xcd	; 205
      00C3FA A3                    2143 	.db #0xa3	; 163
      00C3FB DE                    2144 	.db #0xde	; 222
      00C3FC FF                    2145 	.db #0xff	; 255
      00C3FD B2                    2146 	.db #0xb2	; 178
      00C3FE 2A                    2147 	.db #0x2a	; 42
      00C3FF 35                    2148 	.db #0x35	; 53	'5'
      00C400 00                    2149 	.db #0x00	; 0
      00C401 D6                    2150 	.db #0xd6	; 214
      00C402 7B                    2151 	.db #0x7b	; 123
      00C403 E8                    2152 	.db #0xe8	; 232
      00C404 F2                    2153 	.db #0xf2	; 242
      00C405 1A                    2154 	.db #0x1a	; 26
      00C406 BC                    2155 	.db #0xbc	; 188
      00C407 F5                    2156 	.db #0xf5	; 245
      00C408 7E                    2157 	.db #0x7e	; 126
      00C409 48                    2158 	.db #0x48	; 72	'H'
      00C40A 72                    2159 	.db #0x72	; 114	'r'
      00C40B E0                    2160 	.db #0xe0	; 224
      00C40C E4                    2161 	.db #0xe4	; 228
      00C40D E0                    2162 	.db #0xe0	; 224
      00C40E 27                    2163 	.db #0x27	; 39
      00C40F 87                    2164 	.db #0x87	; 135
      00C410 9A                    2165 	.db #0x9a	; 154
      00C411 51                    2166 	.db #0x51	; 81	'Q'
      00C412 D4                    2167 	.db #0xd4	; 212
      00C413 DD                    2168 	.db #0xdd	; 221
      00C414 C3                    2169 	.db #0xc3	; 195
      00C415 AA                    2170 	.db #0xaa	; 170
      00C416 49                    2171 	.db #0x49	; 73	'I'
      00C417 5A                    2172 	.db #0x5a	; 90	'Z'
      00C418 2A                    2173 	.db #0x2a	; 42
      00C419 00                    2174 	.db #0x00	; 0
      00C41A A0                    2175 	.db #0xa0	; 160
      00C41B 8C                    2176 	.db #0x8c	; 140
      00C41C FF                    2177 	.db #0xff	; 255
      00C41D 74                    2178 	.db #0x74	; 116	't'
      00C41E BF                    2179 	.db #0xbf	; 191
      00C41F EC                    2180 	.db #0xec	; 236
      00C420 1D                    2181 	.db #0x1d	; 29
      00C421 F1                    2182 	.db #0xf1	; 241
      00C422 00                    2183 	.db #0x00	; 0
      00C423 01                    2184 	.db #0x01	; 1
      00C424 D8                    2185 	.db #0xd8	; 216
      00C425 02                    2186 	.db #0x02	; 2
      00C426 CC                    2187 	.db #0xcc	; 204
      00C427 07                    2188 	.db #0x07	; 7
      00C428 00                    2189 	.db #0x00	; 0
      00C429 00                    2190 	.db #0x00	; 0
      00C42A C4                    2191 	.db #0xc4	; 196
      00C42B 5E                    2192 	.db #0x5e	; 94
      00C42C 2C                    2193 	.db #0x2c	; 44
      00C42D 7E                    2194 	.db #0x7e	; 126
      00C42E B1                    2195 	.db #0xb1	; 177
      00C42F C4                    2196 	.db #0xc4	; 196
      00C430 67                    2197 	.db #0x67	; 103	'g'
      00C431 FB                    2198 	.db #0xfb	; 251
      00C432 02                    2199 	.db #0x02	; 2
      00C433 00                    2200 	.db #0x00	; 0
      00C434 00                    2201 	.db #0x00	; 0
      00C435 00                    2202 	.db #0x00	; 0
      00C436 00                    2203 	.db #0x00	; 0
      00C437 04                    2204 	.db #0x04	; 4
      00C438 59                    2205 	.db #0x59	; 89	'Y'
      00C439 5A                    2206 	.db #0x5a	; 90	'Z'
                                   2207 	.area CSEG    (CODE)
                                   2208 	.area CONST   (CODE)
      00C43A                       2209 _vial_handle_cmd_keyboard_uid_40000_615:
      00C43A 04                    2210 	.db #0x04	; 4
      00C43B 70                    2211 	.db #0x70	; 112	'p'
      00C43C FF                    2212 	.db #0xff	; 255
      00C43D 90                    2213 	.db #0x90	; 144
      00C43E 01                    2214 	.db #0x01	; 1
      00C43F B9                    2215 	.db #0xb9	; 185
      00C440 15                    2216 	.db #0x15	; 21
      00C441 D3                    2217 	.db #0xd3	; 211
                                   2218 	.area CSEG    (CODE)
                                   2219 	.area XINIT   (CODE)
      00C67D                       2220 __xinit__vial_unlocked:
      00C67D 00                    2221 	.db #0x00	;  0
      00C67E                       2222 __xinit__vial_unlock_in_progress:
      00C67E 00                    2223 	.db #0x00	;  0
      00C67F                       2224 __xinit__vial_unlock_counter:
      00C67F 00                    2225 	.db #0x00	; 0
      00C680                       2226 __xinit__vial_unlock_combo_rows:
      00C680 00                    2227 	.db #0x00	; 0
      00C681 00                    2228 	.db #0x00	; 0
      00C682                       2229 __xinit__vial_unlock_combo_cols:
      00C682 00                    2230 	.db #0x00	; 0
      00C683 05                    2231 	.db #0x05	; 5
                                   2232 	.area CABS    (ABS,CODE)
                                   2233 
                                   2234 ; Experimental exact instruction outlining.
                                   2235 	.globl _ak820_outline_0000
                                   2236 	.globl _ak820_outline_0001
                                   2237 	.globl _ak820_outline_0002
                                   2238 	.globl _ak820_outline_0003
                                   2239 	.globl _ak820_outline_0004
                                   2240 	.globl _ak820_outline_0006
                                   2241 	.globl _ak820_outline_0007
                                   2242 	.globl _ak820_outline_0010
                                   2243 	.globl _ak820_outline_0011
                                   2244 	.globl _ak820_outline_0014
                                   2245 	.globl _ak820_outline_0015
                                   2246 	.globl _ak820_outline_0016
                                   2247 	.globl _ak820_outline_0026
                                   2248 	.globl _ak820_outline_0027
                                   2249 	.globl _ak820_outline_0033
                                   2250 	.globl _ak820_outline_0041
                                   2251 	.globl _ak820_outline_0043
                                   2252 	.globl _ak820_outline_0045
                                   2253 	.globl _ak820_outline_0060
                                   2254 	.globl _ak820_outline_0073
                                   2255 	.globl _ak820_outline_0089
                                   2256 	.globl _ak820_outline_0091
                                   2257 	.globl _ak820_outline_0093
                                   2258 	.globl _ak820_outline_0094
                                   2259 	.globl _ak820_outline_0098
                                   2260 	.globl _ak820_outline_0100
                                   2261 	.globl _ak820_outline_0118
                                   2262 	.globl _ak820_outline_0149
                                   2263 
                                   2264 	.area CSEG (CODE)
                                   2265 ; function ak820_outline_0093
      00B750                       2266 _ak820_outline_0093:
      00B750 24 37            [12] 2267 	add	a,#_vial_unlock_combo_cols
      00B752 F5 82            [12] 2268 	mov	dpl,a
      00B754 E4               [12] 2269 	clr	a
      00B755 34 0E            [12] 2270 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B757 F5 83            [12] 2271 	mov	dph,a
      00B759 E0               [24] 2272 	movx	a,@dptr
      00B75A 22               [24] 2273 	ret
                                   2274 
                                   2275 	.area CSEG (CODE)
                                   2276 ; function ak820_outline_0094
      00B75B                       2277 _ak820_outline_0094:
      00B75B 24 35            [12] 2278 	add	a,#_vial_unlock_combo_rows
      00B75D F5 82            [12] 2279 	mov	dpl,a
      00B75F E4               [12] 2280 	clr	a
      00B760 34 0E            [12] 2281 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B762 F5 83            [12] 2282 	mov	dph,a
      00B764 E0               [24] 2283 	movx	a,@dptr
      00B765 22               [24] 2284 	ret
