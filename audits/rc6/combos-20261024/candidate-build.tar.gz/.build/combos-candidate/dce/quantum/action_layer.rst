                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _keymap_key_to_keycode
                                     14 	.globl _action_for_keycode
                                     15 	.globl _action_for_key
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _layer_state
                                    260 	.globl _default_layer_state
                                    261 	.globl _layer_switch_get_action_PARM_1
                                    262 	.globl _layer_switch_get_layer_PARM_1
                                    263 	.globl _store_or_get_action_PARM_2
                                    264 	.globl _read_source_keycode_cache_PARM_1
                                    265 	.globl _update_source_layers_cache_PARM_1
                                    266 	.globl _update_source_keycode_cache_PARM_1
                                    267 	.globl _default_layer_state_set_user
                                    268 	.globl _default_layer_state_set_kb
                                    269 	.globl _default_layer_set
                                    270 	.globl _default_layer_or
                                    271 	.globl _default_layer_and
                                    272 	.globl _default_layer_xor
                                    273 	.globl _ak820_layer_refresh
                                    274 	.globl _layer_hold_on
                                    275 	.globl _layer_hold_off
                                    276 	.globl _layer_hold_clear
                                    277 	.globl _layer_state_set_user
                                    278 	.globl _layer_state_set_kb
                                    279 	.globl _layer_state_set
                                    280 	.globl _layer_clear
                                    281 	.globl _layer_move
                                    282 	.globl _layer_on
                                    283 	.globl _layer_off
                                    284 	.globl _layer_or
                                    285 	.globl _layer_and
                                    286 	.globl _layer_xor
                                    287 	.globl _update_source_keycode_cache
                                    288 	.globl _update_source_layers_cache
                                    289 	.globl _read_source_keycode_cache
                                    290 	.globl _store_or_get_action
                                    291 	.globl _layer_switch_get_layer
                                    292 	.globl _layer_switch_get_action
                                    293 ;--------------------------------------------------------
                                    294 ; special function registers
                                    295 ;--------------------------------------------------------
                                    296 	.area RSEG    (ABS,DATA)
      000000                        297 	.org 0x0000
                           0000D0   298 _PSW	=	0x00d0
                           0000E0   299 _ACC	=	0x00e0
                           0000F0   300 _B	=	0x00f0
                           0000FD   301 _A_INV	=	0x00fd
                           000081   302 _SP	=	0x0081
                           000082   303 _DPL	=	0x0082
                           000083   304 _DPH	=	0x0083
                           0000A1   305 _SAFE_MOD	=	0x00a1
                           0000B1   306 _GLOBAL_CFG	=	0x00b1
                           000087   307 _PCON	=	0x0087
                           0000BA   308 _POWER_CFG	=	0x00ba
                           0000B9   309 _CLOCK_CFG	=	0x00b9
                           0000A9   310 _WAKE_CTRL	=	0x00a9
                           0000FE   311 _RESET_KEEP	=	0x00fe
                           0000FF   312 _WDOG_COUNT	=	0x00ff
                           0000A8   313 _IE	=	0x00a8
                           0000B8   314 _IP	=	0x00b8
                           0000E8   315 _IE_EX	=	0x00e8
                           0000E9   316 _IP_EX	=	0x00e9
                           0000B2   317 _GPIO_IE	=	0x00b2
                           008584   318 _ROM_ADDR	=	0x8584
                           000084   319 _ROM_ADDR_L	=	0x0084
                           000085   320 _ROM_ADDR_H	=	0x0085
                           008F8E   321 _ROM_DATA_HI	=	0x8f8e
                           00008E   322 _ROM_DATA_HL	=	0x008e
                           00008F   323 _ROM_DATA_HH	=	0x008f
                           000086   324 _ROM_CTRL	=	0x0086
                           000080   325 _P0	=	0x0080
                           0000C4   326 _P0_MOD_OC	=	0x00c4
                           0000C5   327 _P0_DIR_PU	=	0x00c5
                           000090   328 _P1	=	0x0090
                           000092   329 _P1_MOD_OC	=	0x0092
                           000093   330 _P1_DIR_PU	=	0x0093
                           0000A0   331 _P2	=	0x00a0
                           000094   332 _P2_MOD_OC	=	0x0094
                           000095   333 _P2_DIR_PU	=	0x0095
                           0000B0   334 _P3	=	0x00b0
                           000096   335 _P3_MOD_OC	=	0x0096
                           000097   336 _P3_DIR_PU	=	0x0097
                           0000C0   337 _P4	=	0x00c0
                           0000C2   338 _P4_MOD_OC	=	0x00c2
                           0000C3   339 _P4_DIR_PU	=	0x00c3
                           0000C1   340 _P4_LED_KEY	=	0x00c1
                           0000AA   341 _P5_IN	=	0x00aa
                           0000AB   342 _P5_OUT_PU	=	0x00ab
                           0000AC   343 _P5_DIR	=	0x00ac
                           0000AD   344 _P6_IN	=	0x00ad
                           0000AE   345 _P6_OUT_PU	=	0x00ae
                           0000AF   346 _P6_DIR	=	0x00af
                           0000F1   347 _P7	=	0x00f1
                           0000A2   348 _XBUS_AUX	=	0x00a2
                           000088   349 _TCON	=	0x0088
                           000089   350 _TMOD	=	0x0089
                           00008A   351 _TL0	=	0x008a
                           00008B   352 _TL1	=	0x008b
                           00008C   353 _TH0	=	0x008c
                           00008D   354 _TH1	=	0x008d
                           000098   355 _SCON	=	0x0098
                           000099   356 _SBUF	=	0x0099
                           0000C8   357 _T2CON	=	0x00c8
                           0000C9   358 _T2MOD	=	0x00c9
                           00CBCA   359 _RCAP2	=	0xcbca
                           0000CA   360 _RCAP2L	=	0x00ca
                           0000CB   361 _RCAP2H	=	0x00cb
                           00CDCC   362 _T2COUNT	=	0xcdcc
                           0000CC   363 _TL2	=	0x00cc
                           0000CD   364 _TH2	=	0x00cd
                           00CFCE   365 _T2CAP1	=	0xcfce
                           0000CE   366 _T2CAP1L	=	0x00ce
                           0000CF   367 _T2CAP1H	=	0x00cf
                           0000F8   368 _SPI0_STAT	=	0x00f8
                           0000F9   369 _SPI0_DATA	=	0x00f9
                           0000FA   370 _SPI0_CTRL	=	0x00fa
                           0000FB   371 _SPI0_CK_SE	=	0x00fb
                           0000FC   372 _SPI0_SETUP	=	0x00fc
                           0000BC   373 _SCON1	=	0x00bc
                           0000BD   374 _SBUF1	=	0x00bd
                           0000BE   375 _SBAUD1	=	0x00be
                           0000BF   376 _SIF1	=	0x00bf
                           0000B4   377 _SPI1_STAT	=	0x00b4
                           0000B5   378 _SPI1_DATA	=	0x00b5
                           0000B6   379 _SPI1_CTRL	=	0x00b6
                           0000B7   380 _SPI1_CK_SE	=	0x00b7
                           0000F3   381 _ADC_CTRL	=	0x00f3
                           00F5F4   382 _ADC_DAT	=	0xf5f4
                           0000F4   383 _ADC_DAT_L	=	0x00f4
                           0000F5   384 _ADC_DAT_H	=	0x00f5
                           0000F6   385 _ADC_CHAN	=	0x00f6
                           0000A6   386 _LED_COMMON	=	0x00a6
                           0000A7   387 _LED_PWM_OE	=	0x00a7
                           00C7C6   388 _LED_DMA	=	0xc7c6
                           0000C6   389 _LED_DMA_L	=	0x00c6
                           0000C7   390 _LED_DMA_H	=	0x00c7
                           0000F7   391 _LED_STATUS	=	0x00f7
                           0000B3   392 _I2CX_INT	=	0x00b3
                           0000BB   393 _I2CS_INT_ST	=	0x00bb
                                    394 ;--------------------------------------------------------
                                    395 ; special function bits
                                    396 ;--------------------------------------------------------
                                    397 	.area RSEG    (ABS,DATA)
      000000                        398 	.org 0x0000
                           0000D7   399 _CY	=	0x00d7
                           0000D6   400 _AC	=	0x00d6
                           0000D5   401 _F0	=	0x00d5
                           0000D4   402 _RS1	=	0x00d4
                           0000D3   403 _RS0	=	0x00d3
                           0000D2   404 _OV	=	0x00d2
                           0000D1   405 _F1	=	0x00d1
                           0000D0   406 _P	=	0x00d0
                           0000AF   407 _EA	=	0x00af
                           0000AE   408 _E_DIS	=	0x00ae
                           0000AD   409 _ET2	=	0x00ad
                           0000AC   410 _ES	=	0x00ac
                           0000AB   411 _ET1	=	0x00ab
                           0000AA   412 _EX1	=	0x00aa
                           0000A9   413 _ET0	=	0x00a9
                           0000A8   414 _EX0	=	0x00a8
                           0000BF   415 _PH_FLAG	=	0x00bf
                           0000BE   416 _PL_FLAG	=	0x00be
                           0000BD   417 _PT2	=	0x00bd
                           0000BC   418 _PS	=	0x00bc
                           0000BB   419 _PT1	=	0x00bb
                           0000BA   420 _PX1	=	0x00ba
                           0000B9   421 _PT0	=	0x00b9
                           0000B8   422 _PX0	=	0x00b8
                           0000EF   423 _IE_WDOG	=	0x00ef
                           0000EE   424 _IE_GPIO	=	0x00ee
                           0000ED   425 _IE_PWM_I2C	=	0x00ed
                           0000EC   426 _IE_UART1	=	0x00ec
                           0000EB   427 _IE_ADC	=	0x00eb
                           0000E9   428 _IE_USB	=	0x00e9
                           0000E8   429 _IE_SPI0	=	0x00e8
                           000087   430 _P0_7	=	0x0087
                           000086   431 _P0_6	=	0x0086
                           000085   432 _P0_5	=	0x0085
                           000084   433 _P0_4	=	0x0084
                           000083   434 _P0_3	=	0x0083
                           000082   435 _P0_2	=	0x0082
                           000081   436 _P0_1	=	0x0081
                           000080   437 _P0_0	=	0x0080
                           000081   438 _SDA0	=	0x0081
                           000080   439 _SCL0	=	0x0080
                           000083   440 _TXD_	=	0x0083
                           000082   441 _RXD_	=	0x0082
                           000085   442 _AIN13	=	0x0085
                           000084   443 _AIN12	=	0x0084
                           000083   444 _AIN11	=	0x0083
                           000082   445 _AIN10	=	0x0082
                           000081   446 _AIN9	=	0x0081
                           000080   447 _AIN8	=	0x0080
                           000097   448 _P1_7	=	0x0097
                           000096   449 _P1_6	=	0x0096
                           000095   450 _P1_5	=	0x0095
                           000094   451 _P1_4	=	0x0094
                           000093   452 _P1_3	=	0x0093
                           000092   453 _P1_2	=	0x0092
                           000091   454 _P1_1	=	0x0091
                           000090   455 _P1_0	=	0x0090
                           000097   456 _TXD1_	=	0x0097
                           000096   457 _RXD1_	=	0x0096
                           000097   458 _SCK	=	0x0097
                           000096   459 _MISO	=	0x0096
                           000095   460 _MOSI	=	0x0095
                           000094   461 _SCS	=	0x0094
                           000092   462 _INT0_	=	0x0092
                           000091   463 _T2EX	=	0x0091
                           000091   464 _CAP2	=	0x0091
                           000090   465 _T2	=	0x0090
                           000090   466 _CAP1	=	0x0090
                           000097   467 _AIN7	=	0x0097
                           000096   468 _AIN6	=	0x0096
                           000095   469 _AIN5	=	0x0095
                           000094   470 _AIN4	=	0x0094
                           000093   471 _AIN3	=	0x0093
                           000092   472 _AIN2	=	0x0092
                           000091   473 _AIN1	=	0x0091
                           000090   474 _AIN0	=	0x0090
                           0000A7   475 _P2_7	=	0x00a7
                           0000A6   476 _P2_6	=	0x00a6
                           0000A5   477 _P2_5	=	0x00a5
                           0000A4   478 _P2_4	=	0x00a4
                           0000A3   479 _P2_3	=	0x00a3
                           0000A2   480 _P2_2	=	0x00a2
                           0000A1   481 _P2_1	=	0x00a1
                           0000A0   482 _P2_0	=	0x00a0
                           0000A7   483 _TXD1	=	0x00a7
                           0000A6   484 _RXD1	=	0x00a6
                           0000A5   485 _T2EX_	=	0x00a5
                           0000A5   486 _CAP2_	=	0x00a5
                           0000A4   487 _T2_	=	0x00a4
                           0000A4   488 _CAP1_	=	0x00a4
                           0000B7   489 _P3_7	=	0x00b7
                           0000B6   490 _P3_6	=	0x00b6
                           0000B5   491 _P3_5	=	0x00b5
                           0000B4   492 _P3_4	=	0x00b4
                           0000B3   493 _P3_3	=	0x00b3
                           0000B2   494 _P3_2	=	0x00b2
                           0000B1   495 _P3_1	=	0x00b1
                           0000B0   496 _P3_0	=	0x00b0
                           0000B7   497 _SCK1	=	0x00b7
                           0000B6   498 _MISO1	=	0x00b6
                           0000B5   499 _MOSI1	=	0x00b5
                           0000B5   500 _T1	=	0x00b5
                           0000B4   501 _T0	=	0x00b4
                           0000B3   502 _INT1	=	0x00b3
                           0000B2   503 _INT0	=	0x00b2
                           0000B1   504 _TXD	=	0x00b1
                           0000B0   505 _RXD	=	0x00b0
                           0000C6   506 _P4_6	=	0x00c6
                           0000C5   507 _P4_5	=	0x00c5
                           0000C4   508 _P4_4	=	0x00c4
                           0000C3   509 _P4_3	=	0x00c3
                           0000C2   510 _P4_2	=	0x00c2
                           0000C1   511 _P4_1	=	0x00c1
                           0000C0   512 _P4_0	=	0x00c0
                           00008F   513 _TF1	=	0x008f
                           00008E   514 _TR1	=	0x008e
                           00008D   515 _TF0	=	0x008d
                           00008C   516 _TR0	=	0x008c
                           00008B   517 _IE1	=	0x008b
                           00008A   518 _IT1	=	0x008a
                           000089   519 _IE0	=	0x0089
                           000088   520 _IT0	=	0x0088
                           00009F   521 _SM0	=	0x009f
                           00009E   522 _SM1	=	0x009e
                           00009D   523 _SM2	=	0x009d
                           00009C   524 _REN	=	0x009c
                           00009B   525 _TB8	=	0x009b
                           00009A   526 _RB8	=	0x009a
                           000099   527 _TI	=	0x0099
                           000098   528 _RI	=	0x0098
                           0000CF   529 _TF2	=	0x00cf
                           0000CF   530 _CAP1F	=	0x00cf
                           0000CE   531 _EXF2	=	0x00ce
                           0000CD   532 _RCLK	=	0x00cd
                           0000CC   533 _TCLK	=	0x00cc
                           0000CB   534 _EXEN2	=	0x00cb
                           0000CA   535 _TR2	=	0x00ca
                           0000C9   536 _C_T2	=	0x00c9
                           0000C8   537 _CP_RL2	=	0x00c8
                           0000FF   538 _S0_FST_ACT	=	0x00ff
                           0000FE   539 _S0_IF_OV	=	0x00fe
                           0000FD   540 _S0_IF_FIRST	=	0x00fd
                           0000FC   541 _S0_IF_BYTE	=	0x00fc
                           0000FB   542 _S0_FREE	=	0x00fb
                           0000FA   543 _S0_T_FIFO	=	0x00fa
                           0000F8   544 _S0_R_FIFO	=	0x00f8
                           0000F7   545 _ADC_START	=	0x00f7
                                    546 ;--------------------------------------------------------
                                    547 ; overlayable register banks
                                    548 ;--------------------------------------------------------
                                    549 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        550 	.ds 8
                                    551 ;--------------------------------------------------------
                                    552 ; internal ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area DSEG    (DATA)
                                    555 ;--------------------------------------------------------
                                    556 ; overlayable items in internal ram
                                    557 ;--------------------------------------------------------
                                    558 ;--------------------------------------------------------
                                    559 ; indirectly addressable internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area ISEG    (DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; absolute internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area IABS    (ABS,DATA)
                                    566 	.area IABS    (ABS,DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; bit data
                                    569 ;--------------------------------------------------------
                                    570 	.area BSEG    (BIT)
                                    571 ;--------------------------------------------------------
                                    572 ; paged external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area PSEG    (PAG,XDATA)
                                    575 ;--------------------------------------------------------
                                    576 ; uninitialized external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area XSEG    (XDATA)
      00082E                        579 _default_layer_state_set_user_state_10000_310:
      00082E                        580 	.ds 1
      00082F                        581 _default_layer_state_set_kb_state_10000_312:
      00082F                        582 	.ds 1
      000830                        583 _default_layer_state_set_state_10000_314:
      000830                        584 	.ds 1
      000831                        585 _default_layer_set_state_10000_319:
      000831                        586 	.ds 1
      000832                        587 _default_layer_or_state_10000_321:
      000832                        588 	.ds 1
      000833                        589 _default_layer_and_state_10000_323:
      000833                        590 	.ds 1
      000834                        591 _default_layer_xor_state_10000_325:
      000834                        592 	.ds 1
      000835                        593 _persistent_layers:
      000835                        594 	.ds 1
      000836                        595 _layer_refs:
      000836                        596 	.ds 6
      00083C                        597 _macro_layers:
      00083C                        598 	.ds 1
      00083D                        599 _ak820_layer_refresh_state_10000_328:
      00083D                        600 	.ds 1
      00083E                        601 _layer_hold_on_layer_10000_331:
      00083E                        602 	.ds 1
      00083F                        603 _layer_hold_off_layer_10000_335:
      00083F                        604 	.ds 1
      000840                        605 _layer_state_set_user_state_10000_342:
      000840                        606 	.ds 1
      000841                        607 _layer_state_set_kb_state_10000_344:
      000841                        608 	.ds 1
      000842                        609 _layer_state_set_state_10000_346:
      000842                        610 	.ds 1
      000843                        611 _layer_move_layer_10000_359:
      000843                        612 	.ds 1
      000844                        613 _layer_on_layer_10000_361:
      000844                        614 	.ds 1
      000845                        615 _layer_off_layer_10000_363:
      000845                        616 	.ds 1
      000846                        617 _layer_or_state_10000_367:
      000846                        618 	.ds 1
      000847                        619 _layer_and_state_10000_369:
      000847                        620 	.ds 1
      000848                        621 _layer_xor_state_10000_371:
      000848                        622 	.ds 1
      000849                        623 _source_keycodes_cache:
      000849                        624 	.ds 256
      000949                        625 _encoder_source_keycodes_cache:
      000949                        626 	.ds 4
      00094D                        627 _source_keycode_cache_slot_PARM_1:
      00094D                        628 	.ds 2
      00094F                        629 _update_source_keycode_cache_PARM_1:
      00094F                        630 	.ds 2
      000951                        631 _update_source_keycode_cache_keycode_10000_379:
      000951                        632 	.ds 2
      000953                        633 _update_source_layers_cache_PARM_1:
      000953                        634 	.ds 2
      000955                        635 _update_source_layers_cache_layer_10000_382:
      000955                        636 	.ds 1
      000956                        637 _read_source_keycode_cache_PARM_1:
      000956                        638 	.ds 2
      000958                        639 _store_or_get_action_PARM_2:
      000958                        640 	.ds 2
      00095A                        641 _store_or_get_action_pressed_10000_390:
      00095A                        642 	.ds 1
      00095B                        643 _layer_switch_get_layer_PARM_1:
      00095B                        644 	.ds 2
      00095D                        645 _layer_switch_get_layer_action_10000_396:
      00095D                        646 	.ds 2
      00095F                        647 _layer_switch_get_layer_layers_10001_397:
      00095F                        648 	.ds 1
      000960                        649 _layer_switch_get_action_PARM_1:
      000960                        650 	.ds 2
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DD3                        659 _default_layer_state::
      000DD3                        660 	.ds 1
      000DD4                        661 _layer_state::
      000DD4                        662 	.ds 1
                                    663 	.area HOME    (CODE)
                                    664 	.area GSINIT0 (CODE)
                                    665 	.area GSINIT1 (CODE)
                                    666 	.area GSINIT2 (CODE)
                                    667 	.area GSINIT3 (CODE)
                                    668 	.area GSINIT4 (CODE)
                                    669 	.area GSINIT5 (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 	.area GSFINAL (CODE)
                                    672 	.area CSEG    (CODE)
                                    673 ;--------------------------------------------------------
                                    674 ; global & static initialisations
                                    675 ;--------------------------------------------------------
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; Home
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area HOME    (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; code
                                    687 ;--------------------------------------------------------
                                    688 	.area CSEG    (CODE)
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    691 ;------------------------------------------------------------
                                    692 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_183'
                                    693 ;------------------------------------------------------------
                                    694 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    695 ;	-----------------------------------------
                           000007   696 	ar7 = 0x07
                           000006   697 	ar6 = 0x06
                           000005   698 	ar5 = 0x05
                           000004   699 	ar4 = 0x04
                           000003   700 	ar3 = 0x03
                           000002   701 	ar2 = 0x02
                           000001   702 	ar1 = 0x01
                           000000   703 	ar0 = 0x00
                                    704 ;	 function default_layer_state_set_user
                                    705 ;	-----------------------------------------
      0076ED                        706 _default_layer_state_set_user:
      0076ED E5 82            [12]  707 	mov	a,dpl
      0076EF 90 08 2E         [24]  708 	mov	dptr,#_default_layer_state_set_user_state_10000_310
      0076F2 12 57 0A         [24]  709 	lcall	_ak820_outline_0101
                                    710 ;	quantum/action_layer.c:32: return state;
                                    711 ;	quantum/action_layer.c:33: }
      0076F5 22               [24]  712 	ret
                                    713 ;------------------------------------------------------------
                                    714 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    715 ;------------------------------------------------------------
                                    716 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_312'
                                    717 ;------------------------------------------------------------
                                    718 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    719 ;	-----------------------------------------
                                    720 ;	 function default_layer_state_set_kb
                                    721 ;	-----------------------------------------
      0076F6                        722 _default_layer_state_set_kb:
      0076F6 E5 82            [12]  723 	mov	a,dpl
      0076F8 90 08 2F         [24]  724 	mov	dptr,#_default_layer_state_set_kb_state_10000_312
      0076FB 12 57 0A         [24]  725 	lcall	_ak820_outline_0101
                                    726 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    727 ;	quantum/action_layer.c:41: }
      0076FE 02 76 ED         [24]  728 	ljmp	_default_layer_state_set_user
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'default_layer_state_set'
                                    731 ;------------------------------------------------------------
                                    732 ;state         Allocated with name '_default_layer_state_set_state_10000_314'
                                    733 ;------------------------------------------------------------
                                    734 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    735 ;	-----------------------------------------
                                    736 ;	 function default_layer_state_set
                                    737 ;	-----------------------------------------
      007701                        738 _default_layer_state_set:
      007701 E5 82            [12]  739 	mov	a,dpl
      007703 90 08 30         [24]  740 	mov	dptr,#_default_layer_state_set_state_10000_314
      007706 12 57 0A         [24]  741 	lcall	_ak820_outline_0101
                                    742 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      007709 12 76 F6         [24]  743 	lcall	_default_layer_state_set_kb
      00770C AF 82            [24]  744 	mov	r7, dpl
      00770E 90 08 30         [24]  745 	mov	dptr,#_default_layer_state_set_state_10000_314
      007711 EF               [12]  746 	mov	a,r7
      007712 F0               [24]  747 	movx	@dptr,a
                                    748 ;	quantum/action_layer.c:52: default_layer_state = state;
      007713 90 0D D3         [24]  749 	mov	dptr,#_default_layer_state
      007716 EF               [12]  750 	mov	a,r7
      007717 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    753 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    754 ;	quantum/action_layer.c:63: }
      007718 02 77 60         [24]  755 	ljmp	_ak820_layer_refresh
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'default_layer_set'
                                    758 ;------------------------------------------------------------
                                    759 ;state         Allocated with name '_default_layer_set_state_10000_319'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function default_layer_set
                                    764 ;	-----------------------------------------
      00771B                        765 _default_layer_set:
      00771B E5 82            [12]  766 	mov	a,dpl
      00771D 90 08 31         [24]  767 	mov	dptr,#_default_layer_set_state_10000_319
      007720 12 57 0A         [24]  768 	lcall	_ak820_outline_0101
                                    769 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    770 ;	quantum/action_layer.c:81: }
      007723 02 77 01         [24]  771 	ljmp	_default_layer_state_set
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'default_layer_or'
                                    774 ;------------------------------------------------------------
                                    775 ;state         Allocated with name '_default_layer_or_state_10000_321'
                                    776 ;------------------------------------------------------------
                                    777 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    778 ;	-----------------------------------------
                                    779 ;	 function default_layer_or
                                    780 ;	-----------------------------------------
      007726                        781 _default_layer_or:
      007726 E5 82            [12]  782 	mov	a,dpl
      007728 90 08 32         [24]  783 	mov	dptr,#_default_layer_or_state_10000_321
      00772B F0               [24]  784 	movx	@dptr,a
                                    785 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      00772C E0               [24]  786 	movx	a,@dptr
      00772D FF               [12]  787 	mov	r7,a
      00772E 90 0D D3         [24]  788 	mov	dptr,#_default_layer_state
      007731 12 7B A0         [24]  789 	lcall	_ak820_outline_0090
                                    790 ;	quantum/action_layer.c:90: }
      007734 02 77 01         [24]  791 	ljmp	_default_layer_state_set
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'default_layer_and'
                                    794 ;------------------------------------------------------------
                                    795 ;state         Allocated with name '_default_layer_and_state_10000_323'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function default_layer_and
                                    800 ;	-----------------------------------------
      007737                        801 _default_layer_and:
      007737 E5 82            [12]  802 	mov	a,dpl
      007739 90 08 33         [24]  803 	mov	dptr,#_default_layer_and_state_10000_323
      00773C F0               [24]  804 	movx	@dptr,a
                                    805 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      00773D 90 0D D3         [24]  806 	mov	dptr,#_default_layer_state
      007740 E0               [24]  807 	movx	a,@dptr
      007741 FF               [12]  808 	mov	r7,a
      007742 90 08 33         [24]  809 	mov	dptr,#_default_layer_and_state_10000_323
      007745 E0               [24]  810 	movx	a,@dptr
      007746 52 07            [12]  811 	anl	ar7,a
      007748 8F 82            [24]  812 	mov	dpl, r7
                                    813 ;	quantum/action_layer.c:97: }
      00774A 02 77 01         [24]  814 	ljmp	_default_layer_state_set
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'default_layer_xor'
                                    817 ;------------------------------------------------------------
                                    818 ;state         Allocated with name '_default_layer_xor_state_10000_325'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function default_layer_xor
                                    823 ;	-----------------------------------------
      00774D                        824 _default_layer_xor:
      00774D E5 82            [12]  825 	mov	a,dpl
      00774F 90 08 34         [24]  826 	mov	dptr,#_default_layer_xor_state_10000_325
      007752 F0               [24]  827 	movx	@dptr,a
                                    828 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      007753 E0               [24]  829 	movx	a,@dptr
      007754 FF               [12]  830 	mov	r7,a
      007755 90 0D D3         [24]  831 	mov	dptr,#_default_layer_state
      007758 E0               [24]  832 	movx	a,@dptr
      007759 62 07            [12]  833 	xrl	ar7,a
      00775B 8F 82            [24]  834 	mov	dpl, r7
                                    835 ;	quantum/action_layer.c:104: }
      00775D 02 77 01         [24]  836 	ljmp	_default_layer_state_set
                                    837 ;------------------------------------------------------------
                                    838 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    839 ;------------------------------------------------------------
                                    840 ;state         Allocated with name '_ak820_layer_refresh_state_10000_328'
                                    841 ;i             Allocated with name '_ak820_layer_refresh_i_20000_329'
                                    842 ;------------------------------------------------------------
                                    843 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    844 ;	-----------------------------------------
                                    845 ;	 function ak820_layer_refresh
                                    846 ;	-----------------------------------------
      007760                        847 _ak820_layer_refresh:
                                    848 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      007760 90 08 35         [24]  849 	mov	dptr,#_persistent_layers
      007763 E0               [24]  850 	movx	a,@dptr
      007764 90 08 3D         [24]  851 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      007767 F0               [24]  852 	movx	@dptr,a
                                    853 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      007768 7F 00            [12]  854 	mov	r7,#0x00
      00776A                        855 00105$:
      00776A BF 06 00         [24]  856 	cjne	r7,#0x06,00131$
      00776D                        857 00131$:
      00776D 50 25            [24]  858 	jnc	00103$
      00776F EF               [12]  859 	mov	a,r7
      007770 24 36            [12]  860 	add	a, #_layer_refs
      007772 FD               [12]  861 	mov	r5,a
      007773 E4               [12]  862 	clr	a
      007774 34 08            [12]  863 	addc	a, #(_layer_refs >> 8)
      007776 FE               [12]  864 	mov	r6,a
      007777 12 43 F4         [24]  865 	lcall	_ak820_outline_0012
      00777A E0               [24]  866 	movx	a,@dptr
      00777B 60 14            [24]  867 	jz	00106$
      00777D 8F F0            [24]  868 	mov	b,r7
      00777F 05 F0            [12]  869 	inc	b
      007781 74 01            [12]  870 	mov	a,#0x01
      007783 80 02            [24]  871 	sjmp	00135$
      007785                        872 00134$:
      007785 25 E0            [12]  873 	add	a,acc
      007787                        874 00135$:
      007787 D5 F0 FB         [24]  875 	djnz	b,00134$
      00778A FE               [12]  876 	mov	r6,a
      00778B 90 08 3D         [24]  877 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      00778E E0               [24]  878 	movx	a,@dptr
      00778F 4E               [12]  879 	orl	a,r6
      007790 F0               [24]  880 	movx	@dptr,a
      007791                        881 00106$:
      007791 0F               [12]  882 	inc	r7
      007792 80 D6            [24]  883 	sjmp	00105$
      007794                        884 00103$:
                                    885 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007794 90 0D D3         [24]  886 	mov	dptr,#_default_layer_state
      007797 E0               [24]  887 	movx	a,@dptr
      007798 FF               [12]  888 	mov	r7,a
      007799 90 08 3D         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      00779C E0               [24]  890 	movx	a,@dptr
      00779D FE               [12]  891 	mov	r6,a
      00779E 42 07            [12]  892 	orl	ar7,a
      0077A0 8F 82            [24]  893 	mov	dpl, r7
      0077A2 C0 06            [24]  894 	push	ar6
      0077A4 12 A9 35         [24]  895 	lcall	_ak820_tri_layer_derived
      0077A7 AF 82            [24]  896 	mov	r7, dpl
      0077A9 D0 06            [24]  897 	pop	ar6
      0077AB 90 08 3D         [24]  898 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      0077AE EF               [12]  899 	mov	a,r7
      0077AF 4E               [12]  900 	orl	a,r6
      0077B0 12 57 0A         [24]  901 	lcall	_ak820_outline_0101
                                    902 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      0077B3 12 78 52         [24]  903 	lcall	_layer_state_set_kb
      0077B6 E5 82            [12]  904 	mov	a, dpl
      0077B8 90 0D D4         [24]  905 	mov	dptr,#_layer_state
      0077BB F0               [24]  906 	movx	@dptr,a
                                    907 ;	quantum/action_layer.c:121: }
      0077BC 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'layer_hold_on'
                                    911 ;------------------------------------------------------------
                                    912 ;layer         Allocated with name '_layer_hold_on_layer_10000_331'
                                    913 ;------------------------------------------------------------
                                    914 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    915 ;	-----------------------------------------
                                    916 ;	 function layer_hold_on
                                    917 ;	-----------------------------------------
      0077BD                        918 _layer_hold_on:
      0077BD E5 82            [12]  919 	mov	a,dpl
      0077BF 90 08 3E         [24]  920 	mov	dptr,#_layer_hold_on_layer_10000_331
      0077C2 F0               [24]  921 	movx	@dptr,a
      0077C3 E0               [24]  922 	movx	a,@dptr
      0077C4 FF               [12]  923 	mov	r7,a
      0077C5 BF 06 00         [24]  924 	cjne	r7,#0x06,00120$
      0077C8                        925 00120$:
      0077C8 50 2A            [24]  926 	jnc	00104$
      0077CA 12 7B C0         [24]  927 	lcall	_ak820_outline_0138
      0077CD 74 01            [12]  928 	mov	a,#0x01
      0077CF F0               [24]  929 	movx	@dptr,a
      0077D0 90 08 3C         [24]  930 	mov	dptr,#_macro_layers
      0077D3 C0 07            [24]  931 	push	ar7
      0077D5 12 7B C9         [24]  932 	lcall	_ak820_macro_change
      0077D8 E5 82            [12]  933 	mov	a, dpl
      0077DA D0 07            [24]  934 	pop	ar7
      0077DC 60 16            [24]  935 	jz	00104$
      0077DE EF               [12]  936 	mov	a,r7
      0077DF 24 36            [12]  937 	add	a, #_layer_refs
      0077E1 FF               [12]  938 	mov	r7,a
      0077E2 E4               [12]  939 	clr	a
      0077E3 34 08            [12]  940 	addc	a, #(_layer_refs >> 8)
      0077E5 FE               [12]  941 	mov	r6,a
      0077E6 12 44 79         [24]  942 	lcall	_ak820_outline_0129
      0077E9 E0               [24]  943 	movx	a,@dptr
      0077EA FD               [12]  944 	mov	r5,a
      0077EB 0D               [12]  945 	inc	r5
      0077EC 12 44 79         [24]  946 	lcall	_ak820_outline_0129
      0077EF ED               [12]  947 	mov	a,r5
      0077F0 F0               [24]  948 	movx	@dptr,a
      0077F1 02 77 60         [24]  949 	ljmp	_ak820_layer_refresh
      0077F4                        950 00104$:
      0077F4 22               [24]  951 	ret
                                    952 ;------------------------------------------------------------
                                    953 ;Allocation info for local variables in function 'layer_hold_off'
                                    954 ;------------------------------------------------------------
                                    955 ;layer         Allocated with name '_layer_hold_off_layer_10000_335'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    958 ;	-----------------------------------------
                                    959 ;	 function layer_hold_off
                                    960 ;	-----------------------------------------
      0077F5                        961 _layer_hold_off:
      0077F5 E5 82            [12]  962 	mov	a,dpl
      0077F7 90 08 3F         [24]  963 	mov	dptr,#_layer_hold_off_layer_10000_335
      0077FA F0               [24]  964 	movx	@dptr,a
      0077FB E0               [24]  965 	movx	a,@dptr
      0077FC FF               [12]  966 	mov	r7,a
      0077FD BF 06 00         [24]  967 	cjne	r7,#0x06,00128$
      007800                        968 00128$:
      007800 50 2B            [24]  969 	jnc	00105$
      007802 12 7B C0         [24]  970 	lcall	_ak820_outline_0138
      007805 E4               [12]  971 	clr	a
      007806 F0               [24]  972 	movx	@dptr,a
      007807 90 08 3C         [24]  973 	mov	dptr,#_macro_layers
      00780A C0 07            [24]  974 	push	ar7
      00780C 12 7B C9         [24]  975 	lcall	_ak820_macro_change
      00780F E5 82            [12]  976 	mov	a, dpl
      007811 D0 07            [24]  977 	pop	ar7
      007813 60 18            [24]  978 	jz	00105$
      007815 EF               [12]  979 	mov	a,r7
      007816 24 36            [12]  980 	add	a, #_layer_refs
      007818 FE               [12]  981 	mov	r6,a
      007819 E4               [12]  982 	clr	a
      00781A 34 08            [12]  983 	addc	a, #(_layer_refs >> 8)
      00781C FF               [12]  984 	mov	r7,a
      00781D 12 43 D3         [24]  985 	lcall	_ak820_outline_0002
      007820 E0               [24]  986 	movx	a,@dptr
      007821 FD               [12]  987 	mov	r5,a
      007822 60 09            [24]  988 	jz	00105$
      007824 1D               [12]  989 	dec	r5
      007825 12 43 D3         [24]  990 	lcall	_ak820_outline_0002
      007828 ED               [12]  991 	mov	a,r5
      007829 F0               [24]  992 	movx	@dptr,a
      00782A 02 77 60         [24]  993 	ljmp	_ak820_layer_refresh
      00782D                        994 00105$:
      00782D 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'layer_hold_clear'
                                    998 ;------------------------------------------------------------
                                    999 ;i             Allocated with name '_layer_hold_clear_i_20000_341'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function layer_hold_clear
                                   1004 ;	-----------------------------------------
      00782E                       1005 _layer_hold_clear:
      00782E 90 08 3C         [24] 1006 	mov	dptr,#_macro_layers
      007831 E4               [12] 1007 	clr	a
      007832 F0               [24] 1008 	movx	@dptr,a
      007833 FF               [12] 1009 	mov	r7,a
      007834                       1010 00103$:
      007834 BF 06 00         [24] 1011 	cjne	r7,#0x06,00122$
      007837                       1012 00122$:
      007837 50 0D            [24] 1013 	jnc	00101$
      007839 EF               [12] 1014 	mov	a,r7
      00783A 24 36            [12] 1015 	add	a, #_layer_refs
      00783C F5 82            [12] 1016 	mov	dpl,a
      00783E E4               [12] 1017 	clr	a
      00783F 34 08            [12] 1018 	addc	a, #(_layer_refs >> 8)
      007841 12 7B BA         [24] 1019 	lcall	_ak820_outline_0120
      007844 80 EE            [24] 1020 	sjmp	00103$
      007846                       1021 00101$:
      007846 02 77 60         [24] 1022 	ljmp	_ak820_layer_refresh
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1025 ;------------------------------------------------------------
                                   1026 ;state         Allocated with name '_layer_state_set_user_state_10000_342'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function layer_state_set_user
                                   1031 ;	-----------------------------------------
      007849                       1032 _layer_state_set_user:
      007849 E5 82            [12] 1033 	mov	a,dpl
      00784B 90 08 40         [24] 1034 	mov	dptr,#_layer_state_set_user_state_10000_342
      00784E 12 57 0A         [24] 1035 	lcall	_ak820_outline_0101
                                   1036 ;	quantum/action_layer.c:132: return state;
                                   1037 ;	quantum/action_layer.c:133: }
      007851 22               [24] 1038 	ret
                                   1039 ;------------------------------------------------------------
                                   1040 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1041 ;------------------------------------------------------------
                                   1042 ;state         Allocated with name '_layer_state_set_kb_state_10000_344'
                                   1043 ;------------------------------------------------------------
                                   1044 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1045 ;	-----------------------------------------
                                   1046 ;	 function layer_state_set_kb
                                   1047 ;	-----------------------------------------
      007852                       1048 _layer_state_set_kb:
      007852 E5 82            [12] 1049 	mov	a,dpl
      007854 90 08 41         [24] 1050 	mov	dptr,#_layer_state_set_kb_state_10000_344
      007857 12 57 0A         [24] 1051 	lcall	_ak820_outline_0101
                                   1052 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1053 ;	quantum/action_layer.c:141: }
      00785A 02 78 49         [24] 1054 	ljmp	_layer_state_set_user
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'layer_state_set'
                                   1057 ;------------------------------------------------------------
                                   1058 ;state         Allocated with name '_layer_state_set_state_10000_346'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function layer_state_set
                                   1063 ;	-----------------------------------------
      00785D                       1064 _layer_state_set:
      00785D E5 82            [12] 1065 	mov	a,dpl
      00785F 90 08 42         [24] 1066 	mov	dptr,#_layer_state_set_state_10000_346
      007862 F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/action_layer.c:149: persistent_layers = state;
      007863 E0               [24] 1069 	movx	a,@dptr
      007864 90 08 35         [24] 1070 	mov	dptr,#_persistent_layers
      007867 F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1073 ;	quantum/action_layer.c:151: return;
                                   1074 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1075 ;	quantum/action_layer.c:165: }
      007868 02 77 60         [24] 1076 	ljmp	_ak820_layer_refresh
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'layer_clear'
                                   1079 ;------------------------------------------------------------
                                   1080 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1081 ;	-----------------------------------------
                                   1082 ;	 function layer_clear
                                   1083 ;	-----------------------------------------
      00786B                       1084 _layer_clear:
                                   1085 ;	quantum/action_layer.c:172: layer_state_set(0);
      00786B 75 82 00         [24] 1086 	mov	dpl, #0x00
                                   1087 ;	quantum/action_layer.c:173: }
      00786E 02 78 5D         [24] 1088 	ljmp	_layer_state_set
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'layer_state_is'
                                   1091 ;------------------------------------------------------------
                                   1092 ;layer         Allocated with name '_layer_state_is_layer_10000_353'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function layer_move
                                   1097 ;	-----------------------------------------
      007871                       1098 _layer_move:
      007871 E5 82            [12] 1099 	mov	a,dpl
      007873 90 08 43         [24] 1100 	mov	dptr,#_layer_move_layer_10000_359
      007876 F0               [24] 1101 	movx	@dptr,a
                                   1102 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007877 E0               [24] 1103 	movx	a,@dptr
      007878 12 70 13         [24] 1104 	lcall	_ak820_outline_0021
      00787B 80 02            [24] 1105 	sjmp	00104$
      00787D                       1106 00103$:
      00787D 25 E0            [12] 1107 	add	a,acc
      00787F                       1108 00104$:
      00787F D5 F0 FB         [24] 1109 	djnz	b,00103$
      007882 F5 82            [12] 1110 	mov	dpl,a
                                   1111 ;	quantum/action_layer.c:200: }
      007884 02 78 5D         [24] 1112 	ljmp	_layer_state_set
                                   1113 ;------------------------------------------------------------
                                   1114 ;Allocation info for local variables in function 'layer_on'
                                   1115 ;------------------------------------------------------------
                                   1116 ;layer         Allocated with name '_layer_on_layer_10000_361'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function layer_on
                                   1121 ;	-----------------------------------------
      007887                       1122 _layer_on:
      007887 E5 82            [12] 1123 	mov	a,dpl
      007889 90 08 44         [24] 1124 	mov	dptr,#_layer_on_layer_10000_361
      00788C F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      00788D E0               [24] 1127 	movx	a,@dptr
      00788E 12 70 13         [24] 1128 	lcall	_ak820_outline_0021
      007891 80 02            [24] 1129 	sjmp	00104$
      007893                       1130 00103$:
      007893 25 E0            [12] 1131 	add	a,acc
      007895                       1132 00104$:
      007895 D5 F0 FB         [24] 1133 	djnz	b,00103$
      007898 FF               [12] 1134 	mov	r7,a
      007899 90 08 35         [24] 1135 	mov	dptr,#_persistent_layers
      00789C 12 7B A0         [24] 1136 	lcall	_ak820_outline_0090
                                   1137 ;	quantum/action_layer.c:214: }
      00789F 02 78 5D         [24] 1138 	ljmp	_layer_state_set
                                   1139 ;------------------------------------------------------------
                                   1140 ;Allocation info for local variables in function 'layer_off'
                                   1141 ;------------------------------------------------------------
                                   1142 ;layer         Allocated with name '_layer_off_layer_10000_363'
                                   1143 ;------------------------------------------------------------
                                   1144 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1145 ;	-----------------------------------------
                                   1146 ;	 function layer_off
                                   1147 ;	-----------------------------------------
      0078A2                       1148 _layer_off:
      0078A2 E5 82            [12] 1149 	mov	a,dpl
      0078A4 90 08 45         [24] 1150 	mov	dptr,#_layer_off_layer_10000_363
      0078A7 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      0078A8 E0               [24] 1153 	movx	a,@dptr
      0078A9 12 70 13         [24] 1154 	lcall	_ak820_outline_0021
      0078AC 80 02            [24] 1155 	sjmp	00104$
      0078AE                       1156 00103$:
      0078AE 25 E0            [12] 1157 	add	a,acc
      0078B0                       1158 00104$:
      0078B0 D5 F0 FB         [24] 1159 	djnz	b,00103$
      0078B3 F4               [12] 1160 	cpl	a
      0078B4 FF               [12] 1161 	mov	r7,a
      0078B5 90 08 35         [24] 1162 	mov	dptr,#_persistent_layers
      0078B8 E0               [24] 1163 	movx	a,@dptr
      0078B9 52 07            [12] 1164 	anl	ar7,a
      0078BB 8F 82            [24] 1165 	mov	dpl, r7
                                   1166 ;	quantum/action_layer.c:228: }
      0078BD 02 78 5D         [24] 1167 	ljmp	_layer_state_set
                                   1168 ;------------------------------------------------------------
                                   1169 ;Allocation info for local variables in function 'layer_invert'
                                   1170 ;------------------------------------------------------------
                                   1171 ;layer         Allocated with name '_layer_invert_layer_10000_365'
                                   1172 ;------------------------------------------------------------
                                   1173 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1174 ;	-----------------------------------------
                                   1175 ;	 function layer_or
                                   1176 ;	-----------------------------------------
      0078C0                       1177 _layer_or:
      0078C0 E5 82            [12] 1178 	mov	a,dpl
      0078C2 90 08 46         [24] 1179 	mov	dptr,#_layer_or_state_10000_367
      0078C5 F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	quantum/action_layer.c:255: state);
      0078C6 E0               [24] 1182 	movx	a,@dptr
      0078C7 FF               [12] 1183 	mov	r7,a
      0078C8 90 08 35         [24] 1184 	mov	dptr,#_persistent_layers
      0078CB 12 7B A0         [24] 1185 	lcall	_ak820_outline_0090
                                   1186 ;	quantum/action_layer.c:256: }
      0078CE 02 78 5D         [24] 1187 	ljmp	_layer_state_set
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'layer_and'
                                   1190 ;------------------------------------------------------------
                                   1191 ;state         Allocated with name '_layer_and_state_10000_369'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function layer_and
                                   1196 ;	-----------------------------------------
      0078D1                       1197 _layer_and:
      0078D1 E5 82            [12] 1198 	mov	a,dpl
      0078D3 90 08 47         [24] 1199 	mov	dptr,#_layer_and_state_10000_369
      0078D6 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	quantum/action_layer.c:268: state);
      0078D7 90 08 35         [24] 1202 	mov	dptr,#_persistent_layers
      0078DA E0               [24] 1203 	movx	a,@dptr
      0078DB FF               [12] 1204 	mov	r7,a
      0078DC 90 08 47         [24] 1205 	mov	dptr,#_layer_and_state_10000_369
      0078DF E0               [24] 1206 	movx	a,@dptr
      0078E0 52 07            [12] 1207 	anl	ar7,a
      0078E2 8F 82            [24] 1208 	mov	dpl, r7
                                   1209 ;	quantum/action_layer.c:269: }
      0078E4 02 78 5D         [24] 1210 	ljmp	_layer_state_set
                                   1211 ;------------------------------------------------------------
                                   1212 ;Allocation info for local variables in function 'layer_xor'
                                   1213 ;------------------------------------------------------------
                                   1214 ;state         Allocated with name '_layer_xor_state_10000_371'
                                   1215 ;------------------------------------------------------------
                                   1216 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1217 ;	-----------------------------------------
                                   1218 ;	 function layer_xor
                                   1219 ;	-----------------------------------------
      0078E7                       1220 _layer_xor:
      0078E7 E5 82            [12] 1221 	mov	a,dpl
      0078E9 90 08 48         [24] 1222 	mov	dptr,#_layer_xor_state_10000_371
      0078EC F0               [24] 1223 	movx	@dptr,a
                                   1224 ;	quantum/action_layer.c:281: state);
      0078ED E0               [24] 1225 	movx	a,@dptr
      0078EE FF               [12] 1226 	mov	r7,a
      0078EF 90 08 35         [24] 1227 	mov	dptr,#_persistent_layers
      0078F2 E0               [24] 1228 	movx	a,@dptr
      0078F3 62 07            [12] 1229 	xrl	ar7,a
      0078F5 8F 82            [24] 1230 	mov	dpl, r7
                                   1231 ;	quantum/action_layer.c:282: }
      0078F7 02 78 5D         [24] 1232 	ljmp	_layer_state_set
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1235 ;------------------------------------------------------------
                                   1236 ;key           Allocated with name '_source_keycode_cache_slot_PARM_1'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(keypos_t key) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function source_keycode_cache_slot
                                   1241 ;	-----------------------------------------
      0078FA                       1242 _source_keycode_cache_slot:
                                   1243 ;	quantum/action_layer.c:325: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) {
      0078FA 90 09 4E         [24] 1244 	mov	dptr,#(_source_keycode_cache_slot_PARM_1 + 0x0001)
      0078FD E0               [24] 1245 	movx	a,@dptr
      0078FE FF               [12] 1246 	mov	r7,a
      0078FF BF 10 00         [24] 1247 	cjne	r7,#0x10,00147$
      007902                       1248 00147$:
      007902 50 22            [24] 1249 	jnc	00102$
      007904 90 09 4D         [24] 1250 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007907 E0               [24] 1251 	movx	a,@dptr
      007908 FE               [12] 1252 	mov	r6,a
      007909 BE 08 00         [24] 1253 	cjne	r6,#0x08,00149$
      00790C                       1254 00149$:
      00790C 50 18            [24] 1255 	jnc	00102$
                                   1256 ;	quantum/action_layer.c:326: return &source_keycodes_cache[(uint8_t)(key.row * MATRIX_COLS + key.col)];
      00790E 8F 05            [24] 1257 	mov	ar5,r7
      007910 ED               [12] 1258 	mov	a,r5
      007911 C4               [12] 1259 	swap	a
      007912 03               [12] 1260 	rr	a
      007913 54 F8            [12] 1261 	anl	a,#0xf8
      007915 2E               [12] 1262 	add	a,r6
      007916 75 F0 02         [24] 1263 	mov	b,#0x02
      007919 A4               [48] 1264 	mul	ab
      00791A 24 49            [12] 1265 	add	a, #_source_keycodes_cache
      00791C FD               [12] 1266 	mov	r5,a
      00791D 74 08            [12] 1267 	mov	a,#(_source_keycodes_cache >> 8)
      00791F 35 F0            [12] 1268 	addc	a, b
      007921 FE               [12] 1269 	mov	r6,a
      007922 12 43 F4         [24] 1270 	lcall	_ak820_outline_0012
      007925 22               [24] 1271 	ret
      007926                       1272 00102$:
                                   1273 ;	quantum/action_layer.c:329: if ((key.row == KEYLOC_ENCODER_CW || key.row == KEYLOC_ENCODER_CCW) && key.col < NUM_ENCODERS) {
      007926 BF FD 02         [24] 1274 	cjne	r7,#0xfd,00151$
      007929 80 03            [24] 1275 	sjmp	00107$
      00792B                       1276 00151$:
      00792B BF FC 33         [24] 1277 	cjne	r7,#0xfc,00105$
      00792E                       1278 00107$:
      00792E 90 09 4D         [24] 1279 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007931 E0               [24] 1280 	movx	a,@dptr
      007932 FE               [12] 1281 	mov	r6,a
      007933 BE 01 00         [24] 1282 	cjne	r6,#0x01,00154$
      007936                       1283 00154$:
      007936 50 29            [24] 1284 	jnc	00105$
                                   1285 ;	quantum/action_layer.c:330: return &encoder_source_keycodes_cache[key.col + (key.row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007938 BF FC 04         [24] 1286 	cjne	r7,#0xfc,00110$
      00793B 7F 01            [12] 1287 	mov	r7,#0x01
      00793D 80 02            [24] 1288 	sjmp	00111$
      00793F                       1289 00110$:
      00793F 7F 00            [12] 1290 	mov	r7,#0x00
      007941                       1291 00111$:
      007941 C2 D5            [12] 1292 	clr	F0
      007943 75 F0 02         [24] 1293 	mov	b,#0x02
      007946 EF               [12] 1294 	mov	a,r7
      007947 30 E7 04         [24] 1295 	jnb	acc.7,00158$
      00794A B2 D5            [12] 1296 	cpl	F0
      00794C F4               [12] 1297 	cpl	a
      00794D 04               [12] 1298 	inc	a
      00794E                       1299 00158$:
      00794E A4               [48] 1300 	mul	ab
      00794F 30 D5 03         [24] 1301 	jnb	F0,00159$
      007952 12 70 1A         [24] 1302 	lcall	_ak820_outline_0096
      007955                       1303 00159$:
      007955 24 49            [12] 1304 	add	a, #_encoder_source_keycodes_cache
      007957 FE               [12] 1305 	mov	r6,a
      007958 74 09            [12] 1306 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      00795A 35 F0            [12] 1307 	addc	a, b
      00795C FF               [12] 1308 	mov	r7,a
      00795D 12 43 D3         [24] 1309 	lcall	_ak820_outline_0002
      007960 22               [24] 1310 	ret
      007961                       1311 00105$:
                                   1312 ;	quantum/action_layer.c:333: return 0;
      007961 90 00 00         [24] 1313 	mov	dptr,#0x0000
                                   1314 ;	quantum/action_layer.c:334: }
      007964 22               [24] 1315 	ret
                                   1316 ;------------------------------------------------------------
                                   1317 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1318 ;------------------------------------------------------------
                                   1319 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1320 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_379'
                                   1321 ;slot          Allocated with name '_update_source_keycode_cache_slot_10000_380'
                                   1322 ;------------------------------------------------------------
                                   1323 ;	quantum/action_layer.c:338: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1324 ;	-----------------------------------------
                                   1325 ;	 function update_source_keycode_cache
                                   1326 ;	-----------------------------------------
      007965                       1327 _update_source_keycode_cache:
      007965 12 43 EA         [24] 1328 	lcall	_ak820_outline_0010
      007968 90 09 51         [24] 1329 	mov	dptr,#_update_source_keycode_cache_keycode_10000_379
      00796B 12 43 E5         [24] 1330 	lcall	_ak820_outline_0007
                                   1331 ;	quantum/action_layer.c:339: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      00796E 90 0D B3         [24] 1332 	mov	dptr,#___memcpy_PARM_2
      007971 74 4F            [12] 1333 	mov	a,#_update_source_keycode_cache_PARM_1
      007973 F0               [24] 1334 	movx	@dptr,a
      007974 74 09            [12] 1335 	mov	a,#(_update_source_keycode_cache_PARM_1 >> 8)
      007976 A3               [24] 1336 	inc	dptr
      007977 12 4E 60         [24] 1337 	lcall	_ak820_outline_0003
      00797A 12 7B 90         [24] 1338 	lcall	_ak820_outline_0032
      00797D 12 4E 60         [24] 1339 	lcall	_ak820_outline_0003
      007980 90 09 4D         [24] 1340 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007983 F5 F0            [12] 1341 	mov	b,a
      007985 12 BD 3B         [24] 1342 	lcall	___memcpy
      007988 12 78 FA         [24] 1343 	lcall	_source_keycode_cache_slot
      00798B 12 44 1D         [24] 1344 	lcall	_ak820_outline_0027
                                   1345 ;	quantum/action_layer.c:340: if (!slot) return false;
      00798E EE               [12] 1346 	mov	a,r6
      00798F 4F               [12] 1347 	orl	a,r7
      007990 70 03            [24] 1348 	jnz	00102$
      007992 F5 82            [12] 1349 	mov	dpl,a
      007994 22               [24] 1350 	ret
      007995                       1351 00102$:
                                   1352 ;	quantum/action_layer.c:341: *slot = keycode;
      007995 90 09 51         [24] 1353 	mov	dptr,#_update_source_keycode_cache_keycode_10000_379
      007998 12 43 DF         [24] 1354 	lcall	_ak820_outline_0006
      00799B 12 43 D3         [24] 1355 	lcall	_ak820_outline_0002
      00799E 12 44 0B         [24] 1356 	lcall	_ak820_outline_0023
                                   1357 ;	quantum/action_layer.c:342: return true;
      0079A1 75 82 01         [24] 1358 	mov	dpl, #0x01
                                   1359 ;	quantum/action_layer.c:343: }
      0079A4 22               [24] 1360 	ret
                                   1361 ;------------------------------------------------------------
                                   1362 ;Allocation info for local variables in function 'update_source_layers_cache'
                                   1363 ;------------------------------------------------------------
                                   1364 ;key           Allocated with name '_update_source_layers_cache_PARM_1'
                                   1365 ;layer         Allocated with name '_update_source_layers_cache_layer_10000_382'
                                   1366 ;slot          Allocated with name '_update_source_layers_cache_slot_10000_383'
                                   1367 ;------------------------------------------------------------
                                   1368 ;	quantum/action_layer.c:345: void update_source_layers_cache(keypos_t key, uint8_t layer) {
                                   1369 ;	-----------------------------------------
                                   1370 ;	 function update_source_layers_cache
                                   1371 ;	-----------------------------------------
      0079A5                       1372 _update_source_layers_cache:
      0079A5 E5 82            [12] 1373 	mov	a,dpl
      0079A7 90 09 55         [24] 1374 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      0079AA F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/action_layer.c:346: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      0079AB 12 7B B0         [24] 1377 	lcall	_ak820_outline_0106
      0079AE 12 4E 60         [24] 1378 	lcall	_ak820_outline_0003
      0079B1 12 7B 90         [24] 1379 	lcall	_ak820_outline_0032
      0079B4 12 4E 60         [24] 1380 	lcall	_ak820_outline_0003
      0079B7 90 09 4D         [24] 1381 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      0079BA F5 F0            [12] 1382 	mov	b,a
      0079BC 12 BD 3B         [24] 1383 	lcall	___memcpy
      0079BF 12 78 FA         [24] 1384 	lcall	_source_keycode_cache_slot
      0079C2 12 44 1D         [24] 1385 	lcall	_ak820_outline_0027
                                   1386 ;	quantum/action_layer.c:347: if (!slot) return;
      0079C5 EE               [12] 1387 	mov	a,r6
      0079C6 4F               [12] 1388 	orl	a,r7
      0079C7 70 01            [24] 1389 	jnz	00102$
      0079C9 22               [24] 1390 	ret
      0079CA                       1391 00102$:
                                   1392 ;	quantum/action_layer.c:348: layer &= (1u << MAX_LAYER_BITS) - 1;
      0079CA 90 09 55         [24] 1393 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      0079CD E0               [24] 1394 	movx	a,@dptr
      0079CE 53 E0 07         [24] 1395 	anl	acc,#0x07
      0079D1 F0               [24] 1396 	movx	@dptr,a
                                   1397 ;	quantum/action_layer.c:359: *slot = keymap_key_to_keycode(layer, key);
      0079D2 90 09 55         [24] 1398 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      0079D5 E0               [24] 1399 	movx	a,@dptr
      0079D6 FD               [12] 1400 	mov	r5,a
      0079D7 12 7B B0         [24] 1401 	lcall	_ak820_outline_0106
      0079DA 12 4E 60         [24] 1402 	lcall	_ak820_outline_0003
      0079DD 12 7B 90         [24] 1403 	lcall	_ak820_outline_0032
      0079E0 12 4E 60         [24] 1404 	lcall	_ak820_outline_0003
      0079E3 90 0B 9E         [24] 1405 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      0079E6 F5 F0            [12] 1406 	mov	b,a
      0079E8 C0 07            [24] 1407 	push	ar7
      0079EA C0 06            [24] 1408 	push	ar6
      0079EC C0 05            [24] 1409 	push	ar5
      0079EE 12 BD 3B         [24] 1410 	lcall	___memcpy
      0079F1 D0 05            [24] 1411 	pop	ar5
      0079F3 8D 82            [24] 1412 	mov	dpl, r5
      0079F5 12 98 32         [24] 1413 	lcall	_keymap_key_to_keycode
      0079F8 12 44 83         [24] 1414 	lcall	_ak820_outline_0132
      0079FB D0 06            [24] 1415 	pop	ar6
      0079FD D0 07            [24] 1416 	pop	ar7
      0079FF 12 43 D3         [24] 1417 	lcall	_ak820_outline_0002
      007A02 12 44 0B         [24] 1418 	lcall	_ak820_outline_0023
                                   1419 ;	quantum/action_layer.c:360: }
      007A05 22               [24] 1420 	ret
                                   1421 ;------------------------------------------------------------
                                   1422 ;Allocation info for local variables in function 'read_source_keycode_cache'
                                   1423 ;------------------------------------------------------------
                                   1424 ;key           Allocated with name '_read_source_keycode_cache_PARM_1'
                                   1425 ;slot          Allocated with name '_read_source_keycode_cache_slot_10001_389'
                                   1426 ;------------------------------------------------------------
                                   1427 ;	quantum/action_layer.c:381: uint16_t read_source_keycode_cache(keypos_t key) {
                                   1428 ;	-----------------------------------------
                                   1429 ;	 function read_source_keycode_cache
                                   1430 ;	-----------------------------------------
      007A06                       1431 _read_source_keycode_cache:
                                   1432 ;	quantum/action_layer.c:384: if (vial_unlock_in_progress) return KC_NO;
      007A06 90 0E 33         [24] 1433 	mov	dptr,#_vial_unlock_in_progress
      007A09 E0               [24] 1434 	movx	a,@dptr
      007A0A 60 04            [24] 1435 	jz	00102$
      007A0C 90 00 00         [24] 1436 	mov	dptr,#0x0000
      007A0F 22               [24] 1437 	ret
      007A10                       1438 00102$:
                                   1439 ;	quantum/action_layer.c:385: if (key.row == VIAL_MATRIX_MAGIC && key.col == VIAL_MATRIX_MAGIC) return g_vial_magic_keycode_override;
      007A10 90 09 57         [24] 1440 	mov	dptr,#(_read_source_keycode_cache_PARM_1 + 0x0001)
      007A13 E0               [24] 1441 	movx	a,@dptr
      007A14 FF               [12] 1442 	mov	r7,a
      007A15 BF F0 12         [24] 1443 	cjne	r7,#0xf0,00104$
      007A18 90 09 56         [24] 1444 	mov	dptr,#_read_source_keycode_cache_PARM_1
      007A1B E0               [24] 1445 	movx	a,@dptr
      007A1C FF               [12] 1446 	mov	r7,a
      007A1D BF F0 0A         [24] 1447 	cjne	r7,#0xf0,00104$
      007A20 90 0C 8B         [24] 1448 	mov	dptr,#_g_vial_magic_keycode_override
      007A23 12 43 C5         [24] 1449 	lcall	_ak820_outline_0000
      007A26 12 43 D3         [24] 1450 	lcall	_ak820_outline_0002
      007A29 22               [24] 1451 	ret
      007A2A                       1452 00104$:
                                   1453 ;	quantum/action_layer.c:387: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      007A2A 90 0D B3         [24] 1454 	mov	dptr,#___memcpy_PARM_2
      007A2D 74 56            [12] 1455 	mov	a,#_read_source_keycode_cache_PARM_1
      007A2F F0               [24] 1456 	movx	@dptr,a
      007A30 74 09            [12] 1457 	mov	a,#(_read_source_keycode_cache_PARM_1 >> 8)
      007A32 A3               [24] 1458 	inc	dptr
      007A33 12 4E 60         [24] 1459 	lcall	_ak820_outline_0003
      007A36 12 7B 90         [24] 1460 	lcall	_ak820_outline_0032
      007A39 12 4E 60         [24] 1461 	lcall	_ak820_outline_0003
      007A3C 90 09 4D         [24] 1462 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007A3F F5 F0            [12] 1463 	mov	b,a
      007A41 12 BD 3B         [24] 1464 	lcall	___memcpy
      007A44 12 78 FA         [24] 1465 	lcall	_source_keycode_cache_slot
      007A47 12 44 1D         [24] 1466 	lcall	_ak820_outline_0027
                                   1467 ;	quantum/action_layer.c:388: return slot ? *slot : KC_NO;
      007A4A EE               [12] 1468 	mov	a,r6
      007A4B 4F               [12] 1469 	orl	a,r7
      007A4C 60 08            [24] 1470 	jz	00108$
      007A4E 12 43 D3         [24] 1471 	lcall	_ak820_outline_0002
      007A51 12 43 C5         [24] 1472 	lcall	_ak820_outline_0000
      007A54 80 04            [24] 1473 	sjmp	00109$
      007A56                       1474 00108$:
      007A56 7E 00            [12] 1475 	mov	r6,#0x00
      007A58 7F 00            [12] 1476 	mov	r7,#0x00
      007A5A                       1477 00109$:
      007A5A 12 43 D3         [24] 1478 	lcall	_ak820_outline_0002
                                   1479 ;	quantum/action_layer.c:389: }
      007A5D 22               [24] 1480 	ret
                                   1481 ;------------------------------------------------------------
                                   1482 ;Allocation info for local variables in function 'store_or_get_action'
                                   1483 ;------------------------------------------------------------
                                   1484 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1485 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_390'
                                   1486 ;------------------------------------------------------------
                                   1487 ;	quantum/action_layer.c:478: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1488 ;	-----------------------------------------
                                   1489 ;	 function store_or_get_action
                                   1490 ;	-----------------------------------------
      007A5E                       1491 _store_or_get_action:
      007A5E E5 82            [12] 1492 	mov	a,dpl
      007A60 90 09 5A         [24] 1493 	mov	dptr,#_store_or_get_action_pressed_10000_390
      007A63 F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	quantum/action_layer.c:480: if (disable_action_cache) {
      007A64 90 0D D2         [24] 1496 	mov	dptr,#_disable_action_cache
      007A67 E0               [24] 1497 	movx	a,@dptr
      007A68 60 17            [24] 1498 	jz	00102$
                                   1499 ;	quantum/action_layer.c:481: return layer_switch_get_action(key);
      007A6A 12 7B 96         [24] 1500 	lcall	_ak820_outline_0034
      007A6D 12 4E 60         [24] 1501 	lcall	_ak820_outline_0003
      007A70 12 7B 90         [24] 1502 	lcall	_ak820_outline_0032
      007A73 12 4E 60         [24] 1503 	lcall	_ak820_outline_0003
      007A76 90 09 60         [24] 1504 	mov	dptr,#_layer_switch_get_action_PARM_1
      007A79 F5 F0            [12] 1505 	mov	b,a
      007A7B 12 BD 3B         [24] 1506 	lcall	___memcpy
      007A7E 02 7B 5A         [24] 1507 	ljmp	_layer_switch_get_action
      007A81                       1508 00102$:
                                   1509 ;	quantum/action_layer.c:485: if (pressed) update_source_layers_cache(key, layer_switch_get_layer(key));
      007A81 90 09 5A         [24] 1510 	mov	dptr,#_store_or_get_action_pressed_10000_390
      007A84 E0               [24] 1511 	movx	a,@dptr
      007A85 60 36            [24] 1512 	jz	00104$
      007A87 12 7B 96         [24] 1513 	lcall	_ak820_outline_0034
      007A8A 12 4E 60         [24] 1514 	lcall	_ak820_outline_0003
      007A8D 12 7B 90         [24] 1515 	lcall	_ak820_outline_0032
      007A90 12 4E 60         [24] 1516 	lcall	_ak820_outline_0003
      007A93 90 09 5B         [24] 1517 	mov	dptr,#_layer_switch_get_layer_PARM_1
      007A96 F5 F0            [12] 1518 	mov	b,a
      007A98 12 BD 3B         [24] 1519 	lcall	___memcpy
      007A9B 12 7A D9         [24] 1520 	lcall	_layer_switch_get_layer
      007A9E AF 82            [24] 1521 	mov	r7, dpl
      007AA0 12 7B 96         [24] 1522 	lcall	_ak820_outline_0034
      007AA3 12 4E 60         [24] 1523 	lcall	_ak820_outline_0003
      007AA6 12 7B 90         [24] 1524 	lcall	_ak820_outline_0032
      007AA9 12 4E 60         [24] 1525 	lcall	_ak820_outline_0003
      007AAC 90 09 53         [24] 1526 	mov	dptr,#_update_source_layers_cache_PARM_1
      007AAF F5 F0            [12] 1527 	mov	b,a
      007AB1 C0 07            [24] 1528 	push	ar7
      007AB3 12 BD 3B         [24] 1529 	lcall	___memcpy
      007AB6 D0 07            [24] 1530 	pop	ar7
      007AB8 8F 82            [24] 1531 	mov	dpl, r7
      007ABA 12 79 A5         [24] 1532 	lcall	_update_source_layers_cache
      007ABD                       1533 00104$:
                                   1534 ;	quantum/action_layer.c:486: return action_for_keycode(read_source_keycode_cache(key));
      007ABD 12 7B 96         [24] 1535 	lcall	_ak820_outline_0034
      007AC0 12 4E 60         [24] 1536 	lcall	_ak820_outline_0003
      007AC3 12 7B 90         [24] 1537 	lcall	_ak820_outline_0032
      007AC6 12 4E 60         [24] 1538 	lcall	_ak820_outline_0003
      007AC9 90 09 56         [24] 1539 	mov	dptr,#_read_source_keycode_cache_PARM_1
      007ACC F5 F0            [12] 1540 	mov	b,a
      007ACE 12 BD 3B         [24] 1541 	lcall	___memcpy
      007AD1 12 7A 06         [24] 1542 	lcall	_read_source_keycode_cache
      007AD4 AF 83            [24] 1543 	mov  r7,dph
                                   1544 ;	quantum/action_layer.c:500: }
      007AD6 02 96 CC         [24] 1545 	ljmp	_action_for_keycode
                                   1546 ;------------------------------------------------------------
                                   1547 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1548 ;------------------------------------------------------------
                                   1549 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1550 ;action        Allocated with name '_layer_switch_get_layer_action_10000_396'
                                   1551 ;layers        Allocated with name '_layer_switch_get_layer_layers_10001_397'
                                   1552 ;i             Allocated with name '_layer_switch_get_layer_i_20001_398'
                                   1553 ;------------------------------------------------------------
                                   1554 ;	quantum/action_layer.c:506: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1555 ;	-----------------------------------------
                                   1556 ;	 function layer_switch_get_layer
                                   1557 ;	-----------------------------------------
      007AD9                       1558 _layer_switch_get_layer:
                                   1559 ;	quantum/action_layer.c:509: action.code = ACTION_TRANSPARENT;
      007AD9 90 09 5D         [24] 1560 	mov	dptr,#_layer_switch_get_layer_action_10000_396
      007ADC 74 01            [12] 1561 	mov	a,#0x01
      007ADE 12 4E 60         [24] 1562 	lcall	_ak820_outline_0003
                                   1563 ;	quantum/action_layer.c:511: layer_state_t layers = layer_state | default_layer_state;
      007AE1 90 0D D3         [24] 1564 	mov	dptr,#_default_layer_state
      007AE4 E0               [24] 1565 	movx	a,@dptr
      007AE5 FF               [12] 1566 	mov	r7,a
      007AE6 90 0D D4         [24] 1567 	mov	dptr,#_layer_state
      007AE9 E0               [24] 1568 	movx	a,@dptr
      007AEA 90 09 5F         [24] 1569 	mov	dptr,#_layer_switch_get_layer_layers_10001_397
      007AED 4F               [12] 1570 	orl	a,r7
      007AEE F0               [24] 1571 	movx	@dptr,a
                                   1572 ;	quantum/action_layer.c:513: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007AEF 7F 05            [12] 1573 	mov	r7,#0x05
      007AF1                       1574 00107$:
      007AF1 EF               [12] 1575 	mov	a,r7
      007AF2 20 E7 61         [24] 1576 	jb	acc.7,00105$
                                   1577 ;	quantum/action_layer.c:514: if (layers & ((layer_state_t)1 << i)) {
      007AF5 8F F0            [24] 1578 	mov	b,r7
      007AF7 05 F0            [12] 1579 	inc	b
      007AF9 7D 01            [12] 1580 	mov	r5,#0x01
      007AFB 7E 00            [12] 1581 	mov	r6,#0x00
      007AFD 80 06            [24] 1582 	sjmp	00141$
      007AFF                       1583 00140$:
      007AFF ED               [12] 1584 	mov	a,r5
      007B00 2D               [12] 1585 	add	a,r5
      007B01 FD               [12] 1586 	mov	r5,a
      007B02 EE               [12] 1587 	mov	a,r6
      007B03 33               [12] 1588 	rlc	a
      007B04 FE               [12] 1589 	mov	r6,a
      007B05                       1590 00141$:
      007B05 D5 F0 F7         [24] 1591 	djnz	b,00140$
      007B08 90 09 5F         [24] 1592 	mov	dptr,#_layer_switch_get_layer_layers_10001_397
      007B0B E0               [24] 1593 	movx	a,@dptr
      007B0C 7C 00            [12] 1594 	mov	r4,#0x00
      007B0E 52 05            [12] 1595 	anl	ar5,a
      007B10 EC               [12] 1596 	mov	a,r4
      007B11 52 06            [12] 1597 	anl	ar6,a
      007B13 ED               [12] 1598 	mov	a,r5
      007B14 4E               [12] 1599 	orl	a,r6
      007B15 60 3C            [24] 1600 	jz	00108$
                                   1601 ;	quantum/action_layer.c:515: action.code = action_for_key(i, key);
      007B17 90 0D B3         [24] 1602 	mov	dptr,#___memcpy_PARM_2
      007B1A 74 5B            [12] 1603 	mov	a,#_layer_switch_get_layer_PARM_1
      007B1C F0               [24] 1604 	movx	@dptr,a
      007B1D 74 09            [12] 1605 	mov	a,#(_layer_switch_get_layer_PARM_1 >> 8)
      007B1F A3               [24] 1606 	inc	dptr
      007B20 12 4E 60         [24] 1607 	lcall	_ak820_outline_0003
      007B23 12 7B 90         [24] 1608 	lcall	_ak820_outline_0032
      007B26 12 4E 60         [24] 1609 	lcall	_ak820_outline_0003
      007B29 90 0B 94         [24] 1610 	mov	dptr,#_action_for_key_PARM_2
      007B2C F5 F0            [12] 1611 	mov	b,a
      007B2E C0 07            [24] 1612 	push	ar7
      007B30 12 BD 3B         [24] 1613 	lcall	___memcpy
      007B33 D0 07            [24] 1614 	pop	ar7
      007B35 8F 82            [24] 1615 	mov	dpl, r7
      007B37 C0 07            [24] 1616 	push	ar7
      007B39 12 96 9A         [24] 1617 	lcall	_action_for_key
      007B3C AD 82            [24] 1618 	mov	r5, dpl
      007B3E AE 83            [24] 1619 	mov	r6, dph
      007B40 D0 07            [24] 1620 	pop	ar7
      007B42 90 09 5D         [24] 1621 	mov	dptr,#_layer_switch_get_layer_action_10000_396
      007B45 12 44 56         [24] 1622 	lcall	_ak820_outline_0071
                                   1623 ;	quantum/action_layer.c:516: if (action.code != ACTION_TRANSPARENT) {
      007B48 BD 01 05         [24] 1624 	cjne	r5,#0x01,00143$
      007B4B BE 00 02         [24] 1625 	cjne	r6,#0x00,00143$
      007B4E 80 03            [24] 1626 	sjmp	00108$
      007B50                       1627 00143$:
                                   1628 ;	quantum/action_layer.c:517: return i;
      007B50 8F 82            [24] 1629 	mov	dpl, r7
      007B52 22               [24] 1630 	ret
      007B53                       1631 00108$:
                                   1632 ;	quantum/action_layer.c:513: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007B53 1F               [12] 1633 	dec	r7
      007B54 80 9B            [24] 1634 	sjmp	00107$
      007B56                       1635 00105$:
                                   1636 ;	quantum/action_layer.c:522: return 0;
      007B56 75 82 00         [24] 1637 	mov	dpl, #0x00
                                   1638 ;	quantum/action_layer.c:527: }
      007B59 22               [24] 1639 	ret
                                   1640 ;------------------------------------------------------------
                                   1641 ;Allocation info for local variables in function 'layer_switch_get_action'
                                   1642 ;------------------------------------------------------------
                                   1643 ;key           Allocated with name '_layer_switch_get_action_PARM_1'
                                   1644 ;layer         Allocated with name '_layer_switch_get_action_layer_10000_405'
                                   1645 ;action        Allocated with name '_layer_switch_get_action_action_10000_405'
                                   1646 ;------------------------------------------------------------
                                   1647 ;	quantum/action_layer.c:533: uint16_t layer_switch_get_action(keypos_t key) {
                                   1648 ;	-----------------------------------------
                                   1649 ;	 function layer_switch_get_action
                                   1650 ;	-----------------------------------------
      007B5A                       1651 _layer_switch_get_action:
                                   1652 ;	quantum/action_layer.c:535: uint8_t layer = layer_switch_get_layer(key);
      007B5A 12 7B A6         [24] 1653 	lcall	_ak820_outline_0105
      007B5D 12 4E 60         [24] 1654 	lcall	_ak820_outline_0003
      007B60 12 7B 90         [24] 1655 	lcall	_ak820_outline_0032
      007B63 12 4E 60         [24] 1656 	lcall	_ak820_outline_0003
      007B66 90 09 5B         [24] 1657 	mov	dptr,#_layer_switch_get_layer_PARM_1
      007B69 F5 F0            [12] 1658 	mov	b,a
      007B6B 12 BD 3B         [24] 1659 	lcall	___memcpy
      007B6E 12 7A D9         [24] 1660 	lcall	_layer_switch_get_layer
      007B71 AF 82            [24] 1661 	mov	r7, dpl
                                   1662 ;	quantum/action_layer.c:538: action = action_for_key(layer, key);
      007B73 12 7B A6         [24] 1663 	lcall	_ak820_outline_0105
      007B76 12 4E 60         [24] 1664 	lcall	_ak820_outline_0003
      007B79 12 7B 90         [24] 1665 	lcall	_ak820_outline_0032
      007B7C 12 4E 60         [24] 1666 	lcall	_ak820_outline_0003
      007B7F 90 0B 94         [24] 1667 	mov	dptr,#_action_for_key_PARM_2
      007B82 F5 F0            [12] 1668 	mov	b,a
      007B84 C0 07            [24] 1669 	push	ar7
      007B86 12 BD 3B         [24] 1670 	lcall	___memcpy
      007B89 D0 07            [24] 1671 	pop	ar7
      007B8B 8F 82            [24] 1672 	mov	dpl, r7
                                   1673 ;	quantum/action_layer.c:540: return action;
                                   1674 ;	quantum/action_layer.c:541: }
      007B8D 02 96 9A         [24] 1675 	ljmp	_action_for_key
                                   1676 ;------------------------------------------------------------
                                   1677 ;Allocation info for local variables in function 'update_tri_layer_state'
                                   1678 ;------------------------------------------------------------
                                   1679 ;layer1        Allocated with name '_update_tri_layer_state_PARM_2'
                                   1680 ;layer2        Allocated with name '_update_tri_layer_state_PARM_3'
                                   1681 ;layer3        Allocated with name '_update_tri_layer_state_PARM_4'
                                   1682 ;state         Allocated with name '_update_tri_layer_state_state_10000_406'
                                   1683 ;mask12        Allocated with name '_update_tri_layer_state_mask12_10000_407'
                                   1684 ;mask3         Allocated with name '_update_tri_layer_state_mask3_10000_407'
                                   1685 ;------------------------------------------------------------
                                   1686 ;	quantum/action_layer.c:544: layer_state_t update_tri_layer_state(layer_state_t state, uint8_t layer1, uint8_t layer2, uint8_t layer3) {
                                   1687 ;	-----------------------------------------
                                   1688 	.area CSEG    (CODE)
                                   1689 	.area CONST   (CODE)
                                   1690 	.area XINIT   (CODE)
      00C61E                       1691 __xinit__default_layer_state:
      00C61E 00                    1692 	.db #0x00	; 0
      00C61F                       1693 __xinit__layer_state:
      00C61F 00                    1694 	.db #0x00	; 0
                                   1695 	.area CABS    (ABS,CODE)
                                   1696 
                                   1697 ; Experimental exact instruction outlining.
                                   1698 	.globl _ak820_outline_0000
                                   1699 	.globl _ak820_outline_0002
                                   1700 	.globl _ak820_outline_0003
                                   1701 	.globl _ak820_outline_0006
                                   1702 	.globl _ak820_outline_0007
                                   1703 	.globl _ak820_outline_0010
                                   1704 	.globl _ak820_outline_0012
                                   1705 	.globl _ak820_outline_0021
                                   1706 	.globl _ak820_outline_0023
                                   1707 	.globl _ak820_outline_0027
                                   1708 	.globl _ak820_outline_0032
                                   1709 	.globl _ak820_outline_0034
                                   1710 	.globl _ak820_outline_0071
                                   1711 	.globl _ak820_outline_0090
                                   1712 	.globl _ak820_outline_0096
                                   1713 	.globl _ak820_outline_0101
                                   1714 	.globl _ak820_outline_0105
                                   1715 	.globl _ak820_outline_0106
                                   1716 	.globl _ak820_outline_0120
                                   1717 	.globl _ak820_outline_0129
                                   1718 	.globl _ak820_outline_0132
                                   1719 	.globl _ak820_outline_0138
                                   1720 
                                   1721 	.area CSEG (CODE)
                                   1722 ; function ak820_outline_0032
      007B90                       1723 _ak820_outline_0032:
      007B90 90 0D B6         [24] 1724 	mov	dptr,#___memcpy_PARM_3
      007B93 74 02            [12] 1725 	mov	a,#0x02
      007B95 22               [24] 1726 	ret
                                   1727 
                                   1728 	.area CSEG (CODE)
                                   1729 ; function ak820_outline_0034
      007B96                       1730 _ak820_outline_0034:
      007B96 90 0D B3         [24] 1731 	mov	dptr,#___memcpy_PARM_2
      007B99 74 58            [12] 1732 	mov	a,#_store_or_get_action_PARM_2
      007B9B F0               [24] 1733 	movx	@dptr,a
      007B9C 74 09            [12] 1734 	mov	a,#(_store_or_get_action_PARM_2>>8)
      007B9E A3               [24] 1735 	inc	dptr
      007B9F 22               [24] 1736 	ret
                                   1737 
                                   1738 	.area CSEG (CODE)
                                   1739 ; function ak820_outline_0090
      007BA0                       1740 _ak820_outline_0090:
      007BA0 E0               [24] 1741 	movx	a,@dptr
      007BA1 42 07            [12] 1742 	orl	ar7,a
      007BA3 8F 82            [24] 1743 	mov	dpl,r7
      007BA5 22               [24] 1744 	ret
                                   1745 
                                   1746 	.area CSEG (CODE)
                                   1747 ; function ak820_outline_0105
      007BA6                       1748 _ak820_outline_0105:
      007BA6 90 0D B3         [24] 1749 	mov	dptr,#___memcpy_PARM_2
      007BA9 74 60            [12] 1750 	mov	a,#_layer_switch_get_action_PARM_1
      007BAB F0               [24] 1751 	movx	@dptr,a
      007BAC 74 09            [12] 1752 	mov	a,#(_layer_switch_get_action_PARM_1>>8)
      007BAE A3               [24] 1753 	inc	dptr
      007BAF 22               [24] 1754 	ret
                                   1755 
                                   1756 	.area CSEG (CODE)
                                   1757 ; function ak820_outline_0106
      007BB0                       1758 _ak820_outline_0106:
      007BB0 90 0D B3         [24] 1759 	mov	dptr,#___memcpy_PARM_2
      007BB3 74 53            [12] 1760 	mov	a,#_update_source_layers_cache_PARM_1
      007BB5 F0               [24] 1761 	movx	@dptr,a
      007BB6 74 09            [12] 1762 	mov	a,#(_update_source_layers_cache_PARM_1>>8)
      007BB8 A3               [24] 1763 	inc	dptr
      007BB9 22               [24] 1764 	ret
                                   1765 
                                   1766 	.area CSEG (CODE)
                                   1767 ; function ak820_outline_0120
      007BBA                       1768 _ak820_outline_0120:
      007BBA F5 83            [12] 1769 	mov	dph,a
      007BBC E4               [12] 1770 	clr	a
      007BBD F0               [24] 1771 	movx	@dptr,a
      007BBE 0F               [12] 1772 	inc	r7
      007BBF 22               [24] 1773 	ret
                                   1774 
                                   1775 	.area CSEG (CODE)
                                   1776 ; function ak820_outline_0138
      007BC0                       1777 _ak820_outline_0138:
      007BC0 90 09 78         [24] 1778 	mov	dptr,#_ak820_macro_change_PARM_2
      007BC3 EF               [12] 1779 	mov	a,r7
      007BC4 F0               [24] 1780 	movx	@dptr,a
      007BC5 90 09 79         [24] 1781 	mov	dptr,#_ak820_macro_change_PARM_3
      007BC8 22               [24] 1782 	ret
