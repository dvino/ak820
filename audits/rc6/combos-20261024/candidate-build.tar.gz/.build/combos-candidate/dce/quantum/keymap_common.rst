                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keymap_common
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _KEYCODE2CONSUMER
                                     12 	.globl _keycode_at_encodermap_location
                                     13 	.globl _keycode_at_keymap_location
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _keymap_key_to_keycode_PARM_2
                                    258 	.globl _action_for_key_PARM_2
                                    259 	.globl _action_for_key
                                    260 	.globl _action_for_keycode
                                    261 	.globl _keymap_key_to_keycode
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
                                    540 ;--------------------------------------------------------
                                    541 ; paged external ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area PSEG    (PAG,XDATA)
                                    544 ;--------------------------------------------------------
                                    545 ; uninitialized external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area XSEG    (XDATA)
      000B94                        548 _action_for_key_PARM_2:
      000B94                        549 	.ds 2
      000B96                        550 _action_for_key_layer_10000_304:
      000B96                        551 	.ds 1
      000B97                        552 _action_for_keycode_keycode_10000_306:
      000B97                        553 	.ds 2
      000B99                        554 _action_for_keycode_kind_10000_307:
      000B99                        555 	.ds 1
      000B9A                        556 _action_for_keycode_mods_10000_307:
      000B9A                        557 	.ds 1
      000B9B                        558 _action_for_keycode___400000077_40000_309:
      000B9B                        559 	.ds 2
      000B9D                        560 _action_for_keycode_key_60000_324:
      000B9D                        561 	.ds 1
      000B9E                        562 _keymap_key_to_keycode_PARM_2:
      000B9E                        563 	.ds 2
      000BA0                        564 _keymap_key_to_keycode_layer_10000_326:
      000BA0                        565 	.ds 1
                                    566 ;--------------------------------------------------------
                                    567 ; absolute external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area XABS    (ABS,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; initialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XISEG   (XDATA)
                                    574 	.area HOME    (CODE)
                                    575 	.area GSINIT0 (CODE)
                                    576 	.area GSINIT1 (CODE)
                                    577 	.area GSINIT2 (CODE)
                                    578 	.area GSINIT3 (CODE)
                                    579 	.area GSINIT4 (CODE)
                                    580 	.area GSINIT5 (CODE)
                                    581 	.area GSINIT  (CODE)
                                    582 	.area GSFINAL (CODE)
                                    583 	.area CSEG    (CODE)
                                    584 ;--------------------------------------------------------
                                    585 ; global & static initialisations
                                    586 ;--------------------------------------------------------
                                    587 	.area HOME    (CODE)
                                    588 	.area GSINIT  (CODE)
                                    589 	.area GSFINAL (CODE)
                                    590 	.area GSINIT  (CODE)
                                    591 ;--------------------------------------------------------
                                    592 ; Home
                                    593 ;--------------------------------------------------------
                                    594 	.area HOME    (CODE)
                                    595 	.area HOME    (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; code
                                    598 ;--------------------------------------------------------
                                    599 	.area CSEG    (CODE)
                                    600 ;------------------------------------------------------------
                                    601 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    602 ;------------------------------------------------------------
                                    603 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_107'
                                    604 ;------------------------------------------------------------
                                    605 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    606 ;	-----------------------------------------
                           000007   607 	ar7 = 0x07
                           000006   608 	ar6 = 0x06
                           000005   609 	ar5 = 0x05
                           000004   610 	ar4 = 0x04
                           000003   611 	ar3 = 0x03
                           000002   612 	ar2 = 0x02
                           000001   613 	ar1 = 0x01
                           000000   614 	ar0 = 0x00
                                    615 ;	 function action_for_key
                                    616 ;	-----------------------------------------
      00969A                        617 _action_for_key:
      00969A E5 82            [12]  618 	mov	a,dpl
      00969C 90 0B 96         [24]  619 	mov	dptr,#_action_for_key_layer_10000_304
      00969F F0               [24]  620 	movx	@dptr,a
                                    621 ;	quantum/keymap_common.c:59: uint16_t keycode = keymap_key_to_keycode(layer, key);
      0096A0 E0               [24]  622 	movx	a,@dptr
      0096A1 FF               [12]  623 	mov	r7,a
      0096A2 90 0D B3         [24]  624 	mov	dptr,#___memcpy_PARM_2
      0096A5 74 94            [12]  625 	mov	a,#_action_for_key_PARM_2
      0096A7 F0               [24]  626 	movx	@dptr,a
      0096A8 74 0B            [12]  627 	mov	a,#(_action_for_key_PARM_2 >> 8)
      0096AA A3               [24]  628 	inc	dptr
      0096AB 12 4E 60         [24]  629 	lcall	_ak820_outline_0003
      0096AE 90 0D B6         [24]  630 	mov	dptr,#___memcpy_PARM_3
      0096B1 74 02            [12]  631 	mov	a,#0x02
      0096B3 12 4E 60         [24]  632 	lcall	_ak820_outline_0003
      0096B6 90 0B 9E         [24]  633 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      0096B9 F5 F0            [12]  634 	mov	b,a
      0096BB C0 07            [24]  635 	push	ar7
      0096BD 12 BD 3B         [24]  636 	lcall	___memcpy
      0096C0 D0 07            [24]  637 	pop	ar7
      0096C2 8F 82            [24]  638 	mov	dpl, r7
      0096C4 12 98 32         [24]  639 	lcall	_keymap_key_to_keycode
                                    640 ;	quantum/keymap_common.c:61: return action_for_keycode(keycode);
      0096C7 AF 83            [24]  641 	mov  r7,dph
                                    642 ;	quantum/keymap_common.c:62: }
      0096C9 02 96 CC         [24]  643 	ljmp	_action_for_keycode
                                    644 ;------------------------------------------------------------
                                    645 ;Allocation info for local variables in function 'action_for_keycode'
                                    646 ;------------------------------------------------------------
                                    647 ;keycode       Allocated with name '_action_for_keycode_keycode_10000_306'
                                    648 ;kind          Allocated with name '_action_for_keycode_kind_10000_307'
                                    649 ;key           Allocated with name '_action_for_keycode_key_10000_307'
                                    650 ;mods          Allocated with name '_action_for_keycode_mods_10000_307'
                                    651 ;__400000077   Allocated with name '_action_for_keycode___400000077_40000_309'
                                    652 ;__500000078   Allocated with name '_action_for_keycode___500000078_50000_323'
                                    653 ;key           Allocated with name '_action_for_keycode_key_60000_324'
                                    654 ;layer         Allocated with name '_action_for_keycode_layer_30000_318'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/keymap_common.c:64: uint16_t action_for_keycode(uint16_t keycode) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function action_for_keycode
                                    659 ;	-----------------------------------------
      0096CC                        660 _action_for_keycode:
      0096CC 12 43 EA         [24]  661 	lcall	_ak820_outline_0010
      0096CF 90 0B 97         [24]  662 	mov	dptr,#_action_for_keycode_keycode_10000_306
      0096D2 12 43 E5         [24]  663 	lcall	_ak820_outline_0007
                                    664 ;	quantum/keymap_common.c:87: uint8_t kind = (uint8_t)(keycode >> 8);
      0096D5 90 0B 97         [24]  665 	mov	dptr,#_action_for_keycode_keycode_10000_306
      0096D8 12 43 C5         [24]  666 	lcall	_ak820_outline_0000
                                    667 ;	quantum/keymap_common.c:88: uint8_t key = (uint8_t)keycode;
                                    668 ;	quantum/keymap_common.c:90: if (!kind) {
      0096DB FD               [12]  669 	mov	r5,a
      0096DC 8E 04            [24]  670 	mov	ar4,r6
      0096DE 70 74            [24]  671 	jnz	00117$
                                    672 ;	quantum/keymap_common.c:91: if ((key >= KC_A && key <= KC_EXSEL) ||
      0096E0 BC 04 00         [24]  673 	cjne	r4,#0x04,00251$
      0096E3                        674 00251$:
      0096E3 40 05            [24]  675 	jc	00105$
      0096E5 EC               [12]  676 	mov	a,r4
      0096E6 24 5B            [12]  677 	add	a,#0xff - 0xa4
      0096E8 50 0D            [24]  678 	jnc	00101$
                                    679 ;	free result
      0096EA                        680 00105$:
                                    681 ;	quantum/keymap_common.c:92: (key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI) || key == KC_TRANSPARENT)
      0096EA BC E0 00         [24]  682 	cjne	r4,#0xe0,00254$
      0096ED                        683 00254$:
      0096ED 40 05            [24]  684 	jc	00106$
      0096EF EC               [12]  685 	mov	a,r4
      0096F0 24 18            [12]  686 	add	a,#0xff - 0xe7
      0096F2 50 03            [24]  687 	jnc	00101$
                                    688 ;	free result
      0096F4                        689 00106$:
      0096F4 BC 01 08         [24]  690 	cjne	r4,#0x01,00102$
      0096F7                        691 00101$:
                                    692 ;	quantum/keymap_common.c:93: return ACTION_KEY(key);
      0096F7 8C 02            [24]  693 	mov	ar2,r4
      0096F9 7B 00            [12]  694 	mov	r3,#0x00
      0096FB 12 44 22         [24]  695 	lcall	_ak820_outline_0033
      0096FE 22               [24]  696 	ret
      0096FF                        697 00102$:
                                    698 ;	quantum/keymap_common.c:95: if (key >= KC_SYSTEM_POWER && key <= KC_SYSTEM_WAKE)
      0096FF BC A5 00         [24]  699 	cjne	r4,#0xa5,00259$
      009702                        700 00259$:
      009702 40 1D            [24]  701 	jc	00108$
      009704 EC               [12]  702 	mov	a,r4
      009705 24 58            [12]  703 	add	a,#0xff - 0xa7
      009707 40 18            [24]  704 	jc	00108$
                                    705 ;	free result
                                    706 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      009709 8C 03            [24]  707 	mov	ar3,r4
      00970B 74 DC            [12]  708 	mov	a,#0xdc
      00970D 2B               [12]  709 	add	a, r3
      00970E 90 0B 9B         [24]  710 	mov	dptr,#_action_for_keycode___400000077_40000_309
      009711 12 4E 60         [24]  711 	lcall	_ak820_outline_0003
                                    712 ;	quantum/keymap_common.c:96: return ACTION_USAGE_SYSTEM(KEYCODE2SYSTEM(key));
      009714 90 0B 9B         [24]  713 	mov	dptr,#_action_for_keycode___400000077_40000_309
      009717 12 44 11         [24]  714 	lcall	_ak820_outline_0024
      00971A 43 03 40         [24]  715 	orl	ar3,#0x40
      00971D 12 44 22         [24]  716 	lcall	_ak820_outline_0033
      009720 22               [24]  717 	ret
      009721                        718 00108$:
                                    719 ;	quantum/keymap_common.c:97: if (key >= KC_AUDIO_MUTE && key <= KC_LAUNCHPAD)
      009721 BC A8 00         [24]  720 	cjne	r4,#0xa8,00262$
      009724                        721 00262$:
      009724 40 15            [24]  722 	jc	00111$
      009726 EC               [12]  723 	mov	a,r4
      009727 24 3D            [12]  724 	add	a,#0xff - 0xc2
      009729 40 10            [24]  725 	jc	00111$
                                    726 ;	free result
                                    727 ;	quantum/keymap_common.c:98: return ACTION_USAGE_CONSUMER(KEYCODE2CONSUMER(key));
      00972B 8C 82            [24]  728 	mov	dpl, r4
      00972D 12 6D EB         [24]  729 	lcall	_KEYCODE2CONSUMER
      009730 AA 82            [24]  730 	mov	r2, dpl
      009732 AB 83            [24]  731 	mov	r3, dph
      009734 43 03 44         [24]  732 	orl	ar3,#0x44
      009737 12 44 22         [24]  733 	lcall	_ak820_outline_0033
      00973A 22               [24]  734 	ret
      00973B                        735 00111$:
                                    736 ;	quantum/keymap_common.c:100: if (key >= KC_MS_UP && key <= KC_MS_ACCEL2) return ACTION_MOUSEKEY(key);
      00973B BC CD 00         [24]  737 	cjne	r4,#0xcd,00265$
      00973E                        738 00265$:
      00973E 40 10            [24]  739 	jc	00114$
      009740 EC               [12]  740 	mov	a,r4
      009741 24 20            [12]  741 	add	a,#0xff - 0xdf
      009743 40 0B            [24]  742 	jc	00114$
                                    743 ;	free result
      009745 8C 02            [24]  744 	mov	ar2,r4
      009747 7B 00            [12]  745 	mov	r3,#0x00
      009749 43 03 50         [24]  746 	orl	ar3,#0x50
      00974C 12 44 22         [24]  747 	lcall	_ak820_outline_0033
      00974F 22               [24]  748 	ret
      009750                        749 00114$:
                                    750 ;	quantum/keymap_common.c:101: return ACTION_NO;
      009750 90 00 00         [24]  751 	mov	dptr,#0x0000
      009753 22               [24]  752 	ret
      009754                        753 00117$:
                                    754 ;	quantum/keymap_common.c:103: if (kind < 0x20) return keycode; /* Encoded modifier+basic actions. */
      009754 BD 20 00         [24]  755 	cjne	r5,#0x20,00268$
      009757                        756 00268$:
      009757 50 04            [24]  757 	jnc	00119$
      009759 12 43 D3         [24]  758 	lcall	_ak820_outline_0002
      00975C 22               [24]  759 	ret
      00975D                        760 00119$:
                                    761 ;	quantum/keymap_common.c:104: if (kind < 0x50) {
      00975D BD 50 00         [24]  762 	cjne	r5,#0x50,00270$
      009760                        763 00270$:
      009760 50 04            [24]  764 	jnc	00121$
                                    765 ;	quantum/keymap_common.c:108: return ACTION_NO;
      009762 90 00 00         [24]  766 	mov	dptr,#0x0000
      009765 22               [24]  767 	ret
      009766                        768 00121$:
                                    769 ;	quantum/keymap_common.c:113: if (kind < 0x52) {
      009766 BD 52 00         [24]  770 	cjne	r5,#0x52,00272$
      009769                        771 00272$:
      009769 50 39            [24]  772 	jnc	00125$
                                    773 ;	quantum/keymap_common.c:114: uint8_t layer = ((kind & 1u) << 3) | (key >> 5);
      00976B 74 01            [12]  774 	mov	a,#0x01
      00976D 5D               [12]  775 	anl	a,r5
      00976E C4               [12]  776 	swap	a
      00976F 03               [12]  777 	rr	a
      009770 54 F8            [12]  778 	anl	a,#0xf8
      009772 FF               [12]  779 	mov	r7,a
      009773 EC               [12]  780 	mov	a,r4
      009774 C4               [12]  781 	swap	a
      009775 03               [12]  782 	rr	a
      009776 54 07            [12]  783 	anl	a,#0x07
      009778 42 07            [12]  784 	orl	ar7,a
                                    785 ;	quantum/keymap_common.c:115: mods = key & 0x1f;
      00977A 74 1F            [12]  786 	mov	a,#0x1f
      00977C 5C               [12]  787 	anl	a,r4
      00977D FE               [12]  788 	mov	r6,a
      00977E 90 0B 9A         [24]  789 	mov	dptr,#_action_for_keycode_mods_10000_307
      009781 F0               [24]  790 	movx	@dptr,a
                                    791 ;	quantum/keymap_common.c:116: if (mods & 0x10) mods <<= 4; /* Discard the 5-bit right-mod marker. */
      009782 EE               [12]  792 	mov	a,r6
      009783 30 E4 08         [24]  793 	jnb	acc.4,00123$
      009786 EE               [12]  794 	mov	a,r6
      009787 C4               [12]  795 	swap	a
      009788 54 F0            [12]  796 	anl	a,#0xf0
      00978A 90 0B 9A         [24]  797 	mov	dptr,#_action_for_keycode_mods_10000_307
      00978D F0               [24]  798 	movx	@dptr,a
      00978E                        799 00123$:
                                    800 ;	quantum/keymap_common.c:117: return ACTION_LAYER_MODS(layer, mods);
      00978E 8F 06            [24]  801 	mov	ar6,r7
      009790 7F 00            [12]  802 	mov	r7,#0x00
      009792 90 0B 9A         [24]  803 	mov	dptr,#_action_for_keycode_mods_10000_307
      009795 E0               [24]  804 	movx	a,@dptr
      009796 7B 00            [12]  805 	mov	r3,#0x00
      009798 42 07            [12]  806 	orl	ar7,a
      00979A EB               [12]  807 	mov	a,r3
      00979B 42 06            [12]  808 	orl	ar6,a
      00979D 43 06 90         [24]  809 	orl	ar6,#0x90
      0097A0 12 44 79         [24]  810 	lcall	_ak820_outline_0129
      0097A3 22               [24]  811 	ret
      0097A4                        812 00125$:
                                    813 ;	quantum/keymap_common.c:119: if (kind != 0x52) return ACTION_NO;
      0097A4 BD 52 02         [24]  814 	cjne	r5,#0x52,00275$
      0097A7 80 04            [24]  815 	sjmp	00127$
      0097A9                        816 00275$:
      0097A9 90 00 00         [24]  817 	mov	dptr,#0x0000
      0097AC 22               [24]  818 	ret
      0097AD                        819 00127$:
                                    820 ;	quantum/keymap_common.c:120: mods = key & 0x1f;
      0097AD 74 1F            [12]  821 	mov	a,#0x1f
      0097AF 5C               [12]  822 	anl	a,r4
      0097B0 FF               [12]  823 	mov	r7,a
                                    824 ;	quantum/keymap_common.c:121: switch (key >> 5) {
      0097B1 EC               [12]  825 	mov	a,r4
      0097B2 C4               [12]  826 	swap	a
      0097B3 03               [12]  827 	rr	a
      0097B4 54 07            [12]  828 	anl	a,#0x07
      0097B6 FE               [12]  829 	mov  r6,a
      0097B7 24 F9            [12]  830 	add	a,#0xff - 0x06
      0097B9 40 47            [24]  831 	jc	00134$
                                    832 ;	free result
      0097BB EE               [12]  833 	mov	a,r6
      0097BC 2E               [12]  834 	add	a,r6
                                    835 ;	quantum/keymap_common.c:122: case 0: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2) | ON_PRESS; break;
      0097BD 90 97 C1         [24]  836 	mov	dptr,#00277$
      0097C0 73               [24]  837 	jmp	@a+dptr
      0097C1                        838 00277$:
      0097C1 80 0C            [24]  839 	sjmp	00128$
      0097C3 80 12            [24]  840 	sjmp	00129$
      0097C5 80 20            [24]  841 	sjmp	00130$
      0097C7 80 26            [24]  842 	sjmp	00132$
      0097C9 80 37            [24]  843 	sjmp	00134$
      0097CB 80 2A            [24]  844 	sjmp	00133$
      0097CD 80 20            [24]  845 	sjmp	00132$
      0097CF                        846 00128$:
      0097CF 90 0B 99         [24]  847 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097D2 74 8D            [12]  848 	mov	a,#0x8d
      0097D4 F0               [24]  849 	movx	@dptr,a
                                    850 ;	quantum/keymap_common.c:123: case 1: return ACTION_LAYER_MOMENTARY(mods);
      0097D5 80 2F            [24]  851 	sjmp	00135$
      0097D7                        852 00129$:
      0097D7 8F 05            [24]  853 	mov	ar5,r7
      0097D9 8D 06            [24]  854 	mov	ar6,r5
      0097DB 7D 00            [12]  855 	mov	r5,#0x00
      0097DD 43 05 F1         [24]  856 	orl	ar5,#0xf1
      0097E0 43 06 A0         [24]  857 	orl	ar6,#0xa0
      0097E3 12 43 F4         [24]  858 	lcall	_ak820_outline_0012
                                    859 ;	quantum/keymap_common.c:124: case 2: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2); break;
      0097E6 22               [24]  860 	ret
      0097E7                        861 00130$:
      0097E7 90 0B 99         [24]  862 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097EA 74 8C            [12]  863 	mov	a,#0x8c
      0097EC F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/keymap_common.c:126: case 6: kind = (ACT_LAYER << 4) | (OP_BIT_XOR << 2) | ON_RELEASE; break;
      0097ED 80 17            [24]  866 	sjmp	00135$
      0097EF                        867 00132$:
      0097EF 90 0B 99         [24]  868 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097F2 74 8A            [12]  869 	mov	a,#0x8a
      0097F4 F0               [24]  870 	movx	@dptr,a
                                    871 ;	quantum/keymap_common.c:127: case 5: return ACTION_MODS(mods); /* Existing held-mod fallback for OSM. */
      0097F5 80 0F            [24]  872 	sjmp	00135$
      0097F7                        873 00133$:
      0097F7 53 07 1F         [24]  874 	anl	ar7,#0x1f
      0097FA 8F 06            [24]  875 	mov	ar6,r7
      0097FC 7F 00            [12]  876 	mov	r7,#0x00
      0097FE 12 44 79         [24]  877 	lcall	_ak820_outline_0129
                                    878 ;	quantum/keymap_common.c:128: default: return ACTION_NO;
      009801 22               [24]  879 	ret
      009802                        880 00134$:
      009802 90 00 00         [24]  881 	mov	dptr,#0x0000
                                    882 ;	quantum/keymap_common.c:129: }
      009805 22               [24]  883 	ret
      009806                        884 00135$:
                                    885 ;	quantum/keymap_common.c:131: key = ((key & 0x1c) << 3) | (1u << (key & 3));
      009806 8C 07            [24]  886 	mov	ar7,r4
      009808 53 07 1C         [24]  887 	anl	ar7,#0x1c
      00980B EF               [12]  888 	mov	a,r7
      00980C C4               [12]  889 	swap	a
      00980D 03               [12]  890 	rr	a
      00980E 54 F8            [12]  891 	anl	a,#0xf8
      009810 FF               [12]  892 	mov	r7,a
      009811 74 03            [12]  893 	mov	a,#0x03
      009813 5C               [12]  894 	anl	a,r4
      009814 12 70 13         [24]  895 	lcall	_ak820_outline_0021
      009817 80 02            [24]  896 	sjmp	00279$
      009819                        897 00278$:
      009819 25 E0            [12]  898 	add	a,acc
      00981B                        899 00279$:
      00981B D5 F0 FB         [24]  900 	djnz	b,00278$
      00981E 42 07            [12]  901 	orl	ar7,a
                                    902 ;	quantum/keymap_common.c:132: return ((uint16_t)kind << 8) | key;
      009820 90 0B 99         [24]  903 	mov	dptr,#_action_for_keycode_kind_10000_307
      009823 E0               [24]  904 	movx	a,@dptr
      009824 FE               [12]  905 	mov	r6,a
      009825 E4               [12]  906 	clr	a
      009826 FD               [12]  907 	mov	r5,a
      009827 FC               [12]  908 	mov	r4,a
      009828 EF               [12]  909 	mov	a,r7
      009829 42 05            [12]  910 	orl	ar5,a
      00982B EC               [12]  911 	mov	a,r4
      00982C 42 06            [12]  912 	orl	ar6,a
      00982E 12 43 F4         [24]  913 	lcall	_ak820_outline_0012
                                    914 ;	quantum/keymap_common.c:277: }
      009831 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'keymap_key_to_keycode'
                                    918 ;------------------------------------------------------------
                                    919 ;key           Allocated with name '_keymap_key_to_keycode_PARM_2'
                                    920 ;layer         Allocated with name '_keymap_key_to_keycode_layer_10000_326'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/keymap_common.c:280: __attribute__((weak)) uint16_t keymap_key_to_keycode(uint8_t layer, keypos_t key) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function keymap_key_to_keycode
                                    925 ;	-----------------------------------------
      009832                        926 _keymap_key_to_keycode:
      009832 E5 82            [12]  927 	mov	a,dpl
      009834 90 0B A0         [24]  928 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      009837 F0               [24]  929 	movx	@dptr,a
                                    930 ;	quantum/keymap_common.c:285: if (vial_unlock_in_progress) {
      009838 90 0E 33         [24]  931 	mov	dptr,#_vial_unlock_in_progress
      00983B E0               [24]  932 	movx	a,@dptr
      00983C 60 04            [24]  933 	jz	00102$
                                    934 ;	quantum/keymap_common.c:286: return KC_NO;
      00983E 90 00 00         [24]  935 	mov	dptr,#0x0000
      009841 22               [24]  936 	ret
      009842                        937 00102$:
                                    938 ;	quantum/keymap_common.c:288: if (key.row == VIAL_MATRIX_MAGIC && key.col == VIAL_MATRIX_MAGIC) {
      009842 90 0B 9F         [24]  939 	mov	dptr,#(_keymap_key_to_keycode_PARM_2 + 0x0001)
      009845 E0               [24]  940 	movx	a,@dptr
      009846 FF               [12]  941 	mov	r7,a
      009847 BF F0 12         [24]  942 	cjne	r7,#0xf0,00104$
      00984A 90 0B 9E         [24]  943 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      00984D E0               [24]  944 	movx	a,@dptr
      00984E FE               [12]  945 	mov	r6,a
      00984F BE F0 0A         [24]  946 	cjne	r6,#0xf0,00104$
                                    947 ;	quantum/keymap_common.c:289: return g_vial_magic_keycode_override;
      009852 90 0C 8B         [24]  948 	mov	dptr,#_g_vial_magic_keycode_override
      009855 12 44 17         [24]  949 	lcall	_ak820_outline_0025
      009858 12 43 F4         [24]  950 	lcall	_ak820_outline_0012
      00985B 22               [24]  951 	ret
      00985C                        952 00104$:
                                    953 ;	quantum/keymap_common.c:292: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) {
      00985C BF 10 00         [24]  954 	cjne	r7,#0x10,00187$
      00985F                        955 00187$:
      00985F 50 1E            [24]  956 	jnc	00114$
      009861 90 0B 9E         [24]  957 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      009864 E0               [24]  958 	movx	a,@dptr
      009865 FE               [12]  959 	mov	r6,a
      009866 BE 08 00         [24]  960 	cjne	r6,#0x08,00189$
      009869                        961 00189$:
      009869 50 14            [24]  962 	jnc	00114$
                                    963 ;	quantum/keymap_common.c:294: return keycode_at_keymap_location(layer, key.row, key.col);
      00986B 90 0B A0         [24]  964 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      00986E E0               [24]  965 	movx	a,@dptr
      00986F FD               [12]  966 	mov	r5,a
      009870 90 0B 17         [24]  967 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009873 EF               [12]  968 	mov	a,r7
      009874 F0               [24]  969 	movx	@dptr,a
      009875 90 0B 18         [24]  970 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      009878 EE               [12]  971 	mov	a,r6
      009879 F0               [24]  972 	movx	@dptr,a
      00987A 8D 82            [24]  973 	mov	dpl, r5
      00987C 02 8A E2         [24]  974 	ljmp	_keycode_at_keymap_location
      00987F                        975 00114$:
                                    976 ;	quantum/keymap_common.c:297: else if (key.row == KEYLOC_ENCODER_CW && key.col < NUM_ENCODERS) {
      00987F BF FD 19         [24]  977 	cjne	r7,#0xfd,00110$
      009882 90 0B 9E         [24]  978 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      009885 E0               [24]  979 	movx	a,@dptr
      009886 FE               [12]  980 	mov	r6,a
      009887 BE 01 00         [24]  981 	cjne	r6,#0x01,00193$
      00988A                        982 00193$:
      00988A 50 0F            [24]  983 	jnc	00110$
                                    984 ;	quantum/keymap_common.c:298: return keycode_at_encodermap_location(layer, key.col, true);
      00988C 90 0B A0         [24]  985 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      00988F E0               [24]  986 	movx	a,@dptr
      009890 FE               [12]  987 	mov	r6,a
      009891 12 98 BA         [24]  988 	lcall	_ak820_outline_0140
      009894 04               [12]  989 	inc	a
      009895 F0               [24]  990 	movx	@dptr,a
      009896 8E 82            [24]  991 	mov	dpl, r6
      009898 02 8B 16         [24]  992 	ljmp	_keycode_at_encodermap_location
      00989B                        993 00110$:
                                    994 ;	quantum/keymap_common.c:299: } else if (key.row == KEYLOC_ENCODER_CCW && key.col < NUM_ENCODERS) {
      00989B BF FC 18         [24]  995 	cjne	r7,#0xfc,00115$
      00989E 90 0B 9E         [24]  996 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      0098A1 E0               [24]  997 	movx	a,@dptr
      0098A2 FF               [12]  998 	mov	r7,a
      0098A3 BF 01 00         [24]  999 	cjne	r7,#0x01,00197$
      0098A6                       1000 00197$:
      0098A6 50 0E            [24] 1001 	jnc	00115$
                                   1002 ;	quantum/keymap_common.c:300: return keycode_at_encodermap_location(layer, key.col, false);
      0098A8 90 0B A0         [24] 1003 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      0098AB E0               [24] 1004 	movx	a,@dptr
      0098AC FF               [12] 1005 	mov	r7,a
      0098AD 12 98 BA         [24] 1006 	lcall	_ak820_outline_0140
      0098B0 F0               [24] 1007 	movx	@dptr,a
      0098B1 8F 82            [24] 1008 	mov	dpl, r7
      0098B3 02 8B 16         [24] 1009 	ljmp	_keycode_at_encodermap_location
      0098B6                       1010 00115$:
                                   1011 ;	quantum/keymap_common.c:303: return KC_NO;
      0098B6 90 00 00         [24] 1012 	mov	dptr,#0x0000
                                   1013 ;	quantum/keymap_common.c:304: }
      0098B9 22               [24] 1014 	ret
                                   1015 	.area CSEG    (CODE)
                                   1016 	.area CONST   (CODE)
                                   1017 	.area XINIT   (CODE)
                                   1018 	.area CABS    (ABS,CODE)
                                   1019 
                                   1020 ; Experimental exact instruction outlining.
                                   1021 	.globl _ak820_outline_0000
                                   1022 	.globl _ak820_outline_0002
                                   1023 	.globl _ak820_outline_0003
                                   1024 	.globl _ak820_outline_0007
                                   1025 	.globl _ak820_outline_0010
                                   1026 	.globl _ak820_outline_0012
                                   1027 	.globl _ak820_outline_0021
                                   1028 	.globl _ak820_outline_0024
                                   1029 	.globl _ak820_outline_0025
                                   1030 	.globl _ak820_outline_0033
                                   1031 	.globl _ak820_outline_0129
                                   1032 	.globl _ak820_outline_0140
                                   1033 
                                   1034 	.area CSEG (CODE)
                                   1035 ; function ak820_outline_0140
      0098BA                       1036 _ak820_outline_0140:
      0098BA 90 0B 1A         [24] 1037 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0098BD E4               [12] 1038 	clr	a
      0098BE F0               [24] 1039 	movx	@dptr,a
      0098BF 90 0B 1B         [24] 1040 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0098C2 22               [24] 1041 	ret
