                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module print
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _putchar_
                                     12 	.globl _print_set_sendchar
                                     13 ;--------------------------------------------------------
                                     14 ; special function registers
                                     15 ;--------------------------------------------------------
                                     16 	.area RSEG    (ABS,DATA)
      000000                         17 	.org 0x0000
                                     18 ;--------------------------------------------------------
                                     19 ; special function bits
                                     20 ;--------------------------------------------------------
                                     21 	.area RSEG    (ABS,DATA)
      000000                         22 	.org 0x0000
                                     23 ;--------------------------------------------------------
                                     24 ; overlayable register banks
                                     25 ;--------------------------------------------------------
                                     26 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         27 	.ds 8
                                     28 ;--------------------------------------------------------
                                     29 ; internal ram data
                                     30 ;--------------------------------------------------------
                                     31 	.area DSEG    (DATA)
                                     32 ;--------------------------------------------------------
                                     33 ; overlayable items in internal ram
                                     34 ;--------------------------------------------------------
                                     35 ;--------------------------------------------------------
                                     36 ; indirectly addressable internal ram data
                                     37 ;--------------------------------------------------------
                                     38 	.area ISEG    (DATA)
                                     39 ;--------------------------------------------------------
                                     40 ; absolute internal ram data
                                     41 ;--------------------------------------------------------
                                     42 	.area IABS    (ABS,DATA)
                                     43 	.area IABS    (ABS,DATA)
                                     44 ;--------------------------------------------------------
                                     45 ; bit data
                                     46 ;--------------------------------------------------------
                                     47 	.area BSEG    (BIT)
                                     48 ;--------------------------------------------------------
                                     49 ; paged external ram data
                                     50 ;--------------------------------------------------------
                                     51 	.area PSEG    (PAG,XDATA)
                                     52 ;--------------------------------------------------------
                                     53 ; uninitialized external ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area XSEG    (XDATA)
      000BAD                         56 _print_set_sendchar_send_10000_6:
      000BAD                         57 	.ds 2
      000BAF                         58 _putchar__character_10000_8:
      000BAF                         59 	.ds 1
                                     60 ;--------------------------------------------------------
                                     61 ; absolute external ram data
                                     62 ;--------------------------------------------------------
                                     63 	.area XABS    (ABS,XDATA)
                                     64 ;--------------------------------------------------------
                                     65 ; initialized external ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area XISEG   (XDATA)
      000E25                         68 _func:
      000E25                         69 	.ds 2
                                     70 	.area HOME    (CODE)
                                     71 	.area GSINIT0 (CODE)
                                     72 	.area GSINIT1 (CODE)
                                     73 	.area GSINIT2 (CODE)
                                     74 	.area GSINIT3 (CODE)
                                     75 	.area GSINIT4 (CODE)
                                     76 	.area GSINIT5 (CODE)
                                     77 	.area GSINIT  (CODE)
                                     78 	.area GSFINAL (CODE)
                                     79 	.area CSEG    (CODE)
                                     80 ;--------------------------------------------------------
                                     81 ; global & static initialisations
                                     82 ;--------------------------------------------------------
                                     83 	.area HOME    (CODE)
                                     84 	.area GSINIT  (CODE)
                                     85 	.area GSFINAL (CODE)
                                     86 	.area GSINIT  (CODE)
                                     87 ;--------------------------------------------------------
                                     88 ; Home
                                     89 ;--------------------------------------------------------
                                     90 	.area HOME    (CODE)
                                     91 	.area HOME    (CODE)
                                     92 ;--------------------------------------------------------
                                     93 ; code
                                     94 ;--------------------------------------------------------
                                     95 	.area CSEG    (CODE)
                                     96 ;------------------------------------------------------------
                                     97 ;Allocation info for local variables in function 'null_sendchar_func'
                                     98 ;------------------------------------------------------------
                                     99 ;c             Allocated with name '_null_sendchar_func_c_10000_4'
                                    100 ;------------------------------------------------------------
                                    101 ;	quantum/logging/print.c:22: static int8_t null_sendchar_func(uint8_t c) {
                                    102 ;	-----------------------------------------
                                    103 ;	 function null_sendchar_func
                                    104 ;	-----------------------------------------
      009A06                        105 _null_sendchar_func:
                           000007   106 	ar7 = 0x07
                           000006   107 	ar6 = 0x06
                           000005   108 	ar5 = 0x05
                           000004   109 	ar4 = 0x04
                           000003   110 	ar3 = 0x03
                           000002   111 	ar2 = 0x02
                           000001   112 	ar1 = 0x01
                           000000   113 	ar0 = 0x00
                                    114 ;	quantum/logging/print.c:23: return 0;
      009A06 75 82 00         [24]  115 	mov	dpl, #0x00
                                    116 ;	quantum/logging/print.c:24: }
      009A09 22               [24]  117 	ret
                                    118 ;------------------------------------------------------------
                                    119 ;Allocation info for local variables in function 'print_set_sendchar'
                                    120 ;------------------------------------------------------------
                                    121 ;send          Allocated with name '_print_set_sendchar_send_10000_6'
                                    122 ;------------------------------------------------------------
                                    123 ;	quantum/logging/print.c:27: void print_set_sendchar(sendchar_func_t send) {
                                    124 ;	-----------------------------------------
                                    125 ;	 function print_set_sendchar
                                    126 ;	-----------------------------------------
      009A0A                        127 _print_set_sendchar:
      009A0A 12 43 EA         [24]  128 	lcall	_ak820_outline_0010
      009A0D 90 0B AD         [24]  129 	mov	dptr,#_print_set_sendchar_send_10000_6
      009A10 12 43 E5         [24]  130 	lcall	_ak820_outline_0007
                                    131 ;	quantum/logging/print.c:28: func = send;
      009A13 90 0B AD         [24]  132 	mov	dptr,#_print_set_sendchar_send_10000_6
      009A16 12 43 C5         [24]  133 	lcall	_ak820_outline_0000
      009A19 90 0E 25         [24]  134 	mov	dptr,#_func
      009A1C EE               [12]  135 	mov	a,r6
      009A1D 12 43 E5         [24]  136 	lcall	_ak820_outline_0007
                                    137 ;	quantum/logging/print.c:29: }
      009A20 22               [24]  138 	ret
                                    139 ;------------------------------------------------------------
                                    140 ;Allocation info for local variables in function 'putchar_'
                                    141 ;------------------------------------------------------------
                                    142 ;character     Allocated with name '_putchar__character_10000_8'
                                    143 ;------------------------------------------------------------
                                    144 ;	quantum/logging/print.c:31: void putchar_(char character) {
                                    145 ;	-----------------------------------------
                                    146 ;	 function putchar_
                                    147 ;	-----------------------------------------
      009A21                        148 _putchar_:
      009A21 E5 82            [12]  149 	mov	a,dpl
      009A23 90 0B AF         [24]  150 	mov	dptr,#_putchar__character_10000_8
      009A26 F0               [24]  151 	movx	@dptr,a
                                    152 ;	quantum/logging/print.c:32: func(character);
      009A27 E0               [24]  153 	movx	a,@dptr
      009A28 FF               [12]  154 	mov	r7,a
      009A29 90 0E 25         [24]  155 	mov	dptr,#_func
      009A2C E0               [24]  156 	movx	a,@dptr
      009A2D C0 E0            [24]  157 	push	acc
      009A2F A3               [24]  158 	inc	dptr
      009A30 E0               [24]  159 	movx	a,@dptr
      009A31 C0 E0            [24]  160 	push	acc
      009A33 8F 82            [24]  161 	mov	dpl, r7
      009A35 22               [24]  162 	ret
                                    163 ;	quantum/logging/print.c:33: }
      009A36 22               [24]  164 	ret
                                    165 	.area CSEG    (CODE)
                                    166 	.area CONST   (CODE)
                                    167 	.area XINIT   (CODE)
      00C670                        168 __xinit__func:
      00C670 06 9A                  169 	.byte _null_sendchar_func, (_null_sendchar_func >> 8)
                                    170 	.area CABS    (ABS,CODE)
                                    171 
                                    172 ; Experimental exact instruction outlining.
                                    173 	.globl _ak820_outline_0000
                                    174 	.globl _ak820_outline_0007
                                    175 	.globl _ak820_outline_0010
