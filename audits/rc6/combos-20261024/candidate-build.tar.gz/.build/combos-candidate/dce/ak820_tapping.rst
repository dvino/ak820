                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _layer_hold_off
                                     12 	.globl _layer_hold_on
                                     13 	.globl _unregister_mods
                                     14 	.globl _register_mods
                                     15 	.globl _process_record
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _ak820_tapping_before
                                    260 	.globl _ak820_tapping_process
                                    261 	.globl _ak820_tapping_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
      000017                        524 _ak820_tapping_process_sloc0_1_0:
      000017                        525 	.ds 2
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
      00000A                        542 _ak820_tapping_before_sloc0_1_0:
      00000A                        543 	.ds 1
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
      00059B                        552 _source_state:
      00059B                        553 	.ds 130
      00061D                        554 _pending_time:
      00061D                        555 	.ds 2
      00061F                        556 _pending_code:
      00061F                        557 	.ds 2
      000621                        558 _source_PARM_1:
      000621                        559 	.ds 2
      000623                        560 _hold_PARM_2:
      000623                        561 	.ds 1
      000624                        562 _hold_code_10000_590:
      000624                        563 	.ds 2
      000626                        564 _hold_mods_30000_593:
      000626                        565 	.ds 1
      000627                        566 _commit_pending_id_10000_599:
      000627                        567 	.ds 1
      000628                        568 _ak820_tapping_before_event_10000_600:
      000628                        569 	.ds 2
      00062A                        570 _ak820_tapping_process_record_10000_611:
      00062A                        571 	.ds 2
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000DC3                        580 _pending:
      000DC3                        581 	.ds 1
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    610 ;------------------------------------------------------------
                                    611 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    612 ;------------------------------------------------------------
                                    613 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function source
                                    624 ;	-----------------------------------------
      00449B                        625 _source:
                                    626 ;	keyboards/ajazz/ak820/ak820_tapping.c:29: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00449B 90 06 22         [24]  627 	mov	dptr,#(_source_PARM_1 + 0x0001)
      00449E E0               [24]  628 	movx	a,@dptr
      00449F FF               [12]  629 	mov	r7,a
      0044A0 BF 10 00         [24]  630 	cjne	r7,#0x10,00147$
      0044A3                        631 00147$:
      0044A3 50 15            [24]  632 	jnc	00102$
      0044A5 90 06 21         [24]  633 	mov	dptr,#_source_PARM_1
      0044A8 E0               [24]  634 	movx	a,@dptr
      0044A9 FE               [12]  635 	mov	r6,a
      0044AA BE 08 00         [24]  636 	cjne	r6,#0x08,00149$
      0044AD                        637 00149$:
      0044AD 50 0B            [24]  638 	jnc	00102$
      0044AF 8F 05            [24]  639 	mov	ar5,r7
      0044B1 ED               [12]  640 	mov	a,r5
      0044B2 C4               [12]  641 	swap	a
      0044B3 03               [12]  642 	rr	a
      0044B4 54 F8            [12]  643 	anl	a,#0xf8
      0044B6 2E               [12]  644 	add	a,r6
      0044B7 F5 82            [12]  645 	mov	dpl,a
      0044B9 22               [24]  646 	ret
      0044BA                        647 00102$:
                                    648 ;	keyboards/ajazz/ak820/ak820_tapping.c:30: if (key.col < NUM_ENCODERS) {
      0044BA 90 06 21         [24]  649 	mov	dptr,#_source_PARM_1
      0044BD E0               [24]  650 	movx	a,@dptr
      0044BE FE               [12]  651 	mov	r6,a
      0044BF BE 01 00         [24]  652 	cjne	r6,#0x01,00151$
      0044C2                        653 00151$:
      0044C2 50 0E            [24]  654 	jnc	00109$
                                    655 ;	keyboards/ajazz/ak820/ak820_tapping.c:31: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0044C4 BF FD 04         [24]  656 	cjne	r7,#0xfd,00105$
      0044C7 75 82 80         [24]  657 	mov	dpl, #0x80
      0044CA 22               [24]  658 	ret
      0044CB                        659 00105$:
                                    660 ;	keyboards/ajazz/ak820/ak820_tapping.c:32: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0044CB BF FC 04         [24]  661 	cjne	r7,#0xfc,00109$
      0044CE 75 82 81         [24]  662 	mov	dpl, #0x81
      0044D1 22               [24]  663 	ret
      0044D2                        664 00109$:
                                    665 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: return NONE;
      0044D2 75 82 FF         [24]  666 	mov	dpl, #0xff
                                    667 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: }
      0044D5 22               [24]  668 	ret
                                    669 ;------------------------------------------------------------
                                    670 ;Allocation info for local variables in function 'hold'
                                    671 ;------------------------------------------------------------
                                    672 ;pressed       Allocated with name '_hold_PARM_2'
                                    673 ;code          Allocated with name '_hold_code_10000_590'
                                    674 ;mods          Allocated with name '_hold_mods_30000_593'
                                    675 ;layer         Allocated with name '_hold_layer_30000_596'
                                    676 ;------------------------------------------------------------
                                    677 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: static void hold(uint16_t code, bool pressed) {
                                    678 ;	-----------------------------------------
                                    679 ;	 function hold
                                    680 ;	-----------------------------------------
      0044D6                        681 _hold:
      0044D6 AF 83            [24]  682 	mov	r7,dph
      0044D8 E5 82            [12]  683 	mov	a,dpl
      0044DA 90 06 24         [24]  684 	mov	dptr,#_hold_code_10000_590
      0044DD F0               [24]  685 	movx	@dptr,a
      0044DE EF               [12]  686 	mov	a,r7
      0044DF A3               [24]  687 	inc	dptr
      0044E0 F0               [24]  688 	movx	@dptr,a
                                    689 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (code < QK_LAYER_TAP) {
      0044E1 90 06 24         [24]  690 	mov	dptr,#_hold_code_10000_590
      0044E4 E0               [24]  691 	movx	a,@dptr
      0044E5 FE               [12]  692 	mov	r6,a
      0044E6 A3               [24]  693 	inc	dptr
      0044E7 E0               [24]  694 	movx	a,@dptr
      0044E8 FF               [12]  695 	mov	r7,a
      0044E9 8E 04            [24]  696 	mov	ar4,r6
      0044EB 8F 05            [24]  697 	mov	ar5,r7
      0044ED 74 C0            [12]  698 	mov	a,#0x100 - 0x40
      0044EF 2D               [12]  699 	add	a,r5
      0044F0 40 2E            [24]  700 	jc	00110$
                                    701 ;	keyboards/ajazz/ak820/ak820_tapping.c:38: uint8_t mods = (code >> 8) & 31;
      0044F2 8F 05            [24]  702 	mov	ar5,r7
      0044F4 53 05 1F         [24]  703 	anl	ar5,#0x1f
      0044F7 90 06 26         [24]  704 	mov	dptr,#_hold_mods_30000_593
      0044FA ED               [12]  705 	mov	a,r5
      0044FB F0               [24]  706 	movx	@dptr,a
                                    707 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: if (mods & 16) mods <<= 4;
      0044FC ED               [12]  708 	mov	a,r5
      0044FD 30 E4 08         [24]  709 	jnb	acc.4,00102$
      004500 ED               [12]  710 	mov	a,r5
      004501 C4               [12]  711 	swap	a
      004502 54 F0            [12]  712 	anl	a,#0xf0
      004504 90 06 26         [24]  713 	mov	dptr,#_hold_mods_30000_593
      004507 F0               [24]  714 	movx	@dptr,a
      004508                        715 00102$:
                                    716 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (pressed) register_mods(mods);
      004508 90 06 23         [24]  717 	mov	dptr,#_hold_PARM_2
      00450B E0               [24]  718 	movx	a,@dptr
      00450C 60 09            [24]  719 	jz	00104$
      00450E 90 06 26         [24]  720 	mov	dptr,#_hold_mods_30000_593
      004511 E0               [24]  721 	movx	a,@dptr
      004512 F5 82            [12]  722 	mov	dpl,a
      004514 02 76 10         [24]  723 	ljmp	_register_mods
      004517                        724 00104$:
                                    725 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: else unregister_mods(mods);
      004517 90 06 26         [24]  726 	mov	dptr,#_hold_mods_30000_593
      00451A E0               [24]  727 	movx	a,@dptr
      00451B F5 82            [12]  728 	mov	dpl,a
      00451D 02 76 24         [24]  729 	ljmp	_unregister_mods
      004520                        730 00110$:
                                    731 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t layer = (code >> 8) & 15;
      004520 8F 06            [24]  732 	mov	ar6,r7
      004522 74 0F            [12]  733 	mov	a,#0x0f
      004524 5E               [12]  734 	anl	a,r6
      004525 FF               [12]  735 	mov	r7,a
                                    736 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (pressed) layer_hold_on(layer);
      004526 90 06 23         [24]  737 	mov	dptr,#_hold_PARM_2
      004529 E0               [24]  738 	movx	a,@dptr
      00452A 60 05            [24]  739 	jz	00107$
      00452C 8F 82            [24]  740 	mov	dpl, r7
      00452E 02 77 BD         [24]  741 	ljmp	_layer_hold_on
      004531                        742 00107$:
                                    743 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: else layer_hold_off(layer);
      004531 8F 82            [24]  744 	mov	dpl, r7
                                    745 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: }
      004533 02 77 F5         [24]  746 	ljmp	_layer_hold_off
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'commit_pending'
                                    749 ;------------------------------------------------------------
                                    750 ;id            Allocated with name '_commit_pending_id_10000_599'
                                    751 ;------------------------------------------------------------
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: static void commit_pending(void) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function commit_pending
                                    755 ;	-----------------------------------------
      004536                        756 _commit_pending:
                                    757 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t id = pending;
      004536 90 0D C3         [24]  758 	mov	dptr,#_pending
      004539 E0               [24]  759 	movx	a,@dptr
      00453A 90 06 27         [24]  760 	mov	dptr,#_commit_pending_id_10000_599
      00453D F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: pending = NONE; /* A report callback cannot resurrect the decision. */
      00453E 90 0D C3         [24]  763 	mov	dptr,#_pending
      004541 74 FF            [12]  764 	mov	a,#0xff
      004543 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: source_state[id] |= SOURCE_HELD;
      004544 90 06 27         [24]  767 	mov	dptr,#_commit_pending_id_10000_599
      004547 E0               [24]  768 	movx	a,@dptr
      004548 24 9B            [12]  769 	add	a,#_source_state
      00454A FF               [12]  770 	mov	r7,a
      00454B E4               [12]  771 	clr	a
      00454C 34 05            [12]  772 	addc	a, #(_source_state >> 8)
      00454E FE               [12]  773 	mov	r6,a
      00454F 8F 82            [24]  774 	mov	dpl,r7
      004551 8E 83            [24]  775 	mov	dph,r6
      004553 E0               [24]  776 	movx	a,@dptr
      004554 FD               [12]  777 	mov	r5,a
      004555 43 05 04         [24]  778 	orl	ar5,#0x04
      004558 8F 82            [24]  779 	mov	dpl,r7
      00455A 8E 83            [24]  780 	mov	dph,r6
      00455C ED               [12]  781 	mov	a,r5
      00455D F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: hold(pending_code, true);
      00455E 90 06 1F         [24]  784 	mov	dptr,#_pending_code
      004561 E0               [24]  785 	movx	a,@dptr
      004562 FE               [12]  786 	mov	r6,a
      004563 A3               [24]  787 	inc	dptr
      004564 E0               [24]  788 	movx	a,@dptr
      004565 FF               [12]  789 	mov	r7,a
      004566 90 06 23         [24]  790 	mov	dptr,#_hold_PARM_2
      004569 74 01            [12]  791 	mov	a,#0x01
      00456B F0               [24]  792 	movx	@dptr,a
      00456C 8E 82            [24]  793 	mov	dpl, r6
      00456E 8F 83            [24]  794 	mov	dph, r7
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: }
      004570 02 44 D6         [24]  796 	ljmp	_hold
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    799 ;------------------------------------------------------------
                                    800 ;event         Allocated with name '_ak820_tapping_before_event_10000_600'
                                    801 ;id            Allocated with name '_ak820_tapping_before_id_10000_601'
                                    802 ;------------------------------------------------------------
                                    803 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function ak820_tapping_before
                                    806 ;	-----------------------------------------
      004573                        807 _ak820_tapping_before:
      004573 AF 83            [24]  808 	mov	r7,dph
      004575 E5 82            [12]  809 	mov	a,dpl
      004577 90 06 28         [24]  810 	mov	dptr,#_ak820_tapping_before_event_10000_600
      00457A F0               [24]  811 	movx	@dptr,a
      00457B EF               [12]  812 	mov	a,r7
      00457C A3               [24]  813 	inc	dptr
      00457D F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: uint8_t id = source(event->key);
      00457E 90 06 28         [24]  816 	mov	dptr,#_ak820_tapping_before_event_10000_600
      004581 E0               [24]  817 	movx	a,@dptr
      004582 FE               [12]  818 	mov	r6,a
      004583 A3               [24]  819 	inc	dptr
      004584 E0               [24]  820 	movx	a,@dptr
      004585 FF               [12]  821 	mov	r7,a
      004586 8E 04            [24]  822 	mov	ar4,r6
      004588 8F 05            [24]  823 	mov	ar5,r7
      00458A 90 0D B3         [24]  824 	mov	dptr,#___memcpy_PARM_2
      00458D EC               [12]  825 	mov	a,r4
      00458E F0               [24]  826 	movx	@dptr,a
      00458F ED               [12]  827 	mov	a,r5
      004590 A3               [24]  828 	inc	dptr
      004591 F0               [24]  829 	movx	@dptr,a
      004592 E4               [12]  830 	clr	a
      004593 A3               [24]  831 	inc	dptr
      004594 F0               [24]  832 	movx	@dptr,a
      004595 90 0D B6         [24]  833 	mov	dptr,#___memcpy_PARM_3
      004598 74 02            [12]  834 	mov	a,#0x02
      00459A F0               [24]  835 	movx	@dptr,a
      00459B E4               [12]  836 	clr	a
      00459C A3               [24]  837 	inc	dptr
      00459D F0               [24]  838 	movx	@dptr,a
      00459E 90 06 21         [24]  839 	mov	dptr,#_source_PARM_1
      0045A1 F5 F0            [12]  840 	mov	b,a
      0045A3 C0 07            [24]  841 	push	ar7
      0045A5 C0 06            [24]  842 	push	ar6
      0045A7 12 BD 3B         [24]  843 	lcall	___memcpy
      0045AA 12 44 9B         [24]  844 	lcall	_source
      0045AD AD 82            [24]  845 	mov	r5, dpl
      0045AF D0 06            [24]  846 	pop	ar6
      0045B1 D0 07            [24]  847 	pop	ar7
                                    848 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: if (vial_unlock_in_progress) {
      0045B3 90 0E 33         [24]  849 	mov	dptr,#_vial_unlock_in_progress
      0045B6 E0               [24]  850 	movx	a,@dptr
      0045B7 60 3C            [24]  851 	jz	00106$
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0045B9 74 04            [12]  853 	mov	a,#0x04
      0045BB 2E               [12]  854 	add	a, r6
      0045BC FB               [12]  855 	mov	r3,a
      0045BD E4               [12]  856 	clr	a
      0045BE 3F               [12]  857 	addc	a, r7
      0045BF FC               [12]  858 	mov	r4,a
      0045C0 8B 82            [24]  859 	mov	dpl,r3
      0045C2 8C 83            [24]  860 	mov	dph,r4
      0045C4 E0               [24]  861 	movx	a,@dptr
      0045C5 60 2A            [24]  862 	jz	00102$
      0045C7 BD FF 02         [24]  863 	cjne	r5,#0xff,00218$
      0045CA 80 25            [24]  864 	sjmp	00102$
      0045CC                        865 00218$:
      0045CC 74 05            [12]  866 	mov	a,#0x05
      0045CE 2E               [12]  867 	add	a, r6
      0045CF FB               [12]  868 	mov	r3,a
      0045D0 E4               [12]  869 	clr	a
      0045D1 3F               [12]  870 	addc	a, r7
      0045D2 FC               [12]  871 	mov	r4,a
      0045D3 8B 82            [24]  872 	mov	dpl,r3
      0045D5 8C 83            [24]  873 	mov	dph,r4
      0045D7 E0               [24]  874 	movx	a,@dptr
      0045D8 70 17            [24]  875 	jnz	00102$
      0045DA ED               [12]  876 	mov	a,r5
      0045DB 24 9B            [12]  877 	add	a, #_source_state
      0045DD FB               [12]  878 	mov	r3,a
      0045DE E4               [12]  879 	clr	a
      0045DF 34 05            [12]  880 	addc	a, #(_source_state >> 8)
      0045E1 FC               [12]  881 	mov	r4,a
      0045E2 8B 82            [24]  882 	mov	dpl,r3
      0045E4 8C 83            [24]  883 	mov	dph,r4
      0045E6 E0               [24]  884 	movx	a,@dptr
      0045E7 FA               [12]  885 	mov	r2,a
      0045E8 53 02 FD         [24]  886 	anl	ar2,#0xfd
      0045EB 8B 82            [24]  887 	mov	dpl,r3
      0045ED 8C 83            [24]  888 	mov	dph,r4
      0045EF EA               [12]  889 	mov	a,r2
      0045F0 F0               [24]  890 	movx	@dptr,a
      0045F1                        891 00102$:
                                    892 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: return false;
      0045F1 75 82 00         [24]  893 	mov	dpl, #0x00
      0045F4 22               [24]  894 	ret
      0045F5                        895 00106$:
                                    896 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0045F5 90 0D C3         [24]  897 	mov	dptr,#_pending
      0045F8 E0               [24]  898 	movx	a,@dptr
      0045F9 FC               [12]  899 	mov	r4,a
      0045FA BC FF 02         [24]  900 	cjne	r4,#0xff,00220$
      0045FD 80 51            [24]  901 	sjmp	00108$
      0045FF                        902 00220$:
      0045FF 8E 82            [24]  903 	mov	dpl,r6
      004601 8F 83            [24]  904 	mov	dph,r7
      004603 A3               [24]  905 	inc	dptr
      004604 A3               [24]  906 	inc	dptr
      004605 E0               [24]  907 	movx	a,@dptr
      004606 FA               [12]  908 	mov	r2,a
      004607 A3               [24]  909 	inc	dptr
      004608 E0               [24]  910 	movx	a,@dptr
      004609 FB               [12]  911 	mov	r3,a
      00460A 90 06 1D         [24]  912 	mov	dptr,#_pending_time
      00460D E0               [24]  913 	movx	a,@dptr
      00460E F8               [12]  914 	mov	r0,a
      00460F A3               [24]  915 	inc	dptr
      004610 E0               [24]  916 	movx	a,@dptr
      004611 F9               [12]  917 	mov	r1,a
      004612 EA               [12]  918 	mov	a,r2
      004613 C3               [12]  919 	clr	c
      004614 98               [12]  920 	subb	a,r0
      004615 FA               [12]  921 	mov	r2,a
      004616 EB               [12]  922 	mov	a,r3
      004617 99               [12]  923 	subb	a,r1
      004618 FB               [12]  924 	mov	r3,a
      004619 C3               [12]  925 	clr	c
      00461A EA               [12]  926 	mov	a,r2
      00461B 94 C8            [12]  927 	subb	a,#0xc8
      00461D EB               [12]  928 	mov	a,r3
      00461E 94 00            [12]  929 	subb	a,#0x00
      004620 50 27            [24]  930 	jnc	00107$
                                    931 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004622 74 04            [12]  932 	mov	a,#0x04
      004624 2E               [12]  933 	add	a, r6
      004625 FA               [12]  934 	mov	r2,a
      004626 E4               [12]  935 	clr	a
      004627 3F               [12]  936 	addc	a, r7
      004628 FB               [12]  937 	mov	r3,a
      004629 8A 82            [24]  938 	mov	dpl,r2
      00462B 8B 83            [24]  939 	mov	dph,r3
      00462D E0               [24]  940 	movx	a,@dptr
      00462E 60 20            [24]  941 	jz	00108$
      004630 74 05            [12]  942 	mov	a,#0x05
      004632 2E               [12]  943 	add	a, r6
      004633 FE               [12]  944 	mov	r6,a
      004634 E4               [12]  945 	clr	a
      004635 3F               [12]  946 	addc	a, r7
      004636 FF               [12]  947 	mov	r7,a
      004637 8E 82            [24]  948 	mov	dpl,r6
      004639 8F 83            [24]  949 	mov	dph,r7
      00463B E0               [24]  950 	movx	a,@dptr
      00463C 60 12            [24]  951 	jz	00108$
      00463E BD FF 02         [24]  952 	cjne	r5,#0xff,00224$
      004641 80 06            [24]  953 	sjmp	00107$
      004643                        954 00224$:
      004643 ED               [12]  955 	mov	a,r5
      004644 B5 04 02         [24]  956 	cjne	a,ar4,00225$
      004647 80 07            [24]  957 	sjmp	00108$
      004649                        958 00225$:
      004649                        959 00107$:
      004649 C0 05            [24]  960 	push	ar5
      00464B 12 45 36         [24]  961 	lcall	_commit_pending
      00464E D0 05            [24]  962 	pop	ar5
      004650                        963 00108$:
                                    964 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: if (IS_NOEVENT(*event) || id == NONE) return true;
      004650 90 06 28         [24]  965 	mov	dptr,#_ak820_tapping_before_event_10000_600
      004653 E0               [24]  966 	movx	a,@dptr
      004654 FE               [12]  967 	mov	r6,a
      004655 A3               [24]  968 	inc	dptr
      004656 E0               [24]  969 	movx	a,@dptr
      004657 FF               [12]  970 	mov	r7,a
      004658 74 04            [12]  971 	mov	a,#0x04
      00465A 2E               [12]  972 	add	a, r6
      00465B FB               [12]  973 	mov	r3,a
      00465C E4               [12]  974 	clr	a
      00465D 3F               [12]  975 	addc	a, r7
      00465E FC               [12]  976 	mov	r4,a
      00465F 8B 82            [24]  977 	mov	dpl,r3
      004661 8C 83            [24]  978 	mov	dph,r4
      004663 E0               [24]  979 	movx	a,@dptr
      004664 60 03            [24]  980 	jz	00114$
      004666 BD FF 04         [24]  981 	cjne	r5,#0xff,00115$
      004669                        982 00114$:
      004669 75 82 01         [24]  983 	mov	dpl, #0x01
      00466C 22               [24]  984 	ret
      00466D                        985 00115$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: if ((source_state[id] & SOURCE_BLOCKED)) {
      00466D ED               [12]  987 	mov	a,r5
      00466E 24 9B            [12]  988 	add	a, #_source_state
      004670 FC               [12]  989 	mov	r4,a
      004671 E4               [12]  990 	clr	a
      004672 34 05            [12]  991 	addc	a, #(_source_state >> 8)
      004674 FD               [12]  992 	mov	r5,a
      004675 8C 82            [24]  993 	mov	dpl,r4
      004677 8D 83            [24]  994 	mov	dph,r5
      004679 E0               [24]  995 	movx	a,@dptr
      00467A FB               [12]  996 	mov	r3,a
      00467B 30 E1 1A         [24]  997 	jnb	acc.1,00120$
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00467E 74 05            [12]  999 	mov	a,#0x05
      004680 2E               [12] 1000 	add	a, r6
      004681 F9               [12] 1001 	mov	r1,a
      004682 E4               [12] 1002 	clr	a
      004683 3F               [12] 1003 	addc	a, r7
      004684 FA               [12] 1004 	mov	r2,a
      004685 89 82            [24] 1005 	mov	dpl,r1
      004687 8A 83            [24] 1006 	mov	dph,r2
      004689 E0               [24] 1007 	movx	a,@dptr
      00468A 70 08            [24] 1008 	jnz	00118$
      00468C 74 FD            [12] 1009 	mov	a,#0xfd
      00468E 5B               [12] 1010 	anl	a,r3
      00468F 8C 82            [24] 1011 	mov	dpl,r4
      004691 8D 83            [24] 1012 	mov	dph,r5
      004693 F0               [24] 1013 	movx	@dptr,a
      004694                       1014 00118$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: return false;
      004694 75 82 00         [24] 1016 	mov	dpl, #0x00
      004697 22               [24] 1017 	ret
      004698                       1018 00120$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004698 8E 82            [24] 1020 	mov	dpl,r6
      00469A 8F 83            [24] 1021 	mov	dph,r7
      00469C A3               [24] 1022 	inc	dptr
      00469D A3               [24] 1023 	inc	dptr
      00469E A3               [24] 1024 	inc	dptr
      00469F A3               [24] 1025 	inc	dptr
      0046A0 A3               [24] 1026 	inc	dptr
      0046A1 E0               [24] 1027 	movx	a,@dptr
      0046A2 FF               [12] 1028 	mov	r7,a
      0046A3 8B 06            [24] 1029 	mov	ar6,r3
      0046A5 53 06 01         [24] 1030 	anl	ar6,#0x01
      0046A8 EE               [12] 1031 	mov	a,r6
      0046A9 B4 01 00         [24] 1032 	cjne	a,#0x01,00231$
      0046AC                       1033 00231$:
      0046AC B3               [12] 1034 	cpl	c
      0046AD 92 0A            [24] 1035 	mov	_ak820_tapping_before_sloc0_1_0,c
      0046AF 8F F0            [24] 1036 	mov	b,r7
      0046B1 E4               [12] 1037 	clr	a
      0046B2 33               [12] 1038 	rlc	a
      0046B3 B5 F0 04         [24] 1039 	cjne	a,b,00122$
      0046B6 75 82 00         [24] 1040 	mov	dpl, #0x00
      0046B9 22               [24] 1041 	ret
      0046BA                       1042 00122$:
                                   1043 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: source_state[id] ^= SOURCE_ACTIVE;
      0046BA 63 03 01         [24] 1044 	xrl	ar3,#0x01
      0046BD 8C 82            [24] 1045 	mov	dpl,r4
      0046BF 8D 83            [24] 1046 	mov	dph,r5
      0046C1 EB               [12] 1047 	mov	a,r3
      0046C2 F0               [24] 1048 	movx	@dptr,a
                                   1049 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return true;
      0046C3 75 82 01         [24] 1050 	mov	dpl, #0x01
                                   1051 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: }
      0046C6 22               [24] 1052 	ret
                                   1053 ;------------------------------------------------------------
                                   1054 ;Allocation info for local variables in function 'ak820_tapping_process'
                                   1055 ;------------------------------------------------------------
                                   1056 ;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
                                   1057 ;record        Allocated with name '_ak820_tapping_process_record_10000_611'
                                   1058 ;id            Allocated with name '_ak820_tapping_process_id_10000_612'
                                   1059 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_612'
                                   1060 ;code          Allocated with name '_ak820_tapping_process_code_10000_612'
                                   1061 ;------------------------------------------------------------
                                   1062 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1063 ;	-----------------------------------------
                                   1064 ;	 function ak820_tapping_process
                                   1065 ;	-----------------------------------------
      0046C7                       1066 _ak820_tapping_process:
      0046C7 AF 83            [24] 1067 	mov	r7,dph
      0046C9 E5 82            [12] 1068 	mov	a,dpl
      0046CB 90 06 2A         [24] 1069 	mov	dptr,#_ak820_tapping_process_record_10000_611
      0046CE F0               [24] 1070 	movx	@dptr,a
      0046CF EF               [12] 1071 	mov	a,r7
      0046D0 A3               [24] 1072 	inc	dptr
      0046D1 F0               [24] 1073 	movx	@dptr,a
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (IS_NOEVENT(record->event)) return true;
      0046D2 90 06 2A         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_611
      0046D5 E0               [24] 1076 	movx	a,@dptr
      0046D6 FE               [12] 1077 	mov	r6,a
      0046D7 A3               [24] 1078 	inc	dptr
      0046D8 E0               [24] 1079 	movx	a,@dptr
      0046D9 FF               [12] 1080 	mov	r7,a
      0046DA 74 04            [12] 1081 	mov	a,#0x04
      0046DC 2E               [12] 1082 	add	a, r6
      0046DD FC               [12] 1083 	mov	r4,a
      0046DE E4               [12] 1084 	clr	a
      0046DF 3F               [12] 1085 	addc	a, r7
      0046E0 FD               [12] 1086 	mov	r5,a
      0046E1 8C 82            [24] 1087 	mov	dpl,r4
      0046E3 8D 83            [24] 1088 	mov	dph,r5
      0046E5 E0               [24] 1089 	movx	a,@dptr
      0046E6 70 04            [24] 1090 	jnz	00102$
      0046E8 75 82 01         [24] 1091 	mov	dpl, #0x01
      0046EB 22               [24] 1092 	ret
      0046EC                       1093 00102$:
                                   1094 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: id = source(record->event.key);
      0046EC 8E 04            [24] 1095 	mov	ar4,r6
      0046EE 8F 05            [24] 1096 	mov	ar5,r7
      0046F0 90 0D B3         [24] 1097 	mov	dptr,#___memcpy_PARM_2
      0046F3 EC               [12] 1098 	mov	a,r4
      0046F4 F0               [24] 1099 	movx	@dptr,a
      0046F5 ED               [12] 1100 	mov	a,r5
      0046F6 A3               [24] 1101 	inc	dptr
      0046F7 F0               [24] 1102 	movx	@dptr,a
      0046F8 E4               [12] 1103 	clr	a
      0046F9 A3               [24] 1104 	inc	dptr
      0046FA F0               [24] 1105 	movx	@dptr,a
      0046FB 90 0D B6         [24] 1106 	mov	dptr,#___memcpy_PARM_3
      0046FE 74 02            [12] 1107 	mov	a,#0x02
      004700 F0               [24] 1108 	movx	@dptr,a
      004701 E4               [12] 1109 	clr	a
      004702 A3               [24] 1110 	inc	dptr
      004703 F0               [24] 1111 	movx	@dptr,a
      004704 90 06 21         [24] 1112 	mov	dptr,#_source_PARM_1
      004707 F5 F0            [12] 1113 	mov	b,a
      004709 C0 07            [24] 1114 	push	ar7
      00470B C0 06            [24] 1115 	push	ar6
      00470D 12 BD 3B         [24] 1116 	lcall	___memcpy
      004710 12 44 9B         [24] 1117 	lcall	_source
      004713 AD 82            [24] 1118 	mov	r5, dpl
      004715 D0 06            [24] 1119 	pop	ar6
      004717 D0 07            [24] 1120 	pop	ar7
                                   1121 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: if (id == NONE) return true;
      004719 BD FF 04         [24] 1122 	cjne	r5,#0xff,00104$
      00471C 75 82 01         [24] 1123 	mov	dpl, #0x01
      00471F 22               [24] 1124 	ret
      004720                       1125 00104$:
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:80: code = record->keycode;
      004720 74 07            [12] 1127 	mov	a,#0x07
      004722 2E               [12] 1128 	add	a, r6
      004723 F5 82            [12] 1129 	mov	dpl,a
      004725 E4               [12] 1130 	clr	a
      004726 3F               [12] 1131 	addc	a, r7
      004727 F5 83            [12] 1132 	mov	dph,a
      004729 E0               [24] 1133 	movx	a,@dptr
      00472A F5 17            [12] 1134 	mov	_ak820_tapping_process_sloc0_1_0,a
      00472C A3               [24] 1135 	inc	dptr
      00472D E0               [24] 1136 	movx	a,@dptr
      00472E F5 18            [12] 1137 	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
                                   1138 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: kind = code >> 8;
      004730 AC 18            [24] 1139 	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
                                   1140 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: if (kind < 0x20 || kind >= 0x50) return true;
      004732 BC 20 00         [24] 1141 	cjne	r4,#0x20,00189$
      004735                       1142 00189$:
      004735 40 05            [24] 1143 	jc	00105$
      004737 BC 50 00         [24] 1144 	cjne	r4,#0x50,00191$
      00473A                       1145 00191$:
      00473A 40 04            [24] 1146 	jc	00106$
      00473C                       1147 00105$:
      00473C 75 82 01         [24] 1148 	mov	dpl, #0x01
      00473F 22               [24] 1149 	ret
      004740                       1150 00106$:
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004740 BC 40 00         [24] 1152 	cjne	r4,#0x40,00193$
      004743                       1153 00193$:
      004743 40 0C            [24] 1154 	jc	00109$
      004745 53 04 0F         [24] 1155 	anl	ar4,#0x0f
      004748 BC 06 00         [24] 1156 	cjne	r4,#0x06,00195$
      00474B                       1157 00195$:
      00474B 40 04            [24] 1158 	jc	00109$
      00474D 75 82 00         [24] 1159 	mov	dpl, #0x00
      004750 22               [24] 1160 	ret
      004751                       1161 00109$:
                                   1162 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: if (record->event.pressed) {
      004751 90 06 2A         [24] 1163 	mov	dptr,#_ak820_tapping_process_record_10000_611
      004754 E0               [24] 1164 	movx	a,@dptr
      004755 FB               [12] 1165 	mov	r3,a
      004756 A3               [24] 1166 	inc	dptr
      004757 E0               [24] 1167 	movx	a,@dptr
      004758 FC               [12] 1168 	mov	r4,a
      004759 74 05            [12] 1169 	mov	a,#0x05
      00475B 2B               [12] 1170 	add	a, r3
      00475C F9               [12] 1171 	mov	r1,a
      00475D E4               [12] 1172 	clr	a
      00475E 3C               [12] 1173 	addc	a, r4
      00475F FA               [12] 1174 	mov	r2,a
      004760 89 82            [24] 1175 	mov	dpl,r1
      004762 8A 83            [24] 1176 	mov	dph,r2
      004764 E0               [24] 1177 	movx	a,@dptr
      004765 60 25            [24] 1178 	jz	00119$
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: pending = id;
      004767 90 0D C3         [24] 1180 	mov	dptr,#_pending
      00476A ED               [12] 1181 	mov	a,r5
      00476B F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: pending_time = record->event.time;
      00476C 8B 82            [24] 1184 	mov	dpl,r3
      00476E 8C 83            [24] 1185 	mov	dph,r4
      004770 A3               [24] 1186 	inc	dptr
      004771 A3               [24] 1187 	inc	dptr
      004772 E0               [24] 1188 	movx	a,@dptr
      004773 F8               [12] 1189 	mov	r0,a
      004774 A3               [24] 1190 	inc	dptr
      004775 E0               [24] 1191 	movx	a,@dptr
      004776 FF               [12] 1192 	mov	r7,a
      004777 90 06 1D         [24] 1193 	mov	dptr,#_pending_time
      00477A E8               [12] 1194 	mov	a,r0
      00477B F0               [24] 1195 	movx	@dptr,a
      00477C EF               [12] 1196 	mov	a,r7
      00477D A3               [24] 1197 	inc	dptr
      00477E F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: pending_code = code;
      00477F 90 06 1F         [24] 1200 	mov	dptr,#_pending_code
      004782 E5 17            [12] 1201 	mov	a,_ak820_tapping_process_sloc0_1_0
      004784 F0               [24] 1202 	movx	@dptr,a
      004785 E5 18            [12] 1203 	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
      004787 A3               [24] 1204 	inc	dptr
      004788 F0               [24] 1205 	movx	@dptr,a
      004789 02 48 21         [24] 1206 	ljmp	00120$
      00478C                       1207 00119$:
                                   1208 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: } else if (id == pending) {
      00478C 90 0D C3         [24] 1209 	mov	dptr,#_pending
      00478F E0               [24] 1210 	movx	a,@dptr
      004790 FF               [12] 1211 	mov	r7,a
      004791 ED               [12] 1212 	mov	a,r5
      004792 B5 07 64         [24] 1213 	cjne	a,ar7,00116$
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: pending = NONE;
      004795 90 0D C3         [24] 1215 	mov	dptr,#_pending
      004798 74 FF            [12] 1216 	mov	a,#0xff
      00479A F0               [24] 1217 	movx	@dptr,a
                                   1218 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: record->keycode = (uint8_t)code;
      00479B 74 07            [12] 1219 	mov	a,#0x07
      00479D 2B               [12] 1220 	add	a, r3
      00479E F5 82            [12] 1221 	mov	dpl,a
      0047A0 E4               [12] 1222 	clr	a
      0047A1 3C               [12] 1223 	addc	a, r4
      0047A2 F5 83            [12] 1224 	mov	dph,a
      0047A4 AE 17            [24] 1225 	mov	r6,_ak820_tapping_process_sloc0_1_0
      0047A6 7F 00            [12] 1226 	mov	r7,#0x00
      0047A8 EE               [12] 1227 	mov	a,r6
      0047A9 F0               [24] 1228 	movx	@dptr,a
      0047AA EF               [12] 1229 	mov	a,r7
      0047AB A3               [24] 1230 	inc	dptr
      0047AC F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (record->keycode > KC_TRANSPARENT) {
      0047AD C3               [12] 1233 	clr	c
      0047AE 04               [12] 1234 	inc	a
      0047AF 9E               [12] 1235 	subb	a,r6
      0047B0 50 6F            [24] 1236 	jnc	00120$
                                   1237 ;	free result
                                   1238 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: record->tap.count = 1;
      0047B2 74 06            [12] 1239 	mov	a,#0x06
      0047B4 2B               [12] 1240 	add	a, r3
      0047B5 F5 82            [12] 1241 	mov	dpl,a
      0047B7 E4               [12] 1242 	clr	a
      0047B8 3C               [12] 1243 	addc	a, r4
      0047B9 F5 83            [12] 1244 	mov	dph,a
      0047BB E0               [24] 1245 	movx	a,@dptr
      0047BC 54 0F            [12] 1246 	anl	a,#0x0f
      0047BE 44 10            [12] 1247 	orl	a,#0x10
      0047C0 F0               [24] 1248 	movx	@dptr,a
                                   1249 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: record->event.pressed = true;
      0047C1 89 82            [24] 1250 	mov	dpl,r1
      0047C3 8A 83            [24] 1251 	mov	dph,r2
      0047C5 74 01            [12] 1252 	mov	a,#0x01
      0047C7 F0               [24] 1253 	movx	@dptr,a
                                   1254 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: process_record(record);
      0047C8 8B 00            [24] 1255 	mov	ar0,r3
      0047CA 8C 06            [24] 1256 	mov	ar6,r4
      0047CC 7F 00            [12] 1257 	mov	r7,#0x00
      0047CE 88 82            [24] 1258 	mov	dpl, r0
      0047D0 8E 83            [24] 1259 	mov	dph, r6
      0047D2 8F F0            [24] 1260 	mov	b, r7
      0047D4 C0 04            [24] 1261 	push	ar4
      0047D6 C0 03            [24] 1262 	push	ar3
      0047D8 C0 02            [24] 1263 	push	ar2
      0047DA C0 01            [24] 1264 	push	ar1
      0047DC 12 71 16         [24] 1265 	lcall	_process_record
      0047DF D0 01            [24] 1266 	pop	ar1
      0047E1 D0 02            [24] 1267 	pop	ar2
      0047E3 D0 03            [24] 1268 	pop	ar3
      0047E5 D0 04            [24] 1269 	pop	ar4
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: record->event.pressed = false;
      0047E7 89 82            [24] 1271 	mov	dpl,r1
      0047E9 8A 83            [24] 1272 	mov	dph,r2
      0047EB E4               [12] 1273 	clr	a
      0047EC F0               [24] 1274 	movx	@dptr,a
                                   1275 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: process_record(record);
      0047ED FF               [12] 1276 	mov	r7,a
      0047EE 8B 82            [24] 1277 	mov	dpl, r3
      0047F0 8C 83            [24] 1278 	mov	dph, r4
      0047F2 8F F0            [24] 1279 	mov	b, r7
      0047F4 12 71 16         [24] 1280 	lcall	_process_record
      0047F7 80 28            [24] 1281 	sjmp	00120$
      0047F9                       1282 00116$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: } else if ((source_state[id] & SOURCE_HELD)) {
      0047F9 ED               [12] 1284 	mov	a,r5
      0047FA 24 9B            [12] 1285 	add	a, #_source_state
      0047FC FE               [12] 1286 	mov	r6,a
      0047FD E4               [12] 1287 	clr	a
      0047FE 34 05            [12] 1288 	addc	a, #(_source_state >> 8)
      004800 FF               [12] 1289 	mov	r7,a
      004801 8E 82            [24] 1290 	mov	dpl,r6
      004803 8F 83            [24] 1291 	mov	dph,r7
      004805 E0               [24] 1292 	movx	a,@dptr
      004806 FD               [12] 1293 	mov	r5,a
      004807 30 E2 17         [24] 1294 	jnb	acc.2,00120$
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: source_state[id] &= ~SOURCE_HELD;
      00480A 53 05 FB         [24] 1296 	anl	ar5,#0xfb
      00480D 8E 82            [24] 1297 	mov	dpl,r6
      00480F 8F 83            [24] 1298 	mov	dph,r7
      004811 ED               [12] 1299 	mov	a,r5
      004812 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: hold(code, false);
      004813 90 06 23         [24] 1302 	mov	dptr,#_hold_PARM_2
      004816 E4               [12] 1303 	clr	a
      004817 F0               [24] 1304 	movx	@dptr,a
      004818 85 17 82         [24] 1305 	mov	dpl, _ak820_tapping_process_sloc0_1_0
      00481B 85 18 83         [24] 1306 	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
      00481E 12 44 D6         [24] 1307 	lcall	_hold
      004821                       1308 00120$:
                                   1309 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: return false;
      004821 75 82 00         [24] 1310 	mov	dpl, #0x00
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: }
      004824 22               [24] 1312 	ret
                                   1313 ;------------------------------------------------------------
                                   1314 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1315 ;------------------------------------------------------------
                                   1316 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_627'
                                   1317 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_628'
                                   1318 ;------------------------------------------------------------
                                   1319 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: void ak820_tapping_cancel(void) {
                                   1320 ;	-----------------------------------------
                                   1321 ;	 function ak820_tapping_cancel
                                   1322 ;	-----------------------------------------
      004825                       1323 _ak820_tapping_cancel:
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: pending = NONE;
      004825 90 0D C3         [24] 1325 	mov	dptr,#_pending
      004828 74 FF            [12] 1326 	mov	a,#0xff
      00482A F0               [24] 1327 	movx	@dptr,a
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: for (uint8_t i = 0; i < SOURCES; ++i) {
      00482B 7F 00            [12] 1329 	mov	r7,#0x00
      00482D                       1330 00103$:
      00482D BF 82 00         [24] 1331 	cjne	r7,#0x82,00122$
      004830                       1332 00122$:
      004830 50 22            [24] 1333 	jnc	00105$
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: uint8_t state = source_state[i];
      004832 EF               [12] 1335 	mov	a,r7
      004833 24 9B            [12] 1336 	add	a, #_source_state
      004835 FD               [12] 1337 	mov	r5,a
      004836 E4               [12] 1338 	clr	a
      004837 34 05            [12] 1339 	addc	a, #(_source_state >> 8)
      004839 FE               [12] 1340 	mov	r6,a
      00483A 8D 82            [24] 1341 	mov	dpl,r5
      00483C 8E 83            [24] 1342 	mov	dph,r6
      00483E E0               [24] 1343 	movx	a,@dptr
      00483F FC               [12] 1344 	mov	r4,a
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004840 74 02            [12] 1346 	mov	a,#0x02
      004842 5C               [12] 1347 	anl	a,r4
      004843 FB               [12] 1348 	mov	r3,a
      004844 53 04 01         [24] 1349 	anl	ar4,#0x01
      004847 EC               [12] 1350 	mov	a,r4
      004848 2C               [12] 1351 	add	a,r4
      004849 42 03            [12] 1352 	orl	ar3,a
      00484B 8D 82            [24] 1353 	mov	dpl,r5
      00484D 8E 83            [24] 1354 	mov	dph,r6
      00484F EB               [12] 1355 	mov	a,r3
      004850 F0               [24] 1356 	movx	@dptr,a
                                   1357 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: for (uint8_t i = 0; i < SOURCES; ++i) {
      004851 0F               [12] 1358 	inc	r7
      004852 80 D9            [24] 1359 	sjmp	00103$
      004854                       1360 00105$:
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: }
      004854 22               [24] 1362 	ret
                                   1363 	.area CSEG    (CODE)
                                   1364 	.area CONST   (CODE)
                                   1365 	.area XINIT   (CODE)
      00C60E                       1366 __xinit__pending:
      00C60E FF                    1367 	.db #0xff	; 255
                                   1368 	.area CABS    (ABS,CODE)
