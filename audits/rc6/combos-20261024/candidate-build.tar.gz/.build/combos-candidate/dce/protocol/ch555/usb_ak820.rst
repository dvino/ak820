                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000026                        548 _control_setup_sloc1_1_0:
      000026                        549 	.ds 1
      000027                        550 _control_setup_sloc3_1_0:
      000027                        551 	.ds 2
      000029                        552 _control_setup_sloc4_1_0:
      000029                        553 	.ds 2
      00002B                        554 _ak820_usb_send_sloc0_1_0:
      00002B                        555 	.ds 2
      00002D                        556 _ak820_usb_send_sloc1_1_0:
      00002D                        557 	.ds 1
      00002E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00002E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      00000F                        576 _control_setup_valid_interface_10000_285:
      00000F                        577 	.ds 1
      000010                        578 _control_setup_zero_index_10000_285:
      000010                        579 	.ds 1
      000011                        580 _control_setup_zero_value_10000_285:
      000011                        581 	.ds 1
      000012                        582 _control_setup_zero_length_10000_285:
      000012                        583 	.ds 1
      000013                        584 _control_setup_sloc0_1_0:
      000013                        585 	.ds 1
      000014                        586 _control_setup_sloc2_1_0:
      000014                        587 	.ds 1
      000015                        588 _ak820_usb_try_send_sloc0_1_0:
      000015                        589 	.ds 1
      000016                        590 _ak820_usb_raw_task_sloc1_1_0:
      000016                        591 	.ds 1
      000017                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000017                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000755                        602 _D0SetupReqCode::
      000755                        603 	.ds 1
      000756                        604 _D0SetupLen::
      000756                        605 	.ds 2
      000758                        606 _pD0Descr::
      000758                        607 	.ds 3
      00075B                        608 _D0UsbConfig::
      00075B                        609 	.ds 1
      00075C                        610 _USB_EnumStatus::
      00075C                        611 	.ds 1
      00075D                        612 _USB_SleepStatus::
      00075D                        613 	.ds 1
      00075E                        614 _MCU_Sleep_Operate::
      00075E                        615 	.ds 1
      00075F                        616 _KB_USB_UpStatus::
      00075F                        617 	.ds 1
      000760                        618 _KB_USB_SetReport::
      000760                        619 	.ds 1
      000761                        620 _ak820_boot_stage::
      000761                        621 	.ds 1
      000762                        622 _ak820_main_heartbeat::
      000762                        623 	.ds 1
      000763                        624 _raw_state:
      000763                        625 	.ds 1
      000764                        626 _raw_buffer:
      000764                        627 	.ds 32
      000784                        628 _raw_reply_without_nvm:
      000784                        629 	.ds 1
      000785                        630 _keyboard_reset:
      000785                        631 	.ds 1
      000786                        632 _input_snapshot:
      000786                        633 	.ds 46
      0007B4                        634 _control_phase:
      0007B4                        635 	.ds 1
      0007B5                        636 _output_kind:
      0007B5                        637 	.ds 1
      0007B6                        638 _output_report_id:
      0007B6                        639 	.ds 1
      0007B7                        640 _control_zlp:
      0007B7                        641 	.ds 1
      0007B8                        642 _control_pointer:
      0007B8                        643 	.ds 2
      0007BA                        644 _descriptor_select_PARM_2:
      0007BA                        645 	.ds 1
      0007BB                        646 _descriptor_select_PARM_3:
      0007BB                        647 	.ds 2
      0007BD                        648 _descriptor_select_type_10000_267:
      0007BD                        649 	.ds 1
      0007BE                        650 _control_setup_length_10000_285:
      0007BE                        651 	.ds 2
      0007C0                        652 _control_setup_offset_10000_285:
      0007C0                        653 	.ds 1
      0007C1                        654 _ak820_usb_send_PARM_2:
      0007C1                        655 	.ds 2
      0007C3                        656 _ak820_usb_send_PARM_3:
      0007C3                        657 	.ds 1
      0007C4                        658 _ak820_usb_send_endpoint_10000_421:
      0007C4                        659 	.ds 1
      0007C5                        660 _ak820_usb_send_offset_10000_422:
      0007C5                        661 	.ds 1
      0007C6                        662 _ak820_usb_try_send_PARM_2:
      0007C6                        663 	.ds 2
      0007C8                        664 _ak820_usb_try_send_PARM_3:
      0007C8                        665 	.ds 1
      0007C9                        666 _ak820_usb_try_send_endpoint_10000_442:
      0007C9                        667 	.ds 1
      0007CA                        668 _ak820_usb_try_send_sent_10000_443:
      0007CA                        669 	.ds 1
      0007CB                        670 _ak820_usb_raw_send_PARM_2:
      0007CB                        671 	.ds 1
      0007CC                        672 _ak820_usb_raw_send_report_10000_458:
      0007CC                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005A3B                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:92: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005A3B 90 07 63         [24]  727 	mov	dptr,#_raw_state
      005A3E E0               [24]  728 	movx	a,@dptr
      005A3F FF               [12]  729 	mov	r7,a
      005A40 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005A43 80 1C            [24]  731 	sjmp	00101$
      005A45                        732 00130$:
      005A45 90 07 63         [24]  733 	mov	dptr,#_raw_state
      005A48 E0               [24]  734 	movx	a,@dptr
      005A49 FF               [12]  735 	mov	r7,a
      005A4A BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005A4D 80 12            [24]  737 	sjmp	00101$
      005A4F                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:93: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005A4F 90 07 63         [24]  740 	mov	dptr,#_raw_state
      005A52 E0               [24]  741 	movx	a,@dptr
      005A53 FF               [12]  742 	mov	r7,a
      005A54 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005A57 80 08            [24]  744 	sjmp	00101$
      005A59                        745 00132$:
      005A59 90 07 63         [24]  746 	mov	dptr,#_raw_state
      005A5C E0               [24]  747 	movx	a,@dptr
      005A5D FF               [12]  748 	mov	r7,a
      005A5E BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005A61                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:94: raw_state = RAW_CANCELLED;
      005A61 90 07 63         [24]  752 	mov	dptr,#_raw_state
      005A64 74 07            [12]  753 	mov	a,#0x07
      005A66 F0               [24]  754 	movx	@dptr,a
      005A67 80 05            [24]  755 	sjmp	00103$
      005A69                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_IDLE;
      005A69 90 07 63         [24]  758 	mov	dptr,#_raw_state
      005A6C E4               [12]  759 	clr	a
      005A6D F0               [24]  760 	movx	@dptr,a
      005A6E                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:97: output_kind = OUTPUT_NONE;
      005A6E 90 07 B5         [24]  763 	mov	dptr,#_output_kind
      005A71 E4               [12]  764 	clr	a
      005A72 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:98: }
      005A73 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:100: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005A74                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:101: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005A74 90 07 63         [24]  777 	mov	dptr,#_raw_state
      005A77 E0               [24]  778 	movx	a,@dptr
      005A78 FF               [12]  779 	mov	r7,a
      005A79 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005A7C 90 07 63         [24]  781 	mov	dptr,#_raw_state
      005A7F 74 06            [12]  782 	mov	a,#0x06
      005A81 F0               [24]  783 	movx	@dptr,a
      005A82 22               [24]  784 	ret
      005A83                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:102: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005A83 90 07 63         [24]  787 	mov	dptr,#_raw_state
      005A86 E0               [24]  788 	movx	a,@dptr
      005A87 FF               [12]  789 	mov	r7,a
      005A88 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005A8B 90 07 63         [24]  791 	mov	dptr,#_raw_state
      005A8E E4               [12]  792 	clr	a
      005A8F F0               [24]  793 	movx	@dptr,a
      005A90                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005A90 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_257'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005A91                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:108: D0_EP_MOD = bUX_DEV_EN;
      005A91 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005A94 74 01            [12]  809 	mov	a,#0x01
      005A96 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:109: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A97 F5 82            [12]  812 	mov	dpl,a
      005A99 74 12            [12]  813 	mov	a,#0x12
      005A9B F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A9C A3               [24]  816 	inc	dptr
      005A9D F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A9E A3               [24]  819 	inc	dptr
      005A9F F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005AA0 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005AA3 E4               [12]  823 	clr	a
      005AA4 F0               [24]  824 	movx	@dptr,a
      005AA5 15 82            [12]  825 	dec	dpl
      005AA7 F0               [24]  826 	movx	@dptr,a
      005AA8 15 82            [12]  827 	dec	dpl
      005AAA F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:113: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005AAB FF               [12]  830 	mov	r7,a
      005AAC                        831 00103$:
      005AAC EF               [12]  832 	mov	a,r7
      005AAD 24 86            [12]  833 	add	a, #_input_snapshot
      005AAF F5 82            [12]  834 	mov	dpl,a
      005AB1 E4               [12]  835 	clr	a
      005AB2 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005AB4 F5 83            [12]  837 	mov	dph,a
      005AB6 E4               [12]  838 	clr	a
      005AB7 F0               [24]  839 	movx	@dptr,a
      005AB8 0F               [12]  840 	inc	r7
      005AB9 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005ABC                        842 00139$:
      005ABC 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:114: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005ABE 90 07 8E         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005AC1 74 06            [12]  846 	mov	a,#0x06
      005AC3 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:118: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005AC4 90 07 AE         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005AC7 03               [12]  850 	rr	a
      005AC8 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:119: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005AC9 90 07 B1         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005ACC 04               [12]  854 	inc	a
      005ACD F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:120: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005ACE 7F 00            [12]  857 	mov	r7,#0x00
      005AD0                        858 00105$:
      005AD0 8F 06            [24]  859 	mov	ar6,r7
      005AD2 74 C0            [12]  860 	mov	a,#0xc0
      005AD4 2E               [12]  861 	add	a, r6
      005AD5 F5 82            [12]  862 	mov	dpl,a
      005AD7 74 10            [12]  863 	mov	a,#0x10
      005AD9 24 00            [12]  864 	add	a, #0x00
      005ADB F5 83            [12]  865 	mov	dph,a
      005ADD E4               [12]  866 	clr	a
      005ADE F0               [24]  867 	movx	@dptr,a
      005ADF 0F               [12]  868 	inc	r7
      005AE0 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005AE3                        870 00141$:
      005AE3 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:121: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:122: }
      005AE5 02 5A 3B         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:124: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005AE8                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:125: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005AE8 90 07 63         [24]  884 	mov	dptr,#_raw_state
      005AEB E0               [24]  885 	movx	a,@dptr
      005AEC FF               [12]  886 	mov	r7,a
      005AED BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005AF0 90 07 63         [24]  888 	mov	dptr,#_raw_state
      005AF3 E4               [12]  889 	clr	a
      005AF4 F0               [24]  890 	movx	@dptr,a
      005AF5                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:126: output_kind = OUTPUT_NONE;
      005AF5 90 07 B5         [24]  893 	mov	dptr,#_output_kind
      005AF8 E4               [12]  894 	clr	a
      005AF9 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:127: control_phase = CTRL_IDLE;
      005AFA 90 07 B4         [24]  897 	mov	dptr,#_control_phase
      005AFD F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:128: D0SetupReqCode = 0xff;
      005AFE 90 07 55         [24]  900 	mov	dptr,#_D0SetupReqCode
      005B01 14               [12]  901 	dec	a
      005B02 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005B03 90 22 00         [24]  904 	mov	dptr,#0x2200
      005B06 74 CF            [12]  905 	mov	a,#0xcf
      005B08 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:131: }
      005B09 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_264'
                                    913 ;length        Allocated with name '_control_next_length_10000_264'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:133: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005B0A                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:135: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005B0A 90 07 56         [24]  921 	mov	dptr,#_D0SetupLen
      005B0D E0               [24]  922 	movx	a,@dptr
      005B0E FE               [12]  923 	mov	r6,a
      005B0F A3               [24]  924 	inc	dptr
      005B10 E0               [24]  925 	movx	a,@dptr
      005B11 FF               [12]  926 	mov	r7,a
      005B12 C3               [12]  927 	clr	c
      005B13 74 40            [12]  928 	mov	a,#0x40
      005B15 9E               [12]  929 	subb	a,r6
      005B16 E4               [12]  930 	clr	a
      005B17 9F               [12]  931 	subb	a,r7
      005B18 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005B1A 7E 40            [12]  934 	mov	r6,#0x40
      005B1C 80 07            [24]  935 	sjmp	00110$
      005B1E                        936 00109$:
      005B1E 90 07 56         [24]  937 	mov	dptr,#_D0SetupLen
      005B21 E0               [24]  938 	movx	a,@dptr
      005B22 FE               [12]  939 	mov	r6,a
      005B23 A3               [24]  940 	inc	dptr
      005B24 E0               [24]  941 	movx	a,@dptr
      005B25                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:136: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005B25 7F 00            [12]  944 	mov	r7,#0x00
      005B27                        945 00105$:
      005B27 C3               [12]  946 	clr	c
      005B28 EF               [12]  947 	mov	a,r7
      005B29 9E               [12]  948 	subb	a,r6
      005B2A 50 2A            [24]  949 	jnc	00101$
      005B2C 8F 04            [24]  950 	mov	ar4,r7
      005B2E 74 10            [12]  951 	mov	a,#0x10
      005B30 24 00            [12]  952 	add	a, #0x00
      005B32 FD               [12]  953 	mov	r5,a
      005B33 90 07 B8         [24]  954 	mov	dptr,#_control_pointer
      005B36 E0               [24]  955 	movx	a,@dptr
      005B37 FA               [12]  956 	mov	r2,a
      005B38 A3               [24]  957 	inc	dptr
      005B39 E0               [24]  958 	movx	a,@dptr
      005B3A FB               [12]  959 	mov	r3,a
      005B3B 8A 82            [24]  960 	mov	dpl,r2
      005B3D 8B 83            [24]  961 	mov	dph,r3
      005B3F E4               [12]  962 	clr	a
      005B40 93               [24]  963 	movc	a,@a+dptr
      005B41 F9               [12]  964 	mov	r1,a
      005B42 90 07 B8         [24]  965 	mov	dptr,#_control_pointer
      005B45 74 01            [12]  966 	mov	a,#0x01
      005B47 2A               [12]  967 	add	a, r2
      005B48 F0               [24]  968 	movx	@dptr,a
      005B49 E4               [12]  969 	clr	a
      005B4A 3B               [12]  970 	addc	a, r3
      005B4B A3               [24]  971 	inc	dptr
      005B4C F0               [24]  972 	movx	@dptr,a
      005B4D 8C 82            [24]  973 	mov	dpl,r4
      005B4F 8D 83            [24]  974 	mov	dph,r5
      005B51 E9               [12]  975 	mov	a,r1
      005B52 F0               [24]  976 	movx	@dptr,a
      005B53 0F               [12]  977 	inc	r7
      005B54 80 D1            [24]  978 	sjmp	00105$
      005B56                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:137: D0SetupLen -= length;
      005B56 8E 05            [24]  981 	mov	ar5,r6
      005B58 7F 00            [12]  982 	mov	r7,#0x00
      005B5A 90 07 56         [24]  983 	mov	dptr,#_D0SetupLen
      005B5D E0               [24]  984 	movx	a,@dptr
      005B5E FB               [12]  985 	mov	r3,a
      005B5F A3               [24]  986 	inc	dptr
      005B60 E0               [24]  987 	movx	a,@dptr
      005B61 FC               [12]  988 	mov	r4,a
      005B62 EB               [12]  989 	mov	a,r3
      005B63 C3               [12]  990 	clr	c
      005B64 9D               [12]  991 	subb	a,r5
      005B65 FB               [12]  992 	mov	r3,a
      005B66 EC               [12]  993 	mov	a,r4
      005B67 9F               [12]  994 	subb	a,r7
      005B68 FC               [12]  995 	mov	r4,a
      005B69 90 07 56         [24]  996 	mov	dptr,#_D0SetupLen
      005B6C EB               [12]  997 	mov	a,r3
      005B6D F0               [24]  998 	movx	@dptr,a
      005B6E EC               [12]  999 	mov	a,r4
      005B6F A3               [24] 1000 	inc	dptr
      005B70 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:138: if (!length) control_zlp = 0;
      005B71 EE               [12] 1003 	mov	a,r6
      005B72 70 05            [24] 1004 	jnz	00103$
      005B74 90 07 B7         [24] 1005 	mov	dptr,#_control_zlp
      005B77 E4               [12] 1006 	clr	a
      005B78 F0               [24] 1007 	movx	@dptr,a
      005B79                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0_EP0T_L = length;
      005B79 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005B7C EE               [12] 1011 	mov	a,r6
      005B7D F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:140: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005B7E 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005B81 E0               [24] 1015 	movx	a,@dptr
      005B82 54 C0            [12] 1016 	anl	a,#0xc0
      005B84 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:141: }
      005B85 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_267'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_280'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:157: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005B86                       1032 _descriptor_select:
      005B86 E5 82            [12] 1033 	mov	a,dpl
      005B88 90 07 BD         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_267
      005B8B F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:158: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005B8C E0               [24] 1037 	movx	a,@dptr
      005B8D FF               [12] 1038 	mov	r7,a
      005B8E BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005B91 90 07 BA         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005B94 E0               [24] 1041 	movx	a,@dptr
      005B95 70 1A            [24] 1042 	jnz	00102$
      005B97 90 07 BB         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005B9A E0               [24] 1044 	movx	a,@dptr
      005B9B F5 F0            [12] 1045 	mov	b,a
      005B9D A3               [24] 1046 	inc	dptr
      005B9E E0               [24] 1047 	movx	a,@dptr
      005B9F 45 F0            [12] 1048 	orl	a,b
      005BA1 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:159: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005BA3 90 07 B8         [24] 1051 	mov	dptr,#_control_pointer
      005BA6 74 3E            [12] 1052 	mov	a,#_DeviceDescriptor
      005BA8 F0               [24] 1053 	movx	@dptr,a
      005BA9 74 C5            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005BAB A3               [24] 1055 	inc	dptr
      005BAC F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:160: return sizeof(DeviceDescriptor);
      005BAD 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005BB0 22               [24] 1059 	ret
      005BB1                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:162: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005BB1 90 07 BD         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_267
      005BB4 E0               [24] 1063 	movx	a,@dptr
      005BB5 FF               [12] 1064 	mov	r7,a
      005BB6 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005BB9 90 07 BA         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005BBC E0               [24] 1067 	movx	a,@dptr
      005BBD 70 1A            [24] 1068 	jnz	00106$
      005BBF 90 07 BB         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005BC2 E0               [24] 1070 	movx	a,@dptr
      005BC3 F5 F0            [12] 1071 	mov	b,a
      005BC5 A3               [24] 1072 	inc	dptr
      005BC6 E0               [24] 1073 	movx	a,@dptr
      005BC7 45 F0            [12] 1074 	orl	a,b
      005BC9 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:163: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005BCB 90 07 B8         [24] 1077 	mov	dptr,#_control_pointer
      005BCE 74 50            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005BD0 F0               [24] 1079 	movx	@dptr,a
      005BD1 74 C5            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005BD3 A3               [24] 1081 	inc	dptr
      005BD4 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:164: return sizeof(ConfigurationDescriptor);
      005BD5 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005BD8 22               [24] 1085 	ret
      005BD9                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:166: if (type == USB_DESCR_TYP_STRING) {
      005BD9 90 07 BD         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_267
      005BDC E0               [24] 1089 	movx	a,@dptr
      005BDD FF               [12] 1090 	mov	r7,a
      005BDE BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005BE1 80 03            [24] 1092 	sjmp	00239$
      005BE3                       1093 00238$:
      005BE3 02 5C 7D         [24] 1094 	ljmp	00119$
      005BE6                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (interface != 0 && interface != 0x0409) return 0;
      005BE6 90 07 BB         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005BE9 E0               [24] 1098 	movx	a,@dptr
      005BEA FD               [12] 1099 	mov	r5,a
      005BEB A3               [24] 1100 	inc	dptr
      005BEC E0               [24] 1101 	movx	a,@dptr
      005BED FE               [12] 1102 	mov	r6,a
      005BEE 90 07 BB         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005BF1 E0               [24] 1104 	movx	a,@dptr
      005BF2 F5 F0            [12] 1105 	mov	b,a
      005BF4 A3               [24] 1106 	inc	dptr
      005BF5 E0               [24] 1107 	movx	a,@dptr
      005BF6 45 F0            [12] 1108 	orl	a,b
      005BF8 60 0C            [24] 1109 	jz	00110$
      005BFA BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005BFD BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005C00 80 04            [24] 1112 	sjmp	00110$
      005C02                       1113 00241$:
      005C02 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005C05 22               [24] 1115 	ret
      005C06                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:168: switch (index) {
      005C06 90 07 BA         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005C09 E0               [24] 1119 	movx	a,@dptr
      005C0A FE               [12] 1120 	mov  r6,a
      005C0B 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005C0D 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005C0F EE               [12] 1124 	mov	a,r6
      005C10 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:169: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005C11 90 5C 15         [24] 1127 	mov	dptr,#00243$
      005C14 73               [24] 1128 	jmp	@a+dptr
      005C15                       1129 00243$:
      005C15 80 06            [24] 1130 	sjmp	00112$
      005C17 80 1B            [24] 1131 	sjmp	00113$
      005C19 80 30            [24] 1132 	sjmp	00114$
      005C1B 80 45            [24] 1133 	sjmp	00115$
      005C1D                       1134 00112$:
      005C1D 90 07 B8         [24] 1135 	mov	dptr,#_control_pointer
      005C20 74 A4            [12] 1136 	mov	a,#_LanguageString
      005C22 F0               [24] 1137 	movx	@dptr,a
      005C23 74 C5            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005C25 A3               [24] 1139 	inc	dptr
      005C26 F0               [24] 1140 	movx	@dptr,a
      005C27 90 C5 A4         [24] 1141 	mov	dptr,#_LanguageString
      005C2A E4               [12] 1142 	clr	a
      005C2B 93               [24] 1143 	movc	a,@a+dptr
      005C2C FE               [12] 1144 	mov	r6,a
      005C2D 7D 00            [12] 1145 	mov	r5,#0x00
      005C2F 8E 82            [24] 1146 	mov	dpl, r6
      005C31 8D 83            [24] 1147 	mov	dph, r5
      005C33 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:170: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005C34                       1150 00113$:
      005C34 90 07 B8         [24] 1151 	mov	dptr,#_control_pointer
      005C37 74 A8            [12] 1152 	mov	a,#_ManufacturerString
      005C39 F0               [24] 1153 	movx	@dptr,a
      005C3A 74 C5            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005C3C A3               [24] 1155 	inc	dptr
      005C3D F0               [24] 1156 	movx	@dptr,a
      005C3E 90 C5 A8         [24] 1157 	mov	dptr,#_ManufacturerString
      005C41 E4               [12] 1158 	clr	a
      005C42 93               [24] 1159 	movc	a,@a+dptr
      005C43 FE               [12] 1160 	mov	r6,a
      005C44 7D 00            [12] 1161 	mov	r5,#0x00
      005C46 8E 82            [24] 1162 	mov	dpl, r6
      005C48 8D 83            [24] 1163 	mov	dph, r5
      005C4A 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:171: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005C4B                       1166 00114$:
      005C4B 90 07 B8         [24] 1167 	mov	dptr,#_control_pointer
      005C4E 74 B6            [12] 1168 	mov	a,#_ProductString
      005C50 F0               [24] 1169 	movx	@dptr,a
      005C51 74 C5            [12] 1170 	mov	a,#(_ProductString >> 8)
      005C53 A3               [24] 1171 	inc	dptr
      005C54 F0               [24] 1172 	movx	@dptr,a
      005C55 90 C5 B6         [24] 1173 	mov	dptr,#_ProductString
      005C58 E4               [12] 1174 	clr	a
      005C59 93               [24] 1175 	movc	a,@a+dptr
      005C5A FE               [12] 1176 	mov	r6,a
      005C5B 7D 00            [12] 1177 	mov	r5,#0x00
      005C5D 8E 82            [24] 1178 	mov	dpl, r6
      005C5F 8D 83            [24] 1179 	mov	dph, r5
      005C61 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005C62                       1182 00115$:
      005C62 90 07 B8         [24] 1183 	mov	dptr,#_control_pointer
      005C65 74 EE            [12] 1184 	mov	a,#_SerialNumberString
      005C67 F0               [24] 1185 	movx	@dptr,a
      005C68 74 C5            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005C6A A3               [24] 1187 	inc	dptr
      005C6B F0               [24] 1188 	movx	@dptr,a
      005C6C 90 C5 EE         [24] 1189 	mov	dptr,#_SerialNumberString
      005C6F E4               [12] 1190 	clr	a
      005C70 93               [24] 1191 	movc	a,@a+dptr
      005C71 FE               [12] 1192 	mov	r6,a
      005C72 7D 00            [12] 1193 	mov	r5,#0x00
      005C74 8E 82            [24] 1194 	mov	dpl, r6
      005C76 8D 83            [24] 1195 	mov	dph, r5
      005C78 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:175: default: return 0;
      005C79                       1198 00116$:
      005C79 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005C7C 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:176: }
      005C7D                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:178: if (index || interface >= TOTAL_INTERFACES) return 0;
      005C7D 90 07 BA         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005C80 E0               [24] 1205 	movx	a,@dptr
      005C81 70 11            [24] 1206 	jnz	00120$
      005C83 90 07 BB         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005C86 E0               [24] 1208 	movx	a,@dptr
      005C87 FD               [12] 1209 	mov	r5,a
      005C88 A3               [24] 1210 	inc	dptr
      005C89 E0               [24] 1211 	movx	a,@dptr
      005C8A FE               [12] 1212 	mov	r6,a
      005C8B C3               [12] 1213 	clr	c
      005C8C ED               [12] 1214 	mov	a,r5
      005C8D 94 03            [12] 1215 	subb	a,#0x03
      005C8F EE               [12] 1216 	mov	a,r6
      005C90 94 00            [12] 1217 	subb	a,#0x00
      005C92 40 04            [24] 1218 	jc	00121$
      005C94                       1219 00120$:
      005C94 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005C97 22               [24] 1221 	ret
      005C98                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:179: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005C98 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005C9B 80 03            [24] 1225 	sjmp	00127$
      005C9D                       1226 00246$:
      005C9D BF 21 64         [24] 1227 	cjne	r7,#0x21,00128$
      005CA0                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:180: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[interface].hid;
      005CA0 ED               [12] 1230 	mov	a,r5
      005CA1 2D               [12] 1231 	add	a,r5
      005CA2 FD               [12] 1232 	mov	r5,a
      005CA3 EE               [12] 1233 	mov	a,r6
      005CA4 33               [12] 1234 	rlc	a
      005CA5 FE               [12] 1235 	mov	r6,a
      005CA6 ED               [12] 1236 	mov	a,r5
      005CA7 2D               [12] 1237 	add	a,r5
      005CA8 FD               [12] 1238 	mov	r5,a
      005CA9 EE               [12] 1239 	mov	a,r6
      005CAA 33               [12] 1240 	rlc	a
      005CAB FE               [12] 1241 	mov	r6,a
      005CAC ED               [12] 1242 	mov	a,r5
      005CAD 24 BC            [12] 1243 	add	a, #_interface_descriptors
      005CAF FF               [12] 1244 	mov	r7,a
      005CB0 EE               [12] 1245 	mov	a,r6
      005CB1 34 BE            [12] 1246 	addc	a, #(_interface_descriptors >> 8)
      005CB3 FE               [12] 1247 	mov	r6,a
      005CB4 8F 82            [24] 1248 	mov	dpl,r7
      005CB6 8E 83            [24] 1249 	mov	dph,r6
      005CB8 A3               [24] 1250 	inc	dptr
      005CB9 A3               [24] 1251 	inc	dptr
      005CBA E4               [12] 1252 	clr	a
      005CBB 93               [24] 1253 	movc	a,@a+dptr
      005CBC FC               [12] 1254 	mov	r4,a
      005CBD A3               [24] 1255 	inc	dptr
      005CBE E4               [12] 1256 	clr	a
      005CBF 93               [24] 1257 	movc	a,@a+dptr
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (!hid) return 0;
      005CC0 FD               [12] 1259 	mov	r5,a
      005CC1 4C               [12] 1260 	orl	a,r4
      005CC2 70 04            [24] 1261 	jnz	00124$
      005CC4 90 00 00         [24] 1262 	mov	dptr,#0x0000
      005CC7 22               [24] 1263 	ret
      005CC8                       1264 00124$:
                                   1265 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT) {
      005CC8 90 07 BD         [24] 1266 	mov	dptr,#_descriptor_select_type_10000_267
      005CCB E0               [24] 1267 	movx	a,@dptr
      005CCC FB               [12] 1268 	mov	r3,a
      005CCD BB 22 28         [24] 1269 	cjne	r3,#0x22,00126$
                                   1270 ;	tmk_core/protocol/ch555/usb_ak820.c:183: control_pointer = interface_descriptors[interface].report;
      005CD0 8F 82            [24] 1271 	mov	dpl,r7
      005CD2 8E 83            [24] 1272 	mov	dph,r6
      005CD4 E4               [12] 1273 	clr	a
      005CD5 93               [24] 1274 	movc	a,@a+dptr
      005CD6 FE               [12] 1275 	mov	r6,a
      005CD7 A3               [24] 1276 	inc	dptr
      005CD8 E4               [12] 1277 	clr	a
      005CD9 93               [24] 1278 	movc	a,@a+dptr
      005CDA FF               [12] 1279 	mov	r7,a
      005CDB 90 07 B8         [24] 1280 	mov	dptr,#_control_pointer
      005CDE EE               [12] 1281 	mov	a,r6
      005CDF F0               [24] 1282 	movx	@dptr,a
      005CE0 EF               [12] 1283 	mov	a,r7
      005CE1 A3               [24] 1284 	inc	dptr
      005CE2 F0               [24] 1285 	movx	@dptr,a
                                   1286 ;	tmk_core/protocol/ch555/usb_ak820.c:184: return hid->HIDReportLength;
      005CE3 74 07            [12] 1287 	mov	a,#0x07
      005CE5 2C               [12] 1288 	add	a, r4
      005CE6 F5 82            [12] 1289 	mov	dpl,a
      005CE8 E4               [12] 1290 	clr	a
      005CE9 3D               [12] 1291 	addc	a, r5
      005CEA F5 83            [12] 1292 	mov	dph,a
      005CEC E4               [12] 1293 	clr	a
      005CED 93               [24] 1294 	movc	a,@a+dptr
      005CEE FE               [12] 1295 	mov	r6,a
      005CEF A3               [24] 1296 	inc	dptr
      005CF0 E4               [12] 1297 	clr	a
      005CF1 93               [24] 1298 	movc	a,@a+dptr
      005CF2 FF               [12] 1299 	mov	r7,a
      005CF3 8E 82            [24] 1300 	mov	dpl, r6
      005CF5 8F 83            [24] 1301 	mov	dph, r7
      005CF7 22               [24] 1302 	ret
      005CF8                       1303 00126$:
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = (const uint8_t __code *)hid;
      005CF8 90 07 B8         [24] 1305 	mov	dptr,#_control_pointer
      005CFB EC               [12] 1306 	mov	a,r4
      005CFC F0               [24] 1307 	movx	@dptr,a
      005CFD ED               [12] 1308 	mov	a,r5
      005CFE A3               [24] 1309 	inc	dptr
      005CFF F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return 9;
      005D00 90 00 09         [24] 1312 	mov	dptr,#0x0009
      005D03 22               [24] 1313 	ret
      005D04                       1314 00128$:
                                   1315 ;	tmk_core/protocol/ch555/usb_ak820.c:189: return 0;
      005D04 90 00 00         [24] 1316 	mov	dptr,#0x0000
                                   1317 ;	tmk_core/protocol/ch555/usb_ak820.c:190: }
      005D07 22               [24] 1318 	ret
                                   1319 ;------------------------------------------------------------
                                   1320 ;Allocation info for local variables in function 'control_setup'
                                   1321 ;------------------------------------------------------------
                                   1322 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1323 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1324 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1325 ;type          Allocated with name '_control_setup_type_10000_285'
                                   1326 ;value         Allocated with name '_control_setup_value_10000_285'
                                   1327 ;index         Allocated with name '_control_setup_index_10000_285'
                                   1328 ;length        Allocated with name '_control_setup_length_10000_285'
                                   1329 ;endpoint      Allocated with name '_control_setup_endpoint_10000_285'
                                   1330 ;i             Allocated with name '_control_setup_i_10000_285'
                                   1331 ;offset        Allocated with name '_control_setup_offset_10000_285'
                                   1332 ;report_id     Allocated with name '_control_setup_report_id_10000_285'
                                   1333 ;------------------------------------------------------------
                                   1334 ;	tmk_core/protocol/ch555/usb_ak820.c:192: static void control_setup(void) {
                                   1335 ;	-----------------------------------------
                                   1336 ;	 function control_setup
                                   1337 ;	-----------------------------------------
      005D08                       1338 _control_setup:
                                   1339 ;	tmk_core/protocol/ch555/usb_ak820.c:193: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005D08 90 10 00         [24] 1340 	mov	dptr,#0x1000
      005D0B E0               [24] 1341 	movx	a,@dptr
      005D0C FF               [12] 1342 	mov	r7,a
                                   1343 ;	tmk_core/protocol/ch555/usb_ak820.c:194: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005D0D A3               [24] 1344 	inc	dptr
      005D0E A3               [24] 1345 	inc	dptr
      005D0F E0               [24] 1346 	movx	a,@dptr
      005D10 FE               [12] 1347 	mov	r6,a
      005D11 A3               [24] 1348 	inc	dptr
      005D12 E0               [24] 1349 	movx	a,@dptr
      005D13 FC               [12] 1350 	mov	r4,a
      005D14 7D 00            [12] 1351 	mov	r5,#0x00
      005D16 8E 03            [24] 1352 	mov	ar3,r6
      005D18 7E 00            [12] 1353 	mov	r6,#0x00
      005D1A ED               [12] 1354 	mov	a,r5
      005D1B 4B               [12] 1355 	orl	a,r3
      005D1C FD               [12] 1356 	mov	r5,a
      005D1D EC               [12] 1357 	mov	a,r4
      005D1E 4E               [12] 1358 	orl	a,r6
      005D1F FE               [12] 1359 	mov	r6,a
                                   1360 ;	tmk_core/protocol/ch555/usb_ak820.c:195: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005D20 A3               [24] 1361 	inc	dptr
      005D21 E0               [24] 1362 	movx	a,@dptr
      005D22 FC               [12] 1363 	mov	r4,a
      005D23 A3               [24] 1364 	inc	dptr
      005D24 E0               [24] 1365 	movx	a,@dptr
      005D25 FA               [12] 1366 	mov	r2,a
      005D26 7B 00            [12] 1367 	mov	r3,#0x00
      005D28 8C 01            [24] 1368 	mov	ar1,r4
      005D2A 7C 00            [12] 1369 	mov	r4,#0x00
      005D2C EB               [12] 1370 	mov	a,r3
      005D2D 49               [12] 1371 	orl	a,r1
      005D2E FB               [12] 1372 	mov	r3,a
      005D2F EA               [12] 1373 	mov	a,r2
      005D30 4C               [12] 1374 	orl	a,r4
      005D31 FC               [12] 1375 	mov	r4,a
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:199: __bit valid_interface = index < TOTAL_INTERFACES;
      005D32 C3               [12] 1377 	clr	c
      005D33 EB               [12] 1378 	mov	a,r3
      005D34 94 03            [12] 1379 	subb	a,#0x03
      005D36 EC               [12] 1380 	mov	a,r4
      005D37 94 00            [12] 1381 	subb	a,#0x00
      005D39 92 0F            [24] 1382 	mov	_control_setup_valid_interface_10000_285,c
                                   1383 ;	tmk_core/protocol/ch555/usb_ak820.c:200: __bit zero_index = !index;
      005D3B EB               [12] 1384 	mov	a,r3
      005D3C 4C               [12] 1385 	orl	a,r4
      005D3D B4 01 00         [24] 1386 	cjne	a,#0x01,01201$
      005D40                       1387 01201$:
      005D40 92 10            [24] 1388 	mov	_control_setup_zero_index_10000_285,c
                                   1389 ;	tmk_core/protocol/ch555/usb_ak820.c:201: __bit zero_value = !value;
      005D42 ED               [12] 1390 	mov	a,r5
      005D43 4E               [12] 1391 	orl	a,r6
      005D44 B4 01 00         [24] 1392 	cjne	a,#0x01,01202$
      005D47                       1393 01202$:
                                   1394 ;	assignBit
      005D47 92 13            [24] 1395 	mov  _control_setup_sloc0_1_0,c
      005D49 92 11            [24] 1396 	mov	_control_setup_zero_value_10000_285,c
                                   1397 ;	tmk_core/protocol/ch555/usb_ak820.c:205: uint8_t offset = 0;
      005D4B 90 07 C0         [24] 1398 	mov	dptr,#_control_setup_offset_10000_285
      005D4E E4               [12] 1399 	clr	a
      005D4F F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	tmk_core/protocol/ch555/usb_ak820.c:207: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005D50 90 07 63         [24] 1402 	mov	dptr,#_raw_state
      005D53 E0               [24] 1403 	movx	a,@dptr
      005D54 FA               [12] 1404 	mov	r2,a
      005D55 BA 01 05         [24] 1405 	cjne	r2,#0x01,00102$
      005D58 90 07 63         [24] 1406 	mov	dptr,#_raw_state
      005D5B E4               [12] 1407 	clr	a
      005D5C F0               [24] 1408 	movx	@dptr,a
      005D5D                       1409 00102$:
                                   1410 ;	tmk_core/protocol/ch555/usb_ak820.c:208: output_kind = OUTPUT_NONE;
      005D5D C0 07            [24] 1411 	push	ar7
      005D5F 90 07 B5         [24] 1412 	mov	dptr,#_output_kind
      005D62 E4               [12] 1413 	clr	a
      005D63 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:209: control_phase = CTRL_IDLE;
      005D64 90 07 B4         [24] 1416 	mov	dptr,#_control_phase
      005D67 F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	tmk_core/protocol/ch555/usb_ak820.c:210: control_zlp = 0;
      005D68 90 07 B7         [24] 1419 	mov	dptr,#_control_zlp
      005D6B F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	tmk_core/protocol/ch555/usb_ak820.c:211: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005D6C 90 10 01         [24] 1422 	mov	dptr,#0x1001
      005D6F E0               [24] 1423 	movx	a,@dptr
      005D70 90 07 55         [24] 1424 	mov	dptr,#_D0SetupReqCode
      005D73 F0               [24] 1425 	movx	@dptr,a
                                   1426 ;	tmk_core/protocol/ch555/usb_ak820.c:212: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005D74 90 10 06         [24] 1427 	mov	dptr,#0x1006
      005D77 E0               [24] 1428 	movx	a,@dptr
      005D78 FA               [12] 1429 	mov	r2,a
      005D79 A3               [24] 1430 	inc	dptr
      005D7A E0               [24] 1431 	movx	a,@dptr
      005D7B F9               [12] 1432 	mov	r1,a
      005D7C 78 00            [12] 1433 	mov	r0,#0x00
      005D7E 7F 00            [12] 1434 	mov	r7,#0x00
      005D80 90 07 56         [24] 1435 	mov	dptr,#_D0SetupLen
      005D83 E8               [12] 1436 	mov	a,r0
      005D84 4A               [12] 1437 	orl	a,r2
      005D85 F0               [24] 1438 	movx	@dptr,a
      005D86 E9               [12] 1439 	mov	a,r1
      005D87 4F               [12] 1440 	orl	a,r7
      005D88 A3               [24] 1441 	inc	dptr
      005D89 F0               [24] 1442 	movx	@dptr,a
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:213: zero_length = !D0SetupLen;
      005D8A 90 07 56         [24] 1444 	mov	dptr,#_D0SetupLen
      005D8D E0               [24] 1445 	movx	a,@dptr
      005D8E FA               [12] 1446 	mov	r2,a
      005D8F A3               [24] 1447 	inc	dptr
      005D90 E0               [24] 1448 	movx	a,@dptr
      005D91 4A               [12] 1449 	orl	a,r2
      005D92 B4 01 00         [24] 1450 	cjne	a,#0x01,01205$
      005D95                       1451 01205$:
      005D95 92 12            [24] 1452 	mov	_control_setup_zero_length_10000_285,c
                                   1453 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005D97 90 22 00         [24] 1454 	mov	dptr,#0x2200
      005D9A 74 C2            [12] 1455 	mov	a,#0xc2
      005D9C F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0_EP0T_L = 0;
      005D9D 90 22 08         [24] 1458 	mov	dptr,#0x2208
      005DA0 E4               [12] 1459 	clr	a
      005DA1 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	tmk_core/protocol/ch555/usb_ak820.c:219: switch (D0SetupReqCode) {
      005DA2 90 07 55         [24] 1462 	mov	dptr,#_D0SetupReqCode
      005DA5 E0               [24] 1463 	movx	a,@dptr
      005DA6 F5 26            [12] 1464 	mov	_control_setup_sloc1_1_0,a
      005DA8 C3               [12] 1465 	clr	c
      005DA9 74 0B            [12] 1466 	mov	a,#0x0b
      005DAB 95 26            [12] 1467 	subb	a,_control_setup_sloc1_1_0
      005DAD D0 07            [24] 1468 	pop	ar7
      005DAF 50 03            [24] 1469 	jnc	01206$
      005DB1 02 5A E8         [24] 1470 	ljmp	_control_stall
      005DB4                       1471 01206$:
                                   1472 ;	free result
      005DB4 E5 26            [12] 1473 	mov	a,_control_setup_sloc1_1_0
      005DB6 F5 F0            [12] 1474 	mov	b,a
      005DB8 24 0B            [12] 1475 	add	a,#(01207$-3-.)
      005DBA 83               [24] 1476 	movc	a,@a+pc
      005DBB F5 82            [12] 1477 	mov	dpl,a
      005DBD E5 F0            [12] 1478 	mov	a,b
      005DBF 24 10            [12] 1479 	add	a,#(01208$-3-.)
      005DC1 83               [24] 1480 	movc	a,@a+pc
      005DC2 F5 83            [12] 1481 	mov	dph,a
      005DC4 E4               [12] 1482 	clr	a
      005DC5 73               [24] 1483 	jmp	@a+dptr
      005DC6                       1484 01207$:
      005DC6 6E                    1485 	.db	00188$
      005DC7 14                    1486 	.db	00205$
      005DC8 63                    1487 	.db	00282$
      005DC9 14                    1488 	.db	00205$
      005DCA A7                    1489 	.db	00290$
      005DCB 98                    1490 	.db	00116$
      005DCC DE                    1491 	.db	00103$
      005DCD A7                    1492 	.db	00290$
      005DCE 9D                    1493 	.db	00150$
      005DCF C1                    1494 	.db	00123$
      005DD0 CD                    1495 	.db	00157$
      005DD1 20                    1496 	.db	00173$
      005DD2                       1497 01208$:
      005DD2 60                    1498 	.db	00188$>>8
      005DD3 61                    1499 	.db	00205$>>8
      005DD4 64                    1500 	.db	00282$>>8
      005DD5 61                    1501 	.db	00205$>>8
      005DD6 64                    1502 	.db	00290$>>8
      005DD7 5E                    1503 	.db	00116$>>8
      005DD8 5D                    1504 	.db	00103$>>8
      005DD9 64                    1505 	.db	00290$>>8
      005DDA 5F                    1506 	.db	00150$>>8
      005DDB 5E                    1507 	.db	00123$>>8
      005DDC 5F                    1508 	.db	00157$>>8
      005DDD 60                    1509 	.db	00173$>>8
                                   1510 ;	tmk_core/protocol/ch555/usb_ak820.c:220: case USB_GET_DESCRIPTOR:
      005DDE                       1511 00103$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:221: if (type == 0x80 || type == 0x81) {
      005DDE BF 80 02         [24] 1513 	cjne	r7,#0x80,01209$
      005DE1 80 08            [24] 1514 	sjmp	00112$
      005DE3                       1515 01209$:
      005DE3 BF 81 02         [24] 1516 	cjne	r7,#0x81,01210$
      005DE6 80 03            [24] 1517 	sjmp	01211$
      005DE8                       1518 01210$:
      005DE8 02 5A E8         [24] 1519 	ljmp	_control_stall
      005DEB                       1520 01211$:
      005DEB                       1521 00112$:
                                   1522 ;	tmk_core/protocol/ch555/usb_ak820.c:222: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005DEB 8E 01            [24] 1523 	mov	ar1,r6
      005DED B9 21 02         [24] 1524 	cjne	r1,#0x21,01212$
      005DF0 80 09            [24] 1525 	sjmp	00301$
      005DF2                       1526 01212$:
      005DF2 B9 22 02         [24] 1527 	cjne	r1,#0x22,01213$
      005DF5 80 04            [24] 1528 	sjmp	00301$
      005DF7                       1529 01213$:
                                   1530 ;	assignBit
      005DF7 C2 14            [12] 1531 	clr	_control_setup_sloc2_1_0
      005DF9 80 02            [24] 1532 	sjmp	00302$
      005DFB                       1533 00301$:
                                   1534 ;	assignBit
      005DFB D2 14            [12] 1535 	setb	_control_setup_sloc2_1_0
      005DFD                       1536 00302$:
      005DFD E4               [12] 1537 	clr	a
      005DFE BF 81 01         [24] 1538 	cjne	r7,#0x81,01214$
      005E01 04               [12] 1539 	inc	a
      005E02                       1540 01214$:
      005E02 FA               [12] 1541 	mov	r2,a
      005E03 A2 14            [12] 1542 	mov	c,_control_setup_sloc2_1_0
      005E05 E4               [12] 1543 	clr	a
      005E06 33               [12] 1544 	rlc	a
      005E07 B5 02 02         [24] 1545 	cjne	a,ar2,01216$
      005E0A 80 03            [24] 1546 	sjmp	00105$
      005E0C                       1547 01216$:
                                   1548 ;	tmk_core/protocol/ch555/usb_ak820.c:223: control_stall(); return;
      005E0C 02 5A E8         [24] 1549 	ljmp	_control_stall
      005E0F                       1550 00105$:
                                   1551 ;	tmk_core/protocol/ch555/usb_ak820.c:225: length = descriptor_select(value >> 8, value, index);
      005E0F 8E 02            [24] 1552 	mov	ar2,r6
      005E11 90 07 BA         [24] 1553 	mov	dptr,#_descriptor_select_PARM_2
      005E14 ED               [12] 1554 	mov	a,r5
      005E15 F0               [24] 1555 	movx	@dptr,a
      005E16 90 07 BB         [24] 1556 	mov	dptr,#_descriptor_select_PARM_3
      005E19 EB               [12] 1557 	mov	a,r3
      005E1A F0               [24] 1558 	movx	@dptr,a
      005E1B EC               [12] 1559 	mov	a,r4
      005E1C A3               [24] 1560 	inc	dptr
      005E1D F0               [24] 1561 	movx	@dptr,a
      005E1E 8A 82            [24] 1562 	mov	dpl, r2
      005E20 12 5B 86         [24] 1563 	lcall	_descriptor_select
      005E23 85 82 27         [24] 1564 	mov	_control_setup_sloc3_1_0,dpl
      005E26 85 83 28         [24] 1565 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1566 ;	tmk_core/protocol/ch555/usb_ak820.c:226: if (!length) { control_stall(); return; }
      005E29 E5 27            [12] 1567 	mov	a,_control_setup_sloc3_1_0
      005E2B 45 28            [12] 1568 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005E2D 70 03            [24] 1569 	jnz	00107$
      005E2F 02 5A E8         [24] 1570 	ljmp	_control_stall
      005E32                       1571 00107$:
                                   1572 ;	tmk_core/protocol/ch555/usb_ak820.c:227: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005E32 90 07 56         [24] 1573 	mov	dptr,#_D0SetupLen
      005E35 E0               [24] 1574 	movx	a,@dptr
      005E36 F8               [12] 1575 	mov	r0,a
      005E37 A3               [24] 1576 	inc	dptr
      005E38 E0               [24] 1577 	movx	a,@dptr
      005E39 FA               [12] 1578 	mov	r2,a
      005E3A C3               [12] 1579 	clr	c
      005E3B E5 27            [12] 1580 	mov	a,_control_setup_sloc3_1_0
      005E3D 98               [12] 1581 	subb	a,r0
      005E3E E5 28            [12] 1582 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E40 9A               [12] 1583 	subb	a,r2
      005E41 50 06            [24] 1584 	jnc	00303$
      005E43 E5 27            [12] 1585 	mov	a,_control_setup_sloc3_1_0
      005E45 54 3F            [12] 1586 	anl	a,#0x3f
      005E47 60 04            [24] 1587 	jz	00304$
      005E49                       1588 00303$:
                                   1589 ;	assignBit
      005E49 C2 14            [12] 1590 	clr	_control_setup_sloc2_1_0
      005E4B 80 02            [24] 1591 	sjmp	00305$
      005E4D                       1592 00304$:
                                   1593 ;	assignBit
      005E4D D2 14            [12] 1594 	setb	_control_setup_sloc2_1_0
      005E4F                       1595 00305$:
      005E4F 90 07 B7         [24] 1596 	mov	dptr,#_control_zlp
      005E52 A2 14            [12] 1597 	mov	c,_control_setup_sloc2_1_0
      005E54 E4               [12] 1598 	clr	a
      005E55 33               [12] 1599 	rlc	a
      005E56 F0               [24] 1600 	movx	@dptr,a
                                   1601 ;	tmk_core/protocol/ch555/usb_ak820.c:228: if (D0SetupLen > length) D0SetupLen = length;
      005E57 90 07 56         [24] 1602 	mov	dptr,#_D0SetupLen
      005E5A E0               [24] 1603 	movx	a,@dptr
      005E5B F9               [12] 1604 	mov	r1,a
      005E5C A3               [24] 1605 	inc	dptr
      005E5D E0               [24] 1606 	movx	a,@dptr
      005E5E FA               [12] 1607 	mov	r2,a
      005E5F C3               [12] 1608 	clr	c
      005E60 E5 27            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      005E62 99               [12] 1610 	subb	a,r1
      005E63 E5 28            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E65 9A               [12] 1612 	subb	a,r2
      005E66 50 0A            [24] 1613 	jnc	00109$
                                   1614 ;	free result
      005E68 90 07 56         [24] 1615 	mov	dptr,#_D0SetupLen
      005E6B E5 27            [12] 1616 	mov	a,_control_setup_sloc3_1_0
      005E6D F0               [24] 1617 	movx	@dptr,a
      005E6E E5 28            [12] 1618 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E70 A3               [24] 1619 	inc	dptr
      005E71 F0               [24] 1620 	movx	@dptr,a
      005E72                       1621 00109$:
                                   1622 ;	tmk_core/protocol/ch555/usb_ak820.c:229: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005E72 90 07 56         [24] 1623 	mov	dptr,#_D0SetupLen
      005E75 E0               [24] 1624 	movx	a,@dptr
      005E76 F9               [12] 1625 	mov	r1,a
      005E77 A3               [24] 1626 	inc	dptr
      005E78 E0               [24] 1627 	movx	a,@dptr
      005E79 49               [12] 1628 	orl	a,r1
      005E7A 60 04            [24] 1629 	jz	00306$
      005E7C 7A 01            [12] 1630 	mov	r2,#0x01
      005E7E 80 02            [24] 1631 	sjmp	00307$
      005E80                       1632 00306$:
      005E80 7A 02            [12] 1633 	mov	r2,#0x02
      005E82                       1634 00307$:
      005E82 90 07 B4         [24] 1635 	mov	dptr,#_control_phase
      005E85 EA               [12] 1636 	mov	a,r2
      005E86 F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (D0SetupLen) control_next();
      005E87 90 07 56         [24] 1639 	mov	dptr,#_D0SetupLen
      005E8A E0               [24] 1640 	movx	a,@dptr
      005E8B F9               [12] 1641 	mov	r1,a
      005E8C A3               [24] 1642 	inc	dptr
      005E8D E0               [24] 1643 	movx	a,@dptr
      005E8E 49               [12] 1644 	orl	a,r1
      005E8F 60 03            [24] 1645 	jz	00111$
                                   1646 ;	tmk_core/protocol/ch555/usb_ak820.c:231: return;
      005E91 02 5B 0A         [24] 1647 	ljmp	_control_next
      005E94                       1648 00111$:
      005E94 22               [24] 1649 	ret
                                   1650 ;	tmk_core/protocol/ch555/usb_ak820.c:232: } else { control_stall(); return; }
      005E95 02 5A E8         [24] 1651 	ljmp	_control_stall
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:233: case USB_SET_ADDRESS:
      005E98                       1653 00116$:
                                   1654 ;	tmk_core/protocol/ch555/usb_ak820.c:234: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005E98 EF               [12] 1655 	mov	a,r7
      005E99 70 23            [24] 1656 	jnz	00118$
      005E9B 30 10 20         [24] 1657 	jnb	_control_setup_zero_index_10000_285,00118$
      005E9E 30 12 1D         [24] 1658 	jnb	_control_setup_zero_length_10000_285,00118$
      005EA1 8D 01            [24] 1659 	mov	ar1,r5
      005EA3 8E 02            [24] 1660 	mov	ar2,r6
      005EA5 C3               [12] 1661 	clr	c
      005EA6 74 7F            [12] 1662 	mov	a,#0x7f
      005EA8 99               [12] 1663 	subb	a,r1
      005EA9 E4               [12] 1664 	clr	a
      005EAA 9A               [12] 1665 	subb	a,r2
      005EAB 40 11            [24] 1666 	jc	00118$
                                   1667 ;	free result
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:235: D0SetupLen = value; /* applied after status-IN ACK */
      005EAD 90 07 56         [24] 1669 	mov	dptr,#_D0SetupLen
      005EB0 ED               [12] 1670 	mov	a,r5
      005EB1 F0               [24] 1671 	movx	@dptr,a
      005EB2 EE               [12] 1672 	mov	a,r6
      005EB3 A3               [24] 1673 	inc	dptr
      005EB4 F0               [24] 1674 	movx	@dptr,a
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_phase = CTRL_STATUS_IN;
      005EB5 90 07 B4         [24] 1676 	mov	dptr,#_control_phase
      005EB8 74 03            [12] 1677 	mov	a,#0x03
      005EBA F0               [24] 1678 	movx	@dptr,a
      005EBB 02 64 AA         [24] 1679 	ljmp	00291$
      005EBE                       1680 00118$:
                                   1681 ;	tmk_core/protocol/ch555/usb_ak820.c:237: } else { control_stall(); return; }
      005EBE 02 5A E8         [24] 1682 	ljmp	_control_stall
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:239: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005EC1                       1684 00123$:
                                   1685 ;	tmk_core/protocol/ch555/usb_ak820.c:240: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005EC1 EF               [12] 1686 	mov	a,r7
      005EC2 70 3C            [24] 1687 	jnz	00145$
      005EC4 30 10 39         [24] 1688 	jnb	_control_setup_zero_index_10000_285,00145$
      005EC7 30 12 36         [24] 1689 	jnb	_control_setup_zero_length_10000_285,00145$
      005ECA 8D 01            [24] 1690 	mov	ar1,r5
      005ECC 8E 02            [24] 1691 	mov	ar2,r6
      005ECE C3               [12] 1692 	clr	c
      005ECF 74 01            [12] 1693 	mov	a,#0x01
      005ED1 99               [12] 1694 	subb	a,r1
      005ED2 E4               [12] 1695 	clr	a
      005ED3 9A               [12] 1696 	subb	a,r2
      005ED4 40 2A            [24] 1697 	jc	00145$
                                   1698 ;	free result
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:241: endpoints_reset();
      005ED6 C0 06            [24] 1700 	push	ar6
      005ED8 C0 05            [24] 1701 	push	ar5
      005EDA 12 5A 91         [24] 1702 	lcall	_endpoints_reset
      005EDD D0 05            [24] 1703 	pop	ar5
      005EDF D0 06            [24] 1704 	pop	ar6
                                   1705 ;	tmk_core/protocol/ch555/usb_ak820.c:242: D0UsbConfig = value;
      005EE1 90 07 5B         [24] 1706 	mov	dptr,#_D0UsbConfig
      005EE4 ED               [12] 1707 	mov	a,r5
      005EE5 F0               [24] 1708 	movx	@dptr,a
                                   1709 ;	tmk_core/protocol/ch555/usb_ak820.c:243: USB_EnumStatus = value != 0;
      005EE6 A2 13            [12] 1710 	mov	c,_control_setup_sloc0_1_0
      005EE8 B3               [12] 1711 	cpl	c
      005EE9 92 14            [24] 1712 	mov	_control_setup_sloc2_1_0,c
      005EEB 90 07 5C         [24] 1713 	mov	dptr,#_USB_EnumStatus
      005EEE E4               [12] 1714 	clr	a
      005EEF 33               [12] 1715 	rlc	a
      005EF0 F0               [24] 1716 	movx	@dptr,a
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:244: keyboard_reset = 1;
      005EF1 90 07 85         [24] 1718 	mov	dptr,#_keyboard_reset
      005EF4 74 01            [12] 1719 	mov	a,#0x01
      005EF6 F0               [24] 1720 	movx	@dptr,a
                                   1721 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      005EF7 90 07 B4         [24] 1722 	mov	dptr,#_control_phase
      005EFA 74 03            [12] 1723 	mov	a,#0x03
      005EFC F0               [24] 1724 	movx	@dptr,a
      005EFD 02 64 AA         [24] 1725 	ljmp	00291$
      005F00                       1726 00145$:
                                   1727 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else if (type == 0x21 && D0UsbConfig) {
      005F00 BF 21 02         [24] 1728 	cjne	r7,#0x21,01231$
      005F03 80 03            [24] 1729 	sjmp	01232$
      005F05                       1730 01231$:
      005F05 02 5A E8         [24] 1731 	ljmp	_control_stall
      005F08                       1732 01232$:
      005F08 90 07 5B         [24] 1733 	mov	dptr,#_D0UsbConfig
      005F0B E0               [24] 1734 	movx	a,@dptr
      005F0C 70 03            [24] 1735 	jnz	01233$
      005F0E 02 5A E8         [24] 1736 	ljmp	_control_stall
      005F11                       1737 01233$:
                                   1738 ;	tmk_core/protocol/ch555/usb_ak820.c:247: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005F11 BB 01 2D         [24] 1739 	cjne	r3,#0x01,00135$
      005F14 BC 00 2A         [24] 1740 	cjne	r4,#0x00,00135$
      005F17 8D 01            [24] 1741 	mov	ar1,r5
      005F19 8E 02            [24] 1742 	mov	ar2,r6
      005F1B B9 00 23         [24] 1743 	cjne	r1,#0x00,00135$
      005F1E BA 02 20         [24] 1744 	cjne	r2,#0x02,00135$
      005F21 90 07 56         [24] 1745 	mov	dptr,#_D0SetupLen
      005F24 E0               [24] 1746 	movx	a,@dptr
      005F25 F9               [12] 1747 	mov	r1,a
      005F26 A3               [24] 1748 	inc	dptr
      005F27 E0               [24] 1749 	movx	a,@dptr
      005F28 FA               [12] 1750 	mov	r2,a
      005F29 B9 20 15         [24] 1751 	cjne	r1,#0x20,00135$
      005F2C BA 00 12         [24] 1752 	cjne	r2,#0x00,00135$
      005F2F 90 07 63         [24] 1753 	mov	dptr,#_raw_state
      005F32 E0               [24] 1754 	movx	a,@dptr
      005F33 70 0C            [24] 1755 	jnz	00135$
                                   1756 ;	tmk_core/protocol/ch555/usb_ak820.c:248: raw_state = RAW_RX;
      005F35 90 07 63         [24] 1757 	mov	dptr,#_raw_state
      005F38 74 01            [12] 1758 	mov	a,#0x01
      005F3A F0               [24] 1759 	movx	@dptr,a
                                   1760 ;	tmk_core/protocol/ch555/usb_ak820.c:249: output_kind = OUTPUT_RAW;
      005F3B 90 07 B5         [24] 1761 	mov	dptr,#_output_kind
      005F3E F0               [24] 1762 	movx	@dptr,a
      005F3F 80 52            [24] 1763 	sjmp	00136$
      005F41                       1764 00135$:
                                   1765 ;	tmk_core/protocol/ch555/usb_ak820.c:250: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005F41 EB               [12] 1766 	mov	a,r3
      005F42 4C               [12] 1767 	orl	a,r4
      005F43 70 20            [24] 1768 	jnz	00130$
      005F45 8D 01            [24] 1769 	mov	ar1,r5
      005F47 8E 02            [24] 1770 	mov	ar2,r6
      005F49 B9 00 19         [24] 1771 	cjne	r1,#0x00,00130$
      005F4C BA 02 16         [24] 1772 	cjne	r2,#0x02,00130$
      005F4F 90 07 56         [24] 1773 	mov	dptr,#_D0SetupLen
      005F52 E0               [24] 1774 	movx	a,@dptr
      005F53 F9               [12] 1775 	mov	r1,a
      005F54 A3               [24] 1776 	inc	dptr
      005F55 E0               [24] 1777 	movx	a,@dptr
      005F56 FA               [12] 1778 	mov	r2,a
      005F57 B9 01 0B         [24] 1779 	cjne	r1,#0x01,00130$
      005F5A BA 00 08         [24] 1780 	cjne	r2,#0x00,00130$
                                   1781 ;	tmk_core/protocol/ch555/usb_ak820.c:251: output_kind = OUTPUT_LED;
      005F5D 90 07 B5         [24] 1782 	mov	dptr,#_output_kind
      005F60 74 02            [12] 1783 	mov	a,#0x02
      005F62 F0               [24] 1784 	movx	@dptr,a
      005F63 80 2E            [24] 1785 	sjmp	00136$
      005F65                       1786 00130$:
                                   1787 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005F65 BB 02 28         [24] 1788 	cjne	r3,#0x02,00125$
      005F68 BC 00 25         [24] 1789 	cjne	r4,#0x00,00125$
      005F6B 8D 01            [24] 1790 	mov	ar1,r5
      005F6D 8E 02            [24] 1791 	mov	ar2,r6
      005F6F B9 06 1E         [24] 1792 	cjne	r1,#0x06,00125$
      005F72 BA 02 1B         [24] 1793 	cjne	r2,#0x02,00125$
      005F75 90 07 56         [24] 1794 	mov	dptr,#_D0SetupLen
      005F78 E0               [24] 1795 	movx	a,@dptr
      005F79 F9               [12] 1796 	mov	r1,a
      005F7A A3               [24] 1797 	inc	dptr
      005F7B E0               [24] 1798 	movx	a,@dptr
      005F7C FA               [12] 1799 	mov	r2,a
      005F7D B9 02 10         [24] 1800 	cjne	r1,#0x02,00125$
      005F80 BA 00 0D         [24] 1801 	cjne	r2,#0x00,00125$
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_SHARED_LED;
      005F83 90 07 B5         [24] 1803 	mov	dptr,#_output_kind
      005F86 74 03            [12] 1804 	mov	a,#0x03
      005F88 F0               [24] 1805 	movx	@dptr,a
                                   1806 ;	tmk_core/protocol/ch555/usb_ak820.c:255: output_report_id = REPORT_ID_NKRO;
      005F89 90 07 B6         [24] 1807 	mov	dptr,#_output_report_id
      005F8C 23               [12] 1808 	rl	a
      005F8D F0               [24] 1809 	movx	@dptr,a
      005F8E 80 03            [24] 1810 	sjmp	00136$
      005F90                       1811 00125$:
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:257: } else { control_stall(); return; }
      005F90 02 5A E8         [24] 1813 	ljmp	_control_stall
      005F93                       1814 00136$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:258: control_phase = CTRL_DATA_OUT;
      005F93 90 07 B4         [24] 1816 	mov	dptr,#_control_phase
      005F96 74 04            [12] 1817 	mov	a,#0x04
      005F98 F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:259: return; /* OUT data must arrive before status-IN becomes ACK */
      005F99 22               [24] 1820 	ret
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      005F9A 02 5A E8         [24] 1822 	ljmp	_control_stall
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:262: case USB_GET_CONFIGURATION:
      005F9D                       1824 00150$:
                                   1825 ;	tmk_core/protocol/ch555/usb_ak820.c:263: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005F9D BF 80 2A         [24] 1826 	cjne	r7,#0x80,00152$
      005FA0 30 10 27         [24] 1827 	jnb	_control_setup_zero_index_10000_285,00152$
      005FA3 30 11 24         [24] 1828 	jnb	_control_setup_zero_value_10000_285,00152$
      005FA6 90 07 56         [24] 1829 	mov	dptr,#_D0SetupLen
      005FA9 E0               [24] 1830 	movx	a,@dptr
      005FAA F9               [12] 1831 	mov	r1,a
      005FAB A3               [24] 1832 	inc	dptr
      005FAC E0               [24] 1833 	movx	a,@dptr
      005FAD FA               [12] 1834 	mov	r2,a
      005FAE B9 01 19         [24] 1835 	cjne	r1,#0x01,00152$
      005FB1 BA 00 16         [24] 1836 	cjne	r2,#0x00,00152$
                                   1837 ;	tmk_core/protocol/ch555/usb_ak820.c:264: pD0_EP0_BUF[0] = D0UsbConfig;
      005FB4 90 07 5B         [24] 1838 	mov	dptr,#_D0UsbConfig
      005FB7 E0               [24] 1839 	movx	a,@dptr
      005FB8 90 10 00         [24] 1840 	mov	dptr,#0x1000
      005FBB F0               [24] 1841 	movx	@dptr,a
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:265: D0_EP0T_L = 1;
      005FBC 90 22 08         [24] 1843 	mov	dptr,#0x2208
      005FBF 74 01            [12] 1844 	mov	a,#0x01
      005FC1 F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:266: control_phase = CTRL_STATUS_OUT;
      005FC2 90 07 B4         [24] 1847 	mov	dptr,#_control_phase
      005FC5 04               [12] 1848 	inc	a
      005FC6 F0               [24] 1849 	movx	@dptr,a
      005FC7 02 64 AA         [24] 1850 	ljmp	00291$
      005FCA                       1851 00152$:
                                   1852 ;	tmk_core/protocol/ch555/usb_ak820.c:267: } else { control_stall(); return; }
      005FCA 02 5A E8         [24] 1853 	ljmp	_control_stall
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:269: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005FCD                       1855 00157$:
                                   1856 ;	tmk_core/protocol/ch555/usb_ak820.c:270: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005FCD BF 81 2C         [24] 1857 	cjne	r7,#0x81,00167$
      005FD0 30 0F 29         [24] 1858 	jnb	_control_setup_valid_interface_10000_285,00167$
      005FD3 30 11 26         [24] 1859 	jnb	_control_setup_zero_value_10000_285,00167$
      005FD6 90 07 56         [24] 1860 	mov	dptr,#_D0SetupLen
      005FD9 E0               [24] 1861 	movx	a,@dptr
      005FDA F9               [12] 1862 	mov	r1,a
      005FDB A3               [24] 1863 	inc	dptr
      005FDC E0               [24] 1864 	movx	a,@dptr
      005FDD FA               [12] 1865 	mov	r2,a
      005FDE B9 01 1B         [24] 1866 	cjne	r1,#0x01,00167$
      005FE1 BA 00 18         [24] 1867 	cjne	r2,#0x00,00167$
      005FE4 90 07 5B         [24] 1868 	mov	dptr,#_D0UsbConfig
      005FE7 E0               [24] 1869 	movx	a,@dptr
      005FE8 60 12            [24] 1870 	jz	00167$
                                   1871 ;	tmk_core/protocol/ch555/usb_ak820.c:271: pD0_EP0_BUF[0] = 0;
      005FEA 90 10 00         [24] 1872 	mov	dptr,#0x1000
      005FED E4               [12] 1873 	clr	a
      005FEE F0               [24] 1874 	movx	@dptr,a
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:272: D0_EP0T_L = 1;
      005FEF 90 22 08         [24] 1876 	mov	dptr,#0x2208
      005FF2 04               [12] 1877 	inc	a
      005FF3 F0               [24] 1878 	movx	@dptr,a
                                   1879 ;	tmk_core/protocol/ch555/usb_ak820.c:273: control_phase = CTRL_STATUS_OUT;
      005FF4 90 07 B4         [24] 1880 	mov	dptr,#_control_phase
      005FF7 04               [12] 1881 	inc	a
      005FF8 F0               [24] 1882 	movx	@dptr,a
      005FF9 02 64 AA         [24] 1883 	ljmp	00291$
      005FFC                       1884 00167$:
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:274: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      005FFC 30 0F 1E         [24] 1886 	jnb	_control_setup_valid_interface_10000_285,00161$
      005FFF 90 07 5B         [24] 1887 	mov	dptr,#_D0UsbConfig
      006002 E0               [24] 1888 	movx	a,@dptr
      006003 60 18            [24] 1889 	jz	00161$
      006005 BF 21 15         [24] 1890 	cjne	r7,#0x21,00161$
      006008 30 12 12         [24] 1891 	jnb	_control_setup_zero_length_10000_285,00161$
                                   1892 ;	tmk_core/protocol/ch555/usb_ak820.c:275: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      00600B EB               [12] 1893 	mov	a,r3
      00600C 4C               [12] 1894 	orl	a,r4
      00600D 70 05            [24] 1895 	jnz	00159$
      00600F 90 06 36         [24] 1896 	mov	dptr,#_keyboard_idle
      006012 EE               [12] 1897 	mov	a,r6
      006013 F0               [24] 1898 	movx	@dptr,a
      006014                       1899 00159$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_IN;
      006014 90 07 B4         [24] 1901 	mov	dptr,#_control_phase
      006017 74 03            [12] 1902 	mov	a,#0x03
      006019 F0               [24] 1903 	movx	@dptr,a
      00601A 02 64 AA         [24] 1904 	ljmp	00291$
      00601D                       1905 00161$:
                                   1906 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else { control_stall(); return; }
      00601D 02 5A E8         [24] 1907 	ljmp	_control_stall
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:279: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006020                       1909 00173$:
                                   1910 ;	tmk_core/protocol/ch555/usb_ak820.c:280: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006020 BF 01 18         [24] 1911 	cjne	r7,#0x01,00182$
      006023 30 0F 15         [24] 1912 	jnb	_control_setup_valid_interface_10000_285,00182$
      006026 30 11 12         [24] 1913 	jnb	_control_setup_zero_value_10000_285,00182$
      006029 30 12 0F         [24] 1914 	jnb	_control_setup_zero_length_10000_285,00182$
      00602C 90 07 5B         [24] 1915 	mov	dptr,#_D0UsbConfig
      00602F E0               [24] 1916 	movx	a,@dptr
      006030 60 09            [24] 1917 	jz	00182$
                                   1918 ;	tmk_core/protocol/ch555/usb_ak820.c:281: control_phase = CTRL_STATUS_IN;
      006032 90 07 B4         [24] 1919 	mov	dptr,#_control_phase
      006035 74 03            [12] 1920 	mov	a,#0x03
      006037 F0               [24] 1921 	movx	@dptr,a
      006038 02 64 AA         [24] 1922 	ljmp	00291$
      00603B                       1923 00182$:
                                   1924 ;	tmk_core/protocol/ch555/usb_ak820.c:282: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00603B EB               [12] 1925 	mov	a,r3
      00603C 4C               [12] 1926 	orl	a,r4
      00603D 70 2C            [24] 1927 	jnz	00175$
      00603F 90 07 5B         [24] 1928 	mov	dptr,#_D0UsbConfig
      006042 E0               [24] 1929 	movx	a,@dptr
      006043 60 26            [24] 1930 	jz	00175$
      006045 BF 21 23         [24] 1931 	cjne	r7,#0x21,00175$
      006048 30 12 20         [24] 1932 	jnb	_control_setup_zero_length_10000_285,00175$
      00604B 8D 01            [24] 1933 	mov	ar1,r5
      00604D 8E 02            [24] 1934 	mov	ar2,r6
      00604F C3               [12] 1935 	clr	c
      006050 74 01            [12] 1936 	mov	a,#0x01
      006052 99               [12] 1937 	subb	a,r1
      006053 E4               [12] 1938 	clr	a
      006054 9A               [12] 1939 	subb	a,r2
      006055 40 14            [24] 1940 	jc	00175$
                                   1941 ;	free result
                                   1942 ;	tmk_core/protocol/ch555/usb_ak820.c:283: keyboard_protocol = value;
      006057 90 0D C4         [24] 1943 	mov	dptr,#_keyboard_protocol
      00605A ED               [12] 1944 	mov	a,r5
      00605B F0               [24] 1945 	movx	@dptr,a
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:284: keyboard_reset = 1;
      00605C 90 07 85         [24] 1947 	mov	dptr,#_keyboard_reset
      00605F 74 01            [12] 1948 	mov	a,#0x01
      006061 F0               [24] 1949 	movx	@dptr,a
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006062 90 07 B4         [24] 1951 	mov	dptr,#_control_phase
      006065 74 03            [12] 1952 	mov	a,#0x03
      006067 F0               [24] 1953 	movx	@dptr,a
      006068 02 64 AA         [24] 1954 	ljmp	00291$
      00606B                       1955 00175$:
                                   1956 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      00606B 02 5A E8         [24] 1957 	ljmp	_control_stall
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_GET_STATUS:
      00606E                       1959 00188$:
                                   1960 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (zero_value && D0SetupLen == 2 &&
      00606E 20 11 03         [24] 1961 	jb	_control_setup_zero_value_10000_285,01283$
      006071 02 5A E8         [24] 1962 	ljmp	_control_stall
      006074                       1963 01283$:
      006074 90 07 56         [24] 1964 	mov	dptr,#_D0SetupLen
      006077 E0               [24] 1965 	movx	a,@dptr
      006078 F9               [12] 1966 	mov	r1,a
      006079 A3               [24] 1967 	inc	dptr
      00607A E0               [24] 1968 	movx	a,@dptr
      00607B FA               [12] 1969 	mov	r2,a
      00607C B9 02 05         [24] 1970 	cjne	r1,#0x02,01284$
      00607F BA 00 02         [24] 1971 	cjne	r2,#0x00,01284$
      006082 80 03            [24] 1972 	sjmp	01285$
      006084                       1973 01284$:
      006084 02 5A E8         [24] 1974 	ljmp	_control_stall
      006087                       1975 01285$:
                                   1976 ;	tmk_core/protocol/ch555/usb_ak820.c:290: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006087 E4               [12] 1977 	clr	a
      006088 BF 80 01         [24] 1978 	cjne	r7,#0x80,01286$
      00608B 04               [12] 1979 	inc	a
      00608C                       1980 01286$:
      00608C FA               [12] 1981 	mov	r2,a
      00608D 60 03            [24] 1982 	jz	00196$
      00608F 20 10 35         [24] 1983 	jb	_control_setup_zero_index_10000_285,00189$
      006092                       1984 00196$:
      006092 BF 81 09         [24] 1985 	cjne	r7,#0x81,00202$
      006095 30 0F 06         [24] 1986 	jnb	_control_setup_valid_interface_10000_285,00202$
      006098 90 07 5B         [24] 1987 	mov	dptr,#_D0UsbConfig
      00609B E0               [24] 1988 	movx	a,@dptr
      00609C 70 29            [24] 1989 	jnz	00189$
      00609E                       1990 00202$:
                                   1991 ;	tmk_core/protocol/ch555/usb_ak820.c:291: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      00609E BF 82 70         [24] 1992 	cjne	r7,#0x82,00190$
      0060A1 90 07 5B         [24] 1993 	mov	dptr,#_D0UsbConfig
      0060A4 E0               [24] 1994 	movx	a,@dptr
      0060A5 60 6A            [24] 1995 	jz	00190$
      0060A7 EB               [12] 1996 	mov	a,r3
      0060A8 4C               [12] 1997 	orl	a,r4
      0060A9 60 1C            [24] 1998 	jz	00189$
      0060AB 8B 00            [24] 1999 	mov	ar0,r3
      0060AD 8C 01            [24] 2000 	mov	ar1,r4
      0060AF B8 80 05         [24] 2001 	cjne	r0,#0x80,01298$
      0060B2 B9 00 02         [24] 2002 	cjne	r1,#0x00,01298$
      0060B5 80 10            [24] 2003 	sjmp	00189$
      0060B7                       2004 01298$:
      0060B7 C3               [12] 2005 	clr	c
      0060B8 E8               [12] 2006 	mov	a,r0
      0060B9 94 81            [12] 2007 	subb	a,#0x81
      0060BB E9               [12] 2008 	mov	a,r1
      0060BC 94 00            [12] 2009 	subb	a,#0x00
      0060BE 40 51            [24] 2010 	jc	00190$
      0060C0 74 83            [12] 2011 	mov	a,#0x83
      0060C2 98               [12] 2012 	subb	a,r0
      0060C3 E4               [12] 2013 	clr	a
      0060C4 99               [12] 2014 	subb	a,r1
      0060C5 40 4A            [24] 2015 	jc	00190$
                                   2016 ;	free result
      0060C7                       2017 00189$:
                                   2018 ;	tmk_core/protocol/ch555/usb_ak820.c:292: endpoint = index & 7;
      0060C7 8B 01            [24] 2019 	mov	ar1,r3
      0060C9 53 01 07         [24] 2020 	anl	ar1,#0x07
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:293: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0060CC EA               [12] 2022 	mov	a,r2
      0060CD 60 0B            [24] 2023 	jz	00308$
      0060CF 90 07 5D         [24] 2024 	mov	dptr,#_USB_SleepStatus
      0060D2 E0               [24] 2025 	movx	a,@dptr
      0060D3 54 01            [12] 2026 	anl	a,#0x01
      0060D5 25 E0            [12] 2027 	add	a,acc
      0060D7 FA               [12] 2028 	mov	r2,a
      0060D8 80 22            [24] 2029 	sjmp	00309$
      0060DA                       2030 00308$:
                                   2031 ;	tmk_core/protocol/ch555/usb_ak820.c:294: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0060DA BF 82 1B         [24] 2032 	cjne	r7,#0x82,00310$
      0060DD E9               [12] 2033 	mov	a,r1
      0060DE 60 18            [24] 2034 	jz	00310$
      0060E0 89 00            [24] 2035 	mov	ar0,r1
      0060E2 79 00            [12] 2036 	mov	r1,#0x00
      0060E4 74 22            [12] 2037 	mov	a,#0x22
      0060E6 29               [12] 2038 	add	a, r1
      0060E7 F9               [12] 2039 	mov	r1,a
      0060E8 88 82            [24] 2040 	mov	dpl,r0
      0060EA 89 83            [24] 2041 	mov	dph,r1
      0060EC E0               [24] 2042 	movx	a,@dptr
      0060ED F9               [12] 2043 	mov	r1,a
      0060EE 53 01 03         [24] 2044 	anl	ar1,#0x03
      0060F1 B9 03 04         [24] 2045 	cjne	r1,#0x03,00310$
      0060F4 79 01            [12] 2046 	mov	r1,#0x01
      0060F6 80 02            [24] 2047 	sjmp	00311$
      0060F8                       2048 00310$:
      0060F8 79 00            [12] 2049 	mov	r1,#0x00
      0060FA                       2050 00311$:
      0060FA 89 02            [24] 2051 	mov	ar2,r1
      0060FC                       2052 00309$:
      0060FC 90 10 00         [24] 2053 	mov	dptr,#0x1000
      0060FF EA               [12] 2054 	mov	a,r2
      006100 F0               [24] 2055 	movx	@dptr,a
                                   2056 ;	tmk_core/protocol/ch555/usb_ak820.c:295: pD0_EP0_BUF[1] = 0;
      006101 A3               [24] 2057 	inc	dptr
      006102 E4               [12] 2058 	clr	a
      006103 F0               [24] 2059 	movx	@dptr,a
                                   2060 ;	tmk_core/protocol/ch555/usb_ak820.c:296: D0_EP0T_L = 2;
      006104 90 22 08         [24] 2061 	mov	dptr,#0x2208
      006107 74 02            [12] 2062 	mov	a,#0x02
      006109 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:297: control_phase = CTRL_STATUS_OUT;
      00610A 90 07 B4         [24] 2065 	mov	dptr,#_control_phase
      00610D F0               [24] 2066 	movx	@dptr,a
      00610E 02 64 AA         [24] 2067 	ljmp	00291$
      006111                       2068 00190$:
                                   2069 ;	tmk_core/protocol/ch555/usb_ak820.c:298: } else { control_stall(); return; }
      006111 02 5A E8         [24] 2070 	ljmp	_control_stall
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:301: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006114                       2072 00205$:
                                   2073 ;	tmk_core/protocol/ch555/usb_ak820.c:302: if (zero_length && D0UsbConfig) {
      006114 20 12 03         [24] 2074 	jb	_control_setup_zero_length_10000_285,01307$
      006117 02 61 A7         [24] 2075 	ljmp	00279$
      00611A                       2076 01307$:
      00611A 90 07 5B         [24] 2077 	mov	dptr,#_D0UsbConfig
      00611D E0               [24] 2078 	movx	a,@dptr
      00611E 70 03            [24] 2079 	jnz	01308$
      006120 02 61 A7         [24] 2080 	ljmp	00279$
      006123                       2081 01308$:
                                   2082 ;	tmk_core/protocol/ch555/usb_ak820.c:303: if (type == 0x00 && value == 1 && zero_index) {
      006123 EF               [12] 2083 	mov	a,r7
      006124 70 29            [24] 2084 	jnz	00218$
      006126 8D 01            [24] 2085 	mov	ar1,r5
      006128 8E 02            [24] 2086 	mov	ar2,r6
      00612A B9 01 22         [24] 2087 	cjne	r1,#0x01,00218$
      00612D BA 00 1F         [24] 2088 	cjne	r2,#0x00,00218$
      006130 30 10 1C         [24] 2089 	jnb	_control_setup_zero_index_10000_285,00218$
                                   2090 ;	tmk_core/protocol/ch555/usb_ak820.c:304: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006133 90 07 55         [24] 2091 	mov	dptr,#_D0SetupReqCode
      006136 E0               [24] 2092 	movx	a,@dptr
      006137 FA               [12] 2093 	mov	r2,a
      006138 BA 03 0A         [24] 2094 	cjne	r2,#0x03,00207$
      00613B 90 07 5D         [24] 2095 	mov	dptr,#_USB_SleepStatus
      00613E E0               [24] 2096 	movx	a,@dptr
      00613F 43 E0 01         [24] 2097 	orl	acc,#0x01
      006142 F0               [24] 2098 	movx	@dptr,a
      006143 80 59            [24] 2099 	sjmp	00219$
      006145                       2100 00207$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:305: else USB_SleepStatus &= ~1;
      006145 90 07 5D         [24] 2102 	mov	dptr,#_USB_SleepStatus
      006148 E0               [24] 2103 	movx	a,@dptr
      006149 53 E0 FE         [24] 2104 	anl	acc,#0xfe
      00614C F0               [24] 2105 	movx	@dptr,a
      00614D 80 4F            [24] 2106 	sjmp	00219$
      00614F                       2107 00218$:
                                   2108 ;	tmk_core/protocol/ch555/usb_ak820.c:306: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00614F BF 02 49         [24] 2109 	cjne	r7,#0x02,00212$
      006152 30 11 46         [24] 2110 	jnb	_control_setup_zero_value_10000_285,00212$
      006155 8B 01            [24] 2111 	mov	ar1,r3
      006157 8C 02            [24] 2112 	mov	ar2,r4
      006159 C3               [12] 2113 	clr	c
      00615A E9               [12] 2114 	mov	a,r1
      00615B 94 81            [12] 2115 	subb	a,#0x81
      00615D EA               [12] 2116 	mov	a,r2
      00615E 94 00            [12] 2117 	subb	a,#0x00
      006160 40 39            [24] 2118 	jc	00212$
      006162 74 83            [12] 2119 	mov	a,#0x83
      006164 99               [12] 2120 	subb	a,r1
      006165 E4               [12] 2121 	clr	a
      006166 9A               [12] 2122 	subb	a,r2
      006167 40 32            [24] 2123 	jc	00212$
                                   2124 ;	free result
                                   2125 ;	tmk_core/protocol/ch555/usb_ak820.c:307: endpoint = index & 7;
      006169 8B 02            [24] 2126 	mov	ar2,r3
      00616B 53 02 07         [24] 2127 	anl	ar2,#0x07
                                   2128 ;	tmk_core/protocol/ch555/usb_ak820.c:309: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00616E 8A 00            [24] 2129 	mov	ar0,r2
      006170 79 00            [12] 2130 	mov	r1,#0x00
      006172 74 22            [12] 2131 	mov	a,#0x22
      006174 29               [12] 2132 	add	a, r1
      006175 F9               [12] 2133 	mov	r1,a
      006176 88 27            [24] 2134 	mov	_control_setup_sloc3_1_0,r0
      006178 89 28            [24] 2135 	mov	(_control_setup_sloc3_1_0 + 1),r1
      00617A 90 07 55         [24] 2136 	mov	dptr,#_D0SetupReqCode
      00617D E0               [24] 2137 	movx	a,@dptr
      00617E F9               [12] 2138 	mov	r1,a
      00617F B9 03 04         [24] 2139 	cjne	r1,#0x03,00318$
      006182 79 03            [12] 2140 	mov	r1,#0x03
      006184 80 02            [24] 2141 	sjmp	00319$
      006186                       2142 00318$:
      006186 79 02            [12] 2143 	mov	r1,#0x02
      006188                       2144 00319$:
      006188 43 01 10         [24] 2145 	orl	ar1,#0x10
      00618B 85 27 82         [24] 2146 	mov	dpl,_control_setup_sloc3_1_0
      00618E 85 28 83         [24] 2147 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006191 E9               [12] 2148 	mov	a,r1
      006192 F0               [24] 2149 	movx	@dptr,a
                                   2150 ;	tmk_core/protocol/ch555/usb_ak820.c:310: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006193 BA 03 08         [24] 2151 	cjne	r2,#0x03,00219$
      006196 12 5A 74         [24] 2152 	lcall	_raw_complete
      006199 80 03            [24] 2153 	sjmp	00219$
      00619B                       2154 00212$:
                                   2155 ;	tmk_core/protocol/ch555/usb_ak820.c:311: } else { control_stall(); return; }
      00619B 02 5A E8         [24] 2156 	ljmp	_control_stall
      00619E                       2157 00219$:
                                   2158 ;	tmk_core/protocol/ch555/usb_ak820.c:312: control_phase = CTRL_STATUS_IN;
      00619E 90 07 B4         [24] 2159 	mov	dptr,#_control_phase
      0061A1 74 03            [12] 2160 	mov	a,#0x03
      0061A3 F0               [24] 2161 	movx	@dptr,a
      0061A4 02 64 AA         [24] 2162 	ljmp	00291$
      0061A7                       2163 00279$:
                                   2164 ;	tmk_core/protocol/ch555/usb_ak820.c:313: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0061A7 E4               [12] 2165 	clr	a
      0061A8 BF A1 01         [24] 2166 	cjne	r7,#0xa1,01324$
      0061AB 04               [12] 2167 	inc	a
      0061AC                       2168 01324$:
      0061AC FA               [12] 2169 	mov	r2,a
      0061AD 70 03            [24] 2170 	jnz	01326$
      0061AF 02 64 25         [24] 2171 	ljmp	00273$
      0061B2                       2172 01326$:
      0061B2 90 07 55         [24] 2173 	mov	dptr,#_D0SetupReqCode
      0061B5 E0               [24] 2174 	movx	a,@dptr
      0061B6 F9               [12] 2175 	mov	r1,a
      0061B7 B9 01 02         [24] 2176 	cjne	r1,#0x01,01327$
      0061BA 80 03            [24] 2177 	sjmp	01328$
      0061BC                       2178 01327$:
      0061BC 02 64 25         [24] 2179 	ljmp	00273$
      0061BF                       2180 01328$:
      0061BF 90 07 5B         [24] 2181 	mov	dptr,#_D0UsbConfig
      0061C2 E0               [24] 2182 	movx	a,@dptr
      0061C3 70 03            [24] 2183 	jnz	01329$
      0061C5 02 64 25         [24] 2184 	ljmp	00273$
      0061C8                       2185 01329$:
      0061C8 90 07 56         [24] 2186 	mov	dptr,#_D0SetupLen
      0061CB E0               [24] 2187 	movx	a,@dptr
      0061CC F8               [12] 2188 	mov	r0,a
      0061CD A3               [24] 2189 	inc	dptr
      0061CE E0               [24] 2190 	movx	a,@dptr
      0061CF 48               [12] 2191 	orl	a,r0
      0061D0 70 03            [24] 2192 	jnz	01330$
      0061D2 02 64 25         [24] 2193 	ljmp	00273$
      0061D5                       2194 01330$:
                                   2195 ;	tmk_core/protocol/ch555/usb_ak820.c:314: report_id = value;
      0061D5 C0 03            [24] 2196 	push	ar3
      0061D7 C0 04            [24] 2197 	push	ar4
      0061D9 8D 01            [24] 2198 	mov	ar1,r5
                                   2199 ;	tmk_core/protocol/ch555/usb_ak820.c:315: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0061DB 8E 00            [24] 2200 	mov	ar0,r6
      0061DD B8 01 03         [24] 2201 	cjne	r0,#0x01,01331$
      0061E0 E8               [12] 2202 	mov	a,r0
      0061E1 80 01            [24] 2203 	sjmp	01332$
      0061E3                       2204 01331$:
      0061E3 E4               [12] 2205 	clr	a
      0061E4                       2206 01332$:
      0061E4 F5 27            [12] 2207 	mov	_control_setup_sloc3_1_0,a
      0061E6 D0 04            [24] 2208 	pop	ar4
      0061E8 D0 03            [24] 2209 	pop	ar3
      0061EA E5 27            [12] 2210 	mov	a,_control_setup_sloc3_1_0
      0061EC 60 17            [24] 2211 	jz	00251$
      0061EE EB               [12] 2212 	mov	a,r3
      0061EF 4C               [12] 2213 	orl	a,r4
      0061F0 70 13            [24] 2214 	jnz	00251$
      0061F2 E9               [12] 2215 	mov	a,r1
      0061F3 70 10            [24] 2216 	jnz	00251$
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:316: length = KEYBOARD_EPSIZE;
      0061F5 90 07 BE         [24] 2218 	mov	dptr,#_control_setup_length_10000_285
      0061F8 74 08            [12] 2219 	mov	a,#0x08
      0061FA F0               [24] 2220 	movx	@dptr,a
      0061FB E4               [12] 2221 	clr	a
      0061FC A3               [24] 2222 	inc	dptr
      0061FD F0               [24] 2223 	movx	@dptr,a
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:317: offset = SNAPSHOT_KEYBOARD;
      0061FE 90 07 C0         [24] 2225 	mov	dptr,#_control_setup_offset_10000_285
      006201 F0               [24] 2226 	movx	@dptr,a
      006202 02 63 89         [24] 2227 	ljmp	00252$
      006205                       2228 00251$:
                                   2229 ;	tmk_core/protocol/ch555/usb_ak820.c:318: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006205 E5 27            [12] 2230 	mov	a,_control_setup_sloc3_1_0
      006207 60 27            [24] 2231 	jz	00245$
      006209 BB 02 24         [24] 2232 	cjne	r3,#0x02,00245$
      00620C BC 00 21         [24] 2233 	cjne	r4,#0x00,00245$
                                   2234 ;	tmk_core/protocol/ch555/usb_ak820.c:319: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00620F B9 07 00         [24] 2235 	cjne	r1,#0x07,01339$
      006212                       2236 01339$:
      006212 50 1C            [24] 2237 	jnc	00245$
      006214 E9               [12] 2238 	mov	a,r1
      006215 90 BE B5         [24] 2239 	mov	dptr,#_shared_lengths
      006218 93               [24] 2240 	movc	a,@a+dptr
      006219 F8               [12] 2241 	mov	r0,a
      00621A 60 14            [24] 2242 	jz	00245$
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:320: length = shared_lengths[report_id];
      00621C 90 07 BE         [24] 2244 	mov	dptr,#_control_setup_length_10000_285
      00621F E8               [12] 2245 	mov	a,r0
      006220 F0               [24] 2246 	movx	@dptr,a
      006221 E4               [12] 2247 	clr	a
      006222 A3               [24] 2248 	inc	dptr
      006223 F0               [24] 2249 	movx	@dptr,a
                                   2250 ;	tmk_core/protocol/ch555/usb_ak820.c:321: offset = shared_offsets[report_id];
      006224 E9               [12] 2251 	mov	a,r1
      006225 90 BE AE         [24] 2252 	mov	dptr,#_shared_offsets
      006228 93               [24] 2253 	movc	a,@a+dptr
      006229 90 07 C0         [24] 2254 	mov	dptr,#_control_setup_offset_10000_285
      00622C F0               [24] 2255 	movx	@dptr,a
      00622D 02 63 89         [24] 2256 	ljmp	00252$
      006230                       2257 00245$:
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006230 E5 27            [12] 2259 	mov	a,_control_setup_sloc3_1_0
      006232 60 7A            [24] 2260 	jz	00240$
      006234 BB 01 77         [24] 2261 	cjne	r3,#0x01,00240$
      006237 BC 00 74         [24] 2262 	cjne	r4,#0x00,00240$
      00623A E9               [12] 2263 	mov	a,r1
      00623B 70 71            [24] 2264 	jnz	00240$
                                   2265 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00623D 90 07 56         [24] 2266 	mov	dptr,#_D0SetupLen
      006240 E0               [24] 2267 	movx	a,@dptr
      006241 F8               [12] 2268 	mov	r0,a
      006242 A3               [24] 2269 	inc	dptr
      006243 E0               [24] 2270 	movx	a,@dptr
      006244 F9               [12] 2271 	mov	r1,a
      006245 C3               [12] 2272 	clr	c
      006246 E8               [12] 2273 	mov	a,r0
      006247 94 20            [12] 2274 	subb	a,#0x20
      006249 E9               [12] 2275 	mov	a,r1
      00624A 94 00            [12] 2276 	subb	a,#0x00
      00624C 50 0A            [24] 2277 	jnc	00320$
      00624E 90 07 56         [24] 2278 	mov	dptr,#_D0SetupLen
      006251 E0               [24] 2279 	movx	a,@dptr
      006252 F8               [12] 2280 	mov	r0,a
      006253 A3               [24] 2281 	inc	dptr
      006254 E0               [24] 2282 	movx	a,@dptr
      006255 F9               [12] 2283 	mov	r1,a
      006256 80 04            [24] 2284 	sjmp	00321$
      006258                       2285 00320$:
      006258 78 20            [12] 2286 	mov	r0,#0x20
      00625A 79 00            [12] 2287 	mov	r1,#0x00
      00625C                       2288 00321$:
                                   2289 ;	tmk_core/protocol/ch555/usb_ak820.c:324: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00625C 75 27 00         [24] 2290 	mov	_control_setup_sloc3_1_0,#0x00
      00625F                       2291 00293$:
      00625F C0 03            [24] 2292 	push	ar3
      006261 C0 04            [24] 2293 	push	ar4
      006263 AB 27            [24] 2294 	mov	r3,_control_setup_sloc3_1_0
      006265 7C 00            [12] 2295 	mov	r4,#0x00
      006267 C3               [12] 2296 	clr	c
      006268 EB               [12] 2297 	mov	a,r3
      006269 98               [12] 2298 	subb	a,r0
      00626A EC               [12] 2299 	mov	a,r4
      00626B 99               [12] 2300 	subb	a,r1
      00626C D0 04            [24] 2301 	pop	ar4
      00626E D0 03            [24] 2302 	pop	ar3
      006270 50 32            [24] 2303 	jnc	00222$
      006272 C0 00            [24] 2304 	push	ar0
      006274 C0 01            [24] 2305 	push	ar1
      006276 85 27 29         [24] 2306 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006279 74 10            [12] 2307 	mov	a,#0x10
      00627B 24 00            [12] 2308 	add	a, #0x00
      00627D F5 2A            [12] 2309 	mov	(_control_setup_sloc4_1_0 + 1),a
      00627F A8 27            [24] 2310 	mov	r0,_control_setup_sloc3_1_0
      006281 79 00            [12] 2311 	mov	r1,#0x00
      006283 74 C0            [12] 2312 	mov	a,#0xc0
      006285 28               [12] 2313 	add	a, r0
      006286 F8               [12] 2314 	mov	r0,a
      006287 E4               [12] 2315 	clr	a
      006288 39               [12] 2316 	addc	a, r1
      006289 F9               [12] 2317 	mov	r1,a
      00628A 88 82            [24] 2318 	mov	dpl,r0
      00628C 74 10            [12] 2319 	mov	a,#0x10
      00628E 29               [12] 2320 	add	a, r1
      00628F F5 83            [12] 2321 	mov	dph,a
      006291 E0               [24] 2322 	movx	a,@dptr
      006292 85 29 82         [24] 2323 	mov	dpl,_control_setup_sloc4_1_0
      006295 85 2A 83         [24] 2324 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006298 F0               [24] 2325 	movx	@dptr,a
      006299 E5 27            [12] 2326 	mov	a,_control_setup_sloc3_1_0
      00629B 04               [12] 2327 	inc	a
      00629C F5 27            [12] 2328 	mov	_control_setup_sloc3_1_0,a
      00629E D0 01            [24] 2329 	pop	ar1
      0062A0 D0 00            [24] 2330 	pop	ar0
      0062A2 80 BB            [24] 2331 	sjmp	00293$
      0062A4                       2332 00222$:
                                   2333 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = 0; /* data already copied */
      0062A4 90 07 BE         [24] 2334 	mov	dptr,#_control_setup_length_10000_285
      0062A7 E4               [12] 2335 	clr	a
      0062A8 F0               [24] 2336 	movx	@dptr,a
      0062A9 A3               [24] 2337 	inc	dptr
      0062AA F0               [24] 2338 	movx	@dptr,a
      0062AB 02 63 89         [24] 2339 	ljmp	00252$
      0062AE                       2340 00240$:
                                   2341 ;	tmk_core/protocol/ch555/usb_ak820.c:326: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0062AE 8D 00            [24] 2342 	mov	ar0,r5
      0062B0 8E 01            [24] 2343 	mov	ar1,r6
      0062B2 B8 00 21         [24] 2344 	cjne	r0,#0x00,00236$
      0062B5 B9 02 1E         [24] 2345 	cjne	r1,#0x02,00236$
      0062B8 EB               [12] 2346 	mov	a,r3
      0062B9 4C               [12] 2347 	orl	a,r4
      0062BA 70 1A            [24] 2348 	jnz	00236$
                                   2349 ;	tmk_core/protocol/ch555/usb_ak820.c:327: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0062BC 90 07 60         [24] 2350 	mov	dptr,#_KB_USB_SetReport
      0062BF E0               [24] 2351 	movx	a,@dptr
      0062C0 90 10 00         [24] 2352 	mov	dptr,#0x1000
      0062C3 F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0;
      0062C4 90 07 BE         [24] 2355 	mov	dptr,#_control_setup_length_10000_285
      0062C7 E4               [12] 2356 	clr	a
      0062C8 F0               [24] 2357 	movx	@dptr,a
      0062C9 A3               [24] 2358 	inc	dptr
      0062CA F0               [24] 2359 	movx	@dptr,a
                                   2360 ;	tmk_core/protocol/ch555/usb_ak820.c:329: D0SetupLen = 1;
      0062CB 90 07 56         [24] 2361 	mov	dptr,#_D0SetupLen
      0062CE 04               [12] 2362 	inc	a
      0062CF F0               [24] 2363 	movx	@dptr,a
      0062D0 E4               [12] 2364 	clr	a
      0062D1 A3               [24] 2365 	inc	dptr
      0062D2 F0               [24] 2366 	movx	@dptr,a
      0062D3 02 63 89         [24] 2367 	ljmp	00252$
      0062D6                       2368 00236$:
                                   2369 ;	tmk_core/protocol/ch555/usb_ak820.c:330: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0062D6 B8 06 41         [24] 2370 	cjne	r0,#0x06,00232$
      0062D9 B9 02 3E         [24] 2371 	cjne	r1,#0x02,00232$
      0062DC BB 02 3B         [24] 2372 	cjne	r3,#0x02,00232$
      0062DF BC 00 38         [24] 2373 	cjne	r4,#0x00,00232$
                                   2374 ;	tmk_core/protocol/ch555/usb_ak820.c:331: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0062E2 C0 03            [24] 2375 	push	ar3
      0062E4 C0 04            [24] 2376 	push	ar4
      0062E6 90 10 00         [24] 2377 	mov	dptr,#0x1000
      0062E9 74 06            [12] 2378 	mov	a,#0x06
      0062EB F0               [24] 2379 	movx	@dptr,a
                                   2380 ;	tmk_core/protocol/ch555/usb_ak820.c:332: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0062EC 90 07 60         [24] 2381 	mov	dptr,#_KB_USB_SetReport
      0062EF E0               [24] 2382 	movx	a,@dptr
      0062F0 90 10 01         [24] 2383 	mov	dptr,#0x1001
      0062F3 F0               [24] 2384 	movx	@dptr,a
                                   2385 ;	tmk_core/protocol/ch555/usb_ak820.c:333: length = 0;
      0062F4 90 07 BE         [24] 2386 	mov	dptr,#_control_setup_length_10000_285
      0062F7 E4               [12] 2387 	clr	a
      0062F8 F0               [24] 2388 	movx	@dptr,a
      0062F9 A3               [24] 2389 	inc	dptr
      0062FA F0               [24] 2390 	movx	@dptr,a
                                   2391 ;	tmk_core/protocol/ch555/usb_ak820.c:334: if (D0SetupLen > 2) D0SetupLen = 2;
      0062FB 90 07 56         [24] 2392 	mov	dptr,#_D0SetupLen
      0062FE E0               [24] 2393 	movx	a,@dptr
      0062FF FB               [12] 2394 	mov	r3,a
      006300 A3               [24] 2395 	inc	dptr
      006301 E0               [24] 2396 	movx	a,@dptr
      006302 FC               [12] 2397 	mov	r4,a
      006303 C3               [12] 2398 	clr	c
      006304 74 02            [12] 2399 	mov	a,#0x02
      006306 9B               [12] 2400 	subb	a,r3
      006307 E4               [12] 2401 	clr	a
      006308 9C               [12] 2402 	subb	a,r4
      006309 D0 04            [24] 2403 	pop	ar4
      00630B D0 03            [24] 2404 	pop	ar3
      00630D 50 7A            [24] 2405 	jnc	00252$
                                   2406 ;	free result
      00630F 90 07 56         [24] 2407 	mov	dptr,#_D0SetupLen
      006312 74 02            [12] 2408 	mov	a,#0x02
      006314 F0               [24] 2409 	movx	@dptr,a
      006315 E4               [12] 2410 	clr	a
      006316 A3               [24] 2411 	inc	dptr
      006317 F0               [24] 2412 	movx	@dptr,a
      006318 80 6F            [24] 2413 	sjmp	00252$
      00631A                       2414 00232$:
                                   2415 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00631A B8 00 69         [24] 2416 	cjne	r0,#0x00,00228$
      00631D B9 03 66         [24] 2417 	cjne	r1,#0x03,00228$
      006320 BB 01 63         [24] 2418 	cjne	r3,#0x01,00228$
      006323 BC 00 60         [24] 2419 	cjne	r4,#0x00,00228$
                                   2420 ;	tmk_core/protocol/ch555/usb_ak820.c:338: pD0_EP0_BUF[0] = 'A';
      006326 90 10 00         [24] 2421 	mov	dptr,#0x1000
      006329 74 41            [12] 2422 	mov	a,#0x41
      00632B F0               [24] 2423 	movx	@dptr,a
                                   2424 ;	tmk_core/protocol/ch555/usb_ak820.c:339: pD0_EP0_BUF[1] = 'K';
      00632C A3               [24] 2425 	inc	dptr
      00632D 74 4B            [12] 2426 	mov	a,#0x4b
      00632F F0               [24] 2427 	movx	@dptr,a
                                   2428 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[2] = 'B';
      006330 A3               [24] 2429 	inc	dptr
      006331 74 42            [12] 2430 	mov	a,#0x42
      006333 F0               [24] 2431 	movx	@dptr,a
                                   2432 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[3] = 'T';
      006334 A3               [24] 2433 	inc	dptr
      006335 74 54            [12] 2434 	mov	a,#0x54
      006337 F0               [24] 2435 	movx	@dptr,a
                                   2436 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[4] = 1;
      006338 A3               [24] 2437 	inc	dptr
      006339 74 01            [12] 2438 	mov	a,#0x01
      00633B F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[5] = ak820_boot_stage;
      00633C 90 07 61         [24] 2441 	mov	dptr,#_ak820_boot_stage
      00633F E0               [24] 2442 	movx	a,@dptr
      006340 90 10 05         [24] 2443 	mov	dptr,#0x1005
      006343 F0               [24] 2444 	movx	@dptr,a
                                   2445 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006344 90 07 62         [24] 2446 	mov	dptr,#_ak820_main_heartbeat
      006347 E0               [24] 2447 	movx	a,@dptr
      006348 90 10 06         [24] 2448 	mov	dptr,#0x1006
      00634B F0               [24] 2449 	movx	@dptr,a
                                   2450 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00634C 90 07 5C         [24] 2451 	mov	dptr,#_USB_EnumStatus
      00634F E0               [24] 2452 	movx	a,@dptr
      006350 60 02            [24] 2453 	jz	00322$
      006352 74 01            [12] 2454 	mov	a,#0x01
      006354                       2455 00322$:
      006354 F9               [12] 2456 	mov	r1,a
      006355 90 07 5D         [24] 2457 	mov	dptr,#_USB_SleepStatus
      006358 E0               [24] 2458 	movx	a,@dptr
      006359 54 02            [12] 2459 	anl	a,#0x02
      00635B F8               [12] 2460 	mov	r0,a
      00635C E9               [12] 2461 	mov	a,r1
      00635D 42 00            [12] 2462 	orl	ar0,a
      00635F 90 10 07         [24] 2463 	mov	dptr,#0x1007
      006362 E8               [12] 2464 	mov	a,r0
      006363 F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	tmk_core/protocol/ch555/usb_ak820.c:346: length = 0;
      006364 90 07 BE         [24] 2467 	mov	dptr,#_control_setup_length_10000_285
      006367 E4               [12] 2468 	clr	a
      006368 F0               [24] 2469 	movx	@dptr,a
      006369 A3               [24] 2470 	inc	dptr
      00636A F0               [24] 2471 	movx	@dptr,a
                                   2472 ;	tmk_core/protocol/ch555/usb_ak820.c:347: if (D0SetupLen > 8) D0SetupLen = 8;
      00636B 90 07 56         [24] 2473 	mov	dptr,#_D0SetupLen
      00636E E0               [24] 2474 	movx	a,@dptr
      00636F F8               [12] 2475 	mov	r0,a
      006370 A3               [24] 2476 	inc	dptr
      006371 E0               [24] 2477 	movx	a,@dptr
      006372 F9               [12] 2478 	mov	r1,a
      006373 C3               [12] 2479 	clr	c
      006374 74 08            [12] 2480 	mov	a,#0x08
      006376 98               [12] 2481 	subb	a,r0
      006377 E4               [12] 2482 	clr	a
      006378 99               [12] 2483 	subb	a,r1
      006379 50 0E            [24] 2484 	jnc	00252$
                                   2485 ;	free result
      00637B 90 07 56         [24] 2486 	mov	dptr,#_D0SetupLen
      00637E 74 08            [12] 2487 	mov	a,#0x08
      006380 F0               [24] 2488 	movx	@dptr,a
      006381 E4               [12] 2489 	clr	a
      006382 A3               [24] 2490 	inc	dptr
      006383 F0               [24] 2491 	movx	@dptr,a
      006384 80 03            [24] 2492 	sjmp	00252$
      006386                       2493 00228$:
                                   2494 ;	tmk_core/protocol/ch555/usb_ak820.c:348: } else { control_stall(); return; }
      006386 02 5A E8         [24] 2495 	ljmp	_control_stall
      006389                       2496 00252$:
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:349: if (length) {
      006389 90 07 BE         [24] 2498 	mov	dptr,#_control_setup_length_10000_285
      00638C E0               [24] 2499 	movx	a,@dptr
      00638D F5 29            [12] 2500 	mov	_control_setup_sloc4_1_0,a
      00638F A3               [24] 2501 	inc	dptr
      006390 E0               [24] 2502 	movx	a,@dptr
      006391 F5 2A            [12] 2503 	mov	(_control_setup_sloc4_1_0 + 1),a
      006393 E5 29            [12] 2504 	mov	a,_control_setup_sloc4_1_0
      006395 45 2A            [12] 2505 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006397 60 5C            [24] 2506 	jz	00262$
                                   2507 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > length) D0SetupLen = length;
      006399 90 07 56         [24] 2508 	mov	dptr,#_D0SetupLen
      00639C E0               [24] 2509 	movx	a,@dptr
      00639D F8               [12] 2510 	mov	r0,a
      00639E A3               [24] 2511 	inc	dptr
      00639F E0               [24] 2512 	movx	a,@dptr
      0063A0 F9               [12] 2513 	mov	r1,a
      0063A1 C3               [12] 2514 	clr	c
      0063A2 E5 29            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      0063A4 98               [12] 2516 	subb	a,r0
      0063A5 E5 2A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0063A7 99               [12] 2518 	subb	a,r1
      0063A8 50 0A            [24] 2519 	jnc	00559$
                                   2520 ;	free result
      0063AA 90 07 56         [24] 2521 	mov	dptr,#_D0SetupLen
      0063AD E5 29            [12] 2522 	mov	a,_control_setup_sloc4_1_0
      0063AF F0               [24] 2523 	movx	@dptr,a
      0063B0 E5 2A            [12] 2524 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0063B2 A3               [24] 2525 	inc	dptr
      0063B3 F0               [24] 2526 	movx	@dptr,a
                                   2527 ;	tmk_core/protocol/ch555/usb_ak820.c:351: for (i = 0; i < D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0063B4                       2528 00559$:
      0063B4 75 29 00         [24] 2529 	mov	_control_setup_sloc4_1_0,#0x00
      0063B7                       2530 00296$:
      0063B7 90 07 56         [24] 2531 	mov	dptr,#_D0SetupLen
      0063BA E0               [24] 2532 	movx	a,@dptr
      0063BB F5 27            [12] 2533 	mov	_control_setup_sloc3_1_0,a
      0063BD A3               [24] 2534 	inc	dptr
      0063BE E0               [24] 2535 	movx	a,@dptr
      0063BF F5 28            [12] 2536 	mov	(_control_setup_sloc3_1_0 + 1),a
      0063C1 A8 29            [24] 2537 	mov	r0,_control_setup_sloc4_1_0
      0063C3 79 00            [12] 2538 	mov	r1,#0x00
      0063C5 C3               [12] 2539 	clr	c
      0063C6 E8               [12] 2540 	mov	a,r0
      0063C7 95 27            [12] 2541 	subb	a,_control_setup_sloc3_1_0
      0063C9 E9               [12] 2542 	mov	a,r1
      0063CA 95 28            [12] 2543 	subb	a,(_control_setup_sloc3_1_0 + 1)
      0063CC 50 46            [24] 2544 	jnc	00263$
      0063CE 85 29 27         [24] 2545 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0063D1 74 10            [12] 2546 	mov	a,#0x10
      0063D3 24 00            [12] 2547 	add	a, #0x00
      0063D5 F5 28            [12] 2548 	mov	(_control_setup_sloc3_1_0 + 1),a
      0063D7 90 07 C0         [24] 2549 	mov	dptr,#_control_setup_offset_10000_285
      0063DA E0               [24] 2550 	movx	a,@dptr
      0063DB 25 29            [12] 2551 	add	a, _control_setup_sloc4_1_0
      0063DD 24 86            [12] 2552 	add	a, #_input_snapshot
      0063DF F5 82            [12] 2553 	mov	dpl,a
      0063E1 E4               [12] 2554 	clr	a
      0063E2 34 07            [12] 2555 	addc	a,#(_input_snapshot >> 8)
      0063E4 F5 83            [12] 2556 	mov	dph,a
      0063E6 E0               [24] 2557 	movx	a,@dptr
      0063E7 85 27 82         [24] 2558 	mov	dpl,_control_setup_sloc3_1_0
      0063EA 85 28 83         [24] 2559 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0063ED F0               [24] 2560 	movx	@dptr,a
      0063EE E5 29            [12] 2561 	mov	a,_control_setup_sloc4_1_0
      0063F0 04               [12] 2562 	inc	a
      0063F1 F5 29            [12] 2563 	mov	_control_setup_sloc4_1_0,a
      0063F3 80 C2            [24] 2564 	sjmp	00296$
      0063F5                       2565 00262$:
                                   2566 ;	tmk_core/protocol/ch555/usb_ak820.c:352: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0063F5 BB 01 1C         [24] 2567 	cjne	r3,#0x01,00263$
      0063F8 BC 00 19         [24] 2568 	cjne	r4,#0x00,00263$
      0063FB 90 07 56         [24] 2569 	mov	dptr,#_D0SetupLen
      0063FE E0               [24] 2570 	movx	a,@dptr
      0063FF F8               [12] 2571 	mov	r0,a
      006400 A3               [24] 2572 	inc	dptr
      006401 E0               [24] 2573 	movx	a,@dptr
      006402 F9               [12] 2574 	mov	r1,a
      006403 C3               [12] 2575 	clr	c
      006404 74 20            [12] 2576 	mov	a,#0x20
      006406 98               [12] 2577 	subb	a,r0
      006407 E4               [12] 2578 	clr	a
      006408 99               [12] 2579 	subb	a,r1
      006409 50 09            [24] 2580 	jnc	00263$
                                   2581 ;	free result
      00640B 90 07 56         [24] 2582 	mov	dptr,#_D0SetupLen
      00640E 74 20            [12] 2583 	mov	a,#0x20
      006410 F0               [24] 2584 	movx	@dptr,a
      006411 E4               [12] 2585 	clr	a
      006412 A3               [24] 2586 	inc	dptr
      006413 F0               [24] 2587 	movx	@dptr,a
      006414                       2588 00263$:
                                   2589 ;	tmk_core/protocol/ch555/usb_ak820.c:353: D0_EP0T_L = D0SetupLen;
      006414 90 07 56         [24] 2590 	mov	dptr,#_D0SetupLen
      006417 E0               [24] 2591 	movx	a,@dptr
      006418 90 22 08         [24] 2592 	mov	dptr,#0x2208
      00641B F0               [24] 2593 	movx	@dptr,a
                                   2594 ;	tmk_core/protocol/ch555/usb_ak820.c:354: control_phase = CTRL_STATUS_OUT;
      00641C 90 07 B4         [24] 2595 	mov	dptr,#_control_phase
      00641F 74 02            [12] 2596 	mov	a,#0x02
      006421 F0               [24] 2597 	movx	@dptr,a
      006422 02 64 AA         [24] 2598 	ljmp	00291$
      006425                       2599 00273$:
                                   2600 ;	tmk_core/protocol/ch555/usb_ak820.c:355: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006425 EB               [12] 2601 	mov	a,r3
      006426 4C               [12] 2602 	orl	a,r4
      006427 70 37            [24] 2603 	jnz	00265$
      006429 90 07 5B         [24] 2604 	mov	dptr,#_D0UsbConfig
      00642C E0               [24] 2605 	movx	a,@dptr
      00642D 60 31            [24] 2606 	jz	00265$
      00642F EA               [12] 2607 	mov	a,r2
      006430 60 2E            [24] 2608 	jz	00265$
      006432 90 07 55         [24] 2609 	mov	dptr,#_D0SetupReqCode
      006435 E0               [24] 2610 	movx	a,@dptr
      006436 FA               [12] 2611 	mov	r2,a
      006437 BA 03 26         [24] 2612 	cjne	r2,#0x03,00265$
      00643A 30 11 23         [24] 2613 	jnb	_control_setup_zero_value_10000_285,00265$
      00643D 90 07 56         [24] 2614 	mov	dptr,#_D0SetupLen
      006440 E0               [24] 2615 	movx	a,@dptr
      006441 F9               [12] 2616 	mov	r1,a
      006442 A3               [24] 2617 	inc	dptr
      006443 E0               [24] 2618 	movx	a,@dptr
      006444 FA               [12] 2619 	mov	r2,a
      006445 B9 01 18         [24] 2620 	cjne	r1,#0x01,00265$
      006448 BA 00 15         [24] 2621 	cjne	r2,#0x00,00265$
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:356: pD0_EP0_BUF[0] = keyboard_protocol;
      00644B 90 0D C4         [24] 2623 	mov	dptr,#_keyboard_protocol
      00644E E0               [24] 2624 	movx	a,@dptr
      00644F 90 10 00         [24] 2625 	mov	dptr,#0x1000
      006452 F0               [24] 2626 	movx	@dptr,a
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:357: D0_EP0T_L = 1;
      006453 90 22 08         [24] 2628 	mov	dptr,#0x2208
      006456 74 01            [12] 2629 	mov	a,#0x01
      006458 F0               [24] 2630 	movx	@dptr,a
                                   2631 ;	tmk_core/protocol/ch555/usb_ak820.c:358: control_phase = CTRL_STATUS_OUT;
      006459 90 07 B4         [24] 2632 	mov	dptr,#_control_phase
      00645C 04               [12] 2633 	inc	a
      00645D F0               [24] 2634 	movx	@dptr,a
      00645E 80 4A            [24] 2635 	sjmp	00291$
      006460                       2636 00265$:
                                   2637 ;	tmk_core/protocol/ch555/usb_ak820.c:359: } else { control_stall(); return; }
                                   2638 ;	tmk_core/protocol/ch555/usb_ak820.c:361: case DEF_USB_GET_IDLE:
      006460 02 5A E8         [24] 2639 	ljmp	_control_stall
      006463                       2640 00282$:
                                   2641 ;	tmk_core/protocol/ch555/usb_ak820.c:362: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006463 30 0F 3E         [24] 2642 	jnb	_control_setup_valid_interface_10000_285,00284$
      006466 90 07 5B         [24] 2643 	mov	dptr,#_D0UsbConfig
      006469 E0               [24] 2644 	movx	a,@dptr
      00646A 60 38            [24] 2645 	jz	00284$
      00646C BF A1 35         [24] 2646 	cjne	r7,#0xa1,00284$
      00646F 8E 05            [24] 2647 	mov	ar5,r6
      006471 7E 00            [12] 2648 	mov	r6,#0x00
      006473 ED               [12] 2649 	mov	a,r5
      006474 4E               [12] 2650 	orl	a,r6
      006475 70 2D            [24] 2651 	jnz	00284$
      006477 90 07 56         [24] 2652 	mov	dptr,#_D0SetupLen
      00647A E0               [24] 2653 	movx	a,@dptr
      00647B FE               [12] 2654 	mov	r6,a
      00647C A3               [24] 2655 	inc	dptr
      00647D E0               [24] 2656 	movx	a,@dptr
      00647E FF               [12] 2657 	mov	r7,a
      00647F BE 01 22         [24] 2658 	cjne	r6,#0x01,00284$
      006482 BF 00 1F         [24] 2659 	cjne	r7,#0x00,00284$
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:363: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006485 EB               [12] 2661 	mov	a,r3
      006486 4C               [12] 2662 	orl	a,r4
      006487 70 07            [24] 2663 	jnz	00324$
      006489 90 06 36         [24] 2664 	mov	dptr,#_keyboard_idle
      00648C E0               [24] 2665 	movx	a,@dptr
      00648D FF               [12] 2666 	mov	r7,a
      00648E 80 02            [24] 2667 	sjmp	00325$
      006490                       2668 00324$:
      006490 7F 00            [12] 2669 	mov	r7,#0x00
      006492                       2670 00325$:
      006492 90 10 00         [24] 2671 	mov	dptr,#0x1000
      006495 EF               [12] 2672 	mov	a,r7
      006496 F0               [24] 2673 	movx	@dptr,a
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = 1;
      006497 90 22 08         [24] 2675 	mov	dptr,#0x2208
      00649A 74 01            [12] 2676 	mov	a,#0x01
      00649C F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      00649D 90 07 B4         [24] 2679 	mov	dptr,#_control_phase
      0064A0 04               [12] 2680 	inc	a
      0064A1 F0               [24] 2681 	movx	@dptr,a
      0064A2 80 06            [24] 2682 	sjmp	00291$
      0064A4                       2683 00284$:
                                   2684 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else { control_stall(); return; }
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:368: default: control_stall(); return;
      0064A4 02 5A E8         [24] 2686 	ljmp	_control_stall
      0064A7                       2687 00290$:
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:369: }
      0064A7 02 5A E8         [24] 2689 	ljmp	_control_stall
      0064AA                       2690 00291$:
                                   2691 ;	tmk_core/protocol/ch555/usb_ak820.c:370: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0064AA 90 22 00         [24] 2692 	mov	dptr,#0x2200
      0064AD 74 C0            [12] 2693 	mov	a,#0xc0
      0064AF F0               [24] 2694 	movx	@dptr,a
                                   2695 ;	tmk_core/protocol/ch555/usb_ak820.c:371: }
      0064B0 22               [24] 2696 	ret
                                   2697 ;------------------------------------------------------------
                                   2698 ;Allocation info for local variables in function 'control_out'
                                   2699 ;------------------------------------------------------------
                                   2700 ;i             Allocated with name '_control_out_i_10000_369'
                                   2701 ;------------------------------------------------------------
                                   2702 ;	tmk_core/protocol/ch555/usb_ak820.c:373: static void control_out(void) {
                                   2703 ;	-----------------------------------------
                                   2704 ;	 function control_out
                                   2705 ;	-----------------------------------------
      0064B1                       2706 _control_out:
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:375: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0064B1 90 22 0F         [24] 2708 	mov	dptr,#0x220f
      0064B4 E0               [24] 2709 	movx	a,@dptr
      0064B5 20 E6 01         [24] 2710 	jb	acc.6,00102$
      0064B8 22               [24] 2711 	ret
      0064B9                       2712 00102$:
                                   2713 ;	tmk_core/protocol/ch555/usb_ak820.c:376: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0064B9 90 07 B4         [24] 2714 	mov	dptr,#_control_phase
      0064BC E0               [24] 2715 	movx	a,@dptr
      0064BD FF               [12] 2716 	mov	r7,a
      0064BE BF 02 12         [24] 2717 	cjne	r7,#0x02,00104$
      0064C1 90 22 0E         [24] 2718 	mov	dptr,#0x220e
      0064C4 E0               [24] 2719 	movx	a,@dptr
      0064C5 70 0C            [24] 2720 	jnz	00104$
                                   2721 ;	tmk_core/protocol/ch555/usb_ak820.c:377: control_phase = CTRL_IDLE;
      0064C7 90 07 B4         [24] 2722 	mov	dptr,#_control_phase
      0064CA E4               [12] 2723 	clr	a
      0064CB F0               [24] 2724 	movx	@dptr,a
                                   2725 ;	tmk_core/protocol/ch555/usb_ak820.c:378: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0064CC 90 22 00         [24] 2726 	mov	dptr,#0x2200
      0064CF 74 02            [12] 2727 	mov	a,#0x02
      0064D1 F0               [24] 2728 	movx	@dptr,a
                                   2729 ;	tmk_core/protocol/ch555/usb_ak820.c:379: return;
      0064D2 22               [24] 2730 	ret
      0064D3                       2731 00104$:
                                   2732 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0064D3 BF 04 19         [24] 2733 	cjne	r7,#0x04,00106$
      0064D6 90 22 0E         [24] 2734 	mov	dptr,#0x220e
      0064D9 E0               [24] 2735 	movx	a,@dptr
      0064DA FF               [12] 2736 	mov	r7,a
      0064DB 90 07 56         [24] 2737 	mov	dptr,#_D0SetupLen
      0064DE E0               [24] 2738 	movx	a,@dptr
      0064DF FD               [12] 2739 	mov	r5,a
      0064E0 A3               [24] 2740 	inc	dptr
      0064E1 E0               [24] 2741 	movx	a,@dptr
      0064E2 FE               [12] 2742 	mov	r6,a
      0064E3 7C 00            [12] 2743 	mov	r4,#0x00
      0064E5 EF               [12] 2744 	mov	a,r7
      0064E6 B5 05 06         [24] 2745 	cjne	a,ar5,00209$
      0064E9 EC               [12] 2746 	mov	a,r4
      0064EA B5 06 02         [24] 2747 	cjne	a,ar6,00209$
      0064ED 80 03            [24] 2748 	sjmp	00107$
      0064EF                       2749 00209$:
      0064EF                       2750 00106$:
      0064EF 02 5A E8         [24] 2751 	ljmp	_control_stall
      0064F2                       2752 00107$:
                                   2753 ;	tmk_core/protocol/ch555/usb_ak820.c:382: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0064F2 90 07 B5         [24] 2754 	mov	dptr,#_output_kind
      0064F5 E0               [24] 2755 	movx	a,@dptr
      0064F6 FF               [12] 2756 	mov	r7,a
      0064F7 BF 01 2E         [24] 2757 	cjne	r7,#0x01,00118$
      0064FA 90 07 63         [24] 2758 	mov	dptr,#_raw_state
      0064FD E0               [24] 2759 	movx	a,@dptr
      0064FE FE               [12] 2760 	mov	r6,a
      0064FF BE 01 26         [24] 2761 	cjne	r6,#0x01,00118$
                                   2762 ;	tmk_core/protocol/ch555/usb_ak820.c:383: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006502 7E 00            [12] 2763 	mov	r6,#0x00
      006504                       2764 00121$:
      006504 EE               [12] 2765 	mov	a,r6
      006505 24 64            [12] 2766 	add	a, #_raw_buffer
      006507 FC               [12] 2767 	mov	r4,a
      006508 E4               [12] 2768 	clr	a
      006509 34 07            [12] 2769 	addc	a, #(_raw_buffer >> 8)
      00650B FD               [12] 2770 	mov	r5,a
      00650C 8E 82            [24] 2771 	mov	dpl,r6
      00650E 74 10            [12] 2772 	mov	a,#0x10
      006510 24 00            [12] 2773 	add	a, #0x00
      006512 F5 83            [12] 2774 	mov	dph,a
      006514 E0               [24] 2775 	movx	a,@dptr
      006515 8C 82            [24] 2776 	mov	dpl,r4
      006517 8D 83            [24] 2777 	mov	dph,r5
      006519 F0               [24] 2778 	movx	@dptr,a
      00651A 0E               [12] 2779 	inc	r6
      00651B BE 20 00         [24] 2780 	cjne	r6,#0x20,00214$
      00651E                       2781 00214$:
      00651E 40 E4            [24] 2782 	jc	00121$
                                   2783 ;	tmk_core/protocol/ch555/usb_ak820.c:384: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006520 90 07 63         [24] 2784 	mov	dptr,#_raw_state
      006523 74 02            [12] 2785 	mov	a,#0x02
      006525 F0               [24] 2786 	movx	@dptr,a
      006526 80 2B            [24] 2787 	sjmp	00119$
      006528                       2788 00118$:
                                   2789 ;	tmk_core/protocol/ch555/usb_ak820.c:385: } else if (output_kind == OUTPUT_LED) {
      006528 BF 02 0A         [24] 2790 	cjne	r7,#0x02,00115$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:386: KB_USB_SetReport = pD0_EP0_BUF[0];
      00652B 90 10 00         [24] 2792 	mov	dptr,#0x1000
      00652E E0               [24] 2793 	movx	a,@dptr
      00652F 90 07 60         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006532 F0               [24] 2795 	movx	@dptr,a
      006533 80 1E            [24] 2796 	sjmp	00119$
      006535                       2797 00115$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:387: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006535 BF 03 18         [24] 2799 	cjne	r7,#0x03,00111$
      006538 90 10 00         [24] 2800 	mov	dptr,#0x1000
      00653B E0               [24] 2801 	movx	a,@dptr
      00653C FF               [12] 2802 	mov	r7,a
      00653D 90 07 B6         [24] 2803 	mov	dptr,#_output_report_id
      006540 E0               [24] 2804 	movx	a,@dptr
      006541 FE               [12] 2805 	mov	r6,a
      006542 EF               [12] 2806 	mov	a,r7
      006543 B5 06 0A         [24] 2807 	cjne	a,ar6,00111$
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:388: KB_USB_SetReport = pD0_EP0_BUF[1];
      006546 90 10 01         [24] 2809 	mov	dptr,#0x1001
      006549 E0               [24] 2810 	movx	a,@dptr
      00654A 90 07 60         [24] 2811 	mov	dptr,#_KB_USB_SetReport
      00654D F0               [24] 2812 	movx	@dptr,a
      00654E 80 03            [24] 2813 	sjmp	00119$
      006550                       2814 00111$:
                                   2815 ;	tmk_core/protocol/ch555/usb_ak820.c:389: } else { control_stall(); return; }
      006550 02 5A E8         [24] 2816 	ljmp	_control_stall
      006553                       2817 00119$:
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:390: output_kind = OUTPUT_NONE;
      006553 90 07 B5         [24] 2819 	mov	dptr,#_output_kind
      006556 E4               [12] 2820 	clr	a
      006557 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:391: D0SetupLen = 0;
      006558 90 07 56         [24] 2823 	mov	dptr,#_D0SetupLen
      00655B F0               [24] 2824 	movx	@dptr,a
      00655C A3               [24] 2825 	inc	dptr
      00655D F0               [24] 2826 	movx	@dptr,a
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:392: control_phase = CTRL_STATUS_IN;
      00655E 90 07 B4         [24] 2828 	mov	dptr,#_control_phase
      006561 74 03            [12] 2829 	mov	a,#0x03
      006563 F0               [24] 2830 	movx	@dptr,a
                                   2831 ;	tmk_core/protocol/ch555/usb_ak820.c:393: D0_EP0T_L = 0;
      006564 90 22 08         [24] 2832 	mov	dptr,#0x2208
      006567 E4               [12] 2833 	clr	a
      006568 F0               [24] 2834 	movx	@dptr,a
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:394: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006569 F5 82            [12] 2836 	mov	dpl,a
      00656B 74 48            [12] 2837 	mov	a,#0x48
      00656D F0               [24] 2838 	movx	@dptr,a
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:395: }
      00656E 22               [24] 2840 	ret
                                   2841 ;------------------------------------------------------------
                                   2842 ;Allocation info for local variables in function 'control_in'
                                   2843 ;------------------------------------------------------------
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:397: static void control_in(void) {
                                   2845 ;	-----------------------------------------
                                   2846 ;	 function control_in
                                   2847 ;	-----------------------------------------
      00656F                       2848 _control_in:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:398: if (control_phase == CTRL_DATA_IN) {
      00656F 90 07 B4         [24] 2850 	mov	dptr,#_control_phase
      006572 E0               [24] 2851 	movx	a,@dptr
      006573 FF               [12] 2852 	mov	r7,a
      006574 BF 01 22         [24] 2853 	cjne	r7,#0x01,00109$
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:399: if (D0SetupLen || control_zlp) {
      006577 90 07 56         [24] 2855 	mov	dptr,#_D0SetupLen
      00657A E0               [24] 2856 	movx	a,@dptr
      00657B FD               [12] 2857 	mov	r5,a
      00657C A3               [24] 2858 	inc	dptr
      00657D E0               [24] 2859 	movx	a,@dptr
      00657E 4D               [12] 2860 	orl	a,r5
      00657F 70 06            [24] 2861 	jnz	00101$
      006581 90 07 B7         [24] 2862 	mov	dptr,#_control_zlp
      006584 E0               [24] 2863 	movx	a,@dptr
      006585 60 0A            [24] 2864 	jz	00102$
      006587                       2865 00101$:
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:400: D0_EP0RES ^= bUEP_T_TOG;
      006587 90 22 00         [24] 2867 	mov	dptr,#0x2200
      00658A E0               [24] 2868 	movx	a,@dptr
      00658B 64 40            [12] 2869 	xrl	a,#0x40
      00658D F0               [24] 2870 	movx	@dptr,a
                                   2871 ;	tmk_core/protocol/ch555/usb_ak820.c:401: control_next();
                                   2872 ;	tmk_core/protocol/ch555/usb_ak820.c:402: return;
      00658E 02 5B 0A         [24] 2873 	ljmp	_control_next
      006591                       2874 00102$:
                                   2875 ;	tmk_core/protocol/ch555/usb_ak820.c:404: control_phase = CTRL_STATUS_OUT;
      006591 90 07 B4         [24] 2876 	mov	dptr,#_control_phase
      006594 74 02            [12] 2877 	mov	a,#0x02
      006596 F0               [24] 2878 	movx	@dptr,a
      006597 80 18            [24] 2879 	sjmp	00110$
      006599                       2880 00109$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:405: } else if (control_phase == CTRL_STATUS_IN) {
      006599 BF 03 15         [24] 2882 	cjne	r7,#0x03,00110$
                                   2883 ;	tmk_core/protocol/ch555/usb_ak820.c:406: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00659C 90 07 55         [24] 2884 	mov	dptr,#_D0SetupReqCode
      00659F E0               [24] 2885 	movx	a,@dptr
      0065A0 FF               [12] 2886 	mov	r7,a
      0065A1 BF 05 08         [24] 2887 	cjne	r7,#0x05,00105$
      0065A4 90 07 56         [24] 2888 	mov	dptr,#_D0SetupLen
      0065A7 E0               [24] 2889 	movx	a,@dptr
      0065A8 90 22 07         [24] 2890 	mov	dptr,#0x2207
      0065AB F0               [24] 2891 	movx	@dptr,a
      0065AC                       2892 00105$:
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:407: control_phase = CTRL_IDLE;
      0065AC 90 07 B4         [24] 2894 	mov	dptr,#_control_phase
      0065AF E4               [12] 2895 	clr	a
      0065B0 F0               [24] 2896 	movx	@dptr,a
      0065B1                       2897 00110$:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:409: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065B1 90 22 00         [24] 2899 	mov	dptr,#0x2200
      0065B4 74 82            [12] 2900 	mov	a,#0x82
      0065B6 F0               [24] 2901 	movx	@dptr,a
                                   2902 ;	tmk_core/protocol/ch555/usb_ak820.c:410: }
      0065B7 22               [24] 2903 	ret
                                   2904 ;------------------------------------------------------------
                                   2905 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2906 ;------------------------------------------------------------
                                   2907 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_393'
                                   2908 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_393'
                                   2909 ;------------------------------------------------------------
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:412: void USB_DeviceInterrupt(void) {
                                   2911 ;	-----------------------------------------
                                   2912 ;	 function USB_DeviceInterrupt
                                   2913 ;	-----------------------------------------
      0065B8                       2914 _USB_DeviceInterrupt:
                                   2915 ;	tmk_core/protocol/ch555/usb_ak820.c:415: do {
      0065B8                       2916 00129$:
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (USB_IF & bUX_IF_BUS_RST) {
      0065B8 90 22 3D         [24] 2918 	mov	dptr,#0x223d
      0065BB E0               [24] 2919 	movx	a,@dptr
      0065BC 30 E0 4B         [24] 2920 	jnb	acc.0,00127$
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:418: endpoints_reset();
      0065BF 12 5A 91         [24] 2922 	lcall	_endpoints_reset
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:419: D0_ADDR = 0;
      0065C2 90 22 07         [24] 2924 	mov	dptr,#0x2207
      0065C5 E4               [12] 2925 	clr	a
      0065C6 F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0065C7 90 07 5D         [24] 2928 	mov	dptr,#_USB_SleepStatus
      0065CA F0               [24] 2929 	movx	@dptr,a
      0065CB 90 07 5C         [24] 2930 	mov	dptr,#_USB_EnumStatus
      0065CE F0               [24] 2931 	movx	@dptr,a
      0065CF 90 07 5B         [24] 2932 	mov	dptr,#_D0UsbConfig
      0065D2 F0               [24] 2933 	movx	@dptr,a
                                   2934 ;	tmk_core/protocol/ch555/usb_ak820.c:421: KB_USB_SetReport = 0;
      0065D3 90 07 60         [24] 2935 	mov	dptr,#_KB_USB_SetReport
      0065D6 F0               [24] 2936 	movx	@dptr,a
                                   2937 ;	tmk_core/protocol/ch555/usb_ak820.c:422: keyboard_protocol = 1;
      0065D7 90 0D C4         [24] 2938 	mov	dptr,#_keyboard_protocol
      0065DA 04               [12] 2939 	inc	a
      0065DB F0               [24] 2940 	movx	@dptr,a
                                   2941 ;	tmk_core/protocol/ch555/usb_ak820.c:423: keyboard_idle = 0;
      0065DC 90 06 36         [24] 2942 	mov	dptr,#_keyboard_idle
      0065DF E4               [12] 2943 	clr	a
      0065E0 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:424: keyboard_reset = 1;
      0065E1 90 07 85         [24] 2946 	mov	dptr,#_keyboard_reset
      0065E4 04               [12] 2947 	inc	a
      0065E5 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0SetupReqCode = 0xff;
      0065E6 90 07 55         [24] 2950 	mov	dptr,#_D0SetupReqCode
      0065E9 74 FF            [12] 2951 	mov	a,#0xff
      0065EB F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:426: D0SetupLen = 0;
      0065EC 90 07 56         [24] 2954 	mov	dptr,#_D0SetupLen
      0065EF E4               [12] 2955 	clr	a
      0065F0 F0               [24] 2956 	movx	@dptr,a
      0065F1 A3               [24] 2957 	inc	dptr
      0065F2 F0               [24] 2958 	movx	@dptr,a
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:427: control_phase = CTRL_IDLE;
      0065F3 90 07 B4         [24] 2960 	mov	dptr,#_control_phase
      0065F6 F0               [24] 2961 	movx	@dptr,a
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:428: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065F7 90 22 00         [24] 2963 	mov	dptr,#0x2200
      0065FA 74 02            [12] 2964 	mov	a,#0x02
      0065FC F0               [24] 2965 	movx	@dptr,a
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:429: ACK_TRANSFER();
      0065FD 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      006600 E4               [12] 2968 	clr	a
      006601 F0               [24] 2969 	movx	@dptr,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:430: ACK_RESET();
      006602 90 22 3D         [24] 2971 	mov	dptr,#0x223d
      006605 04               [12] 2972 	inc	a
      006606 F0               [24] 2973 	movx	@dptr,a
      006607 02 66 9D         [24] 2974 	ljmp	00130$
      00660A                       2975 00127$:
                                   2976 ;	tmk_core/protocol/ch555/usb_ak820.c:431: } else if (USB_IF & bUX_IF_D0_TRANS) {
      00660A 90 22 3D         [24] 2977 	mov	dptr,#0x223d
      00660D E0               [24] 2978 	movx	a,@dptr
      00660E 30 E5 60         [24] 2979 	jnb	acc.5,00124$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:432: status = D0_STATUS;
      006611 90 22 0F         [24] 2981 	mov	dptr,#0x220f
      006614 E0               [24] 2982 	movx	a,@dptr
      006615 FF               [12] 2983 	mov	r7,a
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:433: endpoint = status & MASK_UXS_ENDP;
      006616 74 07            [12] 2985 	mov	a,#0x07
      006618 5F               [12] 2986 	anl	a,r7
      006619 FE               [12] 2987 	mov	r6,a
                                   2988 ;	tmk_core/protocol/ch555/usb_ak820.c:437: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      00661A EF               [12] 2989 	mov	a,r7
      00661B 54 18            [12] 2990 	anl	a,#0x18
      00661D 70 08            [24] 2991 	jnz	00115$
      00661F EE               [12] 2992 	mov	a,r6
      006620 70 05            [24] 2993 	jnz	00115$
                                   2994 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_out();
      006622 12 64 B1         [24] 2995 	lcall	_control_out
      006625 80 43            [24] 2996 	sjmp	00116$
      006627                       2997 00115$:
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:439: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006627 8F 05            [24] 2999 	mov	ar5,r7
      006629 74 18            [12] 3000 	mov	a,#0x18
      00662B 5D               [12] 3001 	anl	a,r5
      00662C FC               [12] 3002 	mov	r4,a
      00662D BC 10 2D         [24] 3003 	cjne	r4,#0x10,00112$
                                   3004 ;	tmk_core/protocol/ch555/usb_ak820.c:440: if (!endpoint) control_in();
      006630 EE               [12] 3005 	mov	a,r6
      006631 70 05            [24] 3006 	jnz	00106$
      006633 12 65 6F         [24] 3007 	lcall	_control_in
      006636 80 32            [24] 3008 	sjmp	00116$
      006638                       3009 00106$:
                                   3010 ;	tmk_core/protocol/ch555/usb_ak820.c:441: else if (endpoint <= 3) {
      006638 EE               [12] 3011 	mov	a,r6
      006639 24 FC            [12] 3012 	add	a,#0xff - 0x03
      00663B 40 2D            [24] 3013 	jc	00116$
                                   3014 ;	free result
                                   3015 ;	tmk_core/protocol/ch555/usb_ak820.c:442: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00663D 8E 04            [24] 3016 	mov	ar4,r6
      00663F 7B 00            [12] 3017 	mov	r3,#0x00
      006641 74 22            [12] 3018 	mov	a,#0x22
      006643 2B               [12] 3019 	add	a, r3
      006644 FB               [12] 3020 	mov	r3,a
      006645 8C 82            [24] 3021 	mov	dpl,r4
      006647 8B 83            [24] 3022 	mov	dph,r3
      006649 E0               [24] 3023 	movx	a,@dptr
      00664A FA               [12] 3024 	mov	r2,a
      00664B 74 FC            [12] 3025 	mov	a,#0xfc
      00664D 5A               [12] 3026 	anl	a,r2
      00664E 44 02            [12] 3027 	orl	a,#0x02
      006650 8C 82            [24] 3028 	mov	dpl,r4
      006652 8B 83            [24] 3029 	mov	dph,r3
      006654 F0               [24] 3030 	movx	@dptr,a
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:443: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006655 BE 03 12         [24] 3032 	cjne	r6,#0x03,00116$
      006658 12 5A 74         [24] 3033 	lcall	_raw_complete
      00665B 80 0D            [24] 3034 	sjmp	00116$
      00665D                       3035 00112$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:445: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00665D 53 05 18         [24] 3037 	anl	ar5,#0x18
      006660 BD 18 07         [24] 3038 	cjne	r5,#0x18,00116$
      006663 EF               [12] 3039 	mov	a,r7
      006664 30 E5 03         [24] 3040 	jnb	acc.5,00116$
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:446: control_setup();
      006667 12 5D 08         [24] 3042 	lcall	_control_setup
      00666A                       3043 00116$:
                                   3044 ;	tmk_core/protocol/ch555/usb_ak820.c:448: ACK_TRANSFER();
      00666A 90 22 0F         [24] 3045 	mov	dptr,#0x220f
      00666D E4               [12] 3046 	clr	a
      00666E F0               [24] 3047 	movx	@dptr,a
      00666F 80 2C            [24] 3048 	sjmp	00130$
      006671                       3049 00124$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:449: } else if (USB_IF & bUX_IF_SUSPEND) {
      006671 90 22 3D         [24] 3051 	mov	dptr,#0x223d
      006674 E0               [24] 3052 	movx	a,@dptr
      006675 30 E2 25         [24] 3053 	jnb	acc.2,00130$
                                   3054 ;	tmk_core/protocol/ch555/usb_ak820.c:450: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006678 90 22 3D         [24] 3055 	mov	dptr,#0x223d
      00667B E0               [24] 3056 	movx	a,@dptr
      00667C 30 E3 0A         [24] 3057 	jnb	acc.3,00119$
      00667F 90 07 5D         [24] 3058 	mov	dptr,#_USB_SleepStatus
      006682 E0               [24] 3059 	movx	a,@dptr
      006683 43 E0 02         [24] 3060 	orl	acc,#0x02
      006686 F0               [24] 3061 	movx	@dptr,a
      006687 80 0E            [24] 3062 	sjmp	00120$
      006689                       3063 00119$:
                                   3064 ;	tmk_core/protocol/ch555/usb_ak820.c:452: USB_SleepStatus &= ~2;
      006689 90 07 5D         [24] 3065 	mov	dptr,#_USB_SleepStatus
      00668C E0               [24] 3066 	movx	a,@dptr
      00668D 53 E0 FD         [24] 3067 	anl	acc,#0xfd
      006690 F0               [24] 3068 	movx	@dptr,a
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:453: keyboard_reset = 1;
      006691 90 07 85         [24] 3070 	mov	dptr,#_keyboard_reset
      006694 74 01            [12] 3071 	mov	a,#0x01
      006696 F0               [24] 3072 	movx	@dptr,a
      006697                       3073 00120$:
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:455: ACK_SUSPEND();
      006697 90 22 3D         [24] 3075 	mov	dptr,#0x223d
      00669A 74 04            [12] 3076 	mov	a,#0x04
      00669C F0               [24] 3077 	movx	@dptr,a
      00669D                       3078 00130$:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:457: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      00669D 90 22 3D         [24] 3080 	mov	dptr,#0x223d
      0066A0 E0               [24] 3081 	movx	a,@dptr
      0066A1 54 25            [12] 3082 	anl	a,#0x25
      0066A3 60 03            [24] 3083 	jz	00242$
      0066A5 02 65 B8         [24] 3084 	ljmp	00129$
      0066A8                       3085 00242$:
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:458: }
      0066A8 22               [24] 3087 	ret
                                   3088 ;------------------------------------------------------------
                                   3089 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3090 ;------------------------------------------------------------
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:461: void USB_Device_Init(void) {
                                   3092 ;	-----------------------------------------
                                   3093 ;	 function USB_Device_Init
                                   3094 ;	-----------------------------------------
      0066A9                       3095 _USB_Device_Init:
                                   3096 ;	tmk_core/protocol/ch555/usb_ak820.c:462: IE_USB = 0;
                                   3097 ;	assignBit
      0066A9 C2 E9            [12] 3098 	clr	_IE_USB
                                   3099 ;	tmk_core/protocol/ch555/usb_ak820.c:463: USB_CTRL = 0;
      0066AB 90 22 3C         [24] 3100 	mov	dptr,#0x223c
      0066AE E4               [12] 3101 	clr	a
      0066AF F0               [24] 3102 	movx	@dptr,a
                                   3103 ;	tmk_core/protocol/ch555/usb_ak820.c:464: raw_state = RAW_IDLE;
      0066B0 90 07 63         [24] 3104 	mov	dptr,#_raw_state
      0066B3 F0               [24] 3105 	movx	@dptr,a
                                   3106 ;	tmk_core/protocol/ch555/usb_ak820.c:465: endpoints_reset();
      0066B4 12 5A 91         [24] 3107 	lcall	_endpoints_reset
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:466: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0066B7 90 07 5D         [24] 3109 	mov	dptr,#_USB_SleepStatus
      0066BA E4               [12] 3110 	clr	a
      0066BB F0               [24] 3111 	movx	@dptr,a
      0066BC 90 07 5C         [24] 3112 	mov	dptr,#_USB_EnumStatus
      0066BF F0               [24] 3113 	movx	@dptr,a
      0066C0 90 07 5B         [24] 3114 	mov	dptr,#_D0UsbConfig
      0066C3 F0               [24] 3115 	movx	@dptr,a
      0066C4 90 22 07         [24] 3116 	mov	dptr,#0x2207
      0066C7 F0               [24] 3117 	movx	@dptr,a
                                   3118 ;	tmk_core/protocol/ch555/usb_ak820.c:467: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0066C8 90 07 5E         [24] 3119 	mov	dptr,#_MCU_Sleep_Operate
      0066CB F0               [24] 3120 	movx	@dptr,a
      0066CC 90 07 5F         [24] 3121 	mov	dptr,#_KB_USB_UpStatus
      0066CF F0               [24] 3122 	movx	@dptr,a
      0066D0 90 07 60         [24] 3123 	mov	dptr,#_KB_USB_SetReport
      0066D3 F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:468: keyboard_protocol = 1;
      0066D4 90 0D C4         [24] 3126 	mov	dptr,#_keyboard_protocol
      0066D7 04               [12] 3127 	inc	a
      0066D8 F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:469: keyboard_idle = 0;
      0066D9 90 06 36         [24] 3130 	mov	dptr,#_keyboard_idle
      0066DC E4               [12] 3131 	clr	a
      0066DD F0               [24] 3132 	movx	@dptr,a
                                   3133 ;	tmk_core/protocol/ch555/usb_ak820.c:470: keyboard_reset = 0;
      0066DE 90 07 85         [24] 3134 	mov	dptr,#_keyboard_reset
      0066E1 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:471: control_phase = CTRL_IDLE;
      0066E2 90 07 B4         [24] 3137 	mov	dptr,#_control_phase
      0066E5 F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:472: D0SetupReqCode = 0xff;
      0066E6 90 07 55         [24] 3140 	mov	dptr,#_D0SetupReqCode
      0066E9 14               [12] 3141 	dec	a
      0066EA F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:473: D0SetupLen = 0;
      0066EB 90 07 56         [24] 3144 	mov	dptr,#_D0SetupLen
      0066EE E4               [12] 3145 	clr	a
      0066EF F0               [24] 3146 	movx	@dptr,a
      0066F0 A3               [24] 3147 	inc	dptr
      0066F1 F0               [24] 3148 	movx	@dptr,a
                                   3149 ;	tmk_core/protocol/ch555/usb_ak820.c:474: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066F2 90 22 00         [24] 3150 	mov	dptr,#0x2200
      0066F5 74 02            [12] 3151 	mov	a,#0x02
      0066F7 F0               [24] 3152 	movx	@dptr,a
                                   3153 ;	tmk_core/protocol/ch555/usb_ak820.c:475: HB_ADDR = 0x7f;
      0066F8 90 22 37         [24] 3154 	mov	dptr,#0x2237
      0066FB 74 7F            [12] 3155 	mov	a,#0x7f
      0066FD F0               [24] 3156 	movx	@dptr,a
                                   3157 ;	tmk_core/protocol/ch555/usb_ak820.c:476: ACK_ALL();
      0066FE 90 22 3D         [24] 3158 	mov	dptr,#0x223d
      006701 74 FF            [12] 3159 	mov	a,#0xff
      006703 F0               [24] 3160 	movx	@dptr,a
                                   3161 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006704 90 22 3B         [24] 3162 	mov	dptr,#0x223b
      006707 74 07            [12] 3163 	mov	a,#0x07
      006709 F0               [24] 3164 	movx	@dptr,a
                                   3165 ;	tmk_core/protocol/ch555/usb_ak820.c:478: USB_CTRL = bUX_DP_PU_EN;
      00670A A3               [24] 3166 	inc	dptr
      00670B 74 80            [12] 3167 	mov	a,#0x80
      00670D F0               [24] 3168 	movx	@dptr,a
                                   3169 ;	tmk_core/protocol/ch555/usb_ak820.c:479: IE_USB = 1;
                                   3170 ;	assignBit
      00670E D2 E9            [12] 3171 	setb	_IE_USB
                                   3172 ;	tmk_core/protocol/ch555/usb_ak820.c:480: }
      006710 22               [24] 3173 	ret
                                   3174 ;------------------------------------------------------------
                                   3175 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3176 ;------------------------------------------------------------
                                   3177 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_416'
                                   3178 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_419'
                                   3179 ;------------------------------------------------------------
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:482: void USB_WakeUp_PC(void) {
                                   3181 ;	-----------------------------------------
                                   3182 ;	 function USB_WakeUp_PC
                                   3183 ;	-----------------------------------------
      006711                       3184 _USB_WakeUp_PC:
                                   3185 ;	tmk_core/protocol/ch555/usb_ak820.c:484: if (USB_SleepStatus != 3) return;
      006711 90 07 5D         [24] 3186 	mov	dptr,#_USB_SleepStatus
      006714 E0               [24] 3187 	movx	a,@dptr
      006715 FF               [12] 3188 	mov	r7,a
      006716 BF 03 22         [24] 3189 	cjne	r7,#0x03,00110$
                                   3190 ;	tmk_core/protocol/ch555/usb_ak820.c:485: saved = USB_CTRL;
      006719 90 22 3C         [24] 3191 	mov	dptr,#0x223c
      00671C E0               [24] 3192 	movx	a,@dptr
      00671D FF               [12] 3193 	mov	r7,a
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:486: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      00671E E0               [24] 3195 	movx	a,@dptr
      00671F FE               [12] 3196 	mov	r6,a
      006720 63 06 C0         [24] 3197 	xrl	ar6,#0xc0
      006723 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006726 EE               [12] 3199 	mov	a,r6
      006727 F0               [24] 3200 	movx	@dptr,a
                                   3201 ;	tmk_core/protocol/ch555/usb_ak820.c:487: wait_ms(10);
      006728 7E 0A            [12] 3202 	mov	r6,#0x0a
      00672A                       3203 00108$:
      00672A EE               [12] 3204 	mov	a,r6
      00672B 60 09            [24] 3205 	jz	00105$
      00672D 90 00 01         [24] 3206 	mov	dptr,#0x0001
      006730 12 58 B8         [24] 3207 	lcall	_mDelaymS
      006733 1E               [12] 3208 	dec	r6
      006734 80 F4            [24] 3209 	sjmp	00108$
      006736                       3210 00105$:
                                   3211 ;	tmk_core/protocol/ch555/usb_ak820.c:488: USB_CTRL = saved;
      006736 90 22 3C         [24] 3212 	mov	dptr,#0x223c
      006739 EF               [12] 3213 	mov	a,r7
      00673A F0               [24] 3214 	movx	@dptr,a
      00673B                       3215 00110$:
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:489: }
      00673B 22               [24] 3217 	ret
                                   3218 ;------------------------------------------------------------
                                   3219 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3220 ;------------------------------------------------------------
                                   3221 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3222 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3223 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3224 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3225 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_421'
                                   3226 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_422'
                                   3227 ;i             Allocated with name '_ak820_usb_send_i_10000_422'
                                   3228 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_422'
                                   3229 ;offset        Allocated with name '_ak820_usb_send_offset_10000_422'
                                   3230 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_422'
                                   3231 ;i             Allocated with name '_ak820_usb_send_i_30000_434'
                                   3232 ;------------------------------------------------------------
                                   3233 ;	tmk_core/protocol/ch555/usb_ak820.c:491: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3234 ;	-----------------------------------------
                                   3235 ;	 function ak820_usb_send
                                   3236 ;	-----------------------------------------
      00673C                       3237 _ak820_usb_send:
      00673C E5 82            [12] 3238 	mov	a,dpl
      00673E 90 07 C4         [24] 3239 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006741 F0               [24] 3240 	movx	@dptr,a
                                   3241 ;	tmk_core/protocol/ch555/usb_ak820.c:495: uint8_t offset = SNAPSHOT_SIZE;
      006742 90 07 C5         [24] 3242 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006745 74 2E            [12] 3243 	mov	a,#0x2e
      006747 F0               [24] 3244 	movx	@dptr,a
                                   3245 ;	tmk_core/protocol/ch555/usb_ak820.c:497: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006748 90 07 C4         [24] 3246 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      00674B E0               [24] 3247 	movx	a,@dptr
      00674C FF               [12] 3248 	mov	r7,a
      00674D BF 01 00         [24] 3249 	cjne	r7,#0x01,00306$
      006750                       3250 00306$:
      006750 40 14            [24] 3251 	jc	00101$
      006752 EF               [12] 3252 	mov	a,r7
      006753 24 FC            [12] 3253 	add	a,#0xff - 0x03
      006755 40 0F            [24] 3254 	jc	00101$
                                   3255 ;	free result
      006757 90 07 C3         [24] 3256 	mov	dptr,#_ak820_usb_send_PARM_3
      00675A E0               [24] 3257 	movx	a,@dptr
      00675B FE               [12] 3258 	mov  r6,a
      00675C 24 BF            [12] 3259 	add	a,#0xff - 0x40
      00675E 40 06            [24] 3260 	jc	00101$
                                   3261 ;	free result
      006760 90 07 5C         [24] 3262 	mov	dptr,#_USB_EnumStatus
      006763 E0               [24] 3263 	movx	a,@dptr
      006764 70 04            [24] 3264 	jnz	00102$
      006766                       3265 00101$:
      006766 75 82 00         [24] 3266 	mov	dpl, #0x00
      006769 22               [24] 3267 	ret
      00676A                       3268 00102$:
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (endpoint == KEYBOARD_IN_EPNUM) {
      00676A BF 01 10         [24] 3270 	cjne	r7,#0x01,00118$
                                   3271 ;	tmk_core/protocol/ch555/usb_ak820.c:499: if (length != KEYBOARD_EPSIZE) return false;
      00676D BE 08 02         [24] 3272 	cjne	r6,#0x08,00313$
      006770 80 04            [24] 3273 	sjmp	00107$
      006772                       3274 00313$:
      006772 75 82 00         [24] 3275 	mov	dpl, #0x00
      006775 22               [24] 3276 	ret
      006776                       3277 00107$:
                                   3278 ;	tmk_core/protocol/ch555/usb_ak820.c:500: offset = SNAPSHOT_KEYBOARD;
      006776 90 07 C5         [24] 3279 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006779 E4               [12] 3280 	clr	a
      00677A F0               [24] 3281 	movx	@dptr,a
      00677B 80 3C            [24] 3282 	sjmp	00119$
      00677D                       3283 00118$:
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:501: } else if (endpoint == SHARED_IN_EPNUM) {
      00677D BF 02 30         [24] 3285 	cjne	r7,#0x02,00115$
                                   3286 ;	tmk_core/protocol/ch555/usb_ak820.c:502: report_id = report[0];
      006780 90 07 C1         [24] 3287 	mov	dptr,#_ak820_usb_send_PARM_2
      006783 E0               [24] 3288 	movx	a,@dptr
      006784 FD               [12] 3289 	mov	r5,a
      006785 A3               [24] 3290 	inc	dptr
      006786 E0               [24] 3291 	movx	a,@dptr
      006787 FF               [12] 3292 	mov	r7,a
      006788 8D 82            [24] 3293 	mov	dpl,r5
      00678A 8F 83            [24] 3294 	mov	dph,r7
      00678C E0               [24] 3295 	movx	a,@dptr
      00678D FF               [12] 3296 	mov	r7,a
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      00678E BF 07 00         [24] 3298 	cjne	r7,#0x07,00316$
      006791                       3299 00316$:
      006791 50 0E            [24] 3300 	jnc	00108$
      006793 EF               [12] 3301 	mov	a,r7
      006794 90 BE B5         [24] 3302 	mov	dptr,#_shared_lengths
      006797 93               [24] 3303 	movc	a,@a+dptr
      006798 FD               [12] 3304 	mov	r5,a
      006799 60 06            [24] 3305 	jz	00108$
      00679B EE               [12] 3306 	mov	a,r6
      00679C B5 05 02         [24] 3307 	cjne	a,ar5,00319$
      00679F 80 04            [24] 3308 	sjmp	00109$
      0067A1                       3309 00319$:
      0067A1                       3310 00108$:
      0067A1 75 82 00         [24] 3311 	mov	dpl, #0x00
      0067A4 22               [24] 3312 	ret
      0067A5                       3313 00109$:
                                   3314 ;	tmk_core/protocol/ch555/usb_ak820.c:504: offset = shared_offsets[report_id];
      0067A5 EF               [12] 3315 	mov	a,r7
      0067A6 90 BE AE         [24] 3316 	mov	dptr,#_shared_offsets
      0067A9 93               [24] 3317 	movc	a,@a+dptr
      0067AA 90 07 C5         [24] 3318 	mov	dptr,#_ak820_usb_send_offset_10000_422
      0067AD F0               [24] 3319 	movx	@dptr,a
      0067AE 80 09            [24] 3320 	sjmp	00119$
      0067B0                       3321 00115$:
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:505: } else if (length != RAW_EPSIZE) return false;
      0067B0 BE 20 02         [24] 3323 	cjne	r6,#0x20,00320$
      0067B3 80 04            [24] 3324 	sjmp	00119$
      0067B5                       3325 00320$:
      0067B5 75 82 00         [24] 3326 	mov	dpl, #0x00
      0067B8 22               [24] 3327 	ret
      0067B9                       3328 00119$:
                                   3329 ;	tmk_core/protocol/ch555/usb_ak820.c:506: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      0067B9 90 07 5D         [24] 3330 	mov	dptr,#_USB_SleepStatus
      0067BC E0               [24] 3331 	movx	a,@dptr
      0067BD 30 E1 07         [24] 3332 	jnb	acc.1,00184$
      0067C0 12 67 11         [24] 3333 	lcall	_USB_WakeUp_PC
      0067C3 75 82 00         [24] 3334 	mov	dpl, #0x00
      0067C6 22               [24] 3335 	ret
                                   3336 ;	tmk_core/protocol/ch555/usb_ak820.c:507: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      0067C7                       3337 00184$:
      0067C7 7F FA            [12] 3338 	mov	r7,#0xfa
      0067C9                       3339 00127$:
      0067C9 90 07 C4         [24] 3340 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      0067CC E0               [24] 3341 	movx	a,@dptr
      0067CD FC               [12] 3342 	mov	r4,a
      0067CE 7D 00            [12] 3343 	mov	r5,#0x00
      0067D0 8C 02            [24] 3344 	mov	ar2,r4
      0067D2 74 22            [12] 3345 	mov	a,#0x22
      0067D4 2D               [12] 3346 	add	a, r5
      0067D5 FB               [12] 3347 	mov	r3,a
      0067D6 8A 82            [24] 3348 	mov	dpl,r2
      0067D8 8B 83            [24] 3349 	mov	dph,r3
      0067DA E0               [24] 3350 	movx	a,@dptr
      0067DB 54 03            [12] 3351 	anl	a,#0x03
      0067DD 70 20            [24] 3352 	jnz	00129$
      0067DF 8F 03            [24] 3353 	mov	ar3,r7
      0067E1 1F               [12] 3354 	dec	r7
      0067E2 EB               [12] 3355 	mov	a,r3
      0067E3 60 1A            [24] 3356 	jz	00129$
      0067E5 7B 28            [12] 3357 	mov	r3,#0x28
      0067E7                       3358 00141$:
      0067E7 EB               [12] 3359 	mov	a,r3
      0067E8 60 DF            [24] 3360 	jz	00127$
      0067EA 90 00 01         [24] 3361 	mov	dptr,#0x0001
      0067ED C0 07            [24] 3362 	push	ar7
      0067EF C0 06            [24] 3363 	push	ar6
      0067F1 C0 03            [24] 3364 	push	ar3
      0067F3 12 58 7C         [24] 3365 	lcall	_mDelayuS
      0067F6 D0 03            [24] 3366 	pop	ar3
      0067F8 D0 06            [24] 3367 	pop	ar6
      0067FA D0 07            [24] 3368 	pop	ar7
      0067FC 1B               [12] 3369 	dec	r3
      0067FD 80 E8            [24] 3370 	sjmp	00141$
      0067FF                       3371 00129$:
                                   3372 ;	tmk_core/protocol/ch555/usb_ak820.c:508: saved_ea = EA;
      0067FF A2 AF            [12] 3373 	mov	c,_EA
      006801 E4               [12] 3374 	clr	a
      006802 33               [12] 3375 	rlc	a
      006803 FF               [12] 3376 	mov	r7,a
                                   3377 ;	tmk_core/protocol/ch555/usb_ak820.c:509: EA = 0;
                                   3378 ;	assignBit
      006804 C2 AF            [12] 3379 	clr	_EA
                                   3380 ;	tmk_core/protocol/ch555/usb_ak820.c:510: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006806 90 07 5C         [24] 3381 	mov	dptr,#_USB_EnumStatus
      006809 E0               [24] 3382 	movx	a,@dptr
      00680A 60 25            [24] 3383 	jz	00130$
      00680C 90 07 C4         [24] 3384 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      00680F E0               [24] 3385 	movx	a,@dptr
      006810 FB               [12] 3386 	mov	r3,a
      006811 F9               [12] 3387 	mov	r1,a
      006812 7A 00            [12] 3388 	mov	r2,#0x00
      006814 74 22            [12] 3389 	mov	a,#0x22
      006816 2A               [12] 3390 	add	a, r2
      006817 FA               [12] 3391 	mov	r2,a
      006818 89 82            [24] 3392 	mov	dpl,r1
      00681A 8A 83            [24] 3393 	mov	dph,r2
      00681C E0               [24] 3394 	movx	a,@dptr
      00681D FA               [12] 3395 	mov	r2,a
      00681E 53 02 03         [24] 3396 	anl	ar2,#0x03
      006821 BA 02 0D         [24] 3397 	cjne	r2,#0x02,00130$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:511: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006824 BB 03 13         [24] 3399 	cjne	r3,#0x03,00192$
      006827 90 07 63         [24] 3400 	mov	dptr,#_raw_state
      00682A E0               [24] 3401 	movx	a,@dptr
      00682B FB               [12] 3402 	mov	r3,a
      00682C BB 03 02         [24] 3403 	cjne	r3,#0x03,00331$
      00682F 80 09            [24] 3404 	sjmp	00192$
      006831                       3405 00331$:
      006831                       3406 00130$:
                                   3407 ;	assignBit
      006831 EF               [12] 3408 	mov	a,r7
      006832 24 FF            [12] 3409 	add	a,#0xff
      006834 92 AF            [24] 3410 	mov	_EA,c
      006836 75 82 00         [24] 3411 	mov	dpl, #0x00
      006839 22               [24] 3412 	ret
                                   3413 ;	tmk_core/protocol/ch555/usb_ak820.c:512: for (i = 0; i < length; ++i) {
      00683A                       3414 00192$:
      00683A 7B 00            [12] 3415 	mov	r3,#0x00
      00683C                       3416 00144$:
      00683C C3               [12] 3417 	clr	c
      00683D EB               [12] 3418 	mov	a,r3
      00683E 9E               [12] 3419 	subb	a,r6
      00683F 50 67            [24] 3420 	jnc	00137$
                                   3421 ;	tmk_core/protocol/ch555/usb_ak820.c:513: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006841 C0 07            [24] 3422 	push	ar7
      006843 90 07 C4         [24] 3423 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006846 E0               [24] 3424 	movx	a,@dptr
      006847 F9               [12] 3425 	mov	r1,a
      006848 E4               [12] 3426 	clr	a
      006849 C3               [12] 3427 	clr	c
      00684A C9               [12] 3428 	xch	a,r1
      00684B 13               [12] 3429 	rrc	a
      00684C C9               [12] 3430 	xch	a,r1
      00684D 13               [12] 3431 	rrc	a
      00684E A2 E0            [12] 3432 	mov	c,acc.0
      006850 C9               [12] 3433 	xch	a,r1
      006851 13               [12] 3434 	rrc	a
      006852 C9               [12] 3435 	xch	a,r1
      006853 13               [12] 3436 	rrc	a
      006854 C9               [12] 3437 	xch	a,r1
      006855 FA               [12] 3438 	mov	r2,a
      006856 8B 00            [24] 3439 	mov	ar0,r3
      006858 7F 00            [12] 3440 	mov	r7,#0x00
      00685A E8               [12] 3441 	mov	a,r0
      00685B 29               [12] 3442 	add	a, r1
      00685C F9               [12] 3443 	mov	r1,a
      00685D EF               [12] 3444 	mov	a,r7
      00685E 3A               [12] 3445 	addc	a, r2
      00685F 24 10            [12] 3446 	add	a,#0x10
      006861 FA               [12] 3447 	mov	r2,a
      006862 90 07 C1         [24] 3448 	mov	dptr,#_ak820_usb_send_PARM_2
      006865 E0               [24] 3449 	movx	a,@dptr
      006866 F8               [12] 3450 	mov	r0,a
      006867 A3               [24] 3451 	inc	dptr
      006868 E0               [24] 3452 	movx	a,@dptr
      006869 FF               [12] 3453 	mov	r7,a
      00686A EB               [12] 3454 	mov	a,r3
      00686B 28               [12] 3455 	add	a, r0
      00686C F5 2B            [12] 3456 	mov	_ak820_usb_send_sloc0_1_0,a
      00686E E4               [12] 3457 	clr	a
      00686F 3F               [12] 3458 	addc	a, r7
      006870 F5 2C            [12] 3459 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006872 85 2B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006875 85 2C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006878 E0               [24] 3462 	movx	a,@dptr
      006879 89 82            [24] 3463 	mov	dpl,r1
      00687B 8A 83            [24] 3464 	mov	dph,r2
      00687D F0               [24] 3465 	movx	@dptr,a
                                   3466 ;	tmk_core/protocol/ch555/usb_ak820.c:514: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00687E 90 07 C5         [24] 3467 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006881 E0               [24] 3468 	movx	a,@dptr
      006882 F5 2D            [12] 3469 	mov	_ak820_usb_send_sloc1_1_0,a
      006884 74 2E            [12] 3470 	mov	a,#0x2e
      006886 B5 2D 04         [24] 3471 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006889 D0 07            [24] 3472 	pop	ar7
      00688B 80 18            [24] 3473 	sjmp	00145$
      00688D                       3474 00333$:
      00688D D0 07            [24] 3475 	pop	ar7
      00688F EB               [12] 3476 	mov	a,r3
      006890 25 2D            [12] 3477 	add	a, _ak820_usb_send_sloc1_1_0
      006892 24 86            [12] 3478 	add	a, #_input_snapshot
      006894 F9               [12] 3479 	mov	r1,a
      006895 E4               [12] 3480 	clr	a
      006896 34 07            [12] 3481 	addc	a,#(_input_snapshot >> 8)
      006898 FA               [12] 3482 	mov	r2,a
      006899 85 2B 82         [24] 3483 	mov	dpl,_ak820_usb_send_sloc0_1_0
      00689C 85 2C 83         [24] 3484 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00689F E0               [24] 3485 	movx	a,@dptr
      0068A0 89 82            [24] 3486 	mov	dpl,r1
      0068A2 8A 83            [24] 3487 	mov	dph,r2
      0068A4 F0               [24] 3488 	movx	@dptr,a
      0068A5                       3489 00145$:
                                   3490 ;	tmk_core/protocol/ch555/usb_ak820.c:512: for (i = 0; i < length; ++i) {
      0068A5 0B               [12] 3491 	inc	r3
      0068A6 80 94            [24] 3492 	sjmp	00144$
      0068A8                       3493 00137$:
                                   3494 ;	tmk_core/protocol/ch555/usb_ak820.c:516: EP_LENGTH(endpoint) = length;
      0068A8 90 07 C4         [24] 3495 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      0068AB E0               [24] 3496 	movx	a,@dptr
      0068AC FB               [12] 3497 	mov	r3,a
      0068AD F9               [12] 3498 	mov	r1,a
      0068AE 7A 00            [12] 3499 	mov	r2,#0x00
      0068B0 74 08            [12] 3500 	mov	a,#0x08
      0068B2 29               [12] 3501 	add	a, r1
      0068B3 F9               [12] 3502 	mov	r1,a
      0068B4 74 22            [12] 3503 	mov	a,#0x22
      0068B6 3A               [12] 3504 	addc	a, r2
      0068B7 FA               [12] 3505 	mov	r2,a
      0068B8 89 82            [24] 3506 	mov	dpl,r1
      0068BA 8A 83            [24] 3507 	mov	dph,r2
      0068BC EE               [12] 3508 	mov	a,r6
      0068BD F0               [24] 3509 	movx	@dptr,a
                                   3510 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      0068BE BB 03 06         [24] 3511 	cjne	r3,#0x03,00139$
      0068C1 90 07 63         [24] 3512 	mov	dptr,#_raw_state
      0068C4 74 04            [12] 3513 	mov	a,#0x04
      0068C6 F0               [24] 3514 	movx	@dptr,a
      0068C7                       3515 00139$:
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:518: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0068C7 74 22            [12] 3517 	mov	a,#0x22
      0068C9 2D               [12] 3518 	add	a, r5
      0068CA FD               [12] 3519 	mov	r5,a
      0068CB 8C 82            [24] 3520 	mov	dpl,r4
      0068CD 8D 83            [24] 3521 	mov	dph,r5
      0068CF E0               [24] 3522 	movx	a,@dptr
      0068D0 FE               [12] 3523 	mov	r6,a
      0068D1 53 06 FC         [24] 3524 	anl	ar6,#0xfc
      0068D4 8C 82            [24] 3525 	mov	dpl,r4
      0068D6 8D 83            [24] 3526 	mov	dph,r5
      0068D8 EE               [12] 3527 	mov	a,r6
      0068D9 F0               [24] 3528 	movx	@dptr,a
                                   3529 ;	tmk_core/protocol/ch555/usb_ak820.c:519: EA = saved_ea;
                                   3530 ;	assignBit
      0068DA EF               [12] 3531 	mov	a,r7
      0068DB 24 FF            [12] 3532 	add	a,#0xff
      0068DD 92 AF            [24] 3533 	mov	_EA,c
                                   3534 ;	tmk_core/protocol/ch555/usb_ak820.c:520: return true;
      0068DF 75 82 01         [24] 3535 	mov	dpl, #0x01
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:521: }
      0068E2 22               [24] 3537 	ret
                                   3538 ;------------------------------------------------------------
                                   3539 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3540 ;------------------------------------------------------------
                                   3541 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3542 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3543 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_442'
                                   3544 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_443'
                                   3545 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_443'
                                   3546 ;------------------------------------------------------------
                                   3547 ;	tmk_core/protocol/ch555/usb_ak820.c:523: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3548 ;	-----------------------------------------
                                   3549 ;	 function ak820_usb_try_send
                                   3550 ;	-----------------------------------------
      0068E3                       3551 _ak820_usb_try_send:
      0068E3 E5 82            [12] 3552 	mov	a,dpl
      0068E5 90 07 C9         [24] 3553 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_442
      0068E8 F0               [24] 3554 	movx	@dptr,a
                                   3555 ;	tmk_core/protocol/ch555/usb_ak820.c:524: uint8_t saved_ea = EA;
                                   3556 ;	assignBit
      0068E9 A2 AF            [12] 3557 	mov	c,_EA
      0068EB 92 15            [24] 3558 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3559 ;	tmk_core/protocol/ch555/usb_ak820.c:525: bool sent = false;
      0068ED 90 07 CA         [24] 3560 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      0068F0 E4               [12] 3561 	clr	a
      0068F1 F0               [24] 3562 	movx	@dptr,a
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:526: EA = 0;
                                   3564 ;	assignBit
      0068F2 C2 AF            [12] 3565 	clr	_EA
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:530: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0068F4 90 07 C9         [24] 3567 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_442
      0068F7 E0               [24] 3568 	movx	a,@dptr
      0068F8 FF               [12] 3569 	mov	r7,a
      0068F9 BF 01 00         [24] 3570 	cjne	r7,#0x01,00152$
      0068FC                       3571 00152$:
      0068FC 40 4E            [24] 3572 	jc	00102$
      0068FE EF               [12] 3573 	mov	a,r7
      0068FF 24 FD            [12] 3574 	add	a,#0xff - 0x02
      006901 40 49            [24] 3575 	jc	00102$
                                   3576 ;	free result
      006903 90 07 5C         [24] 3577 	mov	dptr,#_USB_EnumStatus
      006906 E0               [24] 3578 	movx	a,@dptr
      006907 60 43            [24] 3579 	jz	00102$
                                   3580 ;	tmk_core/protocol/ch555/usb_ak820.c:531: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006909 90 07 5D         [24] 3581 	mov	dptr,#_USB_SleepStatus
      00690C E0               [24] 3582 	movx	a,@dptr
      00690D 20 E1 3C         [24] 3583 	jb	acc.1,00102$
      006910 90 07 85         [24] 3584 	mov	dptr,#_keyboard_reset
      006913 E0               [24] 3585 	movx	a,@dptr
                                   3586 ;	tmk_core/protocol/ch555/usb_ak820.c:532: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006914 70 36            [24] 3587 	jnz	00102$
      006916 8F 06            [24] 3588 	mov	ar6,r7
      006918 24 22            [12] 3589 	add	a,#0x22
      00691A FD               [12] 3590 	mov	r5,a
      00691B 8E 82            [24] 3591 	mov	dpl,r6
      00691D 8D 83            [24] 3592 	mov	dph,r5
      00691F E0               [24] 3593 	movx	a,@dptr
      006920 FE               [12] 3594 	mov	r6,a
      006921 53 06 03         [24] 3595 	anl	ar6,#0x03
      006924 BE 02 25         [24] 3596 	cjne	r6,#0x02,00102$
                                   3597 ;	tmk_core/protocol/ch555/usb_ak820.c:533: sent = ak820_usb_send(endpoint, report, length);
      006927 90 07 C6         [24] 3598 	mov	dptr,#_ak820_usb_try_send_PARM_2
      00692A E0               [24] 3599 	movx	a,@dptr
      00692B FD               [12] 3600 	mov	r5,a
      00692C A3               [24] 3601 	inc	dptr
      00692D E0               [24] 3602 	movx	a,@dptr
      00692E FE               [12] 3603 	mov	r6,a
      00692F 90 07 C8         [24] 3604 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006932 E0               [24] 3605 	movx	a,@dptr
      006933 FC               [12] 3606 	mov	r4,a
      006934 90 07 C1         [24] 3607 	mov	dptr,#_ak820_usb_send_PARM_2
      006937 ED               [12] 3608 	mov	a,r5
      006938 F0               [24] 3609 	movx	@dptr,a
      006939 EE               [12] 3610 	mov	a,r6
      00693A A3               [24] 3611 	inc	dptr
      00693B F0               [24] 3612 	movx	@dptr,a
      00693C 90 07 C3         [24] 3613 	mov	dptr,#_ak820_usb_send_PARM_3
      00693F EC               [12] 3614 	mov	a,r4
      006940 F0               [24] 3615 	movx	@dptr,a
      006941 8F 82            [24] 3616 	mov	dpl, r7
      006943 12 67 3C         [24] 3617 	lcall	_ak820_usb_send
      006946 E5 82            [12] 3618 	mov	a, dpl
      006948 90 07 CA         [24] 3619 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      00694B F0               [24] 3620 	movx	@dptr,a
      00694C                       3621 00102$:
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:535: EA = saved_ea;
                                   3623 ;	assignBit
      00694C A2 15            [12] 3624 	mov	c,_ak820_usb_try_send_sloc0_1_0
      00694E 92 AF            [24] 3625 	mov	_EA,c
                                   3626 ;	tmk_core/protocol/ch555/usb_ak820.c:536: return sent;
      006950 90 07 CA         [24] 3627 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      006953 E0               [24] 3628 	movx	a,@dptr
                                   3629 ;	tmk_core/protocol/ch555/usb_ak820.c:537: }
      006954 F5 82            [12] 3630 	mov	dpl,a
      006956 22               [24] 3631 	ret
                                   3632 ;------------------------------------------------------------
                                   3633 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3634 ;------------------------------------------------------------
                                   3635 ;	tmk_core/protocol/ch555/usb_ak820.c:542: static bool raw_request_is_nonpersistent(void) {
                                   3636 ;	-----------------------------------------
                                   3637 ;	 function raw_request_is_nonpersistent
                                   3638 ;	-----------------------------------------
      006957                       3639 _raw_request_is_nonpersistent:
                                   3640 ;	tmk_core/protocol/ch555/usb_ak820.c:543: switch (raw_buffer[0]) {
      006957 90 07 64         [24] 3641 	mov	dptr,#_raw_buffer
      00695A E0               [24] 3642 	movx	a,@dptr
      00695B FF               [12] 3643 	mov	r7,a
      00695C BF 01 02         [24] 3644 	cjne	r7,#0x01,00302$
      00695F 80 35            [24] 3645 	sjmp	00108$
      006961                       3646 00302$:
      006961 BF 02 02         [24] 3647 	cjne	r7,#0x02,00303$
      006964 80 34            [24] 3648 	sjmp	00109$
      006966                       3649 00303$:
      006966 BF 04 02         [24] 3650 	cjne	r7,#0x04,00304$
      006969 80 2B            [24] 3651 	sjmp	00108$
      00696B                       3652 00304$:
      00696B BF 08 02         [24] 3653 	cjne	r7,#0x08,00305$
      00696E 80 47            [24] 3654 	sjmp	00116$
      006970                       3655 00305$:
      006970 BF 0B 02         [24] 3656 	cjne	r7,#0x0b,00306$
      006973 80 21            [24] 3657 	sjmp	00108$
      006975                       3658 00306$:
      006975 BF 0C 02         [24] 3659 	cjne	r7,#0x0c,00307$
      006978 80 1C            [24] 3660 	sjmp	00108$
      00697A                       3661 00307$:
      00697A BF 0D 02         [24] 3662 	cjne	r7,#0x0d,00308$
      00697D 80 17            [24] 3663 	sjmp	00108$
      00697F                       3664 00308$:
      00697F BF 0E 02         [24] 3665 	cjne	r7,#0x0e,00309$
      006982 80 12            [24] 3666 	sjmp	00108$
      006984                       3667 00309$:
      006984 BF 11 02         [24] 3668 	cjne	r7,#0x11,00310$
      006987 80 0D            [24] 3669 	sjmp	00108$
      006989                       3670 00310$:
      006989 BF 12 02         [24] 3671 	cjne	r7,#0x12,00311$
      00698C 80 08            [24] 3672 	sjmp	00108$
      00698E                       3673 00311$:
      00698E BF FE 02         [24] 3674 	cjne	r7,#0xfe,00312$
      006991 80 46            [24] 3675 	sjmp	00124$
      006993                       3676 00312$:
      006993 02 6A 2E         [24] 3677 	ljmp	00144$
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:551: case id_bootloader_jump:
      006996                       3679 00108$:
                                   3680 ;	tmk_core/protocol/ch555/usb_ak820.c:552: return true;
      006996 75 82 01         [24] 3681 	mov	dpl, #0x01
      006999 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:553: case id_get_keyboard_value:
      00699A                       3684 00109$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:554: switch (raw_buffer[1]) {
      00699A 12 6C 5B         [24] 3686 	lcall	_ak820_outline_0121
      00699D BF 01 02         [24] 3687 	cjne	r7,#0x01,00313$
      0069A0 80 0D            [24] 3688 	sjmp	00113$
      0069A2                       3689 00313$:
      0069A2 BF 02 02         [24] 3690 	cjne	r7,#0x02,00314$
      0069A5 80 08            [24] 3691 	sjmp	00113$
      0069A7                       3692 00314$:
      0069A7 BF 03 02         [24] 3693 	cjne	r7,#0x03,00315$
      0069AA 80 03            [24] 3694 	sjmp	00113$
      0069AC                       3695 00315$:
      0069AC BF 04 04         [24] 3696 	cjne	r7,#0x04,00114$
                                   3697 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_firmware_version:
      0069AF                       3698 00113$:
                                   3699 ;	tmk_core/protocol/ch555/usb_ak820.c:559: return true;
      0069AF 75 82 01         [24] 3700 	mov	dpl, #0x01
      0069B2 22               [24] 3701 	ret
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:560: default: return false;
      0069B3                       3703 00114$:
      0069B3 75 82 00         [24] 3704 	mov	dpl, #0x00
      0069B6 22               [24] 3705 	ret
                                   3706 ;	tmk_core/protocol/ch555/usb_ak820.c:562: case id_lighting_get_value:
      0069B7                       3707 00116$:
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:563: switch (raw_buffer[1]) {
      0069B7 12 6C 5B         [24] 3709 	lcall	_ak820_outline_0121
      0069BA BF 40 02         [24] 3710 	cjne	r7,#0x40,00318$
      0069BD 80 12            [24] 3711 	sjmp	00121$
      0069BF                       3712 00318$:
      0069BF BF 41 02         [24] 3713 	cjne	r7,#0x41,00319$
      0069C2 80 0D            [24] 3714 	sjmp	00121$
      0069C4                       3715 00319$:
      0069C4 BF 42 02         [24] 3716 	cjne	r7,#0x42,00320$
      0069C7 80 08            [24] 3717 	sjmp	00121$
      0069C9                       3718 00320$:
      0069C9 BF 43 02         [24] 3719 	cjne	r7,#0x43,00321$
      0069CC 80 03            [24] 3720 	sjmp	00121$
      0069CE                       3721 00321$:
      0069CE BF 44 04         [24] 3722 	cjne	r7,#0x44,00122$
                                   3723 ;	tmk_core/protocol/ch555/usb_ak820.c:568: case vialrgb_get_led_info:
      0069D1                       3724 00121$:
                                   3725 ;	tmk_core/protocol/ch555/usb_ak820.c:569: return true;
      0069D1 75 82 01         [24] 3726 	mov	dpl, #0x01
                                   3727 ;	tmk_core/protocol/ch555/usb_ak820.c:570: default: return false;
      0069D4 22               [24] 3728 	ret
      0069D5                       3729 00122$:
      0069D5 75 82 00         [24] 3730 	mov	dpl, #0x00
                                   3731 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_vial_prefix:
      0069D8 22               [24] 3732 	ret
      0069D9                       3733 00124$:
                                   3734 ;	tmk_core/protocol/ch555/usb_ak820.c:573: switch (raw_buffer[1]) {
      0069D9 12 6C 5B         [24] 3735 	lcall	_ak820_outline_0121
      0069DC 24 F2            [12] 3736 	add	a,#0xff - 0x0d
      0069DE 40 4A            [24] 3737 	jc	00142$
                                   3738 ;	free result
      0069E0 EF               [12] 3739 	mov	a,r7
      0069E1 24 0A            [12] 3740 	add	a,#(00325$-3-.)
      0069E3 83               [24] 3741 	movc	a,@a+pc
      0069E4 F5 82            [12] 3742 	mov	dpl,a
      0069E6 EF               [12] 3743 	mov	a,r7
      0069E7 24 12            [12] 3744 	add	a,#(00326$-3-.)
      0069E9 83               [24] 3745 	movc	a,@a+pc
      0069EA F5 83            [12] 3746 	mov	dph,a
      0069EC E4               [12] 3747 	clr	a
      0069ED 73               [24] 3748 	jmp	@a+dptr
      0069EE                       3749 00325$:
      0069EE 0A                    3750 	.db	00134$
      0069EF 0A                    3751 	.db	00134$
      0069F0 0A                    3752 	.db	00134$
      0069F1 0A                    3753 	.db	00134$
      0069F2 2A                    3754 	.db	00142$
      0069F3 0A                    3755 	.db	00134$
      0069F4 0A                    3756 	.db	00134$
      0069F5 0A                    3757 	.db	00134$
      0069F6 0A                    3758 	.db	00134$
      0069F7 0A                    3759 	.db	00134$
      0069F8 0A                    3760 	.db	00134$
      0069F9 2A                    3761 	.db	00142$
      0069FA 2A                    3762 	.db	00142$
      0069FB 0E                    3763 	.db	00135$
      0069FC                       3764 00326$:
      0069FC 6A                    3765 	.db	00134$>>8
      0069FD 6A                    3766 	.db	00134$>>8
      0069FE 6A                    3767 	.db	00134$>>8
      0069FF 6A                    3768 	.db	00134$>>8
      006A00 6A                    3769 	.db	00142$>>8
      006A01 6A                    3770 	.db	00134$>>8
      006A02 6A                    3771 	.db	00134$>>8
      006A03 6A                    3772 	.db	00134$>>8
      006A04 6A                    3773 	.db	00134$>>8
      006A05 6A                    3774 	.db	00134$>>8
      006A06 6A                    3775 	.db	00134$>>8
      006A07 6A                    3776 	.db	00142$>>8
      006A08 6A                    3777 	.db	00142$>>8
      006A09 6A                    3778 	.db	00135$>>8
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:583: case vial_qmk_settings_get:
      006A0A                       3780 00134$:
                                   3781 ;	tmk_core/protocol/ch555/usb_ak820.c:584: return true;
      006A0A 75 82 01         [24] 3782 	mov	dpl, #0x01
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:585: case vial_dynamic_entry_op:
      006A0D 22               [24] 3784 	ret
      006A0E                       3785 00135$:
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:586: switch (raw_buffer[2]) {
      006A0E 90 07 66         [24] 3787 	mov	dptr,#(_raw_buffer + 0x0002)
      006A11 E0               [24] 3788 	movx	a,@dptr
      006A12 FF               [12] 3789 	mov	r7,a
      006A13 60 0D            [24] 3790 	jz	00139$
      006A15 BF 01 02         [24] 3791 	cjne	r7,#0x01,00328$
      006A18 80 08            [24] 3792 	sjmp	00139$
      006A1A                       3793 00328$:
      006A1A BF 03 02         [24] 3794 	cjne	r7,#0x03,00329$
      006A1D 80 03            [24] 3795 	sjmp	00139$
      006A1F                       3796 00329$:
      006A1F BF 05 04         [24] 3797 	cjne	r7,#0x05,00140$
                                   3798 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case dynamic_vial_key_override_get:
      006A22                       3799 00139$:
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:591: return true;
      006A22 75 82 01         [24] 3801 	mov	dpl, #0x01
                                   3802 ;	tmk_core/protocol/ch555/usb_ak820.c:592: default: return false;
      006A25 22               [24] 3803 	ret
      006A26                       3804 00140$:
      006A26 75 82 00         [24] 3805 	mov	dpl, #0x00
                                   3806 ;	tmk_core/protocol/ch555/usb_ak820.c:594: default: return false;
      006A29 22               [24] 3807 	ret
      006A2A                       3808 00142$:
      006A2A 75 82 00         [24] 3809 	mov	dpl, #0x00
                                   3810 ;	tmk_core/protocol/ch555/usb_ak820.c:596: default: return false;
      006A2D 22               [24] 3811 	ret
      006A2E                       3812 00144$:
      006A2E 75 82 00         [24] 3813 	mov	dpl, #0x00
                                   3814 ;	tmk_core/protocol/ch555/usb_ak820.c:597: }
                                   3815 ;	tmk_core/protocol/ch555/usb_ak820.c:598: }
      006A31 22               [24] 3816 	ret
                                   3817 ;------------------------------------------------------------
                                   3818 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3819 ;------------------------------------------------------------
                                   3820 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3821 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_458'
                                   3822 ;------------------------------------------------------------
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:600: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3824 ;	-----------------------------------------
                                   3825 ;	 function ak820_usb_raw_send
                                   3826 ;	-----------------------------------------
      006A32                       3827 _ak820_usb_raw_send:
      006A32 12 43 D8         [24] 3828 	lcall	_ak820_outline_0004
      006A35 90 07 CC         [24] 3829 	mov	dptr,#_ak820_usb_raw_send_report_10000_458
      006A38 12 43 CB         [24] 3830 	lcall	_ak820_outline_0001
                                   3831 ;	tmk_core/protocol/ch555/usb_ak820.c:601: if (length != RAW_EPSIZE) return;
      006A3B 90 07 CB         [24] 3832 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006A3E E0               [24] 3833 	movx	a,@dptr
      006A3F FF               [12] 3834 	mov	r7,a
      006A40 BF 20 2B         [24] 3835 	cjne	r7,#0x20,00106$
                                   3836 ;	tmk_core/protocol/ch555/usb_ak820.c:602: ak820_nvm_flush();
      006A43 C0 07            [24] 3837 	push	ar7
      006A45 12 3E 92         [24] 3838 	lcall	_ak820_nvm_flush
      006A48 D0 07            [24] 3839 	pop	ar7
                                   3840 ;	tmk_core/protocol/ch555/usb_ak820.c:603: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006A4A 90 07 84         [24] 3841 	mov	dptr,#_raw_reply_without_nvm
      006A4D E0               [24] 3842 	movx	a,@dptr
      006A4E 70 07            [24] 3843 	jnz	00103$
      006A50 12 3E 7C         [24] 3844 	lcall	_ak820_nvm_ok
      006A53 E5 82            [12] 3845 	mov	a, dpl
      006A55 60 17            [24] 3846 	jz	00106$
      006A57                       3847 00103$:
      006A57 90 07 CC         [24] 3848 	mov	dptr,#_ak820_usb_raw_send_report_10000_458
      006A5A 12 44 17         [24] 3849 	lcall	_ak820_outline_0025
      006A5D 90 07 C1         [24] 3850 	mov	dptr,#_ak820_usb_send_PARM_2
      006A60 12 44 56         [24] 3851 	lcall	_ak820_outline_0071
      006A63 90 07 C3         [24] 3852 	mov	dptr,#_ak820_usb_send_PARM_3
      006A66 EF               [12] 3853 	mov	a,r7
      006A67 F0               [24] 3854 	movx	@dptr,a
      006A68 75 82 03         [24] 3855 	mov	dpl, #0x03
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:604: }
      006A6B 02 67 3C         [24] 3857 	ljmp	_ak820_usb_send
      006A6E                       3858 00106$:
      006A6E 22               [24] 3859 	ret
                                   3860 ;------------------------------------------------------------
                                   3861 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3862 ;------------------------------------------------------------
                                   3863 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3864 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_463'
                                   3865 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_463'
                                   3866 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_463'
                                   3867 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_463'
                                   3868 ;------------------------------------------------------------
                                   3869 ;	tmk_core/protocol/ch555/usb_ak820.c:606: void ak820_usb_raw_task(void) {
                                   3870 ;	-----------------------------------------
                                   3871 ;	 function ak820_usb_raw_task
                                   3872 ;	-----------------------------------------
      006A6F                       3873 _ak820_usb_raw_task:
                                   3874 ;	tmk_core/protocol/ch555/usb_ak820.c:610: uint8_t saved_ea = EA;
      006A6F A2 AF            [12] 3875 	mov	c,_EA
      006A71 E4               [12] 3876 	clr	a
      006A72 33               [12] 3877 	rlc	a
      006A73 FF               [12] 3878 	mov	r7,a
                                   3879 ;	tmk_core/protocol/ch555/usb_ak820.c:611: EA = 0;
                                   3880 ;	assignBit
      006A74 C2 AF            [12] 3881 	clr	_EA
                                   3882 ;	tmk_core/protocol/ch555/usb_ak820.c:612: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006A76 90 07 5C         [24] 3883 	mov	dptr,#_USB_EnumStatus
      006A79 E0               [24] 3884 	movx	a,@dptr
      006A7A 60 0A            [24] 3885 	jz	00101$
      006A7C 90 07 63         [24] 3886 	mov	dptr,#_raw_state
      006A7F E0               [24] 3887 	movx	a,@dptr
      006A80 FE               [12] 3888 	mov	r6,a
      006A81 BE 02 02         [24] 3889 	cjne	r6,#0x02,00270$
      006A84 80 06            [24] 3890 	sjmp	00102$
      006A86                       3891 00270$:
      006A86                       3892 00101$:
                                   3893 ;	assignBit
      006A86 EF               [12] 3894 	mov	a,r7
      006A87 24 FF            [12] 3895 	add	a,#0xff
      006A89 92 AF            [24] 3896 	mov	_EA,c
      006A8B 22               [24] 3897 	ret
      006A8C                       3898 00102$:
                                   3899 ;	tmk_core/protocol/ch555/usb_ak820.c:613: raw_state = RAW_WORK;
      006A8C 90 07 63         [24] 3900 	mov	dptr,#_raw_state
      006A8F 74 03            [12] 3901 	mov	a,#0x03
      006A91 F0               [24] 3902 	movx	@dptr,a
                                   3903 ;	tmk_core/protocol/ch555/usb_ak820.c:614: EA = saved_ea;
                                   3904 ;	assignBit
      006A92 EF               [12] 3905 	mov	a,r7
      006A93 24 FF            [12] 3906 	add	a,#0xff
      006A95 92 AF            [24] 3907 	mov	_EA,c
                                   3908 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006A97 90 07 64         [24] 3909 	mov	dptr,#_raw_buffer
      006A9A E0               [24] 3910 	movx	a,@dptr
      006A9B FF               [12] 3911 	mov	r7,a
      006A9C E4               [12] 3912 	clr	a
      006A9D BF FD 01         [24] 3913 	cjne	r7,#0xfd,00271$
      006AA0 04               [12] 3914 	inc	a
      006AA1                       3915 00271$:
      006AA1 FF               [12] 3916 	mov	r7,a
      006AA2 70 03            [24] 3917 	jnz	00273$
      006AA4 02 6B 45         [24] 3918 	ljmp	00118$
      006AA7                       3919 00273$:
      006AA7 90 07 65         [24] 3920 	mov	dptr,#(_raw_buffer + 0x0001)
      006AAA E0               [24] 3921 	movx	a,@dptr
      006AAB 60 03            [24] 3922 	jz	00274$
      006AAD 02 6B 45         [24] 3923 	ljmp	00118$
      006AB0                       3924 00274$:
                                   3925 ;	tmk_core/protocol/ch555/usb_ak820.c:618: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006AB0 90 07 66         [24] 3926 	mov	dptr,#(_raw_buffer + 0x0002)
      006AB3 E0               [24] 3927 	movx	a,@dptr
      006AB4 FD               [12] 3928 	mov	r5,a
      006AB5 7E 00            [12] 3929 	mov	r6,#0x00
      006AB7 90 07 67         [24] 3930 	mov	dptr,#(_raw_buffer + 0x0003)
      006ABA E0               [24] 3931 	movx	a,@dptr
      006ABB 7B 00            [12] 3932 	mov	r3,#0x00
      006ABD 42 06            [12] 3933 	orl	ar6,a
      006ABF EB               [12] 3934 	mov	a,r3
      006AC0 42 05            [12] 3935 	orl	ar5,a
                                   3936 ;	tmk_core/protocol/ch555/usb_ak820.c:619: length = raw_buffer[4];
      006AC2 90 07 68         [24] 3937 	mov	dptr,#(_raw_buffer + 0x0004)
      006AC5 E0               [24] 3938 	movx	a,@dptr
      006AC6 FC               [12] 3939 	mov	r4,a
                                   3940 ;	tmk_core/protocol/ch555/usb_ak820.c:620: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006AC7 7B 05            [12] 3941 	mov	r3,#0x05
      006AC9                       3942 00128$:
      006AC9 EB               [12] 3943 	mov	a,r3
      006ACA 12 6C 4F         [24] 3944 	lcall	_ak820_outline_0081
      006ACD 0B               [12] 3945 	inc	r3
      006ACE BB 20 00         [24] 3946 	cjne	r3,#0x20,00275$
      006AD1                       3947 00275$:
      006AD1 40 F6            [24] 3948 	jc	00128$
                                   3949 ;	tmk_core/protocol/ch555/usb_ak820.c:621: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006AD3 EC               [12] 3950 	mov	a,r4
      006AD4 24 E4            [12] 3951 	add	a,#0xff - 0x1b
      006AD6 40 1C            [24] 3952 	jc	00106$
                                   3953 ;	free result
      006AD8 EC               [12] 3954 	mov	a,r4
      006AD9 60 26            [24] 3955 	jz	00165$
      006ADB 8C 03            [24] 3956 	mov	ar3,r4
      006ADD 1B               [12] 3957 	dec	r3
      006ADE 7A 00            [12] 3958 	mov	r2,#0x00
      006AE0 74 FF            [12] 3959 	mov	a,#0xff
      006AE2 C3               [12] 3960 	clr	c
      006AE3 9B               [12] 3961 	subb	a,r3
      006AE4 FB               [12] 3962 	mov	r3,a
      006AE5 74 FF            [12] 3963 	mov	a,#0xff
      006AE7 9A               [12] 3964 	subb	a,r2
      006AE8 FA               [12] 3965 	mov	r2,a
      006AE9 8E 00            [24] 3966 	mov	ar0,r6
      006AEB 8D 01            [24] 3967 	mov	ar1,r5
      006AED C3               [12] 3968 	clr	c
      006AEE EB               [12] 3969 	mov	a,r3
      006AEF 98               [12] 3970 	subb	a,r0
      006AF0 EA               [12] 3971 	mov	a,r2
      006AF1 99               [12] 3972 	subb	a,r1
      006AF2 50 0D            [24] 3973 	jnc	00165$
                                   3974 ;	free result
      006AF4                       3975 00106$:
                                   3976 ;	tmk_core/protocol/ch555/usb_ak820.c:622: raw_buffer[1] = 0xff;
      006AF4 90 07 65         [24] 3977 	mov	dptr,#(_raw_buffer + 0x0001)
      006AF7 74 FF            [12] 3978 	mov	a,#0xff
      006AF9 F0               [24] 3979 	movx	@dptr,a
                                   3980 ;	tmk_core/protocol/ch555/usb_ak820.c:623: raw_buffer[4] = 0;
      006AFA 90 07 68         [24] 3981 	mov	dptr,#(_raw_buffer + 0x0004)
      006AFD E4               [12] 3982 	clr	a
      006AFE F0               [24] 3983 	movx	@dptr,a
                                   3984 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006AFF 80 3B            [24] 3985 	sjmp	00108$
      006B01                       3986 00165$:
      006B01 7B 00            [12] 3987 	mov	r3,#0x00
      006B03                       3988 00131$:
      006B03 C3               [12] 3989 	clr	c
      006B04 EB               [12] 3990 	mov	a,r3
      006B05 9C               [12] 3991 	subb	a,r4
      006B06 50 34            [24] 3992 	jnc	00108$
      006B08 C0 04            [24] 3993 	push	ar4
      006B0A 8B 02            [24] 3994 	mov	ar2,r3
      006B0C 74 05            [12] 3995 	mov	a,#0x05
      006B0E 2A               [12] 3996 	add	a, r2
      006B0F F9               [12] 3997 	mov	r1,a
      006B10 33               [12] 3998 	rlc	a
      006B11 95 E0            [12] 3999 	subb	a,acc
      006B13 FA               [12] 4000 	mov	r2,a
      006B14 E9               [12] 4001 	mov	a,r1
      006B15 24 64            [12] 4002 	add	a, #_raw_buffer
      006B17 F9               [12] 4003 	mov	r1,a
      006B18 EA               [12] 4004 	mov	a,r2
      006B19 34 07            [12] 4005 	addc	a, #(_raw_buffer >> 8)
      006B1B FA               [12] 4006 	mov	r2,a
      006B1C 8B 2E            [24] 4007 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006B1E 75 2F 00         [24] 4008 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006B21 8E 00            [24] 4009 	mov	ar0,r6
      006B23 8D 04            [24] 4010 	mov	ar4,r5
      006B25 E5 2E            [12] 4011 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006B27 28               [12] 4012 	add	a, r0
      006B28 F8               [12] 4013 	mov	r0,a
      006B29 E5 2F            [12] 4014 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006B2B 3C               [12] 4015 	addc	a, r4
      006B2C FC               [12] 4016 	mov	r4,a
      006B2D 88 82            [24] 4017 	mov	dpl,r0
      006B2F 8C 83            [24] 4018 	mov	dph,r4
      006B31 E4               [12] 4019 	clr	a
      006B32 93               [24] 4020 	movc	a,@a+dptr
      006B33 12 44 06         [24] 4021 	lcall	_ak820_outline_0016
      006B36 F0               [24] 4022 	movx	@dptr,a
      006B37 0B               [12] 4023 	inc	r3
      006B38 D0 04            [24] 4024 	pop	ar4
      006B3A 80 C7            [24] 4025 	sjmp	00131$
      006B3C                       4026 00108$:
                                   4027 ;	tmk_core/protocol/ch555/usb_ak820.c:629: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B3C 12 6C 3B         [24] 4028 	lcall	_ak820_outline_0038
      006B3F 12 67 3C         [24] 4029 	lcall	_ak820_usb_send
      006B42 02 6B EB         [24] 4030 	ljmp	00119$
      006B45                       4031 00118$:
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:630: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006B45 EF               [12] 4033 	mov	a,r7
      006B46 70 03            [24] 4034 	jnz	00281$
      006B48 02 6B C8         [24] 4035 	ljmp	00114$
      006B4B                       4036 00281$:
      006B4B 12 6C 5B         [24] 4037 	lcall	_ak820_outline_0121
      006B4E BF 01 02         [24] 4038 	cjne	r7,#0x01,00282$
      006B51 80 03            [24] 4039 	sjmp	00283$
      006B53                       4040 00282$:
      006B53 02 6B C8         [24] 4041 	ljmp	00114$
      006B56                       4042 00283$:
                                   4043 ;	tmk_core/protocol/ch555/usb_ak820.c:633: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006B56 7F 02            [12] 4044 	mov	r7,#0x02
      006B58                       4045 00133$:
      006B58 EF               [12] 4046 	mov	a,r7
      006B59 12 6C 4F         [24] 4047 	lcall	_ak820_outline_0081
      006B5C 0F               [12] 4048 	inc	r7
      006B5D BF 20 00         [24] 4049 	cjne	r7,#0x20,00284$
      006B60                       4050 00284$:
      006B60 40 F6            [24] 4051 	jc	00133$
                                   4052 ;	tmk_core/protocol/ch555/usb_ak820.c:634: raw_buffer[2] = 1;
      006B62 90 07 66         [24] 4053 	mov	dptr,#(_raw_buffer + 0x0002)
      006B65 74 01            [12] 4054 	mov	a,#0x01
      006B67 F0               [24] 4055 	movx	@dptr,a
                                   4056 ;	tmk_core/protocol/ch555/usb_ak820.c:635: raw_buffer[3] = 0xa8;
      006B68 90 07 67         [24] 4057 	mov	dptr,#(_raw_buffer + 0x0003)
      006B6B 74 A8            [12] 4058 	mov	a,#0xa8
      006B6D F0               [24] 4059 	movx	@dptr,a
                                   4060 ;	tmk_core/protocol/ch555/usb_ak820.c:636: ak820_nvm_diagnostic(&raw_buffer[4]);
      006B6E 90 07 68         [24] 4061 	mov	dptr,#(_raw_buffer + 0x0004)
      006B71 12 3B DA         [24] 4062 	lcall	_ak820_nvm_diagnostic
                                   4063 ;	tmk_core/protocol/ch555/usb_ak820.c:637: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006B74 7F 00            [12] 4064 	mov	r7,#0x00
      006B76                       4065 00135$:
      006B76 8F 06            [24] 4066 	mov	ar6,r7
      006B78 74 0B            [12] 4067 	mov	a,#0x0b
      006B7A 2E               [12] 4068 	add	a, r6
      006B7B 24 64            [12] 4069 	add	a,#_raw_buffer
      006B7D FE               [12] 4070 	mov	r6,a
      006B7E E4               [12] 4071 	clr	a
      006B7F 34 07            [12] 4072 	addc	a, #(_raw_buffer >> 8)
      006B81 FD               [12] 4073 	mov	r5,a
      006B82 EF               [12] 4074 	mov	a,r7
      006B83 24 5D            [12] 4075 	add	a, #_ak820_flash_diagnostic
      006B85 F5 82            [12] 4076 	mov	dpl,a
      006B87 E4               [12] 4077 	clr	a
      006B88 34 04            [12] 4078 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006B8A F5 83            [12] 4079 	mov	dph,a
      006B8C E0               [24] 4080 	movx	a,@dptr
      006B8D 8E 82            [24] 4081 	mov	dpl,r6
      006B8F 8D 83            [24] 4082 	mov	dph,r5
      006B91 F0               [24] 4083 	movx	@dptr,a
      006B92 0F               [12] 4084 	inc	r7
      006B93 BF 06 00         [24] 4085 	cjne	r7,#0x06,00286$
      006B96                       4086 00286$:
      006B96 40 DE            [24] 4087 	jc	00135$
                                   4088 ;	tmk_core/protocol/ch555/usb_ak820.c:638: raw_buffer[17] = vial_unlocked;
      006B98 90 0E 32         [24] 4089 	mov	dptr,#_vial_unlocked
      006B9B E0               [24] 4090 	movx	a,@dptr
      006B9C 90 07 75         [24] 4091 	mov	dptr,#(_raw_buffer + 0x0011)
      006B9F F0               [24] 4092 	movx	@dptr,a
                                   4093 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[18] = vial_unlock_in_progress;
      006BA0 90 0E 33         [24] 4094 	mov	dptr,#_vial_unlock_in_progress
      006BA3 E0               [24] 4095 	movx	a,@dptr
      006BA4 90 07 76         [24] 4096 	mov	dptr,#(_raw_buffer + 0x0012)
      006BA7 F0               [24] 4097 	movx	@dptr,a
                                   4098 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[19] = USB_EnumStatus;
      006BA8 90 07 5C         [24] 4099 	mov	dptr,#_USB_EnumStatus
      006BAB E0               [24] 4100 	movx	a,@dptr
      006BAC 90 07 77         [24] 4101 	mov	dptr,#(_raw_buffer + 0x0013)
      006BAF F0               [24] 4102 	movx	@dptr,a
                                   4103 ;	tmk_core/protocol/ch555/usb_ak820.c:641: raw_buffer[20] = USB_SleepStatus;
      006BB0 90 07 5D         [24] 4104 	mov	dptr,#_USB_SleepStatus
      006BB3 E0               [24] 4105 	movx	a,@dptr
      006BB4 90 07 78         [24] 4106 	mov	dptr,#(_raw_buffer + 0x0014)
      006BB7 F0               [24] 4107 	movx	@dptr,a
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:642: raw_buffer[21] = raw_state;
      006BB8 90 07 63         [24] 4109 	mov	dptr,#_raw_state
      006BBB E0               [24] 4110 	movx	a,@dptr
      006BBC 90 07 79         [24] 4111 	mov	dptr,#(_raw_buffer + 0x0015)
      006BBF F0               [24] 4112 	movx	@dptr,a
                                   4113 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006BC0 12 6C 3B         [24] 4114 	lcall	_ak820_outline_0038
      006BC3 12 67 3C         [24] 4115 	lcall	_ak820_usb_send
      006BC6 80 23            [24] 4116 	sjmp	00119$
      006BC8                       4117 00114$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006BC8 12 69 57         [24] 4119 	lcall	_raw_request_is_nonpersistent
      006BCB E5 82            [12] 4120 	mov	a, dpl
      006BCD 90 07 84         [24] 4121 	mov	dptr,#_raw_reply_without_nvm
      006BD0 F0               [24] 4122 	movx	@dptr,a
                                   4123 ;	tmk_core/protocol/ch555/usb_ak820.c:646: ak820_nvm_begin();
      006BD1 12 3F F6         [24] 4124 	lcall	_ak820_nvm_begin
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006BD4 90 0C 65         [24] 4126 	mov	dptr,#_raw_hid_receive_PARM_2
      006BD7 74 20            [12] 4127 	mov	a,#0x20
      006BD9 F0               [24] 4128 	movx	@dptr,a
      006BDA 90 07 64         [24] 4129 	mov	dptr,#_raw_buffer
      006BDD 75 F0 00         [24] 4130 	mov	b, #0x00
      006BE0 12 AA A4         [24] 4131 	lcall	_raw_hid_receive
                                   4132 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_nvm_end();
      006BE3 12 40 0B         [24] 4133 	lcall	_ak820_nvm_end
                                   4134 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_reply_without_nvm = false;
      006BE6 90 07 84         [24] 4135 	mov	dptr,#_raw_reply_without_nvm
      006BE9 E4               [12] 4136 	clr	a
      006BEA F0               [24] 4137 	movx	@dptr,a
      006BEB                       4138 00119$:
                                   4139 ;	tmk_core/protocol/ch555/usb_ak820.c:651: saved_ea = EA;
                                   4140 ;	assignBit
      006BEB A2 AF            [12] 4141 	mov	c,_EA
      006BED 92 16            [24] 4142 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:652: EA = 0;
                                   4144 ;	assignBit
      006BEF C2 AF            [12] 4145 	clr	_EA
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:654: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006BF1 12 6C 61         [24] 4147 	lcall	_ak820_outline_0125
      006BF4 BF 04 08         [24] 4148 	cjne	r7,#0x04,00126$
      006BF7 90 07 63         [24] 4149 	mov	dptr,#_raw_state
      006BFA 74 05            [12] 4150 	mov	a,#0x05
      006BFC F0               [24] 4151 	movx	@dptr,a
      006BFD 80 1B            [24] 4152 	sjmp	00127$
      006BFF                       4153 00126$:
                                   4154 ;	tmk_core/protocol/ch555/usb_ak820.c:655: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006BFF 12 6C 61         [24] 4155 	lcall	_ak820_outline_0125
      006C02 BF 03 02         [24] 4156 	cjne	r7,#0x03,00290$
      006C05 80 0E            [24] 4157 	sjmp	00121$
      006C07                       4158 00290$:
      006C07 12 6C 61         [24] 4159 	lcall	_ak820_outline_0125
      006C0A BF 06 02         [24] 4160 	cjne	r7,#0x06,00291$
      006C0D 80 06            [24] 4161 	sjmp	00121$
      006C0F                       4162 00291$:
      006C0F 12 6C 61         [24] 4163 	lcall	_ak820_outline_0125
      006C12 BF 07 05         [24] 4164 	cjne	r7,#0x07,00127$
      006C15                       4165 00121$:
      006C15 90 07 63         [24] 4166 	mov	dptr,#_raw_state
      006C18 E4               [12] 4167 	clr	a
      006C19 F0               [24] 4168 	movx	@dptr,a
      006C1A                       4169 00127$:
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:656: EA = saved_ea;
                                   4171 ;	assignBit
      006C1A A2 16            [12] 4172 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006C1C 92 AF            [24] 4173 	mov	_EA,c
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:657: }
      006C1E 22               [24] 4175 	ret
                                   4176 ;------------------------------------------------------------
                                   4177 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4178 ;------------------------------------------------------------
                                   4179 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_481'
                                   4180 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_481'
                                   4181 ;------------------------------------------------------------
                                   4182 ;	tmk_core/protocol/ch555/usb_ak820.c:659: bool ak820_usb_take_keyboard_reset(void) {
                                   4183 ;	-----------------------------------------
                                   4184 ;	 function ak820_usb_take_keyboard_reset
                                   4185 ;	-----------------------------------------
      006C1F                       4186 _ak820_usb_take_keyboard_reset:
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:661: uint8_t saved_ea = EA;
                                   4188 ;	assignBit
      006C1F A2 AF            [12] 4189 	mov	c,_EA
      006C21 92 17            [24] 4190 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4191 ;	tmk_core/protocol/ch555/usb_ak820.c:662: EA = 0;
                                   4192 ;	assignBit
      006C23 C2 AF            [12] 4193 	clr	_EA
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:663: result = keyboard_reset;
      006C25 90 07 85         [24] 4195 	mov	dptr,#_keyboard_reset
      006C28 E0               [24] 4196 	movx	a,@dptr
      006C29 FF               [12] 4197 	mov	r7,a
                                   4198 ;	tmk_core/protocol/ch555/usb_ak820.c:664: keyboard_reset = 0;
      006C2A E4               [12] 4199 	clr	a
      006C2B F0               [24] 4200 	movx	@dptr,a
                                   4201 ;	tmk_core/protocol/ch555/usb_ak820.c:665: EA = saved_ea;
                                   4202 ;	assignBit
      006C2C A2 17            [12] 4203 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006C2E 92 AF            [24] 4204 	mov	_EA,c
                                   4205 ;	tmk_core/protocol/ch555/usb_ak820.c:666: return result != 0;
      006C30 EF               [12] 4206 	mov	a,r7
      006C31 B4 01 00         [24] 4207 	cjne	a,#0x01,00103$
      006C34                       4208 00103$:
      006C34 B3               [12] 4209 	cpl	c
      006C35 92 17            [24] 4210 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006C37 12 44 91         [24] 4211 	lcall	_ak820_outline_0146
                                   4212 ;	tmk_core/protocol/ch555/usb_ak820.c:667: }
      006C3A 22               [24] 4213 	ret
                                   4214 	.area CSEG    (CODE)
                                   4215 	.area CONST   (CODE)
                                   4216 	.area CONST   (CODE)
      00BEAE                       4217 _shared_offsets:
      00BEAE 00                    4218 	.db #0x00	; 0
      00BEAF 00                    4219 	.db #0x00	; 0
      00BEB0 28                    4220 	.db #0x28	; 40
      00BEB1 28                    4221 	.db #0x28	; 40
      00BEB2 2B                    4222 	.db #0x2b	; 43
      00BEB3 00                    4223 	.db #0x00	; 0
      00BEB4 08                    4224 	.db #0x08	; 8
                                   4225 	.area CSEG    (CODE)
                                   4226 	.area CONST   (CODE)
      00BEB5                       4227 _shared_lengths:
      00BEB5 00                    4228 	.db #0x00	; 0
      00BEB6 00                    4229 	.db #0x00	; 0
      00BEB7 00                    4230 	.db #0x00	; 0
      00BEB8 03                    4231 	.db #0x03	; 3
      00BEB9 03                    4232 	.db #0x03	; 3
      00BEBA 00                    4233 	.db #0x00	; 0
      00BEBB 20                    4234 	.db #0x20	; 32
                                   4235 	.area CSEG    (CODE)
                                   4236 	.area CONST   (CODE)
      00BEBC                       4237 _interface_descriptors:
      00BEBC 62 C4                 4238 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BEBE 62 C5                 4239 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BEC0 15 C5                 4240 	.byte _RawReport, (_RawReport >> 8)
      00BEC2 7B C5                 4241 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BEC4 A7 C4                 4242 	.byte _SharedReport, (_SharedReport >> 8)
      00BEC6 94 C5                 4243 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4244 	.area CSEG    (CODE)
                                   4245 	.area XINIT   (CODE)
                                   4246 	.area CABS    (ABS,CODE)
                                   4247 
                                   4248 ; Experimental exact instruction outlining.
                                   4249 	.globl _ak820_outline_0001
                                   4250 	.globl _ak820_outline_0004
                                   4251 	.globl _ak820_outline_0016
                                   4252 	.globl _ak820_outline_0025
                                   4253 	.globl _ak820_outline_0038
                                   4254 	.globl _ak820_outline_0071
                                   4255 	.globl _ak820_outline_0081
                                   4256 	.globl _ak820_outline_0121
                                   4257 	.globl _ak820_outline_0125
                                   4258 	.globl _ak820_outline_0146
                                   4259 
                                   4260 	.area CSEG (CODE)
                                   4261 ; function ak820_outline_0038
      006C3B                       4262 _ak820_outline_0038:
      006C3B 90 07 C1         [24] 4263 	mov	dptr,#_ak820_usb_send_PARM_2
      006C3E 74 64            [12] 4264 	mov	a,#_raw_buffer
      006C40 F0               [24] 4265 	movx	@dptr,a
      006C41 74 07            [12] 4266 	mov	a,#(_raw_buffer>>8)
      006C43 A3               [24] 4267 	inc	dptr
      006C44 F0               [24] 4268 	movx	@dptr,a
      006C45 90 07 C3         [24] 4269 	mov	dptr,#_ak820_usb_send_PARM_3
      006C48 74 20            [12] 4270 	mov	a,#0x20
      006C4A F0               [24] 4271 	movx	@dptr,a
      006C4B 75 82 03         [24] 4272 	mov	dpl,#0x03
      006C4E 22               [24] 4273 	ret
                                   4274 
                                   4275 	.area CSEG (CODE)
                                   4276 ; function ak820_outline_0081
      006C4F                       4277 _ak820_outline_0081:
      006C4F 24 64            [12] 4278 	add	a,#_raw_buffer
      006C51 F5 82            [12] 4279 	mov	dpl,a
      006C53 E4               [12] 4280 	clr	a
      006C54 34 07            [12] 4281 	addc	a,#(_raw_buffer>>8)
      006C56 F5 83            [12] 4282 	mov	dph,a
      006C58 E4               [12] 4283 	clr	a
      006C59 F0               [24] 4284 	movx	@dptr,a
      006C5A 22               [24] 4285 	ret
                                   4286 
                                   4287 	.area CSEG (CODE)
                                   4288 ; function ak820_outline_0121
      006C5B                       4289 _ak820_outline_0121:
      006C5B 90 07 65         [24] 4290 	mov	dptr,#(_raw_buffer+0x0001)
      006C5E E0               [24] 4291 	movx	a,@dptr
      006C5F FF               [12] 4292 	mov	r7,a
      006C60 22               [24] 4293 	ret
                                   4294 
                                   4295 	.area CSEG (CODE)
                                   4296 ; function ak820_outline_0125
      006C61                       4297 _ak820_outline_0125:
      006C61 90 07 63         [24] 4298 	mov	dptr,#_raw_state
      006C64 E0               [24] 4299 	movx	a,@dptr
      006C65 FF               [12] 4300 	mov	r7,a
      006C66 22               [24] 4301 	ret
