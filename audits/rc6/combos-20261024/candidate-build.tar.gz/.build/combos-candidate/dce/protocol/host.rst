                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module host
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ADC_START
                                     12 	.globl _S0_R_FIFO
                                     13 	.globl _S0_T_FIFO
                                     14 	.globl _S0_FREE
                                     15 	.globl _S0_IF_BYTE
                                     16 	.globl _S0_IF_FIRST
                                     17 	.globl _S0_IF_OV
                                     18 	.globl _S0_FST_ACT
                                     19 	.globl _CP_RL2
                                     20 	.globl _C_T2
                                     21 	.globl _TR2
                                     22 	.globl _EXEN2
                                     23 	.globl _TCLK
                                     24 	.globl _RCLK
                                     25 	.globl _EXF2
                                     26 	.globl _CAP1F
                                     27 	.globl _TF2
                                     28 	.globl _RI
                                     29 	.globl _TI
                                     30 	.globl _RB8
                                     31 	.globl _TB8
                                     32 	.globl _REN
                                     33 	.globl _SM2
                                     34 	.globl _SM1
                                     35 	.globl _SM0
                                     36 	.globl _IT0
                                     37 	.globl _IE0
                                     38 	.globl _IT1
                                     39 	.globl _IE1
                                     40 	.globl _TR0
                                     41 	.globl _TF0
                                     42 	.globl _TR1
                                     43 	.globl _TF1
                                     44 	.globl _P4_0
                                     45 	.globl _P4_1
                                     46 	.globl _P4_2
                                     47 	.globl _P4_3
                                     48 	.globl _P4_4
                                     49 	.globl _P4_5
                                     50 	.globl _P4_6
                                     51 	.globl _RXD
                                     52 	.globl _TXD
                                     53 	.globl _INT0
                                     54 	.globl _INT1
                                     55 	.globl _T0
                                     56 	.globl _T1
                                     57 	.globl _MOSI1
                                     58 	.globl _MISO1
                                     59 	.globl _SCK1
                                     60 	.globl _P3_0
                                     61 	.globl _P3_1
                                     62 	.globl _P3_2
                                     63 	.globl _P3_3
                                     64 	.globl _P3_4
                                     65 	.globl _P3_5
                                     66 	.globl _P3_6
                                     67 	.globl _P3_7
                                     68 	.globl _CAP1_
                                     69 	.globl _T2_
                                     70 	.globl _CAP2_
                                     71 	.globl _T2EX_
                                     72 	.globl _RXD1
                                     73 	.globl _TXD1
                                     74 	.globl _P2_0
                                     75 	.globl _P2_1
                                     76 	.globl _P2_2
                                     77 	.globl _P2_3
                                     78 	.globl _P2_4
                                     79 	.globl _P2_5
                                     80 	.globl _P2_6
                                     81 	.globl _P2_7
                                     82 	.globl _AIN0
                                     83 	.globl _AIN1
                                     84 	.globl _AIN2
                                     85 	.globl _AIN3
                                     86 	.globl _AIN4
                                     87 	.globl _AIN5
                                     88 	.globl _AIN6
                                     89 	.globl _AIN7
                                     90 	.globl _CAP1
                                     91 	.globl _T2
                                     92 	.globl _CAP2
                                     93 	.globl _T2EX
                                     94 	.globl _INT0_
                                     95 	.globl _SCS
                                     96 	.globl _MOSI
                                     97 	.globl _MISO
                                     98 	.globl _SCK
                                     99 	.globl _RXD1_
                                    100 	.globl _TXD1_
                                    101 	.globl _P1_0
                                    102 	.globl _P1_1
                                    103 	.globl _P1_2
                                    104 	.globl _P1_3
                                    105 	.globl _P1_4
                                    106 	.globl _P1_5
                                    107 	.globl _P1_6
                                    108 	.globl _P1_7
                                    109 	.globl _AIN8
                                    110 	.globl _AIN9
                                    111 	.globl _AIN10
                                    112 	.globl _AIN11
                                    113 	.globl _AIN12
                                    114 	.globl _AIN13
                                    115 	.globl _RXD_
                                    116 	.globl _TXD_
                                    117 	.globl _SCL0
                                    118 	.globl _SDA0
                                    119 	.globl _P0_0
                                    120 	.globl _P0_1
                                    121 	.globl _P0_2
                                    122 	.globl _P0_3
                                    123 	.globl _P0_4
                                    124 	.globl _P0_5
                                    125 	.globl _P0_6
                                    126 	.globl _P0_7
                                    127 	.globl _IE_SPI0
                                    128 	.globl _IE_USB
                                    129 	.globl _IE_ADC
                                    130 	.globl _IE_UART1
                                    131 	.globl _IE_PWM_I2C
                                    132 	.globl _IE_GPIO
                                    133 	.globl _IE_WDOG
                                    134 	.globl _PX0
                                    135 	.globl _PT0
                                    136 	.globl _PX1
                                    137 	.globl _PT1
                                    138 	.globl _PS
                                    139 	.globl _PT2
                                    140 	.globl _PL_FLAG
                                    141 	.globl _PH_FLAG
                                    142 	.globl _EX0
                                    143 	.globl _ET0
                                    144 	.globl _EX1
                                    145 	.globl _ET1
                                    146 	.globl _ES
                                    147 	.globl _ET2
                                    148 	.globl _E_DIS
                                    149 	.globl _EA
                                    150 	.globl _P
                                    151 	.globl _F1
                                    152 	.globl _OV
                                    153 	.globl _RS0
                                    154 	.globl _RS1
                                    155 	.globl _F0
                                    156 	.globl _AC
                                    157 	.globl _CY
                                    158 	.globl _I2CS_INT_ST
                                    159 	.globl _I2CX_INT
                                    160 	.globl _LED_STATUS
                                    161 	.globl _LED_DMA_H
                                    162 	.globl _LED_DMA_L
                                    163 	.globl _LED_DMA
                                    164 	.globl _LED_PWM_OE
                                    165 	.globl _LED_COMMON
                                    166 	.globl _ADC_CHAN
                                    167 	.globl _ADC_DAT_H
                                    168 	.globl _ADC_DAT_L
                                    169 	.globl _ADC_DAT
                                    170 	.globl _ADC_CTRL
                                    171 	.globl _SPI1_CK_SE
                                    172 	.globl _SPI1_CTRL
                                    173 	.globl _SPI1_DATA
                                    174 	.globl _SPI1_STAT
                                    175 	.globl _SIF1
                                    176 	.globl _SBAUD1
                                    177 	.globl _SBUF1
                                    178 	.globl _SCON1
                                    179 	.globl _SPI0_SETUP
                                    180 	.globl _SPI0_CK_SE
                                    181 	.globl _SPI0_CTRL
                                    182 	.globl _SPI0_DATA
                                    183 	.globl _SPI0_STAT
                                    184 	.globl _T2CAP1H
                                    185 	.globl _T2CAP1L
                                    186 	.globl _T2CAP1
                                    187 	.globl _TH2
                                    188 	.globl _TL2
                                    189 	.globl _T2COUNT
                                    190 	.globl _RCAP2H
                                    191 	.globl _RCAP2L
                                    192 	.globl _RCAP2
                                    193 	.globl _T2MOD
                                    194 	.globl _T2CON
                                    195 	.globl _SBUF
                                    196 	.globl _SCON
                                    197 	.globl _TH1
                                    198 	.globl _TH0
                                    199 	.globl _TL1
                                    200 	.globl _TL0
                                    201 	.globl _TMOD
                                    202 	.globl _TCON
                                    203 	.globl _XBUS_AUX
                                    204 	.globl _P7
                                    205 	.globl _P6_DIR
                                    206 	.globl _P6_OUT_PU
                                    207 	.globl _P6_IN
                                    208 	.globl _P5_DIR
                                    209 	.globl _P5_OUT_PU
                                    210 	.globl _P5_IN
                                    211 	.globl _P4_LED_KEY
                                    212 	.globl _P4_DIR_PU
                                    213 	.globl _P4_MOD_OC
                                    214 	.globl _P4
                                    215 	.globl _P3_DIR_PU
                                    216 	.globl _P3_MOD_OC
                                    217 	.globl _P3
                                    218 	.globl _P2_DIR_PU
                                    219 	.globl _P2_MOD_OC
                                    220 	.globl _P2
                                    221 	.globl _P1_DIR_PU
                                    222 	.globl _P1_MOD_OC
                                    223 	.globl _P1
                                    224 	.globl _P0_DIR_PU
                                    225 	.globl _P0_MOD_OC
                                    226 	.globl _P0
                                    227 	.globl _ROM_CTRL
                                    228 	.globl _ROM_DATA_HH
                                    229 	.globl _ROM_DATA_HL
                                    230 	.globl _ROM_DATA_HI
                                    231 	.globl _ROM_ADDR_H
                                    232 	.globl _ROM_ADDR_L
                                    233 	.globl _ROM_ADDR
                                    234 	.globl _GPIO_IE
                                    235 	.globl _IP_EX
                                    236 	.globl _IE_EX
                                    237 	.globl _IP
                                    238 	.globl _IE
                                    239 	.globl _WDOG_COUNT
                                    240 	.globl _RESET_KEEP
                                    241 	.globl _WAKE_CTRL
                                    242 	.globl _CLOCK_CFG
                                    243 	.globl _POWER_CFG
                                    244 	.globl _PCON
                                    245 	.globl _GLOBAL_CFG
                                    246 	.globl _SAFE_MOD
                                    247 	.globl _DPH
                                    248 	.globl _DPL
                                    249 	.globl _SP
                                    250 	.globl _A_INV
                                    251 	.globl _B
                                    252 	.globl _ACC
                                    253 	.globl _PSW
                                    254 	.globl _host_set_driver
                                    255 	.globl _host_keyboard_leds
                                    256 	.globl _host_keyboard_send
                                    257 	.globl _host_system_send
                                    258 	.globl _host_consumer_send
                                    259 	.globl _host_last_system_usage
                                    260 	.globl _host_last_consumer_usage
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      0007CF                        547 _driver:
      0007CF                        548 	.ds 2
      0007D1                        549 _host_set_driver_d_10000_175:
      0007D1                        550 	.ds 3
      0007D4                        551 _host_keyboard_send_report_10000_184:
      0007D4                        552 	.ds 3
      0007D7                        553 _host_extra_send_PARM_2:
      0007D7                        554 	.ds 2
      0007D9                        555 _host_extra_send_report_id_10000_197:
      0007D9                        556 	.ds 1
      0007DA                        557 _host_extra_send_report_10001_200:
      0007DA                        558 	.ds 3
      0007DD                        559 _host_system_send_usage_10000_201:
      0007DD                        560 	.ds 2
      0007DF                        561 _host_consumer_send_usage_10000_204:
      0007DF                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; absolute external ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area XABS    (ABS,XDATA)
                                    567 ;--------------------------------------------------------
                                    568 ; initialized external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area XISEG   (XDATA)
      000DCD                        571 _last_system_usage:
      000DCD                        572 	.ds 2
      000DCF                        573 _last_consumer_usage:
      000DCF                        574 	.ds 2
                                    575 	.area HOME    (CODE)
                                    576 	.area GSINIT0 (CODE)
                                    577 	.area GSINIT1 (CODE)
                                    578 	.area GSINIT2 (CODE)
                                    579 	.area GSINIT3 (CODE)
                                    580 	.area GSINIT4 (CODE)
                                    581 	.area GSINIT5 (CODE)
                                    582 	.area GSINIT  (CODE)
                                    583 	.area GSFINAL (CODE)
                                    584 	.area CSEG    (CODE)
                                    585 ;--------------------------------------------------------
                                    586 ; global & static initialisations
                                    587 ;--------------------------------------------------------
                                    588 	.area HOME    (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area GSINIT  (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; Home
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area HOME    (CODE)
                                    597 ;--------------------------------------------------------
                                    598 ; code
                                    599 ;--------------------------------------------------------
                                    600 	.area CSEG    (CODE)
                                    601 ;------------------------------------------------------------
                                    602 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    603 ;------------------------------------------------------------
                                    604 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_98'
                                    605 ;------------------------------------------------------------
                                    606 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    607 ;	-----------------------------------------
                           000007   608 	ar7 = 0x07
                           000006   609 	ar6 = 0x06
                           000005   610 	ar5 = 0x05
                           000004   611 	ar4 = 0x04
                           000003   612 	ar3 = 0x03
                           000002   613 	ar2 = 0x02
                           000001   614 	ar1 = 0x01
                           000000   615 	ar0 = 0x00
                                    616 ;	 function host_set_driver
                                    617 ;	-----------------------------------------
      006C67                        618 _host_set_driver:
      006C67 12 43 D8         [24]  619 	lcall	_ak820_outline_0004
      006C6A 90 07 D1         [24]  620 	mov	dptr,#_host_set_driver_d_10000_175
      006C6D 12 43 CB         [24]  621 	lcall	_ak820_outline_0001
                                    622 ;	tmk_core/protocol/host.c:53: driver = (host_driver_t __xdata *)d;
      006C70 90 07 D1         [24]  623 	mov	dptr,#_host_set_driver_d_10000_175
      006C73 12 43 C5         [24]  624 	lcall	_ak820_outline_0000
      006C76 90 07 CF         [24]  625 	mov	dptr,#_driver
      006C79 EE               [12]  626 	mov	a,r6
      006C7A 12 43 E5         [24]  627 	lcall	_ak820_outline_0007
                                    628 ;	tmk_core/protocol/host.c:57: }
      006C7D 22               [24]  629 	ret
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'host_get_driver'
                                    632 ;------------------------------------------------------------
                                    633 ;	tmk_core/protocol/host.c:59: host_driver_t *host_get_driver(void) {
                                    634 ;	-----------------------------------------
                                    635 ;	 function host_keyboard_leds
                                    636 ;	-----------------------------------------
      006C7E                        637 _host_keyboard_leds:
                                    638 ;	tmk_core/protocol/host.c:74: if (!driver) return 0;
      006C7E 90 07 CF         [24]  639 	mov	dptr,#_driver
      006C81 12 43 C5         [24]  640 	lcall	_ak820_outline_0000
      006C84 4E               [12]  641 	orl	a,r6
      006C85 70 03            [24]  642 	jnz	00102$
      006C87 F5 82            [12]  643 	mov	dpl,a
      006C89 22               [24]  644 	ret
      006C8A                        645 00102$:
                                    646 ;	tmk_core/protocol/host.c:75: return (*driver->keyboard_leds)();
      006C8A 12 43 D3         [24]  647 	lcall	_ak820_outline_0002
      006C8D 12 43 C5         [24]  648 	lcall	_ak820_outline_0000
      006C90 C0 07            [24]  649 	push	ar7
      006C92 12 43 D3         [24]  650 	lcall	_ak820_outline_0002
      006C95 12 30 75         [24]  651 	lcall	__sdcc_call_dptr
      006C98 AE 82            [24]  652 	mov	r6, dpl
      006C9A D0 07            [24]  653 	pop	ar7
      006C9C 8E 82            [24]  654 	mov	dpl, r6
                                    655 ;	tmk_core/protocol/host.c:76: }
      006C9E 22               [24]  656 	ret
                                    657 ;------------------------------------------------------------
                                    658 ;Allocation info for local variables in function 'host_keyboard_led_state'
                                    659 ;------------------------------------------------------------
                                    660 ;usb_led       Allocated with name '_host_keyboard_led_state_usb_led_10000_183'
                                    661 ;usb_led_p2    Allocated with name '_host_keyboard_led_state_usb_led_p2_10000_183'
                                    662 ;usb_led_p     Allocated with name '_host_keyboard_led_state_usb_led_p_10000_183'
                                    663 ;------------------------------------------------------------
                                    664 ;	tmk_core/protocol/host.c:78: led_t host_keyboard_led_state(void) {
                                    665 ;	-----------------------------------------
                                    666 ;	 function host_keyboard_send
                                    667 ;	-----------------------------------------
      006C9F                        668 _host_keyboard_send:
      006C9F 12 43 D8         [24]  669 	lcall	_ak820_outline_0004
      006CA2 90 07 D4         [24]  670 	mov	dptr,#_host_keyboard_send_report_10000_184
      006CA5 12 43 CB         [24]  671 	lcall	_ak820_outline_0001
                                    672 ;	tmk_core/protocol/host.c:95: if (!driver) return;
      006CA8 90 07 CF         [24]  673 	mov	dptr,#_driver
      006CAB 12 6D E3         [24]  674 	lcall	_ak820_outline_0018
      006CAE 70 01            [24]  675 	jnz	00102$
      006CB0 22               [24]  676 	ret
      006CB1                        677 00102$:
                                    678 ;	tmk_core/protocol/host.c:97: if (keyboard_protocol && keymap_config.nkro) {
      006CB1 90 0D C4         [24]  679 	mov	dptr,#_keyboard_protocol
      006CB4 E0               [24]  680 	movx	a,@dptr
      006CB5 60 2F            [24]  681 	jz	00104$
      006CB7 90 0A AE         [24]  682 	mov	dptr,#_keymap_config
      006CBA E0               [24]  683 	movx	a,@dptr
      006CBB 30 E7 28         [24]  684 	jnb	acc.7,00104$
                                    685 ;	tmk_core/protocol/host.c:101: report->nkro.mods      = report->mods;
      006CBE 90 07 D4         [24]  686 	mov	dptr,#_host_keyboard_send_report_10000_184
      006CC1 E0               [24]  687 	movx	a,@dptr
      006CC2 FD               [12]  688 	mov	r5,a
      006CC3 A3               [24]  689 	inc	dptr
      006CC4 12 43 C5         [24]  690 	lcall	_ak820_outline_0000
      006CC7 74 01            [12]  691 	mov	a,#0x01
      006CC9 2D               [12]  692 	add	a, r5
      006CCA FA               [12]  693 	mov	r2,a
      006CCB E4               [12]  694 	clr	a
      006CCC 3E               [12]  695 	addc	a, r6
      006CCD FB               [12]  696 	mov	r3,a
      006CCE 8F 04            [24]  697 	mov	ar4,r7
      006CD0 12 4E 65         [24]  698 	lcall	_ak820_outline_0005
      006CD3 12 BE 14         [24]  699 	lcall	__gptrget
      006CD6 12 44 22         [24]  700 	lcall	_ak820_outline_0033
      006CD9 8C F0            [24]  701 	mov	b,r4
      006CDB 12 BD D9         [24]  702 	lcall	__gptrput
                                    703 ;	tmk_core/protocol/host.c:102: report->nkro.report_id = REPORT_ID_NKRO;
      006CDE 12 4E 65         [24]  704 	lcall	_ak820_outline_0005
      006CE1 74 06            [12]  705 	mov	a,#0x06
      006CE3 12 BD D9         [24]  706 	lcall	__gptrput
      006CE6                        707 00104$:
                                    708 ;	tmk_core/protocol/host.c:110: (*driver->send_keyboard)(report);
      006CE6 90 07 CF         [24]  709 	mov	dptr,#_driver
      006CE9 12 43 C5         [24]  710 	lcall	_ak820_outline_0000
      006CEC 12 43 D3         [24]  711 	lcall	_ak820_outline_0002
      006CEF A3               [24]  712 	inc	dptr
      006CF0 A3               [24]  713 	inc	dptr
      006CF1 12 43 C5         [24]  714 	lcall	_ak820_outline_0000
      006CF4 90 07 D4         [24]  715 	mov	dptr,#_host_keyboard_send_report_10000_184
      006CF7 E0               [24]  716 	movx	a,@dptr
      006CF8 FB               [12]  717 	mov	r3,a
      006CF9 A3               [24]  718 	inc	dptr
      006CFA 12 43 DF         [24]  719 	lcall	_ak820_outline_0006
      006CFD C0 07            [24]  720 	push	ar7
      006CFF C0 06            [24]  721 	push	ar6
      006D01 12 6D 06         [24]  722 	lcall	00160$
      006D04 80 0A            [24]  723 	sjmp	00161$
      006D06                        724 00160$:
      006D06 C0 06            [24]  725 	push	ar6
      006D08 C0 07            [24]  726 	push	ar7
      006D0A 12 43 F9         [24]  727 	lcall	_ak820_outline_0014
      006D0D 8D F0            [24]  728 	mov	b, r5
      006D0F 22               [24]  729 	ret
      006D10                        730 00161$:
      006D10 D0 06            [24]  731 	pop	ar6
      006D12 D0 07            [24]  732 	pop	ar7
                                    733 ;	tmk_core/protocol/host.c:112: if (debug_keyboard) {
      006D14 90 0E 24         [24]  734 	mov	dptr,#_debug_config
      006D17 E0               [24]  735 	movx	a,@dptr
      006D18 30 E2 0A         [24]  736 	jnb	acc.2,00112$
                                    737 ;	tmk_core/protocol/host.c:114: for (uint8_t i = 0; i < KEYBOARD_REPORT_SIZE; i++) {
      006D1B 7F 00            [12]  738 	mov	r7,#0x00
      006D1D                        739 00110$:
      006D1D BF 08 00         [24]  740 	cjne	r7,#0x08,00163$
      006D20                        741 00163$:
      006D20 50 03            [24]  742 	jnc	00112$
      006D22 0F               [12]  743 	inc	r7
      006D23 80 F8            [24]  744 	sjmp	00110$
      006D25                        745 00112$:
                                    746 ;	tmk_core/protocol/host.c:119: }
      006D25 22               [24]  747 	ret
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'host_mouse_send'
                                    750 ;------------------------------------------------------------
                                    751 ;report        Allocated with name '_host_mouse_send_report_10000_194'
                                    752 ;------------------------------------------------------------
                                    753 ;	tmk_core/protocol/host.c:121: void host_mouse_send(report_mouse_t *report) {
                                    754 ;	-----------------------------------------
                                    755 ;	 function host_extra_send
                                    756 ;	-----------------------------------------
      006D26                        757 _host_extra_send:
      006D26 E5 82            [12]  758 	mov	a,dpl
      006D28 90 07 D9         [24]  759 	mov	dptr,#_host_extra_send_report_id_10000_197
      006D2B F0               [24]  760 	movx	@dptr,a
                                    761 ;	tmk_core/protocol/host.c:142: if (!driver) return;
      006D2C 90 07 CF         [24]  762 	mov	dptr,#_driver
      006D2F 12 6D E3         [24]  763 	lcall	_ak820_outline_0018
      006D32 70 01            [24]  764 	jnz	00102$
      006D34 22               [24]  765 	ret
      006D35                        766 00102$:
                                    767 ;	tmk_core/protocol/host.c:143: report_extra_t report = {
      006D35 90 07 D9         [24]  768 	mov	dptr,#_host_extra_send_report_id_10000_197
      006D38 E0               [24]  769 	movx	a,@dptr
      006D39 90 07 DA         [24]  770 	mov	dptr,#_host_extra_send_report_10001_200
      006D3C F0               [24]  771 	movx	@dptr,a
      006D3D 90 07 D7         [24]  772 	mov	dptr,#_host_extra_send_PARM_2
      006D40 12 43 C5         [24]  773 	lcall	_ak820_outline_0000
      006D43 90 07 DB         [24]  774 	mov	dptr,#(_host_extra_send_report_10001_200 + 0x0001)
      006D46 EE               [12]  775 	mov	a,r6
      006D47 12 43 E5         [24]  776 	lcall	_ak820_outline_0007
                                    777 ;	tmk_core/protocol/host.c:147: (*driver->send_extra)(&report);
      006D4A 90 07 CF         [24]  778 	mov	dptr,#_driver
      006D4D 12 43 C5         [24]  779 	lcall	_ak820_outline_0000
      006D50 74 06            [12]  780 	mov	a,#0x06
      006D52 12 43 FE         [24]  781 	lcall	_ak820_outline_0015
      006D55 12 43 C5         [24]  782 	lcall	_ak820_outline_0000
      006D58 C0 07            [24]  783 	push	ar7
      006D5A C0 06            [24]  784 	push	ar6
      006D5C 12 6D 61         [24]  785 	lcall	00113$
      006D5F 80 0B            [24]  786 	sjmp	00114$
      006D61                        787 00113$:
      006D61 C0 06            [24]  788 	push	ar6
      006D63 C0 07            [24]  789 	push	ar7
      006D65 90 07 DA         [24]  790 	mov	dptr,#_host_extra_send_report_10001_200
      006D68 75 F0 00         [24]  791 	mov	b, #0x00
      006D6B 22               [24]  792 	ret
      006D6C                        793 00114$:
      006D6C D0 06            [24]  794 	pop	ar6
      006D6E D0 07            [24]  795 	pop	ar7
                                    796 ;	tmk_core/protocol/host.c:148: }
      006D70 22               [24]  797 	ret
                                    798 ;------------------------------------------------------------
                                    799 ;Allocation info for local variables in function 'host_system_send'
                                    800 ;------------------------------------------------------------
                                    801 ;usage         Allocated with name '_host_system_send_usage_10000_201'
                                    802 ;------------------------------------------------------------
                                    803 ;	tmk_core/protocol/host.c:150: void host_system_send(uint16_t usage) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function host_system_send
                                    806 ;	-----------------------------------------
      006D71                        807 _host_system_send:
      006D71 12 43 EA         [24]  808 	lcall	_ak820_outline_0010
      006D74 90 07 DD         [24]  809 	mov	dptr,#_host_system_send_usage_10000_201
      006D77 12 43 E5         [24]  810 	lcall	_ak820_outline_0007
                                    811 ;	tmk_core/protocol/host.c:151: if (usage == last_system_usage) return;
      006D7A 90 07 DD         [24]  812 	mov	dptr,#_host_system_send_usage_10000_201
      006D7D 12 43 C5         [24]  813 	lcall	_ak820_outline_0000
      006D80 90 0D CD         [24]  814 	mov	dptr,#_last_system_usage
      006D83 12 43 DF         [24]  815 	lcall	_ak820_outline_0006
      006D86 EE               [12]  816 	mov	a,r6
      006D87 B5 04 05         [24]  817 	cjne	a,ar4,00102$
      006D8A EF               [12]  818 	mov	a,r7
      006D8B B5 05 01         [24]  819 	cjne	a,ar5,00102$
      006D8E 22               [24]  820 	ret
      006D8F                        821 00102$:
                                    822 ;	tmk_core/protocol/host.c:152: last_system_usage = usage;
      006D8F 90 0D CD         [24]  823 	mov	dptr,#_last_system_usage
      006D92 EE               [12]  824 	mov	a,r6
      006D93 12 43 E5         [24]  825 	lcall	_ak820_outline_0007
                                    826 ;	tmk_core/protocol/host.c:154: host_extra_send(REPORT_ID_SYSTEM, usage);
      006D96 90 07 D7         [24]  827 	mov	dptr,#_host_extra_send_PARM_2
      006D99 EE               [12]  828 	mov	a,r6
      006D9A 12 43 E5         [24]  829 	lcall	_ak820_outline_0007
      006D9D 75 82 03         [24]  830 	mov	dpl, #0x03
                                    831 ;	tmk_core/protocol/host.c:155: }
      006DA0 02 6D 26         [24]  832 	ljmp	_host_extra_send
                                    833 ;------------------------------------------------------------
                                    834 ;Allocation info for local variables in function 'host_consumer_send'
                                    835 ;------------------------------------------------------------
                                    836 ;usage         Allocated with name '_host_consumer_send_usage_10000_204'
                                    837 ;------------------------------------------------------------
                                    838 ;	tmk_core/protocol/host.c:157: void host_consumer_send(uint16_t usage) {
                                    839 ;	-----------------------------------------
                                    840 ;	 function host_consumer_send
                                    841 ;	-----------------------------------------
      006DA3                        842 _host_consumer_send:
      006DA3 12 43 EA         [24]  843 	lcall	_ak820_outline_0010
      006DA6 90 07 DF         [24]  844 	mov	dptr,#_host_consumer_send_usage_10000_204
      006DA9 12 43 E5         [24]  845 	lcall	_ak820_outline_0007
                                    846 ;	tmk_core/protocol/host.c:158: if (usage == last_consumer_usage) return;
      006DAC 90 07 DF         [24]  847 	mov	dptr,#_host_consumer_send_usage_10000_204
      006DAF 12 43 C5         [24]  848 	lcall	_ak820_outline_0000
      006DB2 90 0D CF         [24]  849 	mov	dptr,#_last_consumer_usage
      006DB5 12 43 DF         [24]  850 	lcall	_ak820_outline_0006
      006DB8 EE               [12]  851 	mov	a,r6
      006DB9 B5 04 05         [24]  852 	cjne	a,ar4,00102$
      006DBC EF               [12]  853 	mov	a,r7
      006DBD B5 05 01         [24]  854 	cjne	a,ar5,00102$
      006DC0 22               [24]  855 	ret
      006DC1                        856 00102$:
                                    857 ;	tmk_core/protocol/host.c:159: last_consumer_usage = usage;
      006DC1 90 0D CF         [24]  858 	mov	dptr,#_last_consumer_usage
      006DC4 EE               [12]  859 	mov	a,r6
      006DC5 12 43 E5         [24]  860 	lcall	_ak820_outline_0007
                                    861 ;	tmk_core/protocol/host.c:168: host_extra_send(REPORT_ID_CONSUMER, usage);
      006DC8 90 07 D7         [24]  862 	mov	dptr,#_host_extra_send_PARM_2
      006DCB EE               [12]  863 	mov	a,r6
      006DCC 12 43 E5         [24]  864 	lcall	_ak820_outline_0007
      006DCF 75 82 04         [24]  865 	mov	dpl, #0x04
                                    866 ;	tmk_core/protocol/host.c:169: }
      006DD2 02 6D 26         [24]  867 	ljmp	_host_extra_send
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'host_last_system_usage'
                                    870 ;------------------------------------------------------------
                                    871 ;	tmk_core/protocol/host.c:264: uint16_t host_last_system_usage(void) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function host_last_system_usage
                                    874 ;	-----------------------------------------
      006DD5                        875 _host_last_system_usage:
                                    876 ;	tmk_core/protocol/host.c:265: return last_system_usage;
      006DD5 90 0D CD         [24]  877 	mov	dptr,#_last_system_usage
      006DD8 12 4E 84         [24]  878 	lcall	_ak820_outline_0070
                                    879 ;	tmk_core/protocol/host.c:266: }
      006DDB 22               [24]  880 	ret
                                    881 ;------------------------------------------------------------
                                    882 ;Allocation info for local variables in function 'host_last_consumer_usage'
                                    883 ;------------------------------------------------------------
                                    884 ;	tmk_core/protocol/host.c:268: uint16_t host_last_consumer_usage(void) {
                                    885 ;	-----------------------------------------
                                    886 ;	 function host_last_consumer_usage
                                    887 ;	-----------------------------------------
      006DDC                        888 _host_last_consumer_usage:
                                    889 ;	tmk_core/protocol/host.c:269: return last_consumer_usage;
      006DDC 90 0D CF         [24]  890 	mov	dptr,#_last_consumer_usage
      006DDF 12 4E 84         [24]  891 	lcall	_ak820_outline_0070
                                    892 ;	tmk_core/protocol/host.c:270: }
      006DE2 22               [24]  893 	ret
                                    894 	.area CSEG    (CODE)
                                    895 	.area CONST   (CODE)
                                    896 	.area XINIT   (CODE)
      00C618                        897 __xinit__last_system_usage:
      00C618 00 00                  898 	.byte #0x00, #0x00	; 0
      00C61A                        899 __xinit__last_consumer_usage:
      00C61A 00 00                  900 	.byte #0x00, #0x00	; 0
                                    901 	.area CABS    (ABS,CODE)
                                    902 
                                    903 ; Experimental exact instruction outlining.
                                    904 	.globl _ak820_outline_0000
                                    905 	.globl _ak820_outline_0001
                                    906 	.globl _ak820_outline_0002
                                    907 	.globl _ak820_outline_0004
                                    908 	.globl _ak820_outline_0005
                                    909 	.globl _ak820_outline_0006
                                    910 	.globl _ak820_outline_0007
                                    911 	.globl _ak820_outline_0010
                                    912 	.globl _ak820_outline_0014
                                    913 	.globl _ak820_outline_0015
                                    914 	.globl _ak820_outline_0018
                                    915 	.globl _ak820_outline_0033
                                    916 	.globl _ak820_outline_0070
                                    917 
                                    918 	.area CSEG (CODE)
                                    919 ; function ak820_outline_0018
      006DE3                        920 _ak820_outline_0018:
      006DE3 E0               [24]  921 	movx	a,@dptr
      006DE4 F5 F0            [12]  922 	mov	b,a
      006DE6 A3               [24]  923 	inc	dptr
      006DE7 E0               [24]  924 	movx	a,@dptr
      006DE8 45 F0            [12]  925 	orl	a,b
      006DEA 22               [24]  926 	ret
