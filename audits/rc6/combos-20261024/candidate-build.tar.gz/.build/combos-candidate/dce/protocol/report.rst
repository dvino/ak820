                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007E1                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007E1                        556 	.ds 1
      0007E2                        557 _add_key_byte_PARM_2:
      0007E2                        558 	.ds 1
      0007E3                        559 _add_key_byte_report_arg_10000_144:
      0007E3                        560 	.ds 3
      0007E6                        561 _add_key_byte_empty_10000_145:
      0007E6                        562 	.ds 1
      0007E7                        563 _del_key_byte_PARM_2:
      0007E7                        564 	.ds 1
      0007E8                        565 _del_key_byte_report_arg_10000_156:
      0007E8                        566 	.ds 3
      0007EB                        567 _add_key_bit_PARM_2:
      0007EB                        568 	.ds 1
      0007EC                        569 _add_key_bit_report_arg_10000_162:
      0007EC                        570 	.ds 3
      0007EF                        571 _del_key_bit_PARM_2:
      0007EF                        572 	.ds 1
      0007F0                        573 _del_key_bit_report_arg_10000_167:
      0007F0                        574 	.ds 3
      0007F3                        575 _add_key_to_report_PARM_2:
      0007F3                        576 	.ds 1
      0007F4                        577 _add_key_to_report_report_arg_10000_172:
      0007F4                        578 	.ds 3
      0007F7                        579 _del_key_from_report_PARM_2:
      0007F7                        580 	.ds 1
      0007F8                        581 _del_key_from_report_report_arg_10000_176:
      0007F8                        582 	.ds 3
      0007FB                        583 _clear_keys_from_report_report_arg_10000_180:
      0007FB                        584 	.ds 3
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006DEB                        636 _KEYCODE2CONSUMER:
      006DEB E5 82            [12]  637 	mov	a,dpl
      006DED 90 07 E1         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006DF0 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006DF1 E0               [24]  641 	movx	a,@dptr
      006DF2 FF               [12]  642 	mov	r7,a
      006DF3 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006DF6                        644 00113$:
      006DF6 40 05            [24]  645 	jc	00101$
      006DF8 EF               [12]  646 	mov	a,r7
      006DF9 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006DFB 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006DFD                        650 00101$:
      006DFD 90 00 00         [24]  651 	mov	dptr,#0x0000
      006E00 22               [24]  652 	ret
      006E01                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      006E01 EF               [12]  655 	mov	a,r7
      006E02 24 58            [12]  656 	add	a,#0x58
      006E04 FF               [12]  657 	mov	r7,a
      006E05 C2 D5            [12]  658 	clr	F0
      006E07 75 F0 02         [24]  659 	mov	b,#0x02
      006E0A EF               [12]  660 	mov	a,r7
      006E0B 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006E0E B2 D5            [12]  662 	cpl	F0
      006E10 F4               [12]  663 	cpl	a
      006E11 04               [12]  664 	inc	a
      006E12                        665 00116$:
      006E12 A4               [48]  666 	mul	ab
      006E13 30 D5 03         [24]  667 	jnb	F0,00117$
      006E16 12 70 1A         [24]  668 	lcall	_ak820_outline_0096
      006E19                        669 00117$:
      006E19 24 C8            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006E1B F5 82            [12]  671 	mov	dpl,a
      006E1D 74 BE            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006E1F 12 57 0F         [24]  673 	lcall	_ak820_outline_0111
      006E22 FE               [12]  674 	mov	r6,a
      006E23 A3               [24]  675 	inc	dptr
      006E24 E4               [12]  676 	clr	a
      006E25 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:54: }
      006E26 8E 82            [24]  679 	mov	dpl,r6
      006E28 F5 83            [12]  680 	mov	dph,a
      006E2A 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006E2B                        695 _add_key_byte:
      006E2B 12 43 D8         [24]  696 	lcall	_ak820_outline_0004
      006E2E 90 07 E3         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006E31 12 43 CB         [24]  698 	lcall	_ak820_outline_0001
                                    699 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E34 90 07 E3         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006E37 12 43 C5         [24]  701 	lcall	_ak820_outline_0000
                                    702 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      006E3A 90 07 E6         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006E3D 74 FF            [12]  704 	mov	a,#0xff
      006E3F F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:209: }
      006E40 7D 00            [12]  707 	mov	r5,#0x00
      006E42                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006E42 C3               [12]  710 	clr	c
      006E43 ED               [12]  711 	mov	a,r5
      006E44 64 80            [12]  712 	xrl	a,#0x80
      006E46 94 86            [12]  713 	subb	a,#0x86
      006E48 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      006E4A 12 70 25         [24]  716 	lcall	_ak820_outline_0103
      006E4D F5 82            [12]  717 	mov	dpl,a
      006E4F E4               [12]  718 	clr	a
      006E50 3C               [12]  719 	addc	a, r4
      006E51 F5 83            [12]  720 	mov	dph,a
      006E53 E0               [24]  721 	movx	a,@dptr
      006E54 FC               [12]  722 	mov	r4,a
      006E55 90 07 E2         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      006E58 E0               [24]  724 	movx	a,@dptr
      006E59 FB               [12]  725 	mov	r3,a
      006E5A EC               [12]  726 	mov	a,r4
      006E5B B5 03 02         [24]  727 	cjne	a,ar3,00167$
      006E5E 80 13            [24]  728 	sjmp	00106$
      006E60                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006E60 90 07 E6         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      006E63 E0               [24]  732 	movx	a,@dptr
      006E64 FB               [12]  733 	mov	r3,a
      006E65 BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      006E68 EC               [12]  735 	mov	a,r4
      006E69 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:200: empty = i;
      006E6B 90 07 E6         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      006E6E ED               [12]  739 	mov	a,r5
      006E6F F0               [24]  740 	movx	@dptr,a
      006E70                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006E70 0D               [12]  743 	inc	r5
      006E71 80 CF            [24]  744 	sjmp	00112$
      006E73                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      006E73 BD 06 1D         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      006E76 90 07 E6         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      006E79 E0               [24]  750 	movx	a,@dptr
      006E7A FD               [12]  751 	mov	r5,a
      006E7B BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      006E7E 22               [24]  753 	ret
      006E7F                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      006E7F 74 02            [12]  756 	mov	a,#0x02
      006E81 12 44 39         [24]  757 	lcall	_ak820_outline_0050
      006E84 ED               [12]  758 	mov	a,r5
      006E85 2E               [12]  759 	add	a, r6
      006E86 FD               [12]  760 	mov	r5,a
      006E87 E4               [12]  761 	clr	a
      006E88 3F               [12]  762 	addc	a, r7
      006E89 FC               [12]  763 	mov	r4,a
      006E8A 90 07 E2         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      006E8D E0               [24]  765 	movx	a,@dptr
      006E8E 8D 82            [24]  766 	mov	dpl,r5
      006E90 8C 83            [24]  767 	mov	dph,r4
      006E92 F0               [24]  768 	movx	@dptr,a
      006E93                        769 00114$:
                                    770 ;	tmk_core/protocol/report.c:209: }
      006E93 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'del_key_byte'
                                    774 ;------------------------------------------------------------
                                    775 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    776 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    777 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    778 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    779 ;------------------------------------------------------------
                                    780 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function del_key_byte
                                    783 ;	-----------------------------------------
      006E94                        784 _del_key_byte:
      006E94 12 43 D8         [24]  785 	lcall	_ak820_outline_0004
      006E97 90 07 E8         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006E9A 12 43 CB         [24]  787 	lcall	_ak820_outline_0001
                                    788 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E9D 90 07 E8         [24]  789 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006EA0 12 43 C5         [24]  790 	lcall	_ak820_outline_0000
                                    791 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006EA3 7D 00            [12]  792 	mov	r5,#0x00
      006EA5                        793 00105$:
      006EA5 BD 06 00         [24]  794 	cjne	r5,#0x06,00131$
      006EA8                        795 00131$:
      006EA8 50 1D            [24]  796 	jnc	00107$
                                    797 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      006EAA 12 70 25         [24]  798 	lcall	_ak820_outline_0103
      006EAD FB               [12]  799 	mov	r3,a
      006EAE E4               [12]  800 	clr	a
      006EAF 3C               [12]  801 	addc	a, r4
      006EB0 FC               [12]  802 	mov	r4,a
      006EB1 12 43 F9         [24]  803 	lcall	_ak820_outline_0014
      006EB4 E0               [24]  804 	movx	a,@dptr
      006EB5 FA               [12]  805 	mov	r2,a
      006EB6 90 07 E7         [24]  806 	mov	dptr,#_del_key_byte_PARM_2
      006EB9 E0               [24]  807 	movx	a,@dptr
      006EBA F9               [12]  808 	mov	r1,a
      006EBB EA               [12]  809 	mov	a,r2
      006EBC B5 01 05         [24]  810 	cjne	a,ar1,00106$
                                    811 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      006EBF 12 43 F9         [24]  812 	lcall	_ak820_outline_0014
      006EC2 E4               [12]  813 	clr	a
      006EC3 F0               [24]  814 	movx	@dptr,a
      006EC4                        815 00106$:
                                    816 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006EC4 0D               [12]  817 	inc	r5
      006EC5 80 DE            [24]  818 	sjmp	00105$
      006EC7                        819 00107$:
                                    820 ;	tmk_core/protocol/report.c:249: }
      006EC7 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'add_key_bit'
                                    824 ;------------------------------------------------------------
                                    825 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    826 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    827 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    828 ;------------------------------------------------------------
                                    829 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function add_key_bit
                                    832 ;	-----------------------------------------
      006EC8                        833 _add_key_bit:
      006EC8 12 43 D8         [24]  834 	lcall	_ak820_outline_0004
      006ECB 90 07 EC         [24]  835 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006ECE 12 43 CB         [24]  836 	lcall	_ak820_outline_0001
                                    837 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006ED1 90 07 EC         [24]  838 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006ED4 12 43 C5         [24]  839 	lcall	_ak820_outline_0000
                                    840 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006ED7 90 07 EB         [24]  841 	mov	dptr,#_add_key_bit_PARM_2
      006EDA E0               [24]  842 	movx	a,@dptr
      006EDB FD               [12]  843 	mov	r5,a
      006EDC 12 57 27         [24]  844 	lcall	_ak820_outline_0133
      006EDF FC               [12]  845 	mov	r4,a
      006EE0 BC 1E 00         [24]  846 	cjne	r4,#0x1e,00112$
      006EE3                        847 00112$:
      006EE3 50 1E            [24]  848 	jnc	00103$
                                    849 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      006EE5 74 02            [12]  850 	mov	a,#0x02
      006EE7 12 44 39         [24]  851 	lcall	_ak820_outline_0050
      006EEA 12 70 2F         [24]  852 	lcall	_ak820_outline_0104
      006EED 12 70 13         [24]  853 	lcall	_ak820_outline_0021
      006EF0 80 02            [24]  854 	sjmp	00115$
      006EF2                        855 00114$:
      006EF2 25 E0            [12]  856 	add	a,acc
      006EF4                        857 00115$:
      006EF4 D5 F0 FB         [24]  858 	djnz	b,00114$
      006EF7 FF               [12]  859 	mov	r7,a
      006EF8 12 44 96         [24]  860 	lcall	_ak820_outline_0147
      006EFB E0               [24]  861 	movx	a,@dptr
      006EFC 42 07            [12]  862 	orl	ar7,a
      006EFE 12 44 96         [24]  863 	lcall	_ak820_outline_0147
      006F01 EF               [12]  864 	mov	a,r7
      006F02 F0               [24]  865 	movx	@dptr,a
      006F03                        866 00103$:
                                    867 ;	tmk_core/protocol/report.c:263: }
      006F03 22               [24]  868 	ret
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'del_key_bit'
                                    871 ;------------------------------------------------------------
                                    872 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    873 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    874 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    875 ;------------------------------------------------------------
                                    876 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function del_key_bit
                                    879 ;	-----------------------------------------
      006F04                        880 _del_key_bit:
      006F04 12 43 D8         [24]  881 	lcall	_ak820_outline_0004
      006F07 90 07 F0         [24]  882 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006F0A 12 43 CB         [24]  883 	lcall	_ak820_outline_0001
                                    884 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F0D 90 07 F0         [24]  885 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006F10 12 43 C5         [24]  886 	lcall	_ak820_outline_0000
                                    887 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006F13 90 07 EF         [24]  888 	mov	dptr,#_del_key_bit_PARM_2
      006F16 E0               [24]  889 	movx	a,@dptr
      006F17 FD               [12]  890 	mov	r5,a
      006F18 12 57 27         [24]  891 	lcall	_ak820_outline_0133
      006F1B FC               [12]  892 	mov	r4,a
      006F1C BC 1E 00         [24]  893 	cjne	r4,#0x1e,00112$
      006F1F                        894 00112$:
      006F1F 50 1F            [24]  895 	jnc	00103$
                                    896 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      006F21 74 02            [12]  897 	mov	a,#0x02
      006F23 12 44 39         [24]  898 	lcall	_ak820_outline_0050
      006F26 12 70 2F         [24]  899 	lcall	_ak820_outline_0104
      006F29 12 70 13         [24]  900 	lcall	_ak820_outline_0021
      006F2C 80 02            [24]  901 	sjmp	00115$
      006F2E                        902 00114$:
      006F2E 25 E0            [12]  903 	add	a,acc
      006F30                        904 00115$:
      006F30 D5 F0 FB         [24]  905 	djnz	b,00114$
      006F33 F4               [12]  906 	cpl	a
      006F34 FF               [12]  907 	mov	r7,a
      006F35 12 44 96         [24]  908 	lcall	_ak820_outline_0147
      006F38 E0               [24]  909 	movx	a,@dptr
      006F39 52 07            [12]  910 	anl	ar7,a
      006F3B 12 44 96         [24]  911 	lcall	_ak820_outline_0147
      006F3E EF               [12]  912 	mov	a,r7
      006F3F F0               [24]  913 	movx	@dptr,a
      006F40                        914 00103$:
                                    915 ;	tmk_core/protocol/report.c:276: }
      006F40 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'add_key_to_report'
                                    919 ;------------------------------------------------------------
                                    920 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    921 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    922 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    923 ;------------------------------------------------------------
                                    924 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function add_key_to_report
                                    927 ;	-----------------------------------------
      006F41                        928 _add_key_to_report:
      006F41 12 43 D8         [24]  929 	lcall	_ak820_outline_0004
      006F44 90 07 F4         [24]  930 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006F47 12 43 CB         [24]  931 	lcall	_ak820_outline_0001
                                    932 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F4A 90 07 F4         [24]  933 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006F4D 12 43 C5         [24]  934 	lcall	_ak820_outline_0000
                                    935 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      006F50 90 0D C4         [24]  936 	mov	dptr,#_keyboard_protocol
      006F53 E0               [24]  937 	movx	a,@dptr
      006F54 60 1D            [24]  938 	jz	00102$
      006F56 90 0A AE         [24]  939 	mov	dptr,#_keymap_config
      006F59 E0               [24]  940 	movx	a,@dptr
      006F5A 30 E7 16         [24]  941 	jnb	acc.7,00102$
                                    942 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      006F5D 8E 03            [24]  943 	mov	ar3,r6
      006F5F 8F 04            [24]  944 	mov	ar4,r7
      006F61 7D 00            [12]  945 	mov	r5,#0x00
      006F63 90 07 F3         [24]  946 	mov	dptr,#_add_key_to_report_PARM_2
      006F66 E0               [24]  947 	movx	a,@dptr
      006F67 90 07 EB         [24]  948 	mov	dptr,#_add_key_bit_PARM_2
      006F6A F0               [24]  949 	movx	@dptr,a
      006F6B 12 43 F9         [24]  950 	lcall	_ak820_outline_0014
      006F6E 8D F0            [24]  951 	mov	b, r5
                                    952 ;	tmk_core/protocol/report.c:288: return;
      006F70 02 6E C8         [24]  953 	ljmp	_add_key_bit
      006F73                        954 00102$:
                                    955 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      006F73 7D 00            [12]  956 	mov	r5,#0x00
      006F75 90 07 F3         [24]  957 	mov	dptr,#_add_key_to_report_PARM_2
      006F78 E0               [24]  958 	movx	a,@dptr
      006F79 90 07 E2         [24]  959 	mov	dptr,#_add_key_byte_PARM_2
      006F7C F0               [24]  960 	movx	@dptr,a
      006F7D 12 43 D3         [24]  961 	lcall	_ak820_outline_0002
      006F80 8D F0            [24]  962 	mov	b, r5
                                    963 ;	tmk_core/protocol/report.c:292: }
      006F82 02 6E 2B         [24]  964 	ljmp	_add_key_byte
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'del_key_from_report'
                                    967 ;------------------------------------------------------------
                                    968 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    969 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    970 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    971 ;------------------------------------------------------------
                                    972 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    973 ;	-----------------------------------------
                                    974 ;	 function del_key_from_report
                                    975 ;	-----------------------------------------
      006F85                        976 _del_key_from_report:
      006F85 12 43 D8         [24]  977 	lcall	_ak820_outline_0004
      006F88 90 07 F8         [24]  978 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006F8B 12 43 CB         [24]  979 	lcall	_ak820_outline_0001
                                    980 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F8E 90 07 F8         [24]  981 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006F91 12 43 C5         [24]  982 	lcall	_ak820_outline_0000
                                    983 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      006F94 90 0D C4         [24]  984 	mov	dptr,#_keyboard_protocol
      006F97 E0               [24]  985 	movx	a,@dptr
      006F98 60 1D            [24]  986 	jz	00102$
      006F9A 90 0A AE         [24]  987 	mov	dptr,#_keymap_config
      006F9D E0               [24]  988 	movx	a,@dptr
      006F9E 30 E7 16         [24]  989 	jnb	acc.7,00102$
                                    990 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      006FA1 8E 03            [24]  991 	mov	ar3,r6
      006FA3 8F 04            [24]  992 	mov	ar4,r7
      006FA5 7D 00            [12]  993 	mov	r5,#0x00
      006FA7 90 07 F7         [24]  994 	mov	dptr,#_del_key_from_report_PARM_2
      006FAA E0               [24]  995 	movx	a,@dptr
      006FAB 90 07 EF         [24]  996 	mov	dptr,#_del_key_bit_PARM_2
      006FAE F0               [24]  997 	movx	@dptr,a
      006FAF 12 43 F9         [24]  998 	lcall	_ak820_outline_0014
      006FB2 8D F0            [24]  999 	mov	b, r5
                                   1000 ;	tmk_core/protocol/report.c:303: return;
      006FB4 02 6F 04         [24] 1001 	ljmp	_del_key_bit
      006FB7                       1002 00102$:
                                   1003 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      006FB7 7D 00            [12] 1004 	mov	r5,#0x00
      006FB9 90 07 F7         [24] 1005 	mov	dptr,#_del_key_from_report_PARM_2
      006FBC E0               [24] 1006 	movx	a,@dptr
      006FBD 90 07 E7         [24] 1007 	mov	dptr,#_del_key_byte_PARM_2
      006FC0 F0               [24] 1008 	movx	@dptr,a
      006FC1 12 43 D3         [24] 1009 	lcall	_ak820_outline_0002
      006FC4 8D F0            [24] 1010 	mov	b, r5
                                   1011 ;	tmk_core/protocol/report.c:307: }
      006FC6 02 6E 94         [24] 1012 	ljmp	_del_key_byte
                                   1013 ;------------------------------------------------------------
                                   1014 ;Allocation info for local variables in function 'clear_keys_from_report'
                                   1015 ;------------------------------------------------------------
                                   1016 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                   1017 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function clear_keys_from_report
                                   1022 ;	-----------------------------------------
      006FC9                       1023 _clear_keys_from_report:
      006FC9 12 43 D8         [24] 1024 	lcall	_ak820_outline_0004
      006FCC 90 07 FB         [24] 1025 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006FCF 12 43 CB         [24] 1026 	lcall	_ak820_outline_0001
                                   1027 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006FD2 90 07 FB         [24] 1028 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006FD5 12 43 C5         [24] 1029 	lcall	_ak820_outline_0000
                                   1030 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      006FD8 90 0D C4         [24] 1031 	mov	dptr,#_keyboard_protocol
      006FDB E0               [24] 1032 	movx	a,@dptr
      006FDC 60 1E            [24] 1033 	jz	00102$
      006FDE 90 0A AE         [24] 1034 	mov	dptr,#_keymap_config
      006FE1 E0               [24] 1035 	movx	a,@dptr
      006FE2 30 E7 17         [24] 1036 	jnb	acc.7,00102$
                                   1037 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      006FE5 74 02            [12] 1038 	mov	a,#0x02
      006FE7 12 44 33         [24] 1039 	lcall	_ak820_outline_0043
      006FEA 7B 00            [12] 1040 	mov	r3,#0x00
      006FEC 12 70 39         [24] 1041 	lcall	_ak820_outline_0143
      006FEF 74 1E            [12] 1042 	mov	a,#0x1e
      006FF1 12 4E 60         [24] 1043 	lcall	_ak820_outline_0003
      006FF4 12 43 EF         [24] 1044 	lcall	_ak820_outline_0011
      006FF7 8B F0            [24] 1045 	mov	b, r3
                                   1046 ;	tmk_core/protocol/report.c:319: return;
      006FF9 02 BD B1         [24] 1047 	ljmp	_memset
      006FFC                       1048 00102$:
                                   1049 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      006FFC 74 02            [12] 1050 	mov	a,#0x02
      006FFE 12 44 39         [24] 1051 	lcall	_ak820_outline_0050
      007001 7D 00            [12] 1052 	mov	r5,#0x00
      007003 12 70 39         [24] 1053 	lcall	_ak820_outline_0143
      007006 74 06            [12] 1054 	mov	a,#0x06
      007008 12 4E 60         [24] 1055 	lcall	_ak820_outline_0003
      00700B 12 43 D3         [24] 1056 	lcall	_ak820_outline_0002
      00700E 8D F0            [24] 1057 	mov	b, r5
                                   1058 ;	tmk_core/protocol/report.c:323: }
      007010 02 BD B1         [24] 1059 	ljmp	_memset
                                   1060 	.area CSEG    (CODE)
                                   1061 	.area CONST   (CODE)
                                   1062 	.area CONST   (CODE)
      00BEC8                       1063 _KEYCODE2CONSUMER_usages_10000_118:
      00BEC8 E2 00                 1064 	.byte #0xe2, #0x00	; 226
      00BECA E9 00                 1065 	.byte #0xe9, #0x00	; 233
      00BECC EA 00                 1066 	.byte #0xea, #0x00	; 234
      00BECE B5 00                 1067 	.byte #0xb5, #0x00	; 181
      00BED0 B6 00                 1068 	.byte #0xb6, #0x00	; 182
      00BED2 B7 00                 1069 	.byte #0xb7, #0x00	; 183
      00BED4 CD 00                 1070 	.byte #0xcd, #0x00	; 205
      00BED6 83 01                 1071 	.byte #0x83, #0x01	; 387
      00BED8 CC 00                 1072 	.byte #0xcc, #0x00	; 204
      00BEDA 8A 01                 1073 	.byte #0x8a, #0x01	; 394
      00BEDC 92 01                 1074 	.byte #0x92, #0x01	; 402
      00BEDE 94 01                 1075 	.byte #0x94, #0x01	; 404
      00BEE0 21 02                 1076 	.byte #0x21, #0x02	; 545
      00BEE2 23 02                 1077 	.byte #0x23, #0x02	; 547
      00BEE4 24 02                 1078 	.byte #0x24, #0x02	; 548
      00BEE6 25 02                 1079 	.byte #0x25, #0x02	; 549
      00BEE8 26 02                 1080 	.byte #0x26, #0x02	; 550
      00BEEA 27 02                 1081 	.byte #0x27, #0x02	; 551
      00BEEC 2A 02                 1082 	.byte #0x2a, #0x02	; 554
      00BEEE B3 00                 1083 	.byte #0xb3, #0x00	; 179
      00BEF0 B4 00                 1084 	.byte #0xb4, #0x00	; 180
      00BEF2 6F 00                 1085 	.byte #0x6f, #0x00	; 111
      00BEF4 70 00                 1086 	.byte #0x70, #0x00	; 112
      00BEF6 9F 01                 1087 	.byte #0x9f, #0x01	; 415
      00BEF8 CB 01                 1088 	.byte #0xcb, #0x01	; 459
      00BEFA 9F 02                 1089 	.byte #0x9f, #0x02	; 671
      00BEFC A0 02                 1090 	.byte #0xa0, #0x02	; 672
                                   1091 	.area CSEG    (CODE)
                                   1092 	.area XINIT   (CODE)
                                   1093 	.area CABS    (ABS,CODE)
                                   1094 
                                   1095 ; Experimental exact instruction outlining.
                                   1096 	.globl _ak820_outline_0000
                                   1097 	.globl _ak820_outline_0001
                                   1098 	.globl _ak820_outline_0002
                                   1099 	.globl _ak820_outline_0003
                                   1100 	.globl _ak820_outline_0004
                                   1101 	.globl _ak820_outline_0011
                                   1102 	.globl _ak820_outline_0014
                                   1103 	.globl _ak820_outline_0021
                                   1104 	.globl _ak820_outline_0043
                                   1105 	.globl _ak820_outline_0050
                                   1106 	.globl _ak820_outline_0096
                                   1107 	.globl _ak820_outline_0103
                                   1108 	.globl _ak820_outline_0104
                                   1109 	.globl _ak820_outline_0111
                                   1110 	.globl _ak820_outline_0133
                                   1111 	.globl _ak820_outline_0143
                                   1112 	.globl _ak820_outline_0147
                                   1113 
                                   1114 	.area CSEG (CODE)
                                   1115 ; function ak820_outline_0021
      007013                       1116 _ak820_outline_0021:
      007013 F5 F0            [12] 1117 	mov	b,a
      007015 05 F0            [12] 1118 	inc	b
      007017 74 01            [12] 1119 	mov	a,#0x01
      007019 22               [24] 1120 	ret
                                   1121 
                                   1122 	.area CSEG (CODE)
                                   1123 ; function ak820_outline_0096
      00701A                       1124 _ak820_outline_0096:
      00701A F4               [12] 1125 	cpl	a
      00701B 24 01            [12] 1126 	add	a,#0x01
      00701D C5 F0            [12] 1127 	xch	a,b
      00701F F4               [12] 1128 	cpl	a
      007020 34 00            [12] 1129 	addc	a,#0x00
      007022 C5 F0            [12] 1130 	xch	a,b
      007024 22               [24] 1131 	ret
                                   1132 
                                   1133 	.area CSEG (CODE)
                                   1134 ; function ak820_outline_0103
      007025                       1135 _ak820_outline_0103:
      007025 74 02            [12] 1136 	mov	a,#0x02
      007027 2E               [12] 1137 	add	a,r6
      007028 FB               [12] 1138 	mov	r3,a
      007029 E4               [12] 1139 	clr	a
      00702A 3F               [12] 1140 	addc	a,r7
      00702B FC               [12] 1141 	mov	r4,a
      00702C ED               [12] 1142 	mov	a,r5
      00702D 2B               [12] 1143 	add	a,r3
      00702E 22               [24] 1144 	ret
                                   1145 
                                   1146 	.area CSEG (CODE)
                                   1147 ; function ak820_outline_0104
      00702F                       1148 _ak820_outline_0104:
      00702F EC               [12] 1149 	mov	a,r4
      007030 2E               [12] 1150 	add	a,r6
      007031 FC               [12] 1151 	mov	r4,a
      007032 E4               [12] 1152 	clr	a
      007033 3F               [12] 1153 	addc	a,r7
      007034 FB               [12] 1154 	mov	r3,a
      007035 74 07            [12] 1155 	mov	a,#0x07
      007037 5D               [12] 1156 	anl	a,r5
      007038 22               [24] 1157 	ret
                                   1158 
                                   1159 	.area CSEG (CODE)
                                   1160 ; function ak820_outline_0143
      007039                       1161 _ak820_outline_0143:
      007039 90 0D BB         [24] 1162 	mov	dptr,#_memset_PARM_2
      00703C E4               [12] 1163 	clr	a
      00703D F0               [24] 1164 	movx	@dptr,a
      00703E 90 0D BC         [24] 1165 	mov	dptr,#_memset_PARM_3
      007041 22               [24] 1166 	ret
