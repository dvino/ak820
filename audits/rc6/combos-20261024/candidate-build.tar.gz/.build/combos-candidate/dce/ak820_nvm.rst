                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         53 bits:
      000025                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _load_page_sloc1_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000012                         74 	.ds 2
      000014                         75 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000014                         76 	.ds 3
                                     77 ;--------------------------------------------------------
                                     78 ; overlayable items in internal ram
                                     79 ;--------------------------------------------------------
                                     80 ;--------------------------------------------------------
                                     81 ; indirectly addressable internal ram data
                                     82 ;--------------------------------------------------------
                                     83 	.area ISEG    (DATA)
                                     84 ;--------------------------------------------------------
                                     85 ; absolute internal ram data
                                     86 ;--------------------------------------------------------
                                     87 	.area IABS    (ABS,DATA)
                                     88 	.area IABS    (ABS,DATA)
                                     89 ;--------------------------------------------------------
                                     90 ; bit data
                                     91 ;--------------------------------------------------------
                                     92 	.area BSEG    (BIT)
      000008                         93 _ak820_nvm_ok_sloc0_1_0:
      000008                         94 	.ds 1
      000009                         95 _load_page_sloc0_1_0:
      000009                         96 	.ds 1
                                     97 ;--------------------------------------------------------
                                     98 ; paged external ram data
                                     99 ;--------------------------------------------------------
                                    100 	.area PSEG    (PAG,XDATA)
                                    101 ;--------------------------------------------------------
                                    102 ; uninitialized external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area XSEG    (XDATA)
      000517                        105 _page_data:
      000517                        106 	.ds 64
      000557                        107 _cached_page:
      000557                        108 	.ds 2
      000559                        109 _page_valid:
      000559                        110 	.ds 1
      00055A                        111 _page_dirty:
      00055A                        112 	.ds 1
      00055B                        113 _storage_failed:
      00055B                        114 	.ds 1
      00055C                        115 _batch_depth:
      00055C                        116 	.ds 1
      00055D                        117 _first_failure_stage:
      00055D                        118 	.ds 1
      00055E                        119 _nvm_fail_stage_10000_20:
      00055E                        120 	.ds 1
      00055F                        121 _ak820_nvm_diagnostic_out_10000_23:
      00055F                        122 	.ds 2
      000561                        123 _crc_byte_PARM_2:
      000561                        124 	.ds 1
      000562                        125 _crc_byte_crc_10000_25:
      000562                        126 	.ds 2
      000564                        127 _page_crc_crc_10000_30:
      000564                        128 	.ds 2
      000566                        129 _write_page_address_10000_32:
      000566                        130 	.ds 2
      000568                        131 _journal_header_valid_header_10000_39:
      000568                        132 	.ds 2
      00056A                        133 _recover_journal_header_10000_46:
      00056A                        134 	.ds 9
      000573                        135 _ak820_nvm_flush_header_10000_62:
      000573                        136 	.ds 9
      00057C                        137 _ak820_nvm_flush_stage_10000_62:
      00057C                        138 	.ds 1
      00057D                        139 _load_page_page_10000_87:
      00057D                        140 	.ds 2
      00057F                        141 _read_offset_offset_10000_93:
      00057F                        142 	.ds 2
      000581                        143 _eeprom_read_byte_addr_10000_97:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_2:
      000584                        146 	.ds 3
      000587                        147 _ak820_eeprom_read_block_xdata_PARM_3:
      000587                        148 	.ds 2
      000589                        149 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000589                        150 	.ds 2
      00058B                        151 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058B                        152 	.ds 2
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_2:
      00058D                        154 	.ds 3
      000590                        155 _ak820_eeprom_write_block_xdata_PARM_3:
      000590                        156 	.ds 2
      000592                        157 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000592                        158 	.ds 2
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_2:
      000594                        160 	.ds 3
      000597                        161 _ak820_eeprom_update_block_xdata_PARM_3:
      000597                        162 	.ds 2
      000599                        163 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000599                        164 	.ds 2
                                    165 ;--------------------------------------------------------
                                    166 ; absolute external ram data
                                    167 ;--------------------------------------------------------
                                    168 	.area XABS    (ABS,XDATA)
                                    169 ;--------------------------------------------------------
                                    170 ; initialized external ram data
                                    171 ;--------------------------------------------------------
                                    172 	.area XISEG   (XDATA)
                                    173 	.area HOME    (CODE)
                                    174 	.area GSINIT0 (CODE)
                                    175 	.area GSINIT1 (CODE)
                                    176 	.area GSINIT2 (CODE)
                                    177 	.area GSINIT3 (CODE)
                                    178 	.area GSINIT4 (CODE)
                                    179 	.area GSINIT5 (CODE)
                                    180 	.area GSINIT  (CODE)
                                    181 	.area GSFINAL (CODE)
                                    182 	.area CSEG    (CODE)
                                    183 ;--------------------------------------------------------
                                    184 ; global & static initialisations
                                    185 ;--------------------------------------------------------
                                    186 	.area HOME    (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 	.area GSFINAL (CODE)
                                    189 	.area GSINIT  (CODE)
                                    190 ;--------------------------------------------------------
                                    191 ; Home
                                    192 ;--------------------------------------------------------
                                    193 	.area HOME    (CODE)
                                    194 	.area HOME    (CODE)
                                    195 ;--------------------------------------------------------
                                    196 ; code
                                    197 ;--------------------------------------------------------
                                    198 	.area CSEG    (CODE)
                                    199 ;------------------------------------------------------------
                                    200 ;Allocation info for local variables in function 'nvm_fail'
                                    201 ;------------------------------------------------------------
                                    202 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    203 ;------------------------------------------------------------
                                    204 ;	keyboards/ajazz/ak820/ak820_nvm.c:22: static void nvm_fail(uint8_t stage) {
                                    205 ;	-----------------------------------------
                                    206 ;	 function nvm_fail
                                    207 ;	-----------------------------------------
      003BC0                        208 _nvm_fail:
                           000007   209 	ar7 = 0x07
                           000006   210 	ar6 = 0x06
                           000005   211 	ar5 = 0x05
                           000004   212 	ar4 = 0x04
                           000003   213 	ar3 = 0x03
                           000002   214 	ar2 = 0x02
                           000001   215 	ar1 = 0x01
                           000000   216 	ar0 = 0x00
      003BC0 E5 82            [12]  217 	mov	a,dpl
      003BC2 90 05 5E         [24]  218 	mov	dptr,#_nvm_fail_stage_10000_20
      003BC5 F0               [24]  219 	movx	@dptr,a
                                    220 ;	keyboards/ajazz/ak820/ak820_nvm.c:23: if (!storage_failed) first_failure_stage = stage;
      003BC6 12 44 7E         [24]  221 	lcall	_ak820_outline_0131
      003BC9 70 08            [24]  222 	jnz	00102$
      003BCB 90 05 5E         [24]  223 	mov	dptr,#_nvm_fail_stage_10000_20
      003BCE E0               [24]  224 	movx	a,@dptr
      003BCF 90 05 5D         [24]  225 	mov	dptr,#_first_failure_stage
      003BD2 F0               [24]  226 	movx	@dptr,a
      003BD3                        227 00102$:
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:24: storage_failed = true;
      003BD3 90 05 5B         [24]  229 	mov	dptr,#_storage_failed
      003BD6 74 01            [12]  230 	mov	a,#0x01
      003BD8 F0               [24]  231 	movx	@dptr,a
                                    232 ;	keyboards/ajazz/ak820/ak820_nvm.c:25: }
      003BD9 22               [24]  233 	ret
                                    234 ;------------------------------------------------------------
                                    235 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    236 ;------------------------------------------------------------
                                    237 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    238 ;------------------------------------------------------------
                                    239 ;	keyboards/ajazz/ak820/ak820_nvm.c:27: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    240 ;	-----------------------------------------
                                    241 ;	 function ak820_nvm_diagnostic
                                    242 ;	-----------------------------------------
      003BDA                        243 _ak820_nvm_diagnostic:
      003BDA 12 43 EA         [24]  244 	lcall	_ak820_outline_0010
      003BDD 90 05 5F         [24]  245 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BE0 12 43 E5         [24]  246 	lcall	_ak820_outline_0007
                                    247 ;	keyboards/ajazz/ak820/ak820_nvm.c:28: out[0] = storage_failed;
      003BE3 90 05 5F         [24]  248 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BE6 12 43 C5         [24]  249 	lcall	_ak820_outline_0000
      003BE9 12 44 7E         [24]  250 	lcall	_ak820_outline_0131
      003BEC 12 43 D3         [24]  251 	lcall	_ak820_outline_0002
      003BEF F0               [24]  252 	movx	@dptr,a
                                    253 ;	keyboards/ajazz/ak820/ak820_nvm.c:29: out[1] = page_valid;
      003BF0 74 01            [12]  254 	mov	a,#0x01
      003BF2 12 44 33         [24]  255 	lcall	_ak820_outline_0043
      003BF5 90 05 59         [24]  256 	mov	dptr,#_page_valid
      003BF8 E0               [24]  257 	movx	a,@dptr
      003BF9 12 43 EF         [24]  258 	lcall	_ak820_outline_0011
      003BFC F0               [24]  259 	movx	@dptr,a
                                    260 ;	keyboards/ajazz/ak820/ak820_nvm.c:30: out[2] = page_dirty;
      003BFD 74 02            [12]  261 	mov	a,#0x02
      003BFF 12 44 33         [24]  262 	lcall	_ak820_outline_0043
      003C02 90 05 5A         [24]  263 	mov	dptr,#_page_dirty
      003C05 E0               [24]  264 	movx	a,@dptr
      003C06 12 43 EF         [24]  265 	lcall	_ak820_outline_0011
      003C09 F0               [24]  266 	movx	@dptr,a
                                    267 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: out[3] = batch_depth;
      003C0A 74 03            [12]  268 	mov	a,#0x03
      003C0C 12 44 33         [24]  269 	lcall	_ak820_outline_0043
      003C0F 90 05 5C         [24]  270 	mov	dptr,#_batch_depth
      003C12 E0               [24]  271 	movx	a,@dptr
      003C13 12 43 EF         [24]  272 	lcall	_ak820_outline_0011
      003C16 F0               [24]  273 	movx	@dptr,a
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: out[4] = (uint8_t)cached_page;
      003C17 74 04            [12]  275 	mov	a,#0x04
      003C19 12 44 33         [24]  276 	lcall	_ak820_outline_0043
      003C1C 90 05 57         [24]  277 	mov	dptr,#_cached_page
      003C1F E0               [24]  278 	movx	a,@dptr
      003C20 12 43 EF         [24]  279 	lcall	_ak820_outline_0011
      003C23 F0               [24]  280 	movx	@dptr,a
                                    281 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: out[5] = (uint8_t)(cached_page >> 8);
      003C24 74 05            [12]  282 	mov	a,#0x05
      003C26 12 44 33         [24]  283 	lcall	_ak820_outline_0043
      003C29 90 05 57         [24]  284 	mov	dptr,#_cached_page
      003C2C E0               [24]  285 	movx	a,@dptr
      003C2D A3               [24]  286 	inc	dptr
      003C2E E0               [24]  287 	movx	a,@dptr
      003C2F 12 43 EF         [24]  288 	lcall	_ak820_outline_0011
      003C32 F0               [24]  289 	movx	@dptr,a
                                    290 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: out[6] = first_failure_stage;
      003C33 74 06            [12]  291 	mov	a,#0x06
      003C35 12 44 39         [24]  292 	lcall	_ak820_outline_0050
      003C38 90 05 5D         [24]  293 	mov	dptr,#_first_failure_stage
      003C3B E0               [24]  294 	movx	a,@dptr
      003C3C 12 43 D3         [24]  295 	lcall	_ak820_outline_0002
      003C3F F0               [24]  296 	movx	@dptr,a
                                    297 ;	keyboards/ajazz/ak820/ak820_nvm.c:35: }
      003C40 22               [24]  298 	ret
                                    299 ;------------------------------------------------------------
                                    300 ;Allocation info for local variables in function 'crc_byte'
                                    301 ;------------------------------------------------------------
                                    302 ;value         Allocated with name '_crc_byte_PARM_2'
                                    303 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    304 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    305 ;------------------------------------------------------------
                                    306 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    307 ;	-----------------------------------------
                                    308 ;	 function crc_byte
                                    309 ;	-----------------------------------------
      003C41                        310 _crc_byte:
      003C41 12 43 EA         [24]  311 	lcall	_ak820_outline_0010
      003C44 90 05 62         [24]  312 	mov	dptr,#_crc_byte_crc_10000_25
      003C47 12 43 E5         [24]  313 	lcall	_ak820_outline_0007
                                    314 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: crc ^= (uint16_t)value << 8;
      003C4A 90 05 61         [24]  315 	mov	dptr,#_crc_byte_PARM_2
      003C4D E0               [24]  316 	movx	a,@dptr
      003C4E FF               [12]  317 	mov	r7,a
      003C4F 7E 00            [12]  318 	mov	r6,#0x00
      003C51 90 05 62         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      003C54 E0               [24]  320 	movx	a,@dptr
      003C55 6E               [12]  321 	xrl	a,r6
      003C56 F0               [24]  322 	movx	@dptr,a
      003C57 A3               [24]  323 	inc	dptr
      003C58 E0               [24]  324 	movx	a,@dptr
      003C59 6F               [12]  325 	xrl	a,r7
      003C5A F0               [24]  326 	movx	@dptr,a
                                    327 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: for (bit = 0; bit != 8; ++bit) {
      003C5B 7F 00            [12]  328 	mov	r7,#0x00
      003C5D                        329 00102$:
                                    330 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C5D 90 05 62         [24]  331 	mov	dptr,#_crc_byte_crc_10000_25
      003C60 12 44 17         [24]  332 	lcall	_ak820_outline_0025
      003C63 30 E7 0E         [24]  333 	jnb	acc.7,00106$
      003C66 ED               [12]  334 	mov	a,r5
      003C67 2D               [12]  335 	add	a,r5
      003C68 FB               [12]  336 	mov	r3,a
      003C69 EE               [12]  337 	mov	a,r6
      003C6A 33               [12]  338 	rlc	a
      003C6B FC               [12]  339 	mov	r4,a
      003C6C 63 03 21         [24]  340 	xrl	ar3,#0x21
      003C6F 63 04 10         [24]  341 	xrl	ar4,#0x10
      003C72 80 06            [24]  342 	sjmp	00107$
      003C74                        343 00106$:
      003C74 ED               [12]  344 	mov	a,r5
      003C75 2D               [12]  345 	add	a,r5
      003C76 FB               [12]  346 	mov	r3,a
      003C77 EE               [12]  347 	mov	a,r6
      003C78 33               [12]  348 	rlc	a
      003C79 FC               [12]  349 	mov	r4,a
      003C7A                        350 00107$:
      003C7A 90 05 62         [24]  351 	mov	dptr,#_crc_byte_crc_10000_25
      003C7D 12 44 50         [24]  352 	lcall	_ak820_outline_0060
                                    353 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: for (bit = 0; bit != 8; ++bit) {
      003C80 0F               [12]  354 	inc	r7
      003C81 BF 08 D9         [24]  355 	cjne	r7,#0x08,00102$
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: return crc;
      003C84 12 43 F9         [24]  357 	lcall	_ak820_outline_0014
                                    358 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C87 22               [24]  359 	ret
                                    360 ;------------------------------------------------------------
                                    361 ;Allocation info for local variables in function 'page_crc'
                                    362 ;------------------------------------------------------------
                                    363 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    364 ;i             Allocated with name '_page_crc_i_10000_30'
                                    365 ;------------------------------------------------------------
                                    366 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t page_crc(void) {
                                    367 ;	-----------------------------------------
                                    368 ;	 function page_crc
                                    369 ;	-----------------------------------------
      003C88                        370 _page_crc:
                                    371 ;	keyboards/ajazz/ak820/ak820_nvm.c:47: uint16_t crc = 0xFFFFu;
      003C88 90 05 64         [24]  372 	mov	dptr,#_page_crc_crc_10000_30
      003C8B 74 FF            [12]  373 	mov	a,#0xff
      003C8D F0               [24]  374 	movx	@dptr,a
      003C8E A3               [24]  375 	inc	dptr
      003C8F F0               [24]  376 	movx	@dptr,a
                                    377 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C90 7F 00            [12]  378 	mov	r7,#0x00
      003C92                        379 00102$:
      003C92 90 05 64         [24]  380 	mov	dptr,#_page_crc_crc_10000_30
      003C95 12 44 17         [24]  381 	lcall	_ak820_outline_0025
      003C98 12 44 67         [24]  382 	lcall	_ak820_outline_0083
      003C9B 90 05 61         [24]  383 	mov	dptr,#_crc_byte_PARM_2
      003C9E F0               [24]  384 	movx	@dptr,a
      003C9F 12 43 F4         [24]  385 	lcall	_ak820_outline_0012
      003CA2 C0 07            [24]  386 	push	ar7
      003CA4 12 3C 41         [24]  387 	lcall	_crc_byte
      003CA7 AD 82            [24]  388 	mov	r5, dpl
      003CA9 AE 83            [24]  389 	mov	r6, dph
      003CAB D0 07            [24]  390 	pop	ar7
      003CAD 90 05 64         [24]  391 	mov	dptr,#_page_crc_crc_10000_30
      003CB0 12 44 56         [24]  392 	lcall	_ak820_outline_0071
      003CB3 0F               [12]  393 	inc	r7
      003CB4 BF 40 DB         [24]  394 	cjne	r7,#0x40,00102$
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: return crc;
      003CB7 12 43 F4         [24]  396 	lcall	_ak820_outline_0012
                                    397 ;	keyboards/ajazz/ak820/ak820_nvm.c:51: }
      003CBA 22               [24]  398 	ret
                                    399 ;------------------------------------------------------------
                                    400 ;Allocation info for local variables in function 'write_page'
                                    401 ;------------------------------------------------------------
                                    402 ;address       Allocated with name '_write_page_address_10000_32'
                                    403 ;i             Allocated with name '_write_page_i_10000_33'
                                    404 ;------------------------------------------------------------
                                    405 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: static bool write_page(uint16_t address) {
                                    406 ;	-----------------------------------------
                                    407 ;	 function write_page
                                    408 ;	-----------------------------------------
      003CBB                        409 _write_page:
      003CBB 12 43 EA         [24]  410 	lcall	_ak820_outline_0010
      003CBE 90 05 66         [24]  411 	mov	dptr,#_write_page_address_10000_32
      003CC1 12 43 E5         [24]  412 	lcall	_ak820_outline_0007
                                    413 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: if (!ak820_flash_erase(address)) return false;
      003CC4 90 05 66         [24]  414 	mov	dptr,#_write_page_address_10000_32
      003CC7 12 43 C5         [24]  415 	lcall	_ak820_outline_0000
      003CCA 12 43 D3         [24]  416 	lcall	_ak820_outline_0002
      003CCD C0 07            [24]  417 	push	ar7
      003CCF C0 06            [24]  418 	push	ar6
      003CD1 12 3A 39         [24]  419 	lcall	_ak820_flash_erase
      003CD4 E5 82            [12]  420 	mov	a, dpl
      003CD6 D0 06            [24]  421 	pop	ar6
      003CD8 D0 07            [24]  422 	pop	ar7
      003CDA 70 03            [24]  423 	jnz	00102$
      003CDC F5 82            [12]  424 	mov	dpl,a
      003CDE 22               [24]  425 	ret
      003CDF                        426 00102$:
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: if (!ak820_flash_program_page(address, page_data)) return false;
      003CDF 90 04 F2         [24]  428 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CE2 74 17            [12]  429 	mov	a,#_page_data
      003CE4 F0               [24]  430 	movx	@dptr,a
      003CE5 74 05            [12]  431 	mov	a,#(_page_data >> 8)
      003CE7 A3               [24]  432 	inc	dptr
      003CE8 F0               [24]  433 	movx	@dptr,a
      003CE9 12 43 D3         [24]  434 	lcall	_ak820_outline_0002
      003CEC 12 3B 4D         [24]  435 	lcall	_ak820_flash_program_page
      003CEF E5 82            [12]  436 	mov	a, dpl
      003CF1 70 03            [24]  437 	jnz	00120$
      003CF3 F5 82            [12]  438 	mov	dpl,a
                                    439 ;	keyboards/ajazz/ak820/ak820_nvm.c:57: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CF5 22               [24]  440 	ret
      003CF6                        441 00120$:
      003CF6 7F 00            [12]  442 	mov	r7,#0x00
      003CF8                        443 00108$:
                                    444 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003CF8 8F 05            [24]  445 	mov	ar5,r7
      003CFA 7E 00            [12]  446 	mov	r6,#0x00
      003CFC 90 05 66         [24]  447 	mov	dptr,#_write_page_address_10000_32
      003CFF 12 44 73         [24]  448 	lcall	_ak820_outline_0089
      003D02 ED               [12]  449 	mov	a,r5
      003D03 2B               [12]  450 	add	a, r3
      003D04 FB               [12]  451 	mov	r3,a
      003D05 EE               [12]  452 	mov	a,r6
      003D06 3C               [12]  453 	addc	a, r4
      003D07 FC               [12]  454 	mov	r4,a
      003D08 12 43 F9         [24]  455 	lcall	_ak820_outline_0014
      003D0B 12 39 2C         [24]  456 	lcall	_ak820_flash_read
      003D0E AE 82            [24]  457 	mov	r6, dpl
      003D10 12 44 67         [24]  458 	lcall	_ak820_outline_0083
      003D13 FD               [12]  459 	mov	r5,a
      003D14 EE               [12]  460 	mov	a,r6
      003D15 B5 05 02         [24]  461 	cjne	a,ar5,00149$
      003D18 80 04            [24]  462 	sjmp	00109$
      003D1A                        463 00149$:
      003D1A 75 82 00         [24]  464 	mov	dpl, #0x00
      003D1D 22               [24]  465 	ret
      003D1E                        466 00109$:
                                    467 ;	keyboards/ajazz/ak820/ak820_nvm.c:57: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D1E 0F               [12]  468 	inc	r7
      003D1F BF 40 D6         [24]  469 	cjne	r7,#0x40,00108$
                                    470 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: return true;
      003D22 75 82 01         [24]  471 	mov	dpl, #0x01
                                    472 ;	keyboards/ajazz/ak820/ak820_nvm.c:61: }
      003D25 22               [24]  473 	ret
                                    474 ;------------------------------------------------------------
                                    475 ;Allocation info for local variables in function 'journal_header_valid'
                                    476 ;------------------------------------------------------------
                                    477 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    478 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    479 ;------------------------------------------------------------
                                    480 ;	keyboards/ajazz/ak820/ak820_nvm.c:63: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    481 ;	-----------------------------------------
                                    482 ;	 function journal_header_valid
                                    483 ;	-----------------------------------------
      003D26                        484 _journal_header_valid:
      003D26 12 43 EA         [24]  485 	lcall	_ak820_outline_0010
      003D29 90 05 68         [24]  486 	mov	dptr,#_journal_header_valid_header_10000_39
      003D2C 12 43 E5         [24]  487 	lcall	_ak820_outline_0007
                                    488 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (header[0] != 0xA5u) return false;
      003D2F 90 05 68         [24]  489 	mov	dptr,#_journal_header_valid_header_10000_39
      003D32 12 43 C5         [24]  490 	lcall	_ak820_outline_0000
      003D35 12 43 D3         [24]  491 	lcall	_ak820_outline_0002
      003D38 E0               [24]  492 	movx	a,@dptr
      003D39 FD               [12]  493 	mov	r5,a
      003D3A BD A5 02         [24]  494 	cjne	r5,#0xa5,00138$
      003D3D 80 04            [24]  495 	sjmp	00116$
      003D3F                        496 00138$:
      003D3F 75 82 00         [24]  497 	mov	dpl, #0x00
                                    498 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 1; i != 5; ++i) {
      003D42 22               [24]  499 	ret
      003D43                        500 00116$:
      003D43 7D 01            [12]  501 	mov	r5,#0x01
      003D45                        502 00106$:
                                    503 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D45 ED               [12]  504 	mov	a,r5
      003D46 12 43 FE         [24]  505 	lcall	_ak820_outline_0015
      003D49 E0               [24]  506 	movx	a,@dptr
      003D4A FC               [12]  507 	mov	r4,a
      003D4B 8D 02            [24]  508 	mov	ar2,r5
      003D4D 7B 00            [12]  509 	mov	r3,#0x00
      003D4F 74 04            [12]  510 	mov	a,#0x04
      003D51 2A               [12]  511 	add	a, r2
      003D52 FA               [12]  512 	mov	r2,a
      003D53 E4               [12]  513 	clr	a
      003D54 3B               [12]  514 	addc	a, r3
      003D55 FB               [12]  515 	mov	r3,a
      003D56 EA               [12]  516 	mov	a,r2
      003D57 2E               [12]  517 	add	a, r6
      003D58 F5 82            [12]  518 	mov	dpl,a
      003D5A EB               [12]  519 	mov	a,r3
      003D5B 3F               [12]  520 	addc	a, r7
      003D5C F5 83            [12]  521 	mov	dph,a
      003D5E E0               [24]  522 	movx	a,@dptr
      003D5F 62 04            [12]  523 	xrl	ar4,a
      003D61 BC FF 02         [24]  524 	cjne	r4,#0xff,00139$
      003D64 80 04            [24]  525 	sjmp	00107$
      003D66                        526 00139$:
      003D66 75 82 00         [24]  527 	mov	dpl, #0x00
      003D69 22               [24]  528 	ret
      003D6A                        529 00107$:
                                    530 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 1; i != 5; ++i) {
      003D6A 0D               [12]  531 	inc	r5
      003D6B BD 05 D7         [24]  532 	cjne	r5,#0x05,00106$
                                    533 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003D6E 75 82 01         [24]  534 	mov	dpl, #0x01
                                    535 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003D71 22               [24]  536 	ret
                                    537 ;------------------------------------------------------------
                                    538 ;Allocation info for local variables in function 'recover_journal'
                                    539 ;------------------------------------------------------------
                                    540 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    541 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    542 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    543 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    544 ;------------------------------------------------------------
                                    545 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static void recover_journal(void) {
                                    546 ;	-----------------------------------------
                                    547 ;	 function recover_journal
                                    548 ;	-----------------------------------------
      003D72                        549 _recover_journal:
                                    550 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D72 7F 00            [12]  551 	mov	r7,#0x00
      003D74                        552 00115$:
      003D74 EF               [12]  553 	mov	a,r7
      003D75 24 6A            [12]  554 	add	a, #_recover_journal_header_10000_46
      003D77 FD               [12]  555 	mov	r5,a
      003D78 E4               [12]  556 	clr	a
      003D79 34 05            [12]  557 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D7B FE               [12]  558 	mov	r6,a
      003D7C 8F 04            [24]  559 	mov	ar4,r7
      003D7E 7B 00            [12]  560 	mov	r3,#0x00
      003D80 74 40            [12]  561 	mov	a,#0x40
      003D82 2C               [12]  562 	add	a, r4
      003D83 FC               [12]  563 	mov	r4,a
      003D84 74 EF            [12]  564 	mov	a,#0xef
      003D86 3B               [12]  565 	addc	a, r3
      003D87 FB               [12]  566 	mov	r3,a
      003D88 12 44 96         [24]  567 	lcall	_ak820_outline_0147
      003D8B 12 39 2C         [24]  568 	lcall	_ak820_flash_read
      003D8E AC 82            [24]  569 	mov	r4, dpl
      003D90 12 43 F4         [24]  570 	lcall	_ak820_outline_0012
      003D93 EC               [12]  571 	mov	a,r4
      003D94 F0               [24]  572 	movx	@dptr,a
      003D95 0F               [12]  573 	inc	r7
      003D96 BF 09 DB         [24]  574 	cjne	r7,#0x09,00115$
                                    575 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: if (!journal_header_valid(header)) return;
      003D99 90 05 6A         [24]  576 	mov	dptr,#_recover_journal_header_10000_46
      003D9C 12 3D 26         [24]  577 	lcall	_journal_header_valid
      003D9F E5 82            [12]  578 	mov	a, dpl
      003DA1 70 01            [24]  579 	jnz	00103$
      003DA3 22               [24]  580 	ret
      003DA4                        581 00103$:
                                    582 ;	keyboards/ajazz/ak820/ak820_nvm.c:80: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003DA4 90 05 6B         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003DA7 E0               [24]  584 	movx	a,@dptr
      003DA8 FF               [12]  585 	mov	r7,a
      003DA9 7E 00            [12]  586 	mov	r6,#0x00
      003DAB 90 05 6C         [24]  587 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003DAE E0               [24]  588 	movx	a,@dptr
      003DAF FC               [12]  589 	mov	r4,a
      003DB0 E4               [12]  590 	clr	a
      003DB1 42 07            [12]  591 	orl	ar7,a
      003DB3 EC               [12]  592 	mov	a,r4
      003DB4 42 06            [12]  593 	orl	ar6,a
                                    594 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003DB6 90 05 6D         [24]  595 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003DB9 E0               [24]  596 	movx	a,@dptr
      003DBA FD               [12]  597 	mov	r5,a
      003DBB 7C 00            [12]  598 	mov	r4,#0x00
      003DBD 90 05 6E         [24]  599 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003DC0 12 44 88         [24]  600 	lcall	_ak820_outline_0145
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:82: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003DC3 C3               [12]  602 	clr	c
      003DC4 EF               [12]  603 	mov	a,r7
      003DC5 94 A0            [12]  604 	subb	a,#0xa0
      003DC7 EE               [12]  605 	mov	a,r6
      003DC8 94 00            [12]  606 	subb	a,#0x00
      003DCA 40 06            [24]  607 	jc	00134$
                                    608 ;	keyboards/ajazz/ak820/ak820_nvm.c:83: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003DCC 75 82 01         [24]  609 	mov	dpl, #0x01
                                    610 ;	keyboards/ajazz/ak820/ak820_nvm.c:84: return;
      003DCF 02 3B C0         [24]  611 	ljmp	_nvm_fail
                                    612 ;	keyboards/ajazz/ak820/ak820_nvm.c:86: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DD2                        613 00134$:
      003DD2 7B 00            [12]  614 	mov	r3,#0x00
      003DD4                        615 00117$:
      003DD4 C0 05            [24]  616 	push	ar5
      003DD6 C0 04            [24]  617 	push	ar4
      003DD8 EB               [12]  618 	mov	a,r3
      003DD9 24 17            [12]  619 	add	a, #_page_data
      003DDB F9               [12]  620 	mov	r1,a
      003DDC E4               [12]  621 	clr	a
      003DDD 34 05            [12]  622 	addc	a, #(_page_data >> 8)
      003DDF FA               [12]  623 	mov	r2,a
      003DE0 8B 00            [24]  624 	mov	ar0,r3
      003DE2 7D 00            [12]  625 	mov	r5,#0x00
      003DE4 74 EF            [12]  626 	mov	a,#0xef
      003DE6 2D               [12]  627 	add	a, r5
      003DE7 FD               [12]  628 	mov	r5,a
      003DE8 88 82            [24]  629 	mov	dpl, r0
      003DEA 8D 83            [24]  630 	mov	dph, r5
      003DEC 12 39 2C         [24]  631 	lcall	_ak820_flash_read
      003DEF AD 82            [24]  632 	mov	r5, dpl
      003DF1 12 44 06         [24]  633 	lcall	_ak820_outline_0016
      003DF4 ED               [12]  634 	mov	a,r5
      003DF5 F0               [24]  635 	movx	@dptr,a
      003DF6 0B               [12]  636 	inc	r3
      003DF7 BB 40 02         [24]  637 	cjne	r3,#0x40,00190$
      003DFA 80 06            [24]  638 	sjmp	00191$
      003DFC                        639 00190$:
      003DFC D0 04            [24]  640 	pop	ar4
      003DFE D0 05            [24]  641 	pop	ar5
      003E00 80 D2            [24]  642 	sjmp	00117$
      003E02                        643 00191$:
      003E02 D0 04            [24]  644 	pop	ar4
      003E04 D0 05            [24]  645 	pop	ar5
                                    646 ;	keyboards/ajazz/ak820/ak820_nvm.c:87: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003E06 C0 07            [24]  647 	push	ar7
      003E08 C0 06            [24]  648 	push	ar6
      003E0A C0 05            [24]  649 	push	ar5
      003E0C C0 04            [24]  650 	push	ar4
      003E0E 12 3C 88         [24]  651 	lcall	_page_crc
      003E11 AA 82            [24]  652 	mov	r2, dpl
      003E13 AB 83            [24]  653 	mov	r3, dph
      003E15 D0 04            [24]  654 	pop	ar4
      003E17 D0 05            [24]  655 	pop	ar5
      003E19 D0 06            [24]  656 	pop	ar6
      003E1B D0 07            [24]  657 	pop	ar7
      003E1D EA               [12]  658 	mov	a,r2
      003E1E B5 05 06         [24]  659 	cjne	a,ar5,00192$
      003E21 EB               [12]  660 	mov	a,r3
      003E22 B5 04 02         [24]  661 	cjne	a,ar4,00192$
      003E25 80 06            [24]  662 	sjmp	00113$
      003E27                        663 00192$:
      003E27 75 82 02         [24]  664 	mov	dpl, #0x02
      003E2A 02 3B C0         [24]  665 	ljmp	_nvm_fail
      003E2D                        666 00113$:
                                    667 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E2D EE               [12]  668 	mov	a,r6
      003E2E 54 03            [12]  669 	anl	a,#0x03
      003E30 A2 E0            [12]  670 	mov	c,acc.0
      003E32 CF               [12]  671 	xch	a,r7
      003E33 13               [12]  672 	rrc	a
      003E34 CF               [12]  673 	xch	a,r7
      003E35 13               [12]  674 	rrc	a
      003E36 A2 E0            [12]  675 	mov	c,acc.0
      003E38 CF               [12]  676 	xch	a,r7
      003E39 13               [12]  677 	rrc	a
      003E3A CF               [12]  678 	xch	a,r7
      003E3B 13               [12]  679 	rrc	a
      003E3C CF               [12]  680 	xch	a,r7
      003E3D 24 C7            [12]  681 	add	a,#0xc7
      003E3F FE               [12]  682 	mov	r6,a
      003E40 12 44 79         [24]  683 	lcall	_ak820_outline_0129
      003E43 12 3C BB         [24]  684 	lcall	_write_page
      003E46 E5 82            [12]  685 	mov	a, dpl
      003E48 70 06            [24]  686 	jnz	00110$
      003E4A 75 82 03         [24]  687 	mov	dpl, #0x03
      003E4D 02 3B C0         [24]  688 	ljmp	_nvm_fail
      003E50                        689 00110$:
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E50 90 EF 40         [24]  691 	mov	dptr,#0xef40
      003E53 12 3A 39         [24]  692 	lcall	_ak820_flash_erase
      003E56 E5 82            [12]  693 	mov	a, dpl
      003E58 70 06            [24]  694 	jnz	00119$
      003E5A 75 82 04         [24]  695 	mov	dpl, #0x04
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: }
      003E5D 02 3B C0         [24]  697 	ljmp	_nvm_fail
      003E60                        698 00119$:
      003E60 22               [24]  699 	ret
                                    700 ;------------------------------------------------------------
                                    701 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: void eeprom_driver_init(void) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function eeprom_driver_init
                                    706 ;	-----------------------------------------
      003E61                        707 _eeprom_driver_init:
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: storage_failed = false;
      003E61 90 05 5B         [24]  709 	mov	dptr,#_storage_failed
      003E64 E4               [12]  710 	clr	a
      003E65 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:94: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E66 90 05 5D         [24]  713 	mov	dptr,#_first_failure_stage
      003E69 F0               [24]  714 	movx	@dptr,a
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: page_valid = page_dirty = false;
      003E6A 90 05 5A         [24]  716 	mov	dptr,#_page_dirty
      003E6D F0               [24]  717 	movx	@dptr,a
      003E6E 90 05 59         [24]  718 	mov	dptr,#_page_valid
      003E71 F0               [24]  719 	movx	@dptr,a
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: batch_depth = 0;
      003E72 90 05 5C         [24]  721 	mov	dptr,#_batch_depth
      003E75 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: recover_journal();
      003E76 12 3D 72         [24]  724 	lcall	_recover_journal
                                    725 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: ak820_macro_init();
                                    726 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: }
      003E79 02 2A BA         [24]  727 	ljmp	_ak820_macro_init
                                    728 ;------------------------------------------------------------
                                    729 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    730 ;------------------------------------------------------------
                                    731 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    732 ;	-----------------------------------------
                                    733 ;	 function ak820_nvm_ok
                                    734 ;	-----------------------------------------
      003E7C                        735 _ak820_nvm_ok:
      003E7C C0 07            [24]  736 	push	ar7
      003E7E 12 44 7E         [24]  737 	lcall	_ak820_outline_0131
      003E81 B4 01 00         [24]  738 	cjne	a,#0x01,00103$
      003E84                        739 00103$:
      003E84 92 08            [24]  740 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E86 12 44 91         [24]  741 	lcall	_ak820_outline_0146
      003E89 D0 07            [24]  742 	pop	ar7
      003E8B 22               [24]  743 	ret
                                    744 ;------------------------------------------------------------
                                    745 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_schema_fault
                                    750 ;	-----------------------------------------
      003E8C                        751 _ak820_nvm_schema_fault:
      003E8C 75 82 10         [24]  752 	mov	dpl, #0x10
      003E8F 02 3B C0         [24]  753 	ljmp	_nvm_fail
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    756 ;------------------------------------------------------------
                                    757 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    758 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    759 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    760 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    761 ;------------------------------------------------------------
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:107: void ak820_nvm_flush(void) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function ak820_nvm_flush
                                    765 ;	-----------------------------------------
      003E92                        766 _ak820_nvm_flush:
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: if (!page_dirty || storage_failed) return;
      003E92 90 05 5A         [24]  768 	mov	dptr,#_page_dirty
      003E95 E0               [24]  769 	movx	a,@dptr
      003E96 60 05            [24]  770 	jz	00101$
      003E98 12 44 7E         [24]  771 	lcall	_ak820_outline_0131
      003E9B 60 01            [24]  772 	jz	00102$
      003E9D                        773 00101$:
      003E9D 22               [24]  774 	ret
      003E9E                        775 00102$:
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:113: crc = page_crc();
      003E9E 12 3C 88         [24]  777 	lcall	_page_crc
      003EA1 12 44 1D         [24]  778 	lcall	_ak820_outline_0027
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: header[0] = 0xA5u;
      003EA4 90 05 73         [24]  780 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EA7 74 A5            [12]  781 	mov	a,#0xa5
      003EA9 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_nvm.c:115: header[1] = (uint8_t)cached_page;
      003EAA 90 05 57         [24]  784 	mov	dptr,#_cached_page
      003EAD E0               [24]  785 	movx	a,@dptr
      003EAE 90 05 74         [24]  786 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003EB1 F0               [24]  787 	movx	@dptr,a
                                    788 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: header[2] = (uint8_t)(cached_page >> 8);
      003EB2 90 05 57         [24]  789 	mov	dptr,#_cached_page
      003EB5 E0               [24]  790 	movx	a,@dptr
      003EB6 A3               [24]  791 	inc	dptr
      003EB7 E0               [24]  792 	movx	a,@dptr
      003EB8 90 05 75         [24]  793 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003EBB F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_nvm.c:117: header[3] = (uint8_t)crc;
      003EBC 8E 05            [24]  796 	mov	ar5,r6
      003EBE 90 05 76         [24]  797 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003EC1 ED               [12]  798 	mov	a,r5
      003EC2 F0               [24]  799 	movx	@dptr,a
                                    800 ;	keyboards/ajazz/ak820/ak820_nvm.c:118: header[4] = (uint8_t)(crc >> 8);
      003EC3 8F 06            [24]  801 	mov	ar6,r7
      003EC5 90 05 77         [24]  802 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003EC8 EE               [12]  803 	mov	a,r6
      003EC9 F0               [24]  804 	movx	@dptr,a
                                    805 ;	keyboards/ajazz/ak820/ak820_nvm.c:119: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003ECA 7F 01            [12]  806 	mov	r7,#0x01
      003ECC                        807 00128$:
      003ECC 8F 06            [24]  808 	mov	ar6,r7
      003ECE EE               [12]  809 	mov	a,r6
      003ECF 24 04            [12]  810 	add	a,#0x04
      003ED1 FE               [12]  811 	mov	r6,a
      003ED2 33               [12]  812 	rlc	a
      003ED3 95 E0            [12]  813 	subb	a,acc
      003ED5 FD               [12]  814 	mov	r5,a
      003ED6 EE               [12]  815 	mov	a,r6
      003ED7 24 73            [12]  816 	add	a, #_ak820_nvm_flush_header_10000_62
      003ED9 FE               [12]  817 	mov	r6,a
      003EDA ED               [12]  818 	mov	a,r5
      003EDB 34 05            [12]  819 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003EDD FD               [12]  820 	mov	r5,a
      003EDE 12 44 27         [24]  821 	lcall	_ak820_outline_0039
      003EE1 FC               [12]  822 	mov	r4,a
      003EE2 63 04 FF         [24]  823 	xrl	ar4,#0xff
      003EE5 8E 82            [24]  824 	mov	dpl,r6
      003EE7 8D 83            [24]  825 	mov	dph,r5
      003EE9 EC               [12]  826 	mov	a,r4
      003EEA F0               [24]  827 	movx	@dptr,a
      003EEB 0F               [12]  828 	inc	r7
      003EEC BF 05 DD         [24]  829 	cjne	r7,#0x05,00128$
                                    830 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EEF 90 05 7C         [24]  831 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF2 74 05            [12]  832 	mov	a,#0x05
      003EF4 F0               [24]  833 	movx	@dptr,a
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EF5 90 EF 40         [24]  835 	mov	dptr,#0xef40
      003EF8 12 3A 39         [24]  836 	lcall	_ak820_flash_erase
      003EFB E5 82            [12]  837 	mov	a, dpl
      003EFD 70 03            [24]  838 	jnz	00269$
      003EFF 02 3F ED         [24]  839 	ljmp	00127$
      003F02                        840 00269$:
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003F02 90 05 7C         [24]  842 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F05 74 06            [12]  843 	mov	a,#0x06
      003F07 F0               [24]  844 	movx	@dptr,a
                                    845 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F08 7F 00            [12]  846 	mov	r7,#0x00
      003F0A                        847 00130$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003F0A 12 44 3F         [24]  849 	lcall	_ak820_outline_0051
      003F0D 12 39 2C         [24]  850 	lcall	_ak820_flash_read
      003F10 E5 82            [12]  851 	mov	a, dpl
      003F12 60 03            [24]  852 	jz	00270$
      003F14 02 3F ED         [24]  853 	ljmp	00127$
      003F17                        854 00270$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F17 0F               [12]  856 	inc	r7
      003F18 BF 40 EF         [24]  857 	cjne	r7,#0x40,00130$
                                    858 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003F1B 90 05 7C         [24]  859 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F1E 74 07            [12]  860 	mov	a,#0x07
      003F20 F0               [24]  861 	movx	@dptr,a
                                    862 ;	keyboards/ajazz/ak820/ak820_nvm.c:129: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003F21 90 EF 00         [24]  863 	mov	dptr,#0xef00
      003F24 12 3C BB         [24]  864 	lcall	_write_page
      003F27 E5 82            [12]  865 	mov	a, dpl
      003F29 70 03            [24]  866 	jnz	00273$
      003F2B 02 3F ED         [24]  867 	ljmp	00127$
      003F2E                        868 00273$:
                                    869 ;	keyboards/ajazz/ak820/ak820_nvm.c:130: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003F2E 90 05 7C         [24]  870 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F31 74 08            [12]  871 	mov	a,#0x08
      003F33 F0               [24]  872 	movx	@dptr,a
                                    873 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: for (i = 1; i != sizeof(header); ++i) {
      003F34 7F 01            [12]  874 	mov	r7,#0x01
      003F36                        875 00132$:
                                    876 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003F36 12 44 27         [24]  877 	lcall	_ak820_outline_0039
      003F39 FE               [12]  878 	mov	r6,a
      003F3A 60 23            [24]  879 	jz	00133$
      003F3C 8F 05            [24]  880 	mov	ar5,r7
      003F3E 7C 00            [12]  881 	mov	r4,#0x00
      003F40 74 40            [12]  882 	mov	a,#0x40
      003F42 2D               [12]  883 	add	a, r5
      003F43 FD               [12]  884 	mov	r5,a
      003F44 74 EF            [12]  885 	mov	a,#0xef
      003F46 3C               [12]  886 	addc	a, r4
      003F47 FC               [12]  887 	mov	r4,a
      003F48 90 04 EF         [24]  888 	mov	dptr,#_ak820_flash_program_PARM_2
      003F4B EE               [12]  889 	mov	a,r6
      003F4C F0               [24]  890 	movx	@dptr,a
      003F4D 8D 82            [24]  891 	mov	dpl, r5
      003F4F 8C 83            [24]  892 	mov	dph, r4
      003F51 C0 07            [24]  893 	push	ar7
      003F53 12 3A 99         [24]  894 	lcall	_ak820_flash_program
      003F56 E5 82            [12]  895 	mov	a, dpl
      003F58 D0 07            [24]  896 	pop	ar7
      003F5A 70 03            [24]  897 	jnz	00275$
      003F5C 02 3F ED         [24]  898 	ljmp	00127$
      003F5F                        899 00275$:
      003F5F                        900 00133$:
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: for (i = 1; i != sizeof(header); ++i) {
      003F5F 0F               [12]  902 	inc	r7
      003F60 BF 09 D3         [24]  903 	cjne	r7,#0x09,00132$
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F63 90 05 7C         [24]  905 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F66 74 09            [12]  906 	mov	a,#0x09
      003F68 F0               [24]  907 	movx	@dptr,a
                                    908 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: for (i = 1; i != sizeof(header); ++i) {
      003F69 7F 01            [12]  909 	mov	r7,#0x01
      003F6B                        910 00134$:
                                    911 ;	keyboards/ajazz/ak820/ak820_nvm.c:136: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F6B 12 44 3F         [24]  912 	lcall	_ak820_outline_0051
      003F6E 12 39 2C         [24]  913 	lcall	_ak820_flash_read
      003F71 AE 82            [24]  914 	mov	r6, dpl
      003F73 12 44 27         [24]  915 	lcall	_ak820_outline_0039
      003F76 FD               [12]  916 	mov	r5,a
      003F77 EE               [12]  917 	mov	a,r6
      003F78 B5 05 72         [24]  918 	cjne	a,ar5,00127$
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: for (i = 1; i != sizeof(header); ++i) {
      003F7B 0F               [12]  920 	inc	r7
      003F7C BF 09 EC         [24]  921 	cjne	r7,#0x09,00134$
                                    922 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F7F 90 05 7C         [24]  923 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F82 74 0A            [12]  924 	mov	a,#0x0a
      003F84 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F85 90 05 73         [24]  927 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F88 E0               [24]  928 	movx	a,@dptr
      003F89 90 04 EF         [24]  929 	mov	dptr,#_ak820_flash_program_PARM_2
      003F8C F0               [24]  930 	movx	@dptr,a
      003F8D 90 EF 40         [24]  931 	mov	dptr,#0xef40
      003F90 12 3A 99         [24]  932 	lcall	_ak820_flash_program
      003F93 E5 82            [12]  933 	mov	a, dpl
      003F95 60 56            [24]  934 	jz	00127$
                                    935 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F97 90 05 7C         [24]  936 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F9A 74 0B            [12]  937 	mov	a,#0x0b
      003F9C F0               [24]  938 	movx	@dptr,a
                                    939 ;	keyboards/ajazz/ak820/ak820_nvm.c:142: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F9D 90 EF 40         [24]  940 	mov	dptr,#0xef40
      003FA0 12 39 2C         [24]  941 	lcall	_ak820_flash_read
      003FA3 AF 82            [24]  942 	mov	r7, dpl
      003FA5 90 05 73         [24]  943 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003FA8 E0               [24]  944 	movx	a,@dptr
      003FA9 FE               [12]  945 	mov	r6,a
      003FAA EF               [12]  946 	mov	a,r7
      003FAB B5 06 3F         [24]  947 	cjne	a,ar6,00127$
                                    948 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003FAE 90 05 7C         [24]  949 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FB1 74 0C            [12]  950 	mov	a,#0x0c
      003FB3 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003FB4 90 05 57         [24]  953 	mov	dptr,#_cached_page
      003FB7 E0               [24]  954 	movx	a,@dptr
      003FB8 FE               [12]  955 	mov	r6,a
      003FB9 A3               [24]  956 	inc	dptr
      003FBA E0               [24]  957 	movx	a,@dptr
      003FBB 54 03            [12]  958 	anl	a,#0x03
      003FBD A2 E0            [12]  959 	mov	c,acc.0
      003FBF CE               [12]  960 	xch	a,r6
      003FC0 13               [12]  961 	rrc	a
      003FC1 CE               [12]  962 	xch	a,r6
      003FC2 13               [12]  963 	rrc	a
      003FC3 A2 E0            [12]  964 	mov	c,acc.0
      003FC5 CE               [12]  965 	xch	a,r6
      003FC6 13               [12]  966 	rrc	a
      003FC7 CE               [12]  967 	xch	a,r6
      003FC8 13               [12]  968 	rrc	a
      003FC9 CE               [12]  969 	xch	a,r6
      003FCA 24 C7            [12]  970 	add	a,#0xc7
      003FCC FF               [12]  971 	mov	r7,a
      003FCD 12 43 D3         [24]  972 	lcall	_ak820_outline_0002
      003FD0 12 3C BB         [24]  973 	lcall	_write_page
      003FD3 E5 82            [12]  974 	mov	a, dpl
      003FD5 60 16            [24]  975 	jz	00127$
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: stage = AK820_NVM_FAULT_CLEANUP;
      003FD7 90 05 7C         [24]  977 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FDA 74 0D            [12]  978 	mov	a,#0x0d
      003FDC F0               [24]  979 	movx	@dptr,a
                                    980 ;	keyboards/ajazz/ak820/ak820_nvm.c:146: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003FDD 90 EF 40         [24]  981 	mov	dptr,#0xef40
      003FE0 12 3A 39         [24]  982 	lcall	_ak820_flash_erase
      003FE3 E5 82            [12]  983 	mov	a, dpl
      003FE5 60 06            [24]  984 	jz	00127$
                                    985 ;	keyboards/ajazz/ak820/ak820_nvm.c:147: page_dirty = false;
      003FE7 90 05 5A         [24]  986 	mov	dptr,#_page_dirty
      003FEA E4               [12]  987 	clr	a
      003FEB F0               [24]  988 	movx	@dptr,a
                                    989 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: return;
                                    990 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: failed:
      003FEC 22               [24]  991 	ret
      003FED                        992 00127$:
                                    993 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: nvm_fail(stage);
      003FED 90 05 7C         [24]  994 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FF0 E0               [24]  995 	movx	a,@dptr
      003FF1 F5 82            [12]  996 	mov	dpl,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: }
      003FF3 02 3B C0         [24]  998 	ljmp	_nvm_fail
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: void ak820_nvm_begin(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_begin
                                   1005 ;	-----------------------------------------
      003FF6                       1006 _ak820_nvm_begin:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FF6 90 05 5C         [24] 1008 	mov	dptr,#_batch_depth
      003FF9 E0               [24] 1009 	movx	a,@dptr
      003FFA FF               [12] 1010 	mov	r7,a
      003FFB BF FF 06         [24] 1011 	cjne	r7,#0xff,00102$
      003FFE 75 82 0F         [24] 1012 	mov	dpl, #0x0f
      004001 02 3B C0         [24] 1013 	ljmp	_nvm_fail
      004004                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: else ++batch_depth;
      004004 90 05 5C         [24] 1016 	mov	dptr,#_batch_depth
      004007 EF               [12] 1017 	mov	a,r7
      004008 04               [12] 1018 	inc	a
      004009 F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: }
      00400A 22               [24] 1021 	ret
                                   1022 ;------------------------------------------------------------
                                   1023 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1024 ;------------------------------------------------------------
                                   1025 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: void ak820_nvm_end(void) {
                                   1026 ;	-----------------------------------------
                                   1027 ;	 function ak820_nvm_end
                                   1028 ;	-----------------------------------------
      00400B                       1029 _ak820_nvm_end:
                                   1030 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: if (batch_depth) --batch_depth;
      00400B 90 05 5C         [24] 1031 	mov	dptr,#_batch_depth
      00400E E0               [24] 1032 	movx	a,@dptr
      00400F FF               [12] 1033 	mov	r7,a
      004010 E0               [24] 1034 	movx	a,@dptr
      004011 60 06            [24] 1035 	jz	00102$
      004013 EF               [12] 1036 	mov	a,r7
      004014 14               [12] 1037 	dec	a
      004015 90 05 5C         [24] 1038 	mov	dptr,#_batch_depth
      004018 F0               [24] 1039 	movx	@dptr,a
      004019                       1040 00102$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: if (!batch_depth) ak820_nvm_flush();
      004019 90 05 5C         [24] 1042 	mov	dptr,#_batch_depth
      00401C E0               [24] 1043 	movx	a,@dptr
      00401D 70 03            [24] 1044 	jnz	00105$
                                   1045 ;	keyboards/ajazz/ak820/ak820_nvm.c:161: }
      00401F 02 3E 92         [24] 1046 	ljmp	_ak820_nvm_flush
      004022                       1047 00105$:
      004022 22               [24] 1048 	ret
                                   1049 ;------------------------------------------------------------
                                   1050 ;Allocation info for local variables in function 'load_page'
                                   1051 ;------------------------------------------------------------
                                   1052 ;sloc1         Allocated with name '_load_page_sloc1_1_0'
                                   1053 ;page          Allocated with name '_load_page_page_10000_87'
                                   1054 ;i             Allocated with name '_load_page_i_10000_88'
                                   1055 ;------------------------------------------------------------
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: static bool load_page(uint16_t page) {
                                   1057 ;	-----------------------------------------
                                   1058 ;	 function load_page
                                   1059 ;	-----------------------------------------
      004023                       1060 _load_page:
      004023 12 43 EA         [24] 1061 	lcall	_ak820_outline_0010
      004026 90 05 7D         [24] 1062 	mov	dptr,#_load_page_page_10000_87
      004029 12 43 E5         [24] 1063 	lcall	_ak820_outline_0007
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: if (page_valid && cached_page == page) return !storage_failed;
      00402C 90 05 59         [24] 1065 	mov	dptr,#_page_valid
      00402F E0               [24] 1066 	movx	a,@dptr
      004030 60 20            [24] 1067 	jz	00102$
      004032 90 05 57         [24] 1068 	mov	dptr,#_cached_page
      004035 12 43 C5         [24] 1069 	lcall	_ak820_outline_0000
      004038 90 05 7D         [24] 1070 	mov	dptr,#_load_page_page_10000_87
      00403B 12 43 DF         [24] 1071 	lcall	_ak820_outline_0006
      00403E EE               [12] 1072 	mov	a,r6
      00403F B5 04 10         [24] 1073 	cjne	a,ar4,00102$
      004042 EF               [12] 1074 	mov	a,r7
      004043 B5 05 0C         [24] 1075 	cjne	a,ar5,00102$
      004046 12 44 7E         [24] 1076 	lcall	_ak820_outline_0131
      004049 B4 01 00         [24] 1077 	cjne	a,#0x01,00150$
      00404C                       1078 00150$:
      00404C 92 09            [24] 1079 	mov  _load_page_sloc0_1_0,c
      00404E 12 44 91         [24] 1080 	lcall	_ak820_outline_0146
      004051 22               [24] 1081 	ret
      004052                       1082 00102$:
                                   1083 ;	keyboards/ajazz/ak820/ak820_nvm.c:166: ak820_nvm_flush();
      004052 12 3E 92         [24] 1084 	lcall	_ak820_nvm_flush
                                   1085 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: if (storage_failed) return false;
      004055 12 44 7E         [24] 1086 	lcall	_ak820_outline_0131
      004058 60 04            [24] 1087 	jz	00119$
      00405A 75 82 00         [24] 1088 	mov	dpl, #0x00
                                   1089 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00405D 22               [24] 1090 	ret
      00405E                       1091 00119$:
      00405E 7F 00            [12] 1092 	mov	r7,#0x00
      004060                       1093 00107$:
                                   1094 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004060 EF               [12] 1095 	mov	a,r7
      004061 24 17            [12] 1096 	add	a, #_page_data
      004063 FD               [12] 1097 	mov	r5,a
      004064 E4               [12] 1098 	clr	a
      004065 34 05            [12] 1099 	addc	a, #(_page_data >> 8)
      004067 FE               [12] 1100 	mov	r6,a
      004068 90 05 7D         [24] 1101 	mov	dptr,#_load_page_page_10000_87
      00406B 12 44 73         [24] 1102 	lcall	_ak820_outline_0089
      00406E 8B 01            [24] 1103 	mov	ar1,r3
      004070 8C 02            [24] 1104 	mov	ar2,r4
      004072 EA               [12] 1105 	mov	a,r2
      004073 54 03            [12] 1106 	anl	a,#0x03
      004075 A2 E0            [12] 1107 	mov	c,acc.0
      004077 C9               [12] 1108 	xch	a,r1
      004078 13               [12] 1109 	rrc	a
      004079 C9               [12] 1110 	xch	a,r1
      00407A 13               [12] 1111 	rrc	a
      00407B A2 E0            [12] 1112 	mov	c,acc.0
      00407D C9               [12] 1113 	xch	a,r1
      00407E 13               [12] 1114 	rrc	a
      00407F C9               [12] 1115 	xch	a,r1
      004080 13               [12] 1116 	rrc	a
      004081 C9               [12] 1117 	xch	a,r1
      004082 FA               [12] 1118 	mov	r2,a
      004083 89 0C            [24] 1119 	mov	_load_page_sloc1_1_0,r1
      004085 74 C7            [12] 1120 	mov	a,#0xc7
      004087 2A               [12] 1121 	add	a, r2
      004088 F5 0D            [12] 1122 	mov	(_load_page_sloc1_1_0 + 1),a
      00408A 8F 00            [24] 1123 	mov	ar0,r7
      00408C 7A 00            [12] 1124 	mov	r2,#0x00
      00408E E8               [12] 1125 	mov	a,r0
      00408F 25 0C            [12] 1126 	add	a, _load_page_sloc1_1_0
      004091 F8               [12] 1127 	mov	r0,a
      004092 EA               [12] 1128 	mov	a,r2
      004093 35 0D            [12] 1129 	addc	a, (_load_page_sloc1_1_0 + 1)
      004095 FA               [12] 1130 	mov	r2,a
      004096 88 82            [24] 1131 	mov	dpl, r0
      004098 8A 83            [24] 1132 	mov	dph, r2
      00409A 12 39 2C         [24] 1133 	lcall	_ak820_flash_read
      00409D AA 82            [24] 1134 	mov	r2, dpl
      00409F 12 43 F4         [24] 1135 	lcall	_ak820_outline_0012
      0040A2 EA               [12] 1136 	mov	a,r2
      0040A3 F0               [24] 1137 	movx	@dptr,a
                                   1138 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040A4 0F               [12] 1139 	inc	r7
      0040A5 BF 40 B8         [24] 1140 	cjne	r7,#0x40,00107$
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:171: cached_page = page;
      0040A8 90 05 57         [24] 1142 	mov	dptr,#_cached_page
      0040AB 12 44 50         [24] 1143 	lcall	_ak820_outline_0060
                                   1144 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: page_valid = true;
      0040AE 90 05 59         [24] 1145 	mov	dptr,#_page_valid
      0040B1 74 01            [12] 1146 	mov	a,#0x01
      0040B3 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_nvm.c:173: return true;
      0040B4 75 82 01         [24] 1149 	mov	dpl, #0x01
                                   1150 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: }
      0040B7 22               [24] 1151 	ret
                                   1152 ;------------------------------------------------------------
                                   1153 ;Allocation info for local variables in function 'read_offset'
                                   1154 ;------------------------------------------------------------
                                   1155 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1156 ;------------------------------------------------------------
                                   1157 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: static uint8_t read_offset(uint16_t offset) {
                                   1158 ;	-----------------------------------------
                                   1159 ;	 function read_offset
                                   1160 ;	-----------------------------------------
      0040B8                       1161 _read_offset:
      0040B8 12 43 EA         [24] 1162 	lcall	_ak820_outline_0010
      0040BB 90 05 7F         [24] 1163 	mov	dptr,#_read_offset_offset_10000_93
      0040BE 12 43 E5         [24] 1164 	lcall	_ak820_outline_0007
                                   1165 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: if (offset >= AK820_NVM_SIZE) return 0;
      0040C1 90 05 7F         [24] 1166 	mov	dptr,#_read_offset_offset_10000_93
      0040C4 12 43 C5         [24] 1167 	lcall	_ak820_outline_0000
      0040C7 C3               [12] 1168 	clr	c
      0040C8 94 28            [12] 1169 	subb	a,#0x28
      0040CA 40 04            [24] 1170 	jc	00102$
      0040CC 75 82 00         [24] 1171 	mov	dpl, #0x00
      0040CF 22               [24] 1172 	ret
      0040D0                       1173 00102$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0040D0 90 05 59         [24] 1175 	mov	dptr,#_page_valid
      0040D3 E0               [24] 1176 	movx	a,@dptr
      0040D4 60 33            [24] 1177 	jz	00104$
      0040D6 8E 04            [24] 1178 	mov	ar4,r6
      0040D8 EF               [12] 1179 	mov	a,r7
      0040D9 A2 E7            [12] 1180 	mov	c,acc.7
      0040DB CC               [12] 1181 	xch	a,r4
      0040DC 33               [12] 1182 	rlc	a
      0040DD CC               [12] 1183 	xch	a,r4
      0040DE 33               [12] 1184 	rlc	a
      0040DF A2 E7            [12] 1185 	mov	c,acc.7
      0040E1 CC               [12] 1186 	xch	a,r4
      0040E2 33               [12] 1187 	rlc	a
      0040E3 CC               [12] 1188 	xch	a,r4
      0040E4 33               [12] 1189 	rlc	a
      0040E5 CC               [12] 1190 	xch	a,r4
      0040E6 54 03            [12] 1191 	anl	a,#0x03
      0040E8 FD               [12] 1192 	mov	r5,a
      0040E9 90 05 57         [24] 1193 	mov	dptr,#_cached_page
      0040EC 12 44 11         [24] 1194 	lcall	_ak820_outline_0024
      0040EF EC               [12] 1195 	mov	a,r4
      0040F0 B5 02 16         [24] 1196 	cjne	a,ar2,00104$
      0040F3 ED               [12] 1197 	mov	a,r5
      0040F4 B5 03 12         [24] 1198 	cjne	a,ar3,00104$
                                   1199 ;	keyboards/ajazz/ak820/ak820_nvm.c:179: return page_data[offset % AK820_FLASH_PAGE];
      0040F7 74 3F            [12] 1200 	mov	a,#0x3f
      0040F9 5E               [12] 1201 	anl	a,r6
      0040FA 7D 00            [12] 1202 	mov	r5,#0x00
      0040FC 24 17            [12] 1203 	add	a, #_page_data
      0040FE F5 82            [12] 1204 	mov	dpl,a
      004100 ED               [12] 1205 	mov	a,r5
      004101 34 05            [12] 1206 	addc	a, #(_page_data >> 8)
      004103 F5 83            [12] 1207 	mov	dph,a
      004105 E0               [24] 1208 	movx	a,@dptr
      004106 F5 82            [12] 1209 	mov	dpl,a
      004108 22               [24] 1210 	ret
      004109                       1211 00104$:
                                   1212 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: return ak820_flash_read(AK820_NVM_BASE + offset);
      004109 74 C7            [12] 1213 	mov	a,#0xc7
      00410B 2F               [12] 1214 	add	a, r7
      00410C FF               [12] 1215 	mov	r7,a
      00410D 12 43 D3         [24] 1216 	lcall	_ak820_outline_0002
                                   1217 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: }
      004110 02 39 2C         [24] 1218 	ljmp	_ak820_flash_read
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1221 ;------------------------------------------------------------
                                   1222 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1223 ;------------------------------------------------------------
                                   1224 ;	keyboards/ajazz/ak820/ak820_nvm.c:184: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1225 ;	-----------------------------------------
                                   1226 ;	 function eeprom_read_byte
                                   1227 ;	-----------------------------------------
      004113                       1228 _eeprom_read_byte:
      004113 C0 07            [24] 1229 	push	ar7
      004115 C0 06            [24] 1230 	push	ar6
      004117 12 43 D8         [24] 1231 	lcall	_ak820_outline_0004
      00411A 90 05 81         [24] 1232 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00411D 12 43 CB         [24] 1233 	lcall	_ak820_outline_0001
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: return read_offset((uint16_t)(uintptr_t)addr);
      004120 90 05 81         [24] 1235 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004123 12 43 C5         [24] 1236 	lcall	_ak820_outline_0000
      004126 12 43 D3         [24] 1237 	lcall	_ak820_outline_0002
      004129 C0 06            [24] 1238 	push	ar6
      00412B C0 05            [24] 1239 	push	ar5
      00412D C0 04            [24] 1240 	push	ar4
      00412F C0 03            [24] 1241 	push	ar3
      004131 C0 02            [24] 1242 	push	ar2
      004133 C0 01            [24] 1243 	push	ar1
      004135 C0 00            [24] 1244 	push	ar0
      004137 12 40 B8         [24] 1245 	lcall	_read_offset
      00413A AF 82            [24] 1246 	mov	r7, dpl
      00413C D0 00            [24] 1247 	pop	ar0
      00413E D0 01            [24] 1248 	pop	ar1
      004140 D0 02            [24] 1249 	pop	ar2
      004142 D0 03            [24] 1250 	pop	ar3
      004144 D0 04            [24] 1251 	pop	ar4
      004146 D0 05            [24] 1252 	pop	ar5
      004148 D0 06            [24] 1253 	pop	ar6
      00414A 8F 82            [24] 1254 	mov	dpl, r7
                                   1255 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: }
      00414C D0 06            [24] 1256 	pop	ar6
      00414E D0 07            [24] 1257 	pop	ar7
      004150 22               [24] 1258 	ret
                                   1259 ;------------------------------------------------------------
                                   1260 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1261 ;------------------------------------------------------------
                                   1262 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1263 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1264 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1265 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1266 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1267 ;------------------------------------------------------------
                                   1268 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1269 ;	-----------------------------------------
                                   1270 ;	 function ak820_eeprom_read_block_xdata
                                   1271 ;	-----------------------------------------
      004151                       1272 _ak820_eeprom_read_block_xdata:
      004151 12 43 EA         [24] 1273 	lcall	_ak820_outline_0010
      004154 90 05 89         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004157 12 43 E5         [24] 1275 	lcall	_ak820_outline_0007
                                   1276 ;	keyboards/ajazz/ak820/ak820_nvm.c:221: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00415A 90 05 84         [24] 1277 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00415D 12 43 C5         [24] 1278 	lcall	_ak820_outline_0000
                                   1279 ;	keyboards/ajazz/ak820/ak820_nvm.c:222: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004160 90 05 89         [24] 1280 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004163 12 43 DF         [24] 1281 	lcall	_ak820_outline_0006
      004166 90 05 8B         [24] 1282 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004169 12 44 0B         [24] 1283 	lcall	_ak820_outline_0023
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:223: while (len--) {
      00416C 90 05 87         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00416F 12 43 DF         [24] 1286 	lcall	_ak820_outline_0006
      004172                       1287 00103$:
      004172 8C 02            [24] 1288 	mov	ar2,r4
      004174 8D 03            [24] 1289 	mov	ar3,r5
      004176 1C               [12] 1290 	dec	r4
      004177 BC FF 01         [24] 1291 	cjne	r4,#0xff,00130$
      00417A 1D               [12] 1292 	dec	r5
      00417B                       1293 00130$:
      00417B EA               [12] 1294 	mov	a,r2
      00417C 4B               [12] 1295 	orl	a,r3
      00417D 60 5D            [24] 1296 	jz	00106$
                                   1297 ;	keyboards/ajazz/ak820/ak820_nvm.c:224: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00417F 8E 02            [24] 1298 	mov	ar2,r6
      004181 8F 03            [24] 1299 	mov	ar3,r7
      004183 74 D8            [12] 1300 	mov	a,#0x100 - 0x28
      004185 2B               [12] 1301 	add	a,r3
      004186 50 17            [24] 1302 	jnc	00102$
      004188 90 05 8B         [24] 1303 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00418B 12 44 11         [24] 1304 	lcall	_ak820_outline_0024
      00418E 12 44 22         [24] 1305 	lcall	_ak820_outline_0033
      004191 E4               [12] 1306 	clr	a
      004192 F0               [24] 1307 	movx	@dptr,a
      004193 90 05 8B         [24] 1308 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004196 04               [12] 1309 	inc	a
      004197 2A               [12] 1310 	add	a, r2
      004198 F0               [24] 1311 	movx	@dptr,a
      004199 E4               [12] 1312 	clr	a
      00419A 3B               [12] 1313 	addc	a, r3
      00419B A3               [24] 1314 	inc	dptr
      00419C F0               [24] 1315 	movx	@dptr,a
      00419D 80 D3            [24] 1316 	sjmp	00103$
      00419F                       1317 00102$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:225: *out++ = read_offset(offset);
      00419F 90 05 8B         [24] 1319 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0041A2 12 44 11         [24] 1320 	lcall	_ak820_outline_0024
      0041A5 12 43 D3         [24] 1321 	lcall	_ak820_outline_0002
      0041A8 C0 07            [24] 1322 	push	ar7
      0041AA C0 06            [24] 1323 	push	ar6
      0041AC C0 05            [24] 1324 	push	ar5
      0041AE C0 04            [24] 1325 	push	ar4
      0041B0 C0 03            [24] 1326 	push	ar3
      0041B2 C0 02            [24] 1327 	push	ar2
      0041B4 12 40 B8         [24] 1328 	lcall	_read_offset
      0041B7 A9 82            [24] 1329 	mov	r1, dpl
      0041B9 D0 02            [24] 1330 	pop	ar2
      0041BB D0 03            [24] 1331 	pop	ar3
      0041BD D0 04            [24] 1332 	pop	ar4
      0041BF D0 05            [24] 1333 	pop	ar5
      0041C1 D0 06            [24] 1334 	pop	ar6
      0041C3 D0 07            [24] 1335 	pop	ar7
      0041C5 12 44 22         [24] 1336 	lcall	_ak820_outline_0033
      0041C8 E9               [12] 1337 	mov	a,r1
      0041C9 F0               [24] 1338 	movx	@dptr,a
      0041CA 90 05 8B         [24] 1339 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0041CD 74 01            [12] 1340 	mov	a,#0x01
      0041CF 2A               [12] 1341 	add	a, r2
      0041D0 F0               [24] 1342 	movx	@dptr,a
      0041D1 E4               [12] 1343 	clr	a
      0041D2 3B               [12] 1344 	addc	a, r3
      0041D3 A3               [24] 1345 	inc	dptr
      0041D4 F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:226: ++offset;
      0041D5 0E               [12] 1348 	inc	r6
      0041D6 BE 00 99         [24] 1349 	cjne	r6,#0x00,00103$
      0041D9 0F               [12] 1350 	inc	r7
      0041DA 80 96            [24] 1351 	sjmp	00103$
      0041DC                       1352 00106$:
                                   1353 ;	keyboards/ajazz/ak820/ak820_nvm.c:228: }
      0041DC 22               [24] 1354 	ret
                                   1355 ;------------------------------------------------------------
                                   1356 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1357 ;------------------------------------------------------------
                                   1358 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1359 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1360 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1361 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1362 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1363 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1364 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1365 ;------------------------------------------------------------
                                   1366 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1367 ;	-----------------------------------------
                                   1368 ;	 function ak820_eeprom_write_block_xdata
                                   1369 ;	-----------------------------------------
      0041DD                       1370 _ak820_eeprom_write_block_xdata:
      0041DD 12 43 EA         [24] 1371 	lcall	_ak820_outline_0010
      0041E0 90 05 92         [24] 1372 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041E3 12 43 E5         [24] 1373 	lcall	_ak820_outline_0007
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041E6 90 05 8D         [24] 1375 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0041E9 12 43 C5         [24] 1376 	lcall	_ak820_outline_0000
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0041EC 90 05 92         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041EF 12 43 DF         [24] 1379 	lcall	_ak820_outline_0006
                                   1380 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0041F2 8E 02            [24] 1381 	mov	ar2,r6
      0041F4 8F 03            [24] 1382 	mov	ar3,r7
      0041F6 C3               [12] 1383 	clr	c
      0041F7 E4               [12] 1384 	clr	a
      0041F8 9A               [12] 1385 	subb	a,r2
      0041F9 74 28            [12] 1386 	mov	a,#0x28
      0041FB 9B               [12] 1387 	subb	a,r3
      0041FC 40 15            [24] 1388 	jc	00101$
                                   1389 ;	free result
      0041FE E4               [12] 1390 	clr	a
      0041FF C3               [12] 1391 	clr	c
      004200 9E               [12] 1392 	subb	a,r6
      004201 FA               [12] 1393 	mov	r2,a
      004202 74 28            [12] 1394 	mov	a,#0x28
      004204 9F               [12] 1395 	subb	a,r7
      004205 FB               [12] 1396 	mov	r3,a
      004206 90 05 90         [24] 1397 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004209 12 44 5C         [24] 1398 	lcall	_ak820_outline_0072
      00420C C3               [12] 1399 	clr	c
      00420D EA               [12] 1400 	mov	a,r2
      00420E 98               [12] 1401 	subb	a,r0
      00420F EB               [12] 1402 	mov	a,r3
      004210 99               [12] 1403 	subb	a,r1
      004211 50 06            [24] 1404 	jnc	00125$
                                   1405 ;	free result
      004213                       1406 00101$:
                                   1407 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004213 75 82 0E         [24] 1408 	mov	dpl, #0x0e
                                   1409 ;	keyboards/ajazz/ak820/ak820_nvm.c:236: return;
      004216 02 3B C0         [24] 1410 	ljmp	_nvm_fail
                                   1411 ;	keyboards/ajazz/ak820/ak820_nvm.c:238: while (len--) {
      004219                       1412 00125$:
      004219 90 05 90         [24] 1413 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00421C 12 44 11         [24] 1414 	lcall	_ak820_outline_0024
      00421F                       1415 00108$:
      00421F 8A 00            [24] 1416 	mov	ar0,r2
      004221 8B 01            [24] 1417 	mov	ar1,r3
      004223 1A               [12] 1418 	dec	r2
      004224 BA FF 01         [24] 1419 	cjne	r2,#0xff,00159$
      004227 1B               [12] 1420 	dec	r3
      004228                       1421 00159$:
      004228 E8               [12] 1422 	mov	a,r0
      004229 49               [12] 1423 	orl	a,r1
      00422A 70 03            [24] 1424 	jnz	00160$
      00422C 02 42 BD         [24] 1425 	ljmp	00110$
      00422F                       1426 00160$:
                                   1427 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: uint8_t value = *in++;
      00422F C0 02            [24] 1428 	push	ar2
      004231 C0 03            [24] 1429 	push	ar3
      004233 12 43 EF         [24] 1430 	lcall	_ak820_outline_0011
      004236 E0               [24] 1431 	movx	a,@dptr
      004237 F9               [12] 1432 	mov	r1,a
      004238 A3               [24] 1433 	inc	dptr
      004239 12 44 83         [24] 1434 	lcall	_ak820_outline_0132
                                   1435 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00423C 8E 0E            [24] 1436 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00423E 8F 0F            [24] 1437 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004240 A8 0E            [24] 1438 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004242 E5 0F            [12] 1439 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004244 A2 E7            [12] 1440 	mov	c,acc.7
      004246 C8               [12] 1441 	xch	a,r0
      004247 33               [12] 1442 	rlc	a
      004248 C8               [12] 1443 	xch	a,r0
      004249 33               [12] 1444 	rlc	a
      00424A A2 E7            [12] 1445 	mov	c,acc.7
      00424C C8               [12] 1446 	xch	a,r0
      00424D 33               [12] 1447 	rlc	a
      00424E C8               [12] 1448 	xch	a,r0
      00424F 33               [12] 1449 	rlc	a
      004250 C8               [12] 1450 	xch	a,r0
      004251 54 03            [12] 1451 	anl	a,#0x03
      004253 FB               [12] 1452 	mov	r3,a
      004254 88 82            [24] 1453 	mov	dpl, r0
      004256 8B 83            [24] 1454 	mov	dph, r3
      004258 C0 07            [24] 1455 	push	ar7
      00425A C0 06            [24] 1456 	push	ar6
      00425C C0 05            [24] 1457 	push	ar5
      00425E C0 04            [24] 1458 	push	ar4
      004260 C0 03            [24] 1459 	push	ar3
      004262 C0 02            [24] 1460 	push	ar2
      004264 C0 01            [24] 1461 	push	ar1
      004266 12 40 23         [24] 1462 	lcall	_load_page
      004269 E5 82            [12] 1463 	mov	a, dpl
      00426B D0 01            [24] 1464 	pop	ar1
      00426D D0 02            [24] 1465 	pop	ar2
      00426F D0 03            [24] 1466 	pop	ar3
      004271 D0 04            [24] 1467 	pop	ar4
      004273 D0 05            [24] 1468 	pop	ar5
      004275 D0 06            [24] 1469 	pop	ar6
      004277 D0 07            [24] 1470 	pop	ar7
      004279 D0 03            [24] 1471 	pop	ar3
      00427B D0 02            [24] 1472 	pop	ar2
      00427D 70 01            [24] 1473 	jnz	00105$
      00427F 22               [24] 1474 	ret
      004280                       1475 00105$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004280 C0 06            [24] 1477 	push	ar6
      004282 C0 07            [24] 1478 	push	ar7
      004284 74 3F            [12] 1479 	mov	a,#0x3f
      004286 55 0E            [12] 1480 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004288 7F 00            [12] 1481 	mov	r7,#0x00
      00428A 24 17            [12] 1482 	add	a, #_page_data
      00428C F5 0E            [12] 1483 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00428E EF               [12] 1484 	mov	a,r7
      00428F 34 05            [12] 1485 	addc	a, #(_page_data >> 8)
      004291 F5 0F            [12] 1486 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004293 85 0E 82         [24] 1487 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004296 85 0F 83         [24] 1488 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004299 E0               [24] 1489 	movx	a,@dptr
      00429A B5 01 06         [24] 1490 	cjne	a,ar1,00162$
      00429D D0 07            [24] 1491 	pop	ar7
      00429F D0 06            [24] 1492 	pop	ar6
      0042A1 80 12            [24] 1493 	sjmp	00107$
      0042A3                       1494 00162$:
      0042A3 D0 07            [24] 1495 	pop	ar7
      0042A5 D0 06            [24] 1496 	pop	ar6
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:242: page_data[offset % AK820_FLASH_PAGE] = value;
      0042A7 85 0E 82         [24] 1498 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0042AA 85 0F 83         [24] 1499 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0042AD E9               [12] 1500 	mov	a,r1
      0042AE F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: page_dirty = true;
      0042AF 90 05 5A         [24] 1503 	mov	dptr,#_page_dirty
      0042B2 74 01            [12] 1504 	mov	a,#0x01
      0042B4 F0               [24] 1505 	movx	@dptr,a
      0042B5                       1506 00107$:
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: ++offset;
      0042B5 0E               [12] 1508 	inc	r6
      0042B6 BE 00 01         [24] 1509 	cjne	r6,#0x00,00163$
      0042B9 0F               [12] 1510 	inc	r7
      0042BA                       1511 00163$:
      0042BA 02 42 1F         [24] 1512 	ljmp	00108$
      0042BD                       1513 00110$:
                                   1514 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: if (!batch_depth) ak820_nvm_flush();
      0042BD 90 05 5C         [24] 1515 	mov	dptr,#_batch_depth
      0042C0 E0               [24] 1516 	movx	a,@dptr
      0042C1 70 03            [24] 1517 	jnz	00113$
                                   1518 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: }
      0042C3 02 3E 92         [24] 1519 	ljmp	_ak820_nvm_flush
      0042C6                       1520 00113$:
      0042C6 22               [24] 1521 	ret
                                   1522 ;------------------------------------------------------------
                                   1523 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1524 ;------------------------------------------------------------
                                   1525 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1526 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1527 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1528 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1529 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1530 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1531 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1532 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1533 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1534 ;------------------------------------------------------------
                                   1535 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1536 ;	-----------------------------------------
                                   1537 ;	 function ak820_eeprom_update_block_xdata
                                   1538 ;	-----------------------------------------
      0042C7                       1539 _ak820_eeprom_update_block_xdata:
      0042C7 12 43 EA         [24] 1540 	lcall	_ak820_outline_0010
      0042CA 90 05 99         [24] 1541 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042CD 12 43 E5         [24] 1542 	lcall	_ak820_outline_0007
                                   1543 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0042D0 90 05 99         [24] 1544 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042D3 12 43 C5         [24] 1545 	lcall	_ak820_outline_0000
                                   1546 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0042D6 90 05 94         [24] 1547 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0042D9 E0               [24] 1548 	movx	a,@dptr
      0042DA F5 14            [12] 1549 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0042DC A3               [24] 1550 	inc	dptr
      0042DD E0               [24] 1551 	movx	a,@dptr
      0042DE F5 15            [12] 1552 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0042E0 A3               [24] 1553 	inc	dptr
      0042E1 E0               [24] 1554 	movx	a,@dptr
      0042E2 F5 16            [12] 1555 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0042E4 A9 14            [24] 1556 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042E6 AA 15            [24] 1557 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1558 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: for (i = 0; i < len; ++i) {
      0042E8 E4               [12] 1559 	clr	a
      0042E9 F5 10            [12] 1560 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0042EB F5 11            [12] 1561 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0042ED                       1562 00105$:
      0042ED 90 05 97         [24] 1563 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0042F0 E0               [24] 1564 	movx	a,@dptr
      0042F1 F5 12            [12] 1565 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0042F3 A3               [24] 1566 	inc	dptr
      0042F4 E0               [24] 1567 	movx	a,@dptr
      0042F5 F5 13            [12] 1568 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0042F7 C3               [12] 1569 	clr	c
      0042F8 E5 10            [12] 1570 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042FA 95 12            [12] 1571 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042FC E5 11            [12] 1572 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042FE 95 13            [12] 1573 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004300 50 68            [24] 1574 	jnc	00107$
                                   1575 ;	keyboards/ajazz/ak820/ak820_nvm.c:255: if (read_offset(offset + i) != source[i]) {
      004302 89 00            [24] 1576 	mov	ar0,r1
      004304 8A 05            [24] 1577 	mov	ar5,r2
      004306 E5 10            [12] 1578 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004308 28               [12] 1579 	add	a, r0
      004309 F8               [12] 1580 	mov	r0,a
      00430A E5 11            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00430C 3D               [12] 1582 	addc	a, r5
      00430D FD               [12] 1583 	mov	r5,a
      00430E 88 82            [24] 1584 	mov	dpl, r0
      004310 8D 83            [24] 1585 	mov	dph, r5
      004312 C0 07            [24] 1586 	push	ar7
      004314 C0 06            [24] 1587 	push	ar6
      004316 C0 02            [24] 1588 	push	ar2
      004318 C0 01            [24] 1589 	push	ar1
      00431A 12 40 B8         [24] 1590 	lcall	_read_offset
      00431D AD 82            [24] 1591 	mov	r5, dpl
      00431F D0 01            [24] 1592 	pop	ar1
      004321 D0 02            [24] 1593 	pop	ar2
      004323 D0 06            [24] 1594 	pop	ar6
      004325 D0 07            [24] 1595 	pop	ar7
      004327 E5 10            [12] 1596 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004329 2E               [12] 1597 	add	a, r6
      00432A F5 82            [12] 1598 	mov	dpl,a
      00432C E5 11            [12] 1599 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00432E 3F               [12] 1600 	addc	a, r7
      00432F F5 83            [12] 1601 	mov	dph,a
      004331 E0               [24] 1602 	movx	a,@dptr
      004332 FC               [12] 1603 	mov	r4,a
      004333 ED               [12] 1604 	mov	a,r5
      004334 B5 04 02         [24] 1605 	cjne	a,ar4,00131$
      004337 80 27            [24] 1606 	sjmp	00106$
      004339                       1607 00131$:
                                   1608 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: ak820_eeprom_write_block_xdata(buf, addr, len);
      004339 90 05 99         [24] 1609 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00433C E0               [24] 1610 	movx	a,@dptr
      00433D F8               [12] 1611 	mov	r0,a
      00433E A3               [24] 1612 	inc	dptr
      00433F E0               [24] 1613 	movx	a,@dptr
      004340 FD               [12] 1614 	mov	r5,a
      004341 90 05 8D         [24] 1615 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004344 E5 14            [12] 1616 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004346 F0               [24] 1617 	movx	@dptr,a
      004347 E5 15            [12] 1618 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004349 A3               [24] 1619 	inc	dptr
      00434A F0               [24] 1620 	movx	@dptr,a
      00434B E5 16            [12] 1621 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00434D A3               [24] 1622 	inc	dptr
      00434E F0               [24] 1623 	movx	@dptr,a
      00434F 90 05 90         [24] 1624 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004352 E5 12            [12] 1625 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004354 F0               [24] 1626 	movx	@dptr,a
      004355 E5 13            [12] 1627 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004357 A3               [24] 1628 	inc	dptr
      004358 F0               [24] 1629 	movx	@dptr,a
      004359 88 82            [24] 1630 	mov	dpl, r0
      00435B 8D 83            [24] 1631 	mov	dph, r5
                                   1632 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: return;
      00435D 02 41 DD         [24] 1633 	ljmp	_ak820_eeprom_write_block_xdata
      004360                       1634 00106$:
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: for (i = 0; i < len; ++i) {
      004360 05 10            [12] 1636 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004362 E4               [12] 1637 	clr	a
      004363 B5 10 87         [24] 1638 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004366 05 11            [12] 1639 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004368 80 83            [24] 1640 	sjmp	00105$
      00436A                       1641 00107$:
                                   1642 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: }
      00436A 22               [24] 1643 	ret
                                   1644 ;------------------------------------------------------------
                                   1645 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1646 ;------------------------------------------------------------
                                   1647 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1648 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1649 ;------------------------------------------------------------
                                   1650 ;	keyboards/ajazz/ak820/ak820_nvm.c:262: void eeprom_driver_erase(void) {
                                   1651 ;	-----------------------------------------
                                   1652 ;	 function eeprom_driver_erase
                                   1653 ;	-----------------------------------------
      00436B                       1654 _eeprom_driver_erase:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_nvm_flush();
      00436B 12 3E 92         [24] 1656 	lcall	_ak820_nvm_flush
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00436E 7E 00            [12] 1658 	mov	r6,#0x00
      004370 7F 00            [12] 1659 	mov	r7,#0x00
      004372                       1660 00111$:
      004372 12 44 62         [24] 1661 	lcall	_ak820_outline_0073
      004375 BC A0 04         [24] 1662 	cjne	r4,#0xa0,00165$
      004378 BD 00 01         [24] 1663 	cjne	r5,#0x00,00165$
      00437B 22               [24] 1664 	ret
      00437C                       1665 00165$:
      00437C 12 44 7E         [24] 1666 	lcall	_ak820_outline_0131
      00437F 70 43            [24] 1667 	jnz	00113$
                                   1668 ;	keyboards/ajazz/ak820/ak820_nvm.c:267: if (!load_page(page)) return;
      004381 12 43 D3         [24] 1669 	lcall	_ak820_outline_0002
      004384 C0 07            [24] 1670 	push	ar7
      004386 C0 06            [24] 1671 	push	ar6
      004388 12 40 23         [24] 1672 	lcall	_load_page
      00438B E5 82            [12] 1673 	mov	a, dpl
      00438D D0 06            [24] 1674 	pop	ar6
      00438F D0 07            [24] 1675 	pop	ar7
      004391 70 01            [24] 1676 	jnz	00126$
                                   1677 ;	keyboards/ajazz/ak820/ak820_nvm.c:268: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004393 22               [24] 1678 	ret
      004394                       1679 00126$:
      004394 7D 00            [12] 1680 	mov	r5,#0x00
      004396                       1681 00107$:
                                   1682 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004396 ED               [12] 1683 	mov	a,r5
      004397 24 17            [12] 1684 	add	a, #_page_data
      004399 FB               [12] 1685 	mov	r3,a
      00439A E4               [12] 1686 	clr	a
      00439B 34 05            [12] 1687 	addc	a, #(_page_data >> 8)
      00439D FC               [12] 1688 	mov	r4,a
      00439E 12 43 F9         [24] 1689 	lcall	_ak820_outline_0014
      0043A1 E0               [24] 1690 	movx	a,@dptr
      0043A2 60 0A            [24] 1691 	jz	00108$
      0043A4 12 43 F9         [24] 1692 	lcall	_ak820_outline_0014
      0043A7 E4               [12] 1693 	clr	a
      0043A8 F0               [24] 1694 	movx	@dptr,a
      0043A9 90 05 5A         [24] 1695 	mov	dptr,#_page_dirty
      0043AC 04               [12] 1696 	inc	a
      0043AD F0               [24] 1697 	movx	@dptr,a
      0043AE                       1698 00108$:
                                   1699 ;	keyboards/ajazz/ak820/ak820_nvm.c:268: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0043AE 0D               [12] 1700 	inc	r5
      0043AF BD 40 E4         [24] 1701 	cjne	r5,#0x40,00107$
                                   1702 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: ak820_nvm_flush();
      0043B2 C0 07            [24] 1703 	push	ar7
      0043B4 C0 06            [24] 1704 	push	ar6
      0043B6 12 3E 92         [24] 1705 	lcall	_ak820_nvm_flush
      0043B9 D0 06            [24] 1706 	pop	ar6
      0043BB D0 07            [24] 1707 	pop	ar7
                                   1708 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0043BD 0E               [12] 1709 	inc	r6
      0043BE BE 00 B1         [24] 1710 	cjne	r6,#0x00,00111$
      0043C1 0F               [12] 1711 	inc	r7
      0043C2 80 AE            [24] 1712 	sjmp	00111$
      0043C4                       1713 00113$:
                                   1714 ;	keyboards/ajazz/ak820/ak820_nvm.c:273: }
      0043C4 22               [24] 1715 	ret
                                   1716 	.area CSEG    (CODE)
                                   1717 	.area CONST   (CODE)
                                   1718 	.area XINIT   (CODE)
                                   1719 	.area CABS    (ABS,CODE)
                                   1720 
                                   1721 ; Experimental exact instruction outlining.
                                   1722 	.globl _ak820_outline_0000
                                   1723 	.globl _ak820_outline_0001
                                   1724 	.globl _ak820_outline_0002
                                   1725 	.globl _ak820_outline_0004
                                   1726 	.globl _ak820_outline_0006
                                   1727 	.globl _ak820_outline_0007
                                   1728 	.globl _ak820_outline_0010
                                   1729 	.globl _ak820_outline_0011
                                   1730 	.globl _ak820_outline_0012
                                   1731 	.globl _ak820_outline_0014
                                   1732 	.globl _ak820_outline_0015
                                   1733 	.globl _ak820_outline_0016
                                   1734 	.globl _ak820_outline_0023
                                   1735 	.globl _ak820_outline_0024
                                   1736 	.globl _ak820_outline_0025
                                   1737 	.globl _ak820_outline_0027
                                   1738 	.globl _ak820_outline_0033
                                   1739 	.globl _ak820_outline_0039
                                   1740 	.globl _ak820_outline_0043
                                   1741 	.globl _ak820_outline_0050
                                   1742 	.globl _ak820_outline_0051
                                   1743 	.globl _ak820_outline_0060
                                   1744 	.globl _ak820_outline_0071
                                   1745 	.globl _ak820_outline_0072
                                   1746 	.globl _ak820_outline_0073
                                   1747 	.globl _ak820_outline_0083
                                   1748 	.globl _ak820_outline_0089
                                   1749 	.globl _ak820_outline_0129
                                   1750 	.globl _ak820_outline_0131
                                   1751 	.globl _ak820_outline_0132
                                   1752 	.globl _ak820_outline_0145
                                   1753 	.globl _ak820_outline_0146
                                   1754 	.globl _ak820_outline_0147
                                   1755 
                                   1756 	.area CSEG (CODE)
                                   1757 ; function ak820_outline_0000
      0043C5                       1758 _ak820_outline_0000:
      0043C5 E0               [24] 1759 	movx	a,@dptr
      0043C6 FE               [12] 1760 	mov	r6,a
      0043C7 A3               [24] 1761 	inc	dptr
      0043C8 E0               [24] 1762 	movx	a,@dptr
      0043C9 FF               [12] 1763 	mov	r7,a
      0043CA 22               [24] 1764 	ret
                                   1765 
                                   1766 	.area CSEG (CODE)
                                   1767 ; function ak820_outline_0001
      0043CB                       1768 _ak820_outline_0001:
      0043CB F0               [24] 1769 	movx	@dptr,a
      0043CC EE               [12] 1770 	mov	a,r6
      0043CD A3               [24] 1771 	inc	dptr
      0043CE F0               [24] 1772 	movx	@dptr,a
      0043CF EF               [12] 1773 	mov	a,r7
      0043D0 A3               [24] 1774 	inc	dptr
      0043D1 F0               [24] 1775 	movx	@dptr,a
      0043D2 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0002
      0043D3                       1780 _ak820_outline_0002:
      0043D3 8E 82            [24] 1781 	mov	dpl,r6
      0043D5 8F 83            [24] 1782 	mov	dph,r7
      0043D7 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0004
      0043D8                       1787 _ak820_outline_0004:
      0043D8 AF F0            [24] 1788 	mov	r7,b
      0043DA AE 83            [24] 1789 	mov	r6,dph
      0043DC E5 82            [12] 1790 	mov	a,dpl
      0043DE 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0006
      0043DF                       1795 _ak820_outline_0006:
      0043DF E0               [24] 1796 	movx	a,@dptr
      0043E0 FC               [12] 1797 	mov	r4,a
      0043E1 A3               [24] 1798 	inc	dptr
      0043E2 E0               [24] 1799 	movx	a,@dptr
      0043E3 FD               [12] 1800 	mov	r5,a
      0043E4 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0007
      0043E5                       1805 _ak820_outline_0007:
      0043E5 F0               [24] 1806 	movx	@dptr,a
      0043E6 EF               [12] 1807 	mov	a,r7
      0043E7 A3               [24] 1808 	inc	dptr
      0043E8 F0               [24] 1809 	movx	@dptr,a
      0043E9 22               [24] 1810 	ret
                                   1811 
                                   1812 	.area CSEG (CODE)
                                   1813 ; function ak820_outline_0010
      0043EA                       1814 _ak820_outline_0010:
      0043EA AF 83            [24] 1815 	mov	r7,dph
      0043EC E5 82            [12] 1816 	mov	a,dpl
      0043EE 22               [24] 1817 	ret
                                   1818 
                                   1819 	.area CSEG (CODE)
                                   1820 ; function ak820_outline_0011
      0043EF                       1821 _ak820_outline_0011:
      0043EF 8C 82            [24] 1822 	mov	dpl,r4
      0043F1 8D 83            [24] 1823 	mov	dph,r5
      0043F3 22               [24] 1824 	ret
                                   1825 
                                   1826 	.area CSEG (CODE)
                                   1827 ; function ak820_outline_0012
      0043F4                       1828 _ak820_outline_0012:
      0043F4 8D 82            [24] 1829 	mov	dpl,r5
      0043F6 8E 83            [24] 1830 	mov	dph,r6
      0043F8 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0014
      0043F9                       1835 _ak820_outline_0014:
      0043F9 8B 82            [24] 1836 	mov	dpl,r3
      0043FB 8C 83            [24] 1837 	mov	dph,r4
      0043FD 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0015
      0043FE                       1842 _ak820_outline_0015:
      0043FE 2E               [12] 1843 	add	a,r6
      0043FF F5 82            [12] 1844 	mov	dpl,a
      004401 E4               [12] 1845 	clr	a
      004402 3F               [12] 1846 	addc	a,r7
      004403 F5 83            [12] 1847 	mov	dph,a
      004405 22               [24] 1848 	ret
                                   1849 
                                   1850 	.area CSEG (CODE)
                                   1851 ; function ak820_outline_0016
      004406                       1852 _ak820_outline_0016:
      004406 89 82            [24] 1853 	mov	dpl,r1
      004408 8A 83            [24] 1854 	mov	dph,r2
      00440A 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0023
      00440B                       1859 _ak820_outline_0023:
      00440B EC               [12] 1860 	mov	a,r4
      00440C F0               [24] 1861 	movx	@dptr,a
      00440D ED               [12] 1862 	mov	a,r5
      00440E A3               [24] 1863 	inc	dptr
      00440F F0               [24] 1864 	movx	@dptr,a
      004410 22               [24] 1865 	ret
                                   1866 
                                   1867 	.area CSEG (CODE)
                                   1868 ; function ak820_outline_0024
      004411                       1869 _ak820_outline_0024:
      004411 E0               [24] 1870 	movx	a,@dptr
      004412 FA               [12] 1871 	mov	r2,a
      004413 A3               [24] 1872 	inc	dptr
      004414 E0               [24] 1873 	movx	a,@dptr
      004415 FB               [12] 1874 	mov	r3,a
      004416 22               [24] 1875 	ret
                                   1876 
                                   1877 	.area CSEG (CODE)
                                   1878 ; function ak820_outline_0025
      004417                       1879 _ak820_outline_0025:
      004417 E0               [24] 1880 	movx	a,@dptr
      004418 FD               [12] 1881 	mov	r5,a
      004419 A3               [24] 1882 	inc	dptr
      00441A E0               [24] 1883 	movx	a,@dptr
      00441B FE               [12] 1884 	mov	r6,a
      00441C 22               [24] 1885 	ret
                                   1886 
                                   1887 	.area CSEG (CODE)
                                   1888 ; function ak820_outline_0027
      00441D                       1889 _ak820_outline_0027:
      00441D AE 82            [24] 1890 	mov	r6,dpl
      00441F AF 83            [24] 1891 	mov	r7,dph
      004421 22               [24] 1892 	ret
                                   1893 
                                   1894 	.area CSEG (CODE)
                                   1895 ; function ak820_outline_0033
      004422                       1896 _ak820_outline_0033:
      004422 8A 82            [24] 1897 	mov	dpl,r2
      004424 8B 83            [24] 1898 	mov	dph,r3
      004426 22               [24] 1899 	ret
                                   1900 
                                   1901 	.area CSEG (CODE)
                                   1902 ; function ak820_outline_0039
      004427                       1903 _ak820_outline_0039:
      004427 EF               [12] 1904 	mov	a,r7
      004428 24 73            [12] 1905 	add	a,#_ak820_nvm_flush_header_10000_62
      00442A F5 82            [12] 1906 	mov	dpl,a
      00442C E4               [12] 1907 	clr	a
      00442D 34 05            [12] 1908 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00442F F5 83            [12] 1909 	mov	dph,a
      004431 E0               [24] 1910 	movx	a,@dptr
      004432 22               [24] 1911 	ret
                                   1912 
                                   1913 	.area CSEG (CODE)
                                   1914 ; function ak820_outline_0043
      004433                       1915 _ak820_outline_0043:
      004433 2E               [12] 1916 	add	a,r6
      004434 FC               [12] 1917 	mov	r4,a
      004435 E4               [12] 1918 	clr	a
      004436 3F               [12] 1919 	addc	a,r7
      004437 FD               [12] 1920 	mov	r5,a
      004438 22               [24] 1921 	ret
                                   1922 
                                   1923 	.area CSEG (CODE)
                                   1924 ; function ak820_outline_0050
      004439                       1925 _ak820_outline_0050:
      004439 2E               [12] 1926 	add	a,r6
      00443A FE               [12] 1927 	mov	r6,a
      00443B E4               [12] 1928 	clr	a
      00443C 3F               [12] 1929 	addc	a,r7
      00443D FF               [12] 1930 	mov	r7,a
      00443E 22               [24] 1931 	ret
                                   1932 
                                   1933 	.area CSEG (CODE)
                                   1934 ; function ak820_outline_0051
      00443F                       1935 _ak820_outline_0051:
      00443F 8F 06            [24] 1936 	mov	ar6,r7
      004441 7D 00            [12] 1937 	mov	r5,#0x00
      004443 74 40            [12] 1938 	mov	a,#0x40
      004445 2E               [12] 1939 	add	a,r6
      004446 FE               [12] 1940 	mov	r6,a
      004447 74 EF            [12] 1941 	mov	a,#0xef
      004449 3D               [12] 1942 	addc	a,r5
      00444A FD               [12] 1943 	mov	r5,a
      00444B 8E 82            [24] 1944 	mov	dpl,r6
      00444D 8D 83            [24] 1945 	mov	dph,r5
      00444F 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0060
      004450                       1950 _ak820_outline_0060:
      004450 EB               [12] 1951 	mov	a,r3
      004451 F0               [24] 1952 	movx	@dptr,a
      004452 EC               [12] 1953 	mov	a,r4
      004453 A3               [24] 1954 	inc	dptr
      004454 F0               [24] 1955 	movx	@dptr,a
      004455 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0071
      004456                       1960 _ak820_outline_0071:
      004456 ED               [12] 1961 	mov	a,r5
      004457 F0               [24] 1962 	movx	@dptr,a
      004458 EE               [12] 1963 	mov	a,r6
      004459 A3               [24] 1964 	inc	dptr
      00445A F0               [24] 1965 	movx	@dptr,a
      00445B 22               [24] 1966 	ret
                                   1967 
                                   1968 	.area CSEG (CODE)
                                   1969 ; function ak820_outline_0072
      00445C                       1970 _ak820_outline_0072:
      00445C E0               [24] 1971 	movx	a,@dptr
      00445D F8               [12] 1972 	mov	r0,a
      00445E A3               [24] 1973 	inc	dptr
      00445F E0               [24] 1974 	movx	a,@dptr
      004460 F9               [12] 1975 	mov	r1,a
      004461 22               [24] 1976 	ret
                                   1977 
                                   1978 	.area CSEG (CODE)
                                   1979 ; function ak820_outline_0073
      004462                       1980 _ak820_outline_0073:
      004462 8E 04            [24] 1981 	mov	ar4,r6
      004464 8F 05            [24] 1982 	mov	ar5,r7
      004466 22               [24] 1983 	ret
                                   1984 
                                   1985 	.area CSEG (CODE)
                                   1986 ; function ak820_outline_0083
      004467                       1987 _ak820_outline_0083:
      004467 EF               [12] 1988 	mov	a,r7
      004468 24 17            [12] 1989 	add	a,#_page_data
      00446A F5 82            [12] 1990 	mov	dpl,a
      00446C E4               [12] 1991 	clr	a
      00446D 34 05            [12] 1992 	addc	a,#(_page_data>>8)
      00446F F5 83            [12] 1993 	mov	dph,a
      004471 E0               [24] 1994 	movx	a,@dptr
      004472 22               [24] 1995 	ret
                                   1996 
                                   1997 	.area CSEG (CODE)
                                   1998 ; function ak820_outline_0089
      004473                       1999 _ak820_outline_0089:
      004473 E0               [24] 2000 	movx	a,@dptr
      004474 FB               [12] 2001 	mov	r3,a
      004475 A3               [24] 2002 	inc	dptr
      004476 E0               [24] 2003 	movx	a,@dptr
      004477 FC               [12] 2004 	mov	r4,a
      004478 22               [24] 2005 	ret
                                   2006 
                                   2007 	.area CSEG (CODE)
                                   2008 ; function ak820_outline_0129
      004479                       2009 _ak820_outline_0129:
      004479 8F 82            [24] 2010 	mov	dpl,r7
      00447B 8E 83            [24] 2011 	mov	dph,r6
      00447D 22               [24] 2012 	ret
                                   2013 
                                   2014 	.area CSEG (CODE)
                                   2015 ; function ak820_outline_0131
      00447E                       2016 _ak820_outline_0131:
      00447E 90 05 5B         [24] 2017 	mov	dptr,#_storage_failed
      004481 E0               [24] 2018 	movx	a,@dptr
      004482 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0132
      004483                       2023 _ak820_outline_0132:
      004483 AC 82            [24] 2024 	mov	r4,dpl
      004485 AD 83            [24] 2025 	mov	r5,dph
      004487 22               [24] 2026 	ret
                                   2027 
                                   2028 	.area CSEG (CODE)
                                   2029 ; function ak820_outline_0145
      004488                       2030 _ak820_outline_0145:
      004488 E0               [24] 2031 	movx	a,@dptr
      004489 FA               [12] 2032 	mov	r2,a
      00448A E4               [12] 2033 	clr	a
      00448B 42 05            [12] 2034 	orl	ar5,a
      00448D EA               [12] 2035 	mov	a,r2
      00448E 42 04            [12] 2036 	orl	ar4,a
      004490 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0146
      004491                       2041 _ak820_outline_0146:
      004491 E4               [12] 2042 	clr	a
      004492 33               [12] 2043 	rlc	a
      004493 F5 82            [12] 2044 	mov	dpl,a
      004495 22               [24] 2045 	ret
                                   2046 
                                   2047 	.area CSEG (CODE)
                                   2048 ; function ak820_outline_0147
      004496                       2049 _ak820_outline_0147:
      004496 8C 82            [24] 2050 	mov	dpl,r4
      004498 8B 83            [24] 2051 	mov	dph,r3
      00449A 22               [24] 2052 	ret
