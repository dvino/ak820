                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _timer_elapsed
                                     14 	.globl _timer_read
                                     15 	.globl _hsv_to_rgb_into
                                     16 	.globl _memset
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    261 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    262 	.globl _process_rgb_matrix_PARM_3
                                    263 	.globl _process_rgb_matrix_PARM_2
                                    264 	.globl _rgb_matrix_set_color_all_PARM_3
                                    265 	.globl _rgb_matrix_set_color_all_PARM_2
                                    266 	.globl _rgb_matrix_set_color_PARM_4
                                    267 	.globl _rgb_matrix_set_color_PARM_3
                                    268 	.globl _rgb_matrix_set_color_PARM_2
                                    269 	.globl _rgb_matrix_config
                                    270 	.globl _eeconfig_update_rgb_matrix
                                    271 	.globl _eeconfig_update_rgb_matrix_default
                                    272 	.globl _rgb_matrix_reload_from_eeprom
                                    273 	.globl _rgb_matrix_init
                                    274 	.globl _rgb_matrix_set_color
                                    275 	.globl _rgb_matrix_set_color_all
                                    276 	.globl _rgb_matrix_task
                                    277 	.globl _process_rgb_matrix
                                    278 	.globl _rgb_matrix_set_suspend_state
                                    279 	.globl _rgb_matrix_is_enabled
                                    280 	.globl _rgb_matrix_get_mode
                                    281 	.globl _rgb_matrix_get_hue
                                    282 	.globl _rgb_matrix_get_sat
                                    283 	.globl _rgb_matrix_get_val
                                    284 	.globl _rgb_matrix_get_speed
                                    285 	.globl _rgb_matrix_toggle_noeeprom
                                    286 	.globl _rgb_matrix_enable_noeeprom
                                    287 	.globl _rgb_matrix_disable_noeeprom
                                    288 	.globl _rgb_matrix_mode_noeeprom
                                    289 	.globl _rgb_matrix_step_noeeprom
                                    290 	.globl _rgb_matrix_step_reverse_noeeprom
                                    291 	.globl _rgb_matrix_sethsv_noeeprom
                                    292 	.globl _rgb_matrix_set_speed_noeeprom
                                    293 	.globl _rgb_matrix_increase_hue_noeeprom
                                    294 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    295 	.globl _rgb_matrix_increase_sat_noeeprom
                                    296 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    297 	.globl _rgb_matrix_increase_val_noeeprom
                                    298 	.globl _rgb_matrix_decrease_val_noeeprom
                                    299 	.globl _rgb_matrix_increase_speed_noeeprom
                                    300 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    301 	.globl _rgb_matrix_toggle
                                    302 	.globl _rgb_matrix_step
                                    303 	.globl _rgb_matrix_step_reverse
                                    304 	.globl _rgb_matrix_increase_hue
                                    305 	.globl _rgb_matrix_decrease_hue
                                    306 	.globl _rgb_matrix_increase_sat
                                    307 	.globl _rgb_matrix_decrease_sat
                                    308 	.globl _rgb_matrix_increase_val
                                    309 	.globl _rgb_matrix_decrease_val
                                    310 	.globl _rgb_matrix_increase_speed
                                    311 	.globl _rgb_matrix_decrease_speed
                                    312 	.globl _rgb_matrix_mode
                                    313 ;--------------------------------------------------------
                                    314 ; special function registers
                                    315 ;--------------------------------------------------------
                                    316 	.area RSEG    (ABS,DATA)
      000000                        317 	.org 0x0000
                           0000D0   318 _PSW	=	0x00d0
                           0000E0   319 _ACC	=	0x00e0
                           0000F0   320 _B	=	0x00f0
                           0000FD   321 _A_INV	=	0x00fd
                           000081   322 _SP	=	0x0081
                           000082   323 _DPL	=	0x0082
                           000083   324 _DPH	=	0x0083
                           0000A1   325 _SAFE_MOD	=	0x00a1
                           0000B1   326 _GLOBAL_CFG	=	0x00b1
                           000087   327 _PCON	=	0x0087
                           0000BA   328 _POWER_CFG	=	0x00ba
                           0000B9   329 _CLOCK_CFG	=	0x00b9
                           0000A9   330 _WAKE_CTRL	=	0x00a9
                           0000FE   331 _RESET_KEEP	=	0x00fe
                           0000FF   332 _WDOG_COUNT	=	0x00ff
                           0000A8   333 _IE	=	0x00a8
                           0000B8   334 _IP	=	0x00b8
                           0000E8   335 _IE_EX	=	0x00e8
                           0000E9   336 _IP_EX	=	0x00e9
                           0000B2   337 _GPIO_IE	=	0x00b2
                           008584   338 _ROM_ADDR	=	0x8584
                           000084   339 _ROM_ADDR_L	=	0x0084
                           000085   340 _ROM_ADDR_H	=	0x0085
                           008F8E   341 _ROM_DATA_HI	=	0x8f8e
                           00008E   342 _ROM_DATA_HL	=	0x008e
                           00008F   343 _ROM_DATA_HH	=	0x008f
                           000086   344 _ROM_CTRL	=	0x0086
                           000080   345 _P0	=	0x0080
                           0000C4   346 _P0_MOD_OC	=	0x00c4
                           0000C5   347 _P0_DIR_PU	=	0x00c5
                           000090   348 _P1	=	0x0090
                           000092   349 _P1_MOD_OC	=	0x0092
                           000093   350 _P1_DIR_PU	=	0x0093
                           0000A0   351 _P2	=	0x00a0
                           000094   352 _P2_MOD_OC	=	0x0094
                           000095   353 _P2_DIR_PU	=	0x0095
                           0000B0   354 _P3	=	0x00b0
                           000096   355 _P3_MOD_OC	=	0x0096
                           000097   356 _P3_DIR_PU	=	0x0097
                           0000C0   357 _P4	=	0x00c0
                           0000C2   358 _P4_MOD_OC	=	0x00c2
                           0000C3   359 _P4_DIR_PU	=	0x00c3
                           0000C1   360 _P4_LED_KEY	=	0x00c1
                           0000AA   361 _P5_IN	=	0x00aa
                           0000AB   362 _P5_OUT_PU	=	0x00ab
                           0000AC   363 _P5_DIR	=	0x00ac
                           0000AD   364 _P6_IN	=	0x00ad
                           0000AE   365 _P6_OUT_PU	=	0x00ae
                           0000AF   366 _P6_DIR	=	0x00af
                           0000F1   367 _P7	=	0x00f1
                           0000A2   368 _XBUS_AUX	=	0x00a2
                           000088   369 _TCON	=	0x0088
                           000089   370 _TMOD	=	0x0089
                           00008A   371 _TL0	=	0x008a
                           00008B   372 _TL1	=	0x008b
                           00008C   373 _TH0	=	0x008c
                           00008D   374 _TH1	=	0x008d
                           000098   375 _SCON	=	0x0098
                           000099   376 _SBUF	=	0x0099
                           0000C8   377 _T2CON	=	0x00c8
                           0000C9   378 _T2MOD	=	0x00c9
                           00CBCA   379 _RCAP2	=	0xcbca
                           0000CA   380 _RCAP2L	=	0x00ca
                           0000CB   381 _RCAP2H	=	0x00cb
                           00CDCC   382 _T2COUNT	=	0xcdcc
                           0000CC   383 _TL2	=	0x00cc
                           0000CD   384 _TH2	=	0x00cd
                           00CFCE   385 _T2CAP1	=	0xcfce
                           0000CE   386 _T2CAP1L	=	0x00ce
                           0000CF   387 _T2CAP1H	=	0x00cf
                           0000F8   388 _SPI0_STAT	=	0x00f8
                           0000F9   389 _SPI0_DATA	=	0x00f9
                           0000FA   390 _SPI0_CTRL	=	0x00fa
                           0000FB   391 _SPI0_CK_SE	=	0x00fb
                           0000FC   392 _SPI0_SETUP	=	0x00fc
                           0000BC   393 _SCON1	=	0x00bc
                           0000BD   394 _SBUF1	=	0x00bd
                           0000BE   395 _SBAUD1	=	0x00be
                           0000BF   396 _SIF1	=	0x00bf
                           0000B4   397 _SPI1_STAT	=	0x00b4
                           0000B5   398 _SPI1_DATA	=	0x00b5
                           0000B6   399 _SPI1_CTRL	=	0x00b6
                           0000B7   400 _SPI1_CK_SE	=	0x00b7
                           0000F3   401 _ADC_CTRL	=	0x00f3
                           00F5F4   402 _ADC_DAT	=	0xf5f4
                           0000F4   403 _ADC_DAT_L	=	0x00f4
                           0000F5   404 _ADC_DAT_H	=	0x00f5
                           0000F6   405 _ADC_CHAN	=	0x00f6
                           0000A6   406 _LED_COMMON	=	0x00a6
                           0000A7   407 _LED_PWM_OE	=	0x00a7
                           00C7C6   408 _LED_DMA	=	0xc7c6
                           0000C6   409 _LED_DMA_L	=	0x00c6
                           0000C7   410 _LED_DMA_H	=	0x00c7
                           0000F7   411 _LED_STATUS	=	0x00f7
                           0000B3   412 _I2CX_INT	=	0x00b3
                           0000BB   413 _I2CS_INT_ST	=	0x00bb
                                    414 ;--------------------------------------------------------
                                    415 ; special function bits
                                    416 ;--------------------------------------------------------
                                    417 	.area RSEG    (ABS,DATA)
      000000                        418 	.org 0x0000
                           0000D7   419 _CY	=	0x00d7
                           0000D6   420 _AC	=	0x00d6
                           0000D5   421 _F0	=	0x00d5
                           0000D4   422 _RS1	=	0x00d4
                           0000D3   423 _RS0	=	0x00d3
                           0000D2   424 _OV	=	0x00d2
                           0000D1   425 _F1	=	0x00d1
                           0000D0   426 _P	=	0x00d0
                           0000AF   427 _EA	=	0x00af
                           0000AE   428 _E_DIS	=	0x00ae
                           0000AD   429 _ET2	=	0x00ad
                           0000AC   430 _ES	=	0x00ac
                           0000AB   431 _ET1	=	0x00ab
                           0000AA   432 _EX1	=	0x00aa
                           0000A9   433 _ET0	=	0x00a9
                           0000A8   434 _EX0	=	0x00a8
                           0000BF   435 _PH_FLAG	=	0x00bf
                           0000BE   436 _PL_FLAG	=	0x00be
                           0000BD   437 _PT2	=	0x00bd
                           0000BC   438 _PS	=	0x00bc
                           0000BB   439 _PT1	=	0x00bb
                           0000BA   440 _PX1	=	0x00ba
                           0000B9   441 _PT0	=	0x00b9
                           0000B8   442 _PX0	=	0x00b8
                           0000EF   443 _IE_WDOG	=	0x00ef
                           0000EE   444 _IE_GPIO	=	0x00ee
                           0000ED   445 _IE_PWM_I2C	=	0x00ed
                           0000EC   446 _IE_UART1	=	0x00ec
                           0000EB   447 _IE_ADC	=	0x00eb
                           0000E9   448 _IE_USB	=	0x00e9
                           0000E8   449 _IE_SPI0	=	0x00e8
                           000087   450 _P0_7	=	0x0087
                           000086   451 _P0_6	=	0x0086
                           000085   452 _P0_5	=	0x0085
                           000084   453 _P0_4	=	0x0084
                           000083   454 _P0_3	=	0x0083
                           000082   455 _P0_2	=	0x0082
                           000081   456 _P0_1	=	0x0081
                           000080   457 _P0_0	=	0x0080
                           000081   458 _SDA0	=	0x0081
                           000080   459 _SCL0	=	0x0080
                           000083   460 _TXD_	=	0x0083
                           000082   461 _RXD_	=	0x0082
                           000085   462 _AIN13	=	0x0085
                           000084   463 _AIN12	=	0x0084
                           000083   464 _AIN11	=	0x0083
                           000082   465 _AIN10	=	0x0082
                           000081   466 _AIN9	=	0x0081
                           000080   467 _AIN8	=	0x0080
                           000097   468 _P1_7	=	0x0097
                           000096   469 _P1_6	=	0x0096
                           000095   470 _P1_5	=	0x0095
                           000094   471 _P1_4	=	0x0094
                           000093   472 _P1_3	=	0x0093
                           000092   473 _P1_2	=	0x0092
                           000091   474 _P1_1	=	0x0091
                           000090   475 _P1_0	=	0x0090
                           000097   476 _TXD1_	=	0x0097
                           000096   477 _RXD1_	=	0x0096
                           000097   478 _SCK	=	0x0097
                           000096   479 _MISO	=	0x0096
                           000095   480 _MOSI	=	0x0095
                           000094   481 _SCS	=	0x0094
                           000092   482 _INT0_	=	0x0092
                           000091   483 _T2EX	=	0x0091
                           000091   484 _CAP2	=	0x0091
                           000090   485 _T2	=	0x0090
                           000090   486 _CAP1	=	0x0090
                           000097   487 _AIN7	=	0x0097
                           000096   488 _AIN6	=	0x0096
                           000095   489 _AIN5	=	0x0095
                           000094   490 _AIN4	=	0x0094
                           000093   491 _AIN3	=	0x0093
                           000092   492 _AIN2	=	0x0092
                           000091   493 _AIN1	=	0x0091
                           000090   494 _AIN0	=	0x0090
                           0000A7   495 _P2_7	=	0x00a7
                           0000A6   496 _P2_6	=	0x00a6
                           0000A5   497 _P2_5	=	0x00a5
                           0000A4   498 _P2_4	=	0x00a4
                           0000A3   499 _P2_3	=	0x00a3
                           0000A2   500 _P2_2	=	0x00a2
                           0000A1   501 _P2_1	=	0x00a1
                           0000A0   502 _P2_0	=	0x00a0
                           0000A7   503 _TXD1	=	0x00a7
                           0000A6   504 _RXD1	=	0x00a6
                           0000A5   505 _T2EX_	=	0x00a5
                           0000A5   506 _CAP2_	=	0x00a5
                           0000A4   507 _T2_	=	0x00a4
                           0000A4   508 _CAP1_	=	0x00a4
                           0000B7   509 _P3_7	=	0x00b7
                           0000B6   510 _P3_6	=	0x00b6
                           0000B5   511 _P3_5	=	0x00b5
                           0000B4   512 _P3_4	=	0x00b4
                           0000B3   513 _P3_3	=	0x00b3
                           0000B2   514 _P3_2	=	0x00b2
                           0000B1   515 _P3_1	=	0x00b1
                           0000B0   516 _P3_0	=	0x00b0
                           0000B7   517 _SCK1	=	0x00b7
                           0000B6   518 _MISO1	=	0x00b6
                           0000B5   519 _MOSI1	=	0x00b5
                           0000B5   520 _T1	=	0x00b5
                           0000B4   521 _T0	=	0x00b4
                           0000B3   522 _INT1	=	0x00b3
                           0000B2   523 _INT0	=	0x00b2
                           0000B1   524 _TXD	=	0x00b1
                           0000B0   525 _RXD	=	0x00b0
                           0000C6   526 _P4_6	=	0x00c6
                           0000C5   527 _P4_5	=	0x00c5
                           0000C4   528 _P4_4	=	0x00c4
                           0000C3   529 _P4_3	=	0x00c3
                           0000C2   530 _P4_2	=	0x00c2
                           0000C1   531 _P4_1	=	0x00c1
                           0000C0   532 _P4_0	=	0x00c0
                           00008F   533 _TF1	=	0x008f
                           00008E   534 _TR1	=	0x008e
                           00008D   535 _TF0	=	0x008d
                           00008C   536 _TR0	=	0x008c
                           00008B   537 _IE1	=	0x008b
                           00008A   538 _IT1	=	0x008a
                           000089   539 _IE0	=	0x0089
                           000088   540 _IT0	=	0x0088
                           00009F   541 _SM0	=	0x009f
                           00009E   542 _SM1	=	0x009e
                           00009D   543 _SM2	=	0x009d
                           00009C   544 _REN	=	0x009c
                           00009B   545 _TB8	=	0x009b
                           00009A   546 _RB8	=	0x009a
                           000099   547 _TI	=	0x0099
                           000098   548 _RI	=	0x0098
                           0000CF   549 _TF2	=	0x00cf
                           0000CF   550 _CAP1F	=	0x00cf
                           0000CE   551 _EXF2	=	0x00ce
                           0000CD   552 _RCLK	=	0x00cd
                           0000CC   553 _TCLK	=	0x00cc
                           0000CB   554 _EXEN2	=	0x00cb
                           0000CA   555 _TR2	=	0x00ca
                           0000C9   556 _C_T2	=	0x00c9
                           0000C8   557 _CP_RL2	=	0x00c8
                           0000FF   558 _S0_FST_ACT	=	0x00ff
                           0000FE   559 _S0_IF_OV	=	0x00fe
                           0000FD   560 _S0_IF_FIRST	=	0x00fd
                           0000FC   561 _S0_IF_BYTE	=	0x00fc
                           0000FB   562 _S0_FREE	=	0x00fb
                           0000FA   563 _S0_T_FIFO	=	0x00fa
                           0000F8   564 _S0_R_FIFO	=	0x00f8
                           0000F7   565 _ADC_START	=	0x00f7
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable register banks
                                    568 ;--------------------------------------------------------
                                    569 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        570 	.ds 8
                                    571 ;--------------------------------------------------------
                                    572 ; internal ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area DSEG    (DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; overlayable items in internal ram
                                    577 ;--------------------------------------------------------
                                    578 ;--------------------------------------------------------
                                    579 ; indirectly addressable internal ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area ISEG    (DATA)
                                    582 ;--------------------------------------------------------
                                    583 ; absolute internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area IABS    (ABS,DATA)
                                    586 	.area IABS    (ABS,DATA)
                                    587 ;--------------------------------------------------------
                                    588 ; bit data
                                    589 ;--------------------------------------------------------
                                    590 	.area BSEG    (BIT)
      00000D                        591 _rgb_matrix_task_sloc0_1_0:
      00000D                        592 	.ds 1
                                    593 ;--------------------------------------------------------
                                    594 ; paged external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area PSEG    (PAG,XDATA)
                                    597 ;--------------------------------------------------------
                                    598 ; uninitialized external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area XSEG    (XDATA)
      000698                        601 _rgb_matrix_config::
      000698                        602 	.ds 8
      0006A0                        603 _suspended:
      0006A0                        604 	.ds 1
      0006A1                        605 _dirty:
      0006A1                        606 	.ds 1
      0006A2                        607 _rendering:
      0006A2                        608 	.ds 1
      0006A3                        609 _changed_at:
      0006A3                        610 	.ds 2
      0006A5                        611 _frame_at:
      0006A5                        612 	.ds 2
      0006A7                        613 _phase:
      0006A7                        614 	.ds 2
      0006A9                        615 _led_index:
      0006A9                        616 	.ds 1
      0006AA                        617 _frame_mode:
      0006AA                        618 	.ds 1
      0006AB                        619 _frame_hue:
      0006AB                        620 	.ds 1
      0006AC                        621 _frame_sat:
      0006AC                        622 	.ds 1
      0006AD                        623 _frame_val:
      0006AD                        624 	.ds 1
      0006AE                        625 _frame_flags:
      0006AE                        626 	.ds 1
      0006AF                        627 _frame_phase:
      0006AF                        628 	.ds 1
      0006B0                        629 _reactive_age:
      0006B0                        630 	.ds 82
      000702                        631 _reactive_at:
      000702                        632 	.ds 2
      000704                        633 _add_sat_PARM_2:
      000704                        634 	.ds 1
      000705                        635 _add_sat_x_10000_264:
      000705                        636 	.ds 1
      000706                        637 _sub_sat_PARM_2:
      000706                        638 	.ds 1
      000707                        639 _sub_sat_x_10000_266:
      000707                        640 	.ds 1
      000708                        641 _rgb_matrix_set_color_PARM_2:
      000708                        642 	.ds 1
      000709                        643 _rgb_matrix_set_color_PARM_3:
      000709                        644 	.ds 1
      00070A                        645 _rgb_matrix_set_color_PARM_4:
      00070A                        646 	.ds 1
      00070B                        647 _rgb_matrix_set_color_index_10000_282:
      00070B                        648 	.ds 2
      00070D                        649 _rgb_matrix_set_color_all_PARM_2:
      00070D                        650 	.ds 1
      00070E                        651 _rgb_matrix_set_color_all_PARM_3:
      00070E                        652 	.ds 1
      00070F                        653 _rgb_matrix_set_color_all_r_10000_285:
      00070F                        654 	.ds 1
      000710                        655 _sine8_theta_10000_287:
      000710                        656 	.ds 1
      000711                        657 _sine8_offset_10000_288:
      000711                        658 	.ds 1
      000712                        659 _sine8_fraction_10000_288:
      000712                        660 	.ds 1
      000713                        661 _breathing_cie_value_10000_291:
      000713                        662 	.ds 1
      000714                        663 _rgb_matrix_task_end_10000_296:
      000714                        664 	.ds 1
      000715                        665 _rgb_matrix_task_hsv_10000_296:
      000715                        666 	.ds 3
      000718                        667 _rgb_matrix_task_rgb_10000_296:
      000718                        668 	.ds 3
      00071B                        669 _process_rgb_matrix_PARM_2:
      00071B                        670 	.ds 1
      00071C                        671 _process_rgb_matrix_PARM_3:
      00071C                        672 	.ds 1
      00071D                        673 _process_rgb_matrix_row_10000_317:
      00071D                        674 	.ds 1
      00071E                        675 _rgb_matrix_set_suspend_state_state_10000_324:
      00071E                        676 	.ds 1
      00071F                        677 _rgb_matrix_mode_noeeprom_mode_10000_353:
      00071F                        678 	.ds 1
      000720                        679 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000720                        680 	.ds 1
      000721                        681 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000721                        682 	.ds 1
      000722                        683 _rgb_matrix_sethsv_noeeprom_hue_10000_361:
      000722                        684 	.ds 2
      000724                        685 _rgb_matrix_set_speed_noeeprom_speed_10000_363:
      000724                        686 	.ds 1
      000725                        687 _rgb_matrix_mode_mode_10000_409:
      000725                        688 	.ds 1
                                    689 ;--------------------------------------------------------
                                    690 ; absolute external ram data
                                    691 ;--------------------------------------------------------
                                    692 	.area XABS    (ABS,XDATA)
                                    693 ;--------------------------------------------------------
                                    694 ; initialized external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XISEG   (XDATA)
                                    697 	.area HOME    (CODE)
                                    698 	.area GSINIT0 (CODE)
                                    699 	.area GSINIT1 (CODE)
                                    700 	.area GSINIT2 (CODE)
                                    701 	.area GSINIT3 (CODE)
                                    702 	.area GSINIT4 (CODE)
                                    703 	.area GSINIT5 (CODE)
                                    704 	.area GSINIT  (CODE)
                                    705 	.area GSFINAL (CODE)
                                    706 	.area CSEG    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; global & static initialisations
                                    709 ;--------------------------------------------------------
                                    710 	.area HOME    (CODE)
                                    711 	.area GSINIT  (CODE)
                                    712 	.area GSFINAL (CODE)
                                    713 	.area GSINIT  (CODE)
                                    714 ;--------------------------------------------------------
                                    715 ; Home
                                    716 ;--------------------------------------------------------
                                    717 	.area HOME    (CODE)
                                    718 	.area HOME    (CODE)
                                    719 ;--------------------------------------------------------
                                    720 ; code
                                    721 ;--------------------------------------------------------
                                    722 	.area CSEG    (CODE)
                                    723 ;------------------------------------------------------------
                                    724 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    725 ;------------------------------------------------------------
                                    726 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    729 ;	-----------------------------------------
                           000007   730 	ar7 = 0x07
                           000006   731 	ar6 = 0x06
                           000005   732 	ar5 = 0x05
                           000004   733 	ar4 = 0x04
                           000003   734 	ar3 = 0x03
                           000002   735 	ar2 = 0x02
                           000001   736 	ar1 = 0x01
                           000000   737 	ar0 = 0x00
                                    738 ;	 function clear_reactive
                                    739 ;	-----------------------------------------
      004E92                        740 _clear_reactive:
                                    741 ;	keyboards/ajazz/ak820/ak820_rgb.c:44: memset(reactive_age, 0, sizeof(reactive_age));
      004E92 12 57 35         [24]  742 	lcall	_ak820_outline_0142
      004E95 74 52            [12]  743 	mov	a,#0x52
      004E97 12 4E 60         [24]  744 	lcall	_ak820_outline_0003
      004E9A 90 06 B0         [24]  745 	mov	dptr,#_reactive_age
      004E9D F5 F0            [12]  746 	mov	b,a
      004E9F 12 BD B1         [24]  747 	lcall	_memset
                                    748 ;	keyboards/ajazz/ak820/ak820_rgb.c:45: reactive_at = timer_read();
      004EA2 12 48 CB         [24]  749 	lcall	_timer_read
      004EA5 12 57 16         [24]  750 	lcall	_ak820_outline_0119
      004EA8 90 07 02         [24]  751 	mov	dptr,#_reactive_at
      004EAB 12 57 1C         [24]  752 	lcall	_ak820_outline_0128
                                    753 ;	keyboards/ajazz/ak820/ak820_rgb.c:46: }
      004EAE 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'age_reactive'
                                    757 ;------------------------------------------------------------
                                    758 ;ticks         Allocated with name '_age_reactive_ticks_10000_260'
                                    759 ;i             Allocated with name '_age_reactive_i_10000_260'
                                    760 ;decay         Allocated with name '_age_reactive_decay_10000_260'
                                    761 ;------------------------------------------------------------
                                    762 ;	keyboards/ajazz/ak820/ak820_rgb.c:48: static void age_reactive(void) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function age_reactive
                                    765 ;	-----------------------------------------
      004EAF                        766 _age_reactive:
                                    767 ;	keyboards/ajazz/ak820/ak820_rgb.c:49: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004EAF 90 07 02         [24]  768 	mov	dptr,#_reactive_at
      004EB2 12 43 C5         [24]  769 	lcall	_ak820_outline_0000
      004EB5 12 43 D3         [24]  770 	lcall	_ak820_outline_0002
      004EB8 12 48 CE         [24]  771 	lcall	_timer_elapsed
      004EBB AE 82            [24]  772 	mov	r6, dpl
      004EBD E5 83            [12]  773 	mov	a,dph
      004EBF C4               [12]  774 	swap	a
      004EC0 CE               [12]  775 	xch	a,r6
      004EC1 C4               [12]  776 	swap	a
      004EC2 54 0F            [12]  777 	anl	a,#0x0f
      004EC4 6E               [12]  778 	xrl	a,r6
      004EC5 CE               [12]  779 	xch	a,r6
      004EC6 54 0F            [12]  780 	anl	a,#0x0f
      004EC8 CE               [12]  781 	xch	a,r6
      004EC9 6E               [12]  782 	xrl	a,r6
      004ECA CE               [12]  783 	xch	a,r6
                                    784 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: if (!ticks) return;
      004ECB FF               [12]  785 	mov	r7,a
      004ECC 4E               [12]  786 	orl	a,r6
      004ECD 70 01            [24]  787 	jnz	00102$
      004ECF 22               [24]  788 	ret
      004ED0                        789 00102$:
                                    790 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: reactive_at += ticks << 4;
      004ED0 8E 04            [24]  791 	mov	ar4,r6
      004ED2 EF               [12]  792 	mov	a,r7
      004ED3 C4               [12]  793 	swap	a
      004ED4 54 F0            [12]  794 	anl	a,#0xf0
      004ED6 CC               [12]  795 	xch	a,r4
      004ED7 C4               [12]  796 	swap	a
      004ED8 CC               [12]  797 	xch	a,r4
      004ED9 6C               [12]  798 	xrl	a,r4
      004EDA CC               [12]  799 	xch	a,r4
      004EDB 54 F0            [12]  800 	anl	a,#0xf0
      004EDD CC               [12]  801 	xch	a,r4
      004EDE 6C               [12]  802 	xrl	a,r4
      004EDF FD               [12]  803 	mov	r5,a
      004EE0 90 07 02         [24]  804 	mov	dptr,#_reactive_at
      004EE3 12 44 11         [24]  805 	lcall	_ak820_outline_0024
      004EE6 90 07 02         [24]  806 	mov	dptr,#_reactive_at
      004EE9 EC               [12]  807 	mov	a,r4
      004EEA 2A               [12]  808 	add	a, r2
      004EEB F0               [24]  809 	movx	@dptr,a
      004EEC ED               [12]  810 	mov	a,r5
      004EED 3B               [12]  811 	addc	a, r3
      004EEE A3               [24]  812 	inc	dptr
      004EEF F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      004EF0 12 56 D7         [24]  815 	lcall	_ak820_outline_0045
      004EF3 E4               [12]  816 	clr	a
      004EF4 9D               [12]  817 	subb	a,r5
      004EF5 50 04            [24]  818 	jnc	00108$
                                    819 ;	free result
      004EF7 7D FF            [12]  820 	mov	r5,#0xff
      004EF9 80 02            [24]  821 	sjmp	00109$
      004EFB                        822 00108$:
      004EFB 8E 05            [24]  823 	mov	ar5,r6
      004EFD                        824 00109$:
                                    825 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004EFD 7F 00            [12]  826 	mov	r7,#0x00
      004EFF                        827 00104$:
                                    828 ;	keyboards/ajazz/ak820/ak820_rgb.c:56: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      004EFF EF               [12]  829 	mov	a,r7
      004F00 24 B0            [12]  830 	add	a, #_reactive_age
      004F02 FC               [12]  831 	mov	r4,a
      004F03 E4               [12]  832 	clr	a
      004F04 34 06            [12]  833 	addc	a, #(_reactive_age >> 8)
      004F06 FE               [12]  834 	mov	r6,a
      004F07 8C 82            [24]  835 	mov	dpl,r4
      004F09 8E 83            [24]  836 	mov	dph,r6
      004F0B E0               [24]  837 	movx	a,@dptr
      004F0C FB               [12]  838 	mov	r3,a
      004F0D C3               [12]  839 	clr	c
      004F0E ED               [12]  840 	mov	a,r5
      004F0F 9B               [12]  841 	subb	a,r3
      004F10 40 04            [24]  842 	jc	00110$
      004F12 7B 00            [12]  843 	mov	r3,#0x00
      004F14 80 08            [24]  844 	sjmp	00111$
      004F16                        845 00110$:
      004F16 8C 82            [24]  846 	mov	dpl,r4
      004F18 8E 83            [24]  847 	mov	dph,r6
      004F1A E0               [24]  848 	movx	a,@dptr
      004F1B C3               [12]  849 	clr	c
      004F1C 9D               [12]  850 	subb	a,r5
      004F1D FB               [12]  851 	mov	r3,a
      004F1E                        852 00111$:
      004F1E 8C 82            [24]  853 	mov	dpl,r4
      004F20 8E 83            [24]  854 	mov	dph,r6
      004F22 EB               [12]  855 	mov	a,r3
      004F23 F0               [24]  856 	movx	@dptr,a
                                    857 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004F24 0F               [12]  858 	inc	r7
      004F25 BF 52 00         [24]  859 	cjne	r7,#0x52,00144$
      004F28                        860 00144$:
      004F28 40 D5            [24]  861 	jc	00104$
                                    862 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: }
      004F2A 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'add_sat'
                                    866 ;------------------------------------------------------------
                                    867 ;y             Allocated with name '_add_sat_PARM_2'
                                    868 ;x             Allocated with name '_add_sat_x_10000_264'
                                    869 ;------------------------------------------------------------
                                    870 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function add_sat
                                    873 ;	-----------------------------------------
      004F2B                        874 _add_sat:
      004F2B E5 82            [12]  875 	mov	a,dpl
      004F2D 90 07 05         [24]  876 	mov	dptr,#_add_sat_x_10000_264
      004F30 F0               [24]  877 	movx	@dptr,a
                                    878 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: return x > (uint8_t)(255 - y) ? 255 : x + y;
      004F31 90 07 04         [24]  879 	mov	dptr,#_add_sat_PARM_2
      004F34 E0               [24]  880 	movx	a,@dptr
      004F35 FF               [12]  881 	mov	r7,a
      004F36 FE               [12]  882 	mov	r6,a
      004F37 74 FF            [12]  883 	mov	a,#0xff
      004F39 C3               [12]  884 	clr	c
      004F3A 9E               [12]  885 	subb	a,r6
      004F3B FE               [12]  886 	mov	r6,a
      004F3C 90 07 05         [24]  887 	mov	dptr,#_add_sat_x_10000_264
      004F3F E0               [24]  888 	movx	a,@dptr
      004F40 FD               [12]  889 	mov	r5,a
      004F41 C3               [12]  890 	clr	c
      004F42 EE               [12]  891 	mov	a,r6
      004F43 9D               [12]  892 	subb	a,r5
      004F44 50 04            [24]  893 	jnc	00103$
                                    894 ;	free result
      004F46 7E FF            [12]  895 	mov	r6,#0xff
      004F48 80 03            [24]  896 	sjmp	00104$
      004F4A                        897 00103$:
      004F4A EF               [12]  898 	mov	a,r7
      004F4B 2D               [12]  899 	add	a, r5
      004F4C FE               [12]  900 	mov	r6,a
      004F4D                        901 00104$:
      004F4D 8E 82            [24]  902 	mov	dpl, r6
                                    903 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: }
      004F4F 22               [24]  904 	ret
                                    905 ;------------------------------------------------------------
                                    906 ;Allocation info for local variables in function 'sub_sat'
                                    907 ;------------------------------------------------------------
                                    908 ;y             Allocated with name '_sub_sat_PARM_2'
                                    909 ;x             Allocated with name '_sub_sat_x_10000_266'
                                    910 ;------------------------------------------------------------
                                    911 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function sub_sat
                                    914 ;	-----------------------------------------
      004F50                        915 _sub_sat:
      004F50 E5 82            [12]  916 	mov	a,dpl
      004F52 90 07 07         [24]  917 	mov	dptr,#_sub_sat_x_10000_266
      004F55 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_rgb.c:65: return x < y ? 0 : x - y;
      004F56 E0               [24]  920 	movx	a,@dptr
      004F57 FF               [12]  921 	mov	r7,a
      004F58 90 07 06         [24]  922 	mov	dptr,#_sub_sat_PARM_2
      004F5B E0               [24]  923 	movx	a,@dptr
      004F5C FE               [12]  924 	mov	r6,a
      004F5D C3               [12]  925 	clr	c
      004F5E EF               [12]  926 	mov	a,r7
      004F5F 9E               [12]  927 	subb	a,r6
      004F60 50 04            [24]  928 	jnc	00103$
      004F62 7D 00            [12]  929 	mov	r5,#0x00
      004F64 80 04            [24]  930 	sjmp	00104$
      004F66                        931 00103$:
      004F66 EF               [12]  932 	mov	a,r7
      004F67 C3               [12]  933 	clr	c
      004F68 9E               [12]  934 	subb	a,r6
      004F69 FD               [12]  935 	mov	r5,a
      004F6A                        936 00104$:
      004F6A 8D 82            [24]  937 	mov	dpl, r5
                                    938 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: }
      004F6C 22               [24]  939 	ret
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'mark_dirty'
                                    942 ;------------------------------------------------------------
                                    943 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: static void mark_dirty(void) {
                                    944 ;	-----------------------------------------
                                    945 ;	 function mark_dirty
                                    946 ;	-----------------------------------------
      004F6D                        947 _mark_dirty:
                                    948 ;	keyboards/ajazz/ak820/ak820_rgb.c:69: dirty = true;
      004F6D 90 06 A1         [24]  949 	mov	dptr,#_dirty
      004F70 74 01            [12]  950 	mov	a,#0x01
      004F72 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: changed_at = timer_read();
      004F73 12 48 CB         [24]  953 	lcall	_timer_read
      004F76 12 57 16         [24]  954 	lcall	_ak820_outline_0119
      004F79 90 06 A3         [24]  955 	mov	dptr,#_changed_at
      004F7C 12 57 1C         [24]  956 	lcall	_ak820_outline_0128
                                    957 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: }
      004F7F 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    961 ;------------------------------------------------------------
                                    962 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_271'
                                    963 ;------------------------------------------------------------
                                    964 ;	keyboards/ajazz/ak820/ak820_rgb.c:73: void eeconfig_update_rgb_matrix(void) {
                                    965 ;	-----------------------------------------
                                    966 ;	 function eeconfig_update_rgb_matrix
                                    967 ;	-----------------------------------------
      004F80                        968 _eeconfig_update_rgb_matrix:
                                    969 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: raw[6] = raw[7] = 0;
      004F80 90 06 9F         [24]  971 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      004F83 E4               [12]  972 	clr	a
      004F84 F0               [24]  973 	movx	@dptr,a
      004F85 90 06 9E         [24]  974 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      004F88 F0               [24]  975 	movx	@dptr,a
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      004F89 90 05 94         [24]  977 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004F8C 74 18            [12]  978 	mov	a,#0x18
      004F8E 12 4E 60         [24]  979 	lcall	_ak820_outline_0003
      004F91 A3               [24]  980 	inc	dptr
      004F92 F0               [24]  981 	movx	@dptr,a
      004F93 90 05 97         [24]  982 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004F96 74 08            [12]  983 	mov	a,#0x08
      004F98 12 4E 60         [24]  984 	lcall	_ak820_outline_0003
      004F9B 90 06 98         [24]  985 	mov	dptr,#_rgb_matrix_config
      004F9E 12 42 C7         [24]  986 	lcall	_ak820_eeprom_update_block_xdata
                                    987 ;	keyboards/ajazz/ak820/ak820_rgb.c:78: dirty = false;
      004FA1 90 06 A1         [24]  988 	mov	dptr,#_dirty
      004FA4 E4               [12]  989 	clr	a
      004FA5 F0               [24]  990 	movx	@dptr,a
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: }
      004FA6 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      004FA7                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      004FA7 12 57 35         [24] 1002 	lcall	_ak820_outline_0142
      004FAA 74 08            [12] 1003 	mov	a,#0x08
      004FAC 12 4E 60         [24] 1004 	lcall	_ak820_outline_0003
      004FAF 90 06 98         [24] 1005 	mov	dptr,#_rgb_matrix_config
      004FB2 F5 F0            [12] 1006 	mov	b,a
      004FB4 12 BD B1         [24] 1007 	lcall	_memset
                                   1008 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: rgb_matrix_config.enable = 1;
      004FB7 12 56 FD         [24] 1009 	lcall	_ak820_outline_0078
      004FBA 44 01            [12] 1010 	orl	a,#0x01
      004FBC F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      004FBD 12 56 D0         [24] 1013 	lcall	_ak820_outline_0036
      004FC0 44 04            [12] 1014 	orl	a,#0x04
      004FC2 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: rgb_matrix_config.hsv.h = 0;
      004FC3 90 06 99         [24] 1017 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      004FC6 E4               [12] 1018 	clr	a
      004FC7 F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	keyboards/ajazz/ak820/ak820_rgb.c:86: rgb_matrix_config.hsv.s = 255;
      004FC8 90 06 9A         [24] 1021 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      004FCB 14               [12] 1022 	dec	a
      004FCC F0               [24] 1023 	movx	@dptr,a
                                   1024 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      004FCD 90 06 9B         [24] 1025 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      004FD0 74 50            [12] 1026 	mov	a,#0x50
      004FD2 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      004FD3 90 06 9C         [24] 1029 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      004FD6 74 60            [12] 1030 	mov	a,#0x60
      004FD8 F0               [24] 1031 	movx	@dptr,a
                                   1032 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.flags = LED_FLAG_ALL;
      004FD9 90 06 9D         [24] 1033 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      004FDC 74 FF            [12] 1034 	mov	a,#0xff
      004FDE F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: eeconfig_update_rgb_matrix();
                                   1037 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: }
      004FDF 02 4F 80         [24] 1038 	ljmp	_eeconfig_update_rgb_matrix
                                   1039 ;------------------------------------------------------------
                                   1040 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1041 ;------------------------------------------------------------
                                   1042 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: void rgb_matrix_reload_from_eeprom(void) {
                                   1043 ;	-----------------------------------------
                                   1044 ;	 function rgb_matrix_reload_from_eeprom
                                   1045 ;	-----------------------------------------
      004FE2                       1046 _rgb_matrix_reload_from_eeprom:
                                   1047 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      004FE2 90 05 84         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004FE5 74 18            [12] 1049 	mov	a,#0x18
      004FE7 12 4E 60         [24] 1050 	lcall	_ak820_outline_0003
      004FEA A3               [24] 1051 	inc	dptr
      004FEB F0               [24] 1052 	movx	@dptr,a
      004FEC 90 05 87         [24] 1053 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004FEF 74 08            [12] 1054 	mov	a,#0x08
      004FF1 12 4E 60         [24] 1055 	lcall	_ak820_outline_0003
      004FF4 90 06 98         [24] 1056 	mov	dptr,#_rgb_matrix_config
      004FF7 12 41 51         [24] 1057 	lcall	_ak820_eeprom_read_block_xdata
                                   1058 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      004FFA 12 56 FD         [24] 1059 	lcall	_ak820_outline_0078
      004FFD 60 11            [24] 1060 	jz	00101$
      004FFF 12 56 BF         [24] 1061 	lcall	_ak820_outline_0013
      005002 C3               [12] 1062 	clr	c
      005003 64 80            [12] 1063 	xrl	a,#0x80
      005005 94 87            [12] 1064 	subb	a,#0x87
      005007 50 07            [24] 1065 	jnc	00101$
      005009 12 56 D0         [24] 1066 	lcall	_ak820_outline_0036
      00500C 24 FE            [12] 1067 	add	a,#0xff - 0x01
      00500E 50 03            [24] 1068 	jnc	00102$
                                   1069 ;	free result
      005010                       1070 00101$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix_default();
      005010 12 4F A7         [24] 1072 	lcall	_eeconfig_update_rgb_matrix_default
      005013                       1073 00102$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_rgb.c:98: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005013 90 06 9B         [24] 1075 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005016 E0               [24] 1076 	movx	a,@dptr
      005017 24 5F            [12] 1077 	add	a,#0xff - 0xa0
      005019 50 06            [24] 1078 	jnc	00106$
                                   1079 ;	free result
                                   1080 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00501B 90 06 9B         [24] 1081 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00501E 74 A0            [12] 1082 	mov	a,#0xa0
      005020 F0               [24] 1083 	movx	@dptr,a
      005021                       1084 00106$:
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: dirty = false;
      005021 90 06 A1         [24] 1086 	mov	dptr,#_dirty
      005024 E4               [12] 1087 	clr	a
      005025 F0               [24] 1088 	movx	@dptr,a
                                   1089 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: rendering = false;
      005026 90 06 A2         [24] 1090 	mov	dptr,#_rendering
      005029 F0               [24] 1091 	movx	@dptr,a
                                   1092 ;	keyboards/ajazz/ak820/ak820_rgb.c:103: clear_reactive();
                                   1093 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: }
      00502A 02 4E 92         [24] 1094 	ljmp	_clear_reactive
                                   1095 ;------------------------------------------------------------
                                   1096 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	keyboards/ajazz/ak820/ak820_rgb.c:106: void rgb_matrix_init(void) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function rgb_matrix_init
                                   1101 ;	-----------------------------------------
      00502D                       1102 _rgb_matrix_init:
                                   1103 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: rgb_matrix_driver.init();
      00502D 90 BE 96         [24] 1104 	mov	dptr,#_rgb_matrix_driver
      005030 12 56 C8         [24] 1105 	lcall	_ak820_outline_0020
      005033 C0 07            [24] 1106 	push	ar7
      005035 C0 06            [24] 1107 	push	ar6
      005037 12 43 D3         [24] 1108 	lcall	_ak820_outline_0002
      00503A 12 30 75         [24] 1109 	lcall	__sdcc_call_dptr
      00503D D0 06            [24] 1110 	pop	ar6
      00503F D0 07            [24] 1111 	pop	ar7
                                   1112 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rgb_matrix_reload_from_eeprom();
      005041 12 4F E2         [24] 1113 	lcall	_rgb_matrix_reload_from_eeprom
                                   1114 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      005044 12 48 CB         [24] 1115 	lcall	_timer_read
      005047 12 44 1D         [24] 1116 	lcall	_ak820_outline_0027
      00504A EE               [12] 1117 	mov	a,r6
      00504B 24 F0            [12] 1118 	add	a,#0xf0
      00504D FE               [12] 1119 	mov	r6,a
      00504E EF               [12] 1120 	mov	a,r7
      00504F 34 FF            [12] 1121 	addc	a,#0xff
      005051 FF               [12] 1122 	mov	r7,a
      005052 90 06 A5         [24] 1123 	mov	dptr,#_frame_at
      005055 EE               [12] 1124 	mov	a,r6
      005056 12 43 E5         [24] 1125 	lcall	_ak820_outline_0007
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005059 22               [24] 1127 	ret
                                   1128 ;------------------------------------------------------------
                                   1129 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1130 ;------------------------------------------------------------
                                   1131 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1132 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1133 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1134 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_282'
                                   1135 ;------------------------------------------------------------
                                   1136 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1137 ;	-----------------------------------------
                                   1138 ;	 function rgb_matrix_set_color
                                   1139 ;	-----------------------------------------
      00505A                       1140 _rgb_matrix_set_color:
      00505A 12 43 EA         [24] 1141 	lcall	_ak820_outline_0010
      00505D 90 07 0B         [24] 1142 	mov	dptr,#_rgb_matrix_set_color_index_10000_282
      005060 12 43 E5         [24] 1143 	lcall	_ak820_outline_0007
                                   1144 ;	keyboards/ajazz/ak820/ak820_rgb.c:113: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) rgb_matrix_driver.set_color(index, r, g, b);
      005063 90 07 0B         [24] 1145 	mov	dptr,#_rgb_matrix_set_color_index_10000_282
      005066 12 43 C5         [24] 1146 	lcall	_ak820_outline_0000
      005069 20 E7 42         [24] 1147 	jb	acc.7,00104$
      00506C C3               [12] 1148 	clr	c
      00506D EE               [12] 1149 	mov	a,r6
      00506E 94 52            [12] 1150 	subb	a,#0x52
      005070 EF               [12] 1151 	mov	a,r7
      005071 64 80            [12] 1152 	xrl	a,#0x80
      005073 94 80            [12] 1153 	subb	a,#0x80
      005075 50 37            [24] 1154 	jnc	00104$
      005077 90 BE 98         [24] 1155 	mov	dptr,#(_rgb_matrix_driver + 0x0002)
      00507A E4               [12] 1156 	clr	a
      00507B 93               [24] 1157 	movc	a,@a+dptr
      00507C FC               [12] 1158 	mov	r4,a
      00507D A3               [24] 1159 	inc	dptr
      00507E E4               [12] 1160 	clr	a
      00507F 93               [24] 1161 	movc	a,@a+dptr
      005080 FD               [12] 1162 	mov	r5,a
      005081 C0 05            [24] 1163 	push	ar5
      005083 C0 04            [24] 1164 	push	ar4
      005085 90 07 0A         [24] 1165 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005088 E0               [24] 1166 	movx	a,@dptr
      005089 C0 E0            [24] 1167 	push	acc
      00508B 90 07 09         [24] 1168 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00508E E0               [24] 1169 	movx	a,@dptr
      00508F C0 E0            [24] 1170 	push	acc
      005091 90 07 08         [24] 1171 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005094 E0               [24] 1172 	movx	a,@dptr
      005095 C0 E0            [24] 1173 	push	acc
      005097 12 50 9C         [24] 1174 	lcall	00122$
      00509A 80 08            [24] 1175 	sjmp	00123$
      00509C                       1176 00122$:
      00509C C0 04            [24] 1177 	push	ar4
      00509E C0 05            [24] 1178 	push	ar5
      0050A0 12 43 D3         [24] 1179 	lcall	_ak820_outline_0002
      0050A3 22               [24] 1180 	ret
      0050A4                       1181 00123$:
      0050A4 15 81            [12] 1182 	dec	sp
      0050A6 15 81            [12] 1183 	dec	sp
      0050A8 15 81            [12] 1184 	dec	sp
      0050AA D0 04            [24] 1185 	pop	ar4
      0050AC D0 05            [24] 1186 	pop	ar5
      0050AE                       1187 00104$:
                                   1188 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: }
      0050AE 22               [24] 1189 	ret
                                   1190 ;------------------------------------------------------------
                                   1191 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1192 ;------------------------------------------------------------
                                   1193 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1194 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1195 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_285'
                                   1196 ;------------------------------------------------------------
                                   1197 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1198 ;	-----------------------------------------
                                   1199 ;	 function rgb_matrix_set_color_all
                                   1200 ;	-----------------------------------------
      0050AF                       1201 _rgb_matrix_set_color_all:
      0050AF E5 82            [12] 1202 	mov	a,dpl
      0050B1 90 07 0F         [24] 1203 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_285
      0050B4 F0               [24] 1204 	movx	@dptr,a
                                   1205 ;	keyboards/ajazz/ak820/ak820_rgb.c:117: rgb_matrix_driver.set_color_all(r, g, b);
      0050B5 90 BE 9A         [24] 1206 	mov	dptr,#(_rgb_matrix_driver + 0x0004)
      0050B8 12 56 C8         [24] 1207 	lcall	_ak820_outline_0020
      0050BB 90 07 0F         [24] 1208 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_285
      0050BE E0               [24] 1209 	movx	a,@dptr
      0050BF FD               [12] 1210 	mov	r5,a
      0050C0 C0 07            [24] 1211 	push	ar7
      0050C2 C0 06            [24] 1212 	push	ar6
      0050C4 90 07 0E         [24] 1213 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0050C7 E0               [24] 1214 	movx	a,@dptr
      0050C8 C0 E0            [24] 1215 	push	acc
      0050CA 90 07 0D         [24] 1216 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0050CD E0               [24] 1217 	movx	a,@dptr
      0050CE C0 E0            [24] 1218 	push	acc
      0050D0 12 50 D5         [24] 1219 	lcall	00103$
      0050D3 80 07            [24] 1220 	sjmp	00104$
      0050D5                       1221 00103$:
      0050D5 C0 06            [24] 1222 	push	ar6
      0050D7 C0 07            [24] 1223 	push	ar7
      0050D9 8D 82            [24] 1224 	mov	dpl, r5
      0050DB 22               [24] 1225 	ret
      0050DC                       1226 00104$:
      0050DC 15 81            [12] 1227 	dec	sp
      0050DE 15 81            [12] 1228 	dec	sp
      0050E0 D0 06            [24] 1229 	pop	ar6
      0050E2 D0 07            [24] 1230 	pop	ar7
                                   1231 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: }
      0050E4 22               [24] 1232 	ret
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'sine8'
                                   1235 ;------------------------------------------------------------
                                   1236 ;theta         Allocated with name '_sine8_theta_10000_287'
                                   1237 ;offset        Allocated with name '_sine8_offset_10000_288'
                                   1238 ;section       Allocated with name '_sine8_section_10000_288'
                                   1239 ;fraction      Allocated with name '_sine8_fraction_10000_288'
                                   1240 ;value         Allocated with name '_sine8_value_10000_288'
                                   1241 ;------------------------------------------------------------
                                   1242 ;	keyboards/ajazz/ak820/ak820_rgb.c:121: static uint8_t sine8(uint8_t theta) {
                                   1243 ;	-----------------------------------------
                                   1244 ;	 function sine8
                                   1245 ;	-----------------------------------------
      0050E5                       1246 _sine8:
      0050E5 E5 82            [12] 1247 	mov	a,dpl
      0050E7 90 07 10         [24] 1248 	mov	dptr,#_sine8_theta_10000_287
      0050EA F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: uint8_t offset = theta;
      0050EB E0               [24] 1251 	movx	a,@dptr
      0050EC FF               [12] 1252 	mov	r7,a
      0050ED 90 07 11         [24] 1253 	mov	dptr,#_sine8_offset_10000_288
      0050F0 F0               [24] 1254 	movx	@dptr,a
                                   1255 ;	keyboards/ajazz/ak820/ak820_rgb.c:125: if (theta & 0x40) offset = 255 - offset;
      0050F1 EF               [12] 1256 	mov	a,r7
      0050F2 30 E6 08         [24] 1257 	jnb	acc.6,00102$
      0050F5 90 07 11         [24] 1258 	mov	dptr,#_sine8_offset_10000_288
      0050F8 74 FF            [12] 1259 	mov	a,#0xff
      0050FA C3               [12] 1260 	clr	c
      0050FB 9F               [12] 1261 	subb	a,r7
      0050FC F0               [24] 1262 	movx	@dptr,a
      0050FD                       1263 00102$:
                                   1264 ;	keyboards/ajazz/ak820/ak820_rgb.c:126: offset &= 0x3f;
      0050FD 90 07 11         [24] 1265 	mov	dptr,#_sine8_offset_10000_288
      005100 E0               [24] 1266 	movx	a,@dptr
      005101 53 E0 3F         [24] 1267 	anl	acc,#0x3f
      005104 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: fraction = offset & 15;
      005105 90 07 11         [24] 1270 	mov	dptr,#_sine8_offset_10000_288
      005108 E0               [24] 1271 	movx	a,@dptr
      005109 54 0F            [12] 1272 	anl	a,#0x0f
      00510B FF               [12] 1273 	mov	r7,a
      00510C 90 07 12         [24] 1274 	mov	dptr,#_sine8_fraction_10000_288
      00510F F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	keyboards/ajazz/ak820/ak820_rgb.c:128: if (theta & 0x40) ++fraction;
      005110 90 07 10         [24] 1277 	mov	dptr,#_sine8_theta_10000_287
      005113 E0               [24] 1278 	movx	a,@dptr
      005114 30 E6 06         [24] 1279 	jnb	acc.6,00104$
      005117 90 07 12         [24] 1280 	mov	dptr,#_sine8_fraction_10000_288
      00511A EF               [12] 1281 	mov	a,r7
      00511B 04               [12] 1282 	inc	a
      00511C F0               [24] 1283 	movx	@dptr,a
      00511D                       1284 00104$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: section = (offset >> 4) * 2;
      00511D 90 07 11         [24] 1286 	mov	dptr,#_sine8_offset_10000_288
      005120 E0               [24] 1287 	movx	a,@dptr
      005121 C4               [12] 1288 	swap	a
      005122 54 0F            [12] 1289 	anl	a,#0x0f
                                   1290 ;	keyboards/ajazz/ak820/ak820_rgb.c:130: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005124 25 E0            [12] 1291 	add	a,acc
      005126 FF               [12] 1292 	mov	r7,a
      005127 90 BE 9E         [24] 1293 	mov	dptr,#_sine8_coefficients_10000_288
      00512A 93               [24] 1294 	movc	a,@a+dptr
      00512B FE               [12] 1295 	mov	r6,a
      00512C 0F               [12] 1296 	inc	r7
      00512D EF               [12] 1297 	mov	a,r7
      00512E 90 BE 9E         [24] 1298 	mov	dptr,#_sine8_coefficients_10000_288
      005131 93               [24] 1299 	movc	a,@a+dptr
      005132 FF               [12] 1300 	mov	r7,a
      005133 90 07 12         [24] 1301 	mov	dptr,#_sine8_fraction_10000_288
      005136 E0               [24] 1302 	movx	a,@dptr
      005137 8F F0            [24] 1303 	mov	b,r7
      005139 A4               [48] 1304 	mul	ab
      00513A FF               [12] 1305 	mov	r7,a
      00513B E5 F0            [12] 1306 	mov	a,b
      00513D C4               [12] 1307 	swap	a
      00513E CF               [12] 1308 	xch	a,r7
      00513F C4               [12] 1309 	swap	a
      005140 54 0F            [12] 1310 	anl	a,#0x0f
      005142 6F               [12] 1311 	xrl	a,r7
      005143 CF               [12] 1312 	xch	a,r7
      005144 54 0F            [12] 1313 	anl	a,#0x0f
      005146 CF               [12] 1314 	xch	a,r7
      005147 6F               [12] 1315 	xrl	a,r7
      005148 CF               [12] 1316 	xch	a,r7
      005149 EF               [12] 1317 	mov	a,r7
      00514A 2E               [12] 1318 	add	a, r6
      00514B FF               [12] 1319 	mov	r7,a
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: return (theta & 0x80) ? 128 - value : 128 + value;
      00514C 90 07 10         [24] 1321 	mov	dptr,#_sine8_theta_10000_287
      00514F E0               [24] 1322 	movx	a,@dptr
      005150 30 E7 09         [24] 1323 	jnb	acc.7,00107$
      005153 8F 06            [24] 1324 	mov	ar6,r7
      005155 74 80            [12] 1325 	mov	a,#0x80
      005157 C3               [12] 1326 	clr	c
      005158 9E               [12] 1327 	subb	a,r6
      005159 FE               [12] 1328 	mov	r6,a
      00515A 80 04            [24] 1329 	sjmp	00108$
      00515C                       1330 00107$:
      00515C 74 80            [12] 1331 	mov	a,#0x80
      00515E 2F               [12] 1332 	add	a, r7
      00515F FE               [12] 1333 	mov	r6,a
      005160                       1334 00108$:
      005160 8E 82            [24] 1335 	mov	dpl, r6
                                   1336 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: }
      005162 22               [24] 1337 	ret
                                   1338 ;------------------------------------------------------------
                                   1339 ;Allocation info for local variables in function 'breathing_cie'
                                   1340 ;------------------------------------------------------------
                                   1341 ;value         Allocated with name '_breathing_cie_value_10000_291'
                                   1342 ;index         Allocated with name '_breathing_cie_index_10000_292'
                                   1343 ;low           Allocated with name '_breathing_cie_low_10000_292'
                                   1344 ;delta         Allocated with name '_breathing_cie_delta_10001_294'
                                   1345 ;fraction      Allocated with name '_breathing_cie_fraction_10001_294'
                                   1346 ;product       Allocated with name '_breathing_cie_product_10001_294'
                                   1347 ;------------------------------------------------------------
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:139: static uint8_t breathing_cie(uint8_t value) {
                                   1349 ;	-----------------------------------------
                                   1350 ;	 function breathing_cie
                                   1351 ;	-----------------------------------------
      005163                       1352 _breathing_cie:
      005163 E5 82            [12] 1353 	mov	a,dpl
      005165 90 07 13         [24] 1354 	mov	dptr,#_breathing_cie_value_10000_291
      005168 F0               [24] 1355 	movx	@dptr,a
                                   1356 ;	keyboards/ajazz/ak820/ak820_rgb.c:143: uint8_t index = value >> 3;
      005169 E0               [24] 1357 	movx	a,@dptr
      00516A FF               [12] 1358 	mov	r7,a
      00516B 12 57 27         [24] 1359 	lcall	_ak820_outline_0133
                                   1360 ;	keyboards/ajazz/ak820/ak820_rgb.c:144: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00516E FE               [12] 1361 	mov	r6,a
      00516F 90 C1 AA         [24] 1362 	mov	dptr,#_CIE1931_CURVE
      005172 93               [24] 1363 	movc	a,@a+dptr
      005173 FD               [12] 1364 	mov	r5,a
                                   1365 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: if (index == 31) return low;
      005174 BE 1F 03         [24] 1366 	cjne	r6,#0x1f,00102$
      005177 8D 82            [24] 1367 	mov	dpl, r5
      005179 22               [24] 1368 	ret
      00517A                       1369 00102$:
                                   1370 ;	keyboards/ajazz/ak820/ak820_rgb.c:146: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      00517A EE               [12] 1371 	mov	a,r6
      00517B 04               [12] 1372 	inc	a
      00517C 90 C1 AA         [24] 1373 	mov	dptr,#_CIE1931_CURVE
      00517F 93               [24] 1374 	movc	a,@a+dptr
      005180 C3               [12] 1375 	clr	c
      005181 9D               [12] 1376 	subb	a,r5
      005182 FE               [12] 1377 	mov	r6,a
                                   1378 ;	keyboards/ajazz/ak820/ak820_rgb.c:147: uint8_t fraction = value & 7;
      005183 74 07            [12] 1379 	mov	a,#0x07
      005185 5F               [12] 1380 	anl	a,r7
                                   1381 ;	keyboards/ajazz/ak820/ak820_rgb.c:148: uint8_t product = (uint8_t)(delta * fraction);
      005186 F5 F0            [12] 1382 	mov	b,a
      005188 EE               [12] 1383 	mov	a,r6
      005189 A4               [48] 1384 	mul	ab
                                   1385 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: return low + (product >> 3);
      00518A 12 57 27         [24] 1386 	lcall	_ak820_outline_0133
      00518D 2D               [12] 1387 	add	a, r5
                                   1388 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: }
      00518E F5 82            [12] 1389 	mov	dpl,a
      005190 22               [24] 1390 	ret
                                   1391 ;------------------------------------------------------------
                                   1392 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1393 ;------------------------------------------------------------
                                   1394 ;end           Allocated with name '_rgb_matrix_task_end_10000_296'
                                   1395 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_296'
                                   1396 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_296'
                                   1397 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_314'
                                   1398 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_314'
                                   1399 ;age           Allocated with name '_rgb_matrix_task_age_80000_314'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: void rgb_matrix_task(void) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function rgb_matrix_task
                                   1404 ;	-----------------------------------------
      005191                       1405 _rgb_matrix_task:
                                   1406 ;	keyboards/ajazz/ak820/ak820_rgb.c:158: age_reactive();
      005191 12 4E AF         [24] 1407 	lcall	_age_reactive
                                   1408 ;	keyboards/ajazz/ak820/ak820_rgb.c:159: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005194 90 06 A1         [24] 1409 	mov	dptr,#_dirty
      005197 E0               [24] 1410 	movx	a,@dptr
      005198 60 1B            [24] 1411 	jz	00102$
      00519A 90 06 A3         [24] 1412 	mov	dptr,#_changed_at
      00519D 12 43 C5         [24] 1413 	lcall	_ak820_outline_0000
      0051A0 12 43 D3         [24] 1414 	lcall	_ak820_outline_0002
      0051A3 12 48 CE         [24] 1415 	lcall	_timer_elapsed
      0051A6 12 44 1D         [24] 1416 	lcall	_ak820_outline_0027
      0051A9 C3               [12] 1417 	clr	c
      0051AA EE               [12] 1418 	mov	a,r6
      0051AB 94 E8            [12] 1419 	subb	a,#0xe8
      0051AD EF               [12] 1420 	mov	a,r7
      0051AE 94 03            [12] 1421 	subb	a,#0x03
      0051B0 40 03            [24] 1422 	jc	00102$
      0051B2 12 4F 80         [24] 1423 	lcall	_eeconfig_update_rgb_matrix
      0051B5                       1424 00102$:
                                   1425 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: if (!rendering) {
      0051B5 90 06 A2         [24] 1426 	mov	dptr,#_rendering
      0051B8 E0               [24] 1427 	movx	a,@dptr
      0051B9 60 03            [24] 1428 	jz	00254$
      0051BB 02 52 7C         [24] 1429 	ljmp	00109$
      0051BE                       1430 00254$:
                                   1431 ;	keyboards/ajazz/ak820/ak820_rgb.c:161: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0051BE 90 06 A5         [24] 1432 	mov	dptr,#_frame_at
      0051C1 12 43 C5         [24] 1433 	lcall	_ak820_outline_0000
      0051C4 12 43 D3         [24] 1434 	lcall	_ak820_outline_0002
      0051C7 12 48 CE         [24] 1435 	lcall	_timer_elapsed
      0051CA 12 44 1D         [24] 1436 	lcall	_ak820_outline_0027
      0051CD C3               [12] 1437 	clr	c
      0051CE EE               [12] 1438 	mov	a,r6
      0051CF 94 10            [12] 1439 	subb	a,#0x10
      0051D1 EF               [12] 1440 	mov	a,r7
      0051D2 94 00            [12] 1441 	subb	a,#0x00
      0051D4 50 01            [24] 1442 	jnc	00105$
      0051D6 22               [24] 1443 	ret
      0051D7                       1444 00105$:
                                   1445 ;	keyboards/ajazz/ak820/ak820_rgb.c:162: frame_at = timer_read();
      0051D7 12 48 CB         [24] 1446 	lcall	_timer_read
      0051DA 12 57 16         [24] 1447 	lcall	_ak820_outline_0119
      0051DD 90 06 A5         [24] 1448 	mov	dptr,#_frame_at
      0051E0 12 57 1C         [24] 1449 	lcall	_ak820_outline_0128
                                   1450 ;	keyboards/ajazz/ak820/ak820_rgb.c:163: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0051E3 90 06 9C         [24] 1451 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0051E6 E0               [24] 1452 	movx	a,@dptr
      0051E7 FF               [12] 1453 	mov	r7,a
      0051E8 7E 00            [12] 1454 	mov	r6,#0x00
      0051EA 74 20            [12] 1455 	mov	a,#0x20
      0051EC 2F               [12] 1456 	add	a, r7
      0051ED FF               [12] 1457 	mov	r7,a
      0051EE E4               [12] 1458 	clr	a
      0051EF 3E               [12] 1459 	addc	a, r6
      0051F0 FE               [12] 1460 	mov	r6,a
      0051F1 90 06 A7         [24] 1461 	mov	dptr,#_phase
      0051F4 12 43 DF         [24] 1462 	lcall	_ak820_outline_0006
      0051F7 EF               [12] 1463 	mov	a,r7
      0051F8 2C               [12] 1464 	add	a, r4
      0051F9 FF               [12] 1465 	mov	r7,a
      0051FA EE               [12] 1466 	mov	a,r6
      0051FB 3D               [12] 1467 	addc	a, r5
      0051FC FE               [12] 1468 	mov	r6,a
      0051FD 90 06 A7         [24] 1469 	mov	dptr,#_phase
      005200 EF               [12] 1470 	mov	a,r7
      005201 F0               [24] 1471 	movx	@dptr,a
      005202 EE               [12] 1472 	mov	a,r6
      005203 A3               [24] 1473 	inc	dptr
      005204 F0               [24] 1474 	movx	@dptr,a
                                   1475 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: frame_phase = phase >> 8;
      005205 90 06 A7         [24] 1476 	mov	dptr,#_phase
      005208 E0               [24] 1477 	movx	a,@dptr
      005209 A3               [24] 1478 	inc	dptr
      00520A E0               [24] 1479 	movx	a,@dptr
      00520B FF               [12] 1480 	mov	r7,a
      00520C 90 06 AF         [24] 1481 	mov	dptr,#_frame_phase
      00520F F0               [24] 1482 	movx	@dptr,a
                                   1483 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005210 90 06 A0         [24] 1484 	mov	dptr,#_suspended
      005213 E0               [24] 1485 	movx	a,@dptr
      005214 70 05            [24] 1486 	jnz	00135$
      005216 12 56 D0         [24] 1487 	lcall	_ak820_outline_0036
      005219 70 04            [24] 1488 	jnz	00132$
      00521B                       1489 00135$:
      00521B 7E 00            [12] 1490 	mov	r6,#0x00
      00521D 80 04            [24] 1491 	sjmp	00133$
      00521F                       1492 00132$:
      00521F 12 56 BF         [24] 1493 	lcall	_ak820_outline_0013
      005222 FE               [12] 1494 	mov	r6,a
      005223                       1495 00133$:
      005223 90 06 AA         [24] 1496 	mov	dptr,#_frame_mode
      005226 EE               [12] 1497 	mov	a,r6
      005227 F0               [24] 1498 	movx	@dptr,a
                                   1499 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: frame_hue = rgb_matrix_config.hsv.h;
      005228 90 06 99         [24] 1500 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00522B E0               [24] 1501 	movx	a,@dptr
      00522C 90 06 AB         [24] 1502 	mov	dptr,#_frame_hue
      00522F F0               [24] 1503 	movx	@dptr,a
                                   1504 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: frame_sat = rgb_matrix_config.hsv.s;
      005230 90 06 9A         [24] 1505 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005233 E0               [24] 1506 	movx	a,@dptr
      005234 90 06 AC         [24] 1507 	mov	dptr,#_frame_sat
      005237 F0               [24] 1508 	movx	@dptr,a
                                   1509 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_val = rgb_matrix_config.hsv.v;
      005238 90 06 9B         [24] 1510 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00523B E0               [24] 1511 	movx	a,@dptr
      00523C FD               [12] 1512 	mov	r5,a
      00523D 90 06 AD         [24] 1513 	mov	dptr,#_frame_val
      005240 F0               [24] 1514 	movx	@dptr,a
                                   1515 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: frame_flags = rgb_matrix_config.flags;
      005241 90 06 9D         [24] 1516 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005244 E0               [24] 1517 	movx	a,@dptr
      005245 90 06 AE         [24] 1518 	mov	dptr,#_frame_flags
      005248 F0               [24] 1519 	movx	@dptr,a
                                   1520 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: if (frame_mode == RGB_MATRIX_BREATHING) {
      005249 BE 02 26         [24] 1521 	cjne	r6,#0x02,00107$
                                   1522 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00524C EF               [12] 1523 	mov	a,r7
      00524D 24 C0            [12] 1524 	add	a,#0xc0
      00524F F5 82            [12] 1525 	mov	dpl,a
      005251 C0 05            [24] 1526 	push	ar5
      005253 12 50 E5         [24] 1527 	lcall	_sine8
      005256 AF 82            [24] 1528 	mov	r7, dpl
      005258 D0 05            [24] 1529 	pop	ar5
      00525A 8D F0            [24] 1530 	mov	b,r5
      00525C EF               [12] 1531 	mov	a,r7
      00525D A4               [48] 1532 	mul	ab
      00525E AE F0            [24] 1533 	mov	r6,b
      005260 8E 05            [24] 1534 	mov	ar5,r6
      005262 90 06 AD         [24] 1535 	mov	dptr,#_frame_val
      005265 ED               [12] 1536 	mov	a,r5
      005266 F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_val = breathing_cie(frame_val);
      005267 8D 82            [24] 1539 	mov	dpl, r5
      005269 12 51 63         [24] 1540 	lcall	_breathing_cie
      00526C E5 82            [12] 1541 	mov	a, dpl
      00526E 90 06 AD         [24] 1542 	mov	dptr,#_frame_val
      005271 F0               [24] 1543 	movx	@dptr,a
      005272                       1544 00107$:
                                   1545 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: led_index = 0;
      005272 90 06 A9         [24] 1546 	mov	dptr,#_led_index
      005275 E4               [12] 1547 	clr	a
      005276 F0               [24] 1548 	movx	@dptr,a
                                   1549 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: rendering = true;
      005277 90 06 A2         [24] 1550 	mov	dptr,#_rendering
      00527A 04               [12] 1551 	inc	a
      00527B F0               [24] 1552 	movx	@dptr,a
      00527C                       1553 00109$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: end = led_index + 8;
      00527C 12 57 22         [24] 1555 	lcall	_ak820_outline_0130
      00527F 24 08            [12] 1556 	add	a,#0x08
      005281 FF               [12] 1557 	mov	r7,a
      005282 90 07 14         [24] 1558 	mov	dptr,#_rgb_matrix_task_end_10000_296
      005285 F0               [24] 1559 	movx	@dptr,a
                                   1560 ;	keyboards/ajazz/ak820/ak820_rgb.c:180: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005286 EF               [12] 1561 	mov	a,r7
      005287 24 AD            [12] 1562 	add	a,#0xff - 0x52
      005289 50 06            [24] 1563 	jnc	00125$
                                   1564 ;	free result
      00528B 90 07 14         [24] 1565 	mov	dptr,#_rgb_matrix_task_end_10000_296
      00528E 74 52            [12] 1566 	mov	a,#0x52
      005290 F0               [24] 1567 	movx	@dptr,a
                                   1568 ;	keyboards/ajazz/ak820/ak820_rgb.c:181: while (led_index < end) {
      005291                       1569 00125$:
      005291 12 57 22         [24] 1570 	lcall	_ak820_outline_0130
      005294 FF               [12] 1571 	mov	r7,a
      005295 90 07 14         [24] 1572 	mov	dptr,#_rgb_matrix_task_end_10000_296
      005298 E0               [24] 1573 	movx	a,@dptr
      005299 FE               [12] 1574 	mov	r6,a
      00529A C3               [12] 1575 	clr	c
      00529B EF               [12] 1576 	mov	a,r7
      00529C 9E               [12] 1577 	subb	a,r6
      00529D 40 03            [24] 1578 	jc	00261$
      00529F 02 54 15         [24] 1579 	ljmp	00127$
      0052A2                       1580 00261$:
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0052A2 12 57 04         [24] 1582 	lcall	_ak820_outline_0088
      0052A5 E0               [24] 1583 	movx	a,@dptr
      0052A6 60 07            [24] 1584 	jz	00121$
      0052A8 90 06 AE         [24] 1585 	mov	dptr,#_frame_flags
      0052AB E0               [24] 1586 	movx	a,@dptr
      0052AC 20 E2 1C         [24] 1587 	jb	acc.2,00122$
      0052AF                       1588 00121$:
                                   1589 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rgb_matrix_set_color(led_index, 0, 0, 0);
      0052AF 12 57 22         [24] 1590 	lcall	_ak820_outline_0130
      0052B2 FC               [12] 1591 	mov	r4,a
      0052B3 7D 00            [12] 1592 	mov	r5,#0x00
      0052B5 90 07 08         [24] 1593 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0052B8 E4               [12] 1594 	clr	a
      0052B9 F0               [24] 1595 	movx	@dptr,a
      0052BA 90 07 09         [24] 1596 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0052BD F0               [24] 1597 	movx	@dptr,a
      0052BE 90 07 0A         [24] 1598 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0052C1 F0               [24] 1599 	movx	@dptr,a
      0052C2 12 43 EF         [24] 1600 	lcall	_ak820_outline_0011
      0052C5 12 50 5A         [24] 1601 	lcall	_rgb_matrix_set_color
      0052C8 02 54 0C         [24] 1602 	ljmp	00123$
      0052CB                       1603 00122$:
                                   1604 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0052CB BE 05 2A         [24] 1605 	cjne	r6,#0x05,00119$
                                   1606 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: hsv = g_direct_mode_colors[led_index];
      0052CE EF               [12] 1607 	mov	a,r7
      0052CF 75 F0 03         [24] 1608 	mov	b,#0x03
      0052D2 A4               [48] 1609 	mul	ab
      0052D3 24 9F            [12] 1610 	add	a, #_g_direct_mode_colors
      0052D5 FD               [12] 1611 	mov	r5,a
      0052D6 74 0C            [12] 1612 	mov	a,#(_g_direct_mode_colors >> 8)
      0052D8 35 F0            [12] 1613 	addc	a, b
      0052DA FE               [12] 1614 	mov	r6,a
      0052DB 90 0D B3         [24] 1615 	mov	dptr,#___memcpy_PARM_2
      0052DE ED               [12] 1616 	mov	a,r5
      0052DF F0               [24] 1617 	movx	@dptr,a
      0052E0 EE               [12] 1618 	mov	a,r6
      0052E1 A3               [24] 1619 	inc	dptr
      0052E2 12 4E 60         [24] 1620 	lcall	_ak820_outline_0003
      0052E5 90 0D B6         [24] 1621 	mov	dptr,#___memcpy_PARM_3
      0052E8 74 03            [12] 1622 	mov	a,#0x03
      0052EA 12 4E 60         [24] 1623 	lcall	_ak820_outline_0003
      0052ED 90 07 15         [24] 1624 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      0052F0 F5 F0            [12] 1625 	mov	b,a
      0052F2 12 BD 3B         [24] 1626 	lcall	___memcpy
      0052F5 02 53 A7         [24] 1627 	ljmp	00120$
      0052F8                       1628 00119$:
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: hsv.h = frame_hue;
      0052F8 90 06 AB         [24] 1630 	mov	dptr,#_frame_hue
      0052FB E0               [24] 1631 	movx	a,@dptr
      0052FC 90 07 15         [24] 1632 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      0052FF F0               [24] 1633 	movx	@dptr,a
                                   1634 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: hsv.s = frame_sat;
      005300 90 06 AC         [24] 1635 	mov	dptr,#_frame_sat
      005303 E0               [24] 1636 	movx	a,@dptr
      005304 90 07 16         [24] 1637 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0001)
      005307 F0               [24] 1638 	movx	@dptr,a
                                   1639 ;	keyboards/ajazz/ak820/ak820_rgb.c:190: hsv.v = frame_val;
      005308 90 06 AD         [24] 1640 	mov	dptr,#_frame_val
      00530B E0               [24] 1641 	movx	a,@dptr
      00530C 90 07 17         [24] 1642 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0002)
      00530F F0               [24] 1643 	movx	@dptr,a
                                   1644 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005310 12 57 04         [24] 1645 	lcall	_ak820_outline_0088
      005313 BE 03 0E         [24] 1646 	cjne	r6,#0x03,00113$
      005316 90 07 15         [24] 1647 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      005319 E0               [24] 1648 	movx	a,@dptr
      00531A FE               [12] 1649 	mov	r6,a
      00531B 90 06 AF         [24] 1650 	mov	dptr,#_frame_phase
      00531E E0               [24] 1651 	movx	a,@dptr
      00531F 2E               [12] 1652 	add	a, r6
      005320 90 07 15         [24] 1653 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      005323 F0               [24] 1654 	movx	@dptr,a
      005324                       1655 00113$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005324 12 57 04         [24] 1657 	lcall	_ak820_outline_0088
      005327 BE 04 23         [24] 1658 	cjne	r6,#0x04,00115$
      00532A 90 07 15         [24] 1659 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      00532D E0               [24] 1660 	movx	a,@dptr
      00532E FE               [12] 1661 	mov	r6,a
      00532F 12 57 22         [24] 1662 	lcall	_ak820_outline_0130
      005332 75 F0 02         [24] 1663 	mov	b,#0x02
      005335 A4               [48] 1664 	mul	ab
      005336 24 06            [12] 1665 	add	a, #_ak820_led_points
      005338 F5 82            [12] 1666 	mov	dpl,a
      00533A 74 C1            [12] 1667 	mov	a,#(_ak820_led_points >> 8)
      00533C 12 57 0F         [24] 1668 	lcall	_ak820_outline_0111
      00533F FD               [12] 1669 	mov	r5,a
      005340 90 06 AF         [24] 1670 	mov	dptr,#_frame_phase
      005343 E0               [24] 1671 	movx	a,@dptr
      005344 FC               [12] 1672 	mov	r4,a
      005345 ED               [12] 1673 	mov	a,r5
      005346 C3               [12] 1674 	clr	c
      005347 9C               [12] 1675 	subb	a,r4
      005348 2E               [12] 1676 	add	a, r6
      005349 90 07 15         [24] 1677 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      00534C F0               [24] 1678 	movx	@dptr,a
      00534D                       1679 00115$:
                                   1680 ;	keyboards/ajazz/ak820/ak820_rgb.c:193: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00534D 12 57 04         [24] 1681 	lcall	_ak820_outline_0088
      005350 BE 06 54         [24] 1682 	cjne	r6,#0x06,00120$
                                   1683 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005353 12 57 2C         [24] 1684 	lcall	_ak820_outline_0137
      005356 FE               [12] 1685 	mov	r6,a
      005357 74 07            [12] 1686 	mov	a,#0x07
      005359 C3               [12] 1687 	clr	c
      00535A 9E               [12] 1688 	subb	a,r6
      00535B FE               [12] 1689 	mov	r6,a
                                   1690 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: uint8_t duration = 1 << shift;
      00535C 8E F0            [24] 1691 	mov	b,r6
      00535E 05 F0            [12] 1692 	inc	b
      005360 74 01            [12] 1693 	mov	a,#0x01
      005362 80 02            [24] 1694 	sjmp	00273$
      005364                       1695 00272$:
      005364 25 E0            [12] 1696 	add	a,acc
      005366                       1697 00273$:
      005366 D5 F0 FB         [24] 1698 	djnz	b,00272$
      005369 FD               [12] 1699 	mov	r5,a
                                   1700 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: uint8_t age = reactive_age[led_index];
      00536A 12 57 22         [24] 1701 	lcall	_ak820_outline_0130
      00536D 24 B0            [12] 1702 	add	a, #_reactive_age
      00536F F5 82            [12] 1703 	mov	dpl,a
      005371 E4               [12] 1704 	clr	a
      005372 34 06            [12] 1705 	addc	a, #(_reactive_age >> 8)
      005374 F5 83            [12] 1706 	mov	dph,a
      005376 E0               [24] 1707 	movx	a,@dptr
                                   1708 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005377 FC               [12] 1709 	mov	r4,a
      005378 C3               [12] 1710 	clr	c
      005379 9D               [12] 1711 	subb	a,r5
      00537A 40 07            [24] 1712 	jc	00137$
      00537C 90 06 AD         [24] 1713 	mov	dptr,#_frame_val
      00537F E0               [24] 1714 	movx	a,@dptr
      005380 FB               [12] 1715 	mov	r3,a
      005381 80 1F            [24] 1716 	sjmp	00138$
      005383                       1717 00137$:
      005383 90 06 AD         [24] 1718 	mov	dptr,#_frame_val
      005386 E0               [24] 1719 	movx	a,@dptr
      005387 F5 F0            [12] 1720 	mov	b, a
      005389 EC               [12] 1721 	mov	a,r4
      00538A A4               [48] 1722 	mul	ab
      00538B FC               [12] 1723 	mov	r4,a
      00538C AA F0            [24] 1724 	mov	r2,b
      00538E 8E F0            [24] 1725 	mov	b,r6
      005390 05 F0            [12] 1726 	inc	b
      005392 AB 04            [24] 1727 	mov	r3,ar4
      005394 AD 02            [24] 1728 	mov	r5,ar2
      005396 80 07            [24] 1729 	sjmp	00276$
      005398                       1730 00275$:
      005398 C3               [12] 1731 	clr	c
      005399 ED               [12] 1732 	mov	a,r5
      00539A 13               [12] 1733 	rrc	a
      00539B FD               [12] 1734 	mov	r5,a
      00539C EB               [12] 1735 	mov	a,r3
      00539D 13               [12] 1736 	rrc	a
      00539E FB               [12] 1737 	mov	r3,a
      00539F                       1738 00276$:
      00539F D5 F0 F6         [24] 1739 	djnz	b,00275$
      0053A2                       1740 00138$:
      0053A2 90 07 17         [24] 1741 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0002)
      0053A5 EB               [12] 1742 	mov	a,r3
      0053A6 F0               [24] 1743 	movx	@dptr,a
      0053A7                       1744 00120$:
                                   1745 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0053A7 12 57 04         [24] 1746 	lcall	_ak820_outline_0088
      0053AA BE 02 03         [24] 1747 	cjne	r6,#0x02,00277$
      0053AD D3               [12] 1748 	setb	c
      0053AE 80 01            [24] 1749 	sjmp	00278$
      0053B0                       1750 00277$:
      0053B0 C3               [12] 1751 	clr	c
      0053B1                       1752 00278$:
      0053B1 B3               [12] 1753 	cpl	c
      0053B2 92 0D            [24] 1754 	mov	_rgb_matrix_task_sloc0_1_0,c
      0053B4 90 0D B3         [24] 1755 	mov	dptr,#___memcpy_PARM_2
      0053B7 74 15            [12] 1756 	mov	a,#_rgb_matrix_task_hsv_10000_296
      0053B9 F0               [24] 1757 	movx	@dptr,a
      0053BA 74 07            [12] 1758 	mov	a,#(_rgb_matrix_task_hsv_10000_296 >> 8)
      0053BC A3               [24] 1759 	inc	dptr
      0053BD 12 4E 60         [24] 1760 	lcall	_ak820_outline_0003
      0053C0 90 0D B6         [24] 1761 	mov	dptr,#___memcpy_PARM_3
      0053C3 74 03            [12] 1762 	mov	a,#0x03
      0053C5 12 4E 60         [24] 1763 	lcall	_ak820_outline_0003
      0053C8 90 0A B3         [24] 1764 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0053CB F5 F0            [12] 1765 	mov	b,a
      0053CD 12 BD 3B         [24] 1766 	lcall	___memcpy
      0053D0 90 0A B6         [24] 1767 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0053D3 74 18            [12] 1768 	mov	a,#_rgb_matrix_task_rgb_10000_296
      0053D5 F0               [24] 1769 	movx	@dptr,a
      0053D6 74 07            [12] 1770 	mov	a,#(_rgb_matrix_task_rgb_10000_296 >> 8)
      0053D8 A3               [24] 1771 	inc	dptr
      0053D9 F0               [24] 1772 	movx	@dptr,a
      0053DA A2 0D            [12] 1773 	mov	c,_rgb_matrix_task_sloc0_1_0
      0053DC 12 44 91         [24] 1774 	lcall	_ak820_outline_0146
      0053DF 12 81 E4         [24] 1775 	lcall	_hsv_to_rgb_into
                                   1776 ;	keyboards/ajazz/ak820/ak820_rgb.c:208: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0053E2 12 57 22         [24] 1777 	lcall	_ak820_outline_0130
      0053E5 FD               [12] 1778 	mov	r5,a
      0053E6 7E 00            [12] 1779 	mov	r6,#0x00
      0053E8 90 07 19         [24] 1780 	mov	dptr,#(_rgb_matrix_task_rgb_10000_296 + 0x0001)
      0053EB E0               [24] 1781 	movx	a,@dptr
      0053EC FC               [12] 1782 	mov	r4,a
      0053ED 90 07 18         [24] 1783 	mov	dptr,#_rgb_matrix_task_rgb_10000_296
      0053F0 E0               [24] 1784 	movx	a,@dptr
      0053F1 FB               [12] 1785 	mov	r3,a
      0053F2 90 07 1A         [24] 1786 	mov	dptr,#(_rgb_matrix_task_rgb_10000_296 + 0x0002)
      0053F5 E0               [24] 1787 	movx	a,@dptr
      0053F6 FA               [12] 1788 	mov	r2,a
      0053F7 90 07 08         [24] 1789 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0053FA EC               [12] 1790 	mov	a,r4
      0053FB F0               [24] 1791 	movx	@dptr,a
      0053FC 90 07 09         [24] 1792 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0053FF EB               [12] 1793 	mov	a,r3
      005400 F0               [24] 1794 	movx	@dptr,a
      005401 90 07 0A         [24] 1795 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005404 EA               [12] 1796 	mov	a,r2
      005405 F0               [24] 1797 	movx	@dptr,a
      005406 12 43 F4         [24] 1798 	lcall	_ak820_outline_0012
      005409 12 50 5A         [24] 1799 	lcall	_rgb_matrix_set_color
      00540C                       1800 00123$:
                                   1801 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: ++led_index;
      00540C 12 57 22         [24] 1802 	lcall	_ak820_outline_0130
      00540F 24 01            [12] 1803 	add	a, #0x01
      005411 F0               [24] 1804 	movx	@dptr,a
      005412 02 52 91         [24] 1805 	ljmp	00125$
      005415                       1806 00127$:
                                   1807 ;	keyboards/ajazz/ak820/ak820_rgb.c:212: if (led_index == RGB_MATRIX_LED_COUNT) {
      005415 BF 52 19         [24] 1808 	cjne	r7,#0x52,00130$
                                   1809 ;	keyboards/ajazz/ak820/ak820_rgb.c:213: rgb_matrix_driver.flush();
      005418 90 BE 9C         [24] 1810 	mov	dptr,#(_rgb_matrix_driver + 0x0006)
      00541B 12 56 C8         [24] 1811 	lcall	_ak820_outline_0020
      00541E C0 07            [24] 1812 	push	ar7
      005420 C0 06            [24] 1813 	push	ar6
      005422 12 43 D3         [24] 1814 	lcall	_ak820_outline_0002
      005425 12 30 75         [24] 1815 	lcall	__sdcc_call_dptr
      005428 D0 06            [24] 1816 	pop	ar6
      00542A D0 07            [24] 1817 	pop	ar7
                                   1818 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rendering = false;
      00542C 90 06 A2         [24] 1819 	mov	dptr,#_rendering
      00542F E4               [12] 1820 	clr	a
      005430 F0               [24] 1821 	movx	@dptr,a
      005431                       1822 00130$:
                                   1823 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: }
      005431 22               [24] 1824 	ret
                                   1825 ;------------------------------------------------------------
                                   1826 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1827 ;------------------------------------------------------------
                                   1828 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1829 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1830 ;row           Allocated with name '_process_rgb_matrix_row_10000_317'
                                   1831 ;i             Allocated with name '_process_rgb_matrix_i_10000_318'
                                   1832 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_318'
                                   1833 ;------------------------------------------------------------
                                   1834 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1835 ;	-----------------------------------------
                                   1836 ;	 function process_rgb_matrix
                                   1837 ;	-----------------------------------------
      005432                       1838 _process_rgb_matrix:
      005432 E5 82            [12] 1839 	mov	a,dpl
      005434 90 07 1D         [24] 1840 	mov	dptr,#_process_rgb_matrix_row_10000_317
      005437 F0               [24] 1841 	movx	@dptr,a
                                   1842 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005438 90 07 1C         [24] 1843 	mov	dptr,#_process_rgb_matrix_PARM_3
      00543B E0               [24] 1844 	movx	a,@dptr
      00543C 60 26            [24] 1845 	jz	00101$
      00543E 90 06 A0         [24] 1846 	mov	dptr,#_suspended
      005441 E0               [24] 1847 	movx	a,@dptr
      005442 70 20            [24] 1848 	jnz	00101$
      005444 12 56 D0         [24] 1849 	lcall	_ak820_outline_0036
      005447 60 1B            [24] 1850 	jz	00101$
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:221: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005449 12 56 BF         [24] 1852 	lcall	_ak820_outline_0013
      00544C FF               [12] 1853 	mov	r7,a
      00544D BF 06 14         [24] 1854 	cjne	r7,#0x06,00101$
      005450 90 07 1D         [24] 1855 	mov	dptr,#_process_rgb_matrix_row_10000_317
      005453 E0               [24] 1856 	movx	a,@dptr
      005454 FF               [12] 1857 	mov	r7,a
      005455 BF 10 00         [24] 1858 	cjne	r7,#0x10,00169$
      005458                       1859 00169$:
      005458 50 0A            [24] 1860 	jnc	00101$
      00545A 90 07 1B         [24] 1861 	mov	dptr,#_process_rgb_matrix_PARM_2
      00545D E0               [24] 1862 	movx	a,@dptr
      00545E FE               [12] 1863 	mov	r6,a
      00545F BE 08 00         [24] 1864 	cjne	r6,#0x08,00171$
      005462                       1865 00171$:
      005462 40 01            [24] 1866 	jc	00102$
      005464                       1867 00101$:
      005464 22               [24] 1868 	ret
      005465                       1869 00102$:
                                   1870 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: age_reactive();
      005465 C0 07            [24] 1871 	push	ar7
      005467 C0 06            [24] 1872 	push	ar6
      005469 12 4E AF         [24] 1873 	lcall	_age_reactive
      00546C D0 06            [24] 1874 	pop	ar6
      00546E D0 07            [24] 1875 	pop	ar7
                                   1876 ;	keyboards/ajazz/ak820/ak820_rgb.c:223: slot = row * MATRIX_COLS + col;
      005470 EF               [12] 1877 	mov	a,r7
      005471 C4               [12] 1878 	swap	a
      005472 03               [12] 1879 	rr	a
      005473 54 F8            [12] 1880 	anl	a,#0xf8
      005475 2E               [12] 1881 	add	a,r6
      005476 FF               [12] 1882 	mov	r7,a
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005477 7E 00            [12] 1884 	mov	r6,#0x00
      005479                       1885 00111$:
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:225: if (ak820_rgb_slots[i] == slot) {
      005479 EE               [12] 1887 	mov	a,r6
      00547A 90 BE 44         [24] 1888 	mov	dptr,#_ak820_rgb_slots
      00547D 93               [24] 1889 	movc	a,@a+dptr
      00547E B5 07 29         [24] 1890 	cjne	a,ar7,00112$
                                   1891 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005481 EE               [12] 1892 	mov	a,r6
      005482 24 B0            [12] 1893 	add	a, #_reactive_age
      005484 FC               [12] 1894 	mov	r4,a
      005485 E4               [12] 1895 	clr	a
      005486 34 06            [12] 1896 	addc	a, #(_reactive_age >> 8)
      005488 FD               [12] 1897 	mov	r5,a
      005489 12 57 2C         [24] 1898 	lcall	_ak820_outline_0137
      00548C F5 F0            [12] 1899 	mov	b, a
      00548E 05 F0            [12] 1900 	inc	b
      005490 7B 80            [12] 1901 	mov	r3,#0x80
      005492 E4               [12] 1902 	clr	a
      005493 FA               [12] 1903 	mov	r2,a
      005494 33               [12] 1904 	rlc	a
      005495 92 D2            [24] 1905 	mov	ov,c
      005497 80 08            [24] 1906 	sjmp	00176$
      005499                       1907 00175$:
      005499 A2 D2            [12] 1908 	mov	c,ov
      00549B EA               [12] 1909 	mov	a,r2
      00549C 13               [12] 1910 	rrc	a
      00549D FA               [12] 1911 	mov	r2,a
      00549E EB               [12] 1912 	mov	a,r3
      00549F 13               [12] 1913 	rrc	a
      0054A0 FB               [12] 1914 	mov	r3,a
      0054A1                       1915 00176$:
      0054A1 D5 F0 F5         [24] 1916 	djnz	b,00175$
      0054A4 12 43 EF         [24] 1917 	lcall	_ak820_outline_0011
      0054A7 EB               [12] 1918 	mov	a,r3
      0054A8 F0               [24] 1919 	movx	@dptr,a
                                   1920 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: return;
      0054A9 22               [24] 1921 	ret
      0054AA                       1922 00112$:
                                   1923 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054AA 0E               [12] 1924 	inc	r6
      0054AB BE 52 00         [24] 1925 	cjne	r6,#0x52,00177$
      0054AE                       1926 00177$:
      0054AE 40 C9            [24] 1927 	jc	00111$
                                   1928 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: }
      0054B0 22               [24] 1929 	ret
                                   1930 ;------------------------------------------------------------
                                   1931 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1932 ;------------------------------------------------------------
                                   1933 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_324'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: void rgb_matrix_set_suspend_state(bool state) {
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function rgb_matrix_set_suspend_state
                                   1938 ;	-----------------------------------------
      0054B1                       1939 _rgb_matrix_set_suspend_state:
      0054B1 E5 82            [12] 1940 	mov	a,dpl
      0054B3 90 07 1E         [24] 1941 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_324
      0054B6 F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: suspended = state;
      0054B7 E0               [24] 1944 	movx	a,@dptr
      0054B8 FF               [12] 1945 	mov	r7,a
      0054B9 90 06 A0         [24] 1946 	mov	dptr,#_suspended
      0054BC 12 56 F6         [24] 1947 	lcall	_ak820_outline_0059
                                   1948 ;	keyboards/ajazz/ak820/ak820_rgb.c:234: rendering = false;
                                   1949 ;	keyboards/ajazz/ak820/ak820_rgb.c:235: clear_reactive();
      0054BF C0 07            [24] 1950 	push	ar7
      0054C1 12 4E 92         [24] 1951 	lcall	_clear_reactive
      0054C4 D0 07            [24] 1952 	pop	ar7
                                   1953 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: if (state) {
      0054C6 EF               [12] 1954 	mov	a,r7
      0054C7 60 23            [24] 1955 	jz	00103$
                                   1956 ;	keyboards/ajazz/ak820/ak820_rgb.c:237: rgb_matrix_set_color_all(0, 0, 0);
      0054C9 90 07 0D         [24] 1957 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0054CC E4               [12] 1958 	clr	a
      0054CD F0               [24] 1959 	movx	@dptr,a
      0054CE 90 07 0E         [24] 1960 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0054D1 F0               [24] 1961 	movx	@dptr,a
      0054D2 75 82 00         [24] 1962 	mov	dpl, #0x00
      0054D5 12 50 AF         [24] 1963 	lcall	_rgb_matrix_set_color_all
                                   1964 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: rgb_matrix_driver.flush();
      0054D8 90 BE 9C         [24] 1965 	mov	dptr,#(_rgb_matrix_driver + 0x0006)
      0054DB 12 56 C8         [24] 1966 	lcall	_ak820_outline_0020
      0054DE C0 07            [24] 1967 	push	ar7
      0054E0 C0 06            [24] 1968 	push	ar6
      0054E2 12 43 D3         [24] 1969 	lcall	_ak820_outline_0002
      0054E5 12 30 75         [24] 1970 	lcall	__sdcc_call_dptr
      0054E8 D0 06            [24] 1971 	pop	ar6
      0054EA D0 07            [24] 1972 	pop	ar7
      0054EC                       1973 00103$:
                                   1974 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: }
      0054EC 22               [24] 1975 	ret
                                   1976 ;------------------------------------------------------------
                                   1977 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1978 ;------------------------------------------------------------
                                   1979 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1980 ;	-----------------------------------------
                                   1981 ;	 function rgb_matrix_is_enabled
                                   1982 ;	-----------------------------------------
      0054ED                       1983 _rgb_matrix_is_enabled:
      0054ED 12 56 D0         [24] 1984 	lcall	_ak820_outline_0036
      0054F0 F5 82            [12] 1985 	mov	dpl,a
      0054F2 22               [24] 1986 	ret
                                   1987 ;------------------------------------------------------------
                                   1988 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1989 ;------------------------------------------------------------
                                   1990 ;	keyboards/ajazz/ak820/ak820_rgb.c:244: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1991 ;	-----------------------------------------
                                   1992 ;	 function rgb_matrix_get_mode
                                   1993 ;	-----------------------------------------
      0054F3                       1994 _rgb_matrix_get_mode:
      0054F3 12 56 BF         [24] 1995 	lcall	_ak820_outline_0013
      0054F6 F5 82            [12] 1996 	mov	dpl,a
      0054F8 22               [24] 1997 	ret
                                   1998 ;------------------------------------------------------------
                                   1999 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   2000 ;------------------------------------------------------------
                                   2001 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   2002 ;	-----------------------------------------
                                   2003 ;	 function rgb_matrix_get_hue
                                   2004 ;	-----------------------------------------
      0054F9                       2005 _rgb_matrix_get_hue:
      0054F9 90 06 99         [24] 2006 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0054FC E0               [24] 2007 	movx	a,@dptr
      0054FD F5 82            [12] 2008 	mov	dpl,a
      0054FF 22               [24] 2009 	ret
                                   2010 ;------------------------------------------------------------
                                   2011 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   2012 ;------------------------------------------------------------
                                   2013 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   2014 ;	-----------------------------------------
                                   2015 ;	 function rgb_matrix_get_sat
                                   2016 ;	-----------------------------------------
      005500                       2017 _rgb_matrix_get_sat:
      005500 90 06 9A         [24] 2018 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005503 E0               [24] 2019 	movx	a,@dptr
      005504 F5 82            [12] 2020 	mov	dpl,a
      005506 22               [24] 2021 	ret
                                   2022 ;------------------------------------------------------------
                                   2023 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:248: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_get_val
                                   2028 ;	-----------------------------------------
      005507                       2029 _rgb_matrix_get_val:
      005507 90 06 9B         [24] 2030 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00550A E0               [24] 2031 	movx	a,@dptr
      00550B F5 82            [12] 2032 	mov	dpl,a
      00550D 22               [24] 2033 	ret
                                   2034 ;------------------------------------------------------------
                                   2035 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   2036 ;------------------------------------------------------------
                                   2037 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   2038 ;	-----------------------------------------
                                   2039 ;	 function rgb_matrix_get_speed
                                   2040 ;	-----------------------------------------
      00550E                       2041 _rgb_matrix_get_speed:
      00550E 90 06 9C         [24] 2042 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005511 E0               [24] 2043 	movx	a,@dptr
      005512 F5 82            [12] 2044 	mov	dpl,a
      005514 22               [24] 2045 	ret
                                   2046 ;------------------------------------------------------------
                                   2047 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function rgb_matrix_toggle_noeeprom
                                   2052 ;	-----------------------------------------
      005515                       2053 _rgb_matrix_toggle_noeeprom:
      005515 12 56 D0         [24] 2054 	lcall	_ak820_outline_0036
      005518 FF               [12] 2055 	mov	r7,a
      005519 63 07 01         [24] 2056 	xrl	ar7,#0x01
      00551C 90 06 98         [24] 2057 	mov	dptr,#_rgb_matrix_config
      00551F EF               [12] 2058 	mov	a,r7
      005520 54 03            [12] 2059 	anl	a,#0x03
      005522 F5 F0            [12] 2060 	mov	b,a
      005524 E0               [24] 2061 	movx	a,@dptr
      005525 54 FC            [12] 2062 	anl	a,#0xfc
      005527 45 F0            [12] 2063 	orl	a,b
      005529 12 56 F6         [24] 2064 	lcall	_ak820_outline_0059
      00552C 02 4E 92         [24] 2065 	ljmp	_clear_reactive
                                   2066 ;------------------------------------------------------------
                                   2067 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   2068 ;------------------------------------------------------------
                                   2069 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2070 ;	-----------------------------------------
                                   2071 ;	 function rgb_matrix_enable_noeeprom
                                   2072 ;	-----------------------------------------
      00552F                       2073 _rgb_matrix_enable_noeeprom:
      00552F 12 56 D0         [24] 2074 	lcall	_ak820_outline_0036
      005532 70 03            [24] 2075 	jnz	00102$
      005534 12 4E 92         [24] 2076 	lcall	_clear_reactive
      005537                       2077 00102$:
      005537 12 56 FD         [24] 2078 	lcall	_ak820_outline_0078
      00553A 44 01            [12] 2079 	orl	a,#0x01
      00553C 12 56 F6         [24] 2080 	lcall	_ak820_outline_0059
      00553F 22               [24] 2081 	ret
                                   2082 ;------------------------------------------------------------
                                   2083 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2084 ;------------------------------------------------------------
                                   2085 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2086 ;	-----------------------------------------
                                   2087 ;	 function rgb_matrix_disable_noeeprom
                                   2088 ;	-----------------------------------------
      005540                       2089 _rgb_matrix_disable_noeeprom:
      005540 12 56 FD         [24] 2090 	lcall	_ak820_outline_0078
      005543 12 56 F6         [24] 2091 	lcall	_ak820_outline_0059
      005546 02 4E 92         [24] 2092 	ljmp	_clear_reactive
                                   2093 ;------------------------------------------------------------
                                   2094 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2095 ;------------------------------------------------------------
                                   2096 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_353'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_mode_noeeprom
                                   2101 ;	-----------------------------------------
      005549                       2102 _rgb_matrix_mode_noeeprom:
      005549 E5 82            [12] 2103 	mov	a,dpl
      00554B 90 07 1F         [24] 2104 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_353
      00554E F0               [24] 2105 	movx	@dptr,a
                                   2106 ;	keyboards/ajazz/ak820/ak820_rgb.c:256: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      00554F E0               [24] 2107 	movx	a,@dptr
      005550 FF               [12] 2108 	mov	r7,a
      005551 60 05            [24] 2109 	jz	00101$
      005553 BF 07 00         [24] 2110 	cjne	r7,#0x07,00123$
      005556                       2111 00123$:
      005556 40 01            [24] 2112 	jc	00102$
      005558                       2113 00101$:
      005558 22               [24] 2114 	ret
      005559                       2115 00102$:
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:257: if (mode != rgb_matrix_config.mode) clear_reactive();
      005559 12 56 BF         [24] 2117 	lcall	_ak820_outline_0013
      00555C FE               [12] 2118 	mov	r6,a
      00555D EF               [12] 2119 	mov	a,r7
      00555E B5 06 02         [24] 2120 	cjne	a,ar6,00125$
      005561 80 03            [24] 2121 	sjmp	00105$
      005563                       2122 00125$:
      005563 12 4E 92         [24] 2123 	lcall	_clear_reactive
      005566                       2124 00105$:
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: rgb_matrix_config.mode = mode;
      005566 90 07 1F         [24] 2126 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_353
      005569 E0               [24] 2127 	movx	a,@dptr
      00556A 90 06 98         [24] 2128 	mov	dptr,#_rgb_matrix_config
      00556D 25 E0            [12] 2129 	add	a,acc
      00556F 25 E0            [12] 2130 	add	a,acc
      005571 54 FC            [12] 2131 	anl	a,#0xfc
      005573 F5 F0            [12] 2132 	mov	b,a
      005575 E0               [24] 2133 	movx	a,@dptr
      005576 54 03            [12] 2134 	anl	a,#0x03
      005578 45 F0            [12] 2135 	orl	a,b
      00557A 12 56 F6         [24] 2136 	lcall	_ak820_outline_0059
                                   2137 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: rendering = false;
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: }
      00557D 22               [24] 2139 	ret
                                   2140 ;------------------------------------------------------------
                                   2141 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2142 ;------------------------------------------------------------
                                   2143 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: void rgb_matrix_step_noeeprom(void) {
                                   2144 ;	-----------------------------------------
                                   2145 ;	 function rgb_matrix_step_noeeprom
                                   2146 ;	-----------------------------------------
      00557E                       2147 _rgb_matrix_step_noeeprom:
                                   2148 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      00557E 12 56 BF         [24] 2149 	lcall	_ak820_outline_0013
      005581 FF               [12] 2150 	mov	r7,a
      005582 0F               [12] 2151 	inc	r7
      005583 BF 07 00         [24] 2152 	cjne	r7,#0x07,00112$
      005586                       2153 00112$:
      005586 40 04            [24] 2154 	jc	00103$
      005588 7F 01            [12] 2155 	mov	r7,#0x01
      00558A 80 07            [24] 2156 	sjmp	00104$
      00558C                       2157 00103$:
      00558C 12 56 BF         [24] 2158 	lcall	_ak820_outline_0013
      00558F FE               [12] 2159 	mov	r6,a
      005590 0E               [12] 2160 	inc	r6
      005591 8E 07            [24] 2161 	mov	ar7,r6
      005593                       2162 00104$:
      005593 8F 82            [24] 2163 	mov	dpl, r7
                                   2164 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: }
      005595 02 55 49         [24] 2165 	ljmp	_rgb_matrix_mode_noeeprom
                                   2166 ;------------------------------------------------------------
                                   2167 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2168 ;------------------------------------------------------------
                                   2169 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2170 ;	-----------------------------------------
                                   2171 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2172 ;	-----------------------------------------
      005598                       2173 _rgb_matrix_step_reverse_noeeprom:
                                   2174 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005598 12 56 BF         [24] 2175 	lcall	_ak820_outline_0013
      00559B 24 FE            [12] 2176 	add	a,#0xff - 0x01
      00559D 40 04            [24] 2177 	jc	00103$
                                   2178 ;	free result
      00559F 7F 06            [12] 2179 	mov	r7,#0x06
      0055A1 80 05            [24] 2180 	sjmp	00104$
      0055A3                       2181 00103$:
      0055A3 12 56 BF         [24] 2182 	lcall	_ak820_outline_0013
      0055A6 14               [12] 2183 	dec	a
      0055A7 FF               [12] 2184 	mov	r7,a
      0055A8                       2185 00104$:
      0055A8 8F 82            [24] 2186 	mov	dpl, r7
                                   2187 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: }
      0055AA 02 55 49         [24] 2188 	ljmp	_rgb_matrix_mode_noeeprom
                                   2189 ;------------------------------------------------------------
                                   2190 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2191 ;------------------------------------------------------------
                                   2192 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2193 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2194 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_361'
                                   2195 ;------------------------------------------------------------
                                   2196 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2197 ;	-----------------------------------------
                                   2198 ;	 function rgb_matrix_sethsv_noeeprom
                                   2199 ;	-----------------------------------------
      0055AD                       2200 _rgb_matrix_sethsv_noeeprom:
      0055AD 12 43 EA         [24] 2201 	lcall	_ak820_outline_0010
      0055B0 90 07 22         [24] 2202 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_361
      0055B3 12 43 E5         [24] 2203 	lcall	_ak820_outline_0007
                                   2204 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: rgb_matrix_config.hsv.h = hue;
      0055B6 90 07 22         [24] 2205 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_361
      0055B9 E0               [24] 2206 	movx	a,@dptr
      0055BA 90 06 99         [24] 2207 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055BD F0               [24] 2208 	movx	@dptr,a
                                   2209 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: rgb_matrix_config.hsv.s = sat;
      0055BE 90 07 20         [24] 2210 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      0055C1 E0               [24] 2211 	movx	a,@dptr
      0055C2 FF               [12] 2212 	mov	r7,a
      0055C3 90 06 9A         [24] 2213 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055C6 F0               [24] 2214 	movx	@dptr,a
                                   2215 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0055C7 90 07 21         [24] 2216 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      0055CA E0               [24] 2217 	movx	a,@dptr
      0055CB FF               [12] 2218 	mov  r7,a
      0055CC 24 5F            [12] 2219 	add	a,#0xff - 0xa0
      0055CE 50 04            [24] 2220 	jnc	00103$
                                   2221 ;	free result
      0055D0 7E A0            [12] 2222 	mov	r6,#0xa0
      0055D2 80 02            [24] 2223 	sjmp	00104$
      0055D4                       2224 00103$:
      0055D4 8F 06            [24] 2225 	mov	ar6,r7
      0055D6                       2226 00104$:
      0055D6 90 06 9B         [24] 2227 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055D9 EE               [12] 2228 	mov	a,r6
      0055DA F0               [24] 2229 	movx	@dptr,a
                                   2230 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      0055DB 22               [24] 2231 	ret
                                   2232 ;------------------------------------------------------------
                                   2233 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2234 ;------------------------------------------------------------
                                   2235 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_363'
                                   2236 ;------------------------------------------------------------
                                   2237 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2238 ;	-----------------------------------------
                                   2239 ;	 function rgb_matrix_set_speed_noeeprom
                                   2240 ;	-----------------------------------------
      0055DC                       2241 _rgb_matrix_set_speed_noeeprom:
      0055DC E5 82            [12] 2242 	mov	a,dpl
      0055DE 90 07 24         [24] 2243 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_363
      0055E1 F0               [24] 2244 	movx	@dptr,a
      0055E2 E0               [24] 2245 	movx	a,@dptr
      0055E3 90 06 9C         [24] 2246 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0055E6 F0               [24] 2247 	movx	@dptr,a
      0055E7 22               [24] 2248 	ret
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2251 ;------------------------------------------------------------
                                   2252 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_365'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2257 ;	-----------------------------------------
      0055E8                       2258 _rgb_matrix_increase_hue_noeeprom:
      0055E8 90 06 99         [24] 2259 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055EB E0               [24] 2260 	movx	a,@dptr
      0055EC 24 08            [12] 2261 	add	a,#0x08
      0055EE 90 06 99         [24] 2262 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055F1 F0               [24] 2263 	movx	@dptr,a
      0055F2 22               [24] 2264 	ret
                                   2265 ;------------------------------------------------------------
                                   2266 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2267 ;------------------------------------------------------------
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2269 ;	-----------------------------------------
                                   2270 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2271 ;	-----------------------------------------
      0055F3                       2272 _rgb_matrix_decrease_hue_noeeprom:
      0055F3 90 06 99         [24] 2273 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055F6 E0               [24] 2274 	movx	a,@dptr
      0055F7 24 F8            [12] 2275 	add	a,#0xf8
      0055F9 90 06 99         [24] 2276 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055FC F0               [24] 2277 	movx	@dptr,a
      0055FD 22               [24] 2278 	ret
                                   2279 ;------------------------------------------------------------
                                   2280 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2281 ;------------------------------------------------------------
                                   2282 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2283 ;	-----------------------------------------
                                   2284 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2285 ;	-----------------------------------------
      0055FE                       2286 _rgb_matrix_increase_sat_noeeprom:
      0055FE 90 06 9A         [24] 2287 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005601 12 56 E0         [24] 2288 	lcall	_ak820_outline_0047
      005604 12 4F 2B         [24] 2289 	lcall	_add_sat
      005607 AF 82            [24] 2290 	mov	r7, dpl
      005609 90 06 9A         [24] 2291 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00560C EF               [12] 2292 	mov	a,r7
      00560D F0               [24] 2293 	movx	@dptr,a
      00560E 22               [24] 2294 	ret
                                   2295 ;------------------------------------------------------------
                                   2296 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2301 ;	-----------------------------------------
      00560F                       2302 _rgb_matrix_decrease_sat_noeeprom:
      00560F 90 06 9A         [24] 2303 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005612 12 56 EB         [24] 2304 	lcall	_ak820_outline_0048
      005615 12 4F 50         [24] 2305 	lcall	_sub_sat
      005618 AF 82            [24] 2306 	mov	r7, dpl
      00561A 90 06 9A         [24] 2307 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00561D EF               [12] 2308 	mov	a,r7
      00561E F0               [24] 2309 	movx	@dptr,a
      00561F 22               [24] 2310 	ret
                                   2311 ;------------------------------------------------------------
                                   2312 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2313 ;------------------------------------------------------------
                                   2314 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_376'
                                   2315 ;------------------------------------------------------------
                                   2316 ;	keyboards/ajazz/ak820/ak820_rgb.c:279: void rgb_matrix_increase_val_noeeprom(void) {
                                   2317 ;	-----------------------------------------
                                   2318 ;	 function rgb_matrix_increase_val_noeeprom
                                   2319 ;	-----------------------------------------
      005620                       2320 _rgb_matrix_increase_val_noeeprom:
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:280: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005620 90 06 9B         [24] 2322 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005623 12 56 E0         [24] 2323 	lcall	_ak820_outline_0047
      005626 12 4F 2B         [24] 2324 	lcall	_add_sat
                                   2325 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005629 E5 82            [12] 2326 	mov	a,dpl
      00562B FF               [12] 2327 	mov	r7,a
      00562C 24 5F            [12] 2328 	add	a,#0xff - 0xa0
      00562E 50 04            [24] 2329 	jnc	00103$
                                   2330 ;	free result
      005630 7E A0            [12] 2331 	mov	r6,#0xa0
      005632 80 02            [24] 2332 	sjmp	00104$
      005634                       2333 00103$:
      005634 8F 06            [24] 2334 	mov	ar6,r7
      005636                       2335 00104$:
      005636 90 06 9B         [24] 2336 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005639 EE               [12] 2337 	mov	a,r6
      00563A F0               [24] 2338 	movx	@dptr,a
                                   2339 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: }
      00563B 22               [24] 2340 	ret
                                   2341 ;------------------------------------------------------------
                                   2342 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2343 ;------------------------------------------------------------
                                   2344 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2345 ;	-----------------------------------------
                                   2346 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2347 ;	-----------------------------------------
      00563C                       2348 _rgb_matrix_decrease_val_noeeprom:
      00563C 90 06 9B         [24] 2349 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00563F 12 56 EB         [24] 2350 	lcall	_ak820_outline_0048
      005642 12 4F 50         [24] 2351 	lcall	_sub_sat
      005645 AF 82            [24] 2352 	mov	r7, dpl
      005647 90 06 9B         [24] 2353 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00564A EF               [12] 2354 	mov	a,r7
      00564B F0               [24] 2355 	movx	@dptr,a
      00564C 22               [24] 2356 	ret
                                   2357 ;------------------------------------------------------------
                                   2358 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2359 ;------------------------------------------------------------
                                   2360 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2361 ;	-----------------------------------------
                                   2362 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2363 ;	-----------------------------------------
      00564D                       2364 _rgb_matrix_increase_speed_noeeprom:
      00564D 90 06 9C         [24] 2365 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005650 12 56 E0         [24] 2366 	lcall	_ak820_outline_0047
      005653 12 4F 2B         [24] 2367 	lcall	_add_sat
      005656 AF 82            [24] 2368 	mov	r7, dpl
      005658 90 06 9C         [24] 2369 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00565B EF               [12] 2370 	mov	a,r7
      00565C F0               [24] 2371 	movx	@dptr,a
      00565D 22               [24] 2372 	ret
                                   2373 ;------------------------------------------------------------
                                   2374 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2375 ;------------------------------------------------------------
                                   2376 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2377 ;	-----------------------------------------
                                   2378 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2379 ;	-----------------------------------------
      00565E                       2380 _rgb_matrix_decrease_speed_noeeprom:
      00565E 90 06 9C         [24] 2381 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005661 12 56 EB         [24] 2382 	lcall	_ak820_outline_0048
      005664 12 4F 50         [24] 2383 	lcall	_sub_sat
      005667 AF 82            [24] 2384 	mov	r7, dpl
      005669 90 06 9C         [24] 2385 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00566C EF               [12] 2386 	mov	a,r7
      00566D F0               [24] 2387 	movx	@dptr,a
      00566E 22               [24] 2388 	ret
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_toggle
                                   2395 ;	-----------------------------------------
      00566F                       2396 _rgb_matrix_toggle:
      00566F 12 55 15         [24] 2397 	lcall	_rgb_matrix_toggle_noeeprom
      005672 02 4F 6D         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_step
                                   2405 ;	-----------------------------------------
      005675                       2406 _rgb_matrix_step:
      005675 12 55 7E         [24] 2407 	lcall	_rgb_matrix_step_noeeprom
      005678 02 4F 6D         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:292: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_step_reverse
                                   2415 ;	-----------------------------------------
      00567B                       2416 _rgb_matrix_step_reverse:
      00567B 12 55 98         [24] 2417 	lcall	_rgb_matrix_step_reverse_noeeprom
      00567E 02 4F 6D         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_increase_hue
                                   2425 ;	-----------------------------------------
      005681                       2426 _rgb_matrix_increase_hue:
      005681 12 55 E8         [24] 2427 	lcall	_rgb_matrix_increase_hue_noeeprom
      005684 02 4F 6D         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2431 ;------------------------------------------------------------
                                   2432 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2433 ;	-----------------------------------------
                                   2434 ;	 function rgb_matrix_decrease_hue
                                   2435 ;	-----------------------------------------
      005687                       2436 _rgb_matrix_decrease_hue:
      005687 12 55 F3         [24] 2437 	lcall	_rgb_matrix_decrease_hue_noeeprom
      00568A 02 4F 6D         [24] 2438 	ljmp	_mark_dirty
                                   2439 ;------------------------------------------------------------
                                   2440 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2441 ;------------------------------------------------------------
                                   2442 ;	keyboards/ajazz/ak820/ak820_rgb.c:295: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2443 ;	-----------------------------------------
                                   2444 ;	 function rgb_matrix_increase_sat
                                   2445 ;	-----------------------------------------
      00568D                       2446 _rgb_matrix_increase_sat:
      00568D 12 55 FE         [24] 2447 	lcall	_rgb_matrix_increase_sat_noeeprom
      005690 02 4F 6D         [24] 2448 	ljmp	_mark_dirty
                                   2449 ;------------------------------------------------------------
                                   2450 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2451 ;------------------------------------------------------------
                                   2452 ;	keyboards/ajazz/ak820/ak820_rgb.c:296: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2453 ;	-----------------------------------------
                                   2454 ;	 function rgb_matrix_decrease_sat
                                   2455 ;	-----------------------------------------
      005693                       2456 _rgb_matrix_decrease_sat:
      005693 12 56 0F         [24] 2457 	lcall	_rgb_matrix_decrease_sat_noeeprom
      005696 02 4F 6D         [24] 2458 	ljmp	_mark_dirty
                                   2459 ;------------------------------------------------------------
                                   2460 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2461 ;------------------------------------------------------------
                                   2462 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2463 ;	-----------------------------------------
                                   2464 ;	 function rgb_matrix_increase_val
                                   2465 ;	-----------------------------------------
      005699                       2466 _rgb_matrix_increase_val:
      005699 12 56 20         [24] 2467 	lcall	_rgb_matrix_increase_val_noeeprom
      00569C 02 4F 6D         [24] 2468 	ljmp	_mark_dirty
                                   2469 ;------------------------------------------------------------
                                   2470 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2471 ;------------------------------------------------------------
                                   2472 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2473 ;	-----------------------------------------
                                   2474 ;	 function rgb_matrix_decrease_val
                                   2475 ;	-----------------------------------------
      00569F                       2476 _rgb_matrix_decrease_val:
      00569F 12 56 3C         [24] 2477 	lcall	_rgb_matrix_decrease_val_noeeprom
      0056A2 02 4F 6D         [24] 2478 	ljmp	_mark_dirty
                                   2479 ;------------------------------------------------------------
                                   2480 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2481 ;------------------------------------------------------------
                                   2482 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2483 ;	-----------------------------------------
                                   2484 ;	 function rgb_matrix_increase_speed
                                   2485 ;	-----------------------------------------
      0056A5                       2486 _rgb_matrix_increase_speed:
      0056A5 12 56 4D         [24] 2487 	lcall	_rgb_matrix_increase_speed_noeeprom
      0056A8 02 4F 6D         [24] 2488 	ljmp	_mark_dirty
                                   2489 ;------------------------------------------------------------
                                   2490 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2491 ;------------------------------------------------------------
                                   2492 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2493 ;	-----------------------------------------
                                   2494 ;	 function rgb_matrix_decrease_speed
                                   2495 ;	-----------------------------------------
      0056AB                       2496 _rgb_matrix_decrease_speed:
      0056AB 12 56 5E         [24] 2497 	lcall	_rgb_matrix_decrease_speed_noeeprom
      0056AE 02 4F 6D         [24] 2498 	ljmp	_mark_dirty
                                   2499 ;------------------------------------------------------------
                                   2500 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2501 ;------------------------------------------------------------
                                   2502 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_409'
                                   2503 ;------------------------------------------------------------
                                   2504 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2505 ;	-----------------------------------------
                                   2506 ;	 function rgb_matrix_mode
                                   2507 ;	-----------------------------------------
      0056B1                       2508 _rgb_matrix_mode:
      0056B1 E5 82            [12] 2509 	mov	a,dpl
      0056B3 90 07 25         [24] 2510 	mov	dptr,#_rgb_matrix_mode_mode_10000_409
      0056B6 12 57 0A         [24] 2511 	lcall	_ak820_outline_0101
      0056B9 12 55 49         [24] 2512 	lcall	_rgb_matrix_mode_noeeprom
      0056BC 02 4F 6D         [24] 2513 	ljmp	_mark_dirty
                                   2514 ;------------------------------------------------------------
                                   2515 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2516 ;------------------------------------------------------------
                                   2517 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2518 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2519 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_411'
                                   2520 ;------------------------------------------------------------
                                   2521 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2522 ;	-----------------------------------------
                                   2523 	.area CSEG    (CODE)
                                   2524 	.area CONST   (CODE)
                                   2525 	.area CONST   (CODE)
      00BE9E                       2526 _sine8_coefficients_10000_288:
      00BE9E 00                    2527 	.db #0x00	; 0
      00BE9F 31                    2528 	.db #0x31	; 49	'1'
      00BEA0 31                    2529 	.db #0x31	; 49	'1'
      00BEA1 29                    2530 	.db #0x29	; 41
      00BEA2 5A                    2531 	.db #0x5a	; 90	'Z'
      00BEA3 1B                    2532 	.db #0x1b	; 27
      00BEA4 75                    2533 	.db #0x75	; 117	'u'
      00BEA5 0A                    2534 	.db #0x0a	; 10
                                   2535 	.area CSEG    (CODE)
                                   2536 	.area XINIT   (CODE)
                                   2537 	.area CABS    (ABS,CODE)
                                   2538 
                                   2539 ; Experimental exact instruction outlining.
                                   2540 	.globl _ak820_outline_0000
                                   2541 	.globl _ak820_outline_0002
                                   2542 	.globl _ak820_outline_0003
                                   2543 	.globl _ak820_outline_0006
                                   2544 	.globl _ak820_outline_0007
                                   2545 	.globl _ak820_outline_0010
                                   2546 	.globl _ak820_outline_0011
                                   2547 	.globl _ak820_outline_0012
                                   2548 	.globl _ak820_outline_0013
                                   2549 	.globl _ak820_outline_0020
                                   2550 	.globl _ak820_outline_0024
                                   2551 	.globl _ak820_outline_0027
                                   2552 	.globl _ak820_outline_0036
                                   2553 	.globl _ak820_outline_0045
                                   2554 	.globl _ak820_outline_0047
                                   2555 	.globl _ak820_outline_0048
                                   2556 	.globl _ak820_outline_0059
                                   2557 	.globl _ak820_outline_0078
                                   2558 	.globl _ak820_outline_0088
                                   2559 	.globl _ak820_outline_0101
                                   2560 	.globl _ak820_outline_0111
                                   2561 	.globl _ak820_outline_0119
                                   2562 	.globl _ak820_outline_0128
                                   2563 	.globl _ak820_outline_0130
                                   2564 	.globl _ak820_outline_0133
                                   2565 	.globl _ak820_outline_0137
                                   2566 	.globl _ak820_outline_0142
                                   2567 	.globl _ak820_outline_0146
                                   2568 
                                   2569 	.area CSEG (CODE)
                                   2570 ; function ak820_outline_0013
      0056BF                       2571 _ak820_outline_0013:
      0056BF 90 06 98         [24] 2572 	mov	dptr,#_rgb_matrix_config
      0056C2 E0               [24] 2573 	movx	a,@dptr
      0056C3 03               [12] 2574 	rr	a
      0056C4 03               [12] 2575 	rr	a
      0056C5 54 3F            [12] 2576 	anl	a,#0x3f
      0056C7 22               [24] 2577 	ret
                                   2578 
                                   2579 	.area CSEG (CODE)
                                   2580 ; function ak820_outline_0020
      0056C8                       2581 _ak820_outline_0020:
      0056C8 E4               [12] 2582 	clr	a
      0056C9 93               [24] 2583 	movc	a,@a+dptr
      0056CA FE               [12] 2584 	mov	r6,a
      0056CB A3               [24] 2585 	inc	dptr
      0056CC E4               [12] 2586 	clr	a
      0056CD 93               [24] 2587 	movc	a,@a+dptr
      0056CE FF               [12] 2588 	mov	r7,a
      0056CF 22               [24] 2589 	ret
                                   2590 
                                   2591 	.area CSEG (CODE)
                                   2592 ; function ak820_outline_0036
      0056D0                       2593 _ak820_outline_0036:
      0056D0 90 06 98         [24] 2594 	mov	dptr,#_rgb_matrix_config
      0056D3 E0               [24] 2595 	movx	a,@dptr
      0056D4 54 03            [12] 2596 	anl	a,#0x03
      0056D6 22               [24] 2597 	ret
                                   2598 
                                   2599 	.area CSEG (CODE)
                                   2600 ; function ak820_outline_0045
      0056D7                       2601 _ak820_outline_0045:
      0056D7 8E 04            [24] 2602 	mov	ar4,r6
      0056D9 8F 05            [24] 2603 	mov	ar5,r7
      0056DB C3               [12] 2604 	clr	c
      0056DC 74 FF            [12] 2605 	mov	a,#0xff
      0056DE 9C               [12] 2606 	subb	a,r4
      0056DF 22               [24] 2607 	ret
                                   2608 
                                   2609 	.area CSEG (CODE)
                                   2610 ; function ak820_outline_0047
      0056E0                       2611 _ak820_outline_0047:
      0056E0 E0               [24] 2612 	movx	a,@dptr
      0056E1 FF               [12] 2613 	mov	r7,a
      0056E2 90 07 04         [24] 2614 	mov	dptr,#_add_sat_PARM_2
      0056E5 74 10            [12] 2615 	mov	a,#0x10
      0056E7 F0               [24] 2616 	movx	@dptr,a
      0056E8 8F 82            [24] 2617 	mov	dpl,r7
      0056EA 22               [24] 2618 	ret
                                   2619 
                                   2620 	.area CSEG (CODE)
                                   2621 ; function ak820_outline_0048
      0056EB                       2622 _ak820_outline_0048:
      0056EB E0               [24] 2623 	movx	a,@dptr
      0056EC FF               [12] 2624 	mov	r7,a
      0056ED 90 07 06         [24] 2625 	mov	dptr,#_sub_sat_PARM_2
      0056F0 74 10            [12] 2626 	mov	a,#0x10
      0056F2 F0               [24] 2627 	movx	@dptr,a
      0056F3 8F 82            [24] 2628 	mov	dpl,r7
      0056F5 22               [24] 2629 	ret
                                   2630 
                                   2631 	.area CSEG (CODE)
                                   2632 ; function ak820_outline_0059
      0056F6                       2633 _ak820_outline_0059:
      0056F6 F0               [24] 2634 	movx	@dptr,a
      0056F7 90 06 A2         [24] 2635 	mov	dptr,#_rendering
      0056FA E4               [12] 2636 	clr	a
      0056FB F0               [24] 2637 	movx	@dptr,a
      0056FC 22               [24] 2638 	ret
                                   2639 
                                   2640 	.area CSEG (CODE)
                                   2641 ; function ak820_outline_0078
      0056FD                       2642 _ak820_outline_0078:
      0056FD 90 06 98         [24] 2643 	mov	dptr,#_rgb_matrix_config
      005700 E0               [24] 2644 	movx	a,@dptr
      005701 54 FC            [12] 2645 	anl	a,#0xfc
      005703 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0088
      005704                       2650 _ak820_outline_0088:
      005704 90 06 AA         [24] 2651 	mov	dptr,#_frame_mode
      005707 E0               [24] 2652 	movx	a,@dptr
      005708 FE               [12] 2653 	mov	r6,a
      005709 22               [24] 2654 	ret
                                   2655 
                                   2656 	.area CSEG (CODE)
                                   2657 ; function ak820_outline_0101
      00570A                       2658 _ak820_outline_0101:
      00570A F0               [24] 2659 	movx	@dptr,a
      00570B E0               [24] 2660 	movx	a,@dptr
      00570C F5 82            [12] 2661 	mov	dpl,a
      00570E 22               [24] 2662 	ret
                                   2663 
                                   2664 	.area CSEG (CODE)
                                   2665 ; function ak820_outline_0111
      00570F                       2666 _ak820_outline_0111:
      00570F 35 F0            [12] 2667 	addc	a,b
      005711 F5 83            [12] 2668 	mov	dph,a
      005713 E4               [12] 2669 	clr	a
      005714 93               [24] 2670 	movc	a,@a+dptr
      005715 22               [24] 2671 	ret
                                   2672 
                                   2673 	.area CSEG (CODE)
                                   2674 ; function ak820_outline_0119
      005716                       2675 _ak820_outline_0119:
      005716 E5 82            [12] 2676 	mov	a,dpl
      005718 85 83 F0         [24] 2677 	mov	b,dph
      00571B 22               [24] 2678 	ret
                                   2679 
                                   2680 	.area CSEG (CODE)
                                   2681 ; function ak820_outline_0128
      00571C                       2682 _ak820_outline_0128:
      00571C F0               [24] 2683 	movx	@dptr,a
      00571D E5 F0            [12] 2684 	mov	a,b
      00571F A3               [24] 2685 	inc	dptr
      005720 F0               [24] 2686 	movx	@dptr,a
      005721 22               [24] 2687 	ret
                                   2688 
                                   2689 	.area CSEG (CODE)
                                   2690 ; function ak820_outline_0130
      005722                       2691 _ak820_outline_0130:
      005722 90 06 A9         [24] 2692 	mov	dptr,#_led_index
      005725 E0               [24] 2693 	movx	a,@dptr
      005726 22               [24] 2694 	ret
                                   2695 
                                   2696 	.area CSEG (CODE)
                                   2697 ; function ak820_outline_0133
      005727                       2698 _ak820_outline_0133:
      005727 C4               [12] 2699 	swap	a
      005728 23               [12] 2700 	rl	a
      005729 54 1F            [12] 2701 	anl	a,#0x1f
      00572B 22               [24] 2702 	ret
                                   2703 
                                   2704 	.area CSEG (CODE)
                                   2705 ; function ak820_outline_0137
      00572C                       2706 _ak820_outline_0137:
      00572C 90 06 9C         [24] 2707 	mov	dptr,#(_rgb_matrix_config+0x0004)
      00572F E0               [24] 2708 	movx	a,@dptr
      005730 23               [12] 2709 	rl	a
      005731 23               [12] 2710 	rl	a
      005732 54 03            [12] 2711 	anl	a,#0x03
      005734 22               [24] 2712 	ret
                                   2713 
                                   2714 	.area CSEG (CODE)
                                   2715 ; function ak820_outline_0142
      005735                       2716 _ak820_outline_0142:
      005735 90 0D BB         [24] 2717 	mov	dptr,#_memset_PARM_2
      005738 E4               [12] 2718 	clr	a
      005739 F0               [24] 2719 	movx	@dptr,a
      00573A 90 0D BC         [24] 2720 	mov	dptr,#_memset_PARM_3
      00573D 22               [24] 2721 	ret
