                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_board
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_driver
                                     12 	.globl _ak820_rgb_slots
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_set_slot_rgb_PARM_4
                                    257 	.globl _ak820_set_slot_rgb_PARM_3
                                    258 	.globl _ak820_set_slot_rgb_PARM_2
                                    259 	.globl _ak820_scan_sample
                                    260 	.globl _ak820_scan_ready
                                    261 	.globl _ak820_scan_rows
                                    262 	.globl _ak820_led_dma
                                    263 	.globl _ak820_clock_init
                                    264 	.globl _ak820_board_init
                                    265 	.globl _ak820_led_irq
                                    266 	.globl _ak820_matrix_snapshot
                                    267 	.globl _ak820_set_slot_rgb
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 	.area	OSEG    (OVR,DATA)
      00005A                        534 _ak820_set_slot_rgb_sloc0_1_0:
      00005A                        535 	.ds 1
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
                           000200   557 _ak820_led_dma	=	0x0200
      000400                        558 _ak820_scan_rows::
      000400                        559 	.ds 16
      000410                        560 _ak820_scan_ready::
      000410                        561 	.ds 1
      000411                        562 _ak820_scan_sample::
      000411                        563 	.ds 1
      000412                        564 _ak820_matrix_snapshot_rows_10000_60:
      000412                        565 	.ds 3
      000415                        566 _ak820_matrix_snapshot_changed_10000_61:
      000415                        567 	.ds 1
      000416                        568 _ak820_set_slot_rgb_PARM_2:
      000416                        569 	.ds 1
      000417                        570 _ak820_set_slot_rgb_PARM_3:
      000417                        571 	.ds 1
      000418                        572 _ak820_set_slot_rgb_PARM_4:
      000418                        573 	.ds 1
      000419                        574 _ak820_set_slot_rgb_slot_10000_70:
      000419                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; absolute external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XABS    (ABS,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; initialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XISEG   (XDATA)
                                    584 	.area HOME    (CODE)
                                    585 	.area GSINIT0 (CODE)
                                    586 	.area GSINIT1 (CODE)
                                    587 	.area GSINIT2 (CODE)
                                    588 	.area GSINIT3 (CODE)
                                    589 	.area GSINIT4 (CODE)
                                    590 	.area GSINIT5 (CODE)
                                    591 	.area GSINIT  (CODE)
                                    592 	.area GSFINAL (CODE)
                                    593 	.area CSEG    (CODE)
                                    594 ;--------------------------------------------------------
                                    595 ; global & static initialisations
                                    596 ;--------------------------------------------------------
                                    597 	.area HOME    (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 	.area GSFINAL (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 ;--------------------------------------------------------
                                    602 ; Home
                                    603 ;--------------------------------------------------------
                                    604 	.area HOME    (CODE)
                                    605 	.area HOME    (CODE)
                                    606 ;--------------------------------------------------------
                                    607 ; code
                                    608 ;--------------------------------------------------------
                                    609 	.area CSEG    (CODE)
                                    610 ;------------------------------------------------------------
                                    611 ;Allocation info for local variables in function 'ak820_clock_init'
                                    612 ;------------------------------------------------------------
                                    613 ;	keyboards/ajazz/ak820/ak820_board.c:40: void ak820_clock_init(void) __naked {
                                    614 ;	-----------------------------------------
                                    615 ;	 function ak820_clock_init
                                    616 ;	-----------------------------------------
      003164                        617 _ak820_clock_init:
                                    618 ;	naked function: no prologue.
                                    619 ;	keyboards/ajazz/ak820/ak820_board.c:55: __endasm;
      003164 75 A1 55         [24]  620 	mov 0xa1, #0x55
      003167 75 A1 AA         [24]  621 	mov 0xa1, #0xaa
      00316A 43 B9 80         [24]  622 	orl 0xb9, #0x80
      00316D 53 B9 BF         [24]  623 	anl 0xb9, #0xbf
      003170 75 A1 55         [24]  624 	mov 0xa1, #0x55
      003173 75 A1 AA         [24]  625 	mov 0xa1, #0xaa
      003176 E5 B9            [12]  626 	mov a, 0xb9
      003178 54 F8            [12]  627 	anl a, #0xf8
      00317A 44 06            [12]  628 	orl a, #0x06
      00317C F5 B9            [12]  629 	mov 0xb9, a
      00317E E4               [12]  630 	clr a
      00317F F5 A1            [12]  631 	mov 0xa1, a
      003181 22               [24]  632 	ret
                                    633 ;	keyboards/ajazz/ak820/ak820_board.c:56: }
                                    634 ;	naked function: no epilogue.
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'ak820_board_init'
                                    637 ;------------------------------------------------------------
                                    638 ;i             Allocated with name '_ak820_board_init_i_10000_53'
                                    639 ;------------------------------------------------------------
                                    640 ;	keyboards/ajazz/ak820/ak820_board.c:58: void ak820_board_init(void) {
                                    641 ;	-----------------------------------------
                                    642 ;	 function ak820_board_init
                                    643 ;	-----------------------------------------
      003182                        644 _ak820_board_init:
                           000007   645 	ar7 = 0x07
                           000006   646 	ar6 = 0x06
                           000005   647 	ar5 = 0x05
                           000004   648 	ar4 = 0x04
                           000003   649 	ar3 = 0x03
                           000002   650 	ar2 = 0x02
                           000001   651 	ar1 = 0x01
                           000000   652 	ar0 = 0x00
                                    653 ;	keyboards/ajazz/ak820/ak820_board.c:61: IE_PWM_I2C = 0;
                                    654 ;	assignBit
      003182 C2 ED            [12]  655 	clr	_IE_PWM_I2C
                                    656 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      003184 7E 00            [12]  657 	mov	r6,#0x00
      003186 7F 00            [12]  658 	mov	r7,#0x00
      003188                        659 00103$:
                                    660 ;	keyboards/ajazz/ak820/ak820_board.c:63: ak820_led_dma[i] = 0;
      003188 8E 82            [24]  661 	mov	dpl,r6
      00318A 74 02            [12]  662 	mov	a,#(_ak820_led_dma >> 8)
      00318C 2F               [12]  663 	add	a,r7
      00318D F5 83            [12]  664 	mov	dph,a
      00318F E4               [12]  665 	clr	a
      003190 F0               [24]  666 	movx	@dptr,a
                                    667 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      003191 0E               [12]  668 	inc	r6
      003192 BE 00 01         [24]  669 	cjne	r6,#0x00,00139$
      003195 0F               [12]  670 	inc	r7
      003196                        671 00139$:
      003196 8E 04            [24]  672 	mov	ar4,r6
      003198 8F 05            [24]  673 	mov	ar5,r7
      00319A 74 FE            [12]  674 	mov	a,#0x100 - 0x02
      00319C 2D               [12]  675 	add	a,r5
      00319D 50 E9            [24]  676 	jnc	00103$
                                    677 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      00319F 7E 00            [12]  678 	mov	r6,#0x00
      0031A1 7F 00            [12]  679 	mov	r7,#0x00
      0031A3                        680 00105$:
                                    681 ;	keyboards/ajazz/ak820/ak820_board.c:66: ak820_scan_rows[i] = 0;
      0031A3 EE               [12]  682 	mov	a,r6
      0031A4 24 00            [12]  683 	add	a, #_ak820_scan_rows
      0031A6 F5 82            [12]  684 	mov	dpl,a
      0031A8 EF               [12]  685 	mov	a,r7
      0031A9 34 04            [12]  686 	addc	a, #(_ak820_scan_rows >> 8)
      0031AB F5 83            [12]  687 	mov	dph,a
      0031AD E4               [12]  688 	clr	a
      0031AE F0               [24]  689 	movx	@dptr,a
                                    690 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      0031AF 0E               [12]  691 	inc	r6
      0031B0 BE 00 01         [24]  692 	cjne	r6,#0x00,00141$
      0031B3 0F               [12]  693 	inc	r7
      0031B4                        694 00141$:
      0031B4 8E 04            [24]  695 	mov	ar4,r6
      0031B6 8F 05            [24]  696 	mov	ar5,r7
      0031B8 C3               [12]  697 	clr	c
      0031B9 EC               [12]  698 	mov	a,r4
      0031BA 94 10            [12]  699 	subb	a,#0x10
      0031BC ED               [12]  700 	mov	a,r5
      0031BD 94 00            [12]  701 	subb	a,#0x00
      0031BF 40 E2            [24]  702 	jc	00105$
                                    703 ;	keyboards/ajazz/ak820/ak820_board.c:68: ak820_scan_ready  = 0;
      0031C1 90 04 10         [24]  704 	mov	dptr,#_ak820_scan_ready
      0031C4 E4               [12]  705 	clr	a
      0031C5 F0               [24]  706 	movx	@dptr,a
                                    707 ;	keyboards/ajazz/ak820/ak820_board.c:69: ak820_scan_sample = 0;
      0031C6 90 04 11         [24]  708 	mov	dptr,#_ak820_scan_sample
      0031C9 F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_board.c:72: P4 = P2 = P1 = P3 = P0 = 0xff;
      0031CA 75 80 FF         [24]  711 	mov	_P0,#0xff
      0031CD 75 B0 FF         [24]  712 	mov	_P3,#0xff
      0031D0 75 90 FF         [24]  713 	mov	_P1,#0xff
      0031D3 75 A0 FF         [24]  714 	mov	_P2,#0xff
      0031D6 75 C0 FF         [24]  715 	mov	_P4,#0xff
                                    716 ;	keyboards/ajazz/ak820/ak820_board.c:73: P1_MOD_OC = P2_MOD_OC = P4_MOD_OC = P3_MOD_OC = P0_MOD_OC = 0;
      0031D9 F5 C4            [12]  717 	mov	_P0_MOD_OC,a
      0031DB F5 96            [12]  718 	mov	_P3_MOD_OC,a
      0031DD F5 C2            [12]  719 	mov	_P4_MOD_OC,a
      0031DF F5 94            [12]  720 	mov	_P2_MOD_OC,a
      0031E1 F5 92            [12]  721 	mov	_P1_MOD_OC,a
                                    722 ;	keyboards/ajazz/ak820/ak820_board.c:75: LED_CTRL    = 0x01;
      0031E3 90 21 D1         [24]  723 	mov	dptr,#0x21d1
      0031E6 04               [12]  724 	inc	a
      0031E7 F0               [24]  725 	movx	@dptr,a
                                    726 ;	keyboards/ajazz/ak820/ak820_board.c:76: LED_CYCLE   = 0x30;
      0031E8 A3               [24]  727 	inc	dptr
      0031E9 74 30            [12]  728 	mov	a,#0x30
      0031EB F0               [24]  729 	movx	@dptr,a
                                    730 ;	keyboards/ajazz/ak820/ak820_board.c:77: LED_FRAME   = 0x50;
      0031EC A3               [24]  731 	inc	dptr
      0031ED 74 50            [12]  732 	mov	a,#0x50
      0031EF F0               [24]  733 	movx	@dptr,a
                                    734 ;	keyboards/ajazz/ak820/ak820_board.c:78: LED_DMA_H   = AK820_LED_DMA_ADDRESS >> 8;
      0031F0 75 C7 02         [24]  735 	mov	_LED_DMA_H,#0x02
                                    736 ;	keyboards/ajazz/ak820/ak820_board.c:79: LED_DMA_L   = AK820_LED_DMA_ADDRESS & 0xff;
      0031F3 75 C6 00         [24]  737 	mov	_LED_DMA_L,#0x00
                                    738 ;	keyboards/ajazz/ak820/ak820_board.c:80: LED_INT_ADJ = 0;
      0031F6 90 21 D8         [24]  739 	mov	dptr,#0x21d8
      0031F9 E4               [12]  740 	clr	a
      0031FA F0               [24]  741 	movx	@dptr,a
                                    742 ;	keyboards/ajazz/ak820/ak820_board.c:81: LED_PWM_OE  = 0xff;
      0031FB 75 A7 FF         [24]  743 	mov	_LED_PWM_OE,#0xff
                                    744 ;	keyboards/ajazz/ak820/ak820_board.c:82: LED_COMMON  = 0xff;
      0031FE 75 A6 FF         [24]  745 	mov	_LED_COMMON,#0xff
                                    746 ;	keyboards/ajazz/ak820/ak820_board.c:83: LED_CTRL    = 0xfd;
      003201 90 21 D1         [24]  747 	mov	dptr,#0x21d1
      003204 74 FD            [12]  748 	mov	a,#0xfd
      003206 F0               [24]  749 	movx	@dptr,a
                                    750 ;	keyboards/ajazz/ak820/ak820_board.c:86: P7 = 0x03;
      003207 75 F1 03         [24]  751 	mov	_P7,#0x03
                                    752 ;	keyboards/ajazz/ak820/ak820_board.c:88: LED_STATUS |= 0x40;
      00320A 43 F7 40         [24]  753 	orl	_LED_STATUS,#0x40
                                    754 ;	keyboards/ajazz/ak820/ak820_board.c:89: IE_PWM_I2C = 1;
                                    755 ;	assignBit
      00320D D2 ED            [12]  756 	setb	_IE_PWM_I2C
                                    757 ;	keyboards/ajazz/ak820/ak820_board.c:90: LED_RED_ADJ = LED_GRE_ADJ = LED_BLU_ADJ = 0;
      00320F 90 21 DB         [24]  758 	mov	dptr,#0x21db
      003212 E4               [12]  759 	clr	a
      003213 F0               [24]  760 	movx	@dptr,a
      003214 15 82            [12]  761 	dec	dpl
      003216 F0               [24]  762 	movx	@dptr,a
      003217 15 82            [12]  763 	dec	dpl
      003219 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_board.c:91: }
      00321A 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_led_irq'
                                    769 ;------------------------------------------------------------
                                    770 ;	keyboards/ajazz/ak820/ak820_board.c:101: void ak820_led_irq(void) __naked {
                                    771 ;	-----------------------------------------
                                    772 ;	 function ak820_led_irq
                                    773 ;	-----------------------------------------
      00321B                        774 _ak820_led_irq:
                                    775 ;	naked function: no prologue.
                                    776 ;	keyboards/ajazz/ak820/ak820_board.c:265: __endasm;
      00321B 05 A6            [12]  777 	inc 0xa6
      00321D E5 A6            [12]  778 	mov a, 0xa6
      00321F 54 0F            [12]  779 	anl a, #0x0f
      003221 FE               [12]  780 	mov r6, a
      003222 70 09            [24]  781 	jnz 00001$
      003224 75 A6 10         [24]  782 	mov 0xa6, #0x10
      003227 75 C7 02         [24]  783 	mov 0xc7, #0x02
      00322A 75 C6 00         [24]  784 	mov 0xc6, #0x00
      00322D                        785 00001$:
      00322D 12 32 88         [24]  786 	lcall 00010$
                                    787 ; Native D5ED..D617, only the sample XRAM address is relocated.
      003230 75 C1 FF         [24]  788 	mov 0xc1, #0xff
      003233 75 C2 FF         [24]  789 	mov 0xc2, #0xff
      003236 00               [12]  790 	nop
      003237 00               [12]  791 	nop
      003238 90 21 D1         [24]  792 	mov dptr, #0x21d1
      00323B E0               [24]  793 	movx a, @dptr
      00323C 00               [12]  794 	nop
      00323D 00               [12]  795 	nop
      00323E 00               [12]  796 	nop
      00323F 00               [12]  797 	nop
      003240 00               [12]  798 	nop
      003241 00               [12]  799 	nop
      003242 00               [12]  800 	nop
      003243 00               [12]  801 	nop
      003244 00               [12]  802 	nop
      003245 00               [12]  803 	nop
      003246 00               [12]  804 	nop
      003247 00               [12]  805 	nop
      003248 00               [12]  806 	nop
      003249 00               [12]  807 	nop
      00324A 00               [12]  808 	nop
      00324B 00               [12]  809 	nop
      00324C 00               [12]  810 	nop
      00324D 00               [12]  811 	nop
      00324E 00               [12]  812 	nop
      00324F 00               [12]  813 	nop
      003250 00               [12]  814 	nop
      003251 00               [12]  815 	nop
      003252 00               [12]  816 	nop
      003253 00               [12]  817 	nop
      003254 00               [12]  818 	nop
      003255 90 04 11         [24]  819 	mov dptr, #_ak820_scan_sample
      003258 E5 C0            [12]  820 	mov a, 0xc0
      00325A F0               [24]  821 	movx @dptr, a
      00325B E4               [12]  822 	clr a
      00325C F5 C2            [12]  823 	mov 0xc2, a
      00325E F5 C1            [12]  824 	mov 0xc1, a
      003260 75 A7 FF         [24]  825 	mov 0xa7, #0xff
      003263 75 B0 FF         [24]  826 	mov 0xb0, #0xff
      003266 75 80 FF         [24]  827 	mov 0x80, #0xff
      003269 90 04 11         [24]  828 	mov dptr, #_ak820_scan_sample
      00326C E0               [24]  829 	movx a, @dptr
      00326D F4               [12]  830 	cpl a
      00326E FD               [12]  831 	mov r5, a
      00326F 90 04 00         [24]  832 	mov dptr, #_ak820_scan_rows
      003272 E5 82            [12]  833 	mov a, dpl
      003274 2E               [12]  834 	add a, r6
      003275 F5 82            [12]  835 	mov dpl, a
      003277 E4               [12]  836 	clr a
      003278 35 83            [12]  837 	addc a, dph
      00327A F5 83            [12]  838 	mov dph, a
      00327C ED               [12]  839 	mov a, r5
      00327D F0               [24]  840 	movx @dptr, a
      00327E BE 0F 06         [24]  841 	cjne r6, #0x0f, 00002$
      003281 90 04 10         [24]  842 	mov dptr, #_ak820_scan_ready
      003284 74 01            [12]  843 	mov a, #1
      003286 F0               [24]  844 	movx @dptr, a
      003287                        845 00002$:
      003287 22               [24]  846 	ret
                                    847 ; Native E274..E29D: the32 MOVX operations feed the peripheral DMA.
      003288                        848 00010$:
      003288 D2 AE            [12]  849 	setb 0xae
      00328A D2 D0            [12]  850 	setb 0xd0
      00328C E0               [24]  851 	movx a, @dptr
      00328D E0               [24]  852 	movx a, @dptr
      00328E E0               [24]  853 	movx a, @dptr
      00328F E0               [24]  854 	movx a, @dptr
      003290 E0               [24]  855 	movx a, @dptr
      003291 E0               [24]  856 	movx a, @dptr
      003292 E0               [24]  857 	movx a, @dptr
      003293 E0               [24]  858 	movx a, @dptr
      003294 00               [12]  859 	nop
      003295 E0               [24]  860 	movx a, @dptr
      003296 E0               [24]  861 	movx a, @dptr
      003297 E0               [24]  862 	movx a, @dptr
      003298 E0               [24]  863 	movx a, @dptr
      003299 E0               [24]  864 	movx a, @dptr
      00329A E0               [24]  865 	movx a, @dptr
      00329B E0               [24]  866 	movx a, @dptr
      00329C E0               [24]  867 	movx a, @dptr
      00329D 00               [12]  868 	nop
      00329E E0               [24]  869 	movx a, @dptr
      00329F E0               [24]  870 	movx a, @dptr
      0032A0 E0               [24]  871 	movx a, @dptr
      0032A1 E0               [24]  872 	movx a, @dptr
      0032A2 E0               [24]  873 	movx a, @dptr
      0032A3 E0               [24]  874 	movx a, @dptr
      0032A4 E0               [24]  875 	movx a, @dptr
      0032A5 E0               [24]  876 	movx a, @dptr
      0032A6 00               [12]  877 	nop
      0032A7 E0               [24]  878 	movx a, @dptr
      0032A8 E0               [24]  879 	movx a, @dptr
      0032A9 E0               [24]  880 	movx a, @dptr
      0032AA E0               [24]  881 	movx a, @dptr
      0032AB E0               [24]  882 	movx a, @dptr
      0032AC E0               [24]  883 	movx a, @dptr
      0032AD E0               [24]  884 	movx a, @dptr
      0032AE E0               [24]  885 	movx a, @dptr
      0032AF C2 AE            [12]  886 	clr 0xae
                                    887 ; Native E29D..E2E0, with the jump table relocated locally.
      0032B1 E5 A6            [12]  888 	mov a, 0xa6
      0032B3 10 E4 08         [24]  889 	jbc 0xe4, 00011$
      0032B6 54 01            [12]  890 	anl a, #1
      0032B8 04               [12]  891 	inc a
      0032B9 F4               [12]  892 	cpl a
      0032BA 14               [12]  893 	dec a
      0032BB 52 F1            [12]  894 	anl 0xf1, a
      0032BD 22               [24]  895 	ret
      0032BE                        896 00011$:
      0032BE FF               [12]  897 	mov r7, a
      0032BF 2F               [12]  898 	add a, r7
      0032C0 2F               [12]  899 	add a, r7
      0032C1 90 32 C5         [24]  900 	mov dptr, #00012$
      0032C4 73               [24]  901 	jmp @a+dptr
      0032C5                        902 00012$:
      0032C5 C2 80            [12]  903 	clr 0x80
      0032C7 22               [24]  904 	ret
      0032C8 C2 81            [12]  905 	clr 0x81
      0032CA 22               [24]  906 	ret
      0032CB C2 82            [12]  907 	clr 0x82
      0032CD 22               [24]  908 	ret
      0032CE C2 83            [12]  909 	clr 0x83
      0032D0 22               [24]  910 	ret
      0032D1 C2 84            [12]  911 	clr 0x84
      0032D3 22               [24]  912 	ret
      0032D4 C2 85            [12]  913 	clr 0x85
      0032D6 22               [24]  914 	ret
      0032D7 C2 86            [12]  915 	clr 0x86
      0032D9 22               [24]  916 	ret
      0032DA C2 87            [12]  917 	clr 0x87
      0032DC 22               [24]  918 	ret
      0032DD C2 B0            [12]  919 	clr 0xb0
      0032DF 22               [24]  920 	ret
      0032E0 C2 B1            [12]  921 	clr 0xb1
      0032E2 22               [24]  922 	ret
      0032E3 C2 B2            [12]  923 	clr 0xb2
      0032E5 22               [24]  924 	ret
      0032E6 C2 B3            [12]  925 	clr 0xb3
      0032E8 22               [24]  926 	ret
      0032E9 C2 B4            [12]  927 	clr 0xb4
      0032EB 22               [24]  928 	ret
      0032EC C2 B5            [12]  929 	clr 0xb5
      0032EE 22               [24]  930 	ret
      0032EF C2 B6            [12]  931 	clr 0xb6
      0032F1 22               [24]  932 	ret
      0032F2 C2 B7            [12]  933 	clr 0xb7
      0032F4 22               [24]  934 	ret
                                    935 ;	keyboards/ajazz/ak820/ak820_board.c:266: }
                                    936 ;	naked function: no epilogue.
                                    937 ;------------------------------------------------------------
                                    938 ;Allocation info for local variables in function 'ak820_matrix_snapshot'
                                    939 ;------------------------------------------------------------
                                    940 ;rows          Allocated with name '_ak820_matrix_snapshot_rows_10000_60'
                                    941 ;row           Allocated with name '_ak820_matrix_snapshot_row_10000_61'
                                    942 ;value         Allocated with name '_ak820_matrix_snapshot_value_10000_61'
                                    943 ;irq_enabled   Allocated with name '_ak820_matrix_snapshot_irq_enabled_10000_61'
                                    944 ;changed       Allocated with name '_ak820_matrix_snapshot_changed_10000_61'
                                    945 ;------------------------------------------------------------
                                    946 ;	keyboards/ajazz/ak820/ak820_board.c:268: bool ak820_matrix_snapshot(uint8_t *rows) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function ak820_matrix_snapshot
                                    949 ;	-----------------------------------------
      0032F5                        950 _ak820_matrix_snapshot:
      0032F5 AF F0            [24]  951 	mov	r7,b
      0032F7 AE 83            [24]  952 	mov	r6,dph
      0032F9 E5 82            [12]  953 	mov	a,dpl
      0032FB 90 04 12         [24]  954 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_60
      0032FE F0               [24]  955 	movx	@dptr,a
      0032FF EE               [12]  956 	mov	a,r6
      003300 A3               [24]  957 	inc	dptr
      003301 F0               [24]  958 	movx	@dptr,a
      003302 EF               [12]  959 	mov	a,r7
      003303 A3               [24]  960 	inc	dptr
      003304 F0               [24]  961 	movx	@dptr,a
                                    962 ;	keyboards/ajazz/ak820/ak820_board.c:272: bool changed = false;
      003305 90 04 15         [24]  963 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      003308 E4               [12]  964 	clr	a
      003309 F0               [24]  965 	movx	@dptr,a
                                    966 ;	keyboards/ajazz/ak820/ak820_board.c:274: if (!ak820_scan_ready) {
      00330A 90 04 10         [24]  967 	mov	dptr,#_ak820_scan_ready
      00330D E0               [24]  968 	movx	a,@dptr
                                    969 ;	keyboards/ajazz/ak820/ak820_board.c:275: return false;
      00330E 70 03            [24]  970 	jnz	00102$
      003310 F5 82            [12]  971 	mov	dpl,a
      003312 22               [24]  972 	ret
      003313                        973 00102$:
                                    974 ;	keyboards/ajazz/ak820/ak820_board.c:279: irq_enabled = IE_EX & 0x20;
      003313 E5 E8            [12]  975 	mov	a,_IE_EX
      003315 54 20            [12]  976 	anl	a,#0x20
      003317 FF               [12]  977 	mov	r7,a
                                    978 ;	keyboards/ajazz/ak820/ak820_board.c:280: IE_PWM_I2C = 0;
                                    979 ;	assignBit
      003318 C2 ED            [12]  980 	clr	_IE_PWM_I2C
                                    981 ;	keyboards/ajazz/ak820/ak820_board.c:281: ak820_scan_ready = 0;
      00331A 90 04 10         [24]  982 	mov	dptr,#_ak820_scan_ready
      00331D E4               [12]  983 	clr	a
      00331E F0               [24]  984 	movx	@dptr,a
                                    985 ;	keyboards/ajazz/ak820/ak820_board.c:282: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      00331F FE               [12]  986 	mov	r6,a
      003320                        987 00108$:
                                    988 ;	keyboards/ajazz/ak820/ak820_board.c:283: value = ak820_scan_rows[row];
      003320 EE               [12]  989 	mov	a,r6
      003321 24 00            [12]  990 	add	a, #_ak820_scan_rows
      003323 F5 82            [12]  991 	mov	dpl,a
      003325 E4               [12]  992 	clr	a
      003326 34 04            [12]  993 	addc	a, #(_ak820_scan_rows >> 8)
      003328 F5 83            [12]  994 	mov	dph,a
      00332A E0               [24]  995 	movx	a,@dptr
      00332B FD               [12]  996 	mov	r5,a
                                    997 ;	keyboards/ajazz/ak820/ak820_board.c:285: value &= ak820_matrix_mask[row];
      00332C EE               [12]  998 	mov	a,r6
      00332D 90 BE 34         [24]  999 	mov	dptr,#_ak820_matrix_mask
      003330 93               [24] 1000 	movc	a,@a+dptr
      003331 52 05            [12] 1001 	anl	ar5,a
                                   1002 ;	keyboards/ajazz/ak820/ak820_board.c:287: if (rows[row] != value) {
      003333 90 04 12         [24] 1003 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_60
      003336 E0               [24] 1004 	movx	a,@dptr
      003337 FA               [12] 1005 	mov	r2,a
      003338 A3               [24] 1006 	inc	dptr
      003339 E0               [24] 1007 	movx	a,@dptr
      00333A FB               [12] 1008 	mov	r3,a
      00333B A3               [24] 1009 	inc	dptr
      00333C E0               [24] 1010 	movx	a,@dptr
      00333D FC               [12] 1011 	mov	r4,a
      00333E EE               [12] 1012 	mov	a,r6
      00333F 2A               [12] 1013 	add	a, r2
      003340 FA               [12] 1014 	mov	r2,a
      003341 E4               [12] 1015 	clr	a
      003342 3B               [12] 1016 	addc	a, r3
      003343 FB               [12] 1017 	mov	r3,a
      003344 8A 82            [24] 1018 	mov	dpl,r2
      003346 8B 83            [24] 1019 	mov	dph,r3
      003348 8C F0            [24] 1020 	mov	b,r4
      00334A 12 BE 14         [24] 1021 	lcall	__gptrget
      00334D B5 05 02         [24] 1022 	cjne	a,ar5,00149$
      003350 80 10            [24] 1023 	sjmp	00109$
      003352                       1024 00149$:
                                   1025 ;	keyboards/ajazz/ak820/ak820_board.c:288: rows[row] = value;
      003352 8A 82            [24] 1026 	mov	dpl,r2
      003354 8B 83            [24] 1027 	mov	dph,r3
      003356 8C F0            [24] 1028 	mov	b,r4
      003358 ED               [12] 1029 	mov	a,r5
      003359 12 BD D9         [24] 1030 	lcall	__gptrput
                                   1031 ;	keyboards/ajazz/ak820/ak820_board.c:289: changed = true;
      00335C 90 04 15         [24] 1032 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      00335F 74 01            [12] 1033 	mov	a,#0x01
      003361 F0               [24] 1034 	movx	@dptr,a
      003362                       1035 00109$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_board.c:282: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      003362 0E               [12] 1037 	inc	r6
      003363 BE 10 00         [24] 1038 	cjne	r6,#0x10,00150$
      003366                       1039 00150$:
      003366 40 B8            [24] 1040 	jc	00108$
                                   1041 ;	keyboards/ajazz/ak820/ak820_board.c:292: if (irq_enabled) {
      003368 EF               [12] 1042 	mov	a,r7
      003369 60 02            [24] 1043 	jz	00107$
                                   1044 ;	keyboards/ajazz/ak820/ak820_board.c:293: IE_PWM_I2C = 1;
                                   1045 ;	assignBit
      00336B D2 ED            [12] 1046 	setb	_IE_PWM_I2C
      00336D                       1047 00107$:
                                   1048 ;	keyboards/ajazz/ak820/ak820_board.c:295: return changed;
      00336D 90 04 15         [24] 1049 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      003370 E0               [24] 1050 	movx	a,@dptr
                                   1051 ;	keyboards/ajazz/ak820/ak820_board.c:296: }
      003371 F5 82            [12] 1052 	mov	dpl,a
      003373 22               [24] 1053 	ret
                                   1054 ;------------------------------------------------------------
                                   1055 ;Allocation info for local variables in function 'ak820_set_slot_rgb'
                                   1056 ;------------------------------------------------------------
                                   1057 ;r             Allocated with name '_ak820_set_slot_rgb_PARM_2'
                                   1058 ;g             Allocated with name '_ak820_set_slot_rgb_PARM_3'
                                   1059 ;b             Allocated with name '_ak820_set_slot_rgb_PARM_4'
                                   1060 ;slot          Allocated with name '_ak820_set_slot_rgb_slot_10000_70'
                                   1061 ;offset        Allocated with name '_ak820_set_slot_rgb_offset_10000_71'
                                   1062 ;irq_enabled   Allocated with name '_ak820_set_slot_rgb_irq_enabled_10000_71'
                                   1063 ;sloc0         Allocated with name '_ak820_set_slot_rgb_sloc0_1_0'
                                   1064 ;------------------------------------------------------------
                                   1065 ;	keyboards/ajazz/ak820/ak820_board.c:298: void ak820_set_slot_rgb(uint8_t slot, uint8_t r, uint8_t g, uint8_t b) {
                                   1066 ;	-----------------------------------------
                                   1067 ;	 function ak820_set_slot_rgb
                                   1068 ;	-----------------------------------------
      003374                       1069 _ak820_set_slot_rgb:
      003374 E5 82            [12] 1070 	mov	a,dpl
      003376 90 04 19         [24] 1071 	mov	dptr,#_ak820_set_slot_rgb_slot_10000_70
      003379 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	keyboards/ajazz/ak820/ak820_board.c:301: if (slot >= AK820_SCAN_ROWS * AK820_SCAN_COLS) {
      00337A E0               [24] 1074 	movx	a,@dptr
      00337B FF               [12] 1075 	mov	r7,a
      00337C BF 80 00         [24] 1076 	cjne	r7,#0x80,00130$
      00337F                       1077 00130$:
      00337F 40 01            [24] 1078 	jc	00102$
                                   1079 ;	keyboards/ajazz/ak820/ak820_board.c:302: return;
      003381 22               [24] 1080 	ret
      003382                       1081 00102$:
                                   1082 ;	keyboards/ajazz/ak820/ak820_board.c:304: offset = (uint16_t)slot * 4;
      003382 7E 00            [12] 1083 	mov	r6,#0x00
      003384 EF               [12] 1084 	mov	a,r7
      003385 2F               [12] 1085 	add	a,r7
      003386 FF               [12] 1086 	mov	r7,a
      003387 EE               [12] 1087 	mov	a,r6
      003388 33               [12] 1088 	rlc	a
      003389 FE               [12] 1089 	mov	r6,a
      00338A EF               [12] 1090 	mov	a,r7
      00338B 2F               [12] 1091 	add	a,r7
      00338C FF               [12] 1092 	mov	r7,a
      00338D EE               [12] 1093 	mov	a,r6
      00338E 33               [12] 1094 	rlc	a
      00338F FE               [12] 1095 	mov	r6,a
                                   1096 ;	keyboards/ajazz/ak820/ak820_board.c:305: irq_enabled = IE_EX & 0x20;
      003390 E5 E8            [12] 1097 	mov	a,_IE_EX
      003392 54 20            [12] 1098 	anl	a,#0x20
      003394 FD               [12] 1099 	mov	r5,a
                                   1100 ;	keyboards/ajazz/ak820/ak820_board.c:306: IE_PWM_I2C = 0;
                                   1101 ;	assignBit
      003395 C2 ED            [12] 1102 	clr	_IE_PWM_I2C
                                   1103 ;	keyboards/ajazz/ak820/ak820_board.c:309: ak820_led_dma[offset]     = (r | g | b) ? 0xff : 0;
      003397 8F 03            [24] 1104 	mov	ar3,r7
      003399 74 02            [12] 1105 	mov	a,#(_ak820_led_dma >> 8)
      00339B 2E               [12] 1106 	add	a,r6
      00339C FC               [12] 1107 	mov	r4,a
      00339D 90 04 17         [24] 1108 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      0033A0 E0               [24] 1109 	movx	a,@dptr
      0033A1 FA               [12] 1110 	mov	r2,a
      0033A2 90 04 16         [24] 1111 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      0033A5 E0               [24] 1112 	movx	a,@dptr
      0033A6 F9               [12] 1113 	mov	r1,a
      0033A7 4A               [12] 1114 	orl	a,r2
      0033A8 F8               [12] 1115 	mov	r0,a
      0033A9 90 04 18         [24] 1116 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      0033AC E0               [24] 1117 	movx	a,@dptr
      0033AD F5 5A            [12] 1118 	mov	_ak820_set_slot_rgb_sloc0_1_0,a
      0033AF 48               [12] 1119 	orl	a,r0
      0033B0 60 02            [24] 1120 	jz	00107$
      0033B2 74 FF            [12] 1121 	mov	a,#0xff
      0033B4                       1122 00107$:
      0033B4 F8               [12] 1123 	mov	r0,a
      0033B5 8B 82            [24] 1124 	mov	dpl,r3
      0033B7 8C 83            [24] 1125 	mov	dph,r4
      0033B9 E8               [12] 1126 	mov	a,r0
      0033BA F0               [24] 1127 	movx	@dptr,a
                                   1128 ;	keyboards/ajazz/ak820/ak820_board.c:310: ak820_led_dma[offset + 1] = r;
      0033BB 74 01            [12] 1129 	mov	a,#0x01
      0033BD 2F               [12] 1130 	add	a, r7
      0033BE FB               [12] 1131 	mov	r3,a
      0033BF E4               [12] 1132 	clr	a
      0033C0 3E               [12] 1133 	addc	a, r6
      0033C1 FC               [12] 1134 	mov	r4,a
      0033C2 8B 82            [24] 1135 	mov	dpl,r3
      0033C4 74 02            [12] 1136 	mov	a,#(_ak820_led_dma >> 8)
      0033C6 2C               [12] 1137 	add	a,r4
      0033C7 F5 83            [12] 1138 	mov	dph,a
      0033C9 E9               [12] 1139 	mov	a,r1
      0033CA F0               [24] 1140 	movx	@dptr,a
                                   1141 ;	keyboards/ajazz/ak820/ak820_board.c:311: ak820_led_dma[offset + 2] = g;
      0033CB 74 02            [12] 1142 	mov	a,#0x02
      0033CD 2F               [12] 1143 	add	a, r7
      0033CE FB               [12] 1144 	mov	r3,a
      0033CF E4               [12] 1145 	clr	a
      0033D0 3E               [12] 1146 	addc	a, r6
      0033D1 FC               [12] 1147 	mov	r4,a
      0033D2 8B 82            [24] 1148 	mov	dpl,r3
      0033D4 74 02            [12] 1149 	mov	a,#(_ak820_led_dma >> 8)
      0033D6 2C               [12] 1150 	add	a,r4
      0033D7 F5 83            [12] 1151 	mov	dph,a
      0033D9 EA               [12] 1152 	mov	a,r2
      0033DA F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	keyboards/ajazz/ak820/ak820_board.c:312: ak820_led_dma[offset + 3] = b;
      0033DB 74 03            [12] 1155 	mov	a,#0x03
      0033DD 2F               [12] 1156 	add	a, r7
      0033DE FF               [12] 1157 	mov	r7,a
      0033DF E4               [12] 1158 	clr	a
      0033E0 3E               [12] 1159 	addc	a, r6
      0033E1 FE               [12] 1160 	mov	r6,a
      0033E2 8F 82            [24] 1161 	mov	dpl,r7
      0033E4 74 02            [12] 1162 	mov	a,#(_ak820_led_dma >> 8)
      0033E6 2E               [12] 1163 	add	a,r6
      0033E7 F5 83            [12] 1164 	mov	dph,a
      0033E9 E5 5A            [12] 1165 	mov	a,_ak820_set_slot_rgb_sloc0_1_0
      0033EB F0               [24] 1166 	movx	@dptr,a
                                   1167 ;	keyboards/ajazz/ak820/ak820_board.c:313: if (irq_enabled) {
      0033EC ED               [12] 1168 	mov	a,r5
      0033ED 60 02            [24] 1169 	jz	00105$
                                   1170 ;	keyboards/ajazz/ak820/ak820_board.c:314: IE_PWM_I2C = 1;
                                   1171 ;	assignBit
      0033EF D2 ED            [12] 1172 	setb	_IE_PWM_I2C
      0033F1                       1173 00105$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_board.c:316: }
      0033F1 22               [24] 1175 	ret
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                   1178 ;------------------------------------------------------------
                                   1179 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_198'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function ak820_rgb_init
                                   1184 ;	-----------------------------------------
      0033F2                       1185 _ak820_rgb_init:
                                   1186 ;	keyboards/ajazz/ak820/ak820_board.c:330: }
      0033F2 22               [24] 1187 	ret
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'ak820_rgb_set_color'
                                   1190 ;------------------------------------------------------------
                                   1191 ;r             Allocated to stack - _bp -3 +1 
                                   1192 ;g             Allocated to stack - _bp -4 +1 
                                   1193 ;b             Allocated to stack - _bp -5 +1 
                                   1194 ;index         Allocated to registers r6 r7 
                                   1195 ;------------------------------------------------------------
                                   1196 ;	keyboards/ajazz/ak820/ak820_board.c:333: static void ak820_rgb_set_color(int index, uint8_t r, uint8_t g, uint8_t b) __reentrant {
                                   1197 ;	-----------------------------------------
                                   1198 ;	 function ak820_rgb_set_color
                                   1199 ;	-----------------------------------------
      0033F3                       1200 _ak820_rgb_set_color:
      0033F3 C0 1F            [24] 1201 	push	_bp
      0033F5 85 81 1F         [24] 1202 	mov	_bp,sp
      0033F8 AE 82            [24] 1203 	mov	r6, dpl
                                   1204 ;	keyboards/ajazz/ak820/ak820_board.c:334: if (index < 0 || index >= RGB_MATRIX_LED_COUNT) {
      0033FA E5 83            [12] 1205 	mov	a,dph
      0033FC FF               [12] 1206 	mov	r7,a
      0033FD 20 E7 3B         [24] 1207 	jb	acc.7,00104$
      003400 C3               [12] 1208 	clr	c
      003401 EE               [12] 1209 	mov	a,r6
      003402 94 52            [12] 1210 	subb	a,#0x52
      003404 EF               [12] 1211 	mov	a,r7
      003405 64 80            [12] 1212 	xrl	a,#0x80
      003407 94 80            [12] 1213 	subb	a,#0x80
                                   1214 ;	keyboards/ajazz/ak820/ak820_board.c:335: return;
      003409 50 30            [24] 1215 	jnc	00104$
                                   1216 ;	keyboards/ajazz/ak820/ak820_board.c:338: ak820_set_slot_rgb(ak820_rgb_slots[index], r, g, b);
      00340B EE               [12] 1217 	mov	a,r6
      00340C 24 44            [12] 1218 	add	a, #_ak820_rgb_slots
      00340E F5 82            [12] 1219 	mov	dpl,a
      003410 EF               [12] 1220 	mov	a,r7
      003411 34 BE            [12] 1221 	addc	a, #(_ak820_rgb_slots >> 8)
      003413 F5 83            [12] 1222 	mov	dph,a
      003415 E4               [12] 1223 	clr	a
      003416 93               [24] 1224 	movc	a,@a+dptr
      003417 FF               [12] 1225 	mov	r7,a
      003418 E5 1F            [12] 1226 	mov	a,_bp
      00341A 24 FD            [12] 1227 	add	a,#0xfd
      00341C F8               [12] 1228 	mov	r0,a
      00341D 90 04 16         [24] 1229 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      003420 E6               [12] 1230 	mov	a,@r0
      003421 F0               [24] 1231 	movx	@dptr,a
      003422 E5 1F            [12] 1232 	mov	a,_bp
      003424 24 FC            [12] 1233 	add	a,#0xfc
      003426 F8               [12] 1234 	mov	r0,a
      003427 90 04 17         [24] 1235 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      00342A E6               [12] 1236 	mov	a,@r0
      00342B F0               [24] 1237 	movx	@dptr,a
      00342C E5 1F            [12] 1238 	mov	a,_bp
      00342E 24 FB            [12] 1239 	add	a,#0xfb
      003430 F8               [12] 1240 	mov	r0,a
      003431 90 04 18         [24] 1241 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      003434 E6               [12] 1242 	mov	a,@r0
      003435 F0               [24] 1243 	movx	@dptr,a
      003436 8F 82            [24] 1244 	mov	dpl, r7
      003438 12 33 74         [24] 1245 	lcall	_ak820_set_slot_rgb
      00343B                       1246 00104$:
                                   1247 ;	keyboards/ajazz/ak820/ak820_board.c:342: }
      00343B D0 1F            [24] 1248 	pop	_bp
      00343D 22               [24] 1249 	ret
                                   1250 ;------------------------------------------------------------
                                   1251 ;Allocation info for local variables in function 'ak820_rgb_set_color_all'
                                   1252 ;------------------------------------------------------------
                                   1253 ;g             Allocated to stack - _bp -3 +1 
                                   1254 ;b             Allocated to stack - _bp -4 +1 
                                   1255 ;r             Allocated to registers r7 
                                   1256 ;i             Allocated to registers r6 
                                   1257 ;------------------------------------------------------------
                                   1258 ;	keyboards/ajazz/ak820/ak820_board.c:344: static void ak820_rgb_set_color_all(uint8_t r, uint8_t g, uint8_t b) __reentrant {
                                   1259 ;	-----------------------------------------
                                   1260 ;	 function ak820_rgb_set_color_all
                                   1261 ;	-----------------------------------------
      00343E                       1262 _ak820_rgb_set_color_all:
      00343E C0 1F            [24] 1263 	push	_bp
      003440 85 81 1F         [24] 1264 	mov	_bp,sp
      003443 AF 82            [24] 1265 	mov	r7, dpl
                                   1266 ;	keyboards/ajazz/ak820/ak820_board.c:346: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      003445 7E 00            [12] 1267 	mov	r6,#0x00
      003447                       1268 00102$:
                                   1269 ;	keyboards/ajazz/ak820/ak820_board.c:347: ak820_rgb_set_color(i, r, g, b);
      003447 8E 04            [24] 1270 	mov	ar4,r6
      003449 7D 00            [12] 1271 	mov	r5,#0x00
      00344B C0 07            [24] 1272 	push	ar7
      00344D C0 06            [24] 1273 	push	ar6
      00344F E5 1F            [12] 1274 	mov	a,_bp
      003451 24 FC            [12] 1275 	add	a,#0xfc
      003453 F8               [12] 1276 	mov	r0,a
      003454 E6               [12] 1277 	mov	a,@r0
      003455 C0 E0            [24] 1278 	push	acc
      003457 E5 1F            [12] 1279 	mov	a,_bp
      003459 24 FD            [12] 1280 	add	a,#0xfd
      00345B F8               [12] 1281 	mov	r0,a
      00345C E6               [12] 1282 	mov	a,@r0
      00345D C0 E0            [24] 1283 	push	acc
      00345F C0 07            [24] 1284 	push	ar7
      003461 8C 82            [24] 1285 	mov	dpl, r4
      003463 8D 83            [24] 1286 	mov	dph, r5
      003465 12 33 F3         [24] 1287 	lcall	_ak820_rgb_set_color
      003468 15 81            [12] 1288 	dec	sp
      00346A 15 81            [12] 1289 	dec	sp
      00346C 15 81            [12] 1290 	dec	sp
      00346E D0 06            [24] 1291 	pop	ar6
      003470 D0 07            [24] 1292 	pop	ar7
                                   1293 ;	keyboards/ajazz/ak820/ak820_board.c:346: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      003472 0E               [12] 1294 	inc	r6
      003473 BE 52 00         [24] 1295 	cjne	r6,#0x52,00114$
      003476                       1296 00114$:
      003476 40 CF            [24] 1297 	jc	00102$
                                   1298 ;	keyboards/ajazz/ak820/ak820_board.c:349: }
      003478 D0 1F            [24] 1299 	pop	_bp
      00347A 22               [24] 1300 	ret
                                   1301 ;------------------------------------------------------------
                                   1302 ;Allocation info for local variables in function 'ak820_rgb_flush'
                                   1303 ;------------------------------------------------------------
                                   1304 ;	keyboards/ajazz/ak820/ak820_board.c:351: static void ak820_rgb_flush(void) {
                                   1305 ;	-----------------------------------------
                                   1306 ;	 function ak820_rgb_flush
                                   1307 ;	-----------------------------------------
      00347B                       1308 _ak820_rgb_flush:
                                   1309 ;	keyboards/ajazz/ak820/ak820_board.c:353: }
      00347B 22               [24] 1310 	ret
                                   1311 	.area CSEG    (CODE)
                                   1312 	.area CONST   (CODE)
                                   1313 	.area CONST   (CODE)
      00BE34                       1314 _ak820_matrix_mask:
      00BE34 3F                    1315 	.db #0x3f	; 63
      00BE35 2F                    1316 	.db #0x2f	; 47
      00BE36 3F                    1317 	.db #0x3f	; 63
      00BE37 1F                    1318 	.db #0x1f	; 31
      00BE38 1F                    1319 	.db #0x1f	; 31
      00BE39 3F                    1320 	.db #0x3f	; 63
      00BE3A 1F                    1321 	.db #0x1f	; 31
      00BE3B 1F                    1322 	.db #0x1f	; 31
      00BE3C 1F                    1323 	.db #0x1f	; 31
      00BE3D 3F                    1324 	.db #0x3f	; 63
      00BE3E 3F                    1325 	.db #0x3f	; 63
      00BE3F 3F                    1326 	.db #0x3f	; 63
      00BE40 07                    1327 	.db #0x07	; 7
      00BE41 3F                    1328 	.db #0x3f	; 63
      00BE42 3C                    1329 	.db #0x3c	; 60
      00BE43 2E                    1330 	.db #0x2e	; 46
                                   1331 	.area CSEG    (CODE)
                                   1332 	.area CONST   (CODE)
      00BE44                       1333 _ak820_rgb_slots:
      00BE44 00                    1334 	.db #0x00	; 0
      00BE45 08                    1335 	.db #0x08	; 8
      00BE46 10                    1336 	.db #0x10	; 16
      00BE47 18                    1337 	.db #0x18	; 24
      00BE48 20                    1338 	.db #0x20	; 32
      00BE49 28                    1339 	.db #0x28	; 40
      00BE4A 30                    1340 	.db #0x30	; 48	'0'
      00BE4B 38                    1341 	.db #0x38	; 56	'8'
      00BE4C 40                    1342 	.db #0x40	; 64
      00BE4D 48                    1343 	.db #0x48	; 72	'H'
      00BE4E 50                    1344 	.db #0x50	; 80	'P'
      00BE4F 58                    1345 	.db #0x58	; 88	'X'
      00BE50 60                    1346 	.db #0x60	; 96
      00BE51 72                    1347 	.db #0x72	; 114	'r'
      00BE52 01                    1348 	.db #0x01	; 1
      00BE53 09                    1349 	.db #0x09	; 9
      00BE54 11                    1350 	.db #0x11	; 17
      00BE55 19                    1351 	.db #0x19	; 25
      00BE56 21                    1352 	.db #0x21	; 33
      00BE57 29                    1353 	.db #0x29	; 41
      00BE58 31                    1354 	.db #0x31	; 49	'1'
      00BE59 39                    1355 	.db #0x39	; 57	'9'
      00BE5A 41                    1356 	.db #0x41	; 65	'A'
      00BE5B 49                    1357 	.db #0x49	; 73	'I'
      00BE5C 51                    1358 	.db #0x51	; 81	'Q'
      00BE5D 59                    1359 	.db #0x59	; 89	'Y'
      00BE5E 61                    1360 	.db #0x61	; 97	'a'
      00BE5F 69                    1361 	.db #0x69	; 105	'i'
      00BE60 79                    1362 	.db #0x79	; 121	'y'
      00BE61 02                    1363 	.db #0x02	; 2
      00BE62 0A                    1364 	.db #0x0a	; 10
      00BE63 12                    1365 	.db #0x12	; 18
      00BE64 1A                    1366 	.db #0x1a	; 26
      00BE65 22                    1367 	.db #0x22	; 34
      00BE66 2A                    1368 	.db #0x2a	; 42
      00BE67 32                    1369 	.db #0x32	; 50	'2'
      00BE68 3A                    1370 	.db #0x3a	; 58
      00BE69 42                    1371 	.db #0x42	; 66	'B'
      00BE6A 4A                    1372 	.db #0x4a	; 74	'J'
      00BE6B 52                    1373 	.db #0x52	; 82	'R'
      00BE6C 5A                    1374 	.db #0x5a	; 90	'Z'
      00BE6D 62                    1375 	.db #0x62	; 98	'b'
      00BE6E 6A                    1376 	.db #0x6a	; 106	'j'
      00BE6F 7A                    1377 	.db #0x7a	; 122	'z'
      00BE70 03                    1378 	.db #0x03	; 3
      00BE71 0B                    1379 	.db #0x0b	; 11
      00BE72 13                    1380 	.db #0x13	; 19
      00BE73 1B                    1381 	.db #0x1b	; 27
      00BE74 23                    1382 	.db #0x23	; 35
      00BE75 2B                    1383 	.db #0x2b	; 43
      00BE76 33                    1384 	.db #0x33	; 51	'3'
      00BE77 3B                    1385 	.db #0x3b	; 59
      00BE78 43                    1386 	.db #0x43	; 67	'C'
      00BE79 4B                    1387 	.db #0x4b	; 75	'K'
      00BE7A 53                    1388 	.db #0x53	; 83	'S'
      00BE7B 5B                    1389 	.db #0x5b	; 91
      00BE7C 6B                    1390 	.db #0x6b	; 107	'k'
      00BE7D 73                    1391 	.db #0x73	; 115	's'
      00BE7E 04                    1392 	.db #0x04	; 4
      00BE7F 14                    1393 	.db #0x14	; 20
      00BE80 1C                    1394 	.db #0x1c	; 28
      00BE81 24                    1395 	.db #0x24	; 36
      00BE82 2C                    1396 	.db #0x2c	; 44
      00BE83 34                    1397 	.db #0x34	; 52	'4'
      00BE84 3C                    1398 	.db #0x3c	; 60
      00BE85 44                    1399 	.db #0x44	; 68	'D'
      00BE86 4C                    1400 	.db #0x4c	; 76	'L'
      00BE87 54                    1401 	.db #0x54	; 84	'T'
      00BE88 5C                    1402 	.db #0x5c	; 92
      00BE89 6C                    1403 	.db #0x6c	; 108	'l'
      00BE8A 74                    1404 	.db #0x74	; 116	't'
      00BE8B 7B                    1405 	.db #0x7b	; 123
      00BE8C 05                    1406 	.db #0x05	; 5
      00BE8D 0D                    1407 	.db #0x0d	; 13
      00BE8E 15                    1408 	.db #0x15	; 21
      00BE8F 2D                    1409 	.db #0x2d	; 45
      00BE90 4D                    1410 	.db #0x4d	; 77	'M'
      00BE91 55                    1411 	.db #0x55	; 85	'U'
      00BE92 5D                    1412 	.db #0x5d	; 93
      00BE93 6D                    1413 	.db #0x6d	; 109	'm'
      00BE94 75                    1414 	.db #0x75	; 117	'u'
      00BE95 7D                    1415 	.db #0x7d	; 125
                                   1416 	.area CSEG    (CODE)
                                   1417 	.area CONST   (CODE)
      00BE96                       1418 _rgb_matrix_driver:
      00BE96 F2 33                 1419 	.byte _ak820_rgb_init, (_ak820_rgb_init >> 8)
      00BE98 F3 33                 1420 	.byte _ak820_rgb_set_color, (_ak820_rgb_set_color >> 8)
      00BE9A 3E 34                 1421 	.byte _ak820_rgb_set_color_all, (_ak820_rgb_set_color_all >> 8)
      00BE9C 7B 34                 1422 	.byte _ak820_rgb_flush, (_ak820_rgb_flush >> 8)
                                   1423 	.area CSEG    (CODE)
                                   1424 	.area XINIT   (CODE)
                                   1425 	.area CABS    (ABS,CODE)
