                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_update_byte
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_nvm_end
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_begin
                                     17 	.globl _ak820_nvm_ok
                                     18 	.globl _ak820_macro_write_PARM_3
                                     19 	.globl _ak820_macro_write_PARM_2
                                     20 	.globl _ak820_macro_init
                                     21 	.globl _ak820_macro_ready
                                     22 	.globl _ak820_macro_length
                                     23 	.globl _ak820_macro_write
                                     24 	.globl _ak820_macro_reset
                                     25 ;--------------------------------------------------------
                                     26 ; special function registers
                                     27 ;--------------------------------------------------------
                                     28 	.area RSEG    (ABS,DATA)
      000000                         29 	.org 0x0000
                                     30 ;--------------------------------------------------------
                                     31 ; special function bits
                                     32 ;--------------------------------------------------------
                                     33 	.area RSEG    (ABS,DATA)
      000000                         34 	.org 0x0000
                                     35 ;--------------------------------------------------------
                                     36 ; overlayable register banks
                                     37 ;--------------------------------------------------------
                                     38 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         39 	.ds 8
                                     40 ;--------------------------------------------------------
                                     41 ; internal ram data
                                     42 ;--------------------------------------------------------
                                     43 	.area DSEG    (DATA)
      00000A                         44 _ak820_macro_write_sloc0_1_0:
      00000A                         45 	.ds 2
                                     46 ;--------------------------------------------------------
                                     47 ; overlayable items in internal ram
                                     48 ;--------------------------------------------------------
                                     49 	.area	OSEG    (OVR,DATA)
      00005A                         50 _parse_byte_sloc1_1_0:
      00005A                         51 	.ds 2
                                     52 ;--------------------------------------------------------
                                     53 ; indirectly addressable internal ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area ISEG    (DATA)
                                     56 ;--------------------------------------------------------
                                     57 ; absolute internal ram data
                                     58 ;--------------------------------------------------------
                                     59 	.area IABS    (ABS,DATA)
                                     60 	.area IABS    (ABS,DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; bit data
                                     63 ;--------------------------------------------------------
                                     64 	.area BSEG    (BIT)
      000006                         65 _parse_byte_sloc0_1_0:
      000006                         66 	.ds 1
      000007                         67 _ak820_macro_ready_sloc0_1_0:
      000007                         68 	.ds 1
                                     69 ;--------------------------------------------------------
                                     70 ; paged external ram data
                                     71 ;--------------------------------------------------------
                                     72 	.area PSEG    (PAG,XDATA)
                                     73 ;--------------------------------------------------------
                                     74 ; uninitialized external ram data
                                     75 ;--------------------------------------------------------
                                     76 	.area XSEG    (XDATA)
      0004F6                         77 _parsed:
      0004F6                         78 	.ds 2
      0004F8                         79 _covered:
      0004F8                         80 	.ds 2
      0004FA                         81 _used_length:
      0004FA                         82 	.ds 2
      0004FC                         83 _uploading:
      0004FC                         84 	.ds 1
      0004FD                         85 _macro_byte_offset_10000_67:
      0004FD                         86 	.ds 2
      0004FF                         87 _busy_write_value_10000_69:
      0004FF                         88 	.ds 1
      000500                         89 _commit_length_length_10000_71:
      000500                         90 	.ds 2
      000502                         91 _commit_length_metadata_10000_72:
      000502                         92 	.ds 3
      000505                         93 _parse_byte_PARM_2:
      000505                         94 	.ds 1
      000506                         95 _parse_byte_state_10000_74:
      000506                         96 	.ds 2
      000508                         97 _matches_PARM_2:
      000508                         98 	.ds 2
      00050A                         99 _matches_PARM_3:
      00050A                        100 	.ds 2
      00050C                        101 _matches_offset_10000_89:
      00050C                        102 	.ds 2
      00050E                        103 _ak820_macro_write_PARM_2:
      00050E                        104 	.ds 2
      000510                        105 _ak820_macro_write_PARM_3:
      000510                        106 	.ds 3
      000513                        107 _ak820_macro_write_offset_10000_99:
      000513                        108 	.ds 2
      000515                        109 _ak820_macro_write_next_10000_100:
      000515                        110 	.ds 2
                                    111 ;--------------------------------------------------------
                                    112 ; absolute external ram data
                                    113 ;--------------------------------------------------------
                                    114 	.area XABS    (ABS,XDATA)
                                    115 ;--------------------------------------------------------
                                    116 ; initialized external ram data
                                    117 ;--------------------------------------------------------
                                    118 	.area XISEG   (XDATA)
                                    119 	.area HOME    (CODE)
                                    120 	.area GSINIT0 (CODE)
                                    121 	.area GSINIT1 (CODE)
                                    122 	.area GSINIT2 (CODE)
                                    123 	.area GSINIT3 (CODE)
                                    124 	.area GSINIT4 (CODE)
                                    125 	.area GSINIT5 (CODE)
                                    126 	.area GSINIT  (CODE)
                                    127 	.area GSFINAL (CODE)
                                    128 	.area CSEG    (CODE)
                                    129 ;--------------------------------------------------------
                                    130 ; global & static initialisations
                                    131 ;--------------------------------------------------------
                                    132 	.area HOME    (CODE)
                                    133 	.area GSINIT  (CODE)
                                    134 	.area GSFINAL (CODE)
                                    135 	.area GSINIT  (CODE)
                                    136 ;--------------------------------------------------------
                                    137 ; Home
                                    138 ;--------------------------------------------------------
                                    139 	.area HOME    (CODE)
                                    140 	.area HOME    (CODE)
                                    141 ;--------------------------------------------------------
                                    142 ; code
                                    143 ;--------------------------------------------------------
                                    144 	.area AK820LOW(CODE)
                                    145 ;------------------------------------------------------------
                                    146 ;Allocation info for local variables in function 'macro_byte'
                                    147 ;------------------------------------------------------------
                                    148 ;offset        Allocated with name '_macro_byte_offset_10000_67'
                                    149 ;------------------------------------------------------------
                                    150 ;	keyboards/ajazz/ak820/ak820_macro.c:34: static uint8_t macro_byte(uint16_t offset) {
                                    151 ;	-----------------------------------------
                                    152 ;	 function macro_byte
                                    153 ;	-----------------------------------------
      0028EC                        154 _macro_byte:
                           000007   155 	ar7 = 0x07
                           000006   156 	ar6 = 0x06
                           000005   157 	ar5 = 0x05
                           000004   158 	ar4 = 0x04
                           000003   159 	ar3 = 0x03
                           000002   160 	ar2 = 0x02
                           000001   161 	ar1 = 0x01
                           000000   162 	ar0 = 0x00
      0028EC AF 83            [24]  163 	mov	r7,dph
      0028EE E5 82            [12]  164 	mov	a,dpl
      0028F0 90 04 FD         [24]  165 	mov	dptr,#_macro_byte_offset_10000_67
      0028F3 F0               [24]  166 	movx	@dptr,a
      0028F4 EF               [12]  167 	mov	a,r7
      0028F5 A3               [24]  168 	inc	dptr
      0028F6 F0               [24]  169 	movx	@dptr,a
                                    170 ;	keyboards/ajazz/ak820/ak820_macro.c:35: return eeprom_read_byte((const uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset));
      0028F7 90 04 FD         [24]  171 	mov	dptr,#_macro_byte_offset_10000_67
      0028FA E0               [24]  172 	movx	a,@dptr
      0028FB FE               [12]  173 	mov	r6,a
      0028FC A3               [24]  174 	inc	dptr
      0028FD E0               [24]  175 	movx	a,@dptr
      0028FE 24 08            [12]  176 	add	a,#0x08
      002900 FF               [12]  177 	mov	r7,a
      002901 7D 00            [12]  178 	mov	r5,#0x00
      002903 8E 82            [24]  179 	mov	dpl, r6
      002905 8F 83            [24]  180 	mov	dph, r7
      002907 8D F0            [24]  181 	mov	b, r5
                                    182 ;	keyboards/ajazz/ak820/ak820_macro.c:36: }
      002909 02 41 13         [24]  183 	ljmp	_eeprom_read_byte
                                    184 ;------------------------------------------------------------
                                    185 ;Allocation info for local variables in function 'busy_write'
                                    186 ;------------------------------------------------------------
                                    187 ;value         Allocated with name '_busy_write_value_10000_69'
                                    188 ;------------------------------------------------------------
                                    189 ;	keyboards/ajazz/ak820/ak820_macro.c:38: static void busy_write(uint8_t value) {
                                    190 ;	-----------------------------------------
                                    191 ;	 function busy_write
                                    192 ;	-----------------------------------------
      00290C                        193 _busy_write:
      00290C E5 82            [12]  194 	mov	a,dpl
      00290E 90 04 FF         [24]  195 	mov	dptr,#_busy_write_value_10000_69
      002911 F0               [24]  196 	movx	@dptr,a
                                    197 ;	keyboards/ajazz/ak820/ak820_macro.c:39: eeprom_update_byte((uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR, value);
      002912 E0               [24]  198 	movx	a,@dptr
      002913 90 06 88         [24]  199 	mov	dptr,#_eeprom_update_byte_PARM_2
      002916 F0               [24]  200 	movx	@dptr,a
      002917 90 07 F0         [24]  201 	mov	dptr,#0x07f0
      00291A 75 F0 00         [24]  202 	mov	b, #0x00
      00291D 12 4D 63         [24]  203 	lcall	_eeprom_update_byte
                                    204 ;	keyboards/ajazz/ak820/ak820_macro.c:40: ak820_nvm_flush();
                                    205 ;	keyboards/ajazz/ak820/ak820_macro.c:41: }
      002920 02 3E 92         [24]  206 	ljmp	_ak820_nvm_flush
                                    207 ;------------------------------------------------------------
                                    208 ;Allocation info for local variables in function 'commit_length'
                                    209 ;------------------------------------------------------------
                                    210 ;length        Allocated with name '_commit_length_length_10000_71'
                                    211 ;metadata      Allocated with name '_commit_length_metadata_10000_72'
                                    212 ;------------------------------------------------------------
                                    213 ;	keyboards/ajazz/ak820/ak820_macro.c:43: static void commit_length(uint16_t length) {
                                    214 ;	-----------------------------------------
                                    215 ;	 function commit_length
                                    216 ;	-----------------------------------------
      002923                        217 _commit_length:
      002923 AF 83            [24]  218 	mov	r7,dph
      002925 E5 82            [12]  219 	mov	a,dpl
      002927 90 05 00         [24]  220 	mov	dptr,#_commit_length_length_10000_71
      00292A F0               [24]  221 	movx	@dptr,a
      00292B EF               [12]  222 	mov	a,r7
      00292C A3               [24]  223 	inc	dptr
      00292D F0               [24]  224 	movx	@dptr,a
                                    225 ;	keyboards/ajazz/ak820/ak820_macro.c:45: metadata[0] = 0;
      00292E 90 05 02         [24]  226 	mov	dptr,#_commit_length_metadata_10000_72
      002931 E4               [12]  227 	clr	a
      002932 F0               [24]  228 	movx	@dptr,a
                                    229 ;	keyboards/ajazz/ak820/ak820_macro.c:46: metadata[1] = (uint8_t)length;
      002933 90 05 00         [24]  230 	mov	dptr,#_commit_length_length_10000_71
      002936 E0               [24]  231 	movx	a,@dptr
      002937 FE               [12]  232 	mov	r6,a
      002938 A3               [24]  233 	inc	dptr
      002939 E0               [24]  234 	movx	a,@dptr
      00293A FF               [12]  235 	mov	r7,a
      00293B 8E 05            [24]  236 	mov	ar5,r6
      00293D 90 05 03         [24]  237 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0001)
      002940 ED               [12]  238 	mov	a,r5
      002941 F0               [24]  239 	movx	@dptr,a
                                    240 ;	keyboards/ajazz/ak820/ak820_macro.c:47: metadata[2] = (uint8_t)(length >> 8);
      002942 8F 05            [24]  241 	mov	ar5,r7
      002944 90 05 04         [24]  242 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0002)
      002947 ED               [12]  243 	mov	a,r5
      002948 F0               [24]  244 	movx	@dptr,a
                                    245 ;	keyboards/ajazz/ak820/ak820_macro.c:48: ak820_eeprom_write_block_xdata(metadata, (void *)(uintptr_t)AK820_MACRO_BUSY_ADDR, sizeof(metadata));
      002949 90 05 8D         [24]  246 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00294C 74 F0            [12]  247 	mov	a,#0xf0
      00294E F0               [24]  248 	movx	@dptr,a
      00294F 74 07            [12]  249 	mov	a,#0x07
      002951 A3               [24]  250 	inc	dptr
      002952 F0               [24]  251 	movx	@dptr,a
      002953 E4               [12]  252 	clr	a
      002954 A3               [24]  253 	inc	dptr
      002955 F0               [24]  254 	movx	@dptr,a
      002956 90 05 90         [24]  255 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      002959 74 03            [12]  256 	mov	a,#0x03
      00295B F0               [24]  257 	movx	@dptr,a
      00295C E4               [12]  258 	clr	a
      00295D A3               [24]  259 	inc	dptr
      00295E F0               [24]  260 	movx	@dptr,a
      00295F 90 05 02         [24]  261 	mov	dptr,#_commit_length_metadata_10000_72
      002962 C0 07            [24]  262 	push	ar7
      002964 C0 06            [24]  263 	push	ar6
      002966 12 41 DD         [24]  264 	lcall	_ak820_eeprom_write_block_xdata
                                    265 ;	keyboards/ajazz/ak820/ak820_macro.c:49: ak820_nvm_flush();
      002969 12 3E 92         [24]  266 	lcall	_ak820_nvm_flush
      00296C D0 06            [24]  267 	pop	ar6
      00296E D0 07            [24]  268 	pop	ar7
                                    269 ;	keyboards/ajazz/ak820/ak820_macro.c:50: if (ak820_nvm_ok()) used_length = length;
      002970 12 3E 7C         [24]  270 	lcall	_ak820_nvm_ok
      002973 E5 82            [12]  271 	mov	a, dpl
      002975 60 08            [24]  272 	jz	00103$
      002977 90 04 FA         [24]  273 	mov	dptr,#_used_length
      00297A EE               [12]  274 	mov	a,r6
      00297B F0               [24]  275 	movx	@dptr,a
      00297C EF               [12]  276 	mov	a,r7
      00297D A3               [24]  277 	inc	dptr
      00297E F0               [24]  278 	movx	@dptr,a
      00297F                        279 00103$:
                                    280 ;	keyboards/ajazz/ak820/ak820_macro.c:51: }
      00297F 22               [24]  281 	ret
                                    282 ;------------------------------------------------------------
                                    283 ;Allocation info for local variables in function 'parse_byte'
                                    284 ;------------------------------------------------------------
                                    285 ;value         Allocated with name '_parse_byte_PARM_2'
                                    286 ;state         Allocated with name '_parse_byte_state_10000_74'
                                    287 ;sloc1         Allocated with name '_parse_byte_sloc1_1_0'
                                    288 ;------------------------------------------------------------
                                    289 ;	keyboards/ajazz/ak820/ak820_macro.c:55: static bool parse_byte(macro_parse_t AK820_XDATA *state, uint8_t value) {
                                    290 ;	-----------------------------------------
                                    291 ;	 function parse_byte
                                    292 ;	-----------------------------------------
      002980                        293 _parse_byte:
      002980 AF 83            [24]  294 	mov	r7,dph
      002982 E5 82            [12]  295 	mov	a,dpl
      002984 90 05 06         [24]  296 	mov	dptr,#_parse_byte_state_10000_74
      002987 F0               [24]  297 	movx	@dptr,a
      002988 EF               [12]  298 	mov	a,r7
      002989 A3               [24]  299 	inc	dptr
      00298A F0               [24]  300 	movx	@dptr,a
                                    301 ;	keyboards/ajazz/ak820/ak820_macro.c:56: if (state->terminated == DYNAMIC_KEYMAP_MACRO_COUNT) return value == 0;
      00298B 90 05 06         [24]  302 	mov	dptr,#_parse_byte_state_10000_74
      00298E E0               [24]  303 	movx	a,@dptr
      00298F FE               [12]  304 	mov	r6,a
      002990 A3               [24]  305 	inc	dptr
      002991 E0               [24]  306 	movx	a,@dptr
      002992 FF               [12]  307 	mov	r7,a
      002993 8E 04            [24]  308 	mov	ar4,r6
      002995 8F 05            [24]  309 	mov	ar5,r7
      002997 8C 82            [24]  310 	mov	dpl,r4
      002999 8D 83            [24]  311 	mov	dph,r5
      00299B E0               [24]  312 	movx	a,@dptr
      00299C FB               [12]  313 	mov	r3,a
      00299D BB 10 0E         [24]  314 	cjne	r3,#0x10,00102$
      0029A0 90 05 05         [24]  315 	mov	dptr,#_parse_byte_PARM_2
      0029A3 E0               [24]  316 	movx	a,@dptr
      0029A4 B4 01 00         [24]  317 	cjne	a,#0x01,00191$
      0029A7                        318 00191$:
      0029A7 92 06            [24]  319 	mov  _parse_byte_sloc0_1_0,c
      0029A9 E4               [12]  320 	clr	a
      0029AA 33               [12]  321 	rlc	a
      0029AB F5 82            [12]  322 	mov	dpl, a
      0029AD 22               [24]  323 	ret
      0029AE                        324 00102$:
                                    325 ;	keyboards/ajazz/ak820/ak820_macro.c:57: if (state->arguments == 3) {
      0029AE 0E               [12]  326 	inc	r6
      0029AF BE 00 01         [24]  327 	cjne	r6,#0x00,00192$
      0029B2 0F               [12]  328 	inc	r7
      0029B3                        329 00192$:
      0029B3 8E 82            [24]  330 	mov	dpl,r6
      0029B5 8F 83            [24]  331 	mov	dph,r7
      0029B7 E0               [24]  332 	movx	a,@dptr
      0029B8 FA               [12]  333 	mov	r2,a
      0029B9 BA 03 2C         [24]  334 	cjne	r2,#0x03,00120$
                                    335 ;	keyboards/ajazz/ak820/ak820_macro.c:58: if (value < 1 || value > 7) return false;
      0029BC 90 05 05         [24]  336 	mov	dptr,#_parse_byte_PARM_2
      0029BF E0               [24]  337 	movx	a,@dptr
      0029C0 F9               [12]  338 	mov	r1,a
      0029C1 B9 01 00         [24]  339 	cjne	r1,#0x01,00195$
      0029C4                        340 00195$:
      0029C4 40 05            [24]  341 	jc	00103$
      0029C6 E9               [12]  342 	mov	a,r1
      0029C7 24 F8            [12]  343 	add	a,#0xff - 0x07
      0029C9 50 04            [24]  344 	jnc	00104$
                                    345 ;	free result
      0029CB                        346 00103$:
      0029CB 75 82 00         [24]  347 	mov	dpl, #0x00
      0029CE 22               [24]  348 	ret
      0029CF                        349 00104$:
                                    350 ;	keyboards/ajazz/ak820/ak820_macro.c:59: state->arguments = value <= 3 ? 1 : 2;
      0029CF 8E 5A            [24]  351 	mov	_parse_byte_sloc1_1_0,r6
      0029D1 8F 5B            [24]  352 	mov	(_parse_byte_sloc1_1_0 + 1),r7
      0029D3 E9               [12]  353 	mov	a,r1
      0029D4 24 FC            [12]  354 	add	a,#0xff - 0x03
      0029D6 40 04            [24]  355 	jc	00124$
                                    356 ;	free result
      0029D8 79 01            [12]  357 	mov	r1,#0x01
      0029DA 80 02            [24]  358 	sjmp	00125$
      0029DC                        359 00124$:
      0029DC 79 02            [12]  360 	mov	r1,#0x02
      0029DE                        361 00125$:
      0029DE 85 5A 82         [24]  362 	mov	dpl,_parse_byte_sloc1_1_0
      0029E1 85 5B 83         [24]  363 	mov	dph,(_parse_byte_sloc1_1_0 + 1)
      0029E4 E9               [12]  364 	mov	a,r1
      0029E5 F0               [24]  365 	movx	@dptr,a
      0029E6 80 3A            [24]  366 	sjmp	00121$
      0029E8                        367 00120$:
                                    368 ;	keyboards/ajazz/ak820/ak820_macro.c:60: } else if (state->arguments) {
      0029E8 EA               [12]  369 	mov	a,r2
      0029E9 60 12            [24]  370 	jz	00117$
                                    371 ;	keyboards/ajazz/ak820/ak820_macro.c:61: if (!value) return false;
      0029EB 90 05 05         [24]  372 	mov	dptr,#_parse_byte_PARM_2
      0029EE E0               [24]  373 	movx	a,@dptr
      0029EF 70 03            [24]  374 	jnz	00107$
      0029F1 F5 82            [12]  375 	mov	dpl,a
      0029F3 22               [24]  376 	ret
      0029F4                        377 00107$:
                                    378 ;	keyboards/ajazz/ak820/ak820_macro.c:62: --state->arguments;
      0029F4 1A               [12]  379 	dec	r2
      0029F5 8E 82            [24]  380 	mov	dpl,r6
      0029F7 8F 83            [24]  381 	mov	dph,r7
      0029F9 EA               [12]  382 	mov	a,r2
      0029FA F0               [24]  383 	movx	@dptr,a
      0029FB 80 25            [24]  384 	sjmp	00121$
      0029FD                        385 00117$:
                                    386 ;	keyboards/ajazz/ak820/ak820_macro.c:63: } else if (!value) {
      0029FD 90 05 05         [24]  387 	mov	dptr,#_parse_byte_PARM_2
      002A00 E0               [24]  388 	movx	a,@dptr
      002A01 FA               [12]  389 	mov	r2,a
      002A02 70 09            [24]  390 	jnz	00114$
                                    391 ;	keyboards/ajazz/ak820/ak820_macro.c:64: ++state->terminated;
      002A04 0B               [12]  392 	inc	r3
      002A05 8C 82            [24]  393 	mov	dpl,r4
      002A07 8D 83            [24]  394 	mov	dph,r5
      002A09 EB               [12]  395 	mov	a,r3
      002A0A F0               [24]  396 	movx	@dptr,a
      002A0B 80 15            [24]  397 	sjmp	00121$
      002A0D                        398 00114$:
                                    399 ;	keyboards/ajazz/ak820/ak820_macro.c:65: } else if (value == 1) {
      002A0D BA 01 09         [24]  400 	cjne	r2,#0x01,00111$
                                    401 ;	keyboards/ajazz/ak820/ak820_macro.c:66: state->arguments = 3;
      002A10 8E 82            [24]  402 	mov	dpl,r6
      002A12 8F 83            [24]  403 	mov	dph,r7
      002A14 74 03            [12]  404 	mov	a,#0x03
      002A16 F0               [24]  405 	movx	@dptr,a
      002A17 80 09            [24]  406 	sjmp	00121$
      002A19                        407 00111$:
                                    408 ;	keyboards/ajazz/ak820/ak820_macro.c:67: } else if (value >= 128) {
      002A19 BA 80 00         [24]  409 	cjne	r2,#0x80,00204$
      002A1C                        410 00204$:
      002A1C 40 04            [24]  411 	jc	00121$
                                    412 ;	keyboards/ajazz/ak820/ak820_macro.c:70: return false;
      002A1E 75 82 00         [24]  413 	mov	dpl, #0x00
      002A21 22               [24]  414 	ret
      002A22                        415 00121$:
                                    416 ;	keyboards/ajazz/ak820/ak820_macro.c:72: return true;
      002A22 75 82 01         [24]  417 	mov	dpl, #0x01
                                    418 ;	keyboards/ajazz/ak820/ak820_macro.c:73: }
      002A25 22               [24]  419 	ret
                                    420 ;------------------------------------------------------------
                                    421 ;Allocation info for local variables in function 'matches'
                                    422 ;------------------------------------------------------------
                                    423 ;size          Allocated with name '_matches_PARM_2'
                                    424 ;data          Allocated with name '_matches_PARM_3'
                                    425 ;offset        Allocated with name '_matches_offset_10000_89'
                                    426 ;value         Allocated with name '_matches_value_20000_91'
                                    427 ;------------------------------------------------------------
                                    428 ;	keyboards/ajazz/ak820/ak820_macro.c:75: static bool matches(uint16_t offset, uint16_t size, const uint8_t AK820_XDATA *data) {
                                    429 ;	-----------------------------------------
                                    430 ;	 function matches
                                    431 ;	-----------------------------------------
      002A26                        432 _matches:
      002A26 AF 83            [24]  433 	mov	r7,dph
      002A28 E5 82            [12]  434 	mov	a,dpl
      002A2A 90 05 0C         [24]  435 	mov	dptr,#_matches_offset_10000_89
      002A2D F0               [24]  436 	movx	@dptr,a
      002A2E EF               [12]  437 	mov	a,r7
      002A2F A3               [24]  438 	inc	dptr
      002A30 F0               [24]  439 	movx	@dptr,a
                                    440 ;	keyboards/ajazz/ak820/ak820_macro.c:76: while (size--) {
      002A31 90 05 0A         [24]  441 	mov	dptr,#_matches_PARM_3
      002A34 E0               [24]  442 	movx	a,@dptr
      002A35 FE               [12]  443 	mov	r6,a
      002A36 A3               [24]  444 	inc	dptr
      002A37 E0               [24]  445 	movx	a,@dptr
      002A38 FF               [12]  446 	mov	r7,a
      002A39 90 05 0C         [24]  447 	mov	dptr,#_matches_offset_10000_89
      002A3C E0               [24]  448 	movx	a,@dptr
      002A3D FC               [12]  449 	mov	r4,a
      002A3E A3               [24]  450 	inc	dptr
      002A3F E0               [24]  451 	movx	a,@dptr
      002A40 FD               [12]  452 	mov	r5,a
      002A41 90 05 08         [24]  453 	mov	dptr,#_matches_PARM_2
      002A44 E0               [24]  454 	movx	a,@dptr
      002A45 FA               [12]  455 	mov	r2,a
      002A46 A3               [24]  456 	inc	dptr
      002A47 E0               [24]  457 	movx	a,@dptr
      002A48 FB               [12]  458 	mov	r3,a
      002A49                        459 00103$:
      002A49 8A 00            [24]  460 	mov	ar0,r2
      002A4B 8B 01            [24]  461 	mov	ar1,r3
      002A4D 1A               [12]  462 	dec	r2
      002A4E BA FF 01         [24]  463 	cjne	r2,#0xff,00147$
      002A51 1B               [12]  464 	dec	r3
      002A52                        465 00147$:
      002A52 E8               [12]  466 	mov	a,r0
      002A53 49               [12]  467 	orl	a,r1
      002A54 60 60            [24]  468 	jz	00105$
                                    469 ;	keyboards/ajazz/ak820/ak820_macro.c:77: uint8_t value = !uploading && offset >= used_length ? 0 : macro_byte(offset);
      002A56 90 04 FC         [24]  470 	mov	dptr,#_uploading
      002A59 E0               [24]  471 	movx	a,@dptr
      002A5A 70 13            [24]  472 	jnz	00108$
      002A5C 90 04 FA         [24]  473 	mov	dptr,#_used_length
      002A5F E0               [24]  474 	movx	a,@dptr
      002A60 F8               [12]  475 	mov	r0,a
      002A61 A3               [24]  476 	inc	dptr
      002A62 E0               [24]  477 	movx	a,@dptr
      002A63 F9               [12]  478 	mov	r1,a
      002A64 C3               [12]  479 	clr	c
      002A65 EC               [12]  480 	mov	a,r4
      002A66 98               [12]  481 	subb	a,r0
      002A67 ED               [12]  482 	mov	a,r5
      002A68 99               [12]  483 	subb	a,r1
      002A69 40 04            [24]  484 	jc	00108$
      002A6B 79 00            [12]  485 	mov	r1,#0x00
      002A6D 80 23            [24]  486 	sjmp	00109$
      002A6F                        487 00108$:
      002A6F 8C 82            [24]  488 	mov	dpl, r4
      002A71 8D 83            [24]  489 	mov	dph, r5
      002A73 C0 07            [24]  490 	push	ar7
      002A75 C0 06            [24]  491 	push	ar6
      002A77 C0 05            [24]  492 	push	ar5
      002A79 C0 04            [24]  493 	push	ar4
      002A7B C0 03            [24]  494 	push	ar3
      002A7D C0 02            [24]  495 	push	ar2
      002A7F 12 28 EC         [24]  496 	lcall	_macro_byte
      002A82 A8 82            [24]  497 	mov	r0, dpl
      002A84 D0 02            [24]  498 	pop	ar2
      002A86 D0 03            [24]  499 	pop	ar3
      002A88 D0 04            [24]  500 	pop	ar4
      002A8A D0 05            [24]  501 	pop	ar5
      002A8C D0 06            [24]  502 	pop	ar6
      002A8E D0 07            [24]  503 	pop	ar7
      002A90 88 01            [24]  504 	mov	ar1,r0
      002A92                        505 00109$:
                                    506 ;	keyboards/ajazz/ak820/ak820_macro.c:78: if (value != *data++) return false;
      002A92 8E 82            [24]  507 	mov	dpl,r6
      002A94 8F 83            [24]  508 	mov	dph,r7
      002A96 E0               [24]  509 	movx	a,@dptr
      002A97 F8               [12]  510 	mov	r0,a
      002A98 A3               [24]  511 	inc	dptr
      002A99 AE 82            [24]  512 	mov	r6,dpl
      002A9B AF 83            [24]  513 	mov	r7,dph
      002A9D E9               [12]  514 	mov	a,r1
      002A9E B5 00 02         [24]  515 	cjne	a,ar0,00151$
      002AA1 80 04            [24]  516 	sjmp	00102$
      002AA3                        517 00151$:
      002AA3 75 82 00         [24]  518 	mov	dpl, #0x00
      002AA6 22               [24]  519 	ret
      002AA7                        520 00102$:
                                    521 ;	keyboards/ajazz/ak820/ak820_macro.c:79: ++offset;
      002AA7 0C               [12]  522 	inc	r4
      002AA8 BC 00 01         [24]  523 	cjne	r4,#0x00,00152$
      002AAB 0D               [12]  524 	inc	r5
      002AAC                        525 00152$:
      002AAC 90 05 0C         [24]  526 	mov	dptr,#_matches_offset_10000_89
      002AAF EC               [12]  527 	mov	a,r4
      002AB0 F0               [24]  528 	movx	@dptr,a
      002AB1 ED               [12]  529 	mov	a,r5
      002AB2 A3               [24]  530 	inc	dptr
      002AB3 F0               [24]  531 	movx	@dptr,a
      002AB4 80 93            [24]  532 	sjmp	00103$
      002AB6                        533 00105$:
                                    534 ;	keyboards/ajazz/ak820/ak820_macro.c:81: return true;
      002AB6 75 82 01         [24]  535 	mov	dpl, #0x01
                                    536 ;	keyboards/ajazz/ak820/ak820_macro.c:82: }
      002AB9 22               [24]  537 	ret
                                    538 ;------------------------------------------------------------
                                    539 ;Allocation info for local variables in function 'ak820_macro_init'
                                    540 ;------------------------------------------------------------
                                    541 ;	keyboards/ajazz/ak820/ak820_macro.c:84: void ak820_macro_init(void) {
                                    542 ;	-----------------------------------------
                                    543 ;	 function ak820_macro_init
                                    544 ;	-----------------------------------------
      002ABA                        545 _ak820_macro_init:
                                    546 ;	keyboards/ajazz/ak820/ak820_macro.c:85: covered = 0;
      002ABA 90 04 F8         [24]  547 	mov	dptr,#_covered
      002ABD E4               [12]  548 	clr	a
      002ABE F0               [24]  549 	movx	@dptr,a
      002ABF A3               [24]  550 	inc	dptr
      002AC0 F0               [24]  551 	movx	@dptr,a
                                    552 ;	keyboards/ajazz/ak820/ak820_macro.c:86: uploading = false;
      002AC1 90 04 FC         [24]  553 	mov	dptr,#_uploading
      002AC4 F0               [24]  554 	movx	@dptr,a
                                    555 ;	keyboards/ajazz/ak820/ak820_macro.c:87: parsed.terminated = parsed.arguments = 0;
      002AC5 90 04 F7         [24]  556 	mov	dptr,#(_parsed + 0x0001)
      002AC8 F0               [24]  557 	movx	@dptr,a
      002AC9 90 04 F6         [24]  558 	mov	dptr,#_parsed
      002ACC F0               [24]  559 	movx	@dptr,a
                                    560 ;	keyboards/ajazz/ak820/ak820_macro.c:88: used_length = eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_LENGTH_ADDR);
      002ACD 90 07 F1         [24]  561 	mov	dptr,#0x07f1
      002AD0 F5 F0            [12]  562 	mov	b,a
      002AD2 12 41 13         [24]  563 	lcall	_eeprom_read_byte
      002AD5 AF 82            [24]  564 	mov	r7, dpl
      002AD7 90 04 FA         [24]  565 	mov	dptr,#_used_length
      002ADA EF               [12]  566 	mov	a,r7
      002ADB F0               [24]  567 	movx	@dptr,a
      002ADC E4               [12]  568 	clr	a
      002ADD A3               [24]  569 	inc	dptr
      002ADE F0               [24]  570 	movx	@dptr,a
                                    571 ;	keyboards/ajazz/ak820/ak820_macro.c:89: used_length |= (uint16_t)eeprom_read_byte((const uint8_t *)(uintptr_t)(AK820_MACRO_LENGTH_ADDR + 1)) << 8;
      002ADF 90 07 F2         [24]  572 	mov	dptr,#0x07f2
      002AE2 F5 F0            [12]  573 	mov	b,a
      002AE4 12 41 13         [24]  574 	lcall	_eeprom_read_byte
      002AE7 AE 82            [24]  575 	mov	r6,dpl
      002AE9 7F 00            [12]  576 	mov	r7,#0x00
      002AEB 90 04 FA         [24]  577 	mov	dptr,#_used_length
      002AEE E0               [24]  578 	movx	a,@dptr
      002AEF 4F               [12]  579 	orl	a,r7
      002AF0 F0               [24]  580 	movx	@dptr,a
      002AF1 A3               [24]  581 	inc	dptr
      002AF2 E0               [24]  582 	movx	a,@dptr
      002AF3 4E               [12]  583 	orl	a,r6
      002AF4 F0               [24]  584 	movx	@dptr,a
                                    585 ;	keyboards/ajazz/ak820/ak820_macro.c:90: }
      002AF5 22               [24]  586 	ret
                                    587 ;------------------------------------------------------------
                                    588 ;Allocation info for local variables in function 'ak820_macro_ready'
                                    589 ;------------------------------------------------------------
                                    590 ;	keyboards/ajazz/ak820/ak820_macro.c:92: bool ak820_macro_ready(void) {
                                    591 ;	-----------------------------------------
                                    592 ;	 function ak820_macro_ready
                                    593 ;	-----------------------------------------
      002AF6                        594 _ak820_macro_ready:
                                    595 ;	keyboards/ajazz/ak820/ak820_macro.c:93: return ak820_nvm_ok() && used_length >= DYNAMIC_KEYMAP_MACRO_COUNT &&
      002AF6 12 3E 7C         [24]  596 	lcall	_ak820_nvm_ok
      002AF9 E5 82            [12]  597 	mov	a, dpl
      002AFB 60 25            [24]  598 	jz	00103$
      002AFD 90 04 FA         [24]  599 	mov	dptr,#_used_length
      002B00 E0               [24]  600 	movx	a,@dptr
      002B01 FE               [12]  601 	mov	r6,a
      002B02 A3               [24]  602 	inc	dptr
      002B03 E0               [24]  603 	movx	a,@dptr
      002B04 FF               [12]  604 	mov	r7,a
      002B05 C3               [12]  605 	clr	c
      002B06 EE               [12]  606 	mov	a,r6
      002B07 94 10            [12]  607 	subb	a,#0x10
      002B09 EF               [12]  608 	mov	a,r7
      002B0A 94 00            [12]  609 	subb	a,#0x00
                                    610 ;	keyboards/ajazz/ak820/ak820_macro.c:94: used_length <= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE &&
      002B0C 40 14            [24]  611 	jc	00103$
      002B0E E4               [12]  612 	clr	a
      002B0F 9E               [12]  613 	subb	a,r6
      002B10 74 20            [12]  614 	mov	a,#0x20
      002B12 9F               [12]  615 	subb	a,r7
      002B13 40 0D            [24]  616 	jc	00103$
                                    617 ;	free result
                                    618 ;	keyboards/ajazz/ak820/ak820_macro.c:95: eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR) == 0;
      002B15 90 07 F0         [24]  619 	mov	dptr,#0x07f0
      002B18 75 F0 00         [24]  620 	mov	b, #0x00
      002B1B 12 41 13         [24]  621 	lcall	_eeprom_read_byte
      002B1E E5 82            [12]  622 	mov	a, dpl
      002B20 60 04            [24]  623 	jz	00104$
      002B22                        624 00103$:
                                    625 ;	assignBit
      002B22 C2 07            [12]  626 	clr	_ak820_macro_ready_sloc0_1_0
      002B24 80 02            [24]  627 	sjmp	00105$
      002B26                        628 00104$:
                                    629 ;	assignBit
      002B26 D2 07            [12]  630 	setb	_ak820_macro_ready_sloc0_1_0
      002B28                        631 00105$:
      002B28 A2 07            [12]  632 	mov	c,_ak820_macro_ready_sloc0_1_0
      002B2A E4               [12]  633 	clr	a
      002B2B 33               [12]  634 	rlc	a
      002B2C F5 82            [12]  635 	mov	dpl, a
                                    636 ;	keyboards/ajazz/ak820/ak820_macro.c:96: }
      002B2E 22               [24]  637 	ret
                                    638 ;------------------------------------------------------------
                                    639 ;Allocation info for local variables in function 'ak820_macro_length'
                                    640 ;------------------------------------------------------------
                                    641 ;	keyboards/ajazz/ak820/ak820_macro.c:98: uint16_t ak820_macro_length(void) { return ak820_macro_ready() ? used_length : 0; }
                                    642 ;	-----------------------------------------
                                    643 ;	 function ak820_macro_length
                                    644 ;	-----------------------------------------
      002B2F                        645 _ak820_macro_length:
      002B2F 12 2A F6         [24]  646 	lcall	_ak820_macro_ready
      002B32 E5 82            [12]  647 	mov	a, dpl
      002B34 60 0A            [24]  648 	jz	00103$
      002B36 90 04 FA         [24]  649 	mov	dptr,#_used_length
      002B39 E0               [24]  650 	movx	a,@dptr
      002B3A FE               [12]  651 	mov	r6,a
      002B3B A3               [24]  652 	inc	dptr
      002B3C E0               [24]  653 	movx	a,@dptr
      002B3D FF               [12]  654 	mov	r7,a
      002B3E 80 04            [24]  655 	sjmp	00104$
      002B40                        656 00103$:
      002B40 7E 00            [12]  657 	mov	r6,#0x00
      002B42 7F 00            [12]  658 	mov	r7,#0x00
      002B44                        659 00104$:
      002B44 8E 82            [24]  660 	mov	dpl, r6
      002B46 8F 83            [24]  661 	mov	dph, r7
      002B48 22               [24]  662 	ret
                                    663 ;------------------------------------------------------------
                                    664 ;Allocation info for local variables in function 'ak820_macro_write'
                                    665 ;------------------------------------------------------------
                                    666 ;sloc0         Allocated with name '_ak820_macro_write_sloc0_1_0'
                                    667 ;size          Allocated with name '_ak820_macro_write_PARM_2'
                                    668 ;packet        Allocated with name '_ak820_macro_write_PARM_3'
                                    669 ;offset        Allocated with name '_ak820_macro_write_offset_10000_99'
                                    670 ;data          Allocated with name '_ak820_macro_write_data_10000_100'
                                    671 ;next          Allocated with name '_ak820_macro_write_next_10000_100'
                                    672 ;i             Allocated with name '_ak820_macro_write_i_10000_100'
                                    673 ;end           Allocated with name '_ak820_macro_write_end_10000_100'
                                    674 ;complete      Allocated with name '_ak820_macro_write_complete_10000_100'
                                    675 ;------------------------------------------------------------
                                    676 ;	keyboards/ajazz/ak820/ak820_macro.c:100: bool ak820_macro_write(uint16_t offset, uint16_t size, const uint8_t *packet) {
                                    677 ;	-----------------------------------------
                                    678 ;	 function ak820_macro_write
                                    679 ;	-----------------------------------------
      002B49                        680 _ak820_macro_write:
      002B49 AF 83            [24]  681 	mov	r7,dph
      002B4B E5 82            [12]  682 	mov	a,dpl
      002B4D 90 05 13         [24]  683 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B50 F0               [24]  684 	movx	@dptr,a
      002B51 EF               [12]  685 	mov	a,r7
      002B52 A3               [24]  686 	inc	dptr
      002B53 F0               [24]  687 	movx	@dptr,a
                                    688 ;	keyboards/ajazz/ak820/ak820_macro.c:103: const uint8_t AK820_XDATA *data = (const uint8_t AK820_XDATA *)packet;
      002B54 90 05 10         [24]  689 	mov	dptr,#_ak820_macro_write_PARM_3
      002B57 E0               [24]  690 	movx	a,@dptr
      002B58 FE               [12]  691 	mov	r6,a
      002B59 A3               [24]  692 	inc	dptr
      002B5A E0               [24]  693 	movx	a,@dptr
      002B5B FF               [12]  694 	mov	r7,a
                                    695 ;	keyboards/ajazz/ak820/ak820_macro.c:109: if (!ak820_nvm_ok() || !size || offset >= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE ||
      002B5C 12 3E 7C         [24]  696 	lcall	_ak820_nvm_ok
      002B5F E5 82            [12]  697 	mov	a, dpl
      002B61 60 2B            [24]  698 	jz	00101$
      002B63 90 05 0E         [24]  699 	mov	dptr,#_ak820_macro_write_PARM_2
      002B66 E0               [24]  700 	movx	a,@dptr
      002B67 FC               [12]  701 	mov	r4,a
      002B68 A3               [24]  702 	inc	dptr
      002B69 E0               [24]  703 	movx	a,@dptr
      002B6A FD               [12]  704 	mov	r5,a
      002B6B 4C               [12]  705 	orl	a,r4
      002B6C 60 20            [24]  706 	jz	00101$
      002B6E 90 05 13         [24]  707 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B71 E0               [24]  708 	movx	a,@dptr
      002B72 FA               [12]  709 	mov	r2,a
      002B73 A3               [24]  710 	inc	dptr
      002B74 E0               [24]  711 	movx	a,@dptr
      002B75 FB               [12]  712 	mov	r3,a
      002B76 8A 00            [24]  713 	mov	ar0,r2
      002B78 8B 01            [24]  714 	mov	ar1,r3
      002B7A 74 E0            [12]  715 	mov	a,#0x100 - 0x20
      002B7C 29               [12]  716 	add	a,r1
      002B7D 40 0F            [24]  717 	jc	00101$
                                    718 ;	keyboards/ajazz/ak820/ak820_macro.c:110: size > DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE - offset) return false;
      002B7F E4               [12]  719 	clr	a
      002B80 C3               [12]  720 	clr	c
      002B81 9A               [12]  721 	subb	a,r2
      002B82 F8               [12]  722 	mov	r0,a
      002B83 74 20            [12]  723 	mov	a,#0x20
      002B85 9B               [12]  724 	subb	a,r3
      002B86 F9               [12]  725 	mov	r1,a
      002B87 C3               [12]  726 	clr	c
      002B88 E8               [12]  727 	mov	a,r0
      002B89 9C               [12]  728 	subb	a,r4
      002B8A E9               [12]  729 	mov	a,r1
      002B8B 9D               [12]  730 	subb	a,r5
      002B8C 50 04            [24]  731 	jnc	00102$
                                    732 ;	free result
      002B8E                        733 00101$:
      002B8E 75 82 00         [24]  734 	mov	dpl, #0x00
      002B91 22               [24]  735 	ret
      002B92                        736 00102$:
                                    737 ;	keyboards/ajazz/ak820/ak820_macro.c:111: end = offset + size;
      002B92 EC               [12]  738 	mov	a,r4
      002B93 2A               [12]  739 	add	a, r2
      002B94 F8               [12]  740 	mov	r0,a
      002B95 ED               [12]  741 	mov	a,r5
      002B96 3B               [12]  742 	addc	a, r3
      002B97 F9               [12]  743 	mov	r1,a
                                    744 ;	keyboards/ajazz/ak820/ak820_macro.c:114: if (end <= covered && (uploading || offset || end == covered) && matches(offset, size, data)) return true;
      002B98 90 04 F8         [24]  745 	mov	dptr,#_covered
      002B9B E0               [24]  746 	movx	a,@dptr
      002B9C F5 0A            [12]  747 	mov	_ak820_macro_write_sloc0_1_0,a
      002B9E A3               [24]  748 	inc	dptr
      002B9F E0               [24]  749 	movx	a,@dptr
      002BA0 F5 0B            [12]  750 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002BA2 C3               [12]  751 	clr	c
      002BA3 E5 0A            [12]  752 	mov	a,_ak820_macro_write_sloc0_1_0
      002BA5 98               [12]  753 	subb	a,r0
      002BA6 E5 0B            [12]  754 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002BA8 99               [12]  755 	subb	a,r1
      002BA9 40 51            [24]  756 	jc	00107$
                                    757 ;	free result
      002BAB 90 04 FC         [24]  758 	mov	dptr,#_uploading
      002BAE E0               [24]  759 	movx	a,@dptr
      002BAF 70 0C            [24]  760 	jnz	00111$
      002BB1 EA               [12]  761 	mov	a,r2
      002BB2 4B               [12]  762 	orl	a,r3
      002BB3 70 08            [24]  763 	jnz	00111$
      002BB5 E8               [12]  764 	mov	a,r0
      002BB6 B5 0A 43         [24]  765 	cjne	a,_ak820_macro_write_sloc0_1_0,00107$
      002BB9 E9               [12]  766 	mov	a,r1
      002BBA B5 0B 3F         [24]  767 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00107$
      002BBD                        768 00111$:
      002BBD 90 05 13         [24]  769 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002BC0 E0               [24]  770 	movx	a,@dptr
      002BC1 FA               [12]  771 	mov	r2,a
      002BC2 A3               [24]  772 	inc	dptr
      002BC3 E0               [24]  773 	movx	a,@dptr
      002BC4 FB               [12]  774 	mov	r3,a
      002BC5 90 05 08         [24]  775 	mov	dptr,#_matches_PARM_2
      002BC8 EC               [12]  776 	mov	a,r4
      002BC9 F0               [24]  777 	movx	@dptr,a
      002BCA ED               [12]  778 	mov	a,r5
      002BCB A3               [24]  779 	inc	dptr
      002BCC F0               [24]  780 	movx	@dptr,a
      002BCD 90 05 0A         [24]  781 	mov	dptr,#_matches_PARM_3
      002BD0 EE               [12]  782 	mov	a,r6
      002BD1 F0               [24]  783 	movx	@dptr,a
      002BD2 EF               [12]  784 	mov	a,r7
      002BD3 A3               [24]  785 	inc	dptr
      002BD4 F0               [24]  786 	movx	@dptr,a
      002BD5 8A 82            [24]  787 	mov	dpl, r2
      002BD7 8B 83            [24]  788 	mov	dph, r3
      002BD9 C0 07            [24]  789 	push	ar7
      002BDB C0 06            [24]  790 	push	ar6
      002BDD C0 05            [24]  791 	push	ar5
      002BDF C0 04            [24]  792 	push	ar4
      002BE1 C0 01            [24]  793 	push	ar1
      002BE3 C0 00            [24]  794 	push	ar0
      002BE5 12 2A 26         [24]  795 	lcall	_matches
      002BE8 E5 82            [12]  796 	mov	a, dpl
      002BEA D0 00            [24]  797 	pop	ar0
      002BEC D0 01            [24]  798 	pop	ar1
      002BEE D0 04            [24]  799 	pop	ar4
      002BF0 D0 05            [24]  800 	pop	ar5
      002BF2 D0 06            [24]  801 	pop	ar6
      002BF4 D0 07            [24]  802 	pop	ar7
      002BF6 60 04            [24]  803 	jz	00107$
      002BF8 75 82 01         [24]  804 	mov	dpl, #0x01
      002BFB 22               [24]  805 	ret
      002BFC                        806 00107$:
                                    807 ;	keyboards/ajazz/ak820/ak820_macro.c:116: if (!uploading) {
      002BFC 90 04 FC         [24]  808 	mov	dptr,#_uploading
      002BFF E0               [24]  809 	movx	a,@dptr
      002C00 60 03            [24]  810 	jz	00371$
      002C02 02 2C 9D         [24]  811 	ljmp	00130$
      002C05                        812 00371$:
                                    813 ;	keyboards/ajazz/ak820/ak820_macro.c:117: if (offset) {
      002C05 90 05 13         [24]  814 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002C08 E0               [24]  815 	movx	a,@dptr
      002C09 FA               [12]  816 	mov	r2,a
      002C0A A3               [24]  817 	inc	dptr
      002C0B E0               [24]  818 	movx	a,@dptr
      002C0C FB               [12]  819 	mov	r3,a
      002C0D 90 05 13         [24]  820 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002C10 E0               [24]  821 	movx	a,@dptr
      002C11 F5 F0            [12]  822 	mov	b,a
      002C13 A3               [24]  823 	inc	dptr
      002C14 E0               [24]  824 	movx	a,@dptr
      002C15 45 F0            [12]  825 	orl	a,b
      002C17 60 78            [24]  826 	jz	00120$
                                    827 ;	keyboards/ajazz/ak820/ak820_macro.c:121: if (!covered || offset != covered || !ak820_macro_ready()) return false;
      002C19 90 04 F8         [24]  828 	mov	dptr,#_covered
      002C1C E0               [24]  829 	movx	a,@dptr
      002C1D F5 0A            [12]  830 	mov	_ak820_macro_write_sloc0_1_0,a
      002C1F A3               [24]  831 	inc	dptr
      002C20 E0               [24]  832 	movx	a,@dptr
      002C21 F5 0B            [12]  833 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002C23 90 04 F8         [24]  834 	mov	dptr,#_covered
      002C26 E0               [24]  835 	movx	a,@dptr
      002C27 F5 F0            [12]  836 	mov	b,a
      002C29 A3               [24]  837 	inc	dptr
      002C2A E0               [24]  838 	movx	a,@dptr
      002C2B 45 F0            [12]  839 	orl	a,b
      002C2D 60 27            [24]  840 	jz	00112$
      002C2F EA               [12]  841 	mov	a,r2
      002C30 B5 0A 23         [24]  842 	cjne	a,_ak820_macro_write_sloc0_1_0,00112$
      002C33 EB               [12]  843 	mov	a,r3
      002C34 B5 0B 1F         [24]  844 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00112$
      002C37 C0 07            [24]  845 	push	ar7
      002C39 C0 06            [24]  846 	push	ar6
      002C3B C0 05            [24]  847 	push	ar5
      002C3D C0 04            [24]  848 	push	ar4
      002C3F C0 01            [24]  849 	push	ar1
      002C41 C0 00            [24]  850 	push	ar0
      002C43 12 2A F6         [24]  851 	lcall	_ak820_macro_ready
      002C46 E5 82            [12]  852 	mov	a, dpl
      002C48 D0 00            [24]  853 	pop	ar0
      002C4A D0 01            [24]  854 	pop	ar1
      002C4C D0 04            [24]  855 	pop	ar4
      002C4E D0 05            [24]  856 	pop	ar5
      002C50 D0 06            [24]  857 	pop	ar6
      002C52 D0 07            [24]  858 	pop	ar7
      002C54 70 04            [24]  859 	jnz	00200$
      002C56                        860 00112$:
      002C56 75 82 00         [24]  861 	mov	dpl, #0x00
      002C59 22               [24]  862 	ret
                                    863 ;	keyboards/ajazz/ak820/ak820_macro.c:122: for (i = 0; i < size; ++i) if (data[i]) return false;
      002C5A                        864 00200$:
      002C5A 7A 00            [12]  865 	mov	r2,#0x00
      002C5C 7B 00            [12]  866 	mov	r3,#0x00
      002C5E                        867 00148$:
      002C5E C3               [12]  868 	clr	c
      002C5F EA               [12]  869 	mov	a,r2
      002C60 9C               [12]  870 	subb	a,r4
      002C61 EB               [12]  871 	mov	a,r3
      002C62 9D               [12]  872 	subb	a,r5
      002C63 50 20            [24]  873 	jnc	00118$
      002C65 C0 00            [24]  874 	push	ar0
      002C67 C0 01            [24]  875 	push	ar1
      002C69 EA               [12]  876 	mov	a,r2
      002C6A 2E               [12]  877 	add	a, r6
      002C6B F8               [12]  878 	mov	r0,a
      002C6C EB               [12]  879 	mov	a,r3
      002C6D 3F               [12]  880 	addc	a, r7
      002C6E F9               [12]  881 	mov	r1,a
      002C6F 88 82            [24]  882 	mov	dpl,r0
      002C71 89 83            [24]  883 	mov	dph,r1
      002C73 E0               [24]  884 	movx	a,@dptr
      002C74 D0 01            [24]  885 	pop	ar1
      002C76 D0 00            [24]  886 	pop	ar0
      002C78 60 04            [24]  887 	jz	00149$
      002C7A 75 82 00         [24]  888 	mov	dpl, #0x00
      002C7D 22               [24]  889 	ret
      002C7E                        890 00149$:
      002C7E 0A               [12]  891 	inc	r2
      002C7F BA 00 DC         [24]  892 	cjne	r2,#0x00,00148$
      002C82 0B               [12]  893 	inc	r3
      002C83 80 D9            [24]  894 	sjmp	00148$
      002C85                        895 00118$:
                                    896 ;	keyboards/ajazz/ak820/ak820_macro.c:123: covered = end;
      002C85 90 04 F8         [24]  897 	mov	dptr,#_covered
      002C88 E8               [12]  898 	mov	a,r0
      002C89 F0               [24]  899 	movx	@dptr,a
      002C8A E9               [12]  900 	mov	a,r1
      002C8B A3               [24]  901 	inc	dptr
      002C8C F0               [24]  902 	movx	@dptr,a
                                    903 ;	keyboards/ajazz/ak820/ak820_macro.c:124: return true;
      002C8D 75 82 01         [24]  904 	mov	dpl, #0x01
      002C90 22               [24]  905 	ret
      002C91                        906 00120$:
                                    907 ;	keyboards/ajazz/ak820/ak820_macro.c:126: next.terminated = next.arguments = 0;
      002C91 90 05 16         [24]  908 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002C94 E4               [12]  909 	clr	a
      002C95 F0               [24]  910 	movx	@dptr,a
      002C96 90 05 15         [24]  911 	mov	dptr,#_ak820_macro_write_next_10000_100
      002C99 F0               [24]  912 	movx	@dptr,a
      002C9A 02 2D 32         [24]  913 	ljmp	00208$
      002C9D                        914 00130$:
                                    915 ;	keyboards/ajazz/ak820/ak820_macro.c:128: if (offset > covered) return false; /* A hole is never old EEPROM data. */
      002C9D 90 05 13         [24]  916 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002CA0 E0               [24]  917 	movx	a,@dptr
      002CA1 FA               [12]  918 	mov	r2,a
      002CA2 A3               [24]  919 	inc	dptr
      002CA3 E0               [24]  920 	movx	a,@dptr
      002CA4 FB               [12]  921 	mov	r3,a
      002CA5 90 04 F8         [24]  922 	mov	dptr,#_covered
      002CA8 E0               [24]  923 	movx	a,@dptr
      002CA9 F5 0A            [12]  924 	mov	_ak820_macro_write_sloc0_1_0,a
      002CAB A3               [24]  925 	inc	dptr
      002CAC E0               [24]  926 	movx	a,@dptr
      002CAD F5 0B            [12]  927 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002CAF C3               [12]  928 	clr	c
      002CB0 E5 0A            [12]  929 	mov	a,_ak820_macro_write_sloc0_1_0
      002CB2 9A               [12]  930 	subb	a,r2
      002CB3 E5 0B            [12]  931 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002CB5 9B               [12]  932 	subb	a,r3
      002CB6 50 04            [24]  933 	jnc	00122$
                                    934 ;	free result
      002CB8 75 82 00         [24]  935 	mov	dpl, #0x00
      002CBB 22               [24]  936 	ret
      002CBC                        937 00122$:
                                    938 ;	keyboards/ajazz/ak820/ak820_macro.c:129: if (offset == covered) {
      002CBC EA               [12]  939 	mov	a,r2
      002CBD B5 0A 16         [24]  940 	cjne	a,_ak820_macro_write_sloc0_1_0,00127$
      002CC0 EB               [12]  941 	mov	a,r3
      002CC1 B5 0B 12         [24]  942 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00127$
                                    943 ;	keyboards/ajazz/ak820/ak820_macro.c:130: next.terminated = parsed.terminated;
      002CC4 90 04 F6         [24]  944 	mov	dptr,#_parsed
      002CC7 E0               [24]  945 	movx	a,@dptr
      002CC8 90 05 15         [24]  946 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CCB F0               [24]  947 	movx	@dptr,a
                                    948 ;	keyboards/ajazz/ak820/ak820_macro.c:131: next.arguments = parsed.arguments;
      002CCC 90 04 F7         [24]  949 	mov	dptr,#(_parsed + 0x0001)
      002CCF E0               [24]  950 	movx	a,@dptr
      002CD0 90 05 16         [24]  951 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002CD3 F0               [24]  952 	movx	@dptr,a
      002CD4 80 5C            [24]  953 	sjmp	00208$
      002CD6                        954 00127$:
                                    955 ;	keyboards/ajazz/ak820/ak820_macro.c:136: next.terminated = next.arguments = 0;
      002CD6 90 05 16         [24]  956 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002CD9 E4               [12]  957 	clr	a
      002CDA F0               [24]  958 	movx	@dptr,a
      002CDB 90 05 15         [24]  959 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CDE F0               [24]  960 	movx	@dptr,a
                                    961 ;	keyboards/ajazz/ak820/ak820_macro.c:137: for (i = 0; i < offset; ++i) if (!parse_byte(&next, macro_byte(i))) return false;
      002CDF F5 0A            [12]  962 	mov	_ak820_macro_write_sloc0_1_0,a
      002CE1 F5 0B            [12]  963 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002CE3                        964 00151$:
      002CE3 C3               [12]  965 	clr	c
      002CE4 E5 0A            [12]  966 	mov	a,_ak820_macro_write_sloc0_1_0
      002CE6 9A               [12]  967 	subb	a,r2
      002CE7 E5 0B            [12]  968 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002CE9 9B               [12]  969 	subb	a,r3
      002CEA 50 46            [24]  970 	jnc	00208$
      002CEC 85 0A 82         [24]  971 	mov	dpl, _ak820_macro_write_sloc0_1_0
      002CEF 85 0B 83         [24]  972 	mov	dph, (_ak820_macro_write_sloc0_1_0 + 1)
      002CF2 C0 07            [24]  973 	push	ar7
      002CF4 C0 06            [24]  974 	push	ar6
      002CF6 C0 05            [24]  975 	push	ar5
      002CF8 C0 04            [24]  976 	push	ar4
      002CFA C0 03            [24]  977 	push	ar3
      002CFC C0 02            [24]  978 	push	ar2
      002CFE C0 01            [24]  979 	push	ar1
      002D00 C0 00            [24]  980 	push	ar0
      002D02 12 28 EC         [24]  981 	lcall	_macro_byte
      002D05 E5 82            [12]  982 	mov	a, dpl
      002D07 90 05 05         [24]  983 	mov	dptr,#_parse_byte_PARM_2
      002D0A F0               [24]  984 	movx	@dptr,a
      002D0B 90 05 15         [24]  985 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D0E 12 29 80         [24]  986 	lcall	_parse_byte
      002D11 E5 82            [12]  987 	mov	a, dpl
      002D13 D0 00            [24]  988 	pop	ar0
      002D15 D0 01            [24]  989 	pop	ar1
      002D17 D0 02            [24]  990 	pop	ar2
      002D19 D0 03            [24]  991 	pop	ar3
      002D1B D0 04            [24]  992 	pop	ar4
      002D1D D0 05            [24]  993 	pop	ar5
      002D1F D0 06            [24]  994 	pop	ar6
      002D21 D0 07            [24]  995 	pop	ar7
      002D23 70 03            [24]  996 	jnz	00152$
      002D25 F5 82            [12]  997 	mov	dpl,a
      002D27 22               [24]  998 	ret
      002D28                        999 00152$:
      002D28 05 0A            [12] 1000 	inc	_ak820_macro_write_sloc0_1_0
      002D2A E4               [12] 1001 	clr	a
                                   1002 ;	keyboards/ajazz/ak820/ak820_macro.c:140: for (i = 0; i < size; ++i) if (!parse_byte(&next, data[i])) return false;
      002D2B B5 0A B5         [24] 1003 	cjne	a,_ak820_macro_write_sloc0_1_0,00151$
      002D2E 05 0B            [12] 1004 	inc	(_ak820_macro_write_sloc0_1_0 + 1)
      002D30 80 B1            [24] 1005 	sjmp	00151$
      002D32                       1006 00208$:
      002D32 7A 00            [12] 1007 	mov	r2,#0x00
      002D34 7B 00            [12] 1008 	mov	r3,#0x00
      002D36                       1009 00154$:
      002D36 C3               [12] 1010 	clr	c
      002D37 EA               [12] 1011 	mov	a,r2
      002D38 9C               [12] 1012 	subb	a,r4
      002D39 EB               [12] 1013 	mov	a,r3
      002D3A 9D               [12] 1014 	subb	a,r5
      002D3B 50 4A            [24] 1015 	jnc	00134$
      002D3D C0 00            [24] 1016 	push	ar0
      002D3F C0 01            [24] 1017 	push	ar1
      002D41 EA               [12] 1018 	mov	a,r2
      002D42 2E               [12] 1019 	add	a, r6
      002D43 F5 82            [12] 1020 	mov	dpl,a
      002D45 EB               [12] 1021 	mov	a,r3
      002D46 3F               [12] 1022 	addc	a, r7
      002D47 F5 83            [12] 1023 	mov	dph,a
      002D49 E0               [24] 1024 	movx	a,@dptr
      002D4A F9               [12] 1025 	mov	r1,a
      002D4B 90 05 05         [24] 1026 	mov	dptr,#_parse_byte_PARM_2
      002D4E F0               [24] 1027 	movx	@dptr,a
      002D4F 90 05 15         [24] 1028 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D52 C0 07            [24] 1029 	push	ar7
      002D54 C0 06            [24] 1030 	push	ar6
      002D56 C0 05            [24] 1031 	push	ar5
      002D58 C0 04            [24] 1032 	push	ar4
      002D5A C0 03            [24] 1033 	push	ar3
      002D5C C0 02            [24] 1034 	push	ar2
      002D5E C0 01            [24] 1035 	push	ar1
      002D60 C0 00            [24] 1036 	push	ar0
      002D62 12 29 80         [24] 1037 	lcall	_parse_byte
      002D65 E5 82            [12] 1038 	mov	a, dpl
      002D67 D0 00            [24] 1039 	pop	ar0
      002D69 D0 01            [24] 1040 	pop	ar1
      002D6B D0 02            [24] 1041 	pop	ar2
      002D6D D0 03            [24] 1042 	pop	ar3
      002D6F D0 04            [24] 1043 	pop	ar4
      002D71 D0 05            [24] 1044 	pop	ar5
      002D73 D0 06            [24] 1045 	pop	ar6
      002D75 D0 07            [24] 1046 	pop	ar7
      002D77 D0 01            [24] 1047 	pop	ar1
      002D79 D0 00            [24] 1048 	pop	ar0
      002D7B 70 03            [24] 1049 	jnz	00155$
      002D7D F5 82            [12] 1050 	mov	dpl,a
      002D7F 22               [24] 1051 	ret
      002D80                       1052 00155$:
      002D80 0A               [12] 1053 	inc	r2
      002D81 BA 00 B2         [24] 1054 	cjne	r2,#0x00,00154$
      002D84 0B               [12] 1055 	inc	r3
      002D85 80 AF            [24] 1056 	sjmp	00154$
      002D87                       1057 00134$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_macro.c:141: complete = next.terminated == DYNAMIC_KEYMAP_MACRO_COUNT;
      002D87 90 05 15         [24] 1059 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D8A E0               [24] 1060 	movx	a,@dptr
      002D8B FB               [12] 1061 	mov	r3,a
      002D8C E4               [12] 1062 	clr	a
      002D8D BB 10 01         [24] 1063 	cjne	r3,#0x10,00389$
      002D90 04               [12] 1064 	inc	a
      002D91                       1065 00389$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_macro.c:142: if (!complete && end == DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE) return false;
      002D91 F5 0A            [12] 1067 	mov	_ak820_macro_write_sloc0_1_0,a
      002D93 70 0E            [24] 1068 	jnz	00136$
      002D95 88 02            [24] 1069 	mov	ar2,r0
      002D97 89 03            [24] 1070 	mov	ar3,r1
      002D99 BA 00 07         [24] 1071 	cjne	r2,#0x00,00136$
      002D9C BB 20 04         [24] 1072 	cjne	r3,#0x20,00136$
      002D9F 75 82 00         [24] 1073 	mov	dpl, #0x00
      002DA2 22               [24] 1074 	ret
      002DA3                       1075 00136$:
                                   1076 ;	keyboards/ajazz/ak820/ak820_macro.c:144: ak820_nvm_begin();
      002DA3 C0 07            [24] 1077 	push	ar7
      002DA5 C0 06            [24] 1078 	push	ar6
      002DA7 C0 05            [24] 1079 	push	ar5
      002DA9 C0 04            [24] 1080 	push	ar4
      002DAB C0 01            [24] 1081 	push	ar1
      002DAD C0 00            [24] 1082 	push	ar0
      002DAF 12 3F F6         [24] 1083 	lcall	_ak820_nvm_begin
      002DB2 D0 00            [24] 1084 	pop	ar0
      002DB4 D0 01            [24] 1085 	pop	ar1
      002DB6 D0 04            [24] 1086 	pop	ar4
      002DB8 D0 05            [24] 1087 	pop	ar5
      002DBA D0 06            [24] 1088 	pop	ar6
      002DBC D0 07            [24] 1089 	pop	ar7
                                   1090 ;	keyboards/ajazz/ak820/ak820_macro.c:145: if (!uploading) {
      002DBE 90 04 FC         [24] 1091 	mov	dptr,#_uploading
      002DC1 E0               [24] 1092 	movx	a,@dptr
      002DC2 70 2C            [24] 1093 	jnz	00141$
                                   1094 ;	keyboards/ajazz/ak820/ak820_macro.c:147: busy_write(1);
      002DC4 75 82 01         [24] 1095 	mov	dpl, #0x01
      002DC7 C0 07            [24] 1096 	push	ar7
      002DC9 C0 06            [24] 1097 	push	ar6
      002DCB C0 05            [24] 1098 	push	ar5
      002DCD C0 04            [24] 1099 	push	ar4
      002DCF C0 01            [24] 1100 	push	ar1
      002DD1 C0 00            [24] 1101 	push	ar0
      002DD3 12 29 0C         [24] 1102 	lcall	_busy_write
      002DD6 D0 00            [24] 1103 	pop	ar0
      002DD8 D0 01            [24] 1104 	pop	ar1
      002DDA D0 04            [24] 1105 	pop	ar4
      002DDC D0 05            [24] 1106 	pop	ar5
      002DDE D0 06            [24] 1107 	pop	ar6
      002DE0 D0 07            [24] 1108 	pop	ar7
                                   1109 ;	keyboards/ajazz/ak820/ak820_macro.c:148: if (!ak820_nvm_ok()) { ak820_nvm_end(); return false; }
      002DE2 12 3E 7C         [24] 1110 	lcall	_ak820_nvm_ok
      002DE5 E5 82            [12] 1111 	mov	a, dpl
      002DE7 70 07            [24] 1112 	jnz	00141$
      002DE9 12 40 0B         [24] 1113 	lcall	_ak820_nvm_end
      002DEC 75 82 00         [24] 1114 	mov	dpl, #0x00
      002DEF 22               [24] 1115 	ret
      002DF0                       1116 00141$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_macro.c:150: ak820_eeprom_write_block_xdata(data, (void *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset), size);
      002DF0 90 05 13         [24] 1118 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002DF3 E0               [24] 1119 	movx	a,@dptr
      002DF4 FA               [12] 1120 	mov	r2,a
      002DF5 A3               [24] 1121 	inc	dptr
      002DF6 E0               [24] 1122 	movx	a,@dptr
      002DF7 24 08            [12] 1123 	add	a,#0x08
      002DF9 FB               [12] 1124 	mov	r3,a
      002DFA 90 05 8D         [24] 1125 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      002DFD EA               [12] 1126 	mov	a,r2
      002DFE F0               [24] 1127 	movx	@dptr,a
      002DFF EB               [12] 1128 	mov	a,r3
      002E00 A3               [24] 1129 	inc	dptr
      002E01 F0               [24] 1130 	movx	@dptr,a
      002E02 E4               [12] 1131 	clr	a
      002E03 A3               [24] 1132 	inc	dptr
      002E04 F0               [24] 1133 	movx	@dptr,a
      002E05 90 05 90         [24] 1134 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      002E08 EC               [12] 1135 	mov	a,r4
      002E09 F0               [24] 1136 	movx	@dptr,a
      002E0A ED               [12] 1137 	mov	a,r5
      002E0B A3               [24] 1138 	inc	dptr
      002E0C F0               [24] 1139 	movx	@dptr,a
      002E0D 8E 82            [24] 1140 	mov	dpl, r6
      002E0F 8F 83            [24] 1141 	mov	dph, r7
      002E11 C0 01            [24] 1142 	push	ar1
      002E13 C0 00            [24] 1143 	push	ar0
      002E15 12 41 DD         [24] 1144 	lcall	_ak820_eeprom_write_block_xdata
                                   1145 ;	keyboards/ajazz/ak820/ak820_macro.c:151: ak820_nvm_flush();
      002E18 12 3E 92         [24] 1146 	lcall	_ak820_nvm_flush
      002E1B D0 00            [24] 1147 	pop	ar0
      002E1D D0 01            [24] 1148 	pop	ar1
                                   1149 ;	keyboards/ajazz/ak820/ak820_macro.c:152: if (complete && ak820_nvm_ok()) commit_length(end);
      002E1F E5 0A            [12] 1150 	mov	a,_ak820_macro_write_sloc0_1_0
      002E21 60 16            [24] 1151 	jz	00143$
      002E23 12 3E 7C         [24] 1152 	lcall	_ak820_nvm_ok
      002E26 E5 82            [12] 1153 	mov	a, dpl
      002E28 60 0F            [24] 1154 	jz	00143$
      002E2A 88 82            [24] 1155 	mov	dpl, r0
      002E2C 89 83            [24] 1156 	mov	dph, r1
      002E2E C0 01            [24] 1157 	push	ar1
      002E30 C0 00            [24] 1158 	push	ar0
      002E32 12 29 23         [24] 1159 	lcall	_commit_length
      002E35 D0 00            [24] 1160 	pop	ar0
      002E37 D0 01            [24] 1161 	pop	ar1
      002E39                       1162 00143$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_macro.c:153: ak820_nvm_end();
      002E39 C0 01            [24] 1164 	push	ar1
      002E3B C0 00            [24] 1165 	push	ar0
      002E3D 12 40 0B         [24] 1166 	lcall	_ak820_nvm_end
      002E40 D0 00            [24] 1167 	pop	ar0
      002E42 D0 01            [24] 1168 	pop	ar1
                                   1169 ;	keyboards/ajazz/ak820/ak820_macro.c:154: if (!ak820_nvm_ok()) return false;
      002E44 12 3E 7C         [24] 1170 	lcall	_ak820_nvm_ok
      002E47 E5 82            [12] 1171 	mov	a, dpl
      002E49 70 03            [24] 1172 	jnz	00146$
      002E4B F5 82            [12] 1173 	mov	dpl,a
      002E4D 22               [24] 1174 	ret
      002E4E                       1175 00146$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_macro.c:155: covered = end;
      002E4E 90 04 F8         [24] 1177 	mov	dptr,#_covered
      002E51 E8               [12] 1178 	mov	a,r0
      002E52 F0               [24] 1179 	movx	@dptr,a
      002E53 E9               [12] 1180 	mov	a,r1
      002E54 A3               [24] 1181 	inc	dptr
      002E55 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	keyboards/ajazz/ak820/ak820_macro.c:156: parsed.terminated = next.terminated;
      002E56 90 05 15         [24] 1184 	mov	dptr,#_ak820_macro_write_next_10000_100
      002E59 E0               [24] 1185 	movx	a,@dptr
      002E5A 90 04 F6         [24] 1186 	mov	dptr,#_parsed
      002E5D F0               [24] 1187 	movx	@dptr,a
                                   1188 ;	keyboards/ajazz/ak820/ak820_macro.c:157: parsed.arguments = next.arguments;
      002E5E 90 05 16         [24] 1189 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002E61 E0               [24] 1190 	movx	a,@dptr
      002E62 90 04 F7         [24] 1191 	mov	dptr,#(_parsed + 0x0001)
      002E65 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	keyboards/ajazz/ak820/ak820_macro.c:158: uploading = !complete;
      002E66 90 04 FC         [24] 1194 	mov	dptr,#_uploading
      002E69 E5 0A            [12] 1195 	mov	a,_ak820_macro_write_sloc0_1_0
      002E6B B4 01 00         [24] 1196 	cjne	a,#0x01,00399$
      002E6E                       1197 00399$:
      002E6E E4               [12] 1198 	clr	a
      002E6F 33               [12] 1199 	rlc	a
      002E70 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	keyboards/ajazz/ak820/ak820_macro.c:159: return true;
      002E71 75 82 01         [24] 1202 	mov	dpl, #0x01
                                   1203 ;	keyboards/ajazz/ak820/ak820_macro.c:160: }
      002E74 22               [24] 1204 	ret
                                   1205 ;------------------------------------------------------------
                                   1206 ;Allocation info for local variables in function 'ak820_macro_reset'
                                   1207 ;------------------------------------------------------------
                                   1208 ;i             Allocated with name '_ak820_macro_reset_i_10000_127'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	keyboards/ajazz/ak820/ak820_macro.c:162: bool ak820_macro_reset(void) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function ak820_macro_reset
                                   1213 ;	-----------------------------------------
      002E75                       1214 _ak820_macro_reset:
                                   1215 ;	keyboards/ajazz/ak820/ak820_macro.c:164: ak820_nvm_begin();
      002E75 12 3F F6         [24] 1216 	lcall	_ak820_nvm_begin
                                   1217 ;	keyboards/ajazz/ak820/ak820_macro.c:165: busy_write(1);
      002E78 75 82 01         [24] 1218 	mov	dpl, #0x01
      002E7B 12 29 0C         [24] 1219 	lcall	_busy_write
                                   1220 ;	keyboards/ajazz/ak820/ak820_macro.c:166: if (ak820_nvm_ok()) {
      002E7E 12 3E 7C         [24] 1221 	lcall	_ak820_nvm_ok
      002E81 E5 82            [12] 1222 	mov	a, dpl
      002E83 60 3E            [24] 1223 	jz	00105$
                                   1224 ;	keyboards/ajazz/ak820/ak820_macro.c:167: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002E85 7E 00            [12] 1225 	mov	r6,#0x00
      002E87 7F 00            [12] 1226 	mov	r7,#0x00
      002E89                       1227 00106$:
                                   1228 ;	keyboards/ajazz/ak820/ak820_macro.c:168: eeprom_update_byte((uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + i), 0);
      002E89 8E 04            [24] 1229 	mov	ar4,r6
      002E8B 8F 05            [24] 1230 	mov	ar5,r7
      002E8D 74 08            [12] 1231 	mov	a,#0x08
      002E8F 2D               [12] 1232 	add	a, r5
      002E90 FD               [12] 1233 	mov	r5,a
      002E91 7B 00            [12] 1234 	mov	r3,#0x00
      002E93 90 06 88         [24] 1235 	mov	dptr,#_eeprom_update_byte_PARM_2
      002E96 E4               [12] 1236 	clr	a
      002E97 F0               [24] 1237 	movx	@dptr,a
      002E98 8C 82            [24] 1238 	mov	dpl, r4
      002E9A 8D 83            [24] 1239 	mov	dph, r5
      002E9C 8B F0            [24] 1240 	mov	b, r3
      002E9E 12 4D 63         [24] 1241 	lcall	_eeprom_update_byte
                                   1242 ;	keyboards/ajazz/ak820/ak820_macro.c:167: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002EA1 0E               [12] 1243 	inc	r6
      002EA2 BE 00 01         [24] 1244 	cjne	r6,#0x00,00140$
      002EA5 0F               [12] 1245 	inc	r7
      002EA6                       1246 00140$:
      002EA6 8E 04            [24] 1247 	mov	ar4,r6
      002EA8 8F 05            [24] 1248 	mov	ar5,r7
      002EAA C3               [12] 1249 	clr	c
      002EAB EC               [12] 1250 	mov	a,r4
      002EAC 94 10            [12] 1251 	subb	a,#0x10
      002EAE ED               [12] 1252 	mov	a,r5
      002EAF 94 00            [12] 1253 	subb	a,#0x00
      002EB1 40 D6            [24] 1254 	jc	00106$
                                   1255 ;	keyboards/ajazz/ak820/ak820_macro.c:169: ak820_nvm_flush();
      002EB3 12 3E 92         [24] 1256 	lcall	_ak820_nvm_flush
                                   1257 ;	keyboards/ajazz/ak820/ak820_macro.c:170: if (ak820_nvm_ok()) commit_length(DYNAMIC_KEYMAP_MACRO_COUNT);
      002EB6 12 3E 7C         [24] 1258 	lcall	_ak820_nvm_ok
      002EB9 E5 82            [12] 1259 	mov	a, dpl
      002EBB 60 06            [24] 1260 	jz	00105$
      002EBD 90 00 10         [24] 1261 	mov	dptr,#0x0010
      002EC0 12 29 23         [24] 1262 	lcall	_commit_length
      002EC3                       1263 00105$:
                                   1264 ;	keyboards/ajazz/ak820/ak820_macro.c:172: ak820_nvm_end();
      002EC3 12 40 0B         [24] 1265 	lcall	_ak820_nvm_end
                                   1266 ;	keyboards/ajazz/ak820/ak820_macro.c:173: ak820_macro_init();
      002EC6 12 2A BA         [24] 1267 	lcall	_ak820_macro_init
                                   1268 ;	keyboards/ajazz/ak820/ak820_macro.c:174: return ak820_nvm_ok();
                                   1269 ;	keyboards/ajazz/ak820/ak820_macro.c:175: }
      002EC9 02 3E 7C         [24] 1270 	ljmp	_ak820_nvm_ok
                                   1271 	.area AK820LOW(CODE)
                                   1272 	.area CONST   (CODE)
                                   1273 	.area XINIT   (CODE)
                                   1274 	.area CABS    (ABS,CODE)
