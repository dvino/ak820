                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      00041B                        555 _input_code_10000_585:
      00041B                        556 	.ds 2
      00041D                        557 _output_code_10000_587:
      00041D                        558 	.ds 2
      00041F                        559 _combos:
      00041F                        560 	.ds 32
      00043F                        561 _saved:
      00043F                        562 	.ds 9
      000448                        563 _active:
      000448                        564 	.ds 1
      000449                        565 _ak820_combo_valid_entry_10000_589:
      000449                        566 	.ds 2
      00044B                        567 _ak820_combo_reload_entry_30000_601:
      00044B                        568 	.ds 10
      000455                        569 _ak820_combo_tick_now_10000_606:
      000455                        570 	.ds 2
      000457                        571 _ak820_combo_process_record_10000_609:
      000457                        572 	.ds 2
      000459                        573 _ak820_combo_process_eligible_10001_624:
      000459                        574 	.ds 1
      00045A                        575 _ak820_combo_process_i_40001_627:
      00045A                        576 	.ds 1
      00045B                        577 _ak820_combo_process_a_50001_628:
      00045B                        578 	.ds 1
      00045C                        579 _ak820_combo_process_b_50001_628:
      00045C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000DC1                        589 _first:
      000DC1                        590 	.ds 1
      000DC2                        591 _second:
      000DC2                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      0034E3                        636 _input:
      0034E3 AF 83            [24]  637 	mov	r7,dph
      0034E5 E5 82            [12]  638 	mov	a,dpl
      0034E7 90 04 1B         [24]  639 	mov	dptr,#_input_code_10000_585
      0034EA F0               [24]  640 	movx	@dptr,a
      0034EB EF               [12]  641 	mov	a,r7
      0034EC A3               [24]  642 	inc	dptr
      0034ED F0               [24]  643 	movx	@dptr,a
      0034EE 90 04 1B         [24]  644 	mov	dptr,#_input_code_10000_585
      0034F1 E0               [24]  645 	movx	a,@dptr
      0034F2 FE               [12]  646 	mov	r6,a
      0034F3 A3               [24]  647 	inc	dptr
      0034F4 E0               [24]  648 	movx	a,@dptr
      0034F5 FF               [12]  649 	mov	r7,a
      0034F6 C3               [12]  650 	clr	c
      0034F7 EE               [12]  651 	mov	a,r6
      0034F8 94 04            [12]  652 	subb	a,#0x04
      0034FA EF               [12]  653 	mov	a,r7
      0034FB 94 00            [12]  654 	subb	a,#0x00
      0034FD 40 07            [24]  655 	jc	00103$
      0034FF 74 A4            [12]  656 	mov	a,#0xa4
      003501 9E               [12]  657 	subb	a,r6
      003502 E4               [12]  658 	clr	a
      003503 9F               [12]  659 	subb	a,r7
      003504 50 04            [24]  660 	jnc	00104$
                                    661 ;	free result
      003506                        662 00103$:
                                    663 ;	assignBit
      003506 C2 00            [12]  664 	clr	_input_sloc0_1_0
      003508 80 02            [24]  665 	sjmp	00105$
      00350A                        666 00104$:
                                    667 ;	assignBit
      00350A D2 00            [12]  668 	setb	_input_sloc0_1_0
      00350C                        669 00105$:
      00350C A2 00            [12]  670 	mov	c,_input_sloc0_1_0
      00350E E4               [12]  671 	clr	a
      00350F 33               [12]  672 	rlc	a
      003510 F5 82            [12]  673 	mov	dpl, a
      003512 22               [24]  674 	ret
                                    675 ;------------------------------------------------------------
                                    676 ;Allocation info for local variables in function 'output'
                                    677 ;------------------------------------------------------------
                                    678 ;code          Allocated with name '_output_code_10000_587'
                                    679 ;basic         Allocated with name '_output_basic_10000_588'
                                    680 ;------------------------------------------------------------
                                    681 ;	keyboards/ajazz/ak820/ak820_combo.c:10: static bool output(uint16_t code) {
                                    682 ;	-----------------------------------------
                                    683 ;	 function output
                                    684 ;	-----------------------------------------
      003513                        685 _output:
      003513 AF 83            [24]  686 	mov	r7,dph
      003515 E5 82            [12]  687 	mov	a,dpl
      003517 90 04 1D         [24]  688 	mov	dptr,#_output_code_10000_587
      00351A F0               [24]  689 	movx	@dptr,a
      00351B EF               [12]  690 	mov	a,r7
      00351C A3               [24]  691 	inc	dptr
      00351D F0               [24]  692 	movx	@dptr,a
                                    693 ;	keyboards/ajazz/ak820/ak820_combo.c:11: uint8_t basic = code;
      00351E 90 04 1D         [24]  694 	mov	dptr,#_output_code_10000_587
      003521 E0               [24]  695 	movx	a,@dptr
      003522 FE               [12]  696 	mov	r6,a
      003523 A3               [24]  697 	inc	dptr
      003524 E0               [24]  698 	movx	a,@dptr
      003525 FF               [12]  699 	mov	r7,a
      003526 8E 05            [24]  700 	mov	ar5,r6
                                    701 ;	keyboards/ajazz/ak820/ak820_combo.c:12: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      003528 74 E0            [12]  702 	mov	a,#0x100 - 0x20
      00352A 2F               [12]  703 	add	a,r7
      00352B 40 1D            [24]  704 	jc	00103$
      00352D 8D 06            [24]  705 	mov	ar6,r5
      00352F 7F 00            [12]  706 	mov	r7,#0x00
      003531 8E 82            [24]  707 	mov	dpl, r6
      003533 8F 83            [24]  708 	mov	dph, r7
      003535 C0 05            [24]  709 	push	ar5
      003537 12 34 E3         [24]  710 	lcall	_input
      00353A E5 82            [12]  711 	mov	a, dpl
      00353C D0 05            [24]  712 	pop	ar5
      00353E 70 0E            [24]  713 	jnz	00104$
      003540 BD E0 00         [24]  714 	cjne	r5,#0xe0,00135$
      003543                        715 00135$:
      003543 40 05            [24]  716 	jc	00103$
      003545 ED               [12]  717 	mov	a,r5
      003546 24 18            [12]  718 	add	a,#0xff - 0xe7
      003548 50 04            [24]  719 	jnc	00104$
                                    720 ;	free result
      00354A                        721 00103$:
                                    722 ;	assignBit
      00354A C2 01            [12]  723 	clr	_output_sloc0_1_0
      00354C 80 02            [24]  724 	sjmp	00105$
      00354E                        725 00104$:
                                    726 ;	assignBit
      00354E D2 01            [12]  727 	setb	_output_sloc0_1_0
      003550                        728 00105$:
      003550 A2 01            [12]  729 	mov	c,_output_sloc0_1_0
      003552 E4               [12]  730 	clr	a
      003553 33               [12]  731 	rlc	a
      003554 F5 82            [12]  732 	mov	dpl, a
                                    733 ;	keyboards/ajazz/ak820/ak820_combo.c:13: }
      003556 22               [24]  734 	ret
                                    735 ;------------------------------------------------------------
                                    736 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    737 ;------------------------------------------------------------
                                    738 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_589'
                                    739 ;------------------------------------------------------------
                                    740 ;	keyboards/ajazz/ak820/ak820_combo.c:19: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    741 ;	-----------------------------------------
                                    742 ;	 function ak820_combo_valid
                                    743 ;	-----------------------------------------
      003557                        744 _ak820_combo_valid:
      003557 AF 83            [24]  745 	mov	r7,dph
      003559 E5 82            [12]  746 	mov	a,dpl
      00355B 90 04 49         [24]  747 	mov	dptr,#_ak820_combo_valid_entry_10000_589
      00355E F0               [24]  748 	movx	@dptr,a
      00355F EF               [12]  749 	mov	a,r7
      003560 A3               [24]  750 	inc	dptr
      003561 F0               [24]  751 	movx	@dptr,a
                                    752 ;	keyboards/ajazz/ak820/ak820_combo.c:20: if (entry->input[2] || entry->input[3]) return false;
      003562 90 04 49         [24]  753 	mov	dptr,#_ak820_combo_valid_entry_10000_589
      003565 E0               [24]  754 	movx	a,@dptr
      003566 FE               [12]  755 	mov	r6,a
      003567 A3               [24]  756 	inc	dptr
      003568 E0               [24]  757 	movx	a,@dptr
      003569 FF               [12]  758 	mov	r7,a
      00356A 8E 82            [24]  759 	mov	dpl,r6
      00356C 8F 83            [24]  760 	mov	dph,r7
      00356E A3               [24]  761 	inc	dptr
      00356F A3               [24]  762 	inc	dptr
      003570 A3               [24]  763 	inc	dptr
      003571 A3               [24]  764 	inc	dptr
      003572 E0               [24]  765 	movx	a,@dptr
      003573 FC               [12]  766 	mov	r4,a
      003574 A3               [24]  767 	inc	dptr
      003575 E0               [24]  768 	movx	a,@dptr
      003576 4C               [12]  769 	orl	a,r4
      003577 70 10            [24]  770 	jnz	00101$
      003579 74 06            [12]  771 	mov	a,#0x06
      00357B 2E               [12]  772 	add	a, r6
      00357C F5 82            [12]  773 	mov	dpl,a
      00357E E4               [12]  774 	clr	a
      00357F 3F               [12]  775 	addc	a, r7
      003580 F5 83            [12]  776 	mov	dph,a
      003582 E0               [24]  777 	movx	a,@dptr
      003583 FC               [12]  778 	mov	r4,a
      003584 A3               [24]  779 	inc	dptr
      003585 E0               [24]  780 	movx	a,@dptr
      003586 4C               [12]  781 	orl	a,r4
      003587 60 04            [24]  782 	jz	00102$
      003589                        783 00101$:
      003589 75 82 00         [24]  784 	mov	dpl, #0x00
      00358C 22               [24]  785 	ret
      00358D                        786 00102$:
                                    787 ;	keyboards/ajazz/ak820/ak820_combo.c:21: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00358D 8E 04            [24]  788 	mov	ar4,r6
      00358F 8F 05            [24]  789 	mov	ar5,r7
      003591 8E 82            [24]  790 	mov	dpl,r6
      003593 8F 83            [24]  791 	mov	dph,r7
      003595 A3               [24]  792 	inc	dptr
      003596 A3               [24]  793 	inc	dptr
      003597 E0               [24]  794 	movx	a,@dptr
      003598 FA               [12]  795 	mov	r2,a
      003599 A3               [24]  796 	inc	dptr
      00359A E0               [24]  797 	movx	a,@dptr
      00359B FB               [12]  798 	mov	r3,a
      00359C 8C 82            [24]  799 	mov	dpl,r4
      00359E 8D 83            [24]  800 	mov	dph,r5
      0035A0 E0               [24]  801 	movx	a,@dptr
      0035A1 FC               [12]  802 	mov	r4,a
      0035A2 A3               [24]  803 	inc	dptr
      0035A3 E0               [24]  804 	movx	a,@dptr
      0035A4 FD               [12]  805 	mov	r5,a
      0035A5 EA               [12]  806 	mov	a,r2
      0035A6 4C               [12]  807 	orl	a,r4
      0035A7 F8               [12]  808 	mov	r0,a
      0035A8 EB               [12]  809 	mov	a,r3
      0035A9 4D               [12]  810 	orl	a,r5
      0035AA 48               [12]  811 	orl	a,r0
      0035AB 70 18            [24]  812 	jnz	00105$
      0035AD 74 08            [12]  813 	mov	a,#0x08
      0035AF 2E               [12]  814 	add	a, r6
      0035B0 F5 82            [12]  815 	mov	dpl,a
      0035B2 E4               [12]  816 	clr	a
      0035B3 3F               [12]  817 	addc	a, r7
      0035B4 F5 83            [12]  818 	mov	dph,a
      0035B6 E0               [24]  819 	movx	a,@dptr
      0035B7 F8               [12]  820 	mov	r0,a
      0035B8 A3               [24]  821 	inc	dptr
      0035B9 E0               [24]  822 	movx	a,@dptr
      0035BA 48               [12]  823 	orl	a,r0
      0035BB B4 01 00         [24]  824 	cjne	a,#0x01,00152$
      0035BE                        825 00152$:
      0035BE 92 02            [24]  826 	mov  _ak820_combo_valid_sloc0_1_0,c
      0035C0 E4               [12]  827 	clr	a
      0035C1 33               [12]  828 	rlc	a
      0035C2 F5 82            [12]  829 	mov	dpl, a
      0035C4 22               [24]  830 	ret
      0035C5                        831 00105$:
                                    832 ;	keyboards/ajazz/ak820/ak820_combo.c:22: if (entry->input[0] == entry->input[1]) return false;
      0035C5 EC               [12]  833 	mov	a,r4
      0035C6 B5 02 08         [24]  834 	cjne	a,ar2,00107$
      0035C9 ED               [12]  835 	mov	a,r5
      0035CA B5 03 04         [24]  836 	cjne	a,ar3,00107$
      0035CD 75 82 00         [24]  837 	mov	dpl, #0x00
      0035D0 22               [24]  838 	ret
      0035D1                        839 00107$:
                                    840 ;	keyboards/ajazz/ak820/ak820_combo.c:23: if (!input(entry->input[0])) return false;
      0035D1 8C 82            [24]  841 	mov	dpl, r4
      0035D3 8D 83            [24]  842 	mov	dph, r5
      0035D5 C0 07            [24]  843 	push	ar7
      0035D7 C0 06            [24]  844 	push	ar6
      0035D9 C0 03            [24]  845 	push	ar3
      0035DB C0 02            [24]  846 	push	ar2
      0035DD 12 34 E3         [24]  847 	lcall	_input
      0035E0 E5 82            [12]  848 	mov	a, dpl
      0035E2 D0 02            [24]  849 	pop	ar2
      0035E4 D0 03            [24]  850 	pop	ar3
      0035E6 D0 06            [24]  851 	pop	ar6
      0035E8 D0 07            [24]  852 	pop	ar7
      0035EA 70 03            [24]  853 	jnz	00109$
      0035EC F5 82            [12]  854 	mov	dpl,a
      0035EE 22               [24]  855 	ret
      0035EF                        856 00109$:
                                    857 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (!input(entry->input[1])) return false;
      0035EF 8A 82            [24]  858 	mov	dpl, r2
      0035F1 8B 83            [24]  859 	mov	dph, r3
      0035F3 C0 07            [24]  860 	push	ar7
      0035F5 C0 06            [24]  861 	push	ar6
      0035F7 12 34 E3         [24]  862 	lcall	_input
      0035FA E5 82            [12]  863 	mov	a, dpl
      0035FC D0 06            [24]  864 	pop	ar6
      0035FE D0 07            [24]  865 	pop	ar7
      003600 70 03            [24]  866 	jnz	00111$
      003602 F5 82            [12]  867 	mov	dpl,a
      003604 22               [24]  868 	ret
      003605                        869 00111$:
                                    870 ;	keyboards/ajazz/ak820/ak820_combo.c:25: return output(entry->output);
      003605 74 08            [12]  871 	mov	a,#0x08
      003607 2E               [12]  872 	add	a, r6
      003608 F5 82            [12]  873 	mov	dpl,a
      00360A E4               [12]  874 	clr	a
      00360B 3F               [12]  875 	addc	a, r7
      00360C F5 83            [12]  876 	mov	dph,a
      00360E E0               [24]  877 	movx	a,@dptr
      00360F FE               [12]  878 	mov	r6,a
      003610 A3               [24]  879 	inc	dptr
      003611 E0               [24]  880 	movx	a,@dptr
      003612 FF               [12]  881 	mov	r7,a
      003613 8E 82            [24]  882 	mov	dpl, r6
      003615 8F 83            [24]  883 	mov	dph, r7
                                    884 ;	keyboards/ajazz/ak820/ak820_combo.c:26: }
      003617 02 35 13         [24]  885 	ljmp	_output
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    888 ;------------------------------------------------------------
                                    889 ;	keyboards/ajazz/ak820/ak820_combo.c:29: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    890 ;	-----------------------------------------
                                    891 ;	 function ak820_combo_cancel
                                    892 ;	-----------------------------------------
      00361A                        893 _ak820_combo_cancel:
      00361A 90 0D C2         [24]  894 	mov	dptr,#_second
      00361D 74 FF            [12]  895 	mov	a,#0xff
      00361F F0               [24]  896 	movx	@dptr,a
      003620 90 0D C1         [24]  897 	mov	dptr,#_first
      003623 F0               [24]  898 	movx	@dptr,a
      003624 90 04 48         [24]  899 	mov	dptr,#_active
      003627 E4               [12]  900 	clr	a
      003628 F0               [24]  901 	movx	@dptr,a
      003629 22               [24]  902 	ret
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    905 ;------------------------------------------------------------
                                    906 ;i             Allocated with name '_ak820_combo_reload_i_20000_600'
                                    907 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_601'
                                    908 ;------------------------------------------------------------
                                    909 ;	keyboards/ajazz/ak820/ak820_combo.c:30: void ak820_combo_reload(void) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function ak820_combo_reload
                                    912 ;	-----------------------------------------
      00362A                        913 _ak820_combo_reload:
                                    914 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00362A 7F 00            [12]  915 	mov	r7,#0x00
      00362C                        916 00105$:
      00362C BF 08 00         [24]  917 	cjne	r7,#0x08,00131$
      00362F                        918 00131$:
      00362F 40 01            [24]  919 	jc	00132$
      003631 22               [24]  920 	ret
      003632                        921 00132$:
                                    922 ;	keyboards/ajazz/ak820/ak820_combo.c:33: combos[i].a = 0;
      003632 EF               [12]  923 	mov	a,r7
      003633 75 F0 04         [24]  924 	mov	b,#0x04
      003636 A4               [48]  925 	mul	ab
      003637 24 1F            [12]  926 	add	a, #_combos
      003639 FD               [12]  927 	mov	r5,a
      00363A 74 04            [12]  928 	mov	a,#(_combos >> 8)
      00363C 35 F0            [12]  929 	addc	a, b
      00363E FE               [12]  930 	mov	r6,a
      00363F 8D 03            [24]  931 	mov	ar3,r5
      003641 8E 04            [24]  932 	mov	ar4,r6
      003643 8B 82            [24]  933 	mov	dpl,r3
      003645 8C 83            [24]  934 	mov	dph,r4
      003647 E4               [12]  935 	clr	a
      003648 F0               [24]  936 	movx	@dptr,a
                                    937 ;	keyboards/ajazz/ak820/ak820_combo.c:34: if (!dynamic_keymap_get_combo(i, &entry)) {
      003649 90 0A DD         [24]  938 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00364C 74 4B            [12]  939 	mov	a,#_ak820_combo_reload_entry_30000_601
      00364E F0               [24]  940 	movx	@dptr,a
      00364F 74 04            [12]  941 	mov	a,#(_ak820_combo_reload_entry_30000_601 >> 8)
      003651 A3               [24]  942 	inc	dptr
      003652 F0               [24]  943 	movx	@dptr,a
      003653 E4               [12]  944 	clr	a
      003654 A3               [24]  945 	inc	dptr
      003655 F0               [24]  946 	movx	@dptr,a
      003656 8F 82            [24]  947 	mov	dpl, r7
      003658 C0 07            [24]  948 	push	ar7
      00365A C0 06            [24]  949 	push	ar6
      00365C C0 05            [24]  950 	push	ar5
      00365E C0 04            [24]  951 	push	ar4
      003660 C0 03            [24]  952 	push	ar3
      003662 12 85 F5         [24]  953 	lcall	_dynamic_keymap_get_combo
      003665 E5 82            [12]  954 	mov	a, dpl
      003667 85 83 F0         [24]  955 	mov	b, dph
      00366A D0 03            [24]  956 	pop	ar3
      00366C D0 04            [24]  957 	pop	ar4
      00366E D0 05            [24]  958 	pop	ar5
      003670 D0 06            [24]  959 	pop	ar6
      003672 D0 07            [24]  960 	pop	ar7
      003674 45 F0            [12]  961 	orl	a,b
      003676 70 31            [24]  962 	jnz	00106$
                                    963 ;	keyboards/ajazz/ak820/ak820_combo.c:35: combos[i].a = entry.input[0];
      003678 90 04 4B         [24]  964 	mov	dptr,#_ak820_combo_reload_entry_30000_601
      00367B E0               [24]  965 	movx	a,@dptr
      00367C 8B 82            [24]  966 	mov	dpl,r3
      00367E 8C 83            [24]  967 	mov	dph,r4
      003680 F0               [24]  968 	movx	@dptr,a
                                    969 ;	keyboards/ajazz/ak820/ak820_combo.c:36: combos[i].b = entry.input[1];
      003681 74 01            [12]  970 	mov	a,#0x01
      003683 2D               [12]  971 	add	a, r5
      003684 FB               [12]  972 	mov	r3,a
      003685 E4               [12]  973 	clr	a
      003686 3E               [12]  974 	addc	a, r6
      003687 FC               [12]  975 	mov	r4,a
      003688 90 04 4D         [24]  976 	mov	dptr,#(_ak820_combo_reload_entry_30000_601 + 0x0002)
      00368B E0               [24]  977 	movx	a,@dptr
      00368C 8B 82            [24]  978 	mov	dpl,r3
      00368E 8C 83            [24]  979 	mov	dph,r4
      003690 F0               [24]  980 	movx	@dptr,a
                                    981 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].output = entry.output;
      003691 74 02            [12]  982 	mov	a,#0x02
      003693 2D               [12]  983 	add	a, r5
      003694 FD               [12]  984 	mov	r5,a
      003695 E4               [12]  985 	clr	a
      003696 3E               [12]  986 	addc	a, r6
      003697 FE               [12]  987 	mov	r6,a
      003698 90 04 53         [24]  988 	mov	dptr,#(_ak820_combo_reload_entry_30000_601 + 0x0008)
      00369B E0               [24]  989 	movx	a,@dptr
      00369C FB               [12]  990 	mov	r3,a
      00369D A3               [24]  991 	inc	dptr
      00369E E0               [24]  992 	movx	a,@dptr
      00369F FC               [12]  993 	mov	r4,a
      0036A0 8D 82            [24]  994 	mov	dpl,r5
      0036A2 8E 83            [24]  995 	mov	dph,r6
      0036A4 EB               [12]  996 	mov	a,r3
      0036A5 F0               [24]  997 	movx	@dptr,a
      0036A6 EC               [12]  998 	mov	a,r4
      0036A7 A3               [24]  999 	inc	dptr
      0036A8 F0               [24] 1000 	movx	@dptr,a
      0036A9                       1001 00106$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036A9 0F               [12] 1003 	inc	r7
                                   1004 ;	keyboards/ajazz/ak820/ak820_combo.c:40: }
      0036AA 02 36 2C         [24] 1005 	ljmp	00105$
                                   1006 ;------------------------------------------------------------
                                   1007 ;Allocation info for local variables in function 'flush'
                                   1008 ;------------------------------------------------------------
                                   1009 ;	keyboards/ajazz/ak820/ak820_combo.c:41: static void flush(void) {
                                   1010 ;	-----------------------------------------
                                   1011 ;	 function flush
                                   1012 ;	-----------------------------------------
      0036AD                       1013 _flush:
                                   1014 ;	keyboards/ajazz/ak820/ak820_combo.c:42: first = NONE;
      0036AD 90 0D C1         [24] 1015 	mov	dptr,#_first
      0036B0 74 FF            [12] 1016 	mov	a,#0xff
      0036B2 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_combo.c:43: process_record(&saved);
      0036B3 90 04 3F         [24] 1019 	mov	dptr,#_saved
      0036B6 75 F0 00         [24] 1020 	mov	b, #0x00
                                   1021 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0036B9 02 71 16         [24] 1022 	ljmp	_process_record
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'ak820_combo_tick'
                                   1025 ;------------------------------------------------------------
                                   1026 ;now           Allocated with name '_ak820_combo_tick_now_10000_606'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	keyboards/ajazz/ak820/ak820_combo.c:45: void ak820_combo_tick(uint16_t now) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function ak820_combo_tick
                                   1031 ;	-----------------------------------------
      0036BC                       1032 _ak820_combo_tick:
      0036BC AF 83            [24] 1033 	mov	r7,dph
      0036BE E5 82            [12] 1034 	mov	a,dpl
      0036C0 90 04 55         [24] 1035 	mov	dptr,#_ak820_combo_tick_now_10000_606
      0036C3 F0               [24] 1036 	movx	@dptr,a
      0036C4 EF               [12] 1037 	mov	a,r7
      0036C5 A3               [24] 1038 	inc	dptr
      0036C6 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_combo.c:46: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= 40) flush();
      0036C7 90 0D C1         [24] 1041 	mov	dptr,#_first
      0036CA E0               [24] 1042 	movx	a,@dptr
      0036CB FF               [12] 1043 	mov	r7,a
      0036CC BF FF 01         [24] 1044 	cjne	r7,#0xff,00128$
      0036CF 22               [24] 1045 	ret
      0036D0                       1046 00128$:
      0036D0 90 04 48         [24] 1047 	mov	dptr,#_active
      0036D3 E0               [24] 1048 	movx	a,@dptr
      0036D4 70 23            [24] 1049 	jnz	00105$
      0036D6 90 04 41         [24] 1050 	mov	dptr,#(_saved + 0x0002)
      0036D9 E0               [24] 1051 	movx	a,@dptr
      0036DA FE               [12] 1052 	mov	r6,a
      0036DB A3               [24] 1053 	inc	dptr
      0036DC E0               [24] 1054 	movx	a,@dptr
      0036DD FF               [12] 1055 	mov	r7,a
      0036DE 90 04 55         [24] 1056 	mov	dptr,#_ak820_combo_tick_now_10000_606
      0036E1 E0               [24] 1057 	movx	a,@dptr
      0036E2 FC               [12] 1058 	mov	r4,a
      0036E3 A3               [24] 1059 	inc	dptr
      0036E4 E0               [24] 1060 	movx	a,@dptr
      0036E5 FD               [12] 1061 	mov	r5,a
      0036E6 EC               [12] 1062 	mov	a,r4
      0036E7 C3               [12] 1063 	clr	c
      0036E8 9E               [12] 1064 	subb	a,r6
      0036E9 FE               [12] 1065 	mov	r6,a
      0036EA ED               [12] 1066 	mov	a,r5
      0036EB 9F               [12] 1067 	subb	a,r7
      0036EC FF               [12] 1068 	mov	r7,a
      0036ED C3               [12] 1069 	clr	c
      0036EE EE               [12] 1070 	mov	a,r6
      0036EF 94 28            [12] 1071 	subb	a,#0x28
      0036F1 EF               [12] 1072 	mov	a,r7
      0036F2 94 00            [12] 1073 	subb	a,#0x00
      0036F4 40 03            [24] 1074 	jc	00105$
                                   1075 ;	keyboards/ajazz/ak820/ak820_combo.c:47: }
      0036F6 02 36 AD         [24] 1076 	ljmp	_flush
      0036F9                       1077 00105$:
      0036F9 22               [24] 1078 	ret
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'ak820_combo_process'
                                   1081 ;------------------------------------------------------------
                                   1082 ;record        Allocated with name '_ak820_combo_process_record_10000_609'
                                   1083 ;id            Allocated with name '_ak820_combo_process_id_10000_610'
                                   1084 ;code          Allocated with name '_ak820_combo_process_code_10000_610'
                                   1085 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_624'
                                   1086 ;previous      Allocated with name '_ak820_combo_process_previous_30001_626'
                                   1087 ;i             Allocated with name '_ak820_combo_process_i_40001_627'
                                   1088 ;a             Allocated with name '_ak820_combo_process_a_50001_628'
                                   1089 ;b             Allocated with name '_ak820_combo_process_b_50001_628'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:48: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function ak820_combo_process
                                   1094 ;	-----------------------------------------
      0036FA                       1095 _ak820_combo_process:
      0036FA AF 83            [24] 1096 	mov	r7,dph
      0036FC E5 82            [12] 1097 	mov	a,dpl
      0036FE 90 04 57         [24] 1098 	mov	dptr,#_ak820_combo_process_record_10000_609
      003701 F0               [24] 1099 	movx	@dptr,a
      003702 EF               [12] 1100 	mov	a,r7
      003703 A3               [24] 1101 	inc	dptr
      003704 F0               [24] 1102 	movx	@dptr,a
                                   1103 ;	keyboards/ajazz/ak820/ak820_combo.c:49: uint8_t id, code = record->keycode;
      003705 90 04 57         [24] 1104 	mov	dptr,#_ak820_combo_process_record_10000_609
      003708 E0               [24] 1105 	movx	a,@dptr
      003709 FE               [12] 1106 	mov	r6,a
      00370A A3               [24] 1107 	inc	dptr
      00370B E0               [24] 1108 	movx	a,@dptr
      00370C FF               [12] 1109 	mov	r7,a
      00370D 74 07            [12] 1110 	mov	a,#0x07
      00370F 2E               [12] 1111 	add	a, r6
      003710 F5 82            [12] 1112 	mov	dpl,a
      003712 E4               [12] 1113 	clr	a
      003713 3F               [12] 1114 	addc	a, r7
      003714 F5 83            [12] 1115 	mov	dph,a
      003716 E0               [24] 1116 	movx	a,@dptr
      003717 FC               [12] 1117 	mov	r4,a
      003718 A3               [24] 1118 	inc	dptr
      003719 E0               [24] 1119 	movx	a,@dptr
      00371A FD               [12] 1120 	mov	r5,a
      00371B 8C 03            [24] 1121 	mov	ar3,r4
                                   1122 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (IS_NOEVENT(record->event)) return true;
      00371D 74 04            [12] 1123 	mov	a,#0x04
      00371F 2E               [12] 1124 	add	a, r6
      003720 F9               [12] 1125 	mov	r1,a
      003721 E4               [12] 1126 	clr	a
      003722 3F               [12] 1127 	addc	a, r7
      003723 FA               [12] 1128 	mov	r2,a
      003724 89 82            [24] 1129 	mov	dpl,r1
      003726 8A 83            [24] 1130 	mov	dph,r2
      003728 E0               [24] 1131 	movx	a,@dptr
      003729 70 04            [24] 1132 	jnz	00102$
      00372B 75 82 01         [24] 1133 	mov	dpl, #0x01
      00372E 22               [24] 1134 	ret
      00372F                       1135 00102$:
                                   1136 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00372F 8E 82            [24] 1137 	mov	dpl,r6
      003731 8F 83            [24] 1138 	mov	dph,r7
      003733 A3               [24] 1139 	inc	dptr
      003734 E0               [24] 1140 	movx	a,@dptr
      003735 FA               [12] 1141 	mov	r2,a
      003736 BA 10 00         [24] 1142 	cjne	r2,#0x10,00300$
      003739                       1143 00300$:
      003739 50 0B            [24] 1144 	jnc	00106$
      00373B 8E 82            [24] 1145 	mov	dpl,r6
      00373D 8F 83            [24] 1146 	mov	dph,r7
      00373F E0               [24] 1147 	movx	a,@dptr
      003740 F9               [12] 1148 	mov	r1,a
      003741 B9 08 00         [24] 1149 	cjne	r1,#0x08,00302$
      003744                       1150 00302$:
      003744 40 17            [24] 1151 	jc	00107$
      003746                       1152 00106$:
                                   1153 ;	keyboards/ajazz/ak820/ak820_combo.c:53: if (first != NONE && !active) flush();
      003746 90 0D C1         [24] 1154 	mov	dptr,#_first
      003749 E0               [24] 1155 	movx	a,@dptr
      00374A F8               [12] 1156 	mov	r0,a
      00374B B8 FF 02         [24] 1157 	cjne	r0,#0xff,00304$
      00374E 80 09            [24] 1158 	sjmp	00104$
      003750                       1159 00304$:
      003750 90 04 48         [24] 1160 	mov	dptr,#_active
      003753 E0               [24] 1161 	movx	a,@dptr
      003754 70 03            [24] 1162 	jnz	00104$
      003756 12 36 AD         [24] 1163 	lcall	_flush
      003759                       1164 00104$:
                                   1165 ;	keyboards/ajazz/ak820/ak820_combo.c:54: return true;
      003759 75 82 01         [24] 1166 	mov	dpl, #0x01
      00375C 22               [24] 1167 	ret
      00375D                       1168 00107$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_combo.c:56: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      00375D EA               [12] 1170 	mov	a,r2
      00375E C4               [12] 1171 	swap	a
      00375F 03               [12] 1172 	rr	a
      003760 54 F8            [12] 1173 	anl	a,#0xf8
      003762 29               [12] 1174 	add	a,r1
      003763 FA               [12] 1175 	mov	r2,a
                                   1176 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (active) {
      003764 90 04 48         [24] 1177 	mov	dptr,#_active
      003767 E0               [24] 1178 	movx	a,@dptr
      003768 60 77            [24] 1179 	jz	00123$
                                   1180 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (id != first && id != second) return true;
      00376A 90 0D C1         [24] 1181 	mov	dptr,#_first
      00376D E0               [24] 1182 	movx	a,@dptr
      00376E F9               [12] 1183 	mov	r1,a
      00376F EA               [12] 1184 	mov	a,r2
      003770 B5 01 02         [24] 1185 	cjne	a,ar1,00307$
      003773 80 0F            [24] 1186 	sjmp	00110$
      003775                       1187 00307$:
      003775 90 0D C2         [24] 1188 	mov	dptr,#_second
      003778 E0               [24] 1189 	movx	a,@dptr
      003779 F9               [12] 1190 	mov	r1,a
      00377A EA               [12] 1191 	mov	a,r2
      00377B B5 01 02         [24] 1192 	cjne	a,ar1,00308$
      00377E 80 04            [24] 1193 	sjmp	00110$
      003780                       1194 00308$:
      003780 75 82 01         [24] 1195 	mov	dpl, #0x01
      003783 22               [24] 1196 	ret
      003784                       1197 00110$:
                                   1198 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (!record->event.pressed) {
      003784 90 04 57         [24] 1199 	mov	dptr,#_ak820_combo_process_record_10000_609
      003787 E0               [24] 1200 	movx	a,@dptr
      003788 F8               [12] 1201 	mov	r0,a
      003789 A3               [24] 1202 	inc	dptr
      00378A E0               [24] 1203 	movx	a,@dptr
      00378B F9               [12] 1204 	mov	r1,a
      00378C 74 05            [12] 1205 	mov	a,#0x05
      00378E 28               [12] 1206 	add	a, r0
      00378F F8               [12] 1207 	mov	r0,a
      003790 E4               [12] 1208 	clr	a
      003791 39               [12] 1209 	addc	a, r1
      003792 F9               [12] 1210 	mov	r1,a
      003793 88 82            [24] 1211 	mov	dpl,r0
      003795 89 83            [24] 1212 	mov	dph,r1
      003797 E0               [24] 1213 	movx	a,@dptr
      003798 70 43            [24] 1214 	jnz	00121$
                                   1215 ;	keyboards/ajazz/ak820/ak820_combo.c:60: if (saved.event.pressed) {
      00379A 90 04 44         [24] 1216 	mov	dptr,#(_saved + 0x0005)
      00379D E0               [24] 1217 	movx	a,@dptr
      00379E 60 11            [24] 1218 	jz	00113$
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:61: saved.event.pressed = false;
      0037A0 90 04 44         [24] 1220 	mov	dptr,#(_saved + 0x0005)
      0037A3 E4               [12] 1221 	clr	a
      0037A4 F0               [24] 1222 	movx	@dptr,a
                                   1223 ;	keyboards/ajazz/ak820/ak820_combo.c:62: process_record(&saved);
      0037A5 90 04 3F         [24] 1224 	mov	dptr,#_saved
      0037A8 F5 F0            [12] 1225 	mov	b,a
      0037AA C0 02            [24] 1226 	push	ar2
      0037AC 12 71 16         [24] 1227 	lcall	_process_record
      0037AF D0 02            [24] 1228 	pop	ar2
      0037B1                       1229 00113$:
                                   1230 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id == first) first = NONE;
      0037B1 90 0D C1         [24] 1231 	mov	dptr,#_first
      0037B4 E0               [24] 1232 	movx	a,@dptr
      0037B5 F9               [12] 1233 	mov	r1,a
      0037B6 EA               [12] 1234 	mov	a,r2
      0037B7 B5 01 08         [24] 1235 	cjne	a,ar1,00115$
      0037BA 90 0D C1         [24] 1236 	mov	dptr,#_first
      0037BD 74 FF            [12] 1237 	mov	a,#0xff
      0037BF F0               [24] 1238 	movx	@dptr,a
      0037C0 80 06            [24] 1239 	sjmp	00116$
      0037C2                       1240 00115$:
                                   1241 ;	keyboards/ajazz/ak820/ak820_combo.c:65: else second = NONE;
      0037C2 90 0D C2         [24] 1242 	mov	dptr,#_second
      0037C5 74 FF            [12] 1243 	mov	a,#0xff
      0037C7 F0               [24] 1244 	movx	@dptr,a
      0037C8                       1245 00116$:
                                   1246 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (first == NONE && second == NONE) active = false;
      0037C8 90 0D C1         [24] 1247 	mov	dptr,#_first
      0037CB E0               [24] 1248 	movx	a,@dptr
      0037CC F9               [12] 1249 	mov	r1,a
      0037CD B9 FF 0D         [24] 1250 	cjne	r1,#0xff,00121$
      0037D0 90 0D C2         [24] 1251 	mov	dptr,#_second
      0037D3 E0               [24] 1252 	movx	a,@dptr
      0037D4 F9               [12] 1253 	mov	r1,a
      0037D5 B9 FF 05         [24] 1254 	cjne	r1,#0xff,00121$
      0037D8 90 04 48         [24] 1255 	mov	dptr,#_active
      0037DB E4               [12] 1256 	clr	a
      0037DC F0               [24] 1257 	movx	@dptr,a
      0037DD                       1258 00121$:
                                   1259 ;	keyboards/ajazz/ak820/ak820_combo.c:68: return false;
      0037DD 75 82 00         [24] 1260 	mov	dpl, #0x00
      0037E0 22               [24] 1261 	ret
      0037E1                       1262 00123$:
                                   1263 ;	keyboards/ajazz/ak820/ak820_combo.c:70: bool eligible = false;
      0037E1 90 04 59         [24] 1264 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      0037E4 E4               [12] 1265 	clr	a
      0037E5 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	keyboards/ajazz/ak820/ak820_combo.c:71: if (record->event.pressed && input(record->keycode)) {
      0037E6 74 05            [12] 1268 	mov	a,#0x05
      0037E8 2E               [12] 1269 	add	a, r6
      0037E9 FE               [12] 1270 	mov	r6,a
      0037EA E4               [12] 1271 	clr	a
      0037EB 3F               [12] 1272 	addc	a, r7
      0037EC FF               [12] 1273 	mov	r7,a
      0037ED 8E 82            [24] 1274 	mov	dpl,r6
      0037EF 8F 83            [24] 1275 	mov	dph,r7
      0037F1 E0               [24] 1276 	movx	a,@dptr
      0037F2 70 03            [24] 1277 	jnz	00317$
      0037F4 02 38 BE         [24] 1278 	ljmp	00134$
      0037F7                       1279 00317$:
      0037F7 8C 82            [24] 1280 	mov	dpl, r4
      0037F9 8D 83            [24] 1281 	mov	dph, r5
      0037FB C0 03            [24] 1282 	push	ar3
      0037FD C0 02            [24] 1283 	push	ar2
      0037FF 12 34 E3         [24] 1284 	lcall	_input
      003802 E5 82            [12] 1285 	mov	a, dpl
      003804 D0 02            [24] 1286 	pop	ar2
      003806 D0 03            [24] 1287 	pop	ar3
      003808 70 03            [24] 1288 	jnz	00318$
      00380A 02 38 BE         [24] 1289 	ljmp	00134$
      00380D                       1290 00318$:
                                   1291 ;	keyboards/ajazz/ak820/ak820_combo.c:72: uint8_t previous = saved.keycode;
      00380D 90 04 46         [24] 1292 	mov	dptr,#(_saved + 0x0007)
      003810 E0               [24] 1293 	movx	a,@dptr
      003811 FF               [12] 1294 	mov	r7,a
                                   1295 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003812 90 04 5A         [24] 1296 	mov	dptr,#_ak820_combo_process_i_40001_627
      003815 E4               [12] 1297 	clr	a
      003816 F0               [24] 1298 	movx	@dptr,a
      003817 EB               [12] 1299 	mov	a,r3
      003818 B5 07 03         [24] 1300 	cjne	a,ar7,00319$
      00381B D3               [12] 1301 	setb	c
      00381C 80 01            [24] 1302 	sjmp	00320$
      00381E                       1303 00319$:
      00381E C3               [12] 1304 	clr	c
      00381F                       1305 00320$:
      00381F 92 03            [24] 1306 	mov	_ak820_combo_process_sloc0_1_0,c
      003821 7E 00            [12] 1307 	mov	r6,#0x00
      003823                       1308 00141$:
      003823 BE 08 00         [24] 1309 	cjne	r6,#0x08,00321$
      003826                       1310 00321$:
      003826 40 03            [24] 1311 	jc	00322$
      003828 02 38 BE         [24] 1312 	ljmp	00134$
      00382B                       1313 00322$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_combo.c:74: uint8_t a = combos[i].a, b = combos[i].b;
      00382B EE               [12] 1315 	mov	a,r6
      00382C 75 F0 04         [24] 1316 	mov	b,#0x04
      00382F A4               [48] 1317 	mul	ab
      003830 24 1F            [12] 1318 	add	a, #_combos
      003832 FC               [12] 1319 	mov	r4,a
      003833 74 04            [12] 1320 	mov	a,#(_combos >> 8)
      003835 35 F0            [12] 1321 	addc	a, b
      003837 FD               [12] 1322 	mov	r5,a
      003838 8C 82            [24] 1323 	mov	dpl,r4
      00383A 8D 83            [24] 1324 	mov	dph,r5
      00383C E0               [24] 1325 	movx	a,@dptr
      00383D F9               [12] 1326 	mov	r1,a
      00383E 90 04 5B         [24] 1327 	mov	dptr,#_ak820_combo_process_a_50001_628
      003841 F0               [24] 1328 	movx	@dptr,a
      003842 8C 82            [24] 1329 	mov	dpl,r4
      003844 8D 83            [24] 1330 	mov	dph,r5
      003846 A3               [24] 1331 	inc	dptr
      003847 E0               [24] 1332 	movx	a,@dptr
      003848 FD               [12] 1333 	mov	r5,a
      003849 90 04 5C         [24] 1334 	mov	dptr,#_ak820_combo_process_b_50001_628
      00384C F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (a == code || b == code) {
      00384D E9               [12] 1337 	mov	a,r1
      00384E B5 03 02         [24] 1338 	cjne	a,ar3,00323$
      003851 80 04            [24] 1339 	sjmp	00129$
      003853                       1340 00323$:
      003853 ED               [12] 1341 	mov	a,r5
      003854 B5 03 5E         [24] 1342 	cjne	a,ar3,00142$
      003857                       1343 00129$:
                                   1344 ;	keyboards/ajazz/ak820/ak820_combo.c:76: eligible = true;
      003857 90 04 59         [24] 1345 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      00385A 74 01            [12] 1346 	mov	a,#0x01
      00385C F0               [24] 1347 	movx	@dptr,a
                                   1348 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (first != NONE && code != previous && (a == previous || b == previous)) {
      00385D 90 0D C1         [24] 1349 	mov	dptr,#_first
      003860 E0               [24] 1350 	movx	a,@dptr
      003861 FD               [12] 1351 	mov	r5,a
      003862 BD FF 02         [24] 1352 	cjne	r5,#0xff,00326$
      003865 80 4E            [24] 1353 	sjmp	00142$
      003867                       1354 00326$:
      003867 20 03 4B         [24] 1355 	jb	_ak820_combo_process_sloc0_1_0,00142$
      00386A 90 04 5B         [24] 1356 	mov	dptr,#_ak820_combo_process_a_50001_628
      00386D E0               [24] 1357 	movx	a,@dptr
      00386E B5 07 02         [24] 1358 	cjne	a,ar7,00328$
      003871 80 07            [24] 1359 	sjmp	00124$
      003873                       1360 00328$:
      003873 90 04 5C         [24] 1361 	mov	dptr,#_ak820_combo_process_b_50001_628
      003876 E0               [24] 1362 	movx	a,@dptr
      003877 B5 07 3B         [24] 1363 	cjne	a,ar7,00142$
      00387A                       1364 00124$:
                                   1365 ;	keyboards/ajazz/ak820/ak820_combo.c:78: second = id;
      00387A 90 0D C2         [24] 1366 	mov	dptr,#_second
      00387D EA               [12] 1367 	mov	a,r2
      00387E F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	keyboards/ajazz/ak820/ak820_combo.c:79: active = true;
      00387F 90 04 48         [24] 1370 	mov	dptr,#_active
      003882 74 01            [12] 1371 	mov	a,#0x01
      003884 F0               [24] 1372 	movx	@dptr,a
                                   1373 ;	keyboards/ajazz/ak820/ak820_combo.c:80: saved.keycode = combos[i].output;
      003885 90 04 5A         [24] 1374 	mov	dptr,#_ak820_combo_process_i_40001_627
      003888 E0               [24] 1375 	movx	a,@dptr
      003889 75 F0 04         [24] 1376 	mov	b,#0x04
      00388C A4               [48] 1377 	mul	ab
      00388D 24 1F            [12] 1378 	add	a, #_combos
      00388F FC               [12] 1379 	mov	r4,a
      003890 74 04            [12] 1380 	mov	a,#(_combos >> 8)
      003892 35 F0            [12] 1381 	addc	a, b
      003894 FD               [12] 1382 	mov	r5,a
      003895 8C 82            [24] 1383 	mov	dpl,r4
      003897 8D 83            [24] 1384 	mov	dph,r5
      003899 A3               [24] 1385 	inc	dptr
      00389A A3               [24] 1386 	inc	dptr
      00389B E0               [24] 1387 	movx	a,@dptr
      00389C FC               [12] 1388 	mov	r4,a
      00389D A3               [24] 1389 	inc	dptr
      00389E E0               [24] 1390 	movx	a,@dptr
      00389F FD               [12] 1391 	mov	r5,a
      0038A0 90 04 46         [24] 1392 	mov	dptr,#(_saved + 0x0007)
      0038A3 EC               [12] 1393 	mov	a,r4
      0038A4 F0               [24] 1394 	movx	@dptr,a
      0038A5 ED               [12] 1395 	mov	a,r5
      0038A6 A3               [24] 1396 	inc	dptr
      0038A7 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	keyboards/ajazz/ak820/ak820_combo.c:81: process_record(&saved);
      0038A8 90 04 3F         [24] 1399 	mov	dptr,#_saved
      0038AB 75 F0 00         [24] 1400 	mov	b, #0x00
      0038AE 12 71 16         [24] 1401 	lcall	_process_record
                                   1402 ;	keyboards/ajazz/ak820/ak820_combo.c:82: return false;
      0038B1 75 82 00         [24] 1403 	mov	dpl, #0x00
      0038B4 22               [24] 1404 	ret
      0038B5                       1405 00142$:
                                   1406 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0038B5 0E               [12] 1407 	inc	r6
      0038B6 90 04 5A         [24] 1408 	mov	dptr,#_ak820_combo_process_i_40001_627
      0038B9 EE               [12] 1409 	mov	a,r6
      0038BA F0               [24] 1410 	movx	@dptr,a
      0038BB 02 38 23         [24] 1411 	ljmp	00141$
      0038BE                       1412 00134$:
                                   1413 ;	keyboards/ajazz/ak820/ak820_combo.c:87: if (first != NONE) flush();
      0038BE 90 0D C1         [24] 1414 	mov	dptr,#_first
      0038C1 E0               [24] 1415 	movx	a,@dptr
      0038C2 FF               [12] 1416 	mov	r7,a
      0038C3 BF FF 02         [24] 1417 	cjne	r7,#0xff,00331$
      0038C6 80 07            [24] 1418 	sjmp	00137$
      0038C8                       1419 00331$:
      0038C8 C0 02            [24] 1420 	push	ar2
      0038CA 12 36 AD         [24] 1421 	lcall	_flush
      0038CD D0 02            [24] 1422 	pop	ar2
      0038CF                       1423 00137$:
                                   1424 ;	keyboards/ajazz/ak820/ak820_combo.c:88: if (eligible) {
      0038CF 90 04 59         [24] 1425 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      0038D2 E0               [24] 1426 	movx	a,@dptr
      0038D3 60 2F            [24] 1427 	jz	00139$
                                   1428 ;	keyboards/ajazz/ak820/ak820_combo.c:89: first = id;
      0038D5 90 0D C1         [24] 1429 	mov	dptr,#_first
      0038D8 EA               [12] 1430 	mov	a,r2
      0038D9 F0               [24] 1431 	movx	@dptr,a
                                   1432 ;	keyboards/ajazz/ak820/ak820_combo.c:90: saved = *record;
      0038DA 90 04 57         [24] 1433 	mov	dptr,#_ak820_combo_process_record_10000_609
      0038DD E0               [24] 1434 	movx	a,@dptr
      0038DE FD               [12] 1435 	mov	r5,a
      0038DF A3               [24] 1436 	inc	dptr
      0038E0 E0               [24] 1437 	movx	a,@dptr
      0038E1 FE               [12] 1438 	mov	r6,a
      0038E2 7F 00            [12] 1439 	mov	r7,#0x00
      0038E4 90 0D B3         [24] 1440 	mov	dptr,#___memcpy_PARM_2
      0038E7 ED               [12] 1441 	mov	a,r5
      0038E8 F0               [24] 1442 	movx	@dptr,a
      0038E9 EE               [12] 1443 	mov	a,r6
      0038EA A3               [24] 1444 	inc	dptr
      0038EB F0               [24] 1445 	movx	@dptr,a
      0038EC EF               [12] 1446 	mov	a,r7
      0038ED A3               [24] 1447 	inc	dptr
      0038EE F0               [24] 1448 	movx	@dptr,a
      0038EF 90 0D B6         [24] 1449 	mov	dptr,#___memcpy_PARM_3
      0038F2 74 09            [12] 1450 	mov	a,#0x09
      0038F4 F0               [24] 1451 	movx	@dptr,a
      0038F5 E4               [12] 1452 	clr	a
      0038F6 A3               [24] 1453 	inc	dptr
      0038F7 F0               [24] 1454 	movx	@dptr,a
      0038F8 90 04 3F         [24] 1455 	mov	dptr,#_saved
      0038FB F5 F0            [12] 1456 	mov	b,a
      0038FD 12 BD 3B         [24] 1457 	lcall	___memcpy
                                   1458 ;	keyboards/ajazz/ak820/ak820_combo.c:91: return false;
      003900 75 82 00         [24] 1459 	mov	dpl, #0x00
      003903 22               [24] 1460 	ret
      003904                       1461 00139$:
                                   1462 ;	keyboards/ajazz/ak820/ak820_combo.c:93: return true;
      003904 75 82 01         [24] 1463 	mov	dpl, #0x01
                                   1464 ;	keyboards/ajazz/ak820/ak820_combo.c:94: }
      003907 22               [24] 1465 	ret
                                   1466 	.area CSEG    (CODE)
                                   1467 	.area CONST   (CODE)
                                   1468 	.area XINIT   (CODE)
      00C60C                       1469 __xinit__first:
      00C60C FF                    1470 	.db #0xff	; 255
      00C60D                       1471 __xinit__second:
      00C60D FF                    1472 	.db #0xff	; 255
                                   1473 	.area CABS    (ABS,CODE)
