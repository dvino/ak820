                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000025                         47 bits:
      000025                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00066C                         85 _eeprom_read_word_addr_10000_91:
      00066C                         86 	.ds 3
      00066F                         87 _eeprom_read_word_ret_10000_92:
      00066F                         88 	.ds 2
      000671                         89 _eeprom_read_dword_addr_10000_93:
      000671                         90 	.ds 3
      000674                         91 _eeprom_read_dword_ret_10000_94:
      000674                         92 	.ds 4
      000678                         93 _eeprom_write_byte_PARM_2:
      000678                         94 	.ds 1
      000679                         95 _eeprom_write_byte_addr_10000_95:
      000679                         96 	.ds 3
      00067C                         97 _eeprom_write_word_PARM_2:
      00067C                         98 	.ds 2
      00067E                         99 _eeprom_write_word_addr_10000_97:
      00067E                        100 	.ds 3
      000681                        101 _eeprom_write_dword_PARM_2:
      000681                        102 	.ds 4
      000685                        103 _eeprom_write_dword_addr_10000_99:
      000685                        104 	.ds 3
      000688                        105 _eeprom_update_byte_PARM_2:
      000688                        106 	.ds 1
      000689                        107 _eeprom_update_byte_addr_10000_107:
      000689                        108 	.ds 3
      00068C                        109 _eeprom_update_word_PARM_2:
      00068C                        110 	.ds 2
      00068E                        111 _eeprom_update_word_addr_10000_111:
      00068E                        112 	.ds 3
      000691                        113 _eeprom_update_dword_PARM_2:
      000691                        114 	.ds 4
      000695                        115 _eeprom_update_dword_addr_10000_115:
      000695                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004C7B                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004C7B 12 43 D8         [24]  170 	lcall	_ak820_outline_0004
      004C7E 90 06 6C         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004C81 12 43 CB         [24]  172 	lcall	_ak820_outline_0001
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004C84 90 06 6F         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004C87 12 4E 8D         [24]  175 	lcall	_ak820_outline_0098
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004C8A 90 06 6C         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004C8D E0               [24]  178 	movx	a,@dptr
      004C8E FD               [12]  179 	mov	r5,a
      004C8F A3               [24]  180 	inc	dptr
      004C90 12 43 C5         [24]  181 	lcall	_ak820_outline_0000
      004C93 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004C96 ED               [12]  183 	mov	a,r5
      004C97 12 43 CB         [24]  184 	lcall	_ak820_outline_0001
      004C9A 90 05 87         [24]  185 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004C9D 74 02            [12]  186 	mov	a,#0x02
      004C9F 12 4E 60         [24]  187 	lcall	_ak820_outline_0003
      004CA2 90 06 6F         [24]  188 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CA5 12 41 51         [24]  189 	lcall	_ak820_eeprom_read_block_xdata
                                    190 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004CA8 90 06 6F         [24]  191 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CAB 12 4E 84         [24]  192 	lcall	_ak820_outline_0070
                                    193 ;	drivers/eeprom/eeprom_driver.c:48: }
      004CAE 22               [24]  194 	ret
                                    195 ;------------------------------------------------------------
                                    196 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    197 ;------------------------------------------------------------
                                    198 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    199 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    200 ;------------------------------------------------------------
                                    201 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    202 ;	-----------------------------------------
                                    203 ;	 function eeprom_read_dword
                                    204 ;	-----------------------------------------
      004CAF                        205 _eeprom_read_dword:
      004CAF 12 43 D8         [24]  206 	lcall	_ak820_outline_0004
      004CB2 90 06 71         [24]  207 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CB5 12 43 CB         [24]  208 	lcall	_ak820_outline_0001
                                    209 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004CB8 90 06 74         [24]  210 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CBB E4               [12]  211 	clr	a
      004CBC 12 4E 74         [24]  212 	lcall	_ak820_outline_0042
                                    213 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004CBF 90 06 71         [24]  214 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CC2 E0               [24]  215 	movx	a,@dptr
      004CC3 FD               [12]  216 	mov	r5,a
      004CC4 A3               [24]  217 	inc	dptr
      004CC5 12 43 C5         [24]  218 	lcall	_ak820_outline_0000
      004CC8 90 05 84         [24]  219 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004CCB ED               [12]  220 	mov	a,r5
      004CCC 12 43 CB         [24]  221 	lcall	_ak820_outline_0001
      004CCF 90 05 87         [24]  222 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004CD2 74 04            [12]  223 	mov	a,#0x04
      004CD4 12 4E 60         [24]  224 	lcall	_ak820_outline_0003
      004CD7 90 06 74         [24]  225 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CDA 12 41 51         [24]  226 	lcall	_ak820_eeprom_read_block_xdata
                                    227 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004CDD 90 06 74         [24]  228 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CE0 12 43 DF         [24]  229 	lcall	_ak820_outline_0006
      004CE3 A3               [24]  230 	inc	dptr
      004CE4 E0               [24]  231 	movx	a,@dptr
      004CE5 FE               [12]  232 	mov	r6,a
      004CE6 A3               [24]  233 	inc	dptr
      004CE7 E0               [24]  234 	movx	a,@dptr
      004CE8 12 43 EF         [24]  235 	lcall	_ak820_outline_0011
      004CEB 8E F0            [24]  236 	mov	b,r6
                                    237 ;	drivers/eeprom/eeprom_driver.c:54: }
      004CED 22               [24]  238 	ret
                                    239 ;------------------------------------------------------------
                                    240 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    241 ;------------------------------------------------------------
                                    242 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    243 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    244 ;------------------------------------------------------------
                                    245 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    246 ;	-----------------------------------------
                                    247 ;	 function eeprom_write_byte
                                    248 ;	-----------------------------------------
      004CEE                        249 _eeprom_write_byte:
      004CEE 12 43 D8         [24]  250 	lcall	_ak820_outline_0004
      004CF1 90 06 79         [24]  251 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004CF4 12 43 CB         [24]  252 	lcall	_ak820_outline_0001
                                    253 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004CF7 90 06 79         [24]  254 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004CFA E0               [24]  255 	movx	a,@dptr
      004CFB FD               [12]  256 	mov	r5,a
      004CFC A3               [24]  257 	inc	dptr
      004CFD 12 43 C5         [24]  258 	lcall	_ak820_outline_0000
      004D00 90 05 8D         [24]  259 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004D03 ED               [12]  260 	mov	a,r5
      004D04 12 43 CB         [24]  261 	lcall	_ak820_outline_0001
      004D07 90 05 90         [24]  262 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004D0A 74 01            [12]  263 	mov	a,#0x01
      004D0C 12 4E 60         [24]  264 	lcall	_ak820_outline_0003
      004D0F 90 06 78         [24]  265 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    266 ;	drivers/eeprom/eeprom_driver.c:58: }
      004D12 02 41 DD         [24]  267 	ljmp	_ak820_eeprom_write_block_xdata
                                    268 ;------------------------------------------------------------
                                    269 ;Allocation info for local variables in function 'eeprom_write_word'
                                    270 ;------------------------------------------------------------
                                    271 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    272 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    273 ;------------------------------------------------------------
                                    274 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    275 ;	-----------------------------------------
                                    276 ;	 function eeprom_write_word
                                    277 ;	-----------------------------------------
      004D15                        278 _eeprom_write_word:
      004D15 12 43 D8         [24]  279 	lcall	_ak820_outline_0004
      004D18 90 06 7E         [24]  280 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D1B 12 43 CB         [24]  281 	lcall	_ak820_outline_0001
                                    282 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004D1E 90 06 7E         [24]  283 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D21 E0               [24]  284 	movx	a,@dptr
      004D22 FD               [12]  285 	mov	r5,a
      004D23 A3               [24]  286 	inc	dptr
      004D24 12 43 C5         [24]  287 	lcall	_ak820_outline_0000
      004D27 90 05 8D         [24]  288 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004D2A ED               [12]  289 	mov	a,r5
      004D2B 12 43 CB         [24]  290 	lcall	_ak820_outline_0001
      004D2E 90 05 90         [24]  291 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004D31 74 02            [12]  292 	mov	a,#0x02
      004D33 12 4E 60         [24]  293 	lcall	_ak820_outline_0003
      004D36 90 06 7C         [24]  294 	mov	dptr,#_eeprom_write_word_PARM_2
                                    295 ;	drivers/eeprom/eeprom_driver.c:62: }
      004D39 02 41 DD         [24]  296 	ljmp	_ak820_eeprom_write_block_xdata
                                    297 ;------------------------------------------------------------
                                    298 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    299 ;------------------------------------------------------------
                                    300 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    301 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_write_dword
                                    306 ;	-----------------------------------------
      004D3C                        307 _eeprom_write_dword:
      004D3C 12 43 D8         [24]  308 	lcall	_ak820_outline_0004
      004D3F 90 06 85         [24]  309 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D42 12 43 CB         [24]  310 	lcall	_ak820_outline_0001
                                    311 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004D45 90 06 85         [24]  312 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D48 E0               [24]  313 	movx	a,@dptr
      004D49 FD               [12]  314 	mov	r5,a
      004D4A A3               [24]  315 	inc	dptr
      004D4B 12 43 C5         [24]  316 	lcall	_ak820_outline_0000
      004D4E 90 05 8D         [24]  317 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004D51 ED               [12]  318 	mov	a,r5
      004D52 12 43 CB         [24]  319 	lcall	_ak820_outline_0001
      004D55 90 05 90         [24]  320 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004D58 74 04            [12]  321 	mov	a,#0x04
      004D5A 12 4E 60         [24]  322 	lcall	_ak820_outline_0003
      004D5D 90 06 81         [24]  323 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    324 ;	drivers/eeprom/eeprom_driver.c:66: }
      004D60 02 41 DD         [24]  325 	ljmp	_ak820_eeprom_write_block_xdata
                                    326 ;------------------------------------------------------------
                                    327 ;Allocation info for local variables in function 'eeprom_update_block'
                                    328 ;------------------------------------------------------------
                                    329 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    330 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    331 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    332 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    333 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    334 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    335 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    336 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    337 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    338 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    339 ;------------------------------------------------------------
                                    340 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    341 ;	-----------------------------------------
                                    342 ;	 function eeprom_update_byte
                                    343 ;	-----------------------------------------
      004D63                        344 _eeprom_update_byte:
      004D63 C0 07            [24]  345 	push	ar7
      004D65 C0 06            [24]  346 	push	ar6
      004D67 C0 05            [24]  347 	push	ar5
      004D69 C0 04            [24]  348 	push	ar4
      004D6B 12 43 D8         [24]  349 	lcall	_ak820_outline_0004
      004D6E 90 06 89         [24]  350 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D71 12 43 CB         [24]  351 	lcall	_ak820_outline_0001
                                    352 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004D74 90 06 89         [24]  353 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D77 E0               [24]  354 	movx	a,@dptr
      004D78 FD               [12]  355 	mov	r5,a
      004D79 A3               [24]  356 	inc	dptr
      004D7A 12 43 C5         [24]  357 	lcall	_ak820_outline_0000
      004D7D 12 4E 65         [24]  358 	lcall	_ak820_outline_0005
      004D80 12 41 13         [24]  359 	lcall	_eeprom_read_byte
      004D83 AF 82            [24]  360 	mov	r7, dpl
                                    361 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004D85 90 06 88         [24]  362 	mov	dptr,#_eeprom_update_byte_PARM_2
      004D88 E0               [24]  363 	movx	a,@dptr
      004D89 FE               [12]  364 	mov	r6,a
      004D8A EF               [12]  365 	mov	a,r7
      004D8B B5 06 02         [24]  366 	cjne	a,ar6,00112$
      004D8E 80 36            [24]  367 	sjmp	00103$
      004D90                        368 00112$:
                                    369 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004D90 90 06 89         [24]  370 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D93 12 43 DF         [24]  371 	lcall	_ak820_outline_0006
      004D96 A3               [24]  372 	inc	dptr
      004D97 E0               [24]  373 	movx	a,@dptr
      004D98 FF               [12]  374 	mov	r7,a
      004D99 90 06 78         [24]  375 	mov	dptr,#_eeprom_write_byte_PARM_2
      004D9C EE               [12]  376 	mov	a,r6
      004D9D F0               [24]  377 	movx	@dptr,a
      004D9E 12 43 EF         [24]  378 	lcall	_ak820_outline_0011
      004DA1 8F F0            [24]  379 	mov	b, r7
      004DA3 C0 07            [24]  380 	push	ar7
      004DA5 C0 06            [24]  381 	push	ar6
      004DA7 C0 05            [24]  382 	push	ar5
      004DA9 C0 04            [24]  383 	push	ar4
      004DAB C0 03            [24]  384 	push	ar3
      004DAD C0 02            [24]  385 	push	ar2
      004DAF C0 01            [24]  386 	push	ar1
      004DB1 C0 00            [24]  387 	push	ar0
      004DB3 12 4C EE         [24]  388 	lcall	_eeprom_write_byte
      004DB6 D0 00            [24]  389 	pop	ar0
      004DB8 D0 01            [24]  390 	pop	ar1
      004DBA D0 02            [24]  391 	pop	ar2
      004DBC D0 03            [24]  392 	pop	ar3
      004DBE D0 04            [24]  393 	pop	ar4
      004DC0 D0 05            [24]  394 	pop	ar5
      004DC2 D0 06            [24]  395 	pop	ar6
      004DC4 D0 07            [24]  396 	pop	ar7
      004DC6                        397 00103$:
                                    398 ;	drivers/eeprom/eeprom_driver.c:87: }
      004DC6 D0 04            [24]  399 	pop	ar4
      004DC8 D0 05            [24]  400 	pop	ar5
      004DCA D0 06            [24]  401 	pop	ar6
      004DCC D0 07            [24]  402 	pop	ar7
      004DCE 22               [24]  403 	ret
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_word'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    409 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_word
                                    414 ;	-----------------------------------------
      004DCF                        415 _eeprom_update_word:
      004DCF 12 43 D8         [24]  416 	lcall	_ak820_outline_0004
      004DD2 90 06 8E         [24]  417 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DD5 12 43 CB         [24]  418 	lcall	_ak820_outline_0001
                                    419 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004DD8 90 06 8E         [24]  420 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DDB E0               [24]  421 	movx	a,@dptr
      004DDC FD               [12]  422 	mov	r5,a
      004DDD A3               [24]  423 	inc	dptr
      004DDE 12 43 C5         [24]  424 	lcall	_ak820_outline_0000
      004DE1 12 4E 65         [24]  425 	lcall	_ak820_outline_0005
      004DE4 12 4C 7B         [24]  426 	lcall	_eeprom_read_word
      004DE7 12 44 1D         [24]  427 	lcall	_ak820_outline_0027
                                    428 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004DEA 90 06 8C         [24]  429 	mov	dptr,#_eeprom_update_word_PARM_2
      004DED 12 43 DF         [24]  430 	lcall	_ak820_outline_0006
      004DF0 EE               [12]  431 	mov	a,r6
      004DF1 B5 04 05         [24]  432 	cjne	a,ar4,00112$
      004DF4 EF               [12]  433 	mov	a,r7
      004DF5 B5 05 01         [24]  434 	cjne	a,ar5,00112$
      004DF8 22               [24]  435 	ret
      004DF9                        436 00112$:
                                    437 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004DF9 90 06 8E         [24]  438 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DFC E0               [24]  439 	movx	a,@dptr
      004DFD FB               [12]  440 	mov	r3,a
      004DFE A3               [24]  441 	inc	dptr
      004DFF 12 43 C5         [24]  442 	lcall	_ak820_outline_0000
      004E02 90 06 7C         [24]  443 	mov	dptr,#_eeprom_write_word_PARM_2
      004E05 12 44 0B         [24]  444 	lcall	_ak820_outline_0023
      004E08 8B 82            [24]  445 	mov	dpl, r3
      004E0A 8E 83            [24]  446 	mov	dph, r6
      004E0C 8F F0            [24]  447 	mov	b, r7
                                    448 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E0E 02 4D 15         [24]  449 	ljmp	_eeprom_write_word
                                    450 ;------------------------------------------------------------
                                    451 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    452 ;------------------------------------------------------------
                                    453 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    454 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    455 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    456 ;------------------------------------------------------------
                                    457 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    458 ;	-----------------------------------------
                                    459 ;	 function eeprom_update_dword
                                    460 ;	-----------------------------------------
      004E11                        461 _eeprom_update_dword:
      004E11 12 43 D8         [24]  462 	lcall	_ak820_outline_0004
      004E14 90 06 95         [24]  463 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E17 12 43 CB         [24]  464 	lcall	_ak820_outline_0001
                                    465 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E1A 90 06 95         [24]  466 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E1D E0               [24]  467 	movx	a,@dptr
      004E1E FD               [12]  468 	mov	r5,a
      004E1F A3               [24]  469 	inc	dptr
      004E20 12 43 C5         [24]  470 	lcall	_ak820_outline_0000
      004E23 12 4E 65         [24]  471 	lcall	_ak820_outline_0005
      004E26 12 4C AF         [24]  472 	lcall	_eeprom_read_dword
      004E29 12 4E 6C         [24]  473 	lcall	_ak820_outline_0041
                                    474 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E2C 90 06 91         [24]  475 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E2F 12 44 5C         [24]  476 	lcall	_ak820_outline_0072
      004E32 A3               [24]  477 	inc	dptr
      004E33 12 44 11         [24]  478 	lcall	_ak820_outline_0024
      004E36 EC               [12]  479 	mov	a,r4
      004E37 B5 00 0D         [24]  480 	cjne	a,ar0,00112$
      004E3A ED               [12]  481 	mov	a,r5
      004E3B B5 01 09         [24]  482 	cjne	a,ar1,00112$
      004E3E EE               [12]  483 	mov	a,r6
      004E3F B5 02 05         [24]  484 	cjne	a,ar2,00112$
      004E42 EF               [12]  485 	mov	a,r7
      004E43 B5 03 01         [24]  486 	cjne	a,ar3,00112$
      004E46 22               [24]  487 	ret
      004E47                        488 00112$:
                                    489 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004E47 90 06 95         [24]  490 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E4A E0               [24]  491 	movx	a,@dptr
      004E4B FD               [12]  492 	mov	r5,a
      004E4C A3               [24]  493 	inc	dptr
      004E4D 12 43 C5         [24]  494 	lcall	_ak820_outline_0000
      004E50 90 06 81         [24]  495 	mov	dptr,#_eeprom_write_dword_PARM_2
      004E53 E8               [12]  496 	mov	a,r0
      004E54 F0               [24]  497 	movx	@dptr,a
      004E55 E9               [12]  498 	mov	a,r1
      004E56 A3               [24]  499 	inc	dptr
      004E57 12 4E 7C         [24]  500 	lcall	_ak820_outline_0056
      004E5A 12 4E 65         [24]  501 	lcall	_ak820_outline_0005
                                    502 ;	drivers/eeprom/eeprom_driver.c:101: }
      004E5D 02 4D 3C         [24]  503 	ljmp	_eeprom_write_dword
                                    504 	.area CSEG    (CODE)
                                    505 	.area CONST   (CODE)
                                    506 	.area XINIT   (CODE)
                                    507 	.area CABS    (ABS,CODE)
                                    508 
                                    509 ; Experimental exact instruction outlining.
                                    510 	.globl _ak820_outline_0000
                                    511 	.globl _ak820_outline_0001
                                    512 	.globl _ak820_outline_0003
                                    513 	.globl _ak820_outline_0004
                                    514 	.globl _ak820_outline_0005
                                    515 	.globl _ak820_outline_0006
                                    516 	.globl _ak820_outline_0011
                                    517 	.globl _ak820_outline_0023
                                    518 	.globl _ak820_outline_0024
                                    519 	.globl _ak820_outline_0027
                                    520 	.globl _ak820_outline_0041
                                    521 	.globl _ak820_outline_0042
                                    522 	.globl _ak820_outline_0056
                                    523 	.globl _ak820_outline_0070
                                    524 	.globl _ak820_outline_0072
                                    525 	.globl _ak820_outline_0098
                                    526 
                                    527 	.area CSEG (CODE)
                                    528 ; function ak820_outline_0003
      004E60                        529 _ak820_outline_0003:
      004E60 F0               [24]  530 	movx	@dptr,a
      004E61 E4               [12]  531 	clr	a
      004E62 A3               [24]  532 	inc	dptr
      004E63 F0               [24]  533 	movx	@dptr,a
      004E64 22               [24]  534 	ret
                                    535 
                                    536 	.area CSEG (CODE)
                                    537 ; function ak820_outline_0005
      004E65                        538 _ak820_outline_0005:
      004E65 8D 82            [24]  539 	mov	dpl,r5
      004E67 8E 83            [24]  540 	mov	dph,r6
      004E69 8F F0            [24]  541 	mov	b,r7
      004E6B 22               [24]  542 	ret
                                    543 
                                    544 	.area CSEG (CODE)
                                    545 ; function ak820_outline_0041
      004E6C                        546 _ak820_outline_0041:
      004E6C AC 82            [24]  547 	mov	r4,dpl
      004E6E AD 83            [24]  548 	mov	r5,dph
      004E70 AE F0            [24]  549 	mov	r6,b
      004E72 FF               [12]  550 	mov	r7,a
      004E73 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0042
      004E74                        555 _ak820_outline_0042:
      004E74 F0               [24]  556 	movx	@dptr,a
      004E75 A3               [24]  557 	inc	dptr
      004E76 F0               [24]  558 	movx	@dptr,a
      004E77 A3               [24]  559 	inc	dptr
      004E78 F0               [24]  560 	movx	@dptr,a
      004E79 A3               [24]  561 	inc	dptr
      004E7A F0               [24]  562 	movx	@dptr,a
      004E7B 22               [24]  563 	ret
                                    564 
                                    565 	.area CSEG (CODE)
                                    566 ; function ak820_outline_0056
      004E7C                        567 _ak820_outline_0056:
      004E7C F0               [24]  568 	movx	@dptr,a
      004E7D EA               [12]  569 	mov	a,r2
      004E7E A3               [24]  570 	inc	dptr
      004E7F F0               [24]  571 	movx	@dptr,a
      004E80 EB               [12]  572 	mov	a,r3
      004E81 A3               [24]  573 	inc	dptr
      004E82 F0               [24]  574 	movx	@dptr,a
      004E83 22               [24]  575 	ret
                                    576 
                                    577 	.area CSEG (CODE)
                                    578 ; function ak820_outline_0070
      004E84                        579 _ak820_outline_0070:
      004E84 E0               [24]  580 	movx	a,@dptr
      004E85 FE               [12]  581 	mov	r6,a
      004E86 A3               [24]  582 	inc	dptr
      004E87 E0               [24]  583 	movx	a,@dptr
      004E88 8E 82            [24]  584 	mov	dpl,r6
      004E8A F5 83            [12]  585 	mov	dph,a
      004E8C 22               [24]  586 	ret
                                    587 
                                    588 	.area CSEG (CODE)
                                    589 ; function ak820_outline_0098
      004E8D                        590 _ak820_outline_0098:
      004E8D E4               [12]  591 	clr	a
      004E8E F0               [24]  592 	movx	@dptr,a
      004E8F A3               [24]  593 	inc	dptr
      004E90 F0               [24]  594 	movx	@dptr,a
      004E91 22               [24]  595 	ret
