                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _repeat_key_cancel
                                     27 	.globl _clear_owned_usages
                                     28 	.globl _owned_usage_key
                                     29 	.globl _clear_owned_keys
                                     30 	.globl _del_owned_key
                                     31 	.globl _add_owned_key
                                     32 	.globl _clear_owned_mods
                                     33 	.globl _del_owned_weak_mods
                                     34 	.globl _add_owned_weak_mods
                                     35 	.globl _del_owned_mods
                                     36 	.globl _add_owned_mods
                                     37 	.globl _clear_weak_mods
                                     38 	.globl _clear_mods
                                     39 	.globl _send_keyboard_report
                                     40 	.globl _layer_hold_clear
                                     41 	.globl _layer_hold_off
                                     42 	.globl _layer_hold_on
                                     43 	.globl _ak820_resolve_key
                                     44 	.globl _layer_xor
                                     45 	.globl _layer_and
                                     46 	.globl _layer_or
                                     47 	.globl _layer_off
                                     48 	.globl _layer_on
                                     49 	.globl _layer_move
                                     50 	.globl _layer_clear
                                     51 	.globl _layer_state_set
                                     52 	.globl _default_layer_xor
                                     53 	.globl _default_layer_and
                                     54 	.globl _default_layer_or
                                     55 	.globl _default_layer_set
                                     56 	.globl _post_process_record_quantum
                                     57 	.globl _process_record_quantum
                                     58 	.globl _action_for_keycode
                                     59 	.globl _mousekey_send
                                     60 	.globl _mousekey_clear
                                     61 	.globl _mousekey_off
                                     62 	.globl _mousekey_on
                                     63 	.globl _mDelaymS
                                     64 	.globl _host_consumer_send
                                     65 	.globl _host_system_send
                                     66 	.globl _host_keyboard_leds
                                     67 	.globl _led_set
                                     68 	.globl _clear_keys_from_report
                                     69 	.globl ___memcpy
                                     70 	.globl _ADC_START
                                     71 	.globl _S0_R_FIFO
                                     72 	.globl _S0_T_FIFO
                                     73 	.globl _S0_FREE
                                     74 	.globl _S0_IF_BYTE
                                     75 	.globl _S0_IF_FIRST
                                     76 	.globl _S0_IF_OV
                                     77 	.globl _S0_FST_ACT
                                     78 	.globl _CP_RL2
                                     79 	.globl _C_T2
                                     80 	.globl _TR2
                                     81 	.globl _EXEN2
                                     82 	.globl _TCLK
                                     83 	.globl _RCLK
                                     84 	.globl _EXF2
                                     85 	.globl _CAP1F
                                     86 	.globl _TF2
                                     87 	.globl _RI
                                     88 	.globl _TI
                                     89 	.globl _RB8
                                     90 	.globl _TB8
                                     91 	.globl _REN
                                     92 	.globl _SM2
                                     93 	.globl _SM1
                                     94 	.globl _SM0
                                     95 	.globl _IT0
                                     96 	.globl _IE0
                                     97 	.globl _IT1
                                     98 	.globl _IE1
                                     99 	.globl _TR0
                                    100 	.globl _TF0
                                    101 	.globl _TR1
                                    102 	.globl _TF1
                                    103 	.globl _P4_0
                                    104 	.globl _P4_1
                                    105 	.globl _P4_2
                                    106 	.globl _P4_3
                                    107 	.globl _P4_4
                                    108 	.globl _P4_5
                                    109 	.globl _P4_6
                                    110 	.globl _RXD
                                    111 	.globl _TXD
                                    112 	.globl _INT0
                                    113 	.globl _INT1
                                    114 	.globl _T0
                                    115 	.globl _T1
                                    116 	.globl _MOSI1
                                    117 	.globl _MISO1
                                    118 	.globl _SCK1
                                    119 	.globl _P3_0
                                    120 	.globl _P3_1
                                    121 	.globl _P3_2
                                    122 	.globl _P3_3
                                    123 	.globl _P3_4
                                    124 	.globl _P3_5
                                    125 	.globl _P3_6
                                    126 	.globl _P3_7
                                    127 	.globl _CAP1_
                                    128 	.globl _T2_
                                    129 	.globl _CAP2_
                                    130 	.globl _T2EX_
                                    131 	.globl _RXD1
                                    132 	.globl _TXD1
                                    133 	.globl _P2_0
                                    134 	.globl _P2_1
                                    135 	.globl _P2_2
                                    136 	.globl _P2_3
                                    137 	.globl _P2_4
                                    138 	.globl _P2_5
                                    139 	.globl _P2_6
                                    140 	.globl _P2_7
                                    141 	.globl _AIN0
                                    142 	.globl _AIN1
                                    143 	.globl _AIN2
                                    144 	.globl _AIN3
                                    145 	.globl _AIN4
                                    146 	.globl _AIN5
                                    147 	.globl _AIN6
                                    148 	.globl _AIN7
                                    149 	.globl _CAP1
                                    150 	.globl _T2
                                    151 	.globl _CAP2
                                    152 	.globl _T2EX
                                    153 	.globl _INT0_
                                    154 	.globl _SCS
                                    155 	.globl _MOSI
                                    156 	.globl _MISO
                                    157 	.globl _SCK
                                    158 	.globl _RXD1_
                                    159 	.globl _TXD1_
                                    160 	.globl _P1_0
                                    161 	.globl _P1_1
                                    162 	.globl _P1_2
                                    163 	.globl _P1_3
                                    164 	.globl _P1_4
                                    165 	.globl _P1_5
                                    166 	.globl _P1_6
                                    167 	.globl _P1_7
                                    168 	.globl _AIN8
                                    169 	.globl _AIN9
                                    170 	.globl _AIN10
                                    171 	.globl _AIN11
                                    172 	.globl _AIN12
                                    173 	.globl _AIN13
                                    174 	.globl _RXD_
                                    175 	.globl _TXD_
                                    176 	.globl _SCL0
                                    177 	.globl _SDA0
                                    178 	.globl _P0_0
                                    179 	.globl _P0_1
                                    180 	.globl _P0_2
                                    181 	.globl _P0_3
                                    182 	.globl _P0_4
                                    183 	.globl _P0_5
                                    184 	.globl _P0_6
                                    185 	.globl _P0_7
                                    186 	.globl _IE_SPI0
                                    187 	.globl _IE_USB
                                    188 	.globl _IE_ADC
                                    189 	.globl _IE_UART1
                                    190 	.globl _IE_PWM_I2C
                                    191 	.globl _IE_GPIO
                                    192 	.globl _IE_WDOG
                                    193 	.globl _PX0
                                    194 	.globl _PT0
                                    195 	.globl _PX1
                                    196 	.globl _PT1
                                    197 	.globl _PS
                                    198 	.globl _PT2
                                    199 	.globl _PL_FLAG
                                    200 	.globl _PH_FLAG
                                    201 	.globl _EX0
                                    202 	.globl _ET0
                                    203 	.globl _EX1
                                    204 	.globl _ET1
                                    205 	.globl _ES
                                    206 	.globl _ET2
                                    207 	.globl _E_DIS
                                    208 	.globl _EA
                                    209 	.globl _P
                                    210 	.globl _F1
                                    211 	.globl _OV
                                    212 	.globl _RS0
                                    213 	.globl _RS1
                                    214 	.globl _F0
                                    215 	.globl _AC
                                    216 	.globl _CY
                                    217 	.globl _I2CS_INT_ST
                                    218 	.globl _I2CX_INT
                                    219 	.globl _LED_STATUS
                                    220 	.globl _LED_DMA_H
                                    221 	.globl _LED_DMA_L
                                    222 	.globl _LED_DMA
                                    223 	.globl _LED_PWM_OE
                                    224 	.globl _LED_COMMON
                                    225 	.globl _ADC_CHAN
                                    226 	.globl _ADC_DAT_H
                                    227 	.globl _ADC_DAT_L
                                    228 	.globl _ADC_DAT
                                    229 	.globl _ADC_CTRL
                                    230 	.globl _SPI1_CK_SE
                                    231 	.globl _SPI1_CTRL
                                    232 	.globl _SPI1_DATA
                                    233 	.globl _SPI1_STAT
                                    234 	.globl _SIF1
                                    235 	.globl _SBAUD1
                                    236 	.globl _SBUF1
                                    237 	.globl _SCON1
                                    238 	.globl _SPI0_SETUP
                                    239 	.globl _SPI0_CK_SE
                                    240 	.globl _SPI0_CTRL
                                    241 	.globl _SPI0_DATA
                                    242 	.globl _SPI0_STAT
                                    243 	.globl _T2CAP1H
                                    244 	.globl _T2CAP1L
                                    245 	.globl _T2CAP1
                                    246 	.globl _TH2
                                    247 	.globl _TL2
                                    248 	.globl _T2COUNT
                                    249 	.globl _RCAP2H
                                    250 	.globl _RCAP2L
                                    251 	.globl _RCAP2
                                    252 	.globl _T2MOD
                                    253 	.globl _T2CON
                                    254 	.globl _SBUF
                                    255 	.globl _SCON
                                    256 	.globl _TH1
                                    257 	.globl _TH0
                                    258 	.globl _TL1
                                    259 	.globl _TL0
                                    260 	.globl _TMOD
                                    261 	.globl _TCON
                                    262 	.globl _XBUS_AUX
                                    263 	.globl _P7
                                    264 	.globl _P6_DIR
                                    265 	.globl _P6_OUT_PU
                                    266 	.globl _P6_IN
                                    267 	.globl _P5_DIR
                                    268 	.globl _P5_OUT_PU
                                    269 	.globl _P5_IN
                                    270 	.globl _P4_LED_KEY
                                    271 	.globl _P4_DIR_PU
                                    272 	.globl _P4_MOD_OC
                                    273 	.globl _P4
                                    274 	.globl _P3_DIR_PU
                                    275 	.globl _P3_MOD_OC
                                    276 	.globl _P3
                                    277 	.globl _P2_DIR_PU
                                    278 	.globl _P2_MOD_OC
                                    279 	.globl _P2
                                    280 	.globl _P1_DIR_PU
                                    281 	.globl _P1_MOD_OC
                                    282 	.globl _P1
                                    283 	.globl _P0_DIR_PU
                                    284 	.globl _P0_MOD_OC
                                    285 	.globl _P0
                                    286 	.globl _ROM_CTRL
                                    287 	.globl _ROM_DATA_HH
                                    288 	.globl _ROM_DATA_HL
                                    289 	.globl _ROM_DATA_HI
                                    290 	.globl _ROM_ADDR_H
                                    291 	.globl _ROM_ADDR_L
                                    292 	.globl _ROM_ADDR
                                    293 	.globl _GPIO_IE
                                    294 	.globl _IP_EX
                                    295 	.globl _IE_EX
                                    296 	.globl _IP
                                    297 	.globl _IE
                                    298 	.globl _WDOG_COUNT
                                    299 	.globl _RESET_KEEP
                                    300 	.globl _WAKE_CTRL
                                    301 	.globl _CLOCK_CFG
                                    302 	.globl _POWER_CFG
                                    303 	.globl _PCON
                                    304 	.globl _GLOBAL_CFG
                                    305 	.globl _SAFE_MOD
                                    306 	.globl _DPH
                                    307 	.globl _DPL
                                    308 	.globl _SP
                                    309 	.globl _A_INV
                                    310 	.globl _B
                                    311 	.globl _ACC
                                    312 	.globl _PSW
                                    313 	.globl _disable_action_cache
                                    314 	.globl _tap_code_delay_PARM_2
                                    315 	.globl _process_action_PARM_2
                                    316 	.globl _register_mouse_PARM_2
                                    317 	.globl _action_exec_PARM_1
                                    318 	.globl _tp_buttons
                                    319 	.globl _action_exec
                                    320 	.globl _ak820_action_exec
                                    321 	.globl _process_record
                                    322 	.globl _process_record_handler
                                    323 	.globl _process_action
                                    324 	.globl _register_code
                                    325 	.globl _unregister_code
                                    326 	.globl _tap_code_delay
                                    327 	.globl _tap_code
                                    328 	.globl _register_mods
                                    329 	.globl _unregister_mods
                                    330 	.globl _register_weak_mods
                                    331 	.globl _unregister_weak_mods
                                    332 	.globl _clear_keyboard
                                    333 	.globl _clear_keyboard_but_mods
                                    334 	.globl _clear_keyboard_but_mods_and_keys
                                    335 ;--------------------------------------------------------
                                    336 ; special function registers
                                    337 ;--------------------------------------------------------
                                    338 	.area RSEG    (ABS,DATA)
      000000                        339 	.org 0x0000
                           0000D0   340 _PSW	=	0x00d0
                           0000E0   341 _ACC	=	0x00e0
                           0000F0   342 _B	=	0x00f0
                           0000FD   343 _A_INV	=	0x00fd
                           000081   344 _SP	=	0x0081
                           000082   345 _DPL	=	0x0082
                           000083   346 _DPH	=	0x0083
                           0000A1   347 _SAFE_MOD	=	0x00a1
                           0000B1   348 _GLOBAL_CFG	=	0x00b1
                           000087   349 _PCON	=	0x0087
                           0000BA   350 _POWER_CFG	=	0x00ba
                           0000B9   351 _CLOCK_CFG	=	0x00b9
                           0000A9   352 _WAKE_CTRL	=	0x00a9
                           0000FE   353 _RESET_KEEP	=	0x00fe
                           0000FF   354 _WDOG_COUNT	=	0x00ff
                           0000A8   355 _IE	=	0x00a8
                           0000B8   356 _IP	=	0x00b8
                           0000E8   357 _IE_EX	=	0x00e8
                           0000E9   358 _IP_EX	=	0x00e9
                           0000B2   359 _GPIO_IE	=	0x00b2
                           008584   360 _ROM_ADDR	=	0x8584
                           000084   361 _ROM_ADDR_L	=	0x0084
                           000085   362 _ROM_ADDR_H	=	0x0085
                           008F8E   363 _ROM_DATA_HI	=	0x8f8e
                           00008E   364 _ROM_DATA_HL	=	0x008e
                           00008F   365 _ROM_DATA_HH	=	0x008f
                           000086   366 _ROM_CTRL	=	0x0086
                           000080   367 _P0	=	0x0080
                           0000C4   368 _P0_MOD_OC	=	0x00c4
                           0000C5   369 _P0_DIR_PU	=	0x00c5
                           000090   370 _P1	=	0x0090
                           000092   371 _P1_MOD_OC	=	0x0092
                           000093   372 _P1_DIR_PU	=	0x0093
                           0000A0   373 _P2	=	0x00a0
                           000094   374 _P2_MOD_OC	=	0x0094
                           000095   375 _P2_DIR_PU	=	0x0095
                           0000B0   376 _P3	=	0x00b0
                           000096   377 _P3_MOD_OC	=	0x0096
                           000097   378 _P3_DIR_PU	=	0x0097
                           0000C0   379 _P4	=	0x00c0
                           0000C2   380 _P4_MOD_OC	=	0x00c2
                           0000C3   381 _P4_DIR_PU	=	0x00c3
                           0000C1   382 _P4_LED_KEY	=	0x00c1
                           0000AA   383 _P5_IN	=	0x00aa
                           0000AB   384 _P5_OUT_PU	=	0x00ab
                           0000AC   385 _P5_DIR	=	0x00ac
                           0000AD   386 _P6_IN	=	0x00ad
                           0000AE   387 _P6_OUT_PU	=	0x00ae
                           0000AF   388 _P6_DIR	=	0x00af
                           0000F1   389 _P7	=	0x00f1
                           0000A2   390 _XBUS_AUX	=	0x00a2
                           000088   391 _TCON	=	0x0088
                           000089   392 _TMOD	=	0x0089
                           00008A   393 _TL0	=	0x008a
                           00008B   394 _TL1	=	0x008b
                           00008C   395 _TH0	=	0x008c
                           00008D   396 _TH1	=	0x008d
                           000098   397 _SCON	=	0x0098
                           000099   398 _SBUF	=	0x0099
                           0000C8   399 _T2CON	=	0x00c8
                           0000C9   400 _T2MOD	=	0x00c9
                           00CBCA   401 _RCAP2	=	0xcbca
                           0000CA   402 _RCAP2L	=	0x00ca
                           0000CB   403 _RCAP2H	=	0x00cb
                           00CDCC   404 _T2COUNT	=	0xcdcc
                           0000CC   405 _TL2	=	0x00cc
                           0000CD   406 _TH2	=	0x00cd
                           00CFCE   407 _T2CAP1	=	0xcfce
                           0000CE   408 _T2CAP1L	=	0x00ce
                           0000CF   409 _T2CAP1H	=	0x00cf
                           0000F8   410 _SPI0_STAT	=	0x00f8
                           0000F9   411 _SPI0_DATA	=	0x00f9
                           0000FA   412 _SPI0_CTRL	=	0x00fa
                           0000FB   413 _SPI0_CK_SE	=	0x00fb
                           0000FC   414 _SPI0_SETUP	=	0x00fc
                           0000BC   415 _SCON1	=	0x00bc
                           0000BD   416 _SBUF1	=	0x00bd
                           0000BE   417 _SBAUD1	=	0x00be
                           0000BF   418 _SIF1	=	0x00bf
                           0000B4   419 _SPI1_STAT	=	0x00b4
                           0000B5   420 _SPI1_DATA	=	0x00b5
                           0000B6   421 _SPI1_CTRL	=	0x00b6
                           0000B7   422 _SPI1_CK_SE	=	0x00b7
                           0000F3   423 _ADC_CTRL	=	0x00f3
                           00F5F4   424 _ADC_DAT	=	0xf5f4
                           0000F4   425 _ADC_DAT_L	=	0x00f4
                           0000F5   426 _ADC_DAT_H	=	0x00f5
                           0000F6   427 _ADC_CHAN	=	0x00f6
                           0000A6   428 _LED_COMMON	=	0x00a6
                           0000A7   429 _LED_PWM_OE	=	0x00a7
                           00C7C6   430 _LED_DMA	=	0xc7c6
                           0000C6   431 _LED_DMA_L	=	0x00c6
                           0000C7   432 _LED_DMA_H	=	0x00c7
                           0000F7   433 _LED_STATUS	=	0x00f7
                           0000B3   434 _I2CX_INT	=	0x00b3
                           0000BB   435 _I2CS_INT_ST	=	0x00bb
                                    436 ;--------------------------------------------------------
                                    437 ; special function bits
                                    438 ;--------------------------------------------------------
                                    439 	.area RSEG    (ABS,DATA)
      000000                        440 	.org 0x0000
                           0000D7   441 _CY	=	0x00d7
                           0000D6   442 _AC	=	0x00d6
                           0000D5   443 _F0	=	0x00d5
                           0000D4   444 _RS1	=	0x00d4
                           0000D3   445 _RS0	=	0x00d3
                           0000D2   446 _OV	=	0x00d2
                           0000D1   447 _F1	=	0x00d1
                           0000D0   448 _P	=	0x00d0
                           0000AF   449 _EA	=	0x00af
                           0000AE   450 _E_DIS	=	0x00ae
                           0000AD   451 _ET2	=	0x00ad
                           0000AC   452 _ES	=	0x00ac
                           0000AB   453 _ET1	=	0x00ab
                           0000AA   454 _EX1	=	0x00aa
                           0000A9   455 _ET0	=	0x00a9
                           0000A8   456 _EX0	=	0x00a8
                           0000BF   457 _PH_FLAG	=	0x00bf
                           0000BE   458 _PL_FLAG	=	0x00be
                           0000BD   459 _PT2	=	0x00bd
                           0000BC   460 _PS	=	0x00bc
                           0000BB   461 _PT1	=	0x00bb
                           0000BA   462 _PX1	=	0x00ba
                           0000B9   463 _PT0	=	0x00b9
                           0000B8   464 _PX0	=	0x00b8
                           0000EF   465 _IE_WDOG	=	0x00ef
                           0000EE   466 _IE_GPIO	=	0x00ee
                           0000ED   467 _IE_PWM_I2C	=	0x00ed
                           0000EC   468 _IE_UART1	=	0x00ec
                           0000EB   469 _IE_ADC	=	0x00eb
                           0000E9   470 _IE_USB	=	0x00e9
                           0000E8   471 _IE_SPI0	=	0x00e8
                           000087   472 _P0_7	=	0x0087
                           000086   473 _P0_6	=	0x0086
                           000085   474 _P0_5	=	0x0085
                           000084   475 _P0_4	=	0x0084
                           000083   476 _P0_3	=	0x0083
                           000082   477 _P0_2	=	0x0082
                           000081   478 _P0_1	=	0x0081
                           000080   479 _P0_0	=	0x0080
                           000081   480 _SDA0	=	0x0081
                           000080   481 _SCL0	=	0x0080
                           000083   482 _TXD_	=	0x0083
                           000082   483 _RXD_	=	0x0082
                           000085   484 _AIN13	=	0x0085
                           000084   485 _AIN12	=	0x0084
                           000083   486 _AIN11	=	0x0083
                           000082   487 _AIN10	=	0x0082
                           000081   488 _AIN9	=	0x0081
                           000080   489 _AIN8	=	0x0080
                           000097   490 _P1_7	=	0x0097
                           000096   491 _P1_6	=	0x0096
                           000095   492 _P1_5	=	0x0095
                           000094   493 _P1_4	=	0x0094
                           000093   494 _P1_3	=	0x0093
                           000092   495 _P1_2	=	0x0092
                           000091   496 _P1_1	=	0x0091
                           000090   497 _P1_0	=	0x0090
                           000097   498 _TXD1_	=	0x0097
                           000096   499 _RXD1_	=	0x0096
                           000097   500 _SCK	=	0x0097
                           000096   501 _MISO	=	0x0096
                           000095   502 _MOSI	=	0x0095
                           000094   503 _SCS	=	0x0094
                           000092   504 _INT0_	=	0x0092
                           000091   505 _T2EX	=	0x0091
                           000091   506 _CAP2	=	0x0091
                           000090   507 _T2	=	0x0090
                           000090   508 _CAP1	=	0x0090
                           000097   509 _AIN7	=	0x0097
                           000096   510 _AIN6	=	0x0096
                           000095   511 _AIN5	=	0x0095
                           000094   512 _AIN4	=	0x0094
                           000093   513 _AIN3	=	0x0093
                           000092   514 _AIN2	=	0x0092
                           000091   515 _AIN1	=	0x0091
                           000090   516 _AIN0	=	0x0090
                           0000A7   517 _P2_7	=	0x00a7
                           0000A6   518 _P2_6	=	0x00a6
                           0000A5   519 _P2_5	=	0x00a5
                           0000A4   520 _P2_4	=	0x00a4
                           0000A3   521 _P2_3	=	0x00a3
                           0000A2   522 _P2_2	=	0x00a2
                           0000A1   523 _P2_1	=	0x00a1
                           0000A0   524 _P2_0	=	0x00a0
                           0000A7   525 _TXD1	=	0x00a7
                           0000A6   526 _RXD1	=	0x00a6
                           0000A5   527 _T2EX_	=	0x00a5
                           0000A5   528 _CAP2_	=	0x00a5
                           0000A4   529 _T2_	=	0x00a4
                           0000A4   530 _CAP1_	=	0x00a4
                           0000B7   531 _P3_7	=	0x00b7
                           0000B6   532 _P3_6	=	0x00b6
                           0000B5   533 _P3_5	=	0x00b5
                           0000B4   534 _P3_4	=	0x00b4
                           0000B3   535 _P3_3	=	0x00b3
                           0000B2   536 _P3_2	=	0x00b2
                           0000B1   537 _P3_1	=	0x00b1
                           0000B0   538 _P3_0	=	0x00b0
                           0000B7   539 _SCK1	=	0x00b7
                           0000B6   540 _MISO1	=	0x00b6
                           0000B5   541 _MOSI1	=	0x00b5
                           0000B5   542 _T1	=	0x00b5
                           0000B4   543 _T0	=	0x00b4
                           0000B3   544 _INT1	=	0x00b3
                           0000B2   545 _INT0	=	0x00b2
                           0000B1   546 _TXD	=	0x00b1
                           0000B0   547 _RXD	=	0x00b0
                           0000C6   548 _P4_6	=	0x00c6
                           0000C5   549 _P4_5	=	0x00c5
                           0000C4   550 _P4_4	=	0x00c4
                           0000C3   551 _P4_3	=	0x00c3
                           0000C2   552 _P4_2	=	0x00c2
                           0000C1   553 _P4_1	=	0x00c1
                           0000C0   554 _P4_0	=	0x00c0
                           00008F   555 _TF1	=	0x008f
                           00008E   556 _TR1	=	0x008e
                           00008D   557 _TF0	=	0x008d
                           00008C   558 _TR0	=	0x008c
                           00008B   559 _IE1	=	0x008b
                           00008A   560 _IT1	=	0x008a
                           000089   561 _IE0	=	0x0089
                           000088   562 _IT0	=	0x0088
                           00009F   563 _SM0	=	0x009f
                           00009E   564 _SM1	=	0x009e
                           00009D   565 _SM2	=	0x009d
                           00009C   566 _REN	=	0x009c
                           00009B   567 _TB8	=	0x009b
                           00009A   568 _RB8	=	0x009a
                           000099   569 _TI	=	0x0099
                           000098   570 _RI	=	0x0098
                           0000CF   571 _TF2	=	0x00cf
                           0000CF   572 _CAP1F	=	0x00cf
                           0000CE   573 _EXF2	=	0x00ce
                           0000CD   574 _RCLK	=	0x00cd
                           0000CC   575 _TCLK	=	0x00cc
                           0000CB   576 _EXEN2	=	0x00cb
                           0000CA   577 _TR2	=	0x00ca
                           0000C9   578 _C_T2	=	0x00c9
                           0000C8   579 _CP_RL2	=	0x00c8
                           0000FF   580 _S0_FST_ACT	=	0x00ff
                           0000FE   581 _S0_IF_OV	=	0x00fe
                           0000FD   582 _S0_IF_FIRST	=	0x00fd
                           0000FC   583 _S0_IF_BYTE	=	0x00fc
                           0000FB   584 _S0_FREE	=	0x00fb
                           0000FA   585 _S0_T_FIFO	=	0x00fa
                           0000F8   586 _S0_R_FIFO	=	0x00f8
                           0000F7   587 _ADC_START	=	0x00f7
                                    588 ;--------------------------------------------------------
                                    589 ; overlayable register banks
                                    590 ;--------------------------------------------------------
                                    591 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        592 	.ds 8
                                    593 ;--------------------------------------------------------
                                    594 ; internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area DSEG    (DATA)
      000027                        597 _process_action_sloc0_1_0:
      000027                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; overlayable items in internal ram
                                    601 ;--------------------------------------------------------
                                    602 ;--------------------------------------------------------
                                    603 ; indirectly addressable internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area ISEG    (DATA)
                                    606 ;--------------------------------------------------------
                                    607 ; absolute internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area IABS    (ABS,DATA)
                                    610 	.area IABS    (ABS,DATA)
                                    611 ;--------------------------------------------------------
                                    612 ; bit data
                                    613 ;--------------------------------------------------------
                                    614 	.area BSEG    (BIT)
      000020                        615 _process_action_sloc1_1_0:
      000020                        616 	.ds 1
                                    617 ;--------------------------------------------------------
                                    618 ; paged external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area PSEG    (PAG,XDATA)
                                    621 ;--------------------------------------------------------
                                    622 ; uninitialized external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area XSEG    (XDATA)
      00083A                        625 _tp_buttons::
      00083A                        626 	.ds 2
      00083C                        627 _action_exec_PARM_1:
      00083C                        628 	.ds 6
      000842                        629 _action_exec_record_10001_629:
      000842                        630 	.ds 9
      00084B                        631 _ak820_action_exec_event_10000_634:
      00084B                        632 	.ds 2
      00084D                        633 _ak820_action_exec_snapshot_10000_635:
      00084D                        634 	.ds 6
      000853                        635 _process_record_record_10000_638:
      000853                        636 	.ds 3
      000856                        637 _process_record_handler_record_argument_10000_646:
      000856                        638 	.ds 3
      000859                        639 _process_record_handler_action_10000_647:
      000859                        640 	.ds 2
      00085B                        641 _register_mouse_PARM_2:
      00085B                        642 	.ds 1
      00085C                        643 _register_mouse_mouse_keycode_10000_655:
      00085C                        644 	.ds 1
      00085D                        645 _process_action_PARM_2:
      00085D                        646 	.ds 2
      00085F                        647 _process_action_record_argument_10000_662:
      00085F                        648 	.ds 3
      000862                        649 _process_action_on_40000_685:
      000862                        650 	.ds 1
      000863                        651 _register_code_code_10000_719:
      000863                        652 	.ds 1
      000864                        653 _unregister_code_code_10000_733:
      000864                        654 	.ds 1
      000865                        655 _tap_code_delay_PARM_2:
      000865                        656 	.ds 2
      000867                        657 _tap_code_delay_code_10000_746:
      000867                        658 	.ds 1
      000868                        659 _tap_code_code_10000_753:
      000868                        660 	.ds 1
      000869                        661 _register_mods_mods_10000_755:
      000869                        662 	.ds 1
      00086A                        663 _unregister_mods_mods_10000_759:
      00086A                        664 	.ds 1
      00086B                        665 _register_weak_mods_mods_10000_763:
      00086B                        666 	.ds 1
      00086C                        667 _unregister_weak_mods_mods_10000_767:
      00086C                        668 	.ds 1
                                    669 ;--------------------------------------------------------
                                    670 ; absolute external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XABS    (ABS,XDATA)
                                    673 ;--------------------------------------------------------
                                    674 ; initialized external ram data
                                    675 ;--------------------------------------------------------
                                    676 	.area XISEG   (XDATA)
      000DEC                        677 _disable_action_cache::
      000DEC                        678 	.ds 1
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT0 (CODE)
                                    681 	.area GSINIT1 (CODE)
                                    682 	.area GSINIT2 (CODE)
                                    683 	.area GSINIT3 (CODE)
                                    684 	.area GSINIT4 (CODE)
                                    685 	.area GSINIT5 (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 	.area GSFINAL (CODE)
                                    688 	.area CSEG    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; global & static initialisations
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area GSINIT  (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    707 ;------------------------------------------------------------
                                    708 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    709 ;------------------------------------------------------------
                                    710 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function action_exec
                                    721 ;	-----------------------------------------
      0074A5                        722 _action_exec:
                                    723 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      0074A5 90 08 3E         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0074A8 12 3A 34         [24]  725 	lcall	_ak820_outline_0005
      0074AB 12 38 4B         [24]  726 	lcall	_ak820_combo_tick
                                    727 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      0074AE 90 08 3C         [24]  728 	mov	dptr,#_action_exec_PARM_1
      0074B1 12 46 92         [24]  729 	lcall	_ak820_tapping_before
      0074B4 E5 82            [12]  730 	mov	a, dpl
      0074B6 70 01            [24]  731 	jnz	00102$
      0074B8 22               [24]  732 	ret
      0074B9                        733 00102$:
                                    734 ;	quantum/action.c:100: if (!ak820_autoshift_before(&event)) return;
      0074B9 90 08 3C         [24]  735 	mov	dptr,#_action_exec_PARM_1
      0074BC 12 31 2D         [24]  736 	lcall	_ak820_autoshift_before
      0074BF E5 82            [12]  737 	mov	a, dpl
      0074C1 70 01            [24]  738 	jnz	00104$
      0074C3 22               [24]  739 	ret
      0074C4                        740 00104$:
                                    741 ;	quantum/action.c:116: if (event.pressed) {
      0074C4 90 08 41         [24]  742 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0074C7 E0               [24]  743 	movx	a,@dptr
      0074C8 60 03            [24]  744 	jz	00106$
                                    745 ;	quantum/action.c:118: clear_weak_mods();
      0074CA 12 85 5D         [24]  746 	lcall	_clear_weak_mods
      0074CD                        747 00106$:
                                    748 ;	quantum/action.c:130: record.event = event;
      0074CD 90 0D CB         [24]  749 	mov	dptr,#___memcpy_PARM_2
      0074D0 74 3C            [12]  750 	mov	a,#_action_exec_PARM_1
      0074D2 F0               [24]  751 	movx	@dptr,a
      0074D3 74 08            [12]  752 	mov	a,#(_action_exec_PARM_1 >> 8)
      0074D5 12 3A B0         [24]  753 	lcall	_ak820_outline_0093
      0074D8 12 7B EC         [24]  754 	lcall	_ak820_outline_0070
      0074DB 90 08 42         [24]  755 	mov	dptr,#_action_exec_record_10001_629
      0074DE F5 F0            [12]  756 	mov	b,a
      0074E0 12 BC 13         [24]  757 	lcall	___memcpy
                                    758 ;	quantum/action.c:132: record.tap.count = 0;
      0074E3 90 08 48         [24]  759 	mov	dptr,#(_action_exec_record_10001_629 + 0x0006)
      0074E6 E0               [24]  760 	movx	a,@dptr
      0074E7 54 0F            [12]  761 	anl	a,#0x0f
      0074E9 F0               [24]  762 	movx	@dptr,a
                                    763 ;	quantum/action.c:137: record.keycode = 0;
      0074EA 90 08 49         [24]  764 	mov	dptr,#(_action_exec_record_10001_629 + 0x0007)
      0074ED 12 51 9F         [24]  765 	lcall	_ak820_outline_0182
                                    766 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0074F0 90 08 46         [24]  767 	mov	dptr,#(_action_exec_record_10001_629 + 0x0004)
      0074F3 E0               [24]  768 	movx	a,@dptr
      0074F4 60 0D            [24]  769 	jz	00111$
      0074F6 90 08 42         [24]  770 	mov	dptr,#_action_exec_record_10001_629
      0074F9 75 F0 00         [24]  771 	mov	b, #0x00
      0074FC 12 A2 F3         [24]  772 	lcall	_pre_process_record_quantum
      0074FF E5 82            [12]  773 	mov	a, dpl
      007501 60 1E            [24]  774 	jz	00114$
      007503                        775 00111$:
                                    776 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      007503 90 08 42         [24]  777 	mov	dptr,#_action_exec_record_10001_629
      007506 12 47 77         [24]  778 	lcall	_ak820_tapping_process
      007509 E5 82            [12]  779 	mov	a, dpl
      00750B 70 01            [24]  780 	jnz	00108$
      00750D 22               [24]  781 	ret
      00750E                        782 00108$:
                                    783 ;	quantum/action.c:172: if (!ak820_autoshift_process(&record)) return;
      00750E 90 08 42         [24]  784 	mov	dptr,#_action_exec_record_10001_629
      007511 12 32 35         [24]  785 	lcall	_ak820_autoshift_process
      007514 E5 82            [12]  786 	mov	a, dpl
      007516 70 01            [24]  787 	jnz	00110$
      007518 22               [24]  788 	ret
      007519                        789 00110$:
                                    790 ;	quantum/action.c:175: process_record(&record);
      007519 90 08 42         [24]  791 	mov	dptr,#_action_exec_record_10001_629
      00751C 75 F0 00         [24]  792 	mov	b, #0x00
                                    793 ;	quantum/action.c:190: }
      00751F A1 5D            [12]  794 	ajmp	_process_record
      007521                        795 00114$:
      007521 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'ak820_action_exec'
                                    799 ;------------------------------------------------------------
                                    800 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    801 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    802 ;------------------------------------------------------------
                                    803 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function ak820_action_exec
                                    806 ;	-----------------------------------------
      007522                        807 _ak820_action_exec:
      007522 12 3A C2         [24]  808 	lcall	_ak820_outline_0107
      007525 90 08 4B         [24]  809 	mov	dptr,#_ak820_action_exec_event_10000_634
      007528 12 3A C7         [24]  810 	lcall	_ak820_outline_0108
                                    811 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      00752B 90 08 4B         [24]  812 	mov	dptr,#_ak820_action_exec_event_10000_634
      00752E 12 3A A4         [24]  813 	lcall	_ak820_outline_0079
      007531 7F 00            [12]  814 	mov	r7,#0x00
      007533 90 0D CB         [24]  815 	mov	dptr,#___memcpy_PARM_2
      007536 ED               [12]  816 	mov	a,r5
      007537 12 3A 69         [24]  817 	lcall	_ak820_outline_0017
      00753A 12 7B EC         [24]  818 	lcall	_ak820_outline_0070
      00753D 90 08 4D         [24]  819 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      007540 F5 F0            [12]  820 	mov	b,a
      007542 12 BC 13         [24]  821 	lcall	___memcpy
                                    822 ;	quantum/action.c:197: action_exec(snapshot);
      007545 90 0D CB         [24]  823 	mov	dptr,#___memcpy_PARM_2
      007548 74 4D            [12]  824 	mov	a,#_ak820_action_exec_snapshot_10000_635
      00754A F0               [24]  825 	movx	@dptr,a
      00754B 74 08            [12]  826 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      00754D 12 3A B0         [24]  827 	lcall	_ak820_outline_0093
      007550 12 7B EC         [24]  828 	lcall	_ak820_outline_0070
      007553 90 08 3C         [24]  829 	mov	dptr,#_action_exec_PARM_1
      007556 F5 F0            [12]  830 	mov	b,a
      007558 12 BC 13         [24]  831 	lcall	___memcpy
                                    832 ;	quantum/action.c:198: }
      00755B 81 A5            [12]  833 	ajmp	_action_exec
                                    834 ;------------------------------------------------------------
                                    835 ;Allocation info for local variables in function 'process_record_nocache'
                                    836 ;------------------------------------------------------------
                                    837 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    838 ;------------------------------------------------------------
                                    839 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    840 ;	-----------------------------------------
                                    841 ;	 function process_record
                                    842 ;	-----------------------------------------
      00755D                        843 _process_record:
      00755D 12 45 53         [24]  844 	lcall	_ak820_outline_0037
      007560 90 08 53         [24]  845 	mov	dptr,#_process_record_record_10000_638
      007563 12 3A 69         [24]  846 	lcall	_ak820_outline_0017
                                    847 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      007566 90 08 53         [24]  848 	mov	dptr,#_process_record_record_10000_638
      007569 12 51 4C         [24]  849 	lcall	_ak820_outline_0012
      00756C 74 04            [12]  850 	mov	a,#0x04
      00756E 12 7B BF         [24]  851 	lcall	_ak820_outline_0014
      007571 12 BC EC         [24]  852 	lcall	__gptrget
      007574 70 01            [24]  853 	jnz	00102$
                                    854 ;	quantum/action.c:338: return;
      007576 22               [24]  855 	ret
      007577                        856 00102$:
                                    857 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007577 8D 02            [24]  858 	mov	ar2,r5
      007579 8E 03            [24]  859 	mov	ar3,r6
      00757B 8F 04            [24]  860 	mov	ar4,r7
      00757D 90 0D CB         [24]  861 	mov	dptr,#___memcpy_PARM_2
      007580 EA               [12]  862 	mov	a,r2
      007581 12 7C 33         [24]  863 	lcall	_ak820_outline_0187
      007584 EC               [12]  864 	mov	a,r4
      007585 A3               [24]  865 	inc	dptr
      007586 F0               [24]  866 	movx	@dptr,a
      007587 90 0D CE         [24]  867 	mov	dptr,#___memcpy_PARM_3
      00758A 12 51 91         [24]  868 	lcall	_ak820_outline_0110
      00758D 90 06 34         [24]  869 	mov	dptr,#_ak820_tapping_source_PARM_1
      007590 F5 F0            [12]  870 	mov	b,a
      007592 C0 07            [24]  871 	push	ar7
      007594 C0 06            [24]  872 	push	ar6
      007596 C0 05            [24]  873 	push	ar5
      007598 12 BC 13         [24]  874 	lcall	___memcpy
      00759B 12 45 CD         [24]  875 	lcall	_ak820_tapping_source
      00759E AC 82            [24]  876 	mov	r4, dpl
      0075A0 D0 05            [24]  877 	pop	ar5
      0075A2 D0 06            [24]  878 	pop	ar6
      0075A4 D0 07            [24]  879 	pop	ar7
                                    880 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0075A6 74 05            [12]  881 	mov	a,#0x05
      0075A8 12 7B B1         [24]  882 	lcall	_ak820_outline_0013
      0075AB 12 BC EC         [24]  883 	lcall	__gptrget
      0075AE FB               [12]  884 	mov	r3,a
                                    885 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      0075AF 12 7C 24         [24]  886 	lcall	_ak820_outline_0148
      0075B2 90 0C 22         [24]  887 	mov	dptr,#_get_record_keycode_PARM_2
      0075B5 74 01            [12]  888 	mov	a,#0x01
      0075B7 12 51 55         [24]  889 	lcall	_ak820_outline_0034
      0075BA C0 04            [24]  890 	push	ar4
      0075BC C0 03            [24]  891 	push	ar3
      0075BE C0 02            [24]  892 	push	ar2
      0075C0 C0 01            [24]  893 	push	ar1
      0075C2 C0 00            [24]  894 	push	ar0
      0075C4 12 A2 B5         [24]  895 	lcall	_get_record_keycode
      0075C7 12 45 9C         [24]  896 	lcall	_ak820_outline_0133
      0075CA D0 00            [24]  897 	pop	ar0
      0075CC D0 01            [24]  898 	pop	ar1
      0075CE D0 02            [24]  899 	pop	ar2
      0075D0 D0 03            [24]  900 	pop	ar3
      0075D2 D0 04            [24]  901 	pop	ar4
      0075D4 12 4A EA         [24]  902 	lcall	_ak820_outline_0112
      0075D7 EE               [12]  903 	mov	a,r6
      0075D8 12 BC B1         [24]  904 	lcall	__gptrput
      0075DB A3               [24]  905 	inc	dptr
      0075DC EF               [12]  906 	mov	a,r7
      0075DD 12 BC B1         [24]  907 	lcall	__gptrput
                                    908 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0075E0 90 08 53         [24]  909 	mov	dptr,#_process_record_record_10000_638
      0075E3 12 51 4C         [24]  910 	lcall	_ak820_outline_0012
      0075E6 12 7C 24         [24]  911 	lcall	_ak820_outline_0148
      0075E9 12 4A EA         [24]  912 	lcall	_ak820_outline_0112
      0075EC 12 BC EC         [24]  913 	lcall	__gptrget
      0075EF F8               [12]  914 	mov	r0,a
      0075F0 A3               [24]  915 	inc	dptr
      0075F1 12 BC EC         [24]  916 	lcall	__gptrget
      0075F4 F9               [12]  917 	mov	r1,a
      0075F5 90 06 44         [24]  918 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0075F8 EC               [12]  919 	mov	a,r4
      0075F9 F0               [24]  920 	movx	@dptr,a
      0075FA 90 06 45         [24]  921 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0075FD EB               [12]  922 	mov	a,r3
      0075FE F0               [24]  923 	movx	@dptr,a
      0075FF 12 3A F6         [24]  924 	lcall	_ak820_outline_0160
      007602 C0 07            [24]  925 	push	ar7
      007604 C0 06            [24]  926 	push	ar6
      007606 C0 05            [24]  927 	push	ar5
      007608 C0 04            [24]  928 	push	ar4
      00760A C0 03            [24]  929 	push	ar3
      00760C 12 49 26         [24]  930 	lcall	_ak820_oneshot_process
      00760F E5 82            [12]  931 	mov	a, dpl
      007611 D0 03            [24]  932 	pop	ar3
      007613 D0 04            [24]  933 	pop	ar4
      007615 D0 05            [24]  934 	pop	ar5
      007617 D0 06            [24]  935 	pop	ar6
      007619 D0 07            [24]  936 	pop	ar7
      00761B 70 01            [24]  937 	jnz	00104$
      00761D 22               [24]  938 	ret
      00761E                        939 00104$:
                                    940 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      00761E 12 72 0C         [24]  941 	lcall	_ak820_outline_0057
      007621 C0 04            [24]  942 	push	ar4
      007623 C0 03            [24]  943 	push	ar3
      007625 12 A3 7B         [24]  944 	lcall	_process_record_quantum
      007628 E5 82            [12]  945 	mov	a, dpl
      00762A D0 03            [24]  946 	pop	ar3
      00762C D0 04            [24]  947 	pop	ar4
      00762E 70 0A            [24]  948 	jnz	00106$
                                    949 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007630 90 05 AC         [24]  950 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007633 EB               [12]  951 	mov	a,r3
      007634 F0               [24]  952 	movx	@dptr,a
      007635 8C 82            [24]  953 	mov	dpl, r4
                                    954 ;	quantum/action.c:360: return;
      007637 02 2E BB         [24]  955 	ljmp	_ak820_oneshot_post
      00763A                        956 00106$:
                                    957 ;	quantum/action.c:366: process_record_handler(record);
      00763A 90 08 53         [24]  958 	mov	dptr,#_process_record_record_10000_638
      00763D 12 51 26         [24]  959 	lcall	_ak820_outline_0001
      007640 C0 04            [24]  960 	push	ar4
      007642 C0 03            [24]  961 	push	ar3
      007644 D1 5D            [24]  962 	acall	_process_record_handler
                                    963 ;	quantum/action.c:370: post_process_record_quantum(record);
      007646 90 08 53         [24]  964 	mov	dptr,#_process_record_record_10000_638
      007649 12 51 26         [24]  965 	lcall	_ak820_outline_0001
      00764C 12 A3 52         [24]  966 	lcall	_post_process_record_quantum
      00764F D0 03            [24]  967 	pop	ar3
      007651 D0 04            [24]  968 	pop	ar4
                                    969 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007653 90 05 AC         [24]  970 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007656 EB               [12]  971 	mov	a,r3
      007657 F0               [24]  972 	movx	@dptr,a
      007658 8C 82            [24]  973 	mov	dpl, r4
                                    974 ;	quantum/action.c:374: }
      00765A 02 2E BB         [24]  975 	ljmp	_ak820_oneshot_post
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'process_record_handler'
                                    978 ;------------------------------------------------------------
                                    979 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_646'
                                    980 ;record        Allocated with name '_process_record_handler_record_10000_647'
                                    981 ;action        Allocated with name '_process_record_handler_action_10000_647'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function process_record_handler
                                    986 ;	-----------------------------------------
      00765D                        987 _process_record_handler:
      00765D 12 45 53         [24]  988 	lcall	_ak820_outline_0037
      007660 90 08 56         [24]  989 	mov	dptr,#_process_record_handler_record_argument_10000_646
      007663 12 3A 69         [24]  990 	lcall	_ak820_outline_0017
                                    991 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007666 90 08 56         [24]  992 	mov	dptr,#_process_record_handler_record_argument_10000_646
      007669 12 3A 3E         [24]  993 	lcall	_ak820_outline_0007
                                    994 ;	quantum/action.c:387: if (record->keycode) {
      00766C 4C               [12]  995 	orl	a,r4
      00766D 60 19            [24]  996 	jz	00102$
                                    997 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      00766F 12 3A D7         [24]  998 	lcall	_ak820_outline_0124
      007672 C0 07            [24]  999 	push	ar7
      007674 C0 06            [24] 1000 	push	ar6
      007676 12 99 06         [24] 1001 	lcall	_action_for_keycode
      007679 12 45 AD         [24] 1002 	lcall	_ak820_outline_0152
      00767C D0 06            [24] 1003 	pop	ar6
      00767E D0 07            [24] 1004 	pop	ar7
      007680 90 08 59         [24] 1005 	mov	dptr,#_process_record_handler_action_10000_647
      007683 12 3A 9E         [24] 1006 	lcall	_ak820_outline_0072
      007686 80 2B            [24] 1007 	sjmp	00104$
      007688                       1008 00102$:
                                   1009 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007688 12 7B CD         [24] 1010 	lcall	_ak820_outline_0021
      00768B 7A 00            [12] 1011 	mov	r2,#0x00
      00768D 12 45 A7         [24] 1012 	lcall	_ak820_outline_0144
      007690 12 45 41         [24] 1013 	lcall	_ak820_outline_0011
      007693 E0               [24] 1014 	movx	a,@dptr
      007694 90 09 97         [24] 1015 	mov	dptr,#_ak820_resolve_key_PARM_2
      007697 F0               [24] 1016 	movx	@dptr,a
      007698 8D 82            [24] 1017 	mov	dpl, r5
      00769A 8C 83            [24] 1018 	mov	dph, r4
      00769C C0 07            [24] 1019 	push	ar7
      00769E C0 06            [24] 1020 	push	ar6
      0076A0 12 7F 62         [24] 1021 	lcall	_ak820_resolve_key
      0076A3 12 99 06         [24] 1022 	lcall	_action_for_keycode
      0076A6 12 45 AD         [24] 1023 	lcall	_ak820_outline_0152
      0076A9 D0 06            [24] 1024 	pop	ar6
      0076AB D0 07            [24] 1025 	pop	ar7
      0076AD 90 08 59         [24] 1026 	mov	dptr,#_process_record_handler_action_10000_647
      0076B0 12 3A 9E         [24] 1027 	lcall	_ak820_outline_0072
                                   1028 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      0076B3                       1029 00104$:
                                   1030 ;	quantum/action.c:411: process_action(record, action);
      0076B3 7D 00            [12] 1031 	mov	r5,#0x00
      0076B5 90 0D CB         [24] 1032 	mov	dptr,#___memcpy_PARM_2
      0076B8 74 59            [12] 1033 	mov	a,#_process_record_handler_action_10000_647
      0076BA F0               [24] 1034 	movx	@dptr,a
      0076BB 74 08            [12] 1035 	mov	a,#(_process_record_handler_action_10000_647 >> 8)
      0076BD 12 3A B0         [24] 1036 	lcall	_ak820_outline_0093
      0076C0 90 0D CE         [24] 1037 	mov	dptr,#___memcpy_PARM_3
      0076C3 12 51 91         [24] 1038 	lcall	_ak820_outline_0110
      0076C6 90 08 5D         [24] 1039 	mov	dptr,#_process_action_PARM_2
      0076C9 F5 F0            [12] 1040 	mov	b,a
      0076CB C0 07            [24] 1041 	push	ar7
      0076CD C0 06            [24] 1042 	push	ar6
      0076CF C0 05            [24] 1043 	push	ar5
      0076D1 12 BC 13         [24] 1044 	lcall	___memcpy
      0076D4 D0 05            [24] 1045 	pop	ar5
      0076D6 D0 06            [24] 1046 	pop	ar6
      0076D8 D0 07            [24] 1047 	pop	ar7
      0076DA 12 74 1D         [24] 1048 	lcall	_ak820_outline_0064
                                   1049 ;	quantum/action.c:412: }
      0076DD E1 02            [24] 1050 	ajmp	_process_action
                                   1051 ;------------------------------------------------------------
                                   1052 ;Allocation info for local variables in function 'register_mouse'
                                   1053 ;------------------------------------------------------------
                                   1054 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1055 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_655'
                                   1056 ;------------------------------------------------------------
                                   1057 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1058 ;	-----------------------------------------
                                   1059 ;	 function register_mouse
                                   1060 ;	-----------------------------------------
      0076DF                       1061 _register_mouse:
      0076DF E5 82            [12] 1062 	mov	a,dpl
      0076E1 90 08 5C         [24] 1063 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      0076E4 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/action.c:427: if (pressed) {
      0076E5 90 08 5B         [24] 1066 	mov	dptr,#_register_mouse_PARM_2
      0076E8 E0               [24] 1067 	movx	a,@dptr
      0076E9 60 0B            [24] 1068 	jz	00102$
                                   1069 ;	quantum/action.c:428: mousekey_on(mouse_keycode);
      0076EB 90 08 5C         [24] 1070 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      0076EE E0               [24] 1071 	movx	a,@dptr
      0076EF F5 82            [12] 1072 	mov	dpl,a
      0076F1 12 51 EF         [24] 1073 	lcall	_mousekey_on
      0076F4 80 09            [24] 1074 	sjmp	00103$
      0076F6                       1075 00102$:
                                   1076 ;	quantum/action.c:430: mousekey_off(mouse_keycode);
      0076F6 90 08 5C         [24] 1077 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      0076F9 E0               [24] 1078 	movx	a,@dptr
      0076FA F5 82            [12] 1079 	mov	dpl,a
      0076FC 12 52 63         [24] 1080 	lcall	_mousekey_off
      0076FF                       1081 00103$:
                                   1082 ;	quantum/action.c:451: mousekey_send();
                                   1083 ;	quantum/action.c:453: }
                                   1084 ;	quantum/action.c:469: }
      0076FF 02 52 C2         [24] 1085 	ljmp	_mousekey_send
                                   1086 ;------------------------------------------------------------
                                   1087 ;Allocation info for local variables in function 'process_action'
                                   1088 ;------------------------------------------------------------
                                   1089 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1090 ;action        Allocated with name '_process_action_PARM_2'
                                   1091 ;record_argument Allocated with name '_process_action_record_argument_10000_662'
                                   1092 ;record        Allocated with name '_process_action_record_10000_663'
                                   1093 ;pressed       Allocated with name '_process_action_pressed_10000_663'
                                   1094 ;mods          Allocated with name '_process_action_mods_10000_663'
                                   1095 ;on            Allocated with name '_process_action_on_40000_685'
                                   1096 ;shift         Allocated with name '_process_action_shift_60000_687'
                                   1097 ;bits          Allocated with name '_process_action_bits_60000_687'
                                   1098 ;mask          Allocated with name '_process_action_mask_60000_687'
                                   1099 ;i             Allocated with name '_process_action_i_110000_711'
                                   1100 ;i             Allocated with name '_process_action_i_110000_715'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/action.c:475: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function process_action
                                   1105 ;	-----------------------------------------
      007702                       1106 _process_action:
      007702 12 45 53         [24] 1107 	lcall	_ak820_outline_0037
      007705 90 08 5F         [24] 1108 	mov	dptr,#_process_action_record_argument_10000_662
      007708 12 3A 69         [24] 1109 	lcall	_ak820_outline_0017
                                   1110 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00770B 90 08 5F         [24] 1111 	mov	dptr,#_process_action_record_argument_10000_662
      00770E 12 3A 34         [24] 1112 	lcall	_ak820_outline_0005
                                   1113 ;	quantum/action.c:483: pressed = record->event.pressed;
      007711 A3               [24] 1114 	inc	dptr
      007712 A3               [24] 1115 	inc	dptr
      007713 A3               [24] 1116 	inc	dptr
      007714 A3               [24] 1117 	inc	dptr
      007715 A3               [24] 1118 	inc	dptr
      007716 E0               [24] 1119 	movx	a,@dptr
      007717 F5 27            [12] 1120 	mov	_process_action_sloc0_1_0,a
                                   1121 ;	quantum/action.c:507: switch (action.kind.id) {
      007719 90 08 5E         [24] 1122 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00771C E0               [24] 1123 	movx	a,@dptr
      00771D C4               [12] 1124 	swap	a
      00771E 54 0F            [12] 1125 	anl	a,#0x0f
      007720 FD               [12] 1126 	mov  r5,a
      007721 24 F4            [12] 1127 	add	a,#0xff - 0x0b
      007723 50 03            [24] 1128 	jnc	00434$
      007725 02 79 B5         [24] 1129 	ljmp	00181$
      007728                       1130 00434$:
                                   1131 ;	free result
      007728 ED               [12] 1132 	mov	a,r5
      007729 24 0A            [12] 1133 	add	a,#(00435$-3-.)
      00772B 83               [24] 1134 	movc	a,@a+pc
      00772C F5 82            [12] 1135 	mov	dpl,a
      00772E ED               [12] 1136 	mov	a,r5
      00772F 24 10            [12] 1137 	add	a,#(00436$-3-.)
      007731 83               [24] 1138 	movc	a,@a+pc
      007732 F5 83            [12] 1139 	mov	dph,a
      007734 E4               [12] 1140 	clr	a
      007735 73               [24] 1141 	jmp	@a+dptr
      007736                       1142 00435$:
      007736 4E                    1143 	.db	00102$
      007737 4E                    1144 	.db	00102$
      007738 B5                    1145 	.db	00181$
      007739 B5                    1146 	.db	00181$
      00773A D8                    1147 	.db	00123$
      00773B 38                    1148 	.db	00130$
      00773C B5                    1149 	.db	00181$
      00773D B5                    1150 	.db	00181$
      00773E 4A                    1151 	.db	00131$
      00773F 1C                    1152 	.db	00147$
      007740 42                    1153 	.db	00152$
      007741 42                    1154 	.db	00152$
      007742                       1155 00436$:
      007742 77                    1156 	.db	00102$>>8
      007743 77                    1157 	.db	00102$>>8
      007744 79                    1158 	.db	00181$>>8
      007745 79                    1159 	.db	00181$>>8
      007746 77                    1160 	.db	00123$>>8
      007747 78                    1161 	.db	00130$>>8
      007748 79                    1162 	.db	00181$>>8
      007749 79                    1163 	.db	00181$>>8
      00774A 78                    1164 	.db	00131$>>8
      00774B 79                    1165 	.db	00147$>>8
      00774C 79                    1166 	.db	00152$>>8
      00774D 79                    1167 	.db	00152$>>8
                                   1168 ;	quantum/action.c:510: case ACT_RMODS: {
      00774E                       1169 00102$:
                                   1170 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00774E 90 08 5E         [24] 1171 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007751 E0               [24] 1172 	movx	a,@dptr
      007752 54 F0            [12] 1173 	anl	a,#0xf0
      007754 70 06            [24] 1174 	jnz	00194$
      007756 12 7C 06         [24] 1175 	lcall	_ak820_outline_0113
      007759 FD               [12] 1176 	mov	r5,a
      00775A 80 07            [24] 1177 	sjmp	00195$
      00775C                       1178 00194$:
      00775C 12 7C 06         [24] 1179 	lcall	_ak820_outline_0113
      00775F C4               [12] 1180 	swap	a
      007760 54 F0            [12] 1181 	anl	a,#0xf0
      007762 FD               [12] 1182 	mov	r5,a
      007763                       1183 00195$:
                                   1184 ;	quantum/action.c:513: if (pressed) {
      007763 E5 27            [12] 1185 	mov	a,_process_action_sloc0_1_0
      007765 60 35            [24] 1186 	jz	00119$
                                   1187 ;	quantum/action.c:514: if (mods) {
      007767 ED               [12] 1188 	mov	a,r5
      007768 60 29            [24] 1189 	jz	00110$
                                   1190 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00776A 12 7C 2E         [24] 1191 	lcall	_ak820_outline_0151
      00776D FC               [12] 1192 	mov	r4,a
      00776E BC E0 00         [24] 1193 	cjne	r4,#0xe0,00440$
      007771                       1194 00440$:
      007771 40 07            [24] 1195 	jc	00108$
      007773 12 7C 2E         [24] 1196 	lcall	_ak820_outline_0151
      007776 24 18            [12] 1197 	add	a,#0xff - 0xe7
      007778 50 0A            [24] 1198 	jnc	00104$
                                   1199 ;	free result
      00777A                       1200 00108$:
      00777A 7B 5D            [12] 1201 	mov	r3,#_process_action_PARM_2
      00777C 7C 08            [12] 1202 	mov	r4,#(_process_action_PARM_2 >> 8)
      00777E 12 36 47         [24] 1203 	lcall	_ak820_outline_0123
      007781 E0               [24] 1204 	movx	a,@dptr
      007782 70 07            [24] 1205 	jnz	00105$
      007784                       1206 00104$:
                                   1207 ;	quantum/action.c:519: add_owned_mods(mods);
      007784 8D 82            [24] 1208 	mov	dpl, r5
      007786 12 81 7C         [24] 1209 	lcall	_add_owned_mods
      007789 80 05            [24] 1210 	sjmp	00106$
      00778B                       1211 00105$:
                                   1212 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      00778B 8D 82            [24] 1213 	mov	dpl, r5
      00778D 12 81 98         [24] 1214 	lcall	_add_owned_weak_mods
      007790                       1215 00106$:
                                   1216 ;	quantum/action.c:523: send_keyboard_report();
      007790 12 84 AD         [24] 1217 	lcall	_send_keyboard_report
      007793                       1218 00110$:
                                   1219 ;	quantum/action.c:525: register_code(action.key.code);
      007793 12 7B F6         [24] 1220 	lcall	_ak820_outline_0078
      007796 12 79 CC         [24] 1221 	lcall	_register_code
      007799 02 79 B5         [24] 1222 	ljmp	00181$
      00779C                       1223 00119$:
                                   1224 ;	quantum/action.c:527: unregister_code(action.key.code);
      00779C 12 7B F6         [24] 1225 	lcall	_ak820_outline_0078
      00779F C0 05            [24] 1226 	push	ar5
      0077A1 12 7A 51         [24] 1227 	lcall	_unregister_code
      0077A4 D0 05            [24] 1228 	pop	ar5
                                   1229 ;	quantum/action.c:528: if (mods) {
      0077A6 ED               [12] 1230 	mov	a,r5
      0077A7 70 03            [24] 1231 	jnz	00444$
      0077A9 02 79 B5         [24] 1232 	ljmp	00181$
      0077AC                       1233 00444$:
                                   1234 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0077AC 12 7C 2E         [24] 1235 	lcall	_ak820_outline_0151
      0077AF FC               [12] 1236 	mov	r4,a
      0077B0 BC E0 00         [24] 1237 	cjne	r4,#0xe0,00445$
      0077B3                       1238 00445$:
      0077B3 40 07            [24] 1239 	jc	00115$
      0077B5 12 7C 2E         [24] 1240 	lcall	_ak820_outline_0151
      0077B8 24 18            [12] 1241 	add	a,#0xff - 0xe7
      0077BA 50 0A            [24] 1242 	jnc	00111$
                                   1243 ;	free result
      0077BC                       1244 00115$:
      0077BC 7B 5D            [12] 1245 	mov	r3,#_process_action_PARM_2
      0077BE 7C 08            [12] 1246 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077C0 12 36 47         [24] 1247 	lcall	_ak820_outline_0123
      0077C3 E0               [24] 1248 	movx	a,@dptr
      0077C4 70 07            [24] 1249 	jnz	00112$
      0077C6                       1250 00111$:
                                   1251 ;	quantum/action.c:530: del_owned_mods(mods);
      0077C6 8D 82            [24] 1252 	mov	dpl, r5
      0077C8 12 81 8B         [24] 1253 	lcall	_del_owned_mods
      0077CB 80 05            [24] 1254 	sjmp	00113$
      0077CD                       1255 00112$:
                                   1256 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      0077CD 8D 82            [24] 1257 	mov	dpl, r5
      0077CF 12 81 A7         [24] 1258 	lcall	_del_owned_weak_mods
      0077D2                       1259 00113$:
                                   1260 ;	quantum/action.c:534: send_keyboard_report();
      0077D2 12 84 AD         [24] 1261 	lcall	_send_keyboard_report
                                   1262 ;	quantum/action.c:537: } break;
      0077D5 02 79 B5         [24] 1263 	ljmp	00181$
                                   1264 ;	quantum/action.c:614: case ACT_USAGE:
      0077D8                       1265 00123$:
                                   1266 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0077D8 74 07            [12] 1267 	mov	a,#0x07
      0077DA 12 3A 71         [24] 1268 	lcall	_ak820_outline_0022
      0077DD 12 4A 5E         [24] 1269 	lcall	_ak820_outline_0008
      0077E0 C3               [12] 1270 	clr	c
      0077E1 EC               [12] 1271 	mov	a,r4
      0077E2 94 A5            [12] 1272 	subb	a,#0xa5
      0077E4 ED               [12] 1273 	mov	a,r5
      0077E5 94 00            [12] 1274 	subb	a,#0x00
      0077E7 40 15            [24] 1275 	jc	00125$
      0077E9 74 C2            [12] 1276 	mov	a,#0xc2
      0077EB 9C               [12] 1277 	subb	a,r4
      0077EC E4               [12] 1278 	clr	a
      0077ED 9D               [12] 1279 	subb	a,r5
      0077EE 40 0E            [24] 1280 	jc	00125$
                                   1281 ;	free result
                                   1282 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      0077F0 90 0A BE         [24] 1283 	mov	dptr,#_owned_usage_key_PARM_2
      0077F3 E5 27            [12] 1284 	mov	a,_process_action_sloc0_1_0
      0077F5 F0               [24] 1285 	movx	@dptr,a
      0077F6 8E 82            [24] 1286 	mov	dpl, r6
      0077F8 12 83 5A         [24] 1287 	lcall	_owned_usage_key
                                   1288 ;	quantum/action.c:622: break;
      0077FB 02 79 B5         [24] 1289 	ljmp	00181$
      0077FE                       1290 00125$:
                                   1291 ;	quantum/action.c:625: switch (action.usage.page) {
      0077FE 12 7B FD         [24] 1292 	lcall	_ak820_outline_0089
      007801 FF               [12] 1293 	mov	r7,a
      007802 60 08            [24] 1294 	jz	00127$
      007804 BF 01 02         [24] 1295 	cjne	r7,#0x01,00452$
      007807 80 19            [24] 1296 	sjmp	00128$
      007809                       1297 00452$:
      007809 02 79 B5         [24] 1298 	ljmp	00181$
                                   1299 ;	quantum/action.c:626: case PAGE_SYSTEM:
      00780C                       1300 00127$:
                                   1301 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      00780C E5 27            [12] 1302 	mov	a,_process_action_sloc0_1_0
      00780E 60 05            [24] 1303 	jz	00196$
      007810 12 7C 0D         [24] 1304 	lcall	_ak820_outline_0130
      007813 80 04            [24] 1305 	sjmp	00197$
      007815                       1306 00196$:
      007815 7E 00            [12] 1307 	mov	r6,#0x00
      007817 7F 00            [12] 1308 	mov	r7,#0x00
      007819                       1309 00197$:
      007819 12 3A CC         [24] 1310 	lcall	_ak820_outline_0118
      00781C 12 71 98         [24] 1311 	lcall	_host_system_send
                                   1312 ;	quantum/action.c:628: break;
      00781F 02 79 B5         [24] 1313 	ljmp	00181$
                                   1314 ;	quantum/action.c:629: case PAGE_CONSUMER:
      007822                       1315 00128$:
                                   1316 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      007822 E5 27            [12] 1317 	mov	a,_process_action_sloc0_1_0
      007824 60 05            [24] 1318 	jz	00198$
      007826 12 7C 0D         [24] 1319 	lcall	_ak820_outline_0130
      007829 80 04            [24] 1320 	sjmp	00199$
      00782B                       1321 00198$:
      00782B 7E 00            [12] 1322 	mov	r6,#0x00
      00782D 7F 00            [12] 1323 	mov	r7,#0x00
      00782F                       1324 00199$:
      00782F 12 3A CC         [24] 1325 	lcall	_ak820_outline_0118
      007832 12 71 C7         [24] 1326 	lcall	_host_consumer_send
                                   1327 ;	quantum/action.c:633: break;
      007835 02 79 B5         [24] 1328 	ljmp	00181$
                                   1329 ;	quantum/action.c:636: case ACT_MOUSEKEY:
      007838                       1330 00130$:
                                   1331 ;	quantum/action.c:637: register_mouse(action.key.code, pressed);
      007838 12 7C 2E         [24] 1332 	lcall	_ak820_outline_0151
      00783B FF               [12] 1333 	mov	r7,a
      00783C 90 08 5B         [24] 1334 	mov	dptr,#_register_mouse_PARM_2
      00783F E5 27            [12] 1335 	mov	a,_process_action_sloc0_1_0
      007841 F0               [24] 1336 	movx	@dptr,a
      007842 8F 82            [24] 1337 	mov	dpl, r7
      007844 12 76 DF         [24] 1338 	lcall	_register_mouse
                                   1339 ;	quantum/action.c:638: break;
      007847 02 79 B5         [24] 1340 	ljmp	00181$
                                   1341 ;	quantum/action.c:640: case ACT_LAYER: {
      00784A                       1342 00131$:
                                   1343 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      00784A 90 08 5E         [24] 1344 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00784D E0               [24] 1345 	movx	a,@dptr
      00784E 54 03            [12] 1346 	anl	a,#0x03
      007850 90 08 62         [24] 1347 	mov	dptr,#_process_action_on_40000_685
      007853 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007854 E0               [24] 1350 	movx	a,@dptr
      007855 FF               [12] 1351 	mov	r7,a
      007856 60 11            [24] 1352 	jz	00200$
      007858 E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      00785A 60 07            [24] 1354 	jz	00202$
      00785C 8F 06            [24] 1355 	mov	ar6,r7
      00785E 53 06 01         [24] 1356 	anl	ar6,#0x01
      007861 80 10            [24] 1357 	sjmp	00201$
      007863                       1358 00202$:
      007863 74 02            [12] 1359 	mov	a,#0x02
      007865 5F               [12] 1360 	anl	a,r7
      007866 FE               [12] 1361 	mov	r6,a
      007867 80 0A            [24] 1362 	sjmp	00201$
      007869                       1363 00200$:
      007869 E5 27            [12] 1364 	mov	a,_process_action_sloc0_1_0
      00786B B4 01 00         [24] 1365 	cjne	a,#0x01,00457$
      00786E                       1366 00457$:
      00786E 92 20            [24] 1367 	mov  _process_action_sloc1_1_0,c
      007870 E4               [12] 1368 	clr	a
      007871 33               [12] 1369 	rlc	a
      007872 FE               [12] 1370 	mov	r6,a
      007873                       1371 00201$:
      007873 EE               [12] 1372 	mov	a,r6
      007874 70 03            [24] 1373 	jnz	00458$
      007876 02 79 B5         [24] 1374 	ljmp	00181$
      007879                       1375 00458$:
                                   1376 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      007879 12 7C 2E         [24] 1377 	lcall	_ak820_outline_0151
      00787C C4               [12] 1378 	swap	a
      00787D 03               [12] 1379 	rr	a
      00787E 54 07            [12] 1380 	anl	a,#0x07
      007880 25 E0            [12] 1381 	add	a,acc
      007882 25 E0            [12] 1382 	add	a,acc
      007884 FF               [12] 1383 	mov	r7,a
                                   1384 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007885 12 7C 2E         [24] 1385 	lcall	_ak820_outline_0151
      007888 54 0F            [12] 1386 	anl	a,#0x0f
      00788A FE               [12] 1387 	mov	r6,a
      00788B 8F F0            [24] 1388 	mov	b,r7
      00788D 05 F0            [12] 1389 	inc	b
      00788F EE               [12] 1390 	mov	a,r6
      007890 80 02            [24] 1391 	sjmp	00460$
      007892                       1392 00459$:
      007892 25 E0            [12] 1393 	add	a,acc
      007894                       1394 00460$:
      007894 D5 F0 FB         [24] 1395 	djnz	b,00459$
      007897 FE               [12] 1396 	mov	r6,a
                                   1397 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007898 12 7C 2E         [24] 1398 	lcall	_ak820_outline_0151
      00789B 30 E4 11         [24] 1399 	jnb	acc.4,00204$
      00789E 8F F0            [24] 1400 	mov	b,r7
      0078A0 05 F0            [12] 1401 	inc	b
      0078A2 74 0F            [12] 1402 	mov	a,#0x0f
      0078A4 80 02            [24] 1403 	sjmp	00463$
      0078A6                       1404 00462$:
      0078A6 25 E0            [12] 1405 	add	a,acc
      0078A8                       1406 00463$:
      0078A8 D5 F0 FB         [24] 1407 	djnz	b,00462$
      0078AB F4               [12] 1408 	cpl	a
      0078AC FF               [12] 1409 	mov	r7,a
      0078AD 80 02            [24] 1410 	sjmp	00205$
      0078AF                       1411 00204$:
      0078AF 7F 00            [12] 1412 	mov	r7,#0x00
      0078B1                       1413 00205$:
                                   1414 ;	quantum/action.c:648: bits |= mask;
      0078B1 EE               [12] 1415 	mov	a,r6
      0078B2 42 07            [12] 1416 	orl	ar7,a
                                   1417 ;	quantum/action.c:649: if (!on) {
      0078B4 90 08 62         [24] 1418 	mov	dptr,#_process_action_on_40000_685
      0078B7 E0               [24] 1419 	movx	a,@dptr
      0078B8 70 31            [24] 1420 	jnz	00143$
                                   1421 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0078BA 12 7B FD         [24] 1422 	lcall	_ak820_outline_0089
      0078BD FE               [12] 1423 	mov	r6,a
      0078BE 2E               [12] 1424 	add	a,r6
                                   1425 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0078BF 90 78 C3         [24] 1426 	mov	dptr,#00465$
      0078C2 73               [24] 1427 	jmp	@a+dptr
      0078C3                       1428 00465$:
      0078C3 80 06            [24] 1429 	sjmp	00132$
      0078C5 80 0C            [24] 1430 	sjmp	00133$
      0078C7 80 12            [24] 1431 	sjmp	00134$
      0078C9 80 18            [24] 1432 	sjmp	00135$
      0078CB                       1433 00132$:
      0078CB 8F 82            [24] 1434 	mov	dpl, r7
      0078CD 12 7C 82         [24] 1435 	lcall	_default_layer_and
      0078D0 02 79 B5         [24] 1436 	ljmp	00181$
                                   1437 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      0078D3                       1438 00133$:
      0078D3 8F 82            [24] 1439 	mov	dpl, r7
      0078D5 12 7C 72         [24] 1440 	lcall	_default_layer_or
      0078D8 02 79 B5         [24] 1441 	ljmp	00181$
                                   1442 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      0078DB                       1443 00134$:
      0078DB 8F 82            [24] 1444 	mov	dpl, r7
      0078DD 12 7C 97         [24] 1445 	lcall	_default_layer_xor
      0078E0 02 79 B5         [24] 1446 	ljmp	00181$
                                   1447 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      0078E3                       1448 00135$:
      0078E3 8F 82            [24] 1449 	mov	dpl, r7
      0078E5 12 7C 68         [24] 1450 	lcall	_default_layer_set
                                   1451 ;	quantum/action.c:655: }
      0078E8 02 79 B5         [24] 1452 	ljmp	00181$
      0078EB                       1453 00143$:
                                   1454 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      0078EB 12 7B FD         [24] 1455 	lcall	_ak820_outline_0089
      0078EE FE               [12] 1456 	mov	r6,a
      0078EF 2E               [12] 1457 	add	a,r6
                                   1458 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      0078F0 90 78 F4         [24] 1459 	mov	dptr,#00466$
      0078F3 73               [24] 1460 	jmp	@a+dptr
      0078F4                       1461 00466$:
      0078F4 80 06            [24] 1462 	sjmp	00137$
      0078F6 80 0C            [24] 1463 	sjmp	00138$
      0078F8 80 12            [24] 1464 	sjmp	00139$
      0078FA 80 18            [24] 1465 	sjmp	00140$
      0078FC                       1466 00137$:
      0078FC 8F 82            [24] 1467 	mov	dpl, r7
      0078FE 12 7E 0F         [24] 1468 	lcall	_layer_and
      007901 02 79 B5         [24] 1469 	ljmp	00181$
                                   1470 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007904                       1471 00138$:
      007904 8F 82            [24] 1472 	mov	dpl, r7
      007906 12 7D FF         [24] 1473 	lcall	_layer_or
      007909 02 79 B5         [24] 1474 	ljmp	00181$
                                   1475 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      00790C                       1476 00139$:
      00790C 8F 82            [24] 1477 	mov	dpl, r7
      00790E 12 7E 24         [24] 1478 	lcall	_layer_xor
      007911 02 79 B5         [24] 1479 	ljmp	00181$
                                   1480 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007914                       1481 00140$:
      007914 8F 82            [24] 1482 	mov	dpl, r7
      007916 12 7D A1         [24] 1483 	lcall	_layer_state_set
                                   1484 ;	quantum/action.c:665: break;
      007919 02 79 B5         [24] 1485 	ljmp	00181$
                                   1486 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      00791C                       1487 00147$:
                                   1488 ;	quantum/action.c:668: if (pressed) {
      00791C E5 27            [12] 1489 	mov	a,_process_action_sloc0_1_0
      00791E 60 11            [24] 1490 	jz	00149$
                                   1491 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007920 12 7C 06         [24] 1492 	lcall	_ak820_outline_0113
      007923 F5 82            [12] 1493 	mov	dpl,a
      007925 12 7D 05         [24] 1494 	lcall	_layer_hold_on
                                   1495 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007928 12 7B F6         [24] 1496 	lcall	_ak820_outline_0078
      00792B 12 7B 19         [24] 1497 	lcall	_register_mods
      00792E 02 79 B5         [24] 1498 	ljmp	00181$
      007931                       1499 00149$:
                                   1500 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007931 12 7B F6         [24] 1501 	lcall	_ak820_outline_0078
      007934 12 7B 2D         [24] 1502 	lcall	_unregister_mods
                                   1503 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007937 12 7C 06         [24] 1504 	lcall	_ak820_outline_0113
      00793A F5 82            [12] 1505 	mov	dpl,a
      00793C 12 7D 3C         [24] 1506 	lcall	_layer_hold_off
                                   1507 ;	quantum/action.c:675: break;
      00793F 02 79 B5         [24] 1508 	ljmp	00181$
                                   1509 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007942                       1510 00152$:
                                   1511 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007942 12 7C 2E         [24] 1512 	lcall	_ak820_outline_0151
      007945 FF               [12] 1513 	mov	r7,a
      007946 BF F1 02         [24] 1514 	cjne	r7,#0xf1,00468$
      007949 80 0A            [24] 1515 	sjmp	00154$
      00794B                       1516 00468$:
      00794B BF F2 02         [24] 1517 	cjne	r7,#0xf2,00469$
      00794E 80 19            [24] 1518 	sjmp	00155$
      007950                       1519 00469$:
                                   1520 ;	quantum/action.c:694: momentary_layer_action:
      007950 BF F3 3B         [24] 1521 	cjne	r7,#0xf3,00160$
      007953 80 28            [24] 1522 	sjmp	00156$
      007955                       1523 00154$:
                                   1524 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007955 E5 27            [12] 1525 	mov	a,_process_action_sloc0_1_0
      007957 60 08            [24] 1526 	jz	00206$
      007959 12 7B DC         [24] 1527 	lcall	_ak820_outline_0042
      00795C 12 7D 05         [24] 1528 	lcall	_layer_hold_on
      00795F 80 54            [24] 1529 	sjmp	00181$
      007961                       1530 00206$:
      007961 12 7B DC         [24] 1531 	lcall	_ak820_outline_0042
      007964 12 7D 3C         [24] 1532 	lcall	_layer_hold_off
                                   1533 ;	quantum/action.c:696: break;
                                   1534 ;	quantum/action.c:697: case OP_OFF_ON:
      007967 80 4C            [24] 1535 	sjmp	00181$
      007969                       1536 00155$:
                                   1537 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007969 E5 27            [12] 1538 	mov	a,_process_action_sloc0_1_0
      00796B 60 08            [24] 1539 	jz	00208$
      00796D 12 7B DC         [24] 1540 	lcall	_ak820_outline_0042
      007970 12 7D E2         [24] 1541 	lcall	_layer_off
      007973 80 40            [24] 1542 	sjmp	00181$
      007975                       1543 00208$:
      007975 12 7B DC         [24] 1544 	lcall	_ak820_outline_0042
      007978 12 7D C8         [24] 1545 	lcall	_layer_on
                                   1546 ;	quantum/action.c:699: break;
                                   1547 ;	quantum/action.c:700: case OP_SET_CLEAR:
      00797B 80 38            [24] 1548 	sjmp	00181$
      00797D                       1549 00156$:
                                   1550 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00797D E5 27            [12] 1551 	mov	a,_process_action_sloc0_1_0
      00797F 60 08            [24] 1552 	jz	00210$
      007981 12 7B DC         [24] 1553 	lcall	_ak820_outline_0042
      007984 12 7D B3         [24] 1554 	lcall	_layer_move
      007987 80 2C            [24] 1555 	sjmp	00181$
      007989                       1556 00210$:
      007989 12 7D AE         [24] 1557 	lcall	_layer_clear
                                   1558 ;	quantum/action.c:702: break;
                                   1559 ;	quantum/action.c:748: default:
      00798C 80 27            [24] 1560 	sjmp	00181$
      00798E                       1561 00160$:
                                   1562 ;	quantum/action.c:755: if (pressed) {
      00798E E5 27            [12] 1563 	mov	a,_process_action_sloc0_1_0
      007990 60 08            [24] 1564 	jz	00163$
                                   1565 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007992 12 7B F6         [24] 1566 	lcall	_ak820_outline_0078
      007995 12 79 CC         [24] 1567 	lcall	_register_code
                                   1568 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007998 80 1B            [24] 1569 	sjmp	00181$
      00799A                       1570 00163$:
                                   1571 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      00799A 12 7C 2E         [24] 1572 	lcall	_ak820_outline_0151
      00799D FF               [12] 1573 	mov	r7,a
      00799E BF 39 0E         [24] 1574 	cjne	r7,#0x39,00175$
                                   1575 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0079A1 7F 50            [12] 1576 	mov	r7,#0x50
      0079A3                       1577 00187$:
      0079A3 EF               [12] 1578 	mov	a,r7
      0079A4 60 09            [24] 1579 	jz	00175$
      0079A6 90 00 01         [24] 1580 	mov	dptr,#0x0001
      0079A9 12 5D 6C         [24] 1581 	lcall	_mDelaymS
      0079AC 1F               [12] 1582 	dec	r7
                                   1583 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0079AD 80 F4            [24] 1584 	sjmp	00187$
      0079AF                       1585 00175$:
                                   1586 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0079AF 12 7B F6         [24] 1587 	lcall	_ak820_outline_0078
      0079B2 12 7A 51         [24] 1588 	lcall	_unregister_code
                                   1589 ;	quantum/action.c:848: }
      0079B5                       1590 00181$:
                                   1591 ;	quantum/action.c:869: switch (action.kind.id) {
      0079B5 90 08 5E         [24] 1592 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079B8 E0               [24] 1593 	movx	a,@dptr
      0079B9 C4               [12] 1594 	swap	a
      0079BA 54 0F            [12] 1595 	anl	a,#0x0f
      0079BC FF               [12] 1596 	mov	r7,a
      0079BD BF 08 02         [24] 1597 	cjne	r7,#0x08,00478$
      0079C0 80 03            [24] 1598 	sjmp	00183$
      0079C2                       1599 00478$:
      0079C2 BF 09 06         [24] 1600 	cjne	r7,#0x09,00192$
                                   1601 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      0079C5                       1602 00183$:
                                   1603 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      0079C5 12 70 FD         [24] 1604 	lcall	_host_keyboard_leds
                                   1605 ;	quantum/action.c:880: }
                                   1606 ;	quantum/action.c:933: }
      0079C8 02 9B B9         [24] 1607 	ljmp	_led_set
      0079CB                       1608 00192$:
      0079CB 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'register_code'
                                   1612 ;------------------------------------------------------------
                                   1613 ;code          Allocated with name '_register_code_code_10000_719'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function register_code
                                   1618 ;	-----------------------------------------
      0079CC                       1619 _register_code:
      0079CC E5 82            [12] 1620 	mov	a,dpl
      0079CE 90 08 63         [24] 1621 	mov	dptr,#_register_code_code_10000_719
      0079D1 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:940: if (code == KC_NO) {
      0079D2 E0               [24] 1624 	movx	a,@dptr
      0079D3 FF               [12] 1625 	mov	r7,a
      0079D4 70 01            [24] 1626 	jnz	00123$
                                   1627 ;	quantum/action.c:941: return;
      0079D6 22               [24] 1628 	ret
      0079D7                       1629 00123$:
                                   1630 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      0079D7 BF 04 00         [24] 1631 	cjne	r7,#0x04,00198$
      0079DA                       1632 00198$:
      0079DA 40 12            [24] 1633 	jc	00119$
      0079DC EF               [12] 1634 	mov	a,r7
      0079DD 24 5B            [12] 1635 	add	a,#0xff - 0xa4
      0079DF 40 0D            [24] 1636 	jc	00119$
                                   1637 ;	free result
                                   1638 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      0079E1 8F 82            [24] 1639 	mov	dpl, r7
      0079E3 12 82 1B         [24] 1640 	lcall	_add_owned_key
      0079E6 E5 82            [12] 1641 	mov	a, dpl
      0079E8 70 01            [24] 1642 	jnz	00104$
      0079EA 22               [24] 1643 	ret
      0079EB                       1644 00104$:
                                   1645 ;	quantum/action.c:995: send_keyboard_report();
      0079EB 02 84 AD         [24] 1646 	ljmp	_send_keyboard_report
      0079EE                       1647 00119$:
                                   1648 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079EE 12 7C 18         [24] 1649 	lcall	_ak820_outline_0141
      0079F1 BF E0 00         [24] 1650 	cjne	r7,#0xe0,00202$
      0079F4                       1651 00202$:
      0079F4 40 1A            [24] 1652 	jc	00115$
      0079F6 EF               [12] 1653 	mov	a,r7
      0079F7 24 18            [12] 1654 	add	a,#0xff - 0xe7
      0079F9 40 15            [24] 1655 	jc	00115$
                                   1656 ;	free result
                                   1657 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      0079FB 74 07            [12] 1658 	mov	a,#0x07
      0079FD 5F               [12] 1659 	anl	a,r7
      0079FE 12 7B E5         [24] 1660 	lcall	_ak820_outline_0061
      007A01 80 02            [24] 1661 	sjmp	00206$
      007A03                       1662 00205$:
      007A03 25 E0            [12] 1663 	add	a,acc
      007A05                       1664 00206$:
      007A05 D5 F0 FB         [24] 1665 	djnz	b,00205$
      007A08 F5 82            [12] 1666 	mov	dpl,a
      007A0A 12 81 7C         [24] 1667 	lcall	_add_owned_mods
                                   1668 ;	quantum/action.c:998: send_keyboard_report();
      007A0D 02 84 AD         [24] 1669 	ljmp	_send_keyboard_report
      007A10                       1670 00115$:
                                   1671 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A10 12 7C 18         [24] 1672 	lcall	_ak820_outline_0141
      007A13 BF A5 00         [24] 1673 	cjne	r7,#0xa5,00207$
      007A16                       1674 00207$:
      007A16 40 05            [24] 1675 	jc	00113$
      007A18 EF               [12] 1676 	mov	a,r7
      007A19 24 58            [12] 1677 	add	a,#0xff - 0xa7
      007A1B 50 0D            [24] 1678 	jnc	00108$
                                   1679 ;	free result
      007A1D                       1680 00113$:
      007A1D 12 7C 18         [24] 1681 	lcall	_ak820_outline_0141
      007A20 BF A8 00         [24] 1682 	cjne	r7,#0xa8,00210$
      007A23                       1683 00210$:
      007A23 40 13            [24] 1684 	jc	00109$
      007A25 EF               [12] 1685 	mov	a,r7
      007A26 24 3D            [12] 1686 	add	a,#0xff - 0xc2
      007A28 40 0E            [24] 1687 	jc	00109$
                                   1688 ;	free result
      007A2A                       1689 00108$:
                                   1690 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007A2A 12 7C 18         [24] 1691 	lcall	_ak820_outline_0141
      007A2D 90 0A BE         [24] 1692 	mov	dptr,#_owned_usage_key_PARM_2
      007A30 74 01            [12] 1693 	mov	a,#0x01
      007A32 F0               [24] 1694 	movx	@dptr,a
      007A33 8F 82            [24] 1695 	mov	dpl, r7
      007A35 02 83 5A         [24] 1696 	ljmp	_owned_usage_key
      007A38                       1697 00109$:
                                   1698 ;	quantum/action.c:1010: } else if (IS_MOUSE_KEYCODE(code)) {
      007A38 12 7C 18         [24] 1699 	lcall	_ak820_outline_0141
      007A3B BF CD 00         [24] 1700 	cjne	r7,#0xcd,00213$
      007A3E                       1701 00213$:
      007A3E 40 10            [24] 1702 	jc	00125$
      007A40 EF               [12] 1703 	mov	a,r7
      007A41 24 20            [12] 1704 	add	a,#0xff - 0xdf
      007A43 40 0B            [24] 1705 	jc	00125$
                                   1706 ;	free result
                                   1707 ;	quantum/action.c:1011: register_mouse(code, true);
      007A45 90 08 5B         [24] 1708 	mov	dptr,#_register_mouse_PARM_2
      007A48 74 01            [12] 1709 	mov	a,#0x01
      007A4A F0               [24] 1710 	movx	@dptr,a
      007A4B 8F 82            [24] 1711 	mov	dpl, r7
                                   1712 ;	quantum/action.c:1013: }
      007A4D 02 76 DF         [24] 1713 	ljmp	_register_mouse
      007A50                       1714 00125$:
      007A50 22               [24] 1715 	ret
                                   1716 ;------------------------------------------------------------
                                   1717 ;Allocation info for local variables in function 'unregister_code'
                                   1718 ;------------------------------------------------------------
                                   1719 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function unregister_code
                                   1724 ;	-----------------------------------------
      007A51                       1725 _unregister_code:
      007A51 E5 82            [12] 1726 	mov	a,dpl
      007A53 90 08 64         [24] 1727 	mov	dptr,#_unregister_code_code_10000_733
      007A56 F0               [24] 1728 	movx	@dptr,a
                                   1729 ;	quantum/action.c:1020: if (code == KC_NO) {
      007A57 E0               [24] 1730 	movx	a,@dptr
      007A58 FF               [12] 1731 	mov	r7,a
      007A59 70 01            [24] 1732 	jnz	00121$
                                   1733 ;	quantum/action.c:1021: return;
      007A5B 22               [24] 1734 	ret
      007A5C                       1735 00121$:
                                   1736 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007A5C BF 04 00         [24] 1737 	cjne	r7,#0x04,00196$
      007A5F                       1738 00196$:
      007A5F 40 12            [24] 1739 	jc	00117$
      007A61 EF               [12] 1740 	mov	a,r7
      007A62 24 5B            [12] 1741 	add	a,#0xff - 0xa4
      007A64 40 0D            [24] 1742 	jc	00117$
                                   1743 ;	free result
                                   1744 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      007A66 8F 82            [24] 1745 	mov	dpl, r7
      007A68 12 82 94         [24] 1746 	lcall	_del_owned_key
      007A6B E5 82            [12] 1747 	mov	a, dpl
      007A6D 70 01            [24] 1748 	jnz	00102$
      007A6F 22               [24] 1749 	ret
      007A70                       1750 00102$:
                                   1751 ;	quantum/action.c:1062: send_keyboard_report();
      007A70 02 84 AD         [24] 1752 	ljmp	_send_keyboard_report
      007A73                       1753 00117$:
                                   1754 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A73 12 7C 1E         [24] 1755 	lcall	_ak820_outline_0142
      007A76 BF E0 00         [24] 1756 	cjne	r7,#0xe0,00200$
      007A79                       1757 00200$:
      007A79 40 1A            [24] 1758 	jc	00113$
      007A7B EF               [12] 1759 	mov	a,r7
      007A7C 24 18            [12] 1760 	add	a,#0xff - 0xe7
      007A7E 40 15            [24] 1761 	jc	00113$
                                   1762 ;	free result
                                   1763 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      007A80 74 07            [12] 1764 	mov	a,#0x07
      007A82 5F               [12] 1765 	anl	a,r7
      007A83 12 7B E5         [24] 1766 	lcall	_ak820_outline_0061
      007A86 80 02            [24] 1767 	sjmp	00204$
      007A88                       1768 00203$:
      007A88 25 E0            [12] 1769 	add	a,acc
      007A8A                       1770 00204$:
      007A8A D5 F0 FB         [24] 1771 	djnz	b,00203$
      007A8D F5 82            [12] 1772 	mov	dpl,a
      007A8F 12 81 8B         [24] 1773 	lcall	_del_owned_mods
                                   1774 ;	quantum/action.c:1065: send_keyboard_report();
      007A92 02 84 AD         [24] 1775 	ljmp	_send_keyboard_report
      007A95                       1776 00113$:
                                   1777 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A95 12 7C 1E         [24] 1778 	lcall	_ak820_outline_0142
      007A98 BF A5 00         [24] 1779 	cjne	r7,#0xa5,00205$
      007A9B                       1780 00205$:
      007A9B 40 05            [24] 1781 	jc	00111$
      007A9D EF               [12] 1782 	mov	a,r7
      007A9E 24 58            [12] 1783 	add	a,#0xff - 0xa7
      007AA0 50 0D            [24] 1784 	jnc	00106$
                                   1785 ;	free result
      007AA2                       1786 00111$:
      007AA2 12 7C 1E         [24] 1787 	lcall	_ak820_outline_0142
      007AA5 BF A8 00         [24] 1788 	cjne	r7,#0xa8,00208$
      007AA8                       1789 00208$:
      007AA8 40 11            [24] 1790 	jc	00107$
      007AAA EF               [12] 1791 	mov	a,r7
      007AAB 24 3D            [12] 1792 	add	a,#0xff - 0xc2
      007AAD 40 0C            [24] 1793 	jc	00107$
                                   1794 ;	free result
      007AAF                       1795 00106$:
                                   1796 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007AAF 12 7C 1E         [24] 1797 	lcall	_ak820_outline_0142
      007AB2 90 0A BE         [24] 1798 	mov	dptr,#_owned_usage_key_PARM_2
      007AB5 12 7C 38         [24] 1799 	lcall	_ak820_outline_0189
      007AB8 02 83 5A         [24] 1800 	ljmp	_owned_usage_key
      007ABB                       1801 00107$:
                                   1802 ;	quantum/action.c:1077: } else if (IS_MOUSE_KEYCODE(code)) {
      007ABB 12 7C 1E         [24] 1803 	lcall	_ak820_outline_0142
      007ABE BF CD 00         [24] 1804 	cjne	r7,#0xcd,00211$
      007AC1                       1805 00211$:
      007AC1 40 0E            [24] 1806 	jc	00123$
      007AC3 EF               [12] 1807 	mov	a,r7
      007AC4 24 20            [12] 1808 	add	a,#0xff - 0xdf
      007AC6 40 09            [24] 1809 	jc	00123$
                                   1810 ;	free result
                                   1811 ;	quantum/action.c:1078: register_mouse(code, false);
      007AC8 90 08 5B         [24] 1812 	mov	dptr,#_register_mouse_PARM_2
      007ACB 12 7C 38         [24] 1813 	lcall	_ak820_outline_0189
                                   1814 ;	quantum/action.c:1080: }
      007ACE 02 76 DF         [24] 1815 	ljmp	_register_mouse
      007AD1                       1816 00123$:
      007AD1 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'tap_code_delay'
                                   1820 ;------------------------------------------------------------
                                   1821 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1822 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1823 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1824 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1825 ;------------------------------------------------------------
                                   1826 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1827 ;	-----------------------------------------
                                   1828 ;	 function tap_code_delay
                                   1829 ;	-----------------------------------------
      007AD2                       1830 _tap_code_delay:
      007AD2 E5 82            [12] 1831 	mov	a,dpl
      007AD4 90 08 67         [24] 1832 	mov	dptr,#_tap_code_delay_code_10000_746
      007AD7 F0               [24] 1833 	movx	@dptr,a
                                   1834 ;	quantum/action.c:1088: register_code(code);
      007AD8 E0               [24] 1835 	movx	a,@dptr
      007AD9 FF               [12] 1836 	mov	r7,a
      007ADA F5 82            [12] 1837 	mov	dpl,a
      007ADC C0 07            [24] 1838 	push	ar7
      007ADE 31 CC            [12] 1839 	acall	_register_code
      007AE0 D0 07            [24] 1840 	pop	ar7
                                   1841 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007AE2 90 08 65         [24] 1842 	mov	dptr,#_tap_code_delay_PARM_2
      007AE5 12 3A A4         [24] 1843 	lcall	_ak820_outline_0079
      007AE8                       1844 00110$:
      007AE8 ED               [12] 1845 	mov	a,r5
      007AE9 4E               [12] 1846 	orl	a,r6
      007AEA 60 0D            [24] 1847 	jz	00105$
                                   1848 ;	quantum/action.c:1090: wait_ms(1);
      007AEC 90 00 01         [24] 1849 	mov	dptr,#0x0001
      007AEF 12 5D 6C         [24] 1850 	lcall	_mDelaymS
                                   1851 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007AF2 1D               [12] 1852 	dec	r5
      007AF3 BD FF 01         [24] 1853 	cjne	r5,#0xff,00141$
      007AF6 1E               [12] 1854 	dec	r6
      007AF7                       1855 00141$:
      007AF7 80 EF            [24] 1856 	sjmp	00110$
      007AF9                       1857 00105$:
                                   1858 ;	quantum/action.c:1092: unregister_code(code);
      007AF9 8F 82            [24] 1859 	mov	dpl, r7
                                   1860 ;	quantum/action.c:1093: }
      007AFB 41 51            [12] 1861 	ajmp	_unregister_code
                                   1862 ;------------------------------------------------------------
                                   1863 ;Allocation info for local variables in function 'tap_code'
                                   1864 ;------------------------------------------------------------
                                   1865 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1866 ;------------------------------------------------------------
                                   1867 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1868 ;	-----------------------------------------
                                   1869 ;	 function tap_code
                                   1870 ;	-----------------------------------------
      007AFD                       1871 _tap_code:
      007AFD E5 82            [12] 1872 	mov	a,dpl
      007AFF 90 08 68         [24] 1873 	mov	dptr,#_tap_code_code_10000_753
      007B02 F0               [24] 1874 	movx	@dptr,a
                                   1875 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B03 E0               [24] 1876 	movx	a,@dptr
      007B04 FF               [12] 1877 	mov	r7,a
      007B05 BF 39 04         [24] 1878 	cjne	r7,#0x39,00103$
      007B08 7E 50            [12] 1879 	mov	r6,#0x50
      007B0A 80 02            [24] 1880 	sjmp	00104$
      007B0C                       1881 00103$:
      007B0C 7E 00            [12] 1882 	mov	r6,#0x00
      007B0E                       1883 00104$:
      007B0E 90 08 65         [24] 1884 	mov	dptr,#_tap_code_delay_PARM_2
      007B11 EE               [12] 1885 	mov	a,r6
      007B12 12 3A DC         [24] 1886 	lcall	_ak820_outline_0134
      007B15 8F 82            [24] 1887 	mov	dpl, r7
                                   1888 ;	quantum/action.c:1101: }
      007B17 41 D2            [12] 1889 	ajmp	_tap_code_delay
                                   1890 ;------------------------------------------------------------
                                   1891 ;Allocation info for local variables in function 'register_mods'
                                   1892 ;------------------------------------------------------------
                                   1893 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function register_mods
                                   1898 ;	-----------------------------------------
      007B19                       1899 _register_mods:
      007B19 E5 82            [12] 1900 	mov	a,dpl
      007B1B 90 08 69         [24] 1901 	mov	dptr,#_register_mods_mods_10000_755
      007B1E F0               [24] 1902 	movx	@dptr,a
                                   1903 ;	quantum/action.c:1108: if (mods) {
      007B1F E0               [24] 1904 	movx	a,@dptr
      007B20 FF               [12] 1905 	mov	r7,a
      007B21 E0               [24] 1906 	movx	a,@dptr
      007B22 60 08            [24] 1907 	jz	00103$
                                   1908 ;	quantum/action.c:1109: add_owned_mods(mods);
      007B24 8F 82            [24] 1909 	mov	dpl, r7
      007B26 12 81 7C         [24] 1910 	lcall	_add_owned_mods
                                   1911 ;	quantum/action.c:1110: send_keyboard_report();
                                   1912 ;	quantum/action.c:1112: }
      007B29 02 84 AD         [24] 1913 	ljmp	_send_keyboard_report
      007B2C                       1914 00103$:
      007B2C 22               [24] 1915 	ret
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'unregister_mods'
                                   1918 ;------------------------------------------------------------
                                   1919 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1920 ;------------------------------------------------------------
                                   1921 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1922 ;	-----------------------------------------
                                   1923 ;	 function unregister_mods
                                   1924 ;	-----------------------------------------
      007B2D                       1925 _unregister_mods:
      007B2D E5 82            [12] 1926 	mov	a,dpl
      007B2F 90 08 6A         [24] 1927 	mov	dptr,#_unregister_mods_mods_10000_759
      007B32 F0               [24] 1928 	movx	@dptr,a
                                   1929 ;	quantum/action.c:1119: if (mods) {
      007B33 E0               [24] 1930 	movx	a,@dptr
      007B34 FF               [12] 1931 	mov	r7,a
      007B35 E0               [24] 1932 	movx	a,@dptr
      007B36 60 08            [24] 1933 	jz	00103$
                                   1934 ;	quantum/action.c:1120: del_owned_mods(mods);
      007B38 8F 82            [24] 1935 	mov	dpl, r7
      007B3A 12 81 8B         [24] 1936 	lcall	_del_owned_mods
                                   1937 ;	quantum/action.c:1121: send_keyboard_report();
                                   1938 ;	quantum/action.c:1123: }
      007B3D 02 84 AD         [24] 1939 	ljmp	_send_keyboard_report
      007B40                       1940 00103$:
      007B40 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'register_weak_mods'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function register_weak_mods
                                   1950 ;	-----------------------------------------
      007B41                       1951 _register_weak_mods:
      007B41 E5 82            [12] 1952 	mov	a,dpl
      007B43 90 08 6B         [24] 1953 	mov	dptr,#_register_weak_mods_mods_10000_763
      007B46 F0               [24] 1954 	movx	@dptr,a
                                   1955 ;	quantum/action.c:1130: if (mods) {
      007B47 E0               [24] 1956 	movx	a,@dptr
      007B48 FF               [12] 1957 	mov	r7,a
      007B49 E0               [24] 1958 	movx	a,@dptr
      007B4A 60 08            [24] 1959 	jz	00103$
                                   1960 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007B4C 8F 82            [24] 1961 	mov	dpl, r7
      007B4E 12 81 98         [24] 1962 	lcall	_add_owned_weak_mods
                                   1963 ;	quantum/action.c:1132: send_keyboard_report();
                                   1964 ;	quantum/action.c:1134: }
      007B51 02 84 AD         [24] 1965 	ljmp	_send_keyboard_report
      007B54                       1966 00103$:
      007B54 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1970 ;------------------------------------------------------------
                                   1971 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function unregister_weak_mods
                                   1976 ;	-----------------------------------------
      007B55                       1977 _unregister_weak_mods:
      007B55 E5 82            [12] 1978 	mov	a,dpl
      007B57 90 08 6C         [24] 1979 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007B5A F0               [24] 1980 	movx	@dptr,a
                                   1981 ;	quantum/action.c:1141: if (mods) {
      007B5B E0               [24] 1982 	movx	a,@dptr
      007B5C FF               [12] 1983 	mov	r7,a
      007B5D E0               [24] 1984 	movx	a,@dptr
      007B5E 60 08            [24] 1985 	jz	00103$
                                   1986 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007B60 8F 82            [24] 1987 	mov	dpl, r7
      007B62 12 81 A7         [24] 1988 	lcall	_del_owned_weak_mods
                                   1989 ;	quantum/action.c:1143: send_keyboard_report();
                                   1990 ;	quantum/action.c:1145: }
      007B65 02 84 AD         [24] 1991 	ljmp	_send_keyboard_report
      007B68                       1992 00103$:
      007B68 22               [24] 1993 	ret
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'clear_keyboard'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function clear_keyboard
                                   2000 ;	-----------------------------------------
      007B69                       2001 _clear_keyboard:
                                   2002 ;	quantum/action.c:1152: clear_mods();
      007B69 12 85 28         [24] 2003 	lcall	_clear_mods
                                   2004 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   2005 ;	quantum/action.c:1154: }
      007B6C 61 6E            [12] 2006 	ajmp	_clear_keyboard_but_mods
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function clear_keyboard_but_mods
                                   2013 ;	-----------------------------------------
      007B6E                       2014 _clear_keyboard_but_mods:
                                   2015 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B6E 90 0D F1         [24] 2016 	mov	dptr,#_actual_keyboard_report
      007B71 12 73 BE         [24] 2017 	lcall	_clear_keys_from_report
                                   2018 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   2019 ;	quantum/action.c:1163: }
      007B74 61 76            [12] 2020 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2021 ;------------------------------------------------------------
                                   2022 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2023 ;------------------------------------------------------------
                                   2024 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   2025 ;	-----------------------------------------
                                   2026 ;	 function clear_keyboard_but_mods_and_keys
                                   2027 ;	-----------------------------------------
      007B76                       2028 _clear_keyboard_but_mods_and_keys:
                                   2029 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007B76 12 49 05         [24] 2030 	lcall	_ak820_tapping_cancel
                                   2031 ;	quantum/action.c:1179: ak820_autoshift_cancel();
      007B79 12 33 4A         [24] 2032 	lcall	_ak820_autoshift_cancel
                                   2033 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007B7C 12 2E F0         [24] 2034 	lcall	_ak820_oneshot_cancel
                                   2035 ;	quantum/action.c:1185: ak820_combo_cancel();
      007B7F 12 37 B7         [24] 2036 	lcall	_ak820_combo_cancel
                                   2037 ;	quantum/action.c:1188: repeat_key_cancel();
      007B82 12 A5 8A         [24] 2038 	lcall	_repeat_key_cancel
                                   2039 ;	quantum/action.c:1190: clear_owned_mods();
      007B85 12 81 B6         [24] 2040 	lcall	_clear_owned_mods
                                   2041 ;	quantum/action.c:1191: clear_owned_keys();
      007B88 12 81 EE         [24] 2042 	lcall	_clear_owned_keys
                                   2043 ;	quantum/action.c:1192: clear_owned_usages();
      007B8B 12 83 22         [24] 2044 	lcall	_clear_owned_usages
                                   2045 ;	quantum/action.c:1193: layer_hold_clear();
      007B8E B1 74            [12] 2046 	acall	_layer_hold_clear
                                   2047 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007B90 12 A0 64         [24] 2048 	lcall	_clear_macro_tri_layer
                                   2049 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B93 90 0D F1         [24] 2050 	mov	dptr,#_actual_keyboard_report
      007B96 12 73 BE         [24] 2051 	lcall	_clear_keys_from_report
                                   2052 ;	quantum/action.c:1200: host_system_send(0);
      007B99 90 00 00         [24] 2053 	mov	dptr,#0x0000
      007B9C 12 71 98         [24] 2054 	lcall	_host_system_send
                                   2055 ;	quantum/action.c:1201: host_consumer_send(0);
      007B9F 90 00 00         [24] 2056 	mov	dptr,#0x0000
      007BA2 12 71 C7         [24] 2057 	lcall	_host_consumer_send
                                   2058 ;	quantum/action.c:1203: clear_weak_mods();
      007BA5 12 85 5D         [24] 2059 	lcall	_clear_weak_mods
                                   2060 ;	quantum/action.c:1204: send_keyboard_report();
      007BA8 12 84 AD         [24] 2061 	lcall	_send_keyboard_report
                                   2062 ;	quantum/action.c:1206: mousekey_clear();
      007BAB 12 53 FA         [24] 2063 	lcall	_mousekey_clear
                                   2064 ;	quantum/action.c:1207: mousekey_send();
                                   2065 ;	quantum/action.c:1212: }
      007BAE 02 52 C2         [24] 2066 	ljmp	_mousekey_send
                                   2067 ;------------------------------------------------------------
                                   2068 ;Allocation info for local variables in function 'is_tap_record'
                                   2069 ;------------------------------------------------------------
                                   2070 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   2071 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   2072 ;------------------------------------------------------------
                                   2073 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   2074 ;	-----------------------------------------
                                   2075 	.area CSEG    (CODE)
                                   2076 	.area CONST   (CODE)
                                   2077 	.area XINIT   (CODE)
      00C535                       2078 __xinit__disable_action_cache:
      00C535 00                    2079 	.db #0x00	;  0
                                   2080 	.area CABS    (ABS,CODE)
                                   2081 
                                   2082 ; Experimental exact instruction outlining.
                                   2083 	.globl _ak820_outline_0001
                                   2084 	.globl _ak820_outline_0005
                                   2085 	.globl _ak820_outline_0007
                                   2086 	.globl _ak820_outline_0008
                                   2087 	.globl _ak820_outline_0011
                                   2088 	.globl _ak820_outline_0012
                                   2089 	.globl _ak820_outline_0013
                                   2090 	.globl _ak820_outline_0014
                                   2091 	.globl _ak820_outline_0017
                                   2092 	.globl _ak820_outline_0021
                                   2093 	.globl _ak820_outline_0022
                                   2094 	.globl _ak820_outline_0034
                                   2095 	.globl _ak820_outline_0037
                                   2096 	.globl _ak820_outline_0042
                                   2097 	.globl _ak820_outline_0057
                                   2098 	.globl _ak820_outline_0061
                                   2099 	.globl _ak820_outline_0064
                                   2100 	.globl _ak820_outline_0070
                                   2101 	.globl _ak820_outline_0072
                                   2102 	.globl _ak820_outline_0078
                                   2103 	.globl _ak820_outline_0079
                                   2104 	.globl _ak820_outline_0089
                                   2105 	.globl _ak820_outline_0093
                                   2106 	.globl _ak820_outline_0107
                                   2107 	.globl _ak820_outline_0108
                                   2108 	.globl _ak820_outline_0110
                                   2109 	.globl _ak820_outline_0112
                                   2110 	.globl _ak820_outline_0113
                                   2111 	.globl _ak820_outline_0118
                                   2112 	.globl _ak820_outline_0123
                                   2113 	.globl _ak820_outline_0124
                                   2114 	.globl _ak820_outline_0130
                                   2115 	.globl _ak820_outline_0133
                                   2116 	.globl _ak820_outline_0134
                                   2117 	.globl _ak820_outline_0141
                                   2118 	.globl _ak820_outline_0142
                                   2119 	.globl _ak820_outline_0144
                                   2120 	.globl _ak820_outline_0148
                                   2121 	.globl _ak820_outline_0151
                                   2122 	.globl _ak820_outline_0152
                                   2123 	.globl _ak820_outline_0160
                                   2124 	.globl _ak820_outline_0182
                                   2125 	.globl _ak820_outline_0187
                                   2126 	.globl _ak820_outline_0189
                                   2127 
                                   2128 	.area CSEG (CODE)
                                   2129 ; function ak820_outline_0013
      007BB1                       2130 _ak820_outline_0013:
      007BB1 2D               [12] 2131 	add	a,r5
      007BB2 F9               [12] 2132 	mov	r1,a
      007BB3 E4               [12] 2133 	clr	a
      007BB4 3E               [12] 2134 	addc	a,r6
      007BB5 FA               [12] 2135 	mov	r2,a
      007BB6 8F 03            [24] 2136 	mov	ar3,r7
      007BB8 89 82            [24] 2137 	mov	dpl,r1
      007BBA 8A 83            [24] 2138 	mov	dph,r2
      007BBC 8B F0            [24] 2139 	mov	b,r3
      007BBE 22               [24] 2140 	ret
                                   2141 
                                   2142 	.area CSEG (CODE)
                                   2143 ; function ak820_outline_0014
      007BBF                       2144 _ak820_outline_0014:
      007BBF 2D               [12] 2145 	add	a,r5
      007BC0 FA               [12] 2146 	mov	r2,a
      007BC1 E4               [12] 2147 	clr	a
      007BC2 3E               [12] 2148 	addc	a,r6
      007BC3 FB               [12] 2149 	mov	r3,a
      007BC4 8F 04            [24] 2150 	mov	ar4,r7
      007BC6 8A 82            [24] 2151 	mov	dpl,r2
      007BC8 8B 83            [24] 2152 	mov	dph,r3
      007BCA 8C F0            [24] 2153 	mov	b,r4
      007BCC 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0021
      007BCD                       2158 _ak820_outline_0021:
      007BCD 8E 82            [24] 2159 	mov	dpl,r6
      007BCF 8F 83            [24] 2160 	mov	dph,r7
      007BD1 A3               [24] 2161 	inc	dptr
      007BD2 E0               [24] 2162 	movx	a,@dptr
      007BD3 FC               [12] 2163 	mov	r4,a
      007BD4 7D 00            [12] 2164 	mov	r5,#0x00
      007BD6 8E 82            [24] 2165 	mov	dpl,r6
      007BD8 8F 83            [24] 2166 	mov	dph,r7
      007BDA E0               [24] 2167 	movx	a,@dptr
      007BDB 22               [24] 2168 	ret
                                   2169 
                                   2170 	.area CSEG (CODE)
                                   2171 ; function ak820_outline_0042
      007BDC                       2172 _ak820_outline_0042:
      007BDC 90 08 5E         [24] 2173 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007BDF E0               [24] 2174 	movx	a,@dptr
      007BE0 54 1F            [12] 2175 	anl	a,#0x1f
      007BE2 F5 82            [12] 2176 	mov	dpl,a
      007BE4 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0061
      007BE5                       2181 _ak820_outline_0061:
      007BE5 F5 F0            [12] 2182 	mov	b,a
      007BE7 05 F0            [12] 2183 	inc	b
      007BE9 74 01            [12] 2184 	mov	a,#0x01
      007BEB 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0070
      007BEC                       2189 _ak820_outline_0070:
      007BEC 90 0D CE         [24] 2190 	mov	dptr,#___memcpy_PARM_3
      007BEF 74 06            [12] 2191 	mov	a,#0x06
      007BF1 F0               [24] 2192 	movx	@dptr,a
      007BF2 E4               [12] 2193 	clr	a
      007BF3 A3               [24] 2194 	inc	dptr
      007BF4 F0               [24] 2195 	movx	@dptr,a
      007BF5 22               [24] 2196 	ret
                                   2197 
                                   2198 	.area CSEG (CODE)
                                   2199 ; function ak820_outline_0078
      007BF6                       2200 _ak820_outline_0078:
      007BF6 90 08 5D         [24] 2201 	mov	dptr,#_process_action_PARM_2
      007BF9 E0               [24] 2202 	movx	a,@dptr
      007BFA F5 82            [12] 2203 	mov	dpl,a
      007BFC 22               [24] 2204 	ret
                                   2205 
                                   2206 	.area CSEG (CODE)
                                   2207 ; function ak820_outline_0089
      007BFD                       2208 _ak820_outline_0089:
      007BFD 90 08 5E         [24] 2209 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C00 E0               [24] 2210 	movx	a,@dptr
      007C01 03               [12] 2211 	rr	a
      007C02 03               [12] 2212 	rr	a
      007C03 54 03            [12] 2213 	anl	a,#0x03
      007C05 22               [24] 2214 	ret
                                   2215 
                                   2216 	.area CSEG (CODE)
                                   2217 ; function ak820_outline_0113
      007C06                       2218 _ak820_outline_0113:
      007C06 90 08 5E         [24] 2219 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C09 E0               [24] 2220 	movx	a,@dptr
      007C0A 54 0F            [12] 2221 	anl	a,#0x0f
      007C0C 22               [24] 2222 	ret
                                   2223 
                                   2224 	.area CSEG (CODE)
                                   2225 ; function ak820_outline_0130
      007C0D                       2226 _ak820_outline_0130:
      007C0D 90 08 5D         [24] 2227 	mov	dptr,#_process_action_PARM_2
      007C10 E0               [24] 2228 	movx	a,@dptr
      007C11 FE               [12] 2229 	mov	r6,a
      007C12 A3               [24] 2230 	inc	dptr
      007C13 E0               [24] 2231 	movx	a,@dptr
      007C14 54 03            [12] 2232 	anl	a,#0x03
      007C16 FF               [12] 2233 	mov	r7,a
      007C17 22               [24] 2234 	ret
                                   2235 
                                   2236 	.area CSEG (CODE)
                                   2237 ; function ak820_outline_0141
      007C18                       2238 _ak820_outline_0141:
      007C18 90 08 63         [24] 2239 	mov	dptr,#_register_code_code_10000_719
      007C1B E0               [24] 2240 	movx	a,@dptr
      007C1C FF               [12] 2241 	mov	r7,a
      007C1D 22               [24] 2242 	ret
                                   2243 
                                   2244 	.area CSEG (CODE)
                                   2245 ; function ak820_outline_0142
      007C1E                       2246 _ak820_outline_0142:
      007C1E 90 08 64         [24] 2247 	mov	dptr,#_unregister_code_code_10000_733
      007C21 E0               [24] 2248 	movx	a,@dptr
      007C22 FF               [12] 2249 	mov	r7,a
      007C23 22               [24] 2250 	ret
                                   2251 
                                   2252 	.area CSEG (CODE)
                                   2253 ; function ak820_outline_0148
      007C24                       2254 _ak820_outline_0148:
      007C24 74 07            [12] 2255 	mov	a,#0x07
      007C26 2D               [12] 2256 	add	a,r5
      007C27 F8               [12] 2257 	mov	r0,a
      007C28 E4               [12] 2258 	clr	a
      007C29 3E               [12] 2259 	addc	a,r6
      007C2A F9               [12] 2260 	mov	r1,a
      007C2B 8F 02            [24] 2261 	mov	ar2,r7
      007C2D 22               [24] 2262 	ret
                                   2263 
                                   2264 	.area CSEG (CODE)
                                   2265 ; function ak820_outline_0151
      007C2E                       2266 _ak820_outline_0151:
      007C2E 90 08 5D         [24] 2267 	mov	dptr,#_process_action_PARM_2
      007C31 E0               [24] 2268 	movx	a,@dptr
      007C32 22               [24] 2269 	ret
                                   2270 
                                   2271 	.area CSEG (CODE)
                                   2272 ; function ak820_outline_0187
      007C33                       2273 _ak820_outline_0187:
      007C33 F0               [24] 2274 	movx	@dptr,a
      007C34 EB               [12] 2275 	mov	a,r3
      007C35 A3               [24] 2276 	inc	dptr
      007C36 F0               [24] 2277 	movx	@dptr,a
      007C37 22               [24] 2278 	ret
                                   2279 
                                   2280 	.area CSEG (CODE)
                                   2281 ; function ak820_outline_0189
      007C38                       2282 _ak820_outline_0189:
      007C38 E4               [12] 2283 	clr	a
      007C39 F0               [24] 2284 	movx	@dptr,a
      007C3A 8F 82            [24] 2285 	mov	dpl,r7
      007C3C 22               [24] 2286 	ret
