;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_autoshift
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _del_owned_mods
	.globl _add_owned_mods
	.globl _get_weak_mods
	.globl _get_mods
	.globl _send_keyboard_report
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_autoshift_before
	.globl _ak820_autoshift_process
	.globl _ak820_autoshift_cancel
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_autoshift_process_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_as_saved:
	.ds 9
_as_state:
	.ds 1
_as_emit_shifted_10000_590:
	.ds 1
_ak820_autoshift_before_event_10000_593:
	.ds 2
_ak820_autoshift_before_state_50001_607:
	.ds 1
_ak820_autoshift_process_record_10000_611:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_as_enabled:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function as_emit
;	-----------------------------------------
_as_emit:
	mov	a,dpl
	mov	dptr,#_as_emit_shifted_10000_590
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:13: as_state = shifted ? 3 : 2;
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00105$
	mov	r6,#0x03
	sjmp	00106$
00105$:
	mov	r6,#0x02
00106$:
	mov	dptr,#_as_state
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:14: if (shifted) add_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
	mov	a,r7
	jz	00102$
	mov	dpl, #0x02
	lcall	_add_owned_mods
00102$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:15: process_record(&as_saved);
	mov	dptr,#_as_saved
	mov	b, #0x00
;	keyboards/ajazz/ak820/ak820_autoshift.c:16: }
	ljmp	_process_record
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_autoshift_before'
;------------------------------------------------------------
;event         Allocated with name '_ak820_autoshift_before_event_10000_593'
;state         Allocated with name '_ak820_autoshift_before_state_50001_607'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_autoshift.c:17: bool ak820_autoshift_before(const keyevent_t AK820_STATE_MEM *event) {
;	-----------------------------------------
;	 function ak820_autoshift_before
;	-----------------------------------------
_ak820_autoshift_before:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_autoshift_before_event_10000_593
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:18: if (!as_state) return true;
	mov	dptr,#_as_state
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:19: if (as_state == 1 && (uint16_t)(event->time - as_saved.event.time) >= 175) {
	cjne	r7,#0x01,00106$
	mov	dptr,#_ak820_autoshift_before_event_10000_593
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_as_saved + 0x0002)
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r6,a
	mov	a,r7
	subb	a,r5
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,#0xaf
	mov	a,r7
	subb	a,#0x00
	jc	00106$
;	keyboards/ajazz/ak820/ak820_autoshift.c:20: as_emit(true);
	mov	dpl, #0x01
	lcall	_as_emit
;	keyboards/ajazz/ak820/ak820_autoshift.c:21: if (!as_state) return false;
	mov	dptr,#_as_state
	movx	a,@dptr
	jnz	00106$
	mov	dpl,a
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:23: if (IS_NOEVENT(*event)) return true;
	mov	dptr,#_ak820_autoshift_before_event_10000_593
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x04
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	jnz	00109$
	mov	dpl, #0x01
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:24: if (event->key.row == as_saved.event.key.row && event->key.col == as_saved.event.key.col) {
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#(_as_saved + 0x0001)
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	cjne	a,ar4,00119$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_as_saved
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	cjne	a,ar4,00119$
;	keyboards/ajazz/ak820/ak820_autoshift.c:25: if (!event->pressed) {
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jnz	00117$
;	keyboards/ajazz/ak820/ak820_autoshift.c:26: if (as_state == 1) {
	mov	dptr,#_as_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00113$
;	keyboards/ajazz/ak820/ak820_autoshift.c:27: as_emit(false);
	mov	dpl, #0x00
	lcall	_as_emit
;	keyboards/ajazz/ak820/ak820_autoshift.c:28: if (!as_state) return false;
	mov	dptr,#_as_state
	movx	a,@dptr
	jnz	00113$
	mov	dpl,a
	ret
00113$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:30: uint8_t state = as_state;
	mov	dptr,#_as_state
	movx	a,@dptr
	mov	dptr,#_ak820_autoshift_before_state_50001_607
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:31: as_state = 0;
	mov	dptr,#_as_state
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:32: as_saved.event.pressed = false;
	mov	dptr,#(_as_saved + 0x0005)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:33: process_record(&as_saved);
	mov	dptr,#_as_saved
	mov	b,a
	lcall	_process_record
;	keyboards/ajazz/ak820/ak820_autoshift.c:34: if (state == 3) {
	mov	dptr,#_ak820_autoshift_before_state_50001_607
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00117$
;	keyboards/ajazz/ak820/ak820_autoshift.c:35: del_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
	mov	dpl, #0x02
	lcall	_del_owned_mods
;	keyboards/ajazz/ak820/ak820_autoshift.c:36: send_keyboard_report();
	lcall	_send_keyboard_report
00117$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:39: return false;
	mov	dpl, #0x00
	ret
00119$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:41: if (as_state == 1 && event->pressed) as_emit(false);
	mov	dptr,#_as_state
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00122$
	mov	dptr,#_ak820_autoshift_before_event_10000_593
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00122$
	mov	dpl, #0x00
	lcall	_as_emit
00122$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:42: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_autoshift.c:43: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_autoshift_process'
;------------------------------------------------------------
;record        Allocated with name '_ak820_autoshift_process_record_10000_611'
;code          Allocated with name '_ak820_autoshift_process_code_10000_612'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_autoshift.c:44: bool ak820_autoshift_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_autoshift_process
;	-----------------------------------------
_ak820_autoshift_process:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_autoshift_process_record_10000_611
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:45: uint16_t code = record->keycode;
	mov	dptr,#_ak820_autoshift_process_record_10000_611
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:46: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x10,00209$
00209$:
	jnc	00101$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x08,00211$
00211$:
	jc	00102$
00101$:
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:47: if (code >= QK_AUTO_SHIFT_ON && code <= QK_AUTO_SHIFT_TOGGLE) {
	clr	c
	mov	a,r4
	subb	a,#0x13
	mov	a,r5
	subb	a,#0x7c
	jc	00107$
	mov	a,#0x15
	subb	a,r4
	mov	a,#0x7c
	subb	a,r5
	jc	00107$
;	free result
;	keyboards/ajazz/ak820/ak820_autoshift.c:48: if (record->event.pressed)
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00105$
;	keyboards/ajazz/ak820/ak820_autoshift.c:49: as_enabled = code == QK_AUTO_SHIFT_TOGGLE ? !as_enabled : code == QK_AUTO_SHIFT_ON;
	cjne	r4,#0x15,00123$
	cjne	r5,#0x7c,00123$
	mov	dptr,#_as_enabled
	movx	a,@dptr
	cjne	a,#0x01,00218$
00218$:
	mov  _ak820_autoshift_process_sloc0_1_0,c
	clr	a
	rlc	a
	mov	r7,a
	sjmp	00124$
00123$:
	clr	a
	cjne	r4,#0x13,00219$
	cjne	r5,#0x7c,00219$
	inc	a
00219$:
	mov	r7,a
00124$:
	mov	dptr,#_as_enabled
;	assignBit
	mov	a,r7
	add	a,#0xff
	clr	a
	rlc	a
	movx	@dptr,a
00105$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:50: return false;
	mov	dpl, #0x00
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:52: if (!as_enabled || as_state || !record->event.pressed || get_mods() || get_weak_mods()) return true;
	mov	dptr,#_as_enabled
	movx	a,@dptr
	jz	00109$
	mov	dptr,#_as_state
	movx	a,@dptr
	jnz	00109$
	mov	dptr,#_ak820_autoshift_process_record_10000_611
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00109$
	lcall	_get_mods
	mov	a, dpl
	jnz	00109$
	lcall	_get_weak_mods
	mov	a, dpl
	jz	00110$
00109$:
	mov	dpl, #0x01
	ret
00110$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:53: if (!((code >= KC_A && code <= KC_0) ||
	clr	c
	mov	a,r4
	subb	a,#0x04
	mov	a,r5
	subb	a,#0x00
	jc	00119$
	mov	a,#0x27
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00116$
;	free result
00119$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:54: (code >= KC_MINUS && code <= KC_SLASH) || code == KC_NONUS_BACKSLASH)) return true;
	clr	c
	mov	a,r4
	subb	a,#0x2d
	mov	a,r5
	subb	a,#0x00
	jc	00120$
	mov	a,#0x38
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00116$
;	free result
00120$:
	cjne	r4,#0x64,00230$
	cjne	r5,#0x00,00230$
	sjmp	00116$
00230$:
	mov	dpl, #0x01
	ret
00116$:
;	keyboards/ajazz/ak820/ak820_autoshift.c:55: as_saved = *record;
	mov	dptr,#_ak820_autoshift_process_record_10000_611
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x09
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_as_saved
	mov	b,a
	lcall	___memcpy
;	keyboards/ajazz/ak820/ak820_autoshift.c:56: as_state = 1;
	mov	dptr,#_as_state
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_autoshift.c:57: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_autoshift.c:58: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_autoshift_cancel'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_autoshift.c:59: void ak820_autoshift_cancel(void) { as_state = 0; }
;	-----------------------------------------
;	 function ak820_autoshift_cancel
;	-----------------------------------------
_ak820_autoshift_cancel:
	mov	dptr,#_as_state
	clr	a
	movx	@dptr,a
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__as_enabled:
	.db #0x01	;  1
	.area CABS    (ABS,CODE)
