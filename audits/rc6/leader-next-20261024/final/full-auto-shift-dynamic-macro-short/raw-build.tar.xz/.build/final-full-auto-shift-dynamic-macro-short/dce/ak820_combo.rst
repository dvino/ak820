                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000001                        539 _input_sloc0_1_0:
      000001                        540 	.ds 1
      000002                        541 _output_sloc0_1_0:
      000002                        542 	.ds 1
      000003                        543 _ak820_combo_valid_sloc0_1_0:
      000003                        544 	.ds 1
      000004                        545 _ak820_combo_process_sloc0_1_0:
      000004                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000432                        555 _input_code_10000_592:
      000432                        556 	.ds 2
      000434                        557 _output_code_10000_594:
      000434                        558 	.ds 2
      000436                        559 _combos:
      000436                        560 	.ds 32
      000456                        561 _saved:
      000456                        562 	.ds 9
      00045F                        563 _active:
      00045F                        564 	.ds 1
      000460                        565 _ak820_combo_valid_entry_10000_596:
      000460                        566 	.ds 2
      000462                        567 _ak820_combo_reload_entry_30000_608:
      000462                        568 	.ds 10
      00046C                        569 _ak820_combo_tick_now_10000_613:
      00046C                        570 	.ds 2
      00046E                        571 _ak820_combo_process_record_10000_616:
      00046E                        572 	.ds 2
      000470                        573 _ak820_combo_process_eligible_10001_631:
      000470                        574 	.ds 1
      000471                        575 _ak820_combo_process_i_40001_634:
      000471                        576 	.ds 1
      000472                        577 _ak820_combo_process_a_50001_635:
      000472                        578 	.ds 1
      000473                        579 _ak820_combo_process_b_50001_635:
      000473                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000E12                        589 _first:
      000E12                        590 	.ds 1
      000E13                        591 _second:
      000E13                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      0036B3                        636 _input:
      0036B3 12 3A C2         [24]  637 	lcall	_ak820_outline_0108
      0036B6 90 04 32         [24]  638 	mov	dptr,#_input_code_10000_592
      0036B9 12 3A C7         [24]  639 	lcall	_ak820_outline_0109
      0036BC 90 04 32         [24]  640 	mov	dptr,#_input_code_10000_592
      0036BF 12 3A 81         [24]  641 	lcall	_ak820_outline_0052
      0036C2 C3               [12]  642 	clr	c
      0036C3 EE               [12]  643 	mov	a,r6
      0036C4 94 04            [12]  644 	subb	a,#0x04
      0036C6 EF               [12]  645 	mov	a,r7
      0036C7 94 00            [12]  646 	subb	a,#0x00
      0036C9 40 07            [24]  647 	jc	00103$
      0036CB 74 A4            [12]  648 	mov	a,#0xa4
      0036CD 9E               [12]  649 	subb	a,r6
      0036CE E4               [12]  650 	clr	a
      0036CF 9F               [12]  651 	subb	a,r7
      0036D0 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      0036D2                        654 00103$:
                                    655 ;	assignBit
      0036D2 C2 01            [12]  656 	clr	_input_sloc0_1_0
      0036D4 80 02            [24]  657 	sjmp	00105$
      0036D6                        658 00104$:
                                    659 ;	assignBit
      0036D6 D2 01            [12]  660 	setb	_input_sloc0_1_0
      0036D8                        661 00105$:
      0036D8 A2 01            [12]  662 	mov	c,_input_sloc0_1_0
      0036DA 12 3A F6         [24]  663 	lcall	_ak820_outline_0156
      0036DD 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_594'
                                    669 ;basic         Allocated with name '_output_basic_10000_595'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:10: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      0036DE                        675 _output:
      0036DE 12 3A C2         [24]  676 	lcall	_ak820_outline_0108
      0036E1 90 04 34         [24]  677 	mov	dptr,#_output_code_10000_594
      0036E4 12 3A C7         [24]  678 	lcall	_ak820_outline_0109
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:11: uint8_t basic = code;
      0036E7 90 04 34         [24]  680 	mov	dptr,#_output_code_10000_594
      0036EA 12 3A 81         [24]  681 	lcall	_ak820_outline_0052
      0036ED 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:12: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      0036EF 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      0036F1 2F               [12]  685 	add	a,r7
      0036F2 40 1B            [24]  686 	jc	00103$
      0036F4 8D 06            [24]  687 	mov	ar6,r5
      0036F6 7F 00            [12]  688 	mov	r7,#0x00
      0036F8 12 3A CC         [24]  689 	lcall	_ak820_outline_0118
      0036FB C0 05            [24]  690 	push	ar5
      0036FD D1 B3            [12]  691 	acall	_input
      0036FF E5 82            [12]  692 	mov	a, dpl
      003701 D0 05            [24]  693 	pop	ar5
      003703 70 0E            [24]  694 	jnz	00104$
      003705 BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      003708                        696 00135$:
      003708 40 05            [24]  697 	jc	00103$
      00370A ED               [12]  698 	mov	a,r5
      00370B 24 18            [12]  699 	add	a,#0xff - 0xe7
      00370D 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      00370F                        702 00103$:
                                    703 ;	assignBit
      00370F C2 02            [12]  704 	clr	_output_sloc0_1_0
      003711 80 02            [24]  705 	sjmp	00105$
      003713                        706 00104$:
                                    707 ;	assignBit
      003713 D2 02            [12]  708 	setb	_output_sloc0_1_0
      003715                        709 00105$:
      003715 A2 02            [12]  710 	mov	c,_output_sloc0_1_0
      003717 12 3A F6         [24]  711 	lcall	_ak820_outline_0156
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:13: }
      00371A 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_596'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:19: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      00371B                        723 _ak820_combo_valid:
      00371B 12 3A C2         [24]  724 	lcall	_ak820_outline_0108
      00371E 90 04 60         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_596
      003721 12 3A C7         [24]  726 	lcall	_ak820_outline_0109
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:20: if (entry->input[2] || entry->input[3]) return false;
      003724 90 04 60         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_596
      003727 12 3A 34         [24]  729 	lcall	_ak820_outline_0005
      00372A A3               [24]  730 	inc	dptr
      00372B A3               [24]  731 	inc	dptr
      00372C A3               [24]  732 	inc	dptr
      00372D A3               [24]  733 	inc	dptr
      00372E E0               [24]  734 	movx	a,@dptr
      00372F FC               [12]  735 	mov	r4,a
      003730 A3               [24]  736 	inc	dptr
      003731 E0               [24]  737 	movx	a,@dptr
      003732 4C               [12]  738 	orl	a,r4
      003733 70 0C            [24]  739 	jnz	00101$
      003735 74 06            [12]  740 	mov	a,#0x06
      003737 12 3A 71         [24]  741 	lcall	_ak820_outline_0022
      00373A E0               [24]  742 	movx	a,@dptr
      00373B FC               [12]  743 	mov	r4,a
      00373C A3               [24]  744 	inc	dptr
      00373D E0               [24]  745 	movx	a,@dptr
      00373E 4C               [12]  746 	orl	a,r4
      00373F 60 04            [24]  747 	jz	00102$
      003741                        748 00101$:
      003741 75 82 00         [24]  749 	mov	dpl, #0x00
      003744 22               [24]  750 	ret
      003745                        751 00102$:
                                    752 ;	keyboards/ajazz/ak820/ak820_combo.c:21: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      003745 8E 04            [24]  753 	mov	ar4,r6
      003747 8F 05            [24]  754 	mov	ar5,r7
      003749 12 3A 79         [24]  755 	lcall	_ak820_outline_0036
      00374C FA               [12]  756 	mov	r2,a
      00374D A3               [24]  757 	inc	dptr
      00374E E0               [24]  758 	movx	a,@dptr
      00374F FB               [12]  759 	mov	r3,a
      003750 12 3A D7         [24]  760 	lcall	_ak820_outline_0124
      003753 12 3A 98         [24]  761 	lcall	_ak820_outline_0059
      003756 EA               [12]  762 	mov	a,r2
      003757 4C               [12]  763 	orl	a,r4
      003758 F8               [12]  764 	mov	r0,a
      003759 EB               [12]  765 	mov	a,r3
      00375A 4D               [12]  766 	orl	a,r5
      00375B 48               [12]  767 	orl	a,r0
      00375C 70 13            [24]  768 	jnz	00105$
      00375E 74 08            [12]  769 	mov	a,#0x08
      003760 12 3A 71         [24]  770 	lcall	_ak820_outline_0022
      003763 E0               [24]  771 	movx	a,@dptr
      003764 F8               [12]  772 	mov	r0,a
      003765 A3               [24]  773 	inc	dptr
      003766 E0               [24]  774 	movx	a,@dptr
      003767 48               [12]  775 	orl	a,r0
      003768 B4 01 00         [24]  776 	cjne	a,#0x01,00152$
      00376B                        777 00152$:
      00376B 92 03            [24]  778 	mov  _ak820_combo_valid_sloc0_1_0,c
      00376D 12 3A F6         [24]  779 	lcall	_ak820_outline_0156
      003770 22               [24]  780 	ret
      003771                        781 00105$:
                                    782 ;	keyboards/ajazz/ak820/ak820_combo.c:22: if (entry->input[0] == entry->input[1]) return false;
      003771 EC               [12]  783 	mov	a,r4
      003772 B5 02 08         [24]  784 	cjne	a,ar2,00107$
      003775 ED               [12]  785 	mov	a,r5
      003776 B5 03 04         [24]  786 	cjne	a,ar3,00107$
      003779 75 82 00         [24]  787 	mov	dpl, #0x00
      00377C 22               [24]  788 	ret
      00377D                        789 00107$:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:23: if (!input(entry->input[0])) return false;
      00377D 12 3A D7         [24]  791 	lcall	_ak820_outline_0124
      003780 C0 07            [24]  792 	push	ar7
      003782 C0 06            [24]  793 	push	ar6
      003784 C0 03            [24]  794 	push	ar3
      003786 C0 02            [24]  795 	push	ar2
      003788 D1 B3            [12]  796 	acall	_input
      00378A E5 82            [12]  797 	mov	a, dpl
      00378C D0 02            [24]  798 	pop	ar2
      00378E D0 03            [24]  799 	pop	ar3
      003790 D0 06            [24]  800 	pop	ar6
      003792 D0 07            [24]  801 	pop	ar7
      003794 70 03            [24]  802 	jnz	00109$
      003796 F5 82            [12]  803 	mov	dpl,a
      003798 22               [24]  804 	ret
      003799                        805 00109$:
                                    806 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (!input(entry->input[1])) return false;
      003799 12 3A EC         [24]  807 	lcall	_ak820_outline_0143
      00379C C0 07            [24]  808 	push	ar7
      00379E C0 06            [24]  809 	push	ar6
      0037A0 D1 B3            [12]  810 	acall	_input
      0037A2 E5 82            [12]  811 	mov	a, dpl
      0037A4 D0 06            [24]  812 	pop	ar6
      0037A6 D0 07            [24]  813 	pop	ar7
      0037A8 70 03            [24]  814 	jnz	00111$
      0037AA F5 82            [12]  815 	mov	dpl,a
      0037AC 22               [24]  816 	ret
      0037AD                        817 00111$:
                                    818 ;	keyboards/ajazz/ak820/ak820_combo.c:25: return output(entry->output);
      0037AD 74 08            [12]  819 	mov	a,#0x08
      0037AF 12 3A 71         [24]  820 	lcall	_ak820_outline_0022
      0037B2 12 3A 34         [24]  821 	lcall	_ak820_outline_0005
                                    822 ;	keyboards/ajazz/ak820/ak820_combo.c:26: }
      0037B5 C1 DE            [12]  823 	ajmp	_output
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    826 ;------------------------------------------------------------
                                    827 ;	keyboards/ajazz/ak820/ak820_combo.c:29: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    828 ;	-----------------------------------------
                                    829 ;	 function ak820_combo_cancel
                                    830 ;	-----------------------------------------
      0037B7                        831 _ak820_combo_cancel:
      0037B7 90 0E 13         [24]  832 	mov	dptr,#_second
      0037BA 74 FF            [12]  833 	mov	a,#0xff
      0037BC F0               [24]  834 	movx	@dptr,a
      0037BD 90 0E 12         [24]  835 	mov	dptr,#_first
      0037C0 F0               [24]  836 	movx	@dptr,a
      0037C1 90 04 5F         [24]  837 	mov	dptr,#_active
      0037C4 E4               [12]  838 	clr	a
      0037C5 F0               [24]  839 	movx	@dptr,a
      0037C6 22               [24]  840 	ret
                                    841 ;------------------------------------------------------------
                                    842 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    843 ;------------------------------------------------------------
                                    844 ;i             Allocated with name '_ak820_combo_reload_i_20000_607'
                                    845 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_608'
                                    846 ;------------------------------------------------------------
                                    847 ;	keyboards/ajazz/ak820/ak820_combo.c:30: void ak820_combo_reload(void) {
                                    848 ;	-----------------------------------------
                                    849 ;	 function ak820_combo_reload
                                    850 ;	-----------------------------------------
      0037C7                        851 _ak820_combo_reload:
                                    852 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0037C7 7F 00            [12]  853 	mov	r7,#0x00
      0037C9                        854 00105$:
      0037C9 BF 08 00         [24]  855 	cjne	r7,#0x08,00131$
      0037CC                        856 00131$:
      0037CC 40 01            [24]  857 	jc	00132$
      0037CE 22               [24]  858 	ret
      0037CF                        859 00132$:
                                    860 ;	keyboards/ajazz/ak820/ak820_combo.c:33: combos[i].a = 0;
      0037CF EF               [12]  861 	mov	a,r7
      0037D0 75 F0 04         [24]  862 	mov	b,#0x04
      0037D3 A4               [48]  863 	mul	ab
      0037D4 24 36            [12]  864 	add	a, #_combos
      0037D6 FD               [12]  865 	mov	r5,a
      0037D7 74 04            [12]  866 	mov	a,#(_combos >> 8)
      0037D9 35 F0            [12]  867 	addc	a, b
      0037DB FE               [12]  868 	mov	r6,a
      0037DC 8D 03            [24]  869 	mov	ar3,r5
      0037DE 8E 04            [24]  870 	mov	ar4,r6
      0037E0 12 36 47         [24]  871 	lcall	_ak820_outline_0121
      0037E3 E4               [12]  872 	clr	a
      0037E4 F0               [24]  873 	movx	@dptr,a
                                    874 ;	keyboards/ajazz/ak820/ak820_combo.c:34: if (!dynamic_keymap_get_combo(i, &entry)) {
      0037E5 90 0B 50         [24]  875 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0037E8 74 62            [12]  876 	mov	a,#_ak820_combo_reload_entry_30000_608
      0037EA F0               [24]  877 	movx	@dptr,a
      0037EB 74 04            [12]  878 	mov	a,#(_ak820_combo_reload_entry_30000_608 >> 8)
      0037ED 12 3A B0         [24]  879 	lcall	_ak820_outline_0094
      0037F0 8F 82            [24]  880 	mov	dpl, r7
      0037F2 C0 07            [24]  881 	push	ar7
      0037F4 C0 06            [24]  882 	push	ar6
      0037F6 C0 05            [24]  883 	push	ar5
      0037F8 C0 04            [24]  884 	push	ar4
      0037FA C0 03            [24]  885 	push	ar3
      0037FC 12 8B 80         [24]  886 	lcall	_dynamic_keymap_get_combo
      0037FF 12 3A E6         [24]  887 	lcall	_ak820_outline_0138
      003802 D0 03            [24]  888 	pop	ar3
      003804 D0 04            [24]  889 	pop	ar4
      003806 D0 05            [24]  890 	pop	ar5
      003808 D0 06            [24]  891 	pop	ar6
      00380A D0 07            [24]  892 	pop	ar7
      00380C 45 F0            [12]  893 	orl	a,b
      00380E 70 28            [24]  894 	jnz	00106$
                                    895 ;	keyboards/ajazz/ak820/ak820_combo.c:35: combos[i].a = entry.input[0];
      003810 90 04 62         [24]  896 	mov	dptr,#_ak820_combo_reload_entry_30000_608
      003813 E0               [24]  897 	movx	a,@dptr
      003814 12 36 47         [24]  898 	lcall	_ak820_outline_0121
      003817 F0               [24]  899 	movx	@dptr,a
                                    900 ;	keyboards/ajazz/ak820/ak820_combo.c:36: combos[i].b = entry.input[1];
      003818 74 01            [12]  901 	mov	a,#0x01
      00381A 2D               [12]  902 	add	a, r5
      00381B FB               [12]  903 	mov	r3,a
      00381C E4               [12]  904 	clr	a
      00381D 3E               [12]  905 	addc	a, r6
      00381E FC               [12]  906 	mov	r4,a
      00381F 90 04 64         [24]  907 	mov	dptr,#(_ak820_combo_reload_entry_30000_608 + 0x0002)
      003822 E0               [24]  908 	movx	a,@dptr
      003823 12 36 47         [24]  909 	lcall	_ak820_outline_0121
      003826 F0               [24]  910 	movx	@dptr,a
                                    911 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].output = entry.output;
      003827 74 02            [12]  912 	mov	a,#0x02
      003829 12 3A FB         [24]  913 	lcall	_ak820_outline_0159
      00382C 90 04 6A         [24]  914 	mov	dptr,#(_ak820_combo_reload_entry_30000_608 + 0x0008)
      00382F 12 3A D1         [24]  915 	lcall	_ak820_outline_0123
      003832 12 3A E1         [24]  916 	lcall	_ak820_outline_0135
      003835 12 3A AA         [24]  917 	lcall	_ak820_outline_0086
      003838                        918 00106$:
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003838 0F               [12]  920 	inc	r7
                                    921 ;	keyboards/ajazz/ak820/ak820_combo.c:40: }
      003839 02 37 C9         [24]  922 	ljmp	00105$
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'flush'
                                    925 ;------------------------------------------------------------
                                    926 ;	keyboards/ajazz/ak820/ak820_combo.c:41: static void flush(void) {
                                    927 ;	-----------------------------------------
                                    928 ;	 function flush
                                    929 ;	-----------------------------------------
      00383C                        930 _flush:
                                    931 ;	keyboards/ajazz/ak820/ak820_combo.c:42: first = NONE;
      00383C 90 0E 12         [24]  932 	mov	dptr,#_first
      00383F 74 FF            [12]  933 	mov	a,#0xff
      003841 F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_combo.c:43: process_record(&saved);
      003842 90 04 56         [24]  936 	mov	dptr,#_saved
      003845 75 F0 00         [24]  937 	mov	b, #0x00
                                    938 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      003848 02 76 56         [24]  939 	ljmp	_process_record
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    942 ;------------------------------------------------------------
                                    943 ;now           Allocated with name '_ak820_combo_tick_now_10000_613'
                                    944 ;------------------------------------------------------------
                                    945 ;	keyboards/ajazz/ak820/ak820_combo.c:45: void ak820_combo_tick(uint16_t now) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function ak820_combo_tick
                                    948 ;	-----------------------------------------
      00384B                        949 _ak820_combo_tick:
      00384B 12 3A C2         [24]  950 	lcall	_ak820_outline_0108
      00384E 90 04 6C         [24]  951 	mov	dptr,#_ak820_combo_tick_now_10000_613
      003851 12 3A C7         [24]  952 	lcall	_ak820_outline_0109
                                    953 ;	keyboards/ajazz/ak820/ak820_combo.c:46: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= 40) flush();
      003854 12 3B 01         [24]  954 	lcall	_ak820_outline_0184
      003857 FF               [12]  955 	mov	r7,a
      003858 BF FF 01         [24]  956 	cjne	r7,#0xff,00128$
      00385B 22               [24]  957 	ret
      00385C                        958 00128$:
      00385C 90 04 5F         [24]  959 	mov	dptr,#_active
      00385F E0               [24]  960 	movx	a,@dptr
      003860 70 1E            [24]  961 	jnz	00105$
      003862 90 04 58         [24]  962 	mov	dptr,#(_saved + 0x0002)
      003865 12 3A 81         [24]  963 	lcall	_ak820_outline_0052
      003868 90 04 6C         [24]  964 	mov	dptr,#_ak820_combo_tick_now_10000_613
      00386B 12 3A 98         [24]  965 	lcall	_ak820_outline_0059
      00386E EC               [12]  966 	mov	a,r4
      00386F C3               [12]  967 	clr	c
      003870 9E               [12]  968 	subb	a,r6
      003871 FE               [12]  969 	mov	r6,a
      003872 ED               [12]  970 	mov	a,r5
      003873 9F               [12]  971 	subb	a,r7
      003874 FF               [12]  972 	mov	r7,a
      003875 C3               [12]  973 	clr	c
      003876 EE               [12]  974 	mov	a,r6
      003877 94 28            [12]  975 	subb	a,#0x28
      003879 EF               [12]  976 	mov	a,r7
      00387A 94 00            [12]  977 	subb	a,#0x00
      00387C 40 02            [24]  978 	jc	00105$
                                    979 ;	keyboards/ajazz/ak820/ak820_combo.c:47: }
      00387E 01 3C            [24]  980 	ajmp	_flush
      003880                        981 00105$:
      003880 22               [24]  982 	ret
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'ak820_combo_process'
                                    985 ;------------------------------------------------------------
                                    986 ;record        Allocated with name '_ak820_combo_process_record_10000_616'
                                    987 ;id            Allocated with name '_ak820_combo_process_id_10000_617'
                                    988 ;code          Allocated with name '_ak820_combo_process_code_10000_617'
                                    989 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_631'
                                    990 ;previous      Allocated with name '_ak820_combo_process_previous_30001_633'
                                    991 ;i             Allocated with name '_ak820_combo_process_i_40001_634'
                                    992 ;a             Allocated with name '_ak820_combo_process_a_50001_635'
                                    993 ;b             Allocated with name '_ak820_combo_process_b_50001_635'
                                    994 ;------------------------------------------------------------
                                    995 ;	keyboards/ajazz/ak820/ak820_combo.c:48: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function ak820_combo_process
                                    998 ;	-----------------------------------------
      003881                        999 _ak820_combo_process:
      003881 12 3A C2         [24] 1000 	lcall	_ak820_outline_0108
      003884 90 04 6E         [24] 1001 	mov	dptr,#_ak820_combo_process_record_10000_616
      003887 12 3A C7         [24] 1002 	lcall	_ak820_outline_0109
                                   1003 ;	keyboards/ajazz/ak820/ak820_combo.c:49: uint8_t id, code = record->keycode;
      00388A 90 04 6E         [24] 1004 	mov	dptr,#_ak820_combo_process_record_10000_616
      00388D 12 3A 3E         [24] 1005 	lcall	_ak820_outline_0008
      003890 8C 03            [24] 1006 	mov	ar3,r4
                                   1007 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (IS_NOEVENT(record->event)) return true;
      003892 74 04            [12] 1008 	mov	a,#0x04
      003894 2E               [12] 1009 	add	a, r6
      003895 12 3A 5F         [24] 1010 	lcall	_ak820_outline_0016
      003898 70 04            [24] 1011 	jnz	00102$
      00389A 75 82 01         [24] 1012 	mov	dpl, #0x01
      00389D 22               [24] 1013 	ret
      00389E                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00389E 12 3A CC         [24] 1016 	lcall	_ak820_outline_0118
      0038A1 A3               [24] 1017 	inc	dptr
      0038A2 E0               [24] 1018 	movx	a,@dptr
      0038A3 FA               [12] 1019 	mov	r2,a
      0038A4 BA 10 00         [24] 1020 	cjne	r2,#0x10,00300$
      0038A7                       1021 00300$:
      0038A7 50 0A            [24] 1022 	jnc	00106$
      0038A9 12 3A CC         [24] 1023 	lcall	_ak820_outline_0118
      0038AC E0               [24] 1024 	movx	a,@dptr
      0038AD F9               [12] 1025 	mov	r1,a
      0038AE B9 08 00         [24] 1026 	cjne	r1,#0x08,00302$
      0038B1                       1027 00302$:
      0038B1 40 15            [24] 1028 	jc	00107$
      0038B3                       1029 00106$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_combo.c:53: if (first != NONE && !active) flush();
      0038B3 12 3B 01         [24] 1031 	lcall	_ak820_outline_0184
      0038B6 F8               [12] 1032 	mov	r0,a
      0038B7 B8 FF 02         [24] 1033 	cjne	r0,#0xff,00304$
      0038BA 80 08            [24] 1034 	sjmp	00104$
      0038BC                       1035 00304$:
      0038BC 90 04 5F         [24] 1036 	mov	dptr,#_active
      0038BF E0               [24] 1037 	movx	a,@dptr
      0038C0 70 02            [24] 1038 	jnz	00104$
      0038C2 11 3C            [24] 1039 	acall	_flush
      0038C4                       1040 00104$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_combo.c:54: return true;
      0038C4 75 82 01         [24] 1042 	mov	dpl, #0x01
      0038C7 22               [24] 1043 	ret
      0038C8                       1044 00107$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:56: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      0038C8 EA               [12] 1046 	mov	a,r2
      0038C9 12 3B 06         [24] 1047 	lcall	_ak820_outline_0190
      0038CC 29               [12] 1048 	add	a,r1
      0038CD FA               [12] 1049 	mov	r2,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (active) {
      0038CE 90 04 5F         [24] 1051 	mov	dptr,#_active
      0038D1 E0               [24] 1052 	movx	a,@dptr
      0038D2 60 71            [24] 1053 	jz	00123$
                                   1054 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (id != first && id != second) return true;
      0038D4 12 3B 01         [24] 1055 	lcall	_ak820_outline_0184
      0038D7 F9               [12] 1056 	mov	r1,a
      0038D8 EA               [12] 1057 	mov	a,r2
      0038D9 B5 01 02         [24] 1058 	cjne	a,ar1,00307$
      0038DC 80 0F            [24] 1059 	sjmp	00110$
      0038DE                       1060 00307$:
      0038DE 90 0E 13         [24] 1061 	mov	dptr,#_second
      0038E1 E0               [24] 1062 	movx	a,@dptr
      0038E2 F9               [12] 1063 	mov	r1,a
      0038E3 EA               [12] 1064 	mov	a,r2
      0038E4 B5 01 02         [24] 1065 	cjne	a,ar1,00308$
      0038E7 80 04            [24] 1066 	sjmp	00110$
      0038E9                       1067 00308$:
      0038E9 75 82 01         [24] 1068 	mov	dpl, #0x01
      0038EC 22               [24] 1069 	ret
      0038ED                       1070 00110$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (!record->event.pressed) {
      0038ED 90 04 6E         [24] 1072 	mov	dptr,#_ak820_combo_process_record_10000_616
      0038F0 12 3A BC         [24] 1073 	lcall	_ak820_outline_0103
      0038F3 74 05            [12] 1074 	mov	a,#0x05
      0038F5 28               [12] 1075 	add	a, r0
      0038F6 F8               [12] 1076 	mov	r0,a
      0038F7 E4               [12] 1077 	clr	a
      0038F8 39               [12] 1078 	addc	a, r1
      0038F9 F9               [12] 1079 	mov	r1,a
      0038FA 12 3A F1         [24] 1080 	lcall	_ak820_outline_0144
      0038FD E0               [24] 1081 	movx	a,@dptr
      0038FE 70 41            [24] 1082 	jnz	00121$
                                   1083 ;	keyboards/ajazz/ak820/ak820_combo.c:60: if (saved.event.pressed) {
      003900 90 04 5B         [24] 1084 	mov	dptr,#(_saved + 0x0005)
      003903 E0               [24] 1085 	movx	a,@dptr
      003904 60 11            [24] 1086 	jz	00113$
                                   1087 ;	keyboards/ajazz/ak820/ak820_combo.c:61: saved.event.pressed = false;
      003906 90 04 5B         [24] 1088 	mov	dptr,#(_saved + 0x0005)
      003909 E4               [12] 1089 	clr	a
      00390A F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:62: process_record(&saved);
      00390B 90 04 56         [24] 1092 	mov	dptr,#_saved
      00390E F5 F0            [12] 1093 	mov	b,a
      003910 C0 02            [24] 1094 	push	ar2
      003912 12 76 56         [24] 1095 	lcall	_process_record
      003915 D0 02            [24] 1096 	pop	ar2
      003917                       1097 00113$:
                                   1098 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id == first) first = NONE;
      003917 12 3B 01         [24] 1099 	lcall	_ak820_outline_0184
      00391A F9               [12] 1100 	mov	r1,a
      00391B EA               [12] 1101 	mov	a,r2
      00391C B5 01 08         [24] 1102 	cjne	a,ar1,00115$
      00391F 90 0E 12         [24] 1103 	mov	dptr,#_first
      003922 74 FF            [12] 1104 	mov	a,#0xff
      003924 F0               [24] 1105 	movx	@dptr,a
      003925 80 06            [24] 1106 	sjmp	00116$
      003927                       1107 00115$:
                                   1108 ;	keyboards/ajazz/ak820/ak820_combo.c:65: else second = NONE;
      003927 90 0E 13         [24] 1109 	mov	dptr,#_second
      00392A 74 FF            [12] 1110 	mov	a,#0xff
      00392C F0               [24] 1111 	movx	@dptr,a
      00392D                       1112 00116$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (first == NONE && second == NONE) active = false;
      00392D 12 3B 01         [24] 1114 	lcall	_ak820_outline_0184
      003930 F9               [12] 1115 	mov	r1,a
      003931 B9 FF 0D         [24] 1116 	cjne	r1,#0xff,00121$
      003934 90 0E 13         [24] 1117 	mov	dptr,#_second
      003937 E0               [24] 1118 	movx	a,@dptr
      003938 F9               [12] 1119 	mov	r1,a
      003939 B9 FF 05         [24] 1120 	cjne	r1,#0xff,00121$
      00393C 90 04 5F         [24] 1121 	mov	dptr,#_active
      00393F E4               [12] 1122 	clr	a
      003940 F0               [24] 1123 	movx	@dptr,a
      003941                       1124 00121$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_combo.c:68: return false;
      003941 75 82 00         [24] 1126 	mov	dpl, #0x00
      003944 22               [24] 1127 	ret
      003945                       1128 00123$:
                                   1129 ;	keyboards/ajazz/ak820/ak820_combo.c:70: bool eligible = false;
      003945 90 04 70         [24] 1130 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      003948 E4               [12] 1131 	clr	a
      003949 F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_combo.c:71: if (record->event.pressed && input(record->keycode)) {
      00394A 12 3A 52         [24] 1134 	lcall	_ak820_outline_0010
      00394D 70 02            [24] 1135 	jnz	00317$
      00394F 21 F3            [12] 1136 	ajmp	00134$
      003951                       1137 00317$:
      003951 12 3A D7         [24] 1138 	lcall	_ak820_outline_0124
      003954 C0 03            [24] 1139 	push	ar3
      003956 C0 02            [24] 1140 	push	ar2
      003958 12 36 B3         [24] 1141 	lcall	_input
      00395B E5 82            [12] 1142 	mov	a, dpl
      00395D D0 02            [24] 1143 	pop	ar2
      00395F D0 03            [24] 1144 	pop	ar3
      003961 70 02            [24] 1145 	jnz	00318$
      003963 21 F3            [12] 1146 	ajmp	00134$
      003965                       1147 00318$:
                                   1148 ;	keyboards/ajazz/ak820/ak820_combo.c:72: uint8_t previous = saved.keycode;
      003965 90 04 5D         [24] 1149 	mov	dptr,#(_saved + 0x0007)
      003968 E0               [24] 1150 	movx	a,@dptr
      003969 FF               [12] 1151 	mov	r7,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00396A 90 04 71         [24] 1153 	mov	dptr,#_ak820_combo_process_i_40001_634
      00396D E4               [12] 1154 	clr	a
      00396E F0               [24] 1155 	movx	@dptr,a
      00396F EB               [12] 1156 	mov	a,r3
      003970 B5 07 03         [24] 1157 	cjne	a,ar7,00319$
      003973 D3               [12] 1158 	setb	c
      003974 80 01            [24] 1159 	sjmp	00320$
      003976                       1160 00319$:
      003976 C3               [12] 1161 	clr	c
      003977                       1162 00320$:
      003977 92 04            [24] 1163 	mov	_ak820_combo_process_sloc0_1_0,c
      003979 7E 00            [12] 1164 	mov	r6,#0x00
      00397B                       1165 00141$:
      00397B BE 08 00         [24] 1166 	cjne	r6,#0x08,00321$
      00397E                       1167 00321$:
      00397E 40 02            [24] 1168 	jc	00322$
      003980 21 F3            [12] 1169 	ajmp	00134$
      003982                       1170 00322$:
                                   1171 ;	keyboards/ajazz/ak820/ak820_combo.c:74: uint8_t a = combos[i].a, b = combos[i].b;
      003982 EE               [12] 1172 	mov	a,r6
      003983 12 3A 87         [24] 1173 	lcall	_ak820_outline_0054
      003986 E0               [24] 1174 	movx	a,@dptr
      003987 F9               [12] 1175 	mov	r1,a
      003988 90 04 72         [24] 1176 	mov	dptr,#_ak820_combo_process_a_50001_635
      00398B 12 3A B6         [24] 1177 	lcall	_ak820_outline_0102
      00398E A3               [24] 1178 	inc	dptr
      00398F E0               [24] 1179 	movx	a,@dptr
      003990 FD               [12] 1180 	mov	r5,a
      003991 90 04 73         [24] 1181 	mov	dptr,#_ak820_combo_process_b_50001_635
      003994 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (a == code || b == code) {
      003995 E9               [12] 1184 	mov	a,r1
      003996 B5 03 02         [24] 1185 	cjne	a,ar3,00323$
      003999 80 04            [24] 1186 	sjmp	00129$
      00399B                       1187 00323$:
      00399B ED               [12] 1188 	mov	a,r5
      00399C B5 03 4C         [24] 1189 	cjne	a,ar3,00142$
      00399F                       1190 00129$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_combo.c:76: eligible = true;
      00399F 90 04 70         [24] 1192 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      0039A2 74 01            [12] 1193 	mov	a,#0x01
      0039A4 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (first != NONE && code != previous && (a == previous || b == previous)) {
      0039A5 12 3B 01         [24] 1196 	lcall	_ak820_outline_0184
      0039A8 FD               [12] 1197 	mov	r5,a
      0039A9 BD FF 02         [24] 1198 	cjne	r5,#0xff,00326$
      0039AC 80 3D            [24] 1199 	sjmp	00142$
      0039AE                       1200 00326$:
      0039AE 20 04 3A         [24] 1201 	jb	_ak820_combo_process_sloc0_1_0,00142$
      0039B1 90 04 72         [24] 1202 	mov	dptr,#_ak820_combo_process_a_50001_635
      0039B4 E0               [24] 1203 	movx	a,@dptr
      0039B5 B5 07 02         [24] 1204 	cjne	a,ar7,00328$
      0039B8 80 07            [24] 1205 	sjmp	00124$
      0039BA                       1206 00328$:
      0039BA 90 04 73         [24] 1207 	mov	dptr,#_ak820_combo_process_b_50001_635
      0039BD E0               [24] 1208 	movx	a,@dptr
      0039BE B5 07 2A         [24] 1209 	cjne	a,ar7,00142$
      0039C1                       1210 00124$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_combo.c:78: second = id;
      0039C1 90 0E 13         [24] 1212 	mov	dptr,#_second
      0039C4 EA               [12] 1213 	mov	a,r2
      0039C5 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_combo.c:79: active = true;
      0039C6 90 04 5F         [24] 1216 	mov	dptr,#_active
      0039C9 74 01            [12] 1217 	mov	a,#0x01
      0039CB F0               [24] 1218 	movx	@dptr,a
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:80: saved.keycode = combos[i].output;
      0039CC 90 04 71         [24] 1220 	mov	dptr,#_ak820_combo_process_i_40001_634
      0039CF E0               [24] 1221 	movx	a,@dptr
      0039D0 12 3A 87         [24] 1222 	lcall	_ak820_outline_0054
      0039D3 A3               [24] 1223 	inc	dptr
      0039D4 A3               [24] 1224 	inc	dptr
      0039D5 12 3A 98         [24] 1225 	lcall	_ak820_outline_0059
      0039D8 90 04 5D         [24] 1226 	mov	dptr,#(_saved + 0x0007)
      0039DB 12 3A 9E         [24] 1227 	lcall	_ak820_outline_0072
                                   1228 ;	keyboards/ajazz/ak820/ak820_combo.c:81: process_record(&saved);
      0039DE 90 04 56         [24] 1229 	mov	dptr,#_saved
      0039E1 75 F0 00         [24] 1230 	mov	b, #0x00
      0039E4 12 76 56         [24] 1231 	lcall	_process_record
                                   1232 ;	keyboards/ajazz/ak820/ak820_combo.c:82: return false;
      0039E7 75 82 00         [24] 1233 	mov	dpl, #0x00
      0039EA 22               [24] 1234 	ret
      0039EB                       1235 00142$:
                                   1236 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0039EB 0E               [12] 1237 	inc	r6
      0039EC 90 04 71         [24] 1238 	mov	dptr,#_ak820_combo_process_i_40001_634
      0039EF EE               [12] 1239 	mov	a,r6
      0039F0 F0               [24] 1240 	movx	@dptr,a
      0039F1 21 7B            [24] 1241 	ajmp	00141$
      0039F3                       1242 00134$:
                                   1243 ;	keyboards/ajazz/ak820/ak820_combo.c:87: if (first != NONE) flush();
      0039F3 12 3B 01         [24] 1244 	lcall	_ak820_outline_0184
      0039F6 FF               [12] 1245 	mov	r7,a
      0039F7 BF FF 02         [24] 1246 	cjne	r7,#0xff,00331$
      0039FA 80 06            [24] 1247 	sjmp	00137$
      0039FC                       1248 00331$:
      0039FC C0 02            [24] 1249 	push	ar2
      0039FE 11 3C            [24] 1250 	acall	_flush
      003A00 D0 02            [24] 1251 	pop	ar2
      003A02                       1252 00137$:
                                   1253 ;	keyboards/ajazz/ak820/ak820_combo.c:88: if (eligible) {
      003A02 90 04 70         [24] 1254 	mov	dptr,#_ak820_combo_process_eligible_10001_631
      003A05 E0               [24] 1255 	movx	a,@dptr
      003A06 60 28            [24] 1256 	jz	00139$
                                   1257 ;	keyboards/ajazz/ak820/ak820_combo.c:89: first = id;
      003A08 90 0E 12         [24] 1258 	mov	dptr,#_first
      003A0B EA               [12] 1259 	mov	a,r2
      003A0C F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	keyboards/ajazz/ak820/ak820_combo.c:90: saved = *record;
      003A0D 90 04 6E         [24] 1262 	mov	dptr,#_ak820_combo_process_record_10000_616
      003A10 12 3A A4         [24] 1263 	lcall	_ak820_outline_0079
      003A13 7F 00            [12] 1264 	mov	r7,#0x00
      003A15 90 0E 03         [24] 1265 	mov	dptr,#___memcpy_PARM_2
      003A18 ED               [12] 1266 	mov	a,r5
      003A19 12 3A 69         [24] 1267 	lcall	_ak820_outline_0017
      003A1C 90 0E 06         [24] 1268 	mov	dptr,#___memcpy_PARM_3
      003A1F 74 09            [12] 1269 	mov	a,#0x09
      003A21 12 3A DC         [24] 1270 	lcall	_ak820_outline_0134
      003A24 90 04 56         [24] 1271 	mov	dptr,#_saved
      003A27 F5 F0            [12] 1272 	mov	b,a
      003A29 12 BD 67         [24] 1273 	lcall	___memcpy
                                   1274 ;	keyboards/ajazz/ak820/ak820_combo.c:91: return false;
      003A2C 75 82 00         [24] 1275 	mov	dpl, #0x00
      003A2F 22               [24] 1276 	ret
      003A30                       1277 00139$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_combo.c:93: return true;
      003A30 75 82 01         [24] 1279 	mov	dpl, #0x01
                                   1280 ;	keyboards/ajazz/ak820/ak820_combo.c:94: }
      003A33 22               [24] 1281 	ret
                                   1282 	.area CSEG    (CODE)
                                   1283 	.area CONST   (CODE)
                                   1284 	.area XINIT   (CODE)
      00C626                       1285 __xinit__first:
      00C626 FF                    1286 	.db #0xff	; 255
      00C627                       1287 __xinit__second:
      00C627 FF                    1288 	.db #0xff	; 255
                                   1289 	.area CABS    (ABS,CODE)
                                   1290 
                                   1291 ; Experimental exact instruction outlining.
                                   1292 	.globl _ak820_outline_0005
                                   1293 	.globl _ak820_outline_0008
                                   1294 	.globl _ak820_outline_0010
                                   1295 	.globl _ak820_outline_0016
                                   1296 	.globl _ak820_outline_0017
                                   1297 	.globl _ak820_outline_0022
                                   1298 	.globl _ak820_outline_0036
                                   1299 	.globl _ak820_outline_0052
                                   1300 	.globl _ak820_outline_0054
                                   1301 	.globl _ak820_outline_0059
                                   1302 	.globl _ak820_outline_0072
                                   1303 	.globl _ak820_outline_0079
                                   1304 	.globl _ak820_outline_0086
                                   1305 	.globl _ak820_outline_0094
                                   1306 	.globl _ak820_outline_0102
                                   1307 	.globl _ak820_outline_0103
                                   1308 	.globl _ak820_outline_0108
                                   1309 	.globl _ak820_outline_0109
                                   1310 	.globl _ak820_outline_0118
                                   1311 	.globl _ak820_outline_0121
                                   1312 	.globl _ak820_outline_0123
                                   1313 	.globl _ak820_outline_0124
                                   1314 	.globl _ak820_outline_0134
                                   1315 	.globl _ak820_outline_0135
                                   1316 	.globl _ak820_outline_0138
                                   1317 	.globl _ak820_outline_0143
                                   1318 	.globl _ak820_outline_0144
                                   1319 	.globl _ak820_outline_0156
                                   1320 	.globl _ak820_outline_0159
                                   1321 	.globl _ak820_outline_0184
                                   1322 	.globl _ak820_outline_0190
                                   1323 
                                   1324 	.area CSEG (CODE)
                                   1325 ; function ak820_outline_0005
      003A34                       1326 _ak820_outline_0005:
      003A34 E0               [24] 1327 	movx	a,@dptr
      003A35 FE               [12] 1328 	mov	r6,a
      003A36 A3               [24] 1329 	inc	dptr
      003A37 E0               [24] 1330 	movx	a,@dptr
      003A38 FF               [12] 1331 	mov	r7,a
      003A39 8E 82            [24] 1332 	mov	dpl,r6
      003A3B 8F 83            [24] 1333 	mov	dph,r7
      003A3D 22               [24] 1334 	ret
                                   1335 
                                   1336 	.area CSEG (CODE)
                                   1337 ; function ak820_outline_0008
      003A3E                       1338 _ak820_outline_0008:
      003A3E E0               [24] 1339 	movx	a,@dptr
      003A3F FE               [12] 1340 	mov	r6,a
      003A40 A3               [24] 1341 	inc	dptr
      003A41 E0               [24] 1342 	movx	a,@dptr
      003A42 FF               [12] 1343 	mov	r7,a
      003A43 74 07            [12] 1344 	mov	a,#0x07
      003A45 2E               [12] 1345 	add	a,r6
      003A46 F5 82            [12] 1346 	mov	dpl,a
      003A48 E4               [12] 1347 	clr	a
      003A49 3F               [12] 1348 	addc	a,r7
      003A4A F5 83            [12] 1349 	mov	dph,a
      003A4C E0               [24] 1350 	movx	a,@dptr
      003A4D FC               [12] 1351 	mov	r4,a
      003A4E A3               [24] 1352 	inc	dptr
      003A4F E0               [24] 1353 	movx	a,@dptr
      003A50 FD               [12] 1354 	mov	r5,a
      003A51 22               [24] 1355 	ret
                                   1356 
                                   1357 	.area CSEG (CODE)
                                   1358 ; function ak820_outline_0010
      003A52                       1359 _ak820_outline_0010:
      003A52 74 05            [12] 1360 	mov	a,#0x05
      003A54 2E               [12] 1361 	add	a,r6
      003A55 FE               [12] 1362 	mov	r6,a
      003A56 E4               [12] 1363 	clr	a
      003A57 3F               [12] 1364 	addc	a,r7
      003A58 FF               [12] 1365 	mov	r7,a
      003A59 8E 82            [24] 1366 	mov	dpl,r6
      003A5B 8F 83            [24] 1367 	mov	dph,r7
      003A5D E0               [24] 1368 	movx	a,@dptr
      003A5E 22               [24] 1369 	ret
                                   1370 
                                   1371 	.area CSEG (CODE)
                                   1372 ; function ak820_outline_0016
      003A5F                       1373 _ak820_outline_0016:
      003A5F F9               [12] 1374 	mov	r1,a
      003A60 E4               [12] 1375 	clr	a
      003A61 3F               [12] 1376 	addc	a,r7
      003A62 FA               [12] 1377 	mov	r2,a
      003A63 89 82            [24] 1378 	mov	dpl,r1
      003A65 8A 83            [24] 1379 	mov	dph,r2
      003A67 E0               [24] 1380 	movx	a,@dptr
      003A68 22               [24] 1381 	ret
                                   1382 
                                   1383 	.area CSEG (CODE)
                                   1384 ; function ak820_outline_0017
      003A69                       1385 _ak820_outline_0017:
      003A69 F0               [24] 1386 	movx	@dptr,a
      003A6A EE               [12] 1387 	mov	a,r6
      003A6B A3               [24] 1388 	inc	dptr
      003A6C F0               [24] 1389 	movx	@dptr,a
      003A6D EF               [12] 1390 	mov	a,r7
      003A6E A3               [24] 1391 	inc	dptr
      003A6F F0               [24] 1392 	movx	@dptr,a
      003A70 22               [24] 1393 	ret
                                   1394 
                                   1395 	.area CSEG (CODE)
                                   1396 ; function ak820_outline_0022
      003A71                       1397 _ak820_outline_0022:
      003A71 2E               [12] 1398 	add	a,r6
      003A72 F5 82            [12] 1399 	mov	dpl,a
      003A74 E4               [12] 1400 	clr	a
      003A75 3F               [12] 1401 	addc	a,r7
      003A76 F5 83            [12] 1402 	mov	dph,a
      003A78 22               [24] 1403 	ret
                                   1404 
                                   1405 	.area CSEG (CODE)
                                   1406 ; function ak820_outline_0036
      003A79                       1407 _ak820_outline_0036:
      003A79 8E 82            [24] 1408 	mov	dpl,r6
      003A7B 8F 83            [24] 1409 	mov	dph,r7
      003A7D A3               [24] 1410 	inc	dptr
      003A7E A3               [24] 1411 	inc	dptr
      003A7F E0               [24] 1412 	movx	a,@dptr
      003A80 22               [24] 1413 	ret
                                   1414 
                                   1415 	.area CSEG (CODE)
                                   1416 ; function ak820_outline_0052
      003A81                       1417 _ak820_outline_0052:
      003A81 E0               [24] 1418 	movx	a,@dptr
      003A82 FE               [12] 1419 	mov	r6,a
      003A83 A3               [24] 1420 	inc	dptr
      003A84 E0               [24] 1421 	movx	a,@dptr
      003A85 FF               [12] 1422 	mov	r7,a
      003A86 22               [24] 1423 	ret
                                   1424 
                                   1425 	.area CSEG (CODE)
                                   1426 ; function ak820_outline_0054
      003A87                       1427 _ak820_outline_0054:
      003A87 75 F0 04         [24] 1428 	mov	b,#0x04
      003A8A A4               [48] 1429 	mul	ab
      003A8B 24 36            [12] 1430 	add	a,#_combos
      003A8D FC               [12] 1431 	mov	r4,a
      003A8E 74 04            [12] 1432 	mov	a,#(_combos>>8)
      003A90 35 F0            [12] 1433 	addc	a,b
      003A92 FD               [12] 1434 	mov	r5,a
      003A93 8C 82            [24] 1435 	mov	dpl,r4
      003A95 8D 83            [24] 1436 	mov	dph,r5
      003A97 22               [24] 1437 	ret
                                   1438 
                                   1439 	.area CSEG (CODE)
                                   1440 ; function ak820_outline_0059
      003A98                       1441 _ak820_outline_0059:
      003A98 E0               [24] 1442 	movx	a,@dptr
      003A99 FC               [12] 1443 	mov	r4,a
      003A9A A3               [24] 1444 	inc	dptr
      003A9B E0               [24] 1445 	movx	a,@dptr
      003A9C FD               [12] 1446 	mov	r5,a
      003A9D 22               [24] 1447 	ret
                                   1448 
                                   1449 	.area CSEG (CODE)
                                   1450 ; function ak820_outline_0072
      003A9E                       1451 _ak820_outline_0072:
      003A9E EC               [12] 1452 	mov	a,r4
      003A9F F0               [24] 1453 	movx	@dptr,a
      003AA0 ED               [12] 1454 	mov	a,r5
      003AA1 A3               [24] 1455 	inc	dptr
      003AA2 F0               [24] 1456 	movx	@dptr,a
      003AA3 22               [24] 1457 	ret
                                   1458 
                                   1459 	.area CSEG (CODE)
                                   1460 ; function ak820_outline_0079
      003AA4                       1461 _ak820_outline_0079:
      003AA4 E0               [24] 1462 	movx	a,@dptr
      003AA5 FD               [12] 1463 	mov	r5,a
      003AA6 A3               [24] 1464 	inc	dptr
      003AA7 E0               [24] 1465 	movx	a,@dptr
      003AA8 FE               [12] 1466 	mov	r6,a
      003AA9 22               [24] 1467 	ret
                                   1468 
                                   1469 	.area CSEG (CODE)
                                   1470 ; function ak820_outline_0086
      003AAA                       1471 _ak820_outline_0086:
      003AAA EB               [12] 1472 	mov	a,r3
      003AAB F0               [24] 1473 	movx	@dptr,a
      003AAC EC               [12] 1474 	mov	a,r4
      003AAD A3               [24] 1475 	inc	dptr
      003AAE F0               [24] 1476 	movx	@dptr,a
      003AAF 22               [24] 1477 	ret
                                   1478 
                                   1479 	.area CSEG (CODE)
                                   1480 ; function ak820_outline_0094
      003AB0                       1481 _ak820_outline_0094:
      003AB0 A3               [24] 1482 	inc	dptr
      003AB1 F0               [24] 1483 	movx	@dptr,a
      003AB2 E4               [12] 1484 	clr	a
      003AB3 A3               [24] 1485 	inc	dptr
      003AB4 F0               [24] 1486 	movx	@dptr,a
      003AB5 22               [24] 1487 	ret
                                   1488 
                                   1489 	.area CSEG (CODE)
                                   1490 ; function ak820_outline_0102
      003AB6                       1491 _ak820_outline_0102:
      003AB6 F0               [24] 1492 	movx	@dptr,a
      003AB7 8C 82            [24] 1493 	mov	dpl,r4
      003AB9 8D 83            [24] 1494 	mov	dph,r5
      003ABB 22               [24] 1495 	ret
                                   1496 
                                   1497 	.area CSEG (CODE)
                                   1498 ; function ak820_outline_0103
      003ABC                       1499 _ak820_outline_0103:
      003ABC E0               [24] 1500 	movx	a,@dptr
      003ABD F8               [12] 1501 	mov	r0,a
      003ABE A3               [24] 1502 	inc	dptr
      003ABF E0               [24] 1503 	movx	a,@dptr
      003AC0 F9               [12] 1504 	mov	r1,a
      003AC1 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0108
      003AC2                       1509 _ak820_outline_0108:
      003AC2 AF 83            [24] 1510 	mov	r7,dph
      003AC4 E5 82            [12] 1511 	mov	a,dpl
      003AC6 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0109
      003AC7                       1516 _ak820_outline_0109:
      003AC7 F0               [24] 1517 	movx	@dptr,a
      003AC8 EF               [12] 1518 	mov	a,r7
      003AC9 A3               [24] 1519 	inc	dptr
      003ACA F0               [24] 1520 	movx	@dptr,a
      003ACB 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0118
      003ACC                       1525 _ak820_outline_0118:
      003ACC 8E 82            [24] 1526 	mov	dpl,r6
      003ACE 8F 83            [24] 1527 	mov	dph,r7
      003AD0 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0123
      003AD1                       1532 _ak820_outline_0123:
      003AD1 E0               [24] 1533 	movx	a,@dptr
      003AD2 FB               [12] 1534 	mov	r3,a
      003AD3 A3               [24] 1535 	inc	dptr
      003AD4 E0               [24] 1536 	movx	a,@dptr
      003AD5 FC               [12] 1537 	mov	r4,a
      003AD6 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0124
      003AD7                       1542 _ak820_outline_0124:
      003AD7 8C 82            [24] 1543 	mov	dpl,r4
      003AD9 8D 83            [24] 1544 	mov	dph,r5
      003ADB 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0134
      003ADC                       1549 _ak820_outline_0134:
      003ADC F0               [24] 1550 	movx	@dptr,a
      003ADD E4               [12] 1551 	clr	a
      003ADE A3               [24] 1552 	inc	dptr
      003ADF F0               [24] 1553 	movx	@dptr,a
      003AE0 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0135
      003AE1                       1558 _ak820_outline_0135:
      003AE1 8D 82            [24] 1559 	mov	dpl,r5
      003AE3 8E 83            [24] 1560 	mov	dph,r6
      003AE5 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0138
      003AE6                       1565 _ak820_outline_0138:
      003AE6 E5 82            [12] 1566 	mov	a,dpl
      003AE8 85 83 F0         [24] 1567 	mov	b,dph
      003AEB 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0143
      003AEC                       1572 _ak820_outline_0143:
      003AEC 8A 82            [24] 1573 	mov	dpl,r2
      003AEE 8B 83            [24] 1574 	mov	dph,r3
      003AF0 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0144
      003AF1                       1579 _ak820_outline_0144:
      003AF1 88 82            [24] 1580 	mov	dpl,r0
      003AF3 89 83            [24] 1581 	mov	dph,r1
      003AF5 22               [24] 1582 	ret
                                   1583 
                                   1584 	.area CSEG (CODE)
                                   1585 ; function ak820_outline_0156
      003AF6                       1586 _ak820_outline_0156:
      003AF6 E4               [12] 1587 	clr	a
      003AF7 33               [12] 1588 	rlc	a
      003AF8 F5 82            [12] 1589 	mov	dpl,a
      003AFA 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0159
      003AFB                       1594 _ak820_outline_0159:
      003AFB 2D               [12] 1595 	add	a,r5
      003AFC FD               [12] 1596 	mov	r5,a
      003AFD E4               [12] 1597 	clr	a
      003AFE 3E               [12] 1598 	addc	a,r6
      003AFF FE               [12] 1599 	mov	r6,a
      003B00 22               [24] 1600 	ret
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0184
      003B01                       1604 _ak820_outline_0184:
      003B01 90 0E 12         [24] 1605 	mov	dptr,#_first
      003B04 E0               [24] 1606 	movx	a,@dptr
      003B05 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0190
      003B06                       1611 _ak820_outline_0190:
      003B06 C4               [12] 1612 	swap	a
      003B07 03               [12] 1613 	rr	a
      003B08 54 F8            [12] 1614 	anl	a,#0xf8
      003B0A 22               [24] 1615 	ret
