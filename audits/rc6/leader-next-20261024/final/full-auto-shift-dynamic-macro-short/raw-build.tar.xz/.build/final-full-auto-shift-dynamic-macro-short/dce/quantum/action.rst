                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _ak820_dynamic_macro_cancel
                                     24 	.globl _ak820_dynamic_macro_task
                                     25 	.globl _ak820_dynamic_macro_observe
                                     26 	.globl _ak820_dynamic_macro_process
                                     27 	.globl _pre_process_record_quantum
                                     28 	.globl _get_record_keycode
                                     29 	.globl _get_repeat_key_count
                                     30 	.globl _repeat_key_cancel
                                     31 	.globl _clear_owned_usages
                                     32 	.globl _owned_usage_key
                                     33 	.globl _clear_owned_keys
                                     34 	.globl _del_owned_key
                                     35 	.globl _add_owned_key
                                     36 	.globl _clear_owned_mods
                                     37 	.globl _del_owned_weak_mods
                                     38 	.globl _add_owned_weak_mods
                                     39 	.globl _del_owned_mods
                                     40 	.globl _add_owned_mods
                                     41 	.globl _clear_weak_mods
                                     42 	.globl _clear_mods
                                     43 	.globl _send_keyboard_report
                                     44 	.globl _layer_hold_clear
                                     45 	.globl _layer_hold_off
                                     46 	.globl _layer_hold_on
                                     47 	.globl _ak820_resolve_key
                                     48 	.globl _layer_xor
                                     49 	.globl _layer_and
                                     50 	.globl _layer_or
                                     51 	.globl _layer_off
                                     52 	.globl _layer_on
                                     53 	.globl _layer_move
                                     54 	.globl _layer_clear
                                     55 	.globl _layer_state_set
                                     56 	.globl _default_layer_xor
                                     57 	.globl _default_layer_and
                                     58 	.globl _default_layer_or
                                     59 	.globl _default_layer_set
                                     60 	.globl _post_process_record_quantum
                                     61 	.globl _process_record_quantum
                                     62 	.globl _action_for_keycode
                                     63 	.globl _mDelaymS
                                     64 	.globl _host_consumer_send
                                     65 	.globl _host_system_send
                                     66 	.globl _host_keyboard_leds
                                     67 	.globl _led_set
                                     68 	.globl _clear_keys_from_report
                                     69 	.globl ___memcpy
                                     70 	.globl _ADC_START
                                     71 	.globl _S0_R_FIFO
                                     72 	.globl _S0_T_FIFO
                                     73 	.globl _S0_FREE
                                     74 	.globl _S0_IF_BYTE
                                     75 	.globl _S0_IF_FIRST
                                     76 	.globl _S0_IF_OV
                                     77 	.globl _S0_FST_ACT
                                     78 	.globl _CP_RL2
                                     79 	.globl _C_T2
                                     80 	.globl _TR2
                                     81 	.globl _EXEN2
                                     82 	.globl _TCLK
                                     83 	.globl _RCLK
                                     84 	.globl _EXF2
                                     85 	.globl _CAP1F
                                     86 	.globl _TF2
                                     87 	.globl _RI
                                     88 	.globl _TI
                                     89 	.globl _RB8
                                     90 	.globl _TB8
                                     91 	.globl _REN
                                     92 	.globl _SM2
                                     93 	.globl _SM1
                                     94 	.globl _SM0
                                     95 	.globl _IT0
                                     96 	.globl _IE0
                                     97 	.globl _IT1
                                     98 	.globl _IE1
                                     99 	.globl _TR0
                                    100 	.globl _TF0
                                    101 	.globl _TR1
                                    102 	.globl _TF1
                                    103 	.globl _P4_0
                                    104 	.globl _P4_1
                                    105 	.globl _P4_2
                                    106 	.globl _P4_3
                                    107 	.globl _P4_4
                                    108 	.globl _P4_5
                                    109 	.globl _P4_6
                                    110 	.globl _RXD
                                    111 	.globl _TXD
                                    112 	.globl _INT0
                                    113 	.globl _INT1
                                    114 	.globl _T0
                                    115 	.globl _T1
                                    116 	.globl _MOSI1
                                    117 	.globl _MISO1
                                    118 	.globl _SCK1
                                    119 	.globl _P3_0
                                    120 	.globl _P3_1
                                    121 	.globl _P3_2
                                    122 	.globl _P3_3
                                    123 	.globl _P3_4
                                    124 	.globl _P3_5
                                    125 	.globl _P3_6
                                    126 	.globl _P3_7
                                    127 	.globl _CAP1_
                                    128 	.globl _T2_
                                    129 	.globl _CAP2_
                                    130 	.globl _T2EX_
                                    131 	.globl _RXD1
                                    132 	.globl _TXD1
                                    133 	.globl _P2_0
                                    134 	.globl _P2_1
                                    135 	.globl _P2_2
                                    136 	.globl _P2_3
                                    137 	.globl _P2_4
                                    138 	.globl _P2_5
                                    139 	.globl _P2_6
                                    140 	.globl _P2_7
                                    141 	.globl _AIN0
                                    142 	.globl _AIN1
                                    143 	.globl _AIN2
                                    144 	.globl _AIN3
                                    145 	.globl _AIN4
                                    146 	.globl _AIN5
                                    147 	.globl _AIN6
                                    148 	.globl _AIN7
                                    149 	.globl _CAP1
                                    150 	.globl _T2
                                    151 	.globl _CAP2
                                    152 	.globl _T2EX
                                    153 	.globl _INT0_
                                    154 	.globl _SCS
                                    155 	.globl _MOSI
                                    156 	.globl _MISO
                                    157 	.globl _SCK
                                    158 	.globl _RXD1_
                                    159 	.globl _TXD1_
                                    160 	.globl _P1_0
                                    161 	.globl _P1_1
                                    162 	.globl _P1_2
                                    163 	.globl _P1_3
                                    164 	.globl _P1_4
                                    165 	.globl _P1_5
                                    166 	.globl _P1_6
                                    167 	.globl _P1_7
                                    168 	.globl _AIN8
                                    169 	.globl _AIN9
                                    170 	.globl _AIN10
                                    171 	.globl _AIN11
                                    172 	.globl _AIN12
                                    173 	.globl _AIN13
                                    174 	.globl _RXD_
                                    175 	.globl _TXD_
                                    176 	.globl _SCL0
                                    177 	.globl _SDA0
                                    178 	.globl _P0_0
                                    179 	.globl _P0_1
                                    180 	.globl _P0_2
                                    181 	.globl _P0_3
                                    182 	.globl _P0_4
                                    183 	.globl _P0_5
                                    184 	.globl _P0_6
                                    185 	.globl _P0_7
                                    186 	.globl _IE_SPI0
                                    187 	.globl _IE_USB
                                    188 	.globl _IE_ADC
                                    189 	.globl _IE_UART1
                                    190 	.globl _IE_PWM_I2C
                                    191 	.globl _IE_GPIO
                                    192 	.globl _IE_WDOG
                                    193 	.globl _PX0
                                    194 	.globl _PT0
                                    195 	.globl _PX1
                                    196 	.globl _PT1
                                    197 	.globl _PS
                                    198 	.globl _PT2
                                    199 	.globl _PL_FLAG
                                    200 	.globl _PH_FLAG
                                    201 	.globl _EX0
                                    202 	.globl _ET0
                                    203 	.globl _EX1
                                    204 	.globl _ET1
                                    205 	.globl _ES
                                    206 	.globl _ET2
                                    207 	.globl _E_DIS
                                    208 	.globl _EA
                                    209 	.globl _P
                                    210 	.globl _F1
                                    211 	.globl _OV
                                    212 	.globl _RS0
                                    213 	.globl _RS1
                                    214 	.globl _F0
                                    215 	.globl _AC
                                    216 	.globl _CY
                                    217 	.globl _I2CS_INT_ST
                                    218 	.globl _I2CX_INT
                                    219 	.globl _LED_STATUS
                                    220 	.globl _LED_DMA_H
                                    221 	.globl _LED_DMA_L
                                    222 	.globl _LED_DMA
                                    223 	.globl _LED_PWM_OE
                                    224 	.globl _LED_COMMON
                                    225 	.globl _ADC_CHAN
                                    226 	.globl _ADC_DAT_H
                                    227 	.globl _ADC_DAT_L
                                    228 	.globl _ADC_DAT
                                    229 	.globl _ADC_CTRL
                                    230 	.globl _SPI1_CK_SE
                                    231 	.globl _SPI1_CTRL
                                    232 	.globl _SPI1_DATA
                                    233 	.globl _SPI1_STAT
                                    234 	.globl _SIF1
                                    235 	.globl _SBAUD1
                                    236 	.globl _SBUF1
                                    237 	.globl _SCON1
                                    238 	.globl _SPI0_SETUP
                                    239 	.globl _SPI0_CK_SE
                                    240 	.globl _SPI0_CTRL
                                    241 	.globl _SPI0_DATA
                                    242 	.globl _SPI0_STAT
                                    243 	.globl _T2CAP1H
                                    244 	.globl _T2CAP1L
                                    245 	.globl _T2CAP1
                                    246 	.globl _TH2
                                    247 	.globl _TL2
                                    248 	.globl _T2COUNT
                                    249 	.globl _RCAP2H
                                    250 	.globl _RCAP2L
                                    251 	.globl _RCAP2
                                    252 	.globl _T2MOD
                                    253 	.globl _T2CON
                                    254 	.globl _SBUF
                                    255 	.globl _SCON
                                    256 	.globl _TH1
                                    257 	.globl _TH0
                                    258 	.globl _TL1
                                    259 	.globl _TL0
                                    260 	.globl _TMOD
                                    261 	.globl _TCON
                                    262 	.globl _XBUS_AUX
                                    263 	.globl _P7
                                    264 	.globl _P6_DIR
                                    265 	.globl _P6_OUT_PU
                                    266 	.globl _P6_IN
                                    267 	.globl _P5_DIR
                                    268 	.globl _P5_OUT_PU
                                    269 	.globl _P5_IN
                                    270 	.globl _P4_LED_KEY
                                    271 	.globl _P4_DIR_PU
                                    272 	.globl _P4_MOD_OC
                                    273 	.globl _P4
                                    274 	.globl _P3_DIR_PU
                                    275 	.globl _P3_MOD_OC
                                    276 	.globl _P3
                                    277 	.globl _P2_DIR_PU
                                    278 	.globl _P2_MOD_OC
                                    279 	.globl _P2
                                    280 	.globl _P1_DIR_PU
                                    281 	.globl _P1_MOD_OC
                                    282 	.globl _P1
                                    283 	.globl _P0_DIR_PU
                                    284 	.globl _P0_MOD_OC
                                    285 	.globl _P0
                                    286 	.globl _ROM_CTRL
                                    287 	.globl _ROM_DATA_HH
                                    288 	.globl _ROM_DATA_HL
                                    289 	.globl _ROM_DATA_HI
                                    290 	.globl _ROM_ADDR_H
                                    291 	.globl _ROM_ADDR_L
                                    292 	.globl _ROM_ADDR
                                    293 	.globl _GPIO_IE
                                    294 	.globl _IP_EX
                                    295 	.globl _IE_EX
                                    296 	.globl _IP
                                    297 	.globl _IE
                                    298 	.globl _WDOG_COUNT
                                    299 	.globl _RESET_KEEP
                                    300 	.globl _WAKE_CTRL
                                    301 	.globl _CLOCK_CFG
                                    302 	.globl _POWER_CFG
                                    303 	.globl _PCON
                                    304 	.globl _GLOBAL_CFG
                                    305 	.globl _SAFE_MOD
                                    306 	.globl _DPH
                                    307 	.globl _DPL
                                    308 	.globl _SP
                                    309 	.globl _A_INV
                                    310 	.globl _B
                                    311 	.globl _ACC
                                    312 	.globl _PSW
                                    313 	.globl _disable_action_cache
                                    314 	.globl _tap_code_delay_PARM_2
                                    315 	.globl _process_action_PARM_2
                                    316 	.globl _action_exec_PARM_1
                                    317 	.globl _tp_buttons
                                    318 	.globl _action_exec
                                    319 	.globl _ak820_action_exec
                                    320 	.globl _process_record
                                    321 	.globl _process_record_handler
                                    322 	.globl _process_action
                                    323 	.globl _register_code
                                    324 	.globl _unregister_code
                                    325 	.globl _tap_code_delay
                                    326 	.globl _tap_code
                                    327 	.globl _register_mods
                                    328 	.globl _unregister_mods
                                    329 	.globl _register_weak_mods
                                    330 	.globl _unregister_weak_mods
                                    331 	.globl _clear_keyboard
                                    332 	.globl _clear_keyboard_but_mods
                                    333 	.globl _clear_keyboard_but_mods_and_keys
                                    334 ;--------------------------------------------------------
                                    335 ; special function registers
                                    336 ;--------------------------------------------------------
                                    337 	.area RSEG    (ABS,DATA)
      000000                        338 	.org 0x0000
                           0000D0   339 _PSW	=	0x00d0
                           0000E0   340 _ACC	=	0x00e0
                           0000F0   341 _B	=	0x00f0
                           0000FD   342 _A_INV	=	0x00fd
                           000081   343 _SP	=	0x0081
                           000082   344 _DPL	=	0x0082
                           000083   345 _DPH	=	0x0083
                           0000A1   346 _SAFE_MOD	=	0x00a1
                           0000B1   347 _GLOBAL_CFG	=	0x00b1
                           000087   348 _PCON	=	0x0087
                           0000BA   349 _POWER_CFG	=	0x00ba
                           0000B9   350 _CLOCK_CFG	=	0x00b9
                           0000A9   351 _WAKE_CTRL	=	0x00a9
                           0000FE   352 _RESET_KEEP	=	0x00fe
                           0000FF   353 _WDOG_COUNT	=	0x00ff
                           0000A8   354 _IE	=	0x00a8
                           0000B8   355 _IP	=	0x00b8
                           0000E8   356 _IE_EX	=	0x00e8
                           0000E9   357 _IP_EX	=	0x00e9
                           0000B2   358 _GPIO_IE	=	0x00b2
                           008584   359 _ROM_ADDR	=	0x8584
                           000084   360 _ROM_ADDR_L	=	0x0084
                           000085   361 _ROM_ADDR_H	=	0x0085
                           008F8E   362 _ROM_DATA_HI	=	0x8f8e
                           00008E   363 _ROM_DATA_HL	=	0x008e
                           00008F   364 _ROM_DATA_HH	=	0x008f
                           000086   365 _ROM_CTRL	=	0x0086
                           000080   366 _P0	=	0x0080
                           0000C4   367 _P0_MOD_OC	=	0x00c4
                           0000C5   368 _P0_DIR_PU	=	0x00c5
                           000090   369 _P1	=	0x0090
                           000092   370 _P1_MOD_OC	=	0x0092
                           000093   371 _P1_DIR_PU	=	0x0093
                           0000A0   372 _P2	=	0x00a0
                           000094   373 _P2_MOD_OC	=	0x0094
                           000095   374 _P2_DIR_PU	=	0x0095
                           0000B0   375 _P3	=	0x00b0
                           000096   376 _P3_MOD_OC	=	0x0096
                           000097   377 _P3_DIR_PU	=	0x0097
                           0000C0   378 _P4	=	0x00c0
                           0000C2   379 _P4_MOD_OC	=	0x00c2
                           0000C3   380 _P4_DIR_PU	=	0x00c3
                           0000C1   381 _P4_LED_KEY	=	0x00c1
                           0000AA   382 _P5_IN	=	0x00aa
                           0000AB   383 _P5_OUT_PU	=	0x00ab
                           0000AC   384 _P5_DIR	=	0x00ac
                           0000AD   385 _P6_IN	=	0x00ad
                           0000AE   386 _P6_OUT_PU	=	0x00ae
                           0000AF   387 _P6_DIR	=	0x00af
                           0000F1   388 _P7	=	0x00f1
                           0000A2   389 _XBUS_AUX	=	0x00a2
                           000088   390 _TCON	=	0x0088
                           000089   391 _TMOD	=	0x0089
                           00008A   392 _TL0	=	0x008a
                           00008B   393 _TL1	=	0x008b
                           00008C   394 _TH0	=	0x008c
                           00008D   395 _TH1	=	0x008d
                           000098   396 _SCON	=	0x0098
                           000099   397 _SBUF	=	0x0099
                           0000C8   398 _T2CON	=	0x00c8
                           0000C9   399 _T2MOD	=	0x00c9
                           00CBCA   400 _RCAP2	=	0xcbca
                           0000CA   401 _RCAP2L	=	0x00ca
                           0000CB   402 _RCAP2H	=	0x00cb
                           00CDCC   403 _T2COUNT	=	0xcdcc
                           0000CC   404 _TL2	=	0x00cc
                           0000CD   405 _TH2	=	0x00cd
                           00CFCE   406 _T2CAP1	=	0xcfce
                           0000CE   407 _T2CAP1L	=	0x00ce
                           0000CF   408 _T2CAP1H	=	0x00cf
                           0000F8   409 _SPI0_STAT	=	0x00f8
                           0000F9   410 _SPI0_DATA	=	0x00f9
                           0000FA   411 _SPI0_CTRL	=	0x00fa
                           0000FB   412 _SPI0_CK_SE	=	0x00fb
                           0000FC   413 _SPI0_SETUP	=	0x00fc
                           0000BC   414 _SCON1	=	0x00bc
                           0000BD   415 _SBUF1	=	0x00bd
                           0000BE   416 _SBAUD1	=	0x00be
                           0000BF   417 _SIF1	=	0x00bf
                           0000B4   418 _SPI1_STAT	=	0x00b4
                           0000B5   419 _SPI1_DATA	=	0x00b5
                           0000B6   420 _SPI1_CTRL	=	0x00b6
                           0000B7   421 _SPI1_CK_SE	=	0x00b7
                           0000F3   422 _ADC_CTRL	=	0x00f3
                           00F5F4   423 _ADC_DAT	=	0xf5f4
                           0000F4   424 _ADC_DAT_L	=	0x00f4
                           0000F5   425 _ADC_DAT_H	=	0x00f5
                           0000F6   426 _ADC_CHAN	=	0x00f6
                           0000A6   427 _LED_COMMON	=	0x00a6
                           0000A7   428 _LED_PWM_OE	=	0x00a7
                           00C7C6   429 _LED_DMA	=	0xc7c6
                           0000C6   430 _LED_DMA_L	=	0x00c6
                           0000C7   431 _LED_DMA_H	=	0x00c7
                           0000F7   432 _LED_STATUS	=	0x00f7
                           0000B3   433 _I2CX_INT	=	0x00b3
                           0000BB   434 _I2CS_INT_ST	=	0x00bb
                                    435 ;--------------------------------------------------------
                                    436 ; special function bits
                                    437 ;--------------------------------------------------------
                                    438 	.area RSEG    (ABS,DATA)
      000000                        439 	.org 0x0000
                           0000D7   440 _CY	=	0x00d7
                           0000D6   441 _AC	=	0x00d6
                           0000D5   442 _F0	=	0x00d5
                           0000D4   443 _RS1	=	0x00d4
                           0000D3   444 _RS0	=	0x00d3
                           0000D2   445 _OV	=	0x00d2
                           0000D1   446 _F1	=	0x00d1
                           0000D0   447 _P	=	0x00d0
                           0000AF   448 _EA	=	0x00af
                           0000AE   449 _E_DIS	=	0x00ae
                           0000AD   450 _ET2	=	0x00ad
                           0000AC   451 _ES	=	0x00ac
                           0000AB   452 _ET1	=	0x00ab
                           0000AA   453 _EX1	=	0x00aa
                           0000A9   454 _ET0	=	0x00a9
                           0000A8   455 _EX0	=	0x00a8
                           0000BF   456 _PH_FLAG	=	0x00bf
                           0000BE   457 _PL_FLAG	=	0x00be
                           0000BD   458 _PT2	=	0x00bd
                           0000BC   459 _PS	=	0x00bc
                           0000BB   460 _PT1	=	0x00bb
                           0000BA   461 _PX1	=	0x00ba
                           0000B9   462 _PT0	=	0x00b9
                           0000B8   463 _PX0	=	0x00b8
                           0000EF   464 _IE_WDOG	=	0x00ef
                           0000EE   465 _IE_GPIO	=	0x00ee
                           0000ED   466 _IE_PWM_I2C	=	0x00ed
                           0000EC   467 _IE_UART1	=	0x00ec
                           0000EB   468 _IE_ADC	=	0x00eb
                           0000E9   469 _IE_USB	=	0x00e9
                           0000E8   470 _IE_SPI0	=	0x00e8
                           000087   471 _P0_7	=	0x0087
                           000086   472 _P0_6	=	0x0086
                           000085   473 _P0_5	=	0x0085
                           000084   474 _P0_4	=	0x0084
                           000083   475 _P0_3	=	0x0083
                           000082   476 _P0_2	=	0x0082
                           000081   477 _P0_1	=	0x0081
                           000080   478 _P0_0	=	0x0080
                           000081   479 _SDA0	=	0x0081
                           000080   480 _SCL0	=	0x0080
                           000083   481 _TXD_	=	0x0083
                           000082   482 _RXD_	=	0x0082
                           000085   483 _AIN13	=	0x0085
                           000084   484 _AIN12	=	0x0084
                           000083   485 _AIN11	=	0x0083
                           000082   486 _AIN10	=	0x0082
                           000081   487 _AIN9	=	0x0081
                           000080   488 _AIN8	=	0x0080
                           000097   489 _P1_7	=	0x0097
                           000096   490 _P1_6	=	0x0096
                           000095   491 _P1_5	=	0x0095
                           000094   492 _P1_4	=	0x0094
                           000093   493 _P1_3	=	0x0093
                           000092   494 _P1_2	=	0x0092
                           000091   495 _P1_1	=	0x0091
                           000090   496 _P1_0	=	0x0090
                           000097   497 _TXD1_	=	0x0097
                           000096   498 _RXD1_	=	0x0096
                           000097   499 _SCK	=	0x0097
                           000096   500 _MISO	=	0x0096
                           000095   501 _MOSI	=	0x0095
                           000094   502 _SCS	=	0x0094
                           000092   503 _INT0_	=	0x0092
                           000091   504 _T2EX	=	0x0091
                           000091   505 _CAP2	=	0x0091
                           000090   506 _T2	=	0x0090
                           000090   507 _CAP1	=	0x0090
                           000097   508 _AIN7	=	0x0097
                           000096   509 _AIN6	=	0x0096
                           000095   510 _AIN5	=	0x0095
                           000094   511 _AIN4	=	0x0094
                           000093   512 _AIN3	=	0x0093
                           000092   513 _AIN2	=	0x0092
                           000091   514 _AIN1	=	0x0091
                           000090   515 _AIN0	=	0x0090
                           0000A7   516 _P2_7	=	0x00a7
                           0000A6   517 _P2_6	=	0x00a6
                           0000A5   518 _P2_5	=	0x00a5
                           0000A4   519 _P2_4	=	0x00a4
                           0000A3   520 _P2_3	=	0x00a3
                           0000A2   521 _P2_2	=	0x00a2
                           0000A1   522 _P2_1	=	0x00a1
                           0000A0   523 _P2_0	=	0x00a0
                           0000A7   524 _TXD1	=	0x00a7
                           0000A6   525 _RXD1	=	0x00a6
                           0000A5   526 _T2EX_	=	0x00a5
                           0000A5   527 _CAP2_	=	0x00a5
                           0000A4   528 _T2_	=	0x00a4
                           0000A4   529 _CAP1_	=	0x00a4
                           0000B7   530 _P3_7	=	0x00b7
                           0000B6   531 _P3_6	=	0x00b6
                           0000B5   532 _P3_5	=	0x00b5
                           0000B4   533 _P3_4	=	0x00b4
                           0000B3   534 _P3_3	=	0x00b3
                           0000B2   535 _P3_2	=	0x00b2
                           0000B1   536 _P3_1	=	0x00b1
                           0000B0   537 _P3_0	=	0x00b0
                           0000B7   538 _SCK1	=	0x00b7
                           0000B6   539 _MISO1	=	0x00b6
                           0000B5   540 _MOSI1	=	0x00b5
                           0000B5   541 _T1	=	0x00b5
                           0000B4   542 _T0	=	0x00b4
                           0000B3   543 _INT1	=	0x00b3
                           0000B2   544 _INT0	=	0x00b2
                           0000B1   545 _TXD	=	0x00b1
                           0000B0   546 _RXD	=	0x00b0
                           0000C6   547 _P4_6	=	0x00c6
                           0000C5   548 _P4_5	=	0x00c5
                           0000C4   549 _P4_4	=	0x00c4
                           0000C3   550 _P4_3	=	0x00c3
                           0000C2   551 _P4_2	=	0x00c2
                           0000C1   552 _P4_1	=	0x00c1
                           0000C0   553 _P4_0	=	0x00c0
                           00008F   554 _TF1	=	0x008f
                           00008E   555 _TR1	=	0x008e
                           00008D   556 _TF0	=	0x008d
                           00008C   557 _TR0	=	0x008c
                           00008B   558 _IE1	=	0x008b
                           00008A   559 _IT1	=	0x008a
                           000089   560 _IE0	=	0x0089
                           000088   561 _IT0	=	0x0088
                           00009F   562 _SM0	=	0x009f
                           00009E   563 _SM1	=	0x009e
                           00009D   564 _SM2	=	0x009d
                           00009C   565 _REN	=	0x009c
                           00009B   566 _TB8	=	0x009b
                           00009A   567 _RB8	=	0x009a
                           000099   568 _TI	=	0x0099
                           000098   569 _RI	=	0x0098
                           0000CF   570 _TF2	=	0x00cf
                           0000CF   571 _CAP1F	=	0x00cf
                           0000CE   572 _EXF2	=	0x00ce
                           0000CD   573 _RCLK	=	0x00cd
                           0000CC   574 _TCLK	=	0x00cc
                           0000CB   575 _EXEN2	=	0x00cb
                           0000CA   576 _TR2	=	0x00ca
                           0000C9   577 _C_T2	=	0x00c9
                           0000C8   578 _CP_RL2	=	0x00c8
                           0000FF   579 _S0_FST_ACT	=	0x00ff
                           0000FE   580 _S0_IF_OV	=	0x00fe
                           0000FD   581 _S0_IF_FIRST	=	0x00fd
                           0000FC   582 _S0_IF_BYTE	=	0x00fc
                           0000FB   583 _S0_FREE	=	0x00fb
                           0000FA   584 _S0_T_FIFO	=	0x00fa
                           0000F8   585 _S0_R_FIFO	=	0x00f8
                           0000F7   586 _ADC_START	=	0x00f7
                                    587 ;--------------------------------------------------------
                                    588 ; overlayable register banks
                                    589 ;--------------------------------------------------------
                                    590 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        591 	.ds 8
                                    592 ;--------------------------------------------------------
                                    593 ; internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area DSEG    (DATA)
      000027                        596 _process_record_sloc0_1_0:
      000027                        597 	.ds 1
      000028                        598 _process_action_sloc0_1_0:
      000028                        599 	.ds 1
                                    600 ;--------------------------------------------------------
                                    601 ; overlayable items in internal ram
                                    602 ;--------------------------------------------------------
                                    603 ;--------------------------------------------------------
                                    604 ; indirectly addressable internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area ISEG    (DATA)
                                    607 ;--------------------------------------------------------
                                    608 ; absolute internal ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area IABS    (ABS,DATA)
                                    611 	.area IABS    (ABS,DATA)
                                    612 ;--------------------------------------------------------
                                    613 ; bit data
                                    614 ;--------------------------------------------------------
                                    615 	.area BSEG    (BIT)
      000022                        616 _process_action_sloc1_1_0:
      000022                        617 	.ds 1
                                    618 ;--------------------------------------------------------
                                    619 ; paged external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area PSEG    (PAG,XDATA)
                                    622 ;--------------------------------------------------------
                                    623 ; uninitialized external ram data
                                    624 ;--------------------------------------------------------
                                    625 	.area XSEG    (XDATA)
      000874                        626 _tp_buttons::
      000874                        627 	.ds 2
      000876                        628 _action_exec_PARM_1:
      000876                        629 	.ds 6
      00087C                        630 _action_exec_record_10001_633:
      00087C                        631 	.ds 9
      000885                        632 _ak820_action_exec_event_10000_638:
      000885                        633 	.ds 2
      000887                        634 _ak820_action_exec_snapshot_10000_639:
      000887                        635 	.ds 6
      00088D                        636 _process_record_record_10000_642:
      00088D                        637 	.ds 3
      000890                        638 _process_record_handler_record_argument_10000_651:
      000890                        639 	.ds 3
      000893                        640 _process_record_handler_action_10000_652:
      000893                        641 	.ds 2
      000895                        642 _process_action_PARM_2:
      000895                        643 	.ds 2
      000897                        644 _process_action_record_argument_10000_663:
      000897                        645 	.ds 3
      00089A                        646 _process_action_on_40000_686:
      00089A                        647 	.ds 1
      00089B                        648 _register_code_code_10000_720:
      00089B                        649 	.ds 1
      00089C                        650 _unregister_code_code_10000_734:
      00089C                        651 	.ds 1
      00089D                        652 _tap_code_delay_PARM_2:
      00089D                        653 	.ds 2
      00089F                        654 _tap_code_delay_code_10000_747:
      00089F                        655 	.ds 1
      0008A0                        656 _tap_code_code_10000_754:
      0008A0                        657 	.ds 1
      0008A1                        658 _register_mods_mods_10000_756:
      0008A1                        659 	.ds 1
      0008A2                        660 _unregister_mods_mods_10000_760:
      0008A2                        661 	.ds 1
      0008A3                        662 _register_weak_mods_mods_10000_764:
      0008A3                        663 	.ds 1
      0008A4                        664 _unregister_weak_mods_mods_10000_768:
      0008A4                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000E24                        674 _disable_action_cache::
      000E24                        675 	.ds 1
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT0 (CODE)
                                    678 	.area GSINIT1 (CODE)
                                    679 	.area GSINIT2 (CODE)
                                    680 	.area GSINIT3 (CODE)
                                    681 	.area GSINIT4 (CODE)
                                    682 	.area GSINIT5 (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area CSEG    (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; global & static initialisations
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area GSINIT  (CODE)
                                    691 	.area GSFINAL (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 ;--------------------------------------------------------
                                    694 ; Home
                                    695 ;--------------------------------------------------------
                                    696 	.area HOME    (CODE)
                                    697 	.area HOME    (CODE)
                                    698 ;--------------------------------------------------------
                                    699 ; code
                                    700 ;--------------------------------------------------------
                                    701 	.area CSEG    (CODE)
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    704 ;------------------------------------------------------------
                                    705 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    706 ;------------------------------------------------------------
                                    707 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    708 ;	-----------------------------------------
                           000007   709 	ar7 = 0x07
                           000006   710 	ar6 = 0x06
                           000005   711 	ar5 = 0x05
                           000004   712 	ar4 = 0x04
                           000003   713 	ar3 = 0x03
                           000002   714 	ar2 = 0x02
                           000001   715 	ar1 = 0x01
                           000000   716 	ar0 = 0x00
                                    717 ;	 function action_exec
                                    718 ;	-----------------------------------------
      007595                        719 _action_exec:
                                    720 ;	quantum/action.c:92: ak820_dynamic_macro_task(event.time);
      007595 90 08 78         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007598 12 3A 34         [24]  722 	lcall	_ak820_outline_0005
      00759B 12 3D 66         [24]  723 	lcall	_ak820_dynamic_macro_task
                                    724 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      00759E 90 08 78         [24]  725 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0075A1 12 3A 34         [24]  726 	lcall	_ak820_outline_0005
      0075A4 12 38 4B         [24]  727 	lcall	_ak820_combo_tick
                                    728 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      0075A7 90 08 76         [24]  729 	mov	dptr,#_action_exec_PARM_1
      0075AA 12 49 DF         [24]  730 	lcall	_ak820_tapping_before
      0075AD E5 82            [12]  731 	mov	a, dpl
      0075AF 70 01            [24]  732 	jnz	00102$
      0075B1 22               [24]  733 	ret
      0075B2                        734 00102$:
                                    735 ;	quantum/action.c:100: if (!ak820_autoshift_before(&event)) return;
      0075B2 90 08 76         [24]  736 	mov	dptr,#_action_exec_PARM_1
      0075B5 12 31 2D         [24]  737 	lcall	_ak820_autoshift_before
      0075B8 E5 82            [12]  738 	mov	a, dpl
      0075BA 70 01            [24]  739 	jnz	00104$
      0075BC 22               [24]  740 	ret
      0075BD                        741 00104$:
                                    742 ;	quantum/action.c:116: if (event.pressed) {
      0075BD 90 08 7B         [24]  743 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0075C0 E0               [24]  744 	movx	a,@dptr
      0075C1 60 03            [24]  745 	jz	00106$
                                    746 ;	quantum/action.c:118: clear_weak_mods();
      0075C3 12 86 C7         [24]  747 	lcall	_clear_weak_mods
      0075C6                        748 00106$:
                                    749 ;	quantum/action.c:130: record.event = event;
      0075C6 90 0E 03         [24]  750 	mov	dptr,#___memcpy_PARM_2
      0075C9 74 76            [12]  751 	mov	a,#_action_exec_PARM_1
      0075CB F0               [24]  752 	movx	@dptr,a
      0075CC 74 08            [12]  753 	mov	a,#(_action_exec_PARM_1 >> 8)
      0075CE 12 3A B0         [24]  754 	lcall	_ak820_outline_0094
      0075D1 12 7D 53         [24]  755 	lcall	_ak820_outline_0070
      0075D4 90 08 7C         [24]  756 	mov	dptr,#_action_exec_record_10001_633
      0075D7 F5 F0            [12]  757 	mov	b,a
      0075D9 12 BD 67         [24]  758 	lcall	___memcpy
                                    759 ;	quantum/action.c:132: record.tap.count = 0;
      0075DC 90 08 82         [24]  760 	mov	dptr,#(_action_exec_record_10001_633 + 0x0006)
      0075DF E0               [24]  761 	movx	a,@dptr
      0075E0 54 0F            [12]  762 	anl	a,#0x0f
      0075E2 F0               [24]  763 	movx	@dptr,a
                                    764 ;	quantum/action.c:137: record.keycode = 0;
      0075E3 90 08 83         [24]  765 	mov	dptr,#(_action_exec_record_10001_633 + 0x0007)
      0075E6 12 54 D7         [24]  766 	lcall	_ak820_outline_0181
                                    767 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0075E9 90 08 80         [24]  768 	mov	dptr,#(_action_exec_record_10001_633 + 0x0004)
      0075EC E0               [24]  769 	movx	a,@dptr
      0075ED 60 0D            [24]  770 	jz	00111$
      0075EF 90 08 7C         [24]  771 	mov	dptr,#_action_exec_record_10001_633
      0075F2 75 F0 00         [24]  772 	mov	b, #0x00
      0075F5 12 A4 4E         [24]  773 	lcall	_pre_process_record_quantum
      0075F8 E5 82            [12]  774 	mov	a, dpl
      0075FA 60 1E            [24]  775 	jz	00114$
      0075FC                        776 00111$:
                                    777 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      0075FC 90 08 7C         [24]  778 	mov	dptr,#_action_exec_record_10001_633
      0075FF 12 4A C4         [24]  779 	lcall	_ak820_tapping_process
      007602 E5 82            [12]  780 	mov	a, dpl
      007604 70 01            [24]  781 	jnz	00108$
      007606 22               [24]  782 	ret
      007607                        783 00108$:
                                    784 ;	quantum/action.c:172: if (!ak820_autoshift_process(&record)) return;
      007607 90 08 7C         [24]  785 	mov	dptr,#_action_exec_record_10001_633
      00760A 12 32 35         [24]  786 	lcall	_ak820_autoshift_process
      00760D E5 82            [12]  787 	mov	a, dpl
      00760F 70 01            [24]  788 	jnz	00110$
      007611 22               [24]  789 	ret
      007612                        790 00110$:
                                    791 ;	quantum/action.c:175: process_record(&record);
      007612 90 08 7C         [24]  792 	mov	dptr,#_action_exec_record_10001_633
      007615 75 F0 00         [24]  793 	mov	b, #0x00
                                    794 ;	quantum/action.c:190: }
      007618 C1 56            [12]  795 	ajmp	_process_record
      00761A                        796 00114$:
      00761A 22               [24]  797 	ret
                                    798 ;------------------------------------------------------------
                                    799 ;Allocation info for local variables in function 'ak820_action_exec'
                                    800 ;------------------------------------------------------------
                                    801 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    802 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    803 ;------------------------------------------------------------
                                    804 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    805 ;	-----------------------------------------
                                    806 ;	 function ak820_action_exec
                                    807 ;	-----------------------------------------
      00761B                        808 _ak820_action_exec:
      00761B 12 3A C2         [24]  809 	lcall	_ak820_outline_0108
      00761E 90 08 85         [24]  810 	mov	dptr,#_ak820_action_exec_event_10000_638
      007621 12 3A C7         [24]  811 	lcall	_ak820_outline_0109
                                    812 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      007624 90 08 85         [24]  813 	mov	dptr,#_ak820_action_exec_event_10000_638
      007627 12 3A A4         [24]  814 	lcall	_ak820_outline_0079
      00762A 7F 00            [12]  815 	mov	r7,#0x00
      00762C 90 0E 03         [24]  816 	mov	dptr,#___memcpy_PARM_2
      00762F ED               [12]  817 	mov	a,r5
      007630 12 3A 69         [24]  818 	lcall	_ak820_outline_0017
      007633 12 7D 53         [24]  819 	lcall	_ak820_outline_0070
      007636 90 08 87         [24]  820 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      007639 F5 F0            [12]  821 	mov	b,a
      00763B 12 BD 67         [24]  822 	lcall	___memcpy
                                    823 ;	quantum/action.c:197: action_exec(snapshot);
      00763E 90 0E 03         [24]  824 	mov	dptr,#___memcpy_PARM_2
      007641 74 87            [12]  825 	mov	a,#_ak820_action_exec_snapshot_10000_639
      007643 F0               [24]  826 	movx	@dptr,a
      007644 74 08            [12]  827 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      007646 12 3A B0         [24]  828 	lcall	_ak820_outline_0094
      007649 12 7D 53         [24]  829 	lcall	_ak820_outline_0070
      00764C 90 08 76         [24]  830 	mov	dptr,#_action_exec_PARM_1
      00764F F5 F0            [12]  831 	mov	b,a
      007651 12 BD 67         [24]  832 	lcall	___memcpy
                                    833 ;	quantum/action.c:198: }
      007654 A1 95            [12]  834 	ajmp	_action_exec
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'process_record_nocache'
                                    837 ;------------------------------------------------------------
                                    838 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    839 ;------------------------------------------------------------
                                    840 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    841 ;	-----------------------------------------
                                    842 ;	 function process_record
                                    843 ;	-----------------------------------------
      007656                        844 _process_record:
      007656 12 48 A0         [24]  845 	lcall	_ak820_outline_0037
      007659 90 08 8D         [24]  846 	mov	dptr,#_process_record_record_10000_642
      00765C 12 3A 69         [24]  847 	lcall	_ak820_outline_0017
                                    848 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      00765F 90 08 8D         [24]  849 	mov	dptr,#_process_record_record_10000_642
      007662 12 54 84         [24]  850 	lcall	_ak820_outline_0013
      007665 74 04            [12]  851 	mov	a,#0x04
      007667 12 7D 0F         [24]  852 	lcall	_ak820_outline_0006
      00766A 12 BE 40         [24]  853 	lcall	__gptrget
      00766D 70 01            [24]  854 	jnz	00102$
                                    855 ;	quantum/action.c:338: return;
      00766F 22               [24]  856 	ret
      007670                        857 00102$:
                                    858 ;	quantum/action.c:342: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      007670 74 01            [12]  859 	mov	a,#0x01
      007672 12 7D 0F         [24]  860 	lcall	_ak820_outline_0006
      007675 12 BE 40         [24]  861 	lcall	__gptrget
      007678 FA               [12]  862 	mov	r2,a
      007679 BA 10 00         [24]  863 	cjne	r2,#0x10,00192$
      00767C                        864 00192$:
      00767C 50 4B            [24]  865 	jnc	00104$
      00767E 8D 02            [24]  866 	mov	ar2,r5
      007680 8E 03            [24]  867 	mov	ar3,r6
      007682 8F 04            [24]  868 	mov	ar4,r7
      007684 12 3A EC         [24]  869 	lcall	_ak820_outline_0143
      007687 8C F0            [24]  870 	mov	b,r4
      007689 12 BE 40         [24]  871 	lcall	__gptrget
      00768C FA               [12]  872 	mov	r2,a
      00768D BA 08 00         [24]  873 	cjne	r2,#0x08,00194$
      007690                        874 00194$:
      007690 50 37            [24]  875 	jnc	00104$
      007692 90 09 E9         [24]  876 	mov	dptr,#_ak820_macro_primitive
      007695 E0               [24]  877 	movx	a,@dptr
      007696 70 31            [24]  878 	jnz	00104$
                                    879 ;	quantum/action.c:343: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007698 90 0C 5A         [24]  880 	mov	dptr,#_get_record_keycode_PARM_2
      00769B 74 01            [12]  881 	mov	a,#0x01
      00769D 12 54 8D         [24]  882 	lcall	_ak820_outline_0031
      0076A0 12 A4 10         [24]  883 	lcall	_get_record_keycode
      0076A3 12 48 E9         [24]  884 	lcall	_ak820_outline_0125
      0076A6 90 08 8D         [24]  885 	mov	dptr,#_process_record_record_10000_642
      0076A9 12 7D 3A         [24]  886 	lcall	_ak820_outline_0024
      0076AC 74 05            [12]  887 	mov	a,#0x05
      0076AE 2B               [12]  888 	add	a, r3
      0076AF FB               [12]  889 	mov	r3,a
      0076B0 E4               [12]  890 	clr	a
      0076B1 3C               [12]  891 	addc	a, r4
      0076B2 FC               [12]  892 	mov	r4,a
      0076B3 12 36 47         [24]  893 	lcall	_ak820_outline_0121
      0076B6 8D F0            [24]  894 	mov	b,r5
      0076B8 12 BE 40         [24]  895 	lcall	__gptrget
      0076BB 90 04 BE         [24]  896 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0076BE 12 48 CB         [24]  897 	lcall	_ak820_outline_0071
      0076C1 12 3B BD         [24]  898 	lcall	_ak820_dynamic_macro_process
      0076C4 E5 82            [12]  899 	mov	a, dpl
      0076C6 70 01            [24]  900 	jnz	00104$
      0076C8 22               [24]  901 	ret
      0076C9                        902 00104$:
                                    903 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0076C9 90 08 8D         [24]  904 	mov	dptr,#_process_record_record_10000_642
      0076CC 12 54 84         [24]  905 	lcall	_ak820_outline_0013
      0076CF 8D 02            [24]  906 	mov	ar2,r5
      0076D1 8E 03            [24]  907 	mov	ar3,r6
      0076D3 8F 04            [24]  908 	mov	ar4,r7
      0076D5 90 0E 03         [24]  909 	mov	dptr,#___memcpy_PARM_2
      0076D8 EA               [12]  910 	mov	a,r2
      0076D9 12 7D 9E         [24]  911 	lcall	_ak820_outline_0186
      0076DC EC               [12]  912 	mov	a,r4
      0076DD A3               [24]  913 	inc	dptr
      0076DE F0               [24]  914 	movx	@dptr,a
      0076DF 90 0E 06         [24]  915 	mov	dptr,#___memcpy_PARM_3
      0076E2 12 54 C9         [24]  916 	lcall	_ak820_outline_0111
      0076E5 90 06 8A         [24]  917 	mov	dptr,#_ak820_tapping_source_PARM_1
      0076E8 F5 F0            [12]  918 	mov	b,a
      0076EA C0 07            [24]  919 	push	ar7
      0076EC C0 06            [24]  920 	push	ar6
      0076EE C0 05            [24]  921 	push	ar5
      0076F0 12 BD 67         [24]  922 	lcall	___memcpy
      0076F3 12 49 1A         [24]  923 	lcall	_ak820_tapping_source
      0076F6 AC 82            [24]  924 	mov	r4, dpl
      0076F8 D0 05            [24]  925 	pop	ar5
      0076FA D0 06            [24]  926 	pop	ar6
      0076FC D0 07            [24]  927 	pop	ar7
                                    928 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0076FE 74 05            [12]  929 	mov	a,#0x05
      007700 12 7D 1D         [24]  930 	lcall	_ak820_outline_0014
      007703 12 BE 40         [24]  931 	lcall	__gptrget
      007706 FB               [12]  932 	mov	r3,a
                                    933 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007707 74 07            [12]  934 	mov	a,#0x07
      007709 2D               [12]  935 	add	a, r5
      00770A F8               [12]  936 	mov	r0,a
      00770B E4               [12]  937 	clr	a
      00770C 3E               [12]  938 	addc	a, r6
      00770D F9               [12]  939 	mov	r1,a
      00770E 8F 02            [24]  940 	mov	ar2,r7
      007710 90 0C 5A         [24]  941 	mov	dptr,#_get_record_keycode_PARM_2
      007713 74 01            [12]  942 	mov	a,#0x01
      007715 12 54 8D         [24]  943 	lcall	_ak820_outline_0031
      007718 C0 04            [24]  944 	push	ar4
      00771A C0 03            [24]  945 	push	ar3
      00771C C0 02            [24]  946 	push	ar2
      00771E C0 01            [24]  947 	push	ar1
      007720 C0 00            [24]  948 	push	ar0
      007722 12 A4 10         [24]  949 	lcall	_get_record_keycode
      007725 12 48 E9         [24]  950 	lcall	_ak820_outline_0125
      007728 D0 00            [24]  951 	pop	ar0
      00772A D0 01            [24]  952 	pop	ar1
      00772C D0 02            [24]  953 	pop	ar2
      00772E D0 03            [24]  954 	pop	ar3
      007730 D0 04            [24]  955 	pop	ar4
      007732 12 3A F1         [24]  956 	lcall	_ak820_outline_0144
      007735 8A F0            [24]  957 	mov	b,r2
      007737 EE               [12]  958 	mov	a,r6
      007738 12 BE 05         [24]  959 	lcall	__gptrput
      00773B A3               [24]  960 	inc	dptr
      00773C EF               [12]  961 	mov	a,r7
      00773D 12 BE 05         [24]  962 	lcall	__gptrput
                                    963 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007740 90 08 8D         [24]  964 	mov	dptr,#_process_record_record_10000_642
      007743 12 54 84         [24]  965 	lcall	_ak820_outline_0013
      007746 74 07            [12]  966 	mov	a,#0x07
      007748 12 7D 64         [24]  967 	lcall	_ak820_outline_0081
      00774B 12 BE 40         [24]  968 	lcall	__gptrget
      00774E F8               [12]  969 	mov	r0,a
      00774F A3               [24]  970 	inc	dptr
      007750 12 BE 40         [24]  971 	lcall	__gptrget
      007753 F9               [12]  972 	mov	r1,a
      007754 90 06 9A         [24]  973 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007757 EC               [12]  974 	mov	a,r4
      007758 F0               [24]  975 	movx	@dptr,a
      007759 90 06 9B         [24]  976 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00775C EB               [12]  977 	mov	a,r3
      00775D F0               [24]  978 	movx	@dptr,a
      00775E 12 3A F1         [24]  979 	lcall	_ak820_outline_0144
      007761 C0 07            [24]  980 	push	ar7
      007763 C0 06            [24]  981 	push	ar6
      007765 C0 05            [24]  982 	push	ar5
      007767 C0 04            [24]  983 	push	ar4
      007769 C0 03            [24]  984 	push	ar3
      00776B 12 4C 74         [24]  985 	lcall	_ak820_oneshot_process
      00776E E5 82            [12]  986 	mov	a, dpl
      007770 D0 03            [24]  987 	pop	ar3
      007772 D0 04            [24]  988 	pop	ar4
      007774 D0 05            [24]  989 	pop	ar5
      007776 D0 06            [24]  990 	pop	ar6
      007778 D0 07            [24]  991 	pop	ar7
      00777A 70 01            [24]  992 	jnz	00109$
      00777C 22               [24]  993 	ret
      00777D                        994 00109$:
                                    995 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      00777D 12 72 FC         [24]  996 	lcall	_ak820_outline_0050
      007780 C0 04            [24]  997 	push	ar4
      007782 C0 03            [24]  998 	push	ar3
      007784 12 A4 D6         [24]  999 	lcall	_process_record_quantum
      007787 E5 82            [12] 1000 	mov	a, dpl
      007789 D0 03            [24] 1001 	pop	ar3
      00778B D0 04            [24] 1002 	pop	ar4
      00778D 70 0A            [24] 1003 	jnz	00111$
                                   1004 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00778F 90 06 02         [24] 1005 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007792 EB               [12] 1006 	mov	a,r3
      007793 F0               [24] 1007 	movx	@dptr,a
      007794 8C 82            [24] 1008 	mov	dpl, r4
                                   1009 ;	quantum/action.c:360: return;
      007796 02 2E BB         [24] 1010 	ljmp	_ak820_oneshot_post
      007799                       1011 00111$:
                                   1012 ;	quantum/action.c:364: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      007799 90 08 8D         [24] 1013 	mov	dptr,#_process_record_record_10000_642
      00779C 12 54 84         [24] 1014 	lcall	_ak820_outline_0013
      00779F 74 01            [12] 1015 	mov	a,#0x01
      0077A1 12 7D 64         [24] 1016 	lcall	_ak820_outline_0081
      0077A4 12 BE 40         [24] 1017 	lcall	__gptrget
      0077A7 F8               [12] 1018 	mov	r0,a
      0077A8 B8 10 00         [24] 1019 	cjne	r0,#0x10,00200$
      0077AB                       1020 00200$:
      0077AB 50 21            [24] 1021 	jnc	00114$
      0077AD 12 72 FC         [24] 1022 	lcall	_ak820_outline_0050
      0077B0 12 BE 40         [24] 1023 	lcall	__gptrget
      0077B3 FD               [12] 1024 	mov	r5,a
      0077B4 BD 08 00         [24] 1025 	cjne	r5,#0x08,00202$
      0077B7                       1026 00202$:
      0077B7 50 15            [24] 1027 	jnc	00114$
      0077B9 C0 04            [24] 1028 	push	ar4
      0077BB C0 03            [24] 1029 	push	ar3
      0077BD 12 A7 76         [24] 1030 	lcall	_get_repeat_key_count
      0077C0 E5 82            [12] 1031 	mov	a, dpl
      0077C2 D0 03            [24] 1032 	pop	ar3
      0077C4 D0 04            [24] 1033 	pop	ar4
      0077C6 70 06            [24] 1034 	jnz	00114$
      0077C8 90 09 E9         [24] 1035 	mov	dptr,#_ak820_macro_primitive
      0077CB E0               [24] 1036 	movx	a,@dptr
      0077CC 60 05            [24] 1037 	jz	00115$
      0077CE                       1038 00114$:
      0077CE 75 27 00         [24] 1039 	mov	_process_record_sloc0_1_0,#0x00
      0077D1 80 03            [24] 1040 	sjmp	00116$
      0077D3                       1041 00115$:
      0077D3 75 27 01         [24] 1042 	mov	_process_record_sloc0_1_0,#0x01
      0077D6                       1043 00116$:
      0077D6 90 04 BD         [24] 1044 	mov	dptr,#_ak820_dynamic_macro_source
      0077D9 E5 27            [12] 1045 	mov	a,_process_record_sloc0_1_0
      0077DB F0               [24] 1046 	movx	@dptr,a
                                   1047 ;	quantum/action.c:366: process_record_handler(record);
      0077DC 90 08 8D         [24] 1048 	mov	dptr,#_process_record_record_10000_642
      0077DF 12 54 5E         [24] 1049 	lcall	_ak820_outline_0001
      0077E2 C0 04            [24] 1050 	push	ar4
      0077E4 C0 03            [24] 1051 	push	ar3
      0077E6 12 78 05         [24] 1052 	lcall	_process_record_handler
                                   1053 ;	quantum/action.c:368: ak820_dynamic_macro_source = false;
      0077E9 90 04 BD         [24] 1054 	mov	dptr,#_ak820_dynamic_macro_source
      0077EC E4               [12] 1055 	clr	a
      0077ED F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	quantum/action.c:370: post_process_record_quantum(record);
      0077EE 90 08 8D         [24] 1058 	mov	dptr,#_process_record_record_10000_642
      0077F1 12 54 5E         [24] 1059 	lcall	_ak820_outline_0001
      0077F4 12 A4 AD         [24] 1060 	lcall	_post_process_record_quantum
      0077F7 D0 03            [24] 1061 	pop	ar3
      0077F9 D0 04            [24] 1062 	pop	ar4
                                   1063 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0077FB 90 06 02         [24] 1064 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0077FE EB               [12] 1065 	mov	a,r3
      0077FF F0               [24] 1066 	movx	@dptr,a
      007800 8C 82            [24] 1067 	mov	dpl, r4
                                   1068 ;	quantum/action.c:374: }
      007802 02 2E BB         [24] 1069 	ljmp	_ak820_oneshot_post
                                   1070 ;------------------------------------------------------------
                                   1071 ;Allocation info for local variables in function 'process_record_handler'
                                   1072 ;------------------------------------------------------------
                                   1073 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_651'
                                   1074 ;record        Allocated with name '_process_record_handler_record_10000_652'
                                   1075 ;action        Allocated with name '_process_record_handler_action_10000_652'
                                   1076 ;------------------------------------------------------------
                                   1077 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                   1078 ;	-----------------------------------------
                                   1079 ;	 function process_record_handler
                                   1080 ;	-----------------------------------------
      007805                       1081 _process_record_handler:
      007805 12 48 A0         [24] 1082 	lcall	_ak820_outline_0037
      007808 90 08 90         [24] 1083 	mov	dptr,#_process_record_handler_record_argument_10000_651
      00780B 12 3A 69         [24] 1084 	lcall	_ak820_outline_0017
                                   1085 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00780E 90 08 90         [24] 1086 	mov	dptr,#_process_record_handler_record_argument_10000_651
      007811 12 3A 3E         [24] 1087 	lcall	_ak820_outline_0008
                                   1088 ;	quantum/action.c:387: if (record->keycode) {
      007814 4C               [12] 1089 	orl	a,r4
      007815 60 19            [24] 1090 	jz	00102$
                                   1091 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      007817 12 3A D7         [24] 1092 	lcall	_ak820_outline_0124
      00781A C0 07            [24] 1093 	push	ar7
      00781C C0 06            [24] 1094 	push	ar6
      00781E 12 9A 6A         [24] 1095 	lcall	_action_for_keycode
      007821 12 48 FA         [24] 1096 	lcall	_ak820_outline_0149
      007824 D0 06            [24] 1097 	pop	ar6
      007826 D0 07            [24] 1098 	pop	ar7
      007828 90 08 93         [24] 1099 	mov	dptr,#_process_record_handler_action_10000_652
      00782B 12 3A 9E         [24] 1100 	lcall	_ak820_outline_0072
      00782E 80 2B            [24] 1101 	sjmp	00104$
      007830                       1102 00102$:
                                   1103 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007830 12 7D 2B         [24] 1104 	lcall	_ak820_outline_0021
      007833 7A 00            [12] 1105 	mov	r2,#0x00
      007835 12 48 F4         [24] 1106 	lcall	_ak820_outline_0142
      007838 12 48 8E         [24] 1107 	lcall	_ak820_outline_0012
      00783B E0               [24] 1108 	movx	a,@dptr
      00783C 90 09 CF         [24] 1109 	mov	dptr,#_ak820_resolve_key_PARM_2
      00783F F0               [24] 1110 	movx	@dptr,a
      007840 8D 82            [24] 1111 	mov	dpl, r5
      007842 8C 83            [24] 1112 	mov	dph, r4
      007844 C0 07            [24] 1113 	push	ar7
      007846 C0 06            [24] 1114 	push	ar6
      007848 12 80 D0         [24] 1115 	lcall	_ak820_resolve_key
      00784B 12 9A 6A         [24] 1116 	lcall	_action_for_keycode
      00784E 12 48 FA         [24] 1117 	lcall	_ak820_outline_0149
      007851 D0 06            [24] 1118 	pop	ar6
      007853 D0 07            [24] 1119 	pop	ar7
      007855 90 08 93         [24] 1120 	mov	dptr,#_process_record_handler_action_10000_652
      007858 12 3A 9E         [24] 1121 	lcall	_ak820_outline_0072
                                   1122 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      00785B                       1123 00104$:
                                   1124 ;	quantum/action.c:411: process_action(record, action);
      00785B 7D 00            [12] 1125 	mov	r5,#0x00
      00785D 90 0E 03         [24] 1126 	mov	dptr,#___memcpy_PARM_2
      007860 74 93            [12] 1127 	mov	a,#_process_record_handler_action_10000_652
      007862 F0               [24] 1128 	movx	@dptr,a
      007863 74 08            [12] 1129 	mov	a,#(_process_record_handler_action_10000_652 >> 8)
      007865 12 3A B0         [24] 1130 	lcall	_ak820_outline_0094
      007868 90 0E 06         [24] 1131 	mov	dptr,#___memcpy_PARM_3
      00786B 12 54 C9         [24] 1132 	lcall	_ak820_outline_0111
      00786E 90 08 95         [24] 1133 	mov	dptr,#_process_action_PARM_2
      007871 F5 F0            [12] 1134 	mov	b,a
      007873 C0 07            [24] 1135 	push	ar7
      007875 C0 06            [24] 1136 	push	ar6
      007877 C0 05            [24] 1137 	push	ar5
      007879 12 BD 67         [24] 1138 	lcall	___memcpy
      00787C D0 05            [24] 1139 	pop	ar5
      00787E D0 06            [24] 1140 	pop	ar6
      007880 D0 07            [24] 1141 	pop	ar7
      007882 12 75 0D         [24] 1142 	lcall	_ak820_outline_0064
                                   1143 ;	quantum/action.c:412: }
      007885 01 87            [24] 1144 	ajmp	_process_action
                                   1145 ;------------------------------------------------------------
                                   1146 ;Allocation info for local variables in function 'register_mouse'
                                   1147 ;------------------------------------------------------------
                                   1148 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1149 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_660'
                                   1150 ;------------------------------------------------------------
                                   1151 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1152 ;	-----------------------------------------
                                   1153 ;	 function process_action
                                   1154 ;	-----------------------------------------
      007887                       1155 _process_action:
      007887 12 48 A0         [24] 1156 	lcall	_ak820_outline_0037
      00788A 90 08 97         [24] 1157 	mov	dptr,#_process_action_record_argument_10000_663
      00788D 12 3A 69         [24] 1158 	lcall	_ak820_outline_0017
                                   1159 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007890 90 08 97         [24] 1160 	mov	dptr,#_process_action_record_argument_10000_663
      007893 12 3A 34         [24] 1161 	lcall	_ak820_outline_0005
                                   1162 ;	quantum/action.c:483: pressed = record->event.pressed;
      007896 A3               [24] 1163 	inc	dptr
      007897 A3               [24] 1164 	inc	dptr
      007898 A3               [24] 1165 	inc	dptr
      007899 A3               [24] 1166 	inc	dptr
      00789A A3               [24] 1167 	inc	dptr
      00789B E0               [24] 1168 	movx	a,@dptr
      00789C F5 28            [12] 1169 	mov	_process_action_sloc0_1_0,a
                                   1170 ;	quantum/action.c:507: switch (action.kind.id) {
      00789E 90 08 96         [24] 1171 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078A1 E0               [24] 1172 	movx	a,@dptr
      0078A2 C4               [12] 1173 	swap	a
      0078A3 54 0F            [12] 1174 	anl	a,#0x0f
      0078A5 FD               [12] 1175 	mov  r5,a
      0078A6 24 F4            [12] 1176 	add	a,#0xff - 0x0b
      0078A8 50 03            [24] 1177 	jnc	00434$
      0078AA 02 7B 28         [24] 1178 	ljmp	00181$
      0078AD                       1179 00434$:
                                   1180 ;	free result
      0078AD ED               [12] 1181 	mov	a,r5
      0078AE 24 0A            [12] 1182 	add	a,#(00435$-3-.)
      0078B0 83               [24] 1183 	movc	a,@a+pc
      0078B1 F5 82            [12] 1184 	mov	dpl,a
      0078B3 ED               [12] 1185 	mov	a,r5
      0078B4 24 10            [12] 1186 	add	a,#(00436$-3-.)
      0078B6 83               [24] 1187 	movc	a,@a+pc
      0078B7 F5 83            [12] 1188 	mov	dph,a
      0078B9 E4               [12] 1189 	clr	a
      0078BA 73               [24] 1190 	jmp	@a+dptr
      0078BB                       1191 00435$:
      0078BB D3                    1192 	.db	00102$
      0078BC D3                    1193 	.db	00102$
      0078BD 28                    1194 	.db	00181$
      0078BE 28                    1195 	.db	00181$
      0078BF 5D                    1196 	.db	00123$
      0078C0 28                    1197 	.db	00181$
      0078C1 28                    1198 	.db	00181$
      0078C2 28                    1199 	.db	00181$
      0078C3 BD                    1200 	.db	00131$
      0078C4 8F                    1201 	.db	00147$
      0078C5 B5                    1202 	.db	00152$
      0078C6 B5                    1203 	.db	00152$
      0078C7                       1204 00436$:
      0078C7 78                    1205 	.db	00102$>>8
      0078C8 78                    1206 	.db	00102$>>8
      0078C9 7B                    1207 	.db	00181$>>8
      0078CA 7B                    1208 	.db	00181$>>8
      0078CB 79                    1209 	.db	00123$>>8
      0078CC 7B                    1210 	.db	00181$>>8
      0078CD 7B                    1211 	.db	00181$>>8
      0078CE 7B                    1212 	.db	00181$>>8
      0078CF 79                    1213 	.db	00131$>>8
      0078D0 7A                    1214 	.db	00147$>>8
      0078D1 7A                    1215 	.db	00152$>>8
      0078D2 7A                    1216 	.db	00152$>>8
                                   1217 ;	quantum/action.c:510: case ACT_RMODS: {
      0078D3                       1218 00102$:
                                   1219 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0078D3 90 08 96         [24] 1220 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078D6 E0               [24] 1221 	movx	a,@dptr
      0078D7 54 F0            [12] 1222 	anl	a,#0xf0
      0078D9 70 06            [24] 1223 	jnz	00194$
      0078DB 12 7D 7B         [24] 1224 	lcall	_ak820_outline_0113
      0078DE FD               [12] 1225 	mov	r5,a
      0078DF 80 07            [24] 1226 	sjmp	00195$
      0078E1                       1227 00194$:
      0078E1 12 7D 7B         [24] 1228 	lcall	_ak820_outline_0113
      0078E4 C4               [12] 1229 	swap	a
      0078E5 54 F0            [12] 1230 	anl	a,#0xf0
      0078E7 FD               [12] 1231 	mov	r5,a
      0078E8                       1232 00195$:
                                   1233 ;	quantum/action.c:513: if (pressed) {
      0078E8 E5 28            [12] 1234 	mov	a,_process_action_sloc0_1_0
      0078EA 60 35            [24] 1235 	jz	00119$
                                   1236 ;	quantum/action.c:514: if (mods) {
      0078EC ED               [12] 1237 	mov	a,r5
      0078ED 60 29            [24] 1238 	jz	00110$
                                   1239 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0078EF 12 7D 8D         [24] 1240 	lcall	_ak820_outline_0158
      0078F2 FC               [12] 1241 	mov	r4,a
      0078F3 BC E0 00         [24] 1242 	cjne	r4,#0xe0,00440$
      0078F6                       1243 00440$:
      0078F6 40 07            [24] 1244 	jc	00108$
      0078F8 12 7D 8D         [24] 1245 	lcall	_ak820_outline_0158
      0078FB 24 18            [12] 1246 	add	a,#0xff - 0xe7
      0078FD 50 0A            [24] 1247 	jnc	00104$
                                   1248 ;	free result
      0078FF                       1249 00108$:
      0078FF 7B 95            [12] 1250 	mov	r3,#_process_action_PARM_2
      007901 7C 08            [12] 1251 	mov	r4,#(_process_action_PARM_2 >> 8)
      007903 12 36 47         [24] 1252 	lcall	_ak820_outline_0121
      007906 E0               [24] 1253 	movx	a,@dptr
      007907 70 07            [24] 1254 	jnz	00105$
      007909                       1255 00104$:
                                   1256 ;	quantum/action.c:519: add_owned_mods(mods);
      007909 8D 82            [24] 1257 	mov	dpl, r5
      00790B 12 82 E6         [24] 1258 	lcall	_add_owned_mods
      00790E 80 05            [24] 1259 	sjmp	00106$
      007910                       1260 00105$:
                                   1261 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      007910 8D 82            [24] 1262 	mov	dpl, r5
      007912 12 83 02         [24] 1263 	lcall	_add_owned_weak_mods
      007915                       1264 00106$:
                                   1265 ;	quantum/action.c:523: send_keyboard_report();
      007915 12 86 17         [24] 1266 	lcall	_send_keyboard_report
      007918                       1267 00110$:
                                   1268 ;	quantum/action.c:525: register_code(action.key.code);
      007918 12 7D 5D         [24] 1269 	lcall	_ak820_outline_0078
      00791B 12 7B 3F         [24] 1270 	lcall	_register_code
      00791E 02 7B 28         [24] 1271 	ljmp	00181$
      007921                       1272 00119$:
                                   1273 ;	quantum/action.c:527: unregister_code(action.key.code);
      007921 12 7D 5D         [24] 1274 	lcall	_ak820_outline_0078
      007924 C0 05            [24] 1275 	push	ar5
      007926 12 7B BB         [24] 1276 	lcall	_unregister_code
      007929 D0 05            [24] 1277 	pop	ar5
                                   1278 ;	quantum/action.c:528: if (mods) {
      00792B ED               [12] 1279 	mov	a,r5
      00792C 70 03            [24] 1280 	jnz	00444$
      00792E 02 7B 28         [24] 1281 	ljmp	00181$
      007931                       1282 00444$:
                                   1283 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007931 12 7D 8D         [24] 1284 	lcall	_ak820_outline_0158
      007934 FC               [12] 1285 	mov	r4,a
      007935 BC E0 00         [24] 1286 	cjne	r4,#0xe0,00445$
      007938                       1287 00445$:
      007938 40 07            [24] 1288 	jc	00115$
      00793A 12 7D 8D         [24] 1289 	lcall	_ak820_outline_0158
      00793D 24 18            [12] 1290 	add	a,#0xff - 0xe7
      00793F 50 0A            [24] 1291 	jnc	00111$
                                   1292 ;	free result
      007941                       1293 00115$:
      007941 7B 95            [12] 1294 	mov	r3,#_process_action_PARM_2
      007943 7C 08            [12] 1295 	mov	r4,#(_process_action_PARM_2 >> 8)
      007945 12 36 47         [24] 1296 	lcall	_ak820_outline_0121
      007948 E0               [24] 1297 	movx	a,@dptr
      007949 70 07            [24] 1298 	jnz	00112$
      00794B                       1299 00111$:
                                   1300 ;	quantum/action.c:530: del_owned_mods(mods);
      00794B 8D 82            [24] 1301 	mov	dpl, r5
      00794D 12 82 F5         [24] 1302 	lcall	_del_owned_mods
      007950 80 05            [24] 1303 	sjmp	00113$
      007952                       1304 00112$:
                                   1305 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      007952 8D 82            [24] 1306 	mov	dpl, r5
      007954 12 83 11         [24] 1307 	lcall	_del_owned_weak_mods
      007957                       1308 00113$:
                                   1309 ;	quantum/action.c:534: send_keyboard_report();
      007957 12 86 17         [24] 1310 	lcall	_send_keyboard_report
                                   1311 ;	quantum/action.c:537: } break;
      00795A 02 7B 28         [24] 1312 	ljmp	00181$
                                   1313 ;	quantum/action.c:614: case ACT_USAGE:
      00795D                       1314 00123$:
                                   1315 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00795D 74 07            [12] 1316 	mov	a,#0x07
      00795F 12 3A 71         [24] 1317 	lcall	_ak820_outline_0022
      007962 12 4D AC         [24] 1318 	lcall	_ak820_outline_0009
      007965 C3               [12] 1319 	clr	c
      007966 EC               [12] 1320 	mov	a,r4
      007967 94 A5            [12] 1321 	subb	a,#0xa5
      007969 ED               [12] 1322 	mov	a,r5
      00796A 94 00            [12] 1323 	subb	a,#0x00
      00796C 40 15            [24] 1324 	jc	00125$
      00796E 74 C2            [12] 1325 	mov	a,#0xc2
      007970 9C               [12] 1326 	subb	a,r4
      007971 E4               [12] 1327 	clr	a
      007972 9D               [12] 1328 	subb	a,r5
      007973 40 0E            [24] 1329 	jc	00125$
                                   1330 ;	free result
                                   1331 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007975 90 0A F6         [24] 1332 	mov	dptr,#_owned_usage_key_PARM_2
      007978 E5 28            [12] 1333 	mov	a,_process_action_sloc0_1_0
      00797A F0               [24] 1334 	movx	@dptr,a
      00797B 8E 82            [24] 1335 	mov	dpl, r6
      00797D 12 84 C4         [24] 1336 	lcall	_owned_usage_key
                                   1337 ;	quantum/action.c:622: break;
      007980 02 7B 28         [24] 1338 	ljmp	00181$
      007983                       1339 00125$:
                                   1340 ;	quantum/action.c:625: switch (action.usage.page) {
      007983 12 7D 72         [24] 1341 	lcall	_ak820_outline_0090
      007986 FF               [12] 1342 	mov	r7,a
      007987 60 08            [24] 1343 	jz	00127$
      007989 BF 01 02         [24] 1344 	cjne	r7,#0x01,00452$
      00798C 80 19            [24] 1345 	sjmp	00128$
      00798E                       1346 00452$:
      00798E 02 7B 28         [24] 1347 	ljmp	00181$
                                   1348 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007991                       1349 00127$:
                                   1350 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007991 E5 28            [12] 1351 	mov	a,_process_action_sloc0_1_0
      007993 60 05            [24] 1352 	jz	00196$
      007995 12 7D 82         [24] 1353 	lcall	_ak820_outline_0131
      007998 80 04            [24] 1354 	sjmp	00197$
      00799A                       1355 00196$:
      00799A 7E 00            [12] 1356 	mov	r6,#0x00
      00799C 7F 00            [12] 1357 	mov	r7,#0x00
      00799E                       1358 00197$:
      00799E 12 3A CC         [24] 1359 	lcall	_ak820_outline_0118
      0079A1 12 72 88         [24] 1360 	lcall	_host_system_send
                                   1361 ;	quantum/action.c:628: break;
      0079A4 02 7B 28         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:629: case PAGE_CONSUMER:
      0079A7                       1364 00128$:
                                   1365 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      0079A7 E5 28            [12] 1366 	mov	a,_process_action_sloc0_1_0
      0079A9 60 05            [24] 1367 	jz	00198$
      0079AB 12 7D 82         [24] 1368 	lcall	_ak820_outline_0131
      0079AE 80 04            [24] 1369 	sjmp	00199$
      0079B0                       1370 00198$:
      0079B0 7E 00            [12] 1371 	mov	r6,#0x00
      0079B2 7F 00            [12] 1372 	mov	r7,#0x00
      0079B4                       1373 00199$:
      0079B4 12 3A CC         [24] 1374 	lcall	_ak820_outline_0118
      0079B7 12 72 B7         [24] 1375 	lcall	_host_consumer_send
                                   1376 ;	quantum/action.c:633: break;
      0079BA 02 7B 28         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:640: case ACT_LAYER: {
      0079BD                       1379 00131$:
                                   1380 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      0079BD 90 08 96         [24] 1381 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079C0 E0               [24] 1382 	movx	a,@dptr
      0079C1 54 03            [12] 1383 	anl	a,#0x03
      0079C3 90 08 9A         [24] 1384 	mov	dptr,#_process_action_on_40000_686
      0079C6 F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0079C7 E0               [24] 1387 	movx	a,@dptr
      0079C8 FF               [12] 1388 	mov	r7,a
      0079C9 60 11            [24] 1389 	jz	00200$
      0079CB E5 28            [12] 1390 	mov	a,_process_action_sloc0_1_0
      0079CD 60 07            [24] 1391 	jz	00202$
      0079CF 8F 06            [24] 1392 	mov	ar6,r7
      0079D1 53 06 01         [24] 1393 	anl	ar6,#0x01
      0079D4 80 10            [24] 1394 	sjmp	00201$
      0079D6                       1395 00202$:
      0079D6 74 02            [12] 1396 	mov	a,#0x02
      0079D8 5F               [12] 1397 	anl	a,r7
      0079D9 FE               [12] 1398 	mov	r6,a
      0079DA 80 0A            [24] 1399 	sjmp	00201$
      0079DC                       1400 00200$:
      0079DC E5 28            [12] 1401 	mov	a,_process_action_sloc0_1_0
      0079DE B4 01 00         [24] 1402 	cjne	a,#0x01,00457$
      0079E1                       1403 00457$:
      0079E1 92 22            [24] 1404 	mov  _process_action_sloc1_1_0,c
      0079E3 E4               [12] 1405 	clr	a
      0079E4 33               [12] 1406 	rlc	a
      0079E5 FE               [12] 1407 	mov	r6,a
      0079E6                       1408 00201$:
      0079E6 EE               [12] 1409 	mov	a,r6
      0079E7 70 03            [24] 1410 	jnz	00458$
      0079E9 02 7B 28         [24] 1411 	ljmp	00181$
      0079EC                       1412 00458$:
                                   1413 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0079EC 12 7D 8D         [24] 1414 	lcall	_ak820_outline_0158
      0079EF C4               [12] 1415 	swap	a
      0079F0 03               [12] 1416 	rr	a
      0079F1 54 07            [12] 1417 	anl	a,#0x07
      0079F3 25 E0            [12] 1418 	add	a,acc
      0079F5 25 E0            [12] 1419 	add	a,acc
      0079F7 FF               [12] 1420 	mov	r7,a
                                   1421 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0079F8 12 7D 8D         [24] 1422 	lcall	_ak820_outline_0158
      0079FB 54 0F            [12] 1423 	anl	a,#0x0f
      0079FD FE               [12] 1424 	mov	r6,a
      0079FE 8F F0            [24] 1425 	mov	b,r7
      007A00 05 F0            [12] 1426 	inc	b
      007A02 EE               [12] 1427 	mov	a,r6
      007A03 80 02            [24] 1428 	sjmp	00460$
      007A05                       1429 00459$:
      007A05 25 E0            [12] 1430 	add	a,acc
      007A07                       1431 00460$:
      007A07 D5 F0 FB         [24] 1432 	djnz	b,00459$
      007A0A FE               [12] 1433 	mov	r6,a
                                   1434 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007A0B 12 7D 8D         [24] 1435 	lcall	_ak820_outline_0158
      007A0E 30 E4 11         [24] 1436 	jnb	acc.4,00204$
      007A11 8F F0            [24] 1437 	mov	b,r7
      007A13 05 F0            [12] 1438 	inc	b
      007A15 74 0F            [12] 1439 	mov	a,#0x0f
      007A17 80 02            [24] 1440 	sjmp	00463$
      007A19                       1441 00462$:
      007A19 25 E0            [12] 1442 	add	a,acc
      007A1B                       1443 00463$:
      007A1B D5 F0 FB         [24] 1444 	djnz	b,00462$
      007A1E F4               [12] 1445 	cpl	a
      007A1F FF               [12] 1446 	mov	r7,a
      007A20 80 02            [24] 1447 	sjmp	00205$
      007A22                       1448 00204$:
      007A22 7F 00            [12] 1449 	mov	r7,#0x00
      007A24                       1450 00205$:
                                   1451 ;	quantum/action.c:648: bits |= mask;
      007A24 EE               [12] 1452 	mov	a,r6
      007A25 42 07            [12] 1453 	orl	ar7,a
                                   1454 ;	quantum/action.c:649: if (!on) {
      007A27 90 08 9A         [24] 1455 	mov	dptr,#_process_action_on_40000_686
      007A2A E0               [24] 1456 	movx	a,@dptr
      007A2B 70 31            [24] 1457 	jnz	00143$
                                   1458 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      007A2D 12 7D 72         [24] 1459 	lcall	_ak820_outline_0090
      007A30 FE               [12] 1460 	mov	r6,a
      007A31 2E               [12] 1461 	add	a,r6
                                   1462 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      007A32 90 7A 36         [24] 1463 	mov	dptr,#00465$
      007A35 73               [24] 1464 	jmp	@a+dptr
      007A36                       1465 00465$:
      007A36 80 06            [24] 1466 	sjmp	00132$
      007A38 80 0C            [24] 1467 	sjmp	00133$
      007A3A 80 12            [24] 1468 	sjmp	00134$
      007A3C 80 18            [24] 1469 	sjmp	00135$
      007A3E                       1470 00132$:
      007A3E 8F 82            [24] 1471 	mov	dpl, r7
      007A40 12 7D ED         [24] 1472 	lcall	_default_layer_and
      007A43 02 7B 28         [24] 1473 	ljmp	00181$
                                   1474 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007A46                       1475 00133$:
      007A46 8F 82            [24] 1476 	mov	dpl, r7
      007A48 12 7D DD         [24] 1477 	lcall	_default_layer_or
      007A4B 02 7B 28         [24] 1478 	ljmp	00181$
                                   1479 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      007A4E                       1480 00134$:
      007A4E 8F 82            [24] 1481 	mov	dpl, r7
      007A50 12 7E 02         [24] 1482 	lcall	_default_layer_xor
      007A53 02 7B 28         [24] 1483 	ljmp	00181$
                                   1484 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007A56                       1485 00135$:
      007A56 8F 82            [24] 1486 	mov	dpl, r7
      007A58 12 7D D3         [24] 1487 	lcall	_default_layer_set
                                   1488 ;	quantum/action.c:655: }
      007A5B 02 7B 28         [24] 1489 	ljmp	00181$
      007A5E                       1490 00143$:
                                   1491 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007A5E 12 7D 72         [24] 1492 	lcall	_ak820_outline_0090
      007A61 FE               [12] 1493 	mov	r6,a
      007A62 2E               [12] 1494 	add	a,r6
                                   1495 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      007A63 90 7A 67         [24] 1496 	mov	dptr,#00466$
      007A66 73               [24] 1497 	jmp	@a+dptr
      007A67                       1498 00466$:
      007A67 80 06            [24] 1499 	sjmp	00137$
      007A69 80 0C            [24] 1500 	sjmp	00138$
      007A6B 80 12            [24] 1501 	sjmp	00139$
      007A6D 80 18            [24] 1502 	sjmp	00140$
      007A6F                       1503 00137$:
      007A6F 8F 82            [24] 1504 	mov	dpl, r7
      007A71 12 7F 7A         [24] 1505 	lcall	_layer_and
      007A74 02 7B 28         [24] 1506 	ljmp	00181$
                                   1507 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007A77                       1508 00138$:
      007A77 8F 82            [24] 1509 	mov	dpl, r7
      007A79 12 7F 6A         [24] 1510 	lcall	_layer_or
      007A7C 02 7B 28         [24] 1511 	ljmp	00181$
                                   1512 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007A7F                       1513 00139$:
      007A7F 8F 82            [24] 1514 	mov	dpl, r7
      007A81 12 7F 8F         [24] 1515 	lcall	_layer_xor
      007A84 02 7B 28         [24] 1516 	ljmp	00181$
                                   1517 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007A87                       1518 00140$:
      007A87 8F 82            [24] 1519 	mov	dpl, r7
      007A89 12 7F 0C         [24] 1520 	lcall	_layer_state_set
                                   1521 ;	quantum/action.c:665: break;
      007A8C 02 7B 28         [24] 1522 	ljmp	00181$
                                   1523 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007A8F                       1524 00147$:
                                   1525 ;	quantum/action.c:668: if (pressed) {
      007A8F E5 28            [12] 1526 	mov	a,_process_action_sloc0_1_0
      007A91 60 11            [24] 1527 	jz	00149$
                                   1528 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007A93 12 7D 7B         [24] 1529 	lcall	_ak820_outline_0113
      007A96 F5 82            [12] 1530 	mov	dpl,a
      007A98 12 7E 70         [24] 1531 	lcall	_layer_hold_on
                                   1532 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007A9B 12 7D 5D         [24] 1533 	lcall	_ak820_outline_0078
      007A9E 12 7C 7A         [24] 1534 	lcall	_register_mods
      007AA1 02 7B 28         [24] 1535 	ljmp	00181$
      007AA4                       1536 00149$:
                                   1537 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007AA4 12 7D 5D         [24] 1538 	lcall	_ak820_outline_0078
      007AA7 12 7C 8E         [24] 1539 	lcall	_unregister_mods
                                   1540 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007AAA 12 7D 7B         [24] 1541 	lcall	_ak820_outline_0113
      007AAD F5 82            [12] 1542 	mov	dpl,a
      007AAF 12 7E A7         [24] 1543 	lcall	_layer_hold_off
                                   1544 ;	quantum/action.c:675: break;
      007AB2 02 7B 28         [24] 1545 	ljmp	00181$
                                   1546 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007AB5                       1547 00152$:
                                   1548 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007AB5 12 7D 8D         [24] 1549 	lcall	_ak820_outline_0158
      007AB8 FF               [12] 1550 	mov	r7,a
      007AB9 BF F1 02         [24] 1551 	cjne	r7,#0xf1,00468$
      007ABC 80 0A            [24] 1552 	sjmp	00154$
      007ABE                       1553 00468$:
      007ABE BF F2 02         [24] 1554 	cjne	r7,#0xf2,00469$
      007AC1 80 19            [24] 1555 	sjmp	00155$
      007AC3                       1556 00469$:
                                   1557 ;	quantum/action.c:694: momentary_layer_action:
      007AC3 BF F3 3B         [24] 1558 	cjne	r7,#0xf3,00160$
      007AC6 80 28            [24] 1559 	sjmp	00156$
      007AC8                       1560 00154$:
                                   1561 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007AC8 E5 28            [12] 1562 	mov	a,_process_action_sloc0_1_0
      007ACA 60 08            [24] 1563 	jz	00206$
      007ACC 12 7D 43         [24] 1564 	lcall	_ak820_outline_0042
      007ACF 12 7E 70         [24] 1565 	lcall	_layer_hold_on
      007AD2 80 54            [24] 1566 	sjmp	00181$
      007AD4                       1567 00206$:
      007AD4 12 7D 43         [24] 1568 	lcall	_ak820_outline_0042
      007AD7 12 7E A7         [24] 1569 	lcall	_layer_hold_off
                                   1570 ;	quantum/action.c:696: break;
                                   1571 ;	quantum/action.c:697: case OP_OFF_ON:
      007ADA 80 4C            [24] 1572 	sjmp	00181$
      007ADC                       1573 00155$:
                                   1574 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007ADC E5 28            [12] 1575 	mov	a,_process_action_sloc0_1_0
      007ADE 60 08            [24] 1576 	jz	00208$
      007AE0 12 7D 43         [24] 1577 	lcall	_ak820_outline_0042
      007AE3 12 7F 4D         [24] 1578 	lcall	_layer_off
      007AE6 80 40            [24] 1579 	sjmp	00181$
      007AE8                       1580 00208$:
      007AE8 12 7D 43         [24] 1581 	lcall	_ak820_outline_0042
      007AEB 12 7F 33         [24] 1582 	lcall	_layer_on
                                   1583 ;	quantum/action.c:699: break;
                                   1584 ;	quantum/action.c:700: case OP_SET_CLEAR:
      007AEE 80 38            [24] 1585 	sjmp	00181$
      007AF0                       1586 00156$:
                                   1587 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007AF0 E5 28            [12] 1588 	mov	a,_process_action_sloc0_1_0
      007AF2 60 08            [24] 1589 	jz	00210$
      007AF4 12 7D 43         [24] 1590 	lcall	_ak820_outline_0042
      007AF7 12 7F 1E         [24] 1591 	lcall	_layer_move
      007AFA 80 2C            [24] 1592 	sjmp	00181$
      007AFC                       1593 00210$:
      007AFC 12 7F 19         [24] 1594 	lcall	_layer_clear
                                   1595 ;	quantum/action.c:702: break;
                                   1596 ;	quantum/action.c:748: default:
      007AFF 80 27            [24] 1597 	sjmp	00181$
      007B01                       1598 00160$:
                                   1599 ;	quantum/action.c:755: if (pressed) {
      007B01 E5 28            [12] 1600 	mov	a,_process_action_sloc0_1_0
      007B03 60 08            [24] 1601 	jz	00163$
                                   1602 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007B05 12 7D 5D         [24] 1603 	lcall	_ak820_outline_0078
      007B08 12 7B 3F         [24] 1604 	lcall	_register_code
                                   1605 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007B0B 80 1B            [24] 1606 	sjmp	00181$
      007B0D                       1607 00163$:
                                   1608 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      007B0D 12 7D 8D         [24] 1609 	lcall	_ak820_outline_0158
      007B10 FF               [12] 1610 	mov	r7,a
      007B11 BF 39 0E         [24] 1611 	cjne	r7,#0x39,00175$
                                   1612 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007B14 7F 50            [12] 1613 	mov	r7,#0x50
      007B16                       1614 00187$:
      007B16 EF               [12] 1615 	mov	a,r7
      007B17 60 09            [24] 1616 	jz	00175$
      007B19 90 00 01         [24] 1617 	mov	dptr,#0x0001
      007B1C 12 5E 40         [24] 1618 	lcall	_mDelaymS
      007B1F 1F               [12] 1619 	dec	r7
                                   1620 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      007B20 80 F4            [24] 1621 	sjmp	00187$
      007B22                       1622 00175$:
                                   1623 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      007B22 12 7D 5D         [24] 1624 	lcall	_ak820_outline_0078
      007B25 12 7B BB         [24] 1625 	lcall	_unregister_code
                                   1626 ;	quantum/action.c:848: }
      007B28                       1627 00181$:
                                   1628 ;	quantum/action.c:869: switch (action.kind.id) {
      007B28 90 08 96         [24] 1629 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B2B E0               [24] 1630 	movx	a,@dptr
      007B2C C4               [12] 1631 	swap	a
      007B2D 54 0F            [12] 1632 	anl	a,#0x0f
      007B2F FF               [12] 1633 	mov	r7,a
      007B30 BF 08 02         [24] 1634 	cjne	r7,#0x08,00478$
      007B33 80 03            [24] 1635 	sjmp	00183$
      007B35                       1636 00478$:
      007B35 BF 09 06         [24] 1637 	cjne	r7,#0x09,00192$
                                   1638 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007B38                       1639 00183$:
                                   1640 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007B38 12 71 ED         [24] 1641 	lcall	_host_keyboard_leds
                                   1642 ;	quantum/action.c:880: }
                                   1643 ;	quantum/action.c:933: }
      007B3B 02 9D 1D         [24] 1644 	ljmp	_led_set
      007B3E                       1645 00192$:
      007B3E 22               [24] 1646 	ret
                                   1647 ;------------------------------------------------------------
                                   1648 ;Allocation info for local variables in function 'register_code'
                                   1649 ;------------------------------------------------------------
                                   1650 ;code          Allocated with name '_register_code_code_10000_720'
                                   1651 ;------------------------------------------------------------
                                   1652 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1653 ;	-----------------------------------------
                                   1654 ;	 function register_code
                                   1655 ;	-----------------------------------------
      007B3F                       1656 _register_code:
      007B3F E5 82            [12] 1657 	mov	a,dpl
      007B41 90 08 9B         [24] 1658 	mov	dptr,#_register_code_code_10000_720
      007B44 F0               [24] 1659 	movx	@dptr,a
                                   1660 ;	quantum/action.c:940: if (code == KC_NO) {
      007B45 E0               [24] 1661 	movx	a,@dptr
      007B46 FF               [12] 1662 	mov	r7,a
      007B47 70 01            [24] 1663 	jnz	00123$
                                   1664 ;	quantum/action.c:941: return;
      007B49 22               [24] 1665 	ret
      007B4A                       1666 00123$:
                                   1667 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007B4A BF 04 00         [24] 1668 	cjne	r7,#0x04,00186$
      007B4D                       1669 00186$:
      007B4D 40 21            [24] 1670 	jc	00119$
      007B4F EF               [12] 1671 	mov	a,r7
      007B50 24 5B            [12] 1672 	add	a,#0xff - 0xa4
      007B52 40 1C            [24] 1673 	jc	00119$
                                   1674 ;	free result
                                   1675 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007B54 8F 82            [24] 1676 	mov	dpl, r7
      007B56 C0 07            [24] 1677 	push	ar7
      007B58 12 83 85         [24] 1678 	lcall	_add_owned_key
      007B5B E5 82            [12] 1679 	mov	a, dpl
      007B5D D0 07            [24] 1680 	pop	ar7
      007B5F 70 01            [24] 1681 	jnz	00104$
      007B61 22               [24] 1682 	ret
      007B62                       1683 00104$:
                                   1684 ;	quantum/action.c:983: ak820_dynamic_macro_observe(code, true);
      007B62 90 04 C1         [24] 1685 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007B65 74 01            [12] 1686 	mov	a,#0x01
      007B67 F0               [24] 1687 	movx	@dptr,a
      007B68 8F 82            [24] 1688 	mov	dpl, r7
      007B6A 12 3C 7B         [24] 1689 	lcall	_ak820_dynamic_macro_observe
                                   1690 ;	quantum/action.c:995: send_keyboard_report();
      007B6D 02 86 17         [24] 1691 	ljmp	_send_keyboard_report
      007B70                       1692 00119$:
                                   1693 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      007B70 12 7D 92         [24] 1694 	lcall	_ak820_outline_0166
      007B73 BF E0 00         [24] 1695 	cjne	r7,#0xe0,00190$
      007B76                       1696 00190$:
      007B76 40 1A            [24] 1697 	jc	00115$
      007B78 EF               [12] 1698 	mov	a,r7
      007B79 24 18            [12] 1699 	add	a,#0xff - 0xe7
      007B7B 40 15            [24] 1700 	jc	00115$
                                   1701 ;	free result
                                   1702 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007B7D 74 07            [12] 1703 	mov	a,#0x07
      007B7F 5F               [12] 1704 	anl	a,r7
      007B80 12 7D 4C         [24] 1705 	lcall	_ak820_outline_0061
      007B83 80 02            [24] 1706 	sjmp	00194$
      007B85                       1707 00193$:
      007B85 25 E0            [12] 1708 	add	a,acc
      007B87                       1709 00194$:
      007B87 D5 F0 FB         [24] 1710 	djnz	b,00193$
      007B8A F5 82            [12] 1711 	mov	dpl,a
      007B8C 12 82 E6         [24] 1712 	lcall	_add_owned_mods
                                   1713 ;	quantum/action.c:998: send_keyboard_report();
      007B8F 02 86 17         [24] 1714 	ljmp	_send_keyboard_report
      007B92                       1715 00115$:
                                   1716 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007B92 12 7D 92         [24] 1717 	lcall	_ak820_outline_0166
      007B95 BF A5 00         [24] 1718 	cjne	r7,#0xa5,00195$
      007B98                       1719 00195$:
      007B98 40 05            [24] 1720 	jc	00113$
      007B9A EF               [12] 1721 	mov	a,r7
      007B9B 24 58            [12] 1722 	add	a,#0xff - 0xa7
      007B9D 50 0D            [24] 1723 	jnc	00108$
                                   1724 ;	free result
      007B9F                       1725 00113$:
      007B9F 12 7D 92         [24] 1726 	lcall	_ak820_outline_0166
      007BA2 BF A8 00         [24] 1727 	cjne	r7,#0xa8,00198$
      007BA5                       1728 00198$:
      007BA5 40 13            [24] 1729 	jc	00125$
      007BA7 EF               [12] 1730 	mov	a,r7
      007BA8 24 3D            [12] 1731 	add	a,#0xff - 0xc2
      007BAA 40 0E            [24] 1732 	jc	00125$
                                   1733 ;	free result
      007BAC                       1734 00108$:
                                   1735 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007BAC 12 7D 92         [24] 1736 	lcall	_ak820_outline_0166
      007BAF 90 0A F6         [24] 1737 	mov	dptr,#_owned_usage_key_PARM_2
      007BB2 74 01            [12] 1738 	mov	a,#0x01
      007BB4 F0               [24] 1739 	movx	@dptr,a
      007BB5 8F 82            [24] 1740 	mov	dpl, r7
                                   1741 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1742 ;	quantum/action.c:1013: }
      007BB7 02 84 C4         [24] 1743 	ljmp	_owned_usage_key
      007BBA                       1744 00125$:
      007BBA 22               [24] 1745 	ret
                                   1746 ;------------------------------------------------------------
                                   1747 ;Allocation info for local variables in function 'unregister_code'
                                   1748 ;------------------------------------------------------------
                                   1749 ;code          Allocated with name '_unregister_code_code_10000_734'
                                   1750 ;------------------------------------------------------------
                                   1751 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1752 ;	-----------------------------------------
                                   1753 ;	 function unregister_code
                                   1754 ;	-----------------------------------------
      007BBB                       1755 _unregister_code:
      007BBB E5 82            [12] 1756 	mov	a,dpl
      007BBD 90 08 9C         [24] 1757 	mov	dptr,#_unregister_code_code_10000_734
      007BC0 F0               [24] 1758 	movx	@dptr,a
                                   1759 ;	quantum/action.c:1020: if (code == KC_NO) {
      007BC1 E0               [24] 1760 	movx	a,@dptr
      007BC2 FF               [12] 1761 	mov	r7,a
      007BC3 70 01            [24] 1762 	jnz	00121$
                                   1763 ;	quantum/action.c:1021: return;
      007BC5 22               [24] 1764 	ret
      007BC6                       1765 00121$:
                                   1766 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007BC6 BF 04 00         [24] 1767 	cjne	r7,#0x04,00184$
      007BC9                       1768 00184$:
      007BC9 40 1F            [24] 1769 	jc	00117$
      007BCB EF               [12] 1770 	mov	a,r7
      007BCC 24 5B            [12] 1771 	add	a,#0xff - 0xa4
      007BCE 40 1A            [24] 1772 	jc	00117$
                                   1773 ;	free result
                                   1774 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      007BD0 8F 82            [24] 1775 	mov	dpl, r7
      007BD2 C0 07            [24] 1776 	push	ar7
      007BD4 12 83 FE         [24] 1777 	lcall	_del_owned_key
      007BD7 E5 82            [12] 1778 	mov	a, dpl
      007BD9 D0 07            [24] 1779 	pop	ar7
      007BDB 70 01            [24] 1780 	jnz	00102$
      007BDD 22               [24] 1781 	ret
      007BDE                       1782 00102$:
                                   1783 ;	quantum/action.c:1057: ak820_dynamic_macro_observe(code, false);
      007BDE 90 04 C1         [24] 1784 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007BE1 12 7D A3         [24] 1785 	lcall	_ak820_outline_0188
      007BE4 12 3C 7B         [24] 1786 	lcall	_ak820_dynamic_macro_observe
                                   1787 ;	quantum/action.c:1062: send_keyboard_report();
      007BE7 02 86 17         [24] 1788 	ljmp	_send_keyboard_report
      007BEA                       1789 00117$:
                                   1790 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007BEA 12 7D 98         [24] 1791 	lcall	_ak820_outline_0167
      007BED BF E0 00         [24] 1792 	cjne	r7,#0xe0,00188$
      007BF0                       1793 00188$:
      007BF0 40 1A            [24] 1794 	jc	00113$
      007BF2 EF               [12] 1795 	mov	a,r7
      007BF3 24 18            [12] 1796 	add	a,#0xff - 0xe7
      007BF5 40 15            [24] 1797 	jc	00113$
                                   1798 ;	free result
                                   1799 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      007BF7 74 07            [12] 1800 	mov	a,#0x07
      007BF9 5F               [12] 1801 	anl	a,r7
      007BFA 12 7D 4C         [24] 1802 	lcall	_ak820_outline_0061
      007BFD 80 02            [24] 1803 	sjmp	00192$
      007BFF                       1804 00191$:
      007BFF 25 E0            [12] 1805 	add	a,acc
      007C01                       1806 00192$:
      007C01 D5 F0 FB         [24] 1807 	djnz	b,00191$
      007C04 F5 82            [12] 1808 	mov	dpl,a
      007C06 12 82 F5         [24] 1809 	lcall	_del_owned_mods
                                   1810 ;	quantum/action.c:1065: send_keyboard_report();
      007C09 02 86 17         [24] 1811 	ljmp	_send_keyboard_report
      007C0C                       1812 00113$:
                                   1813 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007C0C 12 7D 98         [24] 1814 	lcall	_ak820_outline_0167
      007C0F BF A5 00         [24] 1815 	cjne	r7,#0xa5,00193$
      007C12                       1816 00193$:
      007C12 40 05            [24] 1817 	jc	00111$
      007C14 EF               [12] 1818 	mov	a,r7
      007C15 24 58            [12] 1819 	add	a,#0xff - 0xa7
      007C17 50 0D            [24] 1820 	jnc	00106$
                                   1821 ;	free result
      007C19                       1822 00111$:
      007C19 12 7D 98         [24] 1823 	lcall	_ak820_outline_0167
      007C1C BF A8 00         [24] 1824 	cjne	r7,#0xa8,00196$
      007C1F                       1825 00196$:
      007C1F 40 11            [24] 1826 	jc	00123$
      007C21 EF               [12] 1827 	mov	a,r7
      007C22 24 3D            [12] 1828 	add	a,#0xff - 0xc2
      007C24 40 0C            [24] 1829 	jc	00123$
                                   1830 ;	free result
      007C26                       1831 00106$:
                                   1832 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007C26 12 7D 98         [24] 1833 	lcall	_ak820_outline_0167
      007C29 90 0A F6         [24] 1834 	mov	dptr,#_owned_usage_key_PARM_2
      007C2C 12 7D A3         [24] 1835 	lcall	_ak820_outline_0188
                                   1836 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1837 ;	quantum/action.c:1080: }
      007C2F 02 84 C4         [24] 1838 	ljmp	_owned_usage_key
      007C32                       1839 00123$:
      007C32 22               [24] 1840 	ret
                                   1841 ;------------------------------------------------------------
                                   1842 ;Allocation info for local variables in function 'tap_code_delay'
                                   1843 ;------------------------------------------------------------
                                   1844 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1845 ;code          Allocated with name '_tap_code_delay_code_10000_747'
                                   1846 ;i             Allocated with name '_tap_code_delay_i_20000_749'
                                   1847 ;i             Allocated with name '_tap_code_delay_i_50000_752'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1850 ;	-----------------------------------------
                                   1851 ;	 function tap_code_delay
                                   1852 ;	-----------------------------------------
      007C33                       1853 _tap_code_delay:
      007C33 E5 82            [12] 1854 	mov	a,dpl
      007C35 90 08 9F         [24] 1855 	mov	dptr,#_tap_code_delay_code_10000_747
      007C38 F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/action.c:1088: register_code(code);
      007C39 E0               [24] 1858 	movx	a,@dptr
      007C3A FF               [12] 1859 	mov	r7,a
      007C3B F5 82            [12] 1860 	mov	dpl,a
      007C3D C0 07            [24] 1861 	push	ar7
      007C3F 71 3F            [12] 1862 	acall	_register_code
      007C41 D0 07            [24] 1863 	pop	ar7
                                   1864 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007C43 90 08 9D         [24] 1865 	mov	dptr,#_tap_code_delay_PARM_2
      007C46 12 3A A4         [24] 1866 	lcall	_ak820_outline_0079
      007C49                       1867 00110$:
      007C49 ED               [12] 1868 	mov	a,r5
      007C4A 4E               [12] 1869 	orl	a,r6
      007C4B 60 0D            [24] 1870 	jz	00105$
                                   1871 ;	quantum/action.c:1090: wait_ms(1);
      007C4D 90 00 01         [24] 1872 	mov	dptr,#0x0001
      007C50 12 5E 40         [24] 1873 	lcall	_mDelaymS
                                   1874 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007C53 1D               [12] 1875 	dec	r5
      007C54 BD FF 01         [24] 1876 	cjne	r5,#0xff,00141$
      007C57 1E               [12] 1877 	dec	r6
      007C58                       1878 00141$:
      007C58 80 EF            [24] 1879 	sjmp	00110$
      007C5A                       1880 00105$:
                                   1881 ;	quantum/action.c:1092: unregister_code(code);
      007C5A 8F 82            [24] 1882 	mov	dpl, r7
                                   1883 ;	quantum/action.c:1093: }
      007C5C 61 BB            [12] 1884 	ajmp	_unregister_code
                                   1885 ;------------------------------------------------------------
                                   1886 ;Allocation info for local variables in function 'tap_code'
                                   1887 ;------------------------------------------------------------
                                   1888 ;code          Allocated with name '_tap_code_code_10000_754'
                                   1889 ;------------------------------------------------------------
                                   1890 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1891 ;	-----------------------------------------
                                   1892 ;	 function tap_code
                                   1893 ;	-----------------------------------------
      007C5E                       1894 _tap_code:
      007C5E E5 82            [12] 1895 	mov	a,dpl
      007C60 90 08 A0         [24] 1896 	mov	dptr,#_tap_code_code_10000_754
      007C63 F0               [24] 1897 	movx	@dptr,a
                                   1898 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007C64 E0               [24] 1899 	movx	a,@dptr
      007C65 FF               [12] 1900 	mov	r7,a
      007C66 BF 39 04         [24] 1901 	cjne	r7,#0x39,00103$
      007C69 7E 50            [12] 1902 	mov	r6,#0x50
      007C6B 80 02            [24] 1903 	sjmp	00104$
      007C6D                       1904 00103$:
      007C6D 7E 00            [12] 1905 	mov	r6,#0x00
      007C6F                       1906 00104$:
      007C6F 90 08 9D         [24] 1907 	mov	dptr,#_tap_code_delay_PARM_2
      007C72 EE               [12] 1908 	mov	a,r6
      007C73 12 3A DC         [24] 1909 	lcall	_ak820_outline_0134
      007C76 8F 82            [24] 1910 	mov	dpl, r7
                                   1911 ;	quantum/action.c:1101: }
      007C78 81 33            [12] 1912 	ajmp	_tap_code_delay
                                   1913 ;------------------------------------------------------------
                                   1914 ;Allocation info for local variables in function 'register_mods'
                                   1915 ;------------------------------------------------------------
                                   1916 ;mods          Allocated with name '_register_mods_mods_10000_756'
                                   1917 ;------------------------------------------------------------
                                   1918 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1919 ;	-----------------------------------------
                                   1920 ;	 function register_mods
                                   1921 ;	-----------------------------------------
      007C7A                       1922 _register_mods:
      007C7A E5 82            [12] 1923 	mov	a,dpl
      007C7C 90 08 A1         [24] 1924 	mov	dptr,#_register_mods_mods_10000_756
      007C7F F0               [24] 1925 	movx	@dptr,a
                                   1926 ;	quantum/action.c:1108: if (mods) {
      007C80 E0               [24] 1927 	movx	a,@dptr
      007C81 FF               [12] 1928 	mov	r7,a
      007C82 E0               [24] 1929 	movx	a,@dptr
      007C83 60 08            [24] 1930 	jz	00103$
                                   1931 ;	quantum/action.c:1109: add_owned_mods(mods);
      007C85 8F 82            [24] 1932 	mov	dpl, r7
      007C87 12 82 E6         [24] 1933 	lcall	_add_owned_mods
                                   1934 ;	quantum/action.c:1110: send_keyboard_report();
                                   1935 ;	quantum/action.c:1112: }
      007C8A 02 86 17         [24] 1936 	ljmp	_send_keyboard_report
      007C8D                       1937 00103$:
      007C8D 22               [24] 1938 	ret
                                   1939 ;------------------------------------------------------------
                                   1940 ;Allocation info for local variables in function 'unregister_mods'
                                   1941 ;------------------------------------------------------------
                                   1942 ;mods          Allocated with name '_unregister_mods_mods_10000_760'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1945 ;	-----------------------------------------
                                   1946 ;	 function unregister_mods
                                   1947 ;	-----------------------------------------
      007C8E                       1948 _unregister_mods:
      007C8E E5 82            [12] 1949 	mov	a,dpl
      007C90 90 08 A2         [24] 1950 	mov	dptr,#_unregister_mods_mods_10000_760
      007C93 F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	quantum/action.c:1119: if (mods) {
      007C94 E0               [24] 1953 	movx	a,@dptr
      007C95 FF               [12] 1954 	mov	r7,a
      007C96 E0               [24] 1955 	movx	a,@dptr
      007C97 60 08            [24] 1956 	jz	00103$
                                   1957 ;	quantum/action.c:1120: del_owned_mods(mods);
      007C99 8F 82            [24] 1958 	mov	dpl, r7
      007C9B 12 82 F5         [24] 1959 	lcall	_del_owned_mods
                                   1960 ;	quantum/action.c:1121: send_keyboard_report();
                                   1961 ;	quantum/action.c:1123: }
      007C9E 02 86 17         [24] 1962 	ljmp	_send_keyboard_report
      007CA1                       1963 00103$:
      007CA1 22               [24] 1964 	ret
                                   1965 ;------------------------------------------------------------
                                   1966 ;Allocation info for local variables in function 'register_weak_mods'
                                   1967 ;------------------------------------------------------------
                                   1968 ;mods          Allocated with name '_register_weak_mods_mods_10000_764'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function register_weak_mods
                                   1973 ;	-----------------------------------------
      007CA2                       1974 _register_weak_mods:
      007CA2 E5 82            [12] 1975 	mov	a,dpl
      007CA4 90 08 A3         [24] 1976 	mov	dptr,#_register_weak_mods_mods_10000_764
      007CA7 F0               [24] 1977 	movx	@dptr,a
                                   1978 ;	quantum/action.c:1130: if (mods) {
      007CA8 E0               [24] 1979 	movx	a,@dptr
      007CA9 FF               [12] 1980 	mov	r7,a
      007CAA E0               [24] 1981 	movx	a,@dptr
      007CAB 60 08            [24] 1982 	jz	00103$
                                   1983 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007CAD 8F 82            [24] 1984 	mov	dpl, r7
      007CAF 12 83 02         [24] 1985 	lcall	_add_owned_weak_mods
                                   1986 ;	quantum/action.c:1132: send_keyboard_report();
                                   1987 ;	quantum/action.c:1134: }
      007CB2 02 86 17         [24] 1988 	ljmp	_send_keyboard_report
      007CB5                       1989 00103$:
      007CB5 22               [24] 1990 	ret
                                   1991 ;------------------------------------------------------------
                                   1992 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1993 ;------------------------------------------------------------
                                   1994 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_768'
                                   1995 ;------------------------------------------------------------
                                   1996 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1997 ;	-----------------------------------------
                                   1998 ;	 function unregister_weak_mods
                                   1999 ;	-----------------------------------------
      007CB6                       2000 _unregister_weak_mods:
      007CB6 E5 82            [12] 2001 	mov	a,dpl
      007CB8 90 08 A4         [24] 2002 	mov	dptr,#_unregister_weak_mods_mods_10000_768
      007CBB F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	quantum/action.c:1141: if (mods) {
      007CBC E0               [24] 2005 	movx	a,@dptr
      007CBD FF               [12] 2006 	mov	r7,a
      007CBE E0               [24] 2007 	movx	a,@dptr
      007CBF 60 08            [24] 2008 	jz	00103$
                                   2009 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007CC1 8F 82            [24] 2010 	mov	dpl, r7
      007CC3 12 83 11         [24] 2011 	lcall	_del_owned_weak_mods
                                   2012 ;	quantum/action.c:1143: send_keyboard_report();
                                   2013 ;	quantum/action.c:1145: }
      007CC6 02 86 17         [24] 2014 	ljmp	_send_keyboard_report
      007CC9                       2015 00103$:
      007CC9 22               [24] 2016 	ret
                                   2017 ;------------------------------------------------------------
                                   2018 ;Allocation info for local variables in function 'clear_keyboard'
                                   2019 ;------------------------------------------------------------
                                   2020 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   2021 ;	-----------------------------------------
                                   2022 ;	 function clear_keyboard
                                   2023 ;	-----------------------------------------
      007CCA                       2024 _clear_keyboard:
                                   2025 ;	quantum/action.c:1152: clear_mods();
      007CCA 12 86 92         [24] 2026 	lcall	_clear_mods
                                   2027 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   2028 ;	quantum/action.c:1154: }
      007CCD 81 CF            [12] 2029 	ajmp	_clear_keyboard_but_mods
                                   2030 ;------------------------------------------------------------
                                   2031 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2032 ;------------------------------------------------------------
                                   2033 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   2034 ;	-----------------------------------------
                                   2035 ;	 function clear_keyboard_but_mods
                                   2036 ;	-----------------------------------------
      007CCF                       2037 _clear_keyboard_but_mods:
                                   2038 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007CCF 90 0E 29         [24] 2039 	mov	dptr,#_actual_keyboard_report
      007CD2 12 74 AE         [24] 2040 	lcall	_clear_keys_from_report
                                   2041 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   2042 ;	quantum/action.c:1163: }
      007CD5 81 D7            [12] 2043 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2044 ;------------------------------------------------------------
                                   2045 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2046 ;------------------------------------------------------------
                                   2047 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   2048 ;	-----------------------------------------
                                   2049 ;	 function clear_keyboard_but_mods_and_keys
                                   2050 ;	-----------------------------------------
      007CD7                       2051 _clear_keyboard_but_mods_and_keys:
                                   2052 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007CD7 12 4C 53         [24] 2053 	lcall	_ak820_tapping_cancel
                                   2054 ;	quantum/action.c:1176: ak820_dynamic_macro_cancel();
      007CDA 12 3B AC         [24] 2055 	lcall	_ak820_dynamic_macro_cancel
                                   2056 ;	quantum/action.c:1179: ak820_autoshift_cancel();
      007CDD 12 33 4A         [24] 2057 	lcall	_ak820_autoshift_cancel
                                   2058 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007CE0 12 2E F0         [24] 2059 	lcall	_ak820_oneshot_cancel
                                   2060 ;	quantum/action.c:1185: ak820_combo_cancel();
      007CE3 12 37 B7         [24] 2061 	lcall	_ak820_combo_cancel
                                   2062 ;	quantum/action.c:1188: repeat_key_cancel();
      007CE6 12 A6 E2         [24] 2063 	lcall	_repeat_key_cancel
                                   2064 ;	quantum/action.c:1190: clear_owned_mods();
      007CE9 12 83 20         [24] 2065 	lcall	_clear_owned_mods
                                   2066 ;	quantum/action.c:1191: clear_owned_keys();
      007CEC 12 83 58         [24] 2067 	lcall	_clear_owned_keys
                                   2068 ;	quantum/action.c:1192: clear_owned_usages();
      007CEF 12 84 8C         [24] 2069 	lcall	_clear_owned_usages
                                   2070 ;	quantum/action.c:1193: layer_hold_clear();
      007CF2 D1 DF            [12] 2071 	acall	_layer_hold_clear
                                   2072 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007CF4 12 A1 BE         [24] 2073 	lcall	_clear_macro_tri_layer
                                   2074 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007CF7 90 0E 29         [24] 2075 	mov	dptr,#_actual_keyboard_report
      007CFA 12 74 AE         [24] 2076 	lcall	_clear_keys_from_report
                                   2077 ;	quantum/action.c:1200: host_system_send(0);
      007CFD 90 00 00         [24] 2078 	mov	dptr,#0x0000
      007D00 12 72 88         [24] 2079 	lcall	_host_system_send
                                   2080 ;	quantum/action.c:1201: host_consumer_send(0);
      007D03 90 00 00         [24] 2081 	mov	dptr,#0x0000
      007D06 12 72 B7         [24] 2082 	lcall	_host_consumer_send
                                   2083 ;	quantum/action.c:1203: clear_weak_mods();
      007D09 12 86 C7         [24] 2084 	lcall	_clear_weak_mods
                                   2085 ;	quantum/action.c:1204: send_keyboard_report();
                                   2086 ;	quantum/action.c:1212: }
      007D0C 02 86 17         [24] 2087 	ljmp	_send_keyboard_report
                                   2088 ;------------------------------------------------------------
                                   2089 ;Allocation info for local variables in function 'is_tap_record'
                                   2090 ;------------------------------------------------------------
                                   2091 ;record        Allocated with name '_is_tap_record_record_10000_784'
                                   2092 ;action        Allocated with name '_is_tap_record_action_10001_788'
                                   2093 ;------------------------------------------------------------
                                   2094 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   2095 ;	-----------------------------------------
                                   2096 	.area CSEG    (CODE)
                                   2097 	.area CONST   (CODE)
                                   2098 	.area XINIT   (CODE)
      00C638                       2099 __xinit__disable_action_cache:
      00C638 00                    2100 	.db #0x00	;  0
                                   2101 	.area CABS    (ABS,CODE)
                                   2102 
                                   2103 ; Experimental exact instruction outlining.
                                   2104 	.globl _ak820_outline_0001
                                   2105 	.globl _ak820_outline_0005
                                   2106 	.globl _ak820_outline_0006
                                   2107 	.globl _ak820_outline_0008
                                   2108 	.globl _ak820_outline_0009
                                   2109 	.globl _ak820_outline_0012
                                   2110 	.globl _ak820_outline_0013
                                   2111 	.globl _ak820_outline_0014
                                   2112 	.globl _ak820_outline_0017
                                   2113 	.globl _ak820_outline_0021
                                   2114 	.globl _ak820_outline_0022
                                   2115 	.globl _ak820_outline_0024
                                   2116 	.globl _ak820_outline_0031
                                   2117 	.globl _ak820_outline_0037
                                   2118 	.globl _ak820_outline_0042
                                   2119 	.globl _ak820_outline_0050
                                   2120 	.globl _ak820_outline_0061
                                   2121 	.globl _ak820_outline_0064
                                   2122 	.globl _ak820_outline_0070
                                   2123 	.globl _ak820_outline_0071
                                   2124 	.globl _ak820_outline_0072
                                   2125 	.globl _ak820_outline_0078
                                   2126 	.globl _ak820_outline_0079
                                   2127 	.globl _ak820_outline_0081
                                   2128 	.globl _ak820_outline_0090
                                   2129 	.globl _ak820_outline_0094
                                   2130 	.globl _ak820_outline_0108
                                   2131 	.globl _ak820_outline_0109
                                   2132 	.globl _ak820_outline_0111
                                   2133 	.globl _ak820_outline_0113
                                   2134 	.globl _ak820_outline_0118
                                   2135 	.globl _ak820_outline_0121
                                   2136 	.globl _ak820_outline_0124
                                   2137 	.globl _ak820_outline_0125
                                   2138 	.globl _ak820_outline_0131
                                   2139 	.globl _ak820_outline_0134
                                   2140 	.globl _ak820_outline_0142
                                   2141 	.globl _ak820_outline_0143
                                   2142 	.globl _ak820_outline_0144
                                   2143 	.globl _ak820_outline_0149
                                   2144 	.globl _ak820_outline_0158
                                   2145 	.globl _ak820_outline_0166
                                   2146 	.globl _ak820_outline_0167
                                   2147 	.globl _ak820_outline_0181
                                   2148 	.globl _ak820_outline_0186
                                   2149 	.globl _ak820_outline_0188
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0006
      007D0F                       2153 _ak820_outline_0006:
      007D0F 2D               [12] 2154 	add	a,r5
      007D10 FA               [12] 2155 	mov	r2,a
      007D11 E4               [12] 2156 	clr	a
      007D12 3E               [12] 2157 	addc	a,r6
      007D13 FB               [12] 2158 	mov	r3,a
      007D14 8F 04            [24] 2159 	mov	ar4,r7
      007D16 8A 82            [24] 2160 	mov	dpl,r2
      007D18 8B 83            [24] 2161 	mov	dph,r3
      007D1A 8C F0            [24] 2162 	mov	b,r4
      007D1C 22               [24] 2163 	ret
                                   2164 
                                   2165 	.area CSEG (CODE)
                                   2166 ; function ak820_outline_0014
      007D1D                       2167 _ak820_outline_0014:
      007D1D 2D               [12] 2168 	add	a,r5
      007D1E F9               [12] 2169 	mov	r1,a
      007D1F E4               [12] 2170 	clr	a
      007D20 3E               [12] 2171 	addc	a,r6
      007D21 FA               [12] 2172 	mov	r2,a
      007D22 8F 03            [24] 2173 	mov	ar3,r7
      007D24 89 82            [24] 2174 	mov	dpl,r1
      007D26 8A 83            [24] 2175 	mov	dph,r2
      007D28 8B F0            [24] 2176 	mov	b,r3
      007D2A 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0021
      007D2B                       2181 _ak820_outline_0021:
      007D2B 8E 82            [24] 2182 	mov	dpl,r6
      007D2D 8F 83            [24] 2183 	mov	dph,r7
      007D2F A3               [24] 2184 	inc	dptr
      007D30 E0               [24] 2185 	movx	a,@dptr
      007D31 FC               [12] 2186 	mov	r4,a
      007D32 7D 00            [12] 2187 	mov	r5,#0x00
      007D34 8E 82            [24] 2188 	mov	dpl,r6
      007D36 8F 83            [24] 2189 	mov	dph,r7
      007D38 E0               [24] 2190 	movx	a,@dptr
      007D39 22               [24] 2191 	ret
                                   2192 
                                   2193 	.area CSEG (CODE)
                                   2194 ; function ak820_outline_0024
      007D3A                       2195 _ak820_outline_0024:
      007D3A E0               [24] 2196 	movx	a,@dptr
      007D3B FB               [12] 2197 	mov	r3,a
      007D3C A3               [24] 2198 	inc	dptr
      007D3D E0               [24] 2199 	movx	a,@dptr
      007D3E FC               [12] 2200 	mov	r4,a
      007D3F A3               [24] 2201 	inc	dptr
      007D40 E0               [24] 2202 	movx	a,@dptr
      007D41 FD               [12] 2203 	mov	r5,a
      007D42 22               [24] 2204 	ret
                                   2205 
                                   2206 	.area CSEG (CODE)
                                   2207 ; function ak820_outline_0042
      007D43                       2208 _ak820_outline_0042:
      007D43 90 08 96         [24] 2209 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D46 E0               [24] 2210 	movx	a,@dptr
      007D47 54 1F            [12] 2211 	anl	a,#0x1f
      007D49 F5 82            [12] 2212 	mov	dpl,a
      007D4B 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0061
      007D4C                       2217 _ak820_outline_0061:
      007D4C F5 F0            [12] 2218 	mov	b,a
      007D4E 05 F0            [12] 2219 	inc	b
      007D50 74 01            [12] 2220 	mov	a,#0x01
      007D52 22               [24] 2221 	ret
                                   2222 
                                   2223 	.area CSEG (CODE)
                                   2224 ; function ak820_outline_0070
      007D53                       2225 _ak820_outline_0070:
      007D53 90 0E 06         [24] 2226 	mov	dptr,#___memcpy_PARM_3
      007D56 74 06            [12] 2227 	mov	a,#0x06
      007D58 F0               [24] 2228 	movx	@dptr,a
      007D59 E4               [12] 2229 	clr	a
      007D5A A3               [24] 2230 	inc	dptr
      007D5B F0               [24] 2231 	movx	@dptr,a
      007D5C 22               [24] 2232 	ret
                                   2233 
                                   2234 	.area CSEG (CODE)
                                   2235 ; function ak820_outline_0078
      007D5D                       2236 _ak820_outline_0078:
      007D5D 90 08 95         [24] 2237 	mov	dptr,#_process_action_PARM_2
      007D60 E0               [24] 2238 	movx	a,@dptr
      007D61 F5 82            [12] 2239 	mov	dpl,a
      007D63 22               [24] 2240 	ret
                                   2241 
                                   2242 	.area CSEG (CODE)
                                   2243 ; function ak820_outline_0081
      007D64                       2244 _ak820_outline_0081:
      007D64 2D               [12] 2245 	add	a,r5
      007D65 F8               [12] 2246 	mov	r0,a
      007D66 E4               [12] 2247 	clr	a
      007D67 3E               [12] 2248 	addc	a,r6
      007D68 F9               [12] 2249 	mov	r1,a
      007D69 8F 02            [24] 2250 	mov	ar2,r7
      007D6B 88 82            [24] 2251 	mov	dpl,r0
      007D6D 89 83            [24] 2252 	mov	dph,r1
      007D6F 8A F0            [24] 2253 	mov	b,r2
      007D71 22               [24] 2254 	ret
                                   2255 
                                   2256 	.area CSEG (CODE)
                                   2257 ; function ak820_outline_0090
      007D72                       2258 _ak820_outline_0090:
      007D72 90 08 96         [24] 2259 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D75 E0               [24] 2260 	movx	a,@dptr
      007D76 03               [12] 2261 	rr	a
      007D77 03               [12] 2262 	rr	a
      007D78 54 03            [12] 2263 	anl	a,#0x03
      007D7A 22               [24] 2264 	ret
                                   2265 
                                   2266 	.area CSEG (CODE)
                                   2267 ; function ak820_outline_0113
      007D7B                       2268 _ak820_outline_0113:
      007D7B 90 08 96         [24] 2269 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D7E E0               [24] 2270 	movx	a,@dptr
      007D7F 54 0F            [12] 2271 	anl	a,#0x0f
      007D81 22               [24] 2272 	ret
                                   2273 
                                   2274 	.area CSEG (CODE)
                                   2275 ; function ak820_outline_0131
      007D82                       2276 _ak820_outline_0131:
      007D82 90 08 95         [24] 2277 	mov	dptr,#_process_action_PARM_2
      007D85 E0               [24] 2278 	movx	a,@dptr
      007D86 FE               [12] 2279 	mov	r6,a
      007D87 A3               [24] 2280 	inc	dptr
      007D88 E0               [24] 2281 	movx	a,@dptr
      007D89 54 03            [12] 2282 	anl	a,#0x03
      007D8B FF               [12] 2283 	mov	r7,a
      007D8C 22               [24] 2284 	ret
                                   2285 
                                   2286 	.area CSEG (CODE)
                                   2287 ; function ak820_outline_0158
      007D8D                       2288 _ak820_outline_0158:
      007D8D 90 08 95         [24] 2289 	mov	dptr,#_process_action_PARM_2
      007D90 E0               [24] 2290 	movx	a,@dptr
      007D91 22               [24] 2291 	ret
                                   2292 
                                   2293 	.area CSEG (CODE)
                                   2294 ; function ak820_outline_0166
      007D92                       2295 _ak820_outline_0166:
      007D92 90 08 9B         [24] 2296 	mov	dptr,#_register_code_code_10000_720
      007D95 E0               [24] 2297 	movx	a,@dptr
      007D96 FF               [12] 2298 	mov	r7,a
      007D97 22               [24] 2299 	ret
                                   2300 
                                   2301 	.area CSEG (CODE)
                                   2302 ; function ak820_outline_0167
      007D98                       2303 _ak820_outline_0167:
      007D98 90 08 9C         [24] 2304 	mov	dptr,#_unregister_code_code_10000_734
      007D9B E0               [24] 2305 	movx	a,@dptr
      007D9C FF               [12] 2306 	mov	r7,a
      007D9D 22               [24] 2307 	ret
                                   2308 
                                   2309 	.area CSEG (CODE)
                                   2310 ; function ak820_outline_0186
      007D9E                       2311 _ak820_outline_0186:
      007D9E F0               [24] 2312 	movx	@dptr,a
      007D9F EB               [12] 2313 	mov	a,r3
      007DA0 A3               [24] 2314 	inc	dptr
      007DA1 F0               [24] 2315 	movx	@dptr,a
      007DA2 22               [24] 2316 	ret
                                   2317 
                                   2318 	.area CSEG (CODE)
                                   2319 ; function ak820_outline_0188
      007DA3                       2320 _ak820_outline_0188:
      007DA3 E4               [12] 2321 	clr	a
      007DA4 F0               [24] 2322 	movx	@dptr,a
      007DA5 8F 82            [24] 2323 	mov	dpl,r7
      007DA7 22               [24] 2324 	ret
