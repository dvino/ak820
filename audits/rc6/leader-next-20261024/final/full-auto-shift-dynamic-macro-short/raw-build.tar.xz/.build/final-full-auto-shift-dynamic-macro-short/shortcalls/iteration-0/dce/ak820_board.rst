                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_board
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_rgb_slots
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _ak820_rgb_set_color_all_PARM_3
                                    256 	.globl _ak820_rgb_set_color_all_PARM_2
                                    257 	.globl _ak820_rgb_set_color_PARM_4
                                    258 	.globl _ak820_rgb_set_color_PARM_3
                                    259 	.globl _ak820_rgb_set_color_PARM_2
                                    260 	.globl _ak820_set_slot_rgb_PARM_4
                                    261 	.globl _ak820_set_slot_rgb_PARM_3
                                    262 	.globl _ak820_set_slot_rgb_PARM_2
                                    263 	.globl _ak820_scan_sample
                                    264 	.globl _ak820_scan_ready
                                    265 	.globl _ak820_scan_rows
                                    266 	.globl _ak820_led_dma
                                    267 	.globl _ak820_clock_init
                                    268 	.globl _ak820_board_init
                                    269 	.globl _ak820_led_irq
                                    270 	.globl _ak820_matrix_snapshot
                                    271 	.globl _ak820_set_slot_rgb
                                    272 	.globl _ak820_rgb_set_color
                                    273 	.globl _ak820_rgb_set_color_all
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 	.area	OSEG    (OVR,DATA)
      000055                        540 _ak820_set_slot_rgb_sloc0_1_0:
      000055                        541 	.ds 1
                                    542 ;--------------------------------------------------------
                                    543 ; indirectly addressable internal ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area ISEG    (DATA)
                                    546 ;--------------------------------------------------------
                                    547 ; absolute internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area IABS    (ABS,DATA)
                                    550 	.area IABS    (ABS,DATA)
                                    551 ;--------------------------------------------------------
                                    552 ; bit data
                                    553 ;--------------------------------------------------------
                                    554 	.area BSEG    (BIT)
                                    555 ;--------------------------------------------------------
                                    556 ; paged external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area PSEG    (PAG,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; uninitialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XSEG    (XDATA)
                           000200   563 _ak820_led_dma	=	0x0200
      000410                        564 _ak820_scan_rows::
      000410                        565 	.ds 16
      000420                        566 _ak820_scan_ready::
      000420                        567 	.ds 1
      000421                        568 _ak820_scan_sample::
      000421                        569 	.ds 1
      000422                        570 _ak820_matrix_snapshot_rows_10000_62:
      000422                        571 	.ds 3
      000425                        572 _ak820_matrix_snapshot_changed_10000_63:
      000425                        573 	.ds 1
      000426                        574 _ak820_set_slot_rgb_PARM_2:
      000426                        575 	.ds 1
      000427                        576 _ak820_set_slot_rgb_PARM_3:
      000427                        577 	.ds 1
      000428                        578 _ak820_set_slot_rgb_PARM_4:
      000428                        579 	.ds 1
      000429                        580 _ak820_set_slot_rgb_slot_10000_72:
      000429                        581 	.ds 1
      00042A                        582 _ak820_rgb_set_color_PARM_2:
      00042A                        583 	.ds 1
      00042B                        584 _ak820_rgb_set_color_PARM_3:
      00042B                        585 	.ds 1
      00042C                        586 _ak820_rgb_set_color_PARM_4:
      00042C                        587 	.ds 1
      00042D                        588 _ak820_rgb_set_color_index_10000_202:
      00042D                        589 	.ds 1
      00042E                        590 _ak820_rgb_set_color_all_PARM_2:
      00042E                        591 	.ds 1
      00042F                        592 _ak820_rgb_set_color_all_PARM_3:
      00042F                        593 	.ds 1
      000430                        594 _ak820_rgb_set_color_all_r_10000_206:
      000430                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; absolute external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area XABS    (ABS,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; initialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XISEG   (XDATA)
                                    604 	.area HOME    (CODE)
                                    605 	.area GSINIT0 (CODE)
                                    606 	.area GSINIT1 (CODE)
                                    607 	.area GSINIT2 (CODE)
                                    608 	.area GSINIT3 (CODE)
                                    609 	.area GSINIT4 (CODE)
                                    610 	.area GSINIT5 (CODE)
                                    611 	.area GSINIT  (CODE)
                                    612 	.area GSFINAL (CODE)
                                    613 	.area CSEG    (CODE)
                                    614 ;--------------------------------------------------------
                                    615 ; global & static initialisations
                                    616 ;--------------------------------------------------------
                                    617 	.area HOME    (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; Home
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area HOME    (CODE)
                                    626 ;--------------------------------------------------------
                                    627 ; code
                                    628 ;--------------------------------------------------------
                                    629 	.area CSEG    (CODE)
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'ak820_clock_init'
                                    632 ;------------------------------------------------------------
                                    633 ;	keyboards/ajazz/ak820/ak820_board.c:40: void ak820_clock_init(void) __naked {
                                    634 ;	-----------------------------------------
                                    635 ;	 function ak820_clock_init
                                    636 ;	-----------------------------------------
      003350                        637 _ak820_clock_init:
                                    638 ;	naked function: no prologue.
                                    639 ;	keyboards/ajazz/ak820/ak820_board.c:55: __endasm;
      003350 75 A1 55         [24]  640 	mov 0xa1, #0x55
      003353 75 A1 AA         [24]  641 	mov 0xa1, #0xaa
      003356 43 B9 80         [24]  642 	orl 0xb9, #0x80
      003359 53 B9 BF         [24]  643 	anl 0xb9, #0xbf
      00335C 75 A1 55         [24]  644 	mov 0xa1, #0x55
      00335F 75 A1 AA         [24]  645 	mov 0xa1, #0xaa
      003362 E5 B9            [12]  646 	mov a, 0xb9
      003364 54 F8            [12]  647 	anl a, #0xf8
      003366 44 06            [12]  648 	orl a, #0x06
      003368 F5 B9            [12]  649 	mov 0xb9, a
      00336A E4               [12]  650 	clr a
      00336B F5 A1            [12]  651 	mov 0xa1, a
      00336D 22               [24]  652 	ret
                                    653 ;	keyboards/ajazz/ak820/ak820_board.c:56: }
                                    654 ;	naked function: no epilogue.
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'ak820_board_init'
                                    657 ;------------------------------------------------------------
                                    658 ;i             Allocated with name '_ak820_board_init_i_10000_55'
                                    659 ;------------------------------------------------------------
                                    660 ;	keyboards/ajazz/ak820/ak820_board.c:58: void ak820_board_init(void) {
                                    661 ;	-----------------------------------------
                                    662 ;	 function ak820_board_init
                                    663 ;	-----------------------------------------
      00336E                        664 _ak820_board_init:
                           000007   665 	ar7 = 0x07
                           000006   666 	ar6 = 0x06
                           000005   667 	ar5 = 0x05
                           000004   668 	ar4 = 0x04
                           000003   669 	ar3 = 0x03
                           000002   670 	ar2 = 0x02
                           000001   671 	ar1 = 0x01
                           000000   672 	ar0 = 0x00
                                    673 ;	keyboards/ajazz/ak820/ak820_board.c:61: IE_PWM_I2C = 0;
                                    674 ;	assignBit
      00336E C2 ED            [12]  675 	clr	_IE_PWM_I2C
                                    676 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      003370 7E 00            [12]  677 	mov	r6,#0x00
      003372 7F 00            [12]  678 	mov	r7,#0x00
      003374                        679 00103$:
                                    680 ;	keyboards/ajazz/ak820/ak820_board.c:63: ak820_led_dma[i] = 0;
      003374 8E 82            [24]  681 	mov	dpl,r6
      003376 74 02            [12]  682 	mov	a,#(_ak820_led_dma >> 8)
      003378 2F               [12]  683 	add	a,r7
      003379 F5 83            [12]  684 	mov	dph,a
      00337B E4               [12]  685 	clr	a
      00337C F0               [24]  686 	movx	@dptr,a
                                    687 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      00337D 0E               [12]  688 	inc	r6
      00337E BE 00 01         [24]  689 	cjne	r6,#0x00,00139$
      003381 0F               [12]  690 	inc	r7
      003382                        691 00139$:
      003382 8E 04            [24]  692 	mov	ar4,r6
      003384 8F 05            [24]  693 	mov	ar5,r7
      003386 74 FE            [12]  694 	mov	a,#0x100 - 0x02
      003388 2D               [12]  695 	add	a,r5
      003389 50 E9            [24]  696 	jnc	00103$
                                    697 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      00338B 7E 00            [12]  698 	mov	r6,#0x00
      00338D 7F 00            [12]  699 	mov	r7,#0x00
      00338F                        700 00105$:
                                    701 ;	keyboards/ajazz/ak820/ak820_board.c:66: ak820_scan_rows[i] = 0;
      00338F EE               [12]  702 	mov	a,r6
      003390 24 10            [12]  703 	add	a, #_ak820_scan_rows
      003392 F5 82            [12]  704 	mov	dpl,a
      003394 EF               [12]  705 	mov	a,r7
      003395 34 04            [12]  706 	addc	a, #(_ak820_scan_rows >> 8)
      003397 F5 83            [12]  707 	mov	dph,a
      003399 E4               [12]  708 	clr	a
      00339A F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      00339B 0E               [12]  711 	inc	r6
      00339C BE 00 01         [24]  712 	cjne	r6,#0x00,00141$
      00339F 0F               [12]  713 	inc	r7
      0033A0                        714 00141$:
      0033A0 8E 04            [24]  715 	mov	ar4,r6
      0033A2 8F 05            [24]  716 	mov	ar5,r7
      0033A4 C3               [12]  717 	clr	c
      0033A5 EC               [12]  718 	mov	a,r4
      0033A6 94 10            [12]  719 	subb	a,#0x10
      0033A8 ED               [12]  720 	mov	a,r5
      0033A9 94 00            [12]  721 	subb	a,#0x00
      0033AB 40 E2            [24]  722 	jc	00105$
                                    723 ;	keyboards/ajazz/ak820/ak820_board.c:68: ak820_scan_ready  = 0;
      0033AD 90 04 20         [24]  724 	mov	dptr,#_ak820_scan_ready
      0033B0 E4               [12]  725 	clr	a
      0033B1 F0               [24]  726 	movx	@dptr,a
                                    727 ;	keyboards/ajazz/ak820/ak820_board.c:69: ak820_scan_sample = 0;
      0033B2 90 04 21         [24]  728 	mov	dptr,#_ak820_scan_sample
      0033B5 F0               [24]  729 	movx	@dptr,a
                                    730 ;	keyboards/ajazz/ak820/ak820_board.c:72: P4 = P2 = P1 = P3 = P0 = 0xff;
      0033B6 75 80 FF         [24]  731 	mov	_P0,#0xff
      0033B9 75 B0 FF         [24]  732 	mov	_P3,#0xff
      0033BC 75 90 FF         [24]  733 	mov	_P1,#0xff
      0033BF 75 A0 FF         [24]  734 	mov	_P2,#0xff
      0033C2 75 C0 FF         [24]  735 	mov	_P4,#0xff
                                    736 ;	keyboards/ajazz/ak820/ak820_board.c:73: P1_MOD_OC = P2_MOD_OC = P4_MOD_OC = P3_MOD_OC = P0_MOD_OC = 0;
      0033C5 F5 C4            [12]  737 	mov	_P0_MOD_OC,a
      0033C7 F5 96            [12]  738 	mov	_P3_MOD_OC,a
      0033C9 F5 C2            [12]  739 	mov	_P4_MOD_OC,a
      0033CB F5 94            [12]  740 	mov	_P2_MOD_OC,a
      0033CD F5 92            [12]  741 	mov	_P1_MOD_OC,a
                                    742 ;	keyboards/ajazz/ak820/ak820_board.c:75: LED_CTRL    = 0x01;
      0033CF 90 21 D1         [24]  743 	mov	dptr,#0x21d1
      0033D2 04               [12]  744 	inc	a
      0033D3 F0               [24]  745 	movx	@dptr,a
                                    746 ;	keyboards/ajazz/ak820/ak820_board.c:76: LED_CYCLE   = 0x30;
      0033D4 A3               [24]  747 	inc	dptr
      0033D5 74 30            [12]  748 	mov	a,#0x30
      0033D7 F0               [24]  749 	movx	@dptr,a
                                    750 ;	keyboards/ajazz/ak820/ak820_board.c:77: LED_FRAME   = 0x50;
      0033D8 A3               [24]  751 	inc	dptr
      0033D9 74 50            [12]  752 	mov	a,#0x50
      0033DB F0               [24]  753 	movx	@dptr,a
                                    754 ;	keyboards/ajazz/ak820/ak820_board.c:78: LED_DMA_H   = AK820_LED_DMA_ADDRESS >> 8;
      0033DC 75 C7 02         [24]  755 	mov	_LED_DMA_H,#0x02
                                    756 ;	keyboards/ajazz/ak820/ak820_board.c:79: LED_DMA_L   = AK820_LED_DMA_ADDRESS & 0xff;
      0033DF 75 C6 00         [24]  757 	mov	_LED_DMA_L,#0x00
                                    758 ;	keyboards/ajazz/ak820/ak820_board.c:80: LED_INT_ADJ = 0;
      0033E2 90 21 D8         [24]  759 	mov	dptr,#0x21d8
      0033E5 E4               [12]  760 	clr	a
      0033E6 F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_board.c:81: LED_PWM_OE  = 0xff;
      0033E7 75 A7 FF         [24]  763 	mov	_LED_PWM_OE,#0xff
                                    764 ;	keyboards/ajazz/ak820/ak820_board.c:82: LED_COMMON  = 0xff;
      0033EA 75 A6 FF         [24]  765 	mov	_LED_COMMON,#0xff
                                    766 ;	keyboards/ajazz/ak820/ak820_board.c:83: LED_CTRL    = 0xfd;
      0033ED 90 21 D1         [24]  767 	mov	dptr,#0x21d1
      0033F0 74 FD            [12]  768 	mov	a,#0xfd
      0033F2 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_board.c:86: P7 = 0x03;
      0033F3 75 F1 03         [24]  771 	mov	_P7,#0x03
                                    772 ;	keyboards/ajazz/ak820/ak820_board.c:88: LED_STATUS |= 0x40;
      0033F6 43 F7 40         [24]  773 	orl	_LED_STATUS,#0x40
                                    774 ;	keyboards/ajazz/ak820/ak820_board.c:89: IE_PWM_I2C = 1;
                                    775 ;	assignBit
      0033F9 D2 ED            [12]  776 	setb	_IE_PWM_I2C
                                    777 ;	keyboards/ajazz/ak820/ak820_board.c:90: LED_RED_ADJ = LED_GRE_ADJ = LED_BLU_ADJ = 0;
      0033FB 90 21 DB         [24]  778 	mov	dptr,#0x21db
      0033FE E4               [12]  779 	clr	a
      0033FF F0               [24]  780 	movx	@dptr,a
      003400 15 82            [12]  781 	dec	dpl
      003402 F0               [24]  782 	movx	@dptr,a
      003403 15 82            [12]  783 	dec	dpl
      003405 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_board.c:91: }
      003406 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'ak820_led_irq'
                                    789 ;------------------------------------------------------------
                                    790 ;	keyboards/ajazz/ak820/ak820_board.c:101: void ak820_led_irq(void) __naked {
                                    791 ;	-----------------------------------------
                                    792 ;	 function ak820_led_irq
                                    793 ;	-----------------------------------------
      003407                        794 _ak820_led_irq:
                                    795 ;	naked function: no prologue.
                                    796 ;	keyboards/ajazz/ak820/ak820_board.c:267: __endasm;
      003407 05 A6            [12]  797 	inc 0xa6
      003409 E5 A6            [12]  798 	mov a, 0xa6
      00340B 54 0F            [12]  799 	anl a, #0x0f
      00340D FE               [12]  800 	mov r6, a
      00340E 70 09            [24]  801 	jnz 00001$
      003410 75 A6 10         [24]  802 	mov 0xa6, #0x10
      003413 75 C7 02         [24]  803 	mov 0xc7, #0x02
      003416 75 C6 00         [24]  804 	mov 0xc6, #0x00
      003419                        805 00001$:
      003419 12 34 74         [24]  806 	lcall 00010$
                                    807 ; Native D5ED..D617, only the sample XRAM address is relocated.
      00341C 75 C1 FF         [24]  808 	mov 0xc1, #0xff
      00341F 75 C2 FF         [24]  809 	mov 0xc2, #0xff
      003422 00               [12]  810 	nop
      003423 00               [12]  811 	nop
      003424 90 21 D1         [24]  812 	mov dptr, #0x21d1
      003427 E0               [24]  813 	movx a, @dptr
      003428 00               [12]  814 	nop
      003429 00               [12]  815 	nop
      00342A 00               [12]  816 	nop
      00342B 00               [12]  817 	nop
      00342C 00               [12]  818 	nop
      00342D 00               [12]  819 	nop
      00342E 00               [12]  820 	nop
      00342F 00               [12]  821 	nop
      003430 00               [12]  822 	nop
      003431 00               [12]  823 	nop
      003432 00               [12]  824 	nop
      003433 00               [12]  825 	nop
      003434 00               [12]  826 	nop
      003435 00               [12]  827 	nop
      003436 00               [12]  828 	nop
      003437 00               [12]  829 	nop
      003438 00               [12]  830 	nop
      003439 00               [12]  831 	nop
      00343A 00               [12]  832 	nop
      00343B 00               [12]  833 	nop
      00343C 00               [12]  834 	nop
      00343D 00               [12]  835 	nop
      00343E 00               [12]  836 	nop
      00343F 00               [12]  837 	nop
      003440 00               [12]  838 	nop
      003441 90 04 21         [24]  839 	mov dptr, #_ak820_scan_sample
      003444 E5 C0            [12]  840 	mov a, 0xc0
      003446 F0               [24]  841 	movx @dptr, a
      003447 E4               [12]  842 	clr a
      003448 F5 C2            [12]  843 	mov 0xc2, a
      00344A F5 C1            [12]  844 	mov 0xc1, a
      00344C 75 A7 FF         [24]  845 	mov 0xa7, #0xff
      00344F 75 B0 FF         [24]  846 	mov 0xb0, #0xff
      003452 75 80 FF         [24]  847 	mov 0x80, #0xff
      003455 90 04 21         [24]  848 	mov dptr, #_ak820_scan_sample
      003458 E0               [24]  849 	movx a, @dptr
      003459 F4               [12]  850 	cpl a
      00345A FD               [12]  851 	mov r5, a
      00345B 90 04 10         [24]  852 	mov dptr, #_ak820_scan_rows
      00345E E5 82            [12]  853 	mov a, dpl
      003460 2E               [12]  854 	add a, r6
      003461 F5 82            [12]  855 	mov dpl, a
      003463 E4               [12]  856 	clr a
      003464 35 83            [12]  857 	addc a, dph
      003466 F5 83            [12]  858 	mov dph, a
      003468 ED               [12]  859 	mov a, r5
      003469 F0               [24]  860 	movx @dptr, a
      00346A BE 0F 06         [24]  861 	cjne r6, #0x0f, 00002$
      00346D 90 04 20         [24]  862 	mov dptr, #_ak820_scan_ready
      003470 74 01            [12]  863 	mov a, #1
      003472 F0               [24]  864 	movx @dptr, a
      003473                        865 00002$:
      003473 22               [24]  866 	ret
                                    867 ; Native E274..E29D: the32 MOVX operations feed the peripheral DMA.
      003474                        868 00010$:
      003474 D2 AE            [12]  869 	setb 0xae
      003476 D2 D0            [12]  870 	setb 0xd0
      003478 E0               [24]  871 	movx a, @dptr
      003479 E0               [24]  872 	movx a, @dptr
      00347A E0               [24]  873 	movx a, @dptr
      00347B E0               [24]  874 	movx a, @dptr
      00347C E0               [24]  875 	movx a, @dptr
      00347D E0               [24]  876 	movx a, @dptr
      00347E E0               [24]  877 	movx a, @dptr
      00347F E0               [24]  878 	movx a, @dptr
      003480 00               [12]  879 	nop
      003481 E0               [24]  880 	movx a, @dptr
      003482 E0               [24]  881 	movx a, @dptr
      003483 E0               [24]  882 	movx a, @dptr
      003484 E0               [24]  883 	movx a, @dptr
      003485 E0               [24]  884 	movx a, @dptr
      003486 E0               [24]  885 	movx a, @dptr
      003487 E0               [24]  886 	movx a, @dptr
      003488 E0               [24]  887 	movx a, @dptr
      003489 00               [12]  888 	nop
      00348A E0               [24]  889 	movx a, @dptr
      00348B E0               [24]  890 	movx a, @dptr
      00348C E0               [24]  891 	movx a, @dptr
      00348D E0               [24]  892 	movx a, @dptr
      00348E E0               [24]  893 	movx a, @dptr
      00348F E0               [24]  894 	movx a, @dptr
      003490 E0               [24]  895 	movx a, @dptr
      003491 E0               [24]  896 	movx a, @dptr
      003492 00               [12]  897 	nop
      003493 E0               [24]  898 	movx a, @dptr
      003494 E0               [24]  899 	movx a, @dptr
      003495 E0               [24]  900 	movx a, @dptr
      003496 E0               [24]  901 	movx a, @dptr
      003497 E0               [24]  902 	movx a, @dptr
      003498 E0               [24]  903 	movx a, @dptr
      003499 E0               [24]  904 	movx a, @dptr
      00349A E0               [24]  905 	movx a, @dptr
      00349B C2 AE            [12]  906 	clr 0xae
                                    907 ; Native E29D..E2E0, with the jump table relocated locally.
      00349D E5 A6            [12]  908 	mov a, 0xa6
      00349F 10 E4 08         [24]  909 	jbc 0xe4, 00011$
      0034A2 54 01            [12]  910 	anl a, #1
      0034A4 04               [12]  911 	inc a
      0034A5 F4               [12]  912 	cpl a
      0034A6 14               [12]  913 	dec a
      0034A7 52 F1            [12]  914 	anl 0xf1, a
      0034A9 22               [24]  915 	ret
      0034AA                        916 00011$:
                                    917 ; The selector has sixteen entries even if the peripheral sets high bits.
      0034AA 54 0F            [12]  918 	anl a, #0x0f
      0034AC FF               [12]  919 	mov r7, a
      0034AD 2F               [12]  920 	add a, r7
      0034AE 2F               [12]  921 	add a, r7
      0034AF 90 34 B3         [24]  922 	mov dptr, #00012$
      0034B2 73               [24]  923 	jmp @a+dptr
      0034B3                        924 00012$:
      0034B3 C2 80            [12]  925 	clr 0x80
      0034B5 22               [24]  926 	ret
      0034B6 C2 81            [12]  927 	clr 0x81
      0034B8 22               [24]  928 	ret
      0034B9 C2 82            [12]  929 	clr 0x82
      0034BB 22               [24]  930 	ret
      0034BC C2 83            [12]  931 	clr 0x83
      0034BE 22               [24]  932 	ret
      0034BF C2 84            [12]  933 	clr 0x84
      0034C1 22               [24]  934 	ret
      0034C2 C2 85            [12]  935 	clr 0x85
      0034C4 22               [24]  936 	ret
      0034C5 C2 86            [12]  937 	clr 0x86
      0034C7 22               [24]  938 	ret
      0034C8 C2 87            [12]  939 	clr 0x87
      0034CA 22               [24]  940 	ret
      0034CB C2 B0            [12]  941 	clr 0xb0
      0034CD 22               [24]  942 	ret
      0034CE C2 B1            [12]  943 	clr 0xb1
      0034D0 22               [24]  944 	ret
      0034D1 C2 B2            [12]  945 	clr 0xb2
      0034D3 22               [24]  946 	ret
      0034D4 C2 B3            [12]  947 	clr 0xb3
      0034D6 22               [24]  948 	ret
      0034D7 C2 B4            [12]  949 	clr 0xb4
      0034D9 22               [24]  950 	ret
      0034DA C2 B5            [12]  951 	clr 0xb5
      0034DC 22               [24]  952 	ret
      0034DD C2 B6            [12]  953 	clr 0xb6
      0034DF 22               [24]  954 	ret
      0034E0 C2 B7            [12]  955 	clr 0xb7
      0034E2 22               [24]  956 	ret
                                    957 ;	keyboards/ajazz/ak820/ak820_board.c:268: }
                                    958 ;	naked function: no epilogue.
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'ak820_matrix_snapshot'
                                    961 ;------------------------------------------------------------
                                    962 ;rows          Allocated with name '_ak820_matrix_snapshot_rows_10000_62'
                                    963 ;row           Allocated with name '_ak820_matrix_snapshot_row_10000_63'
                                    964 ;value         Allocated with name '_ak820_matrix_snapshot_value_10000_63'
                                    965 ;irq_enabled   Allocated with name '_ak820_matrix_snapshot_irq_enabled_10000_63'
                                    966 ;changed       Allocated with name '_ak820_matrix_snapshot_changed_10000_63'
                                    967 ;------------------------------------------------------------
                                    968 ;	keyboards/ajazz/ak820/ak820_board.c:270: bool ak820_matrix_snapshot(uint8_t *rows) {
                                    969 ;	-----------------------------------------
                                    970 ;	 function ak820_matrix_snapshot
                                    971 ;	-----------------------------------------
      0034E3                        972 _ak820_matrix_snapshot:
      0034E3 AF F0            [24]  973 	mov	r7,b
      0034E5 AE 83            [24]  974 	mov	r6,dph
      0034E7 E5 82            [12]  975 	mov	a,dpl
      0034E9 90 04 22         [24]  976 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_62
      0034EC F0               [24]  977 	movx	@dptr,a
      0034ED EE               [12]  978 	mov	a,r6
      0034EE A3               [24]  979 	inc	dptr
      0034EF F0               [24]  980 	movx	@dptr,a
      0034F0 EF               [12]  981 	mov	a,r7
      0034F1 A3               [24]  982 	inc	dptr
      0034F2 F0               [24]  983 	movx	@dptr,a
                                    984 ;	keyboards/ajazz/ak820/ak820_board.c:274: bool changed = false;
      0034F3 90 04 25         [24]  985 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_63
      0034F6 E4               [12]  986 	clr	a
      0034F7 F0               [24]  987 	movx	@dptr,a
                                    988 ;	keyboards/ajazz/ak820/ak820_board.c:276: if (!ak820_scan_ready) {
      0034F8 90 04 20         [24]  989 	mov	dptr,#_ak820_scan_ready
      0034FB E0               [24]  990 	movx	a,@dptr
                                    991 ;	keyboards/ajazz/ak820/ak820_board.c:277: return false;
      0034FC 70 03            [24]  992 	jnz	00102$
      0034FE F5 82            [12]  993 	mov	dpl,a
      003500 22               [24]  994 	ret
      003501                        995 00102$:
                                    996 ;	keyboards/ajazz/ak820/ak820_board.c:281: irq_enabled = IE_EX & 0x20;
      003501 E5 E8            [12]  997 	mov	a,_IE_EX
      003503 54 20            [12]  998 	anl	a,#0x20
      003505 FF               [12]  999 	mov	r7,a
                                   1000 ;	keyboards/ajazz/ak820/ak820_board.c:282: IE_PWM_I2C = 0;
                                   1001 ;	assignBit
      003506 C2 ED            [12] 1002 	clr	_IE_PWM_I2C
                                   1003 ;	keyboards/ajazz/ak820/ak820_board.c:283: ak820_scan_ready = 0;
      003508 90 04 20         [24] 1004 	mov	dptr,#_ak820_scan_ready
      00350B E4               [12] 1005 	clr	a
      00350C F0               [24] 1006 	movx	@dptr,a
                                   1007 ;	keyboards/ajazz/ak820/ak820_board.c:284: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      00350D FE               [12] 1008 	mov	r6,a
      00350E                       1009 00108$:
                                   1010 ;	keyboards/ajazz/ak820/ak820_board.c:285: value = ak820_scan_rows[row];
      00350E EE               [12] 1011 	mov	a,r6
      00350F 24 10            [12] 1012 	add	a, #_ak820_scan_rows
      003511 F5 82            [12] 1013 	mov	dpl,a
      003513 E4               [12] 1014 	clr	a
      003514 34 04            [12] 1015 	addc	a, #(_ak820_scan_rows >> 8)
      003516 F5 83            [12] 1016 	mov	dph,a
      003518 E0               [24] 1017 	movx	a,@dptr
      003519 FD               [12] 1018 	mov	r5,a
                                   1019 ;	keyboards/ajazz/ak820/ak820_board.c:287: value &= ak820_matrix_mask[row];
      00351A EE               [12] 1020 	mov	a,r6
      00351B 90 BE 51         [24] 1021 	mov	dptr,#_ak820_matrix_mask
      00351E 93               [24] 1022 	movc	a,@a+dptr
      00351F 52 05            [12] 1023 	anl	ar5,a
                                   1024 ;	keyboards/ajazz/ak820/ak820_board.c:289: if (rows[row] != value) {
      003521 90 04 22         [24] 1025 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_62
      003524 E0               [24] 1026 	movx	a,@dptr
      003525 FA               [12] 1027 	mov	r2,a
      003526 A3               [24] 1028 	inc	dptr
      003527 E0               [24] 1029 	movx	a,@dptr
      003528 FB               [12] 1030 	mov	r3,a
      003529 A3               [24] 1031 	inc	dptr
      00352A E0               [24] 1032 	movx	a,@dptr
      00352B FC               [12] 1033 	mov	r4,a
      00352C EE               [12] 1034 	mov	a,r6
      00352D 2A               [12] 1035 	add	a, r2
      00352E FA               [12] 1036 	mov	r2,a
      00352F E4               [12] 1037 	clr	a
      003530 3B               [12] 1038 	addc	a, r3
      003531 FB               [12] 1039 	mov	r3,a
      003532 8A 82            [24] 1040 	mov	dpl,r2
      003534 8B 83            [24] 1041 	mov	dph,r3
      003536 8C F0            [24] 1042 	mov	b,r4
      003538 12 BE 31         [24] 1043 	lcall	__gptrget
      00353B B5 05 02         [24] 1044 	cjne	a,ar5,00149$
      00353E 80 10            [24] 1045 	sjmp	00109$
      003540                       1046 00149$:
                                   1047 ;	keyboards/ajazz/ak820/ak820_board.c:290: rows[row] = value;
      003540 8A 82            [24] 1048 	mov	dpl,r2
      003542 8B 83            [24] 1049 	mov	dph,r3
      003544 8C F0            [24] 1050 	mov	b,r4
      003546 ED               [12] 1051 	mov	a,r5
      003547 12 BD F6         [24] 1052 	lcall	__gptrput
                                   1053 ;	keyboards/ajazz/ak820/ak820_board.c:291: changed = true;
      00354A 90 04 25         [24] 1054 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_63
      00354D 74 01            [12] 1055 	mov	a,#0x01
      00354F F0               [24] 1056 	movx	@dptr,a
      003550                       1057 00109$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_board.c:284: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      003550 0E               [12] 1059 	inc	r6
      003551 BE 10 00         [24] 1060 	cjne	r6,#0x10,00150$
      003554                       1061 00150$:
      003554 40 B8            [24] 1062 	jc	00108$
                                   1063 ;	keyboards/ajazz/ak820/ak820_board.c:294: if (irq_enabled) {
      003556 EF               [12] 1064 	mov	a,r7
      003557 60 02            [24] 1065 	jz	00107$
                                   1066 ;	keyboards/ajazz/ak820/ak820_board.c:295: IE_PWM_I2C = 1;
                                   1067 ;	assignBit
      003559 D2 ED            [12] 1068 	setb	_IE_PWM_I2C
      00355B                       1069 00107$:
                                   1070 ;	keyboards/ajazz/ak820/ak820_board.c:297: return changed;
      00355B 90 04 25         [24] 1071 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_63
      00355E E0               [24] 1072 	movx	a,@dptr
                                   1073 ;	keyboards/ajazz/ak820/ak820_board.c:298: }
      00355F F5 82            [12] 1074 	mov	dpl,a
      003561 22               [24] 1075 	ret
                                   1076 ;------------------------------------------------------------
                                   1077 ;Allocation info for local variables in function 'ak820_set_slot_rgb'
                                   1078 ;------------------------------------------------------------
                                   1079 ;r             Allocated with name '_ak820_set_slot_rgb_PARM_2'
                                   1080 ;g             Allocated with name '_ak820_set_slot_rgb_PARM_3'
                                   1081 ;b             Allocated with name '_ak820_set_slot_rgb_PARM_4'
                                   1082 ;slot          Allocated with name '_ak820_set_slot_rgb_slot_10000_72'
                                   1083 ;offset        Allocated with name '_ak820_set_slot_rgb_offset_10000_73'
                                   1084 ;irq_enabled   Allocated with name '_ak820_set_slot_rgb_irq_enabled_10000_73'
                                   1085 ;sloc0         Allocated with name '_ak820_set_slot_rgb_sloc0_1_0'
                                   1086 ;------------------------------------------------------------
                                   1087 ;	keyboards/ajazz/ak820/ak820_board.c:300: void ak820_set_slot_rgb(uint8_t slot, uint8_t r, uint8_t g, uint8_t b) {
                                   1088 ;	-----------------------------------------
                                   1089 ;	 function ak820_set_slot_rgb
                                   1090 ;	-----------------------------------------
      003562                       1091 _ak820_set_slot_rgb:
      003562 E5 82            [12] 1092 	mov	a,dpl
      003564 90 04 29         [24] 1093 	mov	dptr,#_ak820_set_slot_rgb_slot_10000_72
      003567 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	keyboards/ajazz/ak820/ak820_board.c:303: if (slot >= AK820_SCAN_ROWS * AK820_SCAN_COLS) {
      003568 E0               [24] 1096 	movx	a,@dptr
      003569 FF               [12] 1097 	mov	r7,a
      00356A BF 80 00         [24] 1098 	cjne	r7,#0x80,00130$
      00356D                       1099 00130$:
      00356D 40 01            [24] 1100 	jc	00102$
                                   1101 ;	keyboards/ajazz/ak820/ak820_board.c:304: return;
      00356F 22               [24] 1102 	ret
      003570                       1103 00102$:
                                   1104 ;	keyboards/ajazz/ak820/ak820_board.c:306: offset = (uint16_t)slot * 4;
      003570 7E 00            [12] 1105 	mov	r6,#0x00
      003572 EF               [12] 1106 	mov	a,r7
      003573 2F               [12] 1107 	add	a,r7
      003574 FF               [12] 1108 	mov	r7,a
      003575 EE               [12] 1109 	mov	a,r6
      003576 33               [12] 1110 	rlc	a
      003577 FE               [12] 1111 	mov	r6,a
      003578 EF               [12] 1112 	mov	a,r7
      003579 2F               [12] 1113 	add	a,r7
      00357A FF               [12] 1114 	mov	r7,a
      00357B EE               [12] 1115 	mov	a,r6
      00357C 33               [12] 1116 	rlc	a
      00357D FE               [12] 1117 	mov	r6,a
                                   1118 ;	keyboards/ajazz/ak820/ak820_board.c:307: irq_enabled = IE_EX & 0x20;
      00357E E5 E8            [12] 1119 	mov	a,_IE_EX
      003580 54 20            [12] 1120 	anl	a,#0x20
      003582 FD               [12] 1121 	mov	r5,a
                                   1122 ;	keyboards/ajazz/ak820/ak820_board.c:308: IE_PWM_I2C = 0;
                                   1123 ;	assignBit
      003583 C2 ED            [12] 1124 	clr	_IE_PWM_I2C
                                   1125 ;	keyboards/ajazz/ak820/ak820_board.c:311: ak820_led_dma[offset]     = (r | g | b) ? 0xff : 0;
      003585 8F 03            [24] 1126 	mov	ar3,r7
      003587 74 02            [12] 1127 	mov	a,#(_ak820_led_dma >> 8)
      003589 2E               [12] 1128 	add	a,r6
      00358A FC               [12] 1129 	mov	r4,a
      00358B 90 04 27         [24] 1130 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      00358E E0               [24] 1131 	movx	a,@dptr
      00358F FA               [12] 1132 	mov	r2,a
      003590 90 04 26         [24] 1133 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      003593 E0               [24] 1134 	movx	a,@dptr
      003594 F9               [12] 1135 	mov	r1,a
      003595 4A               [12] 1136 	orl	a,r2
      003596 F8               [12] 1137 	mov	r0,a
      003597 90 04 28         [24] 1138 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      00359A E0               [24] 1139 	movx	a,@dptr
      00359B F5 55            [12] 1140 	mov	_ak820_set_slot_rgb_sloc0_1_0,a
      00359D 48               [12] 1141 	orl	a,r0
      00359E 60 02            [24] 1142 	jz	00107$
      0035A0 74 FF            [12] 1143 	mov	a,#0xff
      0035A2                       1144 00107$:
      0035A2 F8               [12] 1145 	mov	r0,a
      0035A3 12 36 47         [24] 1146 	lcall	_ak820_outline_0121
      0035A6 E8               [12] 1147 	mov	a,r0
      0035A7 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	keyboards/ajazz/ak820/ak820_board.c:312: ak820_led_dma[offset + 1] = r;
      0035A8 74 01            [12] 1150 	mov	a,#0x01
      0035AA 12 36 3A         [24] 1151 	lcall	_ak820_outline_0097
      0035AD E9               [12] 1152 	mov	a,r1
      0035AE F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	keyboards/ajazz/ak820/ak820_board.c:313: ak820_led_dma[offset + 2] = g;
      0035AF 74 02            [12] 1155 	mov	a,#0x02
      0035B1 12 36 3A         [24] 1156 	lcall	_ak820_outline_0097
      0035B4 EA               [12] 1157 	mov	a,r2
      0035B5 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	keyboards/ajazz/ak820/ak820_board.c:314: ak820_led_dma[offset + 3] = b;
      0035B6 74 03            [12] 1160 	mov	a,#0x03
      0035B8 2F               [12] 1161 	add	a, r7
      0035B9 FF               [12] 1162 	mov	r7,a
      0035BA E4               [12] 1163 	clr	a
      0035BB 3E               [12] 1164 	addc	a, r6
      0035BC FE               [12] 1165 	mov	r6,a
      0035BD 8F 82            [24] 1166 	mov	dpl,r7
      0035BF 74 02            [12] 1167 	mov	a,#(_ak820_led_dma >> 8)
      0035C1 2E               [12] 1168 	add	a,r6
      0035C2 F5 83            [12] 1169 	mov	dph,a
      0035C4 E5 55            [12] 1170 	mov	a,_ak820_set_slot_rgb_sloc0_1_0
      0035C6 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	keyboards/ajazz/ak820/ak820_board.c:315: if (irq_enabled) {
      0035C7 ED               [12] 1173 	mov	a,r5
      0035C8 60 02            [24] 1174 	jz	00105$
                                   1175 ;	keyboards/ajazz/ak820/ak820_board.c:316: IE_PWM_I2C = 1;
                                   1176 ;	assignBit
      0035CA D2 ED            [12] 1177 	setb	_IE_PWM_I2C
      0035CC                       1178 00105$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_board.c:318: }
      0035CC 22               [24] 1180 	ret
                                   1181 ;------------------------------------------------------------
                                   1182 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                   1183 ;------------------------------------------------------------
                                   1184 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_200'
                                   1185 ;------------------------------------------------------------
                                   1186 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                   1187 ;	-----------------------------------------
                                   1188 ;	 function ak820_rgb_set_color
                                   1189 ;	-----------------------------------------
      0035CD                       1190 _ak820_rgb_set_color:
      0035CD E5 82            [12] 1191 	mov	a,dpl
      0035CF 90 04 2D         [24] 1192 	mov	dptr,#_ak820_rgb_set_color_index_10000_202
      0035D2 F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	keyboards/ajazz/ak820/ak820_board.c:333: if (index >= RGB_MATRIX_LED_COUNT) {
      0035D3 E0               [24] 1195 	movx	a,@dptr
      0035D4 FF               [12] 1196 	mov	r7,a
      0035D5 BF 52 00         [24] 1197 	cjne	r7,#0x52,00112$
      0035D8                       1198 00112$:
      0035D8 40 01            [24] 1199 	jc	00102$
                                   1200 ;	keyboards/ajazz/ak820/ak820_board.c:334: return;
      0035DA 22               [24] 1201 	ret
      0035DB                       1202 00102$:
                                   1203 ;	keyboards/ajazz/ak820/ak820_board.c:337: ak820_set_slot_rgb(ak820_rgb_slots[index], r, g, b);
      0035DB EF               [12] 1204 	mov	a,r7
      0035DC 90 BE 61         [24] 1205 	mov	dptr,#_ak820_rgb_slots
      0035DF 93               [24] 1206 	movc	a,@a+dptr
      0035E0 FF               [12] 1207 	mov	r7,a
      0035E1 90 04 2A         [24] 1208 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0035E4 E0               [24] 1209 	movx	a,@dptr
      0035E5 FE               [12] 1210 	mov	r6,a
      0035E6 90 04 2B         [24] 1211 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0035E9 E0               [24] 1212 	movx	a,@dptr
      0035EA FD               [12] 1213 	mov	r5,a
      0035EB 90 04 2C         [24] 1214 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0035EE E0               [24] 1215 	movx	a,@dptr
      0035EF FC               [12] 1216 	mov	r4,a
      0035F0 90 04 26         [24] 1217 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      0035F3 EE               [12] 1218 	mov	a,r6
      0035F4 F0               [24] 1219 	movx	@dptr,a
      0035F5 90 04 27         [24] 1220 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      0035F8 ED               [12] 1221 	mov	a,r5
      0035F9 F0               [24] 1222 	movx	@dptr,a
      0035FA 90 04 28         [24] 1223 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      0035FD EC               [12] 1224 	mov	a,r4
      0035FE F0               [24] 1225 	movx	@dptr,a
      0035FF 8F 82            [24] 1226 	mov	dpl, r7
                                   1227 ;	keyboards/ajazz/ak820/ak820_board.c:341: }
      003601 02 35 62         [24] 1228 	ljmp	_ak820_set_slot_rgb
                                   1229 ;------------------------------------------------------------
                                   1230 ;Allocation info for local variables in function 'ak820_rgb_set_color_all'
                                   1231 ;------------------------------------------------------------
                                   1232 ;g             Allocated with name '_ak820_rgb_set_color_all_PARM_2'
                                   1233 ;b             Allocated with name '_ak820_rgb_set_color_all_PARM_3'
                                   1234 ;r             Allocated with name '_ak820_rgb_set_color_all_r_10000_206'
                                   1235 ;i             Allocated with name '_ak820_rgb_set_color_all_i_10000_207'
                                   1236 ;------------------------------------------------------------
                                   1237 ;	keyboards/ajazz/ak820/ak820_board.c:343: void ak820_rgb_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1238 ;	-----------------------------------------
                                   1239 ;	 function ak820_rgb_set_color_all
                                   1240 ;	-----------------------------------------
      003604                       1241 _ak820_rgb_set_color_all:
      003604 E5 82            [12] 1242 	mov	a,dpl
      003606 90 04 30         [24] 1243 	mov	dptr,#_ak820_rgb_set_color_all_r_10000_206
      003609 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	keyboards/ajazz/ak820/ak820_board.c:345: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00360A 7F 00            [12] 1246 	mov	r7,#0x00
      00360C                       1247 00102$:
                                   1248 ;	keyboards/ajazz/ak820/ak820_board.c:346: ak820_rgb_set_color(i, r, g, b);
      00360C 90 04 30         [24] 1249 	mov	dptr,#_ak820_rgb_set_color_all_r_10000_206
      00360F E0               [24] 1250 	movx	a,@dptr
      003610 FE               [12] 1251 	mov	r6,a
      003611 90 04 2E         [24] 1252 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      003614 E0               [24] 1253 	movx	a,@dptr
      003615 FD               [12] 1254 	mov	r5,a
      003616 90 04 2F         [24] 1255 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      003619 E0               [24] 1256 	movx	a,@dptr
      00361A FC               [12] 1257 	mov	r4,a
      00361B 90 04 2A         [24] 1258 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      00361E EE               [12] 1259 	mov	a,r6
      00361F F0               [24] 1260 	movx	@dptr,a
      003620 90 04 2B         [24] 1261 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      003623 ED               [12] 1262 	mov	a,r5
      003624 F0               [24] 1263 	movx	@dptr,a
      003625 90 04 2C         [24] 1264 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      003628 EC               [12] 1265 	mov	a,r4
      003629 F0               [24] 1266 	movx	@dptr,a
      00362A 8F 82            [24] 1267 	mov	dpl, r7
      00362C C0 07            [24] 1268 	push	ar7
      00362E 12 35 CD         [24] 1269 	lcall	_ak820_rgb_set_color
      003631 D0 07            [24] 1270 	pop	ar7
                                   1271 ;	keyboards/ajazz/ak820/ak820_board.c:345: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      003633 0F               [12] 1272 	inc	r7
      003634 BF 52 00         [24] 1273 	cjne	r7,#0x52,00114$
      003637                       1274 00114$:
      003637 40 D3            [24] 1275 	jc	00102$
                                   1276 ;	keyboards/ajazz/ak820/ak820_board.c:348: }
      003639 22               [24] 1277 	ret
                                   1278 	.area CSEG    (CODE)
                                   1279 	.area CONST   (CODE)
                                   1280 	.area CONST   (CODE)
      00BE51                       1281 _ak820_matrix_mask:
      00BE51 3F                    1282 	.db #0x3f	; 63
      00BE52 2F                    1283 	.db #0x2f	; 47
      00BE53 3F                    1284 	.db #0x3f	; 63
      00BE54 1F                    1285 	.db #0x1f	; 31
      00BE55 1F                    1286 	.db #0x1f	; 31
      00BE56 3F                    1287 	.db #0x3f	; 63
      00BE57 1F                    1288 	.db #0x1f	; 31
      00BE58 1F                    1289 	.db #0x1f	; 31
      00BE59 1F                    1290 	.db #0x1f	; 31
      00BE5A 3F                    1291 	.db #0x3f	; 63
      00BE5B 3F                    1292 	.db #0x3f	; 63
      00BE5C 3F                    1293 	.db #0x3f	; 63
      00BE5D 07                    1294 	.db #0x07	; 7
      00BE5E 3F                    1295 	.db #0x3f	; 63
      00BE5F 3C                    1296 	.db #0x3c	; 60
      00BE60 2E                    1297 	.db #0x2e	; 46
                                   1298 	.area CSEG    (CODE)
                                   1299 	.area CONST   (CODE)
      00BE61                       1300 _ak820_rgb_slots:
      00BE61 00                    1301 	.db #0x00	; 0
      00BE62 08                    1302 	.db #0x08	; 8
      00BE63 10                    1303 	.db #0x10	; 16
      00BE64 18                    1304 	.db #0x18	; 24
      00BE65 20                    1305 	.db #0x20	; 32
      00BE66 28                    1306 	.db #0x28	; 40
      00BE67 30                    1307 	.db #0x30	; 48	'0'
      00BE68 38                    1308 	.db #0x38	; 56	'8'
      00BE69 40                    1309 	.db #0x40	; 64
      00BE6A 48                    1310 	.db #0x48	; 72	'H'
      00BE6B 50                    1311 	.db #0x50	; 80	'P'
      00BE6C 58                    1312 	.db #0x58	; 88	'X'
      00BE6D 60                    1313 	.db #0x60	; 96
      00BE6E 72                    1314 	.db #0x72	; 114	'r'
      00BE6F 01                    1315 	.db #0x01	; 1
      00BE70 09                    1316 	.db #0x09	; 9
      00BE71 11                    1317 	.db #0x11	; 17
      00BE72 19                    1318 	.db #0x19	; 25
      00BE73 21                    1319 	.db #0x21	; 33
      00BE74 29                    1320 	.db #0x29	; 41
      00BE75 31                    1321 	.db #0x31	; 49	'1'
      00BE76 39                    1322 	.db #0x39	; 57	'9'
      00BE77 41                    1323 	.db #0x41	; 65	'A'
      00BE78 49                    1324 	.db #0x49	; 73	'I'
      00BE79 51                    1325 	.db #0x51	; 81	'Q'
      00BE7A 59                    1326 	.db #0x59	; 89	'Y'
      00BE7B 61                    1327 	.db #0x61	; 97	'a'
      00BE7C 69                    1328 	.db #0x69	; 105	'i'
      00BE7D 79                    1329 	.db #0x79	; 121	'y'
      00BE7E 02                    1330 	.db #0x02	; 2
      00BE7F 0A                    1331 	.db #0x0a	; 10
      00BE80 12                    1332 	.db #0x12	; 18
      00BE81 1A                    1333 	.db #0x1a	; 26
      00BE82 22                    1334 	.db #0x22	; 34
      00BE83 2A                    1335 	.db #0x2a	; 42
      00BE84 32                    1336 	.db #0x32	; 50	'2'
      00BE85 3A                    1337 	.db #0x3a	; 58
      00BE86 42                    1338 	.db #0x42	; 66	'B'
      00BE87 4A                    1339 	.db #0x4a	; 74	'J'
      00BE88 52                    1340 	.db #0x52	; 82	'R'
      00BE89 5A                    1341 	.db #0x5a	; 90	'Z'
      00BE8A 62                    1342 	.db #0x62	; 98	'b'
      00BE8B 6A                    1343 	.db #0x6a	; 106	'j'
      00BE8C 7A                    1344 	.db #0x7a	; 122	'z'
      00BE8D 03                    1345 	.db #0x03	; 3
      00BE8E 0B                    1346 	.db #0x0b	; 11
      00BE8F 13                    1347 	.db #0x13	; 19
      00BE90 1B                    1348 	.db #0x1b	; 27
      00BE91 23                    1349 	.db #0x23	; 35
      00BE92 2B                    1350 	.db #0x2b	; 43
      00BE93 33                    1351 	.db #0x33	; 51	'3'
      00BE94 3B                    1352 	.db #0x3b	; 59
      00BE95 43                    1353 	.db #0x43	; 67	'C'
      00BE96 4B                    1354 	.db #0x4b	; 75	'K'
      00BE97 53                    1355 	.db #0x53	; 83	'S'
      00BE98 5B                    1356 	.db #0x5b	; 91
      00BE99 6B                    1357 	.db #0x6b	; 107	'k'
      00BE9A 73                    1358 	.db #0x73	; 115	's'
      00BE9B 04                    1359 	.db #0x04	; 4
      00BE9C 14                    1360 	.db #0x14	; 20
      00BE9D 1C                    1361 	.db #0x1c	; 28
      00BE9E 24                    1362 	.db #0x24	; 36
      00BE9F 2C                    1363 	.db #0x2c	; 44
      00BEA0 34                    1364 	.db #0x34	; 52	'4'
      00BEA1 3C                    1365 	.db #0x3c	; 60
      00BEA2 44                    1366 	.db #0x44	; 68	'D'
      00BEA3 4C                    1367 	.db #0x4c	; 76	'L'
      00BEA4 54                    1368 	.db #0x54	; 84	'T'
      00BEA5 5C                    1369 	.db #0x5c	; 92
      00BEA6 6C                    1370 	.db #0x6c	; 108	'l'
      00BEA7 74                    1371 	.db #0x74	; 116	't'
      00BEA8 7B                    1372 	.db #0x7b	; 123
      00BEA9 05                    1373 	.db #0x05	; 5
      00BEAA 0D                    1374 	.db #0x0d	; 13
      00BEAB 15                    1375 	.db #0x15	; 21
      00BEAC 2D                    1376 	.db #0x2d	; 45
      00BEAD 4D                    1377 	.db #0x4d	; 77	'M'
      00BEAE 55                    1378 	.db #0x55	; 85	'U'
      00BEAF 5D                    1379 	.db #0x5d	; 93
      00BEB0 6D                    1380 	.db #0x6d	; 109	'm'
      00BEB1 75                    1381 	.db #0x75	; 117	'u'
      00BEB2 7D                    1382 	.db #0x7d	; 125
                                   1383 	.area CSEG    (CODE)
                                   1384 	.area XINIT   (CODE)
                                   1385 	.area CABS    (ABS,CODE)
                                   1386 
                                   1387 ; Experimental exact instruction outlining.
                                   1388 	.globl _ak820_outline_0097
                                   1389 	.globl _ak820_outline_0121
                                   1390 
                                   1391 	.area CSEG (CODE)
                                   1392 ; function ak820_outline_0097
      00363A                       1393 _ak820_outline_0097:
      00363A 2F               [12] 1394 	add	a,r7
      00363B FB               [12] 1395 	mov	r3,a
      00363C E4               [12] 1396 	clr	a
      00363D 3E               [12] 1397 	addc	a,r6
      00363E FC               [12] 1398 	mov	r4,a
      00363F 8B 82            [24] 1399 	mov	dpl,r3
      003641 74 02            [12] 1400 	mov	a,#(_ak820_led_dma>>8)
      003643 2C               [12] 1401 	add	a,r4
      003644 F5 83            [12] 1402 	mov	dph,a
      003646 22               [24] 1403 	ret
                                   1404 
                                   1405 	.area CSEG (CODE)
                                   1406 ; function ak820_outline_0121
      003647                       1407 _ak820_outline_0121:
      003647 8B 82            [24] 1408 	mov	dpl,r3
      003649 8C 83            [24] 1409 	mov	dph,r4
      00364B 22               [24] 1410 	ret
