                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000039                        553 _raw_hid_receive_sloc0_1_0:
      000039                        554 	.ds 4
      00003D                        555 _raw_hid_receive_sloc1_1_0:
      00003D                        556 	.ds 1
      00003E                        557 _raw_hid_receive_sloc2_1_0:
      00003E                        558 	.ds 1
      00003F                        559 _raw_hid_receive_sloc3_1_0:
      00003F                        560 	.ds 2
      000041                        561 _raw_hid_receive_sloc4_1_0:
      000041                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      00002C                        579 _via_eeprom_is_valid_sloc0_1_0:
      00002C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000CA7                        589 _via_eeprom_set_valid_valid_10000_609:
      000CA7                        590 	.ds 1
      000CA8                        591 _via_set_layout_options_value_10000_625:
      000CA8                        592 	.ds 4
      000CAC                        593 _process_record_via_PARM_2:
      000CAC                        594 	.ds 3
      000CAF                        595 _process_record_via_keycode_10000_627:
      000CAF                        596 	.ds 2
      000CB1                        597 _raw_hid_receive_kb_PARM_2:
      000CB1                        598 	.ds 1
      000CB2                        599 _raw_hid_receive_kb_data_10000_633:
      000CB2                        600 	.ds 3
      000CB5                        601 _raw_hid_receive_PARM_2:
      000CB5                        602 	.ds 1
      000CB6                        603 _raw_hid_receive_packet_10000_635:
      000CB6                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00AAEF                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00AAEF 90 00 25         [24]  658 	mov	dptr,#0x0025
      00AAF2 75 F0 00         [24]  659 	mov	b, #0x00
      00AAF5 12 46 01         [24]  660 	lcall	_eeprom_read_byte
      00AAF8 AF 82            [24]  661 	mov	r7, dpl
      00AAFA BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00AAFD 90 00 26         [24]  663 	mov	dptr,#0x0026
      00AB00 75 F0 00         [24]  664 	mov	b, #0x00
      00AB03 12 46 01         [24]  665 	lcall	_eeprom_read_byte
      00AB06 AF 82            [24]  666 	mov	r7, dpl
      00AB08 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00AB0B 90 00 27         [24]  668 	mov	dptr,#0x0027
      00AB0E 75 F0 00         [24]  669 	mov	b, #0x00
      00AB11 12 46 01         [24]  670 	lcall	_eeprom_read_byte
      00AB14 AF 82            [24]  671 	mov	r7, dpl
      00AB16 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00AB19 80 04            [24]  673 	sjmp	00104$
      00AB1B                        674 00126$:
      00AB1B                        675 00103$:
                                    676 ;	assignBit
      00AB1B C2 2C            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00AB1D 80 02            [24]  678 	sjmp	00105$
      00AB1F                        679 00104$:
                                    680 ;	assignBit
      00AB1F D2 2C            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00AB21                        682 00105$:
      00AB21 A2 2C            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00AB23 12 3A F6         [24]  684 	lcall	_ak820_outline_0156
                                    685 ;	quantum/via.c:104: }
      00AB26 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00AB27                        699 _via_eeprom_set_valid:
      00AB27 E5 82            [12]  700 	mov	a,dpl
      00AB29 90 0C A7         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB2C F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00AB2D E0               [24]  704 	movx	a,@dptr
      00AB2E 60 04            [24]  705 	jz	00103$
      00AB30 7F 02            [12]  706 	mov	r7,#0x02
      00AB32 80 02            [24]  707 	sjmp	00104$
      00AB34                        708 00103$:
      00AB34 7F FF            [12]  709 	mov	r7,#0xff
      00AB36                        710 00104$:
      00AB36 90 07 01         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB39 EF               [12]  712 	mov	a,r7
      00AB3A F0               [24]  713 	movx	@dptr,a
      00AB3B 90 00 25         [24]  714 	mov	dptr,#0x0025
      00AB3E 75 F0 00         [24]  715 	mov	b, #0x00
      00AB41 12 53 78         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00AB44 90 0C A7         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB47 E0               [24]  719 	movx	a,@dptr
      00AB48 60 04            [24]  720 	jz	00105$
      00AB4A 7F 20            [12]  721 	mov	r7,#0x20
      00AB4C 80 02            [24]  722 	sjmp	00106$
      00AB4E                        723 00105$:
      00AB4E 7F FF            [12]  724 	mov	r7,#0xff
      00AB50                        725 00106$:
      00AB50 90 07 01         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB53 EF               [12]  727 	mov	a,r7
      00AB54 F0               [24]  728 	movx	@dptr,a
      00AB55 90 00 26         [24]  729 	mov	dptr,#0x0026
      00AB58 75 F0 00         [24]  730 	mov	b, #0x00
      00AB5B 12 53 78         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00AB5E 90 0C A7         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00AB61 E0               [24]  734 	movx	a,@dptr
      00AB62 60 04            [24]  735 	jz	00107$
      00AB64 7F 08            [12]  736 	mov	r7,#0x08
      00AB66 80 02            [24]  737 	sjmp	00108$
      00AB68                        738 00107$:
      00AB68 7F FF            [12]  739 	mov	r7,#0xff
      00AB6A                        740 00108$:
      00AB6A 90 07 01         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00AB6D EF               [12]  742 	mov	a,r7
      00AB6E F0               [24]  743 	movx	@dptr,a
      00AB6F 90 00 27         [24]  744 	mov	dptr,#0x0027
      00AB72 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00AB75 02 53 78         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00AB78                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00AB78 71 9B            [12]  757 	acall	_via_get_layout_options
      00AB7A 71 B3            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00AB7C 51 EF            [12]  760 	acall	_via_eeprom_is_valid
      00AB7E E5 82            [12]  761 	mov	a, dpl
      00AB80 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00AB82 02 43 B0         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00AB85                        766 00103$:
      00AB85 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00AB86                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00AB86 75 82 00         [24]  777 	mov	dpl, #0x00
      00AB89 71 27            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00AB8B 12 96 20         [24]  780 	lcall	_ak820_outline_0152
      00AB8E 71 B4            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00AB90 12 8C C2         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00AB93 12 91 2E         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00AB96 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00AB99 61 27            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00AB9B                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00AB9B 90 00 28         [24]  799 	mov	dptr,#0x0028
      00AB9E 75 F0 00         [24]  800 	mov	b, #0x00
      00ABA1 12 46 01         [24]  801 	lcall	_eeprom_read_byte
      00ABA4 AF 82            [24]  802 	mov	r7, dpl
      00ABA6 7E 00            [12]  803 	mov	r6,#0x00
      00ABA8 7D 00            [12]  804 	mov	r5,#0x00
      00ABAA 7C 00            [12]  805 	mov	r4,#0x00
      00ABAC 12 48 FF         [24]  806 	lcall	_ak820_outline_0157
      00ABAF 8D F0            [24]  807 	mov	b, r5
      00ABB1 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00ABB2 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00ABB3                        820 _via_set_layout_options_kb:
      00ABB3 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00ABB4                        831 _via_set_layout_options:
      00ABB4 12 96 18         [24]  832 	lcall	_ak820_outline_0120
      00ABB7 90 0C A8         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00ABBA 12 96 06         [24]  834 	lcall	_ak820_outline_0044
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00ABBD 90 0C A8         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00ABC0 E0               [24]  837 	movx	a,@dptr
      00ABC1 90 07 01         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00ABC4 F0               [24]  839 	movx	@dptr,a
      00ABC5 90 00 28         [24]  840 	mov	dptr,#0x0028
      00ABC8 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00ABCB 02 53 78         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00ABCE                        855 _process_record_via:
      00ABCE 12 3A C2         [24]  856 	lcall	_ak820_outline_0108
      00ABD1 90 0C AF         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00ABD4 12 3A C7         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00ABD7 90 0C AC         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00ABDA 12 54 84         [24]  861 	lcall	_ak820_outline_0013
      00ABDD 74 05            [12]  862 	mov	a,#0x05
      00ABDF 12 3A FB         [24]  863 	lcall	_ak820_outline_0159
      00ABE2 12 72 FC         [24]  864 	lcall	_ak820_outline_0050
      00ABE5 12 BE 40         [24]  865 	lcall	__gptrget
      00ABE8 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00ABEA 90 0C AF         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00ABED 12 4D AC         [24]  869 	lcall	_ak820_outline_0009
      00ABF0 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00ABF2 2D               [12]  871 	add	a,r5
      00ABF3 50 12            [24]  872 	jnc	00105$
      00ABF5 C3               [12]  873 	clr	c
      00ABF6 74 7F            [12]  874 	mov	a,#0x7f
      00ABF8 9C               [12]  875 	subb	a,r4
      00ABF9 74 77            [12]  876 	mov	a,#0x77
      00ABFB 9D               [12]  877 	subb	a,r5
      00ABFC 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00ABFE 8E 82            [24]  882 	mov	dpl, r6
      00AC00 12 91 54         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00AC03 75 82 00         [24]  885 	mov	dpl, #0x00
      00AC06 22               [24]  886 	ret
      00AC07                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00AC07 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00AC0A 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00AC0B                        903 _raw_hid_receive_kb:
      00AC0B 12 48 A0         [24]  904 	lcall	_ak820_outline_0037
      00AC0E 90 0C B2         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AC11 12 3A 69         [24]  906 	lcall	_ak820_outline_0017
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00AC14 90 0C B2         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00AC17 12 54 5E         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00AC1A 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00AC1C 02 BE 05         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00AC1F                        950 _raw_hid_receive:
      00AC1F 12 48 A0         [24]  951 	lcall	_ak820_outline_0037
      00AC22 90 0C B6         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AC25 12 3A 69         [24]  953 	lcall	_ak820_outline_0017
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00AC28 90 0C B6         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00AC2B 12 3A 81         [24]  956 	lcall	_ak820_outline_0052
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00AC2E 74 01            [12]  958 	mov	a,#0x01
      00AC30 12 49 04         [24]  959 	lcall	_ak820_outline_0160
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00AC33 90 0C B5         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00AC36 E0               [24]  962 	movx	a,@dptr
      00AC37 FB               [12]  963 	mov	r3,a
      00AC38 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00AC3B 80 01            [24]  965 	sjmp	00102$
      00AC3D                        966 00520$:
      00AC3D 22               [24]  967 	ret
      00AC3E                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00AC3E 90 0E 85         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00AC41 E0               [24]  971 	movx	a,@dptr
      00AC42 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00AC44 12 3A CC         [24]  974 	lcall	_ak820_outline_0118
      00AC47 E0               [24]  975 	movx	a,@dptr
      00AC48 FA               [12]  976 	mov	r2,a
      00AC49 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00AC4C 80 01            [24]  978 	sjmp	00104$
      00AC4E                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00AC4E 22               [24]  981 	ret
      00AC4F                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00AC4F 12 48 D1         [24]  984 	lcall	_ak820_outline_0096
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00AC52 FA               [12]  986 	mov	r2,a
      00AC53 60 21            [24]  987 	jz	00114$
      00AC55 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00AC58 80 1C            [24]  989 	sjmp	00114$
      00AC5A                        990 00524$:
      00AC5A BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00AC5D 80 17            [24]  992 	sjmp	00114$
      00AC5F                        993 00525$:
      00AC5F BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00AC62 80 12            [24]  995 	sjmp	00114$
      00AC64                        996 00526$:
      00AC64 BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00AC67 80 0D            [24]  998 	sjmp	00114$
      00AC69                        999 00527$:
      00AC69 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00AC6C 80 08            [24] 1001 	sjmp	00114$
      00AC6E                       1002 00528$:
      00AC6E BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00AC71 80 03            [24] 1004 	sjmp	00530$
      00AC73                       1005 00529$:
      00AC73 02 B1 97         [24] 1006 	ljmp	00171$
      00AC76                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00AC76                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00AC76 12 3A CC         [24] 1011 	lcall	_ak820_outline_0118
      00AC79 E0               [24] 1012 	movx	a,@dptr
      00AC7A FA               [12] 1013 	mov	r2,a
      00AC7B BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00AC7E 80 68            [24] 1015 	sjmp	00115$
      00AC80                       1016 00531$:
      00AC80 BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00AC83 80 70            [24] 1018 	sjmp	00116$
      00AC85                       1019 00532$:
      00AC85 BA 03 02         [24] 1020 	cjne	r2,#0x03,00533$
      00AC88 A1 B3            [24] 1021 	ajmp	00125$
      00AC8A                       1022 00533$:
      00AC8A BA 04 02         [24] 1023 	cjne	r2,#0x04,00534$
      00AC8D C1 47            [12] 1024 	ajmp	00129$
      00AC8F                       1025 00534$:
      00AC8F BA 05 02         [24] 1026 	cjne	r2,#0x05,00535$
      00AC92 C1 81            [12] 1027 	ajmp	00130$
      00AC94                       1028 00535$:
      00AC94 BA 06 02         [24] 1029 	cjne	r2,#0x06,00536$
      00AC97 C1 ED            [12] 1030 	ajmp	00135$
      00AC99                       1031 00536$:
      00AC99 BA 07 02         [24] 1032 	cjne	r2,#0x07,00537$
      00AC9C C1 FF            [12] 1033 	ajmp	00136$
      00AC9E                       1034 00537$:
      00AC9E BA 08 02         [24] 1035 	cjne	r2,#0x08,00538$
      00ACA1 E1 1A            [12] 1036 	ajmp	00137$
      00ACA3                       1037 00538$:
      00ACA3 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00ACA6 02 AF 35         [24] 1039 	ljmp	00138$
      00ACA9                       1040 00539$:
      00ACA9 BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00ACAC 02 B1 27         [24] 1042 	ljmp	00161$
      00ACAF                       1043 00540$:
      00ACAF BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00ACB2 02 AF 50         [24] 1045 	ljmp	00139$
      00ACB5                       1046 00541$:
      00ACB5 BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00ACB8 02 AF 71         [24] 1048 	ljmp	00140$
      00ACBB                       1049 00542$:
      00ACBB BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00ACBE 02 AF 9A         [24] 1051 	ljmp	00141$
      00ACC1                       1052 00543$:
      00ACC1 BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00ACC4 02 AF E2         [24] 1054 	ljmp	00144$
      00ACC7                       1055 00544$:
      00ACC7 BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00ACCA 02 B0 50         [24] 1057 	ljmp	00151$
      00ACCD                       1058 00545$:
      00ACCD BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00ACD0 02 B0 68         [24] 1060 	ljmp	00154$
      00ACD3                       1061 00546$:
      00ACD3 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00ACD6 02 B0 88         [24] 1063 	ljmp	00155$
      00ACD9                       1064 00547$:
      00ACD9 BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00ACDC 02 B0 CE         [24] 1066 	ljmp	00158$
      00ACDF                       1067 00548$:
      00ACDF BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00ACE2 02 B1 66         [24] 1069 	ljmp	00168$
      00ACE5                       1070 00549$:
      00ACE5 02 B1 7F         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00ACE8                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00ACE8 12 3A D7         [24] 1075 	lcall	_ak820_outline_0124
      00ACEB E4               [12] 1076 	clr	a
      00ACEC 12 48 98         [24] 1077 	lcall	_ak820_outline_0032
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00ACEF 74 09            [12] 1079 	mov	a,#0x09
      00ACF1 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00ACF2 02 B1 97         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00ACF5                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00ACF5 12 48 D1         [24] 1086 	lcall	_ak820_outline_0096
      00ACF8 FA               [12] 1087 	mov	r2,a
      00ACF9 BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00ACFC 80 0C            [24] 1089 	sjmp	00117$
      00ACFE                       1090 00550$:
      00ACFE BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00AD01 80 32            [24] 1092 	sjmp	00118$
      00AD03                       1093 00551$:
      00AD03 BA 03 02         [24] 1094 	cjne	r2,#0x03,00552$
      00AD06 A1 6F            [24] 1095 	ajmp	00119$
      00AD08                       1096 00552$:
      00AD08 A1 99            [24] 1097 	ajmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00AD0A                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00AD0A 12 4E 84         [24] 1101 	lcall	_timer_read32
      00AD0D 85 82 39         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD10 85 83 3A         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD13 85 F0 3B         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD16 F5 3C            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AD18 12 3A CC         [24] 1107 	lcall	_ak820_outline_0118
      00AD1B A3               [24] 1108 	inc	dptr
      00AD1C A3               [24] 1109 	inc	dptr
      00AD1D E5 3C            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD1F 12 48 98         [24] 1111 	lcall	_ak820_outline_0032
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AD22 A3               [24] 1113 	inc	dptr
      00AD23 E5 3B            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD25 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AD26 12 B1 C4         [24] 1117 	lcall	_ak820_outline_0023
      00AD29 E5 3A            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD2B F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AD2C 12 48 8E         [24] 1121 	lcall	_ak820_outline_0012
      00AD2F E5 39            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD31 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00AD32 02 B1 97         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00AD35                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AD35 C0 03            [24] 1129 	push	ar3
      00AD37 C0 07            [24] 1130 	push	ar7
      00AD39 C0 06            [24] 1131 	push	ar6
      00AD3B C0 03            [24] 1132 	push	ar3
      00AD3D 71 9B            [12] 1133 	acall	_via_get_layout_options
      00AD3F 85 82 39         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AD42 85 83 3A         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AD45 85 F0 3B         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AD48 F5 3C            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AD4A D0 03            [24] 1138 	pop	ar3
      00AD4C D0 06            [24] 1139 	pop	ar6
      00AD4E D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AD50 12 3A CC         [24] 1142 	lcall	_ak820_outline_0118
      00AD53 A3               [24] 1143 	inc	dptr
      00AD54 A3               [24] 1144 	inc	dptr
      00AD55 E5 3C            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AD57 12 48 98         [24] 1146 	lcall	_ak820_outline_0032
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AD5A A3               [24] 1148 	inc	dptr
      00AD5B E5 3B            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AD5D F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AD5E 12 B1 C4         [24] 1152 	lcall	_ak820_outline_0023
      00AD61 E5 3A            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD63 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AD64 12 48 8E         [24] 1156 	lcall	_ak820_outline_0012
      00AD67 E5 39            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD69 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00AD6A D0 03            [24] 1160 	pop	ar3
      00AD6C 02 B1 97         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AD6F                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00AD6F 90 0E 84         [24] 1165 	mov	dptr,#_vial_unlocked
      00AD72 E0               [24] 1166 	movx	a,@dptr
      00AD73 70 03            [24] 1167 	jnz	00553$
      00AD75 02 B1 97         [24] 1168 	ljmp	00171$
      00AD78                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD78 7A 01            [12] 1171 	mov	r2,#0x01
      00AD7A 79 00            [12] 1172 	mov	r1,#0x00
      00AD7C                       1173 00173$:
      00AD7C B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00AD7F                       1175 00554$:
      00AD7F 40 03            [24] 1176 	jc	00555$
      00AD81 02 B1 97         [24] 1177 	ljmp	00171$
      00AD84                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AD84 89 82            [24] 1180 	mov	dpl, r1
      00AD86 12 5F 01         [24] 1181 	lcall	_matrix_get_row
      00AD89 A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AD8B EA               [12] 1184 	mov	a,r2
      00AD8C 2C               [12] 1185 	add	a, r4
      00AD8D F5 82            [12] 1186 	mov	dpl,a
      00AD8F E4               [12] 1187 	clr	a
      00AD90 3D               [12] 1188 	addc	a, r5
      00AD91 F5 83            [12] 1189 	mov	dph,a
      00AD93 0A               [12] 1190 	inc	r2
      00AD94 E8               [12] 1191 	mov	a,r0
      00AD95 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AD96 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00AD97 80 E3            [24] 1196 	sjmp	00173$
      00AD99                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AD99 12 4E 0F         [24] 1199 	lcall	_ak820_outline_0076
      00AD9C 90 0C B1         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AD9F 12 B1 CD         [24] 1201 	lcall	_ak820_outline_0041
      00ADA2 C0 07            [24] 1202 	push	ar7
      00ADA4 C0 06            [24] 1203 	push	ar6
      00ADA6 C0 03            [24] 1204 	push	ar3
      00ADA8 91 0B            [24] 1205 	acall	_raw_hid_receive_kb
      00ADAA D0 03            [24] 1206 	pop	ar3
      00ADAC D0 06            [24] 1207 	pop	ar6
      00ADAE D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00ADB0 02 B1 97         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00ADB3                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00ADB3 12 48 D1         [24] 1214 	lcall	_ak820_outline_0096
      00ADB6 FA               [12] 1215 	mov	r2,a
      00ADB7 BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00ADBA 80 02            [24] 1217 	sjmp	00557$
      00ADBC                       1218 00556$:
      00ADBC C1 2D            [12] 1219 	ajmp	00127$
      00ADBE                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00ADBE C0 03            [24] 1222 	push	ar3
      00ADC0 12 3A 79         [24] 1223 	lcall	_ak820_outline_0036
      00ADC3 F8               [12] 1224 	mov	r0,a
      00ADC4 79 00            [12] 1225 	mov	r1,#0x00
      00ADC6 7B 00            [12] 1226 	mov	r3,#0x00
      00ADC8 88 3C            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00ADCA 8B 39            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00ADCC 8B 3A            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00ADCE 8B 3B            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00ADD0 12 B1 BB         [24] 1231 	lcall	_ak820_outline_0018
      00ADD3 F8               [12] 1232 	mov	r0,a
      00ADD4 89 03            [24] 1233 	mov	ar3,r1
      00ADD6 88 02            [24] 1234 	mov	ar2,r0
      00ADD8 E4               [12] 1235 	clr	a
      00ADD9 42 39            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADDB E9               [12] 1237 	mov	a,r1
      00ADDC 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADDE EA               [12] 1239 	mov	a,r2
      00ADDF 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADE1 EB               [12] 1241 	mov	a,r3
      00ADE2 42 3C            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADE4 12 B1 C4         [24] 1243 	lcall	_ak820_outline_0023
      00ADE7 E0               [24] 1244 	movx	a,@dptr
      00ADE8 F8               [12] 1245 	mov	r0,a
      00ADE9 79 00            [12] 1246 	mov	r1,#0x00
      00ADEB 7A 00            [12] 1247 	mov	r2,#0x00
      00ADED 8A 03            [24] 1248 	mov	ar3,r2
      00ADEF 89 02            [24] 1249 	mov	ar2,r1
      00ADF1 88 01            [24] 1250 	mov	ar1,r0
      00ADF3 E4               [12] 1251 	clr	a
      00ADF4 42 39            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00ADF6 E9               [12] 1253 	mov	a,r1
      00ADF7 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00ADF9 EA               [12] 1255 	mov	a,r2
      00ADFA 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00ADFC EB               [12] 1257 	mov	a,r3
      00ADFD 42 3C            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00ADFF 12 48 8E         [24] 1259 	lcall	_ak820_outline_0012
      00AE02 E0               [24] 1260 	movx	a,@dptr
      00AE03 F8               [12] 1261 	mov	r0,a
      00AE04 E4               [12] 1262 	clr	a
      00AE05 F9               [12] 1263 	mov	r1,a
      00AE06 FA               [12] 1264 	mov	r2,a
      00AE07 FB               [12] 1265 	mov	r3,a
      00AE08 E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AE0A 42 01            [12] 1267 	orl	ar1,a
      00AE0C E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AE0E 42 02            [12] 1269 	orl	ar2,a
      00AE10 E5 3C            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AE12 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00AE14 12 3A F1         [24] 1273 	lcall	_ak820_outline_0144
      00AE17 8A F0            [24] 1274 	mov	b, r2
      00AE19 EB               [12] 1275 	mov	a, r3
      00AE1A C0 07            [24] 1276 	push	ar7
      00AE1C C0 06            [24] 1277 	push	ar6
      00AE1E C0 03            [24] 1278 	push	ar3
      00AE20 71 B4            [12] 1279 	acall	_via_set_layout_options
      00AE22 D0 03            [24] 1280 	pop	ar3
      00AE24 D0 06            [24] 1281 	pop	ar6
      00AE26 D0 07            [24] 1282 	pop	ar7
                                   1283 ;	quantum/via.c:324: break;
      00AE28 D0 03            [24] 1284 	pop	ar3
      00AE2A 02 B1 97         [24] 1285 	ljmp	00171$
                                   1286 ;	quantum/via.c:326: default: {
      00AE2D                       1287 00127$:
                                   1288 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AE2D 12 4E 0F         [24] 1289 	lcall	_ak820_outline_0076
      00AE30 90 0C B1         [24] 1290 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE33 12 B1 CD         [24] 1291 	lcall	_ak820_outline_0041
      00AE36 C0 07            [24] 1292 	push	ar7
      00AE38 C0 06            [24] 1293 	push	ar6
      00AE3A C0 03            [24] 1294 	push	ar3
      00AE3C 91 0B            [24] 1295 	acall	_raw_hid_receive_kb
      00AE3E D0 03            [24] 1296 	pop	ar3
      00AE40 D0 06            [24] 1297 	pop	ar6
      00AE42 D0 07            [24] 1298 	pop	ar7
                                   1299 ;	quantum/via.c:331: break;
      00AE44 02 B1 97         [24] 1300 	ljmp	00171$
                                   1301 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AE47                       1302 00129$:
                                   1303 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AE47 12 48 D1         [24] 1304 	lcall	_ak820_outline_0096
      00AE4A FA               [12] 1305 	mov	r2,a
      00AE4B 12 3A 79         [24] 1306 	lcall	_ak820_outline_0036
      00AE4E F9               [12] 1307 	mov	r1,a
      00AE4F 12 B1 BB         [24] 1308 	lcall	_ak820_outline_0018
      00AE52 F8               [12] 1309 	mov	r0,a
      00AE53 90 0B 3E         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AE56 E9               [12] 1311 	mov	a,r1
      00AE57 F0               [24] 1312 	movx	@dptr,a
      00AE58 90 0B 3F         [24] 1313 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AE5B E8               [12] 1314 	mov	a,r0
      00AE5C F0               [24] 1315 	movx	@dptr,a
      00AE5D 8A 82            [24] 1316 	mov	dpl, r2
      00AE5F C0 07            [24] 1317 	push	ar7
      00AE61 C0 06            [24] 1318 	push	ar6
      00AE63 C0 03            [24] 1319 	push	ar3
      00AE65 12 89 F3         [24] 1320 	lcall	_dynamic_keymap_get_keycode
      00AE68 A9 82            [24] 1321 	mov	r1, dpl
      00AE6A AA 83            [24] 1322 	mov	r2, dph
      00AE6C D0 03            [24] 1323 	pop	ar3
      00AE6E D0 06            [24] 1324 	pop	ar6
      00AE70 D0 07            [24] 1325 	pop	ar7
                                   1326 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AE72 12 B1 C4         [24] 1327 	lcall	_ak820_outline_0023
      00AE75 8A 00            [24] 1328 	mov	ar0,r2
      00AE77 E8               [12] 1329 	mov	a,r0
      00AE78 F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AE79 12 48 8E         [24] 1332 	lcall	_ak820_outline_0012
      00AE7C E9               [12] 1333 	mov	a,r1
      00AE7D F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00AE7E 02 B1 97         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AE81                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AE81 90 0E 84         [24] 1340 	mov	dptr,#_vial_unlocked
      00AE84 E0               [24] 1341 	movx	a,@dptr
      00AE85 70 19            [24] 1342 	jnz	00132$
      00AE87 12 B1 C4         [24] 1343 	lcall	_ak820_outline_0023
      00AE8A E0               [24] 1344 	movx	a,@dptr
      00AE8B FA               [12] 1345 	mov	r2,a
      00AE8C BA 7C 11         [24] 1346 	cjne	r2,#0x7c,00132$
      00AE8F 74 05            [12] 1347 	mov	a,#0x05
      00AE91 2E               [12] 1348 	add	a, r6
      00AE92 12 3A 5F         [24] 1349 	lcall	_ak820_outline_0016
      00AE95 70 09            [24] 1350 	jnz	00132$
                                   1351 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AE97 12 3A CC         [24] 1352 	lcall	_ak820_outline_0118
      00AE9A 74 FF            [12] 1353 	mov	a,#0xff
      00AE9C F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/via.c:345: break;
      00AE9D 02 B1 97         [24] 1356 	ljmp	00171$
      00AEA0                       1357 00132$:
                                   1358 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AEA0 C0 03            [24] 1359 	push	ar3
      00AEA2 12 48 D1         [24] 1360 	lcall	_ak820_outline_0096
      00AEA5 F5 3E            [12] 1361 	mov	_raw_hid_receive_sloc2_1_0,a
      00AEA7 12 3A 79         [24] 1362 	lcall	_ak820_outline_0036
      00AEAA F5 3D            [12] 1363 	mov	_raw_hid_receive_sloc1_1_0,a
      00AEAC 12 B1 BB         [24] 1364 	lcall	_ak820_outline_0018
      00AEAF F5 39            [12] 1365 	mov	_raw_hid_receive_sloc0_1_0,a
      00AEB1 12 B1 C4         [24] 1366 	lcall	_ak820_outline_0023
      00AEB4 E0               [24] 1367 	movx	a,@dptr
      00AEB5 FB               [12] 1368 	mov	r3,a
      00AEB6 78 00            [12] 1369 	mov	r0,#0x00
      00AEB8 12 48 8E         [24] 1370 	lcall	_ak820_outline_0012
      00AEBB E0               [24] 1371 	movx	a,@dptr
      00AEBC 7A 00            [12] 1372 	mov	r2,#0x00
      00AEBE 42 00            [12] 1373 	orl	ar0,a
      00AEC0 EA               [12] 1374 	mov	a,r2
      00AEC1 42 03            [12] 1375 	orl	ar3,a
      00AEC3 90 0B 41         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00AEC6 E5 3D            [12] 1377 	mov	a,_raw_hid_receive_sloc1_1_0
      00AEC8 F0               [24] 1378 	movx	@dptr,a
      00AEC9 90 0B 42         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00AECC E5 39            [12] 1380 	mov	a,_raw_hid_receive_sloc0_1_0
      00AECE F0               [24] 1381 	movx	@dptr,a
      00AECF 90 0B 43         [24] 1382 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00AED2 E8               [12] 1383 	mov	a,r0
      00AED3 12 7D 9E         [24] 1384 	lcall	_ak820_outline_0186
      00AED6 85 3E 82         [24] 1385 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00AED9 C0 07            [24] 1386 	push	ar7
      00AEDB C0 06            [24] 1387 	push	ar6
      00AEDD C0 03            [24] 1388 	push	ar3
      00AEDF 12 8A 40         [24] 1389 	lcall	_dynamic_keymap_set_keycode
      00AEE2 D0 03            [24] 1390 	pop	ar3
      00AEE4 D0 06            [24] 1391 	pop	ar6
      00AEE6 D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/via.c:349: break;
      00AEE8 D0 03            [24] 1394 	pop	ar3
      00AEEA 02 B1 97         [24] 1395 	ljmp	00171$
                                   1396 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00AEED                       1397 00135$:
                                   1398 ;	quantum/via.c:352: dynamic_keymap_reset();
      00AEED C0 07            [24] 1399 	push	ar7
      00AEEF C0 06            [24] 1400 	push	ar6
      00AEF1 C0 03            [24] 1401 	push	ar3
      00AEF3 12 8C C2         [24] 1402 	lcall	_dynamic_keymap_reset
      00AEF6 D0 03            [24] 1403 	pop	ar3
      00AEF8 D0 06            [24] 1404 	pop	ar6
      00AEFA D0 07            [24] 1405 	pop	ar7
                                   1406 ;	quantum/via.c:353: break;
      00AEFC 02 B1 97         [24] 1407 	ljmp	00171$
                                   1408 ;	quantum/via.c:355: case id_lighting_set_value: {
      00AEFF                       1409 00136$:
                                   1410 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00AEFF 12 4E 0F         [24] 1411 	lcall	_ak820_outline_0076
      00AF02 90 0D FC         [24] 1412 	mov	dptr,#_vialrgb_set_value_PARM_2
      00AF05 12 B1 CD         [24] 1413 	lcall	_ak820_outline_0041
      00AF08 C0 07            [24] 1414 	push	ar7
      00AF0A C0 06            [24] 1415 	push	ar6
      00AF0C C0 03            [24] 1416 	push	ar3
      00AF0E 12 BB DC         [24] 1417 	lcall	_vialrgb_set_value
      00AF11 D0 03            [24] 1418 	pop	ar3
      00AF13 D0 06            [24] 1419 	pop	ar6
      00AF15 D0 07            [24] 1420 	pop	ar7
                                   1421 ;	quantum/via.c:375: break;
      00AF17 02 B1 97         [24] 1422 	ljmp	00171$
                                   1423 ;	quantum/via.c:377: case id_lighting_get_value: {
      00AF1A                       1424 00137$:
                                   1425 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00AF1A 12 4E 0F         [24] 1426 	lcall	_ak820_outline_0076
      00AF1D 90 0D F8         [24] 1427 	mov	dptr,#_vialrgb_get_value_PARM_2
      00AF20 12 B1 CD         [24] 1428 	lcall	_ak820_outline_0041
      00AF23 C0 07            [24] 1429 	push	ar7
      00AF25 C0 06            [24] 1430 	push	ar6
      00AF27 C0 03            [24] 1431 	push	ar3
      00AF29 12 BA 75         [24] 1432 	lcall	_vialrgb_get_value
      00AF2C D0 03            [24] 1433 	pop	ar3
      00AF2E D0 06            [24] 1434 	pop	ar6
      00AF30 D0 07            [24] 1435 	pop	ar7
                                   1436 ;	quantum/via.c:397: break;
      00AF32 02 B1 97         [24] 1437 	ljmp	00171$
                                   1438 ;	quantum/via.c:399: case id_lighting_save: {
      00AF35                       1439 00138$:
                                   1440 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AF35 12 4E 0F         [24] 1441 	lcall	_ak820_outline_0076
      00AF38 90 0E 00         [24] 1442 	mov	dptr,#_vialrgb_save_PARM_2
      00AF3B 12 B1 CD         [24] 1443 	lcall	_ak820_outline_0041
      00AF3E C0 07            [24] 1444 	push	ar7
      00AF40 C0 06            [24] 1445 	push	ar6
      00AF42 C0 03            [24] 1446 	push	ar3
      00AF44 12 BC 69         [24] 1447 	lcall	_vialrgb_save
      00AF47 D0 03            [24] 1448 	pop	ar3
      00AF49 D0 06            [24] 1449 	pop	ar6
      00AF4B D0 07            [24] 1450 	pop	ar7
                                   1451 ;	quantum/via.c:419: break;
      00AF4D 02 B1 97         [24] 1452 	ljmp	00171$
                                   1453 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AF50                       1454 00139$:
                                   1455 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AF50 C0 07            [24] 1456 	push	ar7
      00AF52 C0 06            [24] 1457 	push	ar6
      00AF54 C0 05            [24] 1458 	push	ar5
      00AF56 C0 04            [24] 1459 	push	ar4
      00AF58 C0 03            [24] 1460 	push	ar3
      00AF5A 12 90 AA         [24] 1461 	lcall	_dynamic_keymap_macro_get_count
      00AF5D AA 82            [24] 1462 	mov	r2, dpl
      00AF5F D0 03            [24] 1463 	pop	ar3
      00AF61 D0 04            [24] 1464 	pop	ar4
      00AF63 D0 05            [24] 1465 	pop	ar5
      00AF65 D0 06            [24] 1466 	pop	ar6
      00AF67 D0 07            [24] 1467 	pop	ar7
      00AF69 12 3A D7         [24] 1468 	lcall	_ak820_outline_0124
      00AF6C EA               [12] 1469 	mov	a,r2
      00AF6D F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	quantum/via.c:430: break;
      00AF6E 02 B1 97         [24] 1472 	ljmp	00171$
                                   1473 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AF71                       1474 00140$:
                                   1475 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AF71 C0 07            [24] 1476 	push	ar7
      00AF73 C0 06            [24] 1477 	push	ar6
      00AF75 C0 05            [24] 1478 	push	ar5
      00AF77 C0 04            [24] 1479 	push	ar4
      00AF79 C0 03            [24] 1480 	push	ar3
      00AF7B 12 90 AE         [24] 1481 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AF7E A9 82            [24] 1482 	mov	r1, dpl
      00AF80 AA 83            [24] 1483 	mov	r2, dph
      00AF82 D0 03            [24] 1484 	pop	ar3
      00AF84 D0 04            [24] 1485 	pop	ar4
      00AF86 D0 05            [24] 1486 	pop	ar5
      00AF88 D0 06            [24] 1487 	pop	ar6
      00AF8A D0 07            [24] 1488 	pop	ar7
                                   1489 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AF8C 8A 00            [24] 1490 	mov	ar0,r2
      00AF8E 12 3A D7         [24] 1491 	lcall	_ak820_outline_0124
      00AF91 E8               [12] 1492 	mov	a,r0
      00AF92 12 48 98         [24] 1493 	lcall	_ak820_outline_0032
                                   1494 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AF95 E9               [12] 1495 	mov	a,r1
      00AF96 F0               [24] 1496 	movx	@dptr,a
                                   1497 ;	quantum/via.c:436: break;
      00AF97 02 B1 97         [24] 1498 	ljmp	00171$
                                   1499 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AF9A                       1500 00141$:
                                   1501 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AF9A C0 03            [24] 1502 	push	ar3
      00AF9C 12 B1 A4         [24] 1503 	lcall	_ak820_outline_0003
      00AF9F 89 39            [24] 1504 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AFA1 8A 3A            [24] 1505 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1506 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AFA3 12 B1 BB         [24] 1507 	lcall	_ak820_outline_0018
      00AFA6 FB               [12] 1508 	mov	r3,a
                                   1509 ;	quantum/via.c:441: if (size <= 28)
      00AFA7 8B 3F            [24] 1510 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AFA9 75 40 00         [24] 1511 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AFAC C3               [12] 1512 	clr	c
      00AFAD 74 1C            [12] 1513 	mov	a,#0x1c
      00AFAF 9B               [12] 1514 	subb	a,r3
      00AFB0 D0 03            [24] 1515 	pop	ar3
      00AFB2 50 03            [24] 1516 	jnc	00562$
      00AFB4 02 B1 97         [24] 1517 	ljmp	00171$
      00AFB7                       1518 00562$:
                                   1519 ;	free result
                                   1520 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AFB7 12 B1 D6         [24] 1521 	lcall	_ak820_outline_0068
      00AFBA 90 0B 90         [24] 1522 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AFBD E5 3F            [12] 1523 	mov	a,_raw_hid_receive_sloc3_1_0
      00AFBF F0               [24] 1524 	movx	@dptr,a
      00AFC0 E5 40            [12] 1525 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AFC2 A3               [24] 1526 	inc	dptr
      00AFC3 F0               [24] 1527 	movx	@dptr,a
      00AFC4 90 0B 92         [24] 1528 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AFC7 12 B1 E0         [24] 1529 	lcall	_ak820_outline_0088
      00AFCA 85 39 82         [24] 1530 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AFCD 85 3A 83         [24] 1531 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AFD0 C0 07            [24] 1532 	push	ar7
      00AFD2 C0 06            [24] 1533 	push	ar6
      00AFD4 C0 03            [24] 1534 	push	ar3
      00AFD6 12 90 B2         [24] 1535 	lcall	_dynamic_keymap_macro_get_buffer
      00AFD9 D0 03            [24] 1536 	pop	ar3
      00AFDB D0 06            [24] 1537 	pop	ar6
      00AFDD D0 07            [24] 1538 	pop	ar7
                                   1539 ;	quantum/via.c:443: break;
      00AFDF 02 B1 97         [24] 1540 	ljmp	00171$
                                   1541 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AFE2                       1542 00144$:
                                   1543 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AFE2 90 0E 84         [24] 1544 	mov	dptr,#_vial_unlocked
      00AFE5 E0               [24] 1545 	movx	a,@dptr
      00AFE6 70 01            [24] 1546 	jnz	00146$
                                   1547 ;	quantum/via.c:450: return;
      00AFE8 22               [24] 1548 	ret
      00AFE9                       1549 00146$:
                                   1550 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AFE9 C0 03            [24] 1551 	push	ar3
      00AFEB 12 B1 A4         [24] 1552 	lcall	_ak820_outline_0003
      00AFEE 89 3F            [24] 1553 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AFF0 8A 40            [24] 1554 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1555 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AFF2 12 B1 BB         [24] 1556 	lcall	_ak820_outline_0018
      00AFF5 F5 39            [12] 1557 	mov	_raw_hid_receive_sloc0_1_0, a
      00AFF7 75 3A 00         [24] 1558 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1559 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AFFA 85 39 41         [24] 1560 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AFFD 85 3A 42         [24] 1561 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00B000 C3               [12] 1562 	clr	c
      00B001 74 1C            [12] 1563 	mov	a,#0x1c
      00B003 95 41            [12] 1564 	subb	a,_raw_hid_receive_sloc4_1_0
      00B005 E4               [12] 1565 	clr	a
      00B006 95 42            [12] 1566 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B008 D0 03            [24] 1567 	pop	ar3
      00B00A 40 43            [24] 1568 	jc	00147$
                                   1569 ;	free result
      00B00C 8B 01            [24] 1570 	mov	ar1,r3
      00B00E 7A 00            [12] 1571 	mov	r2,#0x00
      00B010 E9               [12] 1572 	mov	a,r1
      00B011 24 FC            [12] 1573 	add	a,#0xfc
      00B013 F9               [12] 1574 	mov	r1,a
      00B014 EA               [12] 1575 	mov	a,r2
      00B015 34 FF            [12] 1576 	addc	a,#0xff
      00B017 FA               [12] 1577 	mov	r2,a
      00B018 C3               [12] 1578 	clr	c
      00B019 E9               [12] 1579 	mov	a,r1
      00B01A 95 41            [12] 1580 	subb	a,_raw_hid_receive_sloc4_1_0
      00B01C EA               [12] 1581 	mov	a,r2
      00B01D 95 42            [12] 1582 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00B01F 40 2E            [24] 1583 	jc	00147$
                                   1584 ;	free result
      00B021 12 B1 D6         [24] 1585 	lcall	_ak820_outline_0068
      00B024 90 0B 97         [24] 1586 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00B027 E5 39            [12] 1587 	mov	a,_raw_hid_receive_sloc0_1_0
      00B029 F0               [24] 1588 	movx	@dptr,a
      00B02A E5 3A            [12] 1589 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00B02C A3               [24] 1590 	inc	dptr
      00B02D F0               [24] 1591 	movx	@dptr,a
      00B02E 90 0B 99         [24] 1592 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00B031 12 B1 E0         [24] 1593 	lcall	_ak820_outline_0088
      00B034 85 3F 82         [24] 1594 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00B037 85 40 83         [24] 1595 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00B03A C0 07            [24] 1596 	push	ar7
      00B03C C0 06            [24] 1597 	push	ar6
      00B03E C0 03            [24] 1598 	push	ar3
      00B040 12 91 00         [24] 1599 	lcall	_dynamic_keymap_macro_set_buffer
      00B043 E5 82            [12] 1600 	mov	a, dpl
      00B045 D0 03            [24] 1601 	pop	ar3
      00B047 D0 06            [24] 1602 	pop	ar6
      00B049 D0 07            [24] 1603 	pop	ar7
      00B04B 60 02            [24] 1604 	jz	00566$
      00B04D 21 97            [12] 1605 	ajmp	00171$
      00B04F                       1606 00566$:
      00B04F                       1607 00147$:
      00B04F 22               [24] 1608 	ret
                                   1609 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00B050                       1610 00151$:
                                   1611 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00B050 90 0E 84         [24] 1612 	mov	dptr,#_vial_unlocked
      00B053 E0               [24] 1613 	movx	a,@dptr
      00B054 70 01            [24] 1614 	jnz	00153$
      00B056 22               [24] 1615 	ret
      00B057                       1616 00153$:
                                   1617 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00B057 C0 07            [24] 1618 	push	ar7
      00B059 C0 06            [24] 1619 	push	ar6
      00B05B C0 03            [24] 1620 	push	ar3
      00B05D 12 91 2E         [24] 1621 	lcall	_dynamic_keymap_macro_reset
      00B060 D0 03            [24] 1622 	pop	ar3
      00B062 D0 06            [24] 1623 	pop	ar6
      00B064 D0 07            [24] 1624 	pop	ar7
                                   1625 ;	quantum/via.c:473: break;
      00B066 21 97            [12] 1626 	ajmp	00171$
                                   1627 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00B068                       1628 00154$:
                                   1629 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00B068 C0 07            [24] 1630 	push	ar7
      00B06A C0 06            [24] 1631 	push	ar6
      00B06C C0 05            [24] 1632 	push	ar5
      00B06E C0 04            [24] 1633 	push	ar4
      00B070 C0 03            [24] 1634 	push	ar3
      00B072 12 89 BA         [24] 1635 	lcall	_dynamic_keymap_get_layer_count
      00B075 AA 82            [24] 1636 	mov	r2, dpl
      00B077 D0 03            [24] 1637 	pop	ar3
      00B079 D0 04            [24] 1638 	pop	ar4
      00B07B D0 05            [24] 1639 	pop	ar5
      00B07D D0 06            [24] 1640 	pop	ar6
      00B07F D0 07            [24] 1641 	pop	ar7
      00B081 12 3A D7         [24] 1642 	lcall	_ak820_outline_0124
      00B084 EA               [12] 1643 	mov	a,r2
      00B085 F0               [24] 1644 	movx	@dptr,a
                                   1645 ;	quantum/via.c:477: break;
      00B086 21 97            [12] 1646 	ajmp	00171$
                                   1647 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00B088                       1648 00155$:
                                   1649 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B088 C0 03            [24] 1650 	push	ar3
      00B08A 12 B1 A4         [24] 1651 	lcall	_ak820_outline_0003
      00B08D 89 41            [24] 1652 	mov	_raw_hid_receive_sloc4_1_0,r1
      00B08F 8A 42            [24] 1653 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1654 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00B091 12 B1 BB         [24] 1655 	lcall	_ak820_outline_0018
      00B094 FB               [12] 1656 	mov	r3,a
                                   1657 ;	quantum/via.c:482: if (size <= 28)
      00B095 8B 3F            [24] 1658 	mov	_raw_hid_receive_sloc3_1_0,r3
      00B097 75 40 00         [24] 1659 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00B09A C3               [12] 1660 	clr	c
      00B09B 74 1C            [12] 1661 	mov	a,#0x1c
      00B09D 9B               [12] 1662 	subb	a,r3
      00B09E D0 03            [24] 1663 	pop	ar3
      00B0A0 50 02            [24] 1664 	jnc	00568$
      00B0A2 21 97            [12] 1665 	ajmp	00171$
      00B0A4                       1666 00568$:
                                   1667 ;	free result
                                   1668 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00B0A4 12 B1 D6         [24] 1669 	lcall	_ak820_outline_0068
      00B0A7 90 0B 79         [24] 1670 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00B0AA E5 3F            [12] 1671 	mov	a,_raw_hid_receive_sloc3_1_0
      00B0AC F0               [24] 1672 	movx	@dptr,a
      00B0AD E5 40            [12] 1673 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00B0AF A3               [24] 1674 	inc	dptr
      00B0B0 F0               [24] 1675 	movx	@dptr,a
      00B0B1 90 0B 7B         [24] 1676 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00B0B4 12 B1 E0         [24] 1677 	lcall	_ak820_outline_0088
      00B0B7 85 41 82         [24] 1678 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B0BA 85 42 83         [24] 1679 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B0BD C0 07            [24] 1680 	push	ar7
      00B0BF C0 06            [24] 1681 	push	ar6
      00B0C1 C0 03            [24] 1682 	push	ar3
      00B0C3 12 8E 7B         [24] 1683 	lcall	_dynamic_keymap_get_buffer
      00B0C6 D0 03            [24] 1684 	pop	ar3
      00B0C8 D0 06            [24] 1685 	pop	ar6
      00B0CA D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/via.c:484: break;
      00B0CC 21 97            [12] 1688 	ajmp	00171$
                                   1689 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00B0CE                       1690 00158$:
                                   1691 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00B0CE 12 48 D1         [24] 1692 	lcall	_ak820_outline_0096
      00B0D1 FD               [12] 1693 	mov	r5,a
      00B0D2 7C 00            [12] 1694 	mov	r4,#0x00
      00B0D4 12 3A 79         [24] 1695 	lcall	_ak820_outline_0036
      00B0D7 7A 00            [12] 1696 	mov	r2,#0x00
      00B0D9 42 04            [12] 1697 	orl	ar4,a
      00B0DB EA               [12] 1698 	mov	a,r2
      00B0DC 42 05            [12] 1699 	orl	ar5,a
      00B0DE 8C 41            [24] 1700 	mov	_raw_hid_receive_sloc4_1_0,r4
      00B0E0 8D 42            [24] 1701 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1702 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00B0E2 12 B1 BB         [24] 1703 	lcall	_ak820_outline_0018
      00B0E5 F9               [12] 1704 	mov	r1,a
      00B0E6 7A 00            [12] 1705 	mov	r2,#0x00
                                   1706 ;	quantum/via.c:489: if (size <= 28)
      00B0E8 89 00            [24] 1707 	mov	ar0,r1
      00B0EA E8               [12] 1708 	mov	a,r0
      00B0EB 24 E3            [12] 1709 	add	a,#0xff - 0x1c
      00B0ED 50 02            [24] 1710 	jnc	00569$
      00B0EF 21 97            [12] 1711 	ajmp	00171$
      00B0F1                       1712 00569$:
                                   1713 ;	free result
                                   1714 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00B0F1 C0 03            [24] 1715 	push	ar3
      00B0F3 74 04            [12] 1716 	mov	a,#0x04
      00B0F5 2E               [12] 1717 	add	a, r6
      00B0F6 F8               [12] 1718 	mov	r0,a
      00B0F7 E4               [12] 1719 	clr	a
      00B0F8 3F               [12] 1720 	addc	a, r7
      00B0F9 FB               [12] 1721 	mov	r3,a
      00B0FA 7D 00            [12] 1722 	mov	r5,#0x00
      00B0FC 90 0B 80         [24] 1723 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00B0FF E9               [12] 1724 	mov	a,r1
      00B100 F0               [24] 1725 	movx	@dptr,a
      00B101 EA               [12] 1726 	mov	a,r2
      00B102 A3               [24] 1727 	inc	dptr
      00B103 F0               [24] 1728 	movx	@dptr,a
      00B104 90 0B 82         [24] 1729 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00B107 E8               [12] 1730 	mov	a,r0
      00B108 12 7D 9E         [24] 1731 	lcall	_ak820_outline_0186
      00B10B ED               [12] 1732 	mov	a,r5
      00B10C A3               [24] 1733 	inc	dptr
      00B10D F0               [24] 1734 	movx	@dptr,a
      00B10E 85 41 82         [24] 1735 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00B111 85 42 83         [24] 1736 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00B114 C0 07            [24] 1737 	push	ar7
      00B116 C0 06            [24] 1738 	push	ar6
      00B118 C0 03            [24] 1739 	push	ar3
      00B11A 12 8E B8         [24] 1740 	lcall	_dynamic_keymap_set_buffer
      00B11D D0 03            [24] 1741 	pop	ar3
      00B11F D0 06            [24] 1742 	pop	ar6
      00B121 D0 07            [24] 1743 	pop	ar7
                                   1744 ;	quantum/via.c:491: break;
      00B123 D0 03            [24] 1745 	pop	ar3
      00B125 21 97            [12] 1746 	ajmp	00171$
                                   1747 ;	quantum/via.c:495: case id_bootloader_jump: {
      00B127                       1748 00161$:
                                   1749 ;	quantum/via.c:497: if (!vial_unlocked)
      00B127 90 0E 84         [24] 1750 	mov	dptr,#_vial_unlocked
      00B12A E0               [24] 1751 	movx	a,@dptr
      00B12B 70 02            [24] 1752 	jnz	00570$
      00B12D 21 97            [12] 1753 	ajmp	00171$
      00B12F                       1754 00570$:
                                   1755 ;	quantum/via.c:501: raw_hid_send(data, length);
      00B12F 12 B1 F2         [24] 1756 	lcall	_ak820_outline_0150
      00B132 90 06 DB         [24] 1757 	mov	dptr,#_raw_hid_send_PARM_2
      00B135 12 B1 E9         [24] 1758 	lcall	_ak820_outline_0089
      00B138 C0 07            [24] 1759 	push	ar7
      00B13A C0 06            [24] 1760 	push	ar6
      00B13C C0 03            [24] 1761 	push	ar3
      00B13E 12 50 8C         [24] 1762 	lcall	_raw_hid_send
      00B141 D0 03            [24] 1763 	pop	ar3
      00B143 D0 06            [24] 1764 	pop	ar6
      00B145 D0 07            [24] 1765 	pop	ar7
                                   1766 ;	quantum/via.c:503: wait_ms(100);
      00B147 7D 64            [12] 1767 	mov	r5,#0x64
      00B149                       1768 00176$:
      00B149 ED               [12] 1769 	mov	a,r5
      00B14A 60 09            [24] 1770 	jz	00166$
      00B14C 90 00 01         [24] 1771 	mov	dptr,#0x0001
      00B14F 12 5E 40         [24] 1772 	lcall	_mDelaymS
      00B152 1D               [12] 1773 	dec	r5
      00B153 80 F4            [24] 1774 	sjmp	00176$
      00B155                       1775 00166$:
                                   1776 ;	quantum/via.c:504: bootloader_jump();
      00B155 C0 07            [24] 1777 	push	ar7
      00B157 C0 06            [24] 1778 	push	ar6
      00B159 C0 03            [24] 1779 	push	ar3
      00B15B 12 36 59         [24] 1780 	lcall	_bootloader_jump
      00B15E D0 03            [24] 1781 	pop	ar3
      00B160 D0 06            [24] 1782 	pop	ar6
      00B162 D0 07            [24] 1783 	pop	ar7
                                   1784 ;	quantum/via.c:505: break;
                                   1785 ;	quantum/via.c:509: case id_vial_prefix: {
      00B164 80 31            [24] 1786 	sjmp	00171$
      00B166                       1787 00168$:
                                   1788 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00B166 12 B1 F2         [24] 1789 	lcall	_ak820_outline_0150
      00B169 90 0C C3         [24] 1790 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B16C 12 B1 E9         [24] 1791 	lcall	_ak820_outline_0089
      00B16F C0 07            [24] 1792 	push	ar7
      00B171 C0 06            [24] 1793 	push	ar6
      00B173 C0 03            [24] 1794 	push	ar3
      00B175 51 DF            [12] 1795 	acall	_vial_handle_cmd
      00B177 D0 03            [24] 1796 	pop	ar3
      00B179 D0 06            [24] 1797 	pop	ar6
      00B17B D0 07            [24] 1798 	pop	ar7
                                   1799 ;	quantum/via.c:511: break;
                                   1800 ;	quantum/via.c:514: default: {
      00B17D 80 18            [24] 1801 	sjmp	00171$
      00B17F                       1802 00169$:
                                   1803 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00B17F 12 B1 F2         [24] 1804 	lcall	_ak820_outline_0150
      00B182 90 0C B1         [24] 1805 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00B185 12 B1 E9         [24] 1806 	lcall	_ak820_outline_0089
      00B188 C0 07            [24] 1807 	push	ar7
      00B18A C0 06            [24] 1808 	push	ar6
      00B18C C0 03            [24] 1809 	push	ar3
      00B18E 12 AC 0B         [24] 1810 	lcall	_raw_hid_receive_kb
      00B191 D0 03            [24] 1811 	pop	ar3
      00B193 D0 06            [24] 1812 	pop	ar6
      00B195 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/via.c:521: skip:
      00B197                       1815 00171$:
                                   1816 ;	quantum/via.c:525: raw_hid_send(data, length);
      00B197 7D 00            [12] 1817 	mov	r5,#0x00
      00B199 90 06 DB         [24] 1818 	mov	dptr,#_raw_hid_send_PARM_2
      00B19C EB               [12] 1819 	mov	a,r3
      00B19D F0               [24] 1820 	movx	@dptr,a
      00B19E 12 75 0D         [24] 1821 	lcall	_ak820_outline_0064
                                   1822 ;	quantum/via.c:526: }
      00B1A1 02 50 8C         [24] 1823 	ljmp	_raw_hid_send
                                   1824 	.area CSEG    (CODE)
                                   1825 	.area CONST   (CODE)
                                   1826 	.area XINIT   (CODE)
                                   1827 	.area CABS    (ABS,CODE)
                                   1828 
                                   1829 ; Experimental exact instruction outlining.
                                   1830 	.globl _ak820_outline_0001
                                   1831 	.globl _ak820_outline_0003
                                   1832 	.globl _ak820_outline_0009
                                   1833 	.globl _ak820_outline_0012
                                   1834 	.globl _ak820_outline_0013
                                   1835 	.globl _ak820_outline_0016
                                   1836 	.globl _ak820_outline_0017
                                   1837 	.globl _ak820_outline_0018
                                   1838 	.globl _ak820_outline_0023
                                   1839 	.globl _ak820_outline_0032
                                   1840 	.globl _ak820_outline_0036
                                   1841 	.globl _ak820_outline_0037
                                   1842 	.globl _ak820_outline_0041
                                   1843 	.globl _ak820_outline_0044
                                   1844 	.globl _ak820_outline_0050
                                   1845 	.globl _ak820_outline_0052
                                   1846 	.globl _ak820_outline_0064
                                   1847 	.globl _ak820_outline_0068
                                   1848 	.globl _ak820_outline_0076
                                   1849 	.globl _ak820_outline_0088
                                   1850 	.globl _ak820_outline_0089
                                   1851 	.globl _ak820_outline_0096
                                   1852 	.globl _ak820_outline_0108
                                   1853 	.globl _ak820_outline_0109
                                   1854 	.globl _ak820_outline_0118
                                   1855 	.globl _ak820_outline_0120
                                   1856 	.globl _ak820_outline_0124
                                   1857 	.globl _ak820_outline_0144
                                   1858 	.globl _ak820_outline_0150
                                   1859 	.globl _ak820_outline_0152
                                   1860 	.globl _ak820_outline_0156
                                   1861 	.globl _ak820_outline_0157
                                   1862 	.globl _ak820_outline_0159
                                   1863 	.globl _ak820_outline_0160
                                   1864 	.globl _ak820_outline_0186
                                   1865 
                                   1866 	.area CSEG (CODE)
                                   1867 ; function ak820_outline_0003
      00B1A4                       1868 _ak820_outline_0003:
      00B1A4 8C 82            [24] 1869 	mov	dpl,r4
      00B1A6 8D 83            [24] 1870 	mov	dph,r5
      00B1A8 E0               [24] 1871 	movx	a,@dptr
      00B1A9 FA               [12] 1872 	mov	r2,a
      00B1AA 79 00            [12] 1873 	mov	r1,#0x00
      00B1AC 8E 82            [24] 1874 	mov	dpl,r6
      00B1AE 8F 83            [24] 1875 	mov	dph,r7
      00B1B0 A3               [24] 1876 	inc	dptr
      00B1B1 A3               [24] 1877 	inc	dptr
      00B1B2 E0               [24] 1878 	movx	a,@dptr
      00B1B3 7B 00            [12] 1879 	mov	r3,#0x00
      00B1B5 42 01            [12] 1880 	orl	ar1,a
      00B1B7 EB               [12] 1881 	mov	a,r3
      00B1B8 42 02            [12] 1882 	orl	ar2,a
      00B1BA 22               [24] 1883 	ret
                                   1884 
                                   1885 	.area CSEG (CODE)
                                   1886 ; function ak820_outline_0018
      00B1BB                       1887 _ak820_outline_0018:
      00B1BB 8E 82            [24] 1888 	mov	dpl,r6
      00B1BD 8F 83            [24] 1889 	mov	dph,r7
      00B1BF A3               [24] 1890 	inc	dptr
      00B1C0 A3               [24] 1891 	inc	dptr
      00B1C1 A3               [24] 1892 	inc	dptr
      00B1C2 E0               [24] 1893 	movx	a,@dptr
      00B1C3 22               [24] 1894 	ret
                                   1895 
                                   1896 	.area CSEG (CODE)
                                   1897 ; function ak820_outline_0023
      00B1C4                       1898 _ak820_outline_0023:
      00B1C4 8E 82            [24] 1899 	mov	dpl,r6
      00B1C6 8F 83            [24] 1900 	mov	dph,r7
      00B1C8 A3               [24] 1901 	inc	dptr
      00B1C9 A3               [24] 1902 	inc	dptr
      00B1CA A3               [24] 1903 	inc	dptr
      00B1CB A3               [24] 1904 	inc	dptr
      00B1CC 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0041
      00B1CD                       1909 _ak820_outline_0041:
      00B1CD EB               [12] 1910 	mov	a,r3
      00B1CE F0               [24] 1911 	movx	@dptr,a
      00B1CF 88 82            [24] 1912 	mov	dpl,r0
      00B1D1 89 83            [24] 1913 	mov	dph,r1
      00B1D3 8A F0            [24] 1914 	mov	b,r2
      00B1D5 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0068
      00B1D6                       1919 _ak820_outline_0068:
      00B1D6 74 04            [12] 1920 	mov	a,#0x04
      00B1D8 2E               [12] 1921 	add	a,r6
      00B1D9 F9               [12] 1922 	mov	r1,a
      00B1DA E4               [12] 1923 	clr	a
      00B1DB 3F               [12] 1924 	addc	a,r7
      00B1DC F8               [12] 1925 	mov	r0,a
      00B1DD 7A 00            [12] 1926 	mov	r2,#0x00
      00B1DF 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0088
      00B1E0                       1931 _ak820_outline_0088:
      00B1E0 E9               [12] 1932 	mov	a,r1
      00B1E1 F0               [24] 1933 	movx	@dptr,a
      00B1E2 E8               [12] 1934 	mov	a,r0
      00B1E3 A3               [24] 1935 	inc	dptr
      00B1E4 F0               [24] 1936 	movx	@dptr,a
      00B1E5 EA               [12] 1937 	mov	a,r2
      00B1E6 A3               [24] 1938 	inc	dptr
      00B1E7 F0               [24] 1939 	movx	@dptr,a
      00B1E8 22               [24] 1940 	ret
                                   1941 
                                   1942 	.area CSEG (CODE)
                                   1943 ; function ak820_outline_0089
      00B1E9                       1944 _ak820_outline_0089:
      00B1E9 EB               [12] 1945 	mov	a,r3
      00B1EA F0               [24] 1946 	movx	@dptr,a
      00B1EB 8A 82            [24] 1947 	mov	dpl,r2
      00B1ED 8C 83            [24] 1948 	mov	dph,r4
      00B1EF 8D F0            [24] 1949 	mov	b,r5
      00B1F1 22               [24] 1950 	ret
                                   1951 
                                   1952 	.area CSEG (CODE)
                                   1953 ; function ak820_outline_0150
      00B1F2                       1954 _ak820_outline_0150:
      00B1F2 8E 02            [24] 1955 	mov	ar2,r6
      00B1F4 8F 04            [24] 1956 	mov	ar4,r7
      00B1F6 7D 00            [12] 1957 	mov	r5,#0x00
      00B1F8 22               [24] 1958 	ret
