;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module send_string
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ascii_to_keycode_lut
	.globl _ascii_to_dead_lut
	.globl _ascii_to_altgr_lut
	.globl _ascii_to_shift_lut
	.globl _tap_code
	.globl _unregister_code
	.globl _register_code
	.globl _mDelaymS
	.globl _rand
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _send_string_with_delay_PARM_2
	.globl _send_string
	.globl _send_string_with_delay
	.globl _send_char
	.globl _send_dword
	.globl _send_word
	.globl _send_byte
	.globl _send_nibble
	.globl _tap_random_base64
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_send_char_sloc1_1_0:
	.ds 1
_send_char_sloc2_1_0:
	.ds 1
_send_char_sloc3_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_send_char_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_send_string_string_10000_213:
	.ds 3
_send_string_with_delay_PARM_2:
	.ds 1
_send_string_with_delay_string_10000_215:
	.ds 3
_send_string_with_delay_ms_90000_228:
	.ds 2
_send_string_with_delay_keycode_90000_228:
	.ds 1
_send_char_ascii_code_10000_241:
	.ds 1
_send_dword_number_10000_253:
	.ds 4
_send_word_number_10000_255:
	.ds 2
_send_byte_number_10000_257:
	.ds 1
_send_nibble_number_10000_259:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'send_string'
;------------------------------------------------------------
;string        Allocated with name '_send_string_string_10000_213'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:160: void send_string(const char *string) {
;	-----------------------------------------
;	 function send_string
;	-----------------------------------------
_send_string:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_send_string_string_10000_213
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:161: send_string_with_delay(string, 0);
	mov	dptr,#_send_string_string_10000_213
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_send_string_with_delay_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
;	quantum/send_string/send_string.c:162: }
	ljmp	_send_string_with_delay
;------------------------------------------------------------
;Allocation info for local variables in function 'send_string_with_delay'
;------------------------------------------------------------
;interval      Allocated with name '_send_string_with_delay_PARM_2'
;string        Allocated with name '_send_string_with_delay_string_10000_215'
;ascii_code    Allocated with name '_send_string_with_delay_ascii_code_20000_217'
;keycode       Allocated with name '_send_string_with_delay_keycode_60000_222'
;keycode       Allocated with name '_send_string_with_delay_keycode_70000_224'
;keycode       Allocated with name '_send_string_with_delay_keycode_80000_226'
;__1000000066  Allocated with name '_send_string_with_delay___1000000066_100000_228'
;ms            Allocated with name '_send_string_with_delay_ms_90000_228'
;keycode       Allocated with name '_send_string_with_delay_keycode_90000_228'
;__1000000067  Allocated with name '_send_string_with_delay___1000000067_100000_238'
;c             Allocated with name '_send_string_with_delay_c_110000_239'
;i             Allocated with name '_send_string_with_delay_i_110000_231'
;ms            Allocated with name '_send_string_with_delay_ms_30000_234'
;i             Allocated with name '_send_string_with_delay_i_50000_236'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:164: void send_string_with_delay(const char *string, uint8_t interval) {
;	-----------------------------------------
;	 function send_string_with_delay
;	-----------------------------------------
_send_string_with_delay:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:165: while (1) {
	mov	dptr,#_send_string_with_delay_PARM_2
	movx	a,@dptr
	mov	r7,a
00135$:
;	quantum/send_string/send_string.c:166: char ascii_code = *string;
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
;	quantum/send_string/send_string.c:167: if (!ascii_code) break;
	mov	r3,a
	jnz	00264$
	ret
00264$:
;	quantum/send_string/send_string.c:168: if (ascii_code == SS_QMK_PREFIX) {
	cjne	r3,#0x01,00265$
	sjmp	00266$
00265$:
	ljmp	00125$
00266$:
;	quantum/send_string/send_string.c:169: ascii_code = *(++string);
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,#0x01
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r2,a
;	quantum/send_string/send_string.c:170: if (ascii_code == SS_TAP_CODE) {
	cjne	r2,#0x01,00122$
;	quantum/send_string/send_string.c:172: uint8_t keycode = *(++string);
	push	ar7
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,#0x01
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r0
	mov	dph,r1
	mov	b,r7
	lcall	__gptrget
;	quantum/send_string/send_string.c:173: tap_code(keycode);
	mov	dpl,a
	push	ar7
	lcall	_tap_code
	pop	ar7
	pop	ar7
	ljmp	00126$
00122$:
;	quantum/send_string/send_string.c:174: } else if (ascii_code == SS_DOWN_CODE) {
	cjne	r2,#0x02,00119$
;	quantum/send_string/send_string.c:176: uint8_t keycode = *(++string);
	push	ar7
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,#0x01
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r0
	mov	dph,r1
	mov	b,r7
	lcall	__gptrget
;	quantum/send_string/send_string.c:177: register_code(keycode);
	mov	dpl,a
	push	ar7
	lcall	_register_code
	pop	ar7
	pop	ar7
	ljmp	00126$
00119$:
;	quantum/send_string/send_string.c:178: } else if (ascii_code == SS_UP_CODE) {
	cjne	r2,#0x03,00116$
;	quantum/send_string/send_string.c:180: uint8_t keycode = *(++string);
	push	ar7
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,#0x01
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r0
	mov	dph,r1
	mov	b,r7
	lcall	__gptrget
;	quantum/send_string/send_string.c:181: unregister_code(keycode);
	mov	dpl,a
	push	ar7
	lcall	_unregister_code
	pop	ar7
	pop	ar7
	ljmp	00126$
00116$:
;	quantum/send_string/send_string.c:182: } else if (ascii_code == SS_DELAY_CODE) {
	cjne	r2,#0x04,00273$
	sjmp	00274$
00273$:
	ljmp	00126$
00274$:
;	quantum/send_string/send_string.c:184: int     ms      = 0;
	mov	dptr,#_send_string_with_delay_ms_90000_228
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:185: uint8_t keycode = *(++string);
	mov	dptr,#_send_string_with_delay_string_10000_215
	inc	a
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	dptr,#_send_string_with_delay_keycode_90000_228
	movx	@dptr,a
;	quantum/send_string/send_string.c:186: while (isdigit(keycode)) {
00103$:
	mov	dptr,#_send_string_with_delay_keycode_90000_228
	movx	a,@dptr
	mov	r2,a
;	/workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/ctype.h:62: return ((unsigned char)c >= '0' && (unsigned char)c <= '9');
	cjne	r2,#0x30,00275$
00275$:
	jc	00189$
	mov	a,r2
	add	a,#0xff - 0x39
	jc	00189$
;	free result
;	quantum/send_string/send_string.c:187: ms *= 10;
	push	ar7
	mov	dptr,#_send_string_with_delay_ms_90000_228
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#__mulint_PARM_2
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	dptr,#0x000a
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	__mulint
	mov	a, dpl
	mov	b, dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	dptr,#_send_string_with_delay_ms_90000_228
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:188: ms += keycode - '0';
	mov	dptr,#_send_string_with_delay_keycode_90000_228
	movx	a,@dptr
	mov	r2,#0x00
	add	a,#0xd0
	mov	r1,a
	mov	a,r2
	addc	a,#0xff
	mov	r2,a
	mov	dptr,#_send_string_with_delay_ms_90000_228
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_send_string_with_delay_ms_90000_228
	mov	a,r1
	add	a, r0
	movx	@dptr,a
	mov	a,r2
	addc	a, r7
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:189: keycode = *(++string);
	inc	r4
	cjne	r4,#0x00,00278$
	inc	r5
00278$:
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	dptr,#_send_string_with_delay_keycode_90000_228
	movx	@dptr,a
	pop	ar7
	ljmp	00103$
;	quantum/send_string/send_string.c:191: while (ms--)
00189$:
	mov	dptr,#_send_string_with_delay_string_10000_215
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_send_string_with_delay_ms_90000_228
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
00110$:
	mov	ar2,r5
	mov	ar4,r6
	dec	r5
	cjne	r5,#0xff,00279$
	dec	r6
00279$:
	mov	a,r2
	orl	a,r4
	jz	00126$
;	quantum/send_string/send_string.c:192: wait_ms(1);
	mov	dptr,#0x0001
	lcall	_mDelaymS
	sjmp	00110$
00125$:
;	quantum/send_string/send_string.c:195: send_char(ascii_code);
	mov	dpl, r3
	push	ar7
	lcall	_send_char
	pop	ar7
00126$:
;	quantum/send_string/send_string.c:197: ++string;
	mov	dptr,#_send_string_with_delay_string_10000_215
	movx	a,@dptr
	add	a, #0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a, #0x00
	movx	@dptr,a
;	quantum/send_string/send_string.c:201: while (ms--)
	mov	ar6,r7
00131$:
	mov	ar5,r6
	dec	r6
	mov	a,r5
	jnz	00281$
	ljmp	00135$
00281$:
;	quantum/send_string/send_string.c:202: wait_ms(1);
	mov	dptr,#0x0001
	lcall	_mDelaymS
;	quantum/send_string/send_string.c:205: }
	sjmp	00131$
;------------------------------------------------------------
;Allocation info for local variables in function 'send_char'
;------------------------------------------------------------
;sloc1         Allocated with name '_send_char_sloc1_1_0'
;sloc2         Allocated with name '_send_char_sloc2_1_0'
;sloc3         Allocated with name '_send_char_sloc3_1_0'
;ascii_code    Allocated with name '_send_char_ascii_code_10000_241'
;ascii_index   Allocated with name '_send_char_ascii_index_10000_242'
;bit_mask      Allocated with name '_send_char_bit_mask_10000_242'
;bit_index     Allocated with name '_send_char_bit_index_10000_242'
;keycode       Allocated with name '_send_char_keycode_10000_242'
;is_shifted    Allocated with name '_send_char_is_shifted_10000_242'
;is_altgred    Allocated with name '_send_char_is_altgred_10000_242'
;is_dead       Allocated with name '_send_char_is_dead_10000_242'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:207: void send_char(char ascii_code) {
;	-----------------------------------------
;	 function send_char
;	-----------------------------------------
_send_char:
	mov	a,dpl
	mov	dptr,#_send_char_ascii_code_10000_241
	movx	@dptr,a
;	quantum/send_string/send_string.c:216: uint8_t ascii_index = (uint8_t)ascii_code;
	movx	a,@dptr
;	quantum/send_string/send_string.c:217: uint8_t bit_mask    = pgm_read_byte(&ascii_bit_mask_lut[ascii_index & 7]);
	mov	r7,a
	mov	r6,a
	mov	a,#0x07
	anl	a,r6
	mov	dptr,#_ascii_bit_mask_lut
	movc	a,@a+dptr
	mov	r6,a
;	quantum/send_string/send_string.c:218: uint8_t bit_index   = ascii_index >> 3;
	mov	a,r7
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r5,a
;	quantum/send_string/send_string.c:219: uint8_t keycode     = pgm_read_byte(&ascii_to_keycode_lut[ascii_index]);
	mov	a,r7
	mov	dptr,#_ascii_to_keycode_lut
	movc	a,@a+dptr
	mov	r7,a
;	quantum/send_string/send_string.c:220: bool    is_shifted  = (pgm_read_byte(&ascii_to_shift_lut[bit_index]) & bit_mask) != 0;
	mov	a,r5
	mov	dptr,#_ascii_to_shift_lut
	movc	a,@a+dptr
	mov	r4,a
	mov	a,r6
	anl	ar4,a
	mov	a,r4
	cjne	a,#0x01,00148$
00148$:
	mov  _send_char_sloc0_1_0,c
	cpl	c
	clr	a
	rlc	a
	mov	_send_char_sloc1_1_0,a
;	quantum/send_string/send_string.c:221: bool    is_altgred  = (pgm_read_byte(&ascii_to_altgr_lut[bit_index]) & bit_mask) != 0;
	mov	a,r5
	mov	dptr,#_ascii_to_altgr_lut
	movc	a,@a+dptr
	mov	r4,a
	mov	a,r6
	anl	ar4,a
	mov	a,r4
	cjne	a,#0x01,00149$
00149$:
	mov  _send_char_sloc0_1_0,c
	cpl	c
	clr	a
	rlc	a
	mov	_send_char_sloc2_1_0,a
;	quantum/send_string/send_string.c:222: bool    is_dead     = (pgm_read_byte(&ascii_to_dead_lut[bit_index]) & bit_mask) != 0;
	mov	a,r5
	mov	dptr,#_ascii_to_dead_lut
	movc	a,@a+dptr
	anl	ar6,a
	mov	a,r6
	cjne	a,#0x01,00150$
00150$:
	mov  _send_char_sloc0_1_0,c
	cpl	c
	clr	a
	rlc	a
	mov	_send_char_sloc3_1_0,a
;	quantum/send_string/send_string.c:230: if (is_shifted) {
	mov	a,_send_char_sloc1_1_0
	jz	00102$
;	quantum/send_string/send_string.c:231: register_code(KC_LEFT_SHIFT);
	mov	dpl, #0xe1
	push	ar7
	lcall	_register_code
	pop	ar7
00102$:
;	quantum/send_string/send_string.c:233: if (is_altgred) {
	mov	a,_send_char_sloc2_1_0
	jz	00104$
;	quantum/send_string/send_string.c:234: register_code(KC_RIGHT_ALT);
	mov	dpl, #0xe6
	push	ar7
	lcall	_register_code
	pop	ar7
00104$:
;	quantum/send_string/send_string.c:236: tap_code(keycode);
	mov	dpl, r7
	lcall	_tap_code
;	quantum/send_string/send_string.c:237: if (is_altgred) {
	mov	a,_send_char_sloc2_1_0
	jz	00106$
;	quantum/send_string/send_string.c:238: unregister_code(KC_RIGHT_ALT);
	mov	dpl, #0xe6
	lcall	_unregister_code
00106$:
;	quantum/send_string/send_string.c:240: if (is_shifted) {
	mov	a,_send_char_sloc1_1_0
	jz	00108$
;	quantum/send_string/send_string.c:241: unregister_code(KC_LEFT_SHIFT);
	mov	dpl, #0xe1
	lcall	_unregister_code
00108$:
;	quantum/send_string/send_string.c:243: if (is_dead) {
	mov	a,_send_char_sloc3_1_0
	jz	00111$
;	quantum/send_string/send_string.c:244: tap_code(KC_SPACE);
	mov	dpl, #0x2c
;	quantum/send_string/send_string.c:246: }
	ljmp	_tap_code
00111$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'send_dword'
;------------------------------------------------------------
;number        Allocated with name '_send_dword_number_10000_253'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:248: void send_dword(uint32_t number) {
;	-----------------------------------------
;	 function send_dword
;	-----------------------------------------
_send_dword:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	mov	dptr,#_send_dword_number_10000_253
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:249: send_word(number >> 16);
	mov	dptr,#_send_dword_number_10000_253
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar2,r6
	mov	ar3,r7
	mov	dpl, r2
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_send_word
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/send_string/send_string.c:250: send_word(number & 0xFFFFUL);
	mov	dpl, r4
	mov	dph, r5
;	quantum/send_string/send_string.c:251: }
	ljmp	_send_word
;------------------------------------------------------------
;Allocation info for local variables in function 'send_word'
;------------------------------------------------------------
;number        Allocated with name '_send_word_number_10000_255'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:253: void send_word(uint16_t number) {
;	-----------------------------------------
;	 function send_word
;	-----------------------------------------
_send_word:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_send_word_number_10000_255
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/send_string/send_string.c:254: send_byte(number >> 8);
	mov	dptr,#_send_word_number_10000_255
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,a
	push	ar7
	push	ar6
	lcall	_send_byte
	pop	ar6
	pop	ar7
;	quantum/send_string/send_string.c:255: send_byte(number & 0xFF);
	mov	dpl, r6
;	quantum/send_string/send_string.c:256: }
	ljmp	_send_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'send_byte'
;------------------------------------------------------------
;number        Allocated with name '_send_byte_number_10000_257'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:258: void send_byte(uint8_t number) {
;	-----------------------------------------
;	 function send_byte
;	-----------------------------------------
_send_byte:
	mov	a,dpl
	mov	dptr,#_send_byte_number_10000_257
	movx	@dptr,a
;	quantum/send_string/send_string.c:259: send_nibble(number >> 4);
	movx	a,@dptr
	mov	r7,a
	swap	a
	anl	a,#0x0f
	mov	dpl,a
	push	ar7
	lcall	_send_nibble
	pop	ar7
;	quantum/send_string/send_string.c:260: send_nibble(number & 0xF);
	anl	ar7,#0x0f
	mov	dpl, r7
;	quantum/send_string/send_string.c:261: }
	ljmp	_send_nibble
;------------------------------------------------------------
;Allocation info for local variables in function 'send_nibble'
;------------------------------------------------------------
;number        Allocated with name '_send_nibble_number_10000_259'
;number_4b     Allocated with name '_send_nibble_number_4b_10000_260'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:263: void send_nibble(uint8_t number) {
;	-----------------------------------------
;	 function send_nibble
;	-----------------------------------------
_send_nibble:
	mov	a,dpl
	mov	dptr,#_send_nibble_number_10000_259
	movx	@dptr,a
;	quantum/send_string/send_string.c:272: uint8_t number_4b = number & 0xf;
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x0f
	anl	a,r7
	mov	r6,a
;	quantum/send_string/send_string.c:273: if (number_4b < 10)
	cjne	r6,#0x0a,00122$
00122$:
	jnc	00105$
;	quantum/send_string/send_string.c:274: send_char(number + '0');
	mov	ar6,r7
	mov	a,#0x30
	add	a, r6
	mov	dpl,a
	ljmp	_send_char
00105$:
;	quantum/send_string/send_string.c:276: send_char(number - 10 + 'a');
	mov	a,#0x57
	add	a, r7
	mov	dpl,a
;	quantum/send_string/send_string.c:277: }
	ljmp	_send_char
;------------------------------------------------------------
;Allocation info for local variables in function 'tap_random_base64'
;------------------------------------------------------------
;key           Allocated with name '_tap_random_base64_key_10000_264'
;------------------------------------------------------------
;	quantum/send_string/send_string.c:279: void tap_random_base64(void) {
;	-----------------------------------------
;	 function tap_random_base64
;	-----------------------------------------
_tap_random_base64:
;	quantum/send_string/send_string.c:283: uint8_t key = rand() % 64;
	lcall	_rand
	mov	r6, dpl
	mov	r7, dph
	mov	dptr,#__modsint_PARM_2
	mov	a,#0x40
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
	lcall	__modsint
;	quantum/send_string/send_string.c:287: if      (key <= 25) // the >= 0 check seems stupid
	mov	a,dpl
	mov	r6,a
	add	a,#0xff - 0x19
	jc	00118$
;	free result
;	quantum/send_string/send_string.c:288: send_char(key + 'A');
	mov	ar7,r6
	mov	a,#0x41
	add	a, r7
	mov	dpl,a
	ljmp	_send_char
00118$:
;	quantum/send_string/send_string.c:289: else if (key >= 26 && key <= 51)
	mov	a,r6
	add	a,#0xff - 0x33
	jc	00114$
;	free result
;	quantum/send_string/send_string.c:290: send_char(key - 26 + 'a');
	mov	ar7,r6
	mov	a,#0x47
	add	a, r7
	mov	dpl,a
	ljmp	_send_char
00114$:
;	quantum/send_string/send_string.c:291: else if (key == 52)
	cjne	r6,#0x34,00111$
;	quantum/send_string/send_string.c:292: send_char('0');
	mov	dpl, #0x30
	ljmp	_send_char
00111$:
;	quantum/send_string/send_string.c:293: else if (key >= 53 && key <= 61)
	cjne	r6,#0x35,00178$
00178$:
	jc	00107$
	mov	a,r6
	add	a,#0xff - 0x3d
	jc	00107$
;	free result
;	quantum/send_string/send_string.c:294: send_char(key - 53 + '1');
	mov	ar7,r6
	mov	a,#0xfc
	add	a, r7
	mov	dpl,a
	ljmp	_send_char
00107$:
;	quantum/send_string/send_string.c:295: else if (key == 62)
	cjne	r6,#0x3e,00104$
;	quantum/send_string/send_string.c:296: send_char('+');
	mov	dpl, #0x2b
	ljmp	_send_char
00104$:
;	quantum/send_string/send_string.c:297: else if (key == 63)
	cjne	r6,#0x3f,00120$
;	quantum/send_string/send_string.c:298: send_char('/');
	mov	dpl, #0x2f
;	quantum/send_string/send_string.c:300: }
	ljmp	_send_char
00120$:
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_ascii_to_shift_lut:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x0f	; 15
	.db #0x00	; 0
	.db #0xd4	; 212
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xff	; 255
	.db #0xc7	; 199
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x78	; 120	'x'
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ascii_to_altgr_lut:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ascii_to_dead_lut:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ascii_to_keycode_lut:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x2a	; 42
	.db #0x2b	; 43
	.db #0x28	; 40
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x29	; 41
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x2c	; 44
	.db #0x1e	; 30
	.db #0x34	; 52	'4'
	.db #0x20	; 32
	.db #0x21	; 33
	.db #0x22	; 34
	.db #0x24	; 36
	.db #0x34	; 52	'4'
	.db #0x26	; 38
	.db #0x27	; 39
	.db #0x25	; 37
	.db #0x2e	; 46
	.db #0x36	; 54	'6'
	.db #0x2d	; 45
	.db #0x37	; 55	'7'
	.db #0x38	; 56	'8'
	.db #0x27	; 39
	.db #0x1e	; 30
	.db #0x1f	; 31
	.db #0x20	; 32
	.db #0x21	; 33
	.db #0x22	; 34
	.db #0x23	; 35
	.db #0x24	; 36
	.db #0x25	; 37
	.db #0x26	; 38
	.db #0x33	; 51	'3'
	.db #0x33	; 51	'3'
	.db #0x36	; 54	'6'
	.db #0x2e	; 46
	.db #0x37	; 55	'7'
	.db #0x38	; 56	'8'
	.db #0x1f	; 31
	.db #0x04	; 4
	.db #0x05	; 5
	.db #0x06	; 6
	.db #0x07	; 7
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x0a	; 10
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x0d	; 13
	.db #0x0e	; 14
	.db #0x0f	; 15
	.db #0x10	; 16
	.db #0x11	; 17
	.db #0x12	; 18
	.db #0x13	; 19
	.db #0x14	; 20
	.db #0x15	; 21
	.db #0x16	; 22
	.db #0x17	; 23
	.db #0x18	; 24
	.db #0x19	; 25
	.db #0x1a	; 26
	.db #0x1b	; 27
	.db #0x1c	; 28
	.db #0x1d	; 29
	.db #0x2f	; 47
	.db #0x31	; 49	'1'
	.db #0x30	; 48	'0'
	.db #0x23	; 35
	.db #0x2d	; 45
	.db #0x35	; 53	'5'
	.db #0x04	; 4
	.db #0x05	; 5
	.db #0x06	; 6
	.db #0x07	; 7
	.db #0x08	; 8
	.db #0x09	; 9
	.db #0x0a	; 10
	.db #0x0b	; 11
	.db #0x0c	; 12
	.db #0x0d	; 13
	.db #0x0e	; 14
	.db #0x0f	; 15
	.db #0x10	; 16
	.db #0x11	; 17
	.db #0x12	; 18
	.db #0x13	; 19
	.db #0x14	; 20
	.db #0x15	; 21
	.db #0x16	; 22
	.db #0x17	; 23
	.db #0x18	; 24
	.db #0x19	; 25
	.db #0x1a	; 26
	.db #0x1b	; 27
	.db #0x1c	; 28
	.db #0x1d	; 29
	.db #0x2f	; 47
	.db #0x31	; 49	'1'
	.db #0x30	; 48	'0'
	.db #0x35	; 53	'5'
	.db #0x4c	; 76	'L'
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ascii_bit_mask_lut:
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x04	; 4
	.db #0x08	; 8
	.db #0x10	; 16
	.db #0x20	; 32
	.db #0x40	; 64
	.db #0x80	; 128
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
