                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000583                        109 _page_data:
      000583                        110 	.ds 64
      0005C3                        111 _cached_page:
      0005C3                        112 	.ds 1
      0005C4                        113 _batch_depth:
      0005C4                        114 	.ds 1
      0005C5                        115 _first_failure_stage:
      0005C5                        116 	.ds 1
      0005C6                        117 _nvm_fail_stage_10000_20:
      0005C6                        118 	.ds 1
      0005C7                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005C7                        120 	.ds 2
      0005C9                        121 _crc_byte_PARM_2:
      0005C9                        122 	.ds 1
      0005CA                        123 _crc_byte_crc_10000_25:
      0005CA                        124 	.ds 2
      0005CC                        125 _page_crc_crc_10000_30:
      0005CC                        126 	.ds 2
      0005CE                        127 _write_page_address_10000_32:
      0005CE                        128 	.ds 2
      0005D0                        129 _journal_header_valid_header_10000_39:
      0005D0                        130 	.ds 2
      0005D2                        131 _recover_journal_header_10000_46:
      0005D2                        132 	.ds 9
      0005DB                        133 _ak820_nvm_flush_header_10000_62:
      0005DB                        134 	.ds 9
      0005E4                        135 _ak820_nvm_flush_stage_10000_62:
      0005E4                        136 	.ds 1
      0005E5                        137 _load_page_page_10000_87:
      0005E5                        138 	.ds 1
      0005E6                        139 _read_offset_offset_10000_93:
      0005E6                        140 	.ds 2
      0005E8                        141 _eeprom_read_byte_addr_10000_97:
      0005E8                        142 	.ds 3
      0005EB                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005EB                        144 	.ds 3
      0005EE                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005EE                        146 	.ds 2
      0005F0                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005F0                        148 	.ds 2
      0005F2                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005F2                        150 	.ds 2
      0005F4                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005F4                        152 	.ds 3
      0005F7                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005F7                        154 	.ds 2
      0005F9                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005F9                        156 	.ds 2
      0005FB                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005FB                        158 	.ds 3
      0005FE                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005FE                        160 	.ds 2
      000600                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000600                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      004110                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      004110 E5 82            [12]  215 	mov	a,dpl
      004112 90 05 C6         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      004115 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      004116 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      004119 90 05 C6         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      00411C E0               [24]  221 	movx	a,@dptr
      00411D 90 05 C5         [24]  222 	mov	dptr,#_first_failure_stage
      004120 F0               [24]  223 	movx	@dptr,a
      004121                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      004121 D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      004123 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      004124                        239 _ak820_nvm_diagnostic:
      004124 12 3A C2         [24]  240 	lcall	_ak820_outline_0108
      004127 90 05 C7         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      00412A 12 3A C7         [24]  242 	lcall	_ak820_outline_0109
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      00412D 90 05 C7         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004130 12 3A 81         [24]  245 	lcall	_ak820_outline_0052
      004133 A2 0C            [12]  246 	mov	c,_storage_failed
      004135 E4               [12]  247 	clr	a
      004136 33               [12]  248 	rlc	a
      004137 12 3A CC         [24]  249 	lcall	_ak820_outline_0118
      00413A 12 48 CB         [24]  250 	lcall	_ak820_outline_0071
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      00413D A3               [24]  252 	inc	dptr
      00413E A2 0A            [12]  253 	mov	c,_page_valid
      004140 E4               [12]  254 	clr	a
      004141 33               [12]  255 	rlc	a
      004142 12 48 98         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      004145 A2 0B            [12]  258 	mov	c,_page_dirty
      004147 E4               [12]  259 	clr	a
      004148 33               [12]  260 	rlc	a
      004149 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      00414A 74 03            [12]  263 	mov	a,#0x03
      00414C 12 49 04         [24]  264 	lcall	_ak820_outline_0160
      00414F 90 05 C4         [24]  265 	mov	dptr,#_batch_depth
      004152 E0               [24]  266 	movx	a,@dptr
      004153 12 3A D7         [24]  267 	lcall	_ak820_outline_0124
      004156 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      004157 74 04            [12]  270 	mov	a,#0x04
      004159 12 49 04         [24]  271 	lcall	_ak820_outline_0160
      00415C 90 05 C3         [24]  272 	mov	dptr,#_cached_page
      00415F E0               [24]  273 	movx	a,@dptr
      004160 12 3A D7         [24]  274 	lcall	_ak820_outline_0124
      004163 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      004164 12 48 8E         [24]  277 	lcall	_ak820_outline_0012
      004167 E4               [12]  278 	clr	a
      004168 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      004169 74 06            [12]  281 	mov	a,#0x06
      00416B 12 48 EE         [24]  282 	lcall	_ak820_outline_0137
      00416E 90 05 C5         [24]  283 	mov	dptr,#_first_failure_stage
      004171 E0               [24]  284 	movx	a,@dptr
      004172 12 3A CC         [24]  285 	lcall	_ak820_outline_0118
      004175 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      004176 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      004177                        300 _crc_byte:
      004177 12 3A C2         [24]  301 	lcall	_ak820_outline_0108
      00417A 90 05 CA         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      00417D 12 3A C7         [24]  303 	lcall	_ak820_outline_0109
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      004180 90 05 C9         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      004183 E0               [24]  306 	movx	a,@dptr
      004184 FF               [12]  307 	mov	r7,a
      004185 7E 00            [12]  308 	mov	r6,#0x00
      004187 90 05 CA         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      00418A E0               [24]  310 	movx	a,@dptr
      00418B 6E               [12]  311 	xrl	a,r6
      00418C F0               [24]  312 	movx	@dptr,a
      00418D A3               [24]  313 	inc	dptr
      00418E E0               [24]  314 	movx	a,@dptr
      00418F 6F               [12]  315 	xrl	a,r7
      004190 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      004191 7F 00            [12]  318 	mov	r7,#0x00
      004193                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      004193 90 05 CA         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      004196 12 3A A4         [24]  322 	lcall	_ak820_outline_0079
      004199 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      00419C ED               [12]  324 	mov	a,r5
      00419D 2D               [12]  325 	add	a,r5
      00419E FB               [12]  326 	mov	r3,a
      00419F EE               [12]  327 	mov	a,r6
      0041A0 33               [12]  328 	rlc	a
      0041A1 FC               [12]  329 	mov	r4,a
      0041A2 63 03 21         [24]  330 	xrl	ar3,#0x21
      0041A5 63 04 10         [24]  331 	xrl	ar4,#0x10
      0041A8 80 06            [24]  332 	sjmp	00107$
      0041AA                        333 00106$:
      0041AA ED               [12]  334 	mov	a,r5
      0041AB 2D               [12]  335 	add	a,r5
      0041AC FB               [12]  336 	mov	r3,a
      0041AD EE               [12]  337 	mov	a,r6
      0041AE 33               [12]  338 	rlc	a
      0041AF FC               [12]  339 	mov	r4,a
      0041B0                        340 00107$:
      0041B0 90 05 CA         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      0041B3 12 3A AA         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      0041B6 0F               [12]  344 	inc	r7
      0041B7 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      0041BA 12 36 47         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      0041BD 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      0041BE                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      0041BE 90 05 CC         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      0041C1 74 FF            [12]  363 	mov	a,#0xff
      0041C3 F0               [24]  364 	movx	@dptr,a
      0041C4 A3               [24]  365 	inc	dptr
      0041C5 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      0041C6 7F 00            [12]  368 	mov	r7,#0x00
      0041C8                        369 00102$:
      0041C8 90 05 CC         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      0041CB 12 3A A4         [24]  371 	lcall	_ak820_outline_0079
      0041CE 12 48 DD         [24]  372 	lcall	_ak820_outline_0106
      0041D1 90 05 C9         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      0041D4 F0               [24]  374 	movx	@dptr,a
      0041D5 12 3A E1         [24]  375 	lcall	_ak820_outline_0135
      0041D8 C0 07            [24]  376 	push	ar7
      0041DA 12 41 77         [24]  377 	lcall	_crc_byte
      0041DD AD 82            [24]  378 	mov	r5, dpl
      0041DF AE 83            [24]  379 	mov	r6, dph
      0041E1 D0 07            [24]  380 	pop	ar7
      0041E3 90 05 CC         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      0041E6 12 49 0A         [24]  382 	lcall	_ak820_outline_0161
      0041E9 0F               [12]  383 	inc	r7
      0041EA BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      0041ED 12 3A E1         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      0041F0 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      0041F1                        399 _write_page:
      0041F1 12 3A C2         [24]  400 	lcall	_ak820_outline_0108
      0041F4 90 05 CE         [24]  401 	mov	dptr,#_write_page_address_10000_32
      0041F7 12 3A C7         [24]  402 	lcall	_ak820_outline_0109
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      0041FA 90 05 CE         [24]  404 	mov	dptr,#_write_page_address_10000_32
      0041FD 12 3A 34         [24]  405 	lcall	_ak820_outline_0005
      004200 C0 07            [24]  406 	push	ar7
      004202 C0 06            [24]  407 	push	ar6
      004204 12 3F 89         [24]  408 	lcall	_ak820_flash_erase
      004207 E5 82            [12]  409 	mov	a, dpl
      004209 D0 06            [24]  410 	pop	ar6
      00420B D0 07            [24]  411 	pop	ar7
      00420D 70 03            [24]  412 	jnz	00102$
      00420F F5 82            [12]  413 	mov	dpl,a
      004211 22               [24]  414 	ret
      004212                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      004212 90 05 5F         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      004215 74 83            [12]  418 	mov	a,#_page_data
      004217 F0               [24]  419 	movx	@dptr,a
      004218 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      00421A A3               [24]  421 	inc	dptr
      00421B 12 48 CB         [24]  422 	lcall	_ak820_outline_0071
      00421E 12 40 9D         [24]  423 	lcall	_ak820_flash_program_page
      004221 E5 82            [12]  424 	mov	a, dpl
      004223 70 03            [24]  425 	jnz	00120$
      004225 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004227 22               [24]  428 	ret
      004228                        429 00120$:
      004228 7F 00            [12]  430 	mov	r7,#0x00
      00422A                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      00422A 8F 05            [24]  433 	mov	ar5,r7
      00422C 7E 00            [12]  434 	mov	r6,#0x00
      00422E 90 05 CE         [24]  435 	mov	dptr,#_write_page_address_10000_32
      004231 12 3A D1         [24]  436 	lcall	_ak820_outline_0123
      004234 ED               [12]  437 	mov	a,r5
      004235 2B               [12]  438 	add	a, r3
      004236 FB               [12]  439 	mov	r3,a
      004237 EE               [12]  440 	mov	a,r6
      004238 3C               [12]  441 	addc	a, r4
      004239 FC               [12]  442 	mov	r4,a
      00423A 12 36 47         [24]  443 	lcall	_ak820_outline_0121
      00423D 12 3E 7C         [24]  444 	lcall	_ak820_flash_read
      004240 AE 82            [24]  445 	mov	r6, dpl
      004242 12 48 DD         [24]  446 	lcall	_ak820_outline_0106
      004245 FD               [12]  447 	mov	r5,a
      004246 EE               [12]  448 	mov	a,r6
      004247 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      00424A 80 04            [24]  450 	sjmp	00109$
      00424C                        451 00149$:
      00424C 75 82 00         [24]  452 	mov	dpl, #0x00
      00424F 22               [24]  453 	ret
      004250                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004250 0F               [12]  456 	inc	r7
      004251 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      004254 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      004257 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      004258                        472 _journal_header_valid:
      004258 12 3A C2         [24]  473 	lcall	_ak820_outline_0108
      00425B 90 05 D0         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      00425E 12 3A C7         [24]  475 	lcall	_ak820_outline_0109
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      004261 90 05 D0         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      004264 12 3A 34         [24]  478 	lcall	_ak820_outline_0005
      004267 E0               [24]  479 	movx	a,@dptr
      004268 FD               [12]  480 	mov	r5,a
      004269 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      00426C 80 04            [24]  482 	sjmp	00116$
      00426E                        483 00138$:
      00426E 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004271 22               [24]  486 	ret
      004272                        487 00116$:
      004272 7D 01            [12]  488 	mov	r5,#0x01
      004274                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      004274 ED               [12]  491 	mov	a,r5
      004275 12 3A 71         [24]  492 	lcall	_ak820_outline_0022
      004278 E0               [24]  493 	movx	a,@dptr
      004279 FC               [12]  494 	mov	r4,a
      00427A 8D 02            [24]  495 	mov	ar2,r5
      00427C 7B 00            [12]  496 	mov	r3,#0x00
      00427E 74 04            [12]  497 	mov	a,#0x04
      004280 2A               [12]  498 	add	a, r2
      004281 FA               [12]  499 	mov	r2,a
      004282 E4               [12]  500 	clr	a
      004283 3B               [12]  501 	addc	a, r3
      004284 FB               [12]  502 	mov	r3,a
      004285 EA               [12]  503 	mov	a,r2
      004286 2E               [12]  504 	add	a, r6
      004287 F5 82            [12]  505 	mov	dpl,a
      004289 EB               [12]  506 	mov	a,r3
      00428A 3F               [12]  507 	addc	a, r7
      00428B F5 83            [12]  508 	mov	dph,a
      00428D E0               [24]  509 	movx	a,@dptr
      00428E 62 04            [12]  510 	xrl	ar4,a
      004290 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      004293 80 04            [24]  512 	sjmp	00107$
      004295                        513 00139$:
      004295 75 82 00         [24]  514 	mov	dpl, #0x00
      004298 22               [24]  515 	ret
      004299                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004299 0D               [12]  518 	inc	r5
      00429A BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      00429D 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      0042A0 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      0042A1                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      0042A1 7F 00            [12]  538 	mov	r7,#0x00
      0042A3                        539 00115$:
      0042A3 EF               [12]  540 	mov	a,r7
      0042A4 24 D2            [12]  541 	add	a, #_recover_journal_header_10000_46
      0042A6 FD               [12]  542 	mov	r5,a
      0042A7 E4               [12]  543 	clr	a
      0042A8 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      0042AA FE               [12]  545 	mov	r6,a
      0042AB 8F 04            [24]  546 	mov	ar4,r7
      0042AD 7B 00            [12]  547 	mov	r3,#0x00
      0042AF 74 40            [12]  548 	mov	a,#0x40
      0042B1 2C               [12]  549 	add	a, r4
      0042B2 FC               [12]  550 	mov	r4,a
      0042B3 74 EF            [12]  551 	mov	a,#0xef
      0042B5 3B               [12]  552 	addc	a, r3
      0042B6 FB               [12]  553 	mov	r3,a
      0042B7 12 49 15         [24]  554 	lcall	_ak820_outline_0183
      0042BA 12 3E 7C         [24]  555 	lcall	_ak820_flash_read
      0042BD AC 82            [24]  556 	mov	r4, dpl
      0042BF 12 48 C4         [24]  557 	lcall	_ak820_outline_0063
      0042C2 0F               [12]  558 	inc	r7
      0042C3 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      0042C6 90 05 D2         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      0042C9 12 42 58         [24]  562 	lcall	_journal_header_valid
      0042CC E5 82            [12]  563 	mov	a, dpl
      0042CE 70 01            [24]  564 	jnz	00103$
      0042D0 22               [24]  565 	ret
      0042D1                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      0042D1 90 05 D3         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      0042D4 E0               [24]  569 	movx	a,@dptr
      0042D5 FF               [12]  570 	mov	r7,a
      0042D6 7E 00            [12]  571 	mov	r6,#0x00
      0042D8 90 05 D4         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      0042DB E0               [24]  573 	movx	a,@dptr
      0042DC FC               [12]  574 	mov	r4,a
      0042DD E4               [12]  575 	clr	a
      0042DE 42 07            [12]  576 	orl	ar7,a
      0042E0 EC               [12]  577 	mov	a,r4
      0042E1 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      0042E3 90 05 D5         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      0042E6 E0               [24]  581 	movx	a,@dptr
      0042E7 FD               [12]  582 	mov	r5,a
      0042E8 7C 00            [12]  583 	mov	r4,#0x00
      0042EA 90 05 D6         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      0042ED E0               [24]  585 	movx	a,@dptr
      0042EE FA               [12]  586 	mov	r2,a
      0042EF E4               [12]  587 	clr	a
      0042F0 12 48 F4         [24]  588 	lcall	_ak820_outline_0142
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      0042F3 C3               [12]  590 	clr	c
      0042F4 EF               [12]  591 	mov	a,r7
      0042F5 94 A0            [12]  592 	subb	a,#0xa0
      0042F7 EE               [12]  593 	mov	a,r6
      0042F8 94 00            [12]  594 	subb	a,#0x00
      0042FA 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      0042FC 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      0042FF 02 41 10         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      004302                        601 00134$:
      004302 7B 00            [12]  602 	mov	r3,#0x00
      004304                        603 00117$:
      004304 C0 05            [24]  604 	push	ar5
      004306 C0 04            [24]  605 	push	ar4
      004308 EB               [12]  606 	mov	a,r3
      004309 24 83            [12]  607 	add	a, #_page_data
      00430B F9               [12]  608 	mov	r1,a
      00430C E4               [12]  609 	clr	a
      00430D 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      00430F FA               [12]  611 	mov	r2,a
      004310 8B 00            [24]  612 	mov	ar0,r3
      004312 7D 00            [12]  613 	mov	r5,#0x00
      004314 74 EF            [12]  614 	mov	a,#0xef
      004316 2D               [12]  615 	add	a, r5
      004317 FD               [12]  616 	mov	r5,a
      004318 88 82            [24]  617 	mov	dpl, r0
      00431A 8D 83            [24]  618 	mov	dph, r5
      00431C 12 3E 7C         [24]  619 	lcall	_ak820_flash_read
      00431F AD 82            [24]  620 	mov	r5, dpl
      004321 12 49 10         [24]  621 	lcall	_ak820_outline_0182
      004324 ED               [12]  622 	mov	a,r5
      004325 F0               [24]  623 	movx	@dptr,a
      004326 0B               [12]  624 	inc	r3
      004327 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      00432A 80 06            [24]  626 	sjmp	00191$
      00432C                        627 00190$:
      00432C D0 04            [24]  628 	pop	ar4
      00432E D0 05            [24]  629 	pop	ar5
      004330 80 D2            [24]  630 	sjmp	00117$
      004332                        631 00191$:
      004332 D0 04            [24]  632 	pop	ar4
      004334 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      004336 C0 07            [24]  635 	push	ar7
      004338 C0 06            [24]  636 	push	ar6
      00433A C0 05            [24]  637 	push	ar5
      00433C C0 04            [24]  638 	push	ar4
      00433E 12 41 BE         [24]  639 	lcall	_page_crc
      004341 AA 82            [24]  640 	mov	r2, dpl
      004343 AB 83            [24]  641 	mov	r3, dph
      004345 D0 04            [24]  642 	pop	ar4
      004347 D0 05            [24]  643 	pop	ar5
      004349 D0 06            [24]  644 	pop	ar6
      00434B D0 07            [24]  645 	pop	ar7
      00434D EA               [12]  646 	mov	a,r2
      00434E B5 05 06         [24]  647 	cjne	a,ar5,00192$
      004351 EB               [12]  648 	mov	a,r3
      004352 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004355 80 06            [24]  650 	sjmp	00113$
      004357                        651 00192$:
      004357 75 82 02         [24]  652 	mov	dpl, #0x02
      00435A 02 41 10         [24]  653 	ljmp	_nvm_fail
      00435D                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00435D EE               [12]  656 	mov	a,r6
      00435E 54 03            [12]  657 	anl	a,#0x03
      004360 A2 E0            [12]  658 	mov	c,acc.0
      004362 CF               [12]  659 	xch	a,r7
      004363 13               [12]  660 	rrc	a
      004364 CF               [12]  661 	xch	a,r7
      004365 13               [12]  662 	rrc	a
      004366 A2 E0            [12]  663 	mov	c,acc.0
      004368 CF               [12]  664 	xch	a,r7
      004369 13               [12]  665 	rrc	a
      00436A CF               [12]  666 	xch	a,r7
      00436B 13               [12]  667 	rrc	a
      00436C CF               [12]  668 	xch	a,r7
      00436D 24 C7            [12]  669 	add	a,#0xc7
      00436F FE               [12]  670 	mov	r6,a
      004370 12 48 FF         [24]  671 	lcall	_ak820_outline_0157
      004373 12 41 F1         [24]  672 	lcall	_write_page
      004376 E5 82            [12]  673 	mov	a, dpl
      004378 70 06            [24]  674 	jnz	00110$
      00437A 75 82 03         [24]  675 	mov	dpl, #0x03
      00437D 02 41 10         [24]  676 	ljmp	_nvm_fail
      004380                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004380 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004383 12 3F 89         [24]  680 	lcall	_ak820_flash_erase
      004386 E5 82            [12]  681 	mov	a, dpl
      004388 70 06            [24]  682 	jnz	00119$
      00438A 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00438D 02 41 10         [24]  685 	ljmp	_nvm_fail
      004390                        686 00119$:
      004390 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      004391                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      004391 C2 0C            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004393 90 05 C5         [24]  700 	mov	dptr,#_first_failure_stage
      004396 E4               [12]  701 	clr	a
      004397 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      004398 C2 0B            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      00439A C2 0A            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00439C 90 05 C4         [24]  709 	mov	dptr,#_batch_depth
      00439F E4               [12]  710 	clr	a
      0043A0 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      0043A1 12 42 A1         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      0043A4 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      0043A7                        724 _ak820_nvm_ok:
      0043A7 A2 0C            [12]  725 	mov	c,_storage_failed
      0043A9 B3               [12]  726 	cpl	c
      0043AA 92 0D            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      0043AC 12 3A F6         [24]  728 	lcall	_ak820_outline_0156
      0043AF 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      0043B0                        737 _ak820_nvm_schema_fault:
      0043B0 75 82 10         [24]  738 	mov	dpl, #0x10
      0043B3 02 41 10         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      0043B6                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      0043B6 30 0B 03         [24]  754 	jnb	_page_dirty,00101$
      0043B9 30 0C 01         [24]  755 	jnb	_storage_failed,00102$
      0043BC                        756 00101$:
      0043BC 22               [24]  757 	ret
      0043BD                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0043BD 12 41 BE         [24]  760 	lcall	_page_crc
      0043C0 12 48 E9         [24]  761 	lcall	_ak820_outline_0125
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0043C3 90 05 DB         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0043C6 74 A5            [12]  764 	mov	a,#0xa5
      0043C8 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0043C9 90 05 C3         [24]  767 	mov	dptr,#_cached_page
      0043CC E0               [24]  768 	movx	a,@dptr
      0043CD 90 05 DC         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0043D0 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0043D1 90 05 DD         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0043D4 E4               [12]  773 	clr	a
      0043D5 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0043D6 8E 05            [24]  776 	mov	ar5,r6
      0043D8 90 05 DE         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0043DB ED               [12]  778 	mov	a,r5
      0043DC F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0043DD 8F 06            [24]  781 	mov	ar6,r7
      0043DF 90 05 DF         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0043E2 EE               [12]  783 	mov	a,r6
      0043E3 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0043E4 7F 01            [12]  786 	mov	r7,#0x01
      0043E6                        787 00128$:
      0043E6 8F 06            [24]  788 	mov	ar6,r7
      0043E8 EE               [12]  789 	mov	a,r6
      0043E9 24 04            [12]  790 	add	a,#0x04
      0043EB FE               [12]  791 	mov	r6,a
      0043EC 33               [12]  792 	rlc	a
      0043ED 95 E0            [12]  793 	subb	a,acc
      0043EF FD               [12]  794 	mov	r5,a
      0043F0 EE               [12]  795 	mov	a,r6
      0043F1 24 DB            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0043F3 FE               [12]  797 	mov	r6,a
      0043F4 ED               [12]  798 	mov	a,r5
      0043F5 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0043F7 FD               [12]  800 	mov	r5,a
      0043F8 12 48 A7         [24]  801 	lcall	_ak820_outline_0043
      0043FB FC               [12]  802 	mov	r4,a
      0043FC 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0043FF 8E 82            [24]  804 	mov	dpl,r6
      004401 8D 83            [24]  805 	mov	dph,r5
      004403 EC               [12]  806 	mov	a,r4
      004404 F0               [24]  807 	movx	@dptr,a
      004405 0F               [12]  808 	inc	r7
      004406 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004409 90 05 E4         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00440C 74 05            [12]  812 	mov	a,#0x05
      00440E F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00440F 90 EF 40         [24]  815 	mov	dptr,#0xef40
      004412 12 3F 89         [24]  816 	lcall	_ak820_flash_erase
      004415 E5 82            [12]  817 	mov	a, dpl
      004417 70 03            [24]  818 	jnz	00269$
      004419 02 45 00         [24]  819 	ljmp	00127$
      00441C                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      00441C 90 05 E4         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00441F 74 06            [12]  823 	mov	a,#0x06
      004421 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004422 7F 00            [12]  826 	mov	r7,#0x00
      004424                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004424 12 48 B3         [24]  829 	lcall	_ak820_outline_0053
      004427 12 3E 7C         [24]  830 	lcall	_ak820_flash_read
      00442A E5 82            [12]  831 	mov	a, dpl
      00442C 60 03            [24]  832 	jz	00270$
      00442E 02 45 00         [24]  833 	ljmp	00127$
      004431                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004431 0F               [12]  836 	inc	r7
      004432 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      004435 90 05 E4         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004438 74 07            [12]  840 	mov	a,#0x07
      00443A F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      00443B 90 EF 00         [24]  843 	mov	dptr,#0xef00
      00443E 12 41 F1         [24]  844 	lcall	_write_page
      004441 E5 82            [12]  845 	mov	a, dpl
      004443 70 03            [24]  846 	jnz	00273$
      004445 02 45 00         [24]  847 	ljmp	00127$
      004448                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004448 90 05 E4         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00444B 74 08            [12]  851 	mov	a,#0x08
      00444D F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00444E 7F 01            [12]  854 	mov	r7,#0x01
      004450                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004450 12 48 A7         [24]  857 	lcall	_ak820_outline_0043
      004453 FE               [12]  858 	mov	r6,a
      004454 60 23            [24]  859 	jz	00133$
      004456 8F 05            [24]  860 	mov	ar5,r7
      004458 7C 00            [12]  861 	mov	r4,#0x00
      00445A 74 40            [12]  862 	mov	a,#0x40
      00445C 2D               [12]  863 	add	a, r5
      00445D FD               [12]  864 	mov	r5,a
      00445E 74 EF            [12]  865 	mov	a,#0xef
      004460 3C               [12]  866 	addc	a, r4
      004461 FC               [12]  867 	mov	r4,a
      004462 90 05 5C         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004465 EE               [12]  869 	mov	a,r6
      004466 F0               [24]  870 	movx	@dptr,a
      004467 8D 82            [24]  871 	mov	dpl, r5
      004469 8C 83            [24]  872 	mov	dph, r4
      00446B C0 07            [24]  873 	push	ar7
      00446D 12 3F E9         [24]  874 	lcall	_ak820_flash_program
      004470 E5 82            [12]  875 	mov	a, dpl
      004472 D0 07            [24]  876 	pop	ar7
      004474 70 03            [24]  877 	jnz	00275$
      004476 02 45 00         [24]  878 	ljmp	00127$
      004479                        879 00275$:
      004479                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004479 0F               [12]  882 	inc	r7
      00447A BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00447D 90 05 E4         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004480 74 09            [12]  886 	mov	a,#0x09
      004482 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004483 7F 01            [12]  889 	mov	r7,#0x01
      004485                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004485 12 48 B3         [24]  892 	lcall	_ak820_outline_0053
      004488 12 3E 7C         [24]  893 	lcall	_ak820_flash_read
      00448B AE 82            [24]  894 	mov	r6, dpl
      00448D 12 48 A7         [24]  895 	lcall	_ak820_outline_0043
      004490 FD               [12]  896 	mov	r5,a
      004491 EE               [12]  897 	mov	a,r6
      004492 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004495 0F               [12]  900 	inc	r7
      004496 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004499 90 05 E4         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00449C 74 0A            [12]  904 	mov	a,#0x0a
      00449E F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00449F 90 05 DB         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0044A2 E0               [24]  908 	movx	a,@dptr
      0044A3 90 05 5C         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      0044A6 F0               [24]  910 	movx	@dptr,a
      0044A7 90 EF 40         [24]  911 	mov	dptr,#0xef40
      0044AA 12 3F E9         [24]  912 	lcall	_ak820_flash_program
      0044AD E5 82            [12]  913 	mov	a, dpl
      0044AF 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      0044B1 90 05 E4         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044B4 74 0B            [12]  917 	mov	a,#0x0b
      0044B6 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      0044B7 90 EF 40         [24]  920 	mov	dptr,#0xef40
      0044BA 12 3E 7C         [24]  921 	lcall	_ak820_flash_read
      0044BD AF 82            [24]  922 	mov	r7, dpl
      0044BF 90 05 DB         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0044C2 E0               [24]  924 	movx	a,@dptr
      0044C3 FE               [12]  925 	mov	r6,a
      0044C4 EF               [12]  926 	mov	a,r7
      0044C5 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0044C8 90 05 E4         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044CB 74 0C            [12]  930 	mov	a,#0x0c
      0044CD F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0044CE 90 05 C3         [24]  933 	mov	dptr,#_cached_page
      0044D1 E0               [24]  934 	movx	a,@dptr
      0044D2 FE               [12]  935 	mov	r6,a
      0044D3 E4               [12]  936 	clr	a
      0044D4 C3               [12]  937 	clr	c
      0044D5 CE               [12]  938 	xch	a,r6
      0044D6 13               [12]  939 	rrc	a
      0044D7 CE               [12]  940 	xch	a,r6
      0044D8 13               [12]  941 	rrc	a
      0044D9 A2 E0            [12]  942 	mov	c,acc.0
      0044DB CE               [12]  943 	xch	a,r6
      0044DC 13               [12]  944 	rrc	a
      0044DD CE               [12]  945 	xch	a,r6
      0044DE 13               [12]  946 	rrc	a
      0044DF CE               [12]  947 	xch	a,r6
      0044E0 24 C7            [12]  948 	add	a,#0xc7
      0044E2 FF               [12]  949 	mov	r7,a
      0044E3 12 3A CC         [24]  950 	lcall	_ak820_outline_0118
      0044E6 12 41 F1         [24]  951 	lcall	_write_page
      0044E9 E5 82            [12]  952 	mov	a, dpl
      0044EB 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0044ED 90 05 E4         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044F0 74 0D            [12]  956 	mov	a,#0x0d
      0044F2 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0044F3 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0044F6 12 3F 89         [24]  960 	lcall	_ak820_flash_erase
      0044F9 E5 82            [12]  961 	mov	a, dpl
      0044FB 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0044FD C2 0B            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0044FF 22               [24]  968 	ret
      004500                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      004500 90 05 E4         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004503 E0               [24]  972 	movx	a,@dptr
      004504 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004506 02 41 10         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      004509                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004509 90 05 C4         [24]  985 	mov	dptr,#_batch_depth
      00450C E0               [24]  986 	movx	a,@dptr
      00450D FF               [12]  987 	mov	r7,a
      00450E BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      004511 75 82 0F         [24]  989 	mov	dpl, #0x0f
      004514 02 41 10         [24]  990 	ljmp	_nvm_fail
      004517                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004517 90 05 C4         [24]  993 	mov	dptr,#_batch_depth
      00451A EF               [12]  994 	mov	a,r7
      00451B 04               [12]  995 	inc	a
      00451C F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      00451D 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      00451E                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00451E 90 05 C4         [24] 1008 	mov	dptr,#_batch_depth
      004521 E0               [24] 1009 	movx	a,@dptr
      004522 FF               [12] 1010 	mov	r7,a
      004523 E0               [24] 1011 	movx	a,@dptr
      004524 60 06            [24] 1012 	jz	00102$
      004526 EF               [12] 1013 	mov	a,r7
      004527 14               [12] 1014 	dec	a
      004528 90 05 C4         [24] 1015 	mov	dptr,#_batch_depth
      00452B F0               [24] 1016 	movx	@dptr,a
      00452C                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00452C 90 05 C4         [24] 1019 	mov	dptr,#_batch_depth
      00452F E0               [24] 1020 	movx	a,@dptr
      004530 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004532 02 43 B6         [24] 1023 	ljmp	_ak820_nvm_flush
      004535                       1024 00105$:
      004535 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      004536                       1036 _load_page:
      004536 E5 82            [12] 1037 	mov	a,dpl
      004538 90 05 E5         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      00453B F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      00453C 30 0A 17         [24] 1041 	jnb	_page_valid,00102$
      00453F 90 05 C3         [24] 1042 	mov	dptr,#_cached_page
      004542 E0               [24] 1043 	movx	a,@dptr
      004543 FF               [12] 1044 	mov	r7,a
      004544 90 05 E5         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      004547 E0               [24] 1046 	movx	a,@dptr
      004548 FE               [12] 1047 	mov	r6,a
      004549 EF               [12] 1048 	mov	a,r7
      00454A B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      00454D A2 0C            [12] 1050 	mov	c,_storage_failed
      00454F B3               [12] 1051 	cpl	c
      004550 92 0E            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004552 12 3A F6         [24] 1053 	lcall	_ak820_outline_0156
      004555 22               [24] 1054 	ret
      004556                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004556 12 43 B6         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004559 30 0C 04         [24] 1059 	jnb	_storage_failed,00119$
      00455C 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00455F 22               [24] 1062 	ret
      004560                       1063 00119$:
      004560 7F 00            [12] 1064 	mov	r7,#0x00
      004562                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004562 EF               [12] 1067 	mov	a,r7
      004563 24 83            [12] 1068 	add	a, #_page_data
      004565 FD               [12] 1069 	mov	r5,a
      004566 E4               [12] 1070 	clr	a
      004567 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      004569 FE               [12] 1072 	mov	r6,a
      00456A 90 05 E5         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00456D E0               [24] 1074 	movx	a,@dptr
      00456E FC               [12] 1075 	mov	r4,a
      00456F FA               [12] 1076 	mov	r2,a
      004570 E4               [12] 1077 	clr	a
      004571 C3               [12] 1078 	clr	c
      004572 CA               [12] 1079 	xch	a,r2
      004573 13               [12] 1080 	rrc	a
      004574 CA               [12] 1081 	xch	a,r2
      004575 13               [12] 1082 	rrc	a
      004576 A2 E0            [12] 1083 	mov	c,acc.0
      004578 CA               [12] 1084 	xch	a,r2
      004579 13               [12] 1085 	rrc	a
      00457A CA               [12] 1086 	xch	a,r2
      00457B 13               [12] 1087 	rrc	a
      00457C CA               [12] 1088 	xch	a,r2
      00457D 24 C7            [12] 1089 	add	a,#0xc7
      00457F FB               [12] 1090 	mov	r3,a
      004580 8F 01            [24] 1091 	mov	ar1,r7
      004582 89 00            [24] 1092 	mov	ar0,r1
      004584 79 00            [12] 1093 	mov	r1,#0x00
      004586 E8               [12] 1094 	mov	a,r0
      004587 2A               [12] 1095 	add	a, r2
      004588 FA               [12] 1096 	mov	r2,a
      004589 E9               [12] 1097 	mov	a,r1
      00458A 3B               [12] 1098 	addc	a, r3
      00458B FB               [12] 1099 	mov	r3,a
      00458C 12 3A EC         [24] 1100 	lcall	_ak820_outline_0143
      00458F 12 3E 7C         [24] 1101 	lcall	_ak820_flash_read
      004592 AB 82            [24] 1102 	mov	r3, dpl
      004594 12 3A E1         [24] 1103 	lcall	_ak820_outline_0135
      004597 EB               [12] 1104 	mov	a,r3
      004598 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004599 0F               [12] 1107 	inc	r7
      00459A BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00459D 90 05 C3         [24] 1110 	mov	dptr,#_cached_page
      0045A0 EC               [12] 1111 	mov	a,r4
      0045A1 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      0045A2 D2 0A            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      0045A4 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      0045A7 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      0045A8                       1129 _read_offset:
      0045A8 12 3A C2         [24] 1130 	lcall	_ak820_outline_0108
      0045AB 90 05 E6         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      0045AE 12 3A C7         [24] 1132 	lcall	_ak820_outline_0109
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      0045B1 90 05 E6         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      0045B4 12 3A 81         [24] 1135 	lcall	_ak820_outline_0052
      0045B7 C3               [12] 1136 	clr	c
      0045B8 94 28            [12] 1137 	subb	a,#0x28
      0045BA 40 04            [24] 1138 	jc	00102$
      0045BC 75 82 00         [24] 1139 	mov	dpl, #0x00
      0045BF 22               [24] 1140 	ret
      0045C0                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0045C0 30 0A 34         [24] 1143 	jnb	_page_valid,00104$
      0045C3 8E 04            [24] 1144 	mov	ar4,r6
      0045C5 EF               [12] 1145 	mov	a,r7
      0045C6 A2 E7            [12] 1146 	mov	c,acc.7
      0045C8 CC               [12] 1147 	xch	a,r4
      0045C9 33               [12] 1148 	rlc	a
      0045CA CC               [12] 1149 	xch	a,r4
      0045CB 33               [12] 1150 	rlc	a
      0045CC A2 E7            [12] 1151 	mov	c,acc.7
      0045CE CC               [12] 1152 	xch	a,r4
      0045CF 33               [12] 1153 	rlc	a
      0045D0 CC               [12] 1154 	xch	a,r4
      0045D1 33               [12] 1155 	rlc	a
      0045D2 CC               [12] 1156 	xch	a,r4
      0045D3 54 03            [12] 1157 	anl	a,#0x03
      0045D5 FD               [12] 1158 	mov	r5,a
      0045D6 90 05 C3         [24] 1159 	mov	dptr,#_cached_page
      0045D9 E0               [24] 1160 	movx	a,@dptr
      0045DA FA               [12] 1161 	mov	r2,a
      0045DB 7B 00            [12] 1162 	mov	r3,#0x00
      0045DD EC               [12] 1163 	mov	a,r4
      0045DE B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0045E1 ED               [12] 1165 	mov	a,r5
      0045E2 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0045E5 74 3F            [12] 1168 	mov	a,#0x3f
      0045E7 5E               [12] 1169 	anl	a,r6
      0045E8 7D 00            [12] 1170 	mov	r5,#0x00
      0045EA 24 83            [12] 1171 	add	a, #_page_data
      0045EC F5 82            [12] 1172 	mov	dpl,a
      0045EE ED               [12] 1173 	mov	a,r5
      0045EF 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0045F1 F5 83            [12] 1175 	mov	dph,a
      0045F3 E0               [24] 1176 	movx	a,@dptr
      0045F4 F5 82            [12] 1177 	mov	dpl,a
      0045F6 22               [24] 1178 	ret
      0045F7                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0045F7 74 C7            [12] 1181 	mov	a,#0xc7
      0045F9 2F               [12] 1182 	add	a, r7
      0045FA FF               [12] 1183 	mov	r7,a
      0045FB 12 3A CC         [24] 1184 	lcall	_ak820_outline_0118
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0045FE 02 3E 7C         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      004601                       1196 _eeprom_read_byte:
      004601 C0 07            [24] 1197 	push	ar7
      004603 C0 06            [24] 1198 	push	ar6
      004605 12 48 A0         [24] 1199 	lcall	_ak820_outline_0037
      004608 90 05 E8         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00460B 12 3A 69         [24] 1201 	lcall	_ak820_outline_0017
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00460E 90 05 E8         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004611 12 3A 34         [24] 1204 	lcall	_ak820_outline_0005
      004614 C0 06            [24] 1205 	push	ar6
      004616 C0 05            [24] 1206 	push	ar5
      004618 C0 04            [24] 1207 	push	ar4
      00461A C0 03            [24] 1208 	push	ar3
      00461C C0 02            [24] 1209 	push	ar2
      00461E C0 01            [24] 1210 	push	ar1
      004620 C0 00            [24] 1211 	push	ar0
      004622 12 45 A8         [24] 1212 	lcall	_read_offset
      004625 AF 82            [24] 1213 	mov	r7, dpl
      004627 D0 00            [24] 1214 	pop	ar0
      004629 D0 01            [24] 1215 	pop	ar1
      00462B D0 02            [24] 1216 	pop	ar2
      00462D D0 03            [24] 1217 	pop	ar3
      00462F D0 04            [24] 1218 	pop	ar4
      004631 D0 05            [24] 1219 	pop	ar5
      004633 D0 06            [24] 1220 	pop	ar6
      004635 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004637 D0 06            [24] 1223 	pop	ar6
      004639 D0 07            [24] 1224 	pop	ar7
      00463B 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      00463C                       1239 _ak820_eeprom_read_block_xdata:
      00463C 12 3A C2         [24] 1240 	lcall	_ak820_outline_0108
      00463F 90 05 F0         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004642 12 3A C7         [24] 1242 	lcall	_ak820_outline_0109
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004645 90 05 EB         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004648 12 3A 81         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00464B 90 05 F0         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00464E 12 3A 98         [24] 1248 	lcall	_ak820_outline_0059
      004651 90 05 F2         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004654 12 3A 9E         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004657 90 05 EE         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00465A 12 3A 98         [24] 1253 	lcall	_ak820_outline_0059
      00465D                       1254 00103$:
      00465D 8C 02            [24] 1255 	mov	ar2,r4
      00465F 8D 03            [24] 1256 	mov	ar3,r5
      004661 1C               [12] 1257 	dec	r4
      004662 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004665 1D               [12] 1259 	dec	r5
      004666                       1260 00130$:
      004666 EA               [12] 1261 	mov	a,r2
      004667 4B               [12] 1262 	orl	a,r3
      004668 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00466A 8E 02            [24] 1265 	mov	ar2,r6
      00466C 8F 03            [24] 1266 	mov	ar3,r7
      00466E 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004670 2B               [12] 1268 	add	a,r3
      004671 50 17            [24] 1269 	jnc	00102$
      004673 90 05 F2         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004676 12 48 D7         [24] 1271 	lcall	_ak820_outline_0104
      004679 12 3A EC         [24] 1272 	lcall	_ak820_outline_0143
      00467C E4               [12] 1273 	clr	a
      00467D F0               [24] 1274 	movx	@dptr,a
      00467E 90 05 F2         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004681 04               [12] 1276 	inc	a
      004682 2A               [12] 1277 	add	a, r2
      004683 F0               [24] 1278 	movx	@dptr,a
      004684 E4               [12] 1279 	clr	a
      004685 3B               [12] 1280 	addc	a, r3
      004686 A3               [24] 1281 	inc	dptr
      004687 F0               [24] 1282 	movx	@dptr,a
      004688 80 D3            [24] 1283 	sjmp	00103$
      00468A                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00468A 90 05 F2         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00468D 12 48 D7         [24] 1287 	lcall	_ak820_outline_0104
      004690 12 3A CC         [24] 1288 	lcall	_ak820_outline_0118
      004693 C0 07            [24] 1289 	push	ar7
      004695 C0 06            [24] 1290 	push	ar6
      004697 C0 05            [24] 1291 	push	ar5
      004699 C0 04            [24] 1292 	push	ar4
      00469B C0 03            [24] 1293 	push	ar3
      00469D C0 02            [24] 1294 	push	ar2
      00469F 12 45 A8         [24] 1295 	lcall	_read_offset
      0046A2 A9 82            [24] 1296 	mov	r1, dpl
      0046A4 D0 02            [24] 1297 	pop	ar2
      0046A6 D0 03            [24] 1298 	pop	ar3
      0046A8 D0 04            [24] 1299 	pop	ar4
      0046AA D0 05            [24] 1300 	pop	ar5
      0046AC D0 06            [24] 1301 	pop	ar6
      0046AE D0 07            [24] 1302 	pop	ar7
      0046B0 12 3A EC         [24] 1303 	lcall	_ak820_outline_0143
      0046B3 E9               [12] 1304 	mov	a,r1
      0046B4 F0               [24] 1305 	movx	@dptr,a
      0046B5 90 05 F2         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0046B8 74 01            [12] 1307 	mov	a,#0x01
      0046BA 2A               [12] 1308 	add	a, r2
      0046BB F0               [24] 1309 	movx	@dptr,a
      0046BC E4               [12] 1310 	clr	a
      0046BD 3B               [12] 1311 	addc	a, r3
      0046BE A3               [24] 1312 	inc	dptr
      0046BF F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0046C0 0E               [12] 1315 	inc	r6
      0046C1 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      0046C4 0F               [12] 1317 	inc	r7
      0046C5 80 96            [24] 1318 	sjmp	00103$
      0046C7                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0046C7 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      0046C8                       1337 _ak820_eeprom_write_block_xdata:
      0046C8 12 3A C2         [24] 1338 	lcall	_ak820_outline_0108
      0046CB 90 05 F9         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0046CE 12 3A C7         [24] 1340 	lcall	_ak820_outline_0109
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0046D1 90 05 F4         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0046D4 12 3A 81         [24] 1343 	lcall	_ak820_outline_0052
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0046D7 90 05 F9         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0046DA 12 3A 98         [24] 1346 	lcall	_ak820_outline_0059
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0046DD 8E 02            [24] 1348 	mov	ar2,r6
      0046DF 8F 03            [24] 1349 	mov	ar3,r7
      0046E1 C3               [12] 1350 	clr	c
      0046E2 E4               [12] 1351 	clr	a
      0046E3 9A               [12] 1352 	subb	a,r2
      0046E4 74 28            [12] 1353 	mov	a,#0x28
      0046E6 9B               [12] 1354 	subb	a,r3
      0046E7 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0046E9 E4               [12] 1357 	clr	a
      0046EA C3               [12] 1358 	clr	c
      0046EB 9E               [12] 1359 	subb	a,r6
      0046EC FA               [12] 1360 	mov	r2,a
      0046ED 74 28            [12] 1361 	mov	a,#0x28
      0046EF 9F               [12] 1362 	subb	a,r7
      0046F0 FB               [12] 1363 	mov	r3,a
      0046F1 90 05 F7         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0046F4 12 3A BC         [24] 1365 	lcall	_ak820_outline_0103
      0046F7 C3               [12] 1366 	clr	c
      0046F8 EA               [12] 1367 	mov	a,r2
      0046F9 98               [12] 1368 	subb	a,r0
      0046FA EB               [12] 1369 	mov	a,r3
      0046FB 99               [12] 1370 	subb	a,r1
      0046FC 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0046FE                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0046FE 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004701 02 41 10         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004704                       1379 00125$:
      004704 90 05 F7         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004707 12 48 D7         [24] 1381 	lcall	_ak820_outline_0104
      00470A                       1382 00108$:
      00470A 8A 00            [24] 1383 	mov	ar0,r2
      00470C 8B 01            [24] 1384 	mov	ar1,r3
      00470E 1A               [12] 1385 	dec	r2
      00470F BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004712 1B               [12] 1387 	dec	r3
      004713                       1388 00159$:
      004713 E8               [12] 1389 	mov	a,r0
      004714 49               [12] 1390 	orl	a,r1
      004715 70 03            [24] 1391 	jnz	00160$
      004717 02 47 A1         [24] 1392 	ljmp	00110$
      00471A                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00471A C0 02            [24] 1395 	push	ar2
      00471C C0 03            [24] 1396 	push	ar3
      00471E 12 48 D1         [24] 1397 	lcall	_ak820_outline_0096
      004721 F9               [12] 1398 	mov	r1,a
      004722 A3               [24] 1399 	inc	dptr
      004723 12 48 FA         [24] 1400 	lcall	_ak820_outline_0149
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004726 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004728 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00472A A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00472C E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00472E A2 E7            [12] 1406 	mov	c,acc.7
      004730 C8               [12] 1407 	xch	a,r0
      004731 33               [12] 1408 	rlc	a
      004732 C8               [12] 1409 	xch	a,r0
      004733 33               [12] 1410 	rlc	a
      004734 A2 E7            [12] 1411 	mov	c,acc.7
      004736 C8               [12] 1412 	xch	a,r0
      004737 33               [12] 1413 	rlc	a
      004738 C8               [12] 1414 	xch	a,r0
      004739 33               [12] 1415 	rlc	a
      00473A C8               [12] 1416 	xch	a,r0
      00473B 54 03            [12] 1417 	anl	a,#0x03
      00473D FB               [12] 1418 	mov	r3,a
      00473E 88 82            [24] 1419 	mov	dpl, r0
      004740 C0 07            [24] 1420 	push	ar7
      004742 C0 06            [24] 1421 	push	ar6
      004744 C0 05            [24] 1422 	push	ar5
      004746 C0 04            [24] 1423 	push	ar4
      004748 C0 03            [24] 1424 	push	ar3
      00474A C0 02            [24] 1425 	push	ar2
      00474C C0 01            [24] 1426 	push	ar1
      00474E 12 45 36         [24] 1427 	lcall	_load_page
      004751 E5 82            [12] 1428 	mov	a, dpl
      004753 D0 01            [24] 1429 	pop	ar1
      004755 D0 02            [24] 1430 	pop	ar2
      004757 D0 03            [24] 1431 	pop	ar3
      004759 D0 04            [24] 1432 	pop	ar4
      00475B D0 05            [24] 1433 	pop	ar5
      00475D D0 06            [24] 1434 	pop	ar6
      00475F D0 07            [24] 1435 	pop	ar7
      004761 D0 03            [24] 1436 	pop	ar3
      004763 D0 02            [24] 1437 	pop	ar2
      004765 70 01            [24] 1438 	jnz	00105$
      004767 22               [24] 1439 	ret
      004768                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004768 C0 06            [24] 1442 	push	ar6
      00476A C0 07            [24] 1443 	push	ar7
      00476C 74 3F            [12] 1444 	mov	a,#0x3f
      00476E 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004770 7F 00            [12] 1446 	mov	r7,#0x00
      004772 24 83            [12] 1447 	add	a, #_page_data
      004774 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004776 EF               [12] 1449 	mov	a,r7
      004777 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      004779 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00477B 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00477E 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004781 E0               [24] 1454 	movx	a,@dptr
      004782 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004785 D0 07            [24] 1456 	pop	ar7
      004787 D0 06            [24] 1457 	pop	ar6
      004789 80 0E            [24] 1458 	sjmp	00107$
      00478B                       1459 00162$:
      00478B D0 07            [24] 1460 	pop	ar7
      00478D D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00478F 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004792 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004795 E9               [12] 1465 	mov	a,r1
      004796 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004797 D2 0B            [12] 1469 	setb	_page_dirty
      004799                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004799 0E               [12] 1472 	inc	r6
      00479A BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00479D 0F               [12] 1474 	inc	r7
      00479E                       1475 00163$:
      00479E 02 47 0A         [24] 1476 	ljmp	00108$
      0047A1                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0047A1 90 05 C4         [24] 1479 	mov	dptr,#_batch_depth
      0047A4 E0               [24] 1480 	movx	a,@dptr
      0047A5 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0047A7 02 43 B6         [24] 1483 	ljmp	_ak820_nvm_flush
      0047AA                       1484 00113$:
      0047AA 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      0047AB                       1503 _ak820_eeprom_update_block_xdata:
      0047AB 12 3A C2         [24] 1504 	lcall	_ak820_outline_0108
      0047AE 90 06 00         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0047B1 12 3A C7         [24] 1506 	lcall	_ak820_outline_0109
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0047B4 90 06 00         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0047B7 12 3A 81         [24] 1509 	lcall	_ak820_outline_0052
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0047BA 90 05 FB         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0047BD E0               [24] 1512 	movx	a,@dptr
      0047BE F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0047C0 A3               [24] 1514 	inc	dptr
      0047C1 E0               [24] 1515 	movx	a,@dptr
      0047C2 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0047C4 A3               [24] 1517 	inc	dptr
      0047C5 E0               [24] 1518 	movx	a,@dptr
      0047C6 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0047C8 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0047CA AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0047CC E4               [12] 1523 	clr	a
      0047CD F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0047CF F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0047D1                       1526 00105$:
      0047D1 90 05 FE         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0047D4 E0               [24] 1528 	movx	a,@dptr
      0047D5 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0047D7 A3               [24] 1530 	inc	dptr
      0047D8 E0               [24] 1531 	movx	a,@dptr
      0047D9 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0047DB C3               [12] 1533 	clr	c
      0047DC E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047DE 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0047E0 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047E2 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0047E4 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0047E6 89 00            [24] 1540 	mov	ar0,r1
      0047E8 8A 05            [24] 1541 	mov	ar5,r2
      0047EA E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047EC 28               [12] 1543 	add	a, r0
      0047ED F8               [12] 1544 	mov	r0,a
      0047EE E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047F0 3D               [12] 1546 	addc	a, r5
      0047F1 FD               [12] 1547 	mov	r5,a
      0047F2 88 82            [24] 1548 	mov	dpl, r0
      0047F4 8D 83            [24] 1549 	mov	dph, r5
      0047F6 C0 07            [24] 1550 	push	ar7
      0047F8 C0 06            [24] 1551 	push	ar6
      0047FA C0 02            [24] 1552 	push	ar2
      0047FC C0 01            [24] 1553 	push	ar1
      0047FE 12 45 A8         [24] 1554 	lcall	_read_offset
      004801 AD 82            [24] 1555 	mov	r5, dpl
      004803 D0 01            [24] 1556 	pop	ar1
      004805 D0 02            [24] 1557 	pop	ar2
      004807 D0 06            [24] 1558 	pop	ar6
      004809 D0 07            [24] 1559 	pop	ar7
      00480B E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00480D 2E               [12] 1561 	add	a, r6
      00480E F5 82            [12] 1562 	mov	dpl,a
      004810 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004812 3F               [12] 1564 	addc	a, r7
      004813 F5 83            [12] 1565 	mov	dph,a
      004815 E0               [24] 1566 	movx	a,@dptr
      004816 FC               [12] 1567 	mov	r4,a
      004817 ED               [12] 1568 	mov	a,r5
      004818 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      00481B 80 27            [24] 1570 	sjmp	00106$
      00481D                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00481D 90 06 00         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004820 E0               [24] 1574 	movx	a,@dptr
      004821 F8               [12] 1575 	mov	r0,a
      004822 A3               [24] 1576 	inc	dptr
      004823 E0               [24] 1577 	movx	a,@dptr
      004824 FD               [12] 1578 	mov	r5,a
      004825 90 05 F4         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004828 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00482A F0               [24] 1581 	movx	@dptr,a
      00482B E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00482D A3               [24] 1583 	inc	dptr
      00482E F0               [24] 1584 	movx	@dptr,a
      00482F E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004831 A3               [24] 1586 	inc	dptr
      004832 F0               [24] 1587 	movx	@dptr,a
      004833 90 05 F7         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004836 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004838 F0               [24] 1590 	movx	@dptr,a
      004839 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00483B A3               [24] 1592 	inc	dptr
      00483C F0               [24] 1593 	movx	@dptr,a
      00483D 88 82            [24] 1594 	mov	dpl, r0
      00483F 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004841 02 46 C8         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004844                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004844 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004846 E4               [12] 1601 	clr	a
      004847 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00484A 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00484C 80 83            [24] 1604 	sjmp	00105$
      00484E                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00484E 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      00484F                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00484F 12 43 B6         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004852 7F 00            [12] 1622 	mov	r7,#0x00
      004854                       1623 00111$:
      004854 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      004857 22               [24] 1625 	ret
      004858                       1626 00165$:
      004858 20 0C 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00485B 8F 82            [24] 1629 	mov	dpl, r7
      00485D C0 07            [24] 1630 	push	ar7
      00485F 12 45 36         [24] 1631 	lcall	_load_page
      004862 E5 82            [12] 1632 	mov	a, dpl
      004864 D0 07            [24] 1633 	pop	ar7
      004866 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004868 22               [24] 1636 	ret
      004869                       1637 00126$:
      004869 7E 00            [12] 1638 	mov	r6,#0x00
      00486B                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00486B EE               [12] 1641 	mov	a,r6
      00486C 24 83            [12] 1642 	add	a, #_page_data
      00486E FC               [12] 1643 	mov	r4,a
      00486F E4               [12] 1644 	clr	a
      004870 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004872 FD               [12] 1646 	mov	r5,a
      004873 12 48 D1         [24] 1647 	lcall	_ak820_outline_0096
      004876 60 07            [24] 1648 	jz	00108$
      004878 12 3A D7         [24] 1649 	lcall	_ak820_outline_0124
      00487B E4               [12] 1650 	clr	a
      00487C F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      00487D D2 0B            [12] 1653 	setb	_page_dirty
      00487F                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00487F 0E               [12] 1656 	inc	r6
      004880 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004883 C0 07            [24] 1659 	push	ar7
      004885 12 43 B6         [24] 1660 	lcall	_ak820_nvm_flush
      004888 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00488A 0F               [12] 1663 	inc	r7
      00488B 80 C7            [24] 1664 	sjmp	00111$
      00488D                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00488D 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0012
                                   1676 	.globl _ak820_outline_0017
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0032
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0053
                                   1683 	.globl _ak820_outline_0059
                                   1684 	.globl _ak820_outline_0063
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0072
                                   1687 	.globl _ak820_outline_0079
                                   1688 	.globl _ak820_outline_0086
                                   1689 	.globl _ak820_outline_0096
                                   1690 	.globl _ak820_outline_0103
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0106
                                   1693 	.globl _ak820_outline_0108
                                   1694 	.globl _ak820_outline_0109
                                   1695 	.globl _ak820_outline_0118
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0123
                                   1698 	.globl _ak820_outline_0124
                                   1699 	.globl _ak820_outline_0125
                                   1700 	.globl _ak820_outline_0135
                                   1701 	.globl _ak820_outline_0137
                                   1702 	.globl _ak820_outline_0142
                                   1703 	.globl _ak820_outline_0143
                                   1704 	.globl _ak820_outline_0149
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0160
                                   1708 	.globl _ak820_outline_0161
                                   1709 	.globl _ak820_outline_0182
                                   1710 	.globl _ak820_outline_0183
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0012
      00488E                       1714 _ak820_outline_0012:
      00488E 8E 82            [24] 1715 	mov	dpl,r6
      004890 8F 83            [24] 1716 	mov	dph,r7
      004892 A3               [24] 1717 	inc	dptr
      004893 A3               [24] 1718 	inc	dptr
      004894 A3               [24] 1719 	inc	dptr
      004895 A3               [24] 1720 	inc	dptr
      004896 A3               [24] 1721 	inc	dptr
      004897 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0032
      004898                       1726 _ak820_outline_0032:
      004898 F0               [24] 1727 	movx	@dptr,a
      004899 8E 82            [24] 1728 	mov	dpl,r6
      00489B 8F 83            [24] 1729 	mov	dph,r7
      00489D A3               [24] 1730 	inc	dptr
      00489E A3               [24] 1731 	inc	dptr
      00489F 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0037
      0048A0                       1736 _ak820_outline_0037:
      0048A0 AF F0            [24] 1737 	mov	r7,b
      0048A2 AE 83            [24] 1738 	mov	r6,dph
      0048A4 E5 82            [12] 1739 	mov	a,dpl
      0048A6 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      0048A7                       1744 _ak820_outline_0043:
      0048A7 EF               [12] 1745 	mov	a,r7
      0048A8 24 DB            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      0048AA F5 82            [12] 1747 	mov	dpl,a
      0048AC E4               [12] 1748 	clr	a
      0048AD 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0048AF F5 83            [12] 1750 	mov	dph,a
      0048B1 E0               [24] 1751 	movx	a,@dptr
      0048B2 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      0048B3                       1756 _ak820_outline_0053:
      0048B3 8F 06            [24] 1757 	mov	ar6,r7
      0048B5 7D 00            [12] 1758 	mov	r5,#0x00
      0048B7 74 40            [12] 1759 	mov	a,#0x40
      0048B9 2E               [12] 1760 	add	a,r6
      0048BA FE               [12] 1761 	mov	r6,a
      0048BB 74 EF            [12] 1762 	mov	a,#0xef
      0048BD 3D               [12] 1763 	addc	a,r5
      0048BE FD               [12] 1764 	mov	r5,a
      0048BF 8E 82            [24] 1765 	mov	dpl,r6
      0048C1 8D 83            [24] 1766 	mov	dph,r5
      0048C3 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0063
      0048C4                       1771 _ak820_outline_0063:
      0048C4 8D 82            [24] 1772 	mov	dpl,r5
      0048C6 8E 83            [24] 1773 	mov	dph,r6
      0048C8 EC               [12] 1774 	mov	a,r4
      0048C9 F0               [24] 1775 	movx	@dptr,a
      0048CA 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0071
      0048CB                       1780 _ak820_outline_0071:
      0048CB F0               [24] 1781 	movx	@dptr,a
      0048CC 8E 82            [24] 1782 	mov	dpl,r6
      0048CE 8F 83            [24] 1783 	mov	dph,r7
      0048D0 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0096
      0048D1                       1788 _ak820_outline_0096:
      0048D1 8C 82            [24] 1789 	mov	dpl,r4
      0048D3 8D 83            [24] 1790 	mov	dph,r5
      0048D5 E0               [24] 1791 	movx	a,@dptr
      0048D6 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0104
      0048D7                       1796 _ak820_outline_0104:
      0048D7 E0               [24] 1797 	movx	a,@dptr
      0048D8 FA               [12] 1798 	mov	r2,a
      0048D9 A3               [24] 1799 	inc	dptr
      0048DA E0               [24] 1800 	movx	a,@dptr
      0048DB FB               [12] 1801 	mov	r3,a
      0048DC 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0106
      0048DD                       1806 _ak820_outline_0106:
      0048DD EF               [12] 1807 	mov	a,r7
      0048DE 24 83            [12] 1808 	add	a,#_page_data
      0048E0 F5 82            [12] 1809 	mov	dpl,a
      0048E2 E4               [12] 1810 	clr	a
      0048E3 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0048E5 F5 83            [12] 1812 	mov	dph,a
      0048E7 E0               [24] 1813 	movx	a,@dptr
      0048E8 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0125
      0048E9                       1818 _ak820_outline_0125:
      0048E9 AE 82            [24] 1819 	mov	r6,dpl
      0048EB AF 83            [24] 1820 	mov	r7,dph
      0048ED 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0137
      0048EE                       1825 _ak820_outline_0137:
      0048EE 2E               [12] 1826 	add	a,r6
      0048EF FE               [12] 1827 	mov	r6,a
      0048F0 E4               [12] 1828 	clr	a
      0048F1 3F               [12] 1829 	addc	a,r7
      0048F2 FF               [12] 1830 	mov	r7,a
      0048F3 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0142
      0048F4                       1835 _ak820_outline_0142:
      0048F4 42 05            [12] 1836 	orl	ar5,a
      0048F6 EA               [12] 1837 	mov	a,r2
      0048F7 42 04            [12] 1838 	orl	ar4,a
      0048F9 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0149
      0048FA                       1843 _ak820_outline_0149:
      0048FA AC 82            [24] 1844 	mov	r4,dpl
      0048FC AD 83            [24] 1845 	mov	r5,dph
      0048FE 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0157
      0048FF                       1850 _ak820_outline_0157:
      0048FF 8F 82            [24] 1851 	mov	dpl,r7
      004901 8E 83            [24] 1852 	mov	dph,r6
      004903 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0160
      004904                       1857 _ak820_outline_0160:
      004904 2E               [12] 1858 	add	a,r6
      004905 FC               [12] 1859 	mov	r4,a
      004906 E4               [12] 1860 	clr	a
      004907 3F               [12] 1861 	addc	a,r7
      004908 FD               [12] 1862 	mov	r5,a
      004909 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0161
      00490A                       1867 _ak820_outline_0161:
      00490A ED               [12] 1868 	mov	a,r5
      00490B F0               [24] 1869 	movx	@dptr,a
      00490C EE               [12] 1870 	mov	a,r6
      00490D A3               [24] 1871 	inc	dptr
      00490E F0               [24] 1872 	movx	@dptr,a
      00490F 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0182
      004910                       1877 _ak820_outline_0182:
      004910 89 82            [24] 1878 	mov	dpl,r1
      004912 8A 83            [24] 1879 	mov	dph,r2
      004914 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0183
      004915                       1884 _ak820_outline_0183:
      004915 8C 82            [24] 1885 	mov	dpl,r4
      004917 8B 83            [24] 1886 	mov	dph,r3
      004919 22               [24] 1887 	ret
