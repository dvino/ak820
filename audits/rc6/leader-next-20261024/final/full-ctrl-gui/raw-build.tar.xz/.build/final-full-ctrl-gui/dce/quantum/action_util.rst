                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000020                        568 _gui_disabled:
      000020                        569 	.ds 1
      000021                        570 _ctrl_gui_swapped:
      000021                        571 	.ds 1
      000022                        572 _ak820_gui_process_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _ak820_macro_change_sloc0_1_0:
      000023                        575 	.ds 1
      000024                        576 _change_owned_sloc0_1_0:
      000024                        577 	.ds 1
      000025                        578 _owned_usage_key_sloc0_1_0:
      000025                        579 	.ds 1
                                    580 ;--------------------------------------------------------
                                    581 ; paged external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area PSEG    (PAG,XDATA)
                                    584 ;--------------------------------------------------------
                                    585 ; uninitialized external ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area XSEG    (XDATA)
      00096F                        588 _ak820_gui_process_PARM_2:
      00096F                        589 	.ds 1
      000970                        590 _ak820_gui_process_code_10000_294:
      000970                        591 	.ds 2
      000972                        592 _owned_mod_refs:
      000972                        593 	.ds 8
      00097A                        594 _owned_weak_refs:
      00097A                        595 	.ds 8
      000982                        596 _owned_mods:
      000982                        597 	.ds 1
      000983                        598 _owned_weak_mods:
      000983                        599 	.ds 1
      000984                        600 _macro_mods:
      000984                        601 	.ds 2
      000986                        602 _ak820_macro_primitive::
      000986                        603 	.ds 1
      000987                        604 _ak820_macro_cancelled::
      000987                        605 	.ds 1
      000988                        606 _ak820_macro_change_PARM_2:
      000988                        607 	.ds 1
      000989                        608 _ak820_macro_change_PARM_3:
      000989                        609 	.ds 1
      00098A                        610 _ak820_macro_change_bits_10000_303:
      00098A                        611 	.ds 2
      00098C                        612 _change_owned_PARM_2:
      00098C                        613 	.ds 1
      00098D                        614 _change_owned_mods_10000_308:
      00098D                        615 	.ds 1
      00098E                        616 _change_owned_result_10001_312:
      00098E                        617 	.ds 1
      00098F                        618 _change_owned_bit_20001_313:
      00098F                        619 	.ds 1
      000990                        620 _add_owned_mods_mods_10000_321:
      000990                        621 	.ds 1
      000991                        622 _del_owned_mods_mods_10000_323:
      000991                        623 	.ds 1
      000992                        624 _add_owned_weak_mods_mods_10000_325:
      000992                        625 	.ds 1
      000993                        626 _del_owned_weak_mods_mods_10000_327:
      000993                        627 	.ds 1
      000994                        628 _key_refs:
      000994                        629 	.ds 165
      000A39                        630 _distinct_keys:
      000A39                        631 	.ds 1
      000A3A                        632 _macro_keys:
      000A3A                        633 	.ds 21
      000A4F                        634 _add_owned_key_code_10000_336:
      000A4F                        635 	.ds 1
      000A50                        636 _del_owned_key_code_10000_351:
      000A50                        637 	.ds 1
      000A51                        638 _usage_refs:
      000A51                        639 	.ds 30
      000A6F                        640 _usage_order:
      000A6F                        641 	.ds 30
      000A8D                        642 _usage_lengths:
      000A8D                        643 	.ds 2
      000A8F                        644 _macro_usages:
      000A8F                        645 	.ds 4
      000A93                        646 _owned_usage_key_PARM_2:
      000A93                        647 	.ds 1
      000A94                        648 _owned_usage_key_code_10000_378:
      000A94                        649 	.ds 1
      000A95                        650 _owned_usage_key___200000085_20000_379:
      000A95                        651 	.ds 2
      000A97                        652 _owned_usage_key_which_10000_379:
      000A97                        653 	.ds 1
      000A98                        654 _owned_usage_key_count_10000_379:
      000A98                        655 	.ds 1
      000A99                        656 _owned_usage_key_pos_30001_386:
      000A99                        657 	.ds 1
      000A9A                        658 _owned_usage_key_key_40000_391:
      000A9A                        659 	.ds 1
      000A9B                        660 _send_keyboard_report_last_report_10001_401:
      000A9B                        661 	.ds 32
      000ABB                        662 _send_keyboard_report_changed_10001_401:
      000ABB                        663 	.ds 1
      000ABC                        664 _add_weak_mods_mods_10000_419:
      000ABC                        665 	.ds 1
      000ABD                        666 _del_weak_mods_mods_10000_421:
      000ABD                        667 	.ds 1
                                    668 ;--------------------------------------------------------
                                    669 ; absolute external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XABS    (ABS,XDATA)
                                    672 ;--------------------------------------------------------
                                    673 ; initialized external ram data
                                    674 ;--------------------------------------------------------
                                    675 	.area XISEG   (XDATA)
      000DC3                        676 _real_mods:
      000DC3                        677 	.ds 1
      000DC4                        678 _weak_mods:
      000DC4                        679 	.ds 1
      000DC5                        680 _actual_keyboard_report::
      000DC5                        681 	.ds 32
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function ak820_gui_process
                                    724 ;	-----------------------------------------
      007B63                        725 _ak820_gui_process:
      007B63 12 38 88         [24]  726 	lcall	_ak820_outline_0108
      007B66 90 09 70         [24]  727 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B69 12 38 8D         [24]  728 	lcall	_ak820_outline_0109
                                    729 ;	quantum/action_util.c:51: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) {
      007B6C 90 09 70         [24]  730 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B6F 12 38 41         [24]  731 	lcall	_ak820_outline_0051
      007B72 E4               [12]  732 	clr	a
      007B73 BE 1B 04         [24]  733 	cjne	r6,#0x1b,00167$
      007B76 BF 70 01         [24]  734 	cjne	r7,#0x70,00167$
      007B79 04               [12]  735 	inc	a
      007B7A                        736 00167$:
      007B7A FD               [12]  737 	mov	r5,a
      007B7B 70 0E            [24]  738 	jnz	00103$
      007B7D BE 1C 05         [24]  739 	cjne	r6,#0x1c,00170$
      007B80 BF 70 02         [24]  740 	cjne	r7,#0x70,00170$
      007B83 80 06            [24]  741 	sjmp	00103$
      007B85                        742 00170$:
      007B85 BE 1D 27         [24]  743 	cjne	r6,#0x1d,00104$
      007B88 BF 70 24         [24]  744 	cjne	r7,#0x70,00104$
      007B8B                        745 00103$:
                                    746 ;	quantum/action_util.c:52: if (pressed) {
      007B8B 90 09 6F         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007B8E E0               [24]  748 	movx	a,@dptr
      007B8F 60 1A            [24]  749 	jz	00102$
                                    750 ;	quantum/action_util.c:53: ctrl_gui_swapped = code == QK_MAGIC_TOGGLE_CTL_GUI ? !ctrl_gui_swapped : code == QK_MAGIC_SWAP_CTL_GUI;
      007B91 BE 1D 0D         [24]  751 	cjne	r6,#0x1d,00114$
      007B94 BF 70 0A         [24]  752 	cjne	r7,#0x70,00114$
      007B97 A2 21            [12]  753 	mov	c,_ctrl_gui_swapped
      007B99 B3               [12]  754 	cpl	c
      007B9A 92 22            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007B9C E4               [12]  756 	clr	a
      007B9D 33               [12]  757 	rlc	a
      007B9E FC               [12]  758 	mov	r4,a
      007B9F 80 02            [24]  759 	sjmp	00115$
      007BA1                        760 00114$:
      007BA1 8D 04            [24]  761 	mov	ar4,r5
      007BA3                        762 00115$:
                                    763 ;	assignBit
      007BA3 EC               [12]  764 	mov	a,r4
      007BA4 24 FF            [12]  765 	add	a,#0xff
      007BA6 92 21            [24]  766 	mov	_ctrl_gui_swapped,c
                                    767 ;	quantum/action_util.c:54: send_keyboard_report();
      007BA8 12 80 67         [24]  768 	lcall	_send_keyboard_report
      007BAB                        769 00102$:
                                    770 ;	quantum/action_util.c:56: return false;
      007BAB 75 82 00         [24]  771 	mov	dpl, #0x00
      007BAE 22               [24]  772 	ret
      007BAF                        773 00104$:
                                    774 ;	quantum/action_util.c:60: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007BAF C3               [12]  775 	clr	c
      007BB0 EE               [12]  776 	mov	a,r6
      007BB1 94 09            [12]  777 	subb	a,#0x09
      007BB3 EF               [12]  778 	mov	a,r7
      007BB4 94 70            [12]  779 	subb	a,#0x70
      007BB6 40 08            [24]  780 	jc	00107$
      007BB8 74 0B            [12]  781 	mov	a,#0x0b
      007BBA 9E               [12]  782 	subb	a,r6
      007BBB 74 70            [12]  783 	mov	a,#0x70
      007BBD 9F               [12]  784 	subb	a,r7
      007BBE 50 04            [24]  785 	jnc	00108$
                                    786 ;	free result
      007BC0                        787 00107$:
      007BC0 75 82 01         [24]  788 	mov	dpl, #0x01
      007BC3 22               [24]  789 	ret
      007BC4                        790 00108$:
                                    791 ;	quantum/action_util.c:61: if (pressed) {
      007BC4 90 09 6F         [24]  792 	mov	dptr,#_ak820_gui_process_PARM_2
      007BC7 E0               [24]  793 	movx	a,@dptr
      007BC8 60 21            [24]  794 	jz	00111$
                                    795 ;	quantum/action_util.c:62: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007BCA BE 0B 0D         [24]  796 	cjne	r6,#0x0b,00116$
      007BCD BF 70 0A         [24]  797 	cjne	r7,#0x70,00116$
      007BD0 A2 20            [12]  798 	mov	c,_gui_disabled
      007BD2 B3               [12]  799 	cpl	c
      007BD3 92 22            [24]  800 	mov  _ak820_gui_process_sloc0_1_0,c
      007BD5 E4               [12]  801 	clr	a
      007BD6 33               [12]  802 	rlc	a
      007BD7 FD               [12]  803 	mov	r5,a
      007BD8 80 09            [24]  804 	sjmp	00117$
      007BDA                        805 00116$:
      007BDA E4               [12]  806 	clr	a
      007BDB BE 0A 04         [24]  807 	cjne	r6,#0x0a,00181$
      007BDE BF 70 01         [24]  808 	cjne	r7,#0x70,00181$
      007BE1 04               [12]  809 	inc	a
      007BE2                        810 00181$:
      007BE2 FD               [12]  811 	mov	r5,a
      007BE3                        812 00117$:
                                    813 ;	assignBit
      007BE3 ED               [12]  814 	mov	a,r5
      007BE4 24 FF            [12]  815 	add	a,#0xff
      007BE6 92 20            [24]  816 	mov	_gui_disabled,c
                                    817 ;	quantum/action_util.c:63: send_keyboard_report();
      007BE8 12 80 67         [24]  818 	lcall	_send_keyboard_report
      007BEB                        819 00111$:
                                    820 ;	quantum/action_util.c:65: return false;
      007BEB 75 82 00         [24]  821 	mov	dpl, #0x00
                                    822 ;	quantum/action_util.c:69: }
      007BEE 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_macro_change'
                                    826 ;------------------------------------------------------------
                                    827 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    828 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    829 ;bits          Allocated with name '_ak820_macro_change_bits_10000_303'
                                    830 ;mask          Allocated with name '_ak820_macro_change_mask_10001_306'
                                    831 ;------------------------------------------------------------
                                    832 ;	quantum/action_util.c:78: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    833 ;	-----------------------------------------
                                    834 ;	 function ak820_macro_change
                                    835 ;	-----------------------------------------
      007BEF                        836 _ak820_macro_change:
      007BEF 12 38 88         [24]  837 	lcall	_ak820_outline_0108
      007BF2 90 09 8A         [24]  838 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007BF5 12 38 8D         [24]  839 	lcall	_ak820_outline_0109
                                    840 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      007BF8 90 09 86         [24]  841 	mov	dptr,#_ak820_macro_primitive
      007BFB E0               [24]  842 	movx	a,@dptr
      007BFC 70 04            [24]  843 	jnz	00102$
      007BFE 75 82 01         [24]  844 	mov	dpl, #0x01
      007C01 22               [24]  845 	ret
      007C02                        846 00102$:
                                    847 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007C02 90 09 88         [24]  848 	mov	dptr,#_ak820_macro_change_PARM_2
      007C05 E0               [24]  849 	movx	a,@dptr
      007C06 FF               [12]  850 	mov	r7,a
      007C07 74 07            [12]  851 	mov	a,#0x07
      007C09 5F               [12]  852 	anl	a,r7
      007C0A 12 76 F5         [24]  853 	lcall	_ak820_outline_0061
      007C0D 80 02            [24]  854 	sjmp	00123$
      007C0F                        855 00122$:
      007C0F 25 E0            [12]  856 	add	a,acc
      007C11                        857 00123$:
      007C11 D5 F0 FB         [24]  858 	djnz	b,00122$
      007C14 FE               [12]  859 	mov	r6,a
                                    860 ;	quantum/action_util.c:81: bits += index >> 3;
      007C15 EF               [12]  861 	mov	a,r7
      007C16 12 57 54         [24]  862 	lcall	_ak820_outline_0171
      007C19 FF               [12]  863 	mov	r7,a
      007C1A 90 09 8A         [24]  864 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C1D 12 38 58         [24]  865 	lcall	_ak820_outline_0059
      007C20 90 09 8A         [24]  866 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C23 EF               [12]  867 	mov	a,r7
      007C24 2C               [12]  868 	add	a, r4
      007C25 F0               [24]  869 	movx	@dptr,a
      007C26 E4               [12]  870 	clr	a
      007C27 3D               [12]  871 	addc	a, r5
      007C28 A3               [24]  872 	inc	dptr
      007C29 F0               [24]  873 	movx	@dptr,a
                                    874 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      007C2A 90 09 8A         [24]  875 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C2D E0               [24]  876 	movx	a,@dptr
      007C2E FD               [12]  877 	mov	r5,a
      007C2F A3               [24]  878 	inc	dptr
      007C30 E0               [24]  879 	movx	a,@dptr
      007C31 FF               [12]  880 	mov	r7,a
      007C32 12 81 B4         [24]  881 	lcall	_ak820_outline_0190
      007C35 E0               [24]  882 	movx	a,@dptr
      007C36 FC               [12]  883 	mov	r4,a
      007C37 EE               [12]  884 	mov	a,r6
      007C38 5C               [12]  885 	anl	a,r4
      007C39 B4 01 00         [24]  886 	cjne	a,#0x01,00124$
      007C3C                        887 00124$:
      007C3C B3               [12]  888 	cpl	c
      007C3D 92 23            [24]  889 	mov	_ak820_macro_change_sloc0_1_0,c
      007C3F 90 09 89         [24]  890 	mov	dptr,#_ak820_macro_change_PARM_3
      007C42 E0               [24]  891 	movx	a,@dptr
      007C43 FB               [12]  892 	mov	r3,a
      007C44 A2 23            [12]  893 	mov	c,_ak820_macro_change_sloc0_1_0
      007C46 E4               [12]  894 	clr	a
      007C47 33               [12]  895 	rlc	a
      007C48 B5 03 04         [24]  896 	cjne	a,ar3,00104$
      007C4B 75 82 00         [24]  897 	mov	dpl, #0x00
      007C4E 22               [24]  898 	ret
      007C4F                        899 00104$:
                                    900 ;	quantum/action_util.c:83: *bits ^= mask;
      007C4F EC               [12]  901 	mov	a,r4
      007C50 62 06            [12]  902 	xrl	ar6,a
      007C52 12 81 B4         [24]  903 	lcall	_ak820_outline_0190
      007C55 EE               [12]  904 	mov	a,r6
      007C56 F0               [24]  905 	movx	@dptr,a
                                    906 ;	quantum/action_util.c:84: return true;
      007C57 75 82 01         [24]  907 	mov	dpl, #0x01
                                    908 ;	quantum/action_util.c:85: }
      007C5A 22               [24]  909 	ret
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'change_owned'
                                    912 ;------------------------------------------------------------
                                    913 ;mode          Allocated with name '_change_owned_PARM_2'
                                    914 ;mods          Allocated with name '_change_owned_mods_10000_308'
                                    915 ;kind          Allocated with name '_change_owned_kind_10000_309'
                                    916 ;pressed       Allocated with name '_change_owned_pressed_10000_309'
                                    917 ;refs          Allocated with name '_change_owned_refs_10000_309'
                                    918 ;old           Allocated with name '_change_owned_old_30000_311'
                                    919 ;result        Allocated with name '_change_owned_result_10001_312'
                                    920 ;i             Allocated with name '_change_owned_i_20001_313'
                                    921 ;bit           Allocated with name '_change_owned_bit_20001_313'
                                    922 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    923 ;------------------------------------------------------------
                                    924 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function change_owned
                                    927 ;	-----------------------------------------
      007C5B                        928 _change_owned:
      007C5B E5 82            [12]  929 	mov	a,dpl
      007C5D 90 09 8D         [24]  930 	mov	dptr,#_change_owned_mods_10000_308
      007C60 F0               [24]  931 	movx	@dptr,a
                                    932 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007C61 90 09 8C         [24]  933 	mov	dptr,#_change_owned_PARM_2
      007C64 E0               [24]  934 	movx	a,@dptr
      007C65 FF               [12]  935 	mov	r7,a
      007C66 C3               [12]  936 	clr	c
      007C67 13               [12]  937 	rrc	a
      007C68 FE               [12]  938 	mov	r6,a
                                    939 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      007C69 53 07 01         [24]  940 	anl	ar7,#0x01
      007C6C EF               [12]  941 	mov	a,r7
      007C6D B4 01 00         [24]  942 	cjne	a,#0x01,00205$
      007C70                        943 00205$:
      007C70 92 24            [24]  944 	mov  _change_owned_sloc0_1_0,c
      007C72 B3               [12]  945 	cpl	c
      007C73 E4               [12]  946 	clr	a
      007C74 33               [12]  947 	rlc	a
      007C75 F5 54            [12]  948 	mov	_change_owned_sloc1_1_0,a
                                    949 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007C77 EE               [12]  950 	mov	a,r6
      007C78 60 06            [24]  951 	jz	00121$
      007C7A 7D 7A            [12]  952 	mov	r5,#_owned_weak_refs
      007C7C 7F 09            [12]  953 	mov	r7,#(_owned_weak_refs >> 8)
      007C7E 80 04            [24]  954 	sjmp	00122$
      007C80                        955 00121$:
      007C80 7D 72            [12]  956 	mov	r5,#_owned_mod_refs
      007C82 7F 09            [12]  957 	mov	r7,#(_owned_mod_refs >> 8)
      007C84                        958 00122$:
                                    959 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007C84 90 09 86         [24]  960 	mov	dptr,#_ak820_macro_primitive
      007C87 E0               [24]  961 	movx	a,@dptr
      007C88 60 37            [24]  962 	jz	00102$
                                    963 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      007C8A EE               [12]  964 	mov	a,r6
      007C8B 24 84            [12]  965 	add	a, #_macro_mods
      007C8D FB               [12]  966 	mov	r3,a
      007C8E E4               [12]  967 	clr	a
      007C8F 34 09            [12]  968 	addc	a, #(_macro_mods >> 8)
      007C91 FC               [12]  969 	mov	r4,a
      007C92 12 48 B7         [24]  970 	lcall	_ak820_outline_0063
                                    971 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007C95 E5 54            [12]  972 	mov	a,_change_owned_sloc1_1_0
      007C97 60 0A            [24]  973 	jz	00123$
      007C99 90 09 8D         [24]  974 	mov	dptr,#_change_owned_mods_10000_308
      007C9C E0               [24]  975 	movx	a,@dptr
      007C9D F9               [12]  976 	mov	r1,a
      007C9E EA               [12]  977 	mov	a,r2
      007C9F 42 01            [12]  978 	orl	ar1,a
      007CA1 80 07            [24]  979 	sjmp	00124$
      007CA3                        980 00123$:
      007CA3 90 09 8D         [24]  981 	mov	dptr,#_change_owned_mods_10000_308
      007CA6 E0               [24]  982 	movx	a,@dptr
      007CA7 F4               [12]  983 	cpl	a
      007CA8 5A               [12]  984 	anl	a,r2
      007CA9 F9               [12]  985 	mov	r1,a
      007CAA                        986 00124$:
      007CAA 12 33 FC         [24]  987 	lcall	_ak820_outline_0123
      007CAD E9               [12]  988 	mov	a,r1
      007CAE F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007CAF E5 54            [12]  991 	mov	a,_change_owned_sloc1_1_0
      007CB1 60 06            [24]  992 	jz	00125$
      007CB3 74 FF            [12]  993 	mov	a,#0xff
      007CB5 6A               [12]  994 	xrl	a,r2
      007CB6 FC               [12]  995 	mov	r4,a
      007CB7 80 02            [24]  996 	sjmp	00126$
      007CB9                        997 00125$:
      007CB9 8A 04            [24]  998 	mov	ar4,r2
      007CBB                        999 00126$:
      007CBB 90 09 8D         [24] 1000 	mov	dptr,#_change_owned_mods_10000_308
      007CBE E0               [24] 1001 	movx	a,@dptr
      007CBF 5C               [12] 1002 	anl	a,r4
      007CC0 F0               [24] 1003 	movx	@dptr,a
      007CC1                       1004 00102$:
                                   1005 ;	quantum/action_util.c:95: uint8_t result = 0;
      007CC1 90 09 8E         [24] 1006 	mov	dptr,#_change_owned_result_10001_312
      007CC4 E4               [12] 1007 	clr	a
      007CC5 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CC6 90 09 8F         [24] 1010 	mov	dptr,#_change_owned_bit_20001_313
      007CC9 04               [12] 1011 	inc	a
      007CCA F0               [24] 1012 	movx	@dptr,a
      007CCB 90 09 8D         [24] 1013 	mov	dptr,#_change_owned_mods_10000_308
      007CCE E0               [24] 1014 	movx	a,@dptr
      007CCF FC               [12] 1015 	mov	r4,a
      007CD0 7B 00            [12] 1016 	mov	r3,#0x00
      007CD2                       1017 00117$:
      007CD2 BB 08 00         [24] 1018 	cjne	r3,#0x08,00210$
      007CD5                       1019 00210$:
      007CD5 50 3F            [24] 1020 	jnc	00112$
                                   1021 ;	quantum/action_util.c:97: if (mods & bit) {
      007CD7 90 09 8F         [24] 1022 	mov	dptr,#_change_owned_bit_20001_313
      007CDA E0               [24] 1023 	movx	a,@dptr
      007CDB 5C               [12] 1024 	anl	a,r4
      007CDC 60 1C            [24] 1025 	jz	00109$
                                   1026 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007CDE E5 54            [12] 1027 	mov	a,_change_owned_sloc1_1_0
      007CE0 60 0C            [24] 1028 	jz	00106$
      007CE2 EB               [12] 1029 	mov	a,r3
      007CE3 2D               [12] 1030 	add	a, r5
      007CE4 12 38 1F         [24] 1031 	lcall	_ak820_outline_0016
      007CE7 F8               [12] 1032 	mov	r0,a
      007CE8 08               [12] 1033 	inc	r0
      007CE9 12 81 68         [24] 1034 	lcall	_ak820_outline_0062
      007CEC 80 0C            [24] 1035 	sjmp	00109$
      007CEE                       1036 00106$:
                                   1037 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007CEE EB               [12] 1038 	mov	a,r3
      007CEF 2D               [12] 1039 	add	a, r5
      007CF0 12 38 1F         [24] 1040 	lcall	_ak820_outline_0016
      007CF3 F8               [12] 1041 	mov	r0,a
      007CF4 60 04            [24] 1042 	jz	00109$
      007CF6 18               [12] 1043 	dec	r0
      007CF7 12 81 68         [24] 1044 	lcall	_ak820_outline_0062
      007CFA                       1045 00109$:
                                   1046 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      007CFA EB               [12] 1047 	mov	a,r3
      007CFB 2D               [12] 1048 	add	a, r5
      007CFC 12 38 1F         [24] 1049 	lcall	_ak820_outline_0016
      007CFF 60 0B            [24] 1050 	jz	00118$
      007D01 90 09 8F         [24] 1051 	mov	dptr,#_change_owned_bit_20001_313
      007D04 E0               [24] 1052 	movx	a,@dptr
      007D05 FA               [12] 1053 	mov	r2,a
      007D06 90 09 8E         [24] 1054 	mov	dptr,#_change_owned_result_10001_312
      007D09 E0               [24] 1055 	movx	a,@dptr
      007D0A 4A               [12] 1056 	orl	a,r2
      007D0B F0               [24] 1057 	movx	@dptr,a
      007D0C                       1058 00118$:
                                   1059 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007D0C 0B               [12] 1060 	inc	r3
      007D0D 90 09 8F         [24] 1061 	mov	dptr,#_change_owned_bit_20001_313
      007D10 E0               [24] 1062 	movx	a,@dptr
      007D11 25 E0            [12] 1063 	add	a,acc
      007D13 F0               [24] 1064 	movx	@dptr,a
      007D14 80 BC            [24] 1065 	sjmp	00117$
      007D16                       1066 00112$:
                                   1067 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      007D16 EE               [12] 1068 	mov	a,r6
      007D17 60 09            [24] 1069 	jz	00114$
      007D19 90 09 8E         [24] 1070 	mov	dptr,#_change_owned_result_10001_312
      007D1C E0               [24] 1071 	movx	a,@dptr
      007D1D 90 09 83         [24] 1072 	mov	dptr,#_owned_weak_mods
      007D20 F0               [24] 1073 	movx	@dptr,a
      007D21 22               [24] 1074 	ret
      007D22                       1075 00114$:
                                   1076 ;	quantum/action_util.c:104: else owned_mods = result;
      007D22 90 09 8E         [24] 1077 	mov	dptr,#_change_owned_result_10001_312
      007D25 E0               [24] 1078 	movx	a,@dptr
      007D26 90 09 82         [24] 1079 	mov	dptr,#_owned_mods
      007D29 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/action_util.c:105: }
      007D2A 22               [24] 1082 	ret
                                   1083 ;------------------------------------------------------------
                                   1084 ;Allocation info for local variables in function 'add_owned_mods'
                                   1085 ;------------------------------------------------------------
                                   1086 ;mods          Allocated with name '_add_owned_mods_mods_10000_321'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function add_owned_mods
                                   1091 ;	-----------------------------------------
      007D2B                       1092 _add_owned_mods:
      007D2B E5 82            [12] 1093 	mov	a,dpl
      007D2D 90 09 90         [24] 1094 	mov	dptr,#_add_owned_mods_mods_10000_321
      007D30 12 81 88         [24] 1095 	lcall	_ak820_outline_0118
      007D33 74 01            [12] 1096 	mov	a,#0x01
      007D35 F0               [24] 1097 	movx	@dptr,a
      007D36 8F 82            [24] 1098 	mov	dpl, r7
      007D38 02 7C 5B         [24] 1099 	ljmp	_change_owned
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'del_owned_mods'
                                   1102 ;------------------------------------------------------------
                                   1103 ;mods          Allocated with name '_del_owned_mods_mods_10000_323'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function del_owned_mods
                                   1108 ;	-----------------------------------------
      007D3B                       1109 _del_owned_mods:
      007D3B E5 82            [12] 1110 	mov	a,dpl
      007D3D 90 09 91         [24] 1111 	mov	dptr,#_del_owned_mods_mods_10000_323
      007D40 12 81 88         [24] 1112 	lcall	_ak820_outline_0118
      007D43 E4               [12] 1113 	clr	a
      007D44 F0               [24] 1114 	movx	@dptr,a
      007D45 8F 82            [24] 1115 	mov	dpl, r7
      007D47 02 7C 5B         [24] 1116 	ljmp	_change_owned
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1119 ;------------------------------------------------------------
                                   1120 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_325'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function add_owned_weak_mods
                                   1125 ;	-----------------------------------------
      007D4A                       1126 _add_owned_weak_mods:
      007D4A E5 82            [12] 1127 	mov	a,dpl
      007D4C 90 09 92         [24] 1128 	mov	dptr,#_add_owned_weak_mods_mods_10000_325
      007D4F 12 81 88         [24] 1129 	lcall	_ak820_outline_0118
      007D52 74 03            [12] 1130 	mov	a,#0x03
      007D54 F0               [24] 1131 	movx	@dptr,a
      007D55 8F 82            [24] 1132 	mov	dpl, r7
      007D57 02 7C 5B         [24] 1133 	ljmp	_change_owned
                                   1134 ;------------------------------------------------------------
                                   1135 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1136 ;------------------------------------------------------------
                                   1137 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_327'
                                   1138 ;------------------------------------------------------------
                                   1139 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1140 ;	-----------------------------------------
                                   1141 ;	 function del_owned_weak_mods
                                   1142 ;	-----------------------------------------
      007D5A                       1143 _del_owned_weak_mods:
      007D5A E5 82            [12] 1144 	mov	a,dpl
      007D5C 90 09 93         [24] 1145 	mov	dptr,#_del_owned_weak_mods_mods_10000_327
      007D5F 12 81 88         [24] 1146 	lcall	_ak820_outline_0118
      007D62 74 02            [12] 1147 	mov	a,#0x02
      007D64 F0               [24] 1148 	movx	@dptr,a
      007D65 8F 82            [24] 1149 	mov	dpl, r7
      007D67 02 7C 5B         [24] 1150 	ljmp	_change_owned
                                   1151 ;------------------------------------------------------------
                                   1152 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1153 ;------------------------------------------------------------
                                   1154 ;i             Allocated with name '_clear_owned_mods_i_20000_331'
                                   1155 ;------------------------------------------------------------
                                   1156 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1157 ;	-----------------------------------------
                                   1158 ;	 function clear_owned_mods
                                   1159 ;	-----------------------------------------
      007D6A                       1160 _clear_owned_mods:
                                   1161 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007D6A 7F 00            [12] 1162 	mov	r7,#0x00
      007D6C                       1163 00103$:
      007D6C BF 08 00         [24] 1164 	cjne	r7,#0x08,00122$
      007D6F                       1165 00122$:
      007D6F 50 1A            [24] 1166 	jnc	00101$
      007D71 EF               [12] 1167 	mov	a,r7
      007D72 24 72            [12] 1168 	add	a, #_owned_mod_refs
      007D74 FD               [12] 1169 	mov	r5,a
      007D75 E4               [12] 1170 	clr	a
      007D76 34 09            [12] 1171 	addc	a, #(_owned_mod_refs >> 8)
      007D78 FE               [12] 1172 	mov	r6,a
      007D79 EF               [12] 1173 	mov	a,r7
      007D7A 24 7A            [12] 1174 	add	a, #_owned_weak_refs
      007D7C F5 82            [12] 1175 	mov	dpl,a
      007D7E E4               [12] 1176 	clr	a
      007D7F 34 09            [12] 1177 	addc	a, #(_owned_weak_refs >> 8)
      007D81 F5 83            [12] 1178 	mov	dph,a
      007D83 E4               [12] 1179 	clr	a
      007D84 F0               [24] 1180 	movx	@dptr,a
      007D85 12 81 8F         [24] 1181 	lcall	_ak820_outline_0122
      007D88 0F               [12] 1182 	inc	r7
      007D89 80 E1            [24] 1183 	sjmp	00103$
      007D8B                       1184 00101$:
                                   1185 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007D8B 90 09 85         [24] 1186 	mov	dptr,#(_macro_mods + 0x0001)
      007D8E E4               [12] 1187 	clr	a
      007D8F F0               [24] 1188 	movx	@dptr,a
      007D90 90 09 84         [24] 1189 	mov	dptr,#_macro_mods
      007D93 F0               [24] 1190 	movx	@dptr,a
      007D94 90 09 83         [24] 1191 	mov	dptr,#_owned_weak_mods
      007D97 F0               [24] 1192 	movx	@dptr,a
      007D98 90 09 82         [24] 1193 	mov	dptr,#_owned_mods
      007D9B F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007D9C 90 09 87         [24] 1196 	mov	dptr,#_ak820_macro_cancelled
      007D9F 04               [12] 1197 	inc	a
      007DA0 F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	quantum/action_util.c:114: }
      007DA1 22               [24] 1200 	ret
                                   1201 ;------------------------------------------------------------
                                   1202 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1203 ;------------------------------------------------------------
                                   1204 ;i             Allocated with name '_clear_owned_keys_i_20000_334'
                                   1205 ;i             Allocated with name '_clear_owned_keys_i_20000_335'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function clear_owned_keys
                                   1210 ;	-----------------------------------------
      007DA2                       1211 _clear_owned_keys:
                                   1212 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007DA2 7F 00            [12] 1213 	mov	r7,#0x00
      007DA4                       1214 00104$:
      007DA4 EF               [12] 1215 	mov	a,r7
      007DA5 24 5B            [12] 1216 	add	a,#0xff - 0xa4
      007DA7 40 0D            [24] 1217 	jc	00101$
                                   1218 ;	free result
      007DA9 EF               [12] 1219 	mov	a,r7
      007DAA 24 94            [12] 1220 	add	a, #_key_refs
      007DAC F5 82            [12] 1221 	mov	dpl,a
      007DAE E4               [12] 1222 	clr	a
      007DAF 34 09            [12] 1223 	addc	a, #(_key_refs >> 8)
      007DB1 12 7B 54         [24] 1224 	lcall	_ak820_outline_0163
      007DB4 80 EE            [24] 1225 	sjmp	00104$
      007DB6                       1226 00101$:
                                   1227 ;	quantum/action_util.c:122: distinct_keys = 0;
      007DB6 90 0A 39         [24] 1228 	mov	dptr,#_distinct_keys
      007DB9 E4               [12] 1229 	clr	a
      007DBA F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007DBB FF               [12] 1232 	mov	r7,a
      007DBC                       1233 00107$:
      007DBC BF 15 00         [24] 1234 	cjne	r7,#0x15,00142$
      007DBF                       1235 00142$:
      007DBF 50 0D            [24] 1236 	jnc	00109$
      007DC1 EF               [12] 1237 	mov	a,r7
      007DC2 24 3A            [12] 1238 	add	a, #_macro_keys
      007DC4 F5 82            [12] 1239 	mov	dpl,a
      007DC6 E4               [12] 1240 	clr	a
      007DC7 34 0A            [12] 1241 	addc	a, #(_macro_keys >> 8)
      007DC9 12 7B 54         [24] 1242 	lcall	_ak820_outline_0163
      007DCC 80 EE            [24] 1243 	sjmp	00107$
      007DCE                       1244 00109$:
                                   1245 ;	quantum/action_util.c:124: }
      007DCE 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'add_owned_key'
                                   1249 ;------------------------------------------------------------
                                   1250 ;code          Allocated with name '_add_owned_key_code_10000_336'
                                   1251 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_345'
                                   1252 ;key           Allocated with name '_add_owned_key_key_50000_346'
                                   1253 ;i             Allocated with name '_add_owned_key_i_40000_344'
                                   1254 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_348'
                                   1255 ;key           Allocated with name '_add_owned_key_key_40000_349'
                                   1256 ;------------------------------------------------------------
                                   1257 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1258 ;	-----------------------------------------
                                   1259 ;	 function add_owned_key
                                   1260 ;	-----------------------------------------
      007DCF                       1261 _add_owned_key:
      007DCF E5 82            [12] 1262 	mov	a,dpl
      007DD1 90 0A 4F         [24] 1263 	mov	dptr,#_add_owned_key_code_10000_336
      007DD4 12 81 A0         [24] 1264 	lcall	_ak820_outline_0132
                                   1265 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007DD7 74 01            [12] 1266 	mov	a,#0x01
      007DD9 F0               [24] 1267 	movx	@dptr,a
      007DDA 90 0A 3A         [24] 1268 	mov	dptr,#_macro_keys
      007DDD C0 07            [24] 1269 	push	ar7
      007DDF 12 7B EF         [24] 1270 	lcall	_ak820_macro_change
      007DE2 E5 82            [12] 1271 	mov	a, dpl
      007DE4 D0 07            [24] 1272 	pop	ar7
      007DE6 70 03            [24] 1273 	jnz	00102$
      007DE8 F5 82            [12] 1274 	mov	dpl,a
      007DEA 22               [24] 1275 	ret
      007DEB                       1276 00102$:
                                   1277 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007DEB 12 81 5A         [24] 1278 	lcall	_ak820_outline_0030
      007DEE FC               [12] 1279 	mov	r4,a
      007DEF 04               [12] 1280 	inc	a
      007DF0 12 81 8F         [24] 1281 	lcall	_ak820_outline_0122
      007DF3 EC               [12] 1282 	mov	a,r4
      007DF4 60 04            [24] 1283 	jz	00104$
      007DF6 75 82 00         [24] 1284 	mov	dpl, #0x00
      007DF9 22               [24] 1285 	ret
      007DFA                       1286 00104$:
                                   1287 ;	quantum/action_util.c:128: ++distinct_keys;
      007DFA 90 0A 39         [24] 1288 	mov	dptr,#_distinct_keys
      007DFD E0               [24] 1289 	movx	a,@dptr
      007DFE 24 01            [12] 1290 	add	a, #0x01
      007E00 F0               [24] 1291 	movx	@dptr,a
                                   1292 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E01 90 0D B2         [24] 1293 	mov	dptr,#_keyboard_protocol
      007E04 E0               [24] 1294 	movx	a,@dptr
      007E05 60 11            [24] 1295 	jz	00106$
      007E07 90 0A BE         [24] 1296 	mov	dptr,#_keymap_config
      007E0A E0               [24] 1297 	movx	a,@dptr
      007E0B 30 E7 0A         [24] 1298 	jnb	acc.7,00106$
                                   1299 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E0E 12 81 AB         [24] 1300 	lcall	_ak820_outline_0176
      007E11 12 6E D9         [24] 1301 	lcall	_add_key_to_report
                                   1302 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E14 75 82 01         [24] 1303 	mov	dpl, #0x01
      007E17 22               [24] 1304 	ret
      007E18                       1305 00106$:
                                   1306 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007E18 90 0A 39         [24] 1307 	mov	dptr,#_distinct_keys
      007E1B E0               [24] 1308 	movx	a,@dptr
      007E1C 24 F9            [12] 1309 	add	a,#0xff - 0x06
      007E1E 50 17            [24] 1310 	jnc	00110$
                                   1311 ;	free result
                                   1312 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007E20 7F 00            [12] 1313 	mov	r7,#0x00
      007E22                       1314 00115$:
      007E22 BF 06 00         [24] 1315 	cjne	r7,#0x06,00174$
      007E25                       1316 00174$:
      007E25 50 1E            [24] 1317 	jnc	00111$
      007E27 EF               [12] 1318 	mov	a,r7
      007E28 24 C7            [12] 1319 	add	a, #(_actual_keyboard_report + 0x0002)
      007E2A F5 82            [12] 1320 	mov	dpl,a
      007E2C E4               [12] 1321 	clr	a
      007E2D 34 0D            [12] 1322 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007E2F F5 83            [12] 1323 	mov	dph,a
      007E31 74 01            [12] 1324 	mov	a,#0x01
      007E33 F0               [24] 1325 	movx	@dptr,a
      007E34 0F               [12] 1326 	inc	r7
      007E35 80 EB            [24] 1327 	sjmp	00115$
      007E37                       1328 00110$:
                                   1329 ;	quantum/action_util.c:134: } else add_key(code);
      007E37 90 0A 4F         [24] 1330 	mov	dptr,#_add_owned_key_code_10000_336
      007E3A E0               [24] 1331 	movx	a,@dptr
                                   1332 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E3B 90 07 FF         [24] 1333 	mov	dptr,#_add_key_to_report_PARM_2
      007E3E F0               [24] 1334 	movx	@dptr,a
      007E3F 90 0D C5         [24] 1335 	mov	dptr,#_actual_keyboard_report
      007E42 12 6E D9         [24] 1336 	lcall	_add_key_to_report
                                   1337 ;	quantum/action_util.c:134: } else add_key(code);
      007E45                       1338 00111$:
                                   1339 ;	quantum/action_util.c:135: return true;
      007E45 75 82 01         [24] 1340 	mov	dpl, #0x01
                                   1341 ;	quantum/action_util.c:136: }
      007E48 22               [24] 1342 	ret
                                   1343 ;------------------------------------------------------------
                                   1344 ;Allocation info for local variables in function 'del_owned_key'
                                   1345 ;------------------------------------------------------------
                                   1346 ;code          Allocated with name '_del_owned_key_code_10000_351'
                                   1347 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_362'
                                   1348 ;key           Allocated with name '_del_owned_key_key_50000_363'
                                   1349 ;key           Allocated with name '_del_owned_key_key_40000_360'
                                   1350 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_368'
                                   1351 ;key           Allocated with name '_del_owned_key_key_70000_369'
                                   1352 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_371'
                                   1353 ;key           Allocated with name '_del_owned_key_key_40000_372'
                                   1354 ;------------------------------------------------------------
                                   1355 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1356 ;	-----------------------------------------
                                   1357 ;	 function del_owned_key
                                   1358 ;	-----------------------------------------
      007E49                       1359 _del_owned_key:
      007E49 E5 82            [12] 1360 	mov	a,dpl
      007E4B 90 0A 50         [24] 1361 	mov	dptr,#_del_owned_key_code_10000_351
      007E4E 12 81 A0         [24] 1362 	lcall	_ak820_outline_0132
                                   1363 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007E51 E4               [12] 1364 	clr	a
      007E52 F0               [24] 1365 	movx	@dptr,a
      007E53 90 0A 3A         [24] 1366 	mov	dptr,#_macro_keys
      007E56 C0 07            [24] 1367 	push	ar7
      007E58 12 7B EF         [24] 1368 	lcall	_ak820_macro_change
      007E5B E5 82            [12] 1369 	mov	a, dpl
      007E5D D0 07            [24] 1370 	pop	ar7
      007E5F 70 03            [24] 1371 	jnz	00102$
      007E61 F5 82            [12] 1372 	mov	dpl,a
      007E63 22               [24] 1373 	ret
      007E64                       1374 00102$:
                                   1375 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007E64 12 81 5A         [24] 1376 	lcall	_ak820_outline_0030
      007E67 FC               [12] 1377 	mov	r4,a
      007E68 60 09            [24] 1378 	jz	00103$
      007E6A 1C               [12] 1379 	dec	r4
      007E6B 12 38 9C         [24] 1380 	lcall	_ak820_outline_0133
      007E6E EC               [12] 1381 	mov	a,r4
      007E6F F0               [24] 1382 	movx	@dptr,a
      007E70 EC               [12] 1383 	mov	a,r4
      007E71 60 04            [24] 1384 	jz	00104$
      007E73                       1385 00103$:
      007E73 75 82 00         [24] 1386 	mov	dpl, #0x00
      007E76 22               [24] 1387 	ret
      007E77                       1388 00104$:
                                   1389 ;	quantum/action_util.c:140: --distinct_keys;
      007E77 90 0A 39         [24] 1390 	mov	dptr,#_distinct_keys
      007E7A E0               [24] 1391 	movx	a,@dptr
      007E7B 14               [12] 1392 	dec	a
      007E7C F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E7D 90 0D B2         [24] 1395 	mov	dptr,#_keyboard_protocol
      007E80 E0               [24] 1396 	movx	a,@dptr
      007E81 60 16            [24] 1397 	jz	00107$
      007E83 90 0A BE         [24] 1398 	mov	dptr,#_keymap_config
      007E86 E0               [24] 1399 	movx	a,@dptr
      007E87 30 E7 0F         [24] 1400 	jnb	acc.7,00107$
                                   1401 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E8A 90 08 02         [24] 1402 	mov	dptr,#_del_key_from_report_PARM_2
      007E8D EF               [12] 1403 	mov	a,r7
      007E8E F0               [24] 1404 	movx	@dptr,a
      007E8F 90 0D C5         [24] 1405 	mov	dptr,#_actual_keyboard_report
      007E92 12 6F 0F         [24] 1406 	lcall	_del_key_from_report
                                   1407 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E95 75 82 01         [24] 1408 	mov	dpl, #0x01
      007E98 22               [24] 1409 	ret
      007E99                       1410 00107$:
                                   1411 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007E99 90 0A 39         [24] 1412 	mov	dptr,#_distinct_keys
      007E9C E0               [24] 1413 	movx	a,@dptr
      007E9D FF               [12] 1414 	mov  r7,a
      007E9E 24 F9            [12] 1415 	add	a,#0xff - 0x06
      007EA0 50 04            [24] 1416 	jnc	00110$
                                   1417 ;	free result
      007EA2 75 82 01         [24] 1418 	mov	dpl, #0x01
      007EA5 22               [24] 1419 	ret
      007EA6                       1420 00110$:
                                   1421 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007EA6 BF 06 1F         [24] 1422 	cjne	r7,#0x06,00115$
                                   1423 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007EA9 90 0D C5         [24] 1424 	mov	dptr,#_actual_keyboard_report
      007EAC 12 6F 45         [24] 1425 	lcall	_clear_keys_from_report
                                   1426 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007EAF 7F 04            [12] 1427 	mov	r7,#0x04
      007EB1                       1428 00122$:
      007EB1 EF               [12] 1429 	mov	a,r7
      007EB2 24 5B            [12] 1430 	add	a,#0xff - 0xa4
      007EB4 40 20            [24] 1431 	jc	00116$
                                   1432 ;	free result
      007EB6 12 81 5A         [24] 1433 	lcall	_ak820_outline_0030
      007EB9 60 0A            [24] 1434 	jz	00123$
                                   1435 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007EBB 12 81 AB         [24] 1436 	lcall	_ak820_outline_0176
      007EBE C0 07            [24] 1437 	push	ar7
      007EC0 12 6E D9         [24] 1438 	lcall	_add_key_to_report
      007EC3 D0 07            [24] 1439 	pop	ar7
                                   1440 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007EC5                       1441 00123$:
      007EC5 0F               [12] 1442 	inc	r7
      007EC6 80 E9            [24] 1443 	sjmp	00122$
      007EC8                       1444 00115$:
                                   1445 ;	quantum/action_util.c:149: } else del_key(code);
      007EC8 90 0A 50         [24] 1446 	mov	dptr,#_del_owned_key_code_10000_351
      007ECB E0               [24] 1447 	movx	a,@dptr
                                   1448 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007ECC 90 08 02         [24] 1449 	mov	dptr,#_del_key_from_report_PARM_2
      007ECF F0               [24] 1450 	movx	@dptr,a
      007ED0 90 0D C5         [24] 1451 	mov	dptr,#_actual_keyboard_report
      007ED3 12 6F 0F         [24] 1452 	lcall	_del_key_from_report
                                   1453 ;	quantum/action_util.c:149: } else del_key(code);
      007ED6                       1454 00116$:
                                   1455 ;	quantum/action_util.c:150: return true;
      007ED6 75 82 01         [24] 1456 	mov	dpl, #0x01
                                   1457 ;	quantum/action_util.c:151: }
      007ED9 22               [24] 1458 	ret
                                   1459 ;------------------------------------------------------------
                                   1460 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1461 ;------------------------------------------------------------
                                   1462 ;i             Allocated with name '_clear_owned_usages_i_20000_376'
                                   1463 ;i             Allocated with name '_clear_owned_usages_i_20000_377'
                                   1464 ;------------------------------------------------------------
                                   1465 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1466 ;	-----------------------------------------
                                   1467 ;	 function clear_owned_usages
                                   1468 ;	-----------------------------------------
      007EDA                       1469 _clear_owned_usages:
                                   1470 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007EDA 7F 00            [12] 1471 	mov	r7,#0x00
      007EDC                       1472 00104$:
      007EDC BF 1E 00         [24] 1473 	cjne	r7,#0x1e,00141$
      007EDF                       1474 00141$:
      007EDF 50 14            [24] 1475 	jnc	00101$
      007EE1 EF               [12] 1476 	mov	a,r7
      007EE2 24 51            [12] 1477 	add	a, #_usage_refs
      007EE4 FD               [12] 1478 	mov	r5,a
      007EE5 E4               [12] 1479 	clr	a
      007EE6 34 0A            [12] 1480 	addc	a, #(_usage_refs >> 8)
      007EE8 FE               [12] 1481 	mov	r6,a
      007EE9 EF               [12] 1482 	mov	a,r7
      007EEA 12 81 6F         [24] 1483 	lcall	_ak820_outline_0067
      007EED E4               [12] 1484 	clr	a
      007EEE F0               [24] 1485 	movx	@dptr,a
      007EEF 12 81 8F         [24] 1486 	lcall	_ak820_outline_0122
      007EF2 0F               [12] 1487 	inc	r7
      007EF3 80 E7            [24] 1488 	sjmp	00104$
      007EF5                       1489 00101$:
                                   1490 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007EF5 90 0A 8E         [24] 1491 	mov	dptr,#(_usage_lengths + 0x0001)
      007EF8 E4               [12] 1492 	clr	a
      007EF9 F0               [24] 1493 	movx	@dptr,a
      007EFA 90 0A 8D         [24] 1494 	mov	dptr,#_usage_lengths
      007EFD F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007EFE FF               [12] 1497 	mov	r7,a
      007EFF                       1498 00107$:
      007EFF BF 04 00         [24] 1499 	cjne	r7,#0x04,00143$
      007F02                       1500 00143$:
      007F02 50 0D            [24] 1501 	jnc	00109$
      007F04 EF               [12] 1502 	mov	a,r7
      007F05 24 8F            [12] 1503 	add	a, #_macro_usages
      007F07 F5 82            [12] 1504 	mov	dpl,a
      007F09 E4               [12] 1505 	clr	a
      007F0A 34 0A            [12] 1506 	addc	a, #(_macro_usages >> 8)
      007F0C 12 7B 54         [24] 1507 	lcall	_ak820_outline_0163
      007F0F 80 EE            [24] 1508 	sjmp	00107$
      007F11                       1509 00109$:
                                   1510 ;	quantum/action_util.c:165: }
      007F11 22               [24] 1511 	ret
                                   1512 ;------------------------------------------------------------
                                   1513 ;Allocation info for local variables in function 'owned_usage_key'
                                   1514 ;------------------------------------------------------------
                                   1515 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1516 ;code          Allocated with name '_owned_usage_key_code_10000_378'
                                   1517 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_379'
                                   1518 ;which         Allocated with name '_owned_usage_key_which_10000_379'
                                   1519 ;base          Allocated with name '_owned_usage_key_base_10000_379'
                                   1520 ;count         Allocated with name '_owned_usage_key_count_10000_379'
                                   1521 ;index         Allocated with name '_owned_usage_key_index_10000_379'
                                   1522 ;pos           Allocated with name '_owned_usage_key_pos_30001_386'
                                   1523 ;i             Allocated with name '_owned_usage_key_i_40001_387'
                                   1524 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_390'
                                   1525 ;key           Allocated with name '_owned_usage_key_key_40000_391'
                                   1526 ;------------------------------------------------------------
                                   1527 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1528 ;	-----------------------------------------
                                   1529 ;	 function owned_usage_key
                                   1530 ;	-----------------------------------------
      007F12                       1531 _owned_usage_key:
      007F12 E5 82            [12] 1532 	mov	a,dpl
      007F14 90 0A 94         [24] 1533 	mov	dptr,#_owned_usage_key_code_10000_378
      007F17 F0               [24] 1534 	movx	@dptr,a
                                   1535 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007F18 E0               [24] 1536 	movx	a,@dptr
      007F19 FF               [12] 1537 	mov	r7,a
      007F1A BF A8 00         [24] 1538 	cjne	r7,#0xa8,00244$
      007F1D                       1539 00244$:
      007F1D B3               [12] 1540 	cpl	c
      007F1E 92 25            [24] 1541 	mov	_owned_usage_key_sloc0_1_0,c
      007F20 E4               [12] 1542 	clr	a
      007F21 33               [12] 1543 	rlc	a
      007F22 FF               [12] 1544 	mov	r7,a
      007F23 90 0A 97         [24] 1545 	mov	dptr,#_owned_usage_key_which_10000_379
      007F26 F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007F27 EF               [12] 1548 	mov	a,r7
      007F28 60 02            [24] 1549 	jz	00129$
      007F2A 74 03            [12] 1550 	mov	a,#0x03
      007F2C                       1551 00129$:
      007F2C FE               [12] 1552 	mov	r6,a
                                   1553 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007F2D EF               [12] 1554 	mov	a,r7
      007F2E 24 8D            [12] 1555 	add	a, #_usage_lengths
      007F30 FD               [12] 1556 	mov	r5,a
      007F31 E4               [12] 1557 	clr	a
      007F32 34 0A            [12] 1558 	addc	a, #(_usage_lengths >> 8)
      007F34 FF               [12] 1559 	mov	r7,a
      007F35 12 81 B4         [24] 1560 	lcall	_ak820_outline_0190
      007F38 E0               [24] 1561 	movx	a,@dptr
      007F39 FC               [12] 1562 	mov	r4,a
                                   1563 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007F3A 90 0A 94         [24] 1564 	mov	dptr,#_owned_usage_key_code_10000_378
      007F3D E0               [24] 1565 	movx	a,@dptr
      007F3E 24 5B            [12] 1566 	add	a,#0x5b
      007F40 FB               [12] 1567 	mov	r3,a
                                   1568 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007F41 90 0A 93         [24] 1569 	mov	dptr,#_owned_usage_key_PARM_2
      007F44 E0               [24] 1570 	movx	a,@dptr
      007F45 FA               [12] 1571 	mov	r2,a
      007F46 90 09 88         [24] 1572 	mov	dptr,#_ak820_macro_change_PARM_2
      007F49 EB               [12] 1573 	mov	a,r3
      007F4A F0               [24] 1574 	movx	@dptr,a
      007F4B 90 09 89         [24] 1575 	mov	dptr,#_ak820_macro_change_PARM_3
      007F4E EA               [12] 1576 	mov	a,r2
      007F4F F0               [24] 1577 	movx	@dptr,a
      007F50 90 0A 8F         [24] 1578 	mov	dptr,#_macro_usages
      007F53 C0 07            [24] 1579 	push	ar7
      007F55 C0 06            [24] 1580 	push	ar6
      007F57 C0 05            [24] 1581 	push	ar5
      007F59 C0 04            [24] 1582 	push	ar4
      007F5B C0 03            [24] 1583 	push	ar3
      007F5D C0 02            [24] 1584 	push	ar2
      007F5F 12 7B EF         [24] 1585 	lcall	_ak820_macro_change
      007F62 E5 82            [12] 1586 	mov	a, dpl
      007F64 D0 02            [24] 1587 	pop	ar2
      007F66 D0 03            [24] 1588 	pop	ar3
      007F68 D0 04            [24] 1589 	pop	ar4
      007F6A D0 05            [24] 1590 	pop	ar5
      007F6C D0 06            [24] 1591 	pop	ar6
      007F6E D0 07            [24] 1592 	pop	ar7
      007F70 70 01            [24] 1593 	jnz	00102$
      007F72 22               [24] 1594 	ret
      007F73                       1595 00102$:
                                   1596 ;	quantum/action_util.c:172: if (pressed) {
      007F73 EA               [12] 1597 	mov	a,r2
      007F74 60 1B            [24] 1598 	jz	00115$
                                   1599 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007F76 12 81 79         [24] 1600 	lcall	_ak820_outline_0075
      007F79 04               [12] 1601 	inc	a
      007F7A 12 6C 55         [24] 1602 	lcall	_ak820_outline_0139
      007F7D E8               [12] 1603 	mov	a,r0
      007F7E 60 01            [24] 1604 	jz	00104$
      007F80 22               [24] 1605 	ret
      007F81                       1606 00104$:
                                   1607 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007F81 90 0A 98         [24] 1608 	mov	dptr,#_owned_usage_key_count_10000_379
      007F84 EC               [12] 1609 	mov	a,r4
      007F85 04               [12] 1610 	inc	a
      007F86 F0               [24] 1611 	movx	@dptr,a
      007F87 EC               [12] 1612 	mov	a,r4
      007F88 2E               [12] 1613 	add	a, r6
      007F89 12 81 6F         [24] 1614 	lcall	_ak820_outline_0067
      007F8C EB               [12] 1615 	mov	a,r3
      007F8D F0               [24] 1616 	movx	@dptr,a
      007F8E 02 7F F2         [24] 1617 	ljmp	00116$
      007F91                       1618 00115$:
                                   1619 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007F91 12 81 79         [24] 1620 	lcall	_ak820_outline_0075
      007F94 60 07            [24] 1621 	jz	00105$
      007F96 18               [12] 1622 	dec	r0
      007F97 12 81 68         [24] 1623 	lcall	_ak820_outline_0062
      007F9A E8               [12] 1624 	mov	a,r0
      007F9B 60 01            [24] 1625 	jz	00106$
      007F9D                       1626 00105$:
      007F9D 22               [24] 1627 	ret
      007F9E                       1628 00106$:
                                   1629 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007F9E 7A 00            [12] 1630 	mov	r2,#0x00
      007FA0                       1631 00108$:
      007FA0 EA               [12] 1632 	mov	a,r2
      007FA1 2E               [12] 1633 	add	a, r6
      007FA2 12 81 6F         [24] 1634 	lcall	_ak820_outline_0067
      007FA5 E0               [24] 1635 	movx	a,@dptr
      007FA6 B5 03 02         [24] 1636 	cjne	a,ar3,00251$
      007FA9 80 03            [24] 1637 	sjmp	00167$
      007FAB                       1638 00251$:
      007FAB 0A               [12] 1639 	inc	r2
      007FAC 80 F2            [24] 1640 	sjmp	00108$
      007FAE                       1641 00167$:
      007FAE 90 0A 99         [24] 1642 	mov	dptr,#_owned_usage_key_pos_30001_386
      007FB1 EA               [12] 1643 	mov	a,r2
      007FB2 F0               [24] 1644 	movx	@dptr,a
                                   1645 ;	quantum/action_util.c:179: --count;
      007FB3 1C               [12] 1646 	dec	r4
      007FB4 90 0A 98         [24] 1647 	mov	dptr,#_owned_usage_key_count_10000_379
      007FB7 EC               [12] 1648 	mov	a,r4
      007FB8 F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007FB9 8A 03            [24] 1651 	mov	ar3,r2
      007FBB                       1652 00125$:
      007FBB C3               [12] 1653 	clr	c
      007FBC EB               [12] 1654 	mov	a,r3
      007FBD 9C               [12] 1655 	subb	a,r4
      007FBE 50 23            [24] 1656 	jnc	00111$
      007FC0 C0 05            [24] 1657 	push	ar5
      007FC2 C0 07            [24] 1658 	push	ar7
      007FC4 EB               [12] 1659 	mov	a,r3
      007FC5 2E               [12] 1660 	add	a, r6
      007FC6 FA               [12] 1661 	mov	r2,a
      007FC7 24 6F            [12] 1662 	add	a, #_usage_order
      007FC9 F8               [12] 1663 	mov	r0,a
      007FCA E4               [12] 1664 	clr	a
      007FCB 34 0A            [12] 1665 	addc	a, #(_usage_order >> 8)
      007FCD F9               [12] 1666 	mov	r1,a
      007FCE 0A               [12] 1667 	inc	r2
      007FCF EA               [12] 1668 	mov	a,r2
      007FD0 33               [12] 1669 	rlc	a
      007FD1 95 E0            [12] 1670 	subb	a,acc
      007FD3 FF               [12] 1671 	mov	r7,a
      007FD4 EA               [12] 1672 	mov	a,r2
      007FD5 12 81 95         [24] 1673 	lcall	_ak820_outline_0125
      007FD8 12 38 B6         [24] 1674 	lcall	_ak820_outline_0157
      007FDB F0               [24] 1675 	movx	@dptr,a
      007FDC 0B               [12] 1676 	inc	r3
      007FDD D0 07            [24] 1677 	pop	ar7
      007FDF D0 05            [24] 1678 	pop	ar5
      007FE1 80 D8            [24] 1679 	sjmp	00125$
      007FE3                       1680 00111$:
                                   1681 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007FE3 12 81 B4         [24] 1682 	lcall	_ak820_outline_0190
      007FE6 EC               [12] 1683 	mov	a,r4
      007FE7 F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007FE8 90 0A 99         [24] 1686 	mov	dptr,#_owned_usage_key_pos_30001_386
      007FEB E0               [24] 1687 	movx	a,@dptr
      007FEC B5 04 02         [24] 1688 	cjne	a,ar4,00253$
      007FEF 80 01            [24] 1689 	sjmp	00116$
      007FF1                       1690 00253$:
      007FF1 22               [24] 1691 	ret
      007FF2                       1692 00116$:
                                   1693 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007FF2 90 0A 98         [24] 1694 	mov	dptr,#_owned_usage_key_count_10000_379
      007FF5 E0               [24] 1695 	movx	a,@dptr
      007FF6 FC               [12] 1696 	mov	r4,a
      007FF7 12 81 B4         [24] 1697 	lcall	_ak820_outline_0190
      007FFA F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007FFB EC               [12] 1700 	mov	a,r4
      007FFC 60 15            [24] 1701 	jz	00131$
      007FFE EC               [12] 1702 	mov	a,r4
      007FFF 2E               [12] 1703 	add	a, r6
      008000 FE               [12] 1704 	mov	r6,a
      008001 1E               [12] 1705 	dec	r6
      008002 EE               [12] 1706 	mov	a,r6
      008003 33               [12] 1707 	rlc	a
      008004 95 E0            [12] 1708 	subb	a,acc
      008006 FF               [12] 1709 	mov	r7,a
      008007 EE               [12] 1710 	mov	a,r6
      008008 12 81 95         [24] 1711 	lcall	_ak820_outline_0125
      00800B 24 A5            [12] 1712 	add	a,#0xa5
      00800D FE               [12] 1713 	mov	r6,a
      00800E 33               [12] 1714 	rlc	a
      00800F 95 E0            [12] 1715 	subb	a,acc
      008011 80 02            [24] 1716 	sjmp	00132$
      008013                       1717 00131$:
      008013 7E 00            [12] 1718 	mov	r6,#0x00
      008015                       1719 00132$:
      008015 90 0A 94         [24] 1720 	mov	dptr,#_owned_usage_key_code_10000_378
      008018 EE               [12] 1721 	mov	a,r6
      008019 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      00801A 90 0A 97         [24] 1724 	mov	dptr,#_owned_usage_key_which_10000_379
      00801D E0               [24] 1725 	movx	a,@dptr
      00801E 60 18            [24] 1726 	jz	00118$
      008020 EE               [12] 1727 	mov	a,r6
      008021 60 0B            [24] 1728 	jz	00133$
      008023 8E 82            [24] 1729 	mov	dpl, r6
      008025 12 6D 95         [24] 1730 	lcall	_KEYCODE2CONSUMER
      008028 AD 82            [24] 1731 	mov	r5, dpl
      00802A AF 83            [24] 1732 	mov	r7, dph
      00802C 80 04            [24] 1733 	sjmp	00134$
      00802E                       1734 00133$:
      00802E 7D 00            [12] 1735 	mov	r5,#0x00
      008030 7F 00            [12] 1736 	mov	r7,#0x00
      008032                       1737 00134$:
      008032 12 81 B4         [24] 1738 	lcall	_ak820_outline_0190
      008035 02 6D 48         [24] 1739 	ljmp	_host_consumer_send
      008038                       1740 00118$:
                                   1741 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008038 EE               [12] 1742 	mov	a,r6
      008039 60 22            [24] 1743 	jz	00135$
                                   1744 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      00803B BE A5 00         [24] 1745 	cjne	r6,#0xa5,00258$
      00803E                       1746 00258$:
      00803E 40 05            [24] 1747 	jc	00121$
      008040 EE               [12] 1748 	mov	a,r6
      008041 24 58            [12] 1749 	add	a,#0xff - 0xa7
      008043 50 08            [24] 1750 	jnc	00122$
                                   1751 ;	free result
      008045                       1752 00121$:
      008045 90 0A 95         [24] 1753 	mov	dptr,#_owned_usage_key___200000085_20000_379
      008048 12 4F 71         [24] 1754 	lcall	_ak820_outline_0183
      00804B 80 09            [24] 1755 	sjmp	00123$
      00804D                       1756 00122$:
                                   1757 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      00804D 74 DC            [12] 1758 	mov	a,#0xdc
      00804F 2E               [12] 1759 	add	a, r6
      008050 90 0A 95         [24] 1760 	mov	dptr,#_owned_usage_key___200000085_20000_379
      008053 12 38 A1         [24] 1761 	lcall	_ak820_outline_0135
                                   1762 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008056                       1763 00123$:
      008056 90 0A 95         [24] 1764 	mov	dptr,#_owned_usage_key___200000085_20000_379
      008059 E0               [24] 1765 	movx	a,@dptr
      00805A FF               [12] 1766 	mov	r7,a
      00805B 80 02            [24] 1767 	sjmp	00136$
      00805D                       1768 00135$:
      00805D 7F 00            [12] 1769 	mov	r7,#0x00
      00805F                       1770 00136$:
      00805F 7E 00            [12] 1771 	mov	r6,#0x00
      008061 12 43 6D         [24] 1772 	lcall	_ak820_outline_0158
                                   1773 ;	quantum/action_util.c:188: }
      008064 02 6D 18         [24] 1774 	ljmp	_host_system_send
                                   1775 ;------------------------------------------------------------
                                   1776 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1777 ;------------------------------------------------------------
                                   1778 ;mods          Allocated with name '_send_keyboard_report_mods_30000_399'
                                   1779 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_401'
                                   1780 ;changed       Allocated with name '_send_keyboard_report_changed_10001_401'
                                   1781 ;dest          Allocated with name '_send_keyboard_report_dest_10001_401'
                                   1782 ;src           Allocated with name '_send_keyboard_report_src_10001_401'
                                   1783 ;i             Allocated with name '_send_keyboard_report_i_20001_402'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function send_keyboard_report
                                   1788 ;	-----------------------------------------
      008067                       1789 _send_keyboard_report:
                                   1790 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      008067 90 0D C3         [24] 1791 	mov	dptr,#_real_mods
      00806A E0               [24] 1792 	movx	a,@dptr
      00806B FF               [12] 1793 	mov	r7,a
      00806C 90 0D C5         [24] 1794 	mov	dptr,#_actual_keyboard_report
      00806F F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      008070 90 0D C4         [24] 1797 	mov	dptr,#_weak_mods
      008073 E0               [24] 1798 	movx	a,@dptr
      008074 42 07            [12] 1799 	orl	ar7,a
      008076 90 0D C5         [24] 1800 	mov	dptr,#_actual_keyboard_report
      008079 EF               [12] 1801 	mov	a,r7
      00807A F0               [24] 1802 	movx	@dptr,a
                                   1803 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00807B 90 09 83         [24] 1804 	mov	dptr,#_owned_weak_mods
      00807E E0               [24] 1805 	movx	a,@dptr
      00807F FE               [12] 1806 	mov	r6,a
      008080 90 09 82         [24] 1807 	mov	dptr,#_owned_mods
      008083 E0               [24] 1808 	movx	a,@dptr
      008084 4E               [12] 1809 	orl	a,r6
      008085 42 07            [12] 1810 	orl	ar7,a
      008087 90 0D C5         [24] 1811 	mov	dptr,#_actual_keyboard_report
      00808A EF               [12] 1812 	mov	a,r7
      00808B F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:438: if (ctrl_gui_swapped) {
      00808C 30 21 31         [24] 1815 	jnb	_ctrl_gui_swapped,00102$
                                   1816 ;	quantum/action_util.c:439: uint8_t mods = keyboard_report->mods;
      00808F 90 0D C5         [24] 1817 	mov	dptr,#_actual_keyboard_report
      008092 E0               [24] 1818 	movx	a,@dptr
      008093 FF               [12] 1819 	mov	r7,a
                                   1820 ;	quantum/action_util.c:440: keyboard_report->mods = (mods & 0x66) | ((mods & 0x11) << 3) | ((mods & 0x88) >> 3);
      008094 74 66            [12] 1821 	mov	a,#0x66
      008096 5F               [12] 1822 	anl	a,r7
      008097 FE               [12] 1823 	mov	r6,a
      008098 8F 05            [24] 1824 	mov	ar5,r7
      00809A 53 05 11         [24] 1825 	anl	ar5,#0x11
      00809D ED               [12] 1826 	mov	a,r5
      00809E 12 38 C6         [24] 1827 	lcall	_ak820_outline_0189
      0080A1 42 06            [12] 1828 	orl	ar6,a
      0080A3 53 07 88         [24] 1829 	anl	ar7,#0x88
      0080A6 E4               [12] 1830 	clr	a
      0080A7 23               [12] 1831 	rl	a
      0080A8 CF               [12] 1832 	xch	a,r7
      0080A9 12 57 54         [24] 1833 	lcall	_ak820_outline_0171
      0080AC 6F               [12] 1834 	xrl	a,r7
      0080AD CF               [12] 1835 	xch	a,r7
      0080AE 54 1F            [12] 1836 	anl	a,#0x1f
      0080B0 CF               [12] 1837 	xch	a,r7
      0080B1 6F               [12] 1838 	xrl	a,r7
      0080B2 CF               [12] 1839 	xch	a,r7
      0080B3 30 E4 02         [24] 1840 	jnb	acc.4,00159$
      0080B6 44 E0            [12] 1841 	orl	a,#0xffffffe0
      0080B8                       1842 00159$:
      0080B8 EF               [12] 1843 	mov	a,r7
      0080B9 42 06            [12] 1844 	orl	ar6,a
      0080BB 90 0D C5         [24] 1845 	mov	dptr,#_actual_keyboard_report
      0080BE EE               [12] 1846 	mov	a,r6
      0080BF F0               [24] 1847 	movx	@dptr,a
      0080C0                       1848 00102$:
                                   1849 ;	quantum/action_util.c:444: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      0080C0 30 20 07         [24] 1850 	jnb	_gui_disabled,00104$
      0080C3 90 0D C5         [24] 1851 	mov	dptr,#_actual_keyboard_report
      0080C6 E0               [24] 1852 	movx	a,@dptr
      0080C7 54 77            [12] 1853 	anl	a,#0x77
      0080C9 F0               [24] 1854 	movx	@dptr,a
      0080CA                       1855 00104$:
                                   1856 ;	quantum/action_util.c:455: bool changed = false;
      0080CA 90 0A BB         [24] 1857 	mov	dptr,#_send_keyboard_report_changed_10001_401
      0080CD E4               [12] 1858 	clr	a
      0080CE F0               [24] 1859 	movx	@dptr,a
                                   1860 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1861 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1862 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0080CF FF               [12] 1863 	mov	r7,a
      0080D0                       1864 00111$:
      0080D0 BF 20 00         [24] 1865 	cjne	r7,#0x20,00161$
      0080D3                       1866 00161$:
      0080D3 50 2A            [24] 1867 	jnc	00107$
                                   1868 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      0080D5 EF               [12] 1869 	mov	a,r7
      0080D6 24 9B            [12] 1870 	add	a, #_send_keyboard_report_last_report_10001_401
      0080D8 FD               [12] 1871 	mov	r5,a
      0080D9 E4               [12] 1872 	clr	a
      0080DA 34 0A            [12] 1873 	addc	a, #(_send_keyboard_report_last_report_10001_401 >> 8)
      0080DC 12 48 A9         [24] 1874 	lcall	_ak820_outline_0056
      0080DF EF               [12] 1875 	mov	a,r7
      0080E0 24 C5            [12] 1876 	add	a, #_actual_keyboard_report
      0080E2 F5 82            [12] 1877 	mov	dpl,a
      0080E4 E4               [12] 1878 	clr	a
      0080E5 34 0D            [12] 1879 	addc	a, #(_actual_keyboard_report >> 8)
      0080E7 F5 83            [12] 1880 	mov	dph,a
      0080E9 E0               [24] 1881 	movx	a,@dptr
      0080EA FB               [12] 1882 	mov	r3,a
      0080EB EC               [12] 1883 	mov	a,r4
      0080EC B5 03 02         [24] 1884 	cjne	a,ar3,00163$
      0080EF 80 0B            [24] 1885 	sjmp	00112$
      0080F1                       1886 00163$:
                                   1887 ;	quantum/action_util.c:465: dest[i] = src[i];
      0080F1 12 38 9C         [24] 1888 	lcall	_ak820_outline_0133
      0080F4 EB               [12] 1889 	mov	a,r3
      0080F5 F0               [24] 1890 	movx	@dptr,a
                                   1891 ;	quantum/action_util.c:466: changed = true;
      0080F6 90 0A BB         [24] 1892 	mov	dptr,#_send_keyboard_report_changed_10001_401
      0080F9 74 01            [12] 1893 	mov	a,#0x01
      0080FB F0               [24] 1894 	movx	@dptr,a
      0080FC                       1895 00112$:
                                   1896 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0080FC 0F               [12] 1897 	inc	r7
      0080FD 80 D1            [24] 1898 	sjmp	00111$
      0080FF                       1899 00107$:
                                   1900 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      0080FF 90 0A BB         [24] 1901 	mov	dptr,#_send_keyboard_report_changed_10001_401
      008102 E0               [24] 1902 	movx	a,@dptr
      008103 60 09            [24] 1903 	jz	00113$
      008105 90 0D C5         [24] 1904 	mov	dptr,#_actual_keyboard_report
      008108 75 F0 00         [24] 1905 	mov	b, #0x00
                                   1906 ;	quantum/action_util.c:477: }
      00810B 02 6C 8D         [24] 1907 	ljmp	_host_keyboard_send
      00810E                       1908 00113$:
      00810E 22               [24] 1909 	ret
                                   1910 ;------------------------------------------------------------
                                   1911 ;Allocation info for local variables in function 'get_mods'
                                   1912 ;------------------------------------------------------------
                                   1913 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1914 ;	-----------------------------------------
                                   1915 ;	 function get_mods
                                   1916 ;	-----------------------------------------
      00810F                       1917 _get_mods:
      00810F C0 07            [24] 1918 	push	ar7
                                   1919 ;	quantum/action_util.c:488: ;
      008111 90 09 82         [24] 1920 	mov	dptr,#_owned_mods
      008114 E0               [24] 1921 	movx	a,@dptr
      008115 FF               [12] 1922 	mov	r7,a
      008116 90 0D C3         [24] 1923 	mov	dptr,#_real_mods
      008119 12 7B 4E         [24] 1924 	lcall	_ak820_outline_0141
                                   1925 ;	quantum/action_util.c:489: }
      00811C D0 07            [24] 1926 	pop	ar7
      00811E 22               [24] 1927 	ret
                                   1928 ;------------------------------------------------------------
                                   1929 ;Allocation info for local variables in function 'add_mods'
                                   1930 ;------------------------------------------------------------
                                   1931 ;mods          Allocated with name '_add_mods_mods_10000_409'
                                   1932 ;------------------------------------------------------------
                                   1933 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1934 ;	-----------------------------------------
                                   1935 ;	 function clear_mods
                                   1936 ;	-----------------------------------------
      00811F                       1937 _clear_mods:
                                   1938 ;	quantum/action_util.c:516: real_mods = 0;
      00811F 90 0D C3         [24] 1939 	mov	dptr,#_real_mods
      008122 E4               [12] 1940 	clr	a
      008123 F0               [24] 1941 	movx	@dptr,a
                                   1942 ;	quantum/action_util.c:517: }
      008124 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'get_weak_mods'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function get_weak_mods
                                   1950 ;	-----------------------------------------
      008125                       1951 _get_weak_mods:
      008125 C0 07            [24] 1952 	push	ar7
                                   1953 ;	quantum/action_util.c:528: ;
      008127 90 09 83         [24] 1954 	mov	dptr,#_owned_weak_mods
      00812A E0               [24] 1955 	movx	a,@dptr
      00812B FF               [12] 1956 	mov	r7,a
      00812C 90 0D C4         [24] 1957 	mov	dptr,#_weak_mods
      00812F 12 7B 4E         [24] 1958 	lcall	_ak820_outline_0141
                                   1959 ;	quantum/action_util.c:529: }
      008132 D0 07            [24] 1960 	pop	ar7
      008134 22               [24] 1961 	ret
                                   1962 ;------------------------------------------------------------
                                   1963 ;Allocation info for local variables in function 'add_weak_mods'
                                   1964 ;------------------------------------------------------------
                                   1965 ;mods          Allocated with name '_add_weak_mods_mods_10000_419'
                                   1966 ;------------------------------------------------------------
                                   1967 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1968 ;	-----------------------------------------
                                   1969 ;	 function add_weak_mods
                                   1970 ;	-----------------------------------------
      008135                       1971 _add_weak_mods:
      008135 E5 82            [12] 1972 	mov	a,dpl
      008137 90 0A BC         [24] 1973 	mov	dptr,#_add_weak_mods_mods_10000_419
      00813A F0               [24] 1974 	movx	@dptr,a
                                   1975 ;	quantum/action_util.c:535: weak_mods |= mods;
      00813B E0               [24] 1976 	movx	a,@dptr
      00813C FF               [12] 1977 	mov	r7,a
      00813D 90 0D C4         [24] 1978 	mov	dptr,#_weak_mods
      008140 E0               [24] 1979 	movx	a,@dptr
      008141 4F               [12] 1980 	orl	a,r7
      008142 F0               [24] 1981 	movx	@dptr,a
                                   1982 ;	quantum/action_util.c:536: }
      008143 22               [24] 1983 	ret
                                   1984 ;------------------------------------------------------------
                                   1985 ;Allocation info for local variables in function 'del_weak_mods'
                                   1986 ;------------------------------------------------------------
                                   1987 ;mods          Allocated with name '_del_weak_mods_mods_10000_421'
                                   1988 ;------------------------------------------------------------
                                   1989 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1990 ;	-----------------------------------------
                                   1991 ;	 function del_weak_mods
                                   1992 ;	-----------------------------------------
      008144                       1993 _del_weak_mods:
      008144 E5 82            [12] 1994 	mov	a,dpl
      008146 90 0A BD         [24] 1995 	mov	dptr,#_del_weak_mods_mods_10000_421
      008149 F0               [24] 1996 	movx	@dptr,a
                                   1997 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      00814A E0               [24] 1998 	movx	a,@dptr
      00814B F4               [12] 1999 	cpl	a
      00814C FF               [12] 2000 	mov	r7,a
      00814D 90 0D C4         [24] 2001 	mov	dptr,#_weak_mods
      008150 E0               [24] 2002 	movx	a,@dptr
      008151 5F               [12] 2003 	anl	a,r7
      008152 F0               [24] 2004 	movx	@dptr,a
                                   2005 ;	quantum/action_util.c:543: }
      008153 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'set_weak_mods'
                                   2009 ;------------------------------------------------------------
                                   2010 ;mods          Allocated with name '_set_weak_mods_mods_10000_423'
                                   2011 ;------------------------------------------------------------
                                   2012 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   2013 ;	-----------------------------------------
                                   2014 ;	 function clear_weak_mods
                                   2015 ;	-----------------------------------------
      008154                       2016 _clear_weak_mods:
                                   2017 ;	quantum/action_util.c:556: weak_mods = 0;
      008154 90 0D C4         [24] 2018 	mov	dptr,#_weak_mods
      008157 E4               [12] 2019 	clr	a
      008158 F0               [24] 2020 	movx	@dptr,a
                                   2021 ;	quantum/action_util.c:557: }
      008159 22               [24] 2022 	ret
                                   2023 ;------------------------------------------------------------
                                   2024 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2025 ;------------------------------------------------------------
                                   2026 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_427'
                                   2027 ;------------------------------------------------------------
                                   2028 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2029 ;	-----------------------------------------
                                   2030 	.area CSEG    (CODE)
                                   2031 	.area CONST   (CODE)
                                   2032 	.area XINIT   (CODE)
      00C1D8                       2033 __xinit__real_mods:
      00C1D8 00                    2034 	.db #0x00	; 0
      00C1D9                       2035 __xinit__weak_mods:
      00C1D9 00                    2036 	.db #0x00	; 0
      00C1DA                       2037 __xinit__actual_keyboard_report:
      00C1DA 00                    2038 	.db #0x00	; 0
      00C1DB 00                    2039 	.db #0x00	; 0
      00C1DC 00                    2040 	.db #0x00	; 0
      00C1DD 00                    2041 	.db #0x00	; 0
      00C1DE 00                    2042 	.db #0x00	; 0
      00C1DF 00                    2043 	.db #0x00	; 0
      00C1E0 00                    2044 	.db #0x00	; 0
      00C1E1 00                    2045 	.db #0x00	; 0
      00C1E2 00                    2046 	.db 0x00
      00C1E3 00                    2047 	.db 0x00
      00C1E4 00                    2048 	.db 0x00
      00C1E5 00                    2049 	.db 0x00
      00C1E6 00                    2050 	.db 0x00
      00C1E7 00                    2051 	.db 0x00
      00C1E8 00                    2052 	.db 0x00
      00C1E9 00                    2053 	.db 0x00
      00C1EA 00                    2054 	.db 0x00
      00C1EB 00                    2055 	.db 0x00
      00C1EC 00                    2056 	.db 0x00
      00C1ED 00                    2057 	.db 0x00
      00C1EE 00                    2058 	.db 0x00
      00C1EF 00                    2059 	.db 0x00
      00C1F0 00                    2060 	.db 0x00
      00C1F1 00                    2061 	.db 0x00
      00C1F2 00                    2062 	.db 0x00
      00C1F3 00                    2063 	.db 0x00
      00C1F4 00                    2064 	.db 0x00
      00C1F5 00                    2065 	.db 0x00
      00C1F6 00                    2066 	.db 0x00
      00C1F7 00                    2067 	.db 0x00
      00C1F8 00                    2068 	.db 0x00
      00C1F9 00                    2069 	.db 0x00
                                   2070 	.area CABS    (ABS,CODE)
                                   2071 
                                   2072 ; Experimental exact instruction outlining.
                                   2073 	.globl _ak820_outline_0016
                                   2074 	.globl _ak820_outline_0030
                                   2075 	.globl _ak820_outline_0051
                                   2076 	.globl _ak820_outline_0056
                                   2077 	.globl _ak820_outline_0059
                                   2078 	.globl _ak820_outline_0061
                                   2079 	.globl _ak820_outline_0062
                                   2080 	.globl _ak820_outline_0063
                                   2081 	.globl _ak820_outline_0067
                                   2082 	.globl _ak820_outline_0075
                                   2083 	.globl _ak820_outline_0108
                                   2084 	.globl _ak820_outline_0109
                                   2085 	.globl _ak820_outline_0118
                                   2086 	.globl _ak820_outline_0122
                                   2087 	.globl _ak820_outline_0123
                                   2088 	.globl _ak820_outline_0125
                                   2089 	.globl _ak820_outline_0132
                                   2090 	.globl _ak820_outline_0133
                                   2091 	.globl _ak820_outline_0135
                                   2092 	.globl _ak820_outline_0139
                                   2093 	.globl _ak820_outline_0141
                                   2094 	.globl _ak820_outline_0157
                                   2095 	.globl _ak820_outline_0158
                                   2096 	.globl _ak820_outline_0163
                                   2097 	.globl _ak820_outline_0171
                                   2098 	.globl _ak820_outline_0176
                                   2099 	.globl _ak820_outline_0183
                                   2100 	.globl _ak820_outline_0189
                                   2101 	.globl _ak820_outline_0190
                                   2102 
                                   2103 	.area CSEG (CODE)
                                   2104 ; function ak820_outline_0030
      00815A                       2105 _ak820_outline_0030:
      00815A EF               [12] 2106 	mov	a,r7
      00815B 24 94            [12] 2107 	add	a,#_key_refs
      00815D FD               [12] 2108 	mov	r5,a
      00815E E4               [12] 2109 	clr	a
      00815F 34 09            [12] 2110 	addc	a,#(_key_refs>>8)
      008161 FE               [12] 2111 	mov	r6,a
      008162 8D 82            [24] 2112 	mov	dpl,r5
      008164 8E 83            [24] 2113 	mov	dph,r6
      008166 E0               [24] 2114 	movx	a,@dptr
      008167 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0062
      008168                       2119 _ak820_outline_0062:
      008168 89 82            [24] 2120 	mov	dpl,r1
      00816A 8A 83            [24] 2121 	mov	dph,r2
      00816C E8               [12] 2122 	mov	a,r0
      00816D F0               [24] 2123 	movx	@dptr,a
      00816E 22               [24] 2124 	ret
                                   2125 
                                   2126 	.area CSEG (CODE)
                                   2127 ; function ak820_outline_0067
      00816F                       2128 _ak820_outline_0067:
      00816F 24 6F            [12] 2129 	add	a,#_usage_order
      008171 F5 82            [12] 2130 	mov	dpl,a
      008173 E4               [12] 2131 	clr	a
      008174 34 0A            [12] 2132 	addc	a,#(_usage_order>>8)
      008176 F5 83            [12] 2133 	mov	dph,a
      008178 22               [24] 2134 	ret
                                   2135 
                                   2136 	.area CSEG (CODE)
                                   2137 ; function ak820_outline_0075
      008179                       2138 _ak820_outline_0075:
      008179 EB               [12] 2139 	mov	a,r3
      00817A 24 51            [12] 2140 	add	a,#_usage_refs
      00817C F9               [12] 2141 	mov	r1,a
      00817D E4               [12] 2142 	clr	a
      00817E 34 0A            [12] 2143 	addc	a,#(_usage_refs>>8)
      008180 FA               [12] 2144 	mov	r2,a
      008181 89 82            [24] 2145 	mov	dpl,r1
      008183 8A 83            [24] 2146 	mov	dph,r2
      008185 E0               [24] 2147 	movx	a,@dptr
      008186 F8               [12] 2148 	mov	r0,a
      008187 22               [24] 2149 	ret
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0118
      008188                       2153 _ak820_outline_0118:
      008188 F0               [24] 2154 	movx	@dptr,a
      008189 E0               [24] 2155 	movx	a,@dptr
      00818A FF               [12] 2156 	mov	r7,a
      00818B 90 09 8C         [24] 2157 	mov	dptr,#_change_owned_PARM_2
      00818E 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0122
      00818F                       2162 _ak820_outline_0122:
      00818F 8D 82            [24] 2163 	mov	dpl,r5
      008191 8E 83            [24] 2164 	mov	dph,r6
      008193 F0               [24] 2165 	movx	@dptr,a
      008194 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0125
      008195                       2170 _ak820_outline_0125:
      008195 24 6F            [12] 2171 	add	a,#_usage_order
      008197 F5 82            [12] 2172 	mov	dpl,a
      008199 EF               [12] 2173 	mov	a,r7
      00819A 34 0A            [12] 2174 	addc	a,#(_usage_order>>8)
      00819C F5 83            [12] 2175 	mov	dph,a
      00819E E0               [24] 2176 	movx	a,@dptr
      00819F 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0132
      0081A0                       2181 _ak820_outline_0132:
      0081A0 F0               [24] 2182 	movx	@dptr,a
      0081A1 E0               [24] 2183 	movx	a,@dptr
      0081A2 FF               [12] 2184 	mov	r7,a
      0081A3 90 09 88         [24] 2185 	mov	dptr,#_ak820_macro_change_PARM_2
      0081A6 F0               [24] 2186 	movx	@dptr,a
      0081A7 90 09 89         [24] 2187 	mov	dptr,#_ak820_macro_change_PARM_3
      0081AA 22               [24] 2188 	ret
                                   2189 
                                   2190 	.area CSEG (CODE)
                                   2191 ; function ak820_outline_0176
      0081AB                       2192 _ak820_outline_0176:
      0081AB 90 07 FF         [24] 2193 	mov	dptr,#_add_key_to_report_PARM_2
      0081AE EF               [12] 2194 	mov	a,r7
      0081AF F0               [24] 2195 	movx	@dptr,a
      0081B0 90 0D C5         [24] 2196 	mov	dptr,#_actual_keyboard_report
      0081B3 22               [24] 2197 	ret
                                   2198 
                                   2199 	.area CSEG (CODE)
                                   2200 ; function ak820_outline_0190
      0081B4                       2201 _ak820_outline_0190:
      0081B4 8D 82            [24] 2202 	mov	dpl,r5
      0081B6 8F 83            [24] 2203 	mov	dph,r7
      0081B8 22               [24] 2204 	ret
