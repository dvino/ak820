;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module eeconfig
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _eeconfig_init_via
	.globl _via_eeprom_set_valid
	.globl _via_eeprom_is_valid
	.globl _eeprom_driver_erase
	.globl _ak820_eeprom_update_block_xdata
	.globl _eeprom_update_dword
	.globl _eeprom_update_word
	.globl _eeprom_update_byte
	.globl _eeprom_read_dword
	.globl _eeprom_read_word
	.globl _eeprom_read_byte
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _eeconfig_init_user
	.globl _eeconfig_init_kb
	.globl _eeconfig_init_quantum
	.globl _eeconfig_init
	.globl _eeconfig_disable
	.globl _eeconfig_is_enabled
	.globl _eeconfig_read_debug
	.globl _eeconfig_read_default_layer
	.globl _eeconfig_read_keymap
	.globl _eeconfig_update_kb
	.globl _eeconfig_update_user
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_eeconfig_is_enabled_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_eeconfig_init_quantum_dummy_10001_258:
	.ds 8
_eeconfig_is_enabled_is_eeprom_enabled_10000_266:
	.ds 1
_eeconfig_update_kb_val_10000_291:
	.ds 4
_eeconfig_update_user_val_10000_295:
	.ds 4
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_init_user'
;------------------------------------------------------------
;	quantum/eeconfig.c:30: __attribute__((weak)) void eeconfig_init_user(void) {
;	-----------------------------------------
;	 function eeconfig_init_user
;	-----------------------------------------
_eeconfig_init_user:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	quantum/eeconfig.c:33: eeconfig_update_user(0);
	lcall	_ak820_outline_0146
;	quantum/eeconfig.c:35: }
	ljmp	_eeconfig_update_user
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_init_kb'
;------------------------------------------------------------
;	quantum/eeconfig.c:37: __attribute__((weak)) void eeconfig_init_kb(void) {
;	-----------------------------------------
;	 function eeconfig_init_kb
;	-----------------------------------------
_eeconfig_init_kb:
;	quantum/eeconfig.c:40: eeconfig_update_kb(0);
	lcall	_ak820_outline_0146
	lcall	_eeconfig_update_kb
;	quantum/eeconfig.c:43: eeconfig_init_user();
;	quantum/eeconfig.c:44: }
	ljmp	_eeconfig_init_user
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_init_quantum'
;------------------------------------------------------------
;dummy         Allocated with name '_eeconfig_init_quantum_dummy_10001_258'
;------------------------------------------------------------
;	quantum/eeconfig.c:49: void eeconfig_init_quantum(void) {
;	-----------------------------------------
;	 function eeconfig_init_quantum
;	-----------------------------------------
_eeconfig_init_quantum:
;	quantum/eeconfig.c:51: eeprom_driver_erase();
	lcall	_eeprom_driver_erase
;	quantum/eeconfig.c:54: eeprom_update_word(EECONFIG_MAGIC, EECONFIG_MAGIC_NUMBER);
	mov	dptr,#_eeprom_update_word_PARM_2
	mov	a,#0xe6
	movx	@dptr,a
	mov	a,#0xfe
	inc	dptr
	movx	@dptr,a
	lcall	_ak820_outline_0147
	lcall	_eeprom_update_word
;	quantum/eeconfig.c:55: eeprom_update_byte(EECONFIG_DEBUG, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x0002
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:56: eeprom_update_byte(EECONFIG_DEFAULT_LAYER, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x0003
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:57: default_layer_state = 0;
	mov	dptr,#_default_layer_state
	clr	a
	movx	@dptr,a
;	quantum/eeconfig.c:59: eeprom_update_word(EECONFIG_KEYMAP, 0x1400);
	mov	dptr,#_eeprom_update_word_PARM_2
	movx	@dptr,a
	mov	a,#0x14
	inc	dptr
	movx	@dptr,a
	mov	dptr,#0x0004
	mov	b, #0x00
	lcall	_eeprom_update_word
;	quantum/eeconfig.c:60: eeprom_update_byte(EECONFIG_BACKLIGHT, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x0006
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:61: eeprom_update_byte(EECONFIG_AUDIO, 0xFF); // On by default
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,#0xff
	movx	@dptr,a
	mov	dptr,#0x0007
	mov	b, #0x00
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:62: eeprom_update_dword(EECONFIG_RGBLIGHT, 0);
	mov	dptr,#_eeprom_update_dword_PARM_2
	lcall	_ak820_outline_0050
	mov	dptr,#0x0008
	mov	b,a
	lcall	_eeprom_update_dword
;	quantum/eeconfig.c:63: eeprom_update_byte(EECONFIG_RGBLIGHT_EXTENDED, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x0024
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:64: eeprom_update_byte(EECONFIG_VELOCIKEY, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x0017
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:65: eeprom_update_byte(EECONFIG_UNICODEMODE, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x000c
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:66: eeprom_update_byte(EECONFIG_STENOMODE, 0);
	lcall	_ak820_outline_0097
	mov	dptr,#0x000d
	mov	b,a
	lcall	_eeprom_update_byte
;	quantum/eeconfig.c:67: uint64_t dummy = 0;
	mov	dptr,#_eeconfig_init_quantum_dummy_10001_258
	lcall	_ak820_outline_0050
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/eeconfig.c:69: ak820_eeprom_update_block_xdata(&dummy, EECONFIG_RGB_MATRIX, sizeof(uint64_t));
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	lcall	_ak820_outline_0082
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	mov	a,#0x08
	lcall	_ak820_outline_0120
	mov	dptr,#_eeconfig_init_quantum_dummy_10001_258
	lcall	_ak820_eeprom_update_block_xdata
;	quantum/eeconfig.c:73: eeprom_update_dword(EECONFIG_HAPTIC, 0);
	mov	dptr,#_eeprom_update_dword_PARM_2
	lcall	_ak820_outline_0050
	mov	dptr,#0x0020
	mov	b,a
	lcall	_eeprom_update_dword
;	quantum/eeconfig.c:90: via_eeprom_set_valid(false);
	mov	dpl, #0x00
	lcall	_via_eeprom_set_valid
;	quantum/eeconfig.c:91: eeconfig_init_via();
	lcall	_eeconfig_init_via
;	quantum/eeconfig.c:94: eeconfig_init_kb();
;	quantum/eeconfig.c:95: }
	ljmp	_eeconfig_init_kb
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_init'
;------------------------------------------------------------
;	quantum/eeconfig.c:101: void eeconfig_init(void) {
;	-----------------------------------------
;	 function eeconfig_init
;	-----------------------------------------
_eeconfig_init:
;	quantum/eeconfig.c:102: eeconfig_init_quantum();
;	quantum/eeconfig.c:103: }
	ljmp	_eeconfig_init_quantum
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_enable'
;------------------------------------------------------------
;	quantum/eeconfig.c:109: void eeconfig_enable(void) {
;	-----------------------------------------
;	 function eeconfig_disable
;	-----------------------------------------
_eeconfig_disable:
;	quantum/eeconfig.c:119: eeprom_driver_erase();
	lcall	_eeprom_driver_erase
;	quantum/eeconfig.c:121: eeprom_update_word(EECONFIG_MAGIC, EECONFIG_MAGIC_NUMBER_OFF);
	mov	dptr,#_eeprom_update_word_PARM_2
	mov	a,#0xff
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	lcall	_ak820_outline_0147
;	quantum/eeconfig.c:122: }
	ljmp	_eeprom_update_word
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_is_enabled'
;------------------------------------------------------------
;sloc0         Allocated with name '_eeconfig_is_enabled_sloc0_1_0'
;is_eeprom_enabled Allocated with name '_eeconfig_is_enabled_is_eeprom_enabled_10000_266'
;------------------------------------------------------------
;	quantum/eeconfig.c:128: __xdata bool eeconfig_is_enabled(void) {
;	-----------------------------------------
;	 function eeconfig_is_enabled
;	-----------------------------------------
_eeconfig_is_enabled:
;	quantum/eeconfig.c:129: __xdata bool is_eeprom_enabled = (eeprom_read_word(EECONFIG_MAGIC) == EECONFIG_MAGIC_NUMBER);
	lcall	_ak820_outline_0147
	lcall	_eeprom_read_word
	lcall	_ak820_outline_0129
	clr	a
	cjne	r6,#0xe6,00112$
	cjne	r7,#0xfe,00112$
	inc	a
00112$:
	mov	_eeconfig_is_enabled_sloc0_1_0,a
	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
	movx	@dptr,a
;	quantum/eeconfig.c:131: if (is_eeprom_enabled) {
	mov	a,_eeconfig_is_enabled_sloc0_1_0
	jz	00102$
;	quantum/eeconfig.c:132: is_eeprom_enabled = via_eeprom_is_valid();
	lcall	_via_eeprom_is_valid
	mov	a, dpl
	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
	movx	@dptr,a
00102$:
;	quantum/eeconfig.c:135: return is_eeprom_enabled;
	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
	movx	a,@dptr
;	quantum/eeconfig.c:136: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_is_disabled'
;------------------------------------------------------------
;sloc0         Allocated with name '_eeconfig_is_disabled_sloc0_1_0'
;is_eeprom_disabled Allocated with name '_eeconfig_is_disabled_is_eeprom_disabled_10000_270'
;------------------------------------------------------------
;	quantum/eeconfig.c:142: __xdata bool eeconfig_is_disabled(void) {
;	-----------------------------------------
;	 function eeconfig_read_debug
;	-----------------------------------------
_eeconfig_read_debug:
;	quantum/eeconfig.c:157: return eeprom_read_byte(EECONFIG_DEBUG);
	mov	dptr,#0x0002
	mov	b, #0x00
;	quantum/eeconfig.c:158: }
	ljmp	_eeprom_read_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_update_debug'
;------------------------------------------------------------
;val           Allocated with name '_eeconfig_update_debug_val_10000_275'
;------------------------------------------------------------
;	quantum/eeconfig.c:163: void eeconfig_update_debug(uint8_t val) {
;	-----------------------------------------
;	 function eeconfig_read_default_layer
;	-----------------------------------------
_eeconfig_read_default_layer:
;	quantum/eeconfig.c:172: return eeprom_read_byte(EECONFIG_DEFAULT_LAYER);
	mov	dptr,#0x0003
	mov	b, #0x00
;	quantum/eeconfig.c:173: }
	ljmp	_eeprom_read_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_update_default_layer'
;------------------------------------------------------------
;val           Allocated with name '_eeconfig_update_default_layer_val_10000_279'
;------------------------------------------------------------
;	quantum/eeconfig.c:178: void eeconfig_update_default_layer(uint8_t val) {
;	-----------------------------------------
;	 function eeconfig_read_keymap
;	-----------------------------------------
_eeconfig_read_keymap:
;	quantum/eeconfig.c:187: return eeprom_read_word(EECONFIG_KEYMAP);
	mov	dptr,#0x0004
	mov	b, #0x00
;	quantum/eeconfig.c:188: }
	ljmp	_eeprom_read_word
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_update_keymap'
;------------------------------------------------------------
;val           Allocated with name '_eeconfig_update_keymap_val_10000_283'
;------------------------------------------------------------
;	quantum/eeconfig.c:193: void eeconfig_update_keymap(uint16_t val) {
;	-----------------------------------------
;	 function eeconfig_update_kb
;	-----------------------------------------
_eeconfig_update_kb:
	lcall	_ak820_outline_0114
	mov	dptr,#_eeconfig_update_kb_val_10000_291
	lcall	_ak820_outline_0043
;	quantum/eeconfig.c:225: eeprom_update_dword(EECONFIG_KEYBOARD, val);
	mov	dptr,#_eeconfig_update_kb_val_10000_291
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	lcall	_ak820_outline_0013
	mov	dptr,#_eeprom_update_dword_PARM_2
	lcall	_ak820_outline_0006
	mov	dptr,#0x000f
	mov	b, #0x00
;	quantum/eeconfig.c:226: }
	ljmp	_eeprom_update_dword
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_read_user'
;------------------------------------------------------------
;	quantum/eeconfig.c:234: uint32_t eeconfig_read_user(void) {
;	-----------------------------------------
;	 function eeconfig_update_user
;	-----------------------------------------
_eeconfig_update_user:
	lcall	_ak820_outline_0114
	mov	dptr,#_eeconfig_update_user_val_10000_295
	lcall	_ak820_outline_0043
;	quantum/eeconfig.c:242: eeprom_update_dword(EECONFIG_USER, val);
	mov	dptr,#_eeconfig_update_user_val_10000_295
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	lcall	_ak820_outline_0013
	mov	dptr,#_eeprom_update_dword_PARM_2
	lcall	_ak820_outline_0006
	mov	dptr,#0x0013
	mov	b, #0x00
;	quantum/eeconfig.c:243: }
	ljmp	_eeprom_update_dword
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_read_haptic'
;------------------------------------------------------------
;	quantum/eeconfig.c:250: uint32_t eeconfig_read_haptic(void) {
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0006
	.globl _ak820_outline_0013
	.globl _ak820_outline_0043
	.globl _ak820_outline_0050
	.globl _ak820_outline_0082
	.globl _ak820_outline_0097
	.globl _ak820_outline_0114
	.globl _ak820_outline_0120
	.globl _ak820_outline_0129
	.globl _ak820_outline_0146
	.globl _ak820_outline_0147

	.area CSEG (CODE)
; function ak820_outline_0006
_ak820_outline_0006:
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0043
_ak820_outline_0043:
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0097
_ak820_outline_0097:
	mov	dptr,#_eeprom_update_byte_PARM_2
	clr	a
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0114
_ak820_outline_0114:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0146
_ak820_outline_0146:
	mov	dptr,#0x0000
	clr	a
	mov	b,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0147
_ak820_outline_0147:
	mov	dptr,#0x0000
	mov	b,#0x00
	ret
