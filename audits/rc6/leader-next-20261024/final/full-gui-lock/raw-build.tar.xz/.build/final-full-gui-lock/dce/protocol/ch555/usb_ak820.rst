                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_286:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_286:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_286:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_286:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000765                        602 _D0SetupReqCode::
      000765                        603 	.ds 1
      000766                        604 _D0SetupLen::
      000766                        605 	.ds 2
      000768                        606 _pD0Descr::
      000768                        607 	.ds 3
      00076B                        608 _D0UsbConfig::
      00076B                        609 	.ds 1
      00076C                        610 _USB_EnumStatus::
      00076C                        611 	.ds 1
      00076D                        612 _USB_SleepStatus::
      00076D                        613 	.ds 1
      00076E                        614 _MCU_Sleep_Operate::
      00076E                        615 	.ds 1
      00076F                        616 _KB_USB_UpStatus::
      00076F                        617 	.ds 1
      000770                        618 _KB_USB_SetReport::
      000770                        619 	.ds 1
      000771                        620 _ak820_boot_stage::
      000771                        621 	.ds 1
      000772                        622 _ak820_main_heartbeat::
      000772                        623 	.ds 1
      000773                        624 _raw_state:
      000773                        625 	.ds 1
      000774                        626 _raw_buffer:
      000774                        627 	.ds 32
      000794                        628 _raw_reply_without_nvm:
      000794                        629 	.ds 1
      000795                        630 _keyboard_reset:
      000795                        631 	.ds 1
      000796                        632 _input_snapshot:
      000796                        633 	.ds 46
      0007C4                        634 _control_phase:
      0007C4                        635 	.ds 1
      0007C5                        636 _output_kind:
      0007C5                        637 	.ds 1
      0007C6                        638 _output_report_id:
      0007C6                        639 	.ds 1
      0007C7                        640 _control_zlp:
      0007C7                        641 	.ds 1
      0007C8                        642 _control_pointer:
      0007C8                        643 	.ds 2
      0007CA                        644 _descriptor_select_PARM_2:
      0007CA                        645 	.ds 1
      0007CB                        646 _descriptor_select_PARM_3:
      0007CB                        647 	.ds 2
      0007CD                        648 _descriptor_select_type_10000_268:
      0007CD                        649 	.ds 1
      0007CE                        650 _control_setup_length_10000_286:
      0007CE                        651 	.ds 2
      0007D0                        652 _control_setup_offset_10000_286:
      0007D0                        653 	.ds 1
      0007D1                        654 _ak820_usb_send_PARM_2:
      0007D1                        655 	.ds 2
      0007D3                        656 _ak820_usb_send_PARM_3:
      0007D3                        657 	.ds 1
      0007D4                        658 _ak820_usb_send_endpoint_10000_422:
      0007D4                        659 	.ds 1
      0007D5                        660 _ak820_usb_send_offset_10000_423:
      0007D5                        661 	.ds 1
      0007D6                        662 _ak820_usb_try_send_PARM_2:
      0007D6                        663 	.ds 2
      0007D8                        664 _ak820_usb_try_send_PARM_3:
      0007D8                        665 	.ds 1
      0007D9                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007D9                        667 	.ds 1
      0007DA                        668 _ak820_usb_try_send_sent_10000_444:
      0007DA                        669 	.ds 1
      0007DB                        670 _ak820_usb_raw_send_PARM_2:
      0007DB                        671 	.ds 1
      0007DC                        672 _ak820_usb_raw_send_report_10000_459:
      0007DC                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005A37                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005A37 90 07 73         [24]  727 	mov	dptr,#_raw_state
      005A3A E0               [24]  728 	movx	a,@dptr
      005A3B FF               [12]  729 	mov	r7,a
      005A3C BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005A3F 80 1C            [24]  731 	sjmp	00101$
      005A41                        732 00130$:
      005A41 90 07 73         [24]  733 	mov	dptr,#_raw_state
      005A44 E0               [24]  734 	movx	a,@dptr
      005A45 FF               [12]  735 	mov	r7,a
      005A46 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005A49 80 12            [24]  737 	sjmp	00101$
      005A4B                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005A4B 90 07 73         [24]  740 	mov	dptr,#_raw_state
      005A4E E0               [24]  741 	movx	a,@dptr
      005A4F FF               [12]  742 	mov	r7,a
      005A50 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005A53 80 08            [24]  744 	sjmp	00101$
      005A55                        745 00132$:
      005A55 90 07 73         [24]  746 	mov	dptr,#_raw_state
      005A58 E0               [24]  747 	movx	a,@dptr
      005A59 FF               [12]  748 	mov	r7,a
      005A5A BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005A5D                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005A5D 90 07 73         [24]  752 	mov	dptr,#_raw_state
      005A60 74 07            [12]  753 	mov	a,#0x07
      005A62 F0               [24]  754 	movx	@dptr,a
      005A63 80 05            [24]  755 	sjmp	00103$
      005A65                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005A65 90 07 73         [24]  758 	mov	dptr,#_raw_state
      005A68 E4               [12]  759 	clr	a
      005A69 F0               [24]  760 	movx	@dptr,a
      005A6A                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005A6A 90 07 C5         [24]  763 	mov	dptr,#_output_kind
      005A6D E4               [12]  764 	clr	a
      005A6E F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005A6F 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005A70                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005A70 90 07 73         [24]  777 	mov	dptr,#_raw_state
      005A73 E0               [24]  778 	movx	a,@dptr
      005A74 FF               [12]  779 	mov	r7,a
      005A75 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005A78 90 07 73         [24]  781 	mov	dptr,#_raw_state
      005A7B 74 06            [12]  782 	mov	a,#0x06
      005A7D F0               [24]  783 	movx	@dptr,a
      005A7E 22               [24]  784 	ret
      005A7F                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005A7F 90 07 73         [24]  787 	mov	dptr,#_raw_state
      005A82 E0               [24]  788 	movx	a,@dptr
      005A83 FF               [12]  789 	mov	r7,a
      005A84 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005A87 90 07 73         [24]  791 	mov	dptr,#_raw_state
      005A8A E4               [12]  792 	clr	a
      005A8B F0               [24]  793 	movx	@dptr,a
      005A8C                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005A8C 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005A8D                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005A8D 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005A90 74 01            [12]  809 	mov	a,#0x01
      005A92 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A93 F5 82            [12]  812 	mov	dpl,a
      005A95 74 12            [12]  813 	mov	a,#0x12
      005A97 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A98 A3               [24]  816 	inc	dptr
      005A99 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005A9A A3               [24]  819 	inc	dptr
      005A9B F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005A9C 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005A9F E4               [12]  823 	clr	a
      005AA0 F0               [24]  824 	movx	@dptr,a
      005AA1 15 82            [12]  825 	dec	dpl
      005AA3 F0               [24]  826 	movx	@dptr,a
      005AA4 15 82            [12]  827 	dec	dpl
      005AA6 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005AA7 FF               [12]  830 	mov	r7,a
      005AA8                        831 00103$:
      005AA8 EF               [12]  832 	mov	a,r7
      005AA9 24 96            [12]  833 	add	a, #_input_snapshot
      005AAB F5 82            [12]  834 	mov	dpl,a
      005AAD E4               [12]  835 	clr	a
      005AAE 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005AB0 F5 83            [12]  837 	mov	dph,a
      005AB2 E4               [12]  838 	clr	a
      005AB3 F0               [24]  839 	movx	@dptr,a
      005AB4 0F               [12]  840 	inc	r7
      005AB5 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005AB8                        842 00139$:
      005AB8 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005ABA 90 07 9E         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005ABD 74 06            [12]  846 	mov	a,#0x06
      005ABF F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005AC0 90 07 BE         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005AC3 03               [12]  850 	rr	a
      005AC4 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005AC5 90 07 C1         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005AC8 04               [12]  854 	inc	a
      005AC9 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005ACA 7F 00            [12]  857 	mov	r7,#0x00
      005ACC                        858 00105$:
      005ACC 8F 06            [24]  859 	mov	ar6,r7
      005ACE 74 C0            [12]  860 	mov	a,#0xc0
      005AD0 2E               [12]  861 	add	a, r6
      005AD1 F5 82            [12]  862 	mov	dpl,a
      005AD3 74 10            [12]  863 	mov	a,#0x10
      005AD5 24 00            [12]  864 	add	a, #0x00
      005AD7 F5 83            [12]  865 	mov	dph,a
      005AD9 E4               [12]  866 	clr	a
      005ADA F0               [24]  867 	movx	@dptr,a
      005ADB 0F               [12]  868 	inc	r7
      005ADC BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005ADF                        870 00141$:
      005ADF 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005AE1 02 5A 37         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005AE4                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005AE4 90 07 73         [24]  884 	mov	dptr,#_raw_state
      005AE7 E0               [24]  885 	movx	a,@dptr
      005AE8 FF               [12]  886 	mov	r7,a
      005AE9 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005AEC 90 07 73         [24]  888 	mov	dptr,#_raw_state
      005AEF E4               [12]  889 	clr	a
      005AF0 F0               [24]  890 	movx	@dptr,a
      005AF1                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005AF1 90 07 C5         [24]  893 	mov	dptr,#_output_kind
      005AF4 E4               [12]  894 	clr	a
      005AF5 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005AF6 90 07 C4         [24]  897 	mov	dptr,#_control_phase
      005AF9 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005AFA 90 07 65         [24]  900 	mov	dptr,#_D0SetupReqCode
      005AFD 14               [12]  901 	dec	a
      005AFE F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005AFF 90 22 00         [24]  904 	mov	dptr,#0x2200
      005B02 74 CF            [12]  905 	mov	a,#0xcf
      005B04 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005B05 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005B06                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005B06 90 07 66         [24]  921 	mov	dptr,#_D0SetupLen
      005B09 E0               [24]  922 	movx	a,@dptr
      005B0A FE               [12]  923 	mov	r6,a
      005B0B A3               [24]  924 	inc	dptr
      005B0C E0               [24]  925 	movx	a,@dptr
      005B0D FF               [12]  926 	mov	r7,a
      005B0E C3               [12]  927 	clr	c
      005B0F 74 40            [12]  928 	mov	a,#0x40
      005B11 9E               [12]  929 	subb	a,r6
      005B12 E4               [12]  930 	clr	a
      005B13 9F               [12]  931 	subb	a,r7
      005B14 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005B16 7E 40            [12]  934 	mov	r6,#0x40
      005B18 80 07            [24]  935 	sjmp	00110$
      005B1A                        936 00109$:
      005B1A 90 07 66         [24]  937 	mov	dptr,#_D0SetupLen
      005B1D E0               [24]  938 	movx	a,@dptr
      005B1E FE               [12]  939 	mov	r6,a
      005B1F A3               [24]  940 	inc	dptr
      005B20 E0               [24]  941 	movx	a,@dptr
      005B21                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005B21 7F 00            [12]  944 	mov	r7,#0x00
      005B23                        945 00105$:
      005B23 C3               [12]  946 	clr	c
      005B24 EF               [12]  947 	mov	a,r7
      005B25 9E               [12]  948 	subb	a,r6
      005B26 50 2A            [24]  949 	jnc	00101$
      005B28 8F 04            [24]  950 	mov	ar4,r7
      005B2A 74 10            [12]  951 	mov	a,#0x10
      005B2C 24 00            [12]  952 	add	a, #0x00
      005B2E FD               [12]  953 	mov	r5,a
      005B2F 90 07 C8         [24]  954 	mov	dptr,#_control_pointer
      005B32 E0               [24]  955 	movx	a,@dptr
      005B33 FA               [12]  956 	mov	r2,a
      005B34 A3               [24]  957 	inc	dptr
      005B35 E0               [24]  958 	movx	a,@dptr
      005B36 FB               [12]  959 	mov	r3,a
      005B37 8A 82            [24]  960 	mov	dpl,r2
      005B39 8B 83            [24]  961 	mov	dph,r3
      005B3B E4               [12]  962 	clr	a
      005B3C 93               [24]  963 	movc	a,@a+dptr
      005B3D F9               [12]  964 	mov	r1,a
      005B3E 90 07 C8         [24]  965 	mov	dptr,#_control_pointer
      005B41 74 01            [12]  966 	mov	a,#0x01
      005B43 2A               [12]  967 	add	a, r2
      005B44 F0               [24]  968 	movx	@dptr,a
      005B45 E4               [12]  969 	clr	a
      005B46 3B               [12]  970 	addc	a, r3
      005B47 A3               [24]  971 	inc	dptr
      005B48 F0               [24]  972 	movx	@dptr,a
      005B49 8C 82            [24]  973 	mov	dpl,r4
      005B4B 8D 83            [24]  974 	mov	dph,r5
      005B4D E9               [12]  975 	mov	a,r1
      005B4E F0               [24]  976 	movx	@dptr,a
      005B4F 0F               [12]  977 	inc	r7
      005B50 80 D1            [24]  978 	sjmp	00105$
      005B52                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005B52 8E 05            [24]  981 	mov	ar5,r6
      005B54 7F 00            [12]  982 	mov	r7,#0x00
      005B56 90 07 66         [24]  983 	mov	dptr,#_D0SetupLen
      005B59 E0               [24]  984 	movx	a,@dptr
      005B5A FB               [12]  985 	mov	r3,a
      005B5B A3               [24]  986 	inc	dptr
      005B5C E0               [24]  987 	movx	a,@dptr
      005B5D FC               [12]  988 	mov	r4,a
      005B5E EB               [12]  989 	mov	a,r3
      005B5F C3               [12]  990 	clr	c
      005B60 9D               [12]  991 	subb	a,r5
      005B61 FB               [12]  992 	mov	r3,a
      005B62 EC               [12]  993 	mov	a,r4
      005B63 9F               [12]  994 	subb	a,r7
      005B64 FC               [12]  995 	mov	r4,a
      005B65 90 07 66         [24]  996 	mov	dptr,#_D0SetupLen
      005B68 EB               [12]  997 	mov	a,r3
      005B69 F0               [24]  998 	movx	@dptr,a
      005B6A EC               [12]  999 	mov	a,r4
      005B6B A3               [24] 1000 	inc	dptr
      005B6C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005B6D EE               [12] 1003 	mov	a,r6
      005B6E 70 05            [24] 1004 	jnz	00103$
      005B70 90 07 C7         [24] 1005 	mov	dptr,#_control_zlp
      005B73 E4               [12] 1006 	clr	a
      005B74 F0               [24] 1007 	movx	@dptr,a
      005B75                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005B75 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005B78 EE               [12] 1011 	mov	a,r6
      005B79 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005B7A 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005B7D E0               [24] 1015 	movx	a,@dptr
      005B7E 54 C0            [12] 1016 	anl	a,#0xc0
      005B80 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005B81 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005B82                       1032 _descriptor_select:
      005B82 E5 82            [12] 1033 	mov	a,dpl
      005B84 90 07 CD         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005B87 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005B88 E0               [24] 1037 	movx	a,@dptr
      005B89 FF               [12] 1038 	mov	r7,a
      005B8A BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005B8D 90 07 CA         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005B90 E0               [24] 1041 	movx	a,@dptr
      005B91 70 1A            [24] 1042 	jnz	00102$
      005B93 90 07 CB         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005B96 E0               [24] 1044 	movx	a,@dptr
      005B97 F5 F0            [12] 1045 	mov	b,a
      005B99 A3               [24] 1046 	inc	dptr
      005B9A E0               [24] 1047 	movx	a,@dptr
      005B9B 45 F0            [12] 1048 	orl	a,b
      005B9D 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005B9F 90 07 C8         [24] 1051 	mov	dptr,#_control_pointer
      005BA2 74 66            [12] 1052 	mov	a,#_DeviceDescriptor
      005BA4 F0               [24] 1053 	movx	@dptr,a
      005BA5 74 C0            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005BA7 A3               [24] 1055 	inc	dptr
      005BA8 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005BA9 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005BAC 22               [24] 1059 	ret
      005BAD                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005BAD 90 07 CD         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005BB0 E0               [24] 1063 	movx	a,@dptr
      005BB1 FF               [12] 1064 	mov	r7,a
      005BB2 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005BB5 90 07 CA         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005BB8 E0               [24] 1067 	movx	a,@dptr
      005BB9 70 1A            [24] 1068 	jnz	00106$
      005BBB 90 07 CB         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005BBE E0               [24] 1070 	movx	a,@dptr
      005BBF F5 F0            [12] 1071 	mov	b,a
      005BC1 A3               [24] 1072 	inc	dptr
      005BC2 E0               [24] 1073 	movx	a,@dptr
      005BC3 45 F0            [12] 1074 	orl	a,b
      005BC5 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005BC7 90 07 C8         [24] 1077 	mov	dptr,#_control_pointer
      005BCA 74 78            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005BCC F0               [24] 1079 	movx	@dptr,a
      005BCD 74 C0            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005BCF A3               [24] 1081 	inc	dptr
      005BD0 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005BD1 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005BD4 22               [24] 1085 	ret
      005BD5                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005BD5 90 07 CD         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005BD8 E0               [24] 1089 	movx	a,@dptr
      005BD9 FF               [12] 1090 	mov	r7,a
      005BDA BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005BDD 80 03            [24] 1092 	sjmp	00239$
      005BDF                       1093 00238$:
      005BDF 02 5C 79         [24] 1094 	ljmp	00119$
      005BE2                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005BE2 90 07 CB         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005BE5 E0               [24] 1098 	movx	a,@dptr
      005BE6 FD               [12] 1099 	mov	r5,a
      005BE7 A3               [24] 1100 	inc	dptr
      005BE8 E0               [24] 1101 	movx	a,@dptr
      005BE9 FE               [12] 1102 	mov	r6,a
      005BEA 90 07 CB         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005BED E0               [24] 1104 	movx	a,@dptr
      005BEE F5 F0            [12] 1105 	mov	b,a
      005BF0 A3               [24] 1106 	inc	dptr
      005BF1 E0               [24] 1107 	movx	a,@dptr
      005BF2 45 F0            [12] 1108 	orl	a,b
      005BF4 60 0C            [24] 1109 	jz	00110$
      005BF6 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005BF9 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005BFC 80 04            [24] 1112 	sjmp	00110$
      005BFE                       1113 00241$:
      005BFE 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005C01 22               [24] 1115 	ret
      005C02                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005C02 90 07 CA         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005C05 E0               [24] 1119 	movx	a,@dptr
      005C06 FE               [12] 1120 	mov  r6,a
      005C07 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005C09 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005C0B EE               [12] 1124 	mov	a,r6
      005C0C 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005C0D 90 5C 11         [24] 1127 	mov	dptr,#00243$
      005C10 73               [24] 1128 	jmp	@a+dptr
      005C11                       1129 00243$:
      005C11 80 06            [24] 1130 	sjmp	00112$
      005C13 80 1B            [24] 1131 	sjmp	00113$
      005C15 80 30            [24] 1132 	sjmp	00114$
      005C17 80 45            [24] 1133 	sjmp	00115$
      005C19                       1134 00112$:
      005C19 90 07 C8         [24] 1135 	mov	dptr,#_control_pointer
      005C1C 74 CC            [12] 1136 	mov	a,#_LanguageString
      005C1E F0               [24] 1137 	movx	@dptr,a
      005C1F 74 C0            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005C21 A3               [24] 1139 	inc	dptr
      005C22 F0               [24] 1140 	movx	@dptr,a
      005C23 90 C0 CC         [24] 1141 	mov	dptr,#_LanguageString
      005C26 E4               [12] 1142 	clr	a
      005C27 93               [24] 1143 	movc	a,@a+dptr
      005C28 FE               [12] 1144 	mov	r6,a
      005C29 7D 00            [12] 1145 	mov	r5,#0x00
      005C2B 8E 82            [24] 1146 	mov	dpl, r6
      005C2D 8D 83            [24] 1147 	mov	dph, r5
      005C2F 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005C30                       1150 00113$:
      005C30 90 07 C8         [24] 1151 	mov	dptr,#_control_pointer
      005C33 74 D0            [12] 1152 	mov	a,#_ManufacturerString
      005C35 F0               [24] 1153 	movx	@dptr,a
      005C36 74 C0            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005C38 A3               [24] 1155 	inc	dptr
      005C39 F0               [24] 1156 	movx	@dptr,a
      005C3A 90 C0 D0         [24] 1157 	mov	dptr,#_ManufacturerString
      005C3D E4               [12] 1158 	clr	a
      005C3E 93               [24] 1159 	movc	a,@a+dptr
      005C3F FE               [12] 1160 	mov	r6,a
      005C40 7D 00            [12] 1161 	mov	r5,#0x00
      005C42 8E 82            [24] 1162 	mov	dpl, r6
      005C44 8D 83            [24] 1163 	mov	dph, r5
      005C46 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005C47                       1166 00114$:
      005C47 90 07 C8         [24] 1167 	mov	dptr,#_control_pointer
      005C4A 74 DE            [12] 1168 	mov	a,#_ProductString
      005C4C F0               [24] 1169 	movx	@dptr,a
      005C4D 74 C0            [12] 1170 	mov	a,#(_ProductString >> 8)
      005C4F A3               [24] 1171 	inc	dptr
      005C50 F0               [24] 1172 	movx	@dptr,a
      005C51 90 C0 DE         [24] 1173 	mov	dptr,#_ProductString
      005C54 E4               [12] 1174 	clr	a
      005C55 93               [24] 1175 	movc	a,@a+dptr
      005C56 FE               [12] 1176 	mov	r6,a
      005C57 7D 00            [12] 1177 	mov	r5,#0x00
      005C59 8E 82            [24] 1178 	mov	dpl, r6
      005C5B 8D 83            [24] 1179 	mov	dph, r5
      005C5D 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005C5E                       1182 00115$:
      005C5E 90 07 C8         [24] 1183 	mov	dptr,#_control_pointer
      005C61 74 16            [12] 1184 	mov	a,#_SerialNumberString
      005C63 F0               [24] 1185 	movx	@dptr,a
      005C64 74 C1            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005C66 A3               [24] 1187 	inc	dptr
      005C67 F0               [24] 1188 	movx	@dptr,a
      005C68 90 C1 16         [24] 1189 	mov	dptr,#_SerialNumberString
      005C6B E4               [12] 1190 	clr	a
      005C6C 93               [24] 1191 	movc	a,@a+dptr
      005C6D FE               [12] 1192 	mov	r6,a
      005C6E 7D 00            [12] 1193 	mov	r5,#0x00
      005C70 8E 82            [24] 1194 	mov	dpl, r6
      005C72 8D 83            [24] 1195 	mov	dph, r5
      005C74 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005C75                       1198 00116$:
      005C75 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005C78 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005C79                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005C79 90 07 CA         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005C7C E0               [24] 1205 	movx	a,@dptr
      005C7D 70 11            [24] 1206 	jnz	00120$
      005C7F 90 07 CB         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005C82 E0               [24] 1208 	movx	a,@dptr
      005C83 FD               [12] 1209 	mov	r5,a
      005C84 A3               [24] 1210 	inc	dptr
      005C85 E0               [24] 1211 	movx	a,@dptr
      005C86 FE               [12] 1212 	mov	r6,a
      005C87 C3               [12] 1213 	clr	c
      005C88 ED               [12] 1214 	mov	a,r5
      005C89 94 03            [12] 1215 	subb	a,#0x03
      005C8B EE               [12] 1216 	mov	a,r6
      005C8C 94 00            [12] 1217 	subb	a,#0x00
      005C8E 40 04            [24] 1218 	jc	00121$
      005C90                       1219 00120$:
      005C90 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005C93 22               [24] 1221 	ret
      005C94                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005C94 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005C97 80 03            [24] 1225 	sjmp	00127$
      005C99                       1226 00246$:
      005C99 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005C9C                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005C9C ED               [12] 1230 	mov	a,r5
      005C9D 75 F0 04         [24] 1231 	mov	b,#0x04
      005CA0 A4               [48] 1232 	mul	ab
      005CA1 24 EF            [12] 1233 	add	a, #_interface_descriptors
      005CA3 FE               [12] 1234 	mov	r6,a
      005CA4 74 B9            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005CA6 35 F0            [12] 1236 	addc	a, b
      005CA8 FF               [12] 1237 	mov	r7,a
      005CA9 8E 82            [24] 1238 	mov	dpl,r6
      005CAB 8F 83            [24] 1239 	mov	dph,r7
      005CAD A3               [24] 1240 	inc	dptr
      005CAE A3               [24] 1241 	inc	dptr
      005CAF E4               [12] 1242 	clr	a
      005CB0 93               [24] 1243 	movc	a,@a+dptr
      005CB1 FC               [12] 1244 	mov	r4,a
      005CB2 A3               [24] 1245 	inc	dptr
      005CB3 E4               [12] 1246 	clr	a
      005CB4 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005CB5 FD               [12] 1249 	mov	r5,a
      005CB6 4C               [12] 1250 	orl	a,r4
      005CB7 70 04            [24] 1251 	jnz	00124$
      005CB9 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005CBC 22               [24] 1253 	ret
      005CBD                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005CBD 90 07 CD         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005CC0 E0               [24] 1257 	movx	a,@dptr
      005CC1 FB               [12] 1258 	mov	r3,a
      005CC2 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005CC5 8E 82            [24] 1261 	mov	dpl,r6
      005CC7 8F 83            [24] 1262 	mov	dph,r7
      005CC9 E4               [12] 1263 	clr	a
      005CCA 93               [24] 1264 	movc	a,@a+dptr
      005CCB FE               [12] 1265 	mov	r6,a
      005CCC A3               [24] 1266 	inc	dptr
      005CCD E4               [12] 1267 	clr	a
      005CCE 93               [24] 1268 	movc	a,@a+dptr
      005CCF FF               [12] 1269 	mov	r7,a
      005CD0 90 07 C8         [24] 1270 	mov	dptr,#_control_pointer
      005CD3 EE               [12] 1271 	mov	a,r6
      005CD4 F0               [24] 1272 	movx	@dptr,a
      005CD5 EF               [12] 1273 	mov	a,r7
      005CD6 A3               [24] 1274 	inc	dptr
      005CD7 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005CD8 74 07            [12] 1277 	mov	a,#0x07
      005CDA 2C               [12] 1278 	add	a, r4
      005CDB F5 82            [12] 1279 	mov	dpl,a
      005CDD E4               [12] 1280 	clr	a
      005CDE 3D               [12] 1281 	addc	a, r5
      005CDF F5 83            [12] 1282 	mov	dph,a
      005CE1 E4               [12] 1283 	clr	a
      005CE2 93               [24] 1284 	movc	a,@a+dptr
      005CE3 FE               [12] 1285 	mov	r6,a
      005CE4 A3               [24] 1286 	inc	dptr
      005CE5 E4               [12] 1287 	clr	a
      005CE6 93               [24] 1288 	movc	a,@a+dptr
      005CE7 FF               [12] 1289 	mov	r7,a
      005CE8 8E 82            [24] 1290 	mov	dpl, r6
      005CEA 8F 83            [24] 1291 	mov	dph, r7
      005CEC 22               [24] 1292 	ret
      005CED                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005CED 90 07 C8         [24] 1295 	mov	dptr,#_control_pointer
      005CF0 EC               [12] 1296 	mov	a,r4
      005CF1 F0               [24] 1297 	movx	@dptr,a
      005CF2 ED               [12] 1298 	mov	a,r5
      005CF3 A3               [24] 1299 	inc	dptr
      005CF4 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005CF5 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005CF8 22               [24] 1303 	ret
      005CF9                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005CF9 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005CFC 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005CFD                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005CFD 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005D00 E0               [24] 1331 	movx	a,@dptr
      005D01 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005D02 A3               [24] 1334 	inc	dptr
      005D03 A3               [24] 1335 	inc	dptr
      005D04 E0               [24] 1336 	movx	a,@dptr
      005D05 FE               [12] 1337 	mov	r6,a
      005D06 A3               [24] 1338 	inc	dptr
      005D07 E0               [24] 1339 	movx	a,@dptr
      005D08 FC               [12] 1340 	mov	r4,a
      005D09 7D 00            [12] 1341 	mov	r5,#0x00
      005D0B 8E 03            [24] 1342 	mov	ar3,r6
      005D0D 7E 00            [12] 1343 	mov	r6,#0x00
      005D0F ED               [12] 1344 	mov	a,r5
      005D10 4B               [12] 1345 	orl	a,r3
      005D11 FD               [12] 1346 	mov	r5,a
      005D12 EC               [12] 1347 	mov	a,r4
      005D13 4E               [12] 1348 	orl	a,r6
      005D14 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005D15 A3               [24] 1351 	inc	dptr
      005D16 E0               [24] 1352 	movx	a,@dptr
      005D17 FC               [12] 1353 	mov	r4,a
      005D18 A3               [24] 1354 	inc	dptr
      005D19 E0               [24] 1355 	movx	a,@dptr
      005D1A FA               [12] 1356 	mov	r2,a
      005D1B 7B 00            [12] 1357 	mov	r3,#0x00
      005D1D 8C 01            [24] 1358 	mov	ar1,r4
      005D1F 7C 00            [12] 1359 	mov	r4,#0x00
      005D21 EB               [12] 1360 	mov	a,r3
      005D22 49               [12] 1361 	orl	a,r1
      005D23 FB               [12] 1362 	mov	r3,a
      005D24 EA               [12] 1363 	mov	a,r2
      005D25 4C               [12] 1364 	orl	a,r4
      005D26 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005D27 C3               [12] 1367 	clr	c
      005D28 EB               [12] 1368 	mov	a,r3
      005D29 94 03            [12] 1369 	subb	a,#0x03
      005D2B EC               [12] 1370 	mov	a,r4
      005D2C 94 00            [12] 1371 	subb	a,#0x00
      005D2E 92 16            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005D30 EB               [12] 1374 	mov	a,r3
      005D31 4C               [12] 1375 	orl	a,r4
      005D32 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005D35                       1377 01201$:
      005D35 92 17            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005D37 ED               [12] 1380 	mov	a,r5
      005D38 4E               [12] 1381 	orl	a,r6
      005D39 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005D3C                       1383 01202$:
                                   1384 ;	assignBit
      005D3C 92 1A            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005D3E 92 18            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005D40 90 07 D0         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005D43 E4               [12] 1389 	clr	a
      005D44 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005D45 90 07 73         [24] 1392 	mov	dptr,#_raw_state
      005D48 E0               [24] 1393 	movx	a,@dptr
      005D49 FA               [12] 1394 	mov	r2,a
      005D4A BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005D4D 90 07 73         [24] 1396 	mov	dptr,#_raw_state
      005D50 E4               [12] 1397 	clr	a
      005D51 F0               [24] 1398 	movx	@dptr,a
      005D52                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005D52 C0 07            [24] 1401 	push	ar7
      005D54 90 07 C5         [24] 1402 	mov	dptr,#_output_kind
      005D57 E4               [12] 1403 	clr	a
      005D58 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005D59 90 07 C4         [24] 1406 	mov	dptr,#_control_phase
      005D5C F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005D5D 90 07 C7         [24] 1409 	mov	dptr,#_control_zlp
      005D60 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005D61 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005D64 E0               [24] 1413 	movx	a,@dptr
      005D65 90 07 65         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005D68 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005D69 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005D6C E0               [24] 1418 	movx	a,@dptr
      005D6D FA               [12] 1419 	mov	r2,a
      005D6E A3               [24] 1420 	inc	dptr
      005D6F E0               [24] 1421 	movx	a,@dptr
      005D70 F9               [12] 1422 	mov	r1,a
      005D71 78 00            [12] 1423 	mov	r0,#0x00
      005D73 7F 00            [12] 1424 	mov	r7,#0x00
      005D75 90 07 66         [24] 1425 	mov	dptr,#_D0SetupLen
      005D78 E8               [12] 1426 	mov	a,r0
      005D79 4A               [12] 1427 	orl	a,r2
      005D7A F0               [24] 1428 	movx	@dptr,a
      005D7B E9               [12] 1429 	mov	a,r1
      005D7C 4F               [12] 1430 	orl	a,r7
      005D7D A3               [24] 1431 	inc	dptr
      005D7E F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      005D7F 90 07 66         [24] 1434 	mov	dptr,#_D0SetupLen
      005D82 E0               [24] 1435 	movx	a,@dptr
      005D83 FA               [12] 1436 	mov	r2,a
      005D84 A3               [24] 1437 	inc	dptr
      005D85 E0               [24] 1438 	movx	a,@dptr
      005D86 4A               [12] 1439 	orl	a,r2
      005D87 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005D8A                       1441 01205$:
      005D8A 92 19            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005D8C 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005D8F 74 C2            [12] 1445 	mov	a,#0xc2
      005D91 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      005D92 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005D95 E4               [12] 1449 	clr	a
      005D96 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      005D97 90 07 65         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005D9A E0               [24] 1453 	movx	a,@dptr
      005D9B F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005D9D C3               [12] 1455 	clr	c
      005D9E 74 0B            [12] 1456 	mov	a,#0x0b
      005DA0 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005DA2 D0 07            [24] 1458 	pop	ar7
      005DA4 50 03            [24] 1459 	jnc	01206$
      005DA6 02 5A E4         [24] 1460 	ljmp	_control_stall
      005DA9                       1461 01206$:
                                   1462 ;	free result
      005DA9 E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005DAB F5 F0            [12] 1464 	mov	b,a
      005DAD 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005DAF 83               [24] 1466 	movc	a,@a+pc
      005DB0 F5 82            [12] 1467 	mov	dpl,a
      005DB2 E5 F0            [12] 1468 	mov	a,b
      005DB4 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005DB6 83               [24] 1470 	movc	a,@a+pc
      005DB7 F5 83            [12] 1471 	mov	dph,a
      005DB9 E4               [12] 1472 	clr	a
      005DBA 73               [24] 1473 	jmp	@a+dptr
      005DBB                       1474 01207$:
      005DBB 63                    1475 	.db	00188$
      005DBC 09                    1476 	.db	00205$
      005DBD 4C                    1477 	.db	00282$
      005DBE 09                    1478 	.db	00205$
      005DBF 90                    1479 	.db	00290$
      005DC0 8D                    1480 	.db	00116$
      005DC1 D3                    1481 	.db	00103$
      005DC2 90                    1482 	.db	00290$
      005DC3 92                    1483 	.db	00150$
      005DC4 B6                    1484 	.db	00123$
      005DC5 C2                    1485 	.db	00157$
      005DC6 15                    1486 	.db	00173$
      005DC7                       1487 01208$:
      005DC7 60                    1488 	.db	00188$>>8
      005DC8 61                    1489 	.db	00205$>>8
      005DC9 64                    1490 	.db	00282$>>8
      005DCA 61                    1491 	.db	00205$>>8
      005DCB 64                    1492 	.db	00290$>>8
      005DCC 5E                    1493 	.db	00116$>>8
      005DCD 5D                    1494 	.db	00103$>>8
      005DCE 64                    1495 	.db	00290$>>8
      005DCF 5F                    1496 	.db	00150$>>8
      005DD0 5E                    1497 	.db	00123$>>8
      005DD1 5F                    1498 	.db	00157$>>8
      005DD2 60                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      005DD3                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      005DD3 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005DD6 80 08            [24] 1504 	sjmp	00112$
      005DD8                       1505 01209$:
      005DD8 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005DDB 80 03            [24] 1507 	sjmp	01211$
      005DDD                       1508 01210$:
      005DDD 02 5A E4         [24] 1509 	ljmp	_control_stall
      005DE0                       1510 01211$:
      005DE0                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005DE0 8E 01            [24] 1513 	mov	ar1,r6
      005DE2 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005DE5 80 09            [24] 1515 	sjmp	00301$
      005DE7                       1516 01212$:
      005DE7 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005DEA 80 04            [24] 1518 	sjmp	00301$
      005DEC                       1519 01213$:
                                   1520 ;	assignBit
      005DEC C2 1B            [12] 1521 	clr	_control_setup_sloc2_1_0
      005DEE 80 02            [24] 1522 	sjmp	00302$
      005DF0                       1523 00301$:
                                   1524 ;	assignBit
      005DF0 D2 1B            [12] 1525 	setb	_control_setup_sloc2_1_0
      005DF2                       1526 00302$:
      005DF2 E4               [12] 1527 	clr	a
      005DF3 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005DF6 04               [12] 1529 	inc	a
      005DF7                       1530 01214$:
      005DF7 FA               [12] 1531 	mov	r2,a
      005DF8 A2 1B            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005DFA E4               [12] 1533 	clr	a
      005DFB 33               [12] 1534 	rlc	a
      005DFC B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005DFF 80 03            [24] 1536 	sjmp	00105$
      005E01                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      005E01 02 5A E4         [24] 1539 	ljmp	_control_stall
      005E04                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      005E04 8E 02            [24] 1542 	mov	ar2,r6
      005E06 90 07 CA         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005E09 ED               [12] 1544 	mov	a,r5
      005E0A F0               [24] 1545 	movx	@dptr,a
      005E0B 90 07 CB         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005E0E EB               [12] 1547 	mov	a,r3
      005E0F F0               [24] 1548 	movx	@dptr,a
      005E10 EC               [12] 1549 	mov	a,r4
      005E11 A3               [24] 1550 	inc	dptr
      005E12 F0               [24] 1551 	movx	@dptr,a
      005E13 8A 82            [24] 1552 	mov	dpl, r2
      005E15 12 5B 82         [24] 1553 	lcall	_descriptor_select
      005E18 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005E1B 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      005E1E E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005E20 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005E22 70 03            [24] 1559 	jnz	00107$
      005E24 02 5A E4         [24] 1560 	ljmp	_control_stall
      005E27                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005E27 90 07 66         [24] 1563 	mov	dptr,#_D0SetupLen
      005E2A E0               [24] 1564 	movx	a,@dptr
      005E2B F8               [12] 1565 	mov	r0,a
      005E2C A3               [24] 1566 	inc	dptr
      005E2D E0               [24] 1567 	movx	a,@dptr
      005E2E FA               [12] 1568 	mov	r2,a
      005E2F C3               [12] 1569 	clr	c
      005E30 E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005E32 98               [12] 1571 	subb	a,r0
      005E33 E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E35 9A               [12] 1573 	subb	a,r2
      005E36 50 06            [24] 1574 	jnc	00303$
      005E38 E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005E3A 54 3F            [12] 1576 	anl	a,#0x3f
      005E3C 60 04            [24] 1577 	jz	00304$
      005E3E                       1578 00303$:
                                   1579 ;	assignBit
      005E3E C2 1B            [12] 1580 	clr	_control_setup_sloc2_1_0
      005E40 80 02            [24] 1581 	sjmp	00305$
      005E42                       1582 00304$:
                                   1583 ;	assignBit
      005E42 D2 1B            [12] 1584 	setb	_control_setup_sloc2_1_0
      005E44                       1585 00305$:
      005E44 90 07 C7         [24] 1586 	mov	dptr,#_control_zlp
      005E47 A2 1B            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005E49 E4               [12] 1588 	clr	a
      005E4A 33               [12] 1589 	rlc	a
      005E4B F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      005E4C 90 07 66         [24] 1592 	mov	dptr,#_D0SetupLen
      005E4F E0               [24] 1593 	movx	a,@dptr
      005E50 F9               [12] 1594 	mov	r1,a
      005E51 A3               [24] 1595 	inc	dptr
      005E52 E0               [24] 1596 	movx	a,@dptr
      005E53 FA               [12] 1597 	mov	r2,a
      005E54 C3               [12] 1598 	clr	c
      005E55 E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005E57 99               [12] 1600 	subb	a,r1
      005E58 E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E5A 9A               [12] 1602 	subb	a,r2
      005E5B 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005E5D 90 07 66         [24] 1605 	mov	dptr,#_D0SetupLen
      005E60 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005E62 F0               [24] 1607 	movx	@dptr,a
      005E63 E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E65 A3               [24] 1609 	inc	dptr
      005E66 F0               [24] 1610 	movx	@dptr,a
      005E67                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005E67 90 07 66         [24] 1613 	mov	dptr,#_D0SetupLen
      005E6A E0               [24] 1614 	movx	a,@dptr
      005E6B F9               [12] 1615 	mov	r1,a
      005E6C A3               [24] 1616 	inc	dptr
      005E6D E0               [24] 1617 	movx	a,@dptr
      005E6E 49               [12] 1618 	orl	a,r1
      005E6F 60 04            [24] 1619 	jz	00306$
      005E71 7A 01            [12] 1620 	mov	r2,#0x01
      005E73 80 02            [24] 1621 	sjmp	00307$
      005E75                       1622 00306$:
      005E75 7A 02            [12] 1623 	mov	r2,#0x02
      005E77                       1624 00307$:
      005E77 90 07 C4         [24] 1625 	mov	dptr,#_control_phase
      005E7A EA               [12] 1626 	mov	a,r2
      005E7B F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      005E7C 90 07 66         [24] 1629 	mov	dptr,#_D0SetupLen
      005E7F E0               [24] 1630 	movx	a,@dptr
      005E80 F9               [12] 1631 	mov	r1,a
      005E81 A3               [24] 1632 	inc	dptr
      005E82 E0               [24] 1633 	movx	a,@dptr
      005E83 49               [12] 1634 	orl	a,r1
      005E84 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      005E86 02 5B 06         [24] 1637 	ljmp	_control_next
      005E89                       1638 00111$:
      005E89 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      005E8A 02 5A E4         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      005E8D                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005E8D EF               [12] 1645 	mov	a,r7
      005E8E 70 23            [24] 1646 	jnz	00118$
      005E90 30 17 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      005E93 30 19 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      005E96 8D 01            [24] 1649 	mov	ar1,r5
      005E98 8E 02            [24] 1650 	mov	ar2,r6
      005E9A C3               [12] 1651 	clr	c
      005E9B 74 7F            [12] 1652 	mov	a,#0x7f
      005E9D 99               [12] 1653 	subb	a,r1
      005E9E E4               [12] 1654 	clr	a
      005E9F 9A               [12] 1655 	subb	a,r2
      005EA0 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      005EA2 90 07 66         [24] 1659 	mov	dptr,#_D0SetupLen
      005EA5 ED               [12] 1660 	mov	a,r5
      005EA6 F0               [24] 1661 	movx	@dptr,a
      005EA7 EE               [12] 1662 	mov	a,r6
      005EA8 A3               [24] 1663 	inc	dptr
      005EA9 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      005EAA 90 07 C4         [24] 1666 	mov	dptr,#_control_phase
      005EAD 74 03            [12] 1667 	mov	a,#0x03
      005EAF F0               [24] 1668 	movx	@dptr,a
      005EB0 02 64 93         [24] 1669 	ljmp	00291$
      005EB3                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      005EB3 02 5A E4         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005EB6                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005EB6 EF               [12] 1676 	mov	a,r7
      005EB7 70 3C            [24] 1677 	jnz	00145$
      005EB9 30 17 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      005EBC 30 19 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      005EBF 8D 01            [24] 1680 	mov	ar1,r5
      005EC1 8E 02            [24] 1681 	mov	ar2,r6
      005EC3 C3               [12] 1682 	clr	c
      005EC4 74 01            [12] 1683 	mov	a,#0x01
      005EC6 99               [12] 1684 	subb	a,r1
      005EC7 E4               [12] 1685 	clr	a
      005EC8 9A               [12] 1686 	subb	a,r2
      005EC9 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      005ECB C0 06            [24] 1690 	push	ar6
      005ECD C0 05            [24] 1691 	push	ar5
      005ECF 12 5A 8D         [24] 1692 	lcall	_endpoints_reset
      005ED2 D0 05            [24] 1693 	pop	ar5
      005ED4 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      005ED6 90 07 6B         [24] 1696 	mov	dptr,#_D0UsbConfig
      005ED9 ED               [12] 1697 	mov	a,r5
      005EDA F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      005EDB A2 1A            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005EDD B3               [12] 1701 	cpl	c
      005EDE 92 1B            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005EE0 90 07 6C         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005EE3 E4               [12] 1704 	clr	a
      005EE4 33               [12] 1705 	rlc	a
      005EE5 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      005EE6 90 07 95         [24] 1708 	mov	dptr,#_keyboard_reset
      005EE9 74 01            [12] 1709 	mov	a,#0x01
      005EEB F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      005EEC 90 07 C4         [24] 1712 	mov	dptr,#_control_phase
      005EEF 74 03            [12] 1713 	mov	a,#0x03
      005EF1 F0               [24] 1714 	movx	@dptr,a
      005EF2 02 64 93         [24] 1715 	ljmp	00291$
      005EF5                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      005EF5 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005EF8 80 03            [24] 1719 	sjmp	01232$
      005EFA                       1720 01231$:
      005EFA 02 5A E4         [24] 1721 	ljmp	_control_stall
      005EFD                       1722 01232$:
      005EFD 90 07 6B         [24] 1723 	mov	dptr,#_D0UsbConfig
      005F00 E0               [24] 1724 	movx	a,@dptr
      005F01 70 03            [24] 1725 	jnz	01233$
      005F03 02 5A E4         [24] 1726 	ljmp	_control_stall
      005F06                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005F06 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005F09 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005F0C 8D 01            [24] 1731 	mov	ar1,r5
      005F0E 8E 02            [24] 1732 	mov	ar2,r6
      005F10 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005F13 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005F16 90 07 66         [24] 1735 	mov	dptr,#_D0SetupLen
      005F19 E0               [24] 1736 	movx	a,@dptr
      005F1A F9               [12] 1737 	mov	r1,a
      005F1B A3               [24] 1738 	inc	dptr
      005F1C E0               [24] 1739 	movx	a,@dptr
      005F1D FA               [12] 1740 	mov	r2,a
      005F1E B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      005F21 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      005F24 90 07 73         [24] 1743 	mov	dptr,#_raw_state
      005F27 E0               [24] 1744 	movx	a,@dptr
      005F28 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      005F2A 90 07 73         [24] 1747 	mov	dptr,#_raw_state
      005F2D 74 01            [12] 1748 	mov	a,#0x01
      005F2F F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      005F30 90 07 C5         [24] 1751 	mov	dptr,#_output_kind
      005F33 F0               [24] 1752 	movx	@dptr,a
      005F34 80 52            [24] 1753 	sjmp	00136$
      005F36                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005F36 EB               [12] 1756 	mov	a,r3
      005F37 4C               [12] 1757 	orl	a,r4
      005F38 70 20            [24] 1758 	jnz	00130$
      005F3A 8D 01            [24] 1759 	mov	ar1,r5
      005F3C 8E 02            [24] 1760 	mov	ar2,r6
      005F3E B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      005F41 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      005F44 90 07 66         [24] 1763 	mov	dptr,#_D0SetupLen
      005F47 E0               [24] 1764 	movx	a,@dptr
      005F48 F9               [12] 1765 	mov	r1,a
      005F49 A3               [24] 1766 	inc	dptr
      005F4A E0               [24] 1767 	movx	a,@dptr
      005F4B FA               [12] 1768 	mov	r2,a
      005F4C B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      005F4F BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      005F52 90 07 C5         [24] 1772 	mov	dptr,#_output_kind
      005F55 74 02            [12] 1773 	mov	a,#0x02
      005F57 F0               [24] 1774 	movx	@dptr,a
      005F58 80 2E            [24] 1775 	sjmp	00136$
      005F5A                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005F5A BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      005F5D BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      005F60 8D 01            [24] 1780 	mov	ar1,r5
      005F62 8E 02            [24] 1781 	mov	ar2,r6
      005F64 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      005F67 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      005F6A 90 07 66         [24] 1784 	mov	dptr,#_D0SetupLen
      005F6D E0               [24] 1785 	movx	a,@dptr
      005F6E F9               [12] 1786 	mov	r1,a
      005F6F A3               [24] 1787 	inc	dptr
      005F70 E0               [24] 1788 	movx	a,@dptr
      005F71 FA               [12] 1789 	mov	r2,a
      005F72 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      005F75 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      005F78 90 07 C5         [24] 1793 	mov	dptr,#_output_kind
      005F7B 74 03            [12] 1794 	mov	a,#0x03
      005F7D F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      005F7E 90 07 C6         [24] 1797 	mov	dptr,#_output_report_id
      005F81 23               [12] 1798 	rl	a
      005F82 F0               [24] 1799 	movx	@dptr,a
      005F83 80 03            [24] 1800 	sjmp	00136$
      005F85                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      005F85 02 5A E4         [24] 1803 	ljmp	_control_stall
      005F88                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      005F88 90 07 C4         [24] 1806 	mov	dptr,#_control_phase
      005F8B 74 04            [12] 1807 	mov	a,#0x04
      005F8D F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      005F8E 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      005F8F 02 5A E4         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      005F92                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005F92 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      005F95 30 17 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      005F98 30 18 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      005F9B 90 07 66         [24] 1819 	mov	dptr,#_D0SetupLen
      005F9E E0               [24] 1820 	movx	a,@dptr
      005F9F F9               [12] 1821 	mov	r1,a
      005FA0 A3               [24] 1822 	inc	dptr
      005FA1 E0               [24] 1823 	movx	a,@dptr
      005FA2 FA               [12] 1824 	mov	r2,a
      005FA3 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      005FA6 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      005FA9 90 07 6B         [24] 1828 	mov	dptr,#_D0UsbConfig
      005FAC E0               [24] 1829 	movx	a,@dptr
      005FAD 90 10 00         [24] 1830 	mov	dptr,#0x1000
      005FB0 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      005FB1 90 22 08         [24] 1833 	mov	dptr,#0x2208
      005FB4 74 01            [12] 1834 	mov	a,#0x01
      005FB6 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      005FB7 90 07 C4         [24] 1837 	mov	dptr,#_control_phase
      005FBA 04               [12] 1838 	inc	a
      005FBB F0               [24] 1839 	movx	@dptr,a
      005FBC 02 64 93         [24] 1840 	ljmp	00291$
      005FBF                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      005FBF 02 5A E4         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005FC2                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005FC2 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      005FC5 30 16 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      005FC8 30 18 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      005FCB 90 07 66         [24] 1850 	mov	dptr,#_D0SetupLen
      005FCE E0               [24] 1851 	movx	a,@dptr
      005FCF F9               [12] 1852 	mov	r1,a
      005FD0 A3               [24] 1853 	inc	dptr
      005FD1 E0               [24] 1854 	movx	a,@dptr
      005FD2 FA               [12] 1855 	mov	r2,a
      005FD3 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      005FD6 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      005FD9 90 07 6B         [24] 1858 	mov	dptr,#_D0UsbConfig
      005FDC E0               [24] 1859 	movx	a,@dptr
      005FDD 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      005FDF 90 10 00         [24] 1862 	mov	dptr,#0x1000
      005FE2 E4               [12] 1863 	clr	a
      005FE3 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      005FE4 90 22 08         [24] 1866 	mov	dptr,#0x2208
      005FE7 04               [12] 1867 	inc	a
      005FE8 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      005FE9 90 07 C4         [24] 1870 	mov	dptr,#_control_phase
      005FEC 04               [12] 1871 	inc	a
      005FED F0               [24] 1872 	movx	@dptr,a
      005FEE 02 64 93         [24] 1873 	ljmp	00291$
      005FF1                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      005FF1 30 16 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      005FF4 90 07 6B         [24] 1877 	mov	dptr,#_D0UsbConfig
      005FF7 E0               [24] 1878 	movx	a,@dptr
      005FF8 60 18            [24] 1879 	jz	00161$
      005FFA BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      005FFD 30 19 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006000 EB               [12] 1883 	mov	a,r3
      006001 4C               [12] 1884 	orl	a,r4
      006002 70 05            [24] 1885 	jnz	00159$
      006004 90 06 43         [24] 1886 	mov	dptr,#_keyboard_idle
      006007 EE               [12] 1887 	mov	a,r6
      006008 F0               [24] 1888 	movx	@dptr,a
      006009                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      006009 90 07 C4         [24] 1891 	mov	dptr,#_control_phase
      00600C 74 03            [12] 1892 	mov	a,#0x03
      00600E F0               [24] 1893 	movx	@dptr,a
      00600F 02 64 93         [24] 1894 	ljmp	00291$
      006012                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      006012 02 5A E4         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006015                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006015 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006018 30 16 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      00601B 30 18 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      00601E 30 19 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      006021 90 07 6B         [24] 1905 	mov	dptr,#_D0UsbConfig
      006024 E0               [24] 1906 	movx	a,@dptr
      006025 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      006027 90 07 C4         [24] 1909 	mov	dptr,#_control_phase
      00602A 74 03            [12] 1910 	mov	a,#0x03
      00602C F0               [24] 1911 	movx	@dptr,a
      00602D 02 64 93         [24] 1912 	ljmp	00291$
      006030                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006030 EB               [12] 1915 	mov	a,r3
      006031 4C               [12] 1916 	orl	a,r4
      006032 70 2C            [24] 1917 	jnz	00175$
      006034 90 07 6B         [24] 1918 	mov	dptr,#_D0UsbConfig
      006037 E0               [24] 1919 	movx	a,@dptr
      006038 60 26            [24] 1920 	jz	00175$
      00603A BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      00603D 30 19 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      006040 8D 01            [24] 1923 	mov	ar1,r5
      006042 8E 02            [24] 1924 	mov	ar2,r6
      006044 C3               [12] 1925 	clr	c
      006045 74 01            [12] 1926 	mov	a,#0x01
      006047 99               [12] 1927 	subb	a,r1
      006048 E4               [12] 1928 	clr	a
      006049 9A               [12] 1929 	subb	a,r2
      00604A 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      00604C 90 0D B2         [24] 1933 	mov	dptr,#_keyboard_protocol
      00604F ED               [12] 1934 	mov	a,r5
      006050 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      006051 90 07 95         [24] 1937 	mov	dptr,#_keyboard_reset
      006054 74 01            [12] 1938 	mov	a,#0x01
      006056 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      006057 90 07 C4         [24] 1941 	mov	dptr,#_control_phase
      00605A 74 03            [12] 1942 	mov	a,#0x03
      00605C F0               [24] 1943 	movx	@dptr,a
      00605D 02 64 93         [24] 1944 	ljmp	00291$
      006060                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006060 02 5A E4         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      006063                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      006063 20 18 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      006066 02 5A E4         [24] 1952 	ljmp	_control_stall
      006069                       1953 01283$:
      006069 90 07 66         [24] 1954 	mov	dptr,#_D0SetupLen
      00606C E0               [24] 1955 	movx	a,@dptr
      00606D F9               [12] 1956 	mov	r1,a
      00606E A3               [24] 1957 	inc	dptr
      00606F E0               [24] 1958 	movx	a,@dptr
      006070 FA               [12] 1959 	mov	r2,a
      006071 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      006074 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006077 80 03            [24] 1962 	sjmp	01285$
      006079                       1963 01284$:
      006079 02 5A E4         [24] 1964 	ljmp	_control_stall
      00607C                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00607C E4               [12] 1967 	clr	a
      00607D BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      006080 04               [12] 1969 	inc	a
      006081                       1970 01286$:
      006081 FA               [12] 1971 	mov	r2,a
      006082 60 03            [24] 1972 	jz	00196$
      006084 20 17 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      006087                       1974 00196$:
      006087 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      00608A 30 16 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      00608D 90 07 6B         [24] 1977 	mov	dptr,#_D0UsbConfig
      006090 E0               [24] 1978 	movx	a,@dptr
      006091 70 29            [24] 1979 	jnz	00189$
      006093                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006093 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006096 90 07 6B         [24] 1983 	mov	dptr,#_D0UsbConfig
      006099 E0               [24] 1984 	movx	a,@dptr
      00609A 60 6A            [24] 1985 	jz	00190$
      00609C EB               [12] 1986 	mov	a,r3
      00609D 4C               [12] 1987 	orl	a,r4
      00609E 60 1C            [24] 1988 	jz	00189$
      0060A0 8B 00            [24] 1989 	mov	ar0,r3
      0060A2 8C 01            [24] 1990 	mov	ar1,r4
      0060A4 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      0060A7 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      0060AA 80 10            [24] 1993 	sjmp	00189$
      0060AC                       1994 01298$:
      0060AC C3               [12] 1995 	clr	c
      0060AD E8               [12] 1996 	mov	a,r0
      0060AE 94 81            [12] 1997 	subb	a,#0x81
      0060B0 E9               [12] 1998 	mov	a,r1
      0060B1 94 00            [12] 1999 	subb	a,#0x00
      0060B3 40 51            [24] 2000 	jc	00190$
      0060B5 74 83            [12] 2001 	mov	a,#0x83
      0060B7 98               [12] 2002 	subb	a,r0
      0060B8 E4               [12] 2003 	clr	a
      0060B9 99               [12] 2004 	subb	a,r1
      0060BA 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      0060BC                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      0060BC 8B 01            [24] 2009 	mov	ar1,r3
      0060BE 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0060C1 EA               [12] 2012 	mov	a,r2
      0060C2 60 0B            [24] 2013 	jz	00308$
      0060C4 90 07 6D         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0060C7 E0               [24] 2015 	movx	a,@dptr
      0060C8 54 01            [12] 2016 	anl	a,#0x01
      0060CA 25 E0            [12] 2017 	add	a,acc
      0060CC FA               [12] 2018 	mov	r2,a
      0060CD 80 22            [24] 2019 	sjmp	00309$
      0060CF                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0060CF BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      0060D2 E9               [12] 2023 	mov	a,r1
      0060D3 60 18            [24] 2024 	jz	00310$
      0060D5 89 00            [24] 2025 	mov	ar0,r1
      0060D7 79 00            [12] 2026 	mov	r1,#0x00
      0060D9 74 22            [12] 2027 	mov	a,#0x22
      0060DB 29               [12] 2028 	add	a, r1
      0060DC F9               [12] 2029 	mov	r1,a
      0060DD 88 82            [24] 2030 	mov	dpl,r0
      0060DF 89 83            [24] 2031 	mov	dph,r1
      0060E1 E0               [24] 2032 	movx	a,@dptr
      0060E2 F9               [12] 2033 	mov	r1,a
      0060E3 53 01 03         [24] 2034 	anl	ar1,#0x03
      0060E6 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      0060E9 79 01            [12] 2036 	mov	r1,#0x01
      0060EB 80 02            [24] 2037 	sjmp	00311$
      0060ED                       2038 00310$:
      0060ED 79 00            [12] 2039 	mov	r1,#0x00
      0060EF                       2040 00311$:
      0060EF 89 02            [24] 2041 	mov	ar2,r1
      0060F1                       2042 00309$:
      0060F1 90 10 00         [24] 2043 	mov	dptr,#0x1000
      0060F4 EA               [12] 2044 	mov	a,r2
      0060F5 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0060F6 A3               [24] 2047 	inc	dptr
      0060F7 E4               [12] 2048 	clr	a
      0060F8 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0060F9 90 22 08         [24] 2051 	mov	dptr,#0x2208
      0060FC 74 02            [12] 2052 	mov	a,#0x02
      0060FE F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      0060FF 90 07 C4         [24] 2055 	mov	dptr,#_control_phase
      006102 F0               [24] 2056 	movx	@dptr,a
      006103 02 64 93         [24] 2057 	ljmp	00291$
      006106                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      006106 02 5A E4         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006109                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      006109 20 19 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      00610C 02 61 9C         [24] 2065 	ljmp	00279$
      00610F                       2066 01307$:
      00610F 90 07 6B         [24] 2067 	mov	dptr,#_D0UsbConfig
      006112 E0               [24] 2068 	movx	a,@dptr
      006113 70 03            [24] 2069 	jnz	01308$
      006115 02 61 9C         [24] 2070 	ljmp	00279$
      006118                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      006118 EF               [12] 2073 	mov	a,r7
      006119 70 29            [24] 2074 	jnz	00218$
      00611B 8D 01            [24] 2075 	mov	ar1,r5
      00611D 8E 02            [24] 2076 	mov	ar2,r6
      00611F B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      006122 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      006125 30 17 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006128 90 07 65         [24] 2081 	mov	dptr,#_D0SetupReqCode
      00612B E0               [24] 2082 	movx	a,@dptr
      00612C FA               [12] 2083 	mov	r2,a
      00612D BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006130 90 07 6D         [24] 2085 	mov	dptr,#_USB_SleepStatus
      006133 E0               [24] 2086 	movx	a,@dptr
      006134 43 E0 01         [24] 2087 	orl	acc,#0x01
      006137 F0               [24] 2088 	movx	@dptr,a
      006138 80 59            [24] 2089 	sjmp	00219$
      00613A                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      00613A 90 07 6D         [24] 2092 	mov	dptr,#_USB_SleepStatus
      00613D E0               [24] 2093 	movx	a,@dptr
      00613E 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      006141 F0               [24] 2095 	movx	@dptr,a
      006142 80 4F            [24] 2096 	sjmp	00219$
      006144                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006144 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006147 30 18 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      00614A 8B 01            [24] 2101 	mov	ar1,r3
      00614C 8C 02            [24] 2102 	mov	ar2,r4
      00614E C3               [12] 2103 	clr	c
      00614F E9               [12] 2104 	mov	a,r1
      006150 94 81            [12] 2105 	subb	a,#0x81
      006152 EA               [12] 2106 	mov	a,r2
      006153 94 00            [12] 2107 	subb	a,#0x00
      006155 40 39            [24] 2108 	jc	00212$
      006157 74 83            [12] 2109 	mov	a,#0x83
      006159 99               [12] 2110 	subb	a,r1
      00615A E4               [12] 2111 	clr	a
      00615B 9A               [12] 2112 	subb	a,r2
      00615C 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      00615E 8B 02            [24] 2116 	mov	ar2,r3
      006160 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006163 8A 00            [24] 2119 	mov	ar0,r2
      006165 79 00            [12] 2120 	mov	r1,#0x00
      006167 74 22            [12] 2121 	mov	a,#0x22
      006169 29               [12] 2122 	add	a, r1
      00616A F9               [12] 2123 	mov	r1,a
      00616B 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      00616D 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      00616F 90 07 65         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006172 E0               [24] 2127 	movx	a,@dptr
      006173 F9               [12] 2128 	mov	r1,a
      006174 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006177 79 03            [12] 2130 	mov	r1,#0x03
      006179 80 02            [24] 2131 	sjmp	00319$
      00617B                       2132 00318$:
      00617B 79 02            [12] 2133 	mov	r1,#0x02
      00617D                       2134 00319$:
      00617D 43 01 10         [24] 2135 	orl	ar1,#0x10
      006180 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006183 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006186 E9               [12] 2138 	mov	a,r1
      006187 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006188 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      00618B 12 5A 70         [24] 2142 	lcall	_raw_complete
      00618E 80 03            [24] 2143 	sjmp	00219$
      006190                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006190 02 5A E4         [24] 2146 	ljmp	_control_stall
      006193                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006193 90 07 C4         [24] 2149 	mov	dptr,#_control_phase
      006196 74 03            [12] 2150 	mov	a,#0x03
      006198 F0               [24] 2151 	movx	@dptr,a
      006199 02 64 93         [24] 2152 	ljmp	00291$
      00619C                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00619C E4               [12] 2155 	clr	a
      00619D BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      0061A0 04               [12] 2157 	inc	a
      0061A1                       2158 01324$:
      0061A1 FA               [12] 2159 	mov	r2,a
      0061A2 70 03            [24] 2160 	jnz	01326$
      0061A4 02 64 0E         [24] 2161 	ljmp	00273$
      0061A7                       2162 01326$:
      0061A7 90 07 65         [24] 2163 	mov	dptr,#_D0SetupReqCode
      0061AA E0               [24] 2164 	movx	a,@dptr
      0061AB F9               [12] 2165 	mov	r1,a
      0061AC B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      0061AF 80 03            [24] 2167 	sjmp	01328$
      0061B1                       2168 01327$:
      0061B1 02 64 0E         [24] 2169 	ljmp	00273$
      0061B4                       2170 01328$:
      0061B4 90 07 6B         [24] 2171 	mov	dptr,#_D0UsbConfig
      0061B7 E0               [24] 2172 	movx	a,@dptr
      0061B8 70 03            [24] 2173 	jnz	01329$
      0061BA 02 64 0E         [24] 2174 	ljmp	00273$
      0061BD                       2175 01329$:
      0061BD 90 07 66         [24] 2176 	mov	dptr,#_D0SetupLen
      0061C0 E0               [24] 2177 	movx	a,@dptr
      0061C1 F8               [12] 2178 	mov	r0,a
      0061C2 A3               [24] 2179 	inc	dptr
      0061C3 E0               [24] 2180 	movx	a,@dptr
      0061C4 48               [12] 2181 	orl	a,r0
      0061C5 70 03            [24] 2182 	jnz	01330$
      0061C7 02 64 0E         [24] 2183 	ljmp	00273$
      0061CA                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0061CA C0 03            [24] 2186 	push	ar3
      0061CC C0 04            [24] 2187 	push	ar4
      0061CE 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0061D0 8E 00            [24] 2190 	mov	ar0,r6
      0061D2 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      0061D5 E8               [12] 2192 	mov	a,r0
      0061D6 80 01            [24] 2193 	sjmp	01332$
      0061D8                       2194 01331$:
      0061D8 E4               [12] 2195 	clr	a
      0061D9                       2196 01332$:
      0061D9 F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0061DB D0 04            [24] 2198 	pop	ar4
      0061DD D0 03            [24] 2199 	pop	ar3
      0061DF E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0061E1 60 17            [24] 2201 	jz	00251$
      0061E3 EB               [12] 2202 	mov	a,r3
      0061E4 4C               [12] 2203 	orl	a,r4
      0061E5 70 13            [24] 2204 	jnz	00251$
      0061E7 E9               [12] 2205 	mov	a,r1
      0061E8 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0061EA 90 07 CE         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      0061ED 74 08            [12] 2209 	mov	a,#0x08
      0061EF F0               [24] 2210 	movx	@dptr,a
      0061F0 E4               [12] 2211 	clr	a
      0061F1 A3               [24] 2212 	inc	dptr
      0061F2 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0061F3 90 07 D0         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      0061F6 F0               [24] 2216 	movx	@dptr,a
      0061F7 02 63 7E         [24] 2217 	ljmp	00252$
      0061FA                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0061FA E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      0061FC 60 27            [24] 2221 	jz	00245$
      0061FE BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      006201 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006204 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      006207                       2226 01339$:
      006207 50 1C            [24] 2227 	jnc	00245$
      006209 E9               [12] 2228 	mov	a,r1
      00620A 90 B9 E8         [24] 2229 	mov	dptr,#_shared_lengths
      00620D 93               [24] 2230 	movc	a,@a+dptr
      00620E F8               [12] 2231 	mov	r0,a
      00620F 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      006211 90 07 CE         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      006214 E8               [12] 2235 	mov	a,r0
      006215 F0               [24] 2236 	movx	@dptr,a
      006216 E4               [12] 2237 	clr	a
      006217 A3               [24] 2238 	inc	dptr
      006218 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      006219 E9               [12] 2241 	mov	a,r1
      00621A 90 B9 E1         [24] 2242 	mov	dptr,#_shared_offsets
      00621D 93               [24] 2243 	movc	a,@a+dptr
      00621E 90 07 D0         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      006221 F0               [24] 2245 	movx	@dptr,a
      006222 02 63 7E         [24] 2246 	ljmp	00252$
      006225                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006225 E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006227 60 7A            [24] 2250 	jz	00240$
      006229 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      00622C BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      00622F E9               [12] 2253 	mov	a,r1
      006230 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006232 90 07 66         [24] 2256 	mov	dptr,#_D0SetupLen
      006235 E0               [24] 2257 	movx	a,@dptr
      006236 F8               [12] 2258 	mov	r0,a
      006237 A3               [24] 2259 	inc	dptr
      006238 E0               [24] 2260 	movx	a,@dptr
      006239 F9               [12] 2261 	mov	r1,a
      00623A C3               [12] 2262 	clr	c
      00623B E8               [12] 2263 	mov	a,r0
      00623C 94 20            [12] 2264 	subb	a,#0x20
      00623E E9               [12] 2265 	mov	a,r1
      00623F 94 00            [12] 2266 	subb	a,#0x00
      006241 50 0A            [24] 2267 	jnc	00320$
      006243 90 07 66         [24] 2268 	mov	dptr,#_D0SetupLen
      006246 E0               [24] 2269 	movx	a,@dptr
      006247 F8               [12] 2270 	mov	r0,a
      006248 A3               [24] 2271 	inc	dptr
      006249 E0               [24] 2272 	movx	a,@dptr
      00624A F9               [12] 2273 	mov	r1,a
      00624B 80 04            [24] 2274 	sjmp	00321$
      00624D                       2275 00320$:
      00624D 78 20            [12] 2276 	mov	r0,#0x20
      00624F 79 00            [12] 2277 	mov	r1,#0x00
      006251                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006251 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      006254                       2281 00293$:
      006254 C0 03            [24] 2282 	push	ar3
      006256 C0 04            [24] 2283 	push	ar4
      006258 AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      00625A 7C 00            [12] 2285 	mov	r4,#0x00
      00625C C3               [12] 2286 	clr	c
      00625D EB               [12] 2287 	mov	a,r3
      00625E 98               [12] 2288 	subb	a,r0
      00625F EC               [12] 2289 	mov	a,r4
      006260 99               [12] 2290 	subb	a,r1
      006261 D0 04            [24] 2291 	pop	ar4
      006263 D0 03            [24] 2292 	pop	ar3
      006265 50 32            [24] 2293 	jnc	00222$
      006267 C0 00            [24] 2294 	push	ar0
      006269 C0 01            [24] 2295 	push	ar1
      00626B 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      00626E 74 10            [12] 2297 	mov	a,#0x10
      006270 24 00            [12] 2298 	add	a, #0x00
      006272 F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006274 A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006276 79 00            [12] 2301 	mov	r1,#0x00
      006278 74 C0            [12] 2302 	mov	a,#0xc0
      00627A 28               [12] 2303 	add	a, r0
      00627B F8               [12] 2304 	mov	r0,a
      00627C E4               [12] 2305 	clr	a
      00627D 39               [12] 2306 	addc	a, r1
      00627E F9               [12] 2307 	mov	r1,a
      00627F 88 82            [24] 2308 	mov	dpl,r0
      006281 74 10            [12] 2309 	mov	a,#0x10
      006283 29               [12] 2310 	add	a, r1
      006284 F5 83            [12] 2311 	mov	dph,a
      006286 E0               [24] 2312 	movx	a,@dptr
      006287 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      00628A 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00628D F0               [24] 2315 	movx	@dptr,a
      00628E E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006290 04               [12] 2317 	inc	a
      006291 F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006293 D0 01            [24] 2319 	pop	ar1
      006295 D0 00            [24] 2320 	pop	ar0
      006297 80 BB            [24] 2321 	sjmp	00293$
      006299                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      006299 90 07 CE         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      00629C E4               [12] 2325 	clr	a
      00629D F0               [24] 2326 	movx	@dptr,a
      00629E A3               [24] 2327 	inc	dptr
      00629F F0               [24] 2328 	movx	@dptr,a
      0062A0 02 63 7E         [24] 2329 	ljmp	00252$
      0062A3                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0062A3 8D 00            [24] 2332 	mov	ar0,r5
      0062A5 8E 01            [24] 2333 	mov	ar1,r6
      0062A7 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      0062AA B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      0062AD EB               [12] 2336 	mov	a,r3
      0062AE 4C               [12] 2337 	orl	a,r4
      0062AF 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0062B1 90 07 70         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      0062B4 E0               [24] 2341 	movx	a,@dptr
      0062B5 90 10 00         [24] 2342 	mov	dptr,#0x1000
      0062B8 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      0062B9 90 07 CE         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      0062BC E4               [12] 2346 	clr	a
      0062BD F0               [24] 2347 	movx	@dptr,a
      0062BE A3               [24] 2348 	inc	dptr
      0062BF F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      0062C0 90 07 66         [24] 2351 	mov	dptr,#_D0SetupLen
      0062C3 04               [12] 2352 	inc	a
      0062C4 F0               [24] 2353 	movx	@dptr,a
      0062C5 E4               [12] 2354 	clr	a
      0062C6 A3               [24] 2355 	inc	dptr
      0062C7 F0               [24] 2356 	movx	@dptr,a
      0062C8 02 63 7E         [24] 2357 	ljmp	00252$
      0062CB                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0062CB B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      0062CE B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      0062D1 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      0062D4 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0062D7 C0 03            [24] 2365 	push	ar3
      0062D9 C0 04            [24] 2366 	push	ar4
      0062DB 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0062DE 74 06            [12] 2368 	mov	a,#0x06
      0062E0 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0062E1 90 07 70         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0062E4 E0               [24] 2372 	movx	a,@dptr
      0062E5 90 10 01         [24] 2373 	mov	dptr,#0x1001
      0062E8 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      0062E9 90 07 CE         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      0062EC E4               [12] 2377 	clr	a
      0062ED F0               [24] 2378 	movx	@dptr,a
      0062EE A3               [24] 2379 	inc	dptr
      0062EF F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      0062F0 90 07 66         [24] 2382 	mov	dptr,#_D0SetupLen
      0062F3 E0               [24] 2383 	movx	a,@dptr
      0062F4 FB               [12] 2384 	mov	r3,a
      0062F5 A3               [24] 2385 	inc	dptr
      0062F6 E0               [24] 2386 	movx	a,@dptr
      0062F7 FC               [12] 2387 	mov	r4,a
      0062F8 C3               [12] 2388 	clr	c
      0062F9 74 02            [12] 2389 	mov	a,#0x02
      0062FB 9B               [12] 2390 	subb	a,r3
      0062FC E4               [12] 2391 	clr	a
      0062FD 9C               [12] 2392 	subb	a,r4
      0062FE D0 04            [24] 2393 	pop	ar4
      006300 D0 03            [24] 2394 	pop	ar3
      006302 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006304 90 07 66         [24] 2397 	mov	dptr,#_D0SetupLen
      006307 74 02            [12] 2398 	mov	a,#0x02
      006309 F0               [24] 2399 	movx	@dptr,a
      00630A E4               [12] 2400 	clr	a
      00630B A3               [24] 2401 	inc	dptr
      00630C F0               [24] 2402 	movx	@dptr,a
      00630D 80 6F            [24] 2403 	sjmp	00252$
      00630F                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00630F B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      006312 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      006315 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006318 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      00631B 90 10 00         [24] 2411 	mov	dptr,#0x1000
      00631E 74 41            [12] 2412 	mov	a,#0x41
      006320 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      006321 A3               [24] 2415 	inc	dptr
      006322 74 4B            [12] 2416 	mov	a,#0x4b
      006324 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      006325 A3               [24] 2419 	inc	dptr
      006326 74 42            [12] 2420 	mov	a,#0x42
      006328 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006329 A3               [24] 2423 	inc	dptr
      00632A 74 54            [12] 2424 	mov	a,#0x54
      00632C F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      00632D A3               [24] 2427 	inc	dptr
      00632E 74 01            [12] 2428 	mov	a,#0x01
      006330 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      006331 90 07 71         [24] 2431 	mov	dptr,#_ak820_boot_stage
      006334 E0               [24] 2432 	movx	a,@dptr
      006335 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006338 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006339 90 07 72         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      00633C E0               [24] 2437 	movx	a,@dptr
      00633D 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006340 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006341 90 07 6C         [24] 2441 	mov	dptr,#_USB_EnumStatus
      006344 E0               [24] 2442 	movx	a,@dptr
      006345 60 02            [24] 2443 	jz	00322$
      006347 74 01            [12] 2444 	mov	a,#0x01
      006349                       2445 00322$:
      006349 F9               [12] 2446 	mov	r1,a
      00634A 90 07 6D         [24] 2447 	mov	dptr,#_USB_SleepStatus
      00634D E0               [24] 2448 	movx	a,@dptr
      00634E 54 02            [12] 2449 	anl	a,#0x02
      006350 F8               [12] 2450 	mov	r0,a
      006351 E9               [12] 2451 	mov	a,r1
      006352 42 00            [12] 2452 	orl	ar0,a
      006354 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006357 E8               [12] 2454 	mov	a,r0
      006358 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      006359 90 07 CE         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      00635C E4               [12] 2458 	clr	a
      00635D F0               [24] 2459 	movx	@dptr,a
      00635E A3               [24] 2460 	inc	dptr
      00635F F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006360 90 07 66         [24] 2463 	mov	dptr,#_D0SetupLen
      006363 E0               [24] 2464 	movx	a,@dptr
      006364 F8               [12] 2465 	mov	r0,a
      006365 A3               [24] 2466 	inc	dptr
      006366 E0               [24] 2467 	movx	a,@dptr
      006367 F9               [12] 2468 	mov	r1,a
      006368 C3               [12] 2469 	clr	c
      006369 74 08            [12] 2470 	mov	a,#0x08
      00636B 98               [12] 2471 	subb	a,r0
      00636C E4               [12] 2472 	clr	a
      00636D 99               [12] 2473 	subb	a,r1
      00636E 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006370 90 07 66         [24] 2476 	mov	dptr,#_D0SetupLen
      006373 74 08            [12] 2477 	mov	a,#0x08
      006375 F0               [24] 2478 	movx	@dptr,a
      006376 E4               [12] 2479 	clr	a
      006377 A3               [24] 2480 	inc	dptr
      006378 F0               [24] 2481 	movx	@dptr,a
      006379 80 03            [24] 2482 	sjmp	00252$
      00637B                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      00637B 02 5A E4         [24] 2485 	ljmp	_control_stall
      00637E                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      00637E 90 07 CE         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      006381 E0               [24] 2489 	movx	a,@dptr
      006382 F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006384 A3               [24] 2491 	inc	dptr
      006385 E0               [24] 2492 	movx	a,@dptr
      006386 F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      006388 E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      00638A 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00638C 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      00638E 90 07 66         [24] 2498 	mov	dptr,#_D0SetupLen
      006391 E0               [24] 2499 	movx	a,@dptr
      006392 F8               [12] 2500 	mov	r0,a
      006393 A3               [24] 2501 	inc	dptr
      006394 E0               [24] 2502 	movx	a,@dptr
      006395 F9               [12] 2503 	mov	r1,a
      006396 C3               [12] 2504 	clr	c
      006397 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      006399 98               [12] 2506 	subb	a,r0
      00639A E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00639C 99               [12] 2508 	subb	a,r1
      00639D 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      00639F 90 07 66         [24] 2511 	mov	dptr,#_D0SetupLen
      0063A2 E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      0063A4 F0               [24] 2513 	movx	@dptr,a
      0063A5 E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0063A7 A3               [24] 2515 	inc	dptr
      0063A8 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0063A9                       2518 00559$:
      0063A9 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      0063AC                       2520 00296$:
      0063AC 90 07 66         [24] 2521 	mov	dptr,#_D0SetupLen
      0063AF E0               [24] 2522 	movx	a,@dptr
      0063B0 F8               [12] 2523 	mov	r0,a
      0063B1 C3               [12] 2524 	clr	c
      0063B2 E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      0063B4 98               [12] 2526 	subb	a,r0
      0063B5 50 46            [24] 2527 	jnc	00263$
      0063B7 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0063BA 74 10            [12] 2529 	mov	a,#0x10
      0063BC 24 00            [12] 2530 	add	a, #0x00
      0063BE F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      0063C0 90 07 D0         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      0063C3 E0               [24] 2533 	movx	a,@dptr
      0063C4 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      0063C6 24 96            [12] 2535 	add	a, #_input_snapshot
      0063C8 F5 82            [12] 2536 	mov	dpl,a
      0063CA E4               [12] 2537 	clr	a
      0063CB 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      0063CD F5 83            [12] 2539 	mov	dph,a
      0063CF E0               [24] 2540 	movx	a,@dptr
      0063D0 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      0063D3 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0063D6 F0               [24] 2543 	movx	@dptr,a
      0063D7 E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0063D9 04               [12] 2545 	inc	a
      0063DA F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0063DC 80 CE            [24] 2547 	sjmp	00296$
      0063DE                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0063DE BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0063E1 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0063E4 90 07 66         [24] 2552 	mov	dptr,#_D0SetupLen
      0063E7 E0               [24] 2553 	movx	a,@dptr
      0063E8 F8               [12] 2554 	mov	r0,a
      0063E9 A3               [24] 2555 	inc	dptr
      0063EA E0               [24] 2556 	movx	a,@dptr
      0063EB F9               [12] 2557 	mov	r1,a
      0063EC C3               [12] 2558 	clr	c
      0063ED 74 20            [12] 2559 	mov	a,#0x20
      0063EF 98               [12] 2560 	subb	a,r0
      0063F0 E4               [12] 2561 	clr	a
      0063F1 99               [12] 2562 	subb	a,r1
      0063F2 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      0063F4 90 07 66         [24] 2565 	mov	dptr,#_D0SetupLen
      0063F7 74 20            [12] 2566 	mov	a,#0x20
      0063F9 F0               [24] 2567 	movx	@dptr,a
      0063FA E4               [12] 2568 	clr	a
      0063FB A3               [24] 2569 	inc	dptr
      0063FC F0               [24] 2570 	movx	@dptr,a
      0063FD                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      0063FD 90 07 66         [24] 2573 	mov	dptr,#_D0SetupLen
      006400 E0               [24] 2574 	movx	a,@dptr
      006401 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006404 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      006405 90 07 C4         [24] 2578 	mov	dptr,#_control_phase
      006408 74 02            [12] 2579 	mov	a,#0x02
      00640A F0               [24] 2580 	movx	@dptr,a
      00640B 02 64 93         [24] 2581 	ljmp	00291$
      00640E                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00640E EB               [12] 2584 	mov	a,r3
      00640F 4C               [12] 2585 	orl	a,r4
      006410 70 37            [24] 2586 	jnz	00265$
      006412 90 07 6B         [24] 2587 	mov	dptr,#_D0UsbConfig
      006415 E0               [24] 2588 	movx	a,@dptr
      006416 60 31            [24] 2589 	jz	00265$
      006418 EA               [12] 2590 	mov	a,r2
      006419 60 2E            [24] 2591 	jz	00265$
      00641B 90 07 65         [24] 2592 	mov	dptr,#_D0SetupReqCode
      00641E E0               [24] 2593 	movx	a,@dptr
      00641F FA               [12] 2594 	mov	r2,a
      006420 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      006423 30 18 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      006426 90 07 66         [24] 2597 	mov	dptr,#_D0SetupLen
      006429 E0               [24] 2598 	movx	a,@dptr
      00642A F9               [12] 2599 	mov	r1,a
      00642B A3               [24] 2600 	inc	dptr
      00642C E0               [24] 2601 	movx	a,@dptr
      00642D FA               [12] 2602 	mov	r2,a
      00642E B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      006431 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006434 90 0D B2         [24] 2606 	mov	dptr,#_keyboard_protocol
      006437 E0               [24] 2607 	movx	a,@dptr
      006438 90 10 00         [24] 2608 	mov	dptr,#0x1000
      00643B F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      00643C 90 22 08         [24] 2611 	mov	dptr,#0x2208
      00643F 74 01            [12] 2612 	mov	a,#0x01
      006441 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      006442 90 07 C4         [24] 2615 	mov	dptr,#_control_phase
      006445 04               [12] 2616 	inc	a
      006446 F0               [24] 2617 	movx	@dptr,a
      006447 80 4A            [24] 2618 	sjmp	00291$
      006449                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006449 02 5A E4         [24] 2622 	ljmp	_control_stall
      00644C                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      00644C 30 16 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      00644F 90 07 6B         [24] 2626 	mov	dptr,#_D0UsbConfig
      006452 E0               [24] 2627 	movx	a,@dptr
      006453 60 38            [24] 2628 	jz	00284$
      006455 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006458 8E 05            [24] 2630 	mov	ar5,r6
      00645A 7E 00            [12] 2631 	mov	r6,#0x00
      00645C ED               [12] 2632 	mov	a,r5
      00645D 4E               [12] 2633 	orl	a,r6
      00645E 70 2D            [24] 2634 	jnz	00284$
      006460 90 07 66         [24] 2635 	mov	dptr,#_D0SetupLen
      006463 E0               [24] 2636 	movx	a,@dptr
      006464 FE               [12] 2637 	mov	r6,a
      006465 A3               [24] 2638 	inc	dptr
      006466 E0               [24] 2639 	movx	a,@dptr
      006467 FF               [12] 2640 	mov	r7,a
      006468 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      00646B BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      00646E EB               [12] 2644 	mov	a,r3
      00646F 4C               [12] 2645 	orl	a,r4
      006470 70 07            [24] 2646 	jnz	00324$
      006472 90 06 43         [24] 2647 	mov	dptr,#_keyboard_idle
      006475 E0               [24] 2648 	movx	a,@dptr
      006476 FF               [12] 2649 	mov	r7,a
      006477 80 02            [24] 2650 	sjmp	00325$
      006479                       2651 00324$:
      006479 7F 00            [12] 2652 	mov	r7,#0x00
      00647B                       2653 00325$:
      00647B 90 10 00         [24] 2654 	mov	dptr,#0x1000
      00647E EF               [12] 2655 	mov	a,r7
      00647F F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006480 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006483 74 01            [12] 2659 	mov	a,#0x01
      006485 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      006486 90 07 C4         [24] 2662 	mov	dptr,#_control_phase
      006489 04               [12] 2663 	inc	a
      00648A F0               [24] 2664 	movx	@dptr,a
      00648B 80 06            [24] 2665 	sjmp	00291$
      00648D                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      00648D 02 5A E4         [24] 2669 	ljmp	_control_stall
      006490                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006490 02 5A E4         [24] 2672 	ljmp	_control_stall
      006493                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006493 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006496 74 C0            [12] 2676 	mov	a,#0xc0
      006498 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      006499 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      00649A                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      00649A 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      00649D E0               [24] 2692 	movx	a,@dptr
      00649E 20 E6 01         [24] 2693 	jb	acc.6,00102$
      0064A1 22               [24] 2694 	ret
      0064A2                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0064A2 90 07 C4         [24] 2697 	mov	dptr,#_control_phase
      0064A5 E0               [24] 2698 	movx	a,@dptr
      0064A6 FF               [12] 2699 	mov	r7,a
      0064A7 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      0064AA 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      0064AD E0               [24] 2702 	movx	a,@dptr
      0064AE 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      0064B0 90 07 C4         [24] 2705 	mov	dptr,#_control_phase
      0064B3 E4               [12] 2706 	clr	a
      0064B4 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0064B5 90 22 00         [24] 2709 	mov	dptr,#0x2200
      0064B8 74 02            [12] 2710 	mov	a,#0x02
      0064BA F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      0064BB 22               [24] 2713 	ret
      0064BC                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0064BC BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      0064BF 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      0064C2 E0               [24] 2718 	movx	a,@dptr
      0064C3 FF               [12] 2719 	mov	r7,a
      0064C4 90 07 66         [24] 2720 	mov	dptr,#_D0SetupLen
      0064C7 E0               [24] 2721 	movx	a,@dptr
      0064C8 FD               [12] 2722 	mov	r5,a
      0064C9 A3               [24] 2723 	inc	dptr
      0064CA E0               [24] 2724 	movx	a,@dptr
      0064CB FE               [12] 2725 	mov	r6,a
      0064CC 7C 00            [12] 2726 	mov	r4,#0x00
      0064CE EF               [12] 2727 	mov	a,r7
      0064CF B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      0064D2 EC               [12] 2729 	mov	a,r4
      0064D3 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      0064D6 80 03            [24] 2731 	sjmp	00107$
      0064D8                       2732 00209$:
      0064D8                       2733 00106$:
      0064D8 02 5A E4         [24] 2734 	ljmp	_control_stall
      0064DB                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0064DB 90 07 C5         [24] 2737 	mov	dptr,#_output_kind
      0064DE E0               [24] 2738 	movx	a,@dptr
      0064DF FF               [12] 2739 	mov	r7,a
      0064E0 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      0064E3 90 07 73         [24] 2741 	mov	dptr,#_raw_state
      0064E6 E0               [24] 2742 	movx	a,@dptr
      0064E7 FE               [12] 2743 	mov	r6,a
      0064E8 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0064EB 7E 00            [12] 2746 	mov	r6,#0x00
      0064ED                       2747 00121$:
      0064ED EE               [12] 2748 	mov	a,r6
      0064EE 24 74            [12] 2749 	add	a, #_raw_buffer
      0064F0 FC               [12] 2750 	mov	r4,a
      0064F1 E4               [12] 2751 	clr	a
      0064F2 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      0064F4 FD               [12] 2753 	mov	r5,a
      0064F5 8E 82            [24] 2754 	mov	dpl,r6
      0064F7 74 10            [12] 2755 	mov	a,#0x10
      0064F9 24 00            [12] 2756 	add	a, #0x00
      0064FB F5 83            [12] 2757 	mov	dph,a
      0064FD E0               [24] 2758 	movx	a,@dptr
      0064FE 8C 82            [24] 2759 	mov	dpl,r4
      006500 8D 83            [24] 2760 	mov	dph,r5
      006502 F0               [24] 2761 	movx	@dptr,a
      006503 0E               [12] 2762 	inc	r6
      006504 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      006507                       2764 00214$:
      006507 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006509 90 07 73         [24] 2767 	mov	dptr,#_raw_state
      00650C 74 02            [12] 2768 	mov	a,#0x02
      00650E F0               [24] 2769 	movx	@dptr,a
      00650F 80 2B            [24] 2770 	sjmp	00119$
      006511                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      006511 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      006514 90 10 00         [24] 2775 	mov	dptr,#0x1000
      006517 E0               [24] 2776 	movx	a,@dptr
      006518 90 07 70         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      00651B F0               [24] 2778 	movx	@dptr,a
      00651C 80 1E            [24] 2779 	sjmp	00119$
      00651E                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      00651E BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      006521 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006524 E0               [24] 2784 	movx	a,@dptr
      006525 FF               [12] 2785 	mov	r7,a
      006526 90 07 C6         [24] 2786 	mov	dptr,#_output_report_id
      006529 E0               [24] 2787 	movx	a,@dptr
      00652A FE               [12] 2788 	mov	r6,a
      00652B EF               [12] 2789 	mov	a,r7
      00652C B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      00652F 90 10 01         [24] 2792 	mov	dptr,#0x1001
      006532 E0               [24] 2793 	movx	a,@dptr
      006533 90 07 70         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006536 F0               [24] 2795 	movx	@dptr,a
      006537 80 03            [24] 2796 	sjmp	00119$
      006539                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006539 02 5A E4         [24] 2799 	ljmp	_control_stall
      00653C                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      00653C 90 07 C5         [24] 2802 	mov	dptr,#_output_kind
      00653F E4               [12] 2803 	clr	a
      006540 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006541 90 07 66         [24] 2806 	mov	dptr,#_D0SetupLen
      006544 F0               [24] 2807 	movx	@dptr,a
      006545 A3               [24] 2808 	inc	dptr
      006546 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006547 90 07 C4         [24] 2811 	mov	dptr,#_control_phase
      00654A 74 03            [12] 2812 	mov	a,#0x03
      00654C F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      00654D 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006550 E4               [12] 2816 	clr	a
      006551 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006552 F5 82            [12] 2819 	mov	dpl,a
      006554 74 48            [12] 2820 	mov	a,#0x48
      006556 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006557 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006558                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006558 90 07 C4         [24] 2833 	mov	dptr,#_control_phase
      00655B E0               [24] 2834 	movx	a,@dptr
      00655C FF               [12] 2835 	mov	r7,a
      00655D BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006560 90 07 66         [24] 2838 	mov	dptr,#_D0SetupLen
      006563 E0               [24] 2839 	movx	a,@dptr
      006564 FD               [12] 2840 	mov	r5,a
      006565 A3               [24] 2841 	inc	dptr
      006566 E0               [24] 2842 	movx	a,@dptr
      006567 4D               [12] 2843 	orl	a,r5
      006568 70 06            [24] 2844 	jnz	00101$
      00656A 90 07 C7         [24] 2845 	mov	dptr,#_control_zlp
      00656D E0               [24] 2846 	movx	a,@dptr
      00656E 60 0A            [24] 2847 	jz	00102$
      006570                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006570 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006573 E0               [24] 2851 	movx	a,@dptr
      006574 64 40            [12] 2852 	xrl	a,#0x40
      006576 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006577 02 5B 06         [24] 2856 	ljmp	_control_next
      00657A                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      00657A 90 07 C4         [24] 2859 	mov	dptr,#_control_phase
      00657D 74 02            [12] 2860 	mov	a,#0x02
      00657F F0               [24] 2861 	movx	@dptr,a
      006580 80 18            [24] 2862 	sjmp	00110$
      006582                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006582 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006585 90 07 65         [24] 2867 	mov	dptr,#_D0SetupReqCode
      006588 E0               [24] 2868 	movx	a,@dptr
      006589 FF               [12] 2869 	mov	r7,a
      00658A BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      00658D 90 07 66         [24] 2871 	mov	dptr,#_D0SetupLen
      006590 E0               [24] 2872 	movx	a,@dptr
      006591 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006594 F0               [24] 2874 	movx	@dptr,a
      006595                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006595 90 07 C4         [24] 2877 	mov	dptr,#_control_phase
      006598 E4               [12] 2878 	clr	a
      006599 F0               [24] 2879 	movx	@dptr,a
      00659A                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00659A 90 22 00         [24] 2882 	mov	dptr,#0x2200
      00659D 74 82            [12] 2883 	mov	a,#0x82
      00659F F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      0065A0 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      0065A1                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      0065A1                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      0065A1 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      0065A4 E0               [24] 2902 	movx	a,@dptr
      0065A5 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      0065A8 12 5A 8D         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      0065AB 90 22 07         [24] 2907 	mov	dptr,#0x2207
      0065AE E4               [12] 2908 	clr	a
      0065AF F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0065B0 90 07 6D         [24] 2911 	mov	dptr,#_USB_SleepStatus
      0065B3 F0               [24] 2912 	movx	@dptr,a
      0065B4 90 07 6C         [24] 2913 	mov	dptr,#_USB_EnumStatus
      0065B7 F0               [24] 2914 	movx	@dptr,a
      0065B8 90 07 6B         [24] 2915 	mov	dptr,#_D0UsbConfig
      0065BB F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      0065BC 90 07 70         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      0065BF F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      0065C0 90 0D B2         [24] 2921 	mov	dptr,#_keyboard_protocol
      0065C3 04               [12] 2922 	inc	a
      0065C4 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      0065C5 90 06 43         [24] 2925 	mov	dptr,#_keyboard_idle
      0065C8 E4               [12] 2926 	clr	a
      0065C9 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      0065CA 90 07 95         [24] 2929 	mov	dptr,#_keyboard_reset
      0065CD 04               [12] 2930 	inc	a
      0065CE F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      0065CF 90 07 65         [24] 2933 	mov	dptr,#_D0SetupReqCode
      0065D2 74 FF            [12] 2934 	mov	a,#0xff
      0065D4 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      0065D5 90 07 66         [24] 2937 	mov	dptr,#_D0SetupLen
      0065D8 E4               [12] 2938 	clr	a
      0065D9 F0               [24] 2939 	movx	@dptr,a
      0065DA A3               [24] 2940 	inc	dptr
      0065DB F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      0065DC 90 07 C4         [24] 2943 	mov	dptr,#_control_phase
      0065DF F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065E0 90 22 00         [24] 2946 	mov	dptr,#0x2200
      0065E3 74 02            [12] 2947 	mov	a,#0x02
      0065E5 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      0065E6 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      0065E9 E4               [12] 2951 	clr	a
      0065EA F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      0065EB 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      0065EE 04               [12] 2955 	inc	a
      0065EF F0               [24] 2956 	movx	@dptr,a
      0065F0 02 66 86         [24] 2957 	ljmp	00130$
      0065F3                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0065F3 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      0065F6 E0               [24] 2961 	movx	a,@dptr
      0065F7 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      0065FA 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      0065FD E0               [24] 2965 	movx	a,@dptr
      0065FE FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      0065FF 74 07            [12] 2968 	mov	a,#0x07
      006601 5F               [12] 2969 	anl	a,r7
      006602 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006603 EF               [12] 2972 	mov	a,r7
      006604 54 18            [12] 2973 	anl	a,#0x18
      006606 70 08            [24] 2974 	jnz	00115$
      006608 EE               [12] 2975 	mov	a,r6
      006609 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      00660B 12 64 9A         [24] 2978 	lcall	_control_out
      00660E 80 43            [24] 2979 	sjmp	00116$
      006610                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006610 8F 05            [24] 2982 	mov	ar5,r7
      006612 74 18            [12] 2983 	mov	a,#0x18
      006614 5D               [12] 2984 	anl	a,r5
      006615 FC               [12] 2985 	mov	r4,a
      006616 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006619 EE               [12] 2988 	mov	a,r6
      00661A 70 05            [24] 2989 	jnz	00106$
      00661C 12 65 58         [24] 2990 	lcall	_control_in
      00661F 80 32            [24] 2991 	sjmp	00116$
      006621                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006621 EE               [12] 2994 	mov	a,r6
      006622 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006624 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006626 8E 04            [24] 2999 	mov	ar4,r6
      006628 7B 00            [12] 3000 	mov	r3,#0x00
      00662A 74 22            [12] 3001 	mov	a,#0x22
      00662C 2B               [12] 3002 	add	a, r3
      00662D FB               [12] 3003 	mov	r3,a
      00662E 8C 82            [24] 3004 	mov	dpl,r4
      006630 8B 83            [24] 3005 	mov	dph,r3
      006632 E0               [24] 3006 	movx	a,@dptr
      006633 FA               [12] 3007 	mov	r2,a
      006634 74 FC            [12] 3008 	mov	a,#0xfc
      006636 5A               [12] 3009 	anl	a,r2
      006637 44 02            [12] 3010 	orl	a,#0x02
      006639 8C 82            [24] 3011 	mov	dpl,r4
      00663B 8B 83            [24] 3012 	mov	dph,r3
      00663D F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00663E BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006641 12 5A 70         [24] 3016 	lcall	_raw_complete
      006644 80 0D            [24] 3017 	sjmp	00116$
      006646                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006646 53 05 18         [24] 3020 	anl	ar5,#0x18
      006649 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      00664C EF               [12] 3022 	mov	a,r7
      00664D 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006650 12 5C FD         [24] 3025 	lcall	_control_setup
      006653                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006653 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006656 E4               [12] 3029 	clr	a
      006657 F0               [24] 3030 	movx	@dptr,a
      006658 80 2C            [24] 3031 	sjmp	00130$
      00665A                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      00665A 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      00665D E0               [24] 3035 	movx	a,@dptr
      00665E 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006661 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006664 E0               [24] 3039 	movx	a,@dptr
      006665 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006668 90 07 6D         [24] 3041 	mov	dptr,#_USB_SleepStatus
      00666B E0               [24] 3042 	movx	a,@dptr
      00666C 43 E0 02         [24] 3043 	orl	acc,#0x02
      00666F F0               [24] 3044 	movx	@dptr,a
      006670 80 0E            [24] 3045 	sjmp	00120$
      006672                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006672 90 07 6D         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006675 E0               [24] 3049 	movx	a,@dptr
      006676 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006679 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      00667A 90 07 95         [24] 3053 	mov	dptr,#_keyboard_reset
      00667D 74 01            [12] 3054 	mov	a,#0x01
      00667F F0               [24] 3055 	movx	@dptr,a
      006680                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006680 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006683 74 04            [12] 3059 	mov	a,#0x04
      006685 F0               [24] 3060 	movx	@dptr,a
      006686                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006686 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      006689 E0               [24] 3064 	movx	a,@dptr
      00668A 54 25            [12] 3065 	anl	a,#0x25
      00668C 60 03            [24] 3066 	jz	00242$
      00668E 02 65 A1         [24] 3067 	ljmp	00129$
      006691                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006691 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006692                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3080 ;	assignBit
      006692 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006694 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006697 E4               [12] 3084 	clr	a
      006698 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006699 90 07 73         [24] 3087 	mov	dptr,#_raw_state
      00669C F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      00669D 12 5A 8D         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0066A0 90 07 6D         [24] 3092 	mov	dptr,#_USB_SleepStatus
      0066A3 E4               [12] 3093 	clr	a
      0066A4 F0               [24] 3094 	movx	@dptr,a
      0066A5 90 07 6C         [24] 3095 	mov	dptr,#_USB_EnumStatus
      0066A8 F0               [24] 3096 	movx	@dptr,a
      0066A9 90 07 6B         [24] 3097 	mov	dptr,#_D0UsbConfig
      0066AC F0               [24] 3098 	movx	@dptr,a
      0066AD 90 22 07         [24] 3099 	mov	dptr,#0x2207
      0066B0 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0066B1 90 07 6E         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      0066B4 F0               [24] 3103 	movx	@dptr,a
      0066B5 90 07 6F         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      0066B8 F0               [24] 3105 	movx	@dptr,a
      0066B9 90 07 70         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      0066BC F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      0066BD 90 0D B2         [24] 3109 	mov	dptr,#_keyboard_protocol
      0066C0 04               [12] 3110 	inc	a
      0066C1 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      0066C2 90 06 43         [24] 3113 	mov	dptr,#_keyboard_idle
      0066C5 E4               [12] 3114 	clr	a
      0066C6 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      0066C7 90 07 95         [24] 3117 	mov	dptr,#_keyboard_reset
      0066CA F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      0066CB 90 07 C4         [24] 3120 	mov	dptr,#_control_phase
      0066CE F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      0066CF 90 07 65         [24] 3123 	mov	dptr,#_D0SetupReqCode
      0066D2 14               [12] 3124 	dec	a
      0066D3 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      0066D4 90 07 66         [24] 3127 	mov	dptr,#_D0SetupLen
      0066D7 E4               [12] 3128 	clr	a
      0066D8 F0               [24] 3129 	movx	@dptr,a
      0066D9 A3               [24] 3130 	inc	dptr
      0066DA F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066DB 90 22 00         [24] 3133 	mov	dptr,#0x2200
      0066DE 74 02            [12] 3134 	mov	a,#0x02
      0066E0 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      0066E1 90 22 37         [24] 3137 	mov	dptr,#0x2237
      0066E4 74 7F            [12] 3138 	mov	a,#0x7f
      0066E6 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      0066E7 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      0066EA 74 FF            [12] 3142 	mov	a,#0xff
      0066EC F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0066ED 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      0066F0 74 07            [12] 3146 	mov	a,#0x07
      0066F2 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      0066F3 A3               [24] 3149 	inc	dptr
      0066F4 74 80            [12] 3150 	mov	a,#0x80
      0066F6 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3153 ;	assignBit
      0066F7 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      0066F9 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      0066FA                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      0066FA 90 07 6D         [24] 3169 	mov	dptr,#_USB_SleepStatus
      0066FD E0               [24] 3170 	movx	a,@dptr
      0066FE FF               [12] 3171 	mov	r7,a
      0066FF BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006702 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      006705 E0               [24] 3175 	movx	a,@dptr
      006706 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006707 E0               [24] 3178 	movx	a,@dptr
      006708 FE               [12] 3179 	mov	r6,a
      006709 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      00670C 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      00670F EE               [12] 3182 	mov	a,r6
      006710 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006711 7E 0A            [12] 3185 	mov	r6,#0x0a
      006713                       3186 00108$:
      006713 EE               [12] 3187 	mov	a,r6
      006714 60 09            [24] 3188 	jz	00105$
      006716 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006719 12 58 D4         [24] 3190 	lcall	_mDelaymS
      00671C 1E               [12] 3191 	dec	r6
      00671D 80 F4            [24] 3192 	sjmp	00108$
      00671F                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      00671F 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      006722 EF               [12] 3196 	mov	a,r7
      006723 F0               [24] 3197 	movx	@dptr,a
      006724                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006724 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      006725                       3220 _ak820_usb_send:
      006725 E5 82            [12] 3221 	mov	a,dpl
      006727 90 07 D4         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00672A F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      00672B 90 07 D5         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00672E 74 2E            [12] 3226 	mov	a,#0x2e
      006730 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006731 90 07 D4         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006734 E0               [24] 3230 	movx	a,@dptr
      006735 FF               [12] 3231 	mov	r7,a
      006736 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006739                       3233 00306$:
      006739 40 14            [24] 3234 	jc	00101$
      00673B EF               [12] 3235 	mov	a,r7
      00673C 24 FC            [12] 3236 	add	a,#0xff - 0x03
      00673E 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006740 90 07 D3         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      006743 E0               [24] 3240 	movx	a,@dptr
      006744 FE               [12] 3241 	mov  r6,a
      006745 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006747 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006749 90 07 6C         [24] 3245 	mov	dptr,#_USB_EnumStatus
      00674C E0               [24] 3246 	movx	a,@dptr
      00674D 70 04            [24] 3247 	jnz	00102$
      00674F                       3248 00101$:
      00674F 75 82 00         [24] 3249 	mov	dpl, #0x00
      006752 22               [24] 3250 	ret
      006753                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006753 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006756 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006759 80 04            [24] 3256 	sjmp	00107$
      00675B                       3257 00313$:
      00675B 75 82 00         [24] 3258 	mov	dpl, #0x00
      00675E 22               [24] 3259 	ret
      00675F                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      00675F 90 07 D5         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006762 E4               [12] 3263 	clr	a
      006763 F0               [24] 3264 	movx	@dptr,a
      006764 80 3C            [24] 3265 	sjmp	00119$
      006766                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006766 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006769 90 07 D1         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      00676C E0               [24] 3271 	movx	a,@dptr
      00676D FD               [12] 3272 	mov	r5,a
      00676E A3               [24] 3273 	inc	dptr
      00676F E0               [24] 3274 	movx	a,@dptr
      006770 FF               [12] 3275 	mov	r7,a
      006771 8D 82            [24] 3276 	mov	dpl,r5
      006773 8F 83            [24] 3277 	mov	dph,r7
      006775 E0               [24] 3278 	movx	a,@dptr
      006776 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006777 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      00677A                       3282 00316$:
      00677A 50 0E            [24] 3283 	jnc	00108$
      00677C EF               [12] 3284 	mov	a,r7
      00677D 90 B9 E8         [24] 3285 	mov	dptr,#_shared_lengths
      006780 93               [24] 3286 	movc	a,@a+dptr
      006781 FD               [12] 3287 	mov	r5,a
      006782 60 06            [24] 3288 	jz	00108$
      006784 EE               [12] 3289 	mov	a,r6
      006785 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      006788 80 04            [24] 3291 	sjmp	00109$
      00678A                       3292 00319$:
      00678A                       3293 00108$:
      00678A 75 82 00         [24] 3294 	mov	dpl, #0x00
      00678D 22               [24] 3295 	ret
      00678E                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      00678E EF               [12] 3298 	mov	a,r7
      00678F 90 B9 E1         [24] 3299 	mov	dptr,#_shared_offsets
      006792 93               [24] 3300 	movc	a,@a+dptr
      006793 90 07 D5         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006796 F0               [24] 3302 	movx	@dptr,a
      006797 80 09            [24] 3303 	sjmp	00119$
      006799                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006799 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      00679C 80 04            [24] 3307 	sjmp	00119$
      00679E                       3308 00320$:
      00679E 75 82 00         [24] 3309 	mov	dpl, #0x00
      0067A1 22               [24] 3310 	ret
      0067A2                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      0067A2 90 07 6D         [24] 3313 	mov	dptr,#_USB_SleepStatus
      0067A5 E0               [24] 3314 	movx	a,@dptr
      0067A6 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      0067A9 12 66 FA         [24] 3316 	lcall	_USB_WakeUp_PC
      0067AC 75 82 00         [24] 3317 	mov	dpl, #0x00
      0067AF 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      0067B0                       3320 00184$:
      0067B0 7F FA            [12] 3321 	mov	r7,#0xfa
      0067B2                       3322 00127$:
      0067B2 90 07 D4         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0067B5 E0               [24] 3324 	movx	a,@dptr
      0067B6 FC               [12] 3325 	mov	r4,a
      0067B7 7D 00            [12] 3326 	mov	r5,#0x00
      0067B9 8C 02            [24] 3327 	mov	ar2,r4
      0067BB 74 22            [12] 3328 	mov	a,#0x22
      0067BD 2D               [12] 3329 	add	a, r5
      0067BE FB               [12] 3330 	mov	r3,a
      0067BF 8A 82            [24] 3331 	mov	dpl,r2
      0067C1 8B 83            [24] 3332 	mov	dph,r3
      0067C3 E0               [24] 3333 	movx	a,@dptr
      0067C4 54 03            [12] 3334 	anl	a,#0x03
      0067C6 70 14            [24] 3335 	jnz	00129$
      0067C8 8F 03            [24] 3336 	mov	ar3,r7
      0067CA 1F               [12] 3337 	dec	r7
      0067CB EB               [12] 3338 	mov	a,r3
      0067CC 60 0E            [24] 3339 	jz	00129$
      0067CE 7B 28            [12] 3340 	mov	r3,#0x28
      0067D0                       3341 00141$:
      0067D0 EB               [12] 3342 	mov	a,r3
      0067D1 60 DF            [24] 3343 	jz	00127$
      0067D3 90 00 01         [24] 3344 	mov	dptr,#0x0001
      0067D6 12 58 90         [24] 3345 	lcall	_mDelayuS
      0067D9 1B               [12] 3346 	dec	r3
      0067DA 80 F4            [24] 3347 	sjmp	00141$
      0067DC                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      0067DC A2 AF            [12] 3350 	mov	c,_EA
      0067DE E4               [12] 3351 	clr	a
      0067DF 33               [12] 3352 	rlc	a
      0067E0 FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3355 ;	assignBit
      0067E1 C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      0067E3 90 07 6C         [24] 3358 	mov	dptr,#_USB_EnumStatus
      0067E6 E0               [24] 3359 	movx	a,@dptr
      0067E7 60 25            [24] 3360 	jz	00130$
      0067E9 90 07 D4         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0067EC E0               [24] 3362 	movx	a,@dptr
      0067ED FB               [12] 3363 	mov	r3,a
      0067EE F9               [12] 3364 	mov	r1,a
      0067EF 7A 00            [12] 3365 	mov	r2,#0x00
      0067F1 74 22            [12] 3366 	mov	a,#0x22
      0067F3 2A               [12] 3367 	add	a, r2
      0067F4 FA               [12] 3368 	mov	r2,a
      0067F5 89 82            [24] 3369 	mov	dpl,r1
      0067F7 8A 83            [24] 3370 	mov	dph,r2
      0067F9 E0               [24] 3371 	movx	a,@dptr
      0067FA FA               [12] 3372 	mov	r2,a
      0067FB 53 02 03         [24] 3373 	anl	ar2,#0x03
      0067FE BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006801 BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006804 90 07 73         [24] 3377 	mov	dptr,#_raw_state
      006807 E0               [24] 3378 	movx	a,@dptr
      006808 FB               [12] 3379 	mov	r3,a
      006809 BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      00680C 80 09            [24] 3381 	sjmp	00192$
      00680E                       3382 00331$:
      00680E                       3383 00130$:
                                   3384 ;	assignBit
      00680E EF               [12] 3385 	mov	a,r7
      00680F 24 FF            [12] 3386 	add	a,#0xff
      006811 92 AF            [24] 3387 	mov	_EA,c
      006813 75 82 00         [24] 3388 	mov	dpl, #0x00
      006816 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006817                       3391 00192$:
      006817 7B 00            [12] 3392 	mov	r3,#0x00
      006819                       3393 00144$:
      006819 C3               [12] 3394 	clr	c
      00681A EB               [12] 3395 	mov	a,r3
      00681B 9E               [12] 3396 	subb	a,r6
      00681C 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      00681E C0 07            [24] 3399 	push	ar7
      006820 90 07 D4         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006823 E0               [24] 3401 	movx	a,@dptr
      006824 F9               [12] 3402 	mov	r1,a
      006825 E4               [12] 3403 	clr	a
      006826 C3               [12] 3404 	clr	c
      006827 C9               [12] 3405 	xch	a,r1
      006828 13               [12] 3406 	rrc	a
      006829 C9               [12] 3407 	xch	a,r1
      00682A 13               [12] 3408 	rrc	a
      00682B A2 E0            [12] 3409 	mov	c,acc.0
      00682D C9               [12] 3410 	xch	a,r1
      00682E 13               [12] 3411 	rrc	a
      00682F C9               [12] 3412 	xch	a,r1
      006830 13               [12] 3413 	rrc	a
      006831 C9               [12] 3414 	xch	a,r1
      006832 FA               [12] 3415 	mov	r2,a
      006833 8B 00            [24] 3416 	mov	ar0,r3
      006835 7F 00            [12] 3417 	mov	r7,#0x00
      006837 E8               [12] 3418 	mov	a,r0
      006838 29               [12] 3419 	add	a, r1
      006839 F9               [12] 3420 	mov	r1,a
      00683A EF               [12] 3421 	mov	a,r7
      00683B 3A               [12] 3422 	addc	a, r2
      00683C 24 10            [12] 3423 	add	a,#0x10
      00683E FA               [12] 3424 	mov	r2,a
      00683F 90 07 D1         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      006842 E0               [24] 3426 	movx	a,@dptr
      006843 F8               [12] 3427 	mov	r0,a
      006844 A3               [24] 3428 	inc	dptr
      006845 E0               [24] 3429 	movx	a,@dptr
      006846 FF               [12] 3430 	mov	r7,a
      006847 EB               [12] 3431 	mov	a,r3
      006848 28               [12] 3432 	add	a, r0
      006849 F5 1B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      00684B E4               [12] 3434 	clr	a
      00684C 3F               [12] 3435 	addc	a, r7
      00684D F5 1C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      00684F 85 1B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006852 85 1C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006855 E0               [24] 3439 	movx	a,@dptr
      006856 89 82            [24] 3440 	mov	dpl,r1
      006858 8A 83            [24] 3441 	mov	dph,r2
      00685A F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00685B 90 07 D5         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00685E E0               [24] 3445 	movx	a,@dptr
      00685F F5 1D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      006861 74 2E            [12] 3447 	mov	a,#0x2e
      006863 B5 1D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006866 D0 07            [24] 3449 	pop	ar7
      006868 80 18            [24] 3450 	sjmp	00145$
      00686A                       3451 00333$:
      00686A D0 07            [24] 3452 	pop	ar7
      00686C EB               [12] 3453 	mov	a,r3
      00686D 25 1D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      00686F 24 96            [12] 3455 	add	a, #_input_snapshot
      006871 F9               [12] 3456 	mov	r1,a
      006872 E4               [12] 3457 	clr	a
      006873 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      006875 FA               [12] 3459 	mov	r2,a
      006876 85 1B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006879 85 1C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00687C E0               [24] 3462 	movx	a,@dptr
      00687D 89 82            [24] 3463 	mov	dpl,r1
      00687F 8A 83            [24] 3464 	mov	dph,r2
      006881 F0               [24] 3465 	movx	@dptr,a
      006882                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006882 0B               [12] 3468 	inc	r3
      006883 80 94            [24] 3469 	sjmp	00144$
      006885                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006885 90 07 D4         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006888 E0               [24] 3473 	movx	a,@dptr
      006889 FB               [12] 3474 	mov	r3,a
      00688A F9               [12] 3475 	mov	r1,a
      00688B 7A 00            [12] 3476 	mov	r2,#0x00
      00688D 74 08            [12] 3477 	mov	a,#0x08
      00688F 29               [12] 3478 	add	a, r1
      006890 F9               [12] 3479 	mov	r1,a
      006891 74 22            [12] 3480 	mov	a,#0x22
      006893 3A               [12] 3481 	addc	a, r2
      006894 FA               [12] 3482 	mov	r2,a
      006895 89 82            [24] 3483 	mov	dpl,r1
      006897 8A 83            [24] 3484 	mov	dph,r2
      006899 EE               [12] 3485 	mov	a,r6
      00689A F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      00689B BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      00689E 90 07 73         [24] 3489 	mov	dptr,#_raw_state
      0068A1 74 04            [12] 3490 	mov	a,#0x04
      0068A3 F0               [24] 3491 	movx	@dptr,a
      0068A4                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0068A4 74 22            [12] 3494 	mov	a,#0x22
      0068A6 2D               [12] 3495 	add	a, r5
      0068A7 FD               [12] 3496 	mov	r5,a
      0068A8 8C 82            [24] 3497 	mov	dpl,r4
      0068AA 8D 83            [24] 3498 	mov	dph,r5
      0068AC E0               [24] 3499 	movx	a,@dptr
      0068AD FE               [12] 3500 	mov	r6,a
      0068AE 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      0068B1 8C 82            [24] 3502 	mov	dpl,r4
      0068B3 8D 83            [24] 3503 	mov	dph,r5
      0068B5 EE               [12] 3504 	mov	a,r6
      0068B6 F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3507 ;	assignBit
      0068B7 EF               [12] 3508 	mov	a,r7
      0068B8 24 FF            [12] 3509 	add	a,#0xff
      0068BA 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      0068BC 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      0068BF 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      0068C0                       3528 _ak820_usb_try_send:
      0068C0 E5 82            [12] 3529 	mov	a,dpl
      0068C2 90 07 D9         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068C5 F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      0068C6 A2 AF            [12] 3534 	mov	c,_EA
      0068C8 92 1C            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      0068CA 90 07 DA         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0068CD E4               [12] 3538 	clr	a
      0068CE F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3541 ;	assignBit
      0068CF C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0068D1 90 07 D9         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068D4 E0               [24] 3545 	movx	a,@dptr
      0068D5 FF               [12] 3546 	mov	r7,a
      0068D6 BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      0068D9                       3548 00152$:
      0068D9 40 4E            [24] 3549 	jc	00102$
      0068DB EF               [12] 3550 	mov	a,r7
      0068DC 24 FD            [12] 3551 	add	a,#0xff - 0x02
      0068DE 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      0068E0 90 07 6C         [24] 3554 	mov	dptr,#_USB_EnumStatus
      0068E3 E0               [24] 3555 	movx	a,@dptr
      0068E4 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      0068E6 90 07 6D         [24] 3558 	mov	dptr,#_USB_SleepStatus
      0068E9 E0               [24] 3559 	movx	a,@dptr
      0068EA 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      0068ED 90 07 95         [24] 3561 	mov	dptr,#_keyboard_reset
      0068F0 E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      0068F1 70 36            [24] 3564 	jnz	00102$
      0068F3 8F 06            [24] 3565 	mov	ar6,r7
      0068F5 24 22            [12] 3566 	add	a,#0x22
      0068F7 FD               [12] 3567 	mov	r5,a
      0068F8 8E 82            [24] 3568 	mov	dpl,r6
      0068FA 8D 83            [24] 3569 	mov	dph,r5
      0068FC E0               [24] 3570 	movx	a,@dptr
      0068FD FE               [12] 3571 	mov	r6,a
      0068FE 53 06 03         [24] 3572 	anl	ar6,#0x03
      006901 BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006904 90 07 D6         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006907 E0               [24] 3576 	movx	a,@dptr
      006908 FD               [12] 3577 	mov	r5,a
      006909 A3               [24] 3578 	inc	dptr
      00690A E0               [24] 3579 	movx	a,@dptr
      00690B FE               [12] 3580 	mov	r6,a
      00690C 90 07 D8         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      00690F E0               [24] 3582 	movx	a,@dptr
      006910 FC               [12] 3583 	mov	r4,a
      006911 90 07 D1         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      006914 ED               [12] 3585 	mov	a,r5
      006915 F0               [24] 3586 	movx	@dptr,a
      006916 EE               [12] 3587 	mov	a,r6
      006917 A3               [24] 3588 	inc	dptr
      006918 F0               [24] 3589 	movx	@dptr,a
      006919 90 07 D3         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      00691C EC               [12] 3591 	mov	a,r4
      00691D F0               [24] 3592 	movx	@dptr,a
      00691E 8F 82            [24] 3593 	mov	dpl, r7
      006920 12 67 25         [24] 3594 	lcall	_ak820_usb_send
      006923 E5 82            [12] 3595 	mov	a, dpl
      006925 90 07 DA         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006928 F0               [24] 3597 	movx	@dptr,a
      006929                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3600 ;	assignBit
      006929 A2 1C            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      00692B 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      00692D 90 07 DA         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006930 E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006931 F5 82            [12] 3607 	mov	dpl,a
      006933 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      006934                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006934 90 07 74         [24] 3618 	mov	dptr,#_raw_buffer
      006937 E0               [24] 3619 	movx	a,@dptr
      006938 FF               [12] 3620 	mov	r7,a
      006939 BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      00693C 80 35            [24] 3622 	sjmp	00108$
      00693E                       3623 00302$:
      00693E BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      006941 80 34            [24] 3625 	sjmp	00109$
      006943                       3626 00303$:
      006943 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      006946 80 2B            [24] 3628 	sjmp	00108$
      006948                       3629 00304$:
      006948 BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      00694B 80 47            [24] 3631 	sjmp	00116$
      00694D                       3632 00305$:
      00694D BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      006950 80 21            [24] 3634 	sjmp	00108$
      006952                       3635 00306$:
      006952 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      006955 80 1C            [24] 3637 	sjmp	00108$
      006957                       3638 00307$:
      006957 BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      00695A 80 17            [24] 3640 	sjmp	00108$
      00695C                       3641 00308$:
      00695C BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      00695F 80 12            [24] 3643 	sjmp	00108$
      006961                       3644 00309$:
      006961 BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      006964 80 0D            [24] 3646 	sjmp	00108$
      006966                       3647 00310$:
      006966 BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      006969 80 08            [24] 3649 	sjmp	00108$
      00696B                       3650 00311$:
      00696B BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      00696E 80 46            [24] 3652 	sjmp	00124$
      006970                       3653 00312$:
      006970 02 6A 0B         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006973                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006973 75 82 01         [24] 3658 	mov	dpl, #0x01
      006976 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006977                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006977 12 6C 3D         [24] 3663 	lcall	_ak820_outline_0164
      00697A BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      00697D 80 0D            [24] 3665 	sjmp	00113$
      00697F                       3666 00313$:
      00697F BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006982 80 08            [24] 3668 	sjmp	00113$
      006984                       3669 00314$:
      006984 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      006987 80 03            [24] 3671 	sjmp	00113$
      006989                       3672 00315$:
      006989 BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      00698C                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      00698C 75 82 01         [24] 3677 	mov	dpl, #0x01
      00698F 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006990                       3680 00114$:
      006990 75 82 00         [24] 3681 	mov	dpl, #0x00
      006993 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006994                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006994 12 6C 3D         [24] 3686 	lcall	_ak820_outline_0164
      006997 BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      00699A 80 12            [24] 3688 	sjmp	00121$
      00699C                       3689 00318$:
      00699C BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      00699F 80 0D            [24] 3691 	sjmp	00121$
      0069A1                       3692 00319$:
      0069A1 BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      0069A4 80 08            [24] 3694 	sjmp	00121$
      0069A6                       3695 00320$:
      0069A6 BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      0069A9 80 03            [24] 3697 	sjmp	00121$
      0069AB                       3698 00321$:
      0069AB BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      0069AE                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      0069AE 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      0069B1 22               [24] 3705 	ret
      0069B2                       3706 00122$:
      0069B2 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      0069B5 22               [24] 3709 	ret
      0069B6                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      0069B6 12 6C 3D         [24] 3712 	lcall	_ak820_outline_0164
      0069B9 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      0069BB 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      0069BD EF               [12] 3716 	mov	a,r7
      0069BE 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      0069C0 83               [24] 3718 	movc	a,@a+pc
      0069C1 F5 82            [12] 3719 	mov	dpl,a
      0069C3 EF               [12] 3720 	mov	a,r7
      0069C4 24 12            [12] 3721 	add	a,#(00326$-3-.)
      0069C6 83               [24] 3722 	movc	a,@a+pc
      0069C7 F5 83            [12] 3723 	mov	dph,a
      0069C9 E4               [12] 3724 	clr	a
      0069CA 73               [24] 3725 	jmp	@a+dptr
      0069CB                       3726 00325$:
      0069CB E7                    3727 	.db	00134$
      0069CC E7                    3728 	.db	00134$
      0069CD E7                    3729 	.db	00134$
      0069CE E7                    3730 	.db	00134$
      0069CF 07                    3731 	.db	00142$
      0069D0 E7                    3732 	.db	00134$
      0069D1 E7                    3733 	.db	00134$
      0069D2 E7                    3734 	.db	00134$
      0069D3 E7                    3735 	.db	00134$
      0069D4 E7                    3736 	.db	00134$
      0069D5 E7                    3737 	.db	00134$
      0069D6 07                    3738 	.db	00142$
      0069D7 07                    3739 	.db	00142$
      0069D8 EB                    3740 	.db	00135$
      0069D9                       3741 00326$:
      0069D9 69                    3742 	.db	00134$>>8
      0069DA 69                    3743 	.db	00134$>>8
      0069DB 69                    3744 	.db	00134$>>8
      0069DC 69                    3745 	.db	00134$>>8
      0069DD 6A                    3746 	.db	00142$>>8
      0069DE 69                    3747 	.db	00134$>>8
      0069DF 69                    3748 	.db	00134$>>8
      0069E0 69                    3749 	.db	00134$>>8
      0069E1 69                    3750 	.db	00134$>>8
      0069E2 69                    3751 	.db	00134$>>8
      0069E3 69                    3752 	.db	00134$>>8
      0069E4 6A                    3753 	.db	00142$>>8
      0069E5 6A                    3754 	.db	00142$>>8
      0069E6 69                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      0069E7                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      0069E7 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      0069EA 22               [24] 3761 	ret
      0069EB                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      0069EB 90 07 76         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      0069EE E0               [24] 3765 	movx	a,@dptr
      0069EF FF               [12] 3766 	mov	r7,a
      0069F0 60 0D            [24] 3767 	jz	00139$
      0069F2 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      0069F5 80 08            [24] 3769 	sjmp	00139$
      0069F7                       3770 00328$:
      0069F7 BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      0069FA 80 03            [24] 3772 	sjmp	00139$
      0069FC                       3773 00329$:
      0069FC BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      0069FF                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      0069FF 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006A02 22               [24] 3780 	ret
      006A03                       3781 00140$:
      006A03 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006A06 22               [24] 3784 	ret
      006A07                       3785 00142$:
      006A07 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006A0A 22               [24] 3788 	ret
      006A0B                       3789 00144$:
      006A0B 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006A0E 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      006A0F                       3804 _ak820_usb_raw_send:
      006A0F 12 43 15         [24] 3805 	lcall	_ak820_outline_0037
      006A12 90 07 DC         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006A15 12 38 29         [24] 3807 	lcall	_ak820_outline_0017
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006A18 90 07 DB         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006A1B E0               [24] 3810 	movx	a,@dptr
      006A1C FF               [12] 3811 	mov	r7,a
      006A1D BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006A20 C0 07            [24] 3814 	push	ar7
      006A22 12 3E 2B         [24] 3815 	lcall	_ak820_nvm_flush
      006A25 D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006A27 90 07 94         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      006A2A E0               [24] 3819 	movx	a,@dptr
      006A2B 70 07            [24] 3820 	jnz	00103$
      006A2D 12 3E 1C         [24] 3821 	lcall	_ak820_nvm_ok
      006A30 E5 82            [12] 3822 	mov	a, dpl
      006A32 60 17            [24] 3823 	jz	00106$
      006A34                       3824 00103$:
      006A34 90 07 DC         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006A37 12 38 6A         [24] 3826 	lcall	_ak820_outline_0084
      006A3A 90 07 D1         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      006A3D 12 43 78         [24] 3828 	lcall	_ak820_outline_0162
      006A40 90 07 D3         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      006A43 EF               [12] 3830 	mov	a,r7
      006A44 F0               [24] 3831 	movx	@dptr,a
      006A45 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006A48 02 67 25         [24] 3834 	ljmp	_ak820_usb_send
      006A4B                       3835 00106$:
      006A4B 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      006A4C                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006A4C A2 AF            [12] 3852 	mov	c,_EA
      006A4E E4               [12] 3853 	clr	a
      006A4F 33               [12] 3854 	rlc	a
      006A50 FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3857 ;	assignBit
      006A51 C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006A53 90 07 6C         [24] 3860 	mov	dptr,#_USB_EnumStatus
      006A56 E0               [24] 3861 	movx	a,@dptr
      006A57 60 0A            [24] 3862 	jz	00101$
      006A59 90 07 73         [24] 3863 	mov	dptr,#_raw_state
      006A5C E0               [24] 3864 	movx	a,@dptr
      006A5D FE               [12] 3865 	mov	r6,a
      006A5E BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      006A61 80 06            [24] 3867 	sjmp	00102$
      006A63                       3868 00270$:
      006A63                       3869 00101$:
                                   3870 ;	assignBit
      006A63 EF               [12] 3871 	mov	a,r7
      006A64 24 FF            [12] 3872 	add	a,#0xff
      006A66 92 AF            [24] 3873 	mov	_EA,c
      006A68 22               [24] 3874 	ret
      006A69                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006A69 90 07 73         [24] 3877 	mov	dptr,#_raw_state
      006A6C 74 03            [12] 3878 	mov	a,#0x03
      006A6E F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3881 ;	assignBit
      006A6F EF               [12] 3882 	mov	a,r7
      006A70 24 FF            [12] 3883 	add	a,#0xff
      006A72 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006A74 90 07 74         [24] 3886 	mov	dptr,#_raw_buffer
      006A77 E0               [24] 3887 	movx	a,@dptr
      006A78 FF               [12] 3888 	mov	r7,a
      006A79 E4               [12] 3889 	clr	a
      006A7A BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006A7D 04               [12] 3891 	inc	a
      006A7E                       3892 00271$:
      006A7E FF               [12] 3893 	mov	r7,a
      006A7F 70 03            [24] 3894 	jnz	00273$
      006A81 02 6B 21         [24] 3895 	ljmp	00118$
      006A84                       3896 00273$:
      006A84 90 07 75         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      006A87 E0               [24] 3898 	movx	a,@dptr
      006A88 60 03            [24] 3899 	jz	00274$
      006A8A 02 6B 21         [24] 3900 	ljmp	00118$
      006A8D                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006A8D 90 07 76         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006A90 E0               [24] 3904 	movx	a,@dptr
      006A91 FD               [12] 3905 	mov	r5,a
      006A92 7E 00            [12] 3906 	mov	r6,#0x00
      006A94 90 07 77         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      006A97 E0               [24] 3908 	movx	a,@dptr
      006A98 7B 00            [12] 3909 	mov	r3,#0x00
      006A9A 42 06            [12] 3910 	orl	ar6,a
      006A9C EB               [12] 3911 	mov	a,r3
      006A9D 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006A9F 90 07 78         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006AA2 E0               [24] 3915 	movx	a,@dptr
      006AA3 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006AA4 7B 05            [12] 3918 	mov	r3,#0x05
      006AA6                       3919 00128$:
      006AA6 EB               [12] 3920 	mov	a,r3
      006AA7 12 6C 2B         [24] 3921 	lcall	_ak820_outline_0104
      006AAA 0B               [12] 3922 	inc	r3
      006AAB BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006AAE                       3924 00275$:
      006AAE 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006AB0 EC               [12] 3927 	mov	a,r4
      006AB1 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006AB3 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      006AB5 EC               [12] 3931 	mov	a,r4
      006AB6 60 26            [24] 3932 	jz	00165$
      006AB8 8C 03            [24] 3933 	mov	ar3,r4
      006ABA 1B               [12] 3934 	dec	r3
      006ABB 7A 00            [12] 3935 	mov	r2,#0x00
      006ABD 74 FF            [12] 3936 	mov	a,#0xff
      006ABF C3               [12] 3937 	clr	c
      006AC0 9B               [12] 3938 	subb	a,r3
      006AC1 FB               [12] 3939 	mov	r3,a
      006AC2 74 FF            [12] 3940 	mov	a,#0xff
      006AC4 9A               [12] 3941 	subb	a,r2
      006AC5 FA               [12] 3942 	mov	r2,a
      006AC6 8E 00            [24] 3943 	mov	ar0,r6
      006AC8 8D 01            [24] 3944 	mov	ar1,r5
      006ACA C3               [12] 3945 	clr	c
      006ACB EB               [12] 3946 	mov	a,r3
      006ACC 98               [12] 3947 	subb	a,r0
      006ACD EA               [12] 3948 	mov	a,r2
      006ACE 99               [12] 3949 	subb	a,r1
      006ACF 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006AD1                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006AD1 90 07 75         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006AD4 74 FF            [12] 3955 	mov	a,#0xff
      006AD6 F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006AD7 90 07 78         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      006ADA E4               [12] 3959 	clr	a
      006ADB F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006ADC 80 3A            [24] 3962 	sjmp	00108$
      006ADE                       3963 00165$:
      006ADE 7B 00            [12] 3964 	mov	r3,#0x00
      006AE0                       3965 00131$:
      006AE0 C3               [12] 3966 	clr	c
      006AE1 EB               [12] 3967 	mov	a,r3
      006AE2 9C               [12] 3968 	subb	a,r4
      006AE3 50 33            [24] 3969 	jnc	00108$
      006AE5 C0 04            [24] 3970 	push	ar4
      006AE7 8B 02            [24] 3971 	mov	ar2,r3
      006AE9 74 05            [12] 3972 	mov	a,#0x05
      006AEB 2A               [12] 3973 	add	a, r2
      006AEC F9               [12] 3974 	mov	r1,a
      006AED 33               [12] 3975 	rlc	a
      006AEE 95 E0            [12] 3976 	subb	a,acc
      006AF0 FA               [12] 3977 	mov	r2,a
      006AF1 E9               [12] 3978 	mov	a,r1
      006AF2 24 74            [12] 3979 	add	a, #_raw_buffer
      006AF4 F9               [12] 3980 	mov	r1,a
      006AF5 EA               [12] 3981 	mov	a,r2
      006AF6 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      006AF8 FA               [12] 3983 	mov	r2,a
      006AF9 8B 1E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006AFB 75 1F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006AFE 8E 00            [24] 3986 	mov	ar0,r6
      006B00 8D 04            [24] 3987 	mov	ar4,r5
      006B02 E5 1E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006B04 28               [12] 3989 	add	a, r0
      006B05 F8               [12] 3990 	mov	r0,a
      006B06 E5 1F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006B08 3C               [12] 3992 	addc	a, r4
      006B09 FC               [12] 3993 	mov	r4,a
      006B0A 88 82            [24] 3994 	mov	dpl,r0
      006B0C 8C 83            [24] 3995 	mov	dph,r4
      006B0E E4               [12] 3996 	clr	a
      006B0F 93               [24] 3997 	movc	a,@a+dptr
      006B10 12 6C 37         [24] 3998 	lcall	_ak820_outline_0139
      006B13 0B               [12] 3999 	inc	r3
      006B14 D0 04            [24] 4000 	pop	ar4
      006B16 80 C8            [24] 4001 	sjmp	00131$
      006B18                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B18 12 6C 17         [24] 4004 	lcall	_ak820_outline_0045
      006B1B 12 67 25         [24] 4005 	lcall	_ak820_usb_send
      006B1E 02 6B C7         [24] 4006 	ljmp	00119$
      006B21                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006B21 EF               [12] 4009 	mov	a,r7
      006B22 70 03            [24] 4010 	jnz	00281$
      006B24 02 6B A4         [24] 4011 	ljmp	00114$
      006B27                       4012 00281$:
      006B27 12 6C 3D         [24] 4013 	lcall	_ak820_outline_0164
      006B2A BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      006B2D 80 03            [24] 4015 	sjmp	00283$
      006B2F                       4016 00282$:
      006B2F 02 6B A4         [24] 4017 	ljmp	00114$
      006B32                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006B32 7F 02            [12] 4020 	mov	r7,#0x02
      006B34                       4021 00133$:
      006B34 EF               [12] 4022 	mov	a,r7
      006B35 12 6C 2B         [24] 4023 	lcall	_ak820_outline_0104
      006B38 0F               [12] 4024 	inc	r7
      006B39 BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      006B3C                       4026 00284$:
      006B3C 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006B3E 90 07 76         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      006B41 74 01            [12] 4030 	mov	a,#0x01
      006B43 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006B44 90 07 77         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      006B47 74 A8            [12] 4034 	mov	a,#0xa8
      006B49 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006B4A 90 07 78         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      006B4D 12 3B 97         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006B50 7F 00            [12] 4040 	mov	r7,#0x00
      006B52                       4041 00135$:
      006B52 8F 06            [24] 4042 	mov	ar6,r7
      006B54 74 0B            [12] 4043 	mov	a,#0x0b
      006B56 2E               [12] 4044 	add	a, r6
      006B57 24 74            [12] 4045 	add	a,#_raw_buffer
      006B59 FE               [12] 4046 	mov	r6,a
      006B5A E4               [12] 4047 	clr	a
      006B5B 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      006B5D FD               [12] 4049 	mov	r5,a
      006B5E EF               [12] 4050 	mov	a,r7
      006B5F 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      006B61 F5 82            [12] 4052 	mov	dpl,a
      006B63 E4               [12] 4053 	clr	a
      006B64 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006B66 F5 83            [12] 4055 	mov	dph,a
      006B68 E0               [24] 4056 	movx	a,@dptr
      006B69 8E 82            [24] 4057 	mov	dpl,r6
      006B6B 8D 83            [24] 4058 	mov	dph,r5
      006B6D F0               [24] 4059 	movx	@dptr,a
      006B6E 0F               [12] 4060 	inc	r7
      006B6F BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006B72                       4062 00286$:
      006B72 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006B74 90 0E 20         [24] 4065 	mov	dptr,#_vial_unlocked
      006B77 E0               [24] 4066 	movx	a,@dptr
      006B78 90 07 85         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006B7B F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006B7C 90 0E 21         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006B7F E0               [24] 4071 	movx	a,@dptr
      006B80 90 07 86         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006B83 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006B84 90 07 6C         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006B87 E0               [24] 4076 	movx	a,@dptr
      006B88 90 07 87         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006B8B F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006B8C 90 07 6D         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006B8F E0               [24] 4081 	movx	a,@dptr
      006B90 90 07 88         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006B93 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006B94 90 07 73         [24] 4085 	mov	dptr,#_raw_state
      006B97 E0               [24] 4086 	movx	a,@dptr
      006B98 90 07 89         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006B9B F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B9C 12 6C 17         [24] 4090 	lcall	_ak820_outline_0045
      006B9F 12 67 25         [24] 4091 	lcall	_ak820_usb_send
      006BA2 80 23            [24] 4092 	sjmp	00119$
      006BA4                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006BA4 12 69 34         [24] 4095 	lcall	_raw_request_is_nonpersistent
      006BA7 E5 82            [12] 4096 	mov	a, dpl
      006BA9 90 07 94         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      006BAC F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006BAD 12 3F 7E         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006BB0 90 0C 52         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      006BB3 74 20            [12] 4103 	mov	a,#0x20
      006BB5 F0               [24] 4104 	movx	@dptr,a
      006BB6 90 07 74         [24] 4105 	mov	dptr,#_raw_buffer
      006BB9 75 F0 00         [24] 4106 	mov	b, #0x00
      006BBC 12 A7 10         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006BBF 12 3F 93         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006BC2 90 07 94         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      006BC5 E4               [12] 4112 	clr	a
      006BC6 F0               [24] 4113 	movx	@dptr,a
      006BC7                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4116 ;	assignBit
      006BC7 A2 AF            [12] 4117 	mov	c,_EA
      006BC9 92 1D            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4120 ;	assignBit
      006BCB C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006BCD 12 6C 43         [24] 4123 	lcall	_ak820_outline_0166
      006BD0 BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      006BD3 90 07 73         [24] 4125 	mov	dptr,#_raw_state
      006BD6 74 05            [12] 4126 	mov	a,#0x05
      006BD8 F0               [24] 4127 	movx	@dptr,a
      006BD9 80 1B            [24] 4128 	sjmp	00127$
      006BDB                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006BDB 12 6C 43         [24] 4131 	lcall	_ak820_outline_0166
      006BDE BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      006BE1 80 0E            [24] 4133 	sjmp	00121$
      006BE3                       4134 00290$:
      006BE3 12 6C 43         [24] 4135 	lcall	_ak820_outline_0166
      006BE6 BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      006BE9 80 06            [24] 4137 	sjmp	00121$
      006BEB                       4138 00291$:
      006BEB 12 6C 43         [24] 4139 	lcall	_ak820_outline_0166
      006BEE BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      006BF1                       4141 00121$:
      006BF1 90 07 73         [24] 4142 	mov	dptr,#_raw_state
      006BF4 E4               [12] 4143 	clr	a
      006BF5 F0               [24] 4144 	movx	@dptr,a
      006BF6                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4147 ;	assignBit
      006BF6 A2 1D            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006BF8 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006BFA 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      006BFB                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      006BFB A2 AF            [12] 4165 	mov	c,_EA
      006BFD 92 1E            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4168 ;	assignBit
      006BFF C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006C01 90 07 95         [24] 4171 	mov	dptr,#_keyboard_reset
      006C04 E0               [24] 4172 	movx	a,@dptr
      006C05 FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006C06 E4               [12] 4175 	clr	a
      006C07 F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4178 ;	assignBit
      006C08 A2 1E            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006C0A 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006C0C EF               [12] 4182 	mov	a,r7
      006C0D B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      006C10                       4184 00103$:
      006C10 B3               [12] 4185 	cpl	c
      006C11 92 1E            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006C13 12 38 B1         [24] 4187 	lcall	_ak820_outline_0156
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006C16 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00B9E1                       4193 _shared_offsets:
      00B9E1 00                    4194 	.db #0x00	; 0
      00B9E2 00                    4195 	.db #0x00	; 0
      00B9E3 28                    4196 	.db #0x28	; 40
      00B9E4 28                    4197 	.db #0x28	; 40
      00B9E5 2B                    4198 	.db #0x2b	; 43
      00B9E6 00                    4199 	.db #0x00	; 0
      00B9E7 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00B9E8                       4203 _shared_lengths:
      00B9E8 00                    4204 	.db #0x00	; 0
      00B9E9 00                    4205 	.db #0x00	; 0
      00B9EA 00                    4206 	.db #0x00	; 0
      00B9EB 03                    4207 	.db #0x03	; 3
      00B9EC 03                    4208 	.db #0x03	; 3
      00B9ED 00                    4209 	.db #0x00	; 0
      00B9EE 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00B9EF                       4213 _interface_descriptors:
      00B9EF 8A BF                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00B9F1 8A C0                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00B9F3 3D C0                 4216 	.byte _RawReport, (_RawReport >> 8)
      00B9F5 A3 C0                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00B9F7 CF BF                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00B9F9 BC C0                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0017
                                   4226 	.globl _ak820_outline_0037
                                   4227 	.globl _ak820_outline_0045
                                   4228 	.globl _ak820_outline_0084
                                   4229 	.globl _ak820_outline_0104
                                   4230 	.globl _ak820_outline_0139
                                   4231 	.globl _ak820_outline_0156
                                   4232 	.globl _ak820_outline_0162
                                   4233 	.globl _ak820_outline_0164
                                   4234 	.globl _ak820_outline_0166
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0045
      006C17                       4238 _ak820_outline_0045:
      006C17 90 07 D1         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      006C1A 74 74            [12] 4240 	mov	a,#_raw_buffer
      006C1C F0               [24] 4241 	movx	@dptr,a
      006C1D 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      006C1F A3               [24] 4243 	inc	dptr
      006C20 F0               [24] 4244 	movx	@dptr,a
      006C21 90 07 D3         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      006C24 74 20            [12] 4246 	mov	a,#0x20
      006C26 F0               [24] 4247 	movx	@dptr,a
      006C27 75 82 03         [24] 4248 	mov	dpl,#0x03
      006C2A 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0104
      006C2B                       4253 _ak820_outline_0104:
      006C2B 24 74            [12] 4254 	add	a,#_raw_buffer
      006C2D F5 82            [12] 4255 	mov	dpl,a
      006C2F E4               [12] 4256 	clr	a
      006C30 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      006C32 F5 83            [12] 4258 	mov	dph,a
      006C34 E4               [12] 4259 	clr	a
      006C35 F0               [24] 4260 	movx	@dptr,a
      006C36 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0139
      006C37                       4265 _ak820_outline_0139:
      006C37 89 82            [24] 4266 	mov	dpl,r1
      006C39 8A 83            [24] 4267 	mov	dph,r2
      006C3B F0               [24] 4268 	movx	@dptr,a
      006C3C 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0164
      006C3D                       4273 _ak820_outline_0164:
      006C3D 90 07 75         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      006C40 E0               [24] 4275 	movx	a,@dptr
      006C41 FF               [12] 4276 	mov	r7,a
      006C42 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0166
      006C43                       4281 _ak820_outline_0166:
      006C43 90 07 73         [24] 4282 	mov	dptr,#_raw_state
      006C46 E0               [24] 4283 	movx	a,@dptr
      006C47 FF               [12] 4284 	mov	r7,a
      006C48 22               [24] 4285 	ret
