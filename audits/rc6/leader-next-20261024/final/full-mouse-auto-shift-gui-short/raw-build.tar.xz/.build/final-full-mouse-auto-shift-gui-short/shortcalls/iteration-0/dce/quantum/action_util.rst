                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000021                        568 _gui_disabled:
      000021                        569 	.ds 1
      000022                        570 _ak820_gui_process_sloc0_1_0:
      000022                        571 	.ds 1
      000023                        572 _ak820_macro_change_sloc0_1_0:
      000023                        573 	.ds 1
      000024                        574 _change_owned_sloc0_1_0:
      000024                        575 	.ds 1
      000025                        576 _owned_usage_key_sloc0_1_0:
      000025                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      00099D                        586 _ak820_gui_process_PARM_2:
      00099D                        587 	.ds 1
      00099E                        588 _ak820_gui_process_code_10000_295:
      00099E                        589 	.ds 2
      0009A0                        590 _owned_mod_refs:
      0009A0                        591 	.ds 8
      0009A8                        592 _owned_weak_refs:
      0009A8                        593 	.ds 8
      0009B0                        594 _owned_mods:
      0009B0                        595 	.ds 1
      0009B1                        596 _owned_weak_mods:
      0009B1                        597 	.ds 1
      0009B2                        598 _macro_mods:
      0009B2                        599 	.ds 2
      0009B4                        600 _ak820_macro_primitive::
      0009B4                        601 	.ds 1
      0009B5                        602 _ak820_macro_cancelled::
      0009B5                        603 	.ds 1
      0009B6                        604 _ak820_macro_change_PARM_2:
      0009B6                        605 	.ds 1
      0009B7                        606 _ak820_macro_change_PARM_3:
      0009B7                        607 	.ds 1
      0009B8                        608 _ak820_macro_change_bits_10000_300:
      0009B8                        609 	.ds 2
      0009BA                        610 _change_owned_PARM_2:
      0009BA                        611 	.ds 1
      0009BB                        612 _change_owned_mods_10000_305:
      0009BB                        613 	.ds 1
      0009BC                        614 _change_owned_result_10001_309:
      0009BC                        615 	.ds 1
      0009BD                        616 _change_owned_bit_20001_310:
      0009BD                        617 	.ds 1
      0009BE                        618 _add_owned_mods_mods_10000_318:
      0009BE                        619 	.ds 1
      0009BF                        620 _del_owned_mods_mods_10000_320:
      0009BF                        621 	.ds 1
      0009C0                        622 _add_owned_weak_mods_mods_10000_322:
      0009C0                        623 	.ds 1
      0009C1                        624 _del_owned_weak_mods_mods_10000_324:
      0009C1                        625 	.ds 1
      0009C2                        626 _key_refs:
      0009C2                        627 	.ds 165
      000A67                        628 _distinct_keys:
      000A67                        629 	.ds 1
      000A68                        630 _macro_keys:
      000A68                        631 	.ds 21
      000A7D                        632 _add_owned_key_code_10000_333:
      000A7D                        633 	.ds 1
      000A7E                        634 _del_owned_key_code_10000_348:
      000A7E                        635 	.ds 1
      000A7F                        636 _usage_refs:
      000A7F                        637 	.ds 30
      000A9D                        638 _usage_order:
      000A9D                        639 	.ds 30
      000ABB                        640 _usage_lengths:
      000ABB                        641 	.ds 2
      000ABD                        642 _macro_usages:
      000ABD                        643 	.ds 4
      000AC1                        644 _owned_usage_key_PARM_2:
      000AC1                        645 	.ds 1
      000AC2                        646 _owned_usage_key_code_10000_375:
      000AC2                        647 	.ds 1
      000AC3                        648 _owned_usage_key___200000085_20000_376:
      000AC3                        649 	.ds 2
      000AC5                        650 _owned_usage_key_which_10000_376:
      000AC5                        651 	.ds 1
      000AC6                        652 _owned_usage_key_count_10000_376:
      000AC6                        653 	.ds 1
      000AC7                        654 _owned_usage_key_pos_30001_383:
      000AC7                        655 	.ds 1
      000AC8                        656 _owned_usage_key_key_40000_388:
      000AC8                        657 	.ds 1
      000AC9                        658 _send_keyboard_report_last_report_10001_396:
      000AC9                        659 	.ds 32
      000AE9                        660 _send_keyboard_report_changed_10001_396:
      000AE9                        661 	.ds 1
      000AEA                        662 _add_weak_mods_mods_10000_414:
      000AEA                        663 	.ds 1
      000AEB                        664 _del_weak_mods_mods_10000_416:
      000AEB                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DF2                        674 _real_mods:
      000DF2                        675 	.ds 1
      000DF3                        676 _weak_mods:
      000DF3                        677 	.ds 1
      000DF4                        678 _actual_keyboard_report::
      000DF4                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      008057                        723 _ak820_gui_process:
      008057 12 3A C2         [24]  724 	lcall	_ak820_outline_0107
      00805A 90 09 9E         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_295
      00805D 12 3A C7         [24]  726 	lcall	_ak820_outline_0108
                                    727 ;	quantum/action_util.c:60: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      008060 90 09 9E         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_295
      008063 12 3A 81         [24]  729 	lcall	_ak820_outline_0051
      008066 C3               [12]  730 	clr	c
      008067 EE               [12]  731 	mov	a,r6
      008068 94 09            [12]  732 	subb	a,#0x09
      00806A EF               [12]  733 	mov	a,r7
      00806B 94 70            [12]  734 	subb	a,#0x70
      00806D 40 08            [24]  735 	jc	00101$
      00806F 74 0B            [12]  736 	mov	a,#0x0b
      008071 9E               [12]  737 	subb	a,r6
      008072 74 70            [12]  738 	mov	a,#0x70
      008074 9F               [12]  739 	subb	a,r7
      008075 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      008077                        742 00101$:
      008077 75 82 01         [24]  743 	mov	dpl, #0x01
      00807A 22               [24]  744 	ret
      00807B                        745 00102$:
                                    746 ;	quantum/action_util.c:61: if (pressed) {
      00807B 90 09 9D         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      00807E E0               [24]  748 	movx	a,@dptr
      00807F 60 20            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:62: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      008081 BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      008084 BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      008087 A2 21            [12]  753 	mov	c,_gui_disabled
      008089 B3               [12]  754 	cpl	c
      00808A 92 22            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      00808C E4               [12]  756 	clr	a
      00808D 33               [12]  757 	rlc	a
      00808E FD               [12]  758 	mov	r5,a
      00808F 80 09            [24]  759 	sjmp	00109$
      008091                        760 00108$:
      008091 E4               [12]  761 	clr	a
      008092 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      008095 BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      008098 04               [12]  764 	inc	a
      008099                        765 00136$:
      008099 FD               [12]  766 	mov	r5,a
      00809A                        767 00109$:
                                    768 ;	assignBit
      00809A ED               [12]  769 	mov	a,r5
      00809B 24 FF            [12]  770 	add	a,#0xff
      00809D 92 21            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:63: send_keyboard_report();
      00809F B1 14            [12]  773 	acall	_send_keyboard_report
      0080A1                        774 00105$:
                                    775 ;	quantum/action_util.c:65: return false;
      0080A1 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:69: }
      0080A4 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_300'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_303'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:78: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      0080A5                        791 _ak820_macro_change:
      0080A5 12 3A C2         [24]  792 	lcall	_ak820_outline_0107
      0080A8 90 09 B8         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080AB 12 3A C7         [24]  794 	lcall	_ak820_outline_0108
                                    795 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      0080AE 90 09 B4         [24]  796 	mov	dptr,#_ak820_macro_primitive
      0080B1 E0               [24]  797 	movx	a,@dptr
      0080B2 70 04            [24]  798 	jnz	00102$
      0080B4 75 82 01         [24]  799 	mov	dpl, #0x01
      0080B7 22               [24]  800 	ret
      0080B8                        801 00102$:
                                    802 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      0080B8 90 09 B6         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      0080BB E0               [24]  804 	movx	a,@dptr
      0080BC FF               [12]  805 	mov	r7,a
      0080BD 74 07            [12]  806 	mov	a,#0x07
      0080BF 5F               [12]  807 	anl	a,r7
      0080C0 12 7B FC         [24]  808 	lcall	_ak820_outline_0061
      0080C3 80 02            [24]  809 	sjmp	00123$
      0080C5                        810 00122$:
      0080C5 25 E0            [12]  811 	add	a,acc
      0080C7                        812 00123$:
      0080C7 D5 F0 FB         [24]  813 	djnz	b,00122$
      0080CA FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:81: bits += index >> 3;
      0080CB EF               [12]  816 	mov	a,r7
      0080CC 12 5B FB         [24]  817 	lcall	_ak820_outline_0188
      0080CF FF               [12]  818 	mov	r7,a
      0080D0 90 09 B8         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080D3 12 3A 98         [24]  820 	lcall	_ak820_outline_0059
      0080D6 90 09 B8         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080D9 EF               [12]  822 	mov	a,r7
      0080DA 2C               [12]  823 	add	a, r4
      0080DB F0               [24]  824 	movx	@dptr,a
      0080DC E4               [12]  825 	clr	a
      0080DD 3D               [12]  826 	addc	a, r5
      0080DE A3               [24]  827 	inc	dptr
      0080DF F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      0080E0 90 09 B8         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080E3 E0               [24]  831 	movx	a,@dptr
      0080E4 FD               [12]  832 	mov	r5,a
      0080E5 A3               [24]  833 	inc	dptr
      0080E6 E0               [24]  834 	movx	a,@dptr
      0080E7 FF               [12]  835 	mov	r7,a
      0080E8 12 86 2D         [24]  836 	lcall	_ak820_outline_0190
      0080EB E0               [24]  837 	movx	a,@dptr
      0080EC FC               [12]  838 	mov	r4,a
      0080ED EE               [12]  839 	mov	a,r6
      0080EE 5C               [12]  840 	anl	a,r4
      0080EF B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      0080F2                        842 00124$:
      0080F2 B3               [12]  843 	cpl	c
      0080F3 92 23            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      0080F5 90 09 B7         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      0080F8 E0               [24]  846 	movx	a,@dptr
      0080F9 FB               [12]  847 	mov	r3,a
      0080FA A2 23            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      0080FC E4               [12]  849 	clr	a
      0080FD 33               [12]  850 	rlc	a
      0080FE B5 03 04         [24]  851 	cjne	a,ar3,00104$
      008101 75 82 00         [24]  852 	mov	dpl, #0x00
      008104 22               [24]  853 	ret
      008105                        854 00104$:
                                    855 ;	quantum/action_util.c:83: *bits ^= mask;
      008105 EC               [12]  856 	mov	a,r4
      008106 62 06            [12]  857 	xrl	ar6,a
      008108 12 86 2D         [24]  858 	lcall	_ak820_outline_0190
      00810B EE               [12]  859 	mov	a,r6
      00810C F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:84: return true;
      00810D 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:85: }
      008110 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_305'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_306'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_306'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_306'
                                    873 ;old           Allocated with name '_change_owned_old_30000_308'
                                    874 ;result        Allocated with name '_change_owned_result_10001_309'
                                    875 ;i             Allocated with name '_change_owned_i_20001_310'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_310'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      008111                        883 _change_owned:
      008111 E5 82            [12]  884 	mov	a,dpl
      008113 90 09 BB         [24]  885 	mov	dptr,#_change_owned_mods_10000_305
      008116 F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      008117 90 09 BA         [24]  888 	mov	dptr,#_change_owned_PARM_2
      00811A E0               [24]  889 	movx	a,@dptr
      00811B FF               [12]  890 	mov	r7,a
      00811C C3               [12]  891 	clr	c
      00811D 13               [12]  892 	rrc	a
      00811E FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      00811F 53 07 01         [24]  895 	anl	ar7,#0x01
      008122 EF               [12]  896 	mov	a,r7
      008123 B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      008126                        898 00205$:
      008126 92 24            [24]  899 	mov  _change_owned_sloc0_1_0,c
      008128 B3               [12]  900 	cpl	c
      008129 E4               [12]  901 	clr	a
      00812A 33               [12]  902 	rlc	a
      00812B F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00812D EE               [12]  905 	mov	a,r6
      00812E 60 06            [24]  906 	jz	00121$
      008130 7D A8            [12]  907 	mov	r5,#_owned_weak_refs
      008132 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      008134 80 04            [24]  909 	sjmp	00122$
      008136                        910 00121$:
      008136 7D A0            [12]  911 	mov	r5,#_owned_mod_refs
      008138 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      00813A                        913 00122$:
                                    914 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      00813A 90 09 B4         [24]  915 	mov	dptr,#_ak820_macro_primitive
      00813D E0               [24]  916 	movx	a,@dptr
      00813E 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      008140 EE               [12]  919 	mov	a,r6
      008141 24 B2            [12]  920 	add	a, #_macro_mods
      008143 FB               [12]  921 	mov	r3,a
      008144 E4               [12]  922 	clr	a
      008145 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      008147 FC               [12]  924 	mov	r4,a
      008148 12 4A D1         [24]  925 	lcall	_ak820_outline_0063
                                    926 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00814B E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      00814D 60 0A            [24]  928 	jz	00123$
      00814F 90 09 BB         [24]  929 	mov	dptr,#_change_owned_mods_10000_305
      008152 E0               [24]  930 	movx	a,@dptr
      008153 F9               [12]  931 	mov	r1,a
      008154 EA               [12]  932 	mov	a,r2
      008155 42 01            [12]  933 	orl	ar1,a
      008157 80 07            [24]  934 	sjmp	00124$
      008159                        935 00123$:
      008159 90 09 BB         [24]  936 	mov	dptr,#_change_owned_mods_10000_305
      00815C E0               [24]  937 	movx	a,@dptr
      00815D F4               [12]  938 	cpl	a
      00815E 5A               [12]  939 	anl	a,r2
      00815F F9               [12]  940 	mov	r1,a
      008160                        941 00124$:
      008160 12 36 47         [24]  942 	lcall	_ak820_outline_0123
      008163 E9               [12]  943 	mov	a,r1
      008164 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      008165 E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      008167 60 06            [24]  947 	jz	00125$
      008169 74 FF            [12]  948 	mov	a,#0xff
      00816B 6A               [12]  949 	xrl	a,r2
      00816C FC               [12]  950 	mov	r4,a
      00816D 80 02            [24]  951 	sjmp	00126$
      00816F                        952 00125$:
      00816F 8A 04            [24]  953 	mov	ar4,r2
      008171                        954 00126$:
      008171 90 09 BB         [24]  955 	mov	dptr,#_change_owned_mods_10000_305
      008174 E0               [24]  956 	movx	a,@dptr
      008175 5C               [12]  957 	anl	a,r4
      008176 F0               [24]  958 	movx	@dptr,a
      008177                        959 00102$:
                                    960 ;	quantum/action_util.c:95: uint8_t result = 0;
      008177 90 09 BC         [24]  961 	mov	dptr,#_change_owned_result_10001_309
      00817A E4               [12]  962 	clr	a
      00817B F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00817C 90 09 BD         [24]  965 	mov	dptr,#_change_owned_bit_20001_310
      00817F 04               [12]  966 	inc	a
      008180 F0               [24]  967 	movx	@dptr,a
      008181 90 09 BB         [24]  968 	mov	dptr,#_change_owned_mods_10000_305
      008184 E0               [24]  969 	movx	a,@dptr
      008185 FC               [12]  970 	mov	r4,a
      008186 7B 00            [12]  971 	mov	r3,#0x00
      008188                        972 00117$:
      008188 BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      00818B                        974 00210$:
      00818B 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:97: if (mods & bit) {
      00818D 90 09 BD         [24]  977 	mov	dptr,#_change_owned_bit_20001_310
      008190 E0               [24]  978 	movx	a,@dptr
      008191 5C               [12]  979 	anl	a,r4
      008192 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      008194 E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      008196 60 0C            [24]  983 	jz	00106$
      008198 EB               [12]  984 	mov	a,r3
      008199 2D               [12]  985 	add	a, r5
      00819A 12 3A 5F         [24]  986 	lcall	_ak820_outline_0016
      00819D F8               [12]  987 	mov	r0,a
      00819E 08               [12]  988 	inc	r0
      00819F 12 85 E1         [24]  989 	lcall	_ak820_outline_0062
      0081A2 80 0C            [24]  990 	sjmp	00109$
      0081A4                        991 00106$:
                                    992 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      0081A4 EB               [12]  993 	mov	a,r3
      0081A5 2D               [12]  994 	add	a, r5
      0081A6 12 3A 5F         [24]  995 	lcall	_ak820_outline_0016
      0081A9 F8               [12]  996 	mov	r0,a
      0081AA 60 04            [24]  997 	jz	00109$
      0081AC 18               [12]  998 	dec	r0
      0081AD 12 85 E1         [24]  999 	lcall	_ak820_outline_0062
      0081B0                       1000 00109$:
                                   1001 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      0081B0 EB               [12] 1002 	mov	a,r3
      0081B1 2D               [12] 1003 	add	a, r5
      0081B2 12 3A 5F         [24] 1004 	lcall	_ak820_outline_0016
      0081B5 60 0B            [24] 1005 	jz	00118$
      0081B7 90 09 BD         [24] 1006 	mov	dptr,#_change_owned_bit_20001_310
      0081BA E0               [24] 1007 	movx	a,@dptr
      0081BB FA               [12] 1008 	mov	r2,a
      0081BC 90 09 BC         [24] 1009 	mov	dptr,#_change_owned_result_10001_309
      0081BF E0               [24] 1010 	movx	a,@dptr
      0081C0 4A               [12] 1011 	orl	a,r2
      0081C1 F0               [24] 1012 	movx	@dptr,a
      0081C2                       1013 00118$:
                                   1014 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0081C2 0B               [12] 1015 	inc	r3
      0081C3 90 09 BD         [24] 1016 	mov	dptr,#_change_owned_bit_20001_310
      0081C6 E0               [24] 1017 	movx	a,@dptr
      0081C7 25 E0            [12] 1018 	add	a,acc
      0081C9 F0               [24] 1019 	movx	@dptr,a
      0081CA 80 BC            [24] 1020 	sjmp	00117$
      0081CC                       1021 00112$:
                                   1022 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0081CC EE               [12] 1023 	mov	a,r6
      0081CD 60 09            [24] 1024 	jz	00114$
      0081CF 90 09 BC         [24] 1025 	mov	dptr,#_change_owned_result_10001_309
      0081D2 E0               [24] 1026 	movx	a,@dptr
      0081D3 90 09 B1         [24] 1027 	mov	dptr,#_owned_weak_mods
      0081D6 F0               [24] 1028 	movx	@dptr,a
      0081D7 22               [24] 1029 	ret
      0081D8                       1030 00114$:
                                   1031 ;	quantum/action_util.c:104: else owned_mods = result;
      0081D8 90 09 BC         [24] 1032 	mov	dptr,#_change_owned_result_10001_309
      0081DB E0               [24] 1033 	movx	a,@dptr
      0081DC 90 09 B0         [24] 1034 	mov	dptr,#_owned_mods
      0081DF F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:105: }
      0081E0 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_318'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      0081E1                       1047 _add_owned_mods:
      0081E1 E5 82            [12] 1048 	mov	a,dpl
      0081E3 90 09 BE         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_318
      0081E6 12 86 01         [24] 1050 	lcall	_ak820_outline_0117
      0081E9 74 01            [12] 1051 	mov	a,#0x01
      0081EB F0               [24] 1052 	movx	@dptr,a
      0081EC 8F 82            [24] 1053 	mov	dpl, r7
      0081EE 21 11            [12] 1054 	ajmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_320'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      0081F0                       1064 _del_owned_mods:
      0081F0 E5 82            [12] 1065 	mov	a,dpl
      0081F2 90 09 BF         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_320
      0081F5 12 86 01         [24] 1067 	lcall	_ak820_outline_0117
      0081F8 12 7C 4F         [24] 1068 	lcall	_ak820_outline_0189
      0081FB 21 11            [12] 1069 	ajmp	_change_owned
                                   1070 ;------------------------------------------------------------
                                   1071 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1072 ;------------------------------------------------------------
                                   1073 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_322'
                                   1074 ;------------------------------------------------------------
                                   1075 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1076 ;	-----------------------------------------
                                   1077 ;	 function add_owned_weak_mods
                                   1078 ;	-----------------------------------------
      0081FD                       1079 _add_owned_weak_mods:
      0081FD E5 82            [12] 1080 	mov	a,dpl
      0081FF 90 09 C0         [24] 1081 	mov	dptr,#_add_owned_weak_mods_mods_10000_322
      008202 12 86 01         [24] 1082 	lcall	_ak820_outline_0117
      008205 74 03            [12] 1083 	mov	a,#0x03
      008207 F0               [24] 1084 	movx	@dptr,a
      008208 8F 82            [24] 1085 	mov	dpl, r7
      00820A 21 11            [12] 1086 	ajmp	_change_owned
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1089 ;------------------------------------------------------------
                                   1090 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_324'
                                   1091 ;------------------------------------------------------------
                                   1092 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1093 ;	-----------------------------------------
                                   1094 ;	 function del_owned_weak_mods
                                   1095 ;	-----------------------------------------
      00820C                       1096 _del_owned_weak_mods:
      00820C E5 82            [12] 1097 	mov	a,dpl
      00820E 90 09 C1         [24] 1098 	mov	dptr,#_del_owned_weak_mods_mods_10000_324
      008211 12 86 01         [24] 1099 	lcall	_ak820_outline_0117
      008214 74 02            [12] 1100 	mov	a,#0x02
      008216 F0               [24] 1101 	movx	@dptr,a
      008217 8F 82            [24] 1102 	mov	dpl, r7
      008219 21 11            [12] 1103 	ajmp	_change_owned
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1106 ;------------------------------------------------------------
                                   1107 ;i             Allocated with name '_clear_owned_mods_i_20000_328'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function clear_owned_mods
                                   1112 ;	-----------------------------------------
      00821B                       1113 _clear_owned_mods:
                                   1114 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00821B 7F 00            [12] 1115 	mov	r7,#0x00
      00821D                       1116 00103$:
      00821D BF 08 00         [24] 1117 	cjne	r7,#0x08,00122$
      008220                       1118 00122$:
      008220 50 1A            [24] 1119 	jnc	00101$
      008222 EF               [12] 1120 	mov	a,r7
      008223 24 A0            [12] 1121 	add	a, #_owned_mod_refs
      008225 FD               [12] 1122 	mov	r5,a
      008226 E4               [12] 1123 	clr	a
      008227 34 09            [12] 1124 	addc	a, #(_owned_mod_refs >> 8)
      008229 FE               [12] 1125 	mov	r6,a
      00822A EF               [12] 1126 	mov	a,r7
      00822B 24 A8            [12] 1127 	add	a, #_owned_weak_refs
      00822D F5 82            [12] 1128 	mov	dpl,a
      00822F E4               [12] 1129 	clr	a
      008230 34 09            [12] 1130 	addc	a, #(_owned_weak_refs >> 8)
      008232 F5 83            [12] 1131 	mov	dph,a
      008234 E4               [12] 1132 	clr	a
      008235 F0               [24] 1133 	movx	@dptr,a
      008236 12 86 08         [24] 1134 	lcall	_ak820_outline_0121
      008239 0F               [12] 1135 	inc	r7
      00823A 80 E1            [24] 1136 	sjmp	00103$
      00823C                       1137 00101$:
                                   1138 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00823C 90 09 B3         [24] 1139 	mov	dptr,#(_macro_mods + 0x0001)
      00823F E4               [12] 1140 	clr	a
      008240 F0               [24] 1141 	movx	@dptr,a
      008241 90 09 B2         [24] 1142 	mov	dptr,#_macro_mods
      008244 F0               [24] 1143 	movx	@dptr,a
      008245 90 09 B1         [24] 1144 	mov	dptr,#_owned_weak_mods
      008248 F0               [24] 1145 	movx	@dptr,a
      008249 90 09 B0         [24] 1146 	mov	dptr,#_owned_mods
      00824C F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      00824D 90 09 B5         [24] 1149 	mov	dptr,#_ak820_macro_cancelled
      008250 04               [12] 1150 	inc	a
      008251 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_util.c:114: }
      008252 22               [24] 1153 	ret
                                   1154 ;------------------------------------------------------------
                                   1155 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1156 ;------------------------------------------------------------
                                   1157 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1158 ;i             Allocated with name '_clear_owned_keys_i_20000_332'
                                   1159 ;------------------------------------------------------------
                                   1160 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1161 ;	-----------------------------------------
                                   1162 ;	 function clear_owned_keys
                                   1163 ;	-----------------------------------------
      008253                       1164 _clear_owned_keys:
                                   1165 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008253 7F 00            [12] 1166 	mov	r7,#0x00
      008255                       1167 00104$:
      008255 EF               [12] 1168 	mov	a,r7
      008256 24 5B            [12] 1169 	add	a,#0xff - 0xa4
      008258 40 0D            [24] 1170 	jc	00101$
                                   1171 ;	free result
      00825A EF               [12] 1172 	mov	a,r7
      00825B 24 C2            [12] 1173 	add	a, #_key_refs
      00825D F5 82            [12] 1174 	mov	dpl,a
      00825F E4               [12] 1175 	clr	a
      008260 34 09            [12] 1176 	addc	a, #(_key_refs >> 8)
      008262 12 80 48         [24] 1177 	lcall	_ak820_outline_0165
      008265 80 EE            [24] 1178 	sjmp	00104$
      008267                       1179 00101$:
                                   1180 ;	quantum/action_util.c:122: distinct_keys = 0;
      008267 90 0A 67         [24] 1181 	mov	dptr,#_distinct_keys
      00826A E4               [12] 1182 	clr	a
      00826B F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00826C FF               [12] 1185 	mov	r7,a
      00826D                       1186 00107$:
      00826D BF 15 00         [24] 1187 	cjne	r7,#0x15,00142$
      008270                       1188 00142$:
      008270 50 0D            [24] 1189 	jnc	00109$
      008272 EF               [12] 1190 	mov	a,r7
      008273 24 68            [12] 1191 	add	a, #_macro_keys
      008275 F5 82            [12] 1192 	mov	dpl,a
      008277 E4               [12] 1193 	clr	a
      008278 34 0A            [12] 1194 	addc	a, #(_macro_keys >> 8)
      00827A 12 80 48         [24] 1195 	lcall	_ak820_outline_0165
      00827D 80 EE            [24] 1196 	sjmp	00107$
      00827F                       1197 00109$:
                                   1198 ;	quantum/action_util.c:124: }
      00827F 22               [24] 1199 	ret
                                   1200 ;------------------------------------------------------------
                                   1201 ;Allocation info for local variables in function 'add_owned_key'
                                   1202 ;------------------------------------------------------------
                                   1203 ;code          Allocated with name '_add_owned_key_code_10000_333'
                                   1204 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_342'
                                   1205 ;key           Allocated with name '_add_owned_key_key_50000_343'
                                   1206 ;i             Allocated with name '_add_owned_key_i_40000_341'
                                   1207 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_345'
                                   1208 ;key           Allocated with name '_add_owned_key_key_40000_346'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function add_owned_key
                                   1213 ;	-----------------------------------------
      008280                       1214 _add_owned_key:
      008280 E5 82            [12] 1215 	mov	a,dpl
      008282 90 0A 7D         [24] 1216 	mov	dptr,#_add_owned_key_code_10000_333
      008285 12 86 19         [24] 1217 	lcall	_ak820_outline_0132
                                   1218 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008288 74 01            [12] 1219 	mov	a,#0x01
      00828A F0               [24] 1220 	movx	@dptr,a
      00828B 90 0A 68         [24] 1221 	mov	dptr,#_macro_keys
      00828E C0 07            [24] 1222 	push	ar7
      008290 11 A5            [12] 1223 	acall	_ak820_macro_change
      008292 E5 82            [12] 1224 	mov	a, dpl
      008294 D0 07            [24] 1225 	pop	ar7
      008296 70 03            [24] 1226 	jnz	00102$
      008298 F5 82            [12] 1227 	mov	dpl,a
      00829A 22               [24] 1228 	ret
      00829B                       1229 00102$:
                                   1230 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      00829B 12 85 D3         [24] 1231 	lcall	_ak820_outline_0030
      00829E FC               [12] 1232 	mov	r4,a
      00829F 04               [12] 1233 	inc	a
      0082A0 12 86 08         [24] 1234 	lcall	_ak820_outline_0121
      0082A3 EC               [12] 1235 	mov	a,r4
      0082A4 60 04            [24] 1236 	jz	00104$
      0082A6 75 82 00         [24] 1237 	mov	dpl, #0x00
      0082A9 22               [24] 1238 	ret
      0082AA                       1239 00104$:
                                   1240 ;	quantum/action_util.c:128: ++distinct_keys;
      0082AA 90 0A 67         [24] 1241 	mov	dptr,#_distinct_keys
      0082AD E0               [24] 1242 	movx	a,@dptr
      0082AE 24 01            [12] 1243 	add	a, #0x01
      0082B0 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082B1 90 0D E1         [24] 1246 	mov	dptr,#_keyboard_protocol
      0082B4 E0               [24] 1247 	movx	a,@dptr
      0082B5 60 11            [24] 1248 	jz	00106$
      0082B7 90 0A EC         [24] 1249 	mov	dptr,#_keymap_config
      0082BA E0               [24] 1250 	movx	a,@dptr
      0082BB 30 E7 0A         [24] 1251 	jnb	acc.7,00106$
                                   1252 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0082BE 12 86 24         [24] 1253 	lcall	_ak820_outline_0175
      0082C1 12 73 6D         [24] 1254 	lcall	_add_key_to_report
                                   1255 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082C4 75 82 01         [24] 1256 	mov	dpl, #0x01
      0082C7 22               [24] 1257 	ret
      0082C8                       1258 00106$:
                                   1259 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0082C8 90 0A 67         [24] 1260 	mov	dptr,#_distinct_keys
      0082CB E0               [24] 1261 	movx	a,@dptr
      0082CC 24 F9            [12] 1262 	add	a,#0xff - 0x06
      0082CE 50 17            [24] 1263 	jnc	00110$
                                   1264 ;	free result
                                   1265 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0082D0 7F 00            [12] 1266 	mov	r7,#0x00
      0082D2                       1267 00115$:
      0082D2 BF 06 00         [24] 1268 	cjne	r7,#0x06,00174$
      0082D5                       1269 00174$:
      0082D5 50 1E            [24] 1270 	jnc	00111$
      0082D7 EF               [12] 1271 	mov	a,r7
      0082D8 24 F6            [12] 1272 	add	a, #(_actual_keyboard_report + 0x0002)
      0082DA F5 82            [12] 1273 	mov	dpl,a
      0082DC E4               [12] 1274 	clr	a
      0082DD 34 0D            [12] 1275 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      0082DF F5 83            [12] 1276 	mov	dph,a
      0082E1 74 01            [12] 1277 	mov	a,#0x01
      0082E3 F0               [24] 1278 	movx	@dptr,a
      0082E4 0F               [12] 1279 	inc	r7
      0082E5 80 EB            [24] 1280 	sjmp	00115$
      0082E7                       1281 00110$:
                                   1282 ;	quantum/action_util.c:134: } else add_key(code);
      0082E7 90 0A 7D         [24] 1283 	mov	dptr,#_add_owned_key_code_10000_333
      0082EA E0               [24] 1284 	movx	a,@dptr
                                   1285 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0082EB 90 08 2B         [24] 1286 	mov	dptr,#_add_key_to_report_PARM_2
      0082EE F0               [24] 1287 	movx	@dptr,a
      0082EF 90 0D F4         [24] 1288 	mov	dptr,#_actual_keyboard_report
      0082F2 12 73 6D         [24] 1289 	lcall	_add_key_to_report
                                   1290 ;	quantum/action_util.c:134: } else add_key(code);
      0082F5                       1291 00111$:
                                   1292 ;	quantum/action_util.c:135: return true;
      0082F5 75 82 01         [24] 1293 	mov	dpl, #0x01
                                   1294 ;	quantum/action_util.c:136: }
      0082F8 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'del_owned_key'
                                   1298 ;------------------------------------------------------------
                                   1299 ;code          Allocated with name '_del_owned_key_code_10000_348'
                                   1300 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_359'
                                   1301 ;key           Allocated with name '_del_owned_key_key_50000_360'
                                   1302 ;key           Allocated with name '_del_owned_key_key_40000_357'
                                   1303 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_365'
                                   1304 ;key           Allocated with name '_del_owned_key_key_70000_366'
                                   1305 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_368'
                                   1306 ;key           Allocated with name '_del_owned_key_key_40000_369'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function del_owned_key
                                   1311 ;	-----------------------------------------
      0082F9                       1312 _del_owned_key:
      0082F9 E5 82            [12] 1313 	mov	a,dpl
      0082FB 90 0A 7E         [24] 1314 	mov	dptr,#_del_owned_key_code_10000_348
      0082FE 12 86 19         [24] 1315 	lcall	_ak820_outline_0132
                                   1316 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008301 E4               [12] 1317 	clr	a
      008302 F0               [24] 1318 	movx	@dptr,a
      008303 90 0A 68         [24] 1319 	mov	dptr,#_macro_keys
      008306 C0 07            [24] 1320 	push	ar7
      008308 11 A5            [12] 1321 	acall	_ak820_macro_change
      00830A E5 82            [12] 1322 	mov	a, dpl
      00830C D0 07            [24] 1323 	pop	ar7
      00830E 70 03            [24] 1324 	jnz	00102$
      008310 F5 82            [12] 1325 	mov	dpl,a
      008312 22               [24] 1326 	ret
      008313                       1327 00102$:
                                   1328 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      008313 12 85 D3         [24] 1329 	lcall	_ak820_outline_0030
      008316 FC               [12] 1330 	mov	r4,a
      008317 60 09            [24] 1331 	jz	00103$
      008319 1C               [12] 1332 	dec	r4
      00831A 12 3A DC         [24] 1333 	lcall	_ak820_outline_0133
      00831D EC               [12] 1334 	mov	a,r4
      00831E F0               [24] 1335 	movx	@dptr,a
      00831F EC               [12] 1336 	mov	a,r4
      008320 60 04            [24] 1337 	jz	00104$
      008322                       1338 00103$:
      008322 75 82 00         [24] 1339 	mov	dpl, #0x00
      008325 22               [24] 1340 	ret
      008326                       1341 00104$:
                                   1342 ;	quantum/action_util.c:140: --distinct_keys;
      008326 90 0A 67         [24] 1343 	mov	dptr,#_distinct_keys
      008329 E0               [24] 1344 	movx	a,@dptr
      00832A 14               [12] 1345 	dec	a
      00832B F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00832C 90 0D E1         [24] 1348 	mov	dptr,#_keyboard_protocol
      00832F E0               [24] 1349 	movx	a,@dptr
      008330 60 16            [24] 1350 	jz	00107$
      008332 90 0A EC         [24] 1351 	mov	dptr,#_keymap_config
      008335 E0               [24] 1352 	movx	a,@dptr
      008336 30 E7 0F         [24] 1353 	jnb	acc.7,00107$
                                   1354 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008339 90 08 2E         [24] 1355 	mov	dptr,#_del_key_from_report_PARM_2
      00833C EF               [12] 1356 	mov	a,r7
      00833D F0               [24] 1357 	movx	@dptr,a
      00833E 90 0D F4         [24] 1358 	mov	dptr,#_actual_keyboard_report
      008341 12 73 A1         [24] 1359 	lcall	_del_key_from_report
                                   1360 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008344 75 82 01         [24] 1361 	mov	dpl, #0x01
      008347 22               [24] 1362 	ret
      008348                       1363 00107$:
                                   1364 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      008348 90 0A 67         [24] 1365 	mov	dptr,#_distinct_keys
      00834B E0               [24] 1366 	movx	a,@dptr
      00834C FF               [12] 1367 	mov  r7,a
      00834D 24 F9            [12] 1368 	add	a,#0xff - 0x06
      00834F 50 04            [24] 1369 	jnc	00110$
                                   1370 ;	free result
      008351 75 82 01         [24] 1371 	mov	dpl, #0x01
      008354 22               [24] 1372 	ret
      008355                       1373 00110$:
                                   1374 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008355 BF 06 1F         [24] 1375 	cjne	r7,#0x06,00115$
                                   1376 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      008358 90 0D F4         [24] 1377 	mov	dptr,#_actual_keyboard_report
      00835B 12 73 D5         [24] 1378 	lcall	_clear_keys_from_report
                                   1379 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00835E 7F 04            [12] 1380 	mov	r7,#0x04
      008360                       1381 00122$:
      008360 EF               [12] 1382 	mov	a,r7
      008361 24 5B            [12] 1383 	add	a,#0xff - 0xa4
      008363 40 20            [24] 1384 	jc	00116$
                                   1385 ;	free result
      008365 12 85 D3         [24] 1386 	lcall	_ak820_outline_0030
      008368 60 0A            [24] 1387 	jz	00123$
                                   1388 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00836A 12 86 24         [24] 1389 	lcall	_ak820_outline_0175
      00836D C0 07            [24] 1390 	push	ar7
      00836F 12 73 6D         [24] 1391 	lcall	_add_key_to_report
      008372 D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008374                       1394 00123$:
      008374 0F               [12] 1395 	inc	r7
      008375 80 E9            [24] 1396 	sjmp	00122$
      008377                       1397 00115$:
                                   1398 ;	quantum/action_util.c:149: } else del_key(code);
      008377 90 0A 7E         [24] 1399 	mov	dptr,#_del_owned_key_code_10000_348
      00837A E0               [24] 1400 	movx	a,@dptr
                                   1401 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00837B 90 08 2E         [24] 1402 	mov	dptr,#_del_key_from_report_PARM_2
      00837E F0               [24] 1403 	movx	@dptr,a
      00837F 90 0D F4         [24] 1404 	mov	dptr,#_actual_keyboard_report
      008382 12 73 A1         [24] 1405 	lcall	_del_key_from_report
                                   1406 ;	quantum/action_util.c:149: } else del_key(code);
      008385                       1407 00116$:
                                   1408 ;	quantum/action_util.c:150: return true;
      008385 75 82 01         [24] 1409 	mov	dpl, #0x01
                                   1410 ;	quantum/action_util.c:151: }
      008388 22               [24] 1411 	ret
                                   1412 ;------------------------------------------------------------
                                   1413 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1414 ;------------------------------------------------------------
                                   1415 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1416 ;i             Allocated with name '_clear_owned_usages_i_20000_374'
                                   1417 ;------------------------------------------------------------
                                   1418 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1419 ;	-----------------------------------------
                                   1420 ;	 function clear_owned_usages
                                   1421 ;	-----------------------------------------
      008389                       1422 _clear_owned_usages:
                                   1423 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008389 7F 00            [12] 1424 	mov	r7,#0x00
      00838B                       1425 00104$:
      00838B BF 1E 00         [24] 1426 	cjne	r7,#0x1e,00141$
      00838E                       1427 00141$:
      00838E 50 14            [24] 1428 	jnc	00101$
      008390 EF               [12] 1429 	mov	a,r7
      008391 24 7F            [12] 1430 	add	a, #_usage_refs
      008393 FD               [12] 1431 	mov	r5,a
      008394 E4               [12] 1432 	clr	a
      008395 34 0A            [12] 1433 	addc	a, #(_usage_refs >> 8)
      008397 FE               [12] 1434 	mov	r6,a
      008398 EF               [12] 1435 	mov	a,r7
      008399 12 85 E8         [24] 1436 	lcall	_ak820_outline_0067
      00839C E4               [12] 1437 	clr	a
      00839D F0               [24] 1438 	movx	@dptr,a
      00839E 12 86 08         [24] 1439 	lcall	_ak820_outline_0121
      0083A1 0F               [12] 1440 	inc	r7
      0083A2 80 E7            [24] 1441 	sjmp	00104$
      0083A4                       1442 00101$:
                                   1443 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      0083A4 90 0A BC         [24] 1444 	mov	dptr,#(_usage_lengths + 0x0001)
      0083A7 E4               [12] 1445 	clr	a
      0083A8 F0               [24] 1446 	movx	@dptr,a
      0083A9 90 0A BB         [24] 1447 	mov	dptr,#_usage_lengths
      0083AC F0               [24] 1448 	movx	@dptr,a
                                   1449 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0083AD FF               [12] 1450 	mov	r7,a
      0083AE                       1451 00107$:
      0083AE BF 04 00         [24] 1452 	cjne	r7,#0x04,00143$
      0083B1                       1453 00143$:
      0083B1 50 0D            [24] 1454 	jnc	00109$
      0083B3 EF               [12] 1455 	mov	a,r7
      0083B4 24 BD            [12] 1456 	add	a, #_macro_usages
      0083B6 F5 82            [12] 1457 	mov	dpl,a
      0083B8 E4               [12] 1458 	clr	a
      0083B9 34 0A            [12] 1459 	addc	a, #(_macro_usages >> 8)
      0083BB 12 80 48         [24] 1460 	lcall	_ak820_outline_0165
      0083BE 80 EE            [24] 1461 	sjmp	00107$
      0083C0                       1462 00109$:
                                   1463 ;	quantum/action_util.c:165: }
      0083C0 22               [24] 1464 	ret
                                   1465 ;------------------------------------------------------------
                                   1466 ;Allocation info for local variables in function 'owned_usage_key'
                                   1467 ;------------------------------------------------------------
                                   1468 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1469 ;code          Allocated with name '_owned_usage_key_code_10000_375'
                                   1470 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_376'
                                   1471 ;which         Allocated with name '_owned_usage_key_which_10000_376'
                                   1472 ;base          Allocated with name '_owned_usage_key_base_10000_376'
                                   1473 ;count         Allocated with name '_owned_usage_key_count_10000_376'
                                   1474 ;index         Allocated with name '_owned_usage_key_index_10000_376'
                                   1475 ;pos           Allocated with name '_owned_usage_key_pos_30001_383'
                                   1476 ;i             Allocated with name '_owned_usage_key_i_40001_384'
                                   1477 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_387'
                                   1478 ;key           Allocated with name '_owned_usage_key_key_40000_388'
                                   1479 ;------------------------------------------------------------
                                   1480 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1481 ;	-----------------------------------------
                                   1482 ;	 function owned_usage_key
                                   1483 ;	-----------------------------------------
      0083C1                       1484 _owned_usage_key:
      0083C1 E5 82            [12] 1485 	mov	a,dpl
      0083C3 90 0A C2         [24] 1486 	mov	dptr,#_owned_usage_key_code_10000_375
      0083C6 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      0083C7 E0               [24] 1489 	movx	a,@dptr
      0083C8 FF               [12] 1490 	mov	r7,a
      0083C9 BF A8 00         [24] 1491 	cjne	r7,#0xa8,00244$
      0083CC                       1492 00244$:
      0083CC B3               [12] 1493 	cpl	c
      0083CD 92 25            [24] 1494 	mov	_owned_usage_key_sloc0_1_0,c
      0083CF E4               [12] 1495 	clr	a
      0083D0 33               [12] 1496 	rlc	a
      0083D1 FF               [12] 1497 	mov	r7,a
      0083D2 90 0A C5         [24] 1498 	mov	dptr,#_owned_usage_key_which_10000_376
      0083D5 F0               [24] 1499 	movx	@dptr,a
                                   1500 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      0083D6 EF               [12] 1501 	mov	a,r7
      0083D7 60 02            [24] 1502 	jz	00129$
      0083D9 74 03            [12] 1503 	mov	a,#0x03
      0083DB                       1504 00129$:
      0083DB FE               [12] 1505 	mov	r6,a
                                   1506 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      0083DC EF               [12] 1507 	mov	a,r7
      0083DD 24 BB            [12] 1508 	add	a, #_usage_lengths
      0083DF FD               [12] 1509 	mov	r5,a
      0083E0 E4               [12] 1510 	clr	a
      0083E1 34 0A            [12] 1511 	addc	a, #(_usage_lengths >> 8)
      0083E3 FF               [12] 1512 	mov	r7,a
      0083E4 12 86 2D         [24] 1513 	lcall	_ak820_outline_0190
      0083E7 E0               [24] 1514 	movx	a,@dptr
      0083E8 FC               [12] 1515 	mov	r4,a
                                   1516 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      0083E9 90 0A C2         [24] 1517 	mov	dptr,#_owned_usage_key_code_10000_375
      0083EC E0               [24] 1518 	movx	a,@dptr
      0083ED 24 5B            [12] 1519 	add	a,#0x5b
      0083EF FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      0083F0 90 0A C1         [24] 1522 	mov	dptr,#_owned_usage_key_PARM_2
      0083F3 E0               [24] 1523 	movx	a,@dptr
      0083F4 FA               [12] 1524 	mov	r2,a
      0083F5 90 09 B6         [24] 1525 	mov	dptr,#_ak820_macro_change_PARM_2
      0083F8 EB               [12] 1526 	mov	a,r3
      0083F9 F0               [24] 1527 	movx	@dptr,a
      0083FA 90 09 B7         [24] 1528 	mov	dptr,#_ak820_macro_change_PARM_3
      0083FD EA               [12] 1529 	mov	a,r2
      0083FE F0               [24] 1530 	movx	@dptr,a
      0083FF 90 0A BD         [24] 1531 	mov	dptr,#_macro_usages
      008402 C0 07            [24] 1532 	push	ar7
      008404 C0 06            [24] 1533 	push	ar6
      008406 C0 05            [24] 1534 	push	ar5
      008408 C0 04            [24] 1535 	push	ar4
      00840A C0 03            [24] 1536 	push	ar3
      00840C C0 02            [24] 1537 	push	ar2
      00840E 11 A5            [12] 1538 	acall	_ak820_macro_change
      008410 E5 82            [12] 1539 	mov	a, dpl
      008412 D0 02            [24] 1540 	pop	ar2
      008414 D0 03            [24] 1541 	pop	ar3
      008416 D0 04            [24] 1542 	pop	ar4
      008418 D0 05            [24] 1543 	pop	ar5
      00841A D0 06            [24] 1544 	pop	ar6
      00841C D0 07            [24] 1545 	pop	ar7
      00841E 70 01            [24] 1546 	jnz	00102$
      008420 22               [24] 1547 	ret
      008421                       1548 00102$:
                                   1549 ;	quantum/action_util.c:172: if (pressed) {
      008421 EA               [12] 1550 	mov	a,r2
      008422 60 1A            [24] 1551 	jz	00115$
                                   1552 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      008424 12 85 F2         [24] 1553 	lcall	_ak820_outline_0075
      008427 04               [12] 1554 	inc	a
      008428 12 70 EB         [24] 1555 	lcall	_ak820_outline_0139
      00842B E8               [12] 1556 	mov	a,r0
      00842C 60 01            [24] 1557 	jz	00104$
      00842E 22               [24] 1558 	ret
      00842F                       1559 00104$:
                                   1560 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      00842F 90 0A C6         [24] 1561 	mov	dptr,#_owned_usage_key_count_10000_376
      008432 EC               [12] 1562 	mov	a,r4
      008433 04               [12] 1563 	inc	a
      008434 F0               [24] 1564 	movx	@dptr,a
      008435 EC               [12] 1565 	mov	a,r4
      008436 2E               [12] 1566 	add	a, r6
      008437 12 85 E8         [24] 1567 	lcall	_ak820_outline_0067
      00843A EB               [12] 1568 	mov	a,r3
      00843B F0               [24] 1569 	movx	@dptr,a
      00843C 81 9F            [12] 1570 	ajmp	00116$
      00843E                       1571 00115$:
                                   1572 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      00843E 12 85 F2         [24] 1573 	lcall	_ak820_outline_0075
      008441 60 07            [24] 1574 	jz	00105$
      008443 18               [12] 1575 	dec	r0
      008444 12 85 E1         [24] 1576 	lcall	_ak820_outline_0062
      008447 E8               [12] 1577 	mov	a,r0
      008448 60 01            [24] 1578 	jz	00106$
      00844A                       1579 00105$:
      00844A 22               [24] 1580 	ret
      00844B                       1581 00106$:
                                   1582 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      00844B 7A 00            [12] 1583 	mov	r2,#0x00
      00844D                       1584 00108$:
      00844D EA               [12] 1585 	mov	a,r2
      00844E 2E               [12] 1586 	add	a, r6
      00844F 12 85 E8         [24] 1587 	lcall	_ak820_outline_0067
      008452 E0               [24] 1588 	movx	a,@dptr
      008453 B5 03 02         [24] 1589 	cjne	a,ar3,00251$
      008456 80 03            [24] 1590 	sjmp	00167$
      008458                       1591 00251$:
      008458 0A               [12] 1592 	inc	r2
      008459 80 F2            [24] 1593 	sjmp	00108$
      00845B                       1594 00167$:
      00845B 90 0A C7         [24] 1595 	mov	dptr,#_owned_usage_key_pos_30001_383
      00845E EA               [12] 1596 	mov	a,r2
      00845F F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	quantum/action_util.c:179: --count;
      008460 1C               [12] 1599 	dec	r4
      008461 90 0A C6         [24] 1600 	mov	dptr,#_owned_usage_key_count_10000_376
      008464 EC               [12] 1601 	mov	a,r4
      008465 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008466 8A 03            [24] 1604 	mov	ar3,r2
      008468                       1605 00125$:
      008468 C3               [12] 1606 	clr	c
      008469 EB               [12] 1607 	mov	a,r3
      00846A 9C               [12] 1608 	subb	a,r4
      00846B 50 23            [24] 1609 	jnc	00111$
      00846D C0 05            [24] 1610 	push	ar5
      00846F C0 07            [24] 1611 	push	ar7
      008471 EB               [12] 1612 	mov	a,r3
      008472 2E               [12] 1613 	add	a, r6
      008473 FA               [12] 1614 	mov	r2,a
      008474 24 9D            [12] 1615 	add	a, #_usage_order
      008476 F8               [12] 1616 	mov	r0,a
      008477 E4               [12] 1617 	clr	a
      008478 34 0A            [12] 1618 	addc	a, #(_usage_order >> 8)
      00847A F9               [12] 1619 	mov	r1,a
      00847B 0A               [12] 1620 	inc	r2
      00847C EA               [12] 1621 	mov	a,r2
      00847D 33               [12] 1622 	rlc	a
      00847E 95 E0            [12] 1623 	subb	a,acc
      008480 FF               [12] 1624 	mov	r7,a
      008481 EA               [12] 1625 	mov	a,r2
      008482 12 86 0E         [24] 1626 	lcall	_ak820_outline_0125
      008485 12 3A F6         [24] 1627 	lcall	_ak820_outline_0160
      008488 F0               [24] 1628 	movx	@dptr,a
      008489 0B               [12] 1629 	inc	r3
      00848A D0 07            [24] 1630 	pop	ar7
      00848C D0 05            [24] 1631 	pop	ar5
      00848E 80 D8            [24] 1632 	sjmp	00125$
      008490                       1633 00111$:
                                   1634 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      008490 12 86 2D         [24] 1635 	lcall	_ak820_outline_0190
      008493 EC               [12] 1636 	mov	a,r4
      008494 F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      008495 90 0A C7         [24] 1639 	mov	dptr,#_owned_usage_key_pos_30001_383
      008498 E0               [24] 1640 	movx	a,@dptr
      008499 B5 04 02         [24] 1641 	cjne	a,ar4,00253$
      00849C 80 01            [24] 1642 	sjmp	00116$
      00849E                       1643 00253$:
      00849E 22               [24] 1644 	ret
      00849F                       1645 00116$:
                                   1646 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      00849F 90 0A C6         [24] 1647 	mov	dptr,#_owned_usage_key_count_10000_376
      0084A2 E0               [24] 1648 	movx	a,@dptr
      0084A3 FC               [12] 1649 	mov	r4,a
      0084A4 12 86 2D         [24] 1650 	lcall	_ak820_outline_0190
      0084A7 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0084A8 EC               [12] 1653 	mov	a,r4
      0084A9 60 15            [24] 1654 	jz	00131$
      0084AB EC               [12] 1655 	mov	a,r4
      0084AC 2E               [12] 1656 	add	a, r6
      0084AD FE               [12] 1657 	mov	r6,a
      0084AE 1E               [12] 1658 	dec	r6
      0084AF EE               [12] 1659 	mov	a,r6
      0084B0 33               [12] 1660 	rlc	a
      0084B1 95 E0            [12] 1661 	subb	a,acc
      0084B3 FF               [12] 1662 	mov	r7,a
      0084B4 EE               [12] 1663 	mov	a,r6
      0084B5 12 86 0E         [24] 1664 	lcall	_ak820_outline_0125
      0084B8 24 A5            [12] 1665 	add	a,#0xa5
      0084BA FE               [12] 1666 	mov	r6,a
      0084BB 33               [12] 1667 	rlc	a
      0084BC 95 E0            [12] 1668 	subb	a,acc
      0084BE 80 02            [24] 1669 	sjmp	00132$
      0084C0                       1670 00131$:
      0084C0 7E 00            [12] 1671 	mov	r6,#0x00
      0084C2                       1672 00132$:
      0084C2 90 0A C2         [24] 1673 	mov	dptr,#_owned_usage_key_code_10000_375
      0084C5 EE               [12] 1674 	mov	a,r6
      0084C6 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0084C7 90 0A C5         [24] 1677 	mov	dptr,#_owned_usage_key_which_10000_376
      0084CA E0               [24] 1678 	movx	a,@dptr
      0084CB 60 18            [24] 1679 	jz	00118$
      0084CD EE               [12] 1680 	mov	a,r6
      0084CE 60 0B            [24] 1681 	jz	00133$
      0084D0 8E 82            [24] 1682 	mov	dpl, r6
      0084D2 12 72 29         [24] 1683 	lcall	_KEYCODE2CONSUMER
      0084D5 AD 82            [24] 1684 	mov	r5, dpl
      0084D7 AF 83            [24] 1685 	mov	r7, dph
      0084D9 80 04            [24] 1686 	sjmp	00134$
      0084DB                       1687 00133$:
      0084DB 7D 00            [12] 1688 	mov	r5,#0x00
      0084DD 7F 00            [12] 1689 	mov	r7,#0x00
      0084DF                       1690 00134$:
      0084DF 12 86 2D         [24] 1691 	lcall	_ak820_outline_0190
      0084E2 02 71 DD         [24] 1692 	ljmp	_host_consumer_send
      0084E5                       1693 00118$:
                                   1694 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0084E5 EE               [12] 1695 	mov	a,r6
      0084E6 60 22            [24] 1696 	jz	00135$
                                   1697 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0084E8 BE A5 00         [24] 1698 	cjne	r6,#0xa5,00258$
      0084EB                       1699 00258$:
      0084EB 40 05            [24] 1700 	jc	00121$
      0084ED EE               [12] 1701 	mov	a,r6
      0084EE 24 58            [12] 1702 	add	a,#0xff - 0xa7
      0084F0 50 08            [24] 1703 	jnc	00122$
                                   1704 ;	free result
      0084F2                       1705 00121$:
      0084F2 90 0A C3         [24] 1706 	mov	dptr,#_owned_usage_key___200000085_20000_376
      0084F5 12 51 B6         [24] 1707 	lcall	_ak820_outline_0182
      0084F8 80 09            [24] 1708 	sjmp	00123$
      0084FA                       1709 00122$:
                                   1710 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0084FA 74 DC            [12] 1711 	mov	a,#0xdc
      0084FC 2E               [12] 1712 	add	a, r6
      0084FD 90 0A C3         [24] 1713 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008500 12 3A E1         [24] 1714 	lcall	_ak820_outline_0135
                                   1715 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008503                       1716 00123$:
      008503 90 0A C3         [24] 1717 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008506 E0               [24] 1718 	movx	a,@dptr
      008507 FF               [12] 1719 	mov	r7,a
      008508 80 02            [24] 1720 	sjmp	00136$
      00850A                       1721 00135$:
      00850A 7F 00            [12] 1722 	mov	r7,#0x00
      00850C                       1723 00136$:
      00850C 7E 00            [12] 1724 	mov	r6,#0x00
      00850E 12 45 AD         [24] 1725 	lcall	_ak820_outline_0161
                                   1726 ;	quantum/action_util.c:188: }
      008511 02 71 AE         [24] 1727 	ljmp	_host_system_send
                                   1728 ;------------------------------------------------------------
                                   1729 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1730 ;------------------------------------------------------------
                                   1731 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_396'
                                   1732 ;changed       Allocated with name '_send_keyboard_report_changed_10001_396'
                                   1733 ;dest          Allocated with name '_send_keyboard_report_dest_10001_396'
                                   1734 ;src           Allocated with name '_send_keyboard_report_src_10001_396'
                                   1735 ;i             Allocated with name '_send_keyboard_report_i_20001_397'
                                   1736 ;------------------------------------------------------------
                                   1737 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1738 ;	-----------------------------------------
                                   1739 ;	 function send_keyboard_report
                                   1740 ;	-----------------------------------------
      008514                       1741 _send_keyboard_report:
                                   1742 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      008514 90 0D F2         [24] 1743 	mov	dptr,#_real_mods
      008517 E0               [24] 1744 	movx	a,@dptr
      008518 FF               [12] 1745 	mov	r7,a
      008519 90 0D F4         [24] 1746 	mov	dptr,#_actual_keyboard_report
      00851C F0               [24] 1747 	movx	@dptr,a
                                   1748 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      00851D 90 0D F3         [24] 1749 	mov	dptr,#_weak_mods
      008520 E0               [24] 1750 	movx	a,@dptr
      008521 42 07            [12] 1751 	orl	ar7,a
      008523 90 0D F4         [24] 1752 	mov	dptr,#_actual_keyboard_report
      008526 EF               [12] 1753 	mov	a,r7
      008527 F0               [24] 1754 	movx	@dptr,a
                                   1755 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008528 90 09 B1         [24] 1756 	mov	dptr,#_owned_weak_mods
      00852B E0               [24] 1757 	movx	a,@dptr
      00852C FE               [12] 1758 	mov	r6,a
      00852D 90 09 B0         [24] 1759 	mov	dptr,#_owned_mods
      008530 E0               [24] 1760 	movx	a,@dptr
      008531 4E               [12] 1761 	orl	a,r6
      008532 42 07            [12] 1762 	orl	ar7,a
      008534 90 0D F4         [24] 1763 	mov	dptr,#_actual_keyboard_report
      008537 EF               [12] 1764 	mov	a,r7
      008538 F0               [24] 1765 	movx	@dptr,a
                                   1766 ;	quantum/action_util.c:444: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008539 30 21 07         [24] 1767 	jnb	_gui_disabled,00102$
      00853C 90 0D F4         [24] 1768 	mov	dptr,#_actual_keyboard_report
      00853F E0               [24] 1769 	movx	a,@dptr
      008540 54 77            [12] 1770 	anl	a,#0x77
      008542 F0               [24] 1771 	movx	@dptr,a
      008543                       1772 00102$:
                                   1773 ;	quantum/action_util.c:455: bool changed = false;
      008543 90 0A E9         [24] 1774 	mov	dptr,#_send_keyboard_report_changed_10001_396
      008546 E4               [12] 1775 	clr	a
      008547 F0               [24] 1776 	movx	@dptr,a
                                   1777 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1778 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1779 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008548 FF               [12] 1780 	mov	r7,a
      008549                       1781 00109$:
      008549 BF 20 00         [24] 1782 	cjne	r7,#0x20,00150$
      00854C                       1783 00150$:
      00854C 50 2A            [24] 1784 	jnc	00105$
                                   1785 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      00854E EF               [12] 1786 	mov	a,r7
      00854F 24 C9            [12] 1787 	add	a, #_send_keyboard_report_last_report_10001_396
      008551 FD               [12] 1788 	mov	r5,a
      008552 E4               [12] 1789 	clr	a
      008553 34 0A            [12] 1790 	addc	a, #(_send_keyboard_report_last_report_10001_396 >> 8)
      008555 12 4A C3         [24] 1791 	lcall	_ak820_outline_0056
      008558 EF               [12] 1792 	mov	a,r7
      008559 24 F4            [12] 1793 	add	a, #_actual_keyboard_report
      00855B F5 82            [12] 1794 	mov	dpl,a
      00855D E4               [12] 1795 	clr	a
      00855E 34 0D            [12] 1796 	addc	a, #(_actual_keyboard_report >> 8)
      008560 F5 83            [12] 1797 	mov	dph,a
      008562 E0               [24] 1798 	movx	a,@dptr
      008563 FB               [12] 1799 	mov	r3,a
      008564 EC               [12] 1800 	mov	a,r4
      008565 B5 03 02         [24] 1801 	cjne	a,ar3,00152$
      008568 80 0B            [24] 1802 	sjmp	00110$
      00856A                       1803 00152$:
                                   1804 ;	quantum/action_util.c:465: dest[i] = src[i];
      00856A 12 3A DC         [24] 1805 	lcall	_ak820_outline_0133
      00856D EB               [12] 1806 	mov	a,r3
      00856E F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:466: changed = true;
      00856F 90 0A E9         [24] 1809 	mov	dptr,#_send_keyboard_report_changed_10001_396
      008572 74 01            [12] 1810 	mov	a,#0x01
      008574 F0               [24] 1811 	movx	@dptr,a
      008575                       1812 00110$:
                                   1813 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008575 0F               [12] 1814 	inc	r7
      008576 80 D1            [24] 1815 	sjmp	00109$
      008578                       1816 00105$:
                                   1817 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      008578 90 0A E9         [24] 1818 	mov	dptr,#_send_keyboard_report_changed_10001_396
      00857B E0               [24] 1819 	movx	a,@dptr
      00857C 60 09            [24] 1820 	jz	00111$
      00857E 90 0D F4         [24] 1821 	mov	dptr,#_actual_keyboard_report
      008581 75 F0 00         [24] 1822 	mov	b, #0x00
                                   1823 ;	quantum/action_util.c:477: }
      008584 02 71 23         [24] 1824 	ljmp	_host_keyboard_send
      008587                       1825 00111$:
      008587 22               [24] 1826 	ret
                                   1827 ;------------------------------------------------------------
                                   1828 ;Allocation info for local variables in function 'get_mods'
                                   1829 ;------------------------------------------------------------
                                   1830 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1831 ;	-----------------------------------------
                                   1832 ;	 function get_mods
                                   1833 ;	-----------------------------------------
      008588                       1834 _get_mods:
      008588 C0 07            [24] 1835 	push	ar7
                                   1836 ;	quantum/action_util.c:488: ;
      00858A 90 09 B0         [24] 1837 	mov	dptr,#_owned_mods
      00858D E0               [24] 1838 	movx	a,@dptr
      00858E FF               [12] 1839 	mov	r7,a
      00858F 90 0D F2         [24] 1840 	mov	dptr,#_real_mods
      008592 12 80 42         [24] 1841 	lcall	_ak820_outline_0143
                                   1842 ;	quantum/action_util.c:489: }
      008595 D0 07            [24] 1843 	pop	ar7
      008597 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'add_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_add_mods_mods_10000_404'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function clear_mods
                                   1853 ;	-----------------------------------------
      008598                       1854 _clear_mods:
                                   1855 ;	quantum/action_util.c:516: real_mods = 0;
      008598 90 0D F2         [24] 1856 	mov	dptr,#_real_mods
      00859B E4               [12] 1857 	clr	a
      00859C F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/action_util.c:517: }
      00859D 22               [24] 1860 	ret
                                   1861 ;------------------------------------------------------------
                                   1862 ;Allocation info for local variables in function 'get_weak_mods'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function get_weak_mods
                                   1867 ;	-----------------------------------------
      00859E                       1868 _get_weak_mods:
      00859E C0 07            [24] 1869 	push	ar7
                                   1870 ;	quantum/action_util.c:528: ;
      0085A0 90 09 B1         [24] 1871 	mov	dptr,#_owned_weak_mods
      0085A3 E0               [24] 1872 	movx	a,@dptr
      0085A4 FF               [12] 1873 	mov	r7,a
      0085A5 90 0D F3         [24] 1874 	mov	dptr,#_weak_mods
      0085A8 12 80 42         [24] 1875 	lcall	_ak820_outline_0143
                                   1876 ;	quantum/action_util.c:529: }
      0085AB D0 07            [24] 1877 	pop	ar7
      0085AD 22               [24] 1878 	ret
                                   1879 ;------------------------------------------------------------
                                   1880 ;Allocation info for local variables in function 'add_weak_mods'
                                   1881 ;------------------------------------------------------------
                                   1882 ;mods          Allocated with name '_add_weak_mods_mods_10000_414'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function add_weak_mods
                                   1887 ;	-----------------------------------------
      0085AE                       1888 _add_weak_mods:
      0085AE E5 82            [12] 1889 	mov	a,dpl
      0085B0 90 0A EA         [24] 1890 	mov	dptr,#_add_weak_mods_mods_10000_414
      0085B3 F0               [24] 1891 	movx	@dptr,a
                                   1892 ;	quantum/action_util.c:535: weak_mods |= mods;
      0085B4 E0               [24] 1893 	movx	a,@dptr
      0085B5 FF               [12] 1894 	mov	r7,a
      0085B6 90 0D F3         [24] 1895 	mov	dptr,#_weak_mods
      0085B9 E0               [24] 1896 	movx	a,@dptr
      0085BA 4F               [12] 1897 	orl	a,r7
      0085BB F0               [24] 1898 	movx	@dptr,a
                                   1899 ;	quantum/action_util.c:536: }
      0085BC 22               [24] 1900 	ret
                                   1901 ;------------------------------------------------------------
                                   1902 ;Allocation info for local variables in function 'del_weak_mods'
                                   1903 ;------------------------------------------------------------
                                   1904 ;mods          Allocated with name '_del_weak_mods_mods_10000_416'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function del_weak_mods
                                   1909 ;	-----------------------------------------
      0085BD                       1910 _del_weak_mods:
      0085BD E5 82            [12] 1911 	mov	a,dpl
      0085BF 90 0A EB         [24] 1912 	mov	dptr,#_del_weak_mods_mods_10000_416
      0085C2 F0               [24] 1913 	movx	@dptr,a
                                   1914 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      0085C3 E0               [24] 1915 	movx	a,@dptr
      0085C4 F4               [12] 1916 	cpl	a
      0085C5 FF               [12] 1917 	mov	r7,a
      0085C6 90 0D F3         [24] 1918 	mov	dptr,#_weak_mods
      0085C9 E0               [24] 1919 	movx	a,@dptr
      0085CA 5F               [12] 1920 	anl	a,r7
      0085CB F0               [24] 1921 	movx	@dptr,a
                                   1922 ;	quantum/action_util.c:543: }
      0085CC 22               [24] 1923 	ret
                                   1924 ;------------------------------------------------------------
                                   1925 ;Allocation info for local variables in function 'set_weak_mods'
                                   1926 ;------------------------------------------------------------
                                   1927 ;mods          Allocated with name '_set_weak_mods_mods_10000_418'
                                   1928 ;------------------------------------------------------------
                                   1929 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1930 ;	-----------------------------------------
                                   1931 ;	 function clear_weak_mods
                                   1932 ;	-----------------------------------------
      0085CD                       1933 _clear_weak_mods:
                                   1934 ;	quantum/action_util.c:556: weak_mods = 0;
      0085CD 90 0D F3         [24] 1935 	mov	dptr,#_weak_mods
      0085D0 E4               [12] 1936 	clr	a
      0085D1 F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action_util.c:557: }
      0085D2 22               [24] 1939 	ret
                                   1940 ;------------------------------------------------------------
                                   1941 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1942 ;------------------------------------------------------------
                                   1943 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_422'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1946 ;	-----------------------------------------
                                   1947 	.area CSEG    (CODE)
                                   1948 	.area CONST   (CODE)
                                   1949 	.area XINIT   (CODE)
      00C60A                       1950 __xinit__real_mods:
      00C60A 00                    1951 	.db #0x00	; 0
      00C60B                       1952 __xinit__weak_mods:
      00C60B 00                    1953 	.db #0x00	; 0
      00C60C                       1954 __xinit__actual_keyboard_report:
      00C60C 00                    1955 	.db #0x00	; 0
      00C60D 00                    1956 	.db #0x00	; 0
      00C60E 00                    1957 	.db #0x00	; 0
      00C60F 00                    1958 	.db #0x00	; 0
      00C610 00                    1959 	.db #0x00	; 0
      00C611 00                    1960 	.db #0x00	; 0
      00C612 00                    1961 	.db #0x00	; 0
      00C613 00                    1962 	.db #0x00	; 0
      00C614 00                    1963 	.db 0x00
      00C615 00                    1964 	.db 0x00
      00C616 00                    1965 	.db 0x00
      00C617 00                    1966 	.db 0x00
      00C618 00                    1967 	.db 0x00
      00C619 00                    1968 	.db 0x00
      00C61A 00                    1969 	.db 0x00
      00C61B 00                    1970 	.db 0x00
      00C61C 00                    1971 	.db 0x00
      00C61D 00                    1972 	.db 0x00
      00C61E 00                    1973 	.db 0x00
      00C61F 00                    1974 	.db 0x00
      00C620 00                    1975 	.db 0x00
      00C621 00                    1976 	.db 0x00
      00C622 00                    1977 	.db 0x00
      00C623 00                    1978 	.db 0x00
      00C624 00                    1979 	.db 0x00
      00C625 00                    1980 	.db 0x00
      00C626 00                    1981 	.db 0x00
      00C627 00                    1982 	.db 0x00
      00C628 00                    1983 	.db 0x00
      00C629 00                    1984 	.db 0x00
      00C62A 00                    1985 	.db 0x00
      00C62B 00                    1986 	.db 0x00
                                   1987 	.area CABS    (ABS,CODE)
                                   1988 
                                   1989 ; Experimental exact instruction outlining.
                                   1990 	.globl _ak820_outline_0016
                                   1991 	.globl _ak820_outline_0030
                                   1992 	.globl _ak820_outline_0051
                                   1993 	.globl _ak820_outline_0056
                                   1994 	.globl _ak820_outline_0059
                                   1995 	.globl _ak820_outline_0061
                                   1996 	.globl _ak820_outline_0062
                                   1997 	.globl _ak820_outline_0063
                                   1998 	.globl _ak820_outline_0067
                                   1999 	.globl _ak820_outline_0075
                                   2000 	.globl _ak820_outline_0107
                                   2001 	.globl _ak820_outline_0108
                                   2002 	.globl _ak820_outline_0117
                                   2003 	.globl _ak820_outline_0121
                                   2004 	.globl _ak820_outline_0123
                                   2005 	.globl _ak820_outline_0125
                                   2006 	.globl _ak820_outline_0132
                                   2007 	.globl _ak820_outline_0133
                                   2008 	.globl _ak820_outline_0135
                                   2009 	.globl _ak820_outline_0139
                                   2010 	.globl _ak820_outline_0143
                                   2011 	.globl _ak820_outline_0160
                                   2012 	.globl _ak820_outline_0161
                                   2013 	.globl _ak820_outline_0165
                                   2014 	.globl _ak820_outline_0175
                                   2015 	.globl _ak820_outline_0182
                                   2016 	.globl _ak820_outline_0188
                                   2017 	.globl _ak820_outline_0189
                                   2018 	.globl _ak820_outline_0190
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0030
      0085D3                       2022 _ak820_outline_0030:
      0085D3 EF               [12] 2023 	mov	a,r7
      0085D4 24 C2            [12] 2024 	add	a,#_key_refs
      0085D6 FD               [12] 2025 	mov	r5,a
      0085D7 E4               [12] 2026 	clr	a
      0085D8 34 09            [12] 2027 	addc	a,#(_key_refs>>8)
      0085DA FE               [12] 2028 	mov	r6,a
      0085DB 8D 82            [24] 2029 	mov	dpl,r5
      0085DD 8E 83            [24] 2030 	mov	dph,r6
      0085DF E0               [24] 2031 	movx	a,@dptr
      0085E0 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0062
      0085E1                       2036 _ak820_outline_0062:
      0085E1 89 82            [24] 2037 	mov	dpl,r1
      0085E3 8A 83            [24] 2038 	mov	dph,r2
      0085E5 E8               [12] 2039 	mov	a,r0
      0085E6 F0               [24] 2040 	movx	@dptr,a
      0085E7 22               [24] 2041 	ret
                                   2042 
                                   2043 	.area CSEG (CODE)
                                   2044 ; function ak820_outline_0067
      0085E8                       2045 _ak820_outline_0067:
      0085E8 24 9D            [12] 2046 	add	a,#_usage_order
      0085EA F5 82            [12] 2047 	mov	dpl,a
      0085EC E4               [12] 2048 	clr	a
      0085ED 34 0A            [12] 2049 	addc	a,#(_usage_order>>8)
      0085EF F5 83            [12] 2050 	mov	dph,a
      0085F1 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0075
      0085F2                       2055 _ak820_outline_0075:
      0085F2 EB               [12] 2056 	mov	a,r3
      0085F3 24 7F            [12] 2057 	add	a,#_usage_refs
      0085F5 F9               [12] 2058 	mov	r1,a
      0085F6 E4               [12] 2059 	clr	a
      0085F7 34 0A            [12] 2060 	addc	a,#(_usage_refs>>8)
      0085F9 FA               [12] 2061 	mov	r2,a
      0085FA 89 82            [24] 2062 	mov	dpl,r1
      0085FC 8A 83            [24] 2063 	mov	dph,r2
      0085FE E0               [24] 2064 	movx	a,@dptr
      0085FF F8               [12] 2065 	mov	r0,a
      008600 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0117
      008601                       2070 _ak820_outline_0117:
      008601 F0               [24] 2071 	movx	@dptr,a
      008602 E0               [24] 2072 	movx	a,@dptr
      008603 FF               [12] 2073 	mov	r7,a
      008604 90 09 BA         [24] 2074 	mov	dptr,#_change_owned_PARM_2
      008607 22               [24] 2075 	ret
                                   2076 
                                   2077 	.area CSEG (CODE)
                                   2078 ; function ak820_outline_0121
      008608                       2079 _ak820_outline_0121:
      008608 8D 82            [24] 2080 	mov	dpl,r5
      00860A 8E 83            [24] 2081 	mov	dph,r6
      00860C F0               [24] 2082 	movx	@dptr,a
      00860D 22               [24] 2083 	ret
                                   2084 
                                   2085 	.area CSEG (CODE)
                                   2086 ; function ak820_outline_0125
      00860E                       2087 _ak820_outline_0125:
      00860E 24 9D            [12] 2088 	add	a,#_usage_order
      008610 F5 82            [12] 2089 	mov	dpl,a
      008612 EF               [12] 2090 	mov	a,r7
      008613 34 0A            [12] 2091 	addc	a,#(_usage_order>>8)
      008615 F5 83            [12] 2092 	mov	dph,a
      008617 E0               [24] 2093 	movx	a,@dptr
      008618 22               [24] 2094 	ret
                                   2095 
                                   2096 	.area CSEG (CODE)
                                   2097 ; function ak820_outline_0132
      008619                       2098 _ak820_outline_0132:
      008619 F0               [24] 2099 	movx	@dptr,a
      00861A E0               [24] 2100 	movx	a,@dptr
      00861B FF               [12] 2101 	mov	r7,a
      00861C 90 09 B6         [24] 2102 	mov	dptr,#_ak820_macro_change_PARM_2
      00861F F0               [24] 2103 	movx	@dptr,a
      008620 90 09 B7         [24] 2104 	mov	dptr,#_ak820_macro_change_PARM_3
      008623 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0175
      008624                       2109 _ak820_outline_0175:
      008624 90 08 2B         [24] 2110 	mov	dptr,#_add_key_to_report_PARM_2
      008627 EF               [12] 2111 	mov	a,r7
      008628 F0               [24] 2112 	movx	@dptr,a
      008629 90 0D F4         [24] 2113 	mov	dptr,#_actual_keyboard_report
      00862C 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0190
      00862D                       2118 _ak820_outline_0190:
      00862D 8D 82            [24] 2119 	mov	dpl,r5
      00862F 8F 83            [24] 2120 	mov	dph,r7
      008631 22               [24] 2121 	ret
