                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005AE                        562 _source_state:
      0005AE                        563 	.ds 130
      000630                        564 _pending_time:
      000630                        565 	.ds 2
      000632                        566 _pending_code:
      000632                        567 	.ds 2
      000634                        568 _ak820_tapping_source_PARM_1:
      000634                        569 	.ds 2
      000636                        570 _hold_PARM_2:
      000636                        571 	.ds 1
      000637                        572 _hold_code_10000_603:
      000637                        573 	.ds 2
      000639                        574 _hold_mods_30000_606:
      000639                        575 	.ds 1
      00063A                        576 _commit_pending_id_10000_612:
      00063A                        577 	.ds 1
      00063B                        578 _ak820_tapping_before_event_10000_613:
      00063B                        579 	.ds 2
      00063D                        580 _ak820_tapping_process_record_10000_624:
      00063D                        581 	.ds 2
      00063F                        582 _ak820_tapping_process_code_10000_625:
      00063F                        583 	.ds 2
      000641                        584 _ak820_tapping_process_sc_mods_10000_625:
      000641                        585 	.ds 1
      000642                        586 _ak820_oneshot_mods::
      000642                        587 	.ds 1
      000643                        588 _ak820_oneshot_consumed::
      000643                        589 	.ds 1
      000644                        590 _ak820_oneshot_process_PARM_2:
      000644                        591 	.ds 1
      000645                        592 _ak820_oneshot_process_PARM_3:
      000645                        593 	.ds 1
      000646                        594 _ak820_oneshot_process_code_10000_650:
      000646                        595 	.ds 2
      000648                        596 _ak820_oneshot_process_mods_10000_651:
      000648                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DDF                        606 _pending:
      000DDF                        607 	.ds 1
      000DE0                        608 _ak820_oneshot_target::
      000DE0                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0045C8                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0045C8 90 06 35         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0045CB E0               [24]  656 	movx	a,@dptr
      0045CC FF               [12]  657 	mov	r7,a
      0045CD BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0045D0                        659 00147$:
      0045D0 50 14            [24]  660 	jnc	00102$
      0045D2 90 06 34         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045D5 E0               [24]  662 	movx	a,@dptr
      0045D6 FE               [12]  663 	mov	r6,a
      0045D7 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0045DA                        665 00149$:
      0045DA 50 0A            [24]  666 	jnc	00102$
      0045DC 8F 05            [24]  667 	mov	ar5,r7
      0045DE ED               [12]  668 	mov	a,r5
      0045DF 12 3B 06         [24]  669 	lcall	_ak820_outline_0191
      0045E2 2E               [12]  670 	add	a,r6
      0045E3 F5 82            [12]  671 	mov	dpl,a
      0045E5 22               [24]  672 	ret
      0045E6                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0045E6 90 06 34         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045E9 E0               [24]  676 	movx	a,@dptr
      0045EA FE               [12]  677 	mov	r6,a
      0045EB BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0045EE                        679 00151$:
      0045EE 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0045F0 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0045F3 75 82 80         [24]  683 	mov	dpl, #0x80
      0045F6 22               [24]  684 	ret
      0045F7                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0045F7 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0045FA 75 82 81         [24]  688 	mov	dpl, #0x81
      0045FD 22               [24]  689 	ret
      0045FE                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0045FE 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004601 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004602                        707 _hold:
      004602 12 3A C2         [24]  708 	lcall	_ak820_outline_0107
      004605 90 06 37         [24]  709 	mov	dptr,#_hold_code_10000_603
      004608 12 3A C7         [24]  710 	lcall	_ak820_outline_0108
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00460B 90 06 37         [24]  712 	mov	dptr,#_hold_code_10000_603
      00460E 12 4A 6F         [24]  713 	lcall	_ak820_outline_0008
      004611 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004613 2D               [12]  715 	add	a,r5
      004614 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004616 8F 05            [24]  718 	mov	ar5,r7
      004618 53 05 1F         [24]  719 	anl	ar5,#0x1f
      00461B 90 06 39         [24]  720 	mov	dptr,#_hold_mods_30000_606
      00461E ED               [12]  721 	mov	a,r5
      00461F F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004620 ED               [12]  724 	mov	a,r5
      004621 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004624 ED               [12]  726 	mov	a,r5
      004625 C4               [12]  727 	swap	a
      004626 54 F0            [12]  728 	anl	a,#0xf0
      004628 90 06 39         [24]  729 	mov	dptr,#_hold_mods_30000_606
      00462B F0               [24]  730 	movx	@dptr,a
      00462C                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      00462C 90 06 36         [24]  733 	mov	dptr,#_hold_PARM_2
      00462F E0               [24]  734 	movx	a,@dptr
      004630 60 09            [24]  735 	jz	00104$
      004632 90 06 39         [24]  736 	mov	dptr,#_hold_mods_30000_606
      004635 E0               [24]  737 	movx	a,@dptr
      004636 F5 82            [12]  738 	mov	dpl,a
      004638 02 7B 31         [24]  739 	ljmp	_register_mods
      00463B                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00463B 90 06 39         [24]  742 	mov	dptr,#_hold_mods_30000_606
      00463E E0               [24]  743 	movx	a,@dptr
      00463F F5 82            [12]  744 	mov	dpl,a
      004641 02 7B 45         [24]  745 	ljmp	_unregister_mods
      004644                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004644 8F 06            [24]  748 	mov	ar6,r7
      004646 74 0F            [12]  749 	mov	a,#0x0f
      004648 5E               [12]  750 	anl	a,r6
      004649 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00464A 90 06 36         [24]  753 	mov	dptr,#_hold_PARM_2
      00464D E0               [24]  754 	movx	a,@dptr
      00464E 60 05            [24]  755 	jz	00107$
      004650 8F 82            [24]  756 	mov	dpl, r7
      004652 02 7D 1D         [24]  757 	ljmp	_layer_hold_on
      004655                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004655 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004657 02 7D 54         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00465A                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00465A 90 0D DF         [24]  774 	mov	dptr,#_pending
      00465D E0               [24]  775 	movx	a,@dptr
      00465E 90 06 3A         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004661 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004662 12 4B 08         [24]  779 	lcall	_ak820_outline_0157
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004665 90 06 3A         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004668 E0               [24]  782 	movx	a,@dptr
      004669 24 AE            [12]  783 	add	a,#_source_state
      00466B FF               [12]  784 	mov	r7,a
      00466C E4               [12]  785 	clr	a
      00466D 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00466F FE               [12]  787 	mov	r6,a
      004670 12 45 AD         [24]  788 	lcall	_ak820_outline_0161
      004673 E0               [24]  789 	movx	a,@dptr
      004674 FD               [12]  790 	mov	r5,a
      004675 43 05 04         [24]  791 	orl	ar5,#0x04
      004678 12 45 AD         [24]  792 	lcall	_ak820_outline_0161
      00467B ED               [12]  793 	mov	a,r5
      00467C F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00467D 90 06 32         [24]  796 	mov	dptr,#_pending_code
      004680 12 3A 81         [24]  797 	lcall	_ak820_outline_0051
      004683 90 06 36         [24]  798 	mov	dptr,#_hold_PARM_2
      004686 74 01            [12]  799 	mov	a,#0x01
      004688 12 45 79         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00468B C1 02            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      00468D                        813 _ak820_tapping_before:
      00468D 12 3A C2         [24]  814 	lcall	_ak820_outline_0107
      004690 90 06 3B         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004693 12 3A C7         [24]  816 	lcall	_ak820_outline_0108
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      004696 90 06 3B         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004699 12 4A 6F         [24]  819 	lcall	_ak820_outline_0008
      00469C 12 4A 85         [24]  820 	lcall	_ak820_outline_0023
      00469F C0 07            [24]  821 	push	ar7
      0046A1 C0 06            [24]  822 	push	ar6
      0046A3 12 BC F6         [24]  823 	lcall	___memcpy
      0046A6 B1 C8            [12]  824 	acall	_ak820_tapping_source
      0046A8 AD 82            [24]  825 	mov	r5, dpl
      0046AA D0 06            [24]  826 	pop	ar6
      0046AC D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0046AE 90 0E 50         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0046B1 E0               [24]  830 	movx	a,@dptr
      0046B2 60 1E            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0046B4 12 4A F4         [24]  833 	lcall	_ak820_outline_0097
      0046B7 60 15            [24]  834 	jz	00102$
      0046B9 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0046BC 80 10            [24]  836 	sjmp	00102$
      0046BE                        837 00218$:
      0046BE 12 4A 79         [24]  838 	lcall	_ak820_outline_0015
      0046C1 E0               [24]  839 	movx	a,@dptr
      0046C2 70 0A            [24]  840 	jnz	00102$
      0046C4 ED               [12]  841 	mov	a,r5
      0046C5 12 4A 9F         [24]  842 	lcall	_ak820_outline_0026
      0046C8 53 02 FD         [24]  843 	anl	ar2,#0xfd
      0046CB 12 4A ED         [24]  844 	lcall	_ak820_outline_0094
      0046CE                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0046CE 75 82 00         [24]  847 	mov	dpl, #0x00
      0046D1 22               [24]  848 	ret
      0046D2                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0046D2 90 0D DF         [24]  851 	mov	dptr,#_pending
      0046D5 E0               [24]  852 	movx	a,@dptr
      0046D6 FC               [12]  853 	mov	r4,a
      0046D7 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      0046DA 80 3A            [24]  855 	sjmp	00108$
      0046DC                        856 00220$:
      0046DC 12 3A 79         [24]  857 	lcall	_ak820_outline_0036
      0046DF FA               [12]  858 	mov	r2,a
      0046E0 A3               [24]  859 	inc	dptr
      0046E1 E0               [24]  860 	movx	a,@dptr
      0046E2 FB               [12]  861 	mov	r3,a
      0046E3 90 06 30         [24]  862 	mov	dptr,#_pending_time
      0046E6 12 3A BC         [24]  863 	lcall	_ak820_outline_0102
      0046E9 EA               [12]  864 	mov	a,r2
      0046EA C3               [12]  865 	clr	c
      0046EB 98               [12]  866 	subb	a,r0
      0046EC FA               [12]  867 	mov	r2,a
      0046ED EB               [12]  868 	mov	a,r3
      0046EE 99               [12]  869 	subb	a,r1
      0046EF FB               [12]  870 	mov	r3,a
      0046F0 C3               [12]  871 	clr	c
      0046F1 EA               [12]  872 	mov	a,r2
      0046F2 94 C8            [12]  873 	subb	a,#0xc8
      0046F4 EB               [12]  874 	mov	a,r3
      0046F5 94 00            [12]  875 	subb	a,#0x00
      0046F7 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0046F9 74 04            [12]  878 	mov	a,#0x04
      0046FB 12 4A AD         [24]  879 	lcall	_ak820_outline_0032
      0046FE 60 16            [24]  880 	jz	00108$
      004700 12 3A 52         [24]  881 	lcall	_ak820_outline_0009
      004703 60 11            [24]  882 	jz	00108$
      004705 BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      004708 80 06            [24]  884 	sjmp	00107$
      00470A                        885 00224$:
      00470A ED               [12]  886 	mov	a,r5
      00470B B5 04 02         [24]  887 	cjne	a,ar4,00225$
      00470E 80 06            [24]  888 	sjmp	00108$
      004710                        889 00225$:
      004710                        890 00107$:
      004710 C0 05            [24]  891 	push	ar5
      004712 D1 5A            [12]  892 	acall	_commit_pending
      004714 D0 05            [24]  893 	pop	ar5
      004716                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004716 90 06 3B         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004719 12 3A 81         [24]  897 	lcall	_ak820_outline_0051
      00471C 12 4A F4         [24]  898 	lcall	_ak820_outline_0097
      00471F 60 03            [24]  899 	jz	00114$
      004721 BD FF 04         [24]  900 	cjne	r5,#0xff,00115$
      004724                        901 00114$:
      004724 75 82 01         [24]  902 	mov	dpl, #0x01
      004727 22               [24]  903 	ret
      004728                        904 00115$:
                                    905 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004728 ED               [12]  906 	mov	a,r5
      004729 12 4A DF         [24]  907 	lcall	_ak820_outline_0078
      00472C 30 E1 13         [24]  908 	jnb	acc.1,00120$
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00472F 74 05            [12]  910 	mov	a,#0x05
      004731 2E               [12]  911 	add	a, r6
      004732 12 3A 5F         [24]  912 	lcall	_ak820_outline_0016
      004735 70 07            [24]  913 	jnz	00118$
      004737 74 FD            [12]  914 	mov	a,#0xfd
      004739 5B               [12]  915 	anl	a,r3
      00473A 12 3A D7         [24]  916 	lcall	_ak820_outline_0124
      00473D F0               [24]  917 	movx	@dptr,a
      00473E                        918 00118$:
                                    919 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00473E 75 82 00         [24]  920 	mov	dpl, #0x00
      004741 22               [24]  921 	ret
      004742                        922 00120$:
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004742 12 45 43         [24]  924 	lcall	_ak820_outline_0011
      004745 E0               [24]  925 	movx	a,@dptr
      004746 FF               [12]  926 	mov	r7,a
      004747 8B 06            [24]  927 	mov	ar6,r3
      004749 53 06 01         [24]  928 	anl	ar6,#0x01
      00474C EE               [12]  929 	mov	a,r6
      00474D B4 01 00         [24]  930 	cjne	a,#0x01,00231$
      004750                        931 00231$:
      004750 B3               [12]  932 	cpl	c
      004751 92 0F            [24]  933 	mov	_ak820_tapping_before_sloc0_1_0,c
      004753 8F F0            [24]  934 	mov	b,r7
      004755 E4               [12]  935 	clr	a
      004756 33               [12]  936 	rlc	a
      004757 B5 F0 04         [24]  937 	cjne	a,b,00122$
      00475A 75 82 00         [24]  938 	mov	dpl, #0x00
      00475D 22               [24]  939 	ret
      00475E                        940 00122$:
                                    941 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00475E 63 03 01         [24]  942 	xrl	ar3,#0x01
      004761 12 3A D7         [24]  943 	lcall	_ak820_outline_0124
      004764 EB               [12]  944 	mov	a,r3
      004765 F0               [24]  945 	movx	@dptr,a
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004766 75 82 01         [24]  947 	mov	dpl, #0x01
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004769 22               [24]  949 	ret
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    952 ;------------------------------------------------------------
                                    953 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    954 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    955 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    956 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    957 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    958 ;------------------------------------------------------------
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function ak820_tapping_process
                                    962 ;	-----------------------------------------
      00476A                        963 _ak820_tapping_process:
      00476A 12 3A C2         [24]  964 	lcall	_ak820_outline_0107
      00476D 90 06 3D         [24]  965 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004770 12 3A C7         [24]  966 	lcall	_ak820_outline_0108
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004773 90 06 41         [24]  968 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004776 E4               [12]  969 	clr	a
      004777 F0               [24]  970 	movx	@dptr,a
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004778 90 06 3D         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_624
      00477B 12 3A 81         [24]  973 	lcall	_ak820_outline_0051
      00477E 74 04            [12]  974 	mov	a,#0x04
      004780 12 4A B8         [24]  975 	lcall	_ak820_outline_0033
      004783 70 04            [24]  976 	jnz	00102$
      004785 75 82 01         [24]  977 	mov	dpl, #0x01
      004788 22               [24]  978 	ret
      004789                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      004789 8E 04            [24]  981 	mov	ar4,r6
      00478B 8F 05            [24]  982 	mov	ar5,r7
      00478D 12 4A 85         [24]  983 	lcall	_ak820_outline_0023
      004790 C0 07            [24]  984 	push	ar7
      004792 C0 06            [24]  985 	push	ar6
      004794 12 BC F6         [24]  986 	lcall	___memcpy
      004797 B1 C8            [12]  987 	acall	_ak820_tapping_source
      004799 AD 82            [24]  988 	mov	r5, dpl
      00479B D0 06            [24]  989 	pop	ar6
      00479D D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      00479F BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      0047A2 75 82 01         [24]  993 	mov	dpl, #0x01
      0047A5 22               [24]  994 	ret
      0047A6                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0047A6 74 07            [12]  997 	mov	a,#0x07
      0047A8 12 3A 71         [24]  998 	lcall	_ak820_outline_0021
      0047AB 12 3A 81         [24]  999 	lcall	_ak820_outline_0051
      0047AE 90 06 3F         [24] 1000 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047B1 12 4A CB         [24] 1001 	lcall	_ak820_outline_0058
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0047B4 BE 1A 15         [24] 1003 	cjne	r6,#0x1a,00111$
      0047B7 BF 7C 12         [24] 1004 	cjne	r7,#0x7c,00111$
      0047BA 90 06 3F         [24] 1005 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047BD 74 26            [12] 1006 	mov	a,#0x26
      0047BF F0               [24] 1007 	movx	@dptr,a
      0047C0 74 22            [12] 1008 	mov	a,#0x22
      0047C2 A3               [24] 1009 	inc	dptr
      0047C3 F0               [24] 1010 	movx	@dptr,a
      0047C4 90 06 41         [24] 1011 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0047C7 74 02            [12] 1012 	mov	a,#0x02
      0047C9 F0               [24] 1013 	movx	@dptr,a
      0047CA 80 28            [24] 1014 	sjmp	00112$
      0047CC                       1015 00111$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0047CC BE 1B 15         [24] 1017 	cjne	r6,#0x1b,00108$
      0047CF BF 7C 12         [24] 1018 	cjne	r7,#0x7c,00108$
      0047D2 90 06 3F         [24] 1019 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047D5 74 27            [12] 1020 	mov	a,#0x27
      0047D7 F0               [24] 1021 	movx	@dptr,a
      0047D8 74 32            [12] 1022 	mov	a,#0x32
      0047DA A3               [24] 1023 	inc	dptr
      0047DB F0               [24] 1024 	movx	@dptr,a
      0047DC 90 06 41         [24] 1025 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0047DF 74 20            [12] 1026 	mov	a,#0x20
      0047E1 F0               [24] 1027 	movx	@dptr,a
      0047E2 80 10            [24] 1028 	sjmp	00112$
      0047E4                       1029 00108$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0047E4 BE 1E 0D         [24] 1031 	cjne	r6,#0x1e,00112$
      0047E7 BF 7C 0A         [24] 1032 	cjne	r7,#0x7c,00112$
      0047EA 90 06 3F         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047ED 74 28            [12] 1034 	mov	a,#0x28
      0047EF F0               [24] 1035 	movx	@dptr,a
      0047F0 74 32            [12] 1036 	mov	a,#0x32
      0047F2 A3               [24] 1037 	inc	dptr
      0047F3 F0               [24] 1038 	movx	@dptr,a
      0047F4                       1039 00112$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      0047F4 90 06 3F         [24] 1041 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0047F7 E0               [24] 1042 	movx	a,@dptr
      0047F8 A3               [24] 1043 	inc	dptr
      0047F9 E0               [24] 1044 	movx	a,@dptr
      0047FA FF               [12] 1045 	mov	r7,a
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      0047FB BF 20 00         [24] 1047 	cjne	r7,#0x20,00242$
      0047FE                       1048 00242$:
      0047FE 40 05            [24] 1049 	jc	00113$
      004800 BF 50 00         [24] 1050 	cjne	r7,#0x50,00244$
      004803                       1051 00244$:
      004803 40 04            [24] 1052 	jc	00114$
      004805                       1053 00113$:
      004805 75 82 01         [24] 1054 	mov	dpl, #0x01
      004808 22               [24] 1055 	ret
      004809                       1056 00114$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004809 BF 40 00         [24] 1058 	cjne	r7,#0x40,00246$
      00480C                       1059 00246$:
      00480C 40 0C            [24] 1060 	jc	00117$
      00480E 53 07 0F         [24] 1061 	anl	ar7,#0x0f
      004811 BF 06 00         [24] 1062 	cjne	r7,#0x06,00248$
      004814                       1063 00248$:
      004814 40 04            [24] 1064 	jc	00117$
      004816 75 82 00         [24] 1065 	mov	dpl, #0x00
      004819 22               [24] 1066 	ret
      00481A                       1067 00117$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      00481A 90 06 3D         [24] 1069 	mov	dptr,#_ak820_tapping_process_record_10000_624
      00481D 12 3A 81         [24] 1070 	lcall	_ak820_outline_0051
      004820 12 4A 79         [24] 1071 	lcall	_ak820_outline_0015
      004823 E0               [24] 1072 	movx	a,@dptr
      004824 60 1E            [24] 1073 	jz	00131$
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004826 90 0D DF         [24] 1075 	mov	dptr,#_pending
      004829 ED               [12] 1076 	mov	a,r5
      00482A 12 45 4D         [24] 1077 	lcall	_ak820_outline_0031
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      00482D 12 3A 81         [24] 1079 	lcall	_ak820_outline_0051
      004830 90 06 30         [24] 1080 	mov	dptr,#_pending_time
      004833 12 4A CB         [24] 1081 	lcall	_ak820_outline_0058
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004836 90 06 3F         [24] 1083 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004839 12 3A 81         [24] 1084 	lcall	_ak820_outline_0051
      00483C 90 06 32         [24] 1085 	mov	dptr,#_pending_code
      00483F 12 4A CB         [24] 1086 	lcall	_ak820_outline_0058
      004842 01 F4            [12] 1087 	ajmp	00132$
      004844                       1088 00131$:
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004844 90 0D DF         [24] 1090 	mov	dptr,#_pending
      004847 E0               [24] 1091 	movx	a,@dptr
      004848 FF               [12] 1092 	mov	r7,a
      004849 ED               [12] 1093 	mov	a,r5
      00484A B5 07 02         [24] 1094 	cjne	a,ar7,00251$
      00484D 80 02            [24] 1095 	sjmp	00252$
      00484F                       1096 00251$:
      00484F 01 CC            [12] 1097 	ajmp	00128$
      004851                       1098 00252$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004851 12 4B 08         [24] 1100 	lcall	_ak820_outline_0157
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004854 90 06 41         [24] 1102 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004857 E0               [24] 1103 	movx	a,@dptr
      004858 FF               [12] 1104 	mov	r7,a
      004859 E0               [24] 1105 	movx	a,@dptr
      00485A 60 05            [24] 1106 	jz	00120$
      00485C 8F 82            [24] 1107 	mov	dpl, r7
      00485E 12 81 E2         [24] 1108 	lcall	_add_owned_mods
      004861                       1109 00120$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004861 90 06 3D         [24] 1111 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004864 12 3A 81         [24] 1112 	lcall	_ak820_outline_0051
      004867 74 07            [12] 1113 	mov	a,#0x07
      004869 2E               [12] 1114 	add	a, r6
      00486A FB               [12] 1115 	mov	r3,a
      00486B E4               [12] 1116 	clr	a
      00486C 3F               [12] 1117 	addc	a, r7
      00486D FC               [12] 1118 	mov	r4,a
      00486E 90 06 3F         [24] 1119 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004871 E0               [24] 1120 	movx	a,@dptr
      004872 F9               [12] 1121 	mov	r1,a
      004873 7A 00            [12] 1122 	mov	r2,#0x00
      004875 12 36 47         [24] 1123 	lcall	_ak820_outline_0123
      004878 E9               [12] 1124 	mov	a,r1
      004879 F0               [24] 1125 	movx	@dptr,a
      00487A EA               [12] 1126 	mov	a,r2
      00487B A3               [24] 1127 	inc	dptr
      00487C F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      00487D C3               [12] 1130 	clr	c
      00487E 04               [12] 1131 	inc	a
      00487F 99               [12] 1132 	subb	a,r1
      004880 50 38            [24] 1133 	jnc	00122$
                                   1134 ;	free result
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      004882 74 06            [12] 1136 	mov	a,#0x06
      004884 12 3A 71         [24] 1137 	lcall	_ak820_outline_0021
      004887 E0               [24] 1138 	movx	a,@dptr
      004888 54 0F            [12] 1139 	anl	a,#0x0f
      00488A 44 10            [12] 1140 	orl	a,#0x10
      00488C F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      00488D 12 4A 79         [24] 1143 	lcall	_ak820_outline_0015
      004890 74 01            [12] 1144 	mov	a,#0x01
      004892 F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004893 12 4A D8         [24] 1147 	lcall	_ak820_outline_0076
      004896 12 4B 01         [24] 1148 	lcall	_ak820_outline_0112
      004899 C0 07            [24] 1149 	push	ar7
      00489B C0 06            [24] 1150 	push	ar6
      00489D C0 04            [24] 1151 	push	ar4
      00489F C0 03            [24] 1152 	push	ar3
      0048A1 12 75 75         [24] 1153 	lcall	_process_record
      0048A4 D0 03            [24] 1154 	pop	ar3
      0048A6 D0 04            [24] 1155 	pop	ar4
      0048A8 D0 06            [24] 1156 	pop	ar6
      0048AA D0 07            [24] 1157 	pop	ar7
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0048AC 12 36 47         [24] 1159 	lcall	_ak820_outline_0123
      0048AF E4               [12] 1160 	clr	a
      0048B0 F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0048B1 FC               [12] 1163 	mov	r4,a
      0048B2 12 3A CC         [24] 1164 	lcall	_ak820_outline_0118
      0048B5 8C F0            [24] 1165 	mov	b, r4
      0048B7 12 75 75         [24] 1166 	lcall	_process_record
      0048BA                       1167 00122$:
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      0048BA 90 06 41         [24] 1169 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0048BD E0               [24] 1170 	movx	a,@dptr
      0048BE FF               [12] 1171 	mov	r7,a
      0048BF E0               [24] 1172 	movx	a,@dptr
      0048C0 60 32            [24] 1173 	jz	00132$
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      0048C2 8F 82            [24] 1175 	mov	dpl, r7
      0048C4 12 81 F1         [24] 1176 	lcall	_del_owned_mods
                                   1177 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      0048C7 12 85 15         [24] 1178 	lcall	_send_keyboard_report
      0048CA 80 28            [24] 1179 	sjmp	00132$
      0048CC                       1180 00128$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0048CC ED               [12] 1182 	mov	a,r5
      0048CD 24 AE            [12] 1183 	add	a, #_source_state
      0048CF FE               [12] 1184 	mov	r6,a
      0048D0 E4               [12] 1185 	clr	a
      0048D1 34 05            [12] 1186 	addc	a, #(_source_state >> 8)
      0048D3 FF               [12] 1187 	mov	r7,a
      0048D4 12 3A CC         [24] 1188 	lcall	_ak820_outline_0118
      0048D7 E0               [24] 1189 	movx	a,@dptr
      0048D8 FD               [12] 1190 	mov	r5,a
      0048D9 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      0048DC 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0048DF 12 3A CC         [24] 1194 	lcall	_ak820_outline_0118
      0048E2 ED               [12] 1195 	mov	a,r5
      0048E3 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      0048E4 90 06 3F         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048E7 12 3A 81         [24] 1199 	lcall	_ak820_outline_0051
      0048EA 90 06 36         [24] 1200 	mov	dptr,#_hold_PARM_2
      0048ED E4               [12] 1201 	clr	a
      0048EE 12 45 79         [24] 1202 	lcall	_ak820_outline_0071
      0048F1 12 46 02         [24] 1203 	lcall	_hold
      0048F4                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      0048F4 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      0048F7 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0048F8                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      0048F8 12 4B 08         [24] 1221 	lcall	_ak820_outline_0157
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0048FB 7F 00            [12] 1223 	mov	r7,#0x00
      0048FD                       1224 00103$:
      0048FD BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      004900                       1226 00122$:
      004900 50 1D            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004902 EF               [12] 1229 	mov	a,r7
      004903 24 AE            [12] 1230 	add	a, #_source_state
      004905 FD               [12] 1231 	mov	r5,a
      004906 E4               [12] 1232 	clr	a
      004907 34 05            [12] 1233 	addc	a, #(_source_state >> 8)
      004909 12 4A C3         [24] 1234 	lcall	_ak820_outline_0056
                                   1235 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      00490C 74 02            [12] 1236 	mov	a,#0x02
      00490E 5C               [12] 1237 	anl	a,r4
      00490F FB               [12] 1238 	mov	r3,a
      004910 53 04 01         [24] 1239 	anl	ar4,#0x01
      004913 EC               [12] 1240 	mov	a,r4
      004914 2C               [12] 1241 	add	a,r4
      004915 42 03            [12] 1242 	orl	ar3,a
      004917 12 3A DC         [24] 1243 	lcall	_ak820_outline_0133
      00491A EB               [12] 1244 	mov	a,r3
      00491B F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      00491C 0F               [12] 1247 	inc	r7
      00491D 80 DE            [24] 1248 	sjmp	00103$
      00491F                       1249 00105$:
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      00491F 22               [24] 1251 	ret
                                   1252 ;------------------------------------------------------------
                                   1253 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1254 ;------------------------------------------------------------
                                   1255 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1256 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1257 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1258 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1259 ;i             Allocated with name '_ak820_oneshot_process_i_40000_666'
                                   1260 ;------------------------------------------------------------
                                   1261 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1262 ;	-----------------------------------------
                                   1263 ;	 function ak820_oneshot_process
                                   1264 ;	-----------------------------------------
      004920                       1265 _ak820_oneshot_process:
      004920 12 3A C2         [24] 1266 	lcall	_ak820_outline_0107
      004923 90 06 46         [24] 1267 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004926 12 3A C7         [24] 1268 	lcall	_ak820_outline_0108
                                   1269 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004929 90 06 44         [24] 1270 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00492C E0               [24] 1271 	movx	a,@dptr
      00492D FF               [12] 1272 	mov	r7,a
      00492E BF FF 02         [24] 1273 	cjne	r7,#0xff,00265$
      004931 80 0B            [24] 1274 	sjmp	00101$
      004933                       1275 00265$:
      004933 C0 07            [24] 1276 	push	ar7
      004935 12 A7 0B         [24] 1277 	lcall	_get_repeat_key_count
      004938 E5 82            [12] 1278 	mov	a, dpl
      00493A D0 07            [24] 1279 	pop	ar7
      00493C 60 04            [24] 1280 	jz	00102$
      00493E                       1281 00101$:
      00493E 75 82 01         [24] 1282 	mov	dpl, #0x01
      004941 22               [24] 1283 	ret
      004942                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_tapping.c:148: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004942 90 06 46         [24] 1286 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004945 12 3A AA         [24] 1287 	lcall	_ak820_outline_0084
      004948 C3               [12] 1288 	clr	c
      004949 ED               [12] 1289 	mov	a,r5
      00494A 94 09            [12] 1290 	subb	a,#0x09
      00494C EE               [12] 1291 	mov	a,r6
      00494D 94 70            [12] 1292 	subb	a,#0x70
      00494F 40 0C            [24] 1293 	jc	00105$
      004951 74 0B            [12] 1294 	mov	a,#0x0b
      004953 9D               [12] 1295 	subb	a,r5
      004954 74 70            [12] 1296 	mov	a,#0x70
      004956 9E               [12] 1297 	subb	a,r6
      004957 40 04            [24] 1298 	jc	00105$
                                   1299 ;	free result
      004959 75 82 01         [24] 1300 	mov	dpl, #0x01
      00495C 22               [24] 1301 	ret
      00495D                       1302 00105$:
                                   1303 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00495D 90 06 46         [24] 1304 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004960 E0               [24] 1305 	movx	a,@dptr
      004961 FB               [12] 1306 	mov	r3,a
      004962 A3               [24] 1307 	inc	dptr
      004963 E0               [24] 1308 	movx	a,@dptr
      004964 F9               [12] 1309 	mov	r1,a
      004965 B9 52 02         [24] 1310 	cjne	r1,#0x52,00269$
      004968 80 02            [24] 1311 	sjmp	00270$
      00496A                       1312 00269$:
      00496A 41 0F            [12] 1313 	ajmp	00119$
      00496C                       1314 00270$:
      00496C 8B 02            [24] 1315 	mov	ar2,r3
      00496E 53 02 E0         [24] 1316 	anl	ar2,#0xe0
      004971 BA A0 02         [24] 1317 	cjne	r2,#0xa0,00271$
      004974 80 02            [24] 1318 	sjmp	00272$
      004976                       1319 00271$:
      004976 41 0F            [12] 1320 	ajmp	00119$
      004978                       1321 00272$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: mods = code & 15;
      004978 8B 02            [24] 1323 	mov	ar2,r3
      00497A 53 02 0F         [24] 1324 	anl	ar2,#0x0f
      00497D 90 06 48         [24] 1325 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004980 EA               [12] 1326 	mov	a,r2
      004981 F0               [24] 1327 	movx	@dptr,a
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: if (code & 16) mods <<= 4;
      004982 EB               [12] 1329 	mov	a,r3
      004983 30 E4 08         [24] 1330 	jnb	acc.4,00108$
      004986 EA               [12] 1331 	mov	a,r2
      004987 C4               [12] 1332 	swap	a
      004988 54 F0            [12] 1333 	anl	a,#0xf0
      00498A 90 06 48         [24] 1334 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      00498D F0               [24] 1335 	movx	@dptr,a
      00498E                       1336 00108$:
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: if (pressed) {
      00498E 90 06 45         [24] 1338 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004991 E0               [24] 1339 	movx	a,@dptr
      004992 60 2E            [24] 1340 	jz	00116$
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: source_state[id] |= SOURCE_ONESHOT;
      004994 EF               [12] 1342 	mov	a,r7
      004995 12 4A 9F         [24] 1343 	lcall	_ak820_outline_0026
      004998 43 02 08         [24] 1344 	orl	ar2,#0x08
      00499B 12 4A ED         [24] 1345 	lcall	_ak820_outline_0094
                                   1346 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: source_state[id] &= ~SOURCE_ONESHOT_USED;
      00499E 53 02 EF         [24] 1347 	anl	ar2,#0xef
      0049A1 12 4A ED         [24] 1348 	lcall	_ak820_outline_0094
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0049A4 90 0D E0         [24] 1350 	mov	dptr,#_ak820_oneshot_target
      0049A7 E0               [24] 1351 	movx	a,@dptr
      0049A8 FA               [12] 1352 	mov	r2,a
      0049A9 BA FF 02         [24] 1353 	cjne	r2,#0xff,00275$
      0049AC 80 09            [24] 1354 	sjmp	00110$
      0049AE                       1355 00275$:
      0049AE 12 4A D1         [24] 1356 	lcall	_ak820_outline_0063
      0049B1 43 02 10         [24] 1357 	orl	ar2,#0x10
      0049B4 12 4A ED         [24] 1358 	lcall	_ak820_outline_0094
      0049B7                       1359 00110$:
                                   1360 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: register_mods(mods);
      0049B7 90 06 48         [24] 1361 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0049BA E0               [24] 1362 	movx	a,@dptr
      0049BB F5 82            [12] 1363 	mov	dpl,a
      0049BD 12 7B 31         [24] 1364 	lcall	_register_mods
      0049C0 80 49            [24] 1365 	sjmp	00117$
      0049C2                       1366 00116$:
                                   1367 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: } else if (source_state[id] & SOURCE_ONESHOT) {
      0049C2 EF               [12] 1368 	mov	a,r7
      0049C3 12 4A 9F         [24] 1369 	lcall	_ak820_outline_0026
      0049C6 30 E3 42         [24] 1370 	jnb	acc.3,00117$
                                   1371 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0049C9 EA               [12] 1372 	mov	a,r2
      0049CA 20 E4 24         [24] 1373 	jb	acc.4,00112$
                                   1374 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: add_owned_mods(mods & ~ak820_oneshot_mods);
      0049CD 90 06 42         [24] 1375 	mov	dptr,#_ak820_oneshot_mods
      0049D0 E0               [24] 1376 	movx	a,@dptr
      0049D1 F4               [12] 1377 	cpl	a
      0049D2 FA               [12] 1378 	mov	r2,a
      0049D3 90 06 48         [24] 1379 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0049D6 E0               [24] 1380 	movx	a,@dptr
      0049D7 F9               [12] 1381 	mov	r1,a
      0049D8 52 02            [12] 1382 	anl	ar2,a
      0049DA 8A 82            [24] 1383 	mov	dpl, r2
      0049DC C0 04            [24] 1384 	push	ar4
      0049DE C0 03            [24] 1385 	push	ar3
      0049E0 C0 01            [24] 1386 	push	ar1
      0049E2 12 81 E2         [24] 1387 	lcall	_add_owned_mods
      0049E5 D0 01            [24] 1388 	pop	ar1
      0049E7 D0 03            [24] 1389 	pop	ar3
      0049E9 D0 04            [24] 1390 	pop	ar4
                                   1391 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: ak820_oneshot_mods |= mods;
      0049EB 90 06 42         [24] 1392 	mov	dptr,#_ak820_oneshot_mods
      0049EE E0               [24] 1393 	movx	a,@dptr
      0049EF 49               [12] 1394 	orl	a,r1
      0049F0 F0               [24] 1395 	movx	@dptr,a
      0049F1                       1396 00112$:
                                   1397 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: unregister_mods(mods);
      0049F1 90 06 48         [24] 1398 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      0049F4 E0               [24] 1399 	movx	a,@dptr
      0049F5 F5 82            [12] 1400 	mov	dpl,a
      0049F7 C0 04            [24] 1401 	push	ar4
      0049F9 C0 03            [24] 1402 	push	ar3
      0049FB 12 7B 45         [24] 1403 	lcall	_unregister_mods
      0049FE D0 03            [24] 1404 	pop	ar3
      004A00 D0 04            [24] 1405 	pop	ar4
                                   1406 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004A02 12 4A D1         [24] 1407 	lcall	_ak820_outline_0063
      004A05 53 02 E7         [24] 1408 	anl	ar2,#0xe7
      004A08 12 4A ED         [24] 1409 	lcall	_ak820_outline_0094
      004A0B                       1410 00117$:
                                   1411 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: return false;
      004A0B 75 82 00         [24] 1412 	mov	dpl, #0x00
      004A0E 22               [24] 1413 	ret
      004A0F                       1414 00119$:
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: if (pressed && code > KC_TRANSPARENT &&
      004A0F 90 06 45         [24] 1416 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A12 E0               [24] 1417 	movx	a,@dptr
      004A13 60 56            [24] 1418 	jz	00127$
      004A15 C3               [12] 1419 	clr	c
      004A16 74 01            [12] 1420 	mov	a,#0x01
      004A18 9D               [12] 1421 	subb	a,r5
      004A19 E4               [12] 1422 	clr	a
      004A1A 9E               [12] 1423 	subb	a,r6
      004A1B 50 4E            [24] 1424 	jnc	00127$
                                   1425 ;	free result
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004A1D C3               [12] 1427 	clr	c
      004A1E ED               [12] 1428 	mov	a,r5
      004A1F 94 E0            [12] 1429 	subb	a,#0xe0
      004A21 EE               [12] 1430 	mov	a,r6
      004A22 94 00            [12] 1431 	subb	a,#0x00
      004A24 40 07            [24] 1432 	jc	00132$
      004A26 74 E7            [12] 1433 	mov	a,#0xe7
      004A28 9D               [12] 1434 	subb	a,r5
      004A29 E4               [12] 1435 	clr	a
      004A2A 9E               [12] 1436 	subb	a,r6
      004A2B 50 3E            [24] 1437 	jnc	00127$
                                   1438 ;	free result
      004A2D                       1439 00132$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004A2D 74 AE            [12] 1441 	mov	a,#0x100 - 0x52
      004A2F 2E               [12] 1442 	add	a,r6
      004A30 50 09            [24] 1443 	jnc	00172$
      004A32 C3               [12] 1444 	clr	c
      004A33 74 DF            [12] 1445 	mov	a,#0xdf
      004A35 9D               [12] 1446 	subb	a,r5
      004A36 74 52            [12] 1447 	mov	a,#0x52
      004A38 9E               [12] 1448 	subb	a,r6
      004A39 50 30            [24] 1449 	jnc	00127$
                                   1450 ;	free result
                                   1451 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004A3B                       1452 00172$:
      004A3B 7E 00            [12] 1453 	mov	r6,#0x00
      004A3D                       1454 00134$:
      004A3D BE 82 00         [24] 1455 	cjne	r6,#0x82,00284$
      004A40                       1456 00284$:
      004A40 50 12            [24] 1457 	jnc	00123$
                                   1458 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004A42 EE               [12] 1459 	mov	a,r6
      004A43 12 4A DF         [24] 1460 	lcall	_ak820_outline_0078
      004A46 30 E3 08         [24] 1461 	jnb	acc.3,00135$
      004A49 43 03 10         [24] 1462 	orl	ar3,#0x10
      004A4C 12 3A D7         [24] 1463 	lcall	_ak820_outline_0124
      004A4F EB               [12] 1464 	mov	a,r3
      004A50 F0               [24] 1465 	movx	@dptr,a
      004A51                       1466 00135$:
                                   1467 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004A51 0E               [12] 1468 	inc	r6
      004A52 80 E9            [24] 1469 	sjmp	00134$
      004A54                       1470 00123$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: if (ak820_oneshot_mods) {
      004A54 90 06 42         [24] 1472 	mov	dptr,#_ak820_oneshot_mods
      004A57 E0               [24] 1473 	movx	a,@dptr
      004A58 FE               [12] 1474 	mov	r6,a
      004A59 E0               [24] 1475 	movx	a,@dptr
      004A5A 60 0F            [24] 1476 	jz	00127$
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A5C 90 06 43         [24] 1478 	mov	dptr,#_ak820_oneshot_consumed
      004A5F EE               [12] 1479 	mov	a,r6
      004A60 F0               [24] 1480 	movx	@dptr,a
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: ak820_oneshot_target = id;
      004A61 90 0D E0         [24] 1482 	mov	dptr,#_ak820_oneshot_target
      004A64 EF               [12] 1483 	mov	a,r7
      004A65 F0               [24] 1484 	movx	@dptr,a
                                   1485 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: ak820_oneshot_mods = 0;
      004A66 90 06 42         [24] 1486 	mov	dptr,#_ak820_oneshot_mods
      004A69 E4               [12] 1487 	clr	a
      004A6A F0               [24] 1488 	movx	@dptr,a
      004A6B                       1489 00127$:
                                   1490 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: return true;
      004A6B 75 82 01         [24] 1491 	mov	dpl, #0x01
                                   1492 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: }
      004A6E 22               [24] 1493 	ret
                                   1494 	.area CSEG    (CODE)
                                   1495 	.area CONST   (CODE)
                                   1496 	.area XINIT   (CODE)
      00C608                       1497 __xinit__pending:
      00C608 FF                    1498 	.db #0xff	; 255
      00C609                       1499 __xinit__ak820_oneshot_target:
      00C609 FF                    1500 	.db #0xff	; 255
                                   1501 	.area CABS    (ABS,CODE)
                                   1502 
                                   1503 ; Experimental exact instruction outlining.
                                   1504 	.globl _ak820_outline_0008
                                   1505 	.globl _ak820_outline_0009
                                   1506 	.globl _ak820_outline_0011
                                   1507 	.globl _ak820_outline_0015
                                   1508 	.globl _ak820_outline_0016
                                   1509 	.globl _ak820_outline_0021
                                   1510 	.globl _ak820_outline_0023
                                   1511 	.globl _ak820_outline_0026
                                   1512 	.globl _ak820_outline_0031
                                   1513 	.globl _ak820_outline_0032
                                   1514 	.globl _ak820_outline_0033
                                   1515 	.globl _ak820_outline_0036
                                   1516 	.globl _ak820_outline_0051
                                   1517 	.globl _ak820_outline_0056
                                   1518 	.globl _ak820_outline_0058
                                   1519 	.globl _ak820_outline_0063
                                   1520 	.globl _ak820_outline_0071
                                   1521 	.globl _ak820_outline_0076
                                   1522 	.globl _ak820_outline_0078
                                   1523 	.globl _ak820_outline_0084
                                   1524 	.globl _ak820_outline_0094
                                   1525 	.globl _ak820_outline_0097
                                   1526 	.globl _ak820_outline_0102
                                   1527 	.globl _ak820_outline_0107
                                   1528 	.globl _ak820_outline_0108
                                   1529 	.globl _ak820_outline_0112
                                   1530 	.globl _ak820_outline_0118
                                   1531 	.globl _ak820_outline_0123
                                   1532 	.globl _ak820_outline_0124
                                   1533 	.globl _ak820_outline_0133
                                   1534 	.globl _ak820_outline_0157
                                   1535 	.globl _ak820_outline_0161
                                   1536 	.globl _ak820_outline_0191
                                   1537 
                                   1538 	.area CSEG (CODE)
                                   1539 ; function ak820_outline_0008
      004A6F                       1540 _ak820_outline_0008:
      004A6F E0               [24] 1541 	movx	a,@dptr
      004A70 FE               [12] 1542 	mov	r6,a
      004A71 A3               [24] 1543 	inc	dptr
      004A72 E0               [24] 1544 	movx	a,@dptr
      004A73 FF               [12] 1545 	mov	r7,a
      004A74 8E 04            [24] 1546 	mov	ar4,r6
      004A76 8F 05            [24] 1547 	mov	ar5,r7
      004A78 22               [24] 1548 	ret
                                   1549 
                                   1550 	.area CSEG (CODE)
                                   1551 ; function ak820_outline_0015
      004A79                       1552 _ak820_outline_0015:
      004A79 74 05            [12] 1553 	mov	a,#0x05
      004A7B 2E               [12] 1554 	add	a,r6
      004A7C FB               [12] 1555 	mov	r3,a
      004A7D E4               [12] 1556 	clr	a
      004A7E 3F               [12] 1557 	addc	a,r7
      004A7F FC               [12] 1558 	mov	r4,a
      004A80 8B 82            [24] 1559 	mov	dpl,r3
      004A82 8C 83            [24] 1560 	mov	dph,r4
      004A84 22               [24] 1561 	ret
                                   1562 
                                   1563 	.area CSEG (CODE)
                                   1564 ; function ak820_outline_0023
      004A85                       1565 _ak820_outline_0023:
      004A85 90 0D CE         [24] 1566 	mov	dptr,#___memcpy_PARM_2
      004A88 EC               [12] 1567 	mov	a,r4
      004A89 F0               [24] 1568 	movx	@dptr,a
      004A8A ED               [12] 1569 	mov	a,r5
      004A8B A3               [24] 1570 	inc	dptr
      004A8C F0               [24] 1571 	movx	@dptr,a
      004A8D E4               [12] 1572 	clr	a
      004A8E A3               [24] 1573 	inc	dptr
      004A8F F0               [24] 1574 	movx	@dptr,a
      004A90 90 0D D1         [24] 1575 	mov	dptr,#___memcpy_PARM_3
      004A93 74 02            [12] 1576 	mov	a,#0x02
      004A95 F0               [24] 1577 	movx	@dptr,a
      004A96 E4               [12] 1578 	clr	a
      004A97 A3               [24] 1579 	inc	dptr
      004A98 F0               [24] 1580 	movx	@dptr,a
      004A99 90 06 34         [24] 1581 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A9C F5 F0            [12] 1582 	mov	b,a
      004A9E 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0026
      004A9F                       1587 _ak820_outline_0026:
      004A9F 24 AE            [12] 1588 	add	a,#_source_state
      004AA1 FB               [12] 1589 	mov	r3,a
      004AA2 E4               [12] 1590 	clr	a
      004AA3 34 05            [12] 1591 	addc	a,#(_source_state>>8)
      004AA5 FC               [12] 1592 	mov	r4,a
      004AA6 8B 82            [24] 1593 	mov	dpl,r3
      004AA8 8C 83            [24] 1594 	mov	dph,r4
      004AAA E0               [24] 1595 	movx	a,@dptr
      004AAB FA               [12] 1596 	mov	r2,a
      004AAC 22               [24] 1597 	ret
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0032
      004AAD                       1601 _ak820_outline_0032:
      004AAD 2E               [12] 1602 	add	a,r6
      004AAE FA               [12] 1603 	mov	r2,a
      004AAF E4               [12] 1604 	clr	a
      004AB0 3F               [12] 1605 	addc	a,r7
      004AB1 FB               [12] 1606 	mov	r3,a
      004AB2 8A 82            [24] 1607 	mov	dpl,r2
      004AB4 8B 83            [24] 1608 	mov	dph,r3
      004AB6 E0               [24] 1609 	movx	a,@dptr
      004AB7 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0033
      004AB8                       1614 _ak820_outline_0033:
      004AB8 2E               [12] 1615 	add	a,r6
      004AB9 FC               [12] 1616 	mov	r4,a
      004ABA E4               [12] 1617 	clr	a
      004ABB 3F               [12] 1618 	addc	a,r7
      004ABC FD               [12] 1619 	mov	r5,a
      004ABD 8C 82            [24] 1620 	mov	dpl,r4
      004ABF 8D 83            [24] 1621 	mov	dph,r5
      004AC1 E0               [24] 1622 	movx	a,@dptr
      004AC2 22               [24] 1623 	ret
                                   1624 
                                   1625 	.area CSEG (CODE)
                                   1626 ; function ak820_outline_0056
      004AC3                       1627 _ak820_outline_0056:
      004AC3 FE               [12] 1628 	mov	r6,a
      004AC4 8D 82            [24] 1629 	mov	dpl,r5
      004AC6 8E 83            [24] 1630 	mov	dph,r6
      004AC8 E0               [24] 1631 	movx	a,@dptr
      004AC9 FC               [12] 1632 	mov	r4,a
      004ACA 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0058
      004ACB                       1637 _ak820_outline_0058:
      004ACB EE               [12] 1638 	mov	a,r6
      004ACC F0               [24] 1639 	movx	@dptr,a
      004ACD EF               [12] 1640 	mov	a,r7
      004ACE A3               [24] 1641 	inc	dptr
      004ACF F0               [24] 1642 	movx	@dptr,a
      004AD0 22               [24] 1643 	ret
                                   1644 
                                   1645 	.area CSEG (CODE)
                                   1646 ; function ak820_outline_0063
      004AD1                       1647 _ak820_outline_0063:
      004AD1 8B 82            [24] 1648 	mov	dpl,r3
      004AD3 8C 83            [24] 1649 	mov	dph,r4
      004AD5 E0               [24] 1650 	movx	a,@dptr
      004AD6 FA               [12] 1651 	mov	r2,a
      004AD7 22               [24] 1652 	ret
                                   1653 
                                   1654 	.area CSEG (CODE)
                                   1655 ; function ak820_outline_0076
      004AD8                       1656 _ak820_outline_0076:
      004AD8 8E 00            [24] 1657 	mov	ar0,r6
      004ADA 8F 01            [24] 1658 	mov	ar1,r7
      004ADC 7A 00            [12] 1659 	mov	r2,#0x00
      004ADE 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0078
      004ADF                       1664 _ak820_outline_0078:
      004ADF 24 AE            [12] 1665 	add	a,#_source_state
      004AE1 FC               [12] 1666 	mov	r4,a
      004AE2 E4               [12] 1667 	clr	a
      004AE3 34 05            [12] 1668 	addc	a,#(_source_state>>8)
      004AE5 FD               [12] 1669 	mov	r5,a
      004AE6 8C 82            [24] 1670 	mov	dpl,r4
      004AE8 8D 83            [24] 1671 	mov	dph,r5
      004AEA E0               [24] 1672 	movx	a,@dptr
      004AEB FB               [12] 1673 	mov	r3,a
      004AEC 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0094
      004AED                       1678 _ak820_outline_0094:
      004AED 8B 82            [24] 1679 	mov	dpl,r3
      004AEF 8C 83            [24] 1680 	mov	dph,r4
      004AF1 EA               [12] 1681 	mov	a,r2
      004AF2 F0               [24] 1682 	movx	@dptr,a
      004AF3 22               [24] 1683 	ret
                                   1684 
                                   1685 	.area CSEG (CODE)
                                   1686 ; function ak820_outline_0097
      004AF4                       1687 _ak820_outline_0097:
      004AF4 74 04            [12] 1688 	mov	a,#0x04
      004AF6 2E               [12] 1689 	add	a,r6
      004AF7 FB               [12] 1690 	mov	r3,a
      004AF8 E4               [12] 1691 	clr	a
      004AF9 3F               [12] 1692 	addc	a,r7
      004AFA FC               [12] 1693 	mov	r4,a
      004AFB 8B 82            [24] 1694 	mov	dpl,r3
      004AFD 8C 83            [24] 1695 	mov	dph,r4
      004AFF E0               [24] 1696 	movx	a,@dptr
      004B00 22               [24] 1697 	ret
                                   1698 
                                   1699 	.area CSEG (CODE)
                                   1700 ; function ak820_outline_0112
      004B01                       1701 _ak820_outline_0112:
      004B01 88 82            [24] 1702 	mov	dpl,r0
      004B03 89 83            [24] 1703 	mov	dph,r1
      004B05 8A F0            [24] 1704 	mov	b,r2
      004B07 22               [24] 1705 	ret
                                   1706 
                                   1707 	.area CSEG (CODE)
                                   1708 ; function ak820_outline_0157
      004B08                       1709 _ak820_outline_0157:
      004B08 90 0D DF         [24] 1710 	mov	dptr,#_pending
      004B0B 74 FF            [12] 1711 	mov	a,#0xff
      004B0D F0               [24] 1712 	movx	@dptr,a
      004B0E 22               [24] 1713 	ret
