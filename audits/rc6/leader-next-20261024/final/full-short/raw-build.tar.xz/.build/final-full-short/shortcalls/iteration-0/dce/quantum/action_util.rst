                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00096F                        580 _owned_mod_refs:
      00096F                        581 	.ds 8
      000977                        582 _owned_weak_refs:
      000977                        583 	.ds 8
      00097F                        584 _owned_mods:
      00097F                        585 	.ds 1
      000980                        586 _owned_weak_mods:
      000980                        587 	.ds 1
      000981                        588 _macro_mods:
      000981                        589 	.ds 2
      000983                        590 _ak820_macro_primitive::
      000983                        591 	.ds 1
      000984                        592 _ak820_macro_cancelled::
      000984                        593 	.ds 1
      000985                        594 _ak820_macro_change_PARM_2:
      000985                        595 	.ds 1
      000986                        596 _ak820_macro_change_PARM_3:
      000986                        597 	.ds 1
      000987                        598 _ak820_macro_change_bits_10000_293:
      000987                        599 	.ds 2
      000989                        600 _change_owned_PARM_2:
      000989                        601 	.ds 1
      00098A                        602 _change_owned_mods_10000_298:
      00098A                        603 	.ds 1
      00098B                        604 _change_owned_result_10001_302:
      00098B                        605 	.ds 1
      00098C                        606 _change_owned_bit_20001_303:
      00098C                        607 	.ds 1
      00098D                        608 _add_owned_mods_mods_10000_311:
      00098D                        609 	.ds 1
      00098E                        610 _del_owned_mods_mods_10000_313:
      00098E                        611 	.ds 1
      00098F                        612 _add_owned_weak_mods_mods_10000_315:
      00098F                        613 	.ds 1
      000990                        614 _del_owned_weak_mods_mods_10000_317:
      000990                        615 	.ds 1
      000991                        616 _key_refs:
      000991                        617 	.ds 165
      000A36                        618 _distinct_keys:
      000A36                        619 	.ds 1
      000A37                        620 _macro_keys:
      000A37                        621 	.ds 21
      000A4C                        622 _add_owned_key_code_10000_326:
      000A4C                        623 	.ds 1
      000A4D                        624 _del_owned_key_code_10000_341:
      000A4D                        625 	.ds 1
      000A4E                        626 _usage_refs:
      000A4E                        627 	.ds 30
      000A6C                        628 _usage_order:
      000A6C                        629 	.ds 30
      000A8A                        630 _usage_lengths:
      000A8A                        631 	.ds 2
      000A8C                        632 _macro_usages:
      000A8C                        633 	.ds 4
      000A90                        634 _owned_usage_key_PARM_2:
      000A90                        635 	.ds 1
      000A91                        636 _owned_usage_key_code_10000_368:
      000A91                        637 	.ds 1
      000A92                        638 _owned_usage_key___200000085_20000_369:
      000A92                        639 	.ds 2
      000A94                        640 _owned_usage_key_which_10000_369:
      000A94                        641 	.ds 1
      000A95                        642 _owned_usage_key_count_10000_369:
      000A95                        643 	.ds 1
      000A96                        644 _owned_usage_key_pos_30001_376:
      000A96                        645 	.ds 1
      000A97                        646 _owned_usage_key_key_40000_381:
      000A97                        647 	.ds 1
      000A98                        648 _send_keyboard_report_last_report_10001_388:
      000A98                        649 	.ds 32
      000AB8                        650 _send_keyboard_report_changed_10001_388:
      000AB8                        651 	.ds 1
      000AB9                        652 _add_weak_mods_mods_10000_406:
      000AB9                        653 	.ds 1
      000ABA                        654 _del_weak_mods_mods_10000_408:
      000ABA                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC0                        664 _real_mods:
      000DC0                        665 	.ds 1
      000DC1                        666 _weak_mods:
      000DC1                        667 	.ds 1
      000DC2                        668 _actual_keyboard_report::
      000DC2                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007AC5                        713 _ak820_macro_change:
      007AC5 12 38 75         [24]  714 	lcall	_ak820_outline_0107
      007AC8 90 09 87         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007ACB 12 38 7A         [24]  716 	lcall	_ak820_outline_0108
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      007ACE 90 09 83         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007AD1 E0               [24]  719 	movx	a,@dptr
      007AD2 70 04            [24]  720 	jnz	00102$
      007AD4 75 82 01         [24]  721 	mov	dpl, #0x01
      007AD7 22               [24]  722 	ret
      007AD8                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007AD8 90 09 85         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007ADB E0               [24]  726 	movx	a,@dptr
      007ADC FF               [12]  727 	mov	r7,a
      007ADD 74 07            [12]  728 	mov	a,#0x07
      007ADF 5F               [12]  729 	anl	a,r7
      007AE0 12 76 6E         [24]  730 	lcall	_ak820_outline_0061
      007AE3 80 02            [24]  731 	sjmp	00123$
      007AE5                        732 00122$:
      007AE5 25 E0            [12]  733 	add	a,acc
      007AE7                        734 00123$:
      007AE7 D5 F0 FB         [24]  735 	djnz	b,00122$
      007AEA FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      007AEB EF               [12]  738 	mov	a,r7
      007AEC 12 56 F3         [24]  739 	lcall	_ak820_outline_0188
      007AEF FF               [12]  740 	mov	r7,a
      007AF0 90 09 87         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AF3 12 38 4B         [24]  742 	lcall	_ak820_outline_0059
      007AF6 90 09 87         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AF9 EF               [12]  744 	mov	a,r7
      007AFA 2C               [12]  745 	add	a, r4
      007AFB F0               [24]  746 	movx	@dptr,a
      007AFC E4               [12]  747 	clr	a
      007AFD 3D               [12]  748 	addc	a, r5
      007AFE A3               [24]  749 	inc	dptr
      007AFF F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      007B00 90 09 87         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B03 E0               [24]  753 	movx	a,@dptr
      007B04 FD               [12]  754 	mov	r5,a
      007B05 A3               [24]  755 	inc	dptr
      007B06 E0               [24]  756 	movx	a,@dptr
      007B07 FF               [12]  757 	mov	r7,a
      007B08 12 80 42         [24]  758 	lcall	_ak820_outline_0189
      007B0B E0               [24]  759 	movx	a,@dptr
      007B0C FC               [12]  760 	mov	r4,a
      007B0D EE               [12]  761 	mov	a,r6
      007B0E 5C               [12]  762 	anl	a,r4
      007B0F B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007B12                        764 00124$:
      007B12 B3               [12]  765 	cpl	c
      007B13 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007B15 90 09 86         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007B18 E0               [24]  768 	movx	a,@dptr
      007B19 FB               [12]  769 	mov	r3,a
      007B1A A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007B1C E4               [12]  771 	clr	a
      007B1D 33               [12]  772 	rlc	a
      007B1E B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007B21 75 82 00         [24]  774 	mov	dpl, #0x00
      007B24 22               [24]  775 	ret
      007B25                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      007B25 EC               [12]  778 	mov	a,r4
      007B26 62 06            [12]  779 	xrl	ar6,a
      007B28 12 80 42         [24]  780 	lcall	_ak820_outline_0189
      007B2B EE               [12]  781 	mov	a,r6
      007B2C F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      007B2D 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      007B30 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007B31                        805 _change_owned:
      007B31 E5 82            [12]  806 	mov	a,dpl
      007B33 90 09 8A         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007B36 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007B37 90 09 89         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007B3A E0               [24]  811 	movx	a,@dptr
      007B3B FF               [12]  812 	mov	r7,a
      007B3C C3               [12]  813 	clr	c
      007B3D 13               [12]  814 	rrc	a
      007B3E FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      007B3F 53 07 01         [24]  817 	anl	ar7,#0x01
      007B42 EF               [12]  818 	mov	a,r7
      007B43 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007B46                        820 00205$:
      007B46 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007B48 B3               [12]  822 	cpl	c
      007B49 E4               [12]  823 	clr	a
      007B4A 33               [12]  824 	rlc	a
      007B4B F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007B4D EE               [12]  827 	mov	a,r6
      007B4E 60 06            [24]  828 	jz	00121$
      007B50 7D 77            [12]  829 	mov	r5,#_owned_weak_refs
      007B52 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007B54 80 04            [24]  831 	sjmp	00122$
      007B56                        832 00121$:
      007B56 7D 6F            [12]  833 	mov	r5,#_owned_mod_refs
      007B58 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007B5A                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007B5A 90 09 83         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007B5D E0               [24]  838 	movx	a,@dptr
      007B5E 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      007B60 EE               [12]  841 	mov	a,r6
      007B61 24 81            [12]  842 	add	a, #_macro_mods
      007B63 FB               [12]  843 	mov	r3,a
      007B64 E4               [12]  844 	clr	a
      007B65 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007B67 12 48 65         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007B6A E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007B6C 60 0A            [24]  849 	jz	00123$
      007B6E 90 09 8A         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007B71 E0               [24]  851 	movx	a,@dptr
      007B72 F9               [12]  852 	mov	r1,a
      007B73 EA               [12]  853 	mov	a,r2
      007B74 42 01            [12]  854 	orl	ar1,a
      007B76 80 07            [24]  855 	sjmp	00124$
      007B78                        856 00123$:
      007B78 90 09 8A         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007B7B E0               [24]  858 	movx	a,@dptr
      007B7C F4               [12]  859 	cpl	a
      007B7D 5A               [12]  860 	anl	a,r2
      007B7E F9               [12]  861 	mov	r1,a
      007B7F                        862 00124$:
      007B7F 12 33 FC         [24]  863 	lcall	_ak820_outline_0123
      007B82 E9               [12]  864 	mov	a,r1
      007B83 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007B84 E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007B86 60 06            [24]  868 	jz	00125$
      007B88 74 FF            [12]  869 	mov	a,#0xff
      007B8A 6A               [12]  870 	xrl	a,r2
      007B8B FC               [12]  871 	mov	r4,a
      007B8C 80 02            [24]  872 	sjmp	00126$
      007B8E                        873 00125$:
      007B8E 8A 04            [24]  874 	mov	ar4,r2
      007B90                        875 00126$:
      007B90 90 09 8A         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007B93 E0               [24]  877 	movx	a,@dptr
      007B94 5C               [12]  878 	anl	a,r4
      007B95 F0               [24]  879 	movx	@dptr,a
      007B96                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      007B96 90 09 8B         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007B99 E4               [12]  883 	clr	a
      007B9A F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007B9B 90 09 8C         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007B9E 04               [12]  887 	inc	a
      007B9F F0               [24]  888 	movx	@dptr,a
      007BA0 90 09 8A         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007BA3 E0               [24]  890 	movx	a,@dptr
      007BA4 FC               [12]  891 	mov	r4,a
      007BA5 7B 00            [12]  892 	mov	r3,#0x00
      007BA7                        893 00117$:
      007BA7 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007BAA                        895 00210$:
      007BAA 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      007BAC 90 09 8C         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007BAF E0               [24]  899 	movx	a,@dptr
      007BB0 5C               [12]  900 	anl	a,r4
      007BB1 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007BB3 E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007BB5 60 0C            [24]  904 	jz	00106$
      007BB7 EB               [12]  905 	mov	a,r3
      007BB8 2D               [12]  906 	add	a, r5
      007BB9 12 38 12         [24]  907 	lcall	_ak820_outline_0016
      007BBC F8               [12]  908 	mov	r0,a
      007BBD 08               [12]  909 	inc	r0
      007BBE 12 7F F6         [24]  910 	lcall	_ak820_outline_0062
      007BC1 80 0C            [24]  911 	sjmp	00109$
      007BC3                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007BC3 EB               [12]  914 	mov	a,r3
      007BC4 2D               [12]  915 	add	a, r5
      007BC5 12 38 12         [24]  916 	lcall	_ak820_outline_0016
      007BC8 F8               [12]  917 	mov	r0,a
      007BC9 60 04            [24]  918 	jz	00109$
      007BCB 18               [12]  919 	dec	r0
      007BCC 12 7F F6         [24]  920 	lcall	_ak820_outline_0062
      007BCF                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      007BCF EB               [12]  923 	mov	a,r3
      007BD0 2D               [12]  924 	add	a, r5
      007BD1 12 38 12         [24]  925 	lcall	_ak820_outline_0016
      007BD4 60 0B            [24]  926 	jz	00118$
      007BD6 90 09 8C         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007BD9 E0               [24]  928 	movx	a,@dptr
      007BDA FA               [12]  929 	mov	r2,a
      007BDB 90 09 8B         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007BDE E0               [24]  931 	movx	a,@dptr
      007BDF 4A               [12]  932 	orl	a,r2
      007BE0 F0               [24]  933 	movx	@dptr,a
      007BE1                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BE1 0B               [12]  936 	inc	r3
      007BE2 90 09 8C         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007BE5 E0               [24]  938 	movx	a,@dptr
      007BE6 25 E0            [12]  939 	add	a,acc
      007BE8 F0               [24]  940 	movx	@dptr,a
      007BE9 80 BC            [24]  941 	sjmp	00117$
      007BEB                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      007BEB EE               [12]  944 	mov	a,r6
      007BEC 60 09            [24]  945 	jz	00114$
      007BEE 90 09 8B         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007BF1 E0               [24]  947 	movx	a,@dptr
      007BF2 90 09 80         [24]  948 	mov	dptr,#_owned_weak_mods
      007BF5 F0               [24]  949 	movx	@dptr,a
      007BF6 22               [24]  950 	ret
      007BF7                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      007BF7 90 09 8B         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007BFA E0               [24]  954 	movx	a,@dptr
      007BFB 90 09 7F         [24]  955 	mov	dptr,#_owned_mods
      007BFE F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      007BFF 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007C00                        968 _add_owned_mods:
      007C00 E5 82            [12]  969 	mov	a,dpl
      007C02 90 09 8D         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007C05 12 80 16         [24]  971 	lcall	_ak820_outline_0117
      007C08 74 01            [12]  972 	mov	a,#0x01
      007C0A F0               [24]  973 	movx	@dptr,a
      007C0B 8F 82            [24]  974 	mov	dpl, r7
      007C0D 61 31            [12]  975 	ajmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007C0F                        985 _del_owned_mods:
      007C0F E5 82            [12]  986 	mov	a,dpl
      007C11 90 09 8E         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007C14 12 80 16         [24]  988 	lcall	_ak820_outline_0117
      007C17 E4               [12]  989 	clr	a
      007C18 F0               [24]  990 	movx	@dptr,a
      007C19 8F 82            [24]  991 	mov	dpl, r7
      007C1B 61 31            [12]  992 	ajmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007C1D                       1002 _add_owned_weak_mods:
      007C1D E5 82            [12] 1003 	mov	a,dpl
      007C1F 90 09 8F         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007C22 12 80 16         [24] 1005 	lcall	_ak820_outline_0117
      007C25 74 03            [12] 1006 	mov	a,#0x03
      007C27 F0               [24] 1007 	movx	@dptr,a
      007C28 8F 82            [24] 1008 	mov	dpl, r7
      007C2A 61 31            [12] 1009 	ajmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007C2C                       1019 _del_owned_weak_mods:
      007C2C E5 82            [12] 1020 	mov	a,dpl
      007C2E 90 09 90         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007C31 12 80 16         [24] 1022 	lcall	_ak820_outline_0117
      007C34 74 02            [12] 1023 	mov	a,#0x02
      007C36 F0               [24] 1024 	movx	@dptr,a
      007C37 8F 82            [24] 1025 	mov	dpl, r7
      007C39 61 31            [12] 1026 	ajmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007C3B                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007C3B 7F 00            [12] 1038 	mov	r7,#0x00
      007C3D                       1039 00103$:
      007C3D BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007C40                       1041 00122$:
      007C40 50 1A            [24] 1042 	jnc	00101$
      007C42 EF               [12] 1043 	mov	a,r7
      007C43 24 6F            [12] 1044 	add	a, #_owned_mod_refs
      007C45 FD               [12] 1045 	mov	r5,a
      007C46 E4               [12] 1046 	clr	a
      007C47 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007C49 FE               [12] 1048 	mov	r6,a
      007C4A EF               [12] 1049 	mov	a,r7
      007C4B 24 77            [12] 1050 	add	a, #_owned_weak_refs
      007C4D F5 82            [12] 1051 	mov	dpl,a
      007C4F E4               [12] 1052 	clr	a
      007C50 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007C52 F5 83            [12] 1054 	mov	dph,a
      007C54 E4               [12] 1055 	clr	a
      007C55 F0               [24] 1056 	movx	@dptr,a
      007C56 12 80 1D         [24] 1057 	lcall	_ak820_outline_0121
      007C59 0F               [12] 1058 	inc	r7
      007C5A 80 E1            [24] 1059 	sjmp	00103$
      007C5C                       1060 00101$:
                                   1061 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007C5C 90 09 82         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007C5F E4               [12] 1063 	clr	a
      007C60 F0               [24] 1064 	movx	@dptr,a
      007C61 90 09 81         [24] 1065 	mov	dptr,#_macro_mods
      007C64 F0               [24] 1066 	movx	@dptr,a
      007C65 90 09 80         [24] 1067 	mov	dptr,#_owned_weak_mods
      007C68 F0               [24] 1068 	movx	@dptr,a
      007C69 90 09 7F         [24] 1069 	mov	dptr,#_owned_mods
      007C6C F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007C6D 90 09 84         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007C70 04               [12] 1073 	inc	a
      007C71 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:114: }
      007C72 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007C73                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007C73 7F 00            [12] 1089 	mov	r7,#0x00
      007C75                       1090 00104$:
      007C75 EF               [12] 1091 	mov	a,r7
      007C76 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007C78 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007C7A EF               [12] 1095 	mov	a,r7
      007C7B 24 91            [12] 1096 	add	a, #_key_refs
      007C7D F5 82            [12] 1097 	mov	dpl,a
      007C7F E4               [12] 1098 	clr	a
      007C80 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007C82 12 7A B6         [24] 1100 	lcall	_ak820_outline_0163
      007C85 80 EE            [24] 1101 	sjmp	00104$
      007C87                       1102 00101$:
                                   1103 ;	quantum/action_util.c:122: distinct_keys = 0;
      007C87 90 0A 36         [24] 1104 	mov	dptr,#_distinct_keys
      007C8A E4               [12] 1105 	clr	a
      007C8B F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007C8C FF               [12] 1108 	mov	r7,a
      007C8D                       1109 00107$:
      007C8D BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007C90                       1111 00142$:
      007C90 50 0D            [24] 1112 	jnc	00109$
      007C92 EF               [12] 1113 	mov	a,r7
      007C93 24 37            [12] 1114 	add	a, #_macro_keys
      007C95 F5 82            [12] 1115 	mov	dpl,a
      007C97 E4               [12] 1116 	clr	a
      007C98 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007C9A 12 7A B6         [24] 1118 	lcall	_ak820_outline_0163
      007C9D 80 EE            [24] 1119 	sjmp	00107$
      007C9F                       1120 00109$:
                                   1121 ;	quantum/action_util.c:124: }
      007C9F 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007CA0                       1137 _add_owned_key:
      007CA0 E5 82            [12] 1138 	mov	a,dpl
      007CA2 90 0A 4C         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007CA5 12 80 2E         [24] 1140 	lcall	_ak820_outline_0132
                                   1141 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007CA8 74 01            [12] 1142 	mov	a,#0x01
      007CAA F0               [24] 1143 	movx	@dptr,a
      007CAB 90 0A 37         [24] 1144 	mov	dptr,#_macro_keys
      007CAE C0 07            [24] 1145 	push	ar7
      007CB0 51 C5            [12] 1146 	acall	_ak820_macro_change
      007CB2 E5 82            [12] 1147 	mov	a, dpl
      007CB4 D0 07            [24] 1148 	pop	ar7
      007CB6 70 03            [24] 1149 	jnz	00102$
      007CB8 F5 82            [12] 1150 	mov	dpl,a
      007CBA 22               [24] 1151 	ret
      007CBB                       1152 00102$:
                                   1153 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007CBB 12 7F E8         [24] 1154 	lcall	_ak820_outline_0030
      007CBE FC               [12] 1155 	mov	r4,a
      007CBF 04               [12] 1156 	inc	a
      007CC0 12 80 1D         [24] 1157 	lcall	_ak820_outline_0121
      007CC3 EC               [12] 1158 	mov	a,r4
      007CC4 60 04            [24] 1159 	jz	00104$
      007CC6 75 82 00         [24] 1160 	mov	dpl, #0x00
      007CC9 22               [24] 1161 	ret
      007CCA                       1162 00104$:
                                   1163 ;	quantum/action_util.c:128: ++distinct_keys;
      007CCA 90 0A 36         [24] 1164 	mov	dptr,#_distinct_keys
      007CCD E0               [24] 1165 	movx	a,@dptr
      007CCE 24 01            [12] 1166 	add	a, #0x01
      007CD0 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CD1 90 0D AF         [24] 1169 	mov	dptr,#_keyboard_protocol
      007CD4 E0               [24] 1170 	movx	a,@dptr
      007CD5 60 11            [24] 1171 	jz	00106$
      007CD7 90 0A BB         [24] 1172 	mov	dptr,#_keymap_config
      007CDA E0               [24] 1173 	movx	a,@dptr
      007CDB 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007CDE 12 80 39         [24] 1176 	lcall	_ak820_outline_0175
      007CE1 12 6E 5E         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CE4 75 82 01         [24] 1179 	mov	dpl, #0x01
      007CE7 22               [24] 1180 	ret
      007CE8                       1181 00106$:
                                   1182 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007CE8 90 0A 36         [24] 1183 	mov	dptr,#_distinct_keys
      007CEB E0               [24] 1184 	movx	a,@dptr
      007CEC 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007CEE 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007CF0 7F 00            [12] 1189 	mov	r7,#0x00
      007CF2                       1190 00115$:
      007CF2 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007CF5                       1192 00174$:
      007CF5 50 1E            [24] 1193 	jnc	00111$
      007CF7 EF               [12] 1194 	mov	a,r7
      007CF8 24 C4            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007CFA F5 82            [12] 1196 	mov	dpl,a
      007CFC E4               [12] 1197 	clr	a
      007CFD 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007CFF F5 83            [12] 1199 	mov	dph,a
      007D01 74 01            [12] 1200 	mov	a,#0x01
      007D03 F0               [24] 1201 	movx	@dptr,a
      007D04 0F               [12] 1202 	inc	r7
      007D05 80 EB            [24] 1203 	sjmp	00115$
      007D07                       1204 00110$:
                                   1205 ;	quantum/action_util.c:134: } else add_key(code);
      007D07 90 0A 4C         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007D0A E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D0B 90 07 FF         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007D0E F0               [24] 1210 	movx	@dptr,a
      007D0F 90 0D C2         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007D12 12 6E 5E         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:134: } else add_key(code);
      007D15                       1214 00111$:
                                   1215 ;	quantum/action_util.c:135: return true;
      007D15 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:136: }
      007D18 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007D19                       1235 _del_owned_key:
      007D19 E5 82            [12] 1236 	mov	a,dpl
      007D1B 90 0A 4D         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007D1E 12 80 2E         [24] 1238 	lcall	_ak820_outline_0132
                                   1239 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D21 E4               [12] 1240 	clr	a
      007D22 F0               [24] 1241 	movx	@dptr,a
      007D23 90 0A 37         [24] 1242 	mov	dptr,#_macro_keys
      007D26 C0 07            [24] 1243 	push	ar7
      007D28 51 C5            [12] 1244 	acall	_ak820_macro_change
      007D2A E5 82            [12] 1245 	mov	a, dpl
      007D2C D0 07            [24] 1246 	pop	ar7
      007D2E 70 03            [24] 1247 	jnz	00102$
      007D30 F5 82            [12] 1248 	mov	dpl,a
      007D32 22               [24] 1249 	ret
      007D33                       1250 00102$:
                                   1251 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007D33 12 7F E8         [24] 1252 	lcall	_ak820_outline_0030
      007D36 FC               [12] 1253 	mov	r4,a
      007D37 60 07            [24] 1254 	jz	00103$
      007D39 1C               [12] 1255 	dec	r4
      007D3A 12 43 2A         [24] 1256 	lcall	_ak820_outline_0063
      007D3D EC               [12] 1257 	mov	a,r4
      007D3E 60 04            [24] 1258 	jz	00104$
      007D40                       1259 00103$:
      007D40 75 82 00         [24] 1260 	mov	dpl, #0x00
      007D43 22               [24] 1261 	ret
      007D44                       1262 00104$:
                                   1263 ;	quantum/action_util.c:140: --distinct_keys;
      007D44 90 0A 36         [24] 1264 	mov	dptr,#_distinct_keys
      007D47 E0               [24] 1265 	movx	a,@dptr
      007D48 14               [12] 1266 	dec	a
      007D49 F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D4A 90 0D AF         [24] 1269 	mov	dptr,#_keyboard_protocol
      007D4D E0               [24] 1270 	movx	a,@dptr
      007D4E 60 16            [24] 1271 	jz	00107$
      007D50 90 0A BB         [24] 1272 	mov	dptr,#_keymap_config
      007D53 E0               [24] 1273 	movx	a,@dptr
      007D54 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D57 90 08 02         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      007D5A EF               [12] 1277 	mov	a,r7
      007D5B F0               [24] 1278 	movx	@dptr,a
      007D5C 90 0D C2         [24] 1279 	mov	dptr,#_actual_keyboard_report
      007D5F 12 6E 92         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D62 75 82 01         [24] 1282 	mov	dpl, #0x01
      007D65 22               [24] 1283 	ret
      007D66                       1284 00107$:
                                   1285 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007D66 90 0A 36         [24] 1286 	mov	dptr,#_distinct_keys
      007D69 E0               [24] 1287 	movx	a,@dptr
      007D6A FF               [12] 1288 	mov  r7,a
      007D6B 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007D6D 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007D6F 75 82 01         [24] 1292 	mov	dpl, #0x01
      007D72 22               [24] 1293 	ret
      007D73                       1294 00110$:
                                   1295 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007D73 BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D76 90 0D C2         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007D79 12 6E C6         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D7C 7F 04            [12] 1301 	mov	r7,#0x04
      007D7E                       1302 00122$:
      007D7E EF               [12] 1303 	mov	a,r7
      007D7F 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      007D81 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      007D83 12 7F E8         [24] 1307 	lcall	_ak820_outline_0030
      007D86 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D88 12 80 39         [24] 1310 	lcall	_ak820_outline_0175
      007D8B C0 07            [24] 1311 	push	ar7
      007D8D 12 6E 5E         [24] 1312 	lcall	_add_key_to_report
      007D90 D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D92                       1315 00123$:
      007D92 0F               [12] 1316 	inc	r7
      007D93 80 E9            [24] 1317 	sjmp	00122$
      007D95                       1318 00115$:
                                   1319 ;	quantum/action_util.c:149: } else del_key(code);
      007D95 90 0A 4D         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      007D98 E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D99 90 08 02         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      007D9C F0               [24] 1324 	movx	@dptr,a
      007D9D 90 0D C2         [24] 1325 	mov	dptr,#_actual_keyboard_report
      007DA0 12 6E 92         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:149: } else del_key(code);
      007DA3                       1328 00116$:
                                   1329 ;	quantum/action_util.c:150: return true;
      007DA3 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:151: }
      007DA6 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      007DA7                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007DA7 7F 00            [12] 1345 	mov	r7,#0x00
      007DA9                       1346 00104$:
      007DA9 BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      007DAC                       1348 00141$:
      007DAC 50 14            [24] 1349 	jnc	00101$
      007DAE EF               [12] 1350 	mov	a,r7
      007DAF 24 4E            [12] 1351 	add	a, #_usage_refs
      007DB1 FD               [12] 1352 	mov	r5,a
      007DB2 E4               [12] 1353 	clr	a
      007DB3 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      007DB5 FE               [12] 1355 	mov	r6,a
      007DB6 EF               [12] 1356 	mov	a,r7
      007DB7 12 7F FD         [24] 1357 	lcall	_ak820_outline_0067
      007DBA E4               [12] 1358 	clr	a
      007DBB F0               [24] 1359 	movx	@dptr,a
      007DBC 12 80 1D         [24] 1360 	lcall	_ak820_outline_0121
      007DBF 0F               [12] 1361 	inc	r7
      007DC0 80 E7            [24] 1362 	sjmp	00104$
      007DC2                       1363 00101$:
                                   1364 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007DC2 90 0A 8B         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      007DC5 E4               [12] 1366 	clr	a
      007DC6 F0               [24] 1367 	movx	@dptr,a
      007DC7 90 0A 8A         [24] 1368 	mov	dptr,#_usage_lengths
      007DCA F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007DCB FF               [12] 1371 	mov	r7,a
      007DCC                       1372 00107$:
      007DCC BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      007DCF                       1374 00143$:
      007DCF 50 0D            [24] 1375 	jnc	00109$
      007DD1 EF               [12] 1376 	mov	a,r7
      007DD2 24 8C            [12] 1377 	add	a, #_macro_usages
      007DD4 F5 82            [12] 1378 	mov	dpl,a
      007DD6 E4               [12] 1379 	clr	a
      007DD7 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      007DD9 12 7A B6         [24] 1381 	lcall	_ak820_outline_0163
      007DDC 80 EE            [24] 1382 	sjmp	00107$
      007DDE                       1383 00109$:
                                   1384 ;	quantum/action_util.c:165: }
      007DDE 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      007DDF                       1405 _owned_usage_key:
      007DDF E5 82            [12] 1406 	mov	a,dpl
      007DE1 90 0A 91         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      007DE4 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007DE5 E0               [24] 1410 	movx	a,@dptr
      007DE6 FF               [12] 1411 	mov	r7,a
      007DE7 BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      007DEA                       1413 00244$:
      007DEA B3               [12] 1414 	cpl	c
      007DEB 92 22            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      007DED E4               [12] 1416 	clr	a
      007DEE 33               [12] 1417 	rlc	a
      007DEF FF               [12] 1418 	mov	r7,a
      007DF0 90 0A 94         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      007DF3 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007DF4 EF               [12] 1422 	mov	a,r7
      007DF5 60 02            [24] 1423 	jz	00129$
      007DF7 74 03            [12] 1424 	mov	a,#0x03
      007DF9                       1425 00129$:
      007DF9 FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007DFA EF               [12] 1428 	mov	a,r7
      007DFB 24 8A            [12] 1429 	add	a, #_usage_lengths
      007DFD FD               [12] 1430 	mov	r5,a
      007DFE E4               [12] 1431 	clr	a
      007DFF 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      007E01 FF               [12] 1433 	mov	r7,a
      007E02 12 80 42         [24] 1434 	lcall	_ak820_outline_0189
      007E05 E0               [24] 1435 	movx	a,@dptr
      007E06 FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007E07 90 0A 91         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      007E0A E0               [24] 1439 	movx	a,@dptr
      007E0B 24 5B            [12] 1440 	add	a,#0x5b
      007E0D FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E0E 90 0A 90         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      007E11 E0               [24] 1444 	movx	a,@dptr
      007E12 FA               [12] 1445 	mov	r2,a
      007E13 90 09 85         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      007E16 EB               [12] 1447 	mov	a,r3
      007E17 F0               [24] 1448 	movx	@dptr,a
      007E18 90 09 86         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      007E1B EA               [12] 1450 	mov	a,r2
      007E1C F0               [24] 1451 	movx	@dptr,a
      007E1D 90 0A 8C         [24] 1452 	mov	dptr,#_macro_usages
      007E20 C0 07            [24] 1453 	push	ar7
      007E22 C0 06            [24] 1454 	push	ar6
      007E24 C0 05            [24] 1455 	push	ar5
      007E26 C0 04            [24] 1456 	push	ar4
      007E28 C0 03            [24] 1457 	push	ar3
      007E2A C0 02            [24] 1458 	push	ar2
      007E2C 51 C5            [12] 1459 	acall	_ak820_macro_change
      007E2E E5 82            [12] 1460 	mov	a, dpl
      007E30 D0 02            [24] 1461 	pop	ar2
      007E32 D0 03            [24] 1462 	pop	ar3
      007E34 D0 04            [24] 1463 	pop	ar4
      007E36 D0 05            [24] 1464 	pop	ar5
      007E38 D0 06            [24] 1465 	pop	ar6
      007E3A D0 07            [24] 1466 	pop	ar7
      007E3C 70 01            [24] 1467 	jnz	00102$
      007E3E 22               [24] 1468 	ret
      007E3F                       1469 00102$:
                                   1470 ;	quantum/action_util.c:172: if (pressed) {
      007E3F EA               [12] 1471 	mov	a,r2
      007E40 60 1A            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007E42 12 80 07         [24] 1474 	lcall	_ak820_outline_0075
      007E45 04               [12] 1475 	inc	a
      007E46 12 6B DD         [24] 1476 	lcall	_ak820_outline_0139
      007E49 E8               [12] 1477 	mov	a,r0
      007E4A 60 01            [24] 1478 	jz	00104$
      007E4C 22               [24] 1479 	ret
      007E4D                       1480 00104$:
                                   1481 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007E4D 90 0A 95         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      007E50 EC               [12] 1483 	mov	a,r4
      007E51 04               [12] 1484 	inc	a
      007E52 F0               [24] 1485 	movx	@dptr,a
      007E53 EC               [12] 1486 	mov	a,r4
      007E54 2E               [12] 1487 	add	a, r6
      007E55 12 7F FD         [24] 1488 	lcall	_ak820_outline_0067
      007E58 EB               [12] 1489 	mov	a,r3
      007E59 F0               [24] 1490 	movx	@dptr,a
      007E5A C1 BD            [12] 1491 	ajmp	00116$
      007E5C                       1492 00115$:
                                   1493 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007E5C 12 80 07         [24] 1494 	lcall	_ak820_outline_0075
      007E5F 60 07            [24] 1495 	jz	00105$
      007E61 18               [12] 1496 	dec	r0
      007E62 12 7F F6         [24] 1497 	lcall	_ak820_outline_0062
      007E65 E8               [12] 1498 	mov	a,r0
      007E66 60 01            [24] 1499 	jz	00106$
      007E68                       1500 00105$:
      007E68 22               [24] 1501 	ret
      007E69                       1502 00106$:
                                   1503 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007E69 7A 00            [12] 1504 	mov	r2,#0x00
      007E6B                       1505 00108$:
      007E6B EA               [12] 1506 	mov	a,r2
      007E6C 2E               [12] 1507 	add	a, r6
      007E6D 12 7F FD         [24] 1508 	lcall	_ak820_outline_0067
      007E70 E0               [24] 1509 	movx	a,@dptr
      007E71 B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      007E74 80 03            [24] 1511 	sjmp	00167$
      007E76                       1512 00251$:
      007E76 0A               [12] 1513 	inc	r2
      007E77 80 F2            [24] 1514 	sjmp	00108$
      007E79                       1515 00167$:
      007E79 90 0A 96         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      007E7C EA               [12] 1517 	mov	a,r2
      007E7D F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:179: --count;
      007E7E 1C               [12] 1520 	dec	r4
      007E7F 90 0A 95         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      007E82 EC               [12] 1522 	mov	a,r4
      007E83 F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007E84 8A 03            [24] 1525 	mov	ar3,r2
      007E86                       1526 00125$:
      007E86 C3               [12] 1527 	clr	c
      007E87 EB               [12] 1528 	mov	a,r3
      007E88 9C               [12] 1529 	subb	a,r4
      007E89 50 23            [24] 1530 	jnc	00111$
      007E8B C0 05            [24] 1531 	push	ar5
      007E8D C0 07            [24] 1532 	push	ar7
      007E8F EB               [12] 1533 	mov	a,r3
      007E90 2E               [12] 1534 	add	a, r6
      007E91 FA               [12] 1535 	mov	r2,a
      007E92 24 6C            [12] 1536 	add	a, #_usage_order
      007E94 F8               [12] 1537 	mov	r0,a
      007E95 E4               [12] 1538 	clr	a
      007E96 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      007E98 F9               [12] 1540 	mov	r1,a
      007E99 0A               [12] 1541 	inc	r2
      007E9A EA               [12] 1542 	mov	a,r2
      007E9B 33               [12] 1543 	rlc	a
      007E9C 95 E0            [12] 1544 	subb	a,acc
      007E9E FF               [12] 1545 	mov	r7,a
      007E9F EA               [12] 1546 	mov	a,r2
      007EA0 12 80 23         [24] 1547 	lcall	_ak820_outline_0125
      007EA3 12 38 A9         [24] 1548 	lcall	_ak820_outline_0157
      007EA6 F0               [24] 1549 	movx	@dptr,a
      007EA7 0B               [12] 1550 	inc	r3
      007EA8 D0 07            [24] 1551 	pop	ar7
      007EAA D0 05            [24] 1552 	pop	ar5
      007EAC 80 D8            [24] 1553 	sjmp	00125$
      007EAE                       1554 00111$:
                                   1555 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007EAE 12 80 42         [24] 1556 	lcall	_ak820_outline_0189
      007EB1 EC               [12] 1557 	mov	a,r4
      007EB2 F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007EB3 90 0A 96         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      007EB6 E0               [24] 1561 	movx	a,@dptr
      007EB7 B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      007EBA 80 01            [24] 1563 	sjmp	00116$
      007EBC                       1564 00253$:
      007EBC 22               [24] 1565 	ret
      007EBD                       1566 00116$:
                                   1567 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007EBD 90 0A 95         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      007EC0 E0               [24] 1569 	movx	a,@dptr
      007EC1 FC               [12] 1570 	mov	r4,a
      007EC2 12 80 42         [24] 1571 	lcall	_ak820_outline_0189
      007EC5 F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007EC6 EC               [12] 1574 	mov	a,r4
      007EC7 60 15            [24] 1575 	jz	00131$
      007EC9 EC               [12] 1576 	mov	a,r4
      007ECA 2E               [12] 1577 	add	a, r6
      007ECB FE               [12] 1578 	mov	r6,a
      007ECC 1E               [12] 1579 	dec	r6
      007ECD EE               [12] 1580 	mov	a,r6
      007ECE 33               [12] 1581 	rlc	a
      007ECF 95 E0            [12] 1582 	subb	a,acc
      007ED1 FF               [12] 1583 	mov	r7,a
      007ED2 EE               [12] 1584 	mov	a,r6
      007ED3 12 80 23         [24] 1585 	lcall	_ak820_outline_0125
      007ED6 24 A5            [12] 1586 	add	a,#0xa5
      007ED8 FE               [12] 1587 	mov	r6,a
      007ED9 33               [12] 1588 	rlc	a
      007EDA 95 E0            [12] 1589 	subb	a,acc
      007EDC 80 02            [24] 1590 	sjmp	00132$
      007EDE                       1591 00131$:
      007EDE 7E 00            [12] 1592 	mov	r6,#0x00
      007EE0                       1593 00132$:
      007EE0 90 0A 91         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      007EE3 EE               [12] 1595 	mov	a,r6
      007EE4 F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007EE5 90 0A 94         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      007EE8 E0               [24] 1599 	movx	a,@dptr
      007EE9 60 18            [24] 1600 	jz	00118$
      007EEB EE               [12] 1601 	mov	a,r6
      007EEC 60 0B            [24] 1602 	jz	00133$
      007EEE 8E 82            [24] 1603 	mov	dpl, r6
      007EF0 12 6D 1B         [24] 1604 	lcall	_KEYCODE2CONSUMER
      007EF3 AD 82            [24] 1605 	mov	r5, dpl
      007EF5 AF 83            [24] 1606 	mov	r7, dph
      007EF7 80 04            [24] 1607 	sjmp	00134$
      007EF9                       1608 00133$:
      007EF9 7D 00            [12] 1609 	mov	r5,#0x00
      007EFB 7F 00            [12] 1610 	mov	r7,#0x00
      007EFD                       1611 00134$:
      007EFD 12 80 42         [24] 1612 	lcall	_ak820_outline_0189
      007F00 02 6C CF         [24] 1613 	ljmp	_host_consumer_send
      007F03                       1614 00118$:
                                   1615 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F03 EE               [12] 1616 	mov	a,r6
      007F04 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007F06 BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      007F09                       1620 00258$:
      007F09 40 05            [24] 1621 	jc	00121$
      007F0B EE               [12] 1622 	mov	a,r6
      007F0C 24 58            [12] 1623 	add	a,#0xff - 0xa7
      007F0E 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      007F10                       1626 00121$:
      007F10 90 0A 92         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F13 12 4F 26         [24] 1628 	lcall	_ak820_outline_0182
      007F16 80 09            [24] 1629 	sjmp	00123$
      007F18                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F18 74 DC            [12] 1632 	mov	a,#0xdc
      007F1A 2E               [12] 1633 	add	a, r6
      007F1B 90 0A 92         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F1E 12 38 8F         [24] 1635 	lcall	_ak820_outline_0134
                                   1636 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F21                       1637 00123$:
      007F21 90 0A 92         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F24 E0               [24] 1639 	movx	a,@dptr
      007F25 FF               [12] 1640 	mov	r7,a
      007F26 80 02            [24] 1641 	sjmp	00136$
      007F28                       1642 00135$:
      007F28 7F 00            [12] 1643 	mov	r7,#0x00
      007F2A                       1644 00136$:
      007F2A 7E 00            [12] 1645 	mov	r6,#0x00
      007F2C 12 43 65         [24] 1646 	lcall	_ak820_outline_0158
                                   1647 ;	quantum/action_util.c:188: }
      007F2F 02 6C A0         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      007F32                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      007F32 90 0D C0         [24] 1664 	mov	dptr,#_real_mods
      007F35 E0               [24] 1665 	movx	a,@dptr
      007F36 FF               [12] 1666 	mov	r7,a
      007F37 90 0D C2         [24] 1667 	mov	dptr,#_actual_keyboard_report
      007F3A F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      007F3B 90 0D C1         [24] 1670 	mov	dptr,#_weak_mods
      007F3E E0               [24] 1671 	movx	a,@dptr
      007F3F 42 07            [12] 1672 	orl	ar7,a
      007F41 90 0D C2         [24] 1673 	mov	dptr,#_actual_keyboard_report
      007F44 EF               [12] 1674 	mov	a,r7
      007F45 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007F46 90 09 80         [24] 1677 	mov	dptr,#_owned_weak_mods
      007F49 E0               [24] 1678 	movx	a,@dptr
      007F4A FE               [12] 1679 	mov	r6,a
      007F4B 90 09 7F         [24] 1680 	mov	dptr,#_owned_mods
      007F4E E0               [24] 1681 	movx	a,@dptr
      007F4F 4E               [12] 1682 	orl	a,r6
      007F50 42 07            [12] 1683 	orl	ar7,a
      007F52 90 0D C2         [24] 1684 	mov	dptr,#_actual_keyboard_report
      007F55 EF               [12] 1685 	mov	a,r7
      007F56 F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:455: bool changed = false;
      007F57 90 0A B8         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F5A E4               [12] 1689 	clr	a
      007F5B F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1693 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F5C FF               [12] 1694 	mov	r7,a
      007F5D                       1695 00107$:
      007F5D BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      007F60                       1697 00140$:
      007F60 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      007F62 EF               [12] 1700 	mov	a,r7
      007F63 24 98            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      007F65 FD               [12] 1702 	mov	r5,a
      007F66 E4               [12] 1703 	clr	a
      007F67 34 0A            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007F69 FE               [12] 1705 	mov	r6,a
      007F6A 12 48 7A         [24] 1706 	lcall	_ak820_outline_0077
      007F6D EF               [12] 1707 	mov	a,r7
      007F6E 24 C2            [12] 1708 	add	a, #_actual_keyboard_report
      007F70 F5 82            [12] 1709 	mov	dpl,a
      007F72 E4               [12] 1710 	clr	a
      007F73 34 0D            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      007F75 F5 83            [12] 1712 	mov	dph,a
      007F77 E0               [24] 1713 	movx	a,@dptr
      007F78 FB               [12] 1714 	mov	r3,a
      007F79 EC               [12] 1715 	mov	a,r4
      007F7A B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      007F7D 80 0B            [24] 1717 	sjmp	00108$
      007F7F                       1718 00142$:
                                   1719 ;	quantum/action_util.c:465: dest[i] = src[i];
      007F7F 12 38 94         [24] 1720 	lcall	_ak820_outline_0135
      007F82 EB               [12] 1721 	mov	a,r3
      007F83 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:466: changed = true;
      007F84 90 0A B8         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F87 74 01            [12] 1725 	mov	a,#0x01
      007F89 F0               [24] 1726 	movx	@dptr,a
      007F8A                       1727 00108$:
                                   1728 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F8A 0F               [12] 1729 	inc	r7
      007F8B 80 D0            [24] 1730 	sjmp	00107$
      007F8D                       1731 00103$:
                                   1732 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      007F8D 90 0A B8         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F90 E0               [24] 1734 	movx	a,@dptr
      007F91 60 09            [24] 1735 	jz	00109$
      007F93 90 0D C2         [24] 1736 	mov	dptr,#_actual_keyboard_report
      007F96 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:477: }
      007F99 02 6C 15         [24] 1739 	ljmp	_host_keyboard_send
      007F9C                       1740 00109$:
      007F9C 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      007F9D                       1749 _get_mods:
      007F9D C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:488: ;
      007F9F 90 09 7F         [24] 1752 	mov	dptr,#_owned_mods
      007FA2 E0               [24] 1753 	movx	a,@dptr
      007FA3 FF               [12] 1754 	mov	r7,a
      007FA4 90 0D C0         [24] 1755 	mov	dptr,#_real_mods
      007FA7 12 7A B0         [24] 1756 	lcall	_ak820_outline_0141
                                   1757 ;	quantum/action_util.c:489: }
      007FAA D0 07            [24] 1758 	pop	ar7
      007FAC 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      007FAD                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:516: real_mods = 0;
      007FAD 90 0D C0         [24] 1771 	mov	dptr,#_real_mods
      007FB0 E4               [12] 1772 	clr	a
      007FB1 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:517: }
      007FB2 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      007FB3                       1783 _get_weak_mods:
      007FB3 C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:528: ;
      007FB5 90 09 80         [24] 1786 	mov	dptr,#_owned_weak_mods
      007FB8 E0               [24] 1787 	movx	a,@dptr
      007FB9 FF               [12] 1788 	mov	r7,a
      007FBA 90 0D C1         [24] 1789 	mov	dptr,#_weak_mods
      007FBD 12 7A B0         [24] 1790 	lcall	_ak820_outline_0141
                                   1791 ;	quantum/action_util.c:529: }
      007FC0 D0 07            [24] 1792 	pop	ar7
      007FC2 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      007FC3                       1803 _add_weak_mods:
      007FC3 E5 82            [12] 1804 	mov	a,dpl
      007FC5 90 0A B9         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      007FC8 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:535: weak_mods |= mods;
      007FC9 E0               [24] 1808 	movx	a,@dptr
      007FCA FF               [12] 1809 	mov	r7,a
      007FCB 90 0D C1         [24] 1810 	mov	dptr,#_weak_mods
      007FCE E0               [24] 1811 	movx	a,@dptr
      007FCF 4F               [12] 1812 	orl	a,r7
      007FD0 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:536: }
      007FD1 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      007FD2                       1825 _del_weak_mods:
      007FD2 E5 82            [12] 1826 	mov	a,dpl
      007FD4 90 0A BA         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      007FD7 F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      007FD8 E0               [24] 1830 	movx	a,@dptr
      007FD9 F4               [12] 1831 	cpl	a
      007FDA FF               [12] 1832 	mov	r7,a
      007FDB 90 0D C1         [24] 1833 	mov	dptr,#_weak_mods
      007FDE E0               [24] 1834 	movx	a,@dptr
      007FDF 5F               [12] 1835 	anl	a,r7
      007FE0 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:543: }
      007FE1 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      007FE2                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:556: weak_mods = 0;
      007FE2 90 0D C1         [24] 1850 	mov	dptr,#_weak_mods
      007FE5 E4               [12] 1851 	clr	a
      007FE6 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:557: }
      007FE7 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00BF5B                       1865 __xinit__real_mods:
      00BF5B 00                    1866 	.db #0x00	; 0
      00BF5C                       1867 __xinit__weak_mods:
      00BF5C 00                    1868 	.db #0x00	; 0
      00BF5D                       1869 __xinit__actual_keyboard_report:
      00BF5D 00                    1870 	.db #0x00	; 0
      00BF5E 00                    1871 	.db #0x00	; 0
      00BF5F 00                    1872 	.db #0x00	; 0
      00BF60 00                    1873 	.db #0x00	; 0
      00BF61 00                    1874 	.db #0x00	; 0
      00BF62 00                    1875 	.db #0x00	; 0
      00BF63 00                    1876 	.db #0x00	; 0
      00BF64 00                    1877 	.db #0x00	; 0
      00BF65 00                    1878 	.db 0x00
      00BF66 00                    1879 	.db 0x00
      00BF67 00                    1880 	.db 0x00
      00BF68 00                    1881 	.db 0x00
      00BF69 00                    1882 	.db 0x00
      00BF6A 00                    1883 	.db 0x00
      00BF6B 00                    1884 	.db 0x00
      00BF6C 00                    1885 	.db 0x00
      00BF6D 00                    1886 	.db 0x00
      00BF6E 00                    1887 	.db 0x00
      00BF6F 00                    1888 	.db 0x00
      00BF70 00                    1889 	.db 0x00
      00BF71 00                    1890 	.db 0x00
      00BF72 00                    1891 	.db 0x00
      00BF73 00                    1892 	.db 0x00
      00BF74 00                    1893 	.db 0x00
      00BF75 00                    1894 	.db 0x00
      00BF76 00                    1895 	.db 0x00
      00BF77 00                    1896 	.db 0x00
      00BF78 00                    1897 	.db 0x00
      00BF79 00                    1898 	.db 0x00
      00BF7A 00                    1899 	.db 0x00
      00BF7B 00                    1900 	.db 0x00
      00BF7C 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0016
                                   1906 	.globl _ak820_outline_0030
                                   1907 	.globl _ak820_outline_0055
                                   1908 	.globl _ak820_outline_0059
                                   1909 	.globl _ak820_outline_0061
                                   1910 	.globl _ak820_outline_0062
                                   1911 	.globl _ak820_outline_0063
                                   1912 	.globl _ak820_outline_0067
                                   1913 	.globl _ak820_outline_0075
                                   1914 	.globl _ak820_outline_0077
                                   1915 	.globl _ak820_outline_0107
                                   1916 	.globl _ak820_outline_0108
                                   1917 	.globl _ak820_outline_0117
                                   1918 	.globl _ak820_outline_0121
                                   1919 	.globl _ak820_outline_0123
                                   1920 	.globl _ak820_outline_0125
                                   1921 	.globl _ak820_outline_0132
                                   1922 	.globl _ak820_outline_0134
                                   1923 	.globl _ak820_outline_0135
                                   1924 	.globl _ak820_outline_0139
                                   1925 	.globl _ak820_outline_0141
                                   1926 	.globl _ak820_outline_0157
                                   1927 	.globl _ak820_outline_0158
                                   1928 	.globl _ak820_outline_0163
                                   1929 	.globl _ak820_outline_0175
                                   1930 	.globl _ak820_outline_0182
                                   1931 	.globl _ak820_outline_0188
                                   1932 	.globl _ak820_outline_0189
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0030
      007FE8                       1936 _ak820_outline_0030:
      007FE8 EF               [12] 1937 	mov	a,r7
      007FE9 24 91            [12] 1938 	add	a,#_key_refs
      007FEB FD               [12] 1939 	mov	r5,a
      007FEC E4               [12] 1940 	clr	a
      007FED 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      007FEF FE               [12] 1942 	mov	r6,a
      007FF0 8D 82            [24] 1943 	mov	dpl,r5
      007FF2 8E 83            [24] 1944 	mov	dph,r6
      007FF4 E0               [24] 1945 	movx	a,@dptr
      007FF5 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0062
      007FF6                       1950 _ak820_outline_0062:
      007FF6 89 82            [24] 1951 	mov	dpl,r1
      007FF8 8A 83            [24] 1952 	mov	dph,r2
      007FFA E8               [12] 1953 	mov	a,r0
      007FFB F0               [24] 1954 	movx	@dptr,a
      007FFC 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0067
      007FFD                       1959 _ak820_outline_0067:
      007FFD 24 6C            [12] 1960 	add	a,#_usage_order
      007FFF F5 82            [12] 1961 	mov	dpl,a
      008001 E4               [12] 1962 	clr	a
      008002 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      008004 F5 83            [12] 1964 	mov	dph,a
      008006 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0075
      008007                       1969 _ak820_outline_0075:
      008007 EB               [12] 1970 	mov	a,r3
      008008 24 4E            [12] 1971 	add	a,#_usage_refs
      00800A F9               [12] 1972 	mov	r1,a
      00800B E4               [12] 1973 	clr	a
      00800C 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      00800E FA               [12] 1975 	mov	r2,a
      00800F 89 82            [24] 1976 	mov	dpl,r1
      008011 8A 83            [24] 1977 	mov	dph,r2
      008013 E0               [24] 1978 	movx	a,@dptr
      008014 F8               [12] 1979 	mov	r0,a
      008015 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0117
      008016                       1984 _ak820_outline_0117:
      008016 F0               [24] 1985 	movx	@dptr,a
      008017 E0               [24] 1986 	movx	a,@dptr
      008018 FF               [12] 1987 	mov	r7,a
      008019 90 09 89         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      00801C 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0121
      00801D                       1993 _ak820_outline_0121:
      00801D 8D 82            [24] 1994 	mov	dpl,r5
      00801F 8E 83            [24] 1995 	mov	dph,r6
      008021 F0               [24] 1996 	movx	@dptr,a
      008022 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0125
      008023                       2001 _ak820_outline_0125:
      008023 24 6C            [12] 2002 	add	a,#_usage_order
      008025 F5 82            [12] 2003 	mov	dpl,a
      008027 EF               [12] 2004 	mov	a,r7
      008028 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      00802A F5 83            [12] 2006 	mov	dph,a
      00802C E0               [24] 2007 	movx	a,@dptr
      00802D 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0132
      00802E                       2012 _ak820_outline_0132:
      00802E F0               [24] 2013 	movx	@dptr,a
      00802F E0               [24] 2014 	movx	a,@dptr
      008030 FF               [12] 2015 	mov	r7,a
      008031 90 09 85         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      008034 F0               [24] 2017 	movx	@dptr,a
      008035 90 09 86         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      008038 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0175
      008039                       2023 _ak820_outline_0175:
      008039 90 07 FF         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      00803C EF               [12] 2025 	mov	a,r7
      00803D F0               [24] 2026 	movx	@dptr,a
      00803E 90 0D C2         [24] 2027 	mov	dptr,#_actual_keyboard_report
      008041 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0189
      008042                       2032 _ak820_outline_0189:
      008042 8D 82            [24] 2033 	mov	dpl,r5
      008044 8F 83            [24] 2034 	mov	dph,r7
      008046 22               [24] 2035 	ret
