                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059E                        562 _source_state:
      00059E                        563 	.ds 130
      000620                        564 _pending_time:
      000620                        565 	.ds 2
      000622                        566 _pending_code:
      000622                        567 	.ds 2
      000624                        568 _ak820_tapping_source_PARM_1:
      000624                        569 	.ds 2
      000626                        570 _hold_PARM_2:
      000626                        571 	.ds 1
      000627                        572 _hold_code_10000_601:
      000627                        573 	.ds 2
      000629                        574 _hold_mods_30000_604:
      000629                        575 	.ds 1
      00062A                        576 _commit_pending_id_10000_610:
      00062A                        577 	.ds 1
      00062B                        578 _ak820_tapping_before_event_10000_611:
      00062B                        579 	.ds 2
      00062D                        580 _ak820_tapping_process_record_10000_622:
      00062D                        581 	.ds 2
      00062F                        582 _ak820_tapping_process_code_10000_623:
      00062F                        583 	.ds 2
      000631                        584 _ak820_tapping_process_sc_mods_10000_623:
      000631                        585 	.ds 1
      000632                        586 _ak820_oneshot_mods::
      000632                        587 	.ds 1
      000633                        588 _ak820_oneshot_consumed::
      000633                        589 	.ds 1
      000634                        590 _ak820_oneshot_process_PARM_2:
      000634                        591 	.ds 1
      000635                        592 _ak820_oneshot_process_PARM_3:
      000635                        593 	.ds 1
      000636                        594 _ak820_oneshot_process_code_10000_648:
      000636                        595 	.ds 2
      000638                        596 _ak820_oneshot_process_mods_10000_649:
      000638                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DAD                        606 _pending:
      000DAD                        607 	.ds 1
      000DAE                        608 _ak820_oneshot_target::
      000DAE                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004380                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004380 90 06 25         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004383 E0               [24]  656 	movx	a,@dptr
      004384 FF               [12]  657 	mov	r7,a
      004385 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004388                        659 00147$:
      004388 50 14            [24]  660 	jnc	00102$
      00438A 90 06 24         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      00438D E0               [24]  662 	movx	a,@dptr
      00438E FE               [12]  663 	mov	r6,a
      00438F BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004392                        665 00149$:
      004392 50 0A            [24]  666 	jnc	00102$
      004394 8F 05            [24]  667 	mov	ar5,r7
      004396 ED               [12]  668 	mov	a,r5
      004397 12 38 B9         [24]  669 	lcall	_ak820_outline_0190
      00439A 2E               [12]  670 	add	a,r6
      00439B F5 82            [12]  671 	mov	dpl,a
      00439D 22               [24]  672 	ret
      00439E                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      00439E 90 06 24         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043A1 E0               [24]  676 	movx	a,@dptr
      0043A2 FE               [12]  677 	mov	r6,a
      0043A3 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0043A6                        679 00151$:
      0043A6 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043A8 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0043AB 75 82 80         [24]  683 	mov	dpl, #0x80
      0043AE 22               [24]  684 	ret
      0043AF                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043AF BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0043B2 75 82 81         [24]  688 	mov	dpl, #0x81
      0043B5 22               [24]  689 	ret
      0043B6                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0043B6 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      0043B9 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0043BA                        707 _hold:
      0043BA 12 38 75         [24]  708 	lcall	_ak820_outline_0107
      0043BD 90 06 27         [24]  709 	mov	dptr,#_hold_code_10000_601
      0043C0 12 38 7A         [24]  710 	lcall	_ak820_outline_0108
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      0043C3 90 06 27         [24]  712 	mov	dptr,#_hold_code_10000_601
      0043C6 12 48 10         [24]  713 	lcall	_ak820_outline_0008
      0043C9 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0043CB 2D               [12]  715 	add	a,r5
      0043CC 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      0043CE 8F 05            [24]  718 	mov	ar5,r7
      0043D0 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0043D3 90 06 29         [24]  720 	mov	dptr,#_hold_mods_30000_604
      0043D6 ED               [12]  721 	mov	a,r5
      0043D7 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      0043D8 ED               [12]  724 	mov	a,r5
      0043D9 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0043DC ED               [12]  726 	mov	a,r5
      0043DD C4               [12]  727 	swap	a
      0043DE 54 F0            [12]  728 	anl	a,#0xf0
      0043E0 90 06 29         [24]  729 	mov	dptr,#_hold_mods_30000_604
      0043E3 F0               [24]  730 	movx	@dptr,a
      0043E4                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      0043E4 90 06 26         [24]  733 	mov	dptr,#_hold_PARM_2
      0043E7 E0               [24]  734 	movx	a,@dptr
      0043E8 60 09            [24]  735 	jz	00104$
      0043EA 90 06 29         [24]  736 	mov	dptr,#_hold_mods_30000_604
      0043ED E0               [24]  737 	movx	a,@dptr
      0043EE F5 82            [12]  738 	mov	dpl,a
      0043F0 02 75 AD         [24]  739 	ljmp	_register_mods
      0043F3                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      0043F3 90 06 29         [24]  742 	mov	dptr,#_hold_mods_30000_604
      0043F6 E0               [24]  743 	movx	a,@dptr
      0043F7 F5 82            [12]  744 	mov	dpl,a
      0043F9 02 75 C1         [24]  745 	ljmp	_unregister_mods
      0043FC                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      0043FC 8F 06            [24]  748 	mov	ar6,r7
      0043FE 74 0F            [12]  749 	mov	a,#0x0f
      004400 5E               [12]  750 	anl	a,r6
      004401 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      004402 90 06 26         [24]  753 	mov	dptr,#_hold_PARM_2
      004405 E0               [24]  754 	movx	a,@dptr
      004406 60 05            [24]  755 	jz	00107$
      004408 8F 82            [24]  756 	mov	dpl, r7
      00440A 02 77 8D         [24]  757 	ljmp	_layer_hold_on
      00440D                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      00440D 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      00440F 02 77 C5         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004412                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      004412 90 0D AD         [24]  774 	mov	dptr,#_pending
      004415 E0               [24]  775 	movx	a,@dptr
      004416 90 06 2A         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004419 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      00441A 12 48 A3         [24]  779 	lcall	_ak820_outline_0154
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      00441D 90 06 2A         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      004420 E0               [24]  782 	movx	a,@dptr
      004421 24 9E            [12]  783 	add	a,#_source_state
      004423 FF               [12]  784 	mov	r7,a
      004424 E4               [12]  785 	clr	a
      004425 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004427 FE               [12]  787 	mov	r6,a
      004428 12 43 65         [24]  788 	lcall	_ak820_outline_0158
      00442B E0               [24]  789 	movx	a,@dptr
      00442C FD               [12]  790 	mov	r5,a
      00442D 43 05 04         [24]  791 	orl	ar5,#0x04
      004430 12 43 65         [24]  792 	lcall	_ak820_outline_0158
      004433 ED               [12]  793 	mov	a,r5
      004434 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      004435 90 06 22         [24]  796 	mov	dptr,#_pending_code
      004438 12 38 34         [24]  797 	lcall	_ak820_outline_0051
      00443B 90 06 26         [24]  798 	mov	dptr,#_hold_PARM_2
      00443E 74 01            [12]  799 	mov	a,#0x01
      004440 12 43 31         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004443 61 BA            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      004445                        813 _ak820_tapping_before:
      004445 12 38 75         [24]  814 	lcall	_ak820_outline_0107
      004448 90 06 2B         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00444B 12 38 7A         [24]  816 	lcall	_ak820_outline_0108
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      00444E 90 06 2B         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004451 12 48 10         [24]  819 	lcall	_ak820_outline_0008
      004454 12 48 35         [24]  820 	lcall	_ak820_outline_0024
      004457 C0 07            [24]  821 	push	ar7
      004459 C0 06            [24]  822 	push	ar6
      00445B 12 B6 94         [24]  823 	lcall	___memcpy
      00445E 71 80            [12]  824 	acall	_ak820_tapping_source
      004460 AD 82            [24]  825 	mov	r5, dpl
      004462 D0 06            [24]  826 	pop	ar6
      004464 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      004466 90 0E 1E         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004469 E0               [24]  830 	movx	a,@dptr
      00446A 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00446C 12 48 8F         [24]  833 	lcall	_ak820_outline_0097
      00446F 60 1D            [24]  834 	jz	00102$
      004471 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004474 80 18            [24]  836 	sjmp	00102$
      004476                        837 00218$:
      004476 12 48 1A         [24]  838 	lcall	_ak820_outline_0015
      004479 E0               [24]  839 	movx	a,@dptr
      00447A 70 12            [24]  840 	jnz	00102$
      00447C ED               [12]  841 	mov	a,r5
      00447D 24 9E            [12]  842 	add	a, #_source_state
      00447F FB               [12]  843 	mov	r3,a
      004480 E4               [12]  844 	clr	a
      004481 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      004483 12 48 65         [24]  846 	lcall	_ak820_outline_0055
      004486 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004489 12 33 FC         [24]  848 	lcall	_ak820_outline_0123
      00448C EA               [12]  849 	mov	a,r2
      00448D F0               [24]  850 	movx	@dptr,a
      00448E                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      00448E 75 82 00         [24]  853 	mov	dpl, #0x00
      004491 22               [24]  854 	ret
      004492                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      004492 90 0D AD         [24]  857 	mov	dptr,#_pending
      004495 E0               [24]  858 	movx	a,@dptr
      004496 FC               [12]  859 	mov	r4,a
      004497 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      00449A 80 3A            [24]  861 	sjmp	00108$
      00449C                        862 00220$:
      00449C 12 38 2C         [24]  863 	lcall	_ak820_outline_0036
      00449F FA               [12]  864 	mov	r2,a
      0044A0 A3               [24]  865 	inc	dptr
      0044A1 E0               [24]  866 	movx	a,@dptr
      0044A2 FB               [12]  867 	mov	r3,a
      0044A3 90 06 20         [24]  868 	mov	dptr,#_pending_time
      0044A6 12 38 6F         [24]  869 	lcall	_ak820_outline_0102
      0044A9 EA               [12]  870 	mov	a,r2
      0044AA C3               [12]  871 	clr	c
      0044AB 98               [12]  872 	subb	a,r0
      0044AC FA               [12]  873 	mov	r2,a
      0044AD EB               [12]  874 	mov	a,r3
      0044AE 99               [12]  875 	subb	a,r1
      0044AF FB               [12]  876 	mov	r3,a
      0044B0 C3               [12]  877 	clr	c
      0044B1 EA               [12]  878 	mov	a,r2
      0044B2 94 C8            [12]  879 	subb	a,#0xc8
      0044B4 EB               [12]  880 	mov	a,r3
      0044B5 94 00            [12]  881 	subb	a,#0x00
      0044B7 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0044B9 74 04            [12]  884 	mov	a,#0x04
      0044BB 12 48 4F         [24]  885 	lcall	_ak820_outline_0032
      0044BE 60 16            [24]  886 	jz	00108$
      0044C0 12 38 05         [24]  887 	lcall	_ak820_outline_0009
      0044C3 60 11            [24]  888 	jz	00108$
      0044C5 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      0044C8 80 06            [24]  890 	sjmp	00107$
      0044CA                        891 00224$:
      0044CA ED               [12]  892 	mov	a,r5
      0044CB B5 04 02         [24]  893 	cjne	a,ar4,00225$
      0044CE 80 06            [24]  894 	sjmp	00108$
      0044D0                        895 00225$:
      0044D0                        896 00107$:
      0044D0 C0 05            [24]  897 	push	ar5
      0044D2 91 12            [12]  898 	acall	_commit_pending
      0044D4 D0 05            [24]  899 	pop	ar5
      0044D6                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044D6 90 06 2B         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0044D9 12 38 34         [24]  903 	lcall	_ak820_outline_0051
      0044DC 12 48 8F         [24]  904 	lcall	_ak820_outline_0097
      0044DF 60 03            [24]  905 	jz	00114$
      0044E1 BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      0044E4                        907 00114$:
      0044E4 75 82 01         [24]  908 	mov	dpl, #0x01
      0044E7 22               [24]  909 	ret
      0044E8                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044E8 ED               [12]  912 	mov	a,r5
      0044E9 12 48 81         [24]  913 	lcall	_ak820_outline_0080
      0044EC 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044EF 74 05            [12]  916 	mov	a,#0x05
      0044F1 2E               [12]  917 	add	a, r6
      0044F2 12 38 12         [24]  918 	lcall	_ak820_outline_0016
      0044F5 70 07            [24]  919 	jnz	00118$
      0044F7 74 FD            [12]  920 	mov	a,#0xfd
      0044F9 5B               [12]  921 	anl	a,r3
      0044FA 12 38 8A         [24]  922 	lcall	_ak820_outline_0124
      0044FD F0               [24]  923 	movx	@dptr,a
      0044FE                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      0044FE 75 82 00         [24]  926 	mov	dpl, #0x00
      004501 22               [24]  927 	ret
      004502                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004502 12 42 F4         [24]  930 	lcall	_ak820_outline_0011
      004505 E0               [24]  931 	movx	a,@dptr
      004506 FF               [12]  932 	mov	r7,a
      004507 8B 06            [24]  933 	mov	ar6,r3
      004509 53 06 01         [24]  934 	anl	ar6,#0x01
      00450C EE               [12]  935 	mov	a,r6
      00450D B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      004510                        937 00231$:
      004510 B3               [12]  938 	cpl	c
      004511 92 0E            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      004513 8F F0            [24]  940 	mov	b,r7
      004515 E4               [12]  941 	clr	a
      004516 33               [12]  942 	rlc	a
      004517 B5 F0 04         [24]  943 	cjne	a,b,00122$
      00451A 75 82 00         [24]  944 	mov	dpl, #0x00
      00451D 22               [24]  945 	ret
      00451E                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00451E 63 03 01         [24]  948 	xrl	ar3,#0x01
      004521 12 38 8A         [24]  949 	lcall	_ak820_outline_0124
      004524 EB               [12]  950 	mov	a,r3
      004525 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004526 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004529 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      00452A                        969 _ak820_tapping_process:
      00452A 12 38 75         [24]  970 	lcall	_ak820_outline_0107
      00452D 90 06 2D         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004530 12 38 7A         [24]  972 	lcall	_ak820_outline_0108
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004533 90 06 31         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004536 E4               [12]  975 	clr	a
      004537 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004538 90 06 2D         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00453B 12 38 34         [24]  979 	lcall	_ak820_outline_0051
      00453E 74 04            [12]  980 	mov	a,#0x04
      004540 12 48 5A         [24]  981 	lcall	_ak820_outline_0033
      004543 70 04            [24]  982 	jnz	00102$
      004545 75 82 01         [24]  983 	mov	dpl, #0x01
      004548 22               [24]  984 	ret
      004549                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      004549 8E 04            [24]  987 	mov	ar4,r6
      00454B 8F 05            [24]  988 	mov	ar5,r7
      00454D 12 48 35         [24]  989 	lcall	_ak820_outline_0024
      004550 C0 07            [24]  990 	push	ar7
      004552 C0 06            [24]  991 	push	ar6
      004554 12 B6 94         [24]  992 	lcall	___memcpy
      004557 71 80            [12]  993 	acall	_ak820_tapping_source
      004559 AD 82            [24]  994 	mov	r5, dpl
      00455B D0 06            [24]  995 	pop	ar6
      00455D D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      00455F BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      004562 75 82 01         [24]  999 	mov	dpl, #0x01
      004565 22               [24] 1000 	ret
      004566                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      004566 74 07            [12] 1003 	mov	a,#0x07
      004568 12 38 24         [24] 1004 	lcall	_ak820_outline_0022
      00456B 12 38 34         [24] 1005 	lcall	_ak820_outline_0051
      00456E 90 06 2F         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004571 12 48 6D         [24] 1007 	lcall	_ak820_outline_0058
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004574 BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      004577 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      00457A 90 06 2F         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00457D 74 26            [12] 1012 	mov	a,#0x26
      00457F F0               [24] 1013 	movx	@dptr,a
      004580 74 22            [12] 1014 	mov	a,#0x22
      004582 A3               [24] 1015 	inc	dptr
      004583 F0               [24] 1016 	movx	@dptr,a
      004584 90 06 31         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004587 74 02            [12] 1018 	mov	a,#0x02
      004589 F0               [24] 1019 	movx	@dptr,a
      00458A 80 28            [24] 1020 	sjmp	00112$
      00458C                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      00458C BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      00458F BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      004592 90 06 2F         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004595 74 27            [12] 1026 	mov	a,#0x27
      004597 F0               [24] 1027 	movx	@dptr,a
      004598 74 32            [12] 1028 	mov	a,#0x32
      00459A A3               [24] 1029 	inc	dptr
      00459B F0               [24] 1030 	movx	@dptr,a
      00459C 90 06 31         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00459F 74 20            [12] 1032 	mov	a,#0x20
      0045A1 F0               [24] 1033 	movx	@dptr,a
      0045A2 80 10            [24] 1034 	sjmp	00112$
      0045A4                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0045A4 BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      0045A7 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      0045AA 90 06 2F         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0045AD 74 28            [12] 1040 	mov	a,#0x28
      0045AF F0               [24] 1041 	movx	@dptr,a
      0045B0 74 32            [12] 1042 	mov	a,#0x32
      0045B2 A3               [24] 1043 	inc	dptr
      0045B3 F0               [24] 1044 	movx	@dptr,a
      0045B4                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      0045B4 90 06 2F         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0045B7 E0               [24] 1048 	movx	a,@dptr
      0045B8 A3               [24] 1049 	inc	dptr
      0045B9 E0               [24] 1050 	movx	a,@dptr
      0045BA FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      0045BB BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      0045BE                       1054 00242$:
      0045BE 40 05            [24] 1055 	jc	00113$
      0045C0 BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      0045C3                       1057 00244$:
      0045C3 40 04            [24] 1058 	jc	00114$
      0045C5                       1059 00113$:
      0045C5 75 82 01         [24] 1060 	mov	dpl, #0x01
      0045C8 22               [24] 1061 	ret
      0045C9                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0045C9 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      0045CC                       1065 00246$:
      0045CC 40 0C            [24] 1066 	jc	00117$
      0045CE 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      0045D1 BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      0045D4                       1069 00248$:
      0045D4 40 04            [24] 1070 	jc	00117$
      0045D6 75 82 00         [24] 1071 	mov	dpl, #0x00
      0045D9 22               [24] 1072 	ret
      0045DA                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      0045DA 90 06 2D         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_622
      0045DD 12 38 34         [24] 1076 	lcall	_ak820_outline_0051
      0045E0 12 48 1A         [24] 1077 	lcall	_ak820_outline_0015
      0045E3 E0               [24] 1078 	movx	a,@dptr
      0045E4 60 1E            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      0045E6 90 0D AD         [24] 1081 	mov	dptr,#_pending
      0045E9 ED               [12] 1082 	mov	a,r5
      0045EA 12 42 FE         [24] 1083 	lcall	_ak820_outline_0031
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      0045ED 12 38 34         [24] 1085 	lcall	_ak820_outline_0051
      0045F0 90 06 20         [24] 1086 	mov	dptr,#_pending_time
      0045F3 12 48 6D         [24] 1087 	lcall	_ak820_outline_0058
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      0045F6 90 06 2F         [24] 1089 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0045F9 12 38 34         [24] 1090 	lcall	_ak820_outline_0051
      0045FC 90 06 22         [24] 1091 	mov	dptr,#_pending_code
      0045FF 12 48 6D         [24] 1092 	lcall	_ak820_outline_0058
      004602 C1 B3            [12] 1093 	ajmp	00132$
      004604                       1094 00131$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004604 90 0D AD         [24] 1096 	mov	dptr,#_pending
      004607 E0               [24] 1097 	movx	a,@dptr
      004608 FF               [12] 1098 	mov	r7,a
      004609 ED               [12] 1099 	mov	a,r5
      00460A B5 07 02         [24] 1100 	cjne	a,ar7,00251$
      00460D 80 02            [24] 1101 	sjmp	00252$
      00460F                       1102 00251$:
      00460F C1 8C            [12] 1103 	ajmp	00128$
      004611                       1104 00252$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004611 12 48 A3         [24] 1106 	lcall	_ak820_outline_0154
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004614 90 06 31         [24] 1108 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004617 E0               [24] 1109 	movx	a,@dptr
      004618 FF               [12] 1110 	mov	r7,a
      004619 E0               [24] 1111 	movx	a,@dptr
      00461A 60 05            [24] 1112 	jz	00120$
      00461C 8F 82            [24] 1113 	mov	dpl, r7
      00461E 12 7C 04         [24] 1114 	lcall	_add_owned_mods
      004621                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004621 90 06 2D         [24] 1117 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004624 12 38 34         [24] 1118 	lcall	_ak820_outline_0051
      004627 74 07            [12] 1119 	mov	a,#0x07
      004629 2E               [12] 1120 	add	a, r6
      00462A FB               [12] 1121 	mov	r3,a
      00462B E4               [12] 1122 	clr	a
      00462C 3F               [12] 1123 	addc	a, r7
      00462D FC               [12] 1124 	mov	r4,a
      00462E 90 06 2F         [24] 1125 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004631 E0               [24] 1126 	movx	a,@dptr
      004632 F9               [12] 1127 	mov	r1,a
      004633 7A 00            [12] 1128 	mov	r2,#0x00
      004635 12 33 FC         [24] 1129 	lcall	_ak820_outline_0123
      004638 E9               [12] 1130 	mov	a,r1
      004639 F0               [24] 1131 	movx	@dptr,a
      00463A EA               [12] 1132 	mov	a,r2
      00463B A3               [24] 1133 	inc	dptr
      00463C F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      00463D C3               [12] 1136 	clr	c
      00463E 04               [12] 1137 	inc	a
      00463F 99               [12] 1138 	subb	a,r1
      004640 50 38            [24] 1139 	jnc	00122$
                                   1140 ;	free result
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      004642 74 06            [12] 1142 	mov	a,#0x06
      004644 12 38 24         [24] 1143 	lcall	_ak820_outline_0022
      004647 E0               [24] 1144 	movx	a,@dptr
      004648 54 0F            [12] 1145 	anl	a,#0x0f
      00464A 44 10            [12] 1146 	orl	a,#0x10
      00464C F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      00464D 12 48 1A         [24] 1149 	lcall	_ak820_outline_0015
      004650 74 01            [12] 1150 	mov	a,#0x01
      004652 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004653 12 48 73         [24] 1153 	lcall	_ak820_outline_0076
      004656 12 48 9C         [24] 1154 	lcall	_ak820_outline_0112
      004659 C0 07            [24] 1155 	push	ar7
      00465B C0 06            [24] 1156 	push	ar6
      00465D C0 04            [24] 1157 	push	ar4
      00465F C0 03            [24] 1158 	push	ar3
      004661 12 70 53         [24] 1159 	lcall	_process_record
      004664 D0 03            [24] 1160 	pop	ar3
      004666 D0 04            [24] 1161 	pop	ar4
      004668 D0 06            [24] 1162 	pop	ar6
      00466A D0 07            [24] 1163 	pop	ar7
                                   1164 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      00466C 12 33 FC         [24] 1165 	lcall	_ak820_outline_0123
      00466F E4               [12] 1166 	clr	a
      004670 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      004671 FC               [12] 1169 	mov	r4,a
      004672 12 38 7F         [24] 1170 	lcall	_ak820_outline_0118
      004675 8C F0            [24] 1171 	mov	b, r4
      004677 12 70 53         [24] 1172 	lcall	_process_record
      00467A                       1173 00122$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      00467A 90 06 31         [24] 1175 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00467D E0               [24] 1176 	movx	a,@dptr
      00467E FF               [12] 1177 	mov	r7,a
      00467F E0               [24] 1178 	movx	a,@dptr
      004680 60 31            [24] 1179 	jz	00132$
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      004682 8F 82            [24] 1181 	mov	dpl, r7
      004684 12 7C 13         [24] 1182 	lcall	_del_owned_mods
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      004687 12 7F 36         [24] 1184 	lcall	_send_keyboard_report
      00468A 80 27            [24] 1185 	sjmp	00132$
      00468C                       1186 00128$:
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      00468C ED               [12] 1188 	mov	a,r5
      00468D 24 9E            [12] 1189 	add	a, #_source_state
      00468F FE               [12] 1190 	mov	r6,a
      004690 E4               [12] 1191 	clr	a
      004691 34 05            [12] 1192 	addc	a, #(_source_state >> 8)
      004693 FF               [12] 1193 	mov	r7,a
      004694 12 38 7F         [24] 1194 	lcall	_ak820_outline_0118
      004697 E0               [24] 1195 	movx	a,@dptr
      004698 FD               [12] 1196 	mov	r5,a
      004699 30 E2 17         [24] 1197 	jnb	acc.2,00132$
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      00469C 53 05 FB         [24] 1199 	anl	ar5,#0xfb
      00469F 12 38 7F         [24] 1200 	lcall	_ak820_outline_0118
      0046A2 ED               [12] 1201 	mov	a,r5
      0046A3 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      0046A4 90 06 2F         [24] 1204 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0046A7 12 38 34         [24] 1205 	lcall	_ak820_outline_0051
      0046AA 90 06 26         [24] 1206 	mov	dptr,#_hold_PARM_2
      0046AD E4               [12] 1207 	clr	a
      0046AE 12 43 31         [24] 1208 	lcall	_ak820_outline_0071
      0046B1 71 BA            [12] 1209 	acall	_hold
      0046B3                       1210 00132$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      0046B3 75 82 00         [24] 1212 	mov	dpl, #0x00
                                   1213 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      0046B6 22               [24] 1214 	ret
                                   1215 ;------------------------------------------------------------
                                   1216 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1217 ;------------------------------------------------------------
                                   1218 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1219 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1220 ;------------------------------------------------------------
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1222 ;	-----------------------------------------
                                   1223 ;	 function ak820_tapping_cancel
                                   1224 ;	-----------------------------------------
      0046B7                       1225 _ak820_tapping_cancel:
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      0046B7 12 48 A3         [24] 1227 	lcall	_ak820_outline_0154
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046BA 7F 00            [12] 1229 	mov	r7,#0x00
      0046BC                       1230 00103$:
      0046BC BF 82 00         [24] 1231 	cjne	r7,#0x82,00122$
      0046BF                       1232 00122$:
      0046BF 50 16            [24] 1233 	jnc	00105$
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      0046C1 12 48 26         [24] 1235 	lcall	_ak820_outline_0020
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0046C4 74 02            [12] 1237 	mov	a,#0x02
      0046C6 5C               [12] 1238 	anl	a,r4
      0046C7 FB               [12] 1239 	mov	r3,a
      0046C8 53 04 01         [24] 1240 	anl	ar4,#0x01
      0046CB EC               [12] 1241 	mov	a,r4
      0046CC 2C               [12] 1242 	add	a,r4
      0046CD 42 03            [12] 1243 	orl	ar3,a
      0046CF 12 38 94         [24] 1244 	lcall	_ak820_outline_0135
      0046D2 EB               [12] 1245 	mov	a,r3
      0046D3 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046D4 0F               [12] 1248 	inc	r7
      0046D5 80 E5            [24] 1249 	sjmp	00103$
      0046D7                       1250 00105$:
                                   1251 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      0046D7 22               [24] 1252 	ret
                                   1253 ;------------------------------------------------------------
                                   1254 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1255 ;------------------------------------------------------------
                                   1256 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1257 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1258 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1259 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1260 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1261 ;------------------------------------------------------------
                                   1262 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1263 ;	-----------------------------------------
                                   1264 ;	 function ak820_oneshot_process
                                   1265 ;	-----------------------------------------
      0046D8                       1266 _ak820_oneshot_process:
      0046D8 12 38 75         [24] 1267 	lcall	_ak820_outline_0107
      0046DB 90 06 36         [24] 1268 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0046DE 12 38 7A         [24] 1269 	lcall	_ak820_outline_0108
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      0046E1 90 06 34         [24] 1271 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0046E4 E0               [24] 1272 	movx	a,@dptr
      0046E5 FF               [12] 1273 	mov	r7,a
      0046E6 BF FF 02         [24] 1274 	cjne	r7,#0xff,00248$
      0046E9 80 0B            [24] 1275 	sjmp	00101$
      0046EB                       1276 00248$:
      0046EB C0 07            [24] 1277 	push	ar7
      0046ED 12 A0 AC         [24] 1278 	lcall	_get_repeat_key_count
      0046F0 E5 82            [12] 1279 	mov	a, dpl
      0046F2 D0 07            [24] 1280 	pop	ar7
      0046F4 60 04            [24] 1281 	jz	00102$
      0046F6                       1282 00101$:
      0046F6 75 82 01         [24] 1283 	mov	dpl, #0x01
      0046F9 22               [24] 1284 	ret
      0046FA                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      0046FA 90 06 36         [24] 1287 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0046FD E0               [24] 1288 	movx	a,@dptr
      0046FE FD               [12] 1289 	mov	r5,a
      0046FF A3               [24] 1290 	inc	dptr
      004700 E0               [24] 1291 	movx	a,@dptr
      004701 FB               [12] 1292 	mov	r3,a
      004702 BB 52 02         [24] 1293 	cjne	r3,#0x52,00250$
      004705 80 02            [24] 1294 	sjmp	00251$
      004707                       1295 00250$:
      004707 E1 AA            [12] 1296 	ajmp	00116$
      004709                       1297 00251$:
      004709 8D 04            [24] 1298 	mov	ar4,r5
      00470B 53 04 E0         [24] 1299 	anl	ar4,#0xe0
      00470E BC A0 02         [24] 1300 	cjne	r4,#0xa0,00252$
      004711 80 02            [24] 1301 	sjmp	00253$
      004713                       1302 00252$:
      004713 E1 AA            [12] 1303 	ajmp	00116$
      004715                       1304 00253$:
                                   1305 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: mods = code & 15;
      004715 8D 04            [24] 1306 	mov	ar4,r5
      004717 53 04 0F         [24] 1307 	anl	ar4,#0x0f
      00471A 90 06 38         [24] 1308 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00471D EC               [12] 1309 	mov	a,r4
      00471E F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: if (code & 16) mods <<= 4;
      00471F ED               [12] 1312 	mov	a,r5
      004720 30 E4 08         [24] 1313 	jnb	acc.4,00105$
      004723 EC               [12] 1314 	mov	a,r4
      004724 C4               [12] 1315 	swap	a
      004725 54 F0            [12] 1316 	anl	a,#0xf0
      004727 90 06 38         [24] 1317 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00472A F0               [24] 1318 	movx	@dptr,a
      00472B                       1319 00105$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: if (pressed) {
      00472B 90 06 35         [24] 1321 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00472E E0               [24] 1322 	movx	a,@dptr
      00472F 60 2D            [24] 1323 	jz	00113$
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: source_state[id] |= SOURCE_ONESHOT;
      004731 12 48 26         [24] 1325 	lcall	_ak820_outline_0020
      004734 43 04 08         [24] 1326 	orl	ar4,#0x08
      004737 12 43 2A         [24] 1327 	lcall	_ak820_outline_0063
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: source_state[id] &= ~SOURCE_ONESHOT_USED;
      00473A 53 04 EF         [24] 1329 	anl	ar4,#0xef
      00473D 12 43 2A         [24] 1330 	lcall	_ak820_outline_0063
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004740 90 0D AE         [24] 1332 	mov	dptr,#_ak820_oneshot_target
      004743 E0               [24] 1333 	movx	a,@dptr
      004744 FC               [12] 1334 	mov	r4,a
      004745 BC FF 02         [24] 1335 	cjne	r4,#0xff,00256$
      004748 80 09            [24] 1336 	sjmp	00107$
      00474A                       1337 00256$:
      00474A 12 48 7A         [24] 1338 	lcall	_ak820_outline_0077
      00474D 43 04 10         [24] 1339 	orl	ar4,#0x10
      004750 12 43 2A         [24] 1340 	lcall	_ak820_outline_0063
      004753                       1341 00107$:
                                   1342 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: register_mods(mods);
      004753 90 06 38         [24] 1343 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004756 E0               [24] 1344 	movx	a,@dptr
      004757 F5 82            [12] 1345 	mov	dpl,a
      004759 12 75 AD         [24] 1346 	lcall	_register_mods
      00475C 80 48            [24] 1347 	sjmp	00114$
      00475E                       1348 00113$:
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: } else if (source_state[id] & SOURCE_ONESHOT) {
      00475E 12 48 26         [24] 1350 	lcall	_ak820_outline_0020
      004761 30 E3 42         [24] 1351 	jnb	acc.3,00114$
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004764 EC               [12] 1353 	mov	a,r4
      004765 20 E4 24         [24] 1354 	jb	acc.4,00109$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: add_owned_mods(mods & ~ak820_oneshot_mods);
      004768 90 06 32         [24] 1356 	mov	dptr,#_ak820_oneshot_mods
      00476B E0               [24] 1357 	movx	a,@dptr
      00476C F4               [12] 1358 	cpl	a
      00476D FC               [12] 1359 	mov	r4,a
      00476E 90 06 38         [24] 1360 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004771 E0               [24] 1361 	movx	a,@dptr
      004772 FB               [12] 1362 	mov	r3,a
      004773 52 04            [12] 1363 	anl	ar4,a
      004775 8C 82            [24] 1364 	mov	dpl, r4
      004777 C0 06            [24] 1365 	push	ar6
      004779 C0 05            [24] 1366 	push	ar5
      00477B C0 03            [24] 1367 	push	ar3
      00477D 12 7C 04         [24] 1368 	lcall	_add_owned_mods
      004780 D0 03            [24] 1369 	pop	ar3
      004782 D0 05            [24] 1370 	pop	ar5
      004784 D0 06            [24] 1371 	pop	ar6
                                   1372 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: ak820_oneshot_mods |= mods;
      004786 90 06 32         [24] 1373 	mov	dptr,#_ak820_oneshot_mods
      004789 E0               [24] 1374 	movx	a,@dptr
      00478A 4B               [12] 1375 	orl	a,r3
      00478B F0               [24] 1376 	movx	@dptr,a
      00478C                       1377 00109$:
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: unregister_mods(mods);
      00478C 90 06 38         [24] 1379 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00478F E0               [24] 1380 	movx	a,@dptr
      004790 F5 82            [12] 1381 	mov	dpl,a
      004792 C0 06            [24] 1382 	push	ar6
      004794 C0 05            [24] 1383 	push	ar5
      004796 12 75 C1         [24] 1384 	lcall	_unregister_mods
      004799 D0 05            [24] 1385 	pop	ar5
      00479B D0 06            [24] 1386 	pop	ar6
                                   1387 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      00479D 12 48 7A         [24] 1388 	lcall	_ak820_outline_0077
      0047A0 53 04 E7         [24] 1389 	anl	ar4,#0xe7
      0047A3 12 43 2A         [24] 1390 	lcall	_ak820_outline_0063
      0047A6                       1391 00114$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: return false;
      0047A6 75 82 00         [24] 1393 	mov	dpl, #0x00
      0047A9 22               [24] 1394 	ret
      0047AA                       1395 00116$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: if (pressed && code > KC_TRANSPARENT &&
      0047AA 90 06 35         [24] 1397 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0047AD E0               [24] 1398 	movx	a,@dptr
      0047AE 60 5C            [24] 1399 	jz	00124$
      0047B0 90 06 36         [24] 1400 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      0047B3 12 38 57         [24] 1401 	lcall	_ak820_outline_0079
      0047B6 C3               [12] 1402 	clr	c
      0047B7 74 01            [12] 1403 	mov	a,#0x01
      0047B9 9D               [12] 1404 	subb	a,r5
      0047BA E4               [12] 1405 	clr	a
      0047BB 9E               [12] 1406 	subb	a,r6
      0047BC 50 4E            [24] 1407 	jnc	00124$
                                   1408 ;	free result
                                   1409 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: !(code >= KC_LCTL && code <= KC_RGUI) &&
      0047BE C3               [12] 1410 	clr	c
      0047BF ED               [12] 1411 	mov	a,r5
      0047C0 94 E0            [12] 1412 	subb	a,#0xe0
      0047C2 EE               [12] 1413 	mov	a,r6
      0047C3 94 00            [12] 1414 	subb	a,#0x00
      0047C5 40 07            [24] 1415 	jc	00129$
      0047C7 74 E7            [12] 1416 	mov	a,#0xe7
      0047C9 9D               [12] 1417 	subb	a,r5
      0047CA E4               [12] 1418 	clr	a
      0047CB 9E               [12] 1419 	subb	a,r6
      0047CC 50 3E            [24] 1420 	jnc	00124$
                                   1421 ;	free result
      0047CE                       1422 00129$:
                                   1423 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      0047CE 74 AE            [12] 1424 	mov	a,#0x100 - 0x52
      0047D0 2E               [12] 1425 	add	a,r6
      0047D1 50 09            [24] 1426 	jnc	00165$
      0047D3 C3               [12] 1427 	clr	c
      0047D4 74 DF            [12] 1428 	mov	a,#0xdf
      0047D6 9D               [12] 1429 	subb	a,r5
      0047D7 74 52            [12] 1430 	mov	a,#0x52
      0047D9 9E               [12] 1431 	subb	a,r6
      0047DA 50 30            [24] 1432 	jnc	00124$
                                   1433 ;	free result
                                   1434 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      0047DC                       1435 00165$:
      0047DC 7E 00            [12] 1436 	mov	r6,#0x00
      0047DE                       1437 00131$:
      0047DE BE 82 00         [24] 1438 	cjne	r6,#0x82,00265$
      0047E1                       1439 00265$:
      0047E1 50 12            [24] 1440 	jnc	00120$
                                   1441 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      0047E3 EE               [12] 1442 	mov	a,r6
      0047E4 12 48 81         [24] 1443 	lcall	_ak820_outline_0080
      0047E7 30 E3 08         [24] 1444 	jnb	acc.3,00132$
      0047EA 43 03 10         [24] 1445 	orl	ar3,#0x10
      0047ED 12 38 8A         [24] 1446 	lcall	_ak820_outline_0124
      0047F0 EB               [12] 1447 	mov	a,r3
      0047F1 F0               [24] 1448 	movx	@dptr,a
      0047F2                       1449 00132$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      0047F2 0E               [12] 1451 	inc	r6
      0047F3 80 E9            [24] 1452 	sjmp	00131$
      0047F5                       1453 00120$:
                                   1454 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: if (ak820_oneshot_mods) {
      0047F5 90 06 32         [24] 1455 	mov	dptr,#_ak820_oneshot_mods
      0047F8 E0               [24] 1456 	movx	a,@dptr
      0047F9 FE               [12] 1457 	mov	r6,a
      0047FA E0               [24] 1458 	movx	a,@dptr
      0047FB 60 0F            [24] 1459 	jz	00124$
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: ak820_oneshot_consumed = ak820_oneshot_mods;
      0047FD 90 06 33         [24] 1461 	mov	dptr,#_ak820_oneshot_consumed
      004800 EE               [12] 1462 	mov	a,r6
      004801 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: ak820_oneshot_target = id;
      004802 90 0D AE         [24] 1465 	mov	dptr,#_ak820_oneshot_target
      004805 EF               [12] 1466 	mov	a,r7
      004806 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: ak820_oneshot_mods = 0;
      004807 90 06 32         [24] 1469 	mov	dptr,#_ak820_oneshot_mods
      00480A E4               [12] 1470 	clr	a
      00480B F0               [24] 1471 	movx	@dptr,a
      00480C                       1472 00124$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: return true;
      00480C 75 82 01         [24] 1474 	mov	dpl, #0x01
                                   1475 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: }
      00480F 22               [24] 1476 	ret
                                   1477 	.area CSEG    (CODE)
                                   1478 	.area CONST   (CODE)
                                   1479 	.area XINIT   (CODE)
      00BF54                       1480 __xinit__pending:
      00BF54 FF                    1481 	.db #0xff	; 255
      00BF55                       1482 __xinit__ak820_oneshot_target:
      00BF55 FF                    1483 	.db #0xff	; 255
                                   1484 	.area CABS    (ABS,CODE)
                                   1485 
                                   1486 ; Experimental exact instruction outlining.
                                   1487 	.globl _ak820_outline_0008
                                   1488 	.globl _ak820_outline_0009
                                   1489 	.globl _ak820_outline_0011
                                   1490 	.globl _ak820_outline_0015
                                   1491 	.globl _ak820_outline_0016
                                   1492 	.globl _ak820_outline_0020
                                   1493 	.globl _ak820_outline_0022
                                   1494 	.globl _ak820_outline_0024
                                   1495 	.globl _ak820_outline_0031
                                   1496 	.globl _ak820_outline_0032
                                   1497 	.globl _ak820_outline_0033
                                   1498 	.globl _ak820_outline_0036
                                   1499 	.globl _ak820_outline_0051
                                   1500 	.globl _ak820_outline_0055
                                   1501 	.globl _ak820_outline_0058
                                   1502 	.globl _ak820_outline_0063
                                   1503 	.globl _ak820_outline_0071
                                   1504 	.globl _ak820_outline_0076
                                   1505 	.globl _ak820_outline_0077
                                   1506 	.globl _ak820_outline_0079
                                   1507 	.globl _ak820_outline_0080
                                   1508 	.globl _ak820_outline_0097
                                   1509 	.globl _ak820_outline_0102
                                   1510 	.globl _ak820_outline_0107
                                   1511 	.globl _ak820_outline_0108
                                   1512 	.globl _ak820_outline_0112
                                   1513 	.globl _ak820_outline_0118
                                   1514 	.globl _ak820_outline_0123
                                   1515 	.globl _ak820_outline_0124
                                   1516 	.globl _ak820_outline_0135
                                   1517 	.globl _ak820_outline_0154
                                   1518 	.globl _ak820_outline_0158
                                   1519 	.globl _ak820_outline_0190
                                   1520 
                                   1521 	.area CSEG (CODE)
                                   1522 ; function ak820_outline_0008
      004810                       1523 _ak820_outline_0008:
      004810 E0               [24] 1524 	movx	a,@dptr
      004811 FE               [12] 1525 	mov	r6,a
      004812 A3               [24] 1526 	inc	dptr
      004813 E0               [24] 1527 	movx	a,@dptr
      004814 FF               [12] 1528 	mov	r7,a
      004815 8E 04            [24] 1529 	mov	ar4,r6
      004817 8F 05            [24] 1530 	mov	ar5,r7
      004819 22               [24] 1531 	ret
                                   1532 
                                   1533 	.area CSEG (CODE)
                                   1534 ; function ak820_outline_0015
      00481A                       1535 _ak820_outline_0015:
      00481A 74 05            [12] 1536 	mov	a,#0x05
      00481C 2E               [12] 1537 	add	a,r6
      00481D FB               [12] 1538 	mov	r3,a
      00481E E4               [12] 1539 	clr	a
      00481F 3F               [12] 1540 	addc	a,r7
      004820 FC               [12] 1541 	mov	r4,a
      004821 8B 82            [24] 1542 	mov	dpl,r3
      004823 8C 83            [24] 1543 	mov	dph,r4
      004825 22               [24] 1544 	ret
                                   1545 
                                   1546 	.area CSEG (CODE)
                                   1547 ; function ak820_outline_0020
      004826                       1548 _ak820_outline_0020:
      004826 EF               [12] 1549 	mov	a,r7
      004827 24 9E            [12] 1550 	add	a,#_source_state
      004829 FD               [12] 1551 	mov	r5,a
      00482A E4               [12] 1552 	clr	a
      00482B 34 05            [12] 1553 	addc	a,#(_source_state>>8)
      00482D FE               [12] 1554 	mov	r6,a
      00482E 8D 82            [24] 1555 	mov	dpl,r5
      004830 8E 83            [24] 1556 	mov	dph,r6
      004832 E0               [24] 1557 	movx	a,@dptr
      004833 FC               [12] 1558 	mov	r4,a
      004834 22               [24] 1559 	ret
                                   1560 
                                   1561 	.area CSEG (CODE)
                                   1562 ; function ak820_outline_0024
      004835                       1563 _ak820_outline_0024:
      004835 90 0D 9D         [24] 1564 	mov	dptr,#___memcpy_PARM_2
      004838 EC               [12] 1565 	mov	a,r4
      004839 F0               [24] 1566 	movx	@dptr,a
      00483A ED               [12] 1567 	mov	a,r5
      00483B A3               [24] 1568 	inc	dptr
      00483C F0               [24] 1569 	movx	@dptr,a
      00483D E4               [12] 1570 	clr	a
      00483E A3               [24] 1571 	inc	dptr
      00483F F0               [24] 1572 	movx	@dptr,a
      004840 90 0D A0         [24] 1573 	mov	dptr,#___memcpy_PARM_3
      004843 74 02            [12] 1574 	mov	a,#0x02
      004845 F0               [24] 1575 	movx	@dptr,a
      004846 E4               [12] 1576 	clr	a
      004847 A3               [24] 1577 	inc	dptr
      004848 F0               [24] 1578 	movx	@dptr,a
      004849 90 06 24         [24] 1579 	mov	dptr,#_ak820_tapping_source_PARM_1
      00484C F5 F0            [12] 1580 	mov	b,a
      00484E 22               [24] 1581 	ret
                                   1582 
                                   1583 	.area CSEG (CODE)
                                   1584 ; function ak820_outline_0032
      00484F                       1585 _ak820_outline_0032:
      00484F 2E               [12] 1586 	add	a,r6
      004850 FA               [12] 1587 	mov	r2,a
      004851 E4               [12] 1588 	clr	a
      004852 3F               [12] 1589 	addc	a,r7
      004853 FB               [12] 1590 	mov	r3,a
      004854 8A 82            [24] 1591 	mov	dpl,r2
      004856 8B 83            [24] 1592 	mov	dph,r3
      004858 E0               [24] 1593 	movx	a,@dptr
      004859 22               [24] 1594 	ret
                                   1595 
                                   1596 	.area CSEG (CODE)
                                   1597 ; function ak820_outline_0033
      00485A                       1598 _ak820_outline_0033:
      00485A 2E               [12] 1599 	add	a,r6
      00485B FC               [12] 1600 	mov	r4,a
      00485C E4               [12] 1601 	clr	a
      00485D 3F               [12] 1602 	addc	a,r7
      00485E FD               [12] 1603 	mov	r5,a
      00485F 8C 82            [24] 1604 	mov	dpl,r4
      004861 8D 83            [24] 1605 	mov	dph,r5
      004863 E0               [24] 1606 	movx	a,@dptr
      004864 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0055
      004865                       1611 _ak820_outline_0055:
      004865 FC               [12] 1612 	mov	r4,a
      004866 8B 82            [24] 1613 	mov	dpl,r3
      004868 8C 83            [24] 1614 	mov	dph,r4
      00486A E0               [24] 1615 	movx	a,@dptr
      00486B FA               [12] 1616 	mov	r2,a
      00486C 22               [24] 1617 	ret
                                   1618 
                                   1619 	.area CSEG (CODE)
                                   1620 ; function ak820_outline_0058
      00486D                       1621 _ak820_outline_0058:
      00486D EE               [12] 1622 	mov	a,r6
      00486E F0               [24] 1623 	movx	@dptr,a
      00486F EF               [12] 1624 	mov	a,r7
      004870 A3               [24] 1625 	inc	dptr
      004871 F0               [24] 1626 	movx	@dptr,a
      004872 22               [24] 1627 	ret
                                   1628 
                                   1629 	.area CSEG (CODE)
                                   1630 ; function ak820_outline_0076
      004873                       1631 _ak820_outline_0076:
      004873 8E 00            [24] 1632 	mov	ar0,r6
      004875 8F 01            [24] 1633 	mov	ar1,r7
      004877 7A 00            [12] 1634 	mov	r2,#0x00
      004879 22               [24] 1635 	ret
                                   1636 
                                   1637 	.area CSEG (CODE)
                                   1638 ; function ak820_outline_0077
      00487A                       1639 _ak820_outline_0077:
      00487A 8D 82            [24] 1640 	mov	dpl,r5
      00487C 8E 83            [24] 1641 	mov	dph,r6
      00487E E0               [24] 1642 	movx	a,@dptr
      00487F FC               [12] 1643 	mov	r4,a
      004880 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0080
      004881                       1648 _ak820_outline_0080:
      004881 24 9E            [12] 1649 	add	a,#_source_state
      004883 FC               [12] 1650 	mov	r4,a
      004884 E4               [12] 1651 	clr	a
      004885 34 05            [12] 1652 	addc	a,#(_source_state>>8)
      004887 FD               [12] 1653 	mov	r5,a
      004888 8C 82            [24] 1654 	mov	dpl,r4
      00488A 8D 83            [24] 1655 	mov	dph,r5
      00488C E0               [24] 1656 	movx	a,@dptr
      00488D FB               [12] 1657 	mov	r3,a
      00488E 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0097
      00488F                       1662 _ak820_outline_0097:
      00488F 74 04            [12] 1663 	mov	a,#0x04
      004891 2E               [12] 1664 	add	a,r6
      004892 FB               [12] 1665 	mov	r3,a
      004893 E4               [12] 1666 	clr	a
      004894 3F               [12] 1667 	addc	a,r7
      004895 FC               [12] 1668 	mov	r4,a
      004896 8B 82            [24] 1669 	mov	dpl,r3
      004898 8C 83            [24] 1670 	mov	dph,r4
      00489A E0               [24] 1671 	movx	a,@dptr
      00489B 22               [24] 1672 	ret
                                   1673 
                                   1674 	.area CSEG (CODE)
                                   1675 ; function ak820_outline_0112
      00489C                       1676 _ak820_outline_0112:
      00489C 88 82            [24] 1677 	mov	dpl,r0
      00489E 89 83            [24] 1678 	mov	dph,r1
      0048A0 8A F0            [24] 1679 	mov	b,r2
      0048A2 22               [24] 1680 	ret
                                   1681 
                                   1682 	.area CSEG (CODE)
                                   1683 ; function ak820_outline_0154
      0048A3                       1684 _ak820_outline_0154:
      0048A3 90 0D AD         [24] 1685 	mov	dptr,#_pending
      0048A6 74 FF            [12] 1686 	mov	a,#0xff
      0048A8 F0               [24] 1687 	movx	@dptr,a
      0048A9 22               [24] 1688 	ret
