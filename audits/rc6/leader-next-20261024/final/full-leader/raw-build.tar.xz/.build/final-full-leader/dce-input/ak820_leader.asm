;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_leader
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_repeat_key_count
	.globl _dynamic_keymap_macro_send
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_leader_cancel
	.globl _ak820_leader_task
	.globl _ak820_leader_process
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_ak820_leader_process_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_leader_suppressed:
	.ds 16
_leader_waiting:
	.ds 1
_leader_running:
	.ds 1
_leader_started:
	.ds 2
_ak820_leader_task_now_10000_593:
	.ds 2
_ak820_leader_task_slot_30000_600:
	.ds 1
_ak820_leader_process_record_10000_601:
	.ds 2
_ak820_leader_process_slot_10000_602:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_leader_pending:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_leader_cancel
;	-----------------------------------------
_ak820_leader_cancel:
;	keyboards/ajazz/ak820/ak820_leader.c:18: leader_waiting = false;
	mov	dptr,#_leader_waiting
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:19: leader_pending = NONE;
	mov	dptr,#_leader_pending
	dec	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:20: for (uint8_t i = 0; i < sizeof(leader_suppressed); ++i) leader_suppressed[i] = 0;
	mov	r7,#0x00
00103$:
	cjne	r7,#0x10,00122$
00122$:
	jnc	00105$
	mov	a,r7
	add	a, #_leader_suppressed
	mov	dpl,a
	clr	a
	addc	a, #(_leader_suppressed >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	sjmp	00103$
00105$:
;	keyboards/ajazz/ak820/ak820_leader.c:21: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_leader_task'
;------------------------------------------------------------
;now           Allocated with name '_ak820_leader_task_now_10000_593'
;slot          Allocated with name '_ak820_leader_task_slot_30000_600'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_leader.c:22: void ak820_leader_task(uint16_t now) {
;	-----------------------------------------
;	 function ak820_leader_task
;	-----------------------------------------
_ak820_leader_task:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_leader_task_now_10000_593
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:23: if (vial_unlock_in_progress) { ak820_leader_cancel(); return; }
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jz	00102$
	ljmp	_ak820_leader_cancel
00102$:
;	keyboards/ajazz/ak820/ak820_leader.c:24: if (leader_running) return;
	mov	dptr,#_leader_running
	movx	a,@dptr
	jz	00104$
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_leader.c:25: if (leader_waiting && (uint16_t)(now - leader_started) >= 300) leader_waiting = false;
	mov	dptr,#_leader_waiting
	movx	a,@dptr
	jz	00106$
	mov	dptr,#_leader_started
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_leader_task_now_10000_593
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r4
	clr	c
	subb	a,r6
	mov	r6,a
	mov	a,r5
	subb	a,r7
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,#0x2c
	mov	a,r7
	subb	a,#0x01
	jc	00106$
	mov	dptr,#_leader_waiting
	clr	a
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_leader.c:26: if (leader_pending != NONE) {
	mov	dptr,#_leader_pending
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00151$
	ret
00151$:
;	keyboards/ajazz/ak820/ak820_leader.c:27: uint8_t slot = leader_pending;
	mov	dptr,#_ak820_leader_task_slot_30000_600
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:28: leader_pending = NONE; /* Interpreter-generated events cannot recurse. */
	mov	dptr,#_leader_pending
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:29: leader_running = true;
	mov	dptr,#_leader_running
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:30: dynamic_keymap_macro_send(slot);
	mov	dptr,#_ak820_leader_task_slot_30000_600
	movx	a,@dptr
	mov	dpl,a
	lcall	_dynamic_keymap_macro_send
;	keyboards/ajazz/ak820/ak820_leader.c:31: leader_running = false;
	mov	dptr,#_leader_running
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:33: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_leader_process'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_leader_process_sloc0_1_0'
;record        Allocated with name '_ak820_leader_process_record_10000_601'
;id            Allocated with name '_ak820_leader_process_id_10000_602'
;mask          Allocated with name '_ak820_leader_process_mask_10000_602'
;index         Allocated with name '_ak820_leader_process_index_10000_602'
;slot          Allocated with name '_ak820_leader_process_slot_10000_602'
;code          Allocated with name '_ak820_leader_process_code_10000_602'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_leader.c:34: bool ak820_leader_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_leader_process
;	-----------------------------------------
_ak820_leader_process:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_leader_process_record_10000_601
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:35: uint8_t id, mask, index, slot = NONE;
	mov	dptr,#_ak820_leader_process_slot_10000_602
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:37: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
	mov	dptr,#_ak820_leader_process_record_10000_601
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x01,00101$
	mov	a,#0x01
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x10,00252$
00252$:
	jnc	00101$
;	keyboards/ajazz/ak820/ak820_leader.c:38: record->event.key.col >= MATRIX_COLS || leader_running || ak820_macro_primitive || get_repeat_key_count()) return true;
	mov	ar2,r6
	mov	ar3,r7
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0x08,00254$
00254$:
	jnc	00101$
	mov	dptr,#_leader_running
	movx	a,@dptr
	jnz	00101$
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jnz	00101$
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_get_repeat_key_count
	mov	a, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jz	00102$
00101$:
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_leader.c:39: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	swap	a
	rr	a
	anl	a,#0xf8
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	add	a, r4
;	keyboards/ajazz/ak820/ak820_leader.c:40: index = id >> 3;
	mov	r4,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_leader.c:41: mask = 1u << (id & 7);
	mov	a,#0x07
	anl	a,r4
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00260$
00259$:
	add	a,acc
00260$:
	djnz	b,00259$
	mov	r4,a
;	keyboards/ajazz/ak820/ak820_leader.c:42: if (leader_suppressed[index] & mask) {
	mov	a,r5
	add	a, #_leader_suppressed
	mov	r3,a
	clr	a
	addc	a, #(_leader_suppressed >> 8)
	mov	r5,a
	mov	dpl,r3
	mov	dph,r5
	movx	a,@dptr
	mov	r2,a
	mov	a,r4
	anl	a,r2
	jz	00111$
;	keyboards/ajazz/ak820/ak820_leader.c:43: if (!record->event.pressed) leader_suppressed[index] &= ~mask;
	mov	a,#0x05
	add	a, r6
	mov	r0,a
	clr	a
	addc	a, r7
	mov	r1,a
	mov	dpl,r0
	mov	dph,r1
	movx	a,@dptr
	jnz	00109$
	mov	a,#0xff
	xrl	a,r4
	anl	ar2,a
	mov	dpl,r3
	mov	dph,r5
	mov	a,r2
	movx	@dptr,a
00109$:
;	keyboards/ajazz/ak820/ak820_leader.c:44: return false;
	mov	dpl, #0x00
	ret
00111$:
;	keyboards/ajazz/ak820/ak820_leader.c:46: if (!record->event.pressed) return true; /* Preheld release keeps its owner. */
	mov	a,#0x05
	add	a, r6
	mov	r1,a
	clr	a
	addc	a, r7
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	jnz	00113$
	mov	dpl, #0x01
	ret
00113$:
;	keyboards/ajazz/ak820/ak820_leader.c:47: code = record->keycode;
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	keyboards/ajazz/ak820/ak820_leader.c:48: if (code == QK_LEAD) {
	mov	_ak820_leader_process_sloc0_1_0,r1
	mov	(_ak820_leader_process_sloc0_1_0 + 1),r2
	mov	a,#0x58
	cjne	a,_ak820_leader_process_sloc0_1_0,00131$
	mov	a,#0x7c
	cjne	a,(_ak820_leader_process_sloc0_1_0 + 1),00131$
;	keyboards/ajazz/ak820/ak820_leader.c:49: if (leader_pending == NONE) {
	mov	dptr,#_leader_pending
	movx	a,@dptr
	mov	r0,a
	cjne	r0,#0xff,00266$
	sjmp	00267$
00266$:
	ljmp	00132$
00267$:
;	keyboards/ajazz/ak820/ak820_leader.c:50: leader_waiting = true;
	push	ar4
	mov	dptr,#_leader_waiting
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:51: leader_started = record->event.time;
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_leader_started
	mov	a,r0
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	pop	ar4
	ljmp	00132$
00131$:
;	keyboards/ajazz/ak820/ak820_leader.c:54: if (!leader_waiting) return true;
	mov	dptr,#_leader_waiting
	movx	a,@dptr
	jnz	00117$
	mov	dpl, #0x01
	ret
00117$:
;	keyboards/ajazz/ak820/ak820_leader.c:55: leader_waiting = false;
	push	ar4
	mov	dptr,#_leader_waiting
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:56: if ((uint16_t)(record->event.time - leader_started) >= 300) return true;
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_leader_started
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	a,r6
	clr	c
	subb	a,r0
	mov	r6,a
	mov	a,r7
	subb	a,r4
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,#0x2c
	mov	a,r7
	subb	a,#0x01
	pop	ar4
	jc	00119$
	mov	dpl, #0x01
	ret
00119$:
;	keyboards/ajazz/ak820/ak820_leader.c:58: if (code < KC_A || code > KC_EXSEL) return true;
	clr	c
	mov	a,_ak820_leader_process_sloc0_1_0
	subb	a,#0x04
	mov	a,(_ak820_leader_process_sloc0_1_0 + 1)
	subb	a,#0x00
	jc	00120$
	mov	a,#0xa4
	subb	a,_ak820_leader_process_sloc0_1_0
	clr	a
	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
	jnc	00121$
;	free result
00120$:
	mov	dpl, #0x01
	ret
00121$:
;	keyboards/ajazz/ak820/ak820_leader.c:59: if (code >= KC_1 && code <= KC_0) slot = code - KC_1;
	clr	c
	mov	a,_ak820_leader_process_sloc0_1_0
	subb	a,#0x1e
	mov	a,(_ak820_leader_process_sloc0_1_0 + 1)
	subb	a,#0x00
	jc	00127$
	mov	a,#0x27
	subb	a,_ak820_leader_process_sloc0_1_0
	clr	a
	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
	jc	00127$
;	free result
	mov	ar7,r1
	mov	a,r7
	add	a,#0xe2
	mov	dptr,#_ak820_leader_process_slot_10000_602
	movx	@dptr,a
	sjmp	00128$
00127$:
;	keyboards/ajazz/ak820/ak820_leader.c:60: else if (code >= KC_A && code <= KC_F) slot = code - KC_A + 10;
	clr	c
	mov	a,#0x09
	subb	a,_ak820_leader_process_sloc0_1_0
	clr	a
	subb	a,(_ak820_leader_process_sloc0_1_0 + 1)
	jc	00128$
;	free result
	mov	dptr,#_ak820_leader_process_slot_10000_602
	mov	a,#0x06
	add	a, r1
	movx	@dptr,a
00128$:
;	keyboards/ajazz/ak820/ak820_leader.c:61: leader_pending = slot; /* Other basic keys are consumed without output. */
	mov	dptr,#_ak820_leader_process_slot_10000_602
	movx	a,@dptr
	mov	dptr,#_leader_pending
	movx	@dptr,a
00132$:
;	keyboards/ajazz/ak820/ak820_leader.c:63: leader_suppressed[index] |= mask;
	mov	dpl,r3
	mov	dph,r5
	movx	a,@dptr
	orl	ar4,a
	mov	dpl,r3
	mov	dph,r5
	mov	a,r4
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_leader.c:64: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_leader.c:65: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__leader_pending:
	.db #0xff	; 255
	.area CABS    (ABS,CODE)
