;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module vial
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _unregister_code16
	.globl _register_code16
	.globl _matrix_is_on
	.globl _dynamic_keymap_set_combo
	.globl _dynamic_keymap_get_combo
	.globl _dynamic_keymap_set_encoder
	.globl _dynamic_keymap_get_encoder
	.globl _repeat_key_cancel
	.globl _ak820_combo_reload
	.globl _clear_keyboard
	.globl _ak820_action_exec
	.globl _timer_elapsed32
	.globl _timer_read32
	.globl _timer_read
	.globl ___memcpy
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _vial_unlock_in_progress
	.globl _vial_unlocked
	.globl _g_vial_magic_keycode_override
	.globl _vial_handle_cmd_PARM_2
	.globl _vial_unlock_task
	.globl _vial_init
	.globl _vial_handle_cmd
	.globl _vial_keycode_down
	.globl _vial_keycode_up
	.globl _vial_keycode_tap
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_vial_handle_cmd_sloc0_1_0:
	.ds 2
_vial_handle_cmd_sloc1_1_0:
	.ds 2
_vial_handle_cmd_sloc2_1_0:
	.ds 2
_vial_handle_cmd_sloc3_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_vial_unlock_timer:
	.ds 4
_vial_unlock_holding:
	.ds 1
_vial_keycode_firewall_in_10000_609:
	.ds 2
_vial_fill_packet_PARM_2:
	.ds 1
_vial_fill_packet_msg_10000_612:
	.ds 2
_vial_handle_cmd_PARM_2:
	.ds 1
_vial_handle_cmd_data_10000_617:
	.ds 3
_vial_handle_cmd_entry_70000_645:
	.ds 10
_vial_handle_cmd_entry_70000_646:
	.ds 10
_g_vial_magic_keycode_override::
	.ds 2
_vial_keycode_down_keycode_10000_648:
	.ds 2
_vial_keycode_down_dummy_event_30000_655:
	.ds 6
_vial_keycode_up_keycode_10000_656:
	.ds 2
_vial_keycode_up_dummy_event_30000_663:
	.ds 6
_vial_keycode_tap_keycode_10000_664:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_vial_unlocked::
	.ds 1
_vial_unlock_in_progress::
	.ds 1
_vial_unlock_counter:
	.ds 1
_vial_unlock_combo_rows:
	.ds 2
_vial_unlock_combo_cols:
	.ds 2
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function vial_unlock_task
;	-----------------------------------------
_vial_unlock_task:
;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jnz	00131$
	ret
;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
00131$:
	mov	r7,#0x00
00115$:
	cjne	r7,#0x02,00184$
00184$:
	jnc	00105$
;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
	mov	a,r7
	lcall	_ak820_outline_0124
	mov	r6,a
	mov	a,r7
	lcall	_ak820_outline_0123
	mov	dptr,#_matrix_is_on_PARM_2
	movx	@dptr,a
	mov	dpl, r6
	push	ar7
	lcall	_matrix_is_on
	mov	a, dpl
	pop	ar7
	jnz	00116$
;	quantum/vial.c:67: vial_unlock_holding = false;
	mov	dptr,#_vial_unlock_holding
	clr	a
	movx	@dptr,a
;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
	mov	dptr,#_vial_unlock_counter
	mov	a,#0x1e
	movx	@dptr,a
;	quantum/vial.c:69: return;
	ret
00116$:
;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
	inc	r7
	sjmp	00115$
00105$:
;	quantum/vial.c:72: if (!vial_unlock_holding) {
	mov	dptr,#_vial_unlock_holding
	movx	a,@dptr
	jnz	00107$
;	quantum/vial.c:73: vial_unlock_holding = true;
	mov	dptr,#_vial_unlock_holding
	mov	a,#0x01
	movx	@dptr,a
;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
	lcall	_timer_read32
	lcall	_ak820_outline_0056
	mov	dptr,#_vial_unlock_timer
	lcall	_ak820_outline_0006
00107$:
;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
	mov	dptr,#_vial_unlock_timer
	lcall	_ak820_outline_0054
	lcall	_timer_elapsed32
	lcall	_ak820_outline_0056
;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
	mov	r3,#0x1e
00109$:
	mov	a,r3
	jz	00111$
	clr	c
	mov	a,r4
	subb	a,#0x64
	mov	a,r5
	subb	a,#0x00
	mov	a,r6
	subb	a,#0x00
	mov	a,r7
	subb	a,#0x00
	jc	00111$
;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
	mov	a,r4
	add	a,#0x9c
	mov	r4,a
	mov	a,r5
	addc	a,#0xff
	mov	r5,a
	mov	a,r6
	addc	a,#0xff
	mov	r6,a
	mov	a,r7
	addc	a,#0xff
	mov	r7,a
;	quantum/vial.c:82: --counter;
	dec	r3
	sjmp	00109$
00111$:
;	quantum/vial.c:84: vial_unlock_counter = counter;
	mov	dptr,#_vial_unlock_counter
	mov	a,r3
	movx	@dptr,a
;	quantum/vial.c:85: if (!counter) {
	mov	a,r3
	jnz	00117$
;	quantum/vial.c:86: vial_unlock_in_progress = 0;
	mov	dptr,#_vial_unlock_in_progress
	clr	a
	movx	@dptr,a
;	quantum/vial.c:87: vial_unlocked = 1;
	mov	dptr,#_vial_unlocked
	inc	a
	movx	@dptr,a
00117$:
;	quantum/vial.c:90: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_init'
;------------------------------------------------------------
;	quantum/vial.c:108: void vial_init(void) {
;	-----------------------------------------
;	 function vial_init
;	-----------------------------------------
_vial_init:
;	quantum/vial.c:113: reload_combo();
;	quantum/vial.c:118: }
	ljmp	_ak820_combo_reload
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_keycode_firewall'
;------------------------------------------------------------
;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
;------------------------------------------------------------
;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
;	-----------------------------------------
;	 function vial_keycode_firewall
;	-----------------------------------------
_vial_keycode_firewall:
	lcall	_ak820_outline_0104
	mov	dptr,#_vial_keycode_firewall_in_10000_609
	lcall	_ak820_outline_0103
;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
	mov	dptr,#_vial_keycode_firewall_in_10000_609
	lcall	_ak820_outline_0008
	cjne	r4,#0x00,00102$
	cjne	r5,#0x7c,00102$
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jnz	00102$
;	quantum/vial.c:122: return 0;
	mov	dptr,#0x0000
	ret
00102$:
;	quantum/vial.c:123: return in;
	lcall	_ak820_outline_0112
;	quantum/vial.c:124: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_fill_packet'
;------------------------------------------------------------
;value         Allocated with name '_vial_fill_packet_PARM_2'
;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
;i             Allocated with name '_vial_fill_packet_i_20000_614'
;------------------------------------------------------------
;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
;	-----------------------------------------
;	 function vial_fill_packet
;	-----------------------------------------
_vial_fill_packet:
	lcall	_ak820_outline_0104
	mov	dptr,#_vial_fill_packet_msg_10000_612
	lcall	_ak820_outline_0103
;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
	mov	dptr,#_vial_fill_packet_msg_10000_612
	lcall	_ak820_outline_0051
	mov	dptr,#_vial_fill_packet_PARM_2
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
00103$:
	cjne	r4,#0x20,00122$
00122$:
	jnc	00105$
	mov	a,r4
	lcall	_ak820_outline_0021
	mov	a,r5
	movx	@dptr,a
	inc	r4
	sjmp	00103$
00105$:
;	quantum/vial.c:129: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_release_held_state'
;------------------------------------------------------------
;	quantum/vial.c:140: static void vial_release_held_state(void) {
;	-----------------------------------------
;	 function vial_release_held_state
;	-----------------------------------------
_vial_release_held_state:
;	quantum/vial.c:162: repeat_key_cancel();
	lcall	_repeat_key_cancel
;	quantum/vial.c:164: clear_keyboard();
;	quantum/vial.c:165: }
	ljmp	_clear_keyboard
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_handle_cmd'
;------------------------------------------------------------
;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
;length        Allocated with name '_vial_handle_cmd_PARM_2'
;data          Allocated with name '_vial_handle_cmd_data_10000_617'
;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
;i             Allocated with name '_vial_handle_cmd_i_50000_623'
;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
;page          Allocated with name '_vial_handle_cmd_page_40001_627'
;start         Allocated with name '_vial_handle_cmd_start_40002_629'
;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
;count         Allocated with name '_vial_handle_cmd_count_40002_629'
;i             Allocated with name '_vial_handle_cmd_i_50002_630'
;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
;i             Allocated with name '_vial_handle_cmd_i_50000_634'
;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
;------------------------------------------------------------
;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function vial_handle_cmd
;	-----------------------------------------
_vial_handle_cmd:
	lcall	_ak820_outline_0036
	mov	dptr,#_vial_handle_cmd_data_10000_617
	lcall	_ak820_outline_0015
;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
	mov	dptr,#_vial_handle_cmd_data_10000_617
	lcall	_ak820_outline_0051
;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
	mov	dptr,#_vial_handle_cmd_PARM_2
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x20,00258$
	sjmp	00102$
00258$:
;	quantum/vial.c:178: return;
	ret
00102$:
;	quantum/vial.c:181: switch (msg[1]) {
	mov	a,#0x01
	lcall	_ak820_outline_0031
	mov  r3,a
	add	a,#0xff - 0x0d
	jnc	00259$
	ret
00259$:
;	free result
	mov	a,r3
	add	a,#(00260$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r3
	add	a,#(00261$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00260$:
	.db	00103$
	.db	00105$
	.db	00106$
	.db	00112$
	.db	00113$
	.db	00114$
	.db	00116$
	.db	00119$
	.db	00120$
	.db	00121$
	.db	00139$
	.db	00139$
	.db	00139$
	.db	00122$
00261$:
	.db	00103$>>8
	.db	00105$>>8
	.db	00106$>>8
	.db	00112$>>8
	.db	00113$>>8
	.db	00114$>>8
	.db	00116$>>8
	.db	00119$>>8
	.db	00120$>>8
	.db	00121$>>8
	.db	00139$>>8
	.db	00139$>>8
	.db	00139$>>8
	.db	00122$>>8
;	quantum/vial.c:183: case vial_get_keyboard_id: {
00103$:
;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
	mov	dptr,#_vial_fill_packet_PARM_2
	clr	a
	lcall	_ak820_outline_0071
	push	ar7
	push	ar6
	lcall	_vial_fill_packet
	pop	ar6
	pop	ar7
;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
	lcall	_ak820_outline_0112
	mov	a,#0x06
	lcall	_ak820_outline_0071
;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
	inc	dptr
	clr	a
	lcall	_ak820_outline_0032
;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
	lcall	_ak820_outline_0032
;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
	inc	dptr
	movx	@dptr,a
;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
	mov	r3,a
00131$:
	cjne	r3,#0x08,00262$
00262$:
	jnc	00104$
	mov	ar2,r3
	mov	a,#0x04
	add	a, r2
	add	a, r6
	mov	r1,a
	clr	a
	addc	a,r7
	mov	r2,a
	mov	a,r3
	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
	movc	a,@a+dptr
	lcall	_ak820_outline_0134
	inc	r3
	sjmp	00131$
00104$:
;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
	mov	a,#0x0c
	lcall	_ak820_outline_0021
	mov	a,#0x01
	movx	@dptr,a
;	quantum/vial.c:195: break;
	ret
;	quantum/vial.c:198: case vial_get_size: {
00105$:
;	quantum/vial.c:200: msg[0] = sz & 0xFF;
	lcall	_ak820_outline_0112
	mov	a,#0x7c
	movx	@dptr,a
;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
	lcall	_ak820_outline_0120
	mov	a,#0x01
	lcall	_ak820_outline_0032
;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
	clr	a
	lcall	_ak820_outline_0032
;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
	inc	dptr
	movx	@dptr,a
;	quantum/vial.c:204: break;
	ret
;	quantum/vial.c:207: case vial_get_def: {
00106$:
;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
	lcall	_ak820_outline_0020
	movx	a,@dptr
	mov	r3,a
	lcall	_ak820_outline_0010
	movx	a,@dptr
	orl	a,r3
	jz	00108$
	ret
00108$:
;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
	lcall	_ak820_outline_0035
	mov	r3,a
	mov	r2,#0x00
	lcall	_ak820_outline_0016
	mov	r1,a
	clr	a
	orl	ar3,a
	mov	a,r1
	orl	ar2,a
;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
	clr	c
	mov	a,r3
	subb	a,#0x0c
	mov	a,r2
	subb	a,#0x00
	jc	00110$
	ret
00110$:
;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
	mov	a,r2
	swap	a
	rl	a
	anl	a,#0xe0
	xch	a,r3
	swap	a
	rl	a
	xch	a,r3
	xrl	a,r3
	xch	a,r3
	anl	a,#0xe0
	xch	a,r3
	xrl	a,r3
	mov	r2,a
	mov	_vial_handle_cmd_sloc0_1_0,r3
	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
	mov	a,#0x7c
	clr	c
	subb	a,_vial_handle_cmd_sloc0_1_0
	mov	r0,a
	mov	a,#0x01
	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
	mov	r1,a
;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
	clr	c
	mov	a,r0
	subb	a,#0x20
	mov	a,r1
	subb	a,#0x00
	jc	00142$
	mov	r0,#0x20
00142$:
;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
	mov	r1,#0x00
00134$:
	clr	c
	mov	a,r1
	subb	a,r0
	jc	00267$
	ret
00267$:
	push	ar0
	mov	a,r1
	add	a, r6
	mov	_vial_handle_cmd_sloc1_1_0,a
	clr	a
	addc	a, r7
	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
	mov	_vial_handle_cmd_sloc2_1_0,r1
	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
	mov	r0,_vial_handle_cmd_sloc0_1_0
	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
	mov	a,_vial_handle_cmd_sloc2_1_0
	add	a, r0
	mov	r0,a
	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
	addc	a, r3
	mov	r3,a
	mov	a,r0
	add	a, #_keyboard_definition
	mov	dpl,a
	mov	a,r3
	addc	a, #(_keyboard_definition >> 8)
	mov	dph,a
	clr	a
	movc	a,@a+dptr
	mov	dpl,_vial_handle_cmd_sloc1_1_0
	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
	movx	@dptr,a
	inc	r1
	pop	ar0
;	quantum/vial.c:234: case vial_get_encoder: {
	sjmp	00134$
00112$:
;	quantum/vial.c:235: uint8_t layer = msg[2];
	mov	a,#0x02
	lcall	_ak820_outline_0030
	mov	_vial_handle_cmd_sloc2_1_0,a
;	quantum/vial.c:236: uint8_t idx = msg[3];
	mov	a,#0x03
	add	a, r6
	mov	_vial_handle_cmd_sloc1_1_0,a
	clr	a
	addc	a, r7
	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
	mov	dpl,_vial_handle_cmd_sloc1_1_0
	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
	movx	a,@dptr
;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
	mov	_vial_handle_cmd_sloc0_1_0,a
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
	clr	a
	movx	@dptr,a
	mov	dpl, _vial_handle_cmd_sloc2_1_0
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_dynamic_keymap_get_encoder
	mov	_vial_handle_cmd_sloc3_1_0,dpl
	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/vial.c:238: msg[0]  = keycode >> 8;
	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
	lcall	_ak820_outline_0112
	mov	a,r1
	movx	@dptr,a
;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
	mov	r0,_vial_handle_cmd_sloc3_1_0
	lcall	_ak820_outline_0120
	mov	a,r0
	movx	@dptr,a
;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
	mov	a,_vial_handle_cmd_sloc0_1_0
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, _vial_handle_cmd_sloc2_1_0
	push	ar3
	push	ar2
	lcall	_dynamic_keymap_get_encoder
	mov	_vial_handle_cmd_sloc3_1_0,dpl
	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
	pop	ar2
	pop	ar3
;	quantum/vial.c:241: msg[2] = keycode >> 8;
	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
	lcall	_ak820_outline_0138
	mov	a,r1
	movx	@dptr,a
;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
	mov	r0,_vial_handle_cmd_sloc3_1_0
	mov	dpl,_vial_handle_cmd_sloc1_1_0
	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
	mov	a,r0
	movx	@dptr,a
;	quantum/vial.c:243: break;
	ret
;	quantum/vial.c:245: case vial_set_encoder: {
00113$:
;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
	lcall	_ak820_outline_0035
	mov	_vial_handle_cmd_sloc1_1_0,a
	lcall	_ak820_outline_0016
	mov	_vial_handle_cmd_sloc2_1_0,a
	lcall	_ak820_outline_0020
	movx	a,@dptr
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	_vial_handle_cmd_sloc3_1_0,a
	lcall	_ak820_outline_0010
	movx	a,@dptr
	mov	r1,a
	mov	r0,#0x00
	mov	a,#0x06
	lcall	_ak820_outline_0021
	movx	a,@dptr
	mov	r3,#0x00
	orl	ar0,a
	mov	a,r3
	orl	ar1,a
	lcall	_ak820_outline_0151
	lcall	_vial_keycode_firewall
	mov	r2, dpl
	mov	r3, dph
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
	mov	a,_vial_handle_cmd_sloc2_1_0
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
	mov	a,_vial_handle_cmd_sloc3_1_0
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
	mov	a,r2
	lcall	_ak820_outline_0183
	mov	dpl, _vial_handle_cmd_sloc1_1_0
;	quantum/vial.c:247: break;
	ljmp	_dynamic_keymap_set_encoder
;	quantum/vial.c:250: case vial_get_unlock_status: {
00114$:
;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
	mov	dptr,#_vial_fill_packet_PARM_2
	mov	a,#0xff
	lcall	_ak820_outline_0071
	push	ar7
	push	ar6
	lcall	_vial_fill_packet
	pop	ar6
	pop	ar7
;	quantum/vial.c:254: msg[0] = vial_unlocked;
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	lcall	_ak820_outline_0112
	movx	@dptr,a
;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
	mov	a,#0x01
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	lcall	_ak820_outline_0138
	movx	@dptr,a
;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
	mov	r3,#0x00
00137$:
	cjne	r3,#0x02,00268$
00268$:
	jc	00269$
	ret
00269$:
;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
	mov	ar1,r3
	mov	r2,#0x00
	mov	a,r1
	add	a,r1
	mov	_vial_handle_cmd_sloc3_1_0,a
	mov	a,r2
	rlc	a
	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
	mov	a,#0x02
	add	a, _vial_handle_cmd_sloc3_1_0
	mov	r0,a
	clr	a
	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
	mov	r2,a
	mov	a,r0
	add	a, r6
	mov	r0,a
	mov	a,r2
	addc	a, r7
	mov	r2,a
	mov	a,r3
	lcall	_ak820_outline_0124
	mov	dpl,r0
	mov	dph,r2
	movx	@dptr,a
;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
	mov	a,#0x03
	add	a, _vial_handle_cmd_sloc3_1_0
	mov	r1,a
	clr	a
	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
	mov	r2,a
	mov	a,r1
	add	a, r6
	mov	r1,a
	mov	a,r2
	addc	a, r7
	mov	r2,a
	mov	a,r3
	lcall	_ak820_outline_0123
	lcall	_ak820_outline_0134
;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
	inc	r3
;	quantum/vial.c:266: case vial_unlock_start: {
	sjmp	00137$
00116$:
;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jnz	00118$
	lcall	_vial_release_held_state
00118$:
;	quantum/vial.c:270: vial_unlock_in_progress = 1;
	mov	dptr,#_vial_unlock_in_progress
	mov	a,#0x01
	movx	@dptr,a
;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
	mov	dptr,#_vial_unlock_counter
	mov	a,#0x1e
	movx	@dptr,a
;	quantum/vial.c:273: vial_unlock_holding = false;
	mov	dptr,#_vial_unlock_holding
	clr	a
	movx	@dptr,a
;	quantum/vial.c:275: break;
	ret
;	quantum/vial.c:277: case vial_unlock_poll: {
00119$:
;	quantum/vial.c:278: msg[0] = vial_unlocked;
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	lcall	_ak820_outline_0112
	movx	@dptr,a
;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	lcall	_ak820_outline_0116
;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
	mov	a,#0x02
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dptr,#_vial_unlock_counter
	movx	a,@dptr
	lcall	_ak820_outline_0138
	movx	@dptr,a
;	quantum/vial.c:281: break;
	ret
;	quantum/vial.c:283: case vial_lock: {
00120$:
;	quantum/vial.c:285: vial_unlocked = 0;
	mov	dptr,#_vial_unlocked
	clr	a
	movx	@dptr,a
;	quantum/vial.c:286: vial_unlock_in_progress = 0;
	mov	dptr,#_vial_unlock_in_progress
	movx	@dptr,a
;	quantum/vial.c:287: vial_unlock_holding = false;
	mov	dptr,#_vial_unlock_holding
	movx	@dptr,a
;	quantum/vial.c:289: break;
	ret
;	quantum/vial.c:291: case vial_qmk_settings_query: {
00121$:
;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
	mov	dptr,#_vial_fill_packet_PARM_2
	mov	a,#0xff
	lcall	_ak820_outline_0071
;	quantum/vial.c:298: break;
	ljmp	_vial_fill_packet
;	quantum/vial.c:318: case vial_dynamic_entry_op: {
00122$:
;	quantum/vial.c:319: switch (msg[2]) {
	lcall	_ak820_outline_0035
	mov	r3,a
	jz	00123$
	cjne	r3,#0x03,00272$
	sjmp	00124$
00272$:
	cjne	r3,#0x04,00273$
	ljmp	00125$
00273$:
	ret
;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
00123$:
;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
	mov	dptr,#_vial_fill_packet_PARM_2
	clr	a
	lcall	_ak820_outline_0071
	push	ar7
	push	ar6
	lcall	_vial_fill_packet
	pop	ar6
	pop	ar7
;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
	lcall	_ak820_outline_0112
	clr	a
	lcall	_ak820_outline_0071
;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
	inc	dptr
	mov	a,#0x08
	lcall	_ak820_outline_0032
;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
	clr	a
	movx	@dptr,a
;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
	mov	a,#0x1f
	lcall	_ak820_outline_0021
	mov	a,#0x01
	movx	@dptr,a
;	quantum/vial.c:328: break;
	ret
;	quantum/vial.c:352: case dynamic_vial_combo_get: {
00124$:
;	quantum/vial.c:353: uint8_t idx = msg[3];
	lcall	_ak820_outline_0016
	mov	r3,a
;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
	mov	dptr,#_vial_handle_cmd_entry_70000_645
	lcall	_ak820_outline_0164
	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
	mov	a,#_vial_handle_cmd_entry_70000_645
	movx	@dptr,a
	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
	lcall	_ak820_outline_0088
	mov	dpl, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_dynamic_keymap_get_combo
	mov	r2, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	lcall	_ak820_outline_0112
	mov	a,r2
	movx	@dptr,a
;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
	mov	r3,#0x00
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_vial_handle_cmd_entry_70000_645
	movx	@dptr,a
	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
	lcall	_ak820_outline_0073
	lcall	_ak820_outline_0120
	mov	b, r3
;	quantum/vial.c:357: break;
	ljmp	___memcpy
;	quantum/vial.c:359: case dynamic_vial_combo_set: {
00125$:
;	quantum/vial.c:360: uint8_t idx = msg[3];
	lcall	_ak820_outline_0016
	mov	r5,a
;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
	mov	a,#0x04
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dptr,#___memcpy_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	lcall	_ak820_outline_0073
	mov	dptr,#_vial_handle_cmd_entry_70000_646
	mov	b,a
	push	ar7
	push	ar6
	push	ar5
	lcall	___memcpy
;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
	lcall	_ak820_outline_0099
	lcall	_ak820_outline_0119
	lcall	_vial_keycode_firewall
	mov	r3, dpl
	mov	r4, dph
	pop	ar5
	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
	lcall	_ak820_outline_0080
;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
	mov	a,#_vial_handle_cmd_entry_70000_646
	movx	@dptr,a
	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
	lcall	_ak820_outline_0088
	mov	dpl, r5
	lcall	_dynamic_keymap_set_combo
	mov	r4, dpl
	pop	ar6
	pop	ar7
	lcall	_ak820_outline_0112
	mov	a,r4
	movx	@dptr,a
;	quantum/vial.c:365: if (!msg[0]) reload_combo();
	mov	a,r4
	jnz	00139$
;	quantum/vial.c:391: }
;	quantum/vial.c:392: }
	ljmp	_ak820_combo_reload
00139$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_keycode_down'
;------------------------------------------------------------
;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
;------------------------------------------------------------
;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
;	-----------------------------------------
;	 function vial_keycode_down
;	-----------------------------------------
_vial_keycode_down:
	lcall	_ak820_outline_0104
	mov	dptr,#_vial_keycode_down_keycode_10000_648
	lcall	_ak820_outline_0103
;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
	mov	dptr,#_vial_keycode_down_keycode_10000_648
	lcall	_ak820_outline_0008
	mov	a,#0x100 - 0x20
	add	a,r5
	jnc	00104$
	clr	c
	mov	a,#0xff
	subb	a,r4
	mov	a,#0x4f
	subb	a,r5
	jc	00104$
;	free result
;	quantum/vial.c:401: keycode = (uint8_t)keycode;
	mov	dptr,#_vial_keycode_down_keycode_10000_648
	mov	a,r6
	lcall	_ak820_outline_0121
;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
	mov	dptr,#_vial_keycode_down_keycode_10000_648
	movx	a,@dptr
	add	a,#0xff - 0x01
	jc	00104$
;	free result
	ret
00104$:
;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
	mov	dptr,#_vial_keycode_down_keycode_10000_648
	lcall	_ak820_outline_0023
;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
	jc	00107$
;	free result
;	quantum/vial.c:408: register_code16(keycode);
	lcall	_ak820_outline_0112
	ljmp	_register_code16
00107$:
;	quantum/vial.c:410: keyevent_t dummy_event = {
	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
	mov	a,#0xf0
	movx	@dptr,a
	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
	movx	@dptr,a
	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
	mov	a,#0x01
	movx	@dptr,a
	lcall	_timer_read
	lcall	_ak820_outline_0130
	orl	ar6,#0x01
	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
	lcall	_ak820_outline_0058
;	quantum/vial.c:414: AK820_ACTION_EXEC(dummy_event);
	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
;	quantum/vial.c:416: }
	ljmp	_ak820_action_exec
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_keycode_up'
;------------------------------------------------------------
;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
;------------------------------------------------------------
;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
;	-----------------------------------------
;	 function vial_keycode_up
;	-----------------------------------------
_vial_keycode_up:
	lcall	_ak820_outline_0104
	mov	dptr,#_vial_keycode_up_keycode_10000_656
	lcall	_ak820_outline_0103
;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
	mov	dptr,#_vial_keycode_up_keycode_10000_656
	lcall	_ak820_outline_0008
	mov	a,#0x100 - 0x20
	add	a,r5
	jnc	00104$
	clr	c
	mov	a,#0xff
	subb	a,r4
	mov	a,#0x4f
	subb	a,r5
	jc	00104$
;	free result
;	quantum/vial.c:423: keycode = (uint8_t)keycode;
	mov	dptr,#_vial_keycode_up_keycode_10000_656
	mov	a,r6
	lcall	_ak820_outline_0121
;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
	mov	dptr,#_vial_keycode_up_keycode_10000_656
	movx	a,@dptr
	add	a,#0xff - 0x01
	jc	00104$
;	free result
	ret
00104$:
;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
	mov	dptr,#_vial_keycode_up_keycode_10000_656
	lcall	_ak820_outline_0023
;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
	jc	00107$
;	free result
;	quantum/vial.c:430: unregister_code16(keycode);
	lcall	_ak820_outline_0112
	ljmp	_unregister_code16
00107$:
;	quantum/vial.c:432: keyevent_t dummy_event = {
	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
	mov	a,#0xf0
	movx	@dptr,a
	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
	movx	@dptr,a
	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
	clr	a
	movx	@dptr,a
	lcall	_timer_read
	lcall	_ak820_outline_0130
	orl	ar6,#0x01
	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
	lcall	_ak820_outline_0058
;	quantum/vial.c:436: AK820_ACTION_EXEC(dummy_event);
	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
;	quantum/vial.c:438: }
	ljmp	_ak820_action_exec
;------------------------------------------------------------
;Allocation info for local variables in function 'vial_keycode_tap'
;------------------------------------------------------------
;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
;i             Allocated with name '_vial_keycode_tap_i_30000_667'
;------------------------------------------------------------
;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
;	-----------------------------------------
;	 function vial_keycode_tap
;	-----------------------------------------
_vial_keycode_tap:
	lcall	_ak820_outline_0104
	mov	dptr,#_vial_keycode_tap_keycode_10000_664
	lcall	_ak820_outline_0103
;	quantum/vial.c:441: vial_keycode_down(keycode);
	mov	dptr,#_vial_keycode_tap_keycode_10000_664
	lcall	_ak820_outline_0005
	push	ar7
	push	ar6
	lcall	_vial_keycode_down
	pop	ar6
	pop	ar7
;	quantum/vial.c:443: vial_keycode_up(keycode);
	lcall	_ak820_outline_0112
;	quantum/vial.c:444: }
	ljmp	_vial_keycode_up
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_vial'
;------------------------------------------------------------
;record        Allocated with name '_process_record_vial_PARM_2'
;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
;------------------------------------------------------------
;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_keyboard_definition:
	.db #0xfd	; 253
	.db #0x37	; 55	'7'
	.db #0x7a	; 122	'z'
	.db #0x58	; 88	'X'
	.db #0x5a	; 90	'Z'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0xe6	; 230
	.db #0xd6	; 214
	.db #0xb4	; 180
	.db #0x46	; 70	'F'
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x21	; 33
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x37	; 55	'7'
	.db #0x27	; 39
	.db #0x97	; 151
	.db #0xd6	; 214
	.db #0xe0	; 224
	.db #0x03	; 3
	.db #0xcb	; 203
	.db #0x01	; 1
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3d	; 61
	.db #0x88	; 136
	.db #0xcd	; 205
	.db #0xa5	; 165
	.db #0xaa	; 170
	.db #0xe5	; 229
	.db #0xa8	; 168
	.db #0x76	; 118	'v'
	.db #0xf6	; 246
	.db #0x43	; 67	'C'
	.db #0x0e	; 14
	.db #0xd2	; 210
	.db #0x90	; 144
	.db #0x7d	; 125
	.db #0x94	; 148
	.db #0x79	; 121	'y'
	.db #0x78	; 120	'x'
	.db #0xef	; 239
	.db #0x49	; 73	'I'
	.db #0x3e	; 62
	.db #0xef	; 239
	.db #0xfd	; 253
	.db #0x8f	; 143
	.db #0xef	; 239
	.db #0x00	; 0
	.db #0xc6	; 198
	.db #0xd1	; 209
	.db #0xdb	; 219
	.db #0xfb	; 251
	.db #0xeb	; 235
	.db #0xde	; 222
	.db #0x66	; 102	'f'
	.db #0x63	; 99	'c'
	.db #0x0c	; 12
	.db #0x92	; 146
	.db #0x7b	; 123
	.db #0xf9	; 249
	.db #0xd4	; 212
	.db #0x7a	; 122	'z'
	.db #0x4f	; 79	'O'
	.db #0x83	; 131
	.db #0x4b	; 75	'K'
	.db #0x86	; 134
	.db #0x0e	; 14
	.db #0x6a	; 106	'j'
	.db #0xf2	; 242
	.db #0x22	; 34
	.db #0x22	; 34
	.db #0x0b	; 11
	.db #0x03	; 3
	.db #0xba	; 186
	.db #0x67	; 103	'g'
	.db #0x9b	; 155
	.db #0x7a	; 122	'z'
	.db #0xe1	; 225
	.db #0xbc	; 188
	.db #0x37	; 55	'7'
	.db #0x26	; 38
	.db #0x46	; 70	'F'
	.db #0x78	; 120	'x'
	.db #0x05	; 5
	.db #0x0d	; 13
	.db #0x95	; 149
	.db #0x02	; 2
	.db #0xe4	; 228
	.db #0x18	; 24
	.db #0xca	; 202
	.db #0x33	; 51	'3'
	.db #0xea	; 234
	.db #0x24	; 36
	.db #0xc8	; 200
	.db #0x81	; 129
	.db #0x4e	; 78	'N'
	.db #0x47	; 71	'G'
	.db #0xa8	; 168
	.db #0x44	; 68	'D'
	.db #0xdd	; 221
	.db #0x91	; 145
	.db #0x6d	; 109	'm'
	.db #0x69	; 105	'i'
	.db #0xdb	; 219
	.db #0x4f	; 79	'O'
	.db #0x3a	; 58
	.db #0x43	; 67	'C'
	.db #0x9d	; 157
	.db #0x26	; 38
	.db #0x49	; 73	'I'
	.db #0x4c	; 76	'L'
	.db #0xef	; 239
	.db #0x2b	; 43
	.db #0xd8	; 216
	.db #0x55	; 85	'U'
	.db #0x95	; 149
	.db #0x70	; 112	'p'
	.db #0xb1	; 177
	.db #0xcc	; 204
	.db #0xcf	; 207
	.db #0x13	; 19
	.db #0x32	; 50	'2'
	.db #0x6a	; 106	'j'
	.db #0xa1	; 161
	.db #0xff	; 255
	.db #0x99	; 153
	.db #0x61	; 97	'a'
	.db #0x95	; 149
	.db #0xb1	; 177
	.db #0x89	; 137
	.db #0x9b	; 155
	.db #0x11	; 17
	.db #0xd9	; 217
	.db #0x35	; 53	'5'
	.db #0x78	; 120	'x'
	.db #0xed	; 237
	.db #0xcd	; 205
	.db #0x94	; 148
	.db #0x6e	; 110	'n'
	.db #0x60	; 96
	.db #0x8e	; 142
	.db #0x63	; 99	'c'
	.db #0x8b	; 139
	.db #0xff	; 255
	.db #0x4e	; 78	'N'
	.db #0x20	; 32
	.db #0x7a	; 122	'z'
	.db #0xb5	; 181
	.db #0x87	; 135
	.db #0xc2	; 194
	.db #0x35	; 53	'5'
	.db #0xa4	; 164
	.db #0x6d	; 109	'm'
	.db #0x18	; 24
	.db #0xc1	; 193
	.db #0xa3	; 163
	.db #0xdb	; 219
	.db #0x53	; 83	'S'
	.db #0x1d	; 29
	.db #0xec	; 236
	.db #0xf0	; 240
	.db #0xbf	; 191
	.db #0x4a	; 74	'J'
	.db #0x4c	; 76	'L'
	.db #0x4a	; 74	'J'
	.db #0xc4	; 196
	.db #0xaa	; 170
	.db #0x37	; 55	'7'
	.db #0x19	; 25
	.db #0x34	; 52	'4'
	.db #0x3f	; 63
	.db #0xa1	; 161
	.db #0xd3	; 211
	.db #0x1a	; 26
	.db #0x5c	; 92
	.db #0x03	; 3
	.db #0x4d	; 77	'M'
	.db #0xbc	; 188
	.db #0x10	; 16
	.db #0x2e	; 46
	.db #0x80	; 128
	.db #0xf7	; 247
	.db #0xd6	; 214
	.db #0x82	; 130
	.db #0x24	; 36
	.db #0x4c	; 76	'L'
	.db #0x87	; 135
	.db #0xb9	; 185
	.db #0xf8	; 248
	.db #0xbe	; 190
	.db #0x67	; 103	'g'
	.db #0x96	; 150
	.db #0x89	; 137
	.db #0x30	; 48	'0'
	.db #0xc8	; 200
	.db #0x8d	; 141
	.db #0x2c	; 44
	.db #0xf5	; 245
	.db #0x06	; 6
	.db #0x05	; 5
	.db #0x7c	; 124
	.db #0x48	; 72	'H'
	.db #0x1b	; 27
	.db #0x76	; 118	'v'
	.db #0xaa	; 170
	.db #0x3d	; 61
	.db #0x28	; 40
	.db #0xfc	; 252
	.db #0x80	; 128
	.db #0x75	; 117	'u'
	.db #0xeb	; 235
	.db #0x78	; 120	'x'
	.db #0xd0	; 208
	.db #0x8a	; 138
	.db #0x8f	; 143
	.db #0x27	; 39
	.db #0xf7	; 247
	.db #0xf2	; 242
	.db #0xeb	; 235
	.db #0x58	; 88	'X'
	.db #0x37	; 55	'7'
	.db #0x3c	; 60
	.db #0x2b	; 43
	.db #0x6f	; 111	'o'
	.db #0x0e	; 14
	.db #0xc7	; 199
	.db #0xe2	; 226
	.db #0xa0	; 160
	.db #0x97	; 151
	.db #0xee	; 238
	.db #0xfd	; 253
	.db #0x9f	; 159
	.db #0x45	; 69	'E'
	.db #0x17	; 23
	.db #0x94	; 148
	.db #0xe6	; 230
	.db #0xe7	; 231
	.db #0xfa	; 250
	.db #0x4c	; 76	'L'
	.db #0x7a	; 122	'z'
	.db #0xd6	; 214
	.db #0x7a	; 122	'z'
	.db #0x7b	; 123
	.db #0xed	; 237
	.db #0x10	; 16
	.db #0xc5	; 197
	.db #0xbc	; 188
	.db #0xe3	; 227
	.db #0xa9	; 169
	.db #0x1f	; 31
	.db #0xcf	; 207
	.db #0xc4	; 196
	.db #0x9d	; 157
	.db #0xdc	; 220
	.db #0x45	; 69	'E'
	.db #0x2a	; 42
	.db #0x69	; 105	'i'
	.db #0x57	; 87	'W'
	.db #0x8f	; 143
	.db #0xec	; 236
	.db #0x85	; 133
	.db #0x6c	; 108	'l'
	.db #0x43	; 67	'C'
	.db #0x1c	; 28
	.db #0xba	; 186
	.db #0x89	; 137
	.db #0x68	; 104	'h'
	.db #0x4a	; 74	'J'
	.db #0x1c	; 28
	.db #0x91	; 145
	.db #0x3f	; 63
	.db #0xd1	; 209
	.db #0xb3	; 179
	.db #0x96	; 150
	.db #0x1d	; 29
	.db #0x7c	; 124
	.db #0x14	; 20
	.db #0x77	; 119	'w'
	.db #0x9c	; 156
	.db #0x74	; 116	't'
	.db #0x36	; 54	'6'
	.db #0xff	; 255
	.db #0x2c	; 44
	.db #0x66	; 102	'f'
	.db #0xaf	; 175
	.db #0x0f	; 15
	.db #0x3c	; 60
	.db #0xa2	; 162
	.db #0x23	; 35
	.db #0x85	; 133
	.db #0x05	; 5
	.db #0x87	; 135
	.db #0xda	; 218
	.db #0x61	; 97	'a'
	.db #0x5e	; 94
	.db #0x42	; 66	'B'
	.db #0x54	; 84	'T'
	.db #0x60	; 96
	.db #0x23	; 35
	.db #0xca	; 202
	.db #0xbc	; 188
	.db #0xb3	; 179
	.db #0x18	; 24
	.db #0x1d	; 29
	.db #0xf8	; 248
	.db #0x0a	; 10
	.db #0x55	; 85	'U'
	.db #0xcd	; 205
	.db #0xa3	; 163
	.db #0xde	; 222
	.db #0xff	; 255
	.db #0xb2	; 178
	.db #0x2a	; 42
	.db #0x35	; 53	'5'
	.db #0x00	; 0
	.db #0xd6	; 214
	.db #0x7b	; 123
	.db #0xe8	; 232
	.db #0xf2	; 242
	.db #0x1a	; 26
	.db #0xbc	; 188
	.db #0xf5	; 245
	.db #0x7e	; 126
	.db #0x48	; 72	'H'
	.db #0x72	; 114	'r'
	.db #0xe0	; 224
	.db #0xe4	; 228
	.db #0xe0	; 224
	.db #0x27	; 39
	.db #0x87	; 135
	.db #0x9a	; 154
	.db #0x51	; 81	'Q'
	.db #0xd4	; 212
	.db #0xdd	; 221
	.db #0xc3	; 195
	.db #0xaa	; 170
	.db #0x49	; 73	'I'
	.db #0x5a	; 90	'Z'
	.db #0x2a	; 42
	.db #0x00	; 0
	.db #0xa0	; 160
	.db #0x8c	; 140
	.db #0xff	; 255
	.db #0x74	; 116	't'
	.db #0xbf	; 191
	.db #0xec	; 236
	.db #0x1d	; 29
	.db #0xf1	; 241
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0xd8	; 216
	.db #0x02	; 2
	.db #0xcc	; 204
	.db #0x07	; 7
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xc4	; 196
	.db #0x5e	; 94
	.db #0x2c	; 44
	.db #0x7e	; 126
	.db #0xb1	; 177
	.db #0xc4	; 196
	.db #0x67	; 103	'g'
	.db #0xfb	; 251
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x59	; 89	'Y'
	.db #0x5a	; 90	'Z'
	.area CSEG    (CODE)
	.area CONST   (CODE)
_vial_handle_cmd_keyboard_uid_40000_622:
	.db #0x04	; 4
	.db #0x70	; 112	'p'
	.db #0xff	; 255
	.db #0x90	; 144
	.db #0x01	; 1
	.db #0xb9	; 185
	.db #0x15	; 21
	.db #0xd3	; 211
	.area CSEG    (CODE)
	.area XINIT   (CODE)
__xinit__vial_unlocked:
	.db #0x00	;  0
__xinit__vial_unlock_in_progress:
	.db #0x00	;  0
__xinit__vial_unlock_counter:
	.db #0x00	; 0
__xinit__vial_unlock_combo_rows:
	.db #0x00	; 0
	.db #0x00	; 0
__xinit__vial_unlock_combo_cols:
	.db #0x00	; 0
	.db #0x05	; 5
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0006
	.globl _ak820_outline_0008
	.globl _ak820_outline_0010
	.globl _ak820_outline_0015
	.globl _ak820_outline_0016
	.globl _ak820_outline_0020
	.globl _ak820_outline_0021
	.globl _ak820_outline_0023
	.globl _ak820_outline_0030
	.globl _ak820_outline_0031
	.globl _ak820_outline_0032
	.globl _ak820_outline_0035
	.globl _ak820_outline_0036
	.globl _ak820_outline_0051
	.globl _ak820_outline_0054
	.globl _ak820_outline_0056
	.globl _ak820_outline_0058
	.globl _ak820_outline_0071
	.globl _ak820_outline_0073
	.globl _ak820_outline_0080
	.globl _ak820_outline_0088
	.globl _ak820_outline_0099
	.globl _ak820_outline_0103
	.globl _ak820_outline_0104
	.globl _ak820_outline_0112
	.globl _ak820_outline_0116
	.globl _ak820_outline_0119
	.globl _ak820_outline_0120
	.globl _ak820_outline_0121
	.globl _ak820_outline_0123
	.globl _ak820_outline_0124
	.globl _ak820_outline_0130
	.globl _ak820_outline_0134
	.globl _ak820_outline_0138
	.globl _ak820_outline_0151
	.globl _ak820_outline_0164
	.globl _ak820_outline_0183

	.area CSEG (CODE)
; function ak820_outline_0023
_ak820_outline_0023:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_g_vial_magic_keycode_override
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	ar4,r6
	mov	ar5,r7
	clr	c
	mov	a,#0xff
	subb	a,r4
	mov	a,#0x1f
	subb	a,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0073
_ak820_outline_0073:
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x0a
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0123
_ak820_outline_0123:
	add	a,#_vial_unlock_combo_cols
	mov	dpl,a
	clr	a
	addc	a,#(_vial_unlock_combo_cols>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0124
_ak820_outline_0124:
	add	a,#_vial_unlock_combo_rows
	mov	dpl,a
	clr	a
	addc	a,#(_vial_unlock_combo_rows>>8)
	mov	dph,a
	movx	a,@dptr
	ret
