                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000573                        109 _page_data:
      000573                        110 	.ds 64
      0005B3                        111 _cached_page:
      0005B3                        112 	.ds 1
      0005B4                        113 _batch_depth:
      0005B4                        114 	.ds 1
      0005B5                        115 _first_failure_stage:
      0005B5                        116 	.ds 1
      0005B6                        117 _nvm_fail_stage_10000_20:
      0005B6                        118 	.ds 1
      0005B7                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005B7                        120 	.ds 2
      0005B9                        121 _crc_byte_PARM_2:
      0005B9                        122 	.ds 1
      0005BA                        123 _crc_byte_crc_10000_25:
      0005BA                        124 	.ds 2
      0005BC                        125 _page_crc_crc_10000_30:
      0005BC                        126 	.ds 2
      0005BE                        127 _write_page_address_10000_32:
      0005BE                        128 	.ds 2
      0005C0                        129 _journal_header_valid_header_10000_39:
      0005C0                        130 	.ds 2
      0005C2                        131 _recover_journal_header_10000_46:
      0005C2                        132 	.ds 9
      0005CB                        133 _ak820_nvm_flush_header_10000_62:
      0005CB                        134 	.ds 9
      0005D4                        135 _ak820_nvm_flush_stage_10000_62:
      0005D4                        136 	.ds 1
      0005D5                        137 _load_page_page_10000_87:
      0005D5                        138 	.ds 1
      0005D6                        139 _read_offset_offset_10000_93:
      0005D6                        140 	.ds 2
      0005D8                        141 _eeprom_read_byte_addr_10000_97:
      0005D8                        142 	.ds 3
      0005DB                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005DB                        144 	.ds 3
      0005DE                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005DE                        146 	.ds 2
      0005E0                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005E0                        148 	.ds 2
      0005E2                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005E2                        150 	.ds 2
      0005E4                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005E4                        152 	.ds 3
      0005E7                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005E7                        154 	.ds 2
      0005E9                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005E9                        156 	.ds 2
      0005EB                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005EB                        158 	.ds 3
      0005EE                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005EE                        160 	.ds 2
      0005F0                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005F0                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003ED0                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003ED0 E5 82            [12]  215 	mov	a,dpl
      003ED2 90 05 B6         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003ED5 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003ED6 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003ED9 90 05 B6         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003EDC E0               [24]  221 	movx	a,@dptr
      003EDD 90 05 B5         [24]  222 	mov	dptr,#_first_failure_stage
      003EE0 F0               [24]  223 	movx	@dptr,a
      003EE1                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003EE1 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003EE3 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003EE4                        239 _ak820_nvm_diagnostic:
      003EE4 12 38 82         [24]  240 	lcall	_ak820_outline_0108
      003EE7 90 05 B7         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EEA 12 38 87         [24]  242 	lcall	_ak820_outline_0109
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003EED 90 05 B7         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EF0 12 38 41         [24]  245 	lcall	_ak820_outline_0052
      003EF3 A2 0B            [12]  246 	mov	c,_storage_failed
      003EF5 E4               [12]  247 	clr	a
      003EF6 33               [12]  248 	rlc	a
      003EF7 12 38 8C         [24]  249 	lcall	_ak820_outline_0118
      003EFA 12 46 86         [24]  250 	lcall	_ak820_outline_0071
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003EFD A3               [24]  252 	inc	dptr
      003EFE A2 09            [12]  253 	mov	c,_page_valid
      003F00 E4               [12]  254 	clr	a
      003F01 33               [12]  255 	rlc	a
      003F02 12 46 5A         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003F05 A2 0A            [12]  258 	mov	c,_page_dirty
      003F07 E4               [12]  259 	clr	a
      003F08 33               [12]  260 	rlc	a
      003F09 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003F0A 74 03            [12]  263 	mov	a,#0x03
      003F0C 12 46 BF         [24]  264 	lcall	_ak820_outline_0160
      003F0F 90 05 B4         [24]  265 	mov	dptr,#_batch_depth
      003F12 E0               [24]  266 	movx	a,@dptr
      003F13 12 38 97         [24]  267 	lcall	_ak820_outline_0124
      003F16 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003F17 74 04            [12]  270 	mov	a,#0x04
      003F19 12 46 BF         [24]  271 	lcall	_ak820_outline_0160
      003F1C 90 05 B3         [24]  272 	mov	dptr,#_cached_page
      003F1F E0               [24]  273 	movx	a,@dptr
      003F20 12 38 97         [24]  274 	lcall	_ak820_outline_0124
      003F23 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003F24 12 46 50         [24]  277 	lcall	_ak820_outline_0012
      003F27 E4               [12]  278 	clr	a
      003F28 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003F29 74 06            [12]  281 	mov	a,#0x06
      003F2B 12 46 A9         [24]  282 	lcall	_ak820_outline_0138
      003F2E 90 05 B5         [24]  283 	mov	dptr,#_first_failure_stage
      003F31 E0               [24]  284 	movx	a,@dptr
      003F32 12 38 8C         [24]  285 	lcall	_ak820_outline_0118
      003F35 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003F36 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003F37                        300 _crc_byte:
      003F37 12 38 82         [24]  301 	lcall	_ak820_outline_0108
      003F3A 90 05 BA         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003F3D 12 38 87         [24]  303 	lcall	_ak820_outline_0109
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003F40 90 05 B9         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003F43 E0               [24]  306 	movx	a,@dptr
      003F44 FF               [12]  307 	mov	r7,a
      003F45 7E 00            [12]  308 	mov	r6,#0x00
      003F47 90 05 BA         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003F4A E0               [24]  310 	movx	a,@dptr
      003F4B 6E               [12]  311 	xrl	a,r6
      003F4C F0               [24]  312 	movx	@dptr,a
      003F4D A3               [24]  313 	inc	dptr
      003F4E E0               [24]  314 	movx	a,@dptr
      003F4F 6F               [12]  315 	xrl	a,r7
      003F50 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F51 7F 00            [12]  318 	mov	r7,#0x00
      003F53                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003F53 90 05 BA         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003F56 12 38 6A         [24]  322 	lcall	_ak820_outline_0085
      003F59 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003F5C ED               [12]  324 	mov	a,r5
      003F5D 2D               [12]  325 	add	a,r5
      003F5E FB               [12]  326 	mov	r3,a
      003F5F EE               [12]  327 	mov	a,r6
      003F60 33               [12]  328 	rlc	a
      003F61 FC               [12]  329 	mov	r4,a
      003F62 63 03 21         [24]  330 	xrl	ar3,#0x21
      003F65 63 04 10         [24]  331 	xrl	ar4,#0x10
      003F68 80 06            [24]  332 	sjmp	00107$
      003F6A                        333 00106$:
      003F6A ED               [12]  334 	mov	a,r5
      003F6B 2D               [12]  335 	add	a,r5
      003F6C FB               [12]  336 	mov	r3,a
      003F6D EE               [12]  337 	mov	a,r6
      003F6E 33               [12]  338 	rlc	a
      003F6F FC               [12]  339 	mov	r4,a
      003F70                        340 00107$:
      003F70 90 05 BA         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003F73 12 38 64         [24]  342 	lcall	_ak820_outline_0084
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F76 0F               [12]  344 	inc	r7
      003F77 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003F7A 12 33 FC         [24]  347 	lcall	_ak820_outline_0123
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003F7D 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003F7E                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003F7E 90 05 BC         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003F81 74 FF            [12]  363 	mov	a,#0xff
      003F83 F0               [24]  364 	movx	@dptr,a
      003F84 A3               [24]  365 	inc	dptr
      003F85 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003F86 7F 00            [12]  368 	mov	r7,#0x00
      003F88                        369 00102$:
      003F88 90 05 BC         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003F8B 12 38 6A         [24]  371 	lcall	_ak820_outline_0085
      003F8E 12 46 98         [24]  372 	lcall	_ak820_outline_0106
      003F91 90 05 B9         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003F94 F0               [24]  374 	movx	@dptr,a
      003F95 12 38 9C         [24]  375 	lcall	_ak820_outline_0134
      003F98 C0 07            [24]  376 	push	ar7
      003F9A 12 3F 37         [24]  377 	lcall	_crc_byte
      003F9D AD 82            [24]  378 	mov	r5, dpl
      003F9F AE 83            [24]  379 	mov	r6, dph
      003FA1 D0 07            [24]  380 	pop	ar7
      003FA3 90 05 BC         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003FA6 12 46 C5         [24]  382 	lcall	_ak820_outline_0161
      003FA9 0F               [12]  383 	inc	r7
      003FAA BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003FAD 12 38 9C         [24]  386 	lcall	_ak820_outline_0134
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003FB0 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003FB1                        399 _write_page:
      003FB1 12 38 82         [24]  400 	lcall	_ak820_outline_0108
      003FB4 90 05 BE         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003FB7 12 38 87         [24]  402 	lcall	_ak820_outline_0109
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003FBA 90 05 BE         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003FBD 12 37 F4         [24]  405 	lcall	_ak820_outline_0005
      003FC0 C0 07            [24]  406 	push	ar7
      003FC2 C0 06            [24]  407 	push	ar6
      003FC4 12 3D 49         [24]  408 	lcall	_ak820_flash_erase
      003FC7 E5 82            [12]  409 	mov	a, dpl
      003FC9 D0 06            [24]  410 	pop	ar6
      003FCB D0 07            [24]  411 	pop	ar7
      003FCD 70 03            [24]  412 	jnz	00102$
      003FCF F5 82            [12]  413 	mov	dpl,a
      003FD1 22               [24]  414 	ret
      003FD2                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003FD2 90 05 4F         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003FD5 74 73            [12]  418 	mov	a,#_page_data
      003FD7 F0               [24]  419 	movx	@dptr,a
      003FD8 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003FDA A3               [24]  421 	inc	dptr
      003FDB 12 46 86         [24]  422 	lcall	_ak820_outline_0071
      003FDE 12 3E 5D         [24]  423 	lcall	_ak820_flash_program_page
      003FE1 E5 82            [12]  424 	mov	a, dpl
      003FE3 70 03            [24]  425 	jnz	00120$
      003FE5 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FE7 22               [24]  428 	ret
      003FE8                        429 00120$:
      003FE8 7F 00            [12]  430 	mov	r7,#0x00
      003FEA                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003FEA 8F 05            [24]  433 	mov	ar5,r7
      003FEC 7E 00            [12]  434 	mov	r6,#0x00
      003FEE 90 05 BE         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003FF1 12 38 91         [24]  436 	lcall	_ak820_outline_0122
      003FF4 ED               [12]  437 	mov	a,r5
      003FF5 2B               [12]  438 	add	a, r3
      003FF6 FB               [12]  439 	mov	r3,a
      003FF7 EE               [12]  440 	mov	a,r6
      003FF8 3C               [12]  441 	addc	a, r4
      003FF9 FC               [12]  442 	mov	r4,a
      003FFA 12 33 FC         [24]  443 	lcall	_ak820_outline_0123
      003FFD 12 3C 3C         [24]  444 	lcall	_ak820_flash_read
      004000 AE 82            [24]  445 	mov	r6, dpl
      004002 12 46 98         [24]  446 	lcall	_ak820_outline_0106
      004005 FD               [12]  447 	mov	r5,a
      004006 EE               [12]  448 	mov	a,r6
      004007 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      00400A 80 04            [24]  450 	sjmp	00109$
      00400C                        451 00149$:
      00400C 75 82 00         [24]  452 	mov	dpl, #0x00
      00400F 22               [24]  453 	ret
      004010                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004010 0F               [12]  456 	inc	r7
      004011 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      004014 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      004017 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      004018                        472 _journal_header_valid:
      004018 12 38 82         [24]  473 	lcall	_ak820_outline_0108
      00401B 90 05 C0         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      00401E 12 38 87         [24]  475 	lcall	_ak820_outline_0109
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      004021 90 05 C0         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      004024 12 37 F4         [24]  478 	lcall	_ak820_outline_0005
      004027 E0               [24]  479 	movx	a,@dptr
      004028 FD               [12]  480 	mov	r5,a
      004029 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      00402C 80 04            [24]  482 	sjmp	00116$
      00402E                        483 00138$:
      00402E 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004031 22               [24]  486 	ret
      004032                        487 00116$:
      004032 7D 01            [12]  488 	mov	r5,#0x01
      004034                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      004034 ED               [12]  491 	mov	a,r5
      004035 12 38 31         [24]  492 	lcall	_ak820_outline_0021
      004038 E0               [24]  493 	movx	a,@dptr
      004039 FC               [12]  494 	mov	r4,a
      00403A 8D 02            [24]  495 	mov	ar2,r5
      00403C 7B 00            [12]  496 	mov	r3,#0x00
      00403E 74 04            [12]  497 	mov	a,#0x04
      004040 2A               [12]  498 	add	a, r2
      004041 FA               [12]  499 	mov	r2,a
      004042 E4               [12]  500 	clr	a
      004043 3B               [12]  501 	addc	a, r3
      004044 FB               [12]  502 	mov	r3,a
      004045 EA               [12]  503 	mov	a,r2
      004046 2E               [12]  504 	add	a, r6
      004047 F5 82            [12]  505 	mov	dpl,a
      004049 EB               [12]  506 	mov	a,r3
      00404A 3F               [12]  507 	addc	a, r7
      00404B F5 83            [12]  508 	mov	dph,a
      00404D E0               [24]  509 	movx	a,@dptr
      00404E 62 04            [12]  510 	xrl	ar4,a
      004050 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      004053 80 04            [24]  512 	sjmp	00107$
      004055                        513 00139$:
      004055 75 82 00         [24]  514 	mov	dpl, #0x00
      004058 22               [24]  515 	ret
      004059                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004059 0D               [12]  518 	inc	r5
      00405A BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      00405D 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      004060 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      004061                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      004061 7F 00            [12]  538 	mov	r7,#0x00
      004063                        539 00115$:
      004063 EF               [12]  540 	mov	a,r7
      004064 24 C2            [12]  541 	add	a, #_recover_journal_header_10000_46
      004066 FD               [12]  542 	mov	r5,a
      004067 E4               [12]  543 	clr	a
      004068 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      00406A FE               [12]  545 	mov	r6,a
      00406B 8F 04            [24]  546 	mov	ar4,r7
      00406D 7B 00            [12]  547 	mov	r3,#0x00
      00406F 74 40            [12]  548 	mov	a,#0x40
      004071 2C               [12]  549 	add	a, r4
      004072 FC               [12]  550 	mov	r4,a
      004073 74 EF            [12]  551 	mov	a,#0xef
      004075 3B               [12]  552 	addc	a, r3
      004076 FB               [12]  553 	mov	r3,a
      004077 12 46 D0         [24]  554 	lcall	_ak820_outline_0183
      00407A 12 3C 3C         [24]  555 	lcall	_ak820_flash_read
      00407D AC 82            [24]  556 	mov	r4, dpl
      00407F 12 38 9C         [24]  557 	lcall	_ak820_outline_0134
      004082 EC               [12]  558 	mov	a,r4
      004083 F0               [24]  559 	movx	@dptr,a
      004084 0F               [12]  560 	inc	r7
      004085 BF 09 DB         [24]  561 	cjne	r7,#0x09,00115$
                                    562 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      004088 90 05 C2         [24]  563 	mov	dptr,#_recover_journal_header_10000_46
      00408B 12 40 18         [24]  564 	lcall	_journal_header_valid
      00408E E5 82            [12]  565 	mov	a, dpl
      004090 70 01            [24]  566 	jnz	00103$
      004092 22               [24]  567 	ret
      004093                        568 00103$:
                                    569 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      004093 90 05 C3         [24]  570 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      004096 E0               [24]  571 	movx	a,@dptr
      004097 FF               [12]  572 	mov	r7,a
      004098 7E 00            [12]  573 	mov	r6,#0x00
      00409A 90 05 C4         [24]  574 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      00409D E0               [24]  575 	movx	a,@dptr
      00409E FC               [12]  576 	mov	r4,a
      00409F E4               [12]  577 	clr	a
      0040A0 42 07            [12]  578 	orl	ar7,a
      0040A2 EC               [12]  579 	mov	a,r4
      0040A3 42 06            [12]  580 	orl	ar6,a
                                    581 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      0040A5 90 05 C5         [24]  582 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      0040A8 E0               [24]  583 	movx	a,@dptr
      0040A9 FD               [12]  584 	mov	r5,a
      0040AA 7C 00            [12]  585 	mov	r4,#0x00
      0040AC 90 05 C6         [24]  586 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      0040AF E0               [24]  587 	movx	a,@dptr
      0040B0 FA               [12]  588 	mov	r2,a
      0040B1 E4               [12]  589 	clr	a
      0040B2 12 46 AF         [24]  590 	lcall	_ak820_outline_0143
                                    591 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      0040B5 C3               [12]  592 	clr	c
      0040B6 EF               [12]  593 	mov	a,r7
      0040B7 94 A0            [12]  594 	subb	a,#0xa0
      0040B9 EE               [12]  595 	mov	a,r6
      0040BA 94 00            [12]  596 	subb	a,#0x00
      0040BC 40 06            [24]  597 	jc	00134$
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      0040BE 75 82 01         [24]  599 	mov	dpl, #0x01
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      0040C1 02 3E D0         [24]  601 	ljmp	_nvm_fail
                                    602 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      0040C4                        603 00134$:
      0040C4 7B 00            [12]  604 	mov	r3,#0x00
      0040C6                        605 00117$:
      0040C6 C0 05            [24]  606 	push	ar5
      0040C8 C0 04            [24]  607 	push	ar4
      0040CA EB               [12]  608 	mov	a,r3
      0040CB 24 73            [12]  609 	add	a, #_page_data
      0040CD F9               [12]  610 	mov	r1,a
      0040CE E4               [12]  611 	clr	a
      0040CF 34 05            [12]  612 	addc	a, #(_page_data >> 8)
      0040D1 FA               [12]  613 	mov	r2,a
      0040D2 8B 00            [24]  614 	mov	ar0,r3
      0040D4 7D 00            [12]  615 	mov	r5,#0x00
      0040D6 74 EF            [12]  616 	mov	a,#0xef
      0040D8 2D               [12]  617 	add	a, r5
      0040D9 FD               [12]  618 	mov	r5,a
      0040DA 88 82            [24]  619 	mov	dpl, r0
      0040DC 8D 83            [24]  620 	mov	dph, r5
      0040DE 12 3C 3C         [24]  621 	lcall	_ak820_flash_read
      0040E1 AD 82            [24]  622 	mov	r5, dpl
      0040E3 12 46 CB         [24]  623 	lcall	_ak820_outline_0182
      0040E6 ED               [12]  624 	mov	a,r5
      0040E7 F0               [24]  625 	movx	@dptr,a
      0040E8 0B               [12]  626 	inc	r3
      0040E9 BB 40 02         [24]  627 	cjne	r3,#0x40,00190$
      0040EC 80 06            [24]  628 	sjmp	00191$
      0040EE                        629 00190$:
      0040EE D0 04            [24]  630 	pop	ar4
      0040F0 D0 05            [24]  631 	pop	ar5
      0040F2 80 D2            [24]  632 	sjmp	00117$
      0040F4                        633 00191$:
      0040F4 D0 04            [24]  634 	pop	ar4
      0040F6 D0 05            [24]  635 	pop	ar5
                                    636 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      0040F8 C0 07            [24]  637 	push	ar7
      0040FA C0 06            [24]  638 	push	ar6
      0040FC C0 05            [24]  639 	push	ar5
      0040FE C0 04            [24]  640 	push	ar4
      004100 12 3F 7E         [24]  641 	lcall	_page_crc
      004103 AA 82            [24]  642 	mov	r2, dpl
      004105 AB 83            [24]  643 	mov	r3, dph
      004107 D0 04            [24]  644 	pop	ar4
      004109 D0 05            [24]  645 	pop	ar5
      00410B D0 06            [24]  646 	pop	ar6
      00410D D0 07            [24]  647 	pop	ar7
      00410F EA               [12]  648 	mov	a,r2
      004110 B5 05 06         [24]  649 	cjne	a,ar5,00192$
      004113 EB               [12]  650 	mov	a,r3
      004114 B5 04 02         [24]  651 	cjne	a,ar4,00192$
      004117 80 06            [24]  652 	sjmp	00113$
      004119                        653 00192$:
      004119 75 82 02         [24]  654 	mov	dpl, #0x02
      00411C 02 3E D0         [24]  655 	ljmp	_nvm_fail
      00411F                        656 00113$:
                                    657 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00411F EE               [12]  658 	mov	a,r6
      004120 54 03            [12]  659 	anl	a,#0x03
      004122 A2 E0            [12]  660 	mov	c,acc.0
      004124 CF               [12]  661 	xch	a,r7
      004125 13               [12]  662 	rrc	a
      004126 CF               [12]  663 	xch	a,r7
      004127 13               [12]  664 	rrc	a
      004128 A2 E0            [12]  665 	mov	c,acc.0
      00412A CF               [12]  666 	xch	a,r7
      00412B 13               [12]  667 	rrc	a
      00412C CF               [12]  668 	xch	a,r7
      00412D 13               [12]  669 	rrc	a
      00412E CF               [12]  670 	xch	a,r7
      00412F 24 C7            [12]  671 	add	a,#0xc7
      004131 FE               [12]  672 	mov	r6,a
      004132 12 46 BA         [24]  673 	lcall	_ak820_outline_0157
      004135 12 3F B1         [24]  674 	lcall	_write_page
      004138 E5 82            [12]  675 	mov	a, dpl
      00413A 70 06            [24]  676 	jnz	00110$
      00413C 75 82 03         [24]  677 	mov	dpl, #0x03
      00413F 02 3E D0         [24]  678 	ljmp	_nvm_fail
      004142                        679 00110$:
                                    680 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004142 90 EF 40         [24]  681 	mov	dptr,#0xef40
      004145 12 3D 49         [24]  682 	lcall	_ak820_flash_erase
      004148 E5 82            [12]  683 	mov	a, dpl
      00414A 70 06            [24]  684 	jnz	00119$
      00414C 75 82 04         [24]  685 	mov	dpl, #0x04
                                    686 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00414F 02 3E D0         [24]  687 	ljmp	_nvm_fail
      004152                        688 00119$:
      004152 22               [24]  689 	ret
                                    690 ;------------------------------------------------------------
                                    691 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    692 ;------------------------------------------------------------
                                    693 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    694 ;	-----------------------------------------
                                    695 ;	 function eeprom_driver_init
                                    696 ;	-----------------------------------------
      004153                        697 _eeprom_driver_init:
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    699 ;	assignBit
      004153 C2 0B            [12]  700 	clr	_storage_failed
                                    701 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004155 90 05 B5         [24]  702 	mov	dptr,#_first_failure_stage
      004158 E4               [12]  703 	clr	a
      004159 F0               [24]  704 	movx	@dptr,a
                                    705 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    706 ;	assignBit
      00415A C2 0A            [12]  707 	clr	_page_dirty
                                    708 ;	assignBit
      00415C C2 09            [12]  709 	clr	_page_valid
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00415E 90 05 B4         [24]  711 	mov	dptr,#_batch_depth
      004161 E4               [12]  712 	clr	a
      004162 F0               [24]  713 	movx	@dptr,a
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004163 12 40 61         [24]  715 	lcall	_recover_journal
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004166 02 2A B7         [24]  718 	ljmp	_ak820_macro_init
                                    719 ;------------------------------------------------------------
                                    720 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    721 ;------------------------------------------------------------
                                    722 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    723 ;	-----------------------------------------
                                    724 ;	 function ak820_nvm_ok
                                    725 ;	-----------------------------------------
      004169                        726 _ak820_nvm_ok:
      004169 A2 0B            [12]  727 	mov	c,_storage_failed
      00416B B3               [12]  728 	cpl	c
      00416C 92 0C            [24]  729 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00416E 12 38 B6         [24]  730 	lcall	_ak820_outline_0156
      004171 22               [24]  731 	ret
                                    732 ;------------------------------------------------------------
                                    733 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    734 ;------------------------------------------------------------
                                    735 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    736 ;	-----------------------------------------
                                    737 ;	 function ak820_nvm_schema_fault
                                    738 ;	-----------------------------------------
      004172                        739 _ak820_nvm_schema_fault:
      004172 75 82 10         [24]  740 	mov	dpl, #0x10
      004175 02 3E D0         [24]  741 	ljmp	_nvm_fail
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    744 ;------------------------------------------------------------
                                    745 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    746 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    747 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    748 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    749 ;------------------------------------------------------------
                                    750 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    751 ;	-----------------------------------------
                                    752 ;	 function ak820_nvm_flush
                                    753 ;	-----------------------------------------
      004178                        754 _ak820_nvm_flush:
                                    755 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004178 30 0A 03         [24]  756 	jnb	_page_dirty,00101$
      00417B 30 0B 01         [24]  757 	jnb	_storage_failed,00102$
      00417E                        758 00101$:
      00417E 22               [24]  759 	ret
      00417F                        760 00102$:
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00417F 12 3F 7E         [24]  762 	lcall	_page_crc
      004182 12 46 A4         [24]  763 	lcall	_ak820_outline_0125
                                    764 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004185 90 05 CB         [24]  765 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004188 74 A5            [12]  766 	mov	a,#0xa5
      00418A F0               [24]  767 	movx	@dptr,a
                                    768 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      00418B 90 05 B3         [24]  769 	mov	dptr,#_cached_page
      00418E E0               [24]  770 	movx	a,@dptr
      00418F 90 05 CC         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004192 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      004193 90 05 CD         [24]  774 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004196 E4               [12]  775 	clr	a
      004197 F0               [24]  776 	movx	@dptr,a
                                    777 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004198 8E 05            [24]  778 	mov	ar5,r6
      00419A 90 05 CE         [24]  779 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      00419D ED               [12]  780 	mov	a,r5
      00419E F0               [24]  781 	movx	@dptr,a
                                    782 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00419F 8F 06            [24]  783 	mov	ar6,r7
      0041A1 90 05 CF         [24]  784 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0041A4 EE               [12]  785 	mov	a,r6
      0041A5 F0               [24]  786 	movx	@dptr,a
                                    787 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0041A6 7F 01            [12]  788 	mov	r7,#0x01
      0041A8                        789 00128$:
      0041A8 8F 06            [24]  790 	mov	ar6,r7
      0041AA EE               [12]  791 	mov	a,r6
      0041AB 24 04            [12]  792 	add	a,#0x04
      0041AD FE               [12]  793 	mov	r6,a
      0041AE 33               [12]  794 	rlc	a
      0041AF 95 E0            [12]  795 	subb	a,acc
      0041B1 FD               [12]  796 	mov	r5,a
      0041B2 EE               [12]  797 	mov	a,r6
      0041B3 24 CB            [12]  798 	add	a, #_ak820_nvm_flush_header_10000_62
      0041B5 FE               [12]  799 	mov	r6,a
      0041B6 ED               [12]  800 	mov	a,r5
      0041B7 34 05            [12]  801 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0041B9 FD               [12]  802 	mov	r5,a
      0041BA 12 46 69         [24]  803 	lcall	_ak820_outline_0043
      0041BD FC               [12]  804 	mov	r4,a
      0041BE 63 04 FF         [24]  805 	xrl	ar4,#0xff
      0041C1 8E 82            [24]  806 	mov	dpl,r6
      0041C3 8D 83            [24]  807 	mov	dph,r5
      0041C5 EC               [12]  808 	mov	a,r4
      0041C6 F0               [24]  809 	movx	@dptr,a
      0041C7 0F               [12]  810 	inc	r7
      0041C8 BF 05 DD         [24]  811 	cjne	r7,#0x05,00128$
                                    812 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0041CB 90 05 D4         [24]  813 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041CE 74 05            [12]  814 	mov	a,#0x05
      0041D0 F0               [24]  815 	movx	@dptr,a
                                    816 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041D1 90 EF 40         [24]  817 	mov	dptr,#0xef40
      0041D4 12 3D 49         [24]  818 	lcall	_ak820_flash_erase
      0041D7 E5 82            [12]  819 	mov	a, dpl
      0041D9 70 03            [24]  820 	jnz	00269$
      0041DB 02 42 C2         [24]  821 	ljmp	00127$
      0041DE                        822 00269$:
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      0041DE 90 05 D4         [24]  824 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041E1 74 06            [12]  825 	mov	a,#0x06
      0041E3 F0               [24]  826 	movx	@dptr,a
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041E4 7F 00            [12]  828 	mov	r7,#0x00
      0041E6                        829 00130$:
                                    830 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0041E6 12 46 75         [24]  831 	lcall	_ak820_outline_0053
      0041E9 12 3C 3C         [24]  832 	lcall	_ak820_flash_read
      0041EC E5 82            [12]  833 	mov	a, dpl
      0041EE 60 03            [24]  834 	jz	00270$
      0041F0 02 42 C2         [24]  835 	ljmp	00127$
      0041F3                        836 00270$:
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041F3 0F               [12]  838 	inc	r7
      0041F4 BF 40 EF         [24]  839 	cjne	r7,#0x40,00130$
                                    840 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0041F7 90 05 D4         [24]  841 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041FA 74 07            [12]  842 	mov	a,#0x07
      0041FC F0               [24]  843 	movx	@dptr,a
                                    844 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0041FD 90 EF 00         [24]  845 	mov	dptr,#0xef00
      004200 12 3F B1         [24]  846 	lcall	_write_page
      004203 E5 82            [12]  847 	mov	a, dpl
      004205 70 03            [24]  848 	jnz	00273$
      004207 02 42 C2         [24]  849 	ljmp	00127$
      00420A                        850 00273$:
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      00420A 90 05 D4         [24]  852 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00420D 74 08            [12]  853 	mov	a,#0x08
      00420F F0               [24]  854 	movx	@dptr,a
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004210 7F 01            [12]  856 	mov	r7,#0x01
      004212                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004212 12 46 69         [24]  859 	lcall	_ak820_outline_0043
      004215 FE               [12]  860 	mov	r6,a
      004216 60 23            [24]  861 	jz	00133$
      004218 8F 05            [24]  862 	mov	ar5,r7
      00421A 7C 00            [12]  863 	mov	r4,#0x00
      00421C 74 40            [12]  864 	mov	a,#0x40
      00421E 2D               [12]  865 	add	a, r5
      00421F FD               [12]  866 	mov	r5,a
      004220 74 EF            [12]  867 	mov	a,#0xef
      004222 3C               [12]  868 	addc	a, r4
      004223 FC               [12]  869 	mov	r4,a
      004224 90 05 4C         [24]  870 	mov	dptr,#_ak820_flash_program_PARM_2
      004227 EE               [12]  871 	mov	a,r6
      004228 F0               [24]  872 	movx	@dptr,a
      004229 8D 82            [24]  873 	mov	dpl, r5
      00422B 8C 83            [24]  874 	mov	dph, r4
      00422D C0 07            [24]  875 	push	ar7
      00422F 12 3D A9         [24]  876 	lcall	_ak820_flash_program
      004232 E5 82            [12]  877 	mov	a, dpl
      004234 D0 07            [24]  878 	pop	ar7
      004236 70 03            [24]  879 	jnz	00275$
      004238 02 42 C2         [24]  880 	ljmp	00127$
      00423B                        881 00275$:
      00423B                        882 00133$:
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00423B 0F               [12]  884 	inc	r7
      00423C BF 09 D3         [24]  885 	cjne	r7,#0x09,00132$
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00423F 90 05 D4         [24]  887 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004242 74 09            [12]  888 	mov	a,#0x09
      004244 F0               [24]  889 	movx	@dptr,a
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004245 7F 01            [12]  891 	mov	r7,#0x01
      004247                        892 00134$:
                                    893 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004247 12 46 75         [24]  894 	lcall	_ak820_outline_0053
      00424A 12 3C 3C         [24]  895 	lcall	_ak820_flash_read
      00424D AE 82            [24]  896 	mov	r6, dpl
      00424F 12 46 69         [24]  897 	lcall	_ak820_outline_0043
      004252 FD               [12]  898 	mov	r5,a
      004253 EE               [12]  899 	mov	a,r6
      004254 B5 05 6B         [24]  900 	cjne	a,ar5,00127$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004257 0F               [12]  902 	inc	r7
      004258 BF 09 EC         [24]  903 	cjne	r7,#0x09,00134$
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      00425B 90 05 D4         [24]  905 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00425E 74 0A            [12]  906 	mov	a,#0x0a
      004260 F0               [24]  907 	movx	@dptr,a
                                    908 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004261 90 05 CB         [24]  909 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004264 E0               [24]  910 	movx	a,@dptr
      004265 90 05 4C         [24]  911 	mov	dptr,#_ak820_flash_program_PARM_2
      004268 F0               [24]  912 	movx	@dptr,a
      004269 90 EF 40         [24]  913 	mov	dptr,#0xef40
      00426C 12 3D A9         [24]  914 	lcall	_ak820_flash_program
      00426F E5 82            [12]  915 	mov	a, dpl
      004271 60 4F            [24]  916 	jz	00127$
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004273 90 05 D4         [24]  918 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004276 74 0B            [12]  919 	mov	a,#0x0b
      004278 F0               [24]  920 	movx	@dptr,a
                                    921 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004279 90 EF 40         [24]  922 	mov	dptr,#0xef40
      00427C 12 3C 3C         [24]  923 	lcall	_ak820_flash_read
      00427F AF 82            [24]  924 	mov	r7, dpl
      004281 90 05 CB         [24]  925 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004284 E0               [24]  926 	movx	a,@dptr
      004285 FE               [12]  927 	mov	r6,a
      004286 EF               [12]  928 	mov	a,r7
      004287 B5 06 38         [24]  929 	cjne	a,ar6,00127$
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      00428A 90 05 D4         [24]  931 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00428D 74 0C            [12]  932 	mov	a,#0x0c
      00428F F0               [24]  933 	movx	@dptr,a
                                    934 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      004290 90 05 B3         [24]  935 	mov	dptr,#_cached_page
      004293 E0               [24]  936 	movx	a,@dptr
      004294 FE               [12]  937 	mov	r6,a
      004295 E4               [12]  938 	clr	a
      004296 C3               [12]  939 	clr	c
      004297 CE               [12]  940 	xch	a,r6
      004298 13               [12]  941 	rrc	a
      004299 CE               [12]  942 	xch	a,r6
      00429A 13               [12]  943 	rrc	a
      00429B A2 E0            [12]  944 	mov	c,acc.0
      00429D CE               [12]  945 	xch	a,r6
      00429E 13               [12]  946 	rrc	a
      00429F CE               [12]  947 	xch	a,r6
      0042A0 13               [12]  948 	rrc	a
      0042A1 CE               [12]  949 	xch	a,r6
      0042A2 24 C7            [12]  950 	add	a,#0xc7
      0042A4 FF               [12]  951 	mov	r7,a
      0042A5 12 38 8C         [24]  952 	lcall	_ak820_outline_0118
      0042A8 12 3F B1         [24]  953 	lcall	_write_page
      0042AB E5 82            [12]  954 	mov	a, dpl
      0042AD 60 13            [24]  955 	jz	00127$
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0042AF 90 05 D4         [24]  957 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0042B2 74 0D            [12]  958 	mov	a,#0x0d
      0042B4 F0               [24]  959 	movx	@dptr,a
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0042B5 90 EF 40         [24]  961 	mov	dptr,#0xef40
      0042B8 12 3D 49         [24]  962 	lcall	_ak820_flash_erase
      0042BB E5 82            [12]  963 	mov	a, dpl
      0042BD 60 03            [24]  964 	jz	00127$
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    966 ;	assignBit
      0042BF C2 0A            [12]  967 	clr	_page_dirty
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0042C1 22               [24]  970 	ret
      0042C2                        971 00127$:
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0042C2 90 05 D4         [24]  973 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0042C5 E0               [24]  974 	movx	a,@dptr
      0042C6 F5 82            [12]  975 	mov	dpl,a
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0042C8 02 3E D0         [24]  977 	ljmp	_nvm_fail
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    980 ;------------------------------------------------------------
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function ak820_nvm_begin
                                    984 ;	-----------------------------------------
      0042CB                        985 _ak820_nvm_begin:
                                    986 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0042CB 90 05 B4         [24]  987 	mov	dptr,#_batch_depth
      0042CE E0               [24]  988 	movx	a,@dptr
      0042CF FF               [12]  989 	mov	r7,a
      0042D0 BF FF 06         [24]  990 	cjne	r7,#0xff,00102$
      0042D3 75 82 0F         [24]  991 	mov	dpl, #0x0f
      0042D6 02 3E D0         [24]  992 	ljmp	_nvm_fail
      0042D9                        993 00102$:
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0042D9 90 05 B4         [24]  995 	mov	dptr,#_batch_depth
      0042DC EF               [12]  996 	mov	a,r7
      0042DD 04               [12]  997 	inc	a
      0042DE F0               [24]  998 	movx	@dptr,a
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      0042DF 22               [24] 1000 	ret
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1003 ;------------------------------------------------------------
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1005 ;	-----------------------------------------
                                   1006 ;	 function ak820_nvm_end
                                   1007 ;	-----------------------------------------
      0042E0                       1008 _ak820_nvm_end:
                                   1009 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      0042E0 90 05 B4         [24] 1010 	mov	dptr,#_batch_depth
      0042E3 E0               [24] 1011 	movx	a,@dptr
      0042E4 FF               [12] 1012 	mov	r7,a
      0042E5 E0               [24] 1013 	movx	a,@dptr
      0042E6 60 06            [24] 1014 	jz	00102$
      0042E8 EF               [12] 1015 	mov	a,r7
      0042E9 14               [12] 1016 	dec	a
      0042EA 90 05 B4         [24] 1017 	mov	dptr,#_batch_depth
      0042ED F0               [24] 1018 	movx	@dptr,a
      0042EE                       1019 00102$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0042EE 90 05 B4         [24] 1021 	mov	dptr,#_batch_depth
      0042F1 E0               [24] 1022 	movx	a,@dptr
      0042F2 70 03            [24] 1023 	jnz	00105$
                                   1024 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0042F4 02 41 78         [24] 1025 	ljmp	_ak820_nvm_flush
      0042F7                       1026 00105$:
      0042F7 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'load_page'
                                   1030 ;------------------------------------------------------------
                                   1031 ;page          Allocated with name '_load_page_page_10000_87'
                                   1032 ;i             Allocated with name '_load_page_i_10000_88'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function load_page
                                   1037 ;	-----------------------------------------
      0042F8                       1038 _load_page:
      0042F8 E5 82            [12] 1039 	mov	a,dpl
      0042FA 90 05 D5         [24] 1040 	mov	dptr,#_load_page_page_10000_87
      0042FD F0               [24] 1041 	movx	@dptr,a
                                   1042 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0042FE 30 09 17         [24] 1043 	jnb	_page_valid,00102$
      004301 90 05 B3         [24] 1044 	mov	dptr,#_cached_page
      004304 E0               [24] 1045 	movx	a,@dptr
      004305 FF               [12] 1046 	mov	r7,a
      004306 90 05 D5         [24] 1047 	mov	dptr,#_load_page_page_10000_87
      004309 E0               [24] 1048 	movx	a,@dptr
      00430A FE               [12] 1049 	mov	r6,a
      00430B EF               [12] 1050 	mov	a,r7
      00430C B5 06 09         [24] 1051 	cjne	a,ar6,00102$
      00430F A2 0B            [12] 1052 	mov	c,_storage_failed
      004311 B3               [12] 1053 	cpl	c
      004312 92 0D            [24] 1054 	mov  _load_page_sloc0_1_0,c
      004314 12 38 B6         [24] 1055 	lcall	_ak820_outline_0156
      004317 22               [24] 1056 	ret
      004318                       1057 00102$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004318 12 41 78         [24] 1059 	lcall	_ak820_nvm_flush
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      00431B 30 0B 04         [24] 1061 	jnb	_storage_failed,00119$
      00431E 75 82 00         [24] 1062 	mov	dpl, #0x00
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004321 22               [24] 1064 	ret
      004322                       1065 00119$:
      004322 7F 00            [12] 1066 	mov	r7,#0x00
      004324                       1067 00107$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004324 EF               [12] 1069 	mov	a,r7
      004325 24 73            [12] 1070 	add	a, #_page_data
      004327 FD               [12] 1071 	mov	r5,a
      004328 E4               [12] 1072 	clr	a
      004329 34 05            [12] 1073 	addc	a, #(_page_data >> 8)
      00432B FE               [12] 1074 	mov	r6,a
      00432C 90 05 D5         [24] 1075 	mov	dptr,#_load_page_page_10000_87
      00432F E0               [24] 1076 	movx	a,@dptr
      004330 FC               [12] 1077 	mov	r4,a
      004331 FA               [12] 1078 	mov	r2,a
      004332 E4               [12] 1079 	clr	a
      004333 C3               [12] 1080 	clr	c
      004334 CA               [12] 1081 	xch	a,r2
      004335 13               [12] 1082 	rrc	a
      004336 CA               [12] 1083 	xch	a,r2
      004337 13               [12] 1084 	rrc	a
      004338 A2 E0            [12] 1085 	mov	c,acc.0
      00433A CA               [12] 1086 	xch	a,r2
      00433B 13               [12] 1087 	rrc	a
      00433C CA               [12] 1088 	xch	a,r2
      00433D 13               [12] 1089 	rrc	a
      00433E CA               [12] 1090 	xch	a,r2
      00433F 24 C7            [12] 1091 	add	a,#0xc7
      004341 FB               [12] 1092 	mov	r3,a
      004342 8F 01            [24] 1093 	mov	ar1,r7
      004344 89 00            [24] 1094 	mov	ar0,r1
      004346 79 00            [12] 1095 	mov	r1,#0x00
      004348 E8               [12] 1096 	mov	a,r0
      004349 2A               [12] 1097 	add	a, r2
      00434A FA               [12] 1098 	mov	r2,a
      00434B E9               [12] 1099 	mov	a,r1
      00434C 3B               [12] 1100 	addc	a, r3
      00434D FB               [12] 1101 	mov	r3,a
      00434E 12 38 A6         [24] 1102 	lcall	_ak820_outline_0136
      004351 12 3C 3C         [24] 1103 	lcall	_ak820_flash_read
      004354 AB 82            [24] 1104 	mov	r3, dpl
      004356 12 38 9C         [24] 1105 	lcall	_ak820_outline_0134
      004359 EB               [12] 1106 	mov	a,r3
      00435A F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00435B 0F               [12] 1109 	inc	r7
      00435C BF 40 C5         [24] 1110 	cjne	r7,#0x40,00107$
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00435F 90 05 B3         [24] 1112 	mov	dptr,#_cached_page
      004362 EC               [12] 1113 	mov	a,r4
      004363 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1116 ;	assignBit
      004364 D2 09            [12] 1117 	setb	_page_valid
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004366 75 82 01         [24] 1119 	mov	dpl, #0x01
                                   1120 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004369 22               [24] 1121 	ret
                                   1122 ;------------------------------------------------------------
                                   1123 ;Allocation info for local variables in function 'read_offset'
                                   1124 ;------------------------------------------------------------
                                   1125 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1126 ;------------------------------------------------------------
                                   1127 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1128 ;	-----------------------------------------
                                   1129 ;	 function read_offset
                                   1130 ;	-----------------------------------------
      00436A                       1131 _read_offset:
      00436A 12 38 82         [24] 1132 	lcall	_ak820_outline_0108
      00436D 90 05 D6         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004370 12 38 87         [24] 1134 	lcall	_ak820_outline_0109
                                   1135 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004373 90 05 D6         [24] 1136 	mov	dptr,#_read_offset_offset_10000_93
      004376 12 38 41         [24] 1137 	lcall	_ak820_outline_0052
      004379 C3               [12] 1138 	clr	c
      00437A 94 28            [12] 1139 	subb	a,#0x28
      00437C 40 04            [24] 1140 	jc	00102$
      00437E 75 82 00         [24] 1141 	mov	dpl, #0x00
      004381 22               [24] 1142 	ret
      004382                       1143 00102$:
                                   1144 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004382 30 09 34         [24] 1145 	jnb	_page_valid,00104$
      004385 8E 04            [24] 1146 	mov	ar4,r6
      004387 EF               [12] 1147 	mov	a,r7
      004388 A2 E7            [12] 1148 	mov	c,acc.7
      00438A CC               [12] 1149 	xch	a,r4
      00438B 33               [12] 1150 	rlc	a
      00438C CC               [12] 1151 	xch	a,r4
      00438D 33               [12] 1152 	rlc	a
      00438E A2 E7            [12] 1153 	mov	c,acc.7
      004390 CC               [12] 1154 	xch	a,r4
      004391 33               [12] 1155 	rlc	a
      004392 CC               [12] 1156 	xch	a,r4
      004393 33               [12] 1157 	rlc	a
      004394 CC               [12] 1158 	xch	a,r4
      004395 54 03            [12] 1159 	anl	a,#0x03
      004397 FD               [12] 1160 	mov	r5,a
      004398 90 05 B3         [24] 1161 	mov	dptr,#_cached_page
      00439B E0               [24] 1162 	movx	a,@dptr
      00439C FA               [12] 1163 	mov	r2,a
      00439D 7B 00            [12] 1164 	mov	r3,#0x00
      00439F EC               [12] 1165 	mov	a,r4
      0043A0 B5 02 16         [24] 1166 	cjne	a,ar2,00104$
      0043A3 ED               [12] 1167 	mov	a,r5
      0043A4 B5 03 12         [24] 1168 	cjne	a,ar3,00104$
                                   1169 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0043A7 74 3F            [12] 1170 	mov	a,#0x3f
      0043A9 5E               [12] 1171 	anl	a,r6
      0043AA 7D 00            [12] 1172 	mov	r5,#0x00
      0043AC 24 73            [12] 1173 	add	a, #_page_data
      0043AE F5 82            [12] 1174 	mov	dpl,a
      0043B0 ED               [12] 1175 	mov	a,r5
      0043B1 34 05            [12] 1176 	addc	a, #(_page_data >> 8)
      0043B3 F5 83            [12] 1177 	mov	dph,a
      0043B5 E0               [24] 1178 	movx	a,@dptr
      0043B6 F5 82            [12] 1179 	mov	dpl,a
      0043B8 22               [24] 1180 	ret
      0043B9                       1181 00104$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0043B9 74 C7            [12] 1183 	mov	a,#0xc7
      0043BB 2F               [12] 1184 	add	a, r7
      0043BC FF               [12] 1185 	mov	r7,a
      0043BD 12 38 8C         [24] 1186 	lcall	_ak820_outline_0118
                                   1187 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0043C0 02 3C 3C         [24] 1188 	ljmp	_ak820_flash_read
                                   1189 ;------------------------------------------------------------
                                   1190 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1191 ;------------------------------------------------------------
                                   1192 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function eeprom_read_byte
                                   1197 ;	-----------------------------------------
      0043C3                       1198 _eeprom_read_byte:
      0043C3 C0 07            [24] 1199 	push	ar7
      0043C5 C0 06            [24] 1200 	push	ar6
      0043C7 12 46 62         [24] 1201 	lcall	_ak820_outline_0037
      0043CA 90 05 D8         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0043CD 12 38 29         [24] 1203 	lcall	_ak820_outline_0017
                                   1204 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0043D0 90 05 D8         [24] 1205 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0043D3 12 37 F4         [24] 1206 	lcall	_ak820_outline_0005
      0043D6 C0 06            [24] 1207 	push	ar6
      0043D8 C0 05            [24] 1208 	push	ar5
      0043DA C0 04            [24] 1209 	push	ar4
      0043DC C0 03            [24] 1210 	push	ar3
      0043DE C0 02            [24] 1211 	push	ar2
      0043E0 C0 01            [24] 1212 	push	ar1
      0043E2 C0 00            [24] 1213 	push	ar0
      0043E4 12 43 6A         [24] 1214 	lcall	_read_offset
      0043E7 AF 82            [24] 1215 	mov	r7, dpl
      0043E9 D0 00            [24] 1216 	pop	ar0
      0043EB D0 01            [24] 1217 	pop	ar1
      0043ED D0 02            [24] 1218 	pop	ar2
      0043EF D0 03            [24] 1219 	pop	ar3
      0043F1 D0 04            [24] 1220 	pop	ar4
      0043F3 D0 05            [24] 1221 	pop	ar5
      0043F5 D0 06            [24] 1222 	pop	ar6
      0043F7 8F 82            [24] 1223 	mov	dpl, r7
                                   1224 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0043F9 D0 06            [24] 1225 	pop	ar6
      0043FB D0 07            [24] 1226 	pop	ar7
      0043FD 22               [24] 1227 	ret
                                   1228 ;------------------------------------------------------------
                                   1229 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1230 ;------------------------------------------------------------
                                   1231 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1232 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1233 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1234 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1235 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1236 ;------------------------------------------------------------
                                   1237 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1238 ;	-----------------------------------------
                                   1239 ;	 function ak820_eeprom_read_block_xdata
                                   1240 ;	-----------------------------------------
      0043FE                       1241 _ak820_eeprom_read_block_xdata:
      0043FE 12 38 82         [24] 1242 	lcall	_ak820_outline_0108
      004401 90 05 E0         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004404 12 38 87         [24] 1244 	lcall	_ak820_outline_0109
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004407 90 05 DB         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00440A 12 38 41         [24] 1247 	lcall	_ak820_outline_0052
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00440D 90 05 E0         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004410 12 38 58         [24] 1250 	lcall	_ak820_outline_0059
      004413 90 05 E2         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004416 12 38 5E         [24] 1252 	lcall	_ak820_outline_0072
                                   1253 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004419 90 05 DE         [24] 1254 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00441C 12 38 58         [24] 1255 	lcall	_ak820_outline_0059
      00441F                       1256 00103$:
      00441F 8C 02            [24] 1257 	mov	ar2,r4
      004421 8D 03            [24] 1258 	mov	ar3,r5
      004423 1C               [12] 1259 	dec	r4
      004424 BC FF 01         [24] 1260 	cjne	r4,#0xff,00130$
      004427 1D               [12] 1261 	dec	r5
      004428                       1262 00130$:
      004428 EA               [12] 1263 	mov	a,r2
      004429 4B               [12] 1264 	orl	a,r3
      00442A 60 5D            [24] 1265 	jz	00106$
                                   1266 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00442C 8E 02            [24] 1267 	mov	ar2,r6
      00442E 8F 03            [24] 1268 	mov	ar3,r7
      004430 74 D8            [12] 1269 	mov	a,#0x100 - 0x28
      004432 2B               [12] 1270 	add	a,r3
      004433 50 17            [24] 1271 	jnc	00102$
      004435 90 05 E2         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004438 12 46 92         [24] 1273 	lcall	_ak820_outline_0104
      00443B 12 38 A6         [24] 1274 	lcall	_ak820_outline_0136
      00443E E4               [12] 1275 	clr	a
      00443F F0               [24] 1276 	movx	@dptr,a
      004440 90 05 E2         [24] 1277 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004443 04               [12] 1278 	inc	a
      004444 2A               [12] 1279 	add	a, r2
      004445 F0               [24] 1280 	movx	@dptr,a
      004446 E4               [12] 1281 	clr	a
      004447 3B               [12] 1282 	addc	a, r3
      004448 A3               [24] 1283 	inc	dptr
      004449 F0               [24] 1284 	movx	@dptr,a
      00444A 80 D3            [24] 1285 	sjmp	00103$
      00444C                       1286 00102$:
                                   1287 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00444C 90 05 E2         [24] 1288 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00444F 12 46 92         [24] 1289 	lcall	_ak820_outline_0104
      004452 12 38 8C         [24] 1290 	lcall	_ak820_outline_0118
      004455 C0 07            [24] 1291 	push	ar7
      004457 C0 06            [24] 1292 	push	ar6
      004459 C0 05            [24] 1293 	push	ar5
      00445B C0 04            [24] 1294 	push	ar4
      00445D C0 03            [24] 1295 	push	ar3
      00445F C0 02            [24] 1296 	push	ar2
      004461 12 43 6A         [24] 1297 	lcall	_read_offset
      004464 A9 82            [24] 1298 	mov	r1, dpl
      004466 D0 02            [24] 1299 	pop	ar2
      004468 D0 03            [24] 1300 	pop	ar3
      00446A D0 04            [24] 1301 	pop	ar4
      00446C D0 05            [24] 1302 	pop	ar5
      00446E D0 06            [24] 1303 	pop	ar6
      004470 D0 07            [24] 1304 	pop	ar7
      004472 12 38 A6         [24] 1305 	lcall	_ak820_outline_0136
      004475 E9               [12] 1306 	mov	a,r1
      004476 F0               [24] 1307 	movx	@dptr,a
      004477 90 05 E2         [24] 1308 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00447A 74 01            [12] 1309 	mov	a,#0x01
      00447C 2A               [12] 1310 	add	a, r2
      00447D F0               [24] 1311 	movx	@dptr,a
      00447E E4               [12] 1312 	clr	a
      00447F 3B               [12] 1313 	addc	a, r3
      004480 A3               [24] 1314 	inc	dptr
      004481 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004482 0E               [12] 1317 	inc	r6
      004483 BE 00 99         [24] 1318 	cjne	r6,#0x00,00103$
      004486 0F               [12] 1319 	inc	r7
      004487 80 96            [24] 1320 	sjmp	00103$
      004489                       1321 00106$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004489 22               [24] 1323 	ret
                                   1324 ;------------------------------------------------------------
                                   1325 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1326 ;------------------------------------------------------------
                                   1327 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1328 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1329 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1330 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1331 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1332 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1333 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1334 ;------------------------------------------------------------
                                   1335 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1336 ;	-----------------------------------------
                                   1337 ;	 function ak820_eeprom_write_block_xdata
                                   1338 ;	-----------------------------------------
      00448A                       1339 _ak820_eeprom_write_block_xdata:
      00448A 12 38 82         [24] 1340 	lcall	_ak820_outline_0108
      00448D 90 05 E9         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004490 12 38 87         [24] 1342 	lcall	_ak820_outline_0109
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004493 90 05 E4         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004496 12 38 41         [24] 1345 	lcall	_ak820_outline_0052
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004499 90 05 E9         [24] 1347 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00449C 12 38 58         [24] 1348 	lcall	_ak820_outline_0059
                                   1349 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00449F 8E 02            [24] 1350 	mov	ar2,r6
      0044A1 8F 03            [24] 1351 	mov	ar3,r7
      0044A3 C3               [12] 1352 	clr	c
      0044A4 E4               [12] 1353 	clr	a
      0044A5 9A               [12] 1354 	subb	a,r2
      0044A6 74 28            [12] 1355 	mov	a,#0x28
      0044A8 9B               [12] 1356 	subb	a,r3
      0044A9 40 15            [24] 1357 	jc	00101$
                                   1358 ;	free result
      0044AB E4               [12] 1359 	clr	a
      0044AC C3               [12] 1360 	clr	c
      0044AD 9E               [12] 1361 	subb	a,r6
      0044AE FA               [12] 1362 	mov	r2,a
      0044AF 74 28            [12] 1363 	mov	a,#0x28
      0044B1 9F               [12] 1364 	subb	a,r7
      0044B2 FB               [12] 1365 	mov	r3,a
      0044B3 90 05 E7         [24] 1366 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044B6 12 38 7C         [24] 1367 	lcall	_ak820_outline_0103
      0044B9 C3               [12] 1368 	clr	c
      0044BA EA               [12] 1369 	mov	a,r2
      0044BB 98               [12] 1370 	subb	a,r0
      0044BC EB               [12] 1371 	mov	a,r3
      0044BD 99               [12] 1372 	subb	a,r1
      0044BE 50 06            [24] 1373 	jnc	00125$
                                   1374 ;	free result
      0044C0                       1375 00101$:
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0044C0 75 82 0E         [24] 1377 	mov	dpl, #0x0e
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0044C3 02 3E D0         [24] 1379 	ljmp	_nvm_fail
                                   1380 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0044C6                       1381 00125$:
      0044C6 90 05 E7         [24] 1382 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044C9 12 46 92         [24] 1383 	lcall	_ak820_outline_0104
      0044CC                       1384 00108$:
      0044CC 8A 00            [24] 1385 	mov	ar0,r2
      0044CE 8B 01            [24] 1386 	mov	ar1,r3
      0044D0 1A               [12] 1387 	dec	r2
      0044D1 BA FF 01         [24] 1388 	cjne	r2,#0xff,00159$
      0044D4 1B               [12] 1389 	dec	r3
      0044D5                       1390 00159$:
      0044D5 E8               [12] 1391 	mov	a,r0
      0044D6 49               [12] 1392 	orl	a,r1
      0044D7 70 03            [24] 1393 	jnz	00160$
      0044D9 02 45 63         [24] 1394 	ljmp	00110$
      0044DC                       1395 00160$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0044DC C0 02            [24] 1397 	push	ar2
      0044DE C0 03            [24] 1398 	push	ar3
      0044E0 12 46 8C         [24] 1399 	lcall	_ak820_outline_0096
      0044E3 F9               [12] 1400 	mov	r1,a
      0044E4 A3               [24] 1401 	inc	dptr
      0044E5 12 46 B5         [24] 1402 	lcall	_ak820_outline_0149
                                   1403 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0044E8 8E 0C            [24] 1404 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0044EA 8F 0D            [24] 1405 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0044EC A8 0C            [24] 1406 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0044EE E5 0D            [12] 1407 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0044F0 A2 E7            [12] 1408 	mov	c,acc.7
      0044F2 C8               [12] 1409 	xch	a,r0
      0044F3 33               [12] 1410 	rlc	a
      0044F4 C8               [12] 1411 	xch	a,r0
      0044F5 33               [12] 1412 	rlc	a
      0044F6 A2 E7            [12] 1413 	mov	c,acc.7
      0044F8 C8               [12] 1414 	xch	a,r0
      0044F9 33               [12] 1415 	rlc	a
      0044FA C8               [12] 1416 	xch	a,r0
      0044FB 33               [12] 1417 	rlc	a
      0044FC C8               [12] 1418 	xch	a,r0
      0044FD 54 03            [12] 1419 	anl	a,#0x03
      0044FF FB               [12] 1420 	mov	r3,a
      004500 88 82            [24] 1421 	mov	dpl, r0
      004502 C0 07            [24] 1422 	push	ar7
      004504 C0 06            [24] 1423 	push	ar6
      004506 C0 05            [24] 1424 	push	ar5
      004508 C0 04            [24] 1425 	push	ar4
      00450A C0 03            [24] 1426 	push	ar3
      00450C C0 02            [24] 1427 	push	ar2
      00450E C0 01            [24] 1428 	push	ar1
      004510 12 42 F8         [24] 1429 	lcall	_load_page
      004513 E5 82            [12] 1430 	mov	a, dpl
      004515 D0 01            [24] 1431 	pop	ar1
      004517 D0 02            [24] 1432 	pop	ar2
      004519 D0 03            [24] 1433 	pop	ar3
      00451B D0 04            [24] 1434 	pop	ar4
      00451D D0 05            [24] 1435 	pop	ar5
      00451F D0 06            [24] 1436 	pop	ar6
      004521 D0 07            [24] 1437 	pop	ar7
      004523 D0 03            [24] 1438 	pop	ar3
      004525 D0 02            [24] 1439 	pop	ar2
      004527 70 01            [24] 1440 	jnz	00105$
      004529 22               [24] 1441 	ret
      00452A                       1442 00105$:
                                   1443 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00452A C0 06            [24] 1444 	push	ar6
      00452C C0 07            [24] 1445 	push	ar7
      00452E 74 3F            [12] 1446 	mov	a,#0x3f
      004530 55 0C            [12] 1447 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004532 7F 00            [12] 1448 	mov	r7,#0x00
      004534 24 73            [12] 1449 	add	a, #_page_data
      004536 F5 0C            [12] 1450 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004538 EF               [12] 1451 	mov	a,r7
      004539 34 05            [12] 1452 	addc	a, #(_page_data >> 8)
      00453B F5 0D            [12] 1453 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00453D 85 0C 82         [24] 1454 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004540 85 0D 83         [24] 1455 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004543 E0               [24] 1456 	movx	a,@dptr
      004544 B5 01 06         [24] 1457 	cjne	a,ar1,00162$
      004547 D0 07            [24] 1458 	pop	ar7
      004549 D0 06            [24] 1459 	pop	ar6
      00454B 80 0E            [24] 1460 	sjmp	00107$
      00454D                       1461 00162$:
      00454D D0 07            [24] 1462 	pop	ar7
      00454F D0 06            [24] 1463 	pop	ar6
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004551 85 0C 82         [24] 1465 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004554 85 0D 83         [24] 1466 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004557 E9               [12] 1467 	mov	a,r1
      004558 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1470 ;	assignBit
      004559 D2 0A            [12] 1471 	setb	_page_dirty
      00455B                       1472 00107$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00455B 0E               [12] 1474 	inc	r6
      00455C BE 00 01         [24] 1475 	cjne	r6,#0x00,00163$
      00455F 0F               [12] 1476 	inc	r7
      004560                       1477 00163$:
      004560 02 44 CC         [24] 1478 	ljmp	00108$
      004563                       1479 00110$:
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004563 90 05 B4         [24] 1481 	mov	dptr,#_batch_depth
      004566 E0               [24] 1482 	movx	a,@dptr
      004567 70 03            [24] 1483 	jnz	00113$
                                   1484 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004569 02 41 78         [24] 1485 	ljmp	_ak820_nvm_flush
      00456C                       1486 00113$:
      00456C 22               [24] 1487 	ret
                                   1488 ;------------------------------------------------------------
                                   1489 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1490 ;------------------------------------------------------------
                                   1491 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1492 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1493 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1494 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1495 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1496 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1497 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1498 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1499 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function ak820_eeprom_update_block_xdata
                                   1504 ;	-----------------------------------------
      00456D                       1505 _ak820_eeprom_update_block_xdata:
      00456D 12 38 82         [24] 1506 	lcall	_ak820_outline_0108
      004570 90 05 F0         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004573 12 38 87         [24] 1508 	lcall	_ak820_outline_0109
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004576 90 05 F0         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004579 12 38 41         [24] 1511 	lcall	_ak820_outline_0052
                                   1512 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00457C 90 05 EB         [24] 1513 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00457F E0               [24] 1514 	movx	a,@dptr
      004580 F5 12            [12] 1515 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004582 A3               [24] 1516 	inc	dptr
      004583 E0               [24] 1517 	movx	a,@dptr
      004584 F5 13            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004586 A3               [24] 1519 	inc	dptr
      004587 E0               [24] 1520 	movx	a,@dptr
      004588 F5 14            [12] 1521 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      00458A A9 12            [24] 1522 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00458C AA 13            [24] 1523 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1524 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00458E E4               [12] 1525 	clr	a
      00458F F5 0E            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004591 F5 0F            [12] 1527 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004593                       1528 00105$:
      004593 90 05 EE         [24] 1529 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004596 E0               [24] 1530 	movx	a,@dptr
      004597 F5 10            [12] 1531 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004599 A3               [24] 1532 	inc	dptr
      00459A E0               [24] 1533 	movx	a,@dptr
      00459B F5 11            [12] 1534 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00459D C3               [12] 1535 	clr	c
      00459E E5 0E            [12] 1536 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045A0 95 10            [12] 1537 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0045A2 E5 0F            [12] 1538 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045A4 95 11            [12] 1539 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0045A6 50 68            [24] 1540 	jnc	00107$
                                   1541 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0045A8 89 00            [24] 1542 	mov	ar0,r1
      0045AA 8A 05            [24] 1543 	mov	ar5,r2
      0045AC E5 0E            [12] 1544 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045AE 28               [12] 1545 	add	a, r0
      0045AF F8               [12] 1546 	mov	r0,a
      0045B0 E5 0F            [12] 1547 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045B2 3D               [12] 1548 	addc	a, r5
      0045B3 FD               [12] 1549 	mov	r5,a
      0045B4 88 82            [24] 1550 	mov	dpl, r0
      0045B6 8D 83            [24] 1551 	mov	dph, r5
      0045B8 C0 07            [24] 1552 	push	ar7
      0045BA C0 06            [24] 1553 	push	ar6
      0045BC C0 02            [24] 1554 	push	ar2
      0045BE C0 01            [24] 1555 	push	ar1
      0045C0 12 43 6A         [24] 1556 	lcall	_read_offset
      0045C3 AD 82            [24] 1557 	mov	r5, dpl
      0045C5 D0 01            [24] 1558 	pop	ar1
      0045C7 D0 02            [24] 1559 	pop	ar2
      0045C9 D0 06            [24] 1560 	pop	ar6
      0045CB D0 07            [24] 1561 	pop	ar7
      0045CD E5 0E            [12] 1562 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045CF 2E               [12] 1563 	add	a, r6
      0045D0 F5 82            [12] 1564 	mov	dpl,a
      0045D2 E5 0F            [12] 1565 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045D4 3F               [12] 1566 	addc	a, r7
      0045D5 F5 83            [12] 1567 	mov	dph,a
      0045D7 E0               [24] 1568 	movx	a,@dptr
      0045D8 FC               [12] 1569 	mov	r4,a
      0045D9 ED               [12] 1570 	mov	a,r5
      0045DA B5 04 02         [24] 1571 	cjne	a,ar4,00131$
      0045DD 80 27            [24] 1572 	sjmp	00106$
      0045DF                       1573 00131$:
                                   1574 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0045DF 90 05 F0         [24] 1575 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0045E2 E0               [24] 1576 	movx	a,@dptr
      0045E3 F8               [12] 1577 	mov	r0,a
      0045E4 A3               [24] 1578 	inc	dptr
      0045E5 E0               [24] 1579 	movx	a,@dptr
      0045E6 FD               [12] 1580 	mov	r5,a
      0045E7 90 05 E4         [24] 1581 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0045EA E5 12            [12] 1582 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0045EC F0               [24] 1583 	movx	@dptr,a
      0045ED E5 13            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0045EF A3               [24] 1585 	inc	dptr
      0045F0 F0               [24] 1586 	movx	@dptr,a
      0045F1 E5 14            [12] 1587 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0045F3 A3               [24] 1588 	inc	dptr
      0045F4 F0               [24] 1589 	movx	@dptr,a
      0045F5 90 05 E7         [24] 1590 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0045F8 E5 10            [12] 1591 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0045FA F0               [24] 1592 	movx	@dptr,a
      0045FB E5 11            [12] 1593 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0045FD A3               [24] 1594 	inc	dptr
      0045FE F0               [24] 1595 	movx	@dptr,a
      0045FF 88 82            [24] 1596 	mov	dpl, r0
      004601 8D 83            [24] 1597 	mov	dph, r5
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004603 02 44 8A         [24] 1599 	ljmp	_ak820_eeprom_write_block_xdata
      004606                       1600 00106$:
                                   1601 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004606 05 0E            [12] 1602 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004608 E4               [12] 1603 	clr	a
      004609 B5 0E 87         [24] 1604 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00460C 05 0F            [12] 1605 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00460E 80 83            [24] 1606 	sjmp	00105$
      004610                       1607 00107$:
                                   1608 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004610 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1612 ;------------------------------------------------------------
                                   1613 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1614 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1615 ;------------------------------------------------------------
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1617 ;	-----------------------------------------
                                   1618 ;	 function eeprom_driver_erase
                                   1619 ;	-----------------------------------------
      004611                       1620 _eeprom_driver_erase:
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004611 12 41 78         [24] 1622 	lcall	_ak820_nvm_flush
                                   1623 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004614 7F 00            [12] 1624 	mov	r7,#0x00
      004616                       1625 00111$:
      004616 BF A0 01         [24] 1626 	cjne	r7,#0xa0,00165$
      004619 22               [24] 1627 	ret
      00461A                       1628 00165$:
      00461A 20 0B 32         [24] 1629 	jb	_storage_failed,00113$
                                   1630 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00461D 8F 82            [24] 1631 	mov	dpl, r7
      00461F C0 07            [24] 1632 	push	ar7
      004621 12 42 F8         [24] 1633 	lcall	_load_page
      004624 E5 82            [12] 1634 	mov	a, dpl
      004626 D0 07            [24] 1635 	pop	ar7
      004628 70 01            [24] 1636 	jnz	00126$
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00462A 22               [24] 1638 	ret
      00462B                       1639 00126$:
      00462B 7E 00            [12] 1640 	mov	r6,#0x00
      00462D                       1641 00107$:
                                   1642 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00462D EE               [12] 1643 	mov	a,r6
      00462E 24 73            [12] 1644 	add	a, #_page_data
      004630 FC               [12] 1645 	mov	r4,a
      004631 E4               [12] 1646 	clr	a
      004632 34 05            [12] 1647 	addc	a, #(_page_data >> 8)
      004634 FD               [12] 1648 	mov	r5,a
      004635 12 46 8C         [24] 1649 	lcall	_ak820_outline_0096
      004638 60 07            [24] 1650 	jz	00108$
      00463A 12 38 97         [24] 1651 	lcall	_ak820_outline_0124
      00463D E4               [12] 1652 	clr	a
      00463E F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	assignBit
      00463F D2 0A            [12] 1655 	setb	_page_dirty
      004641                       1656 00108$:
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004641 0E               [12] 1658 	inc	r6
      004642 BE 40 E8         [24] 1659 	cjne	r6,#0x40,00107$
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004645 C0 07            [24] 1661 	push	ar7
      004647 12 41 78         [24] 1662 	lcall	_ak820_nvm_flush
      00464A D0 07            [24] 1663 	pop	ar7
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00464C 0F               [12] 1665 	inc	r7
      00464D 80 C7            [24] 1666 	sjmp	00111$
      00464F                       1667 00113$:
                                   1668 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00464F 22               [24] 1669 	ret
                                   1670 	.area CSEG    (CODE)
                                   1671 	.area CONST   (CODE)
                                   1672 	.area XINIT   (CODE)
                                   1673 	.area CABS    (ABS,CODE)
                                   1674 
                                   1675 ; Experimental exact instruction outlining.
                                   1676 	.globl _ak820_outline_0005
                                   1677 	.globl _ak820_outline_0012
                                   1678 	.globl _ak820_outline_0017
                                   1679 	.globl _ak820_outline_0021
                                   1680 	.globl _ak820_outline_0032
                                   1681 	.globl _ak820_outline_0037
                                   1682 	.globl _ak820_outline_0043
                                   1683 	.globl _ak820_outline_0052
                                   1684 	.globl _ak820_outline_0053
                                   1685 	.globl _ak820_outline_0059
                                   1686 	.globl _ak820_outline_0071
                                   1687 	.globl _ak820_outline_0072
                                   1688 	.globl _ak820_outline_0084
                                   1689 	.globl _ak820_outline_0085
                                   1690 	.globl _ak820_outline_0096
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0106
                                   1694 	.globl _ak820_outline_0108
                                   1695 	.globl _ak820_outline_0109
                                   1696 	.globl _ak820_outline_0118
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0123
                                   1699 	.globl _ak820_outline_0124
                                   1700 	.globl _ak820_outline_0125
                                   1701 	.globl _ak820_outline_0134
                                   1702 	.globl _ak820_outline_0136
                                   1703 	.globl _ak820_outline_0138
                                   1704 	.globl _ak820_outline_0143
                                   1705 	.globl _ak820_outline_0149
                                   1706 	.globl _ak820_outline_0156
                                   1707 	.globl _ak820_outline_0157
                                   1708 	.globl _ak820_outline_0160
                                   1709 	.globl _ak820_outline_0161
                                   1710 	.globl _ak820_outline_0182
                                   1711 	.globl _ak820_outline_0183
                                   1712 
                                   1713 	.area CSEG (CODE)
                                   1714 ; function ak820_outline_0012
      004650                       1715 _ak820_outline_0012:
      004650 8E 82            [24] 1716 	mov	dpl,r6
      004652 8F 83            [24] 1717 	mov	dph,r7
      004654 A3               [24] 1718 	inc	dptr
      004655 A3               [24] 1719 	inc	dptr
      004656 A3               [24] 1720 	inc	dptr
      004657 A3               [24] 1721 	inc	dptr
      004658 A3               [24] 1722 	inc	dptr
      004659 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0032
      00465A                       1727 _ak820_outline_0032:
      00465A F0               [24] 1728 	movx	@dptr,a
      00465B 8E 82            [24] 1729 	mov	dpl,r6
      00465D 8F 83            [24] 1730 	mov	dph,r7
      00465F A3               [24] 1731 	inc	dptr
      004660 A3               [24] 1732 	inc	dptr
      004661 22               [24] 1733 	ret
                                   1734 
                                   1735 	.area CSEG (CODE)
                                   1736 ; function ak820_outline_0037
      004662                       1737 _ak820_outline_0037:
      004662 AF F0            [24] 1738 	mov	r7,b
      004664 AE 83            [24] 1739 	mov	r6,dph
      004666 E5 82            [12] 1740 	mov	a,dpl
      004668 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0043
      004669                       1745 _ak820_outline_0043:
      004669 EF               [12] 1746 	mov	a,r7
      00466A 24 CB            [12] 1747 	add	a,#_ak820_nvm_flush_header_10000_62
      00466C F5 82            [12] 1748 	mov	dpl,a
      00466E E4               [12] 1749 	clr	a
      00466F 34 05            [12] 1750 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004671 F5 83            [12] 1751 	mov	dph,a
      004673 E0               [24] 1752 	movx	a,@dptr
      004674 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0053
      004675                       1757 _ak820_outline_0053:
      004675 8F 06            [24] 1758 	mov	ar6,r7
      004677 7D 00            [12] 1759 	mov	r5,#0x00
      004679 74 40            [12] 1760 	mov	a,#0x40
      00467B 2E               [12] 1761 	add	a,r6
      00467C FE               [12] 1762 	mov	r6,a
      00467D 74 EF            [12] 1763 	mov	a,#0xef
      00467F 3D               [12] 1764 	addc	a,r5
      004680 FD               [12] 1765 	mov	r5,a
      004681 8E 82            [24] 1766 	mov	dpl,r6
      004683 8D 83            [24] 1767 	mov	dph,r5
      004685 22               [24] 1768 	ret
                                   1769 
                                   1770 	.area CSEG (CODE)
                                   1771 ; function ak820_outline_0071
      004686                       1772 _ak820_outline_0071:
      004686 F0               [24] 1773 	movx	@dptr,a
      004687 8E 82            [24] 1774 	mov	dpl,r6
      004689 8F 83            [24] 1775 	mov	dph,r7
      00468B 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0096
      00468C                       1780 _ak820_outline_0096:
      00468C 8C 82            [24] 1781 	mov	dpl,r4
      00468E 8D 83            [24] 1782 	mov	dph,r5
      004690 E0               [24] 1783 	movx	a,@dptr
      004691 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0104
      004692                       1788 _ak820_outline_0104:
      004692 E0               [24] 1789 	movx	a,@dptr
      004693 FA               [12] 1790 	mov	r2,a
      004694 A3               [24] 1791 	inc	dptr
      004695 E0               [24] 1792 	movx	a,@dptr
      004696 FB               [12] 1793 	mov	r3,a
      004697 22               [24] 1794 	ret
                                   1795 
                                   1796 	.area CSEG (CODE)
                                   1797 ; function ak820_outline_0106
      004698                       1798 _ak820_outline_0106:
      004698 EF               [12] 1799 	mov	a,r7
      004699 24 73            [12] 1800 	add	a,#_page_data
      00469B F5 82            [12] 1801 	mov	dpl,a
      00469D E4               [12] 1802 	clr	a
      00469E 34 05            [12] 1803 	addc	a,#(_page_data>>8)
      0046A0 F5 83            [12] 1804 	mov	dph,a
      0046A2 E0               [24] 1805 	movx	a,@dptr
      0046A3 22               [24] 1806 	ret
                                   1807 
                                   1808 	.area CSEG (CODE)
                                   1809 ; function ak820_outline_0125
      0046A4                       1810 _ak820_outline_0125:
      0046A4 AE 82            [24] 1811 	mov	r6,dpl
      0046A6 AF 83            [24] 1812 	mov	r7,dph
      0046A8 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0138
      0046A9                       1817 _ak820_outline_0138:
      0046A9 2E               [12] 1818 	add	a,r6
      0046AA FE               [12] 1819 	mov	r6,a
      0046AB E4               [12] 1820 	clr	a
      0046AC 3F               [12] 1821 	addc	a,r7
      0046AD FF               [12] 1822 	mov	r7,a
      0046AE 22               [24] 1823 	ret
                                   1824 
                                   1825 	.area CSEG (CODE)
                                   1826 ; function ak820_outline_0143
      0046AF                       1827 _ak820_outline_0143:
      0046AF 42 05            [12] 1828 	orl	ar5,a
      0046B1 EA               [12] 1829 	mov	a,r2
      0046B2 42 04            [12] 1830 	orl	ar4,a
      0046B4 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0149
      0046B5                       1835 _ak820_outline_0149:
      0046B5 AC 82            [24] 1836 	mov	r4,dpl
      0046B7 AD 83            [24] 1837 	mov	r5,dph
      0046B9 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0157
      0046BA                       1842 _ak820_outline_0157:
      0046BA 8F 82            [24] 1843 	mov	dpl,r7
      0046BC 8E 83            [24] 1844 	mov	dph,r6
      0046BE 22               [24] 1845 	ret
                                   1846 
                                   1847 	.area CSEG (CODE)
                                   1848 ; function ak820_outline_0160
      0046BF                       1849 _ak820_outline_0160:
      0046BF 2E               [12] 1850 	add	a,r6
      0046C0 FC               [12] 1851 	mov	r4,a
      0046C1 E4               [12] 1852 	clr	a
      0046C2 3F               [12] 1853 	addc	a,r7
      0046C3 FD               [12] 1854 	mov	r5,a
      0046C4 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0161
      0046C5                       1859 _ak820_outline_0161:
      0046C5 ED               [12] 1860 	mov	a,r5
      0046C6 F0               [24] 1861 	movx	@dptr,a
      0046C7 EE               [12] 1862 	mov	a,r6
      0046C8 A3               [24] 1863 	inc	dptr
      0046C9 F0               [24] 1864 	movx	@dptr,a
      0046CA 22               [24] 1865 	ret
                                   1866 
                                   1867 	.area CSEG (CODE)
                                   1868 ; function ak820_outline_0182
      0046CB                       1869 _ak820_outline_0182:
      0046CB 89 82            [24] 1870 	mov	dpl,r1
      0046CD 8A 83            [24] 1871 	mov	dph,r2
      0046CF 22               [24] 1872 	ret
                                   1873 
                                   1874 	.area CSEG (CODE)
                                   1875 ; function ak820_outline_0183
      0046D0                       1876 _ak820_outline_0183:
      0046D0 8C 82            [24] 1877 	mov	dpl,r4
      0046D2 8B 83            [24] 1878 	mov	dph,r3
      0046D4 22               [24] 1879 	ret
