                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      00002A                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      00002A                        588 	.ds 2
      00002C                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002C                        590 	.ds 1
      00002D                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002D                        592 	.ds 1
      00002E                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002E                        594 	.ds 2
      000030                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000030                        596 	.ds 2
      000032                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000032                        598 	.ds 1
      000033                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000033                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000028                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000028                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B2E                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B2E                        628 	.ds 1
      000B2F                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B2F                        630 	.ds 1
      000B30                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000B30                        632 	.ds 1
      000B31                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B31                        634 	.ds 1
      000B32                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B32                        636 	.ds 1
      000B33                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000B33                        638 	.ds 1
      000B34                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B34                        640 	.ds 1
      000B35                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B35                        642 	.ds 1
      000B36                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B36                        644 	.ds 2
      000B38                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000B38                        646 	.ds 1
      000B39                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B39                        648 	.ds 1
      000B3A                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000B3A                        650 	.ds 1
      000B3B                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B3B                        652 	.ds 1
      000B3C                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B3C                        654 	.ds 1
      000B3D                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000B3D                        656 	.ds 1
      000B3E                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B3E                        658 	.ds 1
      000B3F                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B3F                        660 	.ds 1
      000B40                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B40                        662 	.ds 2
      000B42                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000B42                        664 	.ds 1
      000B43                        665 _dynamic_keymap_get_combo_PARM_2:
      000B43                        666 	.ds 3
      000B46                        667 _dynamic_keymap_get_combo_index_10000_385:
      000B46                        668 	.ds 1
      000B47                        669 _dynamic_keymap_set_combo_PARM_2:
      000B47                        670 	.ds 3
      000B4A                        671 _dynamic_keymap_set_combo_index_10000_391:
      000B4A                        672 	.ds 1
      000B4B                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000B4B                        674 	.ds 10
      000B55                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B55                        676 	.ds 1
      000B56                        677 _dynamic_keymap_reset_combo_10001_408:
      000B56                        678 	.ds 10
      000B60                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B60                        680 	.ds 2
      000B62                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B62                        682 	.ds 2
      000B64                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B64                        684 	.ds 2
      000B66                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B66                        686 	.ds 3
      000B69                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B69                        688 	.ds 2
      000B6B                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B6B                        690 	.ds 1
      000B6C                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B6C                        692 	.ds 2
      000B6E                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B6E                        694 	.ds 3
      000B71                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B71                        696 	.ds 2
      000B73                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B73                        698 	.ds 2
      000B75                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B75                        700 	.ds 3
      000B78                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B78                        702 	.ds 2
      000B7A                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B7A                        704 	.ds 1
      000B7B                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B7B                        706 	.ds 1
      000B7C                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B7C                        708 	.ds 1
      000B7D                        709 _keycode_at_keymap_location_PARM_2:
      000B7D                        710 	.ds 1
      000B7E                        711 _keycode_at_keymap_location_PARM_3:
      000B7E                        712 	.ds 1
      000B7F                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B7F                        714 	.ds 1
      000B80                        715 _keycode_at_encodermap_location_PARM_2:
      000B80                        716 	.ds 1
      000B81                        717 _keycode_at_encodermap_location_PARM_3:
      000B81                        718 	.ds 1
      000B82                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B82                        720 	.ds 1
      000B83                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B83                        722 	.ds 2
      000B85                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B85                        724 	.ds 3
      000B88                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B88                        726 	.ds 2
      000B8A                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B8A                        728 	.ds 2
      000B8C                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B8C                        730 	.ds 3
      000B8F                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B8F                        732 	.ds 2
      000B91                        733 _decode_keycode_kc_10000_455:
      000B91                        734 	.ds 2
      000B93                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B93                        736 	.ds 1
      000B94                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B94                        738 	.ds 1
      000B95                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B95                        740 	.ds 2
      000B97                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B97                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008827                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008827 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      00882A 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      00882B                        810 _dynamic_keymap_key_to_eeprom_address:
      00882B E5 82            [12]  811 	mov	a,dpl
      00882D 90 0B 30         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008830 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008831 E0               [24]  815 	movx	a,@dptr
      008832 FF               [12]  816 	mov	r7,a
      008833 7E 00            [12]  817 	mov	r6,#0x00
      008835 74 40            [12]  818 	mov	a,#0x40
      008837 12 46 A9         [24]  819 	lcall	_ak820_outline_0138
      00883A 7D 00            [12]  820 	mov	r5,#0x00
      00883C 90 0B 2E         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00883F E0               [24]  822 	movx	a,@dptr
      008840 75 F0 10         [24]  823 	mov	b,#0x10
      008843 A4               [48]  824 	mul	ab
      008844 2E               [12]  825 	add	a, r6
      008845 FE               [12]  826 	mov	r6,a
      008846 EF               [12]  827 	mov	a,r7
      008847 35 F0            [12]  828 	addc	a, b
      008849 FF               [12]  829 	mov	r7,a
      00884A 90 0B 2F         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00884D E0               [24]  831 	movx	a,@dptr
      00884E 7C 00            [12]  832 	mov	r4,#0x00
      008850 25 E0            [12]  833 	add	a,acc
      008852 FB               [12]  834 	mov	r3,a
      008853 EC               [12]  835 	mov	a,r4
      008854 33               [12]  836 	rlc	a
      008855 FC               [12]  837 	mov	r4,a
      008856 EB               [12]  838 	mov	a,r3
      008857 2E               [12]  839 	add	a, r6
      008858 FE               [12]  840 	mov	r6,a
      008859 EC               [12]  841 	mov	a,r4
      00885A 3F               [12]  842 	addc	a, r7
      00885B FF               [12]  843 	mov	r7,a
      00885C 12 73 0C         [24]  844 	lcall	_ak820_outline_0064
                                    845 ;	quantum/dynamic_keymap.c:184: }
      00885F 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      008860                        860 _dynamic_keymap_get_keycode:
      008860 E5 82            [12]  861 	mov	a,dpl
      008862 90 0B 33         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      008865 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008866 E0               [24]  865 	movx	a,@dptr
      008867 FF               [12]  866 	mov	r7,a
      008868 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      00886B                        868 00121$:
      00886B 50 14            [24]  869 	jnc	00101$
      00886D 90 0B 31         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008870 E0               [24]  871 	movx	a,@dptr
      008871 FE               [12]  872 	mov	r6,a
      008872 BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      008875                        874 00123$:
      008875 50 0A            [24]  875 	jnc	00101$
      008877 90 0B 32         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00887A E0               [24]  877 	movx	a,@dptr
      00887B FD               [12]  878 	mov	r5,a
      00887C BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      00887F                        880 00125$:
      00887F 40 04            [24]  881 	jc	00102$
      008881                        882 00101$:
      008881 90 00 00         [24]  883 	mov	dptr,#0x0000
      008884 22               [24]  884 	ret
      008885                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008885 12 92 B8         [24]  887 	lcall	_ak820_outline_0100
      008888 12 88 2B         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      00888B 12 92 CC         [24]  890 	lcall	_ak820_outline_0116
      00888E 12 43 C3         [24]  891 	lcall	_eeprom_read_byte
      008891 AB 82            [24]  892 	mov	r3,dpl
      008893 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008895 0D               [12]  895 	inc	r5
      008896 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      008899 0E               [12]  897 	inc	r6
      00889A                        898 00127$:
      00889A 12 70 F6         [24]  899 	lcall	_ak820_outline_0050
      00889D 12 43 C3         [24]  900 	lcall	_eeprom_read_byte
      0088A0 AF 82            [24]  901 	mov	r7, dpl
      0088A2 7E 00            [12]  902 	mov	r6,#0x00
      0088A4 EF               [12]  903 	mov	a,r7
      0088A5 42 04            [12]  904 	orl	ar4,a
      0088A7 EE               [12]  905 	mov	a,r6
      0088A8 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      0088AA 12 46 D0         [24]  908 	lcall	_ak820_outline_0183
                                    909 ;	quantum/dynamic_keymap.c:193: }
      0088AD 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      0088AE                        924 _dynamic_keymap_set_keycode:
      0088AE E5 82            [12]  925 	mov	a,dpl
      0088B0 90 0B 38         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      0088B3 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0088B4 E0               [24]  929 	movx	a,@dptr
      0088B5 FF               [12]  930 	mov	r7,a
      0088B6 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      0088B9                        932 00121$:
      0088B9 50 14            [24]  933 	jnc	00101$
      0088BB 90 0B 34         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0088BE E0               [24]  935 	movx	a,@dptr
      0088BF FE               [12]  936 	mov	r6,a
      0088C0 BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      0088C3                        938 00123$:
      0088C3 50 0A            [24]  939 	jnc	00101$
      0088C5 90 0B 35         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088C8 E0               [24]  941 	movx	a,@dptr
      0088C9 FD               [12]  942 	mov	r5,a
      0088CA BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      0088CD                        944 00125$:
      0088CD 40 01            [24]  945 	jc	00102$
      0088CF                        946 00101$:
      0088CF 22               [24]  947 	ret
      0088D0                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088D0 12 92 B8         [24]  950 	lcall	_ak820_outline_0100
      0088D3 12 88 2B         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      0088D6 12 92 CC         [24]  952 	lcall	_ak820_outline_0116
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0088D9 90 0B 36         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088DC E0               [24]  955 	movx	a,@dptr
      0088DD FB               [12]  956 	mov	r3,a
      0088DE A3               [24]  957 	inc	dptr
      0088DF E0               [24]  958 	movx	a,@dptr
      0088E0 90 06 F1         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088E3 12 52 6D         [24]  960 	lcall	_ak820_outline_0031
      0088E6 12 51 58         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0088E9 0D               [12]  963 	inc	r5
      0088EA BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      0088ED 0E               [12]  965 	inc	r6
      0088EE                        966 00127$:
      0088EE 90 06 F1         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088F1 EB               [12]  968 	mov	a,r3
      0088F2 12 52 6D         [24]  969 	lcall	_ak820_outline_0031
                                    970 ;	quantum/dynamic_keymap.c:201: }
      0088F5 02 51 58         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      0088F8                        982 _dynamic_keymap_encoder_to_eeprom_address:
      0088F8 E5 82            [12]  983 	mov	a,dpl
      0088FA 90 0B 3A         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      0088FD F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0088FE E0               [24]  987 	movx	a,@dptr
      0088FF 75 F0 04         [24]  988 	mov	b,#0x04
      008902 A4               [48]  989 	mul	ab
      008903 24 40            [12]  990 	add	a, #0x40
      008905 FD               [12]  991 	mov	r5,a
      008906 74 06            [12]  992 	mov	a,#0x06
      008908 35 F0            [12]  993 	addc	a, b
      00890A FE               [12]  994 	mov	r6,a
      00890B 7F 00            [12]  995 	mov	r7,#0x00
      00890D 90 0B 39         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008910 E0               [24]  997 	movx	a,@dptr
      008911 75 F0 04         [24]  998 	mov	b,#0x04
      008914 A4               [48]  999 	mul	ab
      008915 2D               [12] 1000 	add	a, r5
      008916 FD               [12] 1001 	mov	r5,a
      008917 EE               [12] 1002 	mov	a,r6
      008918 35 F0            [12] 1003 	addc	a, b
      00891A FE               [12] 1004 	mov	r6,a
      00891B 12 70 F6         [24] 1005 	lcall	_ak820_outline_0050
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      00891E 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      00891F                       1021 _dynamic_keymap_get_encoder:
      00891F E5 82            [12] 1022 	mov	a,dpl
      008921 90 0B 3D         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008924 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008925 E0               [24] 1026 	movx	a,@dptr
      008926 FF               [12] 1027 	mov	r7,a
      008927 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      00892A                       1029 00131$:
      00892A 50 0A            [24] 1030 	jnc	00101$
      00892C 90 0B 3B         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00892F E0               [24] 1032 	movx	a,@dptr
      008930 FE               [12] 1033 	mov	r6,a
      008931 BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      008934                       1035 00133$:
      008934 40 04            [24] 1036 	jc	00102$
      008936                       1037 00101$:
      008936 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008939 22               [24] 1039 	ret
      00893A                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00893A 90 0B 39         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00893D 12 7B 92         [24] 1043 	lcall	_ak820_outline_0188
      008940 12 88 F8         [24] 1044 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008943 12 92 CC         [24] 1045 	lcall	_ak820_outline_0116
                                   1046 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008946 90 0B 3C         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008949 E0               [24] 1048 	movx	a,@dptr
      00894A FC               [12] 1049 	mov	r4,a
      00894B E0               [24] 1050 	movx	a,@dptr
      00894C 60 04            [24] 1051 	jz	00106$
      00894E 7B 00            [12] 1052 	mov	r3,#0x00
      008950 80 02            [24] 1053 	sjmp	00107$
      008952                       1054 00106$:
      008952 7B 02            [12] 1055 	mov	r3,#0x02
      008954                       1056 00107$:
      008954 EB               [12] 1057 	mov	a,r3
      008955 12 7B 0C         [24] 1058 	lcall	_ak820_outline_0014
      008958 12 43 C3         [24] 1059 	lcall	_eeprom_read_byte
      00895B AA 82            [24] 1060 	mov	r2,dpl
      00895D 7B 00            [12] 1061 	mov	r3,#0x00
                                   1062 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00895F EC               [12] 1063 	mov	a,r4
      008960 60 04            [24] 1064 	jz	00108$
      008962 7C 00            [12] 1065 	mov	r4,#0x00
      008964 80 02            [24] 1066 	sjmp	00109$
      008966                       1067 00108$:
      008966 7C 02            [12] 1068 	mov	r4,#0x02
      008968                       1069 00109$:
      008968 EC               [12] 1070 	mov	a,r4
      008969 12 38 BB         [24] 1071 	lcall	_ak820_outline_0159
      00896C 0D               [12] 1072 	inc	r5
      00896D BD 00 01         [24] 1073 	cjne	r5,#0x00,00137$
      008970 0E               [12] 1074 	inc	r6
      008971                       1075 00137$:
      008971 12 70 F6         [24] 1076 	lcall	_ak820_outline_0050
      008974 12 43 C3         [24] 1077 	lcall	_eeprom_read_byte
      008977 AF 82            [24] 1078 	mov	r7, dpl
      008979 7E 00            [12] 1079 	mov	r6,#0x00
      00897B EF               [12] 1080 	mov	a,r7
      00897C 42 03            [12] 1081 	orl	ar3,a
      00897E EE               [12] 1082 	mov	a,r6
      00897F 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/dynamic_keymap.c:214: return keycode;
      008981 8B 82            [24] 1085 	mov	dpl, r3
      008983 8A 83            [24] 1086 	mov	dph, r2
                                   1087 ;	quantum/dynamic_keymap.c:215: }
      008985 22               [24] 1088 	ret
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1091 ;------------------------------------------------------------
                                   1092 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1093 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1094 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1095 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1096 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1097 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function dynamic_keymap_set_encoder
                                   1102 ;	-----------------------------------------
      008986                       1103 _dynamic_keymap_set_encoder:
      008986 E5 82            [12] 1104 	mov	a,dpl
      008988 90 0B 42         [24] 1105 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      00898B F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00898C E0               [24] 1108 	movx	a,@dptr
      00898D FF               [12] 1109 	mov	r7,a
      00898E BF 06 00         [24] 1110 	cjne	r7,#0x06,00131$
      008991                       1111 00131$:
      008991 50 0A            [24] 1112 	jnc	00101$
      008993 90 0B 3E         [24] 1113 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008996 E0               [24] 1114 	movx	a,@dptr
      008997 FE               [12] 1115 	mov	r6,a
      008998 BE 01 00         [24] 1116 	cjne	r6,#0x01,00133$
      00899B                       1117 00133$:
      00899B 40 01            [24] 1118 	jc	00102$
      00899D                       1119 00101$:
      00899D 22               [24] 1120 	ret
      00899E                       1121 00102$:
                                   1122 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00899E 90 0B 39         [24] 1123 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089A1 12 7B 92         [24] 1124 	lcall	_ak820_outline_0188
      0089A4 12 88 F8         [24] 1125 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0089A7 12 92 CC         [24] 1126 	lcall	_ak820_outline_0116
                                   1127 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0089AA 90 0B 3F         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0089AD E0               [24] 1129 	movx	a,@dptr
      0089AE FC               [12] 1130 	mov	r4,a
      0089AF E0               [24] 1131 	movx	a,@dptr
      0089B0 60 04            [24] 1132 	jz	00106$
      0089B2 7B 00            [12] 1133 	mov	r3,#0x00
      0089B4 80 02            [24] 1134 	sjmp	00107$
      0089B6                       1135 00106$:
      0089B6 7B 02            [12] 1136 	mov	r3,#0x02
      0089B8                       1137 00107$:
      0089B8 EB               [12] 1138 	mov	a,r3
      0089B9 12 92 DE         [24] 1139 	lcall	_ak820_outline_0137
      0089BC 8F 03            [24] 1140 	mov	ar3,r7
      0089BE 90 0B 40         [24] 1141 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0089C1 E0               [24] 1142 	movx	a,@dptr
      0089C2 F5 2A            [12] 1143 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0089C4 A3               [24] 1144 	inc	dptr
      0089C5 E0               [24] 1145 	movx	a,@dptr
      0089C6 F5 2B            [12] 1146 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0089C8 90 06 F1         [24] 1147 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089CB F0               [24] 1148 	movx	@dptr,a
      0089CC 12 46 CB         [24] 1149 	lcall	_ak820_outline_0182
      0089CF 8B F0            [24] 1150 	mov	b, r3
      0089D1 12 51 58         [24] 1151 	lcall	_eeprom_update_byte
                                   1152 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0089D4 EC               [12] 1153 	mov	a,r4
      0089D5 60 04            [24] 1154 	jz	00108$
      0089D7 7C 00            [12] 1155 	mov	r4,#0x00
      0089D9 80 02            [24] 1156 	sjmp	00109$
      0089DB                       1157 00108$:
      0089DB 7C 02            [12] 1158 	mov	r4,#0x02
      0089DD                       1159 00109$:
      0089DD EC               [12] 1160 	mov	a,r4
      0089DE 12 38 BB         [24] 1161 	lcall	_ak820_outline_0159
      0089E1 0D               [12] 1162 	inc	r5
      0089E2 BD 00 01         [24] 1163 	cjne	r5,#0x00,00137$
      0089E5 0E               [12] 1164 	inc	r6
      0089E6                       1165 00137$:
      0089E6 90 06 F1         [24] 1166 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089E9 E5 2A            [12] 1167 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0089EB 12 52 6D         [24] 1168 	lcall	_ak820_outline_0031
                                   1169 ;	quantum/dynamic_keymap.c:223: }
      0089EE 02 51 58         [24] 1170 	ljmp	_eeprom_update_byte
                                   1171 ;------------------------------------------------------------
                                   1172 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1173 ;------------------------------------------------------------
                                   1174 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1175 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1176 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1177 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1178 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1179 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function dynamic_keymap_get_combo
                                   1184 ;	-----------------------------------------
      0089F1                       1185 _dynamic_keymap_get_combo:
      0089F1 E5 82            [12] 1186 	mov	a,dpl
      0089F3 90 0B 46         [24] 1187 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      0089F6 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0089F7 90 0B 43         [24] 1190 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0089FA 12 38 41         [24] 1191 	lcall	_ak820_outline_0052
                                   1192 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      0089FD 90 0B 46         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008A00 E0               [24] 1194 	movx	a,@dptr
      008A01 FD               [12] 1195 	mov	r5,a
      008A02 BD 08 00         [24] 1196 	cjne	r5,#0x08,00132$
      008A05                       1197 00132$:
      008A05 40 04            [24] 1198 	jc	00102$
                                   1199 ;	quantum/dynamic_keymap.c:275: return -1;
      008A07 90 FF FF         [24] 1200 	mov	dptr,#0xffff
      008A0A 22               [24] 1201 	ret
      008A0B                       1202 00102$:
                                   1203 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008A0B 12 92 A4         [24] 1204 	lcall	_ak820_outline_0080
                                   1205 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008A0E 8E 02            [24] 1206 	mov	ar2,r6
      008A10 8F 03            [24] 1207 	mov	ar3,r7
      008A12 90 05 DB         [24] 1208 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A15 12 38 5E         [24] 1209 	lcall	_ak820_outline_0072
      008A18 E4               [12] 1210 	clr	a
      008A19 A3               [24] 1211 	inc	dptr
      008A1A F0               [24] 1212 	movx	@dptr,a
      008A1B 90 05 DE         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A1E 12 92 C5         [24] 1214 	lcall	_ak820_outline_0112
      008A21 12 38 A6         [24] 1215 	lcall	_ak820_outline_0136
      008A24 C0 07            [24] 1216 	push	ar7
      008A26 C0 06            [24] 1217 	push	ar6
      008A28 12 43 FE         [24] 1218 	lcall	_ak820_eeprom_read_block_xdata
      008A2B D0 06            [24] 1219 	pop	ar6
      008A2D D0 07            [24] 1220 	pop	ar7
                                   1221 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008A2F 74 04            [12] 1222 	mov	a,#0x04
      008A31 12 4B CF         [24] 1223 	lcall	_ak820_outline_0034
      008A34 FA               [12] 1224 	mov	r2,a
      008A35 A3               [24] 1225 	inc	dptr
      008A36 E0               [24] 1226 	movx	a,@dptr
      008A37 FB               [12] 1227 	mov	r3,a
      008A38 BA 20 13         [24] 1228 	cjne	r2,#0x20,00108$
      008A3B BB 08 10         [24] 1229 	cjne	r3,#0x08,00108$
      008A3E 74 06            [12] 1230 	mov	a,#0x06
      008A40 12 38 31         [24] 1231 	lcall	_ak820_outline_0021
      008A43 12 46 92         [24] 1232 	lcall	_ak820_outline_0104
      008A46 BA 01 05         [24] 1233 	cjne	r2,#0x01,00136$
      008A49 BB 00 02         [24] 1234 	cjne	r3,#0x00,00136$
      008A4C 80 05            [24] 1235 	sjmp	00109$
      008A4E                       1236 00136$:
      008A4E                       1237 00108$:
      008A4E 75 2C 00         [24] 1238 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008A51 80 03            [24] 1239 	sjmp	00110$
      008A53                       1240 00109$:
      008A53 75 2C 01         [24] 1241 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008A56                       1242 00110$:
                                   1243 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008A56 74 06            [12] 1244 	mov	a,#0x06
      008A58 12 38 31         [24] 1245 	lcall	_ak820_outline_0021
      008A5B E4               [12] 1246 	clr	a
      008A5C F0               [24] 1247 	movx	@dptr,a
      008A5D A3               [24] 1248 	inc	dptr
      008A5E 12 38 76         [24] 1249 	lcall	_ak820_outline_0101
      008A61 F0               [24] 1250 	movx	@dptr,a
      008A62 A3               [24] 1251 	inc	dptr
      008A63 F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008A64 E5 2C            [12] 1254 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008A66 60 12            [24] 1255 	jz	00103$
      008A68 12 38 8C         [24] 1256 	lcall	_ak820_outline_0118
      008A6B C0 07            [24] 1257 	push	ar7
      008A6D C0 06            [24] 1258 	push	ar6
      008A6F 12 34 D1         [24] 1259 	lcall	_ak820_combo_valid
      008A72 E5 82            [12] 1260 	mov	a, dpl
      008A74 D0 06            [24] 1261 	pop	ar6
      008A76 D0 07            [24] 1262 	pop	ar7
      008A78 70 13            [24] 1263 	jnz	00104$
      008A7A                       1264 00103$:
      008A7A 7D 00            [12] 1265 	mov	r5,#0x00
      008A7C 90 0D FE         [24] 1266 	mov	dptr,#_memset_PARM_2
      008A7F E4               [12] 1267 	clr	a
      008A80 F0               [24] 1268 	movx	@dptr,a
      008A81 90 0D FF         [24] 1269 	mov	dptr,#_memset_PARM_3
      008A84 12 92 C5         [24] 1270 	lcall	_ak820_outline_0112
      008A87 12 73 0C         [24] 1271 	lcall	_ak820_outline_0064
      008A8A 12 BD 4E         [24] 1272 	lcall	_memset
      008A8D                       1273 00104$:
                                   1274 ;	quantum/dynamic_keymap.c:289: return 0;
      008A8D 90 00 00         [24] 1275 	mov	dptr,#0x0000
                                   1276 ;	quantum/dynamic_keymap.c:290: }
      008A90 22               [24] 1277 	ret
                                   1278 ;------------------------------------------------------------
                                   1279 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1280 ;------------------------------------------------------------
                                   1281 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1282 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1283 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1284 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1285 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1286 ;------------------------------------------------------------
                                   1287 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1288 ;	-----------------------------------------
                                   1289 ;	 function dynamic_keymap_set_combo
                                   1290 ;	-----------------------------------------
      008A91                       1291 _dynamic_keymap_set_combo:
      008A91 E5 82            [12] 1292 	mov	a,dpl
      008A93 90 0B 4A         [24] 1293 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008A96 F0               [24] 1294 	movx	@dptr,a
                                   1295 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A97 90 0B 47         [24] 1296 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A9A 12 37 F4         [24] 1297 	lcall	_ak820_outline_0005
                                   1298 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008A9D C0 07            [24] 1299 	push	ar7
      008A9F C0 06            [24] 1300 	push	ar6
      008AA1 12 34 D1         [24] 1301 	lcall	_ak820_combo_valid
      008AA4 E5 82            [12] 1302 	mov	a, dpl
      008AA6 D0 06            [24] 1303 	pop	ar6
      008AA8 D0 07            [24] 1304 	pop	ar7
      008AAA 60 07            [24] 1305 	jz	00101$
      008AAC 12 41 69         [24] 1306 	lcall	_ak820_nvm_ok
      008AAF E5 82            [12] 1307 	mov	a, dpl
      008AB1 70 04            [24] 1308 	jnz	00102$
      008AB3                       1309 00101$:
      008AB3 90 FF FF         [24] 1310 	mov	dptr,#0xffff
      008AB6 22               [24] 1311 	ret
      008AB7                       1312 00102$:
                                   1313 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008AB7 90 0B 4A         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008ABA E0               [24] 1315 	movx	a,@dptr
      008ABB FD               [12] 1316 	mov	r5,a
      008ABC BD 08 00         [24] 1317 	cjne	r5,#0x08,00133$
      008ABF                       1318 00133$:
      008ABF 40 04            [24] 1319 	jc	00105$
                                   1320 ;	quantum/dynamic_keymap.c:302: return -1;
      008AC1 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008AC4 22               [24] 1322 	ret
      008AC5                       1323 00105$:
                                   1324 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AC5 12 92 A4         [24] 1325 	lcall	_ak820_outline_0080
                                   1326 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008AC8 C0 07            [24] 1327 	push	ar7
      008ACA C0 06            [24] 1328 	push	ar6
      008ACC C0 05            [24] 1329 	push	ar5
      008ACE C0 04            [24] 1330 	push	ar4
      008AD0 12 7A B9         [24] 1331 	lcall	_clear_keyboard
      008AD3 D0 04            [24] 1332 	pop	ar4
      008AD5 D0 05            [24] 1333 	pop	ar5
      008AD7 D0 06            [24] 1334 	pop	ar6
      008AD9 D0 07            [24] 1335 	pop	ar7
                                   1336 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008ADB 90 0D F6         [24] 1337 	mov	dptr,#___memcpy_PARM_2
      008ADE 12 4B E2         [24] 1338 	lcall	_ak820_outline_0058
      008AE1 E4               [12] 1339 	clr	a
      008AE2 A3               [24] 1340 	inc	dptr
      008AE3 F0               [24] 1341 	movx	@dptr,a
      008AE4 90 0D F9         [24] 1342 	mov	dptr,#___memcpy_PARM_3
      008AE7 12 92 C5         [24] 1343 	lcall	_ak820_outline_0112
      008AEA 90 0B 4B         [24] 1344 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008AED F5 F0            [12] 1345 	mov	b,a
      008AEF C0 05            [24] 1346 	push	ar5
      008AF1 C0 04            [24] 1347 	push	ar4
      008AF3 12 BC D8         [24] 1348 	lcall	___memcpy
      008AF6 D0 04            [24] 1349 	pop	ar4
      008AF8 D0 05            [24] 1350 	pop	ar5
                                   1351 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008AFA 90 0B 4F         [24] 1352 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008AFD 74 20            [12] 1353 	mov	a,#0x20
      008AFF F0               [24] 1354 	movx	@dptr,a
      008B00 74 08            [12] 1355 	mov	a,#0x08
      008B02 A3               [24] 1356 	inc	dptr
      008B03 F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008B04 90 0B 51         [24] 1359 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008B07 74 01            [12] 1360 	mov	a,#0x01
      008B09 12 38 A1         [24] 1361 	lcall	_ak820_outline_0135
                                   1362 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008B0C 90 05 E4         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008B0F 12 38 5E         [24] 1364 	lcall	_ak820_outline_0072
      008B12 E4               [12] 1365 	clr	a
      008B13 A3               [24] 1366 	inc	dptr
      008B14 F0               [24] 1367 	movx	@dptr,a
      008B15 90 05 E7         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B18 12 92 C5         [24] 1369 	lcall	_ak820_outline_0112
      008B1B 90 0B 4B         [24] 1370 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008B1E 12 44 8A         [24] 1371 	lcall	_ak820_eeprom_write_block_xdata
                                   1372 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008B21 12 41 78         [24] 1373 	lcall	_ak820_nvm_flush
                                   1374 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008B24 12 41 69         [24] 1375 	lcall	_ak820_nvm_ok
      008B27 E5 82            [12] 1376 	mov	a, dpl
      008B29 70 04            [24] 1377 	jnz	00107$
      008B2B 90 FF FF         [24] 1378 	mov	dptr,#0xffff
      008B2E 22               [24] 1379 	ret
      008B2F                       1380 00107$:
                                   1381 ;	quantum/dynamic_keymap.c:320: return 0;
      008B2F 90 00 00         [24] 1382 	mov	dptr,#0x0000
                                   1383 ;	quantum/dynamic_keymap.c:321: }
      008B32 22               [24] 1384 	ret
                                   1385 ;------------------------------------------------------------
                                   1386 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1387 ;------------------------------------------------------------
                                   1388 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1389 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1390 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1391 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1392 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1393 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1394 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1395 ;------------------------------------------------------------
                                   1396 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1397 ;	-----------------------------------------
                                   1398 ;	 function dynamic_keymap_reset
                                   1399 ;	-----------------------------------------
      008B33                       1400 _dynamic_keymap_reset:
                                   1401 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008B33 90 0E 76         [24] 1402 	mov	dptr,#_vial_unlocked
      008B36 E0               [24] 1403 	movx	a,@dptr
      008B37 90 0B 55         [24] 1404 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008B3A F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008B3B 90 0E 76         [24] 1407 	mov	dptr,#_vial_unlocked
      008B3E 74 01            [12] 1408 	mov	a,#0x01
      008B40 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008B41 7F 00            [12] 1411 	mov	r7,#0x00
      008B43                       1412 00116$:
      008B43 BF 06 00         [24] 1413 	cjne	r7,#0x06,00198$
      008B46                       1414 00198$:
      008B46 40 03            [24] 1415 	jc	00199$
      008B48 02 8B F6         [24] 1416 	ljmp	00104$
      008B4B                       1417 00199$:
                                   1418 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B4B 7E 00            [12] 1419 	mov	r6,#0x00
      008B4D                       1420 00110$:
      008B4D BE 10 00         [24] 1421 	cjne	r6,#0x10,00200$
      008B50                       1422 00200$:
      008B50 50 4D            [24] 1423 	jnc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B52 7D 00            [12] 1425 	mov	r5,#0x00
      008B54                       1426 00107$:
      008B54 BD 08 00         [24] 1427 	cjne	r5,#0x08,00202$
      008B57                       1428 00202$:
      008B57 50 43            [24] 1429 	jnc	00111$
                                   1430 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008B59 90 0B F1         [24] 1431 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008B5C EE               [12] 1432 	mov	a,r6
      008B5D F0               [24] 1433 	movx	@dptr,a
      008B5E 90 0B F2         [24] 1434 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008B61 ED               [12] 1435 	mov	a,r5
      008B62 F0               [24] 1436 	movx	@dptr,a
      008B63 8F 82            [24] 1437 	mov	dpl, r7
      008B65 C0 07            [24] 1438 	push	ar7
      008B67 C0 06            [24] 1439 	push	ar6
      008B69 C0 05            [24] 1440 	push	ar5
      008B6B 12 9A F2         [24] 1441 	lcall	_keycode_at_keymap_location_raw
      008B6E AB 82            [24] 1442 	mov	r3, dpl
      008B70 AC 83            [24] 1443 	mov	r4, dph
      008B72 D0 05            [24] 1444 	pop	ar5
      008B74 D0 06            [24] 1445 	pop	ar6
      008B76 D0 07            [24] 1446 	pop	ar7
      008B78 90 0B 34         [24] 1447 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008B7B EE               [12] 1448 	mov	a,r6
      008B7C F0               [24] 1449 	movx	@dptr,a
      008B7D 90 0B 35         [24] 1450 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008B80 ED               [12] 1451 	mov	a,r5
      008B81 F0               [24] 1452 	movx	@dptr,a
      008B82 90 0B 36         [24] 1453 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008B85 12 38 64         [24] 1454 	lcall	_ak820_outline_0084
      008B88 8F 82            [24] 1455 	mov	dpl, r7
      008B8A C0 07            [24] 1456 	push	ar7
      008B8C C0 06            [24] 1457 	push	ar6
      008B8E C0 05            [24] 1458 	push	ar5
      008B90 12 88 AE         [24] 1459 	lcall	_dynamic_keymap_set_keycode
      008B93 D0 05            [24] 1460 	pop	ar5
      008B95 D0 06            [24] 1461 	pop	ar6
      008B97 D0 07            [24] 1462 	pop	ar7
                                   1463 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B99 0D               [12] 1464 	inc	r5
      008B9A 80 B8            [24] 1465 	sjmp	00107$
      008B9C                       1466 00111$:
                                   1467 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B9C 0E               [12] 1468 	inc	r6
      008B9D 80 AE            [24] 1469 	sjmp	00110$
      008B9F                       1470 00102$:
                                   1471 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008B9F 7E 00            [12] 1472 	mov	r6,#0x00
      008BA1                       1473 00113$:
      008BA1 BE 01 00         [24] 1474 	cjne	r6,#0x01,00204$
      008BA4                       1475 00204$:
      008BA4 50 4C            [24] 1476 	jnc	00117$
                                   1477 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008BA6 12 92 FA         [24] 1478 	lcall	_ak820_outline_0177
      008BA9 04               [12] 1479 	inc	a
      008BAA F0               [24] 1480 	movx	@dptr,a
      008BAB 8F 82            [24] 1481 	mov	dpl, r7
      008BAD C0 07            [24] 1482 	push	ar7
      008BAF 12 9B 37         [24] 1483 	lcall	_keycode_at_encodermap_location_raw
      008BB2 12 46 B5         [24] 1484 	lcall	_ak820_outline_0149
      008BB5 D0 07            [24] 1485 	pop	ar7
      008BB7 12 92 F1         [24] 1486 	lcall	_ak820_outline_0176
      008BBA 04               [12] 1487 	inc	a
      008BBB F0               [24] 1488 	movx	@dptr,a
      008BBC 90 0B 40         [24] 1489 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BBF 12 38 5E         [24] 1490 	lcall	_ak820_outline_0072
      008BC2 8F 82            [24] 1491 	mov	dpl, r7
      008BC4 C0 07            [24] 1492 	push	ar7
      008BC6 12 89 86         [24] 1493 	lcall	_dynamic_keymap_set_encoder
      008BC9 D0 07            [24] 1494 	pop	ar7
                                   1495 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008BCB 12 92 FA         [24] 1496 	lcall	_ak820_outline_0177
      008BCE F0               [24] 1497 	movx	@dptr,a
      008BCF 8F 82            [24] 1498 	mov	dpl, r7
      008BD1 C0 07            [24] 1499 	push	ar7
      008BD3 12 9B 37         [24] 1500 	lcall	_keycode_at_encodermap_location_raw
      008BD6 12 46 B5         [24] 1501 	lcall	_ak820_outline_0149
      008BD9 D0 07            [24] 1502 	pop	ar7
      008BDB 12 92 F1         [24] 1503 	lcall	_ak820_outline_0176
      008BDE F0               [24] 1504 	movx	@dptr,a
      008BDF 90 0B 40         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BE2 12 38 5E         [24] 1506 	lcall	_ak820_outline_0072
      008BE5 8F 82            [24] 1507 	mov	dpl, r7
      008BE7 C0 07            [24] 1508 	push	ar7
      008BE9 12 89 86         [24] 1509 	lcall	_dynamic_keymap_set_encoder
      008BEC D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008BEE 7E 01            [12] 1512 	mov	r6,#0x01
      008BF0 80 AF            [24] 1513 	sjmp	00113$
      008BF2                       1514 00117$:
                                   1515 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BF2 0F               [12] 1516 	inc	r7
      008BF3 02 8B 43         [24] 1517 	ljmp	00116$
      008BF6                       1518 00104$:
                                   1519 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008BF6 90 0B 56         [24] 1520 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008BF9 12 52 B7         [24] 1521 	lcall	_ak820_outline_0181
      008BFC 90 0B 58         [24] 1522 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008BFF F0               [24] 1523 	movx	@dptr,a
      008C00 A3               [24] 1524 	inc	dptr
      008C01 F0               [24] 1525 	movx	@dptr,a
      008C02 90 0B 5A         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008C05 F0               [24] 1527 	movx	@dptr,a
      008C06 A3               [24] 1528 	inc	dptr
      008C07 F0               [24] 1529 	movx	@dptr,a
      008C08 90 0B 5C         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008C0B F0               [24] 1531 	movx	@dptr,a
      008C0C A3               [24] 1532 	inc	dptr
      008C0D F0               [24] 1533 	movx	@dptr,a
      008C0E 90 0B 5E         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008C11 F0               [24] 1535 	movx	@dptr,a
      008C12 A3               [24] 1536 	inc	dptr
      008C13 F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008C14 FF               [12] 1539 	mov	r7,a
      008C15                       1540 00119$:
      008C15 BF 08 00         [24] 1541 	cjne	r7,#0x08,00206$
      008C18                       1542 00206$:
      008C18 50 19            [24] 1543 	jnc	00105$
                                   1544 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008C1A 8F 06            [24] 1545 	mov	ar6,r7
      008C1C 90 0B 47         [24] 1546 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008C1F 74 56            [12] 1547 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008C21 F0               [24] 1548 	movx	@dptr,a
      008C22 74 0B            [12] 1549 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008C24 12 38 70         [24] 1550 	lcall	_ak820_outline_0093
      008C27 8E 82            [24] 1551 	mov	dpl, r6
      008C29 C0 07            [24] 1552 	push	ar7
      008C2B 12 8A 91         [24] 1553 	lcall	_dynamic_keymap_set_combo
      008C2E D0 07            [24] 1554 	pop	ar7
                                   1555 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008C30 0F               [12] 1556 	inc	r7
      008C31 80 E2            [24] 1557 	sjmp	00119$
      008C33                       1558 00105$:
                                   1559 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008C33 90 0B 55         [24] 1560 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008C36 E0               [24] 1561 	movx	a,@dptr
      008C37 90 0E 76         [24] 1562 	mov	dptr,#_vial_unlocked
      008C3A F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/dynamic_keymap.c:405: }
      008C3B 22               [24] 1565 	ret
                                   1566 ;------------------------------------------------------------
                                   1567 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1568 ;------------------------------------------------------------
                                   1569 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1570 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1571 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1572 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1573 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1574 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1575 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1576 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1577 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1578 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function ak820_dynamic_read_buffer
                                   1583 ;	-----------------------------------------
      008C3C                       1584 _ak820_dynamic_read_buffer:
      008C3C 12 38 82         [24] 1585 	lcall	_ak820_outline_0108
      008C3F 90 0B 69         [24] 1586 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008C42 12 38 87         [24] 1587 	lcall	_ak820_outline_0109
                                   1588 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008C45 90 0B 66         [24] 1589 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C48 12 38 41         [24] 1590 	lcall	_ak820_outline_0052
                                   1591 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008C4B 90 0B 6B         [24] 1592 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008C4E E4               [12] 1593 	clr	a
      008C4F F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008C50 90 0B 64         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C53 12 38 58         [24] 1597 	lcall	_ak820_outline_0059
      008C56 8C 02            [24] 1598 	mov	ar2,r4
      008C58 8D 03            [24] 1599 	mov	ar3,r5
      008C5A C3               [12] 1600 	clr	c
      008C5B 74 1C            [12] 1601 	mov	a,#0x1c
      008C5D 9A               [12] 1602 	subb	a,r2
      008C5E E4               [12] 1603 	clr	a
      008C5F 9B               [12] 1604 	subb	a,r3
      008C60 50 01            [24] 1605 	jnc	00102$
                                   1606 ;	free result
      008C62 22               [24] 1607 	ret
      008C63                       1608 00102$:
                                   1609 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008C63 90 0B 62         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C66 12 46 92         [24] 1611 	lcall	_ak820_outline_0104
      008C69 90 0B 60         [24] 1612 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C6C 12 38 7C         [24] 1613 	lcall	_ak820_outline_0103
      008C6F C3               [12] 1614 	clr	c
      008C70 EA               [12] 1615 	mov	a,r2
      008C71 98               [12] 1616 	subb	a,r0
      008C72 EB               [12] 1617 	mov	a,r3
      008C73 99               [12] 1618 	subb	a,r1
      008C74 50 17            [24] 1619 	jnc	00104$
                                   1620 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008C76 E8               [12] 1621 	mov	a,r0
      008C77 C3               [12] 1622 	clr	c
      008C78 9A               [12] 1623 	subb	a,r2
      008C79 F8               [12] 1624 	mov	r0,a
      008C7A E9               [12] 1625 	mov	a,r1
      008C7B 9B               [12] 1626 	subb	a,r3
      008C7C F9               [12] 1627 	mov	r1,a
                                   1628 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008C7D C3               [12] 1629 	clr	c
      008C7E E8               [12] 1630 	mov	a,r0
      008C7F 9C               [12] 1631 	subb	a,r4
      008C80 E9               [12] 1632 	mov	a,r1
      008C81 9D               [12] 1633 	subb	a,r5
      008C82 40 04            [24] 1634 	jc	00114$
      008C84 8C 00            [24] 1635 	mov	ar0,r4
      008C86 8D 01            [24] 1636 	mov	ar1,r5
      008C88                       1637 00114$:
      008C88 90 0B 6B         [24] 1638 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008C8B E8               [12] 1639 	mov	a,r0
      008C8C F0               [24] 1640 	movx	@dptr,a
      008C8D                       1641 00104$:
                                   1642 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008C8D 90 0B 6B         [24] 1643 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008C90 E0               [24] 1644 	movx	a,@dptr
      008C91 F5 2D            [12] 1645 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008C93 E0               [24] 1646 	movx	a,@dptr
      008C94 60 42            [24] 1647 	jz	00106$
      008C96 C0 04            [24] 1648 	push	ar4
      008C98 C0 05            [24] 1649 	push	ar5
      008C9A 8E 00            [24] 1650 	mov	ar0,r6
      008C9C 8F 05            [24] 1651 	mov	ar5,r7
      008C9E 90 0B 69         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008CA1 E0               [24] 1653 	movx	a,@dptr
      008CA2 F9               [12] 1654 	mov	r1,a
      008CA3 A3               [24] 1655 	inc	dptr
      008CA4 E0               [24] 1656 	movx	a,@dptr
      008CA5 FC               [12] 1657 	mov	r4,a
      008CA6 EA               [12] 1658 	mov	a,r2
      008CA7 29               [12] 1659 	add	a, r1
      008CA8 FA               [12] 1660 	mov	r2,a
      008CA9 EB               [12] 1661 	mov	a,r3
      008CAA 3C               [12] 1662 	addc	a, r4
      008CAB FB               [12] 1663 	mov	r3,a
      008CAC 90 05 DB         [24] 1664 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008CAF EA               [12] 1665 	mov	a,r2
      008CB0 F0               [24] 1666 	movx	@dptr,a
      008CB1 EB               [12] 1667 	mov	a,r3
      008CB2 12 38 70         [24] 1668 	lcall	_ak820_outline_0093
      008CB5 90 05 DE         [24] 1669 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008CB8 E5 2D            [12] 1670 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008CBA 12 38 A1         [24] 1671 	lcall	_ak820_outline_0135
      008CBD 88 82            [24] 1672 	mov	dpl, r0
      008CBF 8D 83            [24] 1673 	mov	dph, r5
      008CC1 C0 07            [24] 1674 	push	ar7
      008CC3 C0 06            [24] 1675 	push	ar6
      008CC5 C0 05            [24] 1676 	push	ar5
      008CC7 C0 04            [24] 1677 	push	ar4
      008CC9 12 43 FE         [24] 1678 	lcall	_ak820_eeprom_read_block_xdata
      008CCC D0 04            [24] 1679 	pop	ar4
      008CCE D0 05            [24] 1680 	pop	ar5
      008CD0 D0 06            [24] 1681 	pop	ar6
      008CD2 D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CD4 D0 05            [24] 1684 	pop	ar5
      008CD6 D0 04            [24] 1685 	pop	ar4
                                   1686 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008CD8                       1687 00106$:
                                   1688 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CD8 90 0B 6B         [24] 1689 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008CDB E0               [24] 1690 	movx	a,@dptr
      008CDC FB               [12] 1691 	mov	r3,a
      008CDD                       1692 00109$:
      008CDD 8B 01            [24] 1693 	mov	ar1,r3
      008CDF 7A 00            [12] 1694 	mov	r2,#0x00
      008CE1 C3               [12] 1695 	clr	c
      008CE2 E9               [12] 1696 	mov	a,r1
      008CE3 9C               [12] 1697 	subb	a,r4
      008CE4 EA               [12] 1698 	mov	a,r2
      008CE5 9D               [12] 1699 	subb	a,r5
      008CE6 50 09            [24] 1700 	jnc	00111$
      008CE8 EB               [12] 1701 	mov	a,r3
      008CE9 12 38 31         [24] 1702 	lcall	_ak820_outline_0021
      008CEC E4               [12] 1703 	clr	a
      008CED F0               [24] 1704 	movx	@dptr,a
      008CEE 0B               [12] 1705 	inc	r3
      008CEF 80 EC            [24] 1706 	sjmp	00109$
      008CF1                       1707 00111$:
                                   1708 ;	quantum/dynamic_keymap.c:420: }
      008CF1 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1712 ;------------------------------------------------------------
                                   1713 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1714 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1715 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function dynamic_keymap_get_buffer
                                   1720 ;	-----------------------------------------
      008CF2                       1721 _dynamic_keymap_get_buffer:
      008CF2 12 38 82         [24] 1722 	lcall	_ak820_outline_0108
      008CF5 90 0B 71         [24] 1723 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008CF8 12 38 87         [24] 1724 	lcall	_ak820_outline_0109
                                   1725 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008CFB 90 0B 71         [24] 1726 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008CFE 12 38 41         [24] 1727 	lcall	_ak820_outline_0052
      008D01 90 0B 6C         [24] 1728 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008D04 12 38 58         [24] 1729 	lcall	_ak820_outline_0059
      008D07 90 0B 6E         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008D0A 12 52 97         [24] 1731 	lcall	_ak820_outline_0091
      008D0D 90 0B 60         [24] 1732 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D10 E4               [12] 1733 	clr	a
      008D11 F0               [24] 1734 	movx	@dptr,a
      008D12 74 06            [12] 1735 	mov	a,#0x06
      008D14 A3               [24] 1736 	inc	dptr
      008D15 F0               [24] 1737 	movx	@dptr,a
      008D16 90 0B 62         [24] 1738 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D19 12 4B E2         [24] 1739 	lcall	_ak820_outline_0058
      008D1C 90 0B 64         [24] 1740 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D1F 12 38 5E         [24] 1741 	lcall	_ak820_outline_0072
      008D22 90 0B 66         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D25 E9               [12] 1743 	mov	a,r1
      008D26 12 52 B0         [24] 1744 	lcall	_ak820_outline_0155
      008D29 F0               [24] 1745 	movx	@dptr,a
      008D2A 90 00 40         [24] 1746 	mov	dptr,#0x0040
                                   1747 ;	quantum/dynamic_keymap.c:448: }
      008D2D 02 8C 3C         [24] 1748 	ljmp	_ak820_dynamic_read_buffer
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1751 ;------------------------------------------------------------
                                   1752 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1753 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1754 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1755 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1756 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1757 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1758 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1759 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1760 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1761 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1762 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1763 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1764 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1766 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1767 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function dynamic_keymap_set_buffer
                                   1772 ;	-----------------------------------------
      008D30                       1773 _dynamic_keymap_set_buffer:
      008D30 12 38 82         [24] 1774 	lcall	_ak820_outline_0108
      008D33 90 0B 78         [24] 1775 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008D36 12 38 87         [24] 1776 	lcall	_ak820_outline_0109
                                   1777 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008D39 90 0B 78         [24] 1778 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008D3C 12 4B 86         [24] 1779 	lcall	_ak820_outline_0009
      008D3F 74 40            [12] 1780 	mov	a,#0x40
      008D41 2C               [12] 1781 	add	a, r4
      008D42 FA               [12] 1782 	mov	r2,a
      008D43 E4               [12] 1783 	clr	a
      008D44 3D               [12] 1784 	addc	a, r5
      008D45 FB               [12] 1785 	mov	r3,a
                                   1786 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D46 90 0B 75         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008D49 12 38 7C         [24] 1788 	lcall	_ak820_outline_0103
                                   1789 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008D4C 90 0B 73         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008D4F E0               [24] 1791 	movx	a,@dptr
      008D50 F5 2E            [12] 1792 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008D52 A3               [24] 1793 	inc	dptr
      008D53 E0               [24] 1794 	movx	a,@dptr
      008D54 F5 2F            [12] 1795 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008D56 E5 2E            [12] 1796 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D58 45 2F            [12] 1797 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D5A 70 01            [24] 1798 	jnz	00102$
      008D5C 22               [24] 1799 	ret
      008D5D                       1800 00102$:
                                   1801 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008D5D 85 2E 30         [24] 1802 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008D60 85 2F 31         [24] 1803 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D63 C3               [12] 1804 	clr	c
      008D64 74 1C            [12] 1805 	mov	a,#0x1c
      008D66 95 30            [12] 1806 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008D68 E4               [12] 1807 	clr	a
      008D69 95 31            [12] 1808 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008D6B 50 01            [24] 1809 	jnc	00104$
                                   1810 ;	free result
      008D6D 22               [24] 1811 	ret
      008D6E                       1812 00104$:
                                   1813 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008D6E 85 2E 32         [24] 1814 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1815 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008D71 74 FA            [12] 1816 	mov	a,#0x100 - 0x06
      008D73 2F               [12] 1817 	add	a,r7
      008D74 40 11            [24] 1818 	jc	00105$
      008D76 E4               [12] 1819 	clr	a
      008D77 C3               [12] 1820 	clr	c
      008D78 9E               [12] 1821 	subb	a,r6
      008D79 FE               [12] 1822 	mov	r6,a
      008D7A 74 06            [12] 1823 	mov	a,#0x06
      008D7C 9F               [12] 1824 	subb	a,r7
      008D7D FF               [12] 1825 	mov	r7,a
      008D7E C3               [12] 1826 	clr	c
      008D7F EE               [12] 1827 	mov	a,r6
      008D80 95 2E            [12] 1828 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D82 EF               [12] 1829 	mov	a,r7
      008D83 95 2F            [12] 1830 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D85 50 01            [24] 1831 	jnc	00106$
      008D87                       1832 00105$:
                                   1833 ;	quantum/dynamic_keymap.c:466: return;
      008D87 22               [24] 1834 	ret
      008D88                       1835 00106$:
                                   1836 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008D88 90 0E 76         [24] 1837 	mov	dptr,#_vial_unlocked
      008D8B E0               [24] 1838 	movx	a,@dptr
      008D8C 60 03            [24] 1839 	jz	00207$
      008D8E 02 8E 9A         [24] 1840 	ljmp	00120$
      008D91                       1841 00207$:
                                   1842 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008D91 90 0B 7A         [24] 1843 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008D94 E4               [12] 1844 	clr	a
      008D95 F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008D96 90 0B 7B         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008D99 E5 32            [12] 1848 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D9B F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008D9C EC               [12] 1851 	mov	a,r4
      008D9D 30 E0 31         [24] 1852 	jnb	acc.0,00111$
                                   1853 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008DA0 EA               [12] 1854 	mov	a,r2
      008DA1 24 FF            [12] 1855 	add	a,#0xff
      008DA3 FE               [12] 1856 	mov	r6,a
      008DA4 EB               [12] 1857 	mov	a,r3
      008DA5 34 FF            [12] 1858 	addc	a,#0xff
      008DA7 FF               [12] 1859 	mov	r7,a
      008DA8 7D 00            [12] 1860 	mov	r5,#0x00
      008DAA 12 73 0C         [24] 1861 	lcall	_ak820_outline_0064
      008DAD 12 43 C3         [24] 1862 	lcall	_eeprom_read_byte
      008DB0 AE 82            [24] 1863 	mov	r6,dpl
      008DB2 7F 00            [12] 1864 	mov	r7,#0x00
      008DB4 12 38 B1         [24] 1865 	lcall	_ak820_outline_0144
      008DB7 E0               [24] 1866 	movx	a,@dptr
      008DB8 7C 00            [12] 1867 	mov	r4,#0x00
      008DBA 42 07            [12] 1868 	orl	ar7,a
      008DBC EC               [12] 1869 	mov	a,r4
      008DBD 42 06            [12] 1870 	orl	ar6,a
                                   1871 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008DBF BF 00 09         [24] 1872 	cjne	r7,#0x00,00109$
      008DC2 BE 7C 06         [24] 1873 	cjne	r6,#0x7c,00109$
                                   1874 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008DC5 12 38 B1         [24] 1875 	lcall	_ak820_outline_0144
      008DC8 74 FF            [12] 1876 	mov	a,#0xff
      008DCA F0               [24] 1877 	movx	@dptr,a
      008DCB                       1878 00109$:
                                   1879 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008DCB 90 0B 7A         [24] 1880 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008DCE 74 01            [12] 1881 	mov	a,#0x01
      008DD0 F0               [24] 1882 	movx	@dptr,a
      008DD1                       1883 00111$:
                                   1884 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008DD1 90 0B 78         [24] 1885 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008DD4 12 38 41         [24] 1886 	lcall	_ak820_outline_0052
      008DD7 E5 2E            [12] 1887 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008DD9 2E               [12] 1888 	add	a, r6
      008DDA FE               [12] 1889 	mov	r6,a
      008DDB E5 2F            [12] 1890 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DDD 3F               [12] 1891 	addc	a, r7
      008DDE EE               [12] 1892 	mov	a,r6
      008DDF 30 E0 5A         [24] 1893 	jnb	acc.0,00115$
                                   1894 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008DE2 AE 32            [24] 1895 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008DE4 7F 00            [12] 1896 	mov	r7,#0x00
      008DE6 EE               [12] 1897 	mov	a,r6
      008DE7 24 FF            [12] 1898 	add	a,#0xff
      008DE9 FC               [12] 1899 	mov	r4,a
      008DEA EF               [12] 1900 	mov	a,r7
      008DEB 34 FF            [12] 1901 	addc	a,#0xff
      008DED FD               [12] 1902 	mov	r5,a
      008DEE EC               [12] 1903 	mov	a,r4
      008DEF 28               [12] 1904 	add	a, r0
      008DF0 F5 82            [12] 1905 	mov	dpl,a
      008DF2 ED               [12] 1906 	mov	a,r5
      008DF3 39               [12] 1907 	addc	a, r1
      008DF4 F5 83            [12] 1908 	mov	dph,a
      008DF6 E0               [24] 1909 	movx	a,@dptr
      008DF7 FC               [12] 1910 	mov	r4,a
      008DF8 7D 00            [12] 1911 	mov	r5,#0x00
      008DFA E5 32            [12] 1912 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008DFC 2A               [12] 1913 	add	a, r2
      008DFD FA               [12] 1914 	mov	r2,a
      008DFE E4               [12] 1915 	clr	a
      008DFF 3B               [12] 1916 	addc	a, r3
      008E00 FB               [12] 1917 	mov	r3,a
      008E01 C0 00            [24] 1918 	push	ar0
      008E03 C0 01            [24] 1919 	push	ar1
      008E05 8B 01            [24] 1920 	mov	ar1,r3
      008E07 7B 00            [12] 1921 	mov	r3,#0x00
      008E09 8A 82            [24] 1922 	mov	dpl, r2
      008E0B 89 83            [24] 1923 	mov	dph, r1
      008E0D 8B F0            [24] 1924 	mov	b, r3
      008E0F 12 43 C3         [24] 1925 	lcall	_eeprom_read_byte
      008E12 AB 82            [24] 1926 	mov	r3, dpl
      008E14 7A 00            [12] 1927 	mov	r2,#0x00
      008E16 EB               [12] 1928 	mov	a,r3
      008E17 12 46 AF         [24] 1929 	lcall	_ak820_outline_0143
                                   1930 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008E1A BD 00 05         [24] 1931 	cjne	r5,#0x00,00212$
      008E1D BC 7C 02         [24] 1932 	cjne	r4,#0x7c,00212$
      008E20 80 06            [24] 1933 	sjmp	00213$
      008E22                       1934 00212$:
      008E22 D0 01            [24] 1935 	pop	ar1
      008E24 D0 00            [24] 1936 	pop	ar0
      008E26 80 0D            [24] 1937 	sjmp	00113$
      008E28                       1938 00213$:
      008E28 D0 01            [24] 1939 	pop	ar1
      008E2A D0 00            [24] 1940 	pop	ar0
                                   1941 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008E2C 1E               [12] 1942 	dec	r6
      008E2D BE FF 01         [24] 1943 	cjne	r6,#0xff,00214$
      008E30 1F               [12] 1944 	dec	r7
      008E31                       1945 00214$:
      008E31 EE               [12] 1946 	mov	a,r6
      008E32 12 92 D3         [24] 1947 	lcall	_ak820_outline_0129
      008E35                       1948 00113$:
                                   1949 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008E35 E5 32            [12] 1950 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E37 14               [12] 1951 	dec	a
      008E38 90 0B 7B         [24] 1952 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008E3B F0               [24] 1953 	movx	@dptr,a
      008E3C                       1954 00115$:
                                   1955 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E3C 90 0B 7A         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008E3F E0               [24] 1957 	movx	a,@dptr
      008E40 90 0B 7C         [24] 1958 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008E43 F0               [24] 1959 	movx	@dptr,a
      008E44                       1960 00122$:
      008E44 90 0B 7C         [24] 1961 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008E47 E0               [24] 1962 	movx	a,@dptr
      008E48 FF               [12] 1963 	mov	r7,a
      008E49 90 0B 7B         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008E4C E0               [24] 1965 	movx	a,@dptr
      008E4D FE               [12] 1966 	mov	r6,a
      008E4E C3               [12] 1967 	clr	c
      008E4F EF               [12] 1968 	mov	a,r7
      008E50 9E               [12] 1969 	subb	a,r6
      008E51 50 47            [24] 1970 	jnc	00120$
                                   1971 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008E53 EF               [12] 1972 	mov	a,r7
      008E54 28               [12] 1973 	add	a, r0
      008E55 FD               [12] 1974 	mov	r5,a
      008E56 E4               [12] 1975 	clr	a
      008E57 39               [12] 1976 	addc	a, r1
      008E58 12 4B DA         [24] 1977 	lcall	_ak820_outline_0057
      008E5B 7B 00            [12] 1978 	mov	r3,#0x00
      008E5D 8C 2F            [24] 1979 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008E5F 8B 2E            [24] 1980 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008E61 8F 02            [24] 1981 	mov	ar2,r7
      008E63 7F 00            [12] 1982 	mov	r7,#0x00
      008E65 74 01            [12] 1983 	mov	a,#0x01
      008E67 2A               [12] 1984 	add	a, r2
      008E68 FB               [12] 1985 	mov	r3,a
      008E69 E4               [12] 1986 	clr	a
      008E6A 3F               [12] 1987 	addc	a, r7
      008E6B FC               [12] 1988 	mov	r4,a
      008E6C EB               [12] 1989 	mov	a,r3
      008E6D 28               [12] 1990 	add	a, r0
      008E6E F5 82            [12] 1991 	mov	dpl,a
      008E70 EC               [12] 1992 	mov	a,r4
      008E71 39               [12] 1993 	addc	a, r1
      008E72 F5 83            [12] 1994 	mov	dph,a
      008E74 E0               [24] 1995 	movx	a,@dptr
      008E75 FC               [12] 1996 	mov	r4,a
      008E76 7B 00            [12] 1997 	mov	r3,#0x00
      008E78 E5 2F            [12] 1998 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E7A 42 03            [12] 1999 	orl	ar3,a
                                   2000 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008E7C BC 00 12         [24] 2001 	cjne	r4,#0x00,00123$
      008E7F BB 7C 0F         [24] 2002 	cjne	r3,#0x7c,00123$
                                   2003 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008E82 12 38 9C         [24] 2004 	lcall	_ak820_outline_0134
      008E85 74 FF            [12] 2005 	mov	a,#0xff
      008E87 F0               [24] 2006 	movx	@dptr,a
                                   2007 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008E88 0A               [12] 2008 	inc	r2
      008E89 BA 00 01         [24] 2009 	cjne	r2,#0x00,00218$
      008E8C 0F               [12] 2010 	inc	r7
      008E8D                       2011 00218$:
      008E8D EA               [12] 2012 	mov	a,r2
      008E8E 12 92 D3         [24] 2013 	lcall	_ak820_outline_0129
      008E91                       2014 00123$:
                                   2015 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E91 90 0B 7C         [24] 2016 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008E94 E0               [24] 2017 	movx	a,@dptr
      008E95 24 02            [12] 2018 	add	a,#0x02
      008E97 F0               [24] 2019 	movx	@dptr,a
      008E98 80 AA            [24] 2020 	sjmp	00122$
      008E9A                       2021 00120$:
                                   2022 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008E9A 90 0B 78         [24] 2023 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008E9D 12 38 41         [24] 2024 	lcall	_ak820_outline_0052
      008EA0 74 40            [12] 2025 	mov	a,#0x40
      008EA2 12 46 A9         [24] 2026 	lcall	_ak820_outline_0138
      008EA5 90 05 E4         [24] 2027 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008EA8 12 4B E2         [24] 2028 	lcall	_ak820_outline_0058
      008EAB E4               [12] 2029 	clr	a
      008EAC A3               [24] 2030 	inc	dptr
      008EAD F0               [24] 2031 	movx	@dptr,a
      008EAE 90 05 E7         [24] 2032 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008EB1 E5 30            [12] 2033 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008EB3 F0               [24] 2034 	movx	@dptr,a
      008EB4 E5 31            [12] 2035 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008EB6 A3               [24] 2036 	inc	dptr
      008EB7 F0               [24] 2037 	movx	@dptr,a
      008EB8 12 38 B1         [24] 2038 	lcall	_ak820_outline_0144
                                   2039 ;	quantum/dynamic_keymap.c:521: }
      008EBB 02 44 8A         [24] 2040 	ljmp	_ak820_eeprom_write_block_xdata
                                   2041 ;------------------------------------------------------------
                                   2042 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2043 ;------------------------------------------------------------
                                   2044 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2045 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2046 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2047 ;------------------------------------------------------------
                                   2048 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2049 ;	-----------------------------------------
                                   2050 ;	 function keycode_at_keymap_location
                                   2051 ;	-----------------------------------------
      008EBE                       2052 _keycode_at_keymap_location:
      008EBE E5 82            [12] 2053 	mov	a,dpl
      008EC0 90 0B 7F         [24] 2054 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008EC3 F0               [24] 2055 	movx	@dptr,a
                                   2056 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008EC4 E0               [24] 2057 	movx	a,@dptr
      008EC5 FF               [12] 2058 	mov	r7,a
      008EC6 BF 06 00         [24] 2059 	cjne	r7,#0x06,00128$
      008EC9                       2060 00128$:
      008EC9 50 23            [24] 2061 	jnc	00102$
      008ECB 90 0B 7D         [24] 2062 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008ECE E0               [24] 2063 	movx	a,@dptr
      008ECF FE               [12] 2064 	mov	r6,a
      008ED0 BE 10 00         [24] 2065 	cjne	r6,#0x10,00130$
      008ED3                       2066 00130$:
      008ED3 50 19            [24] 2067 	jnc	00102$
      008ED5 90 0B 7E         [24] 2068 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008ED8 E0               [24] 2069 	movx	a,@dptr
      008ED9 FD               [12] 2070 	mov	r5,a
      008EDA BD 08 00         [24] 2071 	cjne	r5,#0x08,00132$
      008EDD                       2072 00132$:
      008EDD 50 0F            [24] 2073 	jnc	00102$
                                   2074 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008EDF 90 0B 31         [24] 2075 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008EE2 EE               [12] 2076 	mov	a,r6
      008EE3 F0               [24] 2077 	movx	@dptr,a
      008EE4 90 0B 32         [24] 2078 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008EE7 ED               [12] 2079 	mov	a,r5
      008EE8 F0               [24] 2080 	movx	@dptr,a
      008EE9 8F 82            [24] 2081 	mov	dpl, r7
      008EEB 02 88 60         [24] 2082 	ljmp	_dynamic_keymap_get_keycode
      008EEE                       2083 00102$:
                                   2084 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008EEE 90 00 00         [24] 2085 	mov	dptr,#0x0000
                                   2086 ;	quantum/dynamic_keymap.c:528: }
      008EF1 22               [24] 2087 	ret
                                   2088 ;------------------------------------------------------------
                                   2089 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2090 ;------------------------------------------------------------
                                   2091 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2092 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2093 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2094 ;------------------------------------------------------------
                                   2095 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2096 ;	-----------------------------------------
                                   2097 ;	 function keycode_at_encodermap_location
                                   2098 ;	-----------------------------------------
      008EF2                       2099 _keycode_at_encodermap_location:
      008EF2 E5 82            [12] 2100 	mov	a,dpl
      008EF4 90 0B 82         [24] 2101 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008EF7 F0               [24] 2102 	movx	@dptr,a
                                   2103 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008EF8 E0               [24] 2104 	movx	a,@dptr
      008EF9 FF               [12] 2105 	mov	r7,a
      008EFA BF 06 00         [24] 2106 	cjne	r7,#0x06,00120$
      008EFD                       2107 00120$:
      008EFD 50 1E            [24] 2108 	jnc	00102$
      008EFF 90 0B 80         [24] 2109 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008F02 E0               [24] 2110 	movx	a,@dptr
      008F03 FE               [12] 2111 	mov	r6,a
      008F04 BE 01 00         [24] 2112 	cjne	r6,#0x01,00122$
      008F07                       2113 00122$:
      008F07 50 14            [24] 2114 	jnc	00102$
                                   2115 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008F09 90 0B 81         [24] 2116 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008F0C E0               [24] 2117 	movx	a,@dptr
      008F0D FE               [12] 2118 	mov	r6,a
      008F0E 90 0B 3B         [24] 2119 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008F11 E4               [12] 2120 	clr	a
      008F12 F0               [24] 2121 	movx	@dptr,a
      008F13 90 0B 3C         [24] 2122 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008F16 EE               [12] 2123 	mov	a,r6
      008F17 F0               [24] 2124 	movx	@dptr,a
      008F18 8F 82            [24] 2125 	mov	dpl, r7
      008F1A 02 89 1F         [24] 2126 	ljmp	_dynamic_keymap_get_encoder
      008F1D                       2127 00102$:
                                   2128 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008F1D 90 00 00         [24] 2129 	mov	dptr,#0x0000
                                   2130 ;	quantum/dynamic_keymap.c:536: }
      008F20 22               [24] 2131 	ret
                                   2132 ;------------------------------------------------------------
                                   2133 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2134 ;------------------------------------------------------------
                                   2135 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2136 ;	-----------------------------------------
                                   2137 ;	 function dynamic_keymap_macro_get_count
                                   2138 ;	-----------------------------------------
      008F21                       2139 _dynamic_keymap_macro_get_count:
                                   2140 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008F21 75 82 10         [24] 2141 	mov	dpl, #0x10
                                   2142 ;	quantum/dynamic_keymap.c:541: }
      008F24 22               [24] 2143 	ret
                                   2144 ;------------------------------------------------------------
                                   2145 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2146 ;------------------------------------------------------------
                                   2147 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2148 ;	-----------------------------------------
                                   2149 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2150 ;	-----------------------------------------
      008F25                       2151 _dynamic_keymap_macro_get_buffer_size:
                                   2152 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008F25 90 20 00         [24] 2153 	mov	dptr,#0x2000
                                   2154 ;	quantum/dynamic_keymap.c:545: }
      008F28 22               [24] 2155 	ret
                                   2156 ;------------------------------------------------------------
                                   2157 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2158 ;------------------------------------------------------------
                                   2159 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2160 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2161 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2162 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2163 ;------------------------------------------------------------
                                   2164 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2165 ;	-----------------------------------------
                                   2166 ;	 function dynamic_keymap_macro_get_buffer
                                   2167 ;	-----------------------------------------
      008F29                       2168 _dynamic_keymap_macro_get_buffer:
      008F29 12 38 82         [24] 2169 	lcall	_ak820_outline_0108
      008F2C 90 0B 88         [24] 2170 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008F2F 12 38 87         [24] 2171 	lcall	_ak820_outline_0109
                                   2172 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008F32 12 2B 2B         [24] 2173 	lcall	_ak820_macro_length
      008F35 12 46 A4         [24] 2174 	lcall	_ak820_outline_0125
      008F38 90 0B 88         [24] 2175 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008F3B 12 38 58         [24] 2176 	lcall	_ak820_outline_0059
      008F3E 90 0B 83         [24] 2177 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008F41 E0               [24] 2178 	movx	a,@dptr
      008F42 F5 33            [12] 2179 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008F44 A3               [24] 2180 	inc	dptr
      008F45 E0               [24] 2181 	movx	a,@dptr
      008F46 F5 34            [12] 2182 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008F48 90 0B 85         [24] 2183 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008F4B 12 38 7C         [24] 2184 	lcall	_ak820_outline_0103
      008F4E A3               [24] 2185 	inc	dptr
      008F4F E0               [24] 2186 	movx	a,@dptr
      008F50 FB               [12] 2187 	mov	r3,a
      008F51 90 0B 60         [24] 2188 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F54 12 4B E2         [24] 2189 	lcall	_ak820_outline_0058
      008F57 90 0B 62         [24] 2190 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F5A 12 38 5E         [24] 2191 	lcall	_ak820_outline_0072
      008F5D 90 0B 64         [24] 2192 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008F60 E5 33            [12] 2193 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008F62 F0               [24] 2194 	movx	@dptr,a
      008F63 E5 34            [12] 2195 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008F65 A3               [24] 2196 	inc	dptr
      008F66 F0               [24] 2197 	movx	@dptr,a
      008F67 90 0B 66         [24] 2198 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008F6A E8               [12] 2199 	mov	a,r0
      008F6B F0               [24] 2200 	movx	@dptr,a
      008F6C E9               [12] 2201 	mov	a,r1
      008F6D A3               [24] 2202 	inc	dptr
      008F6E 12 7B 8D         [24] 2203 	lcall	_ak820_outline_0186
      008F71 90 08 00         [24] 2204 	mov	dptr,#0x0800
                                   2205 ;	quantum/dynamic_keymap.c:572: }
      008F74 02 8C 3C         [24] 2206 	ljmp	_ak820_dynamic_read_buffer
                                   2207 ;------------------------------------------------------------
                                   2208 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2209 ;------------------------------------------------------------
                                   2210 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2211 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2212 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2213 ;------------------------------------------------------------
                                   2214 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2215 ;	-----------------------------------------
                                   2216 ;	 function dynamic_keymap_macro_set_buffer
                                   2217 ;	-----------------------------------------
      008F77                       2218 _dynamic_keymap_macro_set_buffer:
      008F77 12 38 82         [24] 2219 	lcall	_ak820_outline_0108
      008F7A 90 0B 8F         [24] 2220 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008F7D 12 38 87         [24] 2221 	lcall	_ak820_outline_0109
                                   2222 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008F80 90 0B 8F         [24] 2223 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008F83 12 38 41         [24] 2224 	lcall	_ak820_outline_0052
      008F86 90 0B 8A         [24] 2225 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008F89 12 38 58         [24] 2226 	lcall	_ak820_outline_0059
      008F8C 90 0B 8C         [24] 2227 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008F8F 12 52 97         [24] 2228 	lcall	_ak820_outline_0091
      008F92 90 05 6A         [24] 2229 	mov	dptr,#_ak820_macro_write_PARM_2
      008F95 12 38 5E         [24] 2230 	lcall	_ak820_outline_0072
      008F98 90 05 6C         [24] 2231 	mov	dptr,#_ak820_macro_write_PARM_3
      008F9B E9               [12] 2232 	mov	a,r1
      008F9C 12 52 B0         [24] 2233 	lcall	_ak820_outline_0155
      008F9F 12 46 86         [24] 2234 	lcall	_ak820_outline_0071
                                   2235 ;	quantum/dynamic_keymap.c:577: }
      008FA2 02 2B 45         [24] 2236 	ljmp	_ak820_macro_write
                                   2237 ;------------------------------------------------------------
                                   2238 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2239 ;------------------------------------------------------------
                                   2240 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2241 ;	-----------------------------------------
                                   2242 ;	 function dynamic_keymap_macro_reset
                                   2243 ;	-----------------------------------------
      008FA5                       2244 _dynamic_keymap_macro_reset:
                                   2245 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2246 ;	quantum/dynamic_keymap.c:603: }
      008FA5 02 2E 64         [24] 2247 	ljmp	_ak820_macro_reset
                                   2248 ;------------------------------------------------------------
                                   2249 ;Allocation info for local variables in function 'decode_keycode'
                                   2250 ;------------------------------------------------------------
                                   2251 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2252 ;------------------------------------------------------------
                                   2253 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2254 ;	-----------------------------------------
                                   2255 ;	 function decode_keycode
                                   2256 ;	-----------------------------------------
      008FA8                       2257 _decode_keycode:
      008FA8 12 38 82         [24] 2258 	lcall	_ak820_outline_0108
      008FAB 90 0B 91         [24] 2259 	mov	dptr,#_decode_keycode_kc_10000_455
      008FAE 12 38 87         [24] 2260 	lcall	_ak820_outline_0109
                                   2261 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008FB1 90 0B 91         [24] 2262 	mov	dptr,#_decode_keycode_kc_10000_455
      008FB4 12 4B 86         [24] 2263 	lcall	_ak820_outline_0009
      008FB7 C3               [12] 2264 	clr	c
      008FB8 E4               [12] 2265 	clr	a
      008FB9 9C               [12] 2266 	subb	a,r4
      008FBA 74 FF            [12] 2267 	mov	a,#0xff
      008FBC 9D               [12] 2268 	subb	a,r5
      008FBD 50 08            [24] 2269 	jnc	00102$
                                   2270 ;	free result
                                   2271 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008FBF 8C 05            [24] 2272 	mov	ar5,r4
      008FC1 7C 00            [12] 2273 	mov	r4,#0x00
      008FC3 12 38 97         [24] 2274 	lcall	_ak820_outline_0124
      008FC6 22               [24] 2275 	ret
      008FC7                       2276 00102$:
                                   2277 ;	quantum/dynamic_keymap.c:609: return kc;
      008FC7 12 38 8C         [24] 2278 	lcall	_ak820_outline_0118
                                   2279 ;	quantum/dynamic_keymap.c:610: }
      008FCA 22               [24] 2280 	ret
                                   2281 ;------------------------------------------------------------
                                   2282 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2283 ;------------------------------------------------------------
                                   2284 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2285 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2286 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2287 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2288 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2289 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2290 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2291 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2292 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2293 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2294 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2295 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2296 ;------------------------------------------------------------
                                   2297 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2298 ;	-----------------------------------------
                                   2299 ;	 function dynamic_keymap_macro_send
                                   2300 ;	-----------------------------------------
      008FCB                       2301 _dynamic_keymap_macro_send:
      008FCB E5 82            [12] 2302 	mov	a,dpl
      008FCD 90 0B 93         [24] 2303 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008FD0 F0               [24] 2304 	movx	@dptr,a
                                   2305 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008FD1 90 0B 94         [24] 2306 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008FD4 E0               [24] 2307 	movx	a,@dptr
      008FD5 60 01            [24] 2308 	jz	00102$
      008FD7 22               [24] 2309 	ret
      008FD8                       2310 00102$:
                                   2311 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008FD8 90 0B 93         [24] 2312 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008FDB E0               [24] 2313 	movx	a,@dptr
      008FDC FF               [12] 2314 	mov	r7,a
      008FDD BF 10 00         [24] 2315 	cjne	r7,#0x10,00422$
      008FE0                       2316 00422$:
      008FE0 40 01            [24] 2317 	jc	00104$
                                   2318 ;	quantum/dynamic_keymap.c:620: return;
      008FE2 22               [24] 2319 	ret
      008FE3                       2320 00104$:
                                   2321 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008FE3 C0 07            [24] 2322 	push	ar7
      008FE5 12 2A F2         [24] 2323 	lcall	_ak820_macro_ready
      008FE8 E5 82            [12] 2324 	mov	a, dpl
      008FEA D0 07            [24] 2325 	pop	ar7
      008FEC 70 01            [24] 2326 	jnz	00106$
      008FEE 22               [24] 2327 	ret
      008FEF                       2328 00106$:
                                   2329 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008FEF 90 0B 95         [24] 2330 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008FF2 E4               [12] 2331 	clr	a
      008FF3 F0               [24] 2332 	movx	@dptr,a
      008FF4 74 08            [12] 2333 	mov	a,#0x08
      008FF6 A3               [24] 2334 	inc	dptr
      008FF7 F0               [24] 2335 	movx	@dptr,a
                                   2336 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008FF8 C0 07            [24] 2337 	push	ar7
      008FFA 12 2B 2B         [24] 2338 	lcall	_ak820_macro_length
      008FFD AD 82            [24] 2339 	mov	r5, dpl
      008FFF AE 83            [24] 2340 	mov	r6, dph
      009001 D0 07            [24] 2341 	pop	ar7
      009003 74 08            [12] 2342 	mov	a,#0x08
      009005 2E               [12] 2343 	add	a, r6
      009006 FE               [12] 2344 	mov	r6,a
                                   2345 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      009007 7B 00            [12] 2346 	mov	r3,#0x00
      009009 7C 08            [12] 2347 	mov	r4,#0x08
      00900B                       2348 00111$:
      00900B EF               [12] 2349 	mov	a,r7
      00900C 60 31            [24] 2350 	jz	00113$
                                   2351 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      00900E EB               [12] 2352 	mov	a,r3
      00900F B5 05 05         [24] 2353 	cjne	a,ar5,00108$
      009012 EC               [12] 2354 	mov	a,r4
      009013 B5 06 01         [24] 2355 	cjne	a,ar6,00108$
                                   2356 ;	quantum/dynamic_keymap.c:654: return;
      009016 22               [24] 2357 	ret
      009017                       2358 00108$:
                                   2359 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      009017 8B 01            [24] 2360 	mov	ar1,r3
      009019 8C 02            [24] 2361 	mov	ar2,r4
      00901B 8A 00            [24] 2362 	mov	ar0,r2
      00901D 7A 00            [12] 2363 	mov	r2,#0x00
      00901F 89 82            [24] 2364 	mov	dpl, r1
      009021 88 83            [24] 2365 	mov	dph, r0
      009023 8A F0            [24] 2366 	mov	b, r2
      009025 12 43 C3         [24] 2367 	lcall	_eeprom_read_byte
      009028 E5 82            [12] 2368 	mov	a, dpl
      00902A 70 06            [24] 2369 	jnz	00110$
                                   2370 ;	quantum/dynamic_keymap.c:657: --id;
      00902C 1F               [12] 2371 	dec	r7
      00902D 90 0B 93         [24] 2372 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      009030 EF               [12] 2373 	mov	a,r7
      009031 F0               [24] 2374 	movx	@dptr,a
      009032                       2375 00110$:
                                   2376 ;	quantum/dynamic_keymap.c:659: ++p;
      009032 0B               [12] 2377 	inc	r3
      009033 BB 00 01         [24] 2378 	cjne	r3,#0x00,00429$
      009036 0C               [12] 2379 	inc	r4
      009037                       2380 00429$:
      009037 90 0B 95         [24] 2381 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00903A 12 38 64         [24] 2382 	lcall	_ak820_outline_0084
      00903D 80 CC            [24] 2383 	sjmp	00111$
      00903F                       2384 00113$:
                                   2385 ;	quantum/dynamic_keymap.c:665: sending = true;
      00903F 90 0B 94         [24] 2386 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      009042 74 01            [12] 2387 	mov	a,#0x01
      009044 F0               [24] 2388 	movx	@dptr,a
                                   2389 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      009045 12 92 EB         [24] 2390 	lcall	_ak820_outline_0164
      009048 90 09 DD         [24] 2391 	mov	dptr,#_ak820_macro_cancelled
      00904B F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      00904C 90 0B 97         [24] 2394 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00904F F0               [24] 2395 	movx	@dptr,a
      009050 90 0B 98         [24] 2396 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009053 F0               [24] 2397 	movx	@dptr,a
      009054 90 0B 99         [24] 2398 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      009057 F0               [24] 2399 	movx	@dptr,a
      009058 90 0B 9A         [24] 2400 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      00905B F0               [24] 2401 	movx	@dptr,a
                                   2402 ;	quantum/dynamic_keymap.c:675: while (p < end
      00905C                       2403 00167$:
                                   2404 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      00905C 90 0B 95         [24] 2405 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00905F E0               [24] 2406 	movx	a,@dptr
      009060 FC               [12] 2407 	mov	r4,a
      009061 A3               [24] 2408 	inc	dptr
      009062 E0               [24] 2409 	movx	a,@dptr
      009063 FF               [12] 2410 	mov	r7,a
      009064 C3               [12] 2411 	clr	c
      009065 EC               [12] 2412 	mov	a,r4
      009066 9D               [12] 2413 	subb	a,r5
      009067 EF               [12] 2414 	mov	a,r7
      009068 9E               [12] 2415 	subb	a,r6
      009069 40 03            [24] 2416 	jc	00430$
      00906B 02 92 80         [24] 2417 	ljmp	00169$
      00906E                       2418 00430$:
      00906E 90 09 DD         [24] 2419 	mov	dptr,#_ak820_macro_cancelled
      009071 E0               [24] 2420 	movx	a,@dptr
      009072 60 03            [24] 2421 	jz	00431$
      009074 02 92 80         [24] 2422 	ljmp	00169$
      009077                       2423 00431$:
                                   2424 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009077 8C 02            [24] 2425 	mov	ar2,r4
      009079 8F 03            [24] 2426 	mov	ar3,r7
      00907B 90 0B 95         [24] 2427 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00907E 74 01            [12] 2428 	mov	a,#0x01
      009080 2C               [12] 2429 	add	a, r4
      009081 F0               [24] 2430 	movx	@dptr,a
      009082 E4               [12] 2431 	clr	a
      009083 3F               [12] 2432 	addc	a, r7
      009084 A3               [24] 2433 	inc	dptr
      009085 F0               [24] 2434 	movx	@dptr,a
      009086 7F 00            [12] 2435 	mov	r7,#0x00
      009088 12 38 A6         [24] 2436 	lcall	_ak820_outline_0136
      00908B 8F F0            [24] 2437 	mov	b, r7
      00908D 12 43 C3         [24] 2438 	lcall	_eeprom_read_byte
      009090 AF 82            [24] 2439 	mov	r7, dpl
      009092 90 0B 97         [24] 2440 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009095 EF               [12] 2441 	mov	a,r7
      009096 F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      009097 90 0B 98         [24] 2444 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00909A E4               [12] 2445 	clr	a
      00909B F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      00909C 90 0B 97         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00909F E0               [24] 2449 	movx	a,@dptr
      0090A0 70 03            [24] 2450 	jnz	00432$
      0090A2 02 92 80         [24] 2451 	ljmp	00169$
      0090A5                       2452 00432$:
                                   2453 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      0090A5 90 0B 97         [24] 2454 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0090A8 E0               [24] 2455 	movx	a,@dptr
      0090A9 FF               [12] 2456 	mov	r7,a
      0090AA BF 01 02         [24] 2457 	cjne	r7,#0x01,00433$
      0090AD 80 03            [24] 2458 	sjmp	00434$
      0090AF                       2459 00433$:
      0090AF 02 92 62         [24] 2460 	ljmp	00164$
      0090B2                       2461 00434$:
                                   2462 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090B2 12 92 88         [24] 2463 	lcall	_ak820_outline_0000
      0090B5 12 43 C3         [24] 2464 	lcall	_eeprom_read_byte
      0090B8 AF 82            [24] 2465 	mov	r7, dpl
      0090BA 90 0B 98         [24] 2466 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      0090BD EF               [12] 2467 	mov	a,r7
      0090BE F0               [24] 2468 	movx	@dptr,a
                                   2469 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      0090BF EF               [12] 2470 	mov	a,r7
      0090C0 70 03            [24] 2471 	jnz	00435$
      0090C2 02 92 80         [24] 2472 	ljmp	00169$
      0090C5                       2473 00435$:
                                   2474 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0090C5 12 92 B2         [24] 2475 	lcall	_ak820_outline_0094
      0090C8 BF 01 02         [24] 2476 	cjne	r7,#0x01,00436$
      0090CB 80 13            [24] 2477 	sjmp	00151$
      0090CD                       2478 00436$:
      0090CD 12 92 B2         [24] 2479 	lcall	_ak820_outline_0094
      0090D0 BF 02 02         [24] 2480 	cjne	r7,#0x02,00437$
      0090D3 80 0B            [24] 2481 	sjmp	00151$
      0090D5                       2482 00437$:
      0090D5 12 92 B2         [24] 2483 	lcall	_ak820_outline_0094
      0090D8 BF 03 02         [24] 2484 	cjne	r7,#0x03,00438$
      0090DB 80 03            [24] 2485 	sjmp	00439$
      0090DD                       2486 00438$:
      0090DD 02 91 41         [24] 2487 	ljmp	00152$
      0090E0                       2488 00439$:
      0090E0                       2489 00151$:
                                   2490 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090E0 12 92 88         [24] 2491 	lcall	_ak820_outline_0000
      0090E3 12 43 C3         [24] 2492 	lcall	_eeprom_read_byte
      0090E6 12 93 03         [24] 2493 	lcall	_ak820_outline_0180
                                   2494 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      0090E9 70 03            [24] 2495 	jnz	00440$
      0090EB 02 90 5C         [24] 2496 	ljmp	00167$
      0090EE                       2497 00440$:
                                   2498 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0090EE 12 92 B2         [24] 2499 	lcall	_ak820_outline_0094
      0090F1 BF 01 03         [24] 2500 	cjne	r7,#0x01,00441$
      0090F4 D3               [12] 2501 	setb	c
      0090F5 80 01            [24] 2502 	sjmp	00442$
      0090F7                       2503 00441$:
      0090F7 C3               [12] 2504 	clr	c
      0090F8                       2505 00442$:
      0090F8 92 28            [24] 2506 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0090FA 90 09 DC         [24] 2507 	mov	dptr,#_ak820_macro_primitive
      0090FD B3               [12] 2508 	cpl	c
      0090FE E4               [12] 2509 	clr	a
      0090FF 33               [12] 2510 	rlc	a
      009100 F0               [24] 2511 	movx	@dptr,a
                                   2512 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      009101 12 92 B2         [24] 2513 	lcall	_ak820_outline_0094
      009104 BF 01 10         [24] 2514 	cjne	r7,#0x01,00122$
      009107 12 92 E4         [24] 2515 	lcall	_ak820_outline_0151
      00910A C0 06            [24] 2516 	push	ar6
      00910C C0 05            [24] 2517 	push	ar5
      00910E 12 7A 4C         [24] 2518 	lcall	_tap_code
      009111 D0 05            [24] 2519 	pop	ar5
      009113 D0 06            [24] 2520 	pop	ar6
      009115 80 24            [24] 2521 	sjmp	00123$
      009117                       2522 00122$:
                                   2523 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009117 12 92 B2         [24] 2524 	lcall	_ak820_outline_0094
      00911A BF 02 10         [24] 2525 	cjne	r7,#0x02,00119$
      00911D 12 92 E4         [24] 2526 	lcall	_ak820_outline_0151
      009120 C0 06            [24] 2527 	push	ar6
      009122 C0 05            [24] 2528 	push	ar5
      009124 12 79 2B         [24] 2529 	lcall	_register_code
      009127 D0 05            [24] 2530 	pop	ar5
      009129 D0 06            [24] 2531 	pop	ar6
      00912B 80 0E            [24] 2532 	sjmp	00123$
      00912D                       2533 00119$:
                                   2534 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      00912D 12 92 E4         [24] 2535 	lcall	_ak820_outline_0151
      009130 C0 06            [24] 2536 	push	ar6
      009132 C0 05            [24] 2537 	push	ar5
      009134 12 79 A7         [24] 2538 	lcall	_unregister_code
      009137 D0 05            [24] 2539 	pop	ar5
      009139 D0 06            [24] 2540 	pop	ar6
      00913B                       2541 00123$:
                                   2542 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      00913B 12 92 EB         [24] 2543 	lcall	_ak820_outline_0164
      00913E 02 90 5C         [24] 2544 	ljmp	00167$
      009141                       2545 00152$:
                                   2546 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009141 12 92 B2         [24] 2547 	lcall	_ak820_outline_0094
      009144 BF 05 02         [24] 2548 	cjne	r7,#0x05,00447$
      009147 80 13            [24] 2549 	sjmp	00146$
      009149                       2550 00447$:
      009149 12 92 B2         [24] 2551 	lcall	_ak820_outline_0094
      00914C BF 06 02         [24] 2552 	cjne	r7,#0x06,00448$
      00914F 80 0B            [24] 2553 	sjmp	00146$
      009151                       2554 00448$:
      009151 12 92 B2         [24] 2555 	lcall	_ak820_outline_0094
      009154 BF 07 02         [24] 2556 	cjne	r7,#0x07,00449$
      009157 80 03            [24] 2557 	sjmp	00450$
      009159                       2558 00449$:
      009159 02 92 02         [24] 2559 	ljmp	00147$
      00915C                       2560 00450$:
      00915C                       2561 00146$:
                                   2562 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00915C 12 92 88         [24] 2563 	lcall	_ak820_outline_0000
      00915F 12 43 C3         [24] 2564 	lcall	_eeprom_read_byte
      009162 12 93 03         [24] 2565 	lcall	_ak820_outline_0180
                                   2566 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      009165 70 03            [24] 2567 	jnz	00451$
      009167 02 90 5C         [24] 2568 	ljmp	00167$
      00916A                       2569 00451$:
                                   2570 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00916A 12 92 88         [24] 2571 	lcall	_ak820_outline_0000
      00916D 12 43 C3         [24] 2572 	lcall	_eeprom_read_byte
      009170 AF 82            [24] 2573 	mov	r7, dpl
      009172 90 0B 9A         [24] 2574 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      009175 EF               [12] 2575 	mov	a,r7
      009176 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      009177 EF               [12] 2578 	mov	a,r7
      009178 70 03            [24] 2579 	jnz	00452$
      00917A 02 90 5C         [24] 2580 	ljmp	00167$
      00917D                       2581 00452$:
                                   2582 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00917D 90 0B 99         [24] 2583 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      009180 E0               [24] 2584 	movx	a,@dptr
      009181 FF               [12] 2585 	mov	r7,a
      009182 90 0B 9A         [24] 2586 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      009185 E0               [24] 2587 	movx	a,@dptr
      009186 FB               [12] 2588 	mov	r3,a
      009187 E4               [12] 2589 	clr	a
      009188 FC               [12] 2590 	mov	r4,a
      009189 FA               [12] 2591 	mov	r2,a
      00918A EF               [12] 2592 	mov	a,r7
      00918B 42 04            [12] 2593 	orl	ar4,a
      00918D EA               [12] 2594 	mov	a,r2
      00918E 42 03            [12] 2595 	orl	ar3,a
                                   2596 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      009190 12 46 D0         [24] 2597 	lcall	_ak820_outline_0183
      009193 C0 06            [24] 2598 	push	ar6
      009195 C0 05            [24] 2599 	push	ar5
      009197 12 8F A8         [24] 2600 	lcall	_decode_keycode
      00919A AC 82            [24] 2601 	mov	r4, dpl
      00919C AF 83            [24] 2602 	mov	r7, dph
      00919E D0 05            [24] 2603 	pop	ar5
      0091A0 D0 06            [24] 2604 	pop	ar6
                                   2605 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      0091A2 90 0B 98         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      0091A5 E0               [24] 2607 	movx	a,@dptr
      0091A6 FB               [12] 2608 	mov	r3,a
      0091A7 BB 05 03         [24] 2609 	cjne	r3,#0x05,00453$
      0091AA D3               [12] 2610 	setb	c
      0091AB 80 01            [24] 2611 	sjmp	00454$
      0091AD                       2612 00453$:
      0091AD C3               [12] 2613 	clr	c
      0091AE                       2614 00454$:
      0091AE 92 28            [24] 2615 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0091B0 90 09 DC         [24] 2616 	mov	dptr,#_ak820_macro_primitive
      0091B3 B3               [12] 2617 	cpl	c
      0091B4 E4               [12] 2618 	clr	a
      0091B5 33               [12] 2619 	rlc	a
      0091B6 F0               [24] 2620 	movx	@dptr,a
                                   2621 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      0091B7 90 0B 98         [24] 2622 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      0091BA E0               [24] 2623 	movx	a,@dptr
      0091BB FB               [12] 2624 	mov	r3,a
      0091BC BB 05 02         [24] 2625 	cjne	r3,#0x05,00455$
      0091BF 80 0A            [24] 2626 	sjmp	00126$
      0091C1                       2627 00455$:
      0091C1 BB 06 02         [24] 2628 	cjne	r3,#0x06,00456$
      0091C4 80 16            [24] 2629 	sjmp	00127$
      0091C6                       2630 00456$:
                                   2631 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      0091C6 BB 07 33         [24] 2632 	cjne	r3,#0x07,00129$
      0091C9 80 22            [24] 2633 	sjmp	00128$
      0091CB                       2634 00126$:
                                   2635 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      0091CB 8C 82            [24] 2636 	mov	dpl, r4
      0091CD 8F 83            [24] 2637 	mov	dph, r7
      0091CF C0 06            [24] 2638 	push	ar6
      0091D1 C0 05            [24] 2639 	push	ar5
      0091D3 12 B6 D2         [24] 2640 	lcall	_vial_keycode_tap
      0091D6 D0 05            [24] 2641 	pop	ar5
      0091D8 D0 06            [24] 2642 	pop	ar6
                                   2643 ;	quantum/dynamic_keymap.c:732: break;
                                   2644 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      0091DA 80 20            [24] 2645 	sjmp	00129$
      0091DC                       2646 00127$:
                                   2647 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      0091DC 8C 82            [24] 2648 	mov	dpl, r4
      0091DE 8F 83            [24] 2649 	mov	dph, r7
      0091E0 C0 06            [24] 2650 	push	ar6
      0091E2 C0 05            [24] 2651 	push	ar5
      0091E4 12 B6 07         [24] 2652 	lcall	_vial_keycode_down
      0091E7 D0 05            [24] 2653 	pop	ar5
      0091E9 D0 06            [24] 2654 	pop	ar6
                                   2655 ;	quantum/dynamic_keymap.c:735: break;
                                   2656 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      0091EB 80 0F            [24] 2657 	sjmp	00129$
      0091ED                       2658 00128$:
                                   2659 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      0091ED 8C 82            [24] 2660 	mov	dpl, r4
      0091EF 8F 83            [24] 2661 	mov	dph, r7
      0091F1 C0 06            [24] 2662 	push	ar6
      0091F3 C0 05            [24] 2663 	push	ar5
      0091F5 12 B6 6D         [24] 2664 	lcall	_vial_keycode_up
      0091F8 D0 05            [24] 2665 	pop	ar5
      0091FA D0 06            [24] 2666 	pop	ar6
                                   2667 ;	quantum/dynamic_keymap.c:739: }
      0091FC                       2668 00129$:
                                   2669 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      0091FC 12 92 EB         [24] 2670 	lcall	_ak820_outline_0164
      0091FF 02 90 5C         [24] 2671 	ljmp	00167$
      009202                       2672 00147$:
                                   2673 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      009202 12 92 B2         [24] 2674 	lcall	_ak820_outline_0094
      009205 BF 04 02         [24] 2675 	cjne	r7,#0x04,00458$
      009208 80 03            [24] 2676 	sjmp	00459$
      00920A                       2677 00458$:
      00920A 02 90 5C         [24] 2678 	ljmp	00167$
      00920D                       2679 00459$:
                                   2680 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00920D 12 92 88         [24] 2681 	lcall	_ak820_outline_0000
      009210 12 43 C3         [24] 2682 	lcall	_eeprom_read_byte
      009213 AF 82            [24] 2683 	mov	r7, dpl
                                   2684 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009215 90 0B 95         [24] 2685 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009218 12 38 91         [24] 2686 	lcall	_ak820_outline_0122
      00921B 90 0B 95         [24] 2687 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00921E 74 01            [12] 2688 	mov	a,#0x01
      009220 2B               [12] 2689 	add	a, r3
      009221 F0               [24] 2690 	movx	@dptr,a
      009222 E4               [12] 2691 	clr	a
      009223 3C               [12] 2692 	addc	a, r4
      009224 A3               [24] 2693 	inc	dptr
      009225 F0               [24] 2694 	movx	@dptr,a
      009226 7A 00            [12] 2695 	mov	r2,#0x00
      009228 12 33 FC         [24] 2696 	lcall	_ak820_outline_0123
      00922B 8A F0            [24] 2697 	mov	b, r2
      00922D 12 43 C3         [24] 2698 	lcall	_eeprom_read_byte
      009230 AC 82            [24] 2699 	mov	r4, dpl
                                   2700 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      009232 EF               [12] 2701 	mov	a,r7
      009233 60 4B            [24] 2702 	jz	00169$
      009235 EC               [12] 2703 	mov	a,r4
      009236 60 48            [24] 2704 	jz	00169$
                                   2705 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009238 1F               [12] 2706 	dec	r7
      009239 1C               [12] 2707 	dec	r4
      00923A EC               [12] 2708 	mov	a,r4
      00923B 75 F0 FF         [24] 2709 	mov	b,#0xff
      00923E A4               [48] 2710 	mul	ab
      00923F FC               [12] 2711 	mov	r4,a
      009240 AB F0            [24] 2712 	mov	r3,b
      009242 7A 00            [12] 2713 	mov	r2,#0x00
      009244 EC               [12] 2714 	mov	a,r4
      009245 2F               [12] 2715 	add	a, r7
      009246 FC               [12] 2716 	mov	r4,a
      009247 EB               [12] 2717 	mov	a,r3
      009248 3A               [12] 2718 	addc	a, r2
      009249 FB               [12] 2719 	mov	r3,a
                                   2720 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      00924A                       2721 00141$:
      00924A 8C 02            [24] 2722 	mov	ar2,r4
      00924C 8B 07            [24] 2723 	mov	ar7,r3
      00924E 1C               [12] 2724 	dec	r4
      00924F BC FF 01         [24] 2725 	cjne	r4,#0xff,00462$
      009252 1B               [12] 2726 	dec	r3
      009253                       2727 00462$:
      009253 EA               [12] 2728 	mov	a,r2
      009254 4F               [12] 2729 	orl	a,r7
      009255 70 03            [24] 2730 	jnz	00463$
      009257 02 90 5C         [24] 2731 	ljmp	00167$
      00925A                       2732 00463$:
      00925A 90 00 01         [24] 2733 	mov	dptr,#0x0001
      00925D 12 5C 38         [24] 2734 	lcall	_mDelaymS
      009260 80 E8            [24] 2735 	sjmp	00141$
      009262                       2736 00164$:
                                   2737 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      009262 90 0B 97         [24] 2738 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009265 E0               [24] 2739 	movx	a,@dptr
      009266 FF               [12] 2740 	mov	r7,a
      009267 BF 80 00         [24] 2741 	cjne	r7,#0x80,00464$
      00926A                       2742 00464$:
      00926A 50 14            [24] 2743 	jnc	00169$
                                   2744 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      00926C 90 0B 97         [24] 2745 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00926F E0               [24] 2746 	movx	a,@dptr
      009270 F5 82            [12] 2747 	mov	dpl,a
      009272 C0 06            [24] 2748 	push	ar6
      009274 C0 05            [24] 2749 	push	ar5
      009276 12 A9 77         [24] 2750 	lcall	_send_char
      009279 D0 05            [24] 2751 	pop	ar5
      00927B D0 06            [24] 2752 	pop	ar6
                                   2753 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      00927D 02 90 5C         [24] 2754 	ljmp	00167$
      009280                       2755 00169$:
                                   2756 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      009280 12 92 EB         [24] 2757 	lcall	_ak820_outline_0164
                                   2758 ;	quantum/dynamic_keymap.c:774: sending = false;
      009283 90 0B 94         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      009286 F0               [24] 2760 	movx	@dptr,a
                                   2761 ;	quantum/dynamic_keymap.c:776: }
      009287 22               [24] 2762 	ret
                                   2763 	.area CSEG    (CODE)
                                   2764 	.area CONST   (CODE)
                                   2765 	.area XINIT   (CODE)
                                   2766 	.area CABS    (ABS,CODE)
                                   2767 
                                   2768 ; Experimental exact instruction outlining.
                                   2769 	.globl _ak820_outline_0000
                                   2770 	.globl _ak820_outline_0005
                                   2771 	.globl _ak820_outline_0009
                                   2772 	.globl _ak820_outline_0014
                                   2773 	.globl _ak820_outline_0021
                                   2774 	.globl _ak820_outline_0031
                                   2775 	.globl _ak820_outline_0034
                                   2776 	.globl _ak820_outline_0050
                                   2777 	.globl _ak820_outline_0052
                                   2778 	.globl _ak820_outline_0057
                                   2779 	.globl _ak820_outline_0058
                                   2780 	.globl _ak820_outline_0059
                                   2781 	.globl _ak820_outline_0064
                                   2782 	.globl _ak820_outline_0071
                                   2783 	.globl _ak820_outline_0072
                                   2784 	.globl _ak820_outline_0080
                                   2785 	.globl _ak820_outline_0084
                                   2786 	.globl _ak820_outline_0091
                                   2787 	.globl _ak820_outline_0093
                                   2788 	.globl _ak820_outline_0094
                                   2789 	.globl _ak820_outline_0100
                                   2790 	.globl _ak820_outline_0101
                                   2791 	.globl _ak820_outline_0103
                                   2792 	.globl _ak820_outline_0104
                                   2793 	.globl _ak820_outline_0108
                                   2794 	.globl _ak820_outline_0109
                                   2795 	.globl _ak820_outline_0112
                                   2796 	.globl _ak820_outline_0116
                                   2797 	.globl _ak820_outline_0118
                                   2798 	.globl _ak820_outline_0122
                                   2799 	.globl _ak820_outline_0123
                                   2800 	.globl _ak820_outline_0124
                                   2801 	.globl _ak820_outline_0125
                                   2802 	.globl _ak820_outline_0129
                                   2803 	.globl _ak820_outline_0134
                                   2804 	.globl _ak820_outline_0135
                                   2805 	.globl _ak820_outline_0136
                                   2806 	.globl _ak820_outline_0137
                                   2807 	.globl _ak820_outline_0138
                                   2808 	.globl _ak820_outline_0143
                                   2809 	.globl _ak820_outline_0144
                                   2810 	.globl _ak820_outline_0149
                                   2811 	.globl _ak820_outline_0151
                                   2812 	.globl _ak820_outline_0155
                                   2813 	.globl _ak820_outline_0159
                                   2814 	.globl _ak820_outline_0164
                                   2815 	.globl _ak820_outline_0176
                                   2816 	.globl _ak820_outline_0177
                                   2817 	.globl _ak820_outline_0180
                                   2818 	.globl _ak820_outline_0181
                                   2819 	.globl _ak820_outline_0182
                                   2820 	.globl _ak820_outline_0183
                                   2821 	.globl _ak820_outline_0186
                                   2822 	.globl _ak820_outline_0188
                                   2823 
                                   2824 	.area CSEG (CODE)
                                   2825 ; function ak820_outline_0000
      009288                       2826 _ak820_outline_0000:
      009288 90 0B 95         [24] 2827 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      00928B E0               [24] 2828 	movx	a,@dptr
      00928C FC               [12] 2829 	mov	r4,a
      00928D A3               [24] 2830 	inc	dptr
      00928E E0               [24] 2831 	movx	a,@dptr
      00928F FF               [12] 2832 	mov	r7,a
      009290 90 0B 95         [24] 2833 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009293 74 01            [12] 2834 	mov	a,#0x01
      009295 2C               [12] 2835 	add	a,r4
      009296 F0               [24] 2836 	movx	@dptr,a
      009297 E4               [12] 2837 	clr	a
      009298 3F               [12] 2838 	addc	a,r7
      009299 A3               [24] 2839 	inc	dptr
      00929A F0               [24] 2840 	movx	@dptr,a
      00929B 7B 00            [12] 2841 	mov	r3,#0x00
      00929D 8C 82            [24] 2842 	mov	dpl,r4
      00929F 8F 83            [24] 2843 	mov	dph,r7
      0092A1 8B F0            [24] 2844 	mov	b,r3
      0092A3 22               [24] 2845 	ret
                                   2846 
                                   2847 	.area CSEG (CODE)
                                   2848 ; function ak820_outline_0080
      0092A4                       2849 _ak820_outline_0080:
      0092A4 ED               [12] 2850 	mov	a,r5
      0092A5 75 F0 0A         [24] 2851 	mov	b,#0x0a
      0092A8 A4               [48] 2852 	mul	ab
      0092A9 24 58            [12] 2853 	add	a,#0x58
      0092AB FC               [12] 2854 	mov	r4,a
      0092AC 74 06            [12] 2855 	mov	a,#0x06
      0092AE 35 F0            [12] 2856 	addc	a,b
      0092B0 FD               [12] 2857 	mov	r5,a
      0092B1 22               [24] 2858 	ret
                                   2859 
                                   2860 	.area CSEG (CODE)
                                   2861 ; function ak820_outline_0094
      0092B2                       2862 _ak820_outline_0094:
      0092B2 90 0B 98         [24] 2863 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      0092B5 E0               [24] 2864 	movx	a,@dptr
      0092B6 FF               [12] 2865 	mov	r7,a
      0092B7 22               [24] 2866 	ret
                                   2867 
                                   2868 	.area CSEG (CODE)
                                   2869 ; function ak820_outline_0100
      0092B8                       2870 _ak820_outline_0100:
      0092B8 90 0B 2E         [24] 2871 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0092BB EE               [12] 2872 	mov	a,r6
      0092BC F0               [24] 2873 	movx	@dptr,a
      0092BD 90 0B 2F         [24] 2874 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0092C0 ED               [12] 2875 	mov	a,r5
      0092C1 F0               [24] 2876 	movx	@dptr,a
      0092C2 8F 82            [24] 2877 	mov	dpl,r7
      0092C4 22               [24] 2878 	ret
                                   2879 
                                   2880 	.area CSEG (CODE)
                                   2881 ; function ak820_outline_0112
      0092C5                       2882 _ak820_outline_0112:
      0092C5 74 0A            [12] 2883 	mov	a,#0x0a
      0092C7 F0               [24] 2884 	movx	@dptr,a
      0092C8 E4               [12] 2885 	clr	a
      0092C9 A3               [24] 2886 	inc	dptr
      0092CA F0               [24] 2887 	movx	@dptr,a
      0092CB 22               [24] 2888 	ret
                                   2889 
                                   2890 	.area CSEG (CODE)
                                   2891 ; function ak820_outline_0116
      0092CC                       2892 _ak820_outline_0116:
      0092CC AD 82            [24] 2893 	mov	r5,dpl
      0092CE AE 83            [24] 2894 	mov	r6,dph
      0092D0 AF F0            [24] 2895 	mov	r7,b
      0092D2 22               [24] 2896 	ret
                                   2897 
                                   2898 	.area CSEG (CODE)
                                   2899 ; function ak820_outline_0129
      0092D3                       2900 _ak820_outline_0129:
      0092D3 28               [12] 2901 	add	a,r0
      0092D4 F5 82            [12] 2902 	mov	dpl,a
      0092D6 EF               [12] 2903 	mov	a,r7
      0092D7 39               [12] 2904 	addc	a,r1
      0092D8 F5 83            [12] 2905 	mov	dph,a
      0092DA 74 FF            [12] 2906 	mov	a,#0xff
      0092DC F0               [24] 2907 	movx	@dptr,a
      0092DD 22               [24] 2908 	ret
                                   2909 
                                   2910 	.area CSEG (CODE)
                                   2911 ; function ak820_outline_0137
      0092DE                       2912 _ak820_outline_0137:
      0092DE 2D               [12] 2913 	add	a,r5
      0092DF F9               [12] 2914 	mov	r1,a
      0092E0 E4               [12] 2915 	clr	a
      0092E1 3E               [12] 2916 	addc	a,r6
      0092E2 FA               [12] 2917 	mov	r2,a
      0092E3 22               [24] 2918 	ret
                                   2919 
                                   2920 	.area CSEG (CODE)
                                   2921 ; function ak820_outline_0151
      0092E4                       2922 _ak820_outline_0151:
      0092E4 90 0B 99         [24] 2923 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      0092E7 E0               [24] 2924 	movx	a,@dptr
      0092E8 F5 82            [12] 2925 	mov	dpl,a
      0092EA 22               [24] 2926 	ret
                                   2927 
                                   2928 	.area CSEG (CODE)
                                   2929 ; function ak820_outline_0164
      0092EB                       2930 _ak820_outline_0164:
      0092EB 90 09 DC         [24] 2931 	mov	dptr,#_ak820_macro_primitive
      0092EE E4               [12] 2932 	clr	a
      0092EF F0               [24] 2933 	movx	@dptr,a
      0092F0 22               [24] 2934 	ret
                                   2935 
                                   2936 	.area CSEG (CODE)
                                   2937 ; function ak820_outline_0176
      0092F1                       2938 _ak820_outline_0176:
      0092F1 90 0B 3E         [24] 2939 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0092F4 E4               [12] 2940 	clr	a
      0092F5 F0               [24] 2941 	movx	@dptr,a
      0092F6 90 0B 3F         [24] 2942 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0092F9 22               [24] 2943 	ret
                                   2944 
                                   2945 	.area CSEG (CODE)
                                   2946 ; function ak820_outline_0177
      0092FA                       2947 _ak820_outline_0177:
      0092FA 90 0B F4         [24] 2948 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0092FD E4               [12] 2949 	clr	a
      0092FE F0               [24] 2950 	movx	@dptr,a
      0092FF 90 0B F5         [24] 2951 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009302 22               [24] 2952 	ret
                                   2953 
                                   2954 	.area CSEG (CODE)
                                   2955 ; function ak820_outline_0180
      009303                       2956 _ak820_outline_0180:
      009303 AF 82            [24] 2957 	mov	r7,dpl
      009305 90 0B 99         [24] 2958 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      009308 EF               [12] 2959 	mov	a,r7
      009309 F0               [24] 2960 	movx	@dptr,a
      00930A EF               [12] 2961 	mov	a,r7
      00930B 22               [24] 2962 	ret
