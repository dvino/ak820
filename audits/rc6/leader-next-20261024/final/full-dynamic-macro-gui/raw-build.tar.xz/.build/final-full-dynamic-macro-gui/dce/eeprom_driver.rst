                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006D5                         85 _eeprom_read_word_addr_10000_91:
      0006D5                         86 	.ds 3
      0006D8                         87 _eeprom_read_word_ret_10000_92:
      0006D8                         88 	.ds 2
      0006DA                         89 _eeprom_read_dword_addr_10000_93:
      0006DA                         90 	.ds 3
      0006DD                         91 _eeprom_read_dword_ret_10000_94:
      0006DD                         92 	.ds 4
      0006E1                         93 _eeprom_write_byte_PARM_2:
      0006E1                         94 	.ds 1
      0006E2                         95 _eeprom_write_byte_addr_10000_95:
      0006E2                         96 	.ds 3
      0006E5                         97 _eeprom_write_word_PARM_2:
      0006E5                         98 	.ds 2
      0006E7                         99 _eeprom_write_word_addr_10000_97:
      0006E7                        100 	.ds 3
      0006EA                        101 _eeprom_write_dword_PARM_2:
      0006EA                        102 	.ds 4
      0006EE                        103 _eeprom_write_dword_addr_10000_99:
      0006EE                        104 	.ds 3
      0006F1                        105 _eeprom_update_byte_PARM_2:
      0006F1                        106 	.ds 1
      0006F2                        107 _eeprom_update_byte_addr_10000_107:
      0006F2                        108 	.ds 3
      0006F5                        109 _eeprom_update_word_PARM_2:
      0006F5                        110 	.ds 2
      0006F7                        111 _eeprom_update_word_addr_10000_111:
      0006F7                        112 	.ds 3
      0006FA                        113 _eeprom_update_dword_PARM_2:
      0006FA                        114 	.ds 4
      0006FE                        115 _eeprom_update_dword_addr_10000_115:
      0006FE                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0050AC                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0050AC 12 46 62         [24]  170 	lcall	_ak820_outline_0037
      0050AF 90 06 D5         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0050B2 12 38 29         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0050B5 90 06 D8         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0050B8 12 52 B7         [24]  175 	lcall	_ak820_outline_0181
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0050BB 90 06 D5         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0050BE 12 52 64         [24]  178 	lcall	_ak820_outline_0013
      0050C1 90 05 DB         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050C4 ED               [12]  180 	mov	a,r5
      0050C5 12 38 29         [24]  181 	lcall	_ak820_outline_0017
      0050C8 90 05 DE         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050CB 12 52 A9         [24]  183 	lcall	_ak820_outline_0111
      0050CE 90 06 D8         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0050D1 12 43 FE         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0050D4 90 06 D8         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0050D7 12 52 A0         [24]  188 	lcall	_ak820_outline_0092
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0050DA 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0050DB                        201 _eeprom_read_dword:
      0050DB 12 46 62         [24]  202 	lcall	_ak820_outline_0037
      0050DE 90 06 DA         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0050E1 12 38 29         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0050E4 90 06 DD         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0050E7 12 52 75         [24]  207 	lcall	_ak820_outline_0051
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0050EA 90 06 DA         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0050ED 12 52 64         [24]  210 	lcall	_ak820_outline_0013
      0050F0 90 05 DB         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050F3 ED               [12]  212 	mov	a,r5
      0050F4 12 38 29         [24]  213 	lcall	_ak820_outline_0017
      0050F7 90 05 DE         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050FA 74 04            [12]  215 	mov	a,#0x04
      0050FC 12 38 A1         [24]  216 	lcall	_ak820_outline_0135
      0050FF 90 06 DD         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005102 12 43 FE         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005105 90 06 DD         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005108 12 52 7E         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      00510B 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00510C                        234 _eeprom_write_byte:
      00510C 12 46 62         [24]  235 	lcall	_ak820_outline_0037
      00510F 90 06 E2         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005112 12 38 29         [24]  237 	lcall	_ak820_outline_0017
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005115 90 06 E2         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005118 12 52 4D         [24]  240 	lcall	_ak820_outline_0004
      00511B 74 01            [12]  241 	mov	a,#0x01
      00511D 12 38 A1         [24]  242 	lcall	_ak820_outline_0135
      005120 90 06 E1         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005123 02 44 8A         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005126                        256 _eeprom_write_word:
      005126 12 46 62         [24]  257 	lcall	_ak820_outline_0037
      005129 90 06 E7         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00512C 12 38 29         [24]  259 	lcall	_ak820_outline_0017
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00512F 90 06 E7         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005132 12 52 4D         [24]  262 	lcall	_ak820_outline_0004
      005135 12 52 A9         [24]  263 	lcall	_ak820_outline_0111
      005138 90 06 E5         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00513B 02 44 8A         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00513E                        277 _eeprom_write_dword:
      00513E 12 46 62         [24]  278 	lcall	_ak820_outline_0037
      005141 90 06 EE         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005144 12 38 29         [24]  280 	lcall	_ak820_outline_0017
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005147 90 06 EE         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00514A 12 52 4D         [24]  283 	lcall	_ak820_outline_0004
      00514D 74 04            [12]  284 	mov	a,#0x04
      00514F 12 38 A1         [24]  285 	lcall	_ak820_outline_0135
      005152 90 06 EA         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005155 02 44 8A         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005158                        307 _eeprom_update_byte:
      005158 C0 07            [24]  308 	push	ar7
      00515A C0 06            [24]  309 	push	ar6
      00515C C0 05            [24]  310 	push	ar5
      00515E C0 04            [24]  311 	push	ar4
      005160 12 46 62         [24]  312 	lcall	_ak820_outline_0037
      005163 90 06 F2         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005166 12 38 29         [24]  314 	lcall	_ak820_outline_0017
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005169 90 06 F2         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00516C 12 52 3E         [24]  317 	lcall	_ak820_outline_0001
      00516F 12 43 C3         [24]  318 	lcall	_eeprom_read_byte
      005172 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005174 90 06 F1         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005177 E0               [24]  322 	movx	a,@dptr
      005178 FE               [12]  323 	mov	r6,a
      005179 EF               [12]  324 	mov	a,r7
      00517A B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00517D 80 35            [24]  326 	sjmp	00103$
      00517F                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00517F 90 06 F2         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005182 12 38 58         [24]  330 	lcall	_ak820_outline_0059
      005185 A3               [24]  331 	inc	dptr
      005186 E0               [24]  332 	movx	a,@dptr
      005187 FF               [12]  333 	mov	r7,a
      005188 90 06 E1         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00518B EE               [12]  335 	mov	a,r6
      00518C 12 38 76         [24]  336 	lcall	_ak820_outline_0101
      00518F 8F F0            [24]  337 	mov	b, r7
      005191 C0 07            [24]  338 	push	ar7
      005193 C0 06            [24]  339 	push	ar6
      005195 C0 05            [24]  340 	push	ar5
      005197 C0 04            [24]  341 	push	ar4
      005199 C0 03            [24]  342 	push	ar3
      00519B C0 02            [24]  343 	push	ar2
      00519D C0 01            [24]  344 	push	ar1
      00519F C0 00            [24]  345 	push	ar0
      0051A1 12 51 0C         [24]  346 	lcall	_eeprom_write_byte
      0051A4 D0 00            [24]  347 	pop	ar0
      0051A6 D0 01            [24]  348 	pop	ar1
      0051A8 D0 02            [24]  349 	pop	ar2
      0051AA D0 03            [24]  350 	pop	ar3
      0051AC D0 04            [24]  351 	pop	ar4
      0051AE D0 05            [24]  352 	pop	ar5
      0051B0 D0 06            [24]  353 	pop	ar6
      0051B2 D0 07            [24]  354 	pop	ar7
      0051B4                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0051B4 D0 04            [24]  357 	pop	ar4
      0051B6 D0 05            [24]  358 	pop	ar5
      0051B8 D0 06            [24]  359 	pop	ar6
      0051BA D0 07            [24]  360 	pop	ar7
      0051BC 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0051BD                        373 _eeprom_update_word:
      0051BD 12 46 62         [24]  374 	lcall	_ak820_outline_0037
      0051C0 90 06 F7         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051C3 12 38 29         [24]  376 	lcall	_ak820_outline_0017
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0051C6 90 06 F7         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051C9 12 52 3E         [24]  379 	lcall	_ak820_outline_0001
      0051CC 12 50 AC         [24]  380 	lcall	_eeprom_read_word
      0051CF 12 46 A4         [24]  381 	lcall	_ak820_outline_0125
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0051D2 90 06 F5         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0051D5 12 38 58         [24]  384 	lcall	_ak820_outline_0059
      0051D8 EE               [12]  385 	mov	a,r6
      0051D9 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0051DC EF               [12]  387 	mov	a,r7
      0051DD B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0051E0 22               [24]  389 	ret
      0051E1                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0051E1 90 06 F7         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051E4 E0               [24]  393 	movx	a,@dptr
      0051E5 FB               [12]  394 	mov	r3,a
      0051E6 A3               [24]  395 	inc	dptr
      0051E7 12 38 41         [24]  396 	lcall	_ak820_outline_0052
      0051EA 90 06 E5         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0051ED 12 38 5E         [24]  398 	lcall	_ak820_outline_0072
      0051F0 8B 82            [24]  399 	mov	dpl, r3
      0051F2 8E 83            [24]  400 	mov	dph, r6
      0051F4 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0051F6 02 51 26         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0051F9                        415 _eeprom_update_dword:
      0051F9 12 46 62         [24]  416 	lcall	_ak820_outline_0037
      0051FC 90 06 FE         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051FF 12 38 29         [24]  418 	lcall	_ak820_outline_0017
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005202 90 06 FE         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005205 12 52 3E         [24]  421 	lcall	_ak820_outline_0001
      005208 12 50 DB         [24]  422 	lcall	_eeprom_read_dword
      00520B 12 52 8F         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00520E 90 06 FA         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      005211 E0               [24]  426 	movx	a,@dptr
      005212 F8               [12]  427 	mov	r0,a
      005213 A3               [24]  428 	inc	dptr
      005214 12 52 97         [24]  429 	lcall	_ak820_outline_0091
      005217 EC               [12]  430 	mov	a,r4
      005218 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      00521B ED               [12]  432 	mov	a,r5
      00521C B5 01 09         [24]  433 	cjne	a,ar1,00112$
      00521F EE               [12]  434 	mov	a,r6
      005220 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005223 EF               [12]  436 	mov	a,r7
      005224 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005227 22               [24]  438 	ret
      005228                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005228 90 06 FE         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00522B 12 52 64         [24]  442 	lcall	_ak820_outline_0013
      00522E 90 06 EA         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005231 E8               [12]  444 	mov	a,r0
      005232 F0               [24]  445 	movx	@dptr,a
      005233 E9               [12]  446 	mov	a,r1
      005234 A3               [24]  447 	inc	dptr
      005235 12 52 B0         [24]  448 	lcall	_ak820_outline_0155
      005238 12 52 6D         [24]  449 	lcall	_ak820_outline_0031
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      00523B 02 51 3E         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0013
                                    461 	.globl _ak820_outline_0017
                                    462 	.globl _ak820_outline_0031
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0051
                                    465 	.globl _ak820_outline_0052
                                    466 	.globl _ak820_outline_0055
                                    467 	.globl _ak820_outline_0056
                                    468 	.globl _ak820_outline_0059
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0091
                                    471 	.globl _ak820_outline_0092
                                    472 	.globl _ak820_outline_0101
                                    473 	.globl _ak820_outline_0111
                                    474 	.globl _ak820_outline_0125
                                    475 	.globl _ak820_outline_0135
                                    476 	.globl _ak820_outline_0155
                                    477 	.globl _ak820_outline_0181
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      00523E                        481 _ak820_outline_0001:
      00523E E0               [24]  482 	movx	a,@dptr
      00523F FD               [12]  483 	mov	r5,a
      005240 A3               [24]  484 	inc	dptr
      005241 E0               [24]  485 	movx	a,@dptr
      005242 FE               [12]  486 	mov	r6,a
      005243 A3               [24]  487 	inc	dptr
      005244 E0               [24]  488 	movx	a,@dptr
      005245 FF               [12]  489 	mov	r7,a
      005246 8D 82            [24]  490 	mov	dpl,r5
      005248 8E 83            [24]  491 	mov	dph,r6
      00524A 8F F0            [24]  492 	mov	b,r7
      00524C 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      00524D                        497 _ak820_outline_0004:
      00524D E0               [24]  498 	movx	a,@dptr
      00524E FD               [12]  499 	mov	r5,a
      00524F A3               [24]  500 	inc	dptr
      005250 E0               [24]  501 	movx	a,@dptr
      005251 FE               [12]  502 	mov	r6,a
      005252 A3               [24]  503 	inc	dptr
      005253 E0               [24]  504 	movx	a,@dptr
      005254 FF               [12]  505 	mov	r7,a
      005255 90 05 E4         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005258 ED               [12]  507 	mov	a,r5
      005259 F0               [24]  508 	movx	@dptr,a
      00525A EE               [12]  509 	mov	a,r6
      00525B A3               [24]  510 	inc	dptr
      00525C F0               [24]  511 	movx	@dptr,a
      00525D EF               [12]  512 	mov	a,r7
      00525E A3               [24]  513 	inc	dptr
      00525F F0               [24]  514 	movx	@dptr,a
      005260 90 05 E7         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005263 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0013
      005264                        520 _ak820_outline_0013:
      005264 E0               [24]  521 	movx	a,@dptr
      005265 FD               [12]  522 	mov	r5,a
      005266 A3               [24]  523 	inc	dptr
      005267 E0               [24]  524 	movx	a,@dptr
      005268 FE               [12]  525 	mov	r6,a
      005269 A3               [24]  526 	inc	dptr
      00526A E0               [24]  527 	movx	a,@dptr
      00526B FF               [12]  528 	mov	r7,a
      00526C 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0031
      00526D                        533 _ak820_outline_0031:
      00526D F0               [24]  534 	movx	@dptr,a
      00526E 8D 82            [24]  535 	mov	dpl,r5
      005270 8E 83            [24]  536 	mov	dph,r6
      005272 8F F0            [24]  537 	mov	b,r7
      005274 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0051
      005275                        542 _ak820_outline_0051:
      005275 E4               [12]  543 	clr	a
      005276 F0               [24]  544 	movx	@dptr,a
      005277 A3               [24]  545 	inc	dptr
      005278 F0               [24]  546 	movx	@dptr,a
      005279 A3               [24]  547 	inc	dptr
      00527A F0               [24]  548 	movx	@dptr,a
      00527B A3               [24]  549 	inc	dptr
      00527C F0               [24]  550 	movx	@dptr,a
      00527D 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      00527E                        555 _ak820_outline_0055:
      00527E E0               [24]  556 	movx	a,@dptr
      00527F FC               [12]  557 	mov	r4,a
      005280 A3               [24]  558 	inc	dptr
      005281 E0               [24]  559 	movx	a,@dptr
      005282 FD               [12]  560 	mov	r5,a
      005283 A3               [24]  561 	inc	dptr
      005284 E0               [24]  562 	movx	a,@dptr
      005285 FE               [12]  563 	mov	r6,a
      005286 A3               [24]  564 	inc	dptr
      005287 E0               [24]  565 	movx	a,@dptr
      005288 8C 82            [24]  566 	mov	dpl,r4
      00528A 8D 83            [24]  567 	mov	dph,r5
      00528C 8E F0            [24]  568 	mov	b,r6
      00528E 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      00528F                        573 _ak820_outline_0056:
      00528F AC 82            [24]  574 	mov	r4,dpl
      005291 AD 83            [24]  575 	mov	r5,dph
      005293 AE F0            [24]  576 	mov	r6,b
      005295 FF               [12]  577 	mov	r7,a
      005296 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0091
      005297                        582 _ak820_outline_0091:
      005297 E0               [24]  583 	movx	a,@dptr
      005298 F9               [12]  584 	mov	r1,a
      005299 A3               [24]  585 	inc	dptr
      00529A E0               [24]  586 	movx	a,@dptr
      00529B FA               [12]  587 	mov	r2,a
      00529C A3               [24]  588 	inc	dptr
      00529D E0               [24]  589 	movx	a,@dptr
      00529E FB               [12]  590 	mov	r3,a
      00529F 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0092
      0052A0                        595 _ak820_outline_0092:
      0052A0 E0               [24]  596 	movx	a,@dptr
      0052A1 FE               [12]  597 	mov	r6,a
      0052A2 A3               [24]  598 	inc	dptr
      0052A3 E0               [24]  599 	movx	a,@dptr
      0052A4 8E 82            [24]  600 	mov	dpl,r6
      0052A6 F5 83            [12]  601 	mov	dph,a
      0052A8 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0111
      0052A9                        606 _ak820_outline_0111:
      0052A9 74 02            [12]  607 	mov	a,#0x02
      0052AB F0               [24]  608 	movx	@dptr,a
      0052AC E4               [12]  609 	clr	a
      0052AD A3               [24]  610 	inc	dptr
      0052AE F0               [24]  611 	movx	@dptr,a
      0052AF 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0155
      0052B0                        616 _ak820_outline_0155:
      0052B0 F0               [24]  617 	movx	@dptr,a
      0052B1 EA               [12]  618 	mov	a,r2
      0052B2 A3               [24]  619 	inc	dptr
      0052B3 F0               [24]  620 	movx	@dptr,a
      0052B4 EB               [12]  621 	mov	a,r3
      0052B5 A3               [24]  622 	inc	dptr
      0052B6 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0181
      0052B7                        627 _ak820_outline_0181:
      0052B7 E4               [12]  628 	clr	a
      0052B8 F0               [24]  629 	movx	@dptr,a
      0052B9 A3               [24]  630 	inc	dptr
      0052BA F0               [24]  631 	movx	@dptr,a
      0052BB 22               [24]  632 	ret
