                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _get_repeat_key_count
                                     27 	.globl _repeat_key_cancel
                                     28 	.globl _clear_owned_usages
                                     29 	.globl _owned_usage_key
                                     30 	.globl _clear_owned_keys
                                     31 	.globl _del_owned_key
                                     32 	.globl _add_owned_key
                                     33 	.globl _clear_owned_mods
                                     34 	.globl _del_owned_weak_mods
                                     35 	.globl _add_owned_weak_mods
                                     36 	.globl _del_owned_mods
                                     37 	.globl _add_owned_mods
                                     38 	.globl _clear_weak_mods
                                     39 	.globl _clear_mods
                                     40 	.globl _send_keyboard_report
                                     41 	.globl _layer_hold_clear
                                     42 	.globl _layer_hold_off
                                     43 	.globl _layer_hold_on
                                     44 	.globl _ak820_resolve_key
                                     45 	.globl _layer_xor
                                     46 	.globl _layer_and
                                     47 	.globl _layer_or
                                     48 	.globl _layer_off
                                     49 	.globl _layer_on
                                     50 	.globl _layer_move
                                     51 	.globl _layer_clear
                                     52 	.globl _layer_state_set
                                     53 	.globl _default_layer_xor
                                     54 	.globl _default_layer_and
                                     55 	.globl _default_layer_or
                                     56 	.globl _default_layer_set
                                     57 	.globl _post_process_record_quantum
                                     58 	.globl _process_record_quantum
                                     59 	.globl _action_for_keycode
                                     60 	.globl _mDelaymS
                                     61 	.globl _host_consumer_send
                                     62 	.globl _host_system_send
                                     63 	.globl _host_keyboard_leds
                                     64 	.globl _led_set
                                     65 	.globl _clear_keys_from_report
                                     66 	.globl ___memcpy
                                     67 	.globl _ADC_START
                                     68 	.globl _S0_R_FIFO
                                     69 	.globl _S0_T_FIFO
                                     70 	.globl _S0_FREE
                                     71 	.globl _S0_IF_BYTE
                                     72 	.globl _S0_IF_FIRST
                                     73 	.globl _S0_IF_OV
                                     74 	.globl _S0_FST_ACT
                                     75 	.globl _CP_RL2
                                     76 	.globl _C_T2
                                     77 	.globl _TR2
                                     78 	.globl _EXEN2
                                     79 	.globl _TCLK
                                     80 	.globl _RCLK
                                     81 	.globl _EXF2
                                     82 	.globl _CAP1F
                                     83 	.globl _TF2
                                     84 	.globl _RI
                                     85 	.globl _TI
                                     86 	.globl _RB8
                                     87 	.globl _TB8
                                     88 	.globl _REN
                                     89 	.globl _SM2
                                     90 	.globl _SM1
                                     91 	.globl _SM0
                                     92 	.globl _IT0
                                     93 	.globl _IE0
                                     94 	.globl _IT1
                                     95 	.globl _IE1
                                     96 	.globl _TR0
                                     97 	.globl _TF0
                                     98 	.globl _TR1
                                     99 	.globl _TF1
                                    100 	.globl _P4_0
                                    101 	.globl _P4_1
                                    102 	.globl _P4_2
                                    103 	.globl _P4_3
                                    104 	.globl _P4_4
                                    105 	.globl _P4_5
                                    106 	.globl _P4_6
                                    107 	.globl _RXD
                                    108 	.globl _TXD
                                    109 	.globl _INT0
                                    110 	.globl _INT1
                                    111 	.globl _T0
                                    112 	.globl _T1
                                    113 	.globl _MOSI1
                                    114 	.globl _MISO1
                                    115 	.globl _SCK1
                                    116 	.globl _P3_0
                                    117 	.globl _P3_1
                                    118 	.globl _P3_2
                                    119 	.globl _P3_3
                                    120 	.globl _P3_4
                                    121 	.globl _P3_5
                                    122 	.globl _P3_6
                                    123 	.globl _P3_7
                                    124 	.globl _CAP1_
                                    125 	.globl _T2_
                                    126 	.globl _CAP2_
                                    127 	.globl _T2EX_
                                    128 	.globl _RXD1
                                    129 	.globl _TXD1
                                    130 	.globl _P2_0
                                    131 	.globl _P2_1
                                    132 	.globl _P2_2
                                    133 	.globl _P2_3
                                    134 	.globl _P2_4
                                    135 	.globl _P2_5
                                    136 	.globl _P2_6
                                    137 	.globl _P2_7
                                    138 	.globl _AIN0
                                    139 	.globl _AIN1
                                    140 	.globl _AIN2
                                    141 	.globl _AIN3
                                    142 	.globl _AIN4
                                    143 	.globl _AIN5
                                    144 	.globl _AIN6
                                    145 	.globl _AIN7
                                    146 	.globl _CAP1
                                    147 	.globl _T2
                                    148 	.globl _CAP2
                                    149 	.globl _T2EX
                                    150 	.globl _INT0_
                                    151 	.globl _SCS
                                    152 	.globl _MOSI
                                    153 	.globl _MISO
                                    154 	.globl _SCK
                                    155 	.globl _RXD1_
                                    156 	.globl _TXD1_
                                    157 	.globl _P1_0
                                    158 	.globl _P1_1
                                    159 	.globl _P1_2
                                    160 	.globl _P1_3
                                    161 	.globl _P1_4
                                    162 	.globl _P1_5
                                    163 	.globl _P1_6
                                    164 	.globl _P1_7
                                    165 	.globl _AIN8
                                    166 	.globl _AIN9
                                    167 	.globl _AIN10
                                    168 	.globl _AIN11
                                    169 	.globl _AIN12
                                    170 	.globl _AIN13
                                    171 	.globl _RXD_
                                    172 	.globl _TXD_
                                    173 	.globl _SCL0
                                    174 	.globl _SDA0
                                    175 	.globl _P0_0
                                    176 	.globl _P0_1
                                    177 	.globl _P0_2
                                    178 	.globl _P0_3
                                    179 	.globl _P0_4
                                    180 	.globl _P0_5
                                    181 	.globl _P0_6
                                    182 	.globl _P0_7
                                    183 	.globl _IE_SPI0
                                    184 	.globl _IE_USB
                                    185 	.globl _IE_ADC
                                    186 	.globl _IE_UART1
                                    187 	.globl _IE_PWM_I2C
                                    188 	.globl _IE_GPIO
                                    189 	.globl _IE_WDOG
                                    190 	.globl _PX0
                                    191 	.globl _PT0
                                    192 	.globl _PX1
                                    193 	.globl _PT1
                                    194 	.globl _PS
                                    195 	.globl _PT2
                                    196 	.globl _PL_FLAG
                                    197 	.globl _PH_FLAG
                                    198 	.globl _EX0
                                    199 	.globl _ET0
                                    200 	.globl _EX1
                                    201 	.globl _ET1
                                    202 	.globl _ES
                                    203 	.globl _ET2
                                    204 	.globl _E_DIS
                                    205 	.globl _EA
                                    206 	.globl _P
                                    207 	.globl _F1
                                    208 	.globl _OV
                                    209 	.globl _RS0
                                    210 	.globl _RS1
                                    211 	.globl _F0
                                    212 	.globl _AC
                                    213 	.globl _CY
                                    214 	.globl _I2CS_INT_ST
                                    215 	.globl _I2CX_INT
                                    216 	.globl _LED_STATUS
                                    217 	.globl _LED_DMA_H
                                    218 	.globl _LED_DMA_L
                                    219 	.globl _LED_DMA
                                    220 	.globl _LED_PWM_OE
                                    221 	.globl _LED_COMMON
                                    222 	.globl _ADC_CHAN
                                    223 	.globl _ADC_DAT_H
                                    224 	.globl _ADC_DAT_L
                                    225 	.globl _ADC_DAT
                                    226 	.globl _ADC_CTRL
                                    227 	.globl _SPI1_CK_SE
                                    228 	.globl _SPI1_CTRL
                                    229 	.globl _SPI1_DATA
                                    230 	.globl _SPI1_STAT
                                    231 	.globl _SIF1
                                    232 	.globl _SBAUD1
                                    233 	.globl _SBUF1
                                    234 	.globl _SCON1
                                    235 	.globl _SPI0_SETUP
                                    236 	.globl _SPI0_CK_SE
                                    237 	.globl _SPI0_CTRL
                                    238 	.globl _SPI0_DATA
                                    239 	.globl _SPI0_STAT
                                    240 	.globl _T2CAP1H
                                    241 	.globl _T2CAP1L
                                    242 	.globl _T2CAP1
                                    243 	.globl _TH2
                                    244 	.globl _TL2
                                    245 	.globl _T2COUNT
                                    246 	.globl _RCAP2H
                                    247 	.globl _RCAP2L
                                    248 	.globl _RCAP2
                                    249 	.globl _T2MOD
                                    250 	.globl _T2CON
                                    251 	.globl _SBUF
                                    252 	.globl _SCON
                                    253 	.globl _TH1
                                    254 	.globl _TH0
                                    255 	.globl _TL1
                                    256 	.globl _TL0
                                    257 	.globl _TMOD
                                    258 	.globl _TCON
                                    259 	.globl _XBUS_AUX
                                    260 	.globl _P7
                                    261 	.globl _P6_DIR
                                    262 	.globl _P6_OUT_PU
                                    263 	.globl _P6_IN
                                    264 	.globl _P5_DIR
                                    265 	.globl _P5_OUT_PU
                                    266 	.globl _P5_IN
                                    267 	.globl _P4_LED_KEY
                                    268 	.globl _P4_DIR_PU
                                    269 	.globl _P4_MOD_OC
                                    270 	.globl _P4
                                    271 	.globl _P3_DIR_PU
                                    272 	.globl _P3_MOD_OC
                                    273 	.globl _P3
                                    274 	.globl _P2_DIR_PU
                                    275 	.globl _P2_MOD_OC
                                    276 	.globl _P2
                                    277 	.globl _P1_DIR_PU
                                    278 	.globl _P1_MOD_OC
                                    279 	.globl _P1
                                    280 	.globl _P0_DIR_PU
                                    281 	.globl _P0_MOD_OC
                                    282 	.globl _P0
                                    283 	.globl _ROM_CTRL
                                    284 	.globl _ROM_DATA_HH
                                    285 	.globl _ROM_DATA_HL
                                    286 	.globl _ROM_DATA_HI
                                    287 	.globl _ROM_ADDR_H
                                    288 	.globl _ROM_ADDR_L
                                    289 	.globl _ROM_ADDR
                                    290 	.globl _GPIO_IE
                                    291 	.globl _IP_EX
                                    292 	.globl _IE_EX
                                    293 	.globl _IP
                                    294 	.globl _IE
                                    295 	.globl _WDOG_COUNT
                                    296 	.globl _RESET_KEEP
                                    297 	.globl _WAKE_CTRL
                                    298 	.globl _CLOCK_CFG
                                    299 	.globl _POWER_CFG
                                    300 	.globl _PCON
                                    301 	.globl _GLOBAL_CFG
                                    302 	.globl _SAFE_MOD
                                    303 	.globl _DPH
                                    304 	.globl _DPL
                                    305 	.globl _SP
                                    306 	.globl _A_INV
                                    307 	.globl _B
                                    308 	.globl _ACC
                                    309 	.globl _PSW
                                    310 	.globl _disable_action_cache
                                    311 	.globl _tap_code_delay_PARM_2
                                    312 	.globl _process_action_PARM_2
                                    313 	.globl _action_exec_PARM_1
                                    314 	.globl _tp_buttons
                                    315 	.globl _action_exec
                                    316 	.globl _ak820_action_exec
                                    317 	.globl _process_record
                                    318 	.globl _process_record_handler
                                    319 	.globl _process_action
                                    320 	.globl _register_code
                                    321 	.globl _unregister_code
                                    322 	.globl _tap_code_delay
                                    323 	.globl _tap_code
                                    324 	.globl _register_mods
                                    325 	.globl _unregister_mods
                                    326 	.globl _register_weak_mods
                                    327 	.globl _unregister_weak_mods
                                    328 	.globl _clear_keyboard
                                    329 	.globl _clear_keyboard_but_mods
                                    330 	.globl _clear_keyboard_but_mods_and_keys
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000027                        593 _process_record_sloc0_1_0:
      000027                        594 	.ds 1
      000028                        595 _process_action_sloc0_1_0:
      000028                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; overlayable items in internal ram
                                    599 ;--------------------------------------------------------
                                    600 ;--------------------------------------------------------
                                    601 ; indirectly addressable internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area ISEG    (DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; absolute internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area IABS    (ABS,DATA)
                                    608 	.area IABS    (ABS,DATA)
                                    609 ;--------------------------------------------------------
                                    610 ; bit data
                                    611 ;--------------------------------------------------------
                                    612 	.area BSEG    (BIT)
      000021                        613 _process_action_sloc1_1_0:
      000021                        614 	.ds 1
                                    615 ;--------------------------------------------------------
                                    616 ; paged external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area PSEG    (PAG,XDATA)
                                    619 ;--------------------------------------------------------
                                    620 ; uninitialized external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area XSEG    (XDATA)
      000864                        623 _tp_buttons::
      000864                        624 	.ds 2
      000866                        625 _action_exec_PARM_1:
      000866                        626 	.ds 6
      00086C                        627 _action_exec_record_10001_630:
      00086C                        628 	.ds 9
      000875                        629 _ak820_action_exec_event_10000_634:
      000875                        630 	.ds 2
      000877                        631 _ak820_action_exec_snapshot_10000_635:
      000877                        632 	.ds 6
      00087D                        633 _process_record_record_10000_638:
      00087D                        634 	.ds 3
      000880                        635 _process_record_handler_record_argument_10000_647:
      000880                        636 	.ds 3
      000883                        637 _process_record_handler_action_10000_648:
      000883                        638 	.ds 2
      000885                        639 _process_action_PARM_2:
      000885                        640 	.ds 2
      000887                        641 _process_action_record_argument_10000_659:
      000887                        642 	.ds 3
      00088A                        643 _process_action_on_40000_682:
      00088A                        644 	.ds 1
      00088B                        645 _register_code_code_10000_716:
      00088B                        646 	.ds 1
      00088C                        647 _unregister_code_code_10000_730:
      00088C                        648 	.ds 1
      00088D                        649 _tap_code_delay_PARM_2:
      00088D                        650 	.ds 2
      00088F                        651 _tap_code_delay_code_10000_743:
      00088F                        652 	.ds 1
      000890                        653 _tap_code_code_10000_750:
      000890                        654 	.ds 1
      000891                        655 _register_mods_mods_10000_752:
      000891                        656 	.ds 1
      000892                        657 _unregister_mods_mods_10000_756:
      000892                        658 	.ds 1
      000893                        659 _register_weak_mods_mods_10000_760:
      000893                        660 	.ds 1
      000894                        661 _unregister_weak_mods_mods_10000_764:
      000894                        662 	.ds 1
                                    663 ;--------------------------------------------------------
                                    664 ; absolute external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XABS    (ABS,XDATA)
                                    667 ;--------------------------------------------------------
                                    668 ; initialized external ram data
                                    669 ;--------------------------------------------------------
                                    670 	.area XISEG   (XDATA)
      000E16                        671 _disable_action_cache::
      000E16                        672 	.ds 1
                                    673 	.area HOME    (CODE)
                                    674 	.area GSINIT0 (CODE)
                                    675 	.area GSINIT1 (CODE)
                                    676 	.area GSINIT2 (CODE)
                                    677 	.area GSINIT3 (CODE)
                                    678 	.area GSINIT4 (CODE)
                                    679 	.area GSINIT5 (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area CSEG    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; global & static initialisations
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    701 ;------------------------------------------------------------
                                    702 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    703 ;------------------------------------------------------------
                                    704 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function action_exec
                                    715 ;	-----------------------------------------
      007394                        716 _action_exec:
                                    717 ;	quantum/action.c:92: ak820_dynamic_macro_task(event.time);
      007394 90 08 68         [24]  718 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007397 12 37 F4         [24]  719 	lcall	_ak820_outline_0005
      00739A 12 3B 26         [24]  720 	lcall	_ak820_dynamic_macro_task
                                    721 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      00739D 90 08 68         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0073A0 12 37 F4         [24]  723 	lcall	_ak820_outline_0005
      0073A3 12 36 04         [24]  724 	lcall	_ak820_combo_tick
                                    725 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      0073A6 90 08 66         [24]  726 	mov	dptr,#_action_exec_PARM_1
      0073A9 12 47 9B         [24]  727 	lcall	_ak820_tapping_before
      0073AC E5 82            [12]  728 	mov	a, dpl
      0073AE 70 01            [24]  729 	jnz	00102$
      0073B0 22               [24]  730 	ret
      0073B1                        731 00102$:
                                    732 ;	quantum/action.c:116: if (event.pressed) {
      0073B1 90 08 6B         [24]  733 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0073B4 E0               [24]  734 	movx	a,@dptr
      0073B5 60 03            [24]  735 	jz	00104$
                                    736 ;	quantum/action.c:118: clear_weak_mods();
      0073B7 12 85 31         [24]  737 	lcall	_clear_weak_mods
      0073BA                        738 00104$:
                                    739 ;	quantum/action.c:130: record.event = event;
      0073BA 90 0D F6         [24]  740 	mov	dptr,#___memcpy_PARM_2
      0073BD 74 66            [12]  741 	mov	a,#_action_exec_PARM_1
      0073BF F0               [24]  742 	movx	@dptr,a
      0073C0 74 08            [12]  743 	mov	a,#(_action_exec_PARM_1 >> 8)
      0073C2 12 38 70         [24]  744 	lcall	_ak820_outline_0093
      0073C5 12 7B 42         [24]  745 	lcall	_ak820_outline_0070
      0073C8 90 08 6C         [24]  746 	mov	dptr,#_action_exec_record_10001_630
      0073CB F5 F0            [12]  747 	mov	b,a
      0073CD 12 BC D8         [24]  748 	lcall	___memcpy
                                    749 ;	quantum/action.c:132: record.tap.count = 0;
      0073D0 90 08 72         [24]  750 	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
      0073D3 E0               [24]  751 	movx	a,@dptr
      0073D4 54 0F            [12]  752 	anl	a,#0x0f
      0073D6 F0               [24]  753 	movx	@dptr,a
                                    754 ;	quantum/action.c:137: record.keycode = 0;
      0073D7 90 08 73         [24]  755 	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
      0073DA 12 52 B7         [24]  756 	lcall	_ak820_outline_0181
                                    757 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0073DD 90 08 70         [24]  758 	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
      0073E0 E0               [24]  759 	movx	a,@dptr
      0073E1 60 0D            [24]  760 	jz	00107$
      0073E3 90 08 6C         [24]  761 	mov	dptr,#_action_exec_record_10001_630
      0073E6 75 F0 00         [24]  762 	mov	b, #0x00
      0073E9 12 A3 08         [24]  763 	lcall	_pre_process_record_quantum
      0073EC E5 82            [12]  764 	mov	a, dpl
      0073EE 60 14            [24]  765 	jz	00110$
      0073F0                        766 00107$:
                                    767 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      0073F0 90 08 6C         [24]  768 	mov	dptr,#_action_exec_record_10001_630
      0073F3 12 48 7A         [24]  769 	lcall	_ak820_tapping_process
      0073F6 E5 82            [12]  770 	mov	a, dpl
      0073F8 70 01            [24]  771 	jnz	00106$
      0073FA 22               [24]  772 	ret
      0073FB                        773 00106$:
                                    774 ;	quantum/action.c:175: process_record(&record);
      0073FB 90 08 6C         [24]  775 	mov	dptr,#_action_exec_record_10001_630
      0073FE 75 F0 00         [24]  776 	mov	b, #0x00
                                    777 ;	quantum/action.c:190: }
      007401 02 74 41         [24]  778 	ljmp	_process_record
      007404                        779 00110$:
      007404 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'ak820_action_exec'
                                    783 ;------------------------------------------------------------
                                    784 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    785 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_action_exec
                                    790 ;	-----------------------------------------
      007405                        791 _ak820_action_exec:
      007405 12 38 82         [24]  792 	lcall	_ak820_outline_0108
      007408 90 08 75         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_634
      00740B 12 38 87         [24]  794 	lcall	_ak820_outline_0109
                                    795 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      00740E 90 08 75         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_634
      007411 12 38 6A         [24]  797 	lcall	_ak820_outline_0085
      007414 7F 00            [12]  798 	mov	r7,#0x00
      007416 90 0D F6         [24]  799 	mov	dptr,#___memcpy_PARM_2
      007419 ED               [12]  800 	mov	a,r5
      00741A 12 38 29         [24]  801 	lcall	_ak820_outline_0017
      00741D 12 7B 42         [24]  802 	lcall	_ak820_outline_0070
      007420 90 08 77         [24]  803 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      007423 F5 F0            [12]  804 	mov	b,a
      007425 12 BC D8         [24]  805 	lcall	___memcpy
                                    806 ;	quantum/action.c:197: action_exec(snapshot);
      007428 90 0D F6         [24]  807 	mov	dptr,#___memcpy_PARM_2
      00742B 74 77            [12]  808 	mov	a,#_ak820_action_exec_snapshot_10000_635
      00742D F0               [24]  809 	movx	@dptr,a
      00742E 74 08            [12]  810 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      007430 12 38 70         [24]  811 	lcall	_ak820_outline_0093
      007433 12 7B 42         [24]  812 	lcall	_ak820_outline_0070
      007436 90 08 66         [24]  813 	mov	dptr,#_action_exec_PARM_1
      007439 F5 F0            [12]  814 	mov	b,a
      00743B 12 BC D8         [24]  815 	lcall	___memcpy
                                    816 ;	quantum/action.c:198: }
      00743E 02 73 94         [24]  817 	ljmp	_action_exec
                                    818 ;------------------------------------------------------------
                                    819 ;Allocation info for local variables in function 'process_record_nocache'
                                    820 ;------------------------------------------------------------
                                    821 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    822 ;------------------------------------------------------------
                                    823 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    824 ;	-----------------------------------------
                                    825 ;	 function process_record
                                    826 ;	-----------------------------------------
      007441                        827 _process_record:
      007441 12 46 62         [24]  828 	lcall	_ak820_outline_0037
      007444 90 08 7D         [24]  829 	mov	dptr,#_process_record_record_10000_638
      007447 12 38 29         [24]  830 	lcall	_ak820_outline_0017
                                    831 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      00744A 90 08 7D         [24]  832 	mov	dptr,#_process_record_record_10000_638
      00744D 12 52 64         [24]  833 	lcall	_ak820_outline_0013
      007450 74 04            [12]  834 	mov	a,#0x04
      007452 12 7A FE         [24]  835 	lcall	_ak820_outline_0006
      007455 12 BD B1         [24]  836 	lcall	__gptrget
      007458 70 01            [24]  837 	jnz	00102$
                                    838 ;	quantum/action.c:338: return;
      00745A 22               [24]  839 	ret
      00745B                        840 00102$:
                                    841 ;	quantum/action.c:342: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      00745B 74 01            [12]  842 	mov	a,#0x01
      00745D 12 7A FE         [24]  843 	lcall	_ak820_outline_0006
      007460 12 BD B1         [24]  844 	lcall	__gptrget
      007463 FA               [12]  845 	mov	r2,a
      007464 BA 10 00         [24]  846 	cjne	r2,#0x10,00192$
      007467                        847 00192$:
      007467 50 4B            [24]  848 	jnc	00104$
      007469 8D 02            [24]  849 	mov	ar2,r5
      00746B 8E 03            [24]  850 	mov	ar3,r6
      00746D 8F 04            [24]  851 	mov	ar4,r7
      00746F 12 38 A6         [24]  852 	lcall	_ak820_outline_0136
      007472 8C F0            [24]  853 	mov	b,r4
      007474 12 BD B1         [24]  854 	lcall	__gptrget
      007477 FA               [12]  855 	mov	r2,a
      007478 BA 08 00         [24]  856 	cjne	r2,#0x08,00194$
      00747B                        857 00194$:
      00747B 50 37            [24]  858 	jnc	00104$
      00747D 90 09 DC         [24]  859 	mov	dptr,#_ak820_macro_primitive
      007480 E0               [24]  860 	movx	a,@dptr
      007481 70 31            [24]  861 	jnz	00104$
                                    862 ;	quantum/action.c:343: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007483 90 0C 4D         [24]  863 	mov	dptr,#_get_record_keycode_PARM_2
      007486 74 01            [12]  864 	mov	a,#0x01
      007488 12 52 6D         [24]  865 	lcall	_ak820_outline_0031
      00748B 12 A2 CA         [24]  866 	lcall	_get_record_keycode
      00748E 12 46 A4         [24]  867 	lcall	_ak820_outline_0125
      007491 90 08 7D         [24]  868 	mov	dptr,#_process_record_record_10000_638
      007494 12 7B 29         [24]  869 	lcall	_ak820_outline_0023
      007497 74 05            [12]  870 	mov	a,#0x05
      007499 2B               [12]  871 	add	a, r3
      00749A FB               [12]  872 	mov	r3,a
      00749B E4               [12]  873 	clr	a
      00749C 3C               [12]  874 	addc	a, r4
      00749D FC               [12]  875 	mov	r4,a
      00749E 12 33 FC         [24]  876 	lcall	_ak820_outline_0123
      0074A1 8D F0            [24]  877 	mov	b,r5
      0074A3 12 BD B1         [24]  878 	lcall	__gptrget
      0074A6 90 04 AE         [24]  879 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0074A9 12 46 86         [24]  880 	lcall	_ak820_outline_0071
      0074AC 12 39 7D         [24]  881 	lcall	_ak820_dynamic_macro_process
      0074AF E5 82            [12]  882 	mov	a, dpl
      0074B1 70 01            [24]  883 	jnz	00104$
      0074B3 22               [24]  884 	ret
      0074B4                        885 00104$:
                                    886 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0074B4 90 08 7D         [24]  887 	mov	dptr,#_process_record_record_10000_638
      0074B7 12 52 64         [24]  888 	lcall	_ak820_outline_0013
      0074BA 8D 02            [24]  889 	mov	ar2,r5
      0074BC 8E 03            [24]  890 	mov	ar3,r6
      0074BE 8F 04            [24]  891 	mov	ar4,r7
      0074C0 90 0D F6         [24]  892 	mov	dptr,#___memcpy_PARM_2
      0074C3 EA               [12]  893 	mov	a,r2
      0074C4 12 7B 8D         [24]  894 	lcall	_ak820_outline_0186
      0074C7 EC               [12]  895 	mov	a,r4
      0074C8 A3               [24]  896 	inc	dptr
      0074C9 F0               [24]  897 	movx	@dptr,a
      0074CA 90 0D F9         [24]  898 	mov	dptr,#___memcpy_PARM_3
      0074CD 12 52 A9         [24]  899 	lcall	_ak820_outline_0111
      0074D0 90 06 7A         [24]  900 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074D3 F5 F0            [12]  901 	mov	b,a
      0074D5 C0 07            [24]  902 	push	ar7
      0074D7 C0 06            [24]  903 	push	ar6
      0074D9 C0 05            [24]  904 	push	ar5
      0074DB 12 BC D8         [24]  905 	lcall	___memcpy
      0074DE 12 46 D5         [24]  906 	lcall	_ak820_tapping_source
      0074E1 AC 82            [24]  907 	mov	r4, dpl
      0074E3 D0 05            [24]  908 	pop	ar5
      0074E5 D0 06            [24]  909 	pop	ar6
      0074E7 D0 07            [24]  910 	pop	ar7
                                    911 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0074E9 74 05            [12]  912 	mov	a,#0x05
      0074EB 12 7B 0C         [24]  913 	lcall	_ak820_outline_0014
      0074EE 12 BD B1         [24]  914 	lcall	__gptrget
      0074F1 FB               [12]  915 	mov	r3,a
                                    916 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      0074F2 74 07            [12]  917 	mov	a,#0x07
      0074F4 2D               [12]  918 	add	a, r5
      0074F5 F8               [12]  919 	mov	r0,a
      0074F6 E4               [12]  920 	clr	a
      0074F7 3E               [12]  921 	addc	a, r6
      0074F8 F9               [12]  922 	mov	r1,a
      0074F9 8F 02            [24]  923 	mov	ar2,r7
      0074FB 90 0C 4D         [24]  924 	mov	dptr,#_get_record_keycode_PARM_2
      0074FE 74 01            [12]  925 	mov	a,#0x01
      007500 12 52 6D         [24]  926 	lcall	_ak820_outline_0031
      007503 C0 04            [24]  927 	push	ar4
      007505 C0 03            [24]  928 	push	ar3
      007507 C0 02            [24]  929 	push	ar2
      007509 C0 01            [24]  930 	push	ar1
      00750B C0 00            [24]  931 	push	ar0
      00750D 12 A2 CA         [24]  932 	lcall	_get_record_keycode
      007510 12 46 A4         [24]  933 	lcall	_ak820_outline_0125
      007513 D0 00            [24]  934 	pop	ar0
      007515 D0 01            [24]  935 	pop	ar1
      007517 D0 02            [24]  936 	pop	ar2
      007519 D0 03            [24]  937 	pop	ar3
      00751B D0 04            [24]  938 	pop	ar4
      00751D 12 38 B1         [24]  939 	lcall	_ak820_outline_0144
      007520 8A F0            [24]  940 	mov	b,r2
      007522 EE               [12]  941 	mov	a,r6
      007523 12 BD 76         [24]  942 	lcall	__gptrput
      007526 A3               [24]  943 	inc	dptr
      007527 EF               [12]  944 	mov	a,r7
      007528 12 BD 76         [24]  945 	lcall	__gptrput
                                    946 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00752B 90 08 7D         [24]  947 	mov	dptr,#_process_record_record_10000_638
      00752E 12 52 64         [24]  948 	lcall	_ak820_outline_0013
      007531 74 07            [12]  949 	mov	a,#0x07
      007533 12 7B 53         [24]  950 	lcall	_ak820_outline_0079
      007536 12 BD B1         [24]  951 	lcall	__gptrget
      007539 F8               [12]  952 	mov	r0,a
      00753A A3               [24]  953 	inc	dptr
      00753B 12 BD B1         [24]  954 	lcall	__gptrget
      00753E F9               [12]  955 	mov	r1,a
      00753F 90 06 8A         [24]  956 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007542 EC               [12]  957 	mov	a,r4
      007543 F0               [24]  958 	movx	@dptr,a
      007544 90 06 8B         [24]  959 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007547 EB               [12]  960 	mov	a,r3
      007548 F0               [24]  961 	movx	@dptr,a
      007549 12 38 B1         [24]  962 	lcall	_ak820_outline_0144
      00754C C0 07            [24]  963 	push	ar7
      00754E C0 06            [24]  964 	push	ar6
      007550 C0 05            [24]  965 	push	ar5
      007552 C0 04            [24]  966 	push	ar4
      007554 C0 03            [24]  967 	push	ar3
      007556 12 4A 35         [24]  968 	lcall	_ak820_oneshot_process
      007559 E5 82            [12]  969 	mov	a, dpl
      00755B D0 03            [24]  970 	pop	ar3
      00755D D0 04            [24]  971 	pop	ar4
      00755F D0 05            [24]  972 	pop	ar5
      007561 D0 06            [24]  973 	pop	ar6
      007563 D0 07            [24]  974 	pop	ar7
      007565 70 01            [24]  975 	jnz	00109$
      007567 22               [24]  976 	ret
      007568                        977 00109$:
                                    978 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      007568 12 70 F6         [24]  979 	lcall	_ak820_outline_0050
      00756B C0 04            [24]  980 	push	ar4
      00756D C0 03            [24]  981 	push	ar3
      00756F 12 A3 94         [24]  982 	lcall	_process_record_quantum
      007572 E5 82            [12]  983 	mov	a, dpl
      007574 D0 03            [24]  984 	pop	ar3
      007576 D0 04            [24]  985 	pop	ar4
      007578 70 0A            [24]  986 	jnz	00111$
                                    987 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00757A 90 05 F2         [24]  988 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00757D EB               [12]  989 	mov	a,r3
      00757E F0               [24]  990 	movx	@dptr,a
      00757F 8C 82            [24]  991 	mov	dpl, r4
                                    992 ;	quantum/action.c:360: return;
      007581 02 2E BB         [24]  993 	ljmp	_ak820_oneshot_post
      007584                        994 00111$:
                                    995 ;	quantum/action.c:364: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      007584 90 08 7D         [24]  996 	mov	dptr,#_process_record_record_10000_638
      007587 12 52 64         [24]  997 	lcall	_ak820_outline_0013
      00758A 74 01            [12]  998 	mov	a,#0x01
      00758C 12 7B 53         [24]  999 	lcall	_ak820_outline_0079
      00758F 12 BD B1         [24] 1000 	lcall	__gptrget
      007592 F8               [12] 1001 	mov	r0,a
      007593 B8 10 00         [24] 1002 	cjne	r0,#0x10,00200$
      007596                       1003 00200$:
      007596 50 21            [24] 1004 	jnc	00114$
      007598 12 70 F6         [24] 1005 	lcall	_ak820_outline_0050
      00759B 12 BD B1         [24] 1006 	lcall	__gptrget
      00759E FD               [12] 1007 	mov	r5,a
      00759F BD 08 00         [24] 1008 	cjne	r5,#0x08,00202$
      0075A2                       1009 00202$:
      0075A2 50 15            [24] 1010 	jnc	00114$
      0075A4 C0 04            [24] 1011 	push	ar4
      0075A6 C0 03            [24] 1012 	push	ar3
      0075A8 12 A6 BC         [24] 1013 	lcall	_get_repeat_key_count
      0075AB E5 82            [12] 1014 	mov	a, dpl
      0075AD D0 03            [24] 1015 	pop	ar3
      0075AF D0 04            [24] 1016 	pop	ar4
      0075B1 70 06            [24] 1017 	jnz	00114$
      0075B3 90 09 DC         [24] 1018 	mov	dptr,#_ak820_macro_primitive
      0075B6 E0               [24] 1019 	movx	a,@dptr
      0075B7 60 05            [24] 1020 	jz	00115$
      0075B9                       1021 00114$:
      0075B9 75 27 00         [24] 1022 	mov	_process_record_sloc0_1_0,#0x00
      0075BC 80 03            [24] 1023 	sjmp	00116$
      0075BE                       1024 00115$:
      0075BE 75 27 01         [24] 1025 	mov	_process_record_sloc0_1_0,#0x01
      0075C1                       1026 00116$:
      0075C1 90 04 AD         [24] 1027 	mov	dptr,#_ak820_dynamic_macro_source
      0075C4 E5 27            [12] 1028 	mov	a,_process_record_sloc0_1_0
      0075C6 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/action.c:366: process_record_handler(record);
      0075C7 90 08 7D         [24] 1031 	mov	dptr,#_process_record_record_10000_638
      0075CA 12 52 3E         [24] 1032 	lcall	_ak820_outline_0001
      0075CD C0 04            [24] 1033 	push	ar4
      0075CF C0 03            [24] 1034 	push	ar3
      0075D1 12 75 F0         [24] 1035 	lcall	_process_record_handler
                                   1036 ;	quantum/action.c:368: ak820_dynamic_macro_source = false;
      0075D4 90 04 AD         [24] 1037 	mov	dptr,#_ak820_dynamic_macro_source
      0075D7 E4               [12] 1038 	clr	a
      0075D8 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/action.c:370: post_process_record_quantum(record);
      0075D9 90 08 7D         [24] 1041 	mov	dptr,#_process_record_record_10000_638
      0075DC 12 52 3E         [24] 1042 	lcall	_ak820_outline_0001
      0075DF 12 A3 69         [24] 1043 	lcall	_post_process_record_quantum
      0075E2 D0 03            [24] 1044 	pop	ar3
      0075E4 D0 04            [24] 1045 	pop	ar4
                                   1046 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075E6 90 05 F2         [24] 1047 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075E9 EB               [12] 1048 	mov	a,r3
      0075EA F0               [24] 1049 	movx	@dptr,a
      0075EB 8C 82            [24] 1050 	mov	dpl, r4
                                   1051 ;	quantum/action.c:374: }
      0075ED 02 2E BB         [24] 1052 	ljmp	_ak820_oneshot_post
                                   1053 ;------------------------------------------------------------
                                   1054 ;Allocation info for local variables in function 'process_record_handler'
                                   1055 ;------------------------------------------------------------
                                   1056 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
                                   1057 ;record        Allocated with name '_process_record_handler_record_10000_648'
                                   1058 ;action        Allocated with name '_process_record_handler_action_10000_648'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function process_record_handler
                                   1063 ;	-----------------------------------------
      0075F0                       1064 _process_record_handler:
      0075F0 12 46 62         [24] 1065 	lcall	_ak820_outline_0037
      0075F3 90 08 80         [24] 1066 	mov	dptr,#_process_record_handler_record_argument_10000_647
      0075F6 12 38 29         [24] 1067 	lcall	_ak820_outline_0017
                                   1068 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075F9 90 08 80         [24] 1069 	mov	dptr,#_process_record_handler_record_argument_10000_647
      0075FC 12 37 FE         [24] 1070 	lcall	_ak820_outline_0008
                                   1071 ;	quantum/action.c:387: if (record->keycode) {
      0075FF 4C               [12] 1072 	orl	a,r4
      007600 60 19            [24] 1073 	jz	00102$
                                   1074 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      007602 12 38 97         [24] 1075 	lcall	_ak820_outline_0124
      007605 C0 07            [24] 1076 	push	ar7
      007607 C0 06            [24] 1077 	push	ar6
      007609 12 99 0F         [24] 1078 	lcall	_action_for_keycode
      00760C 12 46 B5         [24] 1079 	lcall	_ak820_outline_0149
      00760F D0 06            [24] 1080 	pop	ar6
      007611 D0 07            [24] 1081 	pop	ar7
      007613 90 08 83         [24] 1082 	mov	dptr,#_process_record_handler_action_10000_648
      007616 12 38 5E         [24] 1083 	lcall	_ak820_outline_0072
      007619 80 2B            [24] 1084 	sjmp	00104$
      00761B                       1085 00102$:
                                   1086 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00761B 12 7B 1A         [24] 1087 	lcall	_ak820_outline_0020
      00761E 7A 00            [12] 1088 	mov	r2,#0x00
      007620 12 46 AF         [24] 1089 	lcall	_ak820_outline_0143
      007623 12 46 50         [24] 1090 	lcall	_ak820_outline_0012
      007626 E0               [24] 1091 	movx	a,@dptr
      007627 90 09 BF         [24] 1092 	mov	dptr,#_ak820_resolve_key_PARM_2
      00762A F0               [24] 1093 	movx	@dptr,a
      00762B 8D 82            [24] 1094 	mov	dpl, r5
      00762D 8C 83            [24] 1095 	mov	dph, r4
      00762F C0 07            [24] 1096 	push	ar7
      007631 C0 06            [24] 1097 	push	ar6
      007633 12 7E D3         [24] 1098 	lcall	_ak820_resolve_key
      007636 12 99 0F         [24] 1099 	lcall	_action_for_keycode
      007639 12 46 B5         [24] 1100 	lcall	_ak820_outline_0149
      00763C D0 06            [24] 1101 	pop	ar6
      00763E D0 07            [24] 1102 	pop	ar7
      007640 90 08 83         [24] 1103 	mov	dptr,#_process_record_handler_action_10000_648
      007643 12 38 5E         [24] 1104 	lcall	_ak820_outline_0072
                                   1105 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007646                       1106 00104$:
                                   1107 ;	quantum/action.c:411: process_action(record, action);
      007646 7D 00            [12] 1108 	mov	r5,#0x00
      007648 90 0D F6         [24] 1109 	mov	dptr,#___memcpy_PARM_2
      00764B 74 83            [12] 1110 	mov	a,#_process_record_handler_action_10000_648
      00764D F0               [24] 1111 	movx	@dptr,a
      00764E 74 08            [12] 1112 	mov	a,#(_process_record_handler_action_10000_648 >> 8)
      007650 12 38 70         [24] 1113 	lcall	_ak820_outline_0093
      007653 90 0D F9         [24] 1114 	mov	dptr,#___memcpy_PARM_3
      007656 12 52 A9         [24] 1115 	lcall	_ak820_outline_0111
      007659 90 08 85         [24] 1116 	mov	dptr,#_process_action_PARM_2
      00765C F5 F0            [12] 1117 	mov	b,a
      00765E C0 07            [24] 1118 	push	ar7
      007660 C0 06            [24] 1119 	push	ar6
      007662 C0 05            [24] 1120 	push	ar5
      007664 12 BC D8         [24] 1121 	lcall	___memcpy
      007667 D0 05            [24] 1122 	pop	ar5
      007669 D0 06            [24] 1123 	pop	ar6
      00766B D0 07            [24] 1124 	pop	ar7
      00766D 12 73 0C         [24] 1125 	lcall	_ak820_outline_0064
                                   1126 ;	quantum/action.c:412: }
      007670 02 76 73         [24] 1127 	ljmp	_process_action
                                   1128 ;------------------------------------------------------------
                                   1129 ;Allocation info for local variables in function 'register_mouse'
                                   1130 ;------------------------------------------------------------
                                   1131 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1132 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function process_action
                                   1137 ;	-----------------------------------------
      007673                       1138 _process_action:
      007673 12 46 62         [24] 1139 	lcall	_ak820_outline_0037
      007676 90 08 87         [24] 1140 	mov	dptr,#_process_action_record_argument_10000_659
      007679 12 38 29         [24] 1141 	lcall	_ak820_outline_0017
                                   1142 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00767C 90 08 87         [24] 1143 	mov	dptr,#_process_action_record_argument_10000_659
      00767F 12 37 F4         [24] 1144 	lcall	_ak820_outline_0005
                                   1145 ;	quantum/action.c:483: pressed = record->event.pressed;
      007682 A3               [24] 1146 	inc	dptr
      007683 A3               [24] 1147 	inc	dptr
      007684 A3               [24] 1148 	inc	dptr
      007685 A3               [24] 1149 	inc	dptr
      007686 A3               [24] 1150 	inc	dptr
      007687 E0               [24] 1151 	movx	a,@dptr
      007688 F5 28            [12] 1152 	mov	_process_action_sloc0_1_0,a
                                   1153 ;	quantum/action.c:507: switch (action.kind.id) {
      00768A 90 08 86         [24] 1154 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00768D E0               [24] 1155 	movx	a,@dptr
      00768E C4               [12] 1156 	swap	a
      00768F 54 0F            [12] 1157 	anl	a,#0x0f
      007691 FD               [12] 1158 	mov  r5,a
      007692 24 F4            [12] 1159 	add	a,#0xff - 0x0b
      007694 50 03            [24] 1160 	jnc	00434$
      007696 02 79 14         [24] 1161 	ljmp	00181$
      007699                       1162 00434$:
                                   1163 ;	free result
      007699 ED               [12] 1164 	mov	a,r5
      00769A 24 0A            [12] 1165 	add	a,#(00435$-3-.)
      00769C 83               [24] 1166 	movc	a,@a+pc
      00769D F5 82            [12] 1167 	mov	dpl,a
      00769F ED               [12] 1168 	mov	a,r5
      0076A0 24 10            [12] 1169 	add	a,#(00436$-3-.)
      0076A2 83               [24] 1170 	movc	a,@a+pc
      0076A3 F5 83            [12] 1171 	mov	dph,a
      0076A5 E4               [12] 1172 	clr	a
      0076A6 73               [24] 1173 	jmp	@a+dptr
      0076A7                       1174 00435$:
      0076A7 BF                    1175 	.db	00102$
      0076A8 BF                    1176 	.db	00102$
      0076A9 14                    1177 	.db	00181$
      0076AA 14                    1178 	.db	00181$
      0076AB 49                    1179 	.db	00123$
      0076AC 14                    1180 	.db	00181$
      0076AD 14                    1181 	.db	00181$
      0076AE 14                    1182 	.db	00181$
      0076AF A9                    1183 	.db	00131$
      0076B0 7B                    1184 	.db	00147$
      0076B1 A1                    1185 	.db	00152$
      0076B2 A1                    1186 	.db	00152$
      0076B3                       1187 00436$:
      0076B3 76                    1188 	.db	00102$>>8
      0076B4 76                    1189 	.db	00102$>>8
      0076B5 79                    1190 	.db	00181$>>8
      0076B6 79                    1191 	.db	00181$>>8
      0076B7 77                    1192 	.db	00123$>>8
      0076B8 79                    1193 	.db	00181$>>8
      0076B9 79                    1194 	.db	00181$>>8
      0076BA 79                    1195 	.db	00181$>>8
      0076BB 77                    1196 	.db	00131$>>8
      0076BC 78                    1197 	.db	00147$>>8
      0076BD 78                    1198 	.db	00152$>>8
      0076BE 78                    1199 	.db	00152$>>8
                                   1200 ;	quantum/action.c:510: case ACT_RMODS: {
      0076BF                       1201 00102$:
                                   1202 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076BF 90 08 86         [24] 1203 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076C2 E0               [24] 1204 	movx	a,@dptr
      0076C3 54 F0            [12] 1205 	anl	a,#0xf0
      0076C5 70 06            [24] 1206 	jnz	00194$
      0076C7 12 7B 6A         [24] 1207 	lcall	_ak820_outline_0113
      0076CA FD               [12] 1208 	mov	r5,a
      0076CB 80 07            [24] 1209 	sjmp	00195$
      0076CD                       1210 00194$:
      0076CD 12 7B 6A         [24] 1211 	lcall	_ak820_outline_0113
      0076D0 C4               [12] 1212 	swap	a
      0076D1 54 F0            [12] 1213 	anl	a,#0xf0
      0076D3 FD               [12] 1214 	mov	r5,a
      0076D4                       1215 00195$:
                                   1216 ;	quantum/action.c:513: if (pressed) {
      0076D4 E5 28            [12] 1217 	mov	a,_process_action_sloc0_1_0
      0076D6 60 35            [24] 1218 	jz	00119$
                                   1219 ;	quantum/action.c:514: if (mods) {
      0076D8 ED               [12] 1220 	mov	a,r5
      0076D9 60 29            [24] 1221 	jz	00110$
                                   1222 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076DB 12 7B 7C         [24] 1223 	lcall	_ak820_outline_0158
      0076DE FC               [12] 1224 	mov	r4,a
      0076DF BC E0 00         [24] 1225 	cjne	r4,#0xe0,00440$
      0076E2                       1226 00440$:
      0076E2 40 07            [24] 1227 	jc	00108$
      0076E4 12 7B 7C         [24] 1228 	lcall	_ak820_outline_0158
      0076E7 24 18            [12] 1229 	add	a,#0xff - 0xe7
      0076E9 50 0A            [24] 1230 	jnc	00104$
                                   1231 ;	free result
      0076EB                       1232 00108$:
      0076EB 7B 85            [12] 1233 	mov	r3,#_process_action_PARM_2
      0076ED 7C 08            [12] 1234 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076EF 12 33 FC         [24] 1235 	lcall	_ak820_outline_0123
      0076F2 E0               [24] 1236 	movx	a,@dptr
      0076F3 70 07            [24] 1237 	jnz	00105$
      0076F5                       1238 00104$:
                                   1239 ;	quantum/action.c:519: add_owned_mods(mods);
      0076F5 8D 82            [24] 1240 	mov	dpl, r5
      0076F7 12 81 3D         [24] 1241 	lcall	_add_owned_mods
      0076FA 80 05            [24] 1242 	sjmp	00106$
      0076FC                       1243 00105$:
                                   1244 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0076FC 8D 82            [24] 1245 	mov	dpl, r5
      0076FE 12 81 5B         [24] 1246 	lcall	_add_owned_weak_mods
      007701                       1247 00106$:
                                   1248 ;	quantum/action.c:523: send_keyboard_report();
      007701 12 84 78         [24] 1249 	lcall	_send_keyboard_report
      007704                       1250 00110$:
                                   1251 ;	quantum/action.c:525: register_code(action.key.code);
      007704 12 7B 4C         [24] 1252 	lcall	_ak820_outline_0077
      007707 12 79 2B         [24] 1253 	lcall	_register_code
      00770A 02 79 14         [24] 1254 	ljmp	00181$
      00770D                       1255 00119$:
                                   1256 ;	quantum/action.c:527: unregister_code(action.key.code);
      00770D 12 7B 4C         [24] 1257 	lcall	_ak820_outline_0077
      007710 C0 05            [24] 1258 	push	ar5
      007712 12 79 A7         [24] 1259 	lcall	_unregister_code
      007715 D0 05            [24] 1260 	pop	ar5
                                   1261 ;	quantum/action.c:528: if (mods) {
      007717 ED               [12] 1262 	mov	a,r5
      007718 70 03            [24] 1263 	jnz	00444$
      00771A 02 79 14         [24] 1264 	ljmp	00181$
      00771D                       1265 00444$:
                                   1266 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00771D 12 7B 7C         [24] 1267 	lcall	_ak820_outline_0158
      007720 FC               [12] 1268 	mov	r4,a
      007721 BC E0 00         [24] 1269 	cjne	r4,#0xe0,00445$
      007724                       1270 00445$:
      007724 40 07            [24] 1271 	jc	00115$
      007726 12 7B 7C         [24] 1272 	lcall	_ak820_outline_0158
      007729 24 18            [12] 1273 	add	a,#0xff - 0xe7
      00772B 50 0A            [24] 1274 	jnc	00111$
                                   1275 ;	free result
      00772D                       1276 00115$:
      00772D 7B 85            [12] 1277 	mov	r3,#_process_action_PARM_2
      00772F 7C 08            [12] 1278 	mov	r4,#(_process_action_PARM_2 >> 8)
      007731 12 33 FC         [24] 1279 	lcall	_ak820_outline_0123
      007734 E0               [24] 1280 	movx	a,@dptr
      007735 70 07            [24] 1281 	jnz	00112$
      007737                       1282 00111$:
                                   1283 ;	quantum/action.c:530: del_owned_mods(mods);
      007737 8D 82            [24] 1284 	mov	dpl, r5
      007739 12 81 4D         [24] 1285 	lcall	_del_owned_mods
      00773C 80 05            [24] 1286 	sjmp	00113$
      00773E                       1287 00112$:
                                   1288 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      00773E 8D 82            [24] 1289 	mov	dpl, r5
      007740 12 81 6B         [24] 1290 	lcall	_del_owned_weak_mods
      007743                       1291 00113$:
                                   1292 ;	quantum/action.c:534: send_keyboard_report();
      007743 12 84 78         [24] 1293 	lcall	_send_keyboard_report
                                   1294 ;	quantum/action.c:537: } break;
      007746 02 79 14         [24] 1295 	ljmp	00181$
                                   1296 ;	quantum/action.c:614: case ACT_USAGE:
      007749                       1297 00123$:
                                   1298 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007749 74 07            [12] 1299 	mov	a,#0x07
      00774B 12 38 31         [24] 1300 	lcall	_ak820_outline_0021
      00774E 12 4B 86         [24] 1301 	lcall	_ak820_outline_0009
      007751 C3               [12] 1302 	clr	c
      007752 EC               [12] 1303 	mov	a,r4
      007753 94 A5            [12] 1304 	subb	a,#0xa5
      007755 ED               [12] 1305 	mov	a,r5
      007756 94 00            [12] 1306 	subb	a,#0x00
      007758 40 15            [24] 1307 	jc	00125$
      00775A 74 C2            [12] 1308 	mov	a,#0xc2
      00775C 9C               [12] 1309 	subb	a,r4
      00775D E4               [12] 1310 	clr	a
      00775E 9D               [12] 1311 	subb	a,r5
      00775F 40 0E            [24] 1312 	jc	00125$
                                   1313 ;	free result
                                   1314 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007761 90 0A E9         [24] 1315 	mov	dptr,#_owned_usage_key_PARM_2
      007764 E5 28            [12] 1316 	mov	a,_process_action_sloc0_1_0
      007766 F0               [24] 1317 	movx	@dptr,a
      007767 8E 82            [24] 1318 	mov	dpl, r6
      007769 12 83 23         [24] 1319 	lcall	_owned_usage_key
                                   1320 ;	quantum/action.c:622: break;
      00776C 02 79 14         [24] 1321 	ljmp	00181$
      00776F                       1322 00125$:
                                   1323 ;	quantum/action.c:625: switch (action.usage.page) {
      00776F 12 7B 61         [24] 1324 	lcall	_ak820_outline_0089
      007772 FF               [12] 1325 	mov	r7,a
      007773 60 08            [24] 1326 	jz	00127$
      007775 BF 01 02         [24] 1327 	cjne	r7,#0x01,00452$
      007778 80 19            [24] 1328 	sjmp	00128$
      00777A                       1329 00452$:
      00777A 02 79 14         [24] 1330 	ljmp	00181$
                                   1331 ;	quantum/action.c:626: case PAGE_SYSTEM:
      00777D                       1332 00127$:
                                   1333 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      00777D E5 28            [12] 1334 	mov	a,_process_action_sloc0_1_0
      00777F 60 05            [24] 1335 	jz	00196$
      007781 12 7B 71         [24] 1336 	lcall	_ak820_outline_0131
      007784 80 04            [24] 1337 	sjmp	00197$
      007786                       1338 00196$:
      007786 7E 00            [12] 1339 	mov	r6,#0x00
      007788 7F 00            [12] 1340 	mov	r7,#0x00
      00778A                       1341 00197$:
      00778A 12 38 8C         [24] 1342 	lcall	_ak820_outline_0118
      00778D 12 70 80         [24] 1343 	lcall	_host_system_send
                                   1344 ;	quantum/action.c:628: break;
      007790 02 79 14         [24] 1345 	ljmp	00181$
                                   1346 ;	quantum/action.c:629: case PAGE_CONSUMER:
      007793                       1347 00128$:
                                   1348 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      007793 E5 28            [12] 1349 	mov	a,_process_action_sloc0_1_0
      007795 60 05            [24] 1350 	jz	00198$
      007797 12 7B 71         [24] 1351 	lcall	_ak820_outline_0131
      00779A 80 04            [24] 1352 	sjmp	00199$
      00779C                       1353 00198$:
      00779C 7E 00            [12] 1354 	mov	r6,#0x00
      00779E 7F 00            [12] 1355 	mov	r7,#0x00
      0077A0                       1356 00199$:
      0077A0 12 38 8C         [24] 1357 	lcall	_ak820_outline_0118
      0077A3 12 70 B0         [24] 1358 	lcall	_host_consumer_send
                                   1359 ;	quantum/action.c:633: break;
      0077A6 02 79 14         [24] 1360 	ljmp	00181$
                                   1361 ;	quantum/action.c:640: case ACT_LAYER: {
      0077A9                       1362 00131$:
                                   1363 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      0077A9 90 08 86         [24] 1364 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077AC E0               [24] 1365 	movx	a,@dptr
      0077AD 54 03            [12] 1366 	anl	a,#0x03
      0077AF 90 08 8A         [24] 1367 	mov	dptr,#_process_action_on_40000_682
      0077B2 F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0077B3 E0               [24] 1370 	movx	a,@dptr
      0077B4 FF               [12] 1371 	mov	r7,a
      0077B5 60 11            [24] 1372 	jz	00200$
      0077B7 E5 28            [12] 1373 	mov	a,_process_action_sloc0_1_0
      0077B9 60 07            [24] 1374 	jz	00202$
      0077BB 8F 06            [24] 1375 	mov	ar6,r7
      0077BD 53 06 01         [24] 1376 	anl	ar6,#0x01
      0077C0 80 10            [24] 1377 	sjmp	00201$
      0077C2                       1378 00202$:
      0077C2 74 02            [12] 1379 	mov	a,#0x02
      0077C4 5F               [12] 1380 	anl	a,r7
      0077C5 FE               [12] 1381 	mov	r6,a
      0077C6 80 0A            [24] 1382 	sjmp	00201$
      0077C8                       1383 00200$:
      0077C8 E5 28            [12] 1384 	mov	a,_process_action_sloc0_1_0
      0077CA B4 01 00         [24] 1385 	cjne	a,#0x01,00457$
      0077CD                       1386 00457$:
      0077CD 92 21            [24] 1387 	mov  _process_action_sloc1_1_0,c
      0077CF E4               [12] 1388 	clr	a
      0077D0 33               [12] 1389 	rlc	a
      0077D1 FE               [12] 1390 	mov	r6,a
      0077D2                       1391 00201$:
      0077D2 EE               [12] 1392 	mov	a,r6
      0077D3 70 03            [24] 1393 	jnz	00458$
      0077D5 02 79 14         [24] 1394 	ljmp	00181$
      0077D8                       1395 00458$:
                                   1396 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0077D8 12 7B 7C         [24] 1397 	lcall	_ak820_outline_0158
      0077DB C4               [12] 1398 	swap	a
      0077DC 03               [12] 1399 	rr	a
      0077DD 54 07            [12] 1400 	anl	a,#0x07
      0077DF 25 E0            [12] 1401 	add	a,acc
      0077E1 25 E0            [12] 1402 	add	a,acc
      0077E3 FF               [12] 1403 	mov	r7,a
                                   1404 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0077E4 12 7B 7C         [24] 1405 	lcall	_ak820_outline_0158
      0077E7 54 0F            [12] 1406 	anl	a,#0x0f
      0077E9 FE               [12] 1407 	mov	r6,a
      0077EA 8F F0            [24] 1408 	mov	b,r7
      0077EC 05 F0            [12] 1409 	inc	b
      0077EE EE               [12] 1410 	mov	a,r6
      0077EF 80 02            [24] 1411 	sjmp	00460$
      0077F1                       1412 00459$:
      0077F1 25 E0            [12] 1413 	add	a,acc
      0077F3                       1414 00460$:
      0077F3 D5 F0 FB         [24] 1415 	djnz	b,00459$
      0077F6 FE               [12] 1416 	mov	r6,a
                                   1417 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0077F7 12 7B 7C         [24] 1418 	lcall	_ak820_outline_0158
      0077FA 30 E4 11         [24] 1419 	jnb	acc.4,00204$
      0077FD 8F F0            [24] 1420 	mov	b,r7
      0077FF 05 F0            [12] 1421 	inc	b
      007801 74 0F            [12] 1422 	mov	a,#0x0f
      007803 80 02            [24] 1423 	sjmp	00463$
      007805                       1424 00462$:
      007805 25 E0            [12] 1425 	add	a,acc
      007807                       1426 00463$:
      007807 D5 F0 FB         [24] 1427 	djnz	b,00462$
      00780A F4               [12] 1428 	cpl	a
      00780B FF               [12] 1429 	mov	r7,a
      00780C 80 02            [24] 1430 	sjmp	00205$
      00780E                       1431 00204$:
      00780E 7F 00            [12] 1432 	mov	r7,#0x00
      007810                       1433 00205$:
                                   1434 ;	quantum/action.c:648: bits |= mask;
      007810 EE               [12] 1435 	mov	a,r6
      007811 42 07            [12] 1436 	orl	ar7,a
                                   1437 ;	quantum/action.c:649: if (!on) {
      007813 90 08 8A         [24] 1438 	mov	dptr,#_process_action_on_40000_682
      007816 E0               [24] 1439 	movx	a,@dptr
      007817 70 31            [24] 1440 	jnz	00143$
                                   1441 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      007819 12 7B 61         [24] 1442 	lcall	_ak820_outline_0089
      00781C FE               [12] 1443 	mov	r6,a
      00781D 2E               [12] 1444 	add	a,r6
                                   1445 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      00781E 90 78 22         [24] 1446 	mov	dptr,#00465$
      007821 73               [24] 1447 	jmp	@a+dptr
      007822                       1448 00465$:
      007822 80 06            [24] 1449 	sjmp	00132$
      007824 80 0C            [24] 1450 	sjmp	00133$
      007826 80 12            [24] 1451 	sjmp	00134$
      007828 80 18            [24] 1452 	sjmp	00135$
      00782A                       1453 00132$:
      00782A 8F 82            [24] 1454 	mov	dpl, r7
      00782C 12 7B E1         [24] 1455 	lcall	_default_layer_and
      00782F 02 79 14         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007832                       1458 00133$:
      007832 8F 82            [24] 1459 	mov	dpl, r7
      007834 12 7B D0         [24] 1460 	lcall	_default_layer_or
      007837 02 79 14         [24] 1461 	ljmp	00181$
                                   1462 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      00783A                       1463 00134$:
      00783A 8F 82            [24] 1464 	mov	dpl, r7
      00783C 12 7B F7         [24] 1465 	lcall	_default_layer_xor
      00783F 02 79 14         [24] 1466 	ljmp	00181$
                                   1467 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007842                       1468 00135$:
      007842 8F 82            [24] 1469 	mov	dpl, r7
      007844 12 7B C5         [24] 1470 	lcall	_default_layer_set
                                   1471 ;	quantum/action.c:655: }
      007847 02 79 14         [24] 1472 	ljmp	00181$
      00784A                       1473 00143$:
                                   1474 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      00784A 12 7B 61         [24] 1475 	lcall	_ak820_outline_0089
      00784D FE               [12] 1476 	mov	r6,a
      00784E 2E               [12] 1477 	add	a,r6
                                   1478 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      00784F 90 78 53         [24] 1479 	mov	dptr,#00466$
      007852 73               [24] 1480 	jmp	@a+dptr
      007853                       1481 00466$:
      007853 80 06            [24] 1482 	sjmp	00137$
      007855 80 0C            [24] 1483 	sjmp	00138$
      007857 80 12            [24] 1484 	sjmp	00139$
      007859 80 18            [24] 1485 	sjmp	00140$
      00785B                       1486 00137$:
      00785B 8F 82            [24] 1487 	mov	dpl, r7
      00785D 12 7D 7B         [24] 1488 	lcall	_layer_and
      007860 02 79 14         [24] 1489 	ljmp	00181$
                                   1490 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007863                       1491 00138$:
      007863 8F 82            [24] 1492 	mov	dpl, r7
      007865 12 7D 6A         [24] 1493 	lcall	_layer_or
      007868 02 79 14         [24] 1494 	ljmp	00181$
                                   1495 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      00786B                       1496 00139$:
      00786B 8F 82            [24] 1497 	mov	dpl, r7
      00786D 12 7D 91         [24] 1498 	lcall	_layer_xor
      007870 02 79 14         [24] 1499 	ljmp	00181$
                                   1500 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007873                       1501 00140$:
      007873 8F 82            [24] 1502 	mov	dpl, r7
      007875 12 7D 07         [24] 1503 	lcall	_layer_state_set
                                   1504 ;	quantum/action.c:665: break;
      007878 02 79 14         [24] 1505 	ljmp	00181$
                                   1506 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      00787B                       1507 00147$:
                                   1508 ;	quantum/action.c:668: if (pressed) {
      00787B E5 28            [12] 1509 	mov	a,_process_action_sloc0_1_0
      00787D 60 11            [24] 1510 	jz	00149$
                                   1511 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      00787F 12 7B 6A         [24] 1512 	lcall	_ak820_outline_0113
      007882 F5 82            [12] 1513 	mov	dpl,a
      007884 12 7C 67         [24] 1514 	lcall	_layer_hold_on
                                   1515 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007887 12 7B 4C         [24] 1516 	lcall	_ak820_outline_0077
      00788A 12 7A 69         [24] 1517 	lcall	_register_mods
      00788D 02 79 14         [24] 1518 	ljmp	00181$
      007890                       1519 00149$:
                                   1520 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007890 12 7B 4C         [24] 1521 	lcall	_ak820_outline_0077
      007893 12 7A 7D         [24] 1522 	lcall	_unregister_mods
                                   1523 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007896 12 7B 6A         [24] 1524 	lcall	_ak820_outline_0113
      007899 F5 82            [12] 1525 	mov	dpl,a
      00789B 12 7C 9F         [24] 1526 	lcall	_layer_hold_off
                                   1527 ;	quantum/action.c:675: break;
      00789E 02 79 14         [24] 1528 	ljmp	00181$
                                   1529 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      0078A1                       1530 00152$:
                                   1531 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      0078A1 12 7B 7C         [24] 1532 	lcall	_ak820_outline_0158
      0078A4 FF               [12] 1533 	mov	r7,a
      0078A5 BF F1 02         [24] 1534 	cjne	r7,#0xf1,00468$
      0078A8 80 0A            [24] 1535 	sjmp	00154$
      0078AA                       1536 00468$:
      0078AA BF F2 02         [24] 1537 	cjne	r7,#0xf2,00469$
      0078AD 80 19            [24] 1538 	sjmp	00155$
      0078AF                       1539 00469$:
                                   1540 ;	quantum/action.c:694: momentary_layer_action:
      0078AF BF F3 3B         [24] 1541 	cjne	r7,#0xf3,00160$
      0078B2 80 28            [24] 1542 	sjmp	00156$
      0078B4                       1543 00154$:
                                   1544 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0078B4 E5 28            [12] 1545 	mov	a,_process_action_sloc0_1_0
      0078B6 60 08            [24] 1546 	jz	00206$
      0078B8 12 7B 32         [24] 1547 	lcall	_ak820_outline_0042
      0078BB 12 7C 67         [24] 1548 	lcall	_layer_hold_on
      0078BE 80 54            [24] 1549 	sjmp	00181$
      0078C0                       1550 00206$:
      0078C0 12 7B 32         [24] 1551 	lcall	_ak820_outline_0042
      0078C3 12 7C 9F         [24] 1552 	lcall	_layer_hold_off
                                   1553 ;	quantum/action.c:696: break;
                                   1554 ;	quantum/action.c:697: case OP_OFF_ON:
      0078C6 80 4C            [24] 1555 	sjmp	00181$
      0078C8                       1556 00155$:
                                   1557 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0078C8 E5 28            [12] 1558 	mov	a,_process_action_sloc0_1_0
      0078CA 60 08            [24] 1559 	jz	00208$
      0078CC 12 7B 32         [24] 1560 	lcall	_ak820_outline_0042
      0078CF 12 7D 4C         [24] 1561 	lcall	_layer_off
      0078D2 80 40            [24] 1562 	sjmp	00181$
      0078D4                       1563 00208$:
      0078D4 12 7B 32         [24] 1564 	lcall	_ak820_outline_0042
      0078D7 12 7D 31         [24] 1565 	lcall	_layer_on
                                   1566 ;	quantum/action.c:699: break;
                                   1567 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0078DA 80 38            [24] 1568 	sjmp	00181$
      0078DC                       1569 00156$:
                                   1570 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0078DC E5 28            [12] 1571 	mov	a,_process_action_sloc0_1_0
      0078DE 60 08            [24] 1572 	jz	00210$
      0078E0 12 7B 32         [24] 1573 	lcall	_ak820_outline_0042
      0078E3 12 7D 1B         [24] 1574 	lcall	_layer_move
      0078E6 80 2C            [24] 1575 	sjmp	00181$
      0078E8                       1576 00210$:
      0078E8 12 7D 15         [24] 1577 	lcall	_layer_clear
                                   1578 ;	quantum/action.c:702: break;
                                   1579 ;	quantum/action.c:748: default:
      0078EB 80 27            [24] 1580 	sjmp	00181$
      0078ED                       1581 00160$:
                                   1582 ;	quantum/action.c:755: if (pressed) {
      0078ED E5 28            [12] 1583 	mov	a,_process_action_sloc0_1_0
      0078EF 60 08            [24] 1584 	jz	00163$
                                   1585 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0078F1 12 7B 4C         [24] 1586 	lcall	_ak820_outline_0077
      0078F4 12 79 2B         [24] 1587 	lcall	_register_code
                                   1588 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0078F7 80 1B            [24] 1589 	sjmp	00181$
      0078F9                       1590 00163$:
                                   1591 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0078F9 12 7B 7C         [24] 1592 	lcall	_ak820_outline_0158
      0078FC FF               [12] 1593 	mov	r7,a
      0078FD BF 39 0E         [24] 1594 	cjne	r7,#0x39,00175$
                                   1595 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007900 7F 50            [12] 1596 	mov	r7,#0x50
      007902                       1597 00187$:
      007902 EF               [12] 1598 	mov	a,r7
      007903 60 09            [24] 1599 	jz	00175$
      007905 90 00 01         [24] 1600 	mov	dptr,#0x0001
      007908 12 5C 38         [24] 1601 	lcall	_mDelaymS
      00790B 1F               [12] 1602 	dec	r7
                                   1603 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      00790C 80 F4            [24] 1604 	sjmp	00187$
      00790E                       1605 00175$:
                                   1606 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      00790E 12 7B 4C         [24] 1607 	lcall	_ak820_outline_0077
      007911 12 79 A7         [24] 1608 	lcall	_unregister_code
                                   1609 ;	quantum/action.c:848: }
      007914                       1610 00181$:
                                   1611 ;	quantum/action.c:869: switch (action.kind.id) {
      007914 90 08 86         [24] 1612 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007917 E0               [24] 1613 	movx	a,@dptr
      007918 C4               [12] 1614 	swap	a
      007919 54 0F            [12] 1615 	anl	a,#0x0f
      00791B FF               [12] 1616 	mov	r7,a
      00791C BF 08 02         [24] 1617 	cjne	r7,#0x08,00478$
      00791F 80 03            [24] 1618 	sjmp	00183$
      007921                       1619 00478$:
      007921 BF 09 06         [24] 1620 	cjne	r7,#0x09,00192$
                                   1621 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007924                       1622 00183$:
                                   1623 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007924 12 6F E5         [24] 1624 	lcall	_host_keyboard_leds
                                   1625 ;	quantum/action.c:880: }
                                   1626 ;	quantum/action.c:933: }
      007927 02 9B C4         [24] 1627 	ljmp	_led_set
      00792A                       1628 00192$:
      00792A 22               [24] 1629 	ret
                                   1630 ;------------------------------------------------------------
                                   1631 ;Allocation info for local variables in function 'register_code'
                                   1632 ;------------------------------------------------------------
                                   1633 ;code          Allocated with name '_register_code_code_10000_716'
                                   1634 ;------------------------------------------------------------
                                   1635 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1636 ;	-----------------------------------------
                                   1637 ;	 function register_code
                                   1638 ;	-----------------------------------------
      00792B                       1639 _register_code:
      00792B E5 82            [12] 1640 	mov	a,dpl
      00792D 90 08 8B         [24] 1641 	mov	dptr,#_register_code_code_10000_716
      007930 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/action.c:940: if (code == KC_NO) {
      007931 E0               [24] 1644 	movx	a,@dptr
      007932 FF               [12] 1645 	mov	r7,a
      007933 70 01            [24] 1646 	jnz	00123$
                                   1647 ;	quantum/action.c:941: return;
      007935 22               [24] 1648 	ret
      007936                       1649 00123$:
                                   1650 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007936 BF 04 00         [24] 1651 	cjne	r7,#0x04,00186$
      007939                       1652 00186$:
      007939 40 21            [24] 1653 	jc	00119$
      00793B EF               [12] 1654 	mov	a,r7
      00793C 24 5B            [12] 1655 	add	a,#0xff - 0xa4
      00793E 40 1C            [24] 1656 	jc	00119$
                                   1657 ;	free result
                                   1658 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007940 8F 82            [24] 1659 	mov	dpl, r7
      007942 C0 07            [24] 1660 	push	ar7
      007944 12 81 E0         [24] 1661 	lcall	_add_owned_key
      007947 E5 82            [12] 1662 	mov	a, dpl
      007949 D0 07            [24] 1663 	pop	ar7
      00794B 70 01            [24] 1664 	jnz	00104$
      00794D 22               [24] 1665 	ret
      00794E                       1666 00104$:
                                   1667 ;	quantum/action.c:983: ak820_dynamic_macro_observe(code, true);
      00794E 90 04 B1         [24] 1668 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007951 74 01            [12] 1669 	mov	a,#0x01
      007953 F0               [24] 1670 	movx	@dptr,a
      007954 8F 82            [24] 1671 	mov	dpl, r7
      007956 12 3A 3B         [24] 1672 	lcall	_ak820_dynamic_macro_observe
                                   1673 ;	quantum/action.c:995: send_keyboard_report();
      007959 02 84 78         [24] 1674 	ljmp	_send_keyboard_report
      00795C                       1675 00119$:
                                   1676 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      00795C 12 7B 81         [24] 1677 	lcall	_ak820_outline_0166
      00795F BF E0 00         [24] 1678 	cjne	r7,#0xe0,00190$
      007962                       1679 00190$:
      007962 40 1A            [24] 1680 	jc	00115$
      007964 EF               [12] 1681 	mov	a,r7
      007965 24 18            [12] 1682 	add	a,#0xff - 0xe7
      007967 40 15            [24] 1683 	jc	00115$
                                   1684 ;	free result
                                   1685 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007969 74 07            [12] 1686 	mov	a,#0x07
      00796B 5F               [12] 1687 	anl	a,r7
      00796C 12 7B 3B         [24] 1688 	lcall	_ak820_outline_0061
      00796F 80 02            [24] 1689 	sjmp	00194$
      007971                       1690 00193$:
      007971 25 E0            [12] 1691 	add	a,acc
      007973                       1692 00194$:
      007973 D5 F0 FB         [24] 1693 	djnz	b,00193$
      007976 F5 82            [12] 1694 	mov	dpl,a
      007978 12 81 3D         [24] 1695 	lcall	_add_owned_mods
                                   1696 ;	quantum/action.c:998: send_keyboard_report();
      00797B 02 84 78         [24] 1697 	ljmp	_send_keyboard_report
      00797E                       1698 00115$:
                                   1699 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00797E 12 7B 81         [24] 1700 	lcall	_ak820_outline_0166
      007981 BF A5 00         [24] 1701 	cjne	r7,#0xa5,00195$
      007984                       1702 00195$:
      007984 40 05            [24] 1703 	jc	00113$
      007986 EF               [12] 1704 	mov	a,r7
      007987 24 58            [12] 1705 	add	a,#0xff - 0xa7
      007989 50 0D            [24] 1706 	jnc	00108$
                                   1707 ;	free result
      00798B                       1708 00113$:
      00798B 12 7B 81         [24] 1709 	lcall	_ak820_outline_0166
      00798E BF A8 00         [24] 1710 	cjne	r7,#0xa8,00198$
      007991                       1711 00198$:
      007991 40 13            [24] 1712 	jc	00125$
      007993 EF               [12] 1713 	mov	a,r7
      007994 24 3D            [12] 1714 	add	a,#0xff - 0xc2
      007996 40 0E            [24] 1715 	jc	00125$
                                   1716 ;	free result
      007998                       1717 00108$:
                                   1718 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007998 12 7B 81         [24] 1719 	lcall	_ak820_outline_0166
      00799B 90 0A E9         [24] 1720 	mov	dptr,#_owned_usage_key_PARM_2
      00799E 74 01            [12] 1721 	mov	a,#0x01
      0079A0 F0               [24] 1722 	movx	@dptr,a
      0079A1 8F 82            [24] 1723 	mov	dpl, r7
                                   1724 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1725 ;	quantum/action.c:1013: }
      0079A3 02 83 23         [24] 1726 	ljmp	_owned_usage_key
      0079A6                       1727 00125$:
      0079A6 22               [24] 1728 	ret
                                   1729 ;------------------------------------------------------------
                                   1730 ;Allocation info for local variables in function 'unregister_code'
                                   1731 ;------------------------------------------------------------
                                   1732 ;code          Allocated with name '_unregister_code_code_10000_730'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function unregister_code
                                   1737 ;	-----------------------------------------
      0079A7                       1738 _unregister_code:
      0079A7 E5 82            [12] 1739 	mov	a,dpl
      0079A9 90 08 8C         [24] 1740 	mov	dptr,#_unregister_code_code_10000_730
      0079AC F0               [24] 1741 	movx	@dptr,a
                                   1742 ;	quantum/action.c:1020: if (code == KC_NO) {
      0079AD E0               [24] 1743 	movx	a,@dptr
      0079AE FF               [12] 1744 	mov	r7,a
      0079AF 70 01            [24] 1745 	jnz	00121$
                                   1746 ;	quantum/action.c:1021: return;
      0079B1 22               [24] 1747 	ret
      0079B2                       1748 00121$:
                                   1749 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      0079B2 BF 04 00         [24] 1750 	cjne	r7,#0x04,00184$
      0079B5                       1751 00184$:
      0079B5 40 1F            [24] 1752 	jc	00117$
      0079B7 EF               [12] 1753 	mov	a,r7
      0079B8 24 5B            [12] 1754 	add	a,#0xff - 0xa4
      0079BA 40 1A            [24] 1755 	jc	00117$
                                   1756 ;	free result
                                   1757 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      0079BC 8F 82            [24] 1758 	mov	dpl, r7
      0079BE C0 07            [24] 1759 	push	ar7
      0079C0 12 82 5A         [24] 1760 	lcall	_del_owned_key
      0079C3 E5 82            [12] 1761 	mov	a, dpl
      0079C5 D0 07            [24] 1762 	pop	ar7
      0079C7 70 01            [24] 1763 	jnz	00102$
      0079C9 22               [24] 1764 	ret
      0079CA                       1765 00102$:
                                   1766 ;	quantum/action.c:1057: ak820_dynamic_macro_observe(code, false);
      0079CA 90 04 B1         [24] 1767 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      0079CD 12 7B 92         [24] 1768 	lcall	_ak820_outline_0188
      0079D0 12 3A 3B         [24] 1769 	lcall	_ak820_dynamic_macro_observe
                                   1770 ;	quantum/action.c:1062: send_keyboard_report();
      0079D3 02 84 78         [24] 1771 	ljmp	_send_keyboard_report
      0079D6                       1772 00117$:
                                   1773 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079D6 12 7B 87         [24] 1774 	lcall	_ak820_outline_0167
      0079D9 BF E0 00         [24] 1775 	cjne	r7,#0xe0,00188$
      0079DC                       1776 00188$:
      0079DC 40 1A            [24] 1777 	jc	00113$
      0079DE EF               [12] 1778 	mov	a,r7
      0079DF 24 18            [12] 1779 	add	a,#0xff - 0xe7
      0079E1 40 15            [24] 1780 	jc	00113$
                                   1781 ;	free result
                                   1782 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0079E3 74 07            [12] 1783 	mov	a,#0x07
      0079E5 5F               [12] 1784 	anl	a,r7
      0079E6 12 7B 3B         [24] 1785 	lcall	_ak820_outline_0061
      0079E9 80 02            [24] 1786 	sjmp	00192$
      0079EB                       1787 00191$:
      0079EB 25 E0            [12] 1788 	add	a,acc
      0079ED                       1789 00192$:
      0079ED D5 F0 FB         [24] 1790 	djnz	b,00191$
      0079F0 F5 82            [12] 1791 	mov	dpl,a
      0079F2 12 81 4D         [24] 1792 	lcall	_del_owned_mods
                                   1793 ;	quantum/action.c:1065: send_keyboard_report();
      0079F5 02 84 78         [24] 1794 	ljmp	_send_keyboard_report
      0079F8                       1795 00113$:
                                   1796 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079F8 12 7B 87         [24] 1797 	lcall	_ak820_outline_0167
      0079FB BF A5 00         [24] 1798 	cjne	r7,#0xa5,00193$
      0079FE                       1799 00193$:
      0079FE 40 05            [24] 1800 	jc	00111$
      007A00 EF               [12] 1801 	mov	a,r7
      007A01 24 58            [12] 1802 	add	a,#0xff - 0xa7
      007A03 50 0D            [24] 1803 	jnc	00106$
                                   1804 ;	free result
      007A05                       1805 00111$:
      007A05 12 7B 87         [24] 1806 	lcall	_ak820_outline_0167
      007A08 BF A8 00         [24] 1807 	cjne	r7,#0xa8,00196$
      007A0B                       1808 00196$:
      007A0B 40 11            [24] 1809 	jc	00123$
      007A0D EF               [12] 1810 	mov	a,r7
      007A0E 24 3D            [12] 1811 	add	a,#0xff - 0xc2
      007A10 40 0C            [24] 1812 	jc	00123$
                                   1813 ;	free result
      007A12                       1814 00106$:
                                   1815 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007A12 12 7B 87         [24] 1816 	lcall	_ak820_outline_0167
      007A15 90 0A E9         [24] 1817 	mov	dptr,#_owned_usage_key_PARM_2
      007A18 12 7B 92         [24] 1818 	lcall	_ak820_outline_0188
                                   1819 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1820 ;	quantum/action.c:1080: }
      007A1B 02 83 23         [24] 1821 	ljmp	_owned_usage_key
      007A1E                       1822 00123$:
      007A1E 22               [24] 1823 	ret
                                   1824 ;------------------------------------------------------------
                                   1825 ;Allocation info for local variables in function 'tap_code_delay'
                                   1826 ;------------------------------------------------------------
                                   1827 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1828 ;code          Allocated with name '_tap_code_delay_code_10000_743'
                                   1829 ;i             Allocated with name '_tap_code_delay_i_20000_745'
                                   1830 ;i             Allocated with name '_tap_code_delay_i_50000_748'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function tap_code_delay
                                   1835 ;	-----------------------------------------
      007A1F                       1836 _tap_code_delay:
      007A1F E5 82            [12] 1837 	mov	a,dpl
      007A21 90 08 8F         [24] 1838 	mov	dptr,#_tap_code_delay_code_10000_743
      007A24 F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	quantum/action.c:1088: register_code(code);
      007A25 E0               [24] 1841 	movx	a,@dptr
      007A26 FF               [12] 1842 	mov	r7,a
      007A27 F5 82            [12] 1843 	mov	dpl,a
      007A29 C0 07            [24] 1844 	push	ar7
      007A2B 12 79 2B         [24] 1845 	lcall	_register_code
      007A2E D0 07            [24] 1846 	pop	ar7
                                   1847 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007A30 90 08 8D         [24] 1848 	mov	dptr,#_tap_code_delay_PARM_2
      007A33 12 38 6A         [24] 1849 	lcall	_ak820_outline_0085
      007A36                       1850 00110$:
      007A36 ED               [12] 1851 	mov	a,r5
      007A37 4E               [12] 1852 	orl	a,r6
      007A38 60 0D            [24] 1853 	jz	00105$
                                   1854 ;	quantum/action.c:1090: wait_ms(1);
      007A3A 90 00 01         [24] 1855 	mov	dptr,#0x0001
      007A3D 12 5C 38         [24] 1856 	lcall	_mDelaymS
                                   1857 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007A40 1D               [12] 1858 	dec	r5
      007A41 BD FF 01         [24] 1859 	cjne	r5,#0xff,00141$
      007A44 1E               [12] 1860 	dec	r6
      007A45                       1861 00141$:
      007A45 80 EF            [24] 1862 	sjmp	00110$
      007A47                       1863 00105$:
                                   1864 ;	quantum/action.c:1092: unregister_code(code);
      007A47 8F 82            [24] 1865 	mov	dpl, r7
                                   1866 ;	quantum/action.c:1093: }
      007A49 02 79 A7         [24] 1867 	ljmp	_unregister_code
                                   1868 ;------------------------------------------------------------
                                   1869 ;Allocation info for local variables in function 'tap_code'
                                   1870 ;------------------------------------------------------------
                                   1871 ;code          Allocated with name '_tap_code_code_10000_750'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function tap_code
                                   1876 ;	-----------------------------------------
      007A4C                       1877 _tap_code:
      007A4C E5 82            [12] 1878 	mov	a,dpl
      007A4E 90 08 90         [24] 1879 	mov	dptr,#_tap_code_code_10000_750
      007A51 F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A52 E0               [24] 1882 	movx	a,@dptr
      007A53 FF               [12] 1883 	mov	r7,a
      007A54 BF 39 04         [24] 1884 	cjne	r7,#0x39,00103$
      007A57 7E 50            [12] 1885 	mov	r6,#0x50
      007A59 80 02            [24] 1886 	sjmp	00104$
      007A5B                       1887 00103$:
      007A5B 7E 00            [12] 1888 	mov	r6,#0x00
      007A5D                       1889 00104$:
      007A5D 90 08 8D         [24] 1890 	mov	dptr,#_tap_code_delay_PARM_2
      007A60 EE               [12] 1891 	mov	a,r6
      007A61 12 38 A1         [24] 1892 	lcall	_ak820_outline_0135
      007A64 8F 82            [24] 1893 	mov	dpl, r7
                                   1894 ;	quantum/action.c:1101: }
      007A66 02 7A 1F         [24] 1895 	ljmp	_tap_code_delay
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'register_mods'
                                   1898 ;------------------------------------------------------------
                                   1899 ;mods          Allocated with name '_register_mods_mods_10000_752'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function register_mods
                                   1904 ;	-----------------------------------------
      007A69                       1905 _register_mods:
      007A69 E5 82            [12] 1906 	mov	a,dpl
      007A6B 90 08 91         [24] 1907 	mov	dptr,#_register_mods_mods_10000_752
      007A6E F0               [24] 1908 	movx	@dptr,a
                                   1909 ;	quantum/action.c:1108: if (mods) {
      007A6F E0               [24] 1910 	movx	a,@dptr
      007A70 FF               [12] 1911 	mov	r7,a
      007A71 E0               [24] 1912 	movx	a,@dptr
      007A72 60 08            [24] 1913 	jz	00103$
                                   1914 ;	quantum/action.c:1109: add_owned_mods(mods);
      007A74 8F 82            [24] 1915 	mov	dpl, r7
      007A76 12 81 3D         [24] 1916 	lcall	_add_owned_mods
                                   1917 ;	quantum/action.c:1110: send_keyboard_report();
                                   1918 ;	quantum/action.c:1112: }
      007A79 02 84 78         [24] 1919 	ljmp	_send_keyboard_report
      007A7C                       1920 00103$:
      007A7C 22               [24] 1921 	ret
                                   1922 ;------------------------------------------------------------
                                   1923 ;Allocation info for local variables in function 'unregister_mods'
                                   1924 ;------------------------------------------------------------
                                   1925 ;mods          Allocated with name '_unregister_mods_mods_10000_756'
                                   1926 ;------------------------------------------------------------
                                   1927 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1928 ;	-----------------------------------------
                                   1929 ;	 function unregister_mods
                                   1930 ;	-----------------------------------------
      007A7D                       1931 _unregister_mods:
      007A7D E5 82            [12] 1932 	mov	a,dpl
      007A7F 90 08 92         [24] 1933 	mov	dptr,#_unregister_mods_mods_10000_756
      007A82 F0               [24] 1934 	movx	@dptr,a
                                   1935 ;	quantum/action.c:1119: if (mods) {
      007A83 E0               [24] 1936 	movx	a,@dptr
      007A84 FF               [12] 1937 	mov	r7,a
      007A85 E0               [24] 1938 	movx	a,@dptr
      007A86 60 08            [24] 1939 	jz	00103$
                                   1940 ;	quantum/action.c:1120: del_owned_mods(mods);
      007A88 8F 82            [24] 1941 	mov	dpl, r7
      007A8A 12 81 4D         [24] 1942 	lcall	_del_owned_mods
                                   1943 ;	quantum/action.c:1121: send_keyboard_report();
                                   1944 ;	quantum/action.c:1123: }
      007A8D 02 84 78         [24] 1945 	ljmp	_send_keyboard_report
      007A90                       1946 00103$:
      007A90 22               [24] 1947 	ret
                                   1948 ;------------------------------------------------------------
                                   1949 ;Allocation info for local variables in function 'register_weak_mods'
                                   1950 ;------------------------------------------------------------
                                   1951 ;mods          Allocated with name '_register_weak_mods_mods_10000_760'
                                   1952 ;------------------------------------------------------------
                                   1953 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1954 ;	-----------------------------------------
                                   1955 ;	 function register_weak_mods
                                   1956 ;	-----------------------------------------
      007A91                       1957 _register_weak_mods:
      007A91 E5 82            [12] 1958 	mov	a,dpl
      007A93 90 08 93         [24] 1959 	mov	dptr,#_register_weak_mods_mods_10000_760
      007A96 F0               [24] 1960 	movx	@dptr,a
                                   1961 ;	quantum/action.c:1130: if (mods) {
      007A97 E0               [24] 1962 	movx	a,@dptr
      007A98 FF               [12] 1963 	mov	r7,a
      007A99 E0               [24] 1964 	movx	a,@dptr
      007A9A 60 08            [24] 1965 	jz	00103$
                                   1966 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007A9C 8F 82            [24] 1967 	mov	dpl, r7
      007A9E 12 81 5B         [24] 1968 	lcall	_add_owned_weak_mods
                                   1969 ;	quantum/action.c:1132: send_keyboard_report();
                                   1970 ;	quantum/action.c:1134: }
      007AA1 02 84 78         [24] 1971 	ljmp	_send_keyboard_report
      007AA4                       1972 00103$:
      007AA4 22               [24] 1973 	ret
                                   1974 ;------------------------------------------------------------
                                   1975 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1976 ;------------------------------------------------------------
                                   1977 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_764'
                                   1978 ;------------------------------------------------------------
                                   1979 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1980 ;	-----------------------------------------
                                   1981 ;	 function unregister_weak_mods
                                   1982 ;	-----------------------------------------
      007AA5                       1983 _unregister_weak_mods:
      007AA5 E5 82            [12] 1984 	mov	a,dpl
      007AA7 90 08 94         [24] 1985 	mov	dptr,#_unregister_weak_mods_mods_10000_764
      007AAA F0               [24] 1986 	movx	@dptr,a
                                   1987 ;	quantum/action.c:1141: if (mods) {
      007AAB E0               [24] 1988 	movx	a,@dptr
      007AAC FF               [12] 1989 	mov	r7,a
      007AAD E0               [24] 1990 	movx	a,@dptr
      007AAE 60 08            [24] 1991 	jz	00103$
                                   1992 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007AB0 8F 82            [24] 1993 	mov	dpl, r7
      007AB2 12 81 6B         [24] 1994 	lcall	_del_owned_weak_mods
                                   1995 ;	quantum/action.c:1143: send_keyboard_report();
                                   1996 ;	quantum/action.c:1145: }
      007AB5 02 84 78         [24] 1997 	ljmp	_send_keyboard_report
      007AB8                       1998 00103$:
      007AB8 22               [24] 1999 	ret
                                   2000 ;------------------------------------------------------------
                                   2001 ;Allocation info for local variables in function 'clear_keyboard'
                                   2002 ;------------------------------------------------------------
                                   2003 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   2004 ;	-----------------------------------------
                                   2005 ;	 function clear_keyboard
                                   2006 ;	-----------------------------------------
      007AB9                       2007 _clear_keyboard:
                                   2008 ;	quantum/action.c:1152: clear_mods();
      007AB9 12 84 FC         [24] 2009 	lcall	_clear_mods
                                   2010 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   2011 ;	quantum/action.c:1154: }
      007ABC 02 7A BF         [24] 2012 	ljmp	_clear_keyboard_but_mods
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2015 ;------------------------------------------------------------
                                   2016 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   2017 ;	-----------------------------------------
                                   2018 ;	 function clear_keyboard_but_mods
                                   2019 ;	-----------------------------------------
      007ABF                       2020 _clear_keyboard_but_mods:
                                   2021 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007ABF 90 0E 1B         [24] 2022 	mov	dptr,#_actual_keyboard_report
      007AC2 12 72 AD         [24] 2023 	lcall	_clear_keys_from_report
                                   2024 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   2025 ;	quantum/action.c:1163: }
      007AC5 02 7A C8         [24] 2026 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2027 ;------------------------------------------------------------
                                   2028 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2029 ;------------------------------------------------------------
                                   2030 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   2031 ;	-----------------------------------------
                                   2032 ;	 function clear_keyboard_but_mods_and_keys
                                   2033 ;	-----------------------------------------
      007AC8                       2034 _clear_keyboard_but_mods_and_keys:
                                   2035 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007AC8 12 4A 0D         [24] 2036 	lcall	_ak820_tapping_cancel
                                   2037 ;	quantum/action.c:1176: ak820_dynamic_macro_cancel();
      007ACB 12 39 6C         [24] 2038 	lcall	_ak820_dynamic_macro_cancel
                                   2039 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007ACE 12 2E F0         [24] 2040 	lcall	_ak820_oneshot_cancel
                                   2041 ;	quantum/action.c:1185: ak820_combo_cancel();
      007AD1 12 35 70         [24] 2042 	lcall	_ak820_combo_cancel
                                   2043 ;	quantum/action.c:1188: repeat_key_cancel();
      007AD4 12 A6 28         [24] 2044 	lcall	_repeat_key_cancel
                                   2045 ;	quantum/action.c:1190: clear_owned_mods();
      007AD7 12 81 7B         [24] 2046 	lcall	_clear_owned_mods
                                   2047 ;	quantum/action.c:1191: clear_owned_keys();
      007ADA 12 81 B3         [24] 2048 	lcall	_clear_owned_keys
                                   2049 ;	quantum/action.c:1192: clear_owned_usages();
      007ADD 12 82 EB         [24] 2050 	lcall	_clear_owned_usages
                                   2051 ;	quantum/action.c:1193: layer_hold_clear();
      007AE0 12 7C D8         [24] 2052 	lcall	_layer_hold_clear
                                   2053 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007AE3 12 A0 70         [24] 2054 	lcall	_clear_macro_tri_layer
                                   2055 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AE6 90 0E 1B         [24] 2056 	mov	dptr,#_actual_keyboard_report
      007AE9 12 72 AD         [24] 2057 	lcall	_clear_keys_from_report
                                   2058 ;	quantum/action.c:1200: host_system_send(0);
      007AEC 90 00 00         [24] 2059 	mov	dptr,#0x0000
      007AEF 12 70 80         [24] 2060 	lcall	_host_system_send
                                   2061 ;	quantum/action.c:1201: host_consumer_send(0);
      007AF2 90 00 00         [24] 2062 	mov	dptr,#0x0000
      007AF5 12 70 B0         [24] 2063 	lcall	_host_consumer_send
                                   2064 ;	quantum/action.c:1203: clear_weak_mods();
      007AF8 12 85 31         [24] 2065 	lcall	_clear_weak_mods
                                   2066 ;	quantum/action.c:1204: send_keyboard_report();
                                   2067 ;	quantum/action.c:1212: }
      007AFB 02 84 78         [24] 2068 	ljmp	_send_keyboard_report
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'is_tap_record'
                                   2071 ;------------------------------------------------------------
                                   2072 ;record        Allocated with name '_is_tap_record_record_10000_780'
                                   2073 ;action        Allocated with name '_is_tap_record_action_10001_784'
                                   2074 ;------------------------------------------------------------
                                   2075 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   2076 ;	-----------------------------------------
                                   2077 	.area CSEG    (CODE)
                                   2078 	.area CONST   (CODE)
                                   2079 	.area XINIT   (CODE)
      00C5A8                       2080 __xinit__disable_action_cache:
      00C5A8 00                    2081 	.db #0x00	;  0
                                   2082 	.area CABS    (ABS,CODE)
                                   2083 
                                   2084 ; Experimental exact instruction outlining.
                                   2085 	.globl _ak820_outline_0001
                                   2086 	.globl _ak820_outline_0005
                                   2087 	.globl _ak820_outline_0006
                                   2088 	.globl _ak820_outline_0008
                                   2089 	.globl _ak820_outline_0009
                                   2090 	.globl _ak820_outline_0012
                                   2091 	.globl _ak820_outline_0013
                                   2092 	.globl _ak820_outline_0014
                                   2093 	.globl _ak820_outline_0017
                                   2094 	.globl _ak820_outline_0020
                                   2095 	.globl _ak820_outline_0021
                                   2096 	.globl _ak820_outline_0023
                                   2097 	.globl _ak820_outline_0031
                                   2098 	.globl _ak820_outline_0037
                                   2099 	.globl _ak820_outline_0042
                                   2100 	.globl _ak820_outline_0050
                                   2101 	.globl _ak820_outline_0061
                                   2102 	.globl _ak820_outline_0064
                                   2103 	.globl _ak820_outline_0070
                                   2104 	.globl _ak820_outline_0071
                                   2105 	.globl _ak820_outline_0072
                                   2106 	.globl _ak820_outline_0077
                                   2107 	.globl _ak820_outline_0079
                                   2108 	.globl _ak820_outline_0085
                                   2109 	.globl _ak820_outline_0089
                                   2110 	.globl _ak820_outline_0093
                                   2111 	.globl _ak820_outline_0108
                                   2112 	.globl _ak820_outline_0109
                                   2113 	.globl _ak820_outline_0111
                                   2114 	.globl _ak820_outline_0113
                                   2115 	.globl _ak820_outline_0118
                                   2116 	.globl _ak820_outline_0123
                                   2117 	.globl _ak820_outline_0124
                                   2118 	.globl _ak820_outline_0125
                                   2119 	.globl _ak820_outline_0131
                                   2120 	.globl _ak820_outline_0135
                                   2121 	.globl _ak820_outline_0136
                                   2122 	.globl _ak820_outline_0143
                                   2123 	.globl _ak820_outline_0144
                                   2124 	.globl _ak820_outline_0149
                                   2125 	.globl _ak820_outline_0158
                                   2126 	.globl _ak820_outline_0166
                                   2127 	.globl _ak820_outline_0167
                                   2128 	.globl _ak820_outline_0181
                                   2129 	.globl _ak820_outline_0186
                                   2130 	.globl _ak820_outline_0188
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0006
      007AFE                       2134 _ak820_outline_0006:
      007AFE 2D               [12] 2135 	add	a,r5
      007AFF FA               [12] 2136 	mov	r2,a
      007B00 E4               [12] 2137 	clr	a
      007B01 3E               [12] 2138 	addc	a,r6
      007B02 FB               [12] 2139 	mov	r3,a
      007B03 8F 04            [24] 2140 	mov	ar4,r7
      007B05 8A 82            [24] 2141 	mov	dpl,r2
      007B07 8B 83            [24] 2142 	mov	dph,r3
      007B09 8C F0            [24] 2143 	mov	b,r4
      007B0B 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0014
      007B0C                       2148 _ak820_outline_0014:
      007B0C 2D               [12] 2149 	add	a,r5
      007B0D F9               [12] 2150 	mov	r1,a
      007B0E E4               [12] 2151 	clr	a
      007B0F 3E               [12] 2152 	addc	a,r6
      007B10 FA               [12] 2153 	mov	r2,a
      007B11 8F 03            [24] 2154 	mov	ar3,r7
      007B13 89 82            [24] 2155 	mov	dpl,r1
      007B15 8A 83            [24] 2156 	mov	dph,r2
      007B17 8B F0            [24] 2157 	mov	b,r3
      007B19 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0020
      007B1A                       2162 _ak820_outline_0020:
      007B1A 8E 82            [24] 2163 	mov	dpl,r6
      007B1C 8F 83            [24] 2164 	mov	dph,r7
      007B1E A3               [24] 2165 	inc	dptr
      007B1F E0               [24] 2166 	movx	a,@dptr
      007B20 FC               [12] 2167 	mov	r4,a
      007B21 7D 00            [12] 2168 	mov	r5,#0x00
      007B23 8E 82            [24] 2169 	mov	dpl,r6
      007B25 8F 83            [24] 2170 	mov	dph,r7
      007B27 E0               [24] 2171 	movx	a,@dptr
      007B28 22               [24] 2172 	ret
                                   2173 
                                   2174 	.area CSEG (CODE)
                                   2175 ; function ak820_outline_0023
      007B29                       2176 _ak820_outline_0023:
      007B29 E0               [24] 2177 	movx	a,@dptr
      007B2A FB               [12] 2178 	mov	r3,a
      007B2B A3               [24] 2179 	inc	dptr
      007B2C E0               [24] 2180 	movx	a,@dptr
      007B2D FC               [12] 2181 	mov	r4,a
      007B2E A3               [24] 2182 	inc	dptr
      007B2F E0               [24] 2183 	movx	a,@dptr
      007B30 FD               [12] 2184 	mov	r5,a
      007B31 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0042
      007B32                       2189 _ak820_outline_0042:
      007B32 90 08 86         [24] 2190 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B35 E0               [24] 2191 	movx	a,@dptr
      007B36 54 1F            [12] 2192 	anl	a,#0x1f
      007B38 F5 82            [12] 2193 	mov	dpl,a
      007B3A 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0061
      007B3B                       2198 _ak820_outline_0061:
      007B3B F5 F0            [12] 2199 	mov	b,a
      007B3D 05 F0            [12] 2200 	inc	b
      007B3F 74 01            [12] 2201 	mov	a,#0x01
      007B41 22               [24] 2202 	ret
                                   2203 
                                   2204 	.area CSEG (CODE)
                                   2205 ; function ak820_outline_0070
      007B42                       2206 _ak820_outline_0070:
      007B42 90 0D F9         [24] 2207 	mov	dptr,#___memcpy_PARM_3
      007B45 74 06            [12] 2208 	mov	a,#0x06
      007B47 F0               [24] 2209 	movx	@dptr,a
      007B48 E4               [12] 2210 	clr	a
      007B49 A3               [24] 2211 	inc	dptr
      007B4A F0               [24] 2212 	movx	@dptr,a
      007B4B 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0077
      007B4C                       2217 _ak820_outline_0077:
      007B4C 90 08 85         [24] 2218 	mov	dptr,#_process_action_PARM_2
      007B4F E0               [24] 2219 	movx	a,@dptr
      007B50 F5 82            [12] 2220 	mov	dpl,a
      007B52 22               [24] 2221 	ret
                                   2222 
                                   2223 	.area CSEG (CODE)
                                   2224 ; function ak820_outline_0079
      007B53                       2225 _ak820_outline_0079:
      007B53 2D               [12] 2226 	add	a,r5
      007B54 F8               [12] 2227 	mov	r0,a
      007B55 E4               [12] 2228 	clr	a
      007B56 3E               [12] 2229 	addc	a,r6
      007B57 F9               [12] 2230 	mov	r1,a
      007B58 8F 02            [24] 2231 	mov	ar2,r7
      007B5A 88 82            [24] 2232 	mov	dpl,r0
      007B5C 89 83            [24] 2233 	mov	dph,r1
      007B5E 8A F0            [24] 2234 	mov	b,r2
      007B60 22               [24] 2235 	ret
                                   2236 
                                   2237 	.area CSEG (CODE)
                                   2238 ; function ak820_outline_0089
      007B61                       2239 _ak820_outline_0089:
      007B61 90 08 86         [24] 2240 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B64 E0               [24] 2241 	movx	a,@dptr
      007B65 03               [12] 2242 	rr	a
      007B66 03               [12] 2243 	rr	a
      007B67 54 03            [12] 2244 	anl	a,#0x03
      007B69 22               [24] 2245 	ret
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0113
      007B6A                       2249 _ak820_outline_0113:
      007B6A 90 08 86         [24] 2250 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B6D E0               [24] 2251 	movx	a,@dptr
      007B6E 54 0F            [12] 2252 	anl	a,#0x0f
      007B70 22               [24] 2253 	ret
                                   2254 
                                   2255 	.area CSEG (CODE)
                                   2256 ; function ak820_outline_0131
      007B71                       2257 _ak820_outline_0131:
      007B71 90 08 85         [24] 2258 	mov	dptr,#_process_action_PARM_2
      007B74 E0               [24] 2259 	movx	a,@dptr
      007B75 FE               [12] 2260 	mov	r6,a
      007B76 A3               [24] 2261 	inc	dptr
      007B77 E0               [24] 2262 	movx	a,@dptr
      007B78 54 03            [12] 2263 	anl	a,#0x03
      007B7A FF               [12] 2264 	mov	r7,a
      007B7B 22               [24] 2265 	ret
                                   2266 
                                   2267 	.area CSEG (CODE)
                                   2268 ; function ak820_outline_0158
      007B7C                       2269 _ak820_outline_0158:
      007B7C 90 08 85         [24] 2270 	mov	dptr,#_process_action_PARM_2
      007B7F E0               [24] 2271 	movx	a,@dptr
      007B80 22               [24] 2272 	ret
                                   2273 
                                   2274 	.area CSEG (CODE)
                                   2275 ; function ak820_outline_0166
      007B81                       2276 _ak820_outline_0166:
      007B81 90 08 8B         [24] 2277 	mov	dptr,#_register_code_code_10000_716
      007B84 E0               [24] 2278 	movx	a,@dptr
      007B85 FF               [12] 2279 	mov	r7,a
      007B86 22               [24] 2280 	ret
                                   2281 
                                   2282 	.area CSEG (CODE)
                                   2283 ; function ak820_outline_0167
      007B87                       2284 _ak820_outline_0167:
      007B87 90 08 8C         [24] 2285 	mov	dptr,#_unregister_code_code_10000_730
      007B8A E0               [24] 2286 	movx	a,@dptr
      007B8B FF               [12] 2287 	mov	r7,a
      007B8C 22               [24] 2288 	ret
                                   2289 
                                   2290 	.area CSEG (CODE)
                                   2291 ; function ak820_outline_0186
      007B8D                       2292 _ak820_outline_0186:
      007B8D F0               [24] 2293 	movx	@dptr,a
      007B8E EB               [12] 2294 	mov	a,r3
      007B8F A3               [24] 2295 	inc	dptr
      007B90 F0               [24] 2296 	movx	@dptr,a
      007B91 22               [24] 2297 	ret
                                   2298 
                                   2299 	.area CSEG (CODE)
                                   2300 ; function ak820_outline_0188
      007B92                       2301 _ak820_outline_0188:
      007B92 E4               [12] 2302 	clr	a
      007B93 F0               [24] 2303 	movx	@dptr,a
      007B94 8F 82            [24] 2304 	mov	dpl,r7
      007B96 22               [24] 2305 	ret
