;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module action
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_combo_cancel
	.globl _ak820_combo_tick
	.globl _ak820_oneshot_cancel
	.globl _ak820_oneshot_post
	.globl _ak820_oneshot_process
	.globl _ak820_tapping_source
	.globl _ak820_tapping_cancel
	.globl _ak820_tapping_process
	.globl _ak820_tapping_before
	.globl _ak820_dynamic_macro_cancel
	.globl _ak820_dynamic_macro_task
	.globl _ak820_dynamic_macro_observe
	.globl _ak820_dynamic_macro_process
	.globl _pre_process_record_quantum
	.globl _get_record_keycode
	.globl _get_repeat_key_count
	.globl _repeat_key_cancel
	.globl _clear_owned_usages
	.globl _owned_usage_key
	.globl _clear_owned_keys
	.globl _del_owned_key
	.globl _add_owned_key
	.globl _clear_owned_mods
	.globl _del_owned_weak_mods
	.globl _add_owned_weak_mods
	.globl _del_owned_mods
	.globl _add_owned_mods
	.globl _clear_weak_mods
	.globl _clear_mods
	.globl _send_keyboard_report
	.globl _layer_hold_clear
	.globl _layer_hold_off
	.globl _layer_hold_on
	.globl _ak820_resolve_key
	.globl _layer_xor
	.globl _layer_and
	.globl _layer_or
	.globl _layer_off
	.globl _layer_on
	.globl _layer_move
	.globl _layer_clear
	.globl _layer_state_set
	.globl _default_layer_xor
	.globl _default_layer_and
	.globl _default_layer_or
	.globl _default_layer_set
	.globl _post_process_record_quantum
	.globl _process_record_quantum
	.globl _action_for_keycode
	.globl _mDelaymS
	.globl _host_consumer_send
	.globl _host_system_send
	.globl _host_keyboard_leds
	.globl _led_set
	.globl _clear_keys_from_report
	.globl ___memcpy
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _disable_action_cache
	.globl _tap_code_delay_PARM_2
	.globl _process_action_PARM_2
	.globl _action_exec_PARM_1
	.globl _tp_buttons
	.globl _action_exec
	.globl _ak820_action_exec
	.globl _process_record
	.globl _process_record_handler
	.globl _process_action
	.globl _register_code
	.globl _unregister_code
	.globl _tap_code_delay
	.globl _tap_code
	.globl _register_mods
	.globl _unregister_mods
	.globl _register_weak_mods
	.globl _unregister_weak_mods
	.globl _clear_keyboard
	.globl _clear_keyboard_but_mods
	.globl _clear_keyboard_but_mods_and_keys
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_process_record_sloc0_1_0:
	.ds 1
_process_action_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_process_action_sloc1_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_tp_buttons::
	.ds 2
_action_exec_PARM_1:
	.ds 6
_action_exec_record_10001_630:
	.ds 9
_ak820_action_exec_event_10000_634:
	.ds 2
_ak820_action_exec_snapshot_10000_635:
	.ds 6
_process_record_record_10000_638:
	.ds 3
_process_record_handler_record_argument_10000_647:
	.ds 3
_process_record_handler_action_10000_648:
	.ds 2
_process_action_PARM_2:
	.ds 2
_process_action_record_argument_10000_659:
	.ds 3
_process_action_on_40000_682:
	.ds 1
_register_code_code_10000_716:
	.ds 1
_unregister_code_code_10000_730:
	.ds 1
_tap_code_delay_PARM_2:
	.ds 2
_tap_code_delay_code_10000_743:
	.ds 1
_tap_code_code_10000_750:
	.ds 1
_register_mods_mods_10000_752:
	.ds 1
_unregister_mods_mods_10000_756:
	.ds 1
_register_weak_mods_mods_10000_760:
	.ds 1
_unregister_weak_mods_mods_10000_764:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_disable_action_cache::
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function action_exec
;	-----------------------------------------
_action_exec:
;	quantum/action.c:92: ak820_dynamic_macro_task(event.time);
	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_ak820_dynamic_macro_task
;	quantum/action.c:95: ak820_combo_tick(event.time);
	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_ak820_combo_tick
;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
	mov	dptr,#_action_exec_PARM_1
	lcall	_ak820_tapping_before
	mov	a, dpl
	jnz	00102$
	ret
00102$:
;	quantum/action.c:116: if (event.pressed) {
	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
	movx	a,@dptr
	jz	00104$
;	quantum/action.c:118: clear_weak_mods();
	lcall	_clear_weak_mods
00104$:
;	quantum/action.c:130: record.event = event;
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_action_exec_PARM_1
	movx	@dptr,a
	mov	a,#(_action_exec_PARM_1 >> 8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x06
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_action_exec_record_10001_630
	mov	b,a
	lcall	___memcpy
;	quantum/action.c:132: record.tap.count = 0;
	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
	movx	a,@dptr
	anl	a,#0x0f
	movx	@dptr,a
;	quantum/action.c:137: record.keycode = 0;
	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
	movx	a,@dptr
	jz	00107$
	mov	dptr,#_action_exec_record_10001_630
	mov	b, #0x00
	lcall	_pre_process_record_quantum
	mov	a, dpl
	jz	00110$
00107$:
;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
	mov	dptr,#_action_exec_record_10001_630
	lcall	_ak820_tapping_process
	mov	a, dpl
	jnz	00106$
	ret
00106$:
;	quantum/action.c:175: process_record(&record);
	mov	dptr,#_action_exec_record_10001_630
	mov	b, #0x00
;	quantum/action.c:190: }
	ljmp	_process_record
00110$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_action_exec'
;------------------------------------------------------------
;event         Allocated with name '_ak820_action_exec_event_10000_634'
;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
;------------------------------------------------------------
;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
;	-----------------------------------------
;	 function ak820_action_exec
;	-----------------------------------------
_ak820_action_exec:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_action_exec_event_10000_634
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:196: keyevent_t snapshot = *event;
	mov	dptr,#_ak820_action_exec_event_10000_634
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x06
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_action_exec_snapshot_10000_635
	mov	b,a
	lcall	___memcpy
;	quantum/action.c:197: action_exec(snapshot);
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_ak820_action_exec_snapshot_10000_635
	movx	@dptr,a
	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x06
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_action_exec_PARM_1
	mov	b,a
	lcall	___memcpy
;	quantum/action.c:198: }
	ljmp	_action_exec
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_nocache'
;------------------------------------------------------------
;record        Allocated with name '_process_record_nocache_record_10000_636'
;------------------------------------------------------------
;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
;	-----------------------------------------
;	 function process_record
;	-----------------------------------------
_process_record:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_process_record_record_10000_638
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x04
	add	a, r5
	mov	r2,a
	clr	a
	addc	a, r6
	mov	r3,a
	mov	ar4,r7
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	jnz	00102$
;	quantum/action.c:338: return;
	ret
00102$:
;	quantum/action.c:342: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
	mov	a,#0x01
	add	a, r5
	mov	r2,a
	clr	a
	addc	a, r6
	mov	r3,a
	mov	ar4,r7
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	cjne	r2,#0x10,00192$
00192$:
	jnc	00104$
	mov	ar2,r5
	mov	ar3,r6
	mov	ar4,r7
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	cjne	r2,#0x08,00194$
00194$:
	jnc	00104$
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jnz	00104$
;	quantum/action.c:343: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
	mov	dptr,#_get_record_keycode_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	lcall	_get_record_keycode
	mov	r6, dpl
	mov	r7, dph
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,#0x05
	add	a, r3
	mov	r3,a
	clr	a
	addc	a, r4
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_ak820_dynamic_macro_process
	mov	a, dpl
	jnz	00104$
	ret
00104$:
;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar2,r5
	mov	ar3,r6
	mov	ar4,r7
	mov	dptr,#___memcpy_PARM_2
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_tapping_source_PARM_1
	mov	b,a
	push	ar7
	push	ar6
	push	ar5
	lcall	___memcpy
	lcall	_ak820_tapping_source
	mov	r4, dpl
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
	mov	a,#0x05
	add	a, r5
	mov	r1,a
	clr	a
	addc	a, r6
	mov	r2,a
	mov	ar3,r7
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r3,a
;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
	mov	a,#0x07
	add	a, r5
	mov	r0,a
	clr	a
	addc	a, r6
	mov	r1,a
	mov	ar2,r7
	mov	dptr,#_get_record_keycode_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_get_record_keycode
	mov	r6, dpl
	mov	r7, dph
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	mov	a,r6
	lcall	__gptrput
	inc	dptr
	mov	a,r7
	lcall	__gptrput
;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	add	a, r5
	mov	r0,a
	clr	a
	addc	a, r6
	mov	r1,a
	mov	ar2,r7
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	lcall	__gptrget
	mov	r0,a
	inc	dptr
	lcall	__gptrget
	mov	r1,a
	mov	dptr,#_ak820_oneshot_process_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	dptr,#_ak820_oneshot_process_PARM_3
	mov	a,r3
	movx	@dptr,a
	mov	dpl, r0
	mov	dph, r1
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_ak820_oneshot_process
	mov	a, dpl
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00109$
	ret
00109$:
;	quantum/action.c:351: if (!process_record_quantum(record)) {
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	push	ar4
	push	ar3
	lcall	_process_record_quantum
	mov	a, dpl
	pop	ar3
	pop	ar4
	jnz	00111$
;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
	mov	dptr,#_ak820_oneshot_post_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	dpl, r4
;	quantum/action.c:360: return;
	ljmp	_ak820_oneshot_post
00111$:
;	quantum/action.c:364: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x01
	add	a, r5
	mov	r0,a
	clr	a
	addc	a, r6
	mov	r1,a
	mov	ar2,r7
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	lcall	__gptrget
	mov	r0,a
	cjne	r0,#0x10,00200$
00200$:
	jnc	00114$
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
	cjne	r5,#0x08,00202$
00202$:
	jnc	00114$
	push	ar4
	push	ar3
	lcall	_get_repeat_key_count
	mov	a, dpl
	pop	ar3
	pop	ar4
	jnz	00114$
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jz	00115$
00114$:
	mov	_process_record_sloc0_1_0,#0x00
	sjmp	00116$
00115$:
	mov	_process_record_sloc0_1_0,#0x01
00116$:
	mov	dptr,#_ak820_dynamic_macro_source
	mov	a,_process_record_sloc0_1_0
	movx	@dptr,a
;	quantum/action.c:366: process_record_handler(record);
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	push	ar4
	push	ar3
	lcall	_process_record_handler
;	quantum/action.c:368: ak820_dynamic_macro_source = false;
	mov	dptr,#_ak820_dynamic_macro_source
	clr	a
	movx	@dptr,a
;	quantum/action.c:370: post_process_record_quantum(record);
	mov	dptr,#_process_record_record_10000_638
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	lcall	_post_process_record_quantum
	pop	ar3
	pop	ar4
;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
	mov	dptr,#_ak820_oneshot_post_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	dpl, r4
;	quantum/action.c:374: }
	ljmp	_ak820_oneshot_post
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_handler'
;------------------------------------------------------------
;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
;record        Allocated with name '_process_record_handler_record_10000_648'
;action        Allocated with name '_process_record_handler_action_10000_648'
;------------------------------------------------------------
;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
;	-----------------------------------------
;	 function process_record_handler
;	-----------------------------------------
_process_record_handler:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_process_record_handler_record_argument_10000_647
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_process_record_handler_record_argument_10000_647
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/action.c:387: if (record->keycode) {
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	orl	a,r4
	jz	00102$
;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_action_for_keycode
	mov	r4, dpl
	mov	r5, dph
	pop	ar6
	pop	ar7
	mov	dptr,#_process_record_handler_action_10000_648
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	sjmp	00104$
00102$:
;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0x00
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r2,#0x00
	orl	ar5,a
	mov	a,r2
	orl	ar4,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	dptr,#_ak820_resolve_key_PARM_2
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r4
	push	ar7
	push	ar6
	lcall	_ak820_resolve_key
	lcall	_action_for_keycode
	mov	r4, dpl
	mov	r5, dph
	pop	ar6
	pop	ar7
	mov	dptr,#_process_record_handler_action_10000_648
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:400: ac_dprintf("ACTION: ");
00104$:
;	quantum/action.c:411: process_action(record, action);
	mov	r5,#0x00
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_process_record_handler_action_10000_648
	movx	@dptr,a
	mov	a,#(_process_record_handler_action_10000_648 >> 8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_process_action_PARM_2
	mov	b,a
	push	ar7
	push	ar6
	push	ar5
	lcall	___memcpy
	pop	ar5
	pop	ar6
	pop	ar7
	mov	dpl, r6
	mov	dph, r7
	mov	b, r5
;	quantum/action.c:412: }
	ljmp	_process_action
;------------------------------------------------------------
;Allocation info for local variables in function 'register_mouse'
;------------------------------------------------------------
;pressed       Allocated with name '_register_mouse_PARM_2'
;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
;------------------------------------------------------------
;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
;	-----------------------------------------
;	 function process_action
;	-----------------------------------------
_process_action:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_process_action_record_argument_10000_659
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_process_action_record_argument_10000_659
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/action.c:483: pressed = record->event.pressed;
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	_process_action_sloc0_1_0,a
;	quantum/action.c:507: switch (action.kind.id) {
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	swap	a
	anl	a,#0x0f
	mov  r5,a
	add	a,#0xff - 0x0b
	jnc	00434$
	ljmp	00181$
00434$:
;	free result
	mov	a,r5
	add	a,#(00435$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r5
	add	a,#(00436$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00435$:
	.db	00102$
	.db	00102$
	.db	00181$
	.db	00181$
	.db	00123$
	.db	00181$
	.db	00181$
	.db	00181$
	.db	00131$
	.db	00147$
	.db	00152$
	.db	00152$
00436$:
	.db	00102$>>8
	.db	00102$>>8
	.db	00181$>>8
	.db	00181$>>8
	.db	00123$>>8
	.db	00181$>>8
	.db	00181$>>8
	.db	00181$>>8
	.db	00131$>>8
	.db	00147$>>8
	.db	00152$>>8
	.db	00152$>>8
;	quantum/action.c:510: case ACT_RMODS: {
00102$:
;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0xf0
	jnz	00194$
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x0f
	mov	r5,a
	sjmp	00195$
00194$:
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x0f
	swap	a
	anl	a,#0xf0
	mov	r5,a
00195$:
;	quantum/action.c:513: if (pressed) {
	mov	a,_process_action_sloc0_1_0
	jz	00119$
;	quantum/action.c:514: if (mods) {
	mov	a,r5
	jz	00110$
;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xe0,00440$
00440$:
	jc	00108$
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	add	a,#0xff - 0xe7
	jnc	00104$
;	free result
00108$:
	mov	r3,#_process_action_PARM_2
	mov	r4,#(_process_action_PARM_2 >> 8)
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jnz	00105$
00104$:
;	quantum/action.c:519: add_owned_mods(mods);
	mov	dpl, r5
	lcall	_add_owned_mods
	sjmp	00106$
00105$:
;	quantum/action.c:521: add_owned_weak_mods(mods);
	mov	dpl, r5
	lcall	_add_owned_weak_mods
00106$:
;	quantum/action.c:523: send_keyboard_report();
	lcall	_send_keyboard_report
00110$:
;	quantum/action.c:525: register_code(action.key.code);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	lcall	_register_code
	ljmp	00181$
00119$:
;	quantum/action.c:527: unregister_code(action.key.code);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	push	ar5
	lcall	_unregister_code
	pop	ar5
;	quantum/action.c:528: if (mods) {
	mov	a,r5
	jnz	00444$
	ljmp	00181$
00444$:
;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xe0,00445$
00445$:
	jc	00115$
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	add	a,#0xff - 0xe7
	jnc	00111$
;	free result
00115$:
	mov	r3,#_process_action_PARM_2
	mov	r4,#(_process_action_PARM_2 >> 8)
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	jnz	00112$
00111$:
;	quantum/action.c:530: del_owned_mods(mods);
	mov	dpl, r5
	lcall	_del_owned_mods
	sjmp	00113$
00112$:
;	quantum/action.c:532: del_owned_weak_mods(mods);
	mov	dpl, r5
	lcall	_del_owned_weak_mods
00113$:
;	quantum/action.c:534: send_keyboard_report();
	lcall	_send_keyboard_report
;	quantum/action.c:537: } break;
	ljmp	00181$
;	quantum/action.c:614: case ACT_USAGE:
00123$:
;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	clr	c
	mov	a,r4
	subb	a,#0xa5
	mov	a,r5
	subb	a,#0x00
	jc	00125$
	mov	a,#0xc2
	subb	a,r4
	clr	a
	subb	a,r5
	jc	00125$
;	free result
;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
	mov	dptr,#_owned_usage_key_PARM_2
	mov	a,_process_action_sloc0_1_0
	movx	@dptr,a
	mov	dpl, r6
	lcall	_owned_usage_key
;	quantum/action.c:622: break;
	ljmp	00181$
00125$:
;	quantum/action.c:625: switch (action.usage.page) {
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x03
	mov	r7,a
	jz	00127$
	cjne	r7,#0x01,00452$
	sjmp	00128$
00452$:
	ljmp	00181$
;	quantum/action.c:626: case PAGE_SYSTEM:
00127$:
;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
	mov	a,_process_action_sloc0_1_0
	jz	00196$
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	anl	a,#0x03
	mov	r7,a
	sjmp	00197$
00196$:
	mov	r6,#0x00
	mov	r7,#0x00
00197$:
	mov	dpl, r6
	mov	dph, r7
	lcall	_host_system_send
;	quantum/action.c:628: break;
	ljmp	00181$
;	quantum/action.c:629: case PAGE_CONSUMER:
00128$:
;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
	mov	a,_process_action_sloc0_1_0
	jz	00198$
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	anl	a,#0x03
	mov	r7,a
	sjmp	00199$
00198$:
	mov	r6,#0x00
	mov	r7,#0x00
00199$:
	mov	dpl, r6
	mov	dph, r7
	lcall	_host_consumer_send
;	quantum/action.c:633: break;
	ljmp	00181$
;	quantum/action.c:640: case ACT_LAYER: {
00131$:
;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x03
	mov	dptr,#_process_action_on_40000_682
	movx	@dptr,a
;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
	movx	a,@dptr
	mov	r7,a
	jz	00200$
	mov	a,_process_action_sloc0_1_0
	jz	00202$
	mov	ar6,r7
	anl	ar6,#0x01
	sjmp	00201$
00202$:
	mov	a,#0x02
	anl	a,r7
	mov	r6,a
	sjmp	00201$
00200$:
	mov	a,_process_action_sloc0_1_0
	cjne	a,#0x01,00457$
00457$:
	mov  _process_action_sloc1_1_0,c
	clr	a
	rlc	a
	mov	r6,a
00201$:
	mov	a,r6
	jnz	00458$
	ljmp	00181$
00458$:
;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	swap	a
	rr	a
	anl	a,#0x07
	add	a,acc
	add	a,acc
	mov	r7,a
;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	anl	a,#0x0f
	mov	r6,a
	mov	b,r7
	inc	b
	mov	a,r6
	sjmp	00460$
00459$:
	add	a,acc
00460$:
	djnz	b,00459$
	mov	r6,a
;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	jnb	acc.4,00204$
	mov	b,r7
	inc	b
	mov	a,#0x0f
	sjmp	00463$
00462$:
	add	a,acc
00463$:
	djnz	b,00462$
	cpl	a
	mov	r7,a
	sjmp	00205$
00204$:
	mov	r7,#0x00
00205$:
;	quantum/action.c:648: bits |= mask;
	mov	a,r6
	orl	ar7,a
;	quantum/action.c:649: if (!on) {
	mov	dptr,#_process_action_on_40000_682
	movx	a,@dptr
	jnz	00143$
;	quantum/action.c:650: switch (action.layer_bitop.op) {
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x03
	mov	r6,a
	add	a,r6
;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
	mov	dptr,#00465$
	jmp	@a+dptr
00465$:
	sjmp	00132$
	sjmp	00133$
	sjmp	00134$
	sjmp	00135$
00132$:
	mov	dpl, r7
	lcall	_default_layer_and
	ljmp	00181$
;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
00133$:
	mov	dpl, r7
	lcall	_default_layer_or
	ljmp	00181$
;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
00134$:
	mov	dpl, r7
	lcall	_default_layer_xor
	ljmp	00181$
;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
00135$:
	mov	dpl, r7
	lcall	_default_layer_set
;	quantum/action.c:655: }
	ljmp	00181$
00143$:
;	quantum/action.c:657: switch (action.layer_bitop.op) {
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x03
	mov	r6,a
	add	a,r6
;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
	mov	dptr,#00466$
	jmp	@a+dptr
00466$:
	sjmp	00137$
	sjmp	00138$
	sjmp	00139$
	sjmp	00140$
00137$:
	mov	dpl, r7
	lcall	_layer_and
	ljmp	00181$
;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
00138$:
	mov	dpl, r7
	lcall	_layer_or
	ljmp	00181$
;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
00139$:
	mov	dpl, r7
	lcall	_layer_xor
	ljmp	00181$
;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
00140$:
	mov	dpl, r7
	lcall	_layer_state_set
;	quantum/action.c:665: break;
	ljmp	00181$
;	quantum/action.c:667: case ACT_LAYER_MODS:
00147$:
;	quantum/action.c:668: if (pressed) {
	mov	a,_process_action_sloc0_1_0
	jz	00149$
;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x0f
	mov	dpl,a
	lcall	_layer_hold_on
;	quantum/action.c:670: register_mods(action.layer_mods.mods);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	lcall	_register_mods
	ljmp	00181$
00149$:
;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	lcall	_unregister_mods
;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x0f
	mov	dpl,a
	lcall	_layer_hold_off
;	quantum/action.c:675: break;
	ljmp	00181$
;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
00152$:
;	quantum/action.c:678: switch (action.layer_tap.code) {
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xf1,00468$
	sjmp	00154$
00468$:
	cjne	r7,#0xf2,00469$
	sjmp	00155$
00469$:
;	quantum/action.c:694: momentary_layer_action:
	cjne	r7,#0xf3,00160$
	sjmp	00156$
00154$:
;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
	mov	a,_process_action_sloc0_1_0
	jz	00206$
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x1f
	mov	dpl,a
	lcall	_layer_hold_on
	sjmp	00181$
00206$:
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x1f
	mov	dpl,a
	lcall	_layer_hold_off
;	quantum/action.c:696: break;
;	quantum/action.c:697: case OP_OFF_ON:
	sjmp	00181$
00155$:
;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
	mov	a,_process_action_sloc0_1_0
	jz	00208$
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x1f
	mov	dpl,a
	lcall	_layer_off
	sjmp	00181$
00208$:
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x1f
	mov	dpl,a
	lcall	_layer_on
;	quantum/action.c:699: break;
;	quantum/action.c:700: case OP_SET_CLEAR:
	sjmp	00181$
00156$:
;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
	mov	a,_process_action_sloc0_1_0
	jz	00210$
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	anl	a,#0x1f
	mov	dpl,a
	lcall	_layer_move
	sjmp	00181$
00210$:
	lcall	_layer_clear
;	quantum/action.c:702: break;
;	quantum/action.c:748: default:
	sjmp	00181$
00160$:
;	quantum/action.c:755: if (pressed) {
	mov	a,_process_action_sloc0_1_0
	jz	00163$
;	quantum/action.c:757: register_code(action.layer_tap.code);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	lcall	_register_code
;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
	sjmp	00181$
00163$:
;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x39,00175$
;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
	mov	r7,#0x50
00187$:
	mov	a,r7
	jz	00175$
	mov	dptr,#0x0001
	lcall	_mDelaymS
	dec	r7
;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
	sjmp	00187$
00175$:
;	quantum/action.c:765: unregister_code(action.layer_tap.code);
	mov	dptr,#_process_action_PARM_2
	movx	a,@dptr
	mov	dpl,a
	lcall	_unregister_code
;	quantum/action.c:848: }
00181$:
;	quantum/action.c:869: switch (action.kind.id) {
	mov	dptr,#(_process_action_PARM_2 + 0x0001)
	movx	a,@dptr
	swap	a
	anl	a,#0x0f
	mov	r7,a
	cjne	r7,#0x08,00478$
	sjmp	00183$
00478$:
	cjne	r7,#0x09,00192$
;	quantum/action.c:871: case ACT_LAYER_MODS:
00183$:
;	quantum/action.c:876: led_set(host_keyboard_leds());
	lcall	_host_keyboard_leds
;	quantum/action.c:880: }
;	quantum/action.c:933: }
	ljmp	_led_set
00192$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'register_code'
;------------------------------------------------------------
;code          Allocated with name '_register_code_code_10000_716'
;------------------------------------------------------------
;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
;	-----------------------------------------
;	 function register_code
;	-----------------------------------------
_register_code:
	mov	a,dpl
	mov	dptr,#_register_code_code_10000_716
	movx	@dptr,a
;	quantum/action.c:940: if (code == KC_NO) {
	movx	a,@dptr
	mov	r7,a
	jnz	00123$
;	quantum/action.c:941: return;
	ret
00123$:
;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
	cjne	r7,#0x04,00186$
00186$:
	jc	00119$
	mov	a,r7
	add	a,#0xff - 0xa4
	jc	00119$
;	free result
;	quantum/action.c:981: if (!add_owned_key(code)) return;
	mov	dpl, r7
	push	ar7
	lcall	_add_owned_key
	mov	a, dpl
	pop	ar7
	jnz	00104$
	ret
00104$:
;	quantum/action.c:983: ak820_dynamic_macro_observe(code, true);
	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r7
	lcall	_ak820_dynamic_macro_observe
;	quantum/action.c:995: send_keyboard_report();
	ljmp	_send_keyboard_report
00119$:
;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
	mov	dptr,#_register_code_code_10000_716
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xe0,00190$
00190$:
	jc	00115$
	mov	a,r7
	add	a,#0xff - 0xe7
	jc	00115$
;	free result
;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
	mov	a,#0x07
	anl	a,r7
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00194$
00193$:
	add	a,acc
00194$:
	djnz	b,00193$
	mov	dpl,a
	lcall	_add_owned_mods
;	quantum/action.c:998: send_keyboard_report();
	ljmp	_send_keyboard_report
00115$:
;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
	mov	dptr,#_register_code_code_10000_716
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa5,00195$
00195$:
	jc	00113$
	mov	a,r7
	add	a,#0xff - 0xa7
	jnc	00108$
;	free result
00113$:
	mov	dptr,#_register_code_code_10000_716
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa8,00198$
00198$:
	jc	00125$
	mov	a,r7
	add	a,#0xff - 0xc2
	jc	00125$
;	free result
00108$:
;	quantum/action.c:1003: owned_usage_key(code, true);
	mov	dptr,#_register_code_code_10000_716
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_owned_usage_key_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r7
;	quantum/action.c:1011: register_mouse(code, true);
;	quantum/action.c:1013: }
	ljmp	_owned_usage_key
00125$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'unregister_code'
;------------------------------------------------------------
;code          Allocated with name '_unregister_code_code_10000_730'
;------------------------------------------------------------
;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
;	-----------------------------------------
;	 function unregister_code
;	-----------------------------------------
_unregister_code:
	mov	a,dpl
	mov	dptr,#_unregister_code_code_10000_730
	movx	@dptr,a
;	quantum/action.c:1020: if (code == KC_NO) {
	movx	a,@dptr
	mov	r7,a
	jnz	00121$
;	quantum/action.c:1021: return;
	ret
00121$:
;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
	cjne	r7,#0x04,00184$
00184$:
	jc	00117$
	mov	a,r7
	add	a,#0xff - 0xa4
	jc	00117$
;	free result
;	quantum/action.c:1055: if (!del_owned_key(code)) return;
	mov	dpl, r7
	push	ar7
	lcall	_del_owned_key
	mov	a, dpl
	pop	ar7
	jnz	00102$
	ret
00102$:
;	quantum/action.c:1057: ak820_dynamic_macro_observe(code, false);
	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r7
	lcall	_ak820_dynamic_macro_observe
;	quantum/action.c:1062: send_keyboard_report();
	ljmp	_send_keyboard_report
00117$:
;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
	mov	dptr,#_unregister_code_code_10000_730
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xe0,00188$
00188$:
	jc	00113$
	mov	a,r7
	add	a,#0xff - 0xe7
	jc	00113$
;	free result
;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
	mov	a,#0x07
	anl	a,r7
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00192$
00191$:
	add	a,acc
00192$:
	djnz	b,00191$
	mov	dpl,a
	lcall	_del_owned_mods
;	quantum/action.c:1065: send_keyboard_report();
	ljmp	_send_keyboard_report
00113$:
;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
	mov	dptr,#_unregister_code_code_10000_730
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa5,00193$
00193$:
	jc	00111$
	mov	a,r7
	add	a,#0xff - 0xa7
	jnc	00106$
;	free result
00111$:
	mov	dptr,#_unregister_code_code_10000_730
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa8,00196$
00196$:
	jc	00123$
	mov	a,r7
	add	a,#0xff - 0xc2
	jc	00123$
;	free result
00106$:
;	quantum/action.c:1070: owned_usage_key(code, false);
	mov	dptr,#_unregister_code_code_10000_730
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_owned_usage_key_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r7
;	quantum/action.c:1078: register_mouse(code, false);
;	quantum/action.c:1080: }
	ljmp	_owned_usage_key
00123$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'tap_code_delay'
;------------------------------------------------------------
;delay         Allocated with name '_tap_code_delay_PARM_2'
;code          Allocated with name '_tap_code_delay_code_10000_743'
;i             Allocated with name '_tap_code_delay_i_20000_745'
;i             Allocated with name '_tap_code_delay_i_50000_748'
;------------------------------------------------------------
;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
;	-----------------------------------------
;	 function tap_code_delay
;	-----------------------------------------
_tap_code_delay:
	mov	a,dpl
	mov	dptr,#_tap_code_delay_code_10000_743
	movx	@dptr,a
;	quantum/action.c:1088: register_code(code);
	movx	a,@dptr
	mov	r7,a
	mov	dpl,a
	push	ar7
	lcall	_register_code
	pop	ar7
;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
	mov	dptr,#_tap_code_delay_PARM_2
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
00110$:
	mov	a,r5
	orl	a,r6
	jz	00105$
;	quantum/action.c:1090: wait_ms(1);
	mov	dptr,#0x0001
	lcall	_mDelaymS
;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
	dec	r5
	cjne	r5,#0xff,00141$
	dec	r6
00141$:
	sjmp	00110$
00105$:
;	quantum/action.c:1092: unregister_code(code);
	mov	dpl, r7
;	quantum/action.c:1093: }
	ljmp	_unregister_code
;------------------------------------------------------------
;Allocation info for local variables in function 'tap_code'
;------------------------------------------------------------
;code          Allocated with name '_tap_code_code_10000_750'
;------------------------------------------------------------
;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
;	-----------------------------------------
;	 function tap_code
;	-----------------------------------------
_tap_code:
	mov	a,dpl
	mov	dptr,#_tap_code_code_10000_750
	movx	@dptr,a
;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x39,00103$
	mov	r6,#0x50
	sjmp	00104$
00103$:
	mov	r6,#0x00
00104$:
	mov	dptr,#_tap_code_delay_PARM_2
	mov	a,r6
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r7
;	quantum/action.c:1101: }
	ljmp	_tap_code_delay
;------------------------------------------------------------
;Allocation info for local variables in function 'register_mods'
;------------------------------------------------------------
;mods          Allocated with name '_register_mods_mods_10000_752'
;------------------------------------------------------------
;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
;	-----------------------------------------
;	 function register_mods
;	-----------------------------------------
_register_mods:
	mov	a,dpl
	mov	dptr,#_register_mods_mods_10000_752
	movx	@dptr,a
;	quantum/action.c:1108: if (mods) {
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00103$
;	quantum/action.c:1109: add_owned_mods(mods);
	mov	dpl, r7
	lcall	_add_owned_mods
;	quantum/action.c:1110: send_keyboard_report();
;	quantum/action.c:1112: }
	ljmp	_send_keyboard_report
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'unregister_mods'
;------------------------------------------------------------
;mods          Allocated with name '_unregister_mods_mods_10000_756'
;------------------------------------------------------------
;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
;	-----------------------------------------
;	 function unregister_mods
;	-----------------------------------------
_unregister_mods:
	mov	a,dpl
	mov	dptr,#_unregister_mods_mods_10000_756
	movx	@dptr,a
;	quantum/action.c:1119: if (mods) {
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00103$
;	quantum/action.c:1120: del_owned_mods(mods);
	mov	dpl, r7
	lcall	_del_owned_mods
;	quantum/action.c:1121: send_keyboard_report();
;	quantum/action.c:1123: }
	ljmp	_send_keyboard_report
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'register_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_register_weak_mods_mods_10000_760'
;------------------------------------------------------------
;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
;	-----------------------------------------
;	 function register_weak_mods
;	-----------------------------------------
_register_weak_mods:
	mov	a,dpl
	mov	dptr,#_register_weak_mods_mods_10000_760
	movx	@dptr,a
;	quantum/action.c:1130: if (mods) {
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00103$
;	quantum/action.c:1131: add_owned_weak_mods(mods);
	mov	dpl, r7
	lcall	_add_owned_weak_mods
;	quantum/action.c:1132: send_keyboard_report();
;	quantum/action.c:1134: }
	ljmp	_send_keyboard_report
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'unregister_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_unregister_weak_mods_mods_10000_764'
;------------------------------------------------------------
;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
;	-----------------------------------------
;	 function unregister_weak_mods
;	-----------------------------------------
_unregister_weak_mods:
	mov	a,dpl
	mov	dptr,#_unregister_weak_mods_mods_10000_764
	movx	@dptr,a
;	quantum/action.c:1141: if (mods) {
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00103$
;	quantum/action.c:1142: del_owned_weak_mods(mods);
	mov	dpl, r7
	lcall	_del_owned_weak_mods
;	quantum/action.c:1143: send_keyboard_report();
;	quantum/action.c:1145: }
	ljmp	_send_keyboard_report
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_keyboard'
;------------------------------------------------------------
;	quantum/action.c:1151: void clear_keyboard(void) {
;	-----------------------------------------
;	 function clear_keyboard
;	-----------------------------------------
_clear_keyboard:
;	quantum/action.c:1152: clear_mods();
	lcall	_clear_mods
;	quantum/action.c:1153: clear_keyboard_but_mods();
;	quantum/action.c:1154: }
	ljmp	_clear_keyboard_but_mods
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_keyboard_but_mods'
;------------------------------------------------------------
;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
;	-----------------------------------------
;	 function clear_keyboard_but_mods
;	-----------------------------------------
_clear_keyboard_but_mods:
;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
	mov	dptr,#_actual_keyboard_report
	lcall	_clear_keys_from_report
;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
;	quantum/action.c:1163: }
	ljmp	_clear_keyboard_but_mods_and_keys
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
;------------------------------------------------------------
;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
;	-----------------------------------------
;	 function clear_keyboard_but_mods_and_keys
;	-----------------------------------------
_clear_keyboard_but_mods_and_keys:
;	quantum/action.c:1171: ak820_tapping_cancel();
	lcall	_ak820_tapping_cancel
;	quantum/action.c:1176: ak820_dynamic_macro_cancel();
	lcall	_ak820_dynamic_macro_cancel
;	quantum/action.c:1182: ak820_oneshot_cancel();
	lcall	_ak820_oneshot_cancel
;	quantum/action.c:1185: ak820_combo_cancel();
	lcall	_ak820_combo_cancel
;	quantum/action.c:1188: repeat_key_cancel();
	lcall	_repeat_key_cancel
;	quantum/action.c:1190: clear_owned_mods();
	lcall	_clear_owned_mods
;	quantum/action.c:1191: clear_owned_keys();
	lcall	_clear_owned_keys
;	quantum/action.c:1192: clear_owned_usages();
	lcall	_clear_owned_usages
;	quantum/action.c:1193: layer_hold_clear();
	lcall	_layer_hold_clear
;	quantum/action.c:1195: clear_macro_tri_layer();
	lcall	_clear_macro_tri_layer
;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
	mov	dptr,#_actual_keyboard_report
	lcall	_clear_keys_from_report
;	quantum/action.c:1200: host_system_send(0);
	mov	dptr,#0x0000
	lcall	_host_system_send
;	quantum/action.c:1201: host_consumer_send(0);
	mov	dptr,#0x0000
	lcall	_host_consumer_send
;	quantum/action.c:1203: clear_weak_mods();
	lcall	_clear_weak_mods
;	quantum/action.c:1204: send_keyboard_report();
;	quantum/action.c:1212: }
	ljmp	_send_keyboard_report
;------------------------------------------------------------
;Allocation info for local variables in function 'is_tap_record'
;------------------------------------------------------------
;record        Allocated with name '_is_tap_record_record_10000_780'
;action        Allocated with name '_is_tap_record_action_10001_784'
;------------------------------------------------------------
;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__disable_action_cache:
	.db #0x00	;  0
	.area CABS    (ABS,CODE)
