                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CB7                        569 _g_direct_mode_colors::
      000CB7                        570 	.ds 246
      000DAD                        571 _get_supported_PARM_2:
      000DAD                        572 	.ds 1
      000DAE                        573 _get_supported_args_10000_255:
      000DAE                        574 	.ds 2
      000DB0                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DB0                        576 	.ds 2
      000DB2                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DB2                        578 	.ds 2
      000DB4                        579 _set_mode_mode_10000_275:
      000DB4                        580 	.ds 2
      000DB6                        581 _get_matrix_pos_for_led_PARM_2:
      000DB6                        582 	.ds 2
      000DB8                        583 _get_matrix_pos_for_led_led_10000_280:
      000DB8                        584 	.ds 2
      000DBA                        585 _fast_set_leds_PARM_2:
      000DBA                        586 	.ds 1
      000DBB                        587 _fast_set_leds_args_10000_282:
      000DBB                        588 	.ds 2
      000DBD                        589 _fast_set_leds_first_index_10001_285:
      000DBD                        590 	.ds 2
      000DBF                        591 _fast_set_leds_num_leds_10001_285:
      000DBF                        592 	.ds 1
      000DC0                        593 _vialrgb_get_value_PARM_2:
      000DC0                        594 	.ds 1
      000DC1                        595 _vialrgb_get_value_data_10000_291:
      000DC1                        596 	.ds 3
      000DC4                        597 _vialrgb_set_value_PARM_2:
      000DC4                        598 	.ds 1
      000DC5                        599 _vialrgb_set_value_data_10000_302:
      000DC5                        600 	.ds 3
      000DC8                        601 _vialrgb_save_PARM_2:
      000DC8                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B747                        654 _get_supported:
      00B747 12 3A CD         [24]  655 	lcall	_ak820_outline_0107
      00B74A 90 0D AE         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B74D 12 3A D2         [24]  657 	lcall	_ak820_outline_0108
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B750 90 0D AE         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B753 12 3A 3F         [24]  660 	lcall	_ak820_outline_0005
      00B756 E0               [24]  661 	movx	a,@dptr
      00B757 FD               [12]  662 	mov	r5,a
      00B758 7C 00            [12]  663 	mov	r4,#0x00
      00B75A 12 3A D7         [24]  664 	lcall	_ak820_outline_0118
      00B75D A3               [24]  665 	inc	dptr
      00B75E E0               [24]  666 	movx	a,@dptr
      00B75F FA               [12]  667 	mov	r2,a
      00B760 E4               [12]  668 	clr	a
      00B761 12 45 B2         [24]  669 	lcall	_ak820_outline_0144
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B764 90 0D AD         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B767 E0               [24]  672 	movx	a,@dptr
      00B768 FB               [12]  673 	mov	r3,a
      00B769 7A 00            [12]  674 	mov	r2,#0x00
      00B76B                        675 00107$:
      00B76B C3               [12]  676 	clr	c
      00B76C EA               [12]  677 	mov	a,r2
      00B76D 9B               [12]  678 	subb	a,r3
      00B76E 50 0A            [24]  679 	jnc	00101$
      00B770 EA               [12]  680 	mov	a,r2
      00B771 12 3A 7C         [24]  681 	lcall	_ak820_outline_0022
      00B774 74 FF            [12]  682 	mov	a,#0xff
      00B776 F0               [24]  683 	movx	@dptr,a
      00B777 0A               [12]  684 	inc	r2
      00B778 80 F1            [24]  685 	sjmp	00107$
      00B77A                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B77A 8D 06            [24]  688 	mov	ar6,r5
      00B77C 8C 07            [24]  689 	mov	ar7,r4
      00B77E 8B 05            [24]  690 	mov	ar5,r3
      00B780 90 0D AE         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B783 12 3A DC         [24]  692 	lcall	_ak820_outline_0122
      00B786 7A 00            [12]  693 	mov	r2,#0x00
      00B788                        694 00110$:
      00B788 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B78B                        696 00159$:
      00B78B 50 46            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B78D EA               [12]  699 	mov	a,r2
      00B78E 75 F0 02         [24]  700 	mov	b,#0x02
      00B791 A4               [48]  701 	mul	ab
      00B792 24 FA            [12]  702 	add	a, #_supported_modes
      00B794 F5 82            [12]  703 	mov	dpl,a
      00B796 74 C3            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B798 12 5B DA         [24]  705 	lcall	_ak820_outline_0109
      00B79B F8               [12]  706 	mov	r0,a
      00B79C 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B79E C3               [12]  709 	clr	c
      00B79F EE               [12]  710 	mov	a,r6
      00B7A0 98               [12]  711 	subb	a,r0
      00B7A1 EF               [12]  712 	mov	a,r7
      00B7A2 99               [12]  713 	subb	a,r1
      00B7A3 50 2B            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B7A5 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B7A8                        717 00162$:
      00B7A8 40 26            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B7AA C0 06            [24]  720 	push	ar6
      00B7AC C0 07            [24]  721 	push	ar7
      00B7AE 88 07            [24]  722 	mov	ar7,r0
      00B7B0 12 36 47         [24]  723 	lcall	_ak820_outline_0123
      00B7B3 EF               [12]  724 	mov	a,r7
      00B7B4 F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B7B5 12 36 47         [24]  727 	lcall	_ak820_outline_0123
      00B7B8 A3               [24]  728 	inc	dptr
      00B7B9 89 00            [24]  729 	mov	ar0,r1
      00B7BB E8               [12]  730 	mov	a,r0
      00B7BC F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B7BD 1D               [12]  733 	dec	r5
      00B7BE 1D               [12]  734 	dec	r5
                                    735 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7BF 74 02            [12]  736 	mov	a,#0x02
      00B7C1 2B               [12]  737 	add	a, r3
      00B7C2 FB               [12]  738 	mov	r3,a
      00B7C3 E4               [12]  739 	clr	a
      00B7C4 3C               [12]  740 	addc	a, r4
      00B7C5 FC               [12]  741 	mov	r4,a
      00B7C6 90 0D AE         [24]  742 	mov	dptr,#_get_supported_args_10000_255
      00B7C9 12 3A B5         [24]  743 	lcall	_ak820_outline_0085
                                    744 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7CC D0 07            [24]  745 	pop	ar7
      00B7CE D0 06            [24]  746 	pop	ar6
                                    747 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7D0                        748 00111$:
                                    749 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7D0 0A               [12]  750 	inc	r2
      00B7D1 80 B5            [24]  751 	sjmp	00110$
      00B7D3                        752 00127$:
      00B7D3 90 0D AE         [24]  753 	mov	dptr,#_get_supported_args_10000_255
      00B7D6 12 3A B5         [24]  754 	lcall	_ak820_outline_0085
                                    755 ;	quantum/vialrgb.c:55: }
      00B7D9 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    759 ;------------------------------------------------------------
                                    760 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    761 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    762 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function qmk_id_to_vialrgb_id
                                    767 ;	-----------------------------------------
      00B7DA                        768 _qmk_id_to_vialrgb_id:
      00B7DA 12 3A CD         [24]  769 	lcall	_ak820_outline_0107
      00B7DD 90 0D B0         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7E0 12 3A D2         [24]  771 	lcall	_ak820_outline_0108
                                    772 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7E3 90 0D B0         [24]  773 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7E6 12 3A 8C         [24]  774 	lcall	_ak820_outline_0051
      00B7E9 7D 00            [12]  775 	mov	r5,#0x00
      00B7EB                        776 00105$:
      00B7EB BD 07 00         [24]  777 	cjne	r5,#0x07,00130$
      00B7EE                        778 00130$:
      00B7EE 50 19            [24]  779 	jnc	00103$
                                    780 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B7F0 12 BC 11         [24]  781 	lcall	_ak820_outline_0047
      00B7F3 A3               [24]  782 	inc	dptr
      00B7F4 E4               [12]  783 	clr	a
      00B7F5 93               [24]  784 	movc	a,@a+dptr
                                    785 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B7F6 7A 00            [12]  786 	mov	r2,#0x00
      00B7F8 B5 06 0B         [24]  787 	cjne	a,ar6,00106$
      00B7FB EA               [12]  788 	mov	a,r2
      00B7FC B5 07 07         [24]  789 	cjne	a,ar7,00106$
                                    790 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7FF 12 36 47         [24]  791 	lcall	_ak820_outline_0123
      00B802 12 BC 3D         [24]  792 	lcall	_ak820_outline_0146
      00B805 22               [24]  793 	ret
      00B806                        794 00106$:
                                    795 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B806 0D               [12]  796 	inc	r5
      00B807 80 E2            [24]  797 	sjmp	00105$
      00B809                        798 00103$:
                                    799 ;	quantum/vialrgb.c:63: return 0;
      00B809 90 00 00         [24]  800 	mov	dptr,#0x0000
                                    801 ;	quantum/vialrgb.c:64: }
      00B80C 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    805 ;------------------------------------------------------------
                                    806 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    807 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    808 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function vialrgb_id_to_qmk_id
                                    813 ;	-----------------------------------------
      00B80D                        814 _vialrgb_id_to_qmk_id:
      00B80D 12 3A CD         [24]  815 	lcall	_ak820_outline_0107
      00B810 90 0D B2         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B813 12 3A D2         [24]  817 	lcall	_ak820_outline_0108
                                    818 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B816 90 0D B2         [24]  819 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B819 12 3A 8C         [24]  820 	lcall	_ak820_outline_0051
      00B81C 7D 00            [12]  821 	mov	r5,#0x00
      00B81E                        822 00105$:
      00B81E BD 07 00         [24]  823 	cjne	r5,#0x07,00130$
      00B821                        824 00130$:
      00B821 50 19            [24]  825 	jnc	00103$
                                    826 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B823 12 BC 11         [24]  827 	lcall	_ak820_outline_0047
      00B826 E4               [12]  828 	clr	a
      00B827 93               [24]  829 	movc	a,@a+dptr
                                    830 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B828 7A 00            [12]  831 	mov	r2,#0x00
      00B82A B5 06 0C         [24]  832 	cjne	a,ar6,00106$
      00B82D EA               [12]  833 	mov	a,r2
      00B82E B5 07 08         [24]  834 	cjne	a,ar7,00106$
                                    835 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B831 12 36 47         [24]  836 	lcall	_ak820_outline_0123
      00B834 A3               [24]  837 	inc	dptr
      00B835 12 BC 3D         [24]  838 	lcall	_ak820_outline_0146
      00B838 22               [24]  839 	ret
      00B839                        840 00106$:
                                    841 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B839 0D               [12]  842 	inc	r5
      00B83A 80 E2            [24]  843 	sjmp	00105$
      00B83C                        844 00103$:
                                    845 ;	quantum/vialrgb.c:72: return 0;
      00B83C 90 00 00         [24]  846 	mov	dptr,#0x0000
                                    847 ;	quantum/vialrgb.c:73: }
      00B83F 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'get_mode'
                                    851 ;------------------------------------------------------------
                                    852 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function get_mode
                                    855 ;	-----------------------------------------
      00B840                        856 _get_mode:
                                    857 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B840 12 59 C0         [24]  858 	lcall	_rgb_matrix_is_enabled
      00B843 E5 82            [12]  859 	mov	a, dpl
      00B845 70 04            [24]  860 	jnz	00102$
                                    861 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B847 90 00 00         [24]  862 	mov	dptr,#0x0000
      00B84A 22               [24]  863 	ret
      00B84B                        864 00102$:
                                    865 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B84B 12 59 C6         [24]  866 	lcall	_rgb_matrix_get_mode
      00B84E 7E 00            [12]  867 	mov	r6,#0x00
      00B850 8E 83            [24]  868 	mov	dph, r6
                                    869 ;	quantum/vialrgb.c:80: }
      00B852 02 B7 DA         [24]  870 	ljmp	_qmk_id_to_vialrgb_id
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'set_mode'
                                    873 ;------------------------------------------------------------
                                    874 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function set_mode
                                    879 ;	-----------------------------------------
      00B855                        880 _set_mode:
      00B855 12 3A CD         [24]  881 	lcall	_ak820_outline_0107
      00B858 90 0D B4         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B85B 12 3A D2         [24]  883 	lcall	_ak820_outline_0108
                                    884 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B85E 90 0D B4         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B861 12 3A 8C         [24]  886 	lcall	_ak820_outline_0051
      00B864 90 0D B4         [24]  887 	mov	dptr,#_set_mode_mode_10000_275
      00B867 12 72 31         [24]  888 	lcall	_ak820_outline_0040
      00B86A 70 03            [24]  889 	jnz	00102$
                                    890 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B86C 02 5A 13         [24]  891 	ljmp	_rgb_matrix_disable_noeeprom
      00B86F                        892 00102$:
                                    893 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B86F C0 07            [24]  894 	push	ar7
      00B871 C0 06            [24]  895 	push	ar6
      00B873 12 5A 02         [24]  896 	lcall	_rgb_matrix_enable_noeeprom
      00B876 D0 06            [24]  897 	pop	ar6
      00B878 D0 07            [24]  898 	pop	ar7
                                    899 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B87A 12 3A D7         [24]  900 	lcall	_ak820_outline_0118
      00B87D 12 B8 0D         [24]  901 	lcall	_vialrgb_id_to_qmk_id
                                    902 ;	quantum/vialrgb.c:90: }
      00B880 02 5A 1C         [24]  903 	ljmp	_rgb_matrix_mode_noeeprom
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    906 ;------------------------------------------------------------
                                    907 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    908 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    909 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function get_matrix_pos_for_led
                                    914 ;	-----------------------------------------
      00B883                        915 _get_matrix_pos_for_led:
      00B883 12 3A CD         [24]  916 	lcall	_ak820_outline_0107
      00B886 90 0D B8         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B889 12 3A D2         [24]  918 	lcall	_ak820_outline_0108
                                    919 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B88C 90 0D B8         [24]  920 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B88F 12 3A 8C         [24]  921 	lcall	_ak820_outline_0051
      00B892 EE               [12]  922 	mov	a,r6
      00B893 24 F9            [12]  923 	add	a, #_ak820_rgb_slots
      00B895 F5 82            [12]  924 	mov	dpl,a
      00B897 EF               [12]  925 	mov	a,r7
      00B898 34 BD            [12]  926 	addc	a, #(_ak820_rgb_slots >> 8)
      00B89A F5 83            [12]  927 	mov	dph,a
      00B89C E4               [12]  928 	clr	a
      00B89D 93               [24]  929 	movc	a,@a+dptr
      00B89E FF               [12]  930 	mov	r7,a
                                    931 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B89F 90 0D B6         [24]  932 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8A2 12 3A AF         [24]  933 	lcall	_ak820_outline_0079
      00B8A5 EF               [12]  934 	mov	a,r7
      00B8A6 12 5C 10         [24]  935 	lcall	_ak820_outline_0188
      00B8A9 12 85 F2         [24]  936 	lcall	_ak820_outline_0121
                                    937 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B8AC 12 3A EC         [24]  938 	lcall	_ak820_outline_0135
      00B8AF A3               [24]  939 	inc	dptr
      00B8B0 53 07 07         [24]  940 	anl	ar7,#0x07
      00B8B3 EF               [12]  941 	mov	a,r7
      00B8B4 F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/vialrgb.c:110: }
      00B8B5 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'fast_set_leds'
                                    947 ;------------------------------------------------------------
                                    948 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    949 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    950 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    951 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    952 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    953 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    954 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    955 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    956 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function fast_set_leds
                                    961 ;	-----------------------------------------
      00B8B6                        962 _fast_set_leds:
      00B8B6 12 3A CD         [24]  963 	lcall	_ak820_outline_0107
      00B8B9 90 0D BB         [24]  964 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8BC 12 3A D2         [24]  965 	lcall	_ak820_outline_0108
                                    966 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B8BF 90 0D BA         [24]  967 	mov	dptr,#_fast_set_leds_PARM_2
      00B8C2 E0               [24]  968 	movx	a,@dptr
      00B8C3 FF               [12]  969 	mov	r7,a
      00B8C4 BF 03 00         [24]  970 	cjne	r7,#0x03,00159$
      00B8C7                        971 00159$:
      00B8C7 50 01            [24]  972 	jnc	00102$
      00B8C9 22               [24]  973 	ret
      00B8CA                        974 00102$:
                                    975 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8CA 90 0D BB         [24]  976 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8CD 12 3A AF         [24]  977 	lcall	_ak820_outline_0079
      00B8D0 12 4A DB         [24]  978 	lcall	_ak820_outline_0077
      00B8D3 7B 00            [12]  979 	mov	r3,#0x00
      00B8D5 12 3A EC         [24]  980 	lcall	_ak820_outline_0135
      00B8D8 A3               [24]  981 	inc	dptr
      00B8D9 E0               [24]  982 	movx	a,@dptr
      00B8DA FA               [12]  983 	mov	r2,a
      00B8DB 79 00            [12]  984 	mov	r1,#0x00
      00B8DD 90 0D BD         [24]  985 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8E0 E9               [12]  986 	mov	a,r1
      00B8E1 4C               [12]  987 	orl	a,r4
      00B8E2 F0               [24]  988 	movx	@dptr,a
      00B8E3 EA               [12]  989 	mov	a,r2
      00B8E4 4B               [12]  990 	orl	a,r3
      00B8E5 A3               [24]  991 	inc	dptr
      00B8E6 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B8E7 12 3A EC         [24]  994 	lcall	_ak820_outline_0135
      00B8EA A3               [24]  995 	inc	dptr
      00B8EB A3               [24]  996 	inc	dptr
      00B8EC E0               [24]  997 	movx	a,@dptr
      00B8ED 90 0D BF         [24]  998 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8F0 F0               [24]  999 	movx	@dptr,a
                                   1000 ;	quantum/vialrgb.c:119: length -= 3;
      00B8F1 EF               [12] 1001 	mov	a,r7
      00B8F2 24 FD            [12] 1002 	add	a,#0xfd
      00B8F4 90 0D BA         [24] 1003 	mov	dptr,#_fast_set_leds_PARM_2
      00B8F7 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/vialrgb.c:120: args += 3;
      00B8F8 90 0D BB         [24] 1006 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8FB 74 03            [12] 1007 	mov	a,#0x03
      00B8FD 2D               [12] 1008 	add	a, r5
      00B8FE F0               [24] 1009 	movx	@dptr,a
      00B8FF E4               [12] 1010 	clr	a
      00B900 3E               [12] 1011 	addc	a, r6
      00B901 A3               [24] 1012 	inc	dptr
      00B902 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B903 90 0D BF         [24] 1015 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B906 E0               [24] 1016 	movx	a,@dptr
      00B907 FF               [12] 1017 	mov	r7,a
      00B908 75 F0 03         [24] 1018 	mov	b,#0x03
      00B90B A4               [48] 1019 	mul	ab
      00B90C FE               [12] 1020 	mov	r6,a
      00B90D AD F0            [24] 1021 	mov	r5,b
      00B90F 90 0D BA         [24] 1022 	mov	dptr,#_fast_set_leds_PARM_2
      00B912 E0               [24] 1023 	movx	a,@dptr
      00B913 FB               [12] 1024 	mov	r3,a
      00B914 7C 00            [12] 1025 	mov	r4,#0x00
      00B916 C3               [12] 1026 	clr	c
      00B917 EB               [12] 1027 	mov	a,r3
      00B918 9E               [12] 1028 	subb	a,r6
      00B919 EC               [12] 1029 	mov	a,r4
      00B91A 9D               [12] 1030 	subb	a,r5
      00B91B 40 13            [24] 1031 	jc	00103$
                                   1032 ;	free result
      00B91D 90 0D BD         [24] 1033 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B920 12 3A AF         [24] 1034 	lcall	_ak820_outline_0079
      00B923 8D 03            [24] 1035 	mov	ar3,r5
      00B925 8E 04            [24] 1036 	mov	ar4,r6
      00B927 C3               [12] 1037 	clr	c
      00B928 EB               [12] 1038 	mov	a,r3
      00B929 94 52            [12] 1039 	subb	a,#0x52
      00B92B EC               [12] 1040 	mov	a,r4
      00B92C 94 00            [12] 1041 	subb	a,#0x00
      00B92E 40 01            [24] 1042 	jc	00104$
      00B930                       1043 00103$:
      00B930 22               [24] 1044 	ret
      00B931                       1045 00104$:
                                   1046 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B931 74 52            [12] 1047 	mov	a,#0x52
      00B933 C3               [12] 1048 	clr	c
      00B934 9D               [12] 1049 	subb	a,r5
      00B935 FB               [12] 1050 	mov	r3,a
      00B936 E4               [12] 1051 	clr	a
      00B937 9E               [12] 1052 	subb	a,r6
      00B938 FC               [12] 1053 	mov	r4,a
      00B939 7A 00            [12] 1054 	mov	r2,#0x00
      00B93B C3               [12] 1055 	clr	c
      00B93C EB               [12] 1056 	mov	a,r3
      00B93D 9F               [12] 1057 	subb	a,r7
      00B93E EC               [12] 1058 	mov	a,r4
      00B93F 9A               [12] 1059 	subb	a,r2
      00B940 50 08            [24] 1060 	jnc	00127$
                                   1061 ;	free result
      00B942 90 0D BF         [24] 1062 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B945 74 52            [12] 1063 	mov	a,#0x52
      00B947 C3               [12] 1064 	clr	c
      00B948 9D               [12] 1065 	subb	a,r5
      00B949 F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B94A                       1068 00127$:
      00B94A 90 0D BF         [24] 1069 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B94D E0               [24] 1070 	movx	a,@dptr
      00B94E FF               [12] 1071 	mov	r7,a
      00B94F 90 0D BD         [24] 1072 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B952 12 3A AF         [24] 1073 	lcall	_ak820_outline_0079
      00B955 7C 00            [12] 1074 	mov	r4,#0x00
      00B957                       1075 00110$:
      00B957 C3               [12] 1076 	clr	c
      00B958 EC               [12] 1077 	mov	a,r4
      00B959 9F               [12] 1078 	subb	a,r7
      00B95A 40 01            [24] 1079 	jc	00164$
      00B95C 22               [24] 1080 	ret
      00B95D                       1081 00164$:
                                   1082 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B95D C0 07            [24] 1083 	push	ar7
      00B95F 90 0D D7         [24] 1084 	mov	dptr,#__mulint_PARM_2
      00B962 12 45 C8         [24] 1085 	lcall	_ak820_outline_0164
      00B965 90 00 03         [24] 1086 	mov	dptr,#0x0003
      00B968 C0 07            [24] 1087 	push	ar7
      00B96A C0 06            [24] 1088 	push	ar6
      00B96C C0 05            [24] 1089 	push	ar5
      00B96E C0 04            [24] 1090 	push	ar4
      00B970 12 BD A9         [24] 1091 	lcall	__mulint
      00B973 AA 82            [24] 1092 	mov	r2, dpl
      00B975 AB 83            [24] 1093 	mov	r3, dph
      00B977 D0 04            [24] 1094 	pop	ar4
      00B979 D0 05            [24] 1095 	pop	ar5
      00B97B D0 06            [24] 1096 	pop	ar6
      00B97D D0 07            [24] 1097 	pop	ar7
      00B97F 0D               [12] 1098 	inc	r5
      00B980 BD 00 01         [24] 1099 	cjne	r5,#0x00,00165$
      00B983 0E               [12] 1100 	inc	r6
      00B984                       1101 00165$:
      00B984 EA               [12] 1102 	mov	a,r2
      00B985 24 B7            [12] 1103 	add	a, #_g_direct_mode_colors
      00B987 FA               [12] 1104 	mov	r2,a
      00B988 EB               [12] 1105 	mov	a,r3
      00B989 34 0C            [12] 1106 	addc	a, #(_g_direct_mode_colors >> 8)
      00B98B FB               [12] 1107 	mov	r3,a
                                   1108 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B98C 8A 4A            [24] 1109 	mov	_fast_set_leds_sloc0_1_0,r2
      00B98E 8B 4B            [24] 1110 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B990 12 BC 23         [24] 1111 	lcall	_ak820_outline_0084
      00B993 F8               [12] 1112 	mov	r0,a
      00B994 12 BC 31         [24] 1113 	lcall	_ak820_outline_0106
      00B997 85 4A 82         [24] 1114 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B99A 85 4B 83         [24] 1115 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B99D E8               [12] 1116 	mov	a,r0
      00B99E F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B99F 74 01            [12] 1119 	mov	a,#0x01
      00B9A1 2A               [12] 1120 	add	a, r2
      00B9A2 F5 4A            [12] 1121 	mov	_fast_set_leds_sloc0_1_0,a
      00B9A4 E4               [12] 1122 	clr	a
      00B9A5 3B               [12] 1123 	addc	a, r3
      00B9A6 F5 4B            [12] 1124 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B9A8 90 0D BB         [24] 1125 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9AB E0               [24] 1126 	movx	a,@dptr
      00B9AC F8               [12] 1127 	mov	r0,a
      00B9AD A3               [24] 1128 	inc	dptr
      00B9AE E0               [24] 1129 	movx	a,@dptr
      00B9AF FF               [12] 1130 	mov	r7,a
      00B9B0 88 82            [24] 1131 	mov	dpl,r0
      00B9B2 8F 83            [24] 1132 	mov	dph,r7
      00B9B4 E0               [24] 1133 	movx	a,@dptr
      00B9B5 F9               [12] 1134 	mov	r1,a
      00B9B6 90 0D BB         [24] 1135 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9B9 74 01            [12] 1136 	mov	a,#0x01
      00B9BB 28               [12] 1137 	add	a, r0
      00B9BC F0               [24] 1138 	movx	@dptr,a
      00B9BD E4               [12] 1139 	clr	a
      00B9BE 3F               [12] 1140 	addc	a, r7
      00B9BF A3               [24] 1141 	inc	dptr
      00B9C0 F0               [24] 1142 	movx	@dptr,a
      00B9C1 85 4A 82         [24] 1143 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9C4 85 4B 83         [24] 1144 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9C7 E9               [12] 1145 	mov	a,r1
      00B9C8 F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B9C9 12 BC 23         [24] 1148 	lcall	_ak820_outline_0084
      00B9CC F5 4A            [12] 1149 	mov	_fast_set_leds_sloc0_1_0,a
      00B9CE 12 BC 31         [24] 1150 	lcall	_ak820_outline_0106
                                   1151 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B9D1 74 02            [12] 1152 	mov	a,#0x02
      00B9D3 2A               [12] 1153 	add	a, r2
      00B9D4 F5 4C            [12] 1154 	mov	_fast_set_leds_sloc1_1_0,a
      00B9D6 E4               [12] 1155 	clr	a
      00B9D7 3B               [12] 1156 	addc	a, r3
      00B9D8 F5 4D            [12] 1157 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B9DA C3               [12] 1158 	clr	c
      00B9DB 74 A0            [12] 1159 	mov	a,#0xa0
      00B9DD 95 4A            [12] 1160 	subb	a,_fast_set_leds_sloc0_1_0
      00B9DF D0 07            [24] 1161 	pop	ar7
      00B9E1 50 04            [24] 1162 	jnc	00114$
                                   1163 ;	free result
      00B9E3 7B A0            [12] 1164 	mov	r3,#0xa0
      00B9E5 80 04            [24] 1165 	sjmp	00115$
      00B9E7                       1166 00114$:
      00B9E7 AA 4A            [24] 1167 	mov	r2,_fast_set_leds_sloc0_1_0
      00B9E9 8A 03            [24] 1168 	mov	ar3,r2
      00B9EB                       1169 00115$:
      00B9EB 85 4C 82         [24] 1170 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B9EE 85 4D 83         [24] 1171 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B9F1 EB               [12] 1172 	mov	a,r3
      00B9F2 F0               [24] 1173 	movx	@dptr,a
                                   1174 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B9F3 0C               [12] 1175 	inc	r4
                                   1176 ;	quantum/vialrgb.c:133: }
      00B9F4 02 B9 57         [24] 1177 	ljmp	00110$
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1180 ;------------------------------------------------------------
                                   1181 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1182 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1183 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1184 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1185 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1186 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1187 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1188 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function vialrgb_get_value
                                   1193 ;	-----------------------------------------
      00B9F7                       1194 _vialrgb_get_value:
      00B9F7 12 45 5E         [24] 1195 	lcall	_ak820_outline_0037
      00B9FA 90 0D C1         [24] 1196 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B9FD 12 3A 74         [24] 1197 	lcall	_ak820_outline_0017
                                   1198 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BA00 90 0D C0         [24] 1199 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA03 E0               [24] 1200 	movx	a,@dptr
      00BA04 FF               [12] 1201 	mov	r7,a
      00BA05 BF 20 02         [24] 1202 	cjne	r7,#0x20,00162$
      00BA08 80 01            [24] 1203 	sjmp	00102$
      00BA0A                       1204 00162$:
      00BA0A 22               [24] 1205 	ret
      00BA0B                       1206 00102$:
                                   1207 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA0B 90 0D C1         [24] 1208 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA0E 12 BB FD         [24] 1209 	lcall	_ak820_outline_0046
                                   1210 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1211 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BA11 BA 40 02         [24] 1212 	cjne	r2,#0x40,00163$
      00BA14 80 18            [24] 1213 	sjmp	00103$
      00BA16                       1214 00163$:
      00BA16 BA 41 02         [24] 1215 	cjne	r2,#0x41,00164$
      00BA19 80 26            [24] 1216 	sjmp	00104$
      00BA1B                       1217 00164$:
      00BA1B BA 42 03         [24] 1218 	cjne	r2,#0x42,00165$
      00BA1E 02 BA D3         [24] 1219 	ljmp	00105$
      00BA21                       1220 00165$:
      00BA21 BA 43 03         [24] 1221 	cjne	r2,#0x43,00166$
      00BA24 02 BA E0         [24] 1222 	ljmp	00106$
      00BA27                       1223 00166$:
      00BA27 BA 44 03         [24] 1224 	cjne	r2,#0x44,00167$
      00BA2A 02 BA EC         [24] 1225 	ljmp	00107$
      00BA2D                       1226 00167$:
      00BA2D 22               [24] 1227 	ret
                                   1228 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BA2E                       1229 00103$:
                                   1230 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA2E 12 36 47         [24] 1231 	lcall	_ak820_outline_0123
      00BA31 74 01            [12] 1232 	mov	a,#0x01
      00BA33 F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA34 12 BB F5         [24] 1235 	lcall	_ak820_outline_0039
      00BA37 E4               [12] 1236 	clr	a
      00BA38 F0               [24] 1237 	movx	@dptr,a
                                   1238 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA39 12 BB F5         [24] 1239 	lcall	_ak820_outline_0039
      00BA3C A3               [24] 1240 	inc	dptr
      00BA3D 74 A0            [12] 1241 	mov	a,#0xa0
      00BA3F F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	quantum/vialrgb.c:147: break;
      00BA40 22               [24] 1244 	ret
                                   1245 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BA41                       1246 00104$:
                                   1247 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BA41 C0 06            [24] 1248 	push	ar6
      00BA43 C0 05            [24] 1249 	push	ar5
      00BA45 C0 04            [24] 1250 	push	ar4
      00BA47 C0 03            [24] 1251 	push	ar3
      00BA49 12 B8 40         [24] 1252 	lcall	_get_mode
      00BA4C A9 82            [24] 1253 	mov	r1, dpl
      00BA4E AA 83            [24] 1254 	mov	r2, dph
      00BA50 D0 03            [24] 1255 	pop	ar3
      00BA52 D0 04            [24] 1256 	pop	ar4
      00BA54 D0 05            [24] 1257 	pop	ar5
      00BA56 D0 06            [24] 1258 	pop	ar6
                                   1259 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BA58 89 00            [24] 1260 	mov	ar0,r1
      00BA5A 12 36 47         [24] 1261 	lcall	_ak820_outline_0123
      00BA5D E8               [12] 1262 	mov	a,r0
      00BA5E F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BA5F 12 BB F5         [24] 1265 	lcall	_ak820_outline_0039
      00BA62 8A 01            [24] 1266 	mov	ar1,r2
      00BA64 E9               [12] 1267 	mov	a,r1
      00BA65 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BA66 74 04            [12] 1270 	mov	a,#0x04
      00BA68 12 93 65         [24] 1271 	lcall	_ak820_outline_0136
      00BA6B C0 06            [24] 1272 	push	ar6
      00BA6D C0 05            [24] 1273 	push	ar5
      00BA6F C0 02            [24] 1274 	push	ar2
      00BA71 C0 01            [24] 1275 	push	ar1
      00BA73 12 59 E1         [24] 1276 	lcall	_rgb_matrix_get_speed
      00BA76 A8 82            [24] 1277 	mov	r0, dpl
      00BA78 D0 01            [24] 1278 	pop	ar1
      00BA7A D0 02            [24] 1279 	pop	ar2
      00BA7C D0 05            [24] 1280 	pop	ar5
      00BA7E D0 06            [24] 1281 	pop	ar6
      00BA80 12 85 CB         [24] 1282 	lcall	_ak820_outline_0062
                                   1283 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BA83 74 05            [12] 1284 	mov	a,#0x05
      00BA85 12 93 65         [24] 1285 	lcall	_ak820_outline_0136
      00BA88 C0 06            [24] 1286 	push	ar6
      00BA8A C0 05            [24] 1287 	push	ar5
      00BA8C C0 02            [24] 1288 	push	ar2
      00BA8E C0 01            [24] 1289 	push	ar1
      00BA90 12 59 CC         [24] 1290 	lcall	_rgb_matrix_get_hue
      00BA93 A8 82            [24] 1291 	mov	r0, dpl
      00BA95 D0 01            [24] 1292 	pop	ar1
      00BA97 D0 02            [24] 1293 	pop	ar2
      00BA99 D0 05            [24] 1294 	pop	ar5
      00BA9B D0 06            [24] 1295 	pop	ar6
      00BA9D 12 85 CB         [24] 1296 	lcall	_ak820_outline_0062
                                   1297 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BAA0 74 06            [12] 1298 	mov	a,#0x06
      00BAA2 12 93 65         [24] 1299 	lcall	_ak820_outline_0136
      00BAA5 C0 06            [24] 1300 	push	ar6
      00BAA7 C0 05            [24] 1301 	push	ar5
      00BAA9 C0 02            [24] 1302 	push	ar2
      00BAAB C0 01            [24] 1303 	push	ar1
      00BAAD 12 59 D3         [24] 1304 	lcall	_rgb_matrix_get_sat
      00BAB0 A8 82            [24] 1305 	mov	r0, dpl
      00BAB2 D0 01            [24] 1306 	pop	ar1
      00BAB4 D0 02            [24] 1307 	pop	ar2
      00BAB6 D0 05            [24] 1308 	pop	ar5
      00BAB8 D0 06            [24] 1309 	pop	ar6
      00BABA 12 85 CB         [24] 1310 	lcall	_ak820_outline_0062
                                   1311 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BABD 74 07            [12] 1312 	mov	a,#0x07
      00BABF 12 93 65         [24] 1313 	lcall	_ak820_outline_0136
      00BAC2 C0 02            [24] 1314 	push	ar2
      00BAC4 C0 01            [24] 1315 	push	ar1
      00BAC6 12 59 DA         [24] 1316 	lcall	_rgb_matrix_get_val
      00BAC9 A8 82            [24] 1317 	mov	r0, dpl
      00BACB D0 01            [24] 1318 	pop	ar1
      00BACD D0 02            [24] 1319 	pop	ar2
      00BACF 12 85 CB         [24] 1320 	lcall	_ak820_outline_0062
                                   1321 ;	quantum/vialrgb.c:156: break;
      00BAD2 22               [24] 1322 	ret
                                   1323 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BAD3                       1324 00105$:
                                   1325 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BAD3 EF               [12] 1326 	mov	a,r7
      00BAD4 24 FE            [12] 1327 	add	a,#0xfe
      00BAD6 90 0D AD         [24] 1328 	mov	dptr,#_get_supported_PARM_2
      00BAD9 F0               [24] 1329 	movx	@dptr,a
      00BADA 12 36 47         [24] 1330 	lcall	_ak820_outline_0123
                                   1331 ;	quantum/vialrgb.c:160: break;
      00BADD 02 B7 47         [24] 1332 	ljmp	_get_supported
                                   1333 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BAE0                       1334 00106$:
                                   1335 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BAE0 12 36 47         [24] 1336 	lcall	_ak820_outline_0123
      00BAE3 74 52            [12] 1337 	mov	a,#0x52
      00BAE5 F0               [24] 1338 	movx	@dptr,a
                                   1339 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BAE6 12 BB F5         [24] 1340 	lcall	_ak820_outline_0039
      00BAE9 E4               [12] 1341 	clr	a
      00BAEA F0               [24] 1342 	movx	@dptr,a
                                   1343 ;	quantum/vialrgb.c:166: break;
      00BAEB 22               [24] 1344 	ret
                                   1345 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BAEC                       1346 00107$:
                                   1347 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BAEC 12 36 47         [24] 1348 	lcall	_ak820_outline_0123
      00BAEF E0               [24] 1349 	movx	a,@dptr
      00BAF0 FF               [12] 1350 	mov	r7,a
      00BAF1 7A 00            [12] 1351 	mov	r2,#0x00
      00BAF3 74 03            [12] 1352 	mov	a,#0x03
      00BAF5 2D               [12] 1353 	add	a, r5
      00BAF6 F8               [12] 1354 	mov	r0,a
      00BAF7 E4               [12] 1355 	clr	a
      00BAF8 3E               [12] 1356 	addc	a, r6
      00BAF9 F9               [12] 1357 	mov	r1,a
      00BAFA C0 03            [24] 1358 	push	ar3
      00BAFC C0 04            [24] 1359 	push	ar4
      00BAFE 12 3B 01         [24] 1360 	lcall	_ak820_outline_0160
      00BB01 E0               [24] 1361 	movx	a,@dptr
      00BB02 FB               [12] 1362 	mov	r3,a
      00BB03 E4               [12] 1363 	clr	a
      00BB04 4F               [12] 1364 	orl	a,r7
      00BB05 F5 4E            [12] 1365 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB07 EB               [12] 1366 	mov	a,r3
      00BB08 4A               [12] 1367 	orl	a,r2
      00BB09 F5 4F            [12] 1368 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1369 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB0B AC 4E            [24] 1370 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB0D AF 4F            [24] 1371 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB0F C3               [12] 1372 	clr	c
      00BB10 EC               [12] 1373 	mov	a,r4
      00BB11 94 52            [12] 1374 	subb	a,#0x52
      00BB13 EF               [12] 1375 	mov	a,r7
      00BB14 94 00            [12] 1376 	subb	a,#0x00
      00BB16 D0 04            [24] 1377 	pop	ar4
      00BB18 D0 03            [24] 1378 	pop	ar3
      00BB1A 40 01            [24] 1379 	jc	00109$
      00BB1C 22               [24] 1380 	ret
      00BB1D                       1381 00109$:
                                   1382 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BB1D E5 4E            [12] 1383 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB1F 25 4E            [12] 1384 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB21 FA               [12] 1385 	mov	r2,a
      00BB22 E5 4F            [12] 1386 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB24 33               [12] 1387 	rlc	a
      00BB25 FF               [12] 1388 	mov	r7,a
      00BB26 EA               [12] 1389 	mov	a,r2
      00BB27 24 B3            [12] 1390 	add	a, #_ak820_led_points
      00BB29 F5 50            [12] 1391 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB2B EF               [12] 1392 	mov	a,r7
      00BB2C 34 C0            [12] 1393 	addc	a, #(_ak820_led_points >> 8)
      00BB2E F5 51            [12] 1394 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB30 85 50 82         [24] 1395 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB33 85 51 83         [24] 1396 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB36 E4               [12] 1397 	clr	a
      00BB37 93               [24] 1398 	movc	a,@a+dptr
      00BB38 12 36 47         [24] 1399 	lcall	_ak820_outline_0123
      00BB3B F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BB3C 85 50 82         [24] 1402 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB3F 85 51 83         [24] 1403 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB42 A3               [24] 1404 	inc	dptr
      00BB43 E4               [12] 1405 	clr	a
      00BB44 93               [24] 1406 	movc	a,@a+dptr
      00BB45 12 3B 01         [24] 1407 	lcall	_ak820_outline_0160
      00BB48 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BB49 12 BB F5         [24] 1410 	lcall	_ak820_outline_0039
      00BB4C A3               [24] 1411 	inc	dptr
      00BB4D 74 04            [12] 1412 	mov	a,#0x04
      00BB4F F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BB50 90 0D B6         [24] 1415 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BB53 04               [12] 1416 	inc	a
      00BB54 2D               [12] 1417 	add	a, r5
      00BB55 F0               [24] 1418 	movx	@dptr,a
      00BB56 E4               [12] 1419 	clr	a
      00BB57 3E               [12] 1420 	addc	a, r6
      00BB58 A3               [24] 1421 	inc	dptr
      00BB59 F0               [24] 1422 	movx	@dptr,a
      00BB5A 85 4E 82         [24] 1423 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BB5D 85 4F 83         [24] 1424 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1425 ;	quantum/vialrgb.c:187: }
                                   1426 ;	quantum/vialrgb.c:188: }
      00BB60 02 B8 83         [24] 1427 	ljmp	_get_matrix_pos_for_led
                                   1428 ;------------------------------------------------------------
                                   1429 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1430 ;------------------------------------------------------------
                                   1431 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1432 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1433 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1434 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1435 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1436 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1437 ;------------------------------------------------------------
                                   1438 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1439 ;	-----------------------------------------
                                   1440 ;	 function vialrgb_set_value
                                   1441 ;	-----------------------------------------
      00BB63                       1442 _vialrgb_set_value:
      00BB63 12 45 5E         [24] 1443 	lcall	_ak820_outline_0037
      00BB66 90 0D C5         [24] 1444 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB69 12 3A 74         [24] 1445 	lcall	_ak820_outline_0017
                                   1446 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BB6C 90 0D C4         [24] 1447 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BB6F E0               [24] 1448 	movx	a,@dptr
      00BB70 FF               [12] 1449 	mov	r7,a
      00BB71 BF 20 02         [24] 1450 	cjne	r7,#0x20,00129$
      00BB74 80 01            [24] 1451 	sjmp	00102$
      00BB76                       1452 00129$:
      00BB76 22               [24] 1453 	ret
      00BB77                       1454 00102$:
                                   1455 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB77 90 0D C5         [24] 1456 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB7A 12 BB FD         [24] 1457 	lcall	_ak820_outline_0046
                                   1458 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1459 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BB7D BA 41 02         [24] 1460 	cjne	r2,#0x41,00130$
      00BB80 80 06            [24] 1461 	sjmp	00103$
      00BB82                       1462 00130$:
      00BB82 BA 42 02         [24] 1463 	cjne	r2,#0x42,00131$
      00BB85 80 5E            [24] 1464 	sjmp	00104$
      00BB87                       1465 00131$:
      00BB87 22               [24] 1466 	ret
                                   1467 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BB88                       1468 00103$:
                                   1469 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BB88 12 36 47         [24] 1470 	lcall	_ak820_outline_0123
      00BB8B E0               [24] 1471 	movx	a,@dptr
      00BB8C FA               [12] 1472 	mov	r2,a
      00BB8D 12 BB F5         [24] 1473 	lcall	_ak820_outline_0039
      00BB90 E0               [24] 1474 	movx	a,@dptr
      00BB91 F8               [12] 1475 	mov	r0,a
      00BB92 79 00            [12] 1476 	mov	r1,#0x00
      00BB94 88 53            [24] 1477 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BB96 89 52            [24] 1478 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BB98 8A 01            [24] 1479 	mov	ar1,r2
      00BB9A 7A 00            [12] 1480 	mov	r2,#0x00
      00BB9C E5 53            [12] 1481 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BB9E 42 02            [12] 1482 	orl	ar2,a
                                   1483 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BBA0 12 45 CE         [24] 1484 	lcall	_ak820_outline_0183
      00BBA3 C0 06            [24] 1485 	push	ar6
      00BBA5 C0 05            [24] 1486 	push	ar5
      00BBA7 12 B8 55         [24] 1487 	lcall	_set_mode
      00BBAA D0 05            [24] 1488 	pop	ar5
      00BBAC D0 06            [24] 1489 	pop	ar6
                                   1490 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BBAE 12 BB F5         [24] 1491 	lcall	_ak820_outline_0039
      00BBB1 A3               [24] 1492 	inc	dptr
      00BBB2 E0               [24] 1493 	movx	a,@dptr
      00BBB3 F5 82            [12] 1494 	mov	dpl,a
      00BBB5 C0 06            [24] 1495 	push	ar6
      00BBB7 C0 05            [24] 1496 	push	ar5
      00BBB9 12 5A AF         [24] 1497 	lcall	_rgb_matrix_set_speed_noeeprom
      00BBBC D0 05            [24] 1498 	pop	ar5
      00BBBE D0 06            [24] 1499 	pop	ar6
                                   1500 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BBC0 12 BB F5         [24] 1501 	lcall	_ak820_outline_0039
      00BBC3 A3               [24] 1502 	inc	dptr
      00BBC4 A3               [24] 1503 	inc	dptr
      00BBC5 E0               [24] 1504 	movx	a,@dptr
      00BBC6 F9               [12] 1505 	mov	r1,a
      00BBC7 7A 00            [12] 1506 	mov	r2,#0x00
      00BBC9 74 06            [12] 1507 	mov	a,#0x06
      00BBCB 12 BC 47         [24] 1508 	lcall	_ak820_outline_0171
      00BBCE F8               [12] 1509 	mov	r0,a
      00BBCF 74 07            [12] 1510 	mov	a,#0x07
      00BBD1 12 BC 47         [24] 1511 	lcall	_ak820_outline_0171
      00BBD4 FE               [12] 1512 	mov	r6,a
      00BBD5 90 07 56         [24] 1513 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BBD8 E8               [12] 1514 	mov	a,r0
      00BBD9 F0               [24] 1515 	movx	@dptr,a
      00BBDA 90 07 57         [24] 1516 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BBDD EE               [12] 1517 	mov	a,r6
      00BBDE F0               [24] 1518 	movx	@dptr,a
      00BBDF 12 45 CE         [24] 1519 	lcall	_ak820_outline_0183
                                   1520 ;	quantum/vialrgb.c:202: break;
                                   1521 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BBE2 02 5A 80         [24] 1522 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BBE5                       1523 00104$:
                                   1524 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BBE5 EF               [12] 1525 	mov	a,r7
      00BBE6 24 FE            [12] 1526 	add	a,#0xfe
      00BBE8 90 0D BA         [24] 1527 	mov	dptr,#_fast_set_leds_PARM_2
      00BBEB F0               [24] 1528 	movx	@dptr,a
      00BBEC 12 36 47         [24] 1529 	lcall	_ak820_outline_0123
                                   1530 ;	quantum/vialrgb.c:210: }
                                   1531 ;	quantum/vialrgb.c:211: }
      00BBEF 02 B8 B6         [24] 1532 	ljmp	_fast_set_leds
                                   1533 ;------------------------------------------------------------
                                   1534 ;Allocation info for local variables in function 'vialrgb_save'
                                   1535 ;------------------------------------------------------------
                                   1536 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1537 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1538 ;------------------------------------------------------------
                                   1539 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function vialrgb_save
                                   1542 ;	-----------------------------------------
      00BBF2                       1543 _vialrgb_save:
                                   1544 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1545 ;	quantum/vialrgb.c:218: }
      00BBF2 02 55 07         [24] 1546 	ljmp	_eeconfig_update_rgb_matrix
                                   1547 	.area CSEG    (CODE)
                                   1548 	.area CONST   (CODE)
                                   1549 	.area CONST   (CODE)
      00C3FA                       1550 _supported_modes:
      00C3FA 00                    1551 	.db #0x00	; 0
      00C3FB 00                    1552 	.db #0x00	; 0
      00C3FC 01                    1553 	.db #0x01	; 1
      00C3FD 05                    1554 	.db #0x05	; 5
      00C3FE 02                    1555 	.db #0x02	; 2
      00C3FF 01                    1556 	.db #0x01	; 1
      00C400 06                    1557 	.db #0x06	; 6
      00C401 02                    1558 	.db #0x02	; 2
      00C402 0D                    1559 	.db #0x0d	; 13
      00C403 03                    1560 	.db #0x03	; 3
      00C404 0E                    1561 	.db #0x0e	; 14
      00C405 04                    1562 	.db #0x04	; 4
      00C406 1F                    1563 	.db #0x1f	; 31
      00C407 06                    1564 	.db #0x06	; 6
                                   1565 	.area CSEG    (CODE)
                                   1566 	.area XINIT   (CODE)
                                   1567 	.area CABS    (ABS,CODE)
                                   1568 
                                   1569 ; Experimental exact instruction outlining.
                                   1570 	.globl _ak820_outline_0005
                                   1571 	.globl _ak820_outline_0017
                                   1572 	.globl _ak820_outline_0022
                                   1573 	.globl _ak820_outline_0037
                                   1574 	.globl _ak820_outline_0039
                                   1575 	.globl _ak820_outline_0040
                                   1576 	.globl _ak820_outline_0046
                                   1577 	.globl _ak820_outline_0047
                                   1578 	.globl _ak820_outline_0051
                                   1579 	.globl _ak820_outline_0062
                                   1580 	.globl _ak820_outline_0077
                                   1581 	.globl _ak820_outline_0079
                                   1582 	.globl _ak820_outline_0084
                                   1583 	.globl _ak820_outline_0085
                                   1584 	.globl _ak820_outline_0106
                                   1585 	.globl _ak820_outline_0107
                                   1586 	.globl _ak820_outline_0108
                                   1587 	.globl _ak820_outline_0109
                                   1588 	.globl _ak820_outline_0118
                                   1589 	.globl _ak820_outline_0121
                                   1590 	.globl _ak820_outline_0122
                                   1591 	.globl _ak820_outline_0123
                                   1592 	.globl _ak820_outline_0135
                                   1593 	.globl _ak820_outline_0136
                                   1594 	.globl _ak820_outline_0144
                                   1595 	.globl _ak820_outline_0146
                                   1596 	.globl _ak820_outline_0160
                                   1597 	.globl _ak820_outline_0164
                                   1598 	.globl _ak820_outline_0171
                                   1599 	.globl _ak820_outline_0183
                                   1600 	.globl _ak820_outline_0188
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0039
      00BBF5                       1604 _ak820_outline_0039:
      00BBF5 8D 82            [24] 1605 	mov	dpl,r5
      00BBF7 8E 83            [24] 1606 	mov	dph,r6
      00BBF9 A3               [24] 1607 	inc	dptr
      00BBFA A3               [24] 1608 	inc	dptr
      00BBFB A3               [24] 1609 	inc	dptr
      00BBFC 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0046
      00BBFD                       1614 _ak820_outline_0046:
      00BBFD E0               [24] 1615 	movx	a,@dptr
      00BBFE FD               [12] 1616 	mov	r5,a
      00BBFF A3               [24] 1617 	inc	dptr
      00BC00 E0               [24] 1618 	movx	a,@dptr
      00BC01 FE               [12] 1619 	mov	r6,a
      00BC02 74 02            [12] 1620 	mov	a,#0x02
      00BC04 2D               [12] 1621 	add	a,r5
      00BC05 FB               [12] 1622 	mov	r3,a
      00BC06 E4               [12] 1623 	clr	a
      00BC07 3E               [12] 1624 	addc	a,r6
      00BC08 FC               [12] 1625 	mov	r4,a
      00BC09 8D 82            [24] 1626 	mov	dpl,r5
      00BC0B 8E 83            [24] 1627 	mov	dph,r6
      00BC0D A3               [24] 1628 	inc	dptr
      00BC0E E0               [24] 1629 	movx	a,@dptr
      00BC0F FA               [12] 1630 	mov	r2,a
      00BC10 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0047
      00BC11                       1635 _ak820_outline_0047:
      00BC11 ED               [12] 1636 	mov	a,r5
      00BC12 75 F0 02         [24] 1637 	mov	b,#0x02
      00BC15 A4               [48] 1638 	mul	ab
      00BC16 24 FA            [12] 1639 	add	a,#_supported_modes
      00BC18 FB               [12] 1640 	mov	r3,a
      00BC19 74 C3            [12] 1641 	mov	a,#(_supported_modes>>8)
      00BC1B 35 F0            [12] 1642 	addc	a,b
      00BC1D FC               [12] 1643 	mov	r4,a
      00BC1E 8B 82            [24] 1644 	mov	dpl,r3
      00BC20 8C 83            [24] 1645 	mov	dph,r4
      00BC22 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0084
      00BC23                       1650 _ak820_outline_0084:
      00BC23 90 0D BB         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC26 E0               [24] 1652 	movx	a,@dptr
      00BC27 F9               [12] 1653 	mov	r1,a
      00BC28 A3               [24] 1654 	inc	dptr
      00BC29 E0               [24] 1655 	movx	a,@dptr
      00BC2A FF               [12] 1656 	mov	r7,a
      00BC2B 89 82            [24] 1657 	mov	dpl,r1
      00BC2D 8F 83            [24] 1658 	mov	dph,r7
      00BC2F E0               [24] 1659 	movx	a,@dptr
      00BC30 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0106
      00BC31                       1664 _ak820_outline_0106:
      00BC31 90 0D BB         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC34 74 01            [12] 1666 	mov	a,#0x01
      00BC36 29               [12] 1667 	add	a,r1
      00BC37 F0               [24] 1668 	movx	@dptr,a
      00BC38 E4               [12] 1669 	clr	a
      00BC39 3F               [12] 1670 	addc	a,r7
      00BC3A A3               [24] 1671 	inc	dptr
      00BC3B F0               [24] 1672 	movx	@dptr,a
      00BC3C 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0146
      00BC3D                       1677 _ak820_outline_0146:
      00BC3D E4               [12] 1678 	clr	a
      00BC3E 93               [24] 1679 	movc	a,@a+dptr
      00BC3F FC               [12] 1680 	mov	r4,a
      00BC40 7B 00            [12] 1681 	mov	r3,#0x00
      00BC42 8C 82            [24] 1682 	mov	dpl,r4
      00BC44 8B 83            [24] 1683 	mov	dph,r3
      00BC46 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0171
      00BC47                       1688 _ak820_outline_0171:
      00BC47 2D               [12] 1689 	add	a,r5
      00BC48 F5 82            [12] 1690 	mov	dpl,a
      00BC4A E4               [12] 1691 	clr	a
      00BC4B 3E               [12] 1692 	addc	a,r6
      00BC4C F5 83            [12] 1693 	mov	dph,a
      00BC4E E0               [24] 1694 	movx	a,@dptr
      00BC4F 22               [24] 1695 	ret
