                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000018                        588 _process_action_sloc0_1_0:
      000018                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      00080B                        616 _tp_buttons::
      00080B                        617 	.ds 2
      00080D                        618 _action_exec_PARM_1:
      00080D                        619 	.ds 6
      000813                        620 _action_exec_record_10001_624:
      000813                        621 	.ds 9
      00081C                        622 _ak820_action_exec_event_10000_628:
      00081C                        623 	.ds 2
      00081E                        624 _ak820_action_exec_snapshot_10000_629:
      00081E                        625 	.ds 6
      000824                        626 _process_record_record_10000_632:
      000824                        627 	.ds 3
      000827                        628 _process_record_handler_record_argument_10000_640:
      000827                        629 	.ds 3
      00082A                        630 _process_record_handler_action_10000_641:
      00082A                        631 	.ds 2
      00082C                        632 _process_action_PARM_2:
      00082C                        633 	.ds 2
      00082E                        634 _process_action_record_argument_10000_652:
      00082E                        635 	.ds 3
      000831                        636 _process_action_on_40000_675:
      000831                        637 	.ds 1
      000832                        638 _register_code_code_10000_709:
      000832                        639 	.ds 1
      000833                        640 _unregister_code_code_10000_723:
      000833                        641 	.ds 1
      000834                        642 _tap_code_delay_PARM_2:
      000834                        643 	.ds 2
      000836                        644 _tap_code_delay_code_10000_736:
      000836                        645 	.ds 1
      000837                        646 _tap_code_code_10000_743:
      000837                        647 	.ds 1
      000838                        648 _register_mods_mods_10000_745:
      000838                        649 	.ds 1
      000839                        650 _unregister_mods_mods_10000_749:
      000839                        651 	.ds 1
      00083A                        652 _register_weak_mods_mods_10000_753:
      00083A                        653 	.ds 1
      00083B                        654 _unregister_weak_mods_mods_10000_757:
      00083B                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DB5                        664 _disable_action_cache::
      000DB5                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      006F7A                        709 _action_exec:
                                    710 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      006F7A 90 08 0F         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006F7D 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      006F80 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      006F83 90 08 0D         [24]  715 	mov	dptr,#_action_exec_PARM_1
      006F86 12 44 53         [24]  716 	lcall	_ak820_tapping_before
      006F89 E5 82            [12]  717 	mov	a, dpl
      006F8B 70 01            [24]  718 	jnz	00102$
      006F8D 22               [24]  719 	ret
      006F8E                        720 00102$:
                                    721 ;	quantum/action.c:116: if (event.pressed) {
      006F8E 90 08 12         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006F91 E0               [24]  723 	movx	a,@dptr
      006F92 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:118: clear_weak_mods();
      006F94 12 7F DA         [24]  726 	lcall	_clear_weak_mods
      006F97                        727 00104$:
                                    728 ;	quantum/action.c:130: record.event = event;
      006F97 90 0D 95         [24]  729 	mov	dptr,#___memcpy_PARM_2
      006F9A 74 0D            [12]  730 	mov	a,#_action_exec_PARM_1
      006F9C F0               [24]  731 	movx	@dptr,a
      006F9D 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      006F9F 12 38 70         [24]  733 	lcall	_ak820_outline_0092
      006FA2 12 76 4E         [24]  734 	lcall	_ak820_outline_0070
      006FA5 90 08 13         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      006FA8 F5 F0            [12]  736 	mov	b,a
      006FAA 12 B6 8E         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:132: record.tap.count = 0;
      006FAD 90 08 19         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      006FB0 E0               [24]  740 	movx	a,@dptr
      006FB1 54 0F            [12]  741 	anl	a,#0x0f
      006FB3 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:137: record.keycode = 0;
      006FB4 90 08 1A         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      006FB7 12 4E C3         [24]  745 	lcall	_ak820_outline_0183
                                    746 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006FBA 90 08 17         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      006FBD E0               [24]  748 	movx	a,@dptr
      006FBE 60 0D            [24]  749 	jz	00107$
      006FC0 90 08 13         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      006FC3 75 F0 00         [24]  751 	mov	b, #0x00
      006FC6 12 9D BC         [24]  752 	lcall	_pre_process_record_quantum
      006FC9 E5 82            [12]  753 	mov	a, dpl
      006FCB 60 14            [24]  754 	jz	00110$
      006FCD                        755 00107$:
                                    756 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      006FCD 90 08 13         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      006FD0 12 45 3F         [24]  758 	lcall	_ak820_tapping_process
      006FD3 E5 82            [12]  759 	mov	a, dpl
      006FD5 70 01            [24]  760 	jnz	00106$
      006FD7 22               [24]  761 	ret
      006FD8                        762 00106$:
                                    763 ;	quantum/action.c:175: process_record(&record);
      006FD8 90 08 13         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      006FDB 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:190: }
      006FDE 02 70 1E         [24]  767 	ljmp	_process_record
      006FE1                        768 00110$:
      006FE1 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      006FE2                        780 _ak820_action_exec:
      006FE2 12 38 8D         [24]  781 	lcall	_ak820_outline_0108
      006FE5 90 08 1C         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      006FE8 12 38 88         [24]  783 	lcall	_ak820_outline_0107
                                    784 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      006FEB 90 08 1C         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      006FEE 12 38 64         [24]  786 	lcall	_ak820_outline_0078
      006FF1 7F 00            [12]  787 	mov	r7,#0x00
      006FF3 90 0D 95         [24]  788 	mov	dptr,#___memcpy_PARM_2
      006FF6 ED               [12]  789 	mov	a,r5
      006FF7 12 38 29         [24]  790 	lcall	_ak820_outline_0016
      006FFA 12 76 4E         [24]  791 	lcall	_ak820_outline_0070
      006FFD 90 08 1E         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      007000 F5 F0            [12]  793 	mov	b,a
      007002 12 B6 8E         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:197: action_exec(snapshot);
      007005 90 0D 95         [24]  796 	mov	dptr,#___memcpy_PARM_2
      007008 74 1E            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      00700A F0               [24]  798 	movx	@dptr,a
      00700B 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      00700D 12 38 70         [24]  800 	lcall	_ak820_outline_0092
      007010 12 76 4E         [24]  801 	lcall	_ak820_outline_0070
      007013 90 08 0D         [24]  802 	mov	dptr,#_action_exec_PARM_1
      007016 F5 F0            [12]  803 	mov	b,a
      007018 12 B6 8E         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:198: }
      00701B 02 6F 7A         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      00701E                        816 _process_record:
      00701E 12 43 13         [24]  817 	lcall	_ak820_outline_0037
      007021 90 08 24         [24]  818 	mov	dptr,#_process_record_record_10000_632
      007024 12 38 29         [24]  819 	lcall	_ak820_outline_0016
                                    820 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      007027 90 08 24         [24]  821 	mov	dptr,#_process_record_record_10000_632
      00702A 12 4E 70         [24]  822 	lcall	_ak820_outline_0011
      00702D 74 04            [12]  823 	mov	a,#0x04
      00702F 12 76 21         [24]  824 	lcall	_ak820_outline_0013
      007032 12 B7 67         [24]  825 	lcall	__gptrget
      007035 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:338: return;
      007037 22               [24]  828 	ret
      007038                        829 00102$:
                                    830 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007038 8D 02            [24]  831 	mov	ar2,r5
      00703A 8E 03            [24]  832 	mov	ar3,r6
      00703C 8F 04            [24]  833 	mov	ar4,r7
      00703E 90 0D 95         [24]  834 	mov	dptr,#___memcpy_PARM_2
      007041 EA               [12]  835 	mov	a,r2
      007042 12 76 95         [24]  836 	lcall	_ak820_outline_0187
      007045 EC               [12]  837 	mov	a,r4
      007046 A3               [24]  838 	inc	dptr
      007047 F0               [24]  839 	movx	@dptr,a
      007048 90 0D 98         [24]  840 	mov	dptr,#___memcpy_PARM_3
      00704B 12 4E B5         [24]  841 	lcall	_ak820_outline_0110
      00704E 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      007051 F5 F0            [12]  843 	mov	b,a
      007053 C0 07            [24]  844 	push	ar7
      007055 C0 06            [24]  845 	push	ar6
      007057 C0 05            [24]  846 	push	ar5
      007059 12 B6 8E         [24]  847 	lcall	___memcpy
      00705C 12 43 8D         [24]  848 	lcall	_ak820_tapping_source
      00705F AC 82            [24]  849 	mov	r4, dpl
      007061 D0 05            [24]  850 	pop	ar5
      007063 D0 06            [24]  851 	pop	ar6
      007065 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      007067 74 05            [12]  854 	mov	a,#0x05
      007069 12 76 13         [24]  855 	lcall	_ak820_outline_0012
      00706C 12 B7 67         [24]  856 	lcall	__gptrget
      00706F FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007070 12 76 7A         [24]  859 	lcall	_ak820_outline_0146
      007073 90 0B F1         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      007076 74 01            [12]  861 	mov	a,#0x01
      007078 12 4E 79         [24]  862 	lcall	_ak820_outline_0033
      00707B C0 04            [24]  863 	push	ar4
      00707D C0 03            [24]  864 	push	ar3
      00707F C0 02            [24]  865 	push	ar2
      007081 C0 01            [24]  866 	push	ar1
      007083 C0 00            [24]  867 	push	ar0
      007085 12 9D 7E         [24]  868 	lcall	_get_record_keycode
      007088 12 43 5C         [24]  869 	lcall	_ak820_outline_0133
      00708B D0 00            [24]  870 	pop	ar0
      00708D D0 01            [24]  871 	pop	ar1
      00708F D0 02            [24]  872 	pop	ar2
      007091 D0 03            [24]  873 	pop	ar3
      007093 D0 04            [24]  874 	pop	ar4
      007095 12 38 B1         [24]  875 	lcall	_ak820_outline_0144
      007098 8A F0            [24]  876 	mov	b,r2
      00709A EE               [12]  877 	mov	a,r6
      00709B 12 B7 2C         [24]  878 	lcall	__gptrput
      00709E A3               [24]  879 	inc	dptr
      00709F EF               [12]  880 	mov	a,r7
      0070A0 12 B7 2C         [24]  881 	lcall	__gptrput
                                    882 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0070A3 90 08 24         [24]  883 	mov	dptr,#_process_record_record_10000_632
      0070A6 12 4E 70         [24]  884 	lcall	_ak820_outline_0011
      0070A9 12 76 7A         [24]  885 	lcall	_ak820_outline_0146
      0070AC 12 38 B1         [24]  886 	lcall	_ak820_outline_0144
      0070AF 8A F0            [24]  887 	mov	b,r2
      0070B1 12 B7 67         [24]  888 	lcall	__gptrget
      0070B4 F8               [12]  889 	mov	r0,a
      0070B5 A3               [24]  890 	inc	dptr
      0070B6 12 B7 67         [24]  891 	lcall	__gptrget
      0070B9 F9               [12]  892 	mov	r1,a
      0070BA 90 06 31         [24]  893 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0070BD EC               [12]  894 	mov	a,r4
      0070BE F0               [24]  895 	movx	@dptr,a
      0070BF 90 06 32         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0070C2 EB               [12]  897 	mov	a,r3
      0070C3 F0               [24]  898 	movx	@dptr,a
      0070C4 12 38 B1         [24]  899 	lcall	_ak820_outline_0144
      0070C7 C0 07            [24]  900 	push	ar7
      0070C9 C0 06            [24]  901 	push	ar6
      0070CB C0 05            [24]  902 	push	ar5
      0070CD C0 04            [24]  903 	push	ar4
      0070CF C0 03            [24]  904 	push	ar3
      0070D1 12 46 81         [24]  905 	lcall	_ak820_oneshot_process
      0070D4 E5 82            [12]  906 	mov	a, dpl
      0070D6 D0 03            [24]  907 	pop	ar3
      0070D8 D0 04            [24]  908 	pop	ar4
      0070DA D0 05            [24]  909 	pop	ar5
      0070DC D0 06            [24]  910 	pop	ar6
      0070DE D0 07            [24]  911 	pop	ar7
      0070E0 70 01            [24]  912 	jnz	00104$
      0070E2 22               [24]  913 	ret
      0070E3                        914 00104$:
                                    915 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      0070E3 12 6C E0         [24]  916 	lcall	_ak820_outline_0057
      0070E6 C0 04            [24]  917 	push	ar4
      0070E8 C0 03            [24]  918 	push	ar3
      0070EA 12 9E 47         [24]  919 	lcall	_process_record_quantum
      0070ED E5 82            [12]  920 	mov	a, dpl
      0070EF D0 03            [24]  921 	pop	ar3
      0070F1 D0 04            [24]  922 	pop	ar4
      0070F3 70 0A            [24]  923 	jnz	00106$
                                    924 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0070F5 90 05 9C         [24]  925 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0070F8 EB               [12]  926 	mov	a,r3
      0070F9 F0               [24]  927 	movx	@dptr,a
      0070FA 8C 82            [24]  928 	mov	dpl, r4
                                    929 ;	quantum/action.c:360: return;
      0070FC 02 2E BB         [24]  930 	ljmp	_ak820_oneshot_post
      0070FF                        931 00106$:
                                    932 ;	quantum/action.c:366: process_record_handler(record);
      0070FF 90 08 24         [24]  933 	mov	dptr,#_process_record_record_10000_632
      007102 12 4E 4A         [24]  934 	lcall	_ak820_outline_0001
      007105 C0 04            [24]  935 	push	ar4
      007107 C0 03            [24]  936 	push	ar3
      007109 12 71 23         [24]  937 	lcall	_process_record_handler
                                    938 ;	quantum/action.c:370: post_process_record_quantum(record);
      00710C 90 08 24         [24]  939 	mov	dptr,#_process_record_record_10000_632
      00710F 12 4E 4A         [24]  940 	lcall	_ak820_outline_0001
      007112 12 9E 1C         [24]  941 	lcall	_post_process_record_quantum
      007115 D0 03            [24]  942 	pop	ar3
      007117 D0 04            [24]  943 	pop	ar4
                                    944 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007119 90 05 9C         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00711C EB               [12]  946 	mov	a,r3
      00711D F0               [24]  947 	movx	@dptr,a
      00711E 8C 82            [24]  948 	mov	dpl, r4
                                    949 ;	quantum/action.c:374: }
      007120 02 2E BB         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      007123                        962 _process_record_handler:
      007123 12 43 13         [24]  963 	lcall	_ak820_outline_0037
      007126 90 08 27         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007129 12 38 29         [24]  965 	lcall	_ak820_outline_0016
                                    966 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00712C 90 08 27         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_640
      00712F 12 37 FE         [24]  968 	lcall	_ak820_outline_0007
                                    969 ;	quantum/action.c:387: if (record->keycode) {
      007132 4C               [12]  970 	orl	a,r4
      007133 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      007135 12 38 97         [24]  973 	lcall	_ak820_outline_0124
      007138 C0 07            [24]  974 	push	ar7
      00713A C0 06            [24]  975 	push	ar6
      00713C 12 93 B9         [24]  976 	lcall	_action_for_keycode
      00713F 12 43 72         [24]  977 	lcall	_ak820_outline_0150
      007142 D0 06            [24]  978 	pop	ar6
      007144 D0 07            [24]  979 	pop	ar7
      007146 90 08 2A         [24]  980 	mov	dptr,#_process_record_handler_action_10000_641
      007149 12 38 5E         [24]  981 	lcall	_ak820_outline_0071
      00714C 80 2B            [24]  982 	sjmp	00104$
      00714E                        983 00102$:
                                    984 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00714E 12 76 2F         [24]  985 	lcall	_ak820_outline_0021
      007151 7A 00            [12]  986 	mov	r2,#0x00
      007153 12 43 67         [24]  987 	lcall	_ak820_outline_0142
      007156 12 43 01         [24]  988 	lcall	_ak820_outline_0010
      007159 E0               [24]  989 	movx	a,@dptr
      00715A 90 09 66         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      00715D F0               [24]  991 	movx	@dptr,a
      00715E 8D 82            [24]  992 	mov	dpl, r5
      007160 8C 83            [24]  993 	mov	dph, r4
      007162 C0 07            [24]  994 	push	ar7
      007164 C0 06            [24]  995 	push	ar6
      007166 12 79 D6         [24]  996 	lcall	_ak820_resolve_key
      007169 12 93 B9         [24]  997 	lcall	_action_for_keycode
      00716C 12 43 72         [24]  998 	lcall	_ak820_outline_0150
      00716F D0 06            [24]  999 	pop	ar6
      007171 D0 07            [24] 1000 	pop	ar7
      007173 90 08 2A         [24] 1001 	mov	dptr,#_process_record_handler_action_10000_641
      007176 12 38 5E         [24] 1002 	lcall	_ak820_outline_0071
                                   1003 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007179                       1004 00104$:
                                   1005 ;	quantum/action.c:411: process_action(record, action);
      007179 7D 00            [12] 1006 	mov	r5,#0x00
      00717B 90 0D 95         [24] 1007 	mov	dptr,#___memcpy_PARM_2
      00717E 74 2A            [12] 1008 	mov	a,#_process_record_handler_action_10000_641
      007180 F0               [24] 1009 	movx	@dptr,a
      007181 74 08            [12] 1010 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      007183 12 38 70         [24] 1011 	lcall	_ak820_outline_0092
      007186 90 0D 98         [24] 1012 	mov	dptr,#___memcpy_PARM_3
      007189 12 4E B5         [24] 1013 	lcall	_ak820_outline_0110
      00718C 90 08 2C         [24] 1014 	mov	dptr,#_process_action_PARM_2
      00718F F5 F0            [12] 1015 	mov	b,a
      007191 C0 07            [24] 1016 	push	ar7
      007193 C0 06            [24] 1017 	push	ar6
      007195 C0 05            [24] 1018 	push	ar5
      007197 12 B6 8E         [24] 1019 	lcall	___memcpy
      00719A D0 05            [24] 1020 	pop	ar5
      00719C D0 06            [24] 1021 	pop	ar6
      00719E D0 07            [24] 1022 	pop	ar7
      0071A0 12 6E F3         [24] 1023 	lcall	_ak820_outline_0064
                                   1024 ;	quantum/action.c:412: }
      0071A3 02 71 A6         [24] 1025 	ljmp	_process_action
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'register_mouse'
                                   1028 ;------------------------------------------------------------
                                   1029 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1030 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function process_action
                                   1035 ;	-----------------------------------------
      0071A6                       1036 _process_action:
      0071A6 12 43 13         [24] 1037 	lcall	_ak820_outline_0037
      0071A9 90 08 2E         [24] 1038 	mov	dptr,#_process_action_record_argument_10000_652
      0071AC 12 38 29         [24] 1039 	lcall	_ak820_outline_0016
                                   1040 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071AF 90 08 2E         [24] 1041 	mov	dptr,#_process_action_record_argument_10000_652
      0071B2 12 37 F4         [24] 1042 	lcall	_ak820_outline_0005
                                   1043 ;	quantum/action.c:483: pressed = record->event.pressed;
      0071B5 A3               [24] 1044 	inc	dptr
      0071B6 A3               [24] 1045 	inc	dptr
      0071B7 A3               [24] 1046 	inc	dptr
      0071B8 A3               [24] 1047 	inc	dptr
      0071B9 A3               [24] 1048 	inc	dptr
      0071BA E0               [24] 1049 	movx	a,@dptr
      0071BB F5 18            [12] 1050 	mov	_process_action_sloc0_1_0,a
                                   1051 ;	quantum/action.c:507: switch (action.kind.id) {
      0071BD 90 08 2D         [24] 1052 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071C0 E0               [24] 1053 	movx	a,@dptr
      0071C1 C4               [12] 1054 	swap	a
      0071C2 54 0F            [12] 1055 	anl	a,#0x0f
      0071C4 FD               [12] 1056 	mov  r5,a
      0071C5 24 F4            [12] 1057 	add	a,#0xff - 0x0b
      0071C7 50 03            [24] 1058 	jnc	00434$
      0071C9 02 74 47         [24] 1059 	ljmp	00181$
      0071CC                       1060 00434$:
                                   1061 ;	free result
      0071CC ED               [12] 1062 	mov	a,r5
      0071CD 24 0A            [12] 1063 	add	a,#(00435$-3-.)
      0071CF 83               [24] 1064 	movc	a,@a+pc
      0071D0 F5 82            [12] 1065 	mov	dpl,a
      0071D2 ED               [12] 1066 	mov	a,r5
      0071D3 24 10            [12] 1067 	add	a,#(00436$-3-.)
      0071D5 83               [24] 1068 	movc	a,@a+pc
      0071D6 F5 83            [12] 1069 	mov	dph,a
      0071D8 E4               [12] 1070 	clr	a
      0071D9 73               [24] 1071 	jmp	@a+dptr
      0071DA                       1072 00435$:
      0071DA F2                    1073 	.db	00102$
      0071DB F2                    1074 	.db	00102$
      0071DC 47                    1075 	.db	00181$
      0071DD 47                    1076 	.db	00181$
      0071DE 7C                    1077 	.db	00123$
      0071DF 47                    1078 	.db	00181$
      0071E0 47                    1079 	.db	00181$
      0071E1 47                    1080 	.db	00181$
      0071E2 DC                    1081 	.db	00131$
      0071E3 AE                    1082 	.db	00147$
      0071E4 D4                    1083 	.db	00152$
      0071E5 D4                    1084 	.db	00152$
      0071E6                       1085 00436$:
      0071E6 71                    1086 	.db	00102$>>8
      0071E7 71                    1087 	.db	00102$>>8
      0071E8 74                    1088 	.db	00181$>>8
      0071E9 74                    1089 	.db	00181$>>8
      0071EA 72                    1090 	.db	00123$>>8
      0071EB 74                    1091 	.db	00181$>>8
      0071EC 74                    1092 	.db	00181$>>8
      0071ED 74                    1093 	.db	00181$>>8
      0071EE 72                    1094 	.db	00131$>>8
      0071EF 73                    1095 	.db	00147$>>8
      0071F0 73                    1096 	.db	00152$>>8
      0071F1 73                    1097 	.db	00152$>>8
                                   1098 ;	quantum/action.c:510: case ACT_RMODS: {
      0071F2                       1099 00102$:
                                   1100 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0071F2 90 08 2D         [24] 1101 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071F5 E0               [24] 1102 	movx	a,@dptr
      0071F6 54 F0            [12] 1103 	anl	a,#0xf0
      0071F8 70 06            [24] 1104 	jnz	00194$
      0071FA 12 76 68         [24] 1105 	lcall	_ak820_outline_0112
      0071FD FD               [12] 1106 	mov	r5,a
      0071FE 80 07            [24] 1107 	sjmp	00195$
      007200                       1108 00194$:
      007200 12 76 68         [24] 1109 	lcall	_ak820_outline_0112
      007203 C4               [12] 1110 	swap	a
      007204 54 F0            [12] 1111 	anl	a,#0xf0
      007206 FD               [12] 1112 	mov	r5,a
      007207                       1113 00195$:
                                   1114 ;	quantum/action.c:513: if (pressed) {
      007207 E5 18            [12] 1115 	mov	a,_process_action_sloc0_1_0
      007209 60 35            [24] 1116 	jz	00119$
                                   1117 ;	quantum/action.c:514: if (mods) {
      00720B ED               [12] 1118 	mov	a,r5
      00720C 60 29            [24] 1119 	jz	00110$
                                   1120 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00720E 12 76 84         [24] 1121 	lcall	_ak820_outline_0159
      007211 FC               [12] 1122 	mov	r4,a
      007212 BC E0 00         [24] 1123 	cjne	r4,#0xe0,00440$
      007215                       1124 00440$:
      007215 40 07            [24] 1125 	jc	00108$
      007217 12 76 84         [24] 1126 	lcall	_ak820_outline_0159
      00721A 24 18            [12] 1127 	add	a,#0xff - 0xe7
      00721C 50 0A            [24] 1128 	jnc	00104$
                                   1129 ;	free result
      00721E                       1130 00108$:
      00721E 7B 2C            [12] 1131 	mov	r3,#_process_action_PARM_2
      007220 7C 08            [12] 1132 	mov	r4,#(_process_action_PARM_2 >> 8)
      007222 12 33 FC         [24] 1133 	lcall	_ak820_outline_0123
      007225 E0               [24] 1134 	movx	a,@dptr
      007226 70 07            [24] 1135 	jnz	00105$
      007228                       1136 00104$:
                                   1137 ;	quantum/action.c:519: add_owned_mods(mods);
      007228 8D 82            [24] 1138 	mov	dpl, r5
      00722A 12 7B F0         [24] 1139 	lcall	_add_owned_mods
      00722D 80 05            [24] 1140 	sjmp	00106$
      00722F                       1141 00105$:
                                   1142 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      00722F 8D 82            [24] 1143 	mov	dpl, r5
      007231 12 7C 0F         [24] 1144 	lcall	_add_owned_weak_mods
      007234                       1145 00106$:
                                   1146 ;	quantum/action.c:523: send_keyboard_report();
      007234 12 7F 2A         [24] 1147 	lcall	_send_keyboard_report
      007237                       1148 00110$:
                                   1149 ;	quantum/action.c:525: register_code(action.key.code);
      007237 12 76 58         [24] 1150 	lcall	_ak820_outline_0077
      00723A 12 74 5E         [24] 1151 	lcall	_register_code
      00723D 02 74 47         [24] 1152 	ljmp	00181$
      007240                       1153 00119$:
                                   1154 ;	quantum/action.c:527: unregister_code(action.key.code);
      007240 12 76 58         [24] 1155 	lcall	_ak820_outline_0077
      007243 C0 05            [24] 1156 	push	ar5
      007245 12 74 CB         [24] 1157 	lcall	_unregister_code
      007248 D0 05            [24] 1158 	pop	ar5
                                   1159 ;	quantum/action.c:528: if (mods) {
      00724A ED               [12] 1160 	mov	a,r5
      00724B 70 03            [24] 1161 	jnz	00444$
      00724D 02 74 47         [24] 1162 	ljmp	00181$
      007250                       1163 00444$:
                                   1164 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007250 12 76 84         [24] 1165 	lcall	_ak820_outline_0159
      007253 FC               [12] 1166 	mov	r4,a
      007254 BC E0 00         [24] 1167 	cjne	r4,#0xe0,00445$
      007257                       1168 00445$:
      007257 40 07            [24] 1169 	jc	00115$
      007259 12 76 84         [24] 1170 	lcall	_ak820_outline_0159
      00725C 24 18            [12] 1171 	add	a,#0xff - 0xe7
      00725E 50 0A            [24] 1172 	jnc	00111$
                                   1173 ;	free result
      007260                       1174 00115$:
      007260 7B 2C            [12] 1175 	mov	r3,#_process_action_PARM_2
      007262 7C 08            [12] 1176 	mov	r4,#(_process_action_PARM_2 >> 8)
      007264 12 33 FC         [24] 1177 	lcall	_ak820_outline_0123
      007267 E0               [24] 1178 	movx	a,@dptr
      007268 70 07            [24] 1179 	jnz	00112$
      00726A                       1180 00111$:
                                   1181 ;	quantum/action.c:530: del_owned_mods(mods);
      00726A 8D 82            [24] 1182 	mov	dpl, r5
      00726C 12 7C 00         [24] 1183 	lcall	_del_owned_mods
      00726F 80 05            [24] 1184 	sjmp	00113$
      007271                       1185 00112$:
                                   1186 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      007271 8D 82            [24] 1187 	mov	dpl, r5
      007273 12 7C 1F         [24] 1188 	lcall	_del_owned_weak_mods
      007276                       1189 00113$:
                                   1190 ;	quantum/action.c:534: send_keyboard_report();
      007276 12 7F 2A         [24] 1191 	lcall	_send_keyboard_report
                                   1192 ;	quantum/action.c:537: } break;
      007279 02 74 47         [24] 1193 	ljmp	00181$
                                   1194 ;	quantum/action.c:614: case ACT_USAGE:
      00727C                       1195 00123$:
                                   1196 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00727C 74 07            [12] 1197 	mov	a,#0x07
      00727E 12 38 31         [24] 1198 	lcall	_ak820_outline_0023
      007281 12 47 BB         [24] 1199 	lcall	_ak820_outline_0008
      007284 C3               [12] 1200 	clr	c
      007285 EC               [12] 1201 	mov	a,r4
      007286 94 A5            [12] 1202 	subb	a,#0xa5
      007288 ED               [12] 1203 	mov	a,r5
      007289 94 00            [12] 1204 	subb	a,#0x00
      00728B 40 15            [24] 1205 	jc	00125$
      00728D 74 C2            [12] 1206 	mov	a,#0xc2
      00728F 9C               [12] 1207 	subb	a,r4
      007290 E4               [12] 1208 	clr	a
      007291 9D               [12] 1209 	subb	a,r5
      007292 40 0E            [24] 1210 	jc	00125$
                                   1211 ;	free result
                                   1212 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007294 90 0A 8D         [24] 1213 	mov	dptr,#_owned_usage_key_PARM_2
      007297 E5 18            [12] 1214 	mov	a,_process_action_sloc0_1_0
      007299 F0               [24] 1215 	movx	@dptr,a
      00729A 8E 82            [24] 1216 	mov	dpl, r6
      00729C 12 7D D5         [24] 1217 	lcall	_owned_usage_key
                                   1218 ;	quantum/action.c:622: break;
      00729F 02 74 47         [24] 1219 	ljmp	00181$
      0072A2                       1220 00125$:
                                   1221 ;	quantum/action.c:625: switch (action.usage.page) {
      0072A2 12 76 5F         [24] 1222 	lcall	_ak820_outline_0088
      0072A5 FF               [12] 1223 	mov	r7,a
      0072A6 60 08            [24] 1224 	jz	00127$
      0072A8 BF 01 02         [24] 1225 	cjne	r7,#0x01,00452$
      0072AB 80 19            [24] 1226 	sjmp	00128$
      0072AD                       1227 00452$:
      0072AD 02 74 47         [24] 1228 	ljmp	00181$
                                   1229 ;	quantum/action.c:626: case PAGE_SYSTEM:
      0072B0                       1230 00127$:
                                   1231 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      0072B0 E5 18            [12] 1232 	mov	a,_process_action_sloc0_1_0
      0072B2 60 05            [24] 1233 	jz	00196$
      0072B4 12 76 6F         [24] 1234 	lcall	_ak820_outline_0130
      0072B7 80 04            [24] 1235 	sjmp	00197$
      0072B9                       1236 00196$:
      0072B9 7E 00            [12] 1237 	mov	r6,#0x00
      0072BB 7F 00            [12] 1238 	mov	r7,#0x00
      0072BD                       1239 00197$:
      0072BD 12 38 92         [24] 1240 	lcall	_ak820_outline_0117
      0072C0 12 6C 6A         [24] 1241 	lcall	_host_system_send
                                   1242 ;	quantum/action.c:628: break;
      0072C3 02 74 47         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:629: case PAGE_CONSUMER:
      0072C6                       1245 00128$:
                                   1246 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      0072C6 E5 18            [12] 1247 	mov	a,_process_action_sloc0_1_0
      0072C8 60 05            [24] 1248 	jz	00198$
      0072CA 12 76 6F         [24] 1249 	lcall	_ak820_outline_0130
      0072CD 80 04            [24] 1250 	sjmp	00199$
      0072CF                       1251 00198$:
      0072CF 7E 00            [12] 1252 	mov	r6,#0x00
      0072D1 7F 00            [12] 1253 	mov	r7,#0x00
      0072D3                       1254 00199$:
      0072D3 12 38 92         [24] 1255 	lcall	_ak820_outline_0117
      0072D6 12 6C 9A         [24] 1256 	lcall	_host_consumer_send
                                   1257 ;	quantum/action.c:633: break;
      0072D9 02 74 47         [24] 1258 	ljmp	00181$
                                   1259 ;	quantum/action.c:640: case ACT_LAYER: {
      0072DC                       1260 00131$:
                                   1261 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      0072DC 90 08 2D         [24] 1262 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072DF E0               [24] 1263 	movx	a,@dptr
      0072E0 54 03            [12] 1264 	anl	a,#0x03
      0072E2 90 08 31         [24] 1265 	mov	dptr,#_process_action_on_40000_675
      0072E5 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0072E6 E0               [24] 1268 	movx	a,@dptr
      0072E7 FF               [12] 1269 	mov	r7,a
      0072E8 60 11            [24] 1270 	jz	00200$
      0072EA E5 18            [12] 1271 	mov	a,_process_action_sloc0_1_0
      0072EC 60 07            [24] 1272 	jz	00202$
      0072EE 8F 06            [24] 1273 	mov	ar6,r7
      0072F0 53 06 01         [24] 1274 	anl	ar6,#0x01
      0072F3 80 10            [24] 1275 	sjmp	00201$
      0072F5                       1276 00202$:
      0072F5 74 02            [12] 1277 	mov	a,#0x02
      0072F7 5F               [12] 1278 	anl	a,r7
      0072F8 FE               [12] 1279 	mov	r6,a
      0072F9 80 0A            [24] 1280 	sjmp	00201$
      0072FB                       1281 00200$:
      0072FB E5 18            [12] 1282 	mov	a,_process_action_sloc0_1_0
      0072FD B4 01 00         [24] 1283 	cjne	a,#0x01,00457$
      007300                       1284 00457$:
      007300 92 1F            [24] 1285 	mov  _process_action_sloc1_1_0,c
      007302 E4               [12] 1286 	clr	a
      007303 33               [12] 1287 	rlc	a
      007304 FE               [12] 1288 	mov	r6,a
      007305                       1289 00201$:
      007305 EE               [12] 1290 	mov	a,r6
      007306 70 03            [24] 1291 	jnz	00458$
      007308 02 74 47         [24] 1292 	ljmp	00181$
      00730B                       1293 00458$:
                                   1294 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      00730B 12 76 84         [24] 1295 	lcall	_ak820_outline_0159
      00730E C4               [12] 1296 	swap	a
      00730F 03               [12] 1297 	rr	a
      007310 54 07            [12] 1298 	anl	a,#0x07
      007312 25 E0            [12] 1299 	add	a,acc
      007314 25 E0            [12] 1300 	add	a,acc
      007316 FF               [12] 1301 	mov	r7,a
                                   1302 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007317 12 76 84         [24] 1303 	lcall	_ak820_outline_0159
      00731A 54 0F            [12] 1304 	anl	a,#0x0f
      00731C FE               [12] 1305 	mov	r6,a
      00731D 8F F0            [24] 1306 	mov	b,r7
      00731F 05 F0            [12] 1307 	inc	b
      007321 EE               [12] 1308 	mov	a,r6
      007322 80 02            [24] 1309 	sjmp	00460$
      007324                       1310 00459$:
      007324 25 E0            [12] 1311 	add	a,acc
      007326                       1312 00460$:
      007326 D5 F0 FB         [24] 1313 	djnz	b,00459$
      007329 FE               [12] 1314 	mov	r6,a
                                   1315 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00732A 12 76 84         [24] 1316 	lcall	_ak820_outline_0159
      00732D 30 E4 11         [24] 1317 	jnb	acc.4,00204$
      007330 8F F0            [24] 1318 	mov	b,r7
      007332 05 F0            [12] 1319 	inc	b
      007334 74 0F            [12] 1320 	mov	a,#0x0f
      007336 80 02            [24] 1321 	sjmp	00463$
      007338                       1322 00462$:
      007338 25 E0            [12] 1323 	add	a,acc
      00733A                       1324 00463$:
      00733A D5 F0 FB         [24] 1325 	djnz	b,00462$
      00733D F4               [12] 1326 	cpl	a
      00733E FF               [12] 1327 	mov	r7,a
      00733F 80 02            [24] 1328 	sjmp	00205$
      007341                       1329 00204$:
      007341 7F 00            [12] 1330 	mov	r7,#0x00
      007343                       1331 00205$:
                                   1332 ;	quantum/action.c:648: bits |= mask;
      007343 EE               [12] 1333 	mov	a,r6
      007344 42 07            [12] 1334 	orl	ar7,a
                                   1335 ;	quantum/action.c:649: if (!on) {
      007346 90 08 31         [24] 1336 	mov	dptr,#_process_action_on_40000_675
      007349 E0               [24] 1337 	movx	a,@dptr
      00734A 70 31            [24] 1338 	jnz	00143$
                                   1339 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      00734C 12 76 5F         [24] 1340 	lcall	_ak820_outline_0088
      00734F FE               [12] 1341 	mov	r6,a
      007350 2E               [12] 1342 	add	a,r6
                                   1343 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      007351 90 73 55         [24] 1344 	mov	dptr,#00465$
      007354 73               [24] 1345 	jmp	@a+dptr
      007355                       1346 00465$:
      007355 80 06            [24] 1347 	sjmp	00132$
      007357 80 0C            [24] 1348 	sjmp	00133$
      007359 80 12            [24] 1349 	sjmp	00134$
      00735B 80 18            [24] 1350 	sjmp	00135$
      00735D                       1351 00132$:
      00735D 8F 82            [24] 1352 	mov	dpl, r7
      00735F 12 76 E4         [24] 1353 	lcall	_default_layer_and
      007362 02 74 47         [24] 1354 	ljmp	00181$
                                   1355 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007365                       1356 00133$:
      007365 8F 82            [24] 1357 	mov	dpl, r7
      007367 12 76 D3         [24] 1358 	lcall	_default_layer_or
      00736A 02 74 47         [24] 1359 	ljmp	00181$
                                   1360 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      00736D                       1361 00134$:
      00736D 8F 82            [24] 1362 	mov	dpl, r7
      00736F 12 76 FA         [24] 1363 	lcall	_default_layer_xor
      007372 02 74 47         [24] 1364 	ljmp	00181$
                                   1365 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007375                       1366 00135$:
      007375 8F 82            [24] 1367 	mov	dpl, r7
      007377 12 76 C8         [24] 1368 	lcall	_default_layer_set
                                   1369 ;	quantum/action.c:655: }
      00737A 02 74 47         [24] 1370 	ljmp	00181$
      00737D                       1371 00143$:
                                   1372 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      00737D 12 76 5F         [24] 1373 	lcall	_ak820_outline_0088
      007380 FE               [12] 1374 	mov	r6,a
      007381 2E               [12] 1375 	add	a,r6
                                   1376 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      007382 90 73 86         [24] 1377 	mov	dptr,#00466$
      007385 73               [24] 1378 	jmp	@a+dptr
      007386                       1379 00466$:
      007386 80 06            [24] 1380 	sjmp	00137$
      007388 80 0C            [24] 1381 	sjmp	00138$
      00738A 80 12            [24] 1382 	sjmp	00139$
      00738C 80 18            [24] 1383 	sjmp	00140$
      00738E                       1384 00137$:
      00738E 8F 82            [24] 1385 	mov	dpl, r7
      007390 12 78 7E         [24] 1386 	lcall	_layer_and
      007393 02 74 47         [24] 1387 	ljmp	00181$
                                   1388 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007396                       1389 00138$:
      007396 8F 82            [24] 1390 	mov	dpl, r7
      007398 12 78 6D         [24] 1391 	lcall	_layer_or
      00739B 02 74 47         [24] 1392 	ljmp	00181$
                                   1393 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      00739E                       1394 00139$:
      00739E 8F 82            [24] 1395 	mov	dpl, r7
      0073A0 12 78 94         [24] 1396 	lcall	_layer_xor
      0073A3 02 74 47         [24] 1397 	ljmp	00181$
                                   1398 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      0073A6                       1399 00140$:
      0073A6 8F 82            [24] 1400 	mov	dpl, r7
      0073A8 12 78 0A         [24] 1401 	lcall	_layer_state_set
                                   1402 ;	quantum/action.c:665: break;
      0073AB 02 74 47         [24] 1403 	ljmp	00181$
                                   1404 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      0073AE                       1405 00147$:
                                   1406 ;	quantum/action.c:668: if (pressed) {
      0073AE E5 18            [12] 1407 	mov	a,_process_action_sloc0_1_0
      0073B0 60 11            [24] 1408 	jz	00149$
                                   1409 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      0073B2 12 76 68         [24] 1410 	lcall	_ak820_outline_0112
      0073B5 F5 82            [12] 1411 	mov	dpl,a
      0073B7 12 77 6A         [24] 1412 	lcall	_layer_hold_on
                                   1413 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      0073BA 12 76 58         [24] 1414 	lcall	_ak820_outline_0077
      0073BD 12 75 81         [24] 1415 	lcall	_register_mods
      0073C0 02 74 47         [24] 1416 	ljmp	00181$
      0073C3                       1417 00149$:
                                   1418 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      0073C3 12 76 58         [24] 1419 	lcall	_ak820_outline_0077
      0073C6 12 75 95         [24] 1420 	lcall	_unregister_mods
                                   1421 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      0073C9 12 76 68         [24] 1422 	lcall	_ak820_outline_0112
      0073CC F5 82            [12] 1423 	mov	dpl,a
      0073CE 12 77 A2         [24] 1424 	lcall	_layer_hold_off
                                   1425 ;	quantum/action.c:675: break;
      0073D1 02 74 47         [24] 1426 	ljmp	00181$
                                   1427 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      0073D4                       1428 00152$:
                                   1429 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      0073D4 12 76 84         [24] 1430 	lcall	_ak820_outline_0159
      0073D7 FF               [12] 1431 	mov	r7,a
      0073D8 BF F1 02         [24] 1432 	cjne	r7,#0xf1,00468$
      0073DB 80 0A            [24] 1433 	sjmp	00154$
      0073DD                       1434 00468$:
      0073DD BF F2 02         [24] 1435 	cjne	r7,#0xf2,00469$
      0073E0 80 19            [24] 1436 	sjmp	00155$
      0073E2                       1437 00469$:
                                   1438 ;	quantum/action.c:694: momentary_layer_action:
      0073E2 BF F3 3B         [24] 1439 	cjne	r7,#0xf3,00160$
      0073E5 80 28            [24] 1440 	sjmp	00156$
      0073E7                       1441 00154$:
                                   1442 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0073E7 E5 18            [12] 1443 	mov	a,_process_action_sloc0_1_0
      0073E9 60 08            [24] 1444 	jz	00206$
      0073EB 12 76 3E         [24] 1445 	lcall	_ak820_outline_0042
      0073EE 12 77 6A         [24] 1446 	lcall	_layer_hold_on
      0073F1 80 54            [24] 1447 	sjmp	00181$
      0073F3                       1448 00206$:
      0073F3 12 76 3E         [24] 1449 	lcall	_ak820_outline_0042
      0073F6 12 77 A2         [24] 1450 	lcall	_layer_hold_off
                                   1451 ;	quantum/action.c:696: break;
                                   1452 ;	quantum/action.c:697: case OP_OFF_ON:
      0073F9 80 4C            [24] 1453 	sjmp	00181$
      0073FB                       1454 00155$:
                                   1455 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0073FB E5 18            [12] 1456 	mov	a,_process_action_sloc0_1_0
      0073FD 60 08            [24] 1457 	jz	00208$
      0073FF 12 76 3E         [24] 1458 	lcall	_ak820_outline_0042
      007402 12 78 4F         [24] 1459 	lcall	_layer_off
      007405 80 40            [24] 1460 	sjmp	00181$
      007407                       1461 00208$:
      007407 12 76 3E         [24] 1462 	lcall	_ak820_outline_0042
      00740A 12 78 34         [24] 1463 	lcall	_layer_on
                                   1464 ;	quantum/action.c:699: break;
                                   1465 ;	quantum/action.c:700: case OP_SET_CLEAR:
      00740D 80 38            [24] 1466 	sjmp	00181$
      00740F                       1467 00156$:
                                   1468 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00740F E5 18            [12] 1469 	mov	a,_process_action_sloc0_1_0
      007411 60 08            [24] 1470 	jz	00210$
      007413 12 76 3E         [24] 1471 	lcall	_ak820_outline_0042
      007416 12 78 1E         [24] 1472 	lcall	_layer_move
      007419 80 2C            [24] 1473 	sjmp	00181$
      00741B                       1474 00210$:
      00741B 12 78 18         [24] 1475 	lcall	_layer_clear
                                   1476 ;	quantum/action.c:702: break;
                                   1477 ;	quantum/action.c:748: default:
      00741E 80 27            [24] 1478 	sjmp	00181$
      007420                       1479 00160$:
                                   1480 ;	quantum/action.c:755: if (pressed) {
      007420 E5 18            [12] 1481 	mov	a,_process_action_sloc0_1_0
      007422 60 08            [24] 1482 	jz	00163$
                                   1483 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007424 12 76 58         [24] 1484 	lcall	_ak820_outline_0077
      007427 12 74 5E         [24] 1485 	lcall	_register_code
                                   1486 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00742A 80 1B            [24] 1487 	sjmp	00181$
      00742C                       1488 00163$:
                                   1489 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      00742C 12 76 84         [24] 1490 	lcall	_ak820_outline_0159
      00742F FF               [12] 1491 	mov	r7,a
      007430 BF 39 0E         [24] 1492 	cjne	r7,#0x39,00175$
                                   1493 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007433 7F 50            [12] 1494 	mov	r7,#0x50
      007435                       1495 00187$:
      007435 EF               [12] 1496 	mov	a,r7
      007436 60 09            [24] 1497 	jz	00175$
      007438 90 00 01         [24] 1498 	mov	dptr,#0x0001
      00743B 12 58 44         [24] 1499 	lcall	_mDelaymS
      00743E 1F               [12] 1500 	dec	r7
                                   1501 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      00743F 80 F4            [24] 1502 	sjmp	00187$
      007441                       1503 00175$:
                                   1504 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      007441 12 76 58         [24] 1505 	lcall	_ak820_outline_0077
      007444 12 74 CB         [24] 1506 	lcall	_unregister_code
                                   1507 ;	quantum/action.c:848: }
      007447                       1508 00181$:
                                   1509 ;	quantum/action.c:869: switch (action.kind.id) {
      007447 90 08 2D         [24] 1510 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00744A E0               [24] 1511 	movx	a,@dptr
      00744B C4               [12] 1512 	swap	a
      00744C 54 0F            [12] 1513 	anl	a,#0x0f
      00744E FF               [12] 1514 	mov	r7,a
      00744F BF 08 02         [24] 1515 	cjne	r7,#0x08,00478$
      007452 80 03            [24] 1516 	sjmp	00183$
      007454                       1517 00478$:
      007454 BF 09 06         [24] 1518 	cjne	r7,#0x09,00192$
                                   1519 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007457                       1520 00183$:
                                   1521 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007457 12 6B CF         [24] 1522 	lcall	_host_keyboard_leds
                                   1523 ;	quantum/action.c:880: }
                                   1524 ;	quantum/action.c:933: }
      00745A 02 96 6E         [24] 1525 	ljmp	_led_set
      00745D                       1526 00192$:
      00745D 22               [24] 1527 	ret
                                   1528 ;------------------------------------------------------------
                                   1529 ;Allocation info for local variables in function 'register_code'
                                   1530 ;------------------------------------------------------------
                                   1531 ;code          Allocated with name '_register_code_code_10000_709'
                                   1532 ;------------------------------------------------------------
                                   1533 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1534 ;	-----------------------------------------
                                   1535 ;	 function register_code
                                   1536 ;	-----------------------------------------
      00745E                       1537 _register_code:
      00745E E5 82            [12] 1538 	mov	a,dpl
      007460 90 08 32         [24] 1539 	mov	dptr,#_register_code_code_10000_709
      007463 F0               [24] 1540 	movx	@dptr,a
                                   1541 ;	quantum/action.c:940: if (code == KC_NO) {
      007464 E0               [24] 1542 	movx	a,@dptr
      007465 FF               [12] 1543 	mov	r7,a
      007466 70 01            [24] 1544 	jnz	00123$
                                   1545 ;	quantum/action.c:941: return;
      007468 22               [24] 1546 	ret
      007469                       1547 00123$:
                                   1548 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007469 BF 04 00         [24] 1549 	cjne	r7,#0x04,00186$
      00746C                       1550 00186$:
      00746C 40 12            [24] 1551 	jc	00119$
      00746E EF               [12] 1552 	mov	a,r7
      00746F 24 5B            [12] 1553 	add	a,#0xff - 0xa4
      007471 40 0D            [24] 1554 	jc	00119$
                                   1555 ;	free result
                                   1556 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007473 8F 82            [24] 1557 	mov	dpl, r7
      007475 12 7C 94         [24] 1558 	lcall	_add_owned_key
      007478 E5 82            [12] 1559 	mov	a, dpl
      00747A 70 01            [24] 1560 	jnz	00104$
      00747C 22               [24] 1561 	ret
      00747D                       1562 00104$:
                                   1563 ;	quantum/action.c:995: send_keyboard_report();
      00747D 02 7F 2A         [24] 1564 	ljmp	_send_keyboard_report
      007480                       1565 00119$:
                                   1566 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      007480 12 76 89         [24] 1567 	lcall	_ak820_outline_0167
      007483 BF E0 00         [24] 1568 	cjne	r7,#0xe0,00190$
      007486                       1569 00190$:
      007486 40 1A            [24] 1570 	jc	00115$
      007488 EF               [12] 1571 	mov	a,r7
      007489 24 18            [12] 1572 	add	a,#0xff - 0xe7
      00748B 40 15            [24] 1573 	jc	00115$
                                   1574 ;	free result
                                   1575 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      00748D 74 07            [12] 1576 	mov	a,#0x07
      00748F 5F               [12] 1577 	anl	a,r7
      007490 12 76 47         [24] 1578 	lcall	_ak820_outline_0061
      007493 80 02            [24] 1579 	sjmp	00194$
      007495                       1580 00193$:
      007495 25 E0            [12] 1581 	add	a,acc
      007497                       1582 00194$:
      007497 D5 F0 FB         [24] 1583 	djnz	b,00193$
      00749A F5 82            [12] 1584 	mov	dpl,a
      00749C 12 7B F0         [24] 1585 	lcall	_add_owned_mods
                                   1586 ;	quantum/action.c:998: send_keyboard_report();
      00749F 02 7F 2A         [24] 1587 	ljmp	_send_keyboard_report
      0074A2                       1588 00115$:
                                   1589 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0074A2 12 76 89         [24] 1590 	lcall	_ak820_outline_0167
      0074A5 BF A5 00         [24] 1591 	cjne	r7,#0xa5,00195$
      0074A8                       1592 00195$:
      0074A8 40 05            [24] 1593 	jc	00113$
      0074AA EF               [12] 1594 	mov	a,r7
      0074AB 24 58            [12] 1595 	add	a,#0xff - 0xa7
      0074AD 50 0D            [24] 1596 	jnc	00108$
                                   1597 ;	free result
      0074AF                       1598 00113$:
      0074AF 12 76 89         [24] 1599 	lcall	_ak820_outline_0167
      0074B2 BF A8 00         [24] 1600 	cjne	r7,#0xa8,00198$
      0074B5                       1601 00198$:
      0074B5 40 13            [24] 1602 	jc	00125$
      0074B7 EF               [12] 1603 	mov	a,r7
      0074B8 24 3D            [12] 1604 	add	a,#0xff - 0xc2
      0074BA 40 0E            [24] 1605 	jc	00125$
                                   1606 ;	free result
      0074BC                       1607 00108$:
                                   1608 ;	quantum/action.c:1003: owned_usage_key(code, true);
      0074BC 12 76 89         [24] 1609 	lcall	_ak820_outline_0167
      0074BF 90 0A 8D         [24] 1610 	mov	dptr,#_owned_usage_key_PARM_2
      0074C2 74 01            [12] 1611 	mov	a,#0x01
      0074C4 F0               [24] 1612 	movx	@dptr,a
      0074C5 8F 82            [24] 1613 	mov	dpl, r7
                                   1614 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1615 ;	quantum/action.c:1013: }
      0074C7 02 7D D5         [24] 1616 	ljmp	_owned_usage_key
      0074CA                       1617 00125$:
      0074CA 22               [24] 1618 	ret
                                   1619 ;------------------------------------------------------------
                                   1620 ;Allocation info for local variables in function 'unregister_code'
                                   1621 ;------------------------------------------------------------
                                   1622 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1623 ;------------------------------------------------------------
                                   1624 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1625 ;	-----------------------------------------
                                   1626 ;	 function unregister_code
                                   1627 ;	-----------------------------------------
      0074CB                       1628 _unregister_code:
      0074CB E5 82            [12] 1629 	mov	a,dpl
      0074CD 90 08 33         [24] 1630 	mov	dptr,#_unregister_code_code_10000_723
      0074D0 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	quantum/action.c:1020: if (code == KC_NO) {
      0074D1 E0               [24] 1633 	movx	a,@dptr
      0074D2 FF               [12] 1634 	mov	r7,a
      0074D3 70 01            [24] 1635 	jnz	00121$
                                   1636 ;	quantum/action.c:1021: return;
      0074D5 22               [24] 1637 	ret
      0074D6                       1638 00121$:
                                   1639 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      0074D6 BF 04 00         [24] 1640 	cjne	r7,#0x04,00184$
      0074D9                       1641 00184$:
      0074D9 40 12            [24] 1642 	jc	00117$
      0074DB EF               [12] 1643 	mov	a,r7
      0074DC 24 5B            [12] 1644 	add	a,#0xff - 0xa4
      0074DE 40 0D            [24] 1645 	jc	00117$
                                   1646 ;	free result
                                   1647 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      0074E0 8F 82            [24] 1648 	mov	dpl, r7
      0074E2 12 7D 0E         [24] 1649 	lcall	_del_owned_key
      0074E5 E5 82            [12] 1650 	mov	a, dpl
      0074E7 70 01            [24] 1651 	jnz	00102$
      0074E9 22               [24] 1652 	ret
      0074EA                       1653 00102$:
                                   1654 ;	quantum/action.c:1062: send_keyboard_report();
      0074EA 02 7F 2A         [24] 1655 	ljmp	_send_keyboard_report
      0074ED                       1656 00117$:
                                   1657 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      0074ED 12 76 8F         [24] 1658 	lcall	_ak820_outline_0168
      0074F0 BF E0 00         [24] 1659 	cjne	r7,#0xe0,00188$
      0074F3                       1660 00188$:
      0074F3 40 1A            [24] 1661 	jc	00113$
      0074F5 EF               [12] 1662 	mov	a,r7
      0074F6 24 18            [12] 1663 	add	a,#0xff - 0xe7
      0074F8 40 15            [24] 1664 	jc	00113$
                                   1665 ;	free result
                                   1666 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0074FA 74 07            [12] 1667 	mov	a,#0x07
      0074FC 5F               [12] 1668 	anl	a,r7
      0074FD 12 76 47         [24] 1669 	lcall	_ak820_outline_0061
      007500 80 02            [24] 1670 	sjmp	00192$
      007502                       1671 00191$:
      007502 25 E0            [12] 1672 	add	a,acc
      007504                       1673 00192$:
      007504 D5 F0 FB         [24] 1674 	djnz	b,00191$
      007507 F5 82            [12] 1675 	mov	dpl,a
      007509 12 7C 00         [24] 1676 	lcall	_del_owned_mods
                                   1677 ;	quantum/action.c:1065: send_keyboard_report();
      00750C 02 7F 2A         [24] 1678 	ljmp	_send_keyboard_report
      00750F                       1679 00113$:
                                   1680 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00750F 12 76 8F         [24] 1681 	lcall	_ak820_outline_0168
      007512 BF A5 00         [24] 1682 	cjne	r7,#0xa5,00193$
      007515                       1683 00193$:
      007515 40 05            [24] 1684 	jc	00111$
      007517 EF               [12] 1685 	mov	a,r7
      007518 24 58            [12] 1686 	add	a,#0xff - 0xa7
      00751A 50 0D            [24] 1687 	jnc	00106$
                                   1688 ;	free result
      00751C                       1689 00111$:
      00751C 12 76 8F         [24] 1690 	lcall	_ak820_outline_0168
      00751F BF A8 00         [24] 1691 	cjne	r7,#0xa8,00196$
      007522                       1692 00196$:
      007522 40 12            [24] 1693 	jc	00123$
      007524 EF               [12] 1694 	mov	a,r7
      007525 24 3D            [12] 1695 	add	a,#0xff - 0xc2
      007527 40 0D            [24] 1696 	jc	00123$
                                   1697 ;	free result
      007529                       1698 00106$:
                                   1699 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007529 12 76 8F         [24] 1700 	lcall	_ak820_outline_0168
      00752C 90 0A 8D         [24] 1701 	mov	dptr,#_owned_usage_key_PARM_2
      00752F E4               [12] 1702 	clr	a
      007530 F0               [24] 1703 	movx	@dptr,a
      007531 8F 82            [24] 1704 	mov	dpl, r7
                                   1705 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1706 ;	quantum/action.c:1080: }
      007533 02 7D D5         [24] 1707 	ljmp	_owned_usage_key
      007536                       1708 00123$:
      007536 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'tap_code_delay'
                                   1712 ;------------------------------------------------------------
                                   1713 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1714 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1715 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1716 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function tap_code_delay
                                   1721 ;	-----------------------------------------
      007537                       1722 _tap_code_delay:
      007537 E5 82            [12] 1723 	mov	a,dpl
      007539 90 08 36         [24] 1724 	mov	dptr,#_tap_code_delay_code_10000_736
      00753C F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action.c:1088: register_code(code);
      00753D E0               [24] 1727 	movx	a,@dptr
      00753E FF               [12] 1728 	mov	r7,a
      00753F F5 82            [12] 1729 	mov	dpl,a
      007541 C0 07            [24] 1730 	push	ar7
      007543 12 74 5E         [24] 1731 	lcall	_register_code
      007546 D0 07            [24] 1732 	pop	ar7
                                   1733 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007548 90 08 34         [24] 1734 	mov	dptr,#_tap_code_delay_PARM_2
      00754B 12 38 64         [24] 1735 	lcall	_ak820_outline_0078
      00754E                       1736 00110$:
      00754E ED               [12] 1737 	mov	a,r5
      00754F 4E               [12] 1738 	orl	a,r6
      007550 60 0D            [24] 1739 	jz	00105$
                                   1740 ;	quantum/action.c:1090: wait_ms(1);
      007552 90 00 01         [24] 1741 	mov	dptr,#0x0001
      007555 12 58 44         [24] 1742 	lcall	_mDelaymS
                                   1743 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007558 1D               [12] 1744 	dec	r5
      007559 BD FF 01         [24] 1745 	cjne	r5,#0xff,00141$
      00755C 1E               [12] 1746 	dec	r6
      00755D                       1747 00141$:
      00755D 80 EF            [24] 1748 	sjmp	00110$
      00755F                       1749 00105$:
                                   1750 ;	quantum/action.c:1092: unregister_code(code);
      00755F 8F 82            [24] 1751 	mov	dpl, r7
                                   1752 ;	quantum/action.c:1093: }
      007561 02 74 CB         [24] 1753 	ljmp	_unregister_code
                                   1754 ;------------------------------------------------------------
                                   1755 ;Allocation info for local variables in function 'tap_code'
                                   1756 ;------------------------------------------------------------
                                   1757 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1758 ;------------------------------------------------------------
                                   1759 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1760 ;	-----------------------------------------
                                   1761 ;	 function tap_code
                                   1762 ;	-----------------------------------------
      007564                       1763 _tap_code:
      007564 E5 82            [12] 1764 	mov	a,dpl
      007566 90 08 37         [24] 1765 	mov	dptr,#_tap_code_code_10000_743
      007569 F0               [24] 1766 	movx	@dptr,a
                                   1767 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      00756A E0               [24] 1768 	movx	a,@dptr
      00756B FF               [12] 1769 	mov	r7,a
      00756C BF 39 04         [24] 1770 	cjne	r7,#0x39,00103$
      00756F 7E 50            [12] 1771 	mov	r6,#0x50
      007571 80 02            [24] 1772 	sjmp	00104$
      007573                       1773 00103$:
      007573 7E 00            [12] 1774 	mov	r6,#0x00
      007575                       1775 00104$:
      007575 90 08 34         [24] 1776 	mov	dptr,#_tap_code_delay_PARM_2
      007578 EE               [12] 1777 	mov	a,r6
      007579 12 38 9C         [24] 1778 	lcall	_ak820_outline_0134
      00757C 8F 82            [24] 1779 	mov	dpl, r7
                                   1780 ;	quantum/action.c:1101: }
      00757E 02 75 37         [24] 1781 	ljmp	_tap_code_delay
                                   1782 ;------------------------------------------------------------
                                   1783 ;Allocation info for local variables in function 'register_mods'
                                   1784 ;------------------------------------------------------------
                                   1785 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function register_mods
                                   1790 ;	-----------------------------------------
      007581                       1791 _register_mods:
      007581 E5 82            [12] 1792 	mov	a,dpl
      007583 90 08 38         [24] 1793 	mov	dptr,#_register_mods_mods_10000_745
      007586 F0               [24] 1794 	movx	@dptr,a
                                   1795 ;	quantum/action.c:1108: if (mods) {
      007587 E0               [24] 1796 	movx	a,@dptr
      007588 FF               [12] 1797 	mov	r7,a
      007589 E0               [24] 1798 	movx	a,@dptr
      00758A 60 08            [24] 1799 	jz	00103$
                                   1800 ;	quantum/action.c:1109: add_owned_mods(mods);
      00758C 8F 82            [24] 1801 	mov	dpl, r7
      00758E 12 7B F0         [24] 1802 	lcall	_add_owned_mods
                                   1803 ;	quantum/action.c:1110: send_keyboard_report();
                                   1804 ;	quantum/action.c:1112: }
      007591 02 7F 2A         [24] 1805 	ljmp	_send_keyboard_report
      007594                       1806 00103$:
      007594 22               [24] 1807 	ret
                                   1808 ;------------------------------------------------------------
                                   1809 ;Allocation info for local variables in function 'unregister_mods'
                                   1810 ;------------------------------------------------------------
                                   1811 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function unregister_mods
                                   1816 ;	-----------------------------------------
      007595                       1817 _unregister_mods:
      007595 E5 82            [12] 1818 	mov	a,dpl
      007597 90 08 39         [24] 1819 	mov	dptr,#_unregister_mods_mods_10000_749
      00759A F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	quantum/action.c:1119: if (mods) {
      00759B E0               [24] 1822 	movx	a,@dptr
      00759C FF               [12] 1823 	mov	r7,a
      00759D E0               [24] 1824 	movx	a,@dptr
      00759E 60 08            [24] 1825 	jz	00103$
                                   1826 ;	quantum/action.c:1120: del_owned_mods(mods);
      0075A0 8F 82            [24] 1827 	mov	dpl, r7
      0075A2 12 7C 00         [24] 1828 	lcall	_del_owned_mods
                                   1829 ;	quantum/action.c:1121: send_keyboard_report();
                                   1830 ;	quantum/action.c:1123: }
      0075A5 02 7F 2A         [24] 1831 	ljmp	_send_keyboard_report
      0075A8                       1832 00103$:
      0075A8 22               [24] 1833 	ret
                                   1834 ;------------------------------------------------------------
                                   1835 ;Allocation info for local variables in function 'register_weak_mods'
                                   1836 ;------------------------------------------------------------
                                   1837 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1838 ;------------------------------------------------------------
                                   1839 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1840 ;	-----------------------------------------
                                   1841 ;	 function register_weak_mods
                                   1842 ;	-----------------------------------------
      0075A9                       1843 _register_weak_mods:
      0075A9 E5 82            [12] 1844 	mov	a,dpl
      0075AB 90 08 3A         [24] 1845 	mov	dptr,#_register_weak_mods_mods_10000_753
      0075AE F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/action.c:1130: if (mods) {
      0075AF E0               [24] 1848 	movx	a,@dptr
      0075B0 FF               [12] 1849 	mov	r7,a
      0075B1 E0               [24] 1850 	movx	a,@dptr
      0075B2 60 08            [24] 1851 	jz	00103$
                                   1852 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      0075B4 8F 82            [24] 1853 	mov	dpl, r7
      0075B6 12 7C 0F         [24] 1854 	lcall	_add_owned_weak_mods
                                   1855 ;	quantum/action.c:1132: send_keyboard_report();
                                   1856 ;	quantum/action.c:1134: }
      0075B9 02 7F 2A         [24] 1857 	ljmp	_send_keyboard_report
      0075BC                       1858 00103$:
      0075BC 22               [24] 1859 	ret
                                   1860 ;------------------------------------------------------------
                                   1861 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1862 ;------------------------------------------------------------
                                   1863 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function unregister_weak_mods
                                   1868 ;	-----------------------------------------
      0075BD                       1869 _unregister_weak_mods:
      0075BD E5 82            [12] 1870 	mov	a,dpl
      0075BF 90 08 3B         [24] 1871 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      0075C2 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	quantum/action.c:1141: if (mods) {
      0075C3 E0               [24] 1874 	movx	a,@dptr
      0075C4 FF               [12] 1875 	mov	r7,a
      0075C5 E0               [24] 1876 	movx	a,@dptr
      0075C6 60 08            [24] 1877 	jz	00103$
                                   1878 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      0075C8 8F 82            [24] 1879 	mov	dpl, r7
      0075CA 12 7C 1F         [24] 1880 	lcall	_del_owned_weak_mods
                                   1881 ;	quantum/action.c:1143: send_keyboard_report();
                                   1882 ;	quantum/action.c:1145: }
      0075CD 02 7F 2A         [24] 1883 	ljmp	_send_keyboard_report
      0075D0                       1884 00103$:
      0075D0 22               [24] 1885 	ret
                                   1886 ;------------------------------------------------------------
                                   1887 ;Allocation info for local variables in function 'clear_keyboard'
                                   1888 ;------------------------------------------------------------
                                   1889 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1890 ;	-----------------------------------------
                                   1891 ;	 function clear_keyboard
                                   1892 ;	-----------------------------------------
      0075D1                       1893 _clear_keyboard:
                                   1894 ;	quantum/action.c:1152: clear_mods();
      0075D1 12 7F A5         [24] 1895 	lcall	_clear_mods
                                   1896 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1897 ;	quantum/action.c:1154: }
      0075D4 02 75 D7         [24] 1898 	ljmp	_clear_keyboard_but_mods
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1903 ;	-----------------------------------------
                                   1904 ;	 function clear_keyboard_but_mods
                                   1905 ;	-----------------------------------------
      0075D7                       1906 _clear_keyboard_but_mods:
                                   1907 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0075D7 90 0D BA         [24] 1908 	mov	dptr,#_actual_keyboard_report
      0075DA 12 6E 94         [24] 1909 	lcall	_clear_keys_from_report
                                   1910 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1911 ;	quantum/action.c:1163: }
      0075DD 02 75 E0         [24] 1912 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1913 ;------------------------------------------------------------
                                   1914 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1915 ;------------------------------------------------------------
                                   1916 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1917 ;	-----------------------------------------
                                   1918 ;	 function clear_keyboard_but_mods_and_keys
                                   1919 ;	-----------------------------------------
      0075E0                       1920 _clear_keyboard_but_mods_and_keys:
                                   1921 ;	quantum/action.c:1171: ak820_tapping_cancel();
      0075E0 12 46 60         [24] 1922 	lcall	_ak820_tapping_cancel
                                   1923 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      0075E3 12 2E F0         [24] 1924 	lcall	_ak820_oneshot_cancel
                                   1925 ;	quantum/action.c:1185: ak820_combo_cancel();
      0075E6 12 35 70         [24] 1926 	lcall	_ak820_combo_cancel
                                   1927 ;	quantum/action.c:1188: repeat_key_cancel();
      0075E9 12 9F D9         [24] 1928 	lcall	_repeat_key_cancel
                                   1929 ;	quantum/action.c:1190: clear_owned_mods();
      0075EC 12 7C 2F         [24] 1930 	lcall	_clear_owned_mods
                                   1931 ;	quantum/action.c:1191: clear_owned_keys();
      0075EF 12 7C 67         [24] 1932 	lcall	_clear_owned_keys
                                   1933 ;	quantum/action.c:1192: clear_owned_usages();
      0075F2 12 7D 9D         [24] 1934 	lcall	_clear_owned_usages
                                   1935 ;	quantum/action.c:1193: layer_hold_clear();
      0075F5 12 77 DB         [24] 1936 	lcall	_layer_hold_clear
                                   1937 ;	quantum/action.c:1195: clear_macro_tri_layer();
      0075F8 12 9B 24         [24] 1938 	lcall	_clear_macro_tri_layer
                                   1939 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0075FB 90 0D BA         [24] 1940 	mov	dptr,#_actual_keyboard_report
      0075FE 12 6E 94         [24] 1941 	lcall	_clear_keys_from_report
                                   1942 ;	quantum/action.c:1200: host_system_send(0);
      007601 90 00 00         [24] 1943 	mov	dptr,#0x0000
      007604 12 6C 6A         [24] 1944 	lcall	_host_system_send
                                   1945 ;	quantum/action.c:1201: host_consumer_send(0);
      007607 90 00 00         [24] 1946 	mov	dptr,#0x0000
      00760A 12 6C 9A         [24] 1947 	lcall	_host_consumer_send
                                   1948 ;	quantum/action.c:1203: clear_weak_mods();
      00760D 12 7F DA         [24] 1949 	lcall	_clear_weak_mods
                                   1950 ;	quantum/action.c:1204: send_keyboard_report();
                                   1951 ;	quantum/action.c:1212: }
      007610 02 7F 2A         [24] 1952 	ljmp	_send_keyboard_report
                                   1953 ;------------------------------------------------------------
                                   1954 ;Allocation info for local variables in function 'is_tap_record'
                                   1955 ;------------------------------------------------------------
                                   1956 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1957 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1960 ;	-----------------------------------------
                                   1961 	.area CSEG    (CODE)
                                   1962 	.area CONST   (CODE)
                                   1963 	.area XINIT   (CODE)
      00BF5E                       1964 __xinit__disable_action_cache:
      00BF5E 00                    1965 	.db #0x00	;  0
                                   1966 	.area CABS    (ABS,CODE)
                                   1967 
                                   1968 ; Experimental exact instruction outlining.
                                   1969 	.globl _ak820_outline_0001
                                   1970 	.globl _ak820_outline_0005
                                   1971 	.globl _ak820_outline_0007
                                   1972 	.globl _ak820_outline_0008
                                   1973 	.globl _ak820_outline_0010
                                   1974 	.globl _ak820_outline_0011
                                   1975 	.globl _ak820_outline_0012
                                   1976 	.globl _ak820_outline_0013
                                   1977 	.globl _ak820_outline_0016
                                   1978 	.globl _ak820_outline_0021
                                   1979 	.globl _ak820_outline_0023
                                   1980 	.globl _ak820_outline_0033
                                   1981 	.globl _ak820_outline_0037
                                   1982 	.globl _ak820_outline_0042
                                   1983 	.globl _ak820_outline_0057
                                   1984 	.globl _ak820_outline_0061
                                   1985 	.globl _ak820_outline_0064
                                   1986 	.globl _ak820_outline_0070
                                   1987 	.globl _ak820_outline_0071
                                   1988 	.globl _ak820_outline_0077
                                   1989 	.globl _ak820_outline_0078
                                   1990 	.globl _ak820_outline_0088
                                   1991 	.globl _ak820_outline_0092
                                   1992 	.globl _ak820_outline_0107
                                   1993 	.globl _ak820_outline_0108
                                   1994 	.globl _ak820_outline_0110
                                   1995 	.globl _ak820_outline_0112
                                   1996 	.globl _ak820_outline_0117
                                   1997 	.globl _ak820_outline_0123
                                   1998 	.globl _ak820_outline_0124
                                   1999 	.globl _ak820_outline_0130
                                   2000 	.globl _ak820_outline_0133
                                   2001 	.globl _ak820_outline_0134
                                   2002 	.globl _ak820_outline_0142
                                   2003 	.globl _ak820_outline_0144
                                   2004 	.globl _ak820_outline_0146
                                   2005 	.globl _ak820_outline_0150
                                   2006 	.globl _ak820_outline_0159
                                   2007 	.globl _ak820_outline_0167
                                   2008 	.globl _ak820_outline_0168
                                   2009 	.globl _ak820_outline_0183
                                   2010 	.globl _ak820_outline_0187
                                   2011 
                                   2012 	.area CSEG (CODE)
                                   2013 ; function ak820_outline_0012
      007613                       2014 _ak820_outline_0012:
      007613 2D               [12] 2015 	add	a,r5
      007614 F9               [12] 2016 	mov	r1,a
      007615 E4               [12] 2017 	clr	a
      007616 3E               [12] 2018 	addc	a,r6
      007617 FA               [12] 2019 	mov	r2,a
      007618 8F 03            [24] 2020 	mov	ar3,r7
      00761A 89 82            [24] 2021 	mov	dpl,r1
      00761C 8A 83            [24] 2022 	mov	dph,r2
      00761E 8B F0            [24] 2023 	mov	b,r3
      007620 22               [24] 2024 	ret
                                   2025 
                                   2026 	.area CSEG (CODE)
                                   2027 ; function ak820_outline_0013
      007621                       2028 _ak820_outline_0013:
      007621 2D               [12] 2029 	add	a,r5
      007622 FA               [12] 2030 	mov	r2,a
      007623 E4               [12] 2031 	clr	a
      007624 3E               [12] 2032 	addc	a,r6
      007625 FB               [12] 2033 	mov	r3,a
      007626 8F 04            [24] 2034 	mov	ar4,r7
      007628 8A 82            [24] 2035 	mov	dpl,r2
      00762A 8B 83            [24] 2036 	mov	dph,r3
      00762C 8C F0            [24] 2037 	mov	b,r4
      00762E 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0021
      00762F                       2042 _ak820_outline_0021:
      00762F 8E 82            [24] 2043 	mov	dpl,r6
      007631 8F 83            [24] 2044 	mov	dph,r7
      007633 A3               [24] 2045 	inc	dptr
      007634 E0               [24] 2046 	movx	a,@dptr
      007635 FC               [12] 2047 	mov	r4,a
      007636 7D 00            [12] 2048 	mov	r5,#0x00
      007638 8E 82            [24] 2049 	mov	dpl,r6
      00763A 8F 83            [24] 2050 	mov	dph,r7
      00763C E0               [24] 2051 	movx	a,@dptr
      00763D 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0042
      00763E                       2056 _ak820_outline_0042:
      00763E 90 08 2D         [24] 2057 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007641 E0               [24] 2058 	movx	a,@dptr
      007642 54 1F            [12] 2059 	anl	a,#0x1f
      007644 F5 82            [12] 2060 	mov	dpl,a
      007646 22               [24] 2061 	ret
                                   2062 
                                   2063 	.area CSEG (CODE)
                                   2064 ; function ak820_outline_0061
      007647                       2065 _ak820_outline_0061:
      007647 F5 F0            [12] 2066 	mov	b,a
      007649 05 F0            [12] 2067 	inc	b
      00764B 74 01            [12] 2068 	mov	a,#0x01
      00764D 22               [24] 2069 	ret
                                   2070 
                                   2071 	.area CSEG (CODE)
                                   2072 ; function ak820_outline_0070
      00764E                       2073 _ak820_outline_0070:
      00764E 90 0D 98         [24] 2074 	mov	dptr,#___memcpy_PARM_3
      007651 74 06            [12] 2075 	mov	a,#0x06
      007653 F0               [24] 2076 	movx	@dptr,a
      007654 E4               [12] 2077 	clr	a
      007655 A3               [24] 2078 	inc	dptr
      007656 F0               [24] 2079 	movx	@dptr,a
      007657 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0077
      007658                       2084 _ak820_outline_0077:
      007658 90 08 2C         [24] 2085 	mov	dptr,#_process_action_PARM_2
      00765B E0               [24] 2086 	movx	a,@dptr
      00765C F5 82            [12] 2087 	mov	dpl,a
      00765E 22               [24] 2088 	ret
                                   2089 
                                   2090 	.area CSEG (CODE)
                                   2091 ; function ak820_outline_0088
      00765F                       2092 _ak820_outline_0088:
      00765F 90 08 2D         [24] 2093 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007662 E0               [24] 2094 	movx	a,@dptr
      007663 03               [12] 2095 	rr	a
      007664 03               [12] 2096 	rr	a
      007665 54 03            [12] 2097 	anl	a,#0x03
      007667 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0112
      007668                       2102 _ak820_outline_0112:
      007668 90 08 2D         [24] 2103 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00766B E0               [24] 2104 	movx	a,@dptr
      00766C 54 0F            [12] 2105 	anl	a,#0x0f
      00766E 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0130
      00766F                       2110 _ak820_outline_0130:
      00766F 90 08 2C         [24] 2111 	mov	dptr,#_process_action_PARM_2
      007672 E0               [24] 2112 	movx	a,@dptr
      007673 FE               [12] 2113 	mov	r6,a
      007674 A3               [24] 2114 	inc	dptr
      007675 E0               [24] 2115 	movx	a,@dptr
      007676 54 03            [12] 2116 	anl	a,#0x03
      007678 FF               [12] 2117 	mov	r7,a
      007679 22               [24] 2118 	ret
                                   2119 
                                   2120 	.area CSEG (CODE)
                                   2121 ; function ak820_outline_0146
      00767A                       2122 _ak820_outline_0146:
      00767A 74 07            [12] 2123 	mov	a,#0x07
      00767C 2D               [12] 2124 	add	a,r5
      00767D F8               [12] 2125 	mov	r0,a
      00767E E4               [12] 2126 	clr	a
      00767F 3E               [12] 2127 	addc	a,r6
      007680 F9               [12] 2128 	mov	r1,a
      007681 8F 02            [24] 2129 	mov	ar2,r7
      007683 22               [24] 2130 	ret
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0159
      007684                       2134 _ak820_outline_0159:
      007684 90 08 2C         [24] 2135 	mov	dptr,#_process_action_PARM_2
      007687 E0               [24] 2136 	movx	a,@dptr
      007688 22               [24] 2137 	ret
                                   2138 
                                   2139 	.area CSEG (CODE)
                                   2140 ; function ak820_outline_0167
      007689                       2141 _ak820_outline_0167:
      007689 90 08 32         [24] 2142 	mov	dptr,#_register_code_code_10000_709
      00768C E0               [24] 2143 	movx	a,@dptr
      00768D FF               [12] 2144 	mov	r7,a
      00768E 22               [24] 2145 	ret
                                   2146 
                                   2147 	.area CSEG (CODE)
                                   2148 ; function ak820_outline_0168
      00768F                       2149 _ak820_outline_0168:
      00768F 90 08 33         [24] 2150 	mov	dptr,#_unregister_code_code_10000_723
      007692 E0               [24] 2151 	movx	a,@dptr
      007693 FF               [12] 2152 	mov	r7,a
      007694 22               [24] 2153 	ret
                                   2154 
                                   2155 	.area CSEG (CODE)
                                   2156 ; function ak820_outline_0187
      007695                       2157 _ak820_outline_0187:
      007695 F0               [24] 2158 	movx	@dptr,a
      007696 EB               [12] 2159 	mov	a,r3
      007697 A3               [24] 2160 	inc	dptr
      007698 F0               [24] 2161 	movx	@dptr,a
      007699 22               [24] 2162 	ret
