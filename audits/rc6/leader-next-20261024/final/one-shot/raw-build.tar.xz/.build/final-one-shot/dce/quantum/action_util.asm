;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module action_util
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _host_consumer_send
	.globl _host_system_send
	.globl _host_keyboard_send
	.globl _clear_keys_from_report
	.globl _del_key_from_report
	.globl _add_key_to_report
	.globl _KEYCODE2CONSUMER
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _actual_keyboard_report
	.globl _owned_usage_key_PARM_2
	.globl _ak820_macro_change_PARM_3
	.globl _ak820_macro_change_PARM_2
	.globl _ak820_macro_cancelled
	.globl _ak820_macro_primitive
	.globl _ak820_macro_change
	.globl _add_owned_mods
	.globl _del_owned_mods
	.globl _add_owned_weak_mods
	.globl _del_owned_weak_mods
	.globl _clear_owned_mods
	.globl _clear_owned_keys
	.globl _add_owned_key
	.globl _del_owned_key
	.globl _clear_owned_usages
	.globl _owned_usage_key
	.globl _send_keyboard_report
	.globl _get_mods
	.globl _clear_mods
	.globl _get_weak_mods
	.globl _add_weak_mods
	.globl _del_weak_mods
	.globl _clear_weak_mods
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_change_owned_sloc1_1_0:
	.ds 1
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_macro_change_sloc0_1_0:
	.ds 1
_change_owned_sloc0_1_0:
	.ds 1
_owned_usage_key_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_owned_mod_refs:
	.ds 8
_owned_weak_refs:
	.ds 8
_owned_mods:
	.ds 1
_owned_weak_mods:
	.ds 1
_macro_mods:
	.ds 2
_ak820_macro_primitive::
	.ds 1
_ak820_macro_cancelled::
	.ds 1
_ak820_macro_change_PARM_2:
	.ds 1
_ak820_macro_change_PARM_3:
	.ds 1
_ak820_macro_change_bits_10000_293:
	.ds 2
_change_owned_PARM_2:
	.ds 1
_change_owned_mods_10000_298:
	.ds 1
_change_owned_result_10001_302:
	.ds 1
_change_owned_bit_20001_303:
	.ds 1
_add_owned_mods_mods_10000_311:
	.ds 1
_del_owned_mods_mods_10000_313:
	.ds 1
_add_owned_weak_mods_mods_10000_315:
	.ds 1
_del_owned_weak_mods_mods_10000_317:
	.ds 1
_key_refs:
	.ds 165
_distinct_keys:
	.ds 1
_macro_keys:
	.ds 21
_add_owned_key_code_10000_326:
	.ds 1
_del_owned_key_code_10000_341:
	.ds 1
_usage_refs:
	.ds 30
_usage_order:
	.ds 30
_usage_lengths:
	.ds 2
_macro_usages:
	.ds 4
_owned_usage_key_PARM_2:
	.ds 1
_owned_usage_key_code_10000_368:
	.ds 1
_owned_usage_key___200000085_20000_369:
	.ds 2
_owned_usage_key_which_10000_369:
	.ds 1
_owned_usage_key_count_10000_369:
	.ds 1
_owned_usage_key_pos_30001_376:
	.ds 1
_owned_usage_key_key_40000_381:
	.ds 1
_send_keyboard_report_last_report_10001_388:
	.ds 32
_send_keyboard_report_changed_10001_388:
	.ds 1
_add_weak_mods_mods_10000_406:
	.ds 1
_del_weak_mods_mods_10000_408:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_real_mods:
	.ds 1
_weak_mods:
	.ds 1
_actual_keyboard_report::
	.ds 32
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_macro_change
;	-----------------------------------------
_ak820_macro_change:
	lcall	_ak820_outline_0108
	mov	dptr,#_ak820_macro_change_bits_10000_293
	lcall	_ak820_outline_0107
;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
	mov	dptr,#_ak820_macro_change_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	anl	a,r7
	lcall	_ak820_outline_0061
	sjmp	00123$
00122$:
	add	a,acc
00123$:
	djnz	b,00122$
	mov	r6,a
;	quantum/action_util.c:81: bits += index >> 3;
	mov	a,r7
	lcall	_ak820_outline_0188
	mov	r7,a
	mov	dptr,#_ak820_macro_change_bits_10000_293
	lcall	_ak820_outline_0059
	mov	dptr,#_ak820_macro_change_bits_10000_293
	mov	a,r7
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r5
	inc	dptr
	movx	@dptr,a
;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
	mov	dptr,#_ak820_macro_change_bits_10000_293
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	lcall	_ak820_outline_0189
	movx	a,@dptr
	mov	r4,a
	mov	a,r6
	anl	a,r4
	cjne	a,#0x01,00124$
00124$:
	cpl	c
	mov	_ak820_macro_change_sloc0_1_0,c
	mov	dptr,#_ak820_macro_change_PARM_3
	movx	a,@dptr
	mov	r3,a
	mov	c,_ak820_macro_change_sloc0_1_0
	clr	a
	rlc	a
	cjne	a,ar3,00104$
	mov	dpl, #0x00
	ret
00104$:
;	quantum/action_util.c:83: *bits ^= mask;
	mov	a,r4
	xrl	ar6,a
	lcall	_ak820_outline_0189
	mov	a,r6
	movx	@dptr,a
;	quantum/action_util.c:84: return true;
	mov	dpl, #0x01
;	quantum/action_util.c:85: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'change_owned'
;------------------------------------------------------------
;mode          Allocated with name '_change_owned_PARM_2'
;mods          Allocated with name '_change_owned_mods_10000_298'
;kind          Allocated with name '_change_owned_kind_10000_299'
;pressed       Allocated with name '_change_owned_pressed_10000_299'
;refs          Allocated with name '_change_owned_refs_10000_299'
;old           Allocated with name '_change_owned_old_30000_301'
;result        Allocated with name '_change_owned_result_10001_302'
;i             Allocated with name '_change_owned_i_20001_303'
;bit           Allocated with name '_change_owned_bit_20001_303'
;sloc1         Allocated with name '_change_owned_sloc1_1_0'
;------------------------------------------------------------
;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
;	-----------------------------------------
;	 function change_owned
;	-----------------------------------------
_change_owned:
	mov	a,dpl
	mov	dptr,#_change_owned_mods_10000_298
	movx	@dptr,a
;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
	mov	dptr,#_change_owned_PARM_2
	movx	a,@dptr
	mov	r7,a
	clr	c
	rrc	a
	mov	r6,a
;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
	anl	ar7,#0x01
	mov	a,r7
	cjne	a,#0x01,00205$
00205$:
	mov  _change_owned_sloc0_1_0,c
	cpl	c
	clr	a
	rlc	a
	mov	_change_owned_sloc1_1_0,a
;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
	mov	a,r6
	jz	00121$
	mov	r5,#_owned_weak_refs
	mov	r7,#(_owned_weak_refs >> 8)
	sjmp	00122$
00121$:
	mov	r5,#_owned_mod_refs
	mov	r7,#(_owned_mod_refs >> 8)
00122$:
;	quantum/action_util.c:90: if (ak820_macro_primitive) {
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jz	00102$
;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
	mov	a,r6
	add	a, #_macro_mods
	mov	r3,a
	clr	a
	addc	a, #(_macro_mods >> 8)
	lcall	_ak820_outline_0055
;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
	mov	a,_change_owned_sloc1_1_0
	jz	00123$
	mov	dptr,#_change_owned_mods_10000_298
	movx	a,@dptr
	mov	r1,a
	mov	a,r2
	orl	ar1,a
	sjmp	00124$
00123$:
	mov	dptr,#_change_owned_mods_10000_298
	movx	a,@dptr
	cpl	a
	anl	a,r2
	mov	r1,a
00124$:
	lcall	_ak820_outline_0123
	mov	a,r1
	movx	@dptr,a
;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
	mov	a,_change_owned_sloc1_1_0
	jz	00125$
	mov	a,#0xff
	xrl	a,r2
	mov	r4,a
	sjmp	00126$
00125$:
	mov	ar4,r2
00126$:
	mov	dptr,#_change_owned_mods_10000_298
	movx	a,@dptr
	anl	a,r4
	movx	@dptr,a
00102$:
;	quantum/action_util.c:95: uint8_t result = 0;
	mov	dptr,#_change_owned_result_10001_302
	clr	a
	movx	@dptr,a
;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
	mov	dptr,#_change_owned_bit_20001_303
	inc	a
	movx	@dptr,a
	mov	dptr,#_change_owned_mods_10000_298
	movx	a,@dptr
	mov	r4,a
	mov	r3,#0x00
00117$:
	cjne	r3,#0x08,00210$
00210$:
	jnc	00112$
;	quantum/action_util.c:97: if (mods & bit) {
	mov	dptr,#_change_owned_bit_20001_303
	movx	a,@dptr
	anl	a,r4
	jz	00109$
;	quantum/action_util.c:98: if (pressed) ++refs[i];
	mov	a,_change_owned_sloc1_1_0
	jz	00106$
	mov	a,r3
	add	a, r5
	lcall	_ak820_outline_0015
	mov	r0,a
	inc	r0
	lcall	_ak820_outline_0062
	sjmp	00109$
00106$:
;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
	mov	a,r3
	add	a, r5
	lcall	_ak820_outline_0015
	mov	r0,a
	jz	00109$
	dec	r0
	lcall	_ak820_outline_0062
00109$:
;	quantum/action_util.c:101: if (refs[i]) result |= bit;
	mov	a,r3
	add	a, r5
	lcall	_ak820_outline_0015
	jz	00118$
	mov	dptr,#_change_owned_bit_20001_303
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_change_owned_result_10001_302
	movx	a,@dptr
	orl	a,r2
	movx	@dptr,a
00118$:
;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
	inc	r3
	mov	dptr,#_change_owned_bit_20001_303
	movx	a,@dptr
	add	a,acc
	movx	@dptr,a
	sjmp	00117$
00112$:
;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
	mov	a,r6
	jz	00114$
	mov	dptr,#_change_owned_result_10001_302
	movx	a,@dptr
	mov	dptr,#_owned_weak_mods
	movx	@dptr,a
	ret
00114$:
;	quantum/action_util.c:104: else owned_mods = result;
	mov	dptr,#_change_owned_result_10001_302
	movx	a,@dptr
	mov	dptr,#_owned_mods
	movx	@dptr,a
;	quantum/action_util.c:105: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'add_owned_mods'
;------------------------------------------------------------
;mods          Allocated with name '_add_owned_mods_mods_10000_311'
;------------------------------------------------------------
;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
;	-----------------------------------------
;	 function add_owned_mods
;	-----------------------------------------
_add_owned_mods:
	mov	a,dpl
	mov	dptr,#_add_owned_mods_mods_10000_311
	lcall	_ak820_outline_0116
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_change_owned
;------------------------------------------------------------
;Allocation info for local variables in function 'del_owned_mods'
;------------------------------------------------------------
;mods          Allocated with name '_del_owned_mods_mods_10000_313'
;------------------------------------------------------------
;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
;	-----------------------------------------
;	 function del_owned_mods
;	-----------------------------------------
_del_owned_mods:
	mov	a,dpl
	mov	dptr,#_del_owned_mods_mods_10000_313
	lcall	_ak820_outline_0116
	clr	a
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_change_owned
;------------------------------------------------------------
;Allocation info for local variables in function 'add_owned_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
;------------------------------------------------------------
;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
;	-----------------------------------------
;	 function add_owned_weak_mods
;	-----------------------------------------
_add_owned_weak_mods:
	mov	a,dpl
	mov	dptr,#_add_owned_weak_mods_mods_10000_315
	lcall	_ak820_outline_0116
	mov	a,#0x03
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_change_owned
;------------------------------------------------------------
;Allocation info for local variables in function 'del_owned_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
;------------------------------------------------------------
;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
;	-----------------------------------------
;	 function del_owned_weak_mods
;	-----------------------------------------
_del_owned_weak_mods:
	mov	a,dpl
	mov	dptr,#_del_owned_weak_mods_mods_10000_317
	lcall	_ak820_outline_0116
	mov	a,#0x02
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_change_owned
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_owned_mods'
;------------------------------------------------------------
;i             Allocated with name '_clear_owned_mods_i_20000_321'
;------------------------------------------------------------
;	quantum/action_util.c:110: void clear_owned_mods(void) {
;	-----------------------------------------
;	 function clear_owned_mods
;	-----------------------------------------
_clear_owned_mods:
;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
	mov	r7,#0x00
00103$:
	cjne	r7,#0x08,00122$
00122$:
	jnc	00101$
	mov	a,r7
	add	a, #_owned_mod_refs
	mov	r5,a
	clr	a
	addc	a, #(_owned_mod_refs >> 8)
	mov	r6,a
	mov	a,r7
	add	a, #_owned_weak_refs
	mov	dpl,a
	clr	a
	addc	a, #(_owned_weak_refs >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	lcall	_ak820_outline_0121
	inc	r7
	sjmp	00103$
00101$:
;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
	mov	dptr,#(_macro_mods + 0x0001)
	clr	a
	movx	@dptr,a
	mov	dptr,#_macro_mods
	movx	@dptr,a
	mov	dptr,#_owned_weak_mods
	movx	@dptr,a
	mov	dptr,#_owned_mods
	movx	@dptr,a
;	quantum/action_util.c:113: ak820_macro_cancelled = true;
	mov	dptr,#_ak820_macro_cancelled
	inc	a
	movx	@dptr,a
;	quantum/action_util.c:114: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_owned_keys'
;------------------------------------------------------------
;i             Allocated with name '_clear_owned_keys_i_20000_324'
;i             Allocated with name '_clear_owned_keys_i_20000_325'
;------------------------------------------------------------
;	quantum/action_util.c:120: void clear_owned_keys(void) {
;	-----------------------------------------
;	 function clear_owned_keys
;	-----------------------------------------
_clear_owned_keys:
;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
	mov	r7,#0x00
00104$:
	mov	a,r7
	add	a,#0xff - 0xa4
	jc	00101$
;	free result
	mov	a,r7
	add	a, #_key_refs
	mov	dpl,a
	clr	a
	addc	a, #(_key_refs >> 8)
	lcall	_ak820_outline_0163
	sjmp	00104$
00101$:
;	quantum/action_util.c:122: distinct_keys = 0;
	mov	dptr,#_distinct_keys
	clr	a
	movx	@dptr,a
;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
	mov	r7,a
00107$:
	cjne	r7,#0x15,00142$
00142$:
	jnc	00109$
	mov	a,r7
	add	a, #_macro_keys
	mov	dpl,a
	clr	a
	addc	a, #(_macro_keys >> 8)
	lcall	_ak820_outline_0163
	sjmp	00107$
00109$:
;	quantum/action_util.c:124: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'add_owned_key'
;------------------------------------------------------------
;code          Allocated with name '_add_owned_key_code_10000_326'
;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
;key           Allocated with name '_add_owned_key_key_50000_336'
;i             Allocated with name '_add_owned_key_i_40000_334'
;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
;key           Allocated with name '_add_owned_key_key_40000_339'
;------------------------------------------------------------
;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
;	-----------------------------------------
;	 function add_owned_key
;	-----------------------------------------
_add_owned_key:
	mov	a,dpl
	mov	dptr,#_add_owned_key_code_10000_326
	lcall	_ak820_outline_0132
;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#_macro_keys
	push	ar7
	lcall	_ak820_macro_change
	mov	a, dpl
	pop	ar7
	jnz	00102$
	mov	dpl,a
	ret
00102$:
;	quantum/action_util.c:127: if (key_refs[code]++) return false;
	lcall	_ak820_outline_0030
	mov	r4,a
	inc	a
	lcall	_ak820_outline_0121
	mov	a,r4
	jz	00104$
	mov	dpl, #0x00
	ret
00104$:
;	quantum/action_util.c:128: ++distinct_keys;
	mov	dptr,#_distinct_keys
	movx	a,@dptr
	add	a, #0x01
	movx	@dptr,a
;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	jz	00106$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	jnb	acc.7,00106$
;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
	lcall	_ak820_outline_0176
	lcall	_add_key_to_report
;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
	mov	dpl, #0x01
	ret
00106$:
;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
	mov	dptr,#_distinct_keys
	movx	a,@dptr
	add	a,#0xff - 0x06
	jnc	00110$
;	free result
;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
	mov	r7,#0x00
00115$:
	cjne	r7,#0x06,00174$
00174$:
	jnc	00111$
	mov	a,r7
	add	a, #(_actual_keyboard_report + 0x0002)
	mov	dpl,a
	clr	a
	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
	mov	dph,a
	mov	a,#0x01
	movx	@dptr,a
	inc	r7
	sjmp	00115$
00110$:
;	quantum/action_util.c:134: } else add_key(code);
	mov	dptr,#_add_owned_key_code_10000_326
	movx	a,@dptr
;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
	mov	dptr,#_add_key_to_report_PARM_2
	movx	@dptr,a
	mov	dptr,#_actual_keyboard_report
	lcall	_add_key_to_report
;	quantum/action_util.c:134: } else add_key(code);
00111$:
;	quantum/action_util.c:135: return true;
	mov	dpl, #0x01
;	quantum/action_util.c:136: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'del_owned_key'
;------------------------------------------------------------
;code          Allocated with name '_del_owned_key_code_10000_341'
;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
;key           Allocated with name '_del_owned_key_key_50000_353'
;key           Allocated with name '_del_owned_key_key_40000_350'
;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
;key           Allocated with name '_del_owned_key_key_70000_359'
;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
;key           Allocated with name '_del_owned_key_key_40000_362'
;------------------------------------------------------------
;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
;	-----------------------------------------
;	 function del_owned_key
;	-----------------------------------------
_del_owned_key:
	mov	a,dpl
	mov	dptr,#_del_owned_key_code_10000_341
	lcall	_ak820_outline_0132
;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
	clr	a
	movx	@dptr,a
	mov	dptr,#_macro_keys
	push	ar7
	lcall	_ak820_macro_change
	mov	a, dpl
	pop	ar7
	jnz	00102$
	mov	dpl,a
	ret
00102$:
;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
	lcall	_ak820_outline_0030
	mov	r4,a
	jz	00103$
	dec	r4
	lcall	_ak820_outline_0063
	mov	a,r4
	jz	00104$
00103$:
	mov	dpl, #0x00
	ret
00104$:
;	quantum/action_util.c:140: --distinct_keys;
	mov	dptr,#_distinct_keys
	movx	a,@dptr
	dec	a
	movx	@dptr,a
;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
	mov	dptr,#_keyboard_protocol
	movx	a,@dptr
	jz	00107$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	jnb	acc.7,00107$
;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
	mov	dptr,#_del_key_from_report_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_actual_keyboard_report
	lcall	_del_key_from_report
;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
	mov	dpl, #0x01
	ret
00107$:
;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
	mov	dptr,#_distinct_keys
	movx	a,@dptr
	mov  r7,a
	add	a,#0xff - 0x06
	jnc	00110$
;	free result
	mov	dpl, #0x01
	ret
00110$:
;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
	cjne	r7,#0x06,00115$
;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
	mov	dptr,#_actual_keyboard_report
	lcall	_clear_keys_from_report
;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
	mov	r7,#0x04
00122$:
	mov	a,r7
	add	a,#0xff - 0xa4
	jc	00116$
;	free result
	lcall	_ak820_outline_0030
	jz	00123$
;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
	lcall	_ak820_outline_0176
	push	ar7
	lcall	_add_key_to_report
	pop	ar7
;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
00123$:
	inc	r7
	sjmp	00122$
00115$:
;	quantum/action_util.c:149: } else del_key(code);
	mov	dptr,#_del_owned_key_code_10000_341
	movx	a,@dptr
;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
	mov	dptr,#_del_key_from_report_PARM_2
	movx	@dptr,a
	mov	dptr,#_actual_keyboard_report
	lcall	_del_key_from_report
;	quantum/action_util.c:149: } else del_key(code);
00116$:
;	quantum/action_util.c:150: return true;
	mov	dpl, #0x01
;	quantum/action_util.c:151: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'clear_owned_usages'
;------------------------------------------------------------
;i             Allocated with name '_clear_owned_usages_i_20000_366'
;i             Allocated with name '_clear_owned_usages_i_20000_367'
;------------------------------------------------------------
;	quantum/action_util.c:161: void clear_owned_usages(void) {
;	-----------------------------------------
;	 function clear_owned_usages
;	-----------------------------------------
_clear_owned_usages:
;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
	mov	r7,#0x00
00104$:
	cjne	r7,#0x1e,00141$
00141$:
	jnc	00101$
	mov	a,r7
	add	a, #_usage_refs
	mov	r5,a
	clr	a
	addc	a, #(_usage_refs >> 8)
	mov	r6,a
	mov	a,r7
	lcall	_ak820_outline_0067
	clr	a
	movx	@dptr,a
	lcall	_ak820_outline_0121
	inc	r7
	sjmp	00104$
00101$:
;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
	mov	dptr,#(_usage_lengths + 0x0001)
	clr	a
	movx	@dptr,a
	mov	dptr,#_usage_lengths
	movx	@dptr,a
;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
	mov	r7,a
00107$:
	cjne	r7,#0x04,00143$
00143$:
	jnc	00109$
	mov	a,r7
	add	a, #_macro_usages
	mov	dpl,a
	clr	a
	addc	a, #(_macro_usages >> 8)
	lcall	_ak820_outline_0163
	sjmp	00107$
00109$:
;	quantum/action_util.c:165: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'owned_usage_key'
;------------------------------------------------------------
;pressed       Allocated with name '_owned_usage_key_PARM_2'
;code          Allocated with name '_owned_usage_key_code_10000_368'
;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
;which         Allocated with name '_owned_usage_key_which_10000_369'
;base          Allocated with name '_owned_usage_key_base_10000_369'
;count         Allocated with name '_owned_usage_key_count_10000_369'
;index         Allocated with name '_owned_usage_key_index_10000_369'
;pos           Allocated with name '_owned_usage_key_pos_30001_376'
;i             Allocated with name '_owned_usage_key_i_40001_377'
;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
;key           Allocated with name '_owned_usage_key_key_40000_381'
;------------------------------------------------------------
;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
;	-----------------------------------------
;	 function owned_usage_key
;	-----------------------------------------
_owned_usage_key:
	mov	a,dpl
	mov	dptr,#_owned_usage_key_code_10000_368
	movx	@dptr,a
;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa8,00244$
00244$:
	cpl	c
	mov	_owned_usage_key_sloc0_1_0,c
	clr	a
	rlc	a
	mov	r7,a
	mov	dptr,#_owned_usage_key_which_10000_369
	movx	@dptr,a
;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
	mov	a,r7
	jz	00129$
	mov	a,#0x03
00129$:
	mov	r6,a
;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
	mov	a,r7
	add	a, #_usage_lengths
	mov	r5,a
	clr	a
	addc	a, #(_usage_lengths >> 8)
	mov	r7,a
	lcall	_ak820_outline_0189
	movx	a,@dptr
	mov	r4,a
;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
	mov	dptr,#_owned_usage_key_code_10000_368
	movx	a,@dptr
	add	a,#0x5b
	mov	r3,a
;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
	mov	dptr,#_owned_usage_key_PARM_2
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_ak820_macro_change_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	dptr,#_ak820_macro_change_PARM_3
	mov	a,r2
	movx	@dptr,a
	mov	dptr,#_macro_usages
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_ak820_macro_change
	mov	a, dpl
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00102$
	ret
00102$:
;	quantum/action_util.c:172: if (pressed) {
	mov	a,r2
	jz	00115$
;	quantum/action_util.c:173: if (usage_refs[index]++) return;
	lcall	_ak820_outline_0075
	inc	a
	lcall	_ak820_outline_0139
	mov	a,r0
	jz	00104$
	ret
00104$:
;	quantum/action_util.c:174: usage_order[base + count++] = index;
	mov	dptr,#_owned_usage_key_count_10000_369
	mov	a,r4
	inc	a
	movx	@dptr,a
	mov	a,r4
	add	a, r6
	lcall	_ak820_outline_0067
	mov	a,r3
	movx	@dptr,a
	ljmp	00116$
00115$:
;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
	lcall	_ak820_outline_0075
	jz	00105$
	dec	r0
	lcall	_ak820_outline_0062
	mov	a,r0
	jz	00106$
00105$:
	ret
00106$:
;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
	mov	r2,#0x00
00108$:
	mov	a,r2
	add	a, r6
	lcall	_ak820_outline_0067
	movx	a,@dptr
	cjne	a,ar3,00251$
	sjmp	00167$
00251$:
	inc	r2
	sjmp	00108$
00167$:
	mov	dptr,#_owned_usage_key_pos_30001_376
	mov	a,r2
	movx	@dptr,a
;	quantum/action_util.c:179: --count;
	dec	r4
	mov	dptr,#_owned_usage_key_count_10000_369
	mov	a,r4
	movx	@dptr,a
;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
	mov	ar3,r2
00125$:
	clr	c
	mov	a,r3
	subb	a,r4
	jnc	00111$
	push	ar5
	push	ar7
	mov	a,r3
	add	a, r6
	mov	r2,a
	add	a, #_usage_order
	mov	r0,a
	clr	a
	addc	a, #(_usage_order >> 8)
	mov	r1,a
	inc	r2
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	a,r2
	lcall	_ak820_outline_0125
	lcall	_ak820_outline_0144
	movx	@dptr,a
	inc	r3
	pop	ar7
	pop	ar5
	sjmp	00125$
00111$:
;	quantum/action_util.c:181: usage_lengths[which] = count;
	lcall	_ak820_outline_0189
	mov	a,r4
	movx	@dptr,a
;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
	mov	dptr,#_owned_usage_key_pos_30001_376
	movx	a,@dptr
	cjne	a,ar4,00253$
	sjmp	00116$
00253$:
	ret
00116$:
;	quantum/action_util.c:184: usage_lengths[which] = count;
	mov	dptr,#_owned_usage_key_count_10000_369
	movx	a,@dptr
	mov	r4,a
	lcall	_ak820_outline_0189
	movx	@dptr,a
;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
	mov	a,r4
	jz	00131$
	mov	a,r4
	add	a, r6
	mov	r6,a
	dec	r6
	mov	a,r6
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	a,r6
	lcall	_ak820_outline_0125
	add	a,#0xa5
	mov	r6,a
	rlc	a
	subb	a,acc
	sjmp	00132$
00131$:
	mov	r6,#0x00
00132$:
	mov	dptr,#_owned_usage_key_code_10000_368
	mov	a,r6
	movx	@dptr,a
;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
	mov	dptr,#_owned_usage_key_which_10000_369
	movx	a,@dptr
	jz	00118$
	mov	a,r6
	jz	00133$
	mov	dpl, r6
	lcall	_KEYCODE2CONSUMER
	mov	r5, dpl
	mov	r7, dph
	sjmp	00134$
00133$:
	mov	r5,#0x00
	mov	r7,#0x00
00134$:
	lcall	_ak820_outline_0189
	ljmp	_host_consumer_send
00118$:
;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
	mov	a,r6
	jz	00135$
;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
	cjne	r6,#0xa5,00258$
00258$:
	jc	00121$
	mov	a,r6
	add	a,#0xff - 0xa7
	jnc	00122$
;	free result
00121$:
	mov	dptr,#_owned_usage_key___200000085_20000_369
	lcall	_ak820_outline_0183
	sjmp	00123$
00122$:
;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
	mov	a,#0xdc
	add	a, r6
	mov	dptr,#_owned_usage_key___200000085_20000_369
	lcall	_ak820_outline_0134
;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
00123$:
	mov	dptr,#_owned_usage_key___200000085_20000_369
	movx	a,@dptr
	mov	r7,a
	sjmp	00136$
00135$:
	mov	r7,#0x00
00136$:
	mov	r6,#0x00
	lcall	_ak820_outline_0158
;	quantum/action_util.c:188: }
	ljmp	_host_system_send
;------------------------------------------------------------
;Allocation info for local variables in function 'send_keyboard_report'
;------------------------------------------------------------
;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
;src           Allocated with name '_send_keyboard_report_src_10001_388'
;i             Allocated with name '_send_keyboard_report_i_20001_389'
;------------------------------------------------------------
;	quantum/action_util.c:410: void send_keyboard_report(void) {
;	-----------------------------------------
;	 function send_keyboard_report
;	-----------------------------------------
_send_keyboard_report:
;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
	mov	dptr,#_real_mods
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_actual_keyboard_report
	movx	@dptr,a
;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
	mov	dptr,#_weak_mods
	movx	a,@dptr
	orl	ar7,a
	mov	dptr,#_actual_keyboard_report
	mov	a,r7
	movx	@dptr,a
;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
	mov	dptr,#_owned_weak_mods
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_owned_mods
	movx	a,@dptr
	orl	a,r6
	orl	ar7,a
	mov	dptr,#_actual_keyboard_report
	mov	a,r7
	movx	@dptr,a
;	quantum/action_util.c:455: bool changed = false;
	mov	dptr,#_send_keyboard_report_changed_10001_388
	clr	a
	movx	@dptr,a
;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
	mov	r7,a
00107$:
	cjne	r7,#0x20,00140$
00140$:
	jnc	00103$
;	quantum/action_util.c:464: if (dest[i] != src[i]) {
	mov	a,r7
	add	a, #_send_keyboard_report_last_report_10001_388
	mov	r5,a
	clr	a
	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
	mov	r6,a
	lcall	_ak820_outline_0076
	mov	a,r7
	add	a, #_actual_keyboard_report
	mov	dpl,a
	clr	a
	addc	a, #(_actual_keyboard_report >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r3,a
	mov	a,r4
	cjne	a,ar3,00142$
	sjmp	00108$
00142$:
;	quantum/action_util.c:465: dest[i] = src[i];
	lcall	_ak820_outline_0135
	mov	a,r3
	movx	@dptr,a
;	quantum/action_util.c:466: changed = true;
	mov	dptr,#_send_keyboard_report_changed_10001_388
	mov	a,#0x01
	movx	@dptr,a
00108$:
;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
	inc	r7
	sjmp	00107$
00103$:
;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
	mov	dptr,#_send_keyboard_report_changed_10001_388
	movx	a,@dptr
	jz	00109$
	mov	dptr,#_actual_keyboard_report
	mov	b, #0x00
;	quantum/action_util.c:477: }
	ljmp	_host_keyboard_send
00109$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_mods'
;------------------------------------------------------------
;	quantum/action_util.c:483: uint8_t get_mods(void) {
;	-----------------------------------------
;	 function get_mods
;	-----------------------------------------
_get_mods:
	push	ar7
;	quantum/action_util.c:488: ;
	mov	dptr,#_owned_mods
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_real_mods
	lcall	_ak820_outline_0141
;	quantum/action_util.c:489: }
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'add_mods'
;------------------------------------------------------------
;mods          Allocated with name '_add_mods_mods_10000_396'
;------------------------------------------------------------
;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
;	-----------------------------------------
;	 function clear_mods
;	-----------------------------------------
_clear_mods:
;	quantum/action_util.c:516: real_mods = 0;
	mov	dptr,#_real_mods
	clr	a
	movx	@dptr,a
;	quantum/action_util.c:517: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_weak_mods'
;------------------------------------------------------------
;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
;	-----------------------------------------
;	 function get_weak_mods
;	-----------------------------------------
_get_weak_mods:
	push	ar7
;	quantum/action_util.c:528: ;
	mov	dptr,#_owned_weak_mods
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_weak_mods
	lcall	_ak820_outline_0141
;	quantum/action_util.c:529: }
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'add_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_add_weak_mods_mods_10000_406'
;------------------------------------------------------------
;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
;	-----------------------------------------
;	 function add_weak_mods
;	-----------------------------------------
_add_weak_mods:
	mov	a,dpl
	mov	dptr,#_add_weak_mods_mods_10000_406
	movx	@dptr,a
;	quantum/action_util.c:535: weak_mods |= mods;
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_weak_mods
	movx	a,@dptr
	orl	a,r7
	movx	@dptr,a
;	quantum/action_util.c:536: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'del_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_del_weak_mods_mods_10000_408'
;------------------------------------------------------------
;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
;	-----------------------------------------
;	 function del_weak_mods
;	-----------------------------------------
_del_weak_mods:
	mov	a,dpl
	mov	dptr,#_del_weak_mods_mods_10000_408
	movx	@dptr,a
;	quantum/action_util.c:542: weak_mods &= ~mods;
	movx	a,@dptr
	cpl	a
	mov	r7,a
	mov	dptr,#_weak_mods
	movx	a,@dptr
	anl	a,r7
	movx	@dptr,a
;	quantum/action_util.c:543: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'set_weak_mods'
;------------------------------------------------------------
;mods          Allocated with name '_set_weak_mods_mods_10000_410'
;------------------------------------------------------------
;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
;	-----------------------------------------
;	 function clear_weak_mods
;	-----------------------------------------
_clear_weak_mods:
;	quantum/action_util.c:556: weak_mods = 0;
	mov	dptr,#_weak_mods
	clr	a
	movx	@dptr,a
;	quantum/action_util.c:557: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
;------------------------------------------------------------
;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
;------------------------------------------------------------
;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__real_mods:
	.db #0x00	; 0
__xinit__weak_mods:
	.db #0x00	; 0
__xinit__actual_keyboard_report:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.db 0x00
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0015
	.globl _ak820_outline_0030
	.globl _ak820_outline_0055
	.globl _ak820_outline_0059
	.globl _ak820_outline_0061
	.globl _ak820_outline_0062
	.globl _ak820_outline_0063
	.globl _ak820_outline_0067
	.globl _ak820_outline_0075
	.globl _ak820_outline_0076
	.globl _ak820_outline_0107
	.globl _ak820_outline_0108
	.globl _ak820_outline_0116
	.globl _ak820_outline_0121
	.globl _ak820_outline_0123
	.globl _ak820_outline_0125
	.globl _ak820_outline_0132
	.globl _ak820_outline_0134
	.globl _ak820_outline_0135
	.globl _ak820_outline_0139
	.globl _ak820_outline_0141
	.globl _ak820_outline_0144
	.globl _ak820_outline_0158
	.globl _ak820_outline_0163
	.globl _ak820_outline_0176
	.globl _ak820_outline_0183
	.globl _ak820_outline_0188
	.globl _ak820_outline_0189

	.area CSEG (CODE)
; function ak820_outline_0030
_ak820_outline_0030:
	mov	a,r7
	add	a,#_key_refs
	mov	r5,a
	clr	a
	addc	a,#(_key_refs>>8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0062
_ak820_outline_0062:
	mov	dpl,r1
	mov	dph,r2
	mov	a,r0
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0067
_ak820_outline_0067:
	add	a,#_usage_order
	mov	dpl,a
	clr	a
	addc	a,#(_usage_order>>8)
	mov	dph,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0075
_ak820_outline_0075:
	mov	a,r3
	add	a,#_usage_refs
	mov	r1,a
	clr	a
	addc	a,#(_usage_refs>>8)
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	mov	r0,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0116
_ak820_outline_0116:
	movx	@dptr,a
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_change_owned_PARM_2
	ret

	.area CSEG (CODE)
; function ak820_outline_0121
_ak820_outline_0121:
	mov	dpl,r5
	mov	dph,r6
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0125
_ak820_outline_0125:
	add	a,#_usage_order
	mov	dpl,a
	mov	a,r7
	addc	a,#(_usage_order>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0132
_ak820_outline_0132:
	movx	@dptr,a
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_macro_change_PARM_2
	movx	@dptr,a
	mov	dptr,#_ak820_macro_change_PARM_3
	ret

	.area CSEG (CODE)
; function ak820_outline_0176
_ak820_outline_0176:
	mov	dptr,#_add_key_to_report_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_actual_keyboard_report
	ret

	.area CSEG (CODE)
; function ak820_outline_0189
_ak820_outline_0189:
	mov	dpl,r5
	mov	dph,r7
	ret
