                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000025                        582 _get_record_keycode_sloc0_1_0:
      000025                        583 	.ds 1
      000026                        584 _pre_process_record_quantum_sloc0_1_0:
      000026                        585 	.ds 1
                                    586 ;--------------------------------------------------------
                                    587 ; paged external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area PSEG    (PAG,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; uninitialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XSEG    (XDATA)
      000BD3                        594 _extract_mod_bits_code_10000_599:
      000BD3                        595 	.ds 2
      000BD5                        596 _register_code16_code_10000_605:
      000BD5                        597 	.ds 2
      000BD7                        598 _unregister_code16_code_10000_610:
      000BD7                        599 	.ds 2
      000BD9                        600 _pre_process_record_kb_PARM_2:
      000BD9                        601 	.ds 3
      000BDC                        602 _pre_process_record_kb_keycode_10000_624:
      000BDC                        603 	.ds 2
      000BDE                        604 _pre_process_record_user_PARM_2:
      000BDE                        605 	.ds 3
      000BE1                        606 _process_record_kb_PARM_2:
      000BE1                        607 	.ds 3
      000BE4                        608 _process_record_kb_keycode_10000_630:
      000BE4                        609 	.ds 2
      000BE6                        610 _process_record_user_PARM_2:
      000BE6                        611 	.ds 3
      000BE9                        612 _post_process_record_kb_PARM_2:
      000BE9                        613 	.ds 3
      000BEC                        614 _post_process_record_kb_keycode_10000_634:
      000BEC                        615 	.ds 2
      000BEE                        616 _post_process_record_user_PARM_2:
      000BEE                        617 	.ds 3
      000BF1                        618 _get_record_keycode_PARM_2:
      000BF1                        619 	.ds 1
      000BF2                        620 _get_record_keycode_record_argument_10000_648:
      000BF2                        621 	.ds 3
      000BF5                        622 _pre_process_record_quantum_record_argument_10000_654:
      000BF5                        623 	.ds 3
      000BF8                        624 _post_process_record_quantum_record_10000_656:
      000BF8                        625 	.ds 3
      000BFB                        626 _process_record_quantum_record_10000_658:
      000BFB                        627 	.ds 3
      000BFE                        628 _process_record_quantum_helper_PARM_2:
      000BFE                        629 	.ds 3
      000C01                        630 _process_record_quantum_helper_keycode_10000_660:
      000C01                        631 	.ds 2
      000C03                        632 _get_u8_str_last_num_10000_686:
      000C03                        633 	.ds 1
      000C04                        634 _get_u16_str_last_num_10000_690:
      000C04                        635 	.ds 2
                                    636 ;--------------------------------------------------------
                                    637 ; absolute external ram data
                                    638 ;--------------------------------------------------------
                                    639 	.area XABS    (ABS,XDATA)
                                    640 ;--------------------------------------------------------
                                    641 ; initialized external ram data
                                    642 ;--------------------------------------------------------
                                    643 	.area XISEG   (XDATA)
                                    644 	.area HOME    (CODE)
                                    645 	.area GSINIT0 (CODE)
                                    646 	.area GSINIT1 (CODE)
                                    647 	.area GSINIT2 (CODE)
                                    648 	.area GSINIT3 (CODE)
                                    649 	.area GSINIT4 (CODE)
                                    650 	.area GSINIT5 (CODE)
                                    651 	.area GSINIT  (CODE)
                                    652 	.area GSFINAL (CODE)
                                    653 	.area CSEG    (CODE)
                                    654 ;--------------------------------------------------------
                                    655 ; global & static initialisations
                                    656 ;--------------------------------------------------------
                                    657 	.area HOME    (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area GSINIT  (CODE)
                                    661 ;------------------------------------------------------------
                                    662 ;Allocation info for local variables in function 'get_u8_str'
                                    663 ;------------------------------------------------------------
                                    664 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    665 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_685'
                                    666 ;buf           Allocated with name '_get_u8_str_buf_10000_686'
                                    667 ;last_num      Allocated with name '_get_u8_str_last_num_10000_686'
                                    668 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_686'
                                    669 ;------------------------------------------------------------
                                    670 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 03         [24]  671 	mov	dptr,#_get_u8_str_last_num_10000_686
      0030F6 74 FF            [12]  672 	mov	a,#0xff
      0030F8 F0               [24]  673 	movx	@dptr,a
                                    674 ;------------------------------------------------------------
                                    675 ;Allocation info for local variables in function 'get_u16_str'
                                    676 ;------------------------------------------------------------
                                    677 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    678 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_689'
                                    679 ;buf           Allocated with name '_get_u16_str_buf_10000_690'
                                    680 ;last_num      Allocated with name '_get_u16_str_last_num_10000_690'
                                    681 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_690'
                                    682 ;------------------------------------------------------------
                                    683 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 04         [24]  684 	mov	dptr,#_get_u16_str_last_num_10000_690
      0030FC 74 FF            [12]  685 	mov	a,#0xff
      0030FE F0               [24]  686 	movx	@dptr,a
      0030FF E4               [12]  687 	clr	a
      003100 A3               [24]  688 	inc	dptr
      003101 F0               [24]  689 	movx	@dptr,a
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    701 ;------------------------------------------------------------
                                    702 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    703 ;------------------------------------------------------------
                                    704 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function extract_mod_bits
                                    715 ;	-----------------------------------------
      009C3D                        716 _extract_mod_bits:
      009C3D 12 38 8D         [24]  717 	lcall	_ak820_outline_0108
      009C40 90 0B D3         [24]  718 	mov	dptr,#_extract_mod_bits_code_10000_599
      009C43 12 38 88         [24]  719 	lcall	_ak820_outline_0107
                                    720 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009C46 90 0B D3         [24]  721 	mov	dptr,#_extract_mod_bits_code_10000_599
      009C49 E0               [24]  722 	movx	a,@dptr
      009C4A A3               [24]  723 	inc	dptr
      009C4B E0               [24]  724 	movx	a,@dptr
                                    725 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009C4C FF               [12]  726 	mov	r7,a
      009C4D 60 05            [24]  727 	jz	00101$
      009C4F EF               [12]  728 	mov	a,r7
      009C50 24 E0            [12]  729 	add	a,#0xff - 0x1f
      009C52 50 04            [24]  730 	jnc	00102$
                                    731 ;	free result
      009C54                        732 00101$:
      009C54 75 82 00         [24]  733 	mov	dpl, #0x00
      009C57 22               [24]  734 	ret
      009C58                        735 00102$:
                                    736 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009C58 EF               [12]  737 	mov	a,r7
      009C59 30 E4 07         [24]  738 	jnb	acc.4,00106$
      009C5C EF               [12]  739 	mov	a,r7
      009C5D C4               [12]  740 	swap	a
      009C5E 54 F0            [12]  741 	anl	a,#0xf0
      009C60 FE               [12]  742 	mov	r6,a
      009C61 80 02            [24]  743 	sjmp	00107$
      009C63                        744 00106$:
      009C63 8F 06            [24]  745 	mov	ar6,r7
      009C65                        746 00107$:
      009C65 8E 82            [24]  747 	mov	dpl, r6
                                    748 ;	quantum/quantum.c:137: }
      009C67 22               [24]  749 	ret
                                    750 ;------------------------------------------------------------
                                    751 ;Allocation info for local variables in function 'do_code16'
                                    752 ;------------------------------------------------------------
                                    753 ;f             Allocated with name '_do_code16_PARM_2'
                                    754 ;code          Allocated with name '_do_code16_code_10000_602'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function register_code16
                                    759 ;	-----------------------------------------
      009C68                        760 _register_code16:
      009C68 12 38 8D         [24]  761 	lcall	_ak820_outline_0108
      009C6B 90 0B D5         [24]  762 	mov	dptr,#_register_code16_code_10000_605
      009C6E 12 38 88         [24]  763 	lcall	_ak820_outline_0107
                                    764 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009C71 90 0B D5         [24]  765 	mov	dptr,#_register_code16_code_10000_605
      009C74 12 37 F4         [24]  766 	lcall	_ak820_outline_0005
      009C77 C0 07            [24]  767 	push	ar7
      009C79 C0 06            [24]  768 	push	ar6
      009C7B 12 9C 3D         [24]  769 	lcall	_extract_mod_bits
      009C7E AD 82            [24]  770 	mov	r5, dpl
      009C80 D0 06            [24]  771 	pop	ar6
      009C82 D0 07            [24]  772 	pop	ar7
                                    773 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009C84 12 9A 76         [24]  774 	lcall	_ak820_outline_0119
      009C87 40 07            [24]  775 	jc	00105$
      009C89 74 E7            [12]  776 	mov	a,#0xe7
      009C8B 9E               [12]  777 	subb	a,r6
      009C8C E4               [12]  778 	clr	a
      009C8D 9F               [12]  779 	subb	a,r7
      009C8E 50 08            [24]  780 	jnc	00101$
                                    781 ;	free result
      009C90                        782 00105$:
      009C90 90 0B D5         [24]  783 	mov	dptr,#_register_code16_code_10000_605
      009C93 12 6C D8         [24]  784 	lcall	_ak820_outline_0040
      009C96 70 07            [24]  785 	jnz	00102$
      009C98                        786 00101$:
                                    787 ;	quantum/quantum.c:147: register_mods(mods);
      009C98 8D 82            [24]  788 	mov	dpl, r5
      009C9A 12 75 81         [24]  789 	lcall	_register_mods
      009C9D 80 05            [24]  790 	sjmp	00103$
      009C9F                        791 00102$:
                                    792 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009C9F 8D 82            [24]  793 	mov	dpl, r5
      009CA1 12 75 A9         [24]  794 	lcall	_register_weak_mods
      009CA4                        795 00103$:
                                    796 ;	quantum/quantum.c:151: register_code(code);
      009CA4 90 0B D5         [24]  797 	mov	dptr,#_register_code16_code_10000_605
      009CA7 E0               [24]  798 	movx	a,@dptr
      009CA8 F5 82            [12]  799 	mov	dpl,a
                                    800 ;	quantum/quantum.c:161: }
      009CAA 02 74 5E         [24]  801 	ljmp	_register_code
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'unregister_code16'
                                    804 ;------------------------------------------------------------
                                    805 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    806 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function unregister_code16
                                    811 ;	-----------------------------------------
      009CAD                        812 _unregister_code16:
      009CAD 12 38 8D         [24]  813 	lcall	_ak820_outline_0108
      009CB0 90 0B D7         [24]  814 	mov	dptr,#_unregister_code16_code_10000_610
      009CB3 12 38 88         [24]  815 	lcall	_ak820_outline_0107
                                    816 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009CB6 90 0B D7         [24]  817 	mov	dptr,#_unregister_code16_code_10000_610
      009CB9 12 37 F4         [24]  818 	lcall	_ak820_outline_0005
      009CBC C0 07            [24]  819 	push	ar7
      009CBE C0 06            [24]  820 	push	ar6
      009CC0 12 9C 3D         [24]  821 	lcall	_extract_mod_bits
      009CC3 AD 82            [24]  822 	mov	r5, dpl
      009CC5 D0 06            [24]  823 	pop	ar6
                                    824 ;	quantum/quantum.c:166: unregister_code(code);
      009CC7 8E 04            [24]  825 	mov	ar4,r6
      009CC9 8C 82            [24]  826 	mov	dpl, r4
      009CCB C0 06            [24]  827 	push	ar6
      009CCD C0 05            [24]  828 	push	ar5
      009CCF 12 74 CB         [24]  829 	lcall	_unregister_code
      009CD2 D0 05            [24]  830 	pop	ar5
      009CD4 D0 06            [24]  831 	pop	ar6
      009CD6 D0 07            [24]  832 	pop	ar7
                                    833 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009CD8 12 9A 76         [24]  834 	lcall	_ak820_outline_0119
      009CDB 40 07            [24]  835 	jc	00105$
      009CDD 74 E7            [12]  836 	mov	a,#0xe7
      009CDF 9E               [12]  837 	subb	a,r6
      009CE0 E4               [12]  838 	clr	a
      009CE1 9F               [12]  839 	subb	a,r7
      009CE2 50 08            [24]  840 	jnc	00101$
                                    841 ;	free result
      009CE4                        842 00105$:
      009CE4 90 0B D7         [24]  843 	mov	dptr,#_unregister_code16_code_10000_610
      009CE7 12 6C D8         [24]  844 	lcall	_ak820_outline_0040
      009CEA 70 05            [24]  845 	jnz	00102$
      009CEC                        846 00101$:
                                    847 ;	quantum/quantum.c:168: unregister_mods(mods);
      009CEC 8D 82            [24]  848 	mov	dpl, r5
      009CEE 02 75 95         [24]  849 	ljmp	_unregister_mods
      009CF1                        850 00102$:
                                    851 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009CF1 8D 82            [24]  852 	mov	dpl, r5
                                    853 ;	quantum/quantum.c:181: }
      009CF3 02 75 BD         [24]  854 	ljmp	_unregister_weak_mods
                                    855 ;------------------------------------------------------------
                                    856 ;Allocation info for local variables in function 'tap_code16_delay'
                                    857 ;------------------------------------------------------------
                                    858 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    859 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    860 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    861 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    862 ;------------------------------------------------------------
                                    863 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    864 ;	-----------------------------------------
                                    865 ;	 function pre_process_record_kb
                                    866 ;	-----------------------------------------
      009CF6                        867 _pre_process_record_kb:
      009CF6 12 38 8D         [24]  868 	lcall	_ak820_outline_0108
      009CF9 90 0B DC         [24]  869 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009CFC 12 38 88         [24]  870 	lcall	_ak820_outline_0107
                                    871 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009CFF 90 0B DC         [24]  872 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009D02 12 38 41         [24]  873 	lcall	_ak820_outline_0051
      009D05 90 0B D9         [24]  874 	mov	dptr,#_pre_process_record_kb_PARM_2
      009D08 12 9A 6D         [24]  875 	lcall	_ak820_outline_0026
      009D0B 90 0B DE         [24]  876 	mov	dptr,#_pre_process_record_user_PARM_2
      009D0E 12 9F CC         [24]  877 	lcall	_ak820_outline_0009
                                    878 ;	quantum/quantum.c:206: }
      009D11 02 9D 14         [24]  879 	ljmp	_pre_process_record_user
                                    880 ;------------------------------------------------------------
                                    881 ;Allocation info for local variables in function 'pre_process_record_user'
                                    882 ;------------------------------------------------------------
                                    883 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    884 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_626'
                                    885 ;------------------------------------------------------------
                                    886 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    887 ;	-----------------------------------------
                                    888 ;	 function pre_process_record_user
                                    889 ;	-----------------------------------------
      009D14                        890 _pre_process_record_user:
                                    891 ;	quantum/quantum.c:209: return true;
      009D14 75 82 01         [24]  892 	mov	dpl, #0x01
                                    893 ;	quantum/quantum.c:210: }
      009D17 22               [24]  894 	ret
                                    895 ;------------------------------------------------------------
                                    896 ;Allocation info for local variables in function 'process_action_kb'
                                    897 ;------------------------------------------------------------
                                    898 ;record        Allocated with name '_process_action_kb_record_10000_628'
                                    899 ;------------------------------------------------------------
                                    900 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    901 ;	-----------------------------------------
                                    902 ;	 function process_action_kb
                                    903 ;	-----------------------------------------
      009D18                        904 _process_action_kb:
                                    905 ;	quantum/quantum.c:213: return true;
      009D18 75 82 01         [24]  906 	mov	dpl, #0x01
                                    907 ;	quantum/quantum.c:214: }
      009D1B 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'process_record_kb'
                                    911 ;------------------------------------------------------------
                                    912 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    913 ;keycode       Allocated with name '_process_record_kb_keycode_10000_630'
                                    914 ;------------------------------------------------------------
                                    915 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function process_record_kb
                                    918 ;	-----------------------------------------
      009D1C                        919 _process_record_kb:
      009D1C 12 38 8D         [24]  920 	lcall	_ak820_outline_0108
      009D1F 90 0B E4         [24]  921 	mov	dptr,#_process_record_kb_keycode_10000_630
      009D22 12 38 88         [24]  922 	lcall	_ak820_outline_0107
                                    923 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      009D25 90 0B E4         [24]  924 	mov	dptr,#_process_record_kb_keycode_10000_630
      009D28 12 38 41         [24]  925 	lcall	_ak820_outline_0051
      009D2B 90 0B E1         [24]  926 	mov	dptr,#_process_record_kb_PARM_2
      009D2E 12 9A 6D         [24]  927 	lcall	_ak820_outline_0026
      009D31 90 0B E6         [24]  928 	mov	dptr,#_process_record_user_PARM_2
      009D34 12 9F CC         [24]  929 	lcall	_ak820_outline_0009
                                    930 ;	quantum/quantum.c:218: }
      009D37 02 9D 3A         [24]  931 	ljmp	_process_record_user
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'process_record_user'
                                    934 ;------------------------------------------------------------
                                    935 ;record        Allocated with name '_process_record_user_PARM_2'
                                    936 ;keycode       Allocated with name '_process_record_user_keycode_10000_632'
                                    937 ;------------------------------------------------------------
                                    938 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function process_record_user
                                    941 ;	-----------------------------------------
      009D3A                        942 _process_record_user:
                                    943 ;	quantum/quantum.c:221: return true;
      009D3A 75 82 01         [24]  944 	mov	dpl, #0x01
                                    945 ;	quantum/quantum.c:222: }
      009D3D 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'post_process_record_kb'
                                    949 ;------------------------------------------------------------
                                    950 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    951 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_634'
                                    952 ;------------------------------------------------------------
                                    953 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    954 ;	-----------------------------------------
                                    955 ;	 function post_process_record_kb
                                    956 ;	-----------------------------------------
      009D3E                        957 _post_process_record_kb:
      009D3E 12 38 8D         [24]  958 	lcall	_ak820_outline_0108
      009D41 90 0B EC         [24]  959 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009D44 12 38 88         [24]  960 	lcall	_ak820_outline_0107
                                    961 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      009D47 90 0B EC         [24]  962 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009D4A 12 38 41         [24]  963 	lcall	_ak820_outline_0051
      009D4D 90 0B E9         [24]  964 	mov	dptr,#_post_process_record_kb_PARM_2
      009D50 12 9A 6D         [24]  965 	lcall	_ak820_outline_0026
      009D53 90 0B EE         [24]  966 	mov	dptr,#_post_process_record_user_PARM_2
      009D56 12 9F CC         [24]  967 	lcall	_ak820_outline_0009
                                    968 ;	quantum/quantum.c:226: }
      009D59 02 9D 5C         [24]  969 	ljmp	_post_process_record_user
                                    970 ;------------------------------------------------------------
                                    971 ;Allocation info for local variables in function 'post_process_record_user'
                                    972 ;------------------------------------------------------------
                                    973 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    974 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_636'
                                    975 ;------------------------------------------------------------
                                    976 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    977 ;	-----------------------------------------
                                    978 ;	 function post_process_record_user
                                    979 ;	-----------------------------------------
      009D5C                        980 _post_process_record_user:
      009D5C 22               [24]  981 	ret
                                    982 ;------------------------------------------------------------
                                    983 ;Allocation info for local variables in function 'shutdown_quantum'
                                    984 ;------------------------------------------------------------
                                    985 ;i             Allocated with name '_shutdown_quantum_i_30000_642'
                                    986 ;------------------------------------------------------------
                                    987 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    988 ;	-----------------------------------------
                                    989 ;	 function shutdown_quantum
                                    990 ;	-----------------------------------------
      009D5D                        991 _shutdown_quantum:
                                    992 ;	quantum/quantum.c:231: clear_keyboard();
      009D5D 12 75 D1         [24]  993 	lcall	_clear_keyboard
                                    994 ;	quantum/quantum.c:246: shutdown_user();
      009D60 12 9F BE         [24]  995 	lcall	_shutdown_user
                                    996 ;	quantum/quantum.c:247: wait_ms(250);
      009D63 7F FA            [12]  997 	mov	r7,#0xfa
      009D65                        998 00106$:
      009D65 EF               [12]  999 	mov	a,r7
      009D66 60 09            [24] 1000 	jz	00108$
      009D68 90 00 01         [24] 1001 	mov	dptr,#0x0001
      009D6B 12 58 44         [24] 1002 	lcall	_mDelaymS
      009D6E 1F               [12] 1003 	dec	r7
      009D6F 80 F4            [24] 1004 	sjmp	00106$
      009D71                       1005 00108$:
                                   1006 ;	quantum/quantum.c:252: }
      009D71 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'reset_keyboard'
                                   1010 ;------------------------------------------------------------
                                   1011 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1012 ;	-----------------------------------------
                                   1013 ;	 function reset_keyboard
                                   1014 ;	-----------------------------------------
      009D72                       1015 _reset_keyboard:
                                   1016 ;	quantum/quantum.c:255: shutdown_quantum();
      009D72 12 9D 5D         [24] 1017 	lcall	_shutdown_quantum
                                   1018 ;	quantum/quantum.c:256: bootloader_jump();
                                   1019 ;	quantum/quantum.c:257: }
      009D75 02 34 0E         [24] 1020 	ljmp	_bootloader_jump
                                   1021 ;------------------------------------------------------------
                                   1022 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function soft_reset_keyboard
                                   1027 ;	-----------------------------------------
      009D78                       1028 _soft_reset_keyboard:
                                   1029 ;	quantum/quantum.c:260: shutdown_quantum();
      009D78 12 9D 5D         [24] 1030 	lcall	_shutdown_quantum
                                   1031 ;	quantum/quantum.c:261: mcu_reset();
                                   1032 ;	quantum/quantum.c:262: }
      009D7B 02 34 01         [24] 1033 	ljmp	_mcu_reset
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'get_record_keycode'
                                   1036 ;------------------------------------------------------------
                                   1037 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1038 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                   1039 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                   1040 ;------------------------------------------------------------
                                   1041 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1042 ;	-----------------------------------------
                                   1043 ;	 function get_record_keycode
                                   1044 ;	-----------------------------------------
      009D7E                       1045 _get_record_keycode:
      009D7E 12 43 13         [24] 1046 	lcall	_ak820_outline_0037
      009D81 90 0B F2         [24] 1047 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009D84 12 38 29         [24] 1048 	lcall	_ak820_outline_0016
                                   1049 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D87 90 0B F2         [24] 1050 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009D8A 12 37 FE         [24] 1051 	lcall	_ak820_outline_0007
                                   1052 ;	quantum/quantum.c:272: if (record->keycode) {
      009D8D 4C               [12] 1053 	orl	a,r4
      009D8E 60 04            [24] 1054 	jz	00102$
                                   1055 ;	quantum/quantum.c:273: return record->keycode;
      009D90 12 38 97         [24] 1056 	lcall	_ak820_outline_0124
      009D93 22               [24] 1057 	ret
      009D94                       1058 00102$:
                                   1059 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009D94 12 76 2F         [24] 1060 	lcall	_ak820_outline_0021
      009D97 7A 00            [12] 1061 	mov	r2,#0x00
      009D99 12 43 67         [24] 1062 	lcall	_ak820_outline_0142
      009D9C 12 38 12         [24] 1063 	lcall	_ak820_outline_0014
      009D9F 60 06            [24] 1064 	jz	00105$
      009DA1 90 0B F1         [24] 1065 	mov	dptr,#_get_record_keycode_PARM_2
      009DA4 E0               [24] 1066 	movx	a,@dptr
      009DA5 70 04            [24] 1067 	jnz	00106$
      009DA7                       1068 00105$:
                                   1069 ;	assignBit
      009DA7 C2 25            [12] 1070 	clr	_get_record_keycode_sloc0_1_0
      009DA9 80 02            [24] 1071 	sjmp	00107$
      009DAB                       1072 00106$:
                                   1073 ;	assignBit
      009DAB D2 25            [12] 1074 	setb	_get_record_keycode_sloc0_1_0
      009DAD                       1075 00107$:
      009DAD 90 09 66         [24] 1076 	mov	dptr,#_ak820_resolve_key_PARM_2
      009DB0 A2 25            [12] 1077 	mov	c,_get_record_keycode_sloc0_1_0
      009DB2 E4               [12] 1078 	clr	a
      009DB3 33               [12] 1079 	rlc	a
      009DB4 F0               [24] 1080 	movx	@dptr,a
      009DB5 8D 82            [24] 1081 	mov	dpl, r5
      009DB7 8C 83            [24] 1082 	mov	dph, r4
                                   1083 ;	quantum/quantum.c:281: }
      009DB9 02 79 D6         [24] 1084 	ljmp	_ak820_resolve_key
                                   1085 ;------------------------------------------------------------
                                   1086 ;Allocation info for local variables in function 'get_event_keycode'
                                   1087 ;------------------------------------------------------------
                                   1088 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1089 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function pre_process_record_quantum
                                   1094 ;	-----------------------------------------
      009DBC                       1095 _pre_process_record_quantum:
      009DBC 12 43 13         [24] 1096 	lcall	_ak820_outline_0037
      009DBF 90 0B F5         [24] 1097 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009DC2 12 38 29         [24] 1098 	lcall	_ak820_outline_0016
                                   1099 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009DC5 90 0B F5         [24] 1100 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009DC8 12 38 41         [24] 1101 	lcall	_ak820_outline_0051
                                   1102 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      009DCB 8E 03            [24] 1103 	mov	ar3,r6
      009DCD 8F 04            [24] 1104 	mov	ar4,r7
      009DCF 7D 00            [12] 1105 	mov	r5,#0x00
      009DD1 90 0B F1         [24] 1106 	mov	dptr,#_get_record_keycode_PARM_2
      009DD4 74 01            [12] 1107 	mov	a,#0x01
      009DD6 12 48 3A         [24] 1108 	lcall	_ak820_outline_0122
      009DD9 8D F0            [24] 1109 	mov	b, r5
      009DDB C0 07            [24] 1110 	push	ar7
      009DDD C0 06            [24] 1111 	push	ar6
      009DDF 12 9D 7E         [24] 1112 	lcall	_get_record_keycode
      009DE2 12 43 72         [24] 1113 	lcall	_ak820_outline_0150
      009DE5 D0 06            [24] 1114 	pop	ar6
      009DE7 D0 07            [24] 1115 	pop	ar7
                                   1116 ;	quantum/quantum.c:328: record->keycode = keycode;
      009DE9 74 07            [12] 1117 	mov	a,#0x07
      009DEB 12 38 31         [24] 1118 	lcall	_ak820_outline_0023
      009DEE 12 38 5E         [24] 1119 	lcall	_ak820_outline_0071
                                   1120 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      009DF1 90 0B D9         [24] 1121 	mov	dptr,#_pre_process_record_kb_PARM_2
      009DF4 12 9F BF         [24] 1122 	lcall	_ak820_outline_0002
      009DF7 C0 07            [24] 1123 	push	ar7
      009DF9 C0 06            [24] 1124 	push	ar6
      009DFB 12 9C F6         [24] 1125 	lcall	_pre_process_record_kb
      009DFE E5 82            [12] 1126 	mov	a, dpl
      009E00 D0 06            [24] 1127 	pop	ar6
      009E02 D0 07            [24] 1128 	pop	ar7
      009E04 60 0A            [24] 1129 	jz	00103$
                                   1130 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009E06 12 38 92         [24] 1131 	lcall	_ak820_outline_0117
      009E09 12 36 3B         [24] 1132 	lcall	_ak820_combo_process
      009E0C E5 82            [12] 1133 	mov	a, dpl
      009E0E 70 04            [24] 1134 	jnz	00104$
                                   1135 ;	quantum/quantum.c:346: true;
      009E10                       1136 00103$:
                                   1137 ;	assignBit
      009E10 C2 26            [12] 1138 	clr	_pre_process_record_quantum_sloc0_1_0
      009E12 80 02            [24] 1139 	sjmp	00105$
      009E14                       1140 00104$:
                                   1141 ;	assignBit
      009E14 D2 26            [12] 1142 	setb	_pre_process_record_quantum_sloc0_1_0
      009E16                       1143 00105$:
      009E16 A2 26            [12] 1144 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009E18 12 38 B6         [24] 1145 	lcall	_ak820_outline_0157
                                   1146 ;	quantum/quantum.c:347: }
      009E1B 22               [24] 1147 	ret
                                   1148 ;------------------------------------------------------------
                                   1149 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1150 ;------------------------------------------------------------
                                   1151 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                   1152 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                   1153 ;------------------------------------------------------------
                                   1154 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1155 ;	-----------------------------------------
                                   1156 ;	 function post_process_record_quantum
                                   1157 ;	-----------------------------------------
      009E1C                       1158 _post_process_record_quantum:
      009E1C 12 43 13         [24] 1159 	lcall	_ak820_outline_0037
      009E1F 90 0B F8         [24] 1160 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009E22 12 38 29         [24] 1161 	lcall	_ak820_outline_0016
                                   1162 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      009E25 90 0B F8         [24] 1163 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009E28 12 4E 70         [24] 1164 	lcall	_ak820_outline_0011
      009E2B 90 0B F1         [24] 1165 	mov	dptr,#_get_record_keycode_PARM_2
      009E2E E4               [12] 1166 	clr	a
      009E2F 12 4E 79         [24] 1167 	lcall	_ak820_outline_0033
      009E32 12 9D 7E         [24] 1168 	lcall	_get_record_keycode
      009E35 12 43 5C         [24] 1169 	lcall	_ak820_outline_0133
                                   1170 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      009E38 90 0B F8         [24] 1171 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009E3B 12 9A 6D         [24] 1172 	lcall	_ak820_outline_0026
      009E3E 90 0B E9         [24] 1173 	mov	dptr,#_post_process_record_kb_PARM_2
      009E41 12 9F CC         [24] 1174 	lcall	_ak820_outline_0009
                                   1175 ;	quantum/quantum.c:353: }
      009E44 02 9D 3E         [24] 1176 	ljmp	_post_process_record_kb
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'process_record_quantum'
                                   1179 ;------------------------------------------------------------
                                   1180 ;record        Allocated with name '_process_record_quantum_record_10000_658'
                                   1181 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_659'
                                   1182 ;------------------------------------------------------------
                                   1183 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1184 ;	-----------------------------------------
                                   1185 ;	 function process_record_quantum
                                   1186 ;	-----------------------------------------
      009E47                       1187 _process_record_quantum:
      009E47 12 43 13         [24] 1188 	lcall	_ak820_outline_0037
      009E4A 90 0B FB         [24] 1189 	mov	dptr,#_process_record_quantum_record_10000_658
      009E4D 12 38 29         [24] 1190 	lcall	_ak820_outline_0016
                                   1191 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      009E50 90 0B FB         [24] 1192 	mov	dptr,#_process_record_quantum_record_10000_658
      009E53 12 4E 70         [24] 1193 	lcall	_ak820_outline_0011
      009E56 90 0B F1         [24] 1194 	mov	dptr,#_get_record_keycode_PARM_2
      009E59 E4               [12] 1195 	clr	a
      009E5A 12 4E 79         [24] 1196 	lcall	_ak820_outline_0033
      009E5D 12 9D 7E         [24] 1197 	lcall	_get_record_keycode
      009E60 12 43 5C         [24] 1198 	lcall	_ak820_outline_0133
                                   1199 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      009E63 90 0B FB         [24] 1200 	mov	dptr,#_process_record_quantum_record_10000_658
      009E66 12 9A 6D         [24] 1201 	lcall	_ak820_outline_0026
      009E69 90 0B FE         [24] 1202 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009E6C 12 9F CC         [24] 1203 	lcall	_ak820_outline_0009
                                   1204 ;	quantum/quantum.c:362: }
      009E6F 02 9E 72         [24] 1205 	ljmp	_process_record_quantum_helper
                                   1206 ;------------------------------------------------------------
                                   1207 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1208 ;------------------------------------------------------------
                                   1209 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1210 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_660'
                                   1211 ;record        Allocated with name '_process_record_quantum_helper_record_10000_661'
                                   1212 ;------------------------------------------------------------
                                   1213 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1214 ;	-----------------------------------------
                                   1215 ;	 function process_record_quantum_helper
                                   1216 ;	-----------------------------------------
      009E72                       1217 _process_record_quantum_helper:
      009E72 12 38 8D         [24] 1218 	lcall	_ak820_outline_0108
      009E75 90 0C 01         [24] 1219 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009E78 12 38 88         [24] 1220 	lcall	_ak820_outline_0107
                                   1221 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009E7B 90 0B FE         [24] 1222 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009E7E 12 38 41         [24] 1223 	lcall	_ak820_outline_0051
                                   1224 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009E81 90 0C 01         [24] 1225 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009E84 12 38 58         [24] 1226 	lcall	_ak820_outline_0059
      009E87 90 0B BC         [24] 1227 	mov	dptr,#_process_last_key_PARM_2
      009E8A 12 9F BF         [24] 1228 	lcall	_ak820_outline_0002
      009E8D C0 07            [24] 1229 	push	ar7
      009E8F C0 06            [24] 1230 	push	ar6
      009E91 C0 05            [24] 1231 	push	ar5
      009E93 C0 04            [24] 1232 	push	ar4
      009E95 12 99 A6         [24] 1233 	lcall	_process_last_key
      009E98 E5 82            [12] 1234 	mov	a, dpl
      009E9A D0 04            [24] 1235 	pop	ar4
      009E9C D0 05            [24] 1236 	pop	ar5
      009E9E D0 06            [24] 1237 	pop	ar6
      009EA0 D0 07            [24] 1238 	pop	ar7
      009EA2 70 03            [24] 1239 	jnz	00196$
      009EA4 02 9F 7B         [24] 1240 	ljmp	00101$
      009EA7                       1241 00196$:
      009EA7 90 0B C2         [24] 1242 	mov	dptr,#_process_repeat_key_PARM_2
      009EAA 12 9F BF         [24] 1243 	lcall	_ak820_outline_0002
      009EAD C0 07            [24] 1244 	push	ar7
      009EAF C0 06            [24] 1245 	push	ar6
      009EB1 C0 05            [24] 1246 	push	ar5
      009EB3 C0 04            [24] 1247 	push	ar4
      009EB5 12 9A 24         [24] 1248 	lcall	_process_repeat_key
      009EB8 E5 82            [12] 1249 	mov	a, dpl
      009EBA D0 04            [24] 1250 	pop	ar4
      009EBC D0 05            [24] 1251 	pop	ar5
      009EBE D0 06            [24] 1252 	pop	ar6
      009EC0 D0 07            [24] 1253 	pop	ar7
      009EC2 70 03            [24] 1254 	jnz	00197$
      009EC4 02 9F 7B         [24] 1255 	ljmp	00101$
      009EC7                       1256 00197$:
                                   1257 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      009EC7 90 0C 3E         [24] 1258 	mov	dptr,#_process_record_via_PARM_2
      009ECA 12 9F BF         [24] 1259 	lcall	_ak820_outline_0002
      009ECD C0 07            [24] 1260 	push	ar7
      009ECF C0 06            [24] 1261 	push	ar6
      009ED1 C0 05            [24] 1262 	push	ar5
      009ED3 C0 04            [24] 1263 	push	ar4
      009ED5 12 A4 D0         [24] 1264 	lcall	_process_record_via
      009ED8 E5 82            [12] 1265 	mov	a, dpl
      009EDA D0 04            [24] 1266 	pop	ar4
      009EDC D0 05            [24] 1267 	pop	ar5
      009EDE D0 06            [24] 1268 	pop	ar6
      009EE0 D0 07            [24] 1269 	pop	ar7
      009EE2 70 03            [24] 1270 	jnz	00198$
      009EE4 02 9F 7B         [24] 1271 	ljmp	00101$
      009EE7                       1272 00198$:
                                   1273 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      009EE7 90 0B E1         [24] 1274 	mov	dptr,#_process_record_kb_PARM_2
      009EEA 12 9F BF         [24] 1275 	lcall	_ak820_outline_0002
      009EED C0 07            [24] 1276 	push	ar7
      009EEF C0 06            [24] 1277 	push	ar6
      009EF1 C0 05            [24] 1278 	push	ar5
      009EF3 C0 04            [24] 1279 	push	ar4
      009EF5 12 9D 1C         [24] 1280 	lcall	_process_record_kb
      009EF8 E5 82            [12] 1281 	mov	a, dpl
      009EFA D0 04            [24] 1282 	pop	ar4
      009EFC D0 05            [24] 1283 	pop	ar5
      009EFE D0 06            [24] 1284 	pop	ar6
      009F00 D0 07            [24] 1285 	pop	ar7
      009F02 70 03            [24] 1286 	jnz	00199$
      009F04 02 9F 7B         [24] 1287 	ljmp	00101$
      009F07                       1288 00199$:
                                   1289 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      009F07 90 0B A4         [24] 1290 	mov	dptr,#_process_caps_word_PARM_2
      009F0A 12 9F BF         [24] 1291 	lcall	_ak820_outline_0002
      009F0D C0 07            [24] 1292 	push	ar7
      009F0F C0 06            [24] 1293 	push	ar6
      009F11 C0 05            [24] 1294 	push	ar5
      009F13 C0 04            [24] 1295 	push	ar4
      009F15 12 97 2D         [24] 1296 	lcall	_process_caps_word
      009F18 E5 82            [12] 1297 	mov	a, dpl
      009F1A D0 04            [24] 1298 	pop	ar4
      009F1C D0 05            [24] 1299 	pop	ar5
      009F1E D0 06            [24] 1300 	pop	ar6
      009F20 D0 07            [24] 1301 	pop	ar7
      009F22 60 57            [24] 1302 	jz	00101$
                                   1303 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      009F24 90 0B A9         [24] 1304 	mov	dptr,#_process_grave_esc_PARM_2
      009F27 12 9F BF         [24] 1305 	lcall	_ak820_outline_0002
      009F2A C0 07            [24] 1306 	push	ar7
      009F2C C0 06            [24] 1307 	push	ar6
      009F2E C0 05            [24] 1308 	push	ar5
      009F30 C0 04            [24] 1309 	push	ar4
      009F32 12 98 40         [24] 1310 	lcall	_process_grave_esc
      009F35 E5 82            [12] 1311 	mov	a, dpl
      009F37 D0 04            [24] 1312 	pop	ar4
      009F39 D0 05            [24] 1313 	pop	ar5
      009F3B D0 06            [24] 1314 	pop	ar6
      009F3D D0 07            [24] 1315 	pop	ar7
      009F3F 60 3A            [24] 1316 	jz	00101$
                                   1317 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      009F41 90 0B C7         [24] 1318 	mov	dptr,#_process_rgb_PARM_2
      009F44 12 9F BF         [24] 1319 	lcall	_ak820_outline_0002
      009F47 C0 07            [24] 1320 	push	ar7
      009F49 C0 06            [24] 1321 	push	ar6
      009F4B C0 05            [24] 1322 	push	ar5
      009F4D C0 04            [24] 1323 	push	ar4
      009F4F 12 9A 7E         [24] 1324 	lcall	_process_rgb
      009F52 E5 82            [12] 1325 	mov	a, dpl
      009F54 D0 04            [24] 1326 	pop	ar4
      009F56 D0 05            [24] 1327 	pop	ar5
      009F58 D0 06            [24] 1328 	pop	ar6
      009F5A D0 07            [24] 1329 	pop	ar7
      009F5C 60 1D            [24] 1330 	jz	00101$
                                   1331 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      009F5E 90 0B CD         [24] 1332 	mov	dptr,#_process_tri_layer_PARM_2
      009F61 12 9F BF         [24] 1333 	lcall	_ak820_outline_0002
      009F64 C0 07            [24] 1334 	push	ar7
      009F66 C0 06            [24] 1335 	push	ar6
      009F68 C0 05            [24] 1336 	push	ar5
      009F6A C0 04            [24] 1337 	push	ar4
      009F6C 12 9B 2F         [24] 1338 	lcall	_process_tri_layer
      009F6F E5 82            [12] 1339 	mov	a, dpl
      009F71 D0 04            [24] 1340 	pop	ar4
      009F73 D0 05            [24] 1341 	pop	ar5
      009F75 D0 06            [24] 1342 	pop	ar6
      009F77 D0 07            [24] 1343 	pop	ar7
      009F79 70 04            [24] 1344 	jnz	00102$
                                   1345 ;	quantum/quantum.c:526: true)) {
      009F7B                       1346 00101$:
                                   1347 ;	quantum/quantum.c:527: return false;
      009F7B 75 82 00         [24] 1348 	mov	dpl, #0x00
      009F7E 22               [24] 1349 	ret
      009F7F                       1350 00102$:
                                   1351 ;	quantum/quantum.c:530: if (record->event.pressed) {
      009F7F 74 05            [12] 1352 	mov	a,#0x05
      009F81 12 47 F9         [24] 1353 	lcall	_ak820_outline_0031
      009F84 60 30            [24] 1354 	jz	00116$
                                   1355 ;	quantum/quantum.c:531: switch (keycode) {
      009F86 BC 00 05         [24] 1356 	cjne	r4,#0x00,00205$
      009F89 BD 7C 02         [24] 1357 	cjne	r5,#0x7c,00205$
      009F8C 80 10            [24] 1358 	sjmp	00111$
      009F8E                       1359 00205$:
      009F8E BC 01 05         [24] 1360 	cjne	r4,#0x01,00206$
      009F91 BD 7C 02         [24] 1361 	cjne	r5,#0x7c,00206$
      009F94 80 0F            [24] 1362 	sjmp	00112$
      009F96                       1363 00206$:
                                   1364 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      009F96 BC 03 1D         [24] 1365 	cjne	r4,#0x03,00116$
      009F99 BD 7C 1A         [24] 1366 	cjne	r5,#0x7c,00116$
      009F9C 80 0E            [24] 1367 	sjmp	00113$
      009F9E                       1368 00111$:
                                   1369 ;	quantum/quantum.c:534: reset_keyboard();
      009F9E 12 9D 72         [24] 1370 	lcall	_reset_keyboard
                                   1371 ;	quantum/quantum.c:535: return false;
      009FA1 75 82 00         [24] 1372 	mov	dpl, #0x00
                                   1373 ;	quantum/quantum.c:536: case QK_REBOOT:
      009FA4 22               [24] 1374 	ret
      009FA5                       1375 00112$:
                                   1376 ;	quantum/quantum.c:537: soft_reset_keyboard();
      009FA5 12 9D 78         [24] 1377 	lcall	_soft_reset_keyboard
                                   1378 ;	quantum/quantum.c:538: return false;
      009FA8 75 82 00         [24] 1379 	mov	dpl, #0x00
                                   1380 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      009FAB 22               [24] 1381 	ret
      009FAC                       1382 00113$:
                                   1383 ;	quantum/quantum.c:557: eeconfig_disable();
      009FAC 12 8E 99         [24] 1384 	lcall	_eeconfig_disable
                                   1385 ;	quantum/quantum.c:558: soft_reset_keyboard();
      009FAF 12 9D 78         [24] 1386 	lcall	_soft_reset_keyboard
                                   1387 ;	quantum/quantum.c:560: return false;
      009FB2 75 82 00         [24] 1388 	mov	dpl, #0x00
                                   1389 ;	quantum/quantum.c:615: }
      009FB5 22               [24] 1390 	ret
      009FB6                       1391 00116$:
                                   1392 ;	quantum/quantum.c:618: return process_action_kb(record);
      009FB6 7D 00            [12] 1393 	mov	r5,#0x00
      009FB8 12 6E F3         [24] 1394 	lcall	_ak820_outline_0064
                                   1395 ;	quantum/quantum.c:619: }
      009FBB 02 9D 18         [24] 1396 	ljmp	_process_action_kb
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1399 ;------------------------------------------------------------
                                   1400 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_668'
                                   1401 ;------------------------------------------------------------
                                   1402 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1403 ;	-----------------------------------------
                                   1404 ;	 function shutdown_user
                                   1405 ;	-----------------------------------------
      009FBE                       1406 _shutdown_user:
      009FBE 22               [24] 1407 	ret
                                   1408 ;------------------------------------------------------------
                                   1409 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1410 ;------------------------------------------------------------
                                   1411 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1412 ;	-----------------------------------------
                                   1413 	.area CSEG    (CODE)
                                   1414 	.area CONST   (CODE)
                                   1415 	.area XINIT   (CODE)
                                   1416 	.area CABS    (ABS,CODE)
                                   1417 
                                   1418 ; Experimental exact instruction outlining.
                                   1419 	.globl _ak820_outline_0002
                                   1420 	.globl _ak820_outline_0005
                                   1421 	.globl _ak820_outline_0007
                                   1422 	.globl _ak820_outline_0009
                                   1423 	.globl _ak820_outline_0011
                                   1424 	.globl _ak820_outline_0014
                                   1425 	.globl _ak820_outline_0016
                                   1426 	.globl _ak820_outline_0021
                                   1427 	.globl _ak820_outline_0023
                                   1428 	.globl _ak820_outline_0026
                                   1429 	.globl _ak820_outline_0031
                                   1430 	.globl _ak820_outline_0033
                                   1431 	.globl _ak820_outline_0037
                                   1432 	.globl _ak820_outline_0040
                                   1433 	.globl _ak820_outline_0051
                                   1434 	.globl _ak820_outline_0059
                                   1435 	.globl _ak820_outline_0064
                                   1436 	.globl _ak820_outline_0071
                                   1437 	.globl _ak820_outline_0107
                                   1438 	.globl _ak820_outline_0108
                                   1439 	.globl _ak820_outline_0117
                                   1440 	.globl _ak820_outline_0119
                                   1441 	.globl _ak820_outline_0122
                                   1442 	.globl _ak820_outline_0124
                                   1443 	.globl _ak820_outline_0133
                                   1444 	.globl _ak820_outline_0142
                                   1445 	.globl _ak820_outline_0150
                                   1446 	.globl _ak820_outline_0157
                                   1447 
                                   1448 	.area CSEG (CODE)
                                   1449 ; function ak820_outline_0002
      009FBF                       1450 _ak820_outline_0002:
      009FBF EE               [12] 1451 	mov	a,r6
      009FC0 F0               [24] 1452 	movx	@dptr,a
      009FC1 EF               [12] 1453 	mov	a,r7
      009FC2 A3               [24] 1454 	inc	dptr
      009FC3 F0               [24] 1455 	movx	@dptr,a
      009FC4 E4               [12] 1456 	clr	a
      009FC5 A3               [24] 1457 	inc	dptr
      009FC6 F0               [24] 1458 	movx	@dptr,a
      009FC7 8C 82            [24] 1459 	mov	dpl,r4
      009FC9 8D 83            [24] 1460 	mov	dph,r5
      009FCB 22               [24] 1461 	ret
                                   1462 
                                   1463 	.area CSEG (CODE)
                                   1464 ; function ak820_outline_0009
      009FCC                       1465 _ak820_outline_0009:
      009FCC EB               [12] 1466 	mov	a,r3
      009FCD F0               [24] 1467 	movx	@dptr,a
      009FCE EC               [12] 1468 	mov	a,r4
      009FCF A3               [24] 1469 	inc	dptr
      009FD0 F0               [24] 1470 	movx	@dptr,a
      009FD1 ED               [12] 1471 	mov	a,r5
      009FD2 A3               [24] 1472 	inc	dptr
      009FD3 F0               [24] 1473 	movx	@dptr,a
      009FD4 8E 82            [24] 1474 	mov	dpl,r6
      009FD6 8F 83            [24] 1475 	mov	dph,r7
      009FD8 22               [24] 1476 	ret
