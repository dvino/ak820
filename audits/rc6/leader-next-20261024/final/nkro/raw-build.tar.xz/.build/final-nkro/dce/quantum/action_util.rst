                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000963                        580 _owned_mod_refs:
      000963                        581 	.ds 8
      00096B                        582 _owned_weak_refs:
      00096B                        583 	.ds 8
      000973                        584 _owned_mods:
      000973                        585 	.ds 1
      000974                        586 _owned_weak_mods:
      000974                        587 	.ds 1
      000975                        588 _macro_mods:
      000975                        589 	.ds 2
      000977                        590 _ak820_macro_primitive::
      000977                        591 	.ds 1
      000978                        592 _ak820_macro_cancelled::
      000978                        593 	.ds 1
      000979                        594 _ak820_macro_change_PARM_2:
      000979                        595 	.ds 1
      00097A                        596 _ak820_macro_change_PARM_3:
      00097A                        597 	.ds 1
      00097B                        598 _ak820_macro_change_bits_10000_293:
      00097B                        599 	.ds 2
      00097D                        600 _change_owned_PARM_2:
      00097D                        601 	.ds 1
      00097E                        602 _change_owned_mods_10000_298:
      00097E                        603 	.ds 1
      00097F                        604 _change_owned_result_10001_302:
      00097F                        605 	.ds 1
      000980                        606 _change_owned_bit_20001_303:
      000980                        607 	.ds 1
      000981                        608 _add_owned_mods_mods_10000_311:
      000981                        609 	.ds 1
      000982                        610 _del_owned_mods_mods_10000_313:
      000982                        611 	.ds 1
      000983                        612 _add_owned_weak_mods_mods_10000_315:
      000983                        613 	.ds 1
      000984                        614 _del_owned_weak_mods_mods_10000_317:
      000984                        615 	.ds 1
      000985                        616 _key_refs:
      000985                        617 	.ds 165
      000A2A                        618 _distinct_keys:
      000A2A                        619 	.ds 1
      000A2B                        620 _macro_keys:
      000A2B                        621 	.ds 21
      000A40                        622 _add_owned_key_code_10000_326:
      000A40                        623 	.ds 1
      000A41                        624 _del_owned_key_code_10000_341:
      000A41                        625 	.ds 1
      000A42                        626 _usage_refs:
      000A42                        627 	.ds 30
      000A60                        628 _usage_order:
      000A60                        629 	.ds 30
      000A7E                        630 _usage_lengths:
      000A7E                        631 	.ds 2
      000A80                        632 _macro_usages:
      000A80                        633 	.ds 4
      000A84                        634 _owned_usage_key_PARM_2:
      000A84                        635 	.ds 1
      000A85                        636 _owned_usage_key_code_10000_368:
      000A85                        637 	.ds 1
      000A86                        638 _owned_usage_key___200000085_20000_369:
      000A86                        639 	.ds 2
      000A88                        640 _owned_usage_key_which_10000_369:
      000A88                        641 	.ds 1
      000A89                        642 _owned_usage_key_count_10000_369:
      000A89                        643 	.ds 1
      000A8A                        644 _owned_usage_key_pos_30001_376:
      000A8A                        645 	.ds 1
      000A8B                        646 _owned_usage_key_key_40000_381:
      000A8B                        647 	.ds 1
      000A8C                        648 _send_keyboard_report_last_report_10001_388:
      000A8C                        649 	.ds 32
      000AAC                        650 _send_keyboard_report_changed_10001_388:
      000AAC                        651 	.ds 1
      000AAD                        652 _add_weak_mods_mods_10000_406:
      000AAD                        653 	.ds 1
      000AAE                        654 _del_weak_mods_mods_10000_408:
      000AAE                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DB3                        664 _real_mods:
      000DB3                        665 	.ds 1
      000DB4                        666 _weak_mods:
      000DB4                        667 	.ds 1
      000DB5                        668 _actual_keyboard_report::
      000DB5                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007883                        713 _ak820_macro_change:
      007883 12 38 88         [24]  714 	lcall	_ak820_outline_0104
      007886 90 09 7B         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007889 12 38 83         [24]  716 	lcall	_ak820_outline_0103
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      00788C 90 09 77         [24]  718 	mov	dptr,#_ak820_macro_primitive
      00788F E0               [24]  719 	movx	a,@dptr
      007890 70 04            [24]  720 	jnz	00102$
      007892 75 82 01         [24]  721 	mov	dpl, #0x01
      007895 22               [24]  722 	ret
      007896                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007896 90 09 79         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007899 E0               [24]  726 	movx	a,@dptr
      00789A FF               [12]  727 	mov	r7,a
      00789B 74 07            [12]  728 	mov	a,#0x07
      00789D 5F               [12]  729 	anl	a,r7
      00789E 12 74 24         [24]  730 	lcall	_ak820_outline_0061
      0078A1 80 02            [24]  731 	sjmp	00123$
      0078A3                        732 00122$:
      0078A3 25 E0            [12]  733 	add	a,acc
      0078A5                        734 00123$:
      0078A5 D5 F0 FB         [24]  735 	djnz	b,00122$
      0078A8 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      0078A9 EF               [12]  738 	mov	a,r7
      0078AA 12 55 6E         [24]  739 	lcall	_ak820_outline_0181
      0078AD FF               [12]  740 	mov	r7,a
      0078AE 90 09 7B         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078B1 12 38 59         [24]  742 	lcall	_ak820_outline_0058
      0078B4 90 09 7B         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078B7 EF               [12]  744 	mov	a,r7
      0078B8 2C               [12]  745 	add	a, r4
      0078B9 F0               [24]  746 	movx	@dptr,a
      0078BA E4               [12]  747 	clr	a
      0078BB 3D               [12]  748 	addc	a, r5
      0078BC A3               [24]  749 	inc	dptr
      0078BD F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      0078BE 90 09 7B         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078C1 E0               [24]  753 	movx	a,@dptr
      0078C2 FD               [12]  754 	mov	r5,a
      0078C3 A3               [24]  755 	inc	dptr
      0078C4 E0               [24]  756 	movx	a,@dptr
      0078C5 FF               [12]  757 	mov	r7,a
      0078C6 12 7E 09         [24]  758 	lcall	_ak820_outline_0182
      0078C9 E0               [24]  759 	movx	a,@dptr
      0078CA FC               [12]  760 	mov	r4,a
      0078CB EE               [12]  761 	mov	a,r6
      0078CC 5C               [12]  762 	anl	a,r4
      0078CD B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      0078D0                        764 00124$:
      0078D0 B3               [12]  765 	cpl	c
      0078D1 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      0078D3 90 09 7A         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      0078D6 E0               [24]  768 	movx	a,@dptr
      0078D7 FB               [12]  769 	mov	r3,a
      0078D8 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      0078DA E4               [12]  771 	clr	a
      0078DB 33               [12]  772 	rlc	a
      0078DC B5 03 04         [24]  773 	cjne	a,ar3,00104$
      0078DF 75 82 00         [24]  774 	mov	dpl, #0x00
      0078E2 22               [24]  775 	ret
      0078E3                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      0078E3 EC               [12]  778 	mov	a,r4
      0078E4 62 06            [12]  779 	xrl	ar6,a
      0078E6 12 7E 09         [24]  780 	lcall	_ak820_outline_0182
      0078E9 EE               [12]  781 	mov	a,r6
      0078EA F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      0078EB 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      0078EE 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      0078EF                        805 _change_owned:
      0078EF E5 82            [12]  806 	mov	a,dpl
      0078F1 90 09 7E         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      0078F4 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      0078F5 90 09 7D         [24]  810 	mov	dptr,#_change_owned_PARM_2
      0078F8 E0               [24]  811 	movx	a,@dptr
      0078F9 FF               [12]  812 	mov	r7,a
      0078FA C3               [12]  813 	clr	c
      0078FB 13               [12]  814 	rrc	a
      0078FC FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      0078FD 53 07 01         [24]  817 	anl	ar7,#0x01
      007900 EF               [12]  818 	mov	a,r7
      007901 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007904                        820 00205$:
      007904 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007906 B3               [12]  822 	cpl	c
      007907 E4               [12]  823 	clr	a
      007908 33               [12]  824 	rlc	a
      007909 F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00790B EE               [12]  827 	mov	a,r6
      00790C 60 06            [24]  828 	jz	00121$
      00790E 7D 6B            [12]  829 	mov	r5,#_owned_weak_refs
      007910 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007912 80 04            [24]  831 	sjmp	00122$
      007914                        832 00121$:
      007914 7D 63            [12]  833 	mov	r5,#_owned_mod_refs
      007916 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007918                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007918 90 09 77         [24]  837 	mov	dptr,#_ak820_macro_primitive
      00791B E0               [24]  838 	movx	a,@dptr
      00791C 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      00791E EE               [12]  841 	mov	a,r6
      00791F 24 75            [12]  842 	add	a, #_macro_mods
      007921 FB               [12]  843 	mov	r3,a
      007922 E4               [12]  844 	clr	a
      007923 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007925 12 46 CE         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007928 E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      00792A 60 0A            [24]  849 	jz	00123$
      00792C 90 09 7E         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      00792F E0               [24]  851 	movx	a,@dptr
      007930 F9               [12]  852 	mov	r1,a
      007931 EA               [12]  853 	mov	a,r2
      007932 42 01            [12]  854 	orl	ar1,a
      007934 80 07            [24]  855 	sjmp	00124$
      007936                        856 00123$:
      007936 90 09 7E         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007939 E0               [24]  858 	movx	a,@dptr
      00793A F4               [12]  859 	cpl	a
      00793B 5A               [12]  860 	anl	a,r2
      00793C F9               [12]  861 	mov	r1,a
      00793D                        862 00124$:
      00793D 12 33 FC         [24]  863 	lcall	_ak820_outline_0119
      007940 E9               [12]  864 	mov	a,r1
      007941 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007942 E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007944 60 06            [24]  868 	jz	00125$
      007946 74 FF            [12]  869 	mov	a,#0xff
      007948 6A               [12]  870 	xrl	a,r2
      007949 FC               [12]  871 	mov	r4,a
      00794A 80 02            [24]  872 	sjmp	00126$
      00794C                        873 00125$:
      00794C 8A 04            [24]  874 	mov	ar4,r2
      00794E                        875 00126$:
      00794E 90 09 7E         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007951 E0               [24]  877 	movx	a,@dptr
      007952 5C               [12]  878 	anl	a,r4
      007953 F0               [24]  879 	movx	@dptr,a
      007954                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      007954 90 09 7F         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007957 E4               [12]  883 	clr	a
      007958 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007959 90 09 80         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      00795C 04               [12]  887 	inc	a
      00795D F0               [24]  888 	movx	@dptr,a
      00795E 90 09 7E         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007961 E0               [24]  890 	movx	a,@dptr
      007962 FC               [12]  891 	mov	r4,a
      007963 7B 00            [12]  892 	mov	r3,#0x00
      007965                        893 00117$:
      007965 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007968                        895 00210$:
      007968 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      00796A 90 09 80         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      00796D E0               [24]  899 	movx	a,@dptr
      00796E 5C               [12]  900 	anl	a,r4
      00796F 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007971 E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007973 60 0C            [24]  904 	jz	00106$
      007975 EB               [12]  905 	mov	a,r3
      007976 2D               [12]  906 	add	a, r5
      007977 12 38 20         [24]  907 	lcall	_ak820_outline_0014
      00797A F8               [12]  908 	mov	r0,a
      00797B 08               [12]  909 	inc	r0
      00797C 12 7D BD         [24]  910 	lcall	_ak820_outline_0062
      00797F 80 0C            [24]  911 	sjmp	00109$
      007981                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007981 EB               [12]  914 	mov	a,r3
      007982 2D               [12]  915 	add	a, r5
      007983 12 38 20         [24]  916 	lcall	_ak820_outline_0014
      007986 F8               [12]  917 	mov	r0,a
      007987 60 04            [24]  918 	jz	00109$
      007989 18               [12]  919 	dec	r0
      00798A 12 7D BD         [24]  920 	lcall	_ak820_outline_0062
      00798D                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      00798D EB               [12]  923 	mov	a,r3
      00798E 2D               [12]  924 	add	a, r5
      00798F 12 38 20         [24]  925 	lcall	_ak820_outline_0014
      007992 60 0B            [24]  926 	jz	00118$
      007994 90 09 80         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007997 E0               [24]  928 	movx	a,@dptr
      007998 FA               [12]  929 	mov	r2,a
      007999 90 09 7F         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      00799C E0               [24]  931 	movx	a,@dptr
      00799D 4A               [12]  932 	orl	a,r2
      00799E F0               [24]  933 	movx	@dptr,a
      00799F                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00799F 0B               [12]  936 	inc	r3
      0079A0 90 09 80         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      0079A3 E0               [24]  938 	movx	a,@dptr
      0079A4 25 E0            [12]  939 	add	a,acc
      0079A6 F0               [24]  940 	movx	@dptr,a
      0079A7 80 BC            [24]  941 	sjmp	00117$
      0079A9                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0079A9 EE               [12]  944 	mov	a,r6
      0079AA 60 09            [24]  945 	jz	00114$
      0079AC 90 09 7F         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      0079AF E0               [24]  947 	movx	a,@dptr
      0079B0 90 09 74         [24]  948 	mov	dptr,#_owned_weak_mods
      0079B3 F0               [24]  949 	movx	@dptr,a
      0079B4 22               [24]  950 	ret
      0079B5                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      0079B5 90 09 7F         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      0079B8 E0               [24]  954 	movx	a,@dptr
      0079B9 90 09 73         [24]  955 	mov	dptr,#_owned_mods
      0079BC F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      0079BD 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0079BE                        968 _add_owned_mods:
      0079BE E5 82            [12]  969 	mov	a,dpl
      0079C0 90 09 81         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      0079C3 12 7D DD         [24]  971 	lcall	_ak820_outline_0111
      0079C6 74 01            [12]  972 	mov	a,#0x01
      0079C8 F0               [24]  973 	movx	@dptr,a
      0079C9 8F 82            [24]  974 	mov	dpl, r7
      0079CB 02 78 EF         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      0079CE                        985 _del_owned_mods:
      0079CE E5 82            [12]  986 	mov	a,dpl
      0079D0 90 09 82         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      0079D3 12 7D DD         [24]  988 	lcall	_ak820_outline_0111
      0079D6 E4               [12]  989 	clr	a
      0079D7 F0               [24]  990 	movx	@dptr,a
      0079D8 8F 82            [24]  991 	mov	dpl, r7
      0079DA 02 78 EF         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      0079DD                       1002 _add_owned_weak_mods:
      0079DD E5 82            [12] 1003 	mov	a,dpl
      0079DF 90 09 83         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      0079E2 12 7D DD         [24] 1005 	lcall	_ak820_outline_0111
      0079E5 74 03            [12] 1006 	mov	a,#0x03
      0079E7 F0               [24] 1007 	movx	@dptr,a
      0079E8 8F 82            [24] 1008 	mov	dpl, r7
      0079EA 02 78 EF         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      0079ED                       1019 _del_owned_weak_mods:
      0079ED E5 82            [12] 1020 	mov	a,dpl
      0079EF 90 09 84         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      0079F2 12 7D DD         [24] 1022 	lcall	_ak820_outline_0111
      0079F5 74 02            [12] 1023 	mov	a,#0x02
      0079F7 F0               [24] 1024 	movx	@dptr,a
      0079F8 8F 82            [24] 1025 	mov	dpl, r7
      0079FA 02 78 EF         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      0079FD                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0079FD 7F 00            [12] 1038 	mov	r7,#0x00
      0079FF                       1039 00103$:
      0079FF BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007A02                       1041 00122$:
      007A02 50 1A            [24] 1042 	jnc	00101$
      007A04 EF               [12] 1043 	mov	a,r7
      007A05 24 63            [12] 1044 	add	a, #_owned_mod_refs
      007A07 FD               [12] 1045 	mov	r5,a
      007A08 E4               [12] 1046 	clr	a
      007A09 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007A0B FE               [12] 1048 	mov	r6,a
      007A0C EF               [12] 1049 	mov	a,r7
      007A0D 24 6B            [12] 1050 	add	a, #_owned_weak_refs
      007A0F F5 82            [12] 1051 	mov	dpl,a
      007A11 E4               [12] 1052 	clr	a
      007A12 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007A14 F5 83            [12] 1054 	mov	dph,a
      007A16 E4               [12] 1055 	clr	a
      007A17 F0               [24] 1056 	movx	@dptr,a
      007A18 12 7D E4         [24] 1057 	lcall	_ak820_outline_0117
      007A1B 0F               [12] 1058 	inc	r7
      007A1C 80 E1            [24] 1059 	sjmp	00103$
      007A1E                       1060 00101$:
                                   1061 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007A1E 90 09 76         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007A21 E4               [12] 1063 	clr	a
      007A22 F0               [24] 1064 	movx	@dptr,a
      007A23 90 09 75         [24] 1065 	mov	dptr,#_macro_mods
      007A26 F0               [24] 1066 	movx	@dptr,a
      007A27 90 09 74         [24] 1067 	mov	dptr,#_owned_weak_mods
      007A2A F0               [24] 1068 	movx	@dptr,a
      007A2B 90 09 73         [24] 1069 	mov	dptr,#_owned_mods
      007A2E F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007A2F 90 09 78         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007A32 04               [12] 1073 	inc	a
      007A33 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:114: }
      007A34 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007A35                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007A35 7F 00            [12] 1089 	mov	r7,#0x00
      007A37                       1090 00104$:
      007A37 EF               [12] 1091 	mov	a,r7
      007A38 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007A3A 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007A3C EF               [12] 1095 	mov	a,r7
      007A3D 24 85            [12] 1096 	add	a, #_key_refs
      007A3F F5 82            [12] 1097 	mov	dpl,a
      007A41 E4               [12] 1098 	clr	a
      007A42 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007A44 12 78 74         [24] 1100 	lcall	_ak820_outline_0157
      007A47 80 EE            [24] 1101 	sjmp	00104$
      007A49                       1102 00101$:
                                   1103 ;	quantum/action_util.c:122: distinct_keys = 0;
      007A49 90 0A 2A         [24] 1104 	mov	dptr,#_distinct_keys
      007A4C E4               [12] 1105 	clr	a
      007A4D F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007A4E FF               [12] 1108 	mov	r7,a
      007A4F                       1109 00107$:
      007A4F BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007A52                       1111 00142$:
      007A52 50 0D            [24] 1112 	jnc	00109$
      007A54 EF               [12] 1113 	mov	a,r7
      007A55 24 2B            [12] 1114 	add	a, #_macro_keys
      007A57 F5 82            [12] 1115 	mov	dpl,a
      007A59 E4               [12] 1116 	clr	a
      007A5A 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007A5C 12 78 74         [24] 1118 	lcall	_ak820_outline_0157
      007A5F 80 EE            [24] 1119 	sjmp	00107$
      007A61                       1120 00109$:
                                   1121 ;	quantum/action_util.c:124: }
      007A61 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007A62                       1137 _add_owned_key:
      007A62 E5 82            [12] 1138 	mov	a,dpl
      007A64 90 0A 40         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007A67 12 7D F5         [24] 1140 	lcall	_ak820_outline_0128
                                   1141 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007A6A 74 01            [12] 1142 	mov	a,#0x01
      007A6C F0               [24] 1143 	movx	@dptr,a
      007A6D 90 0A 2B         [24] 1144 	mov	dptr,#_macro_keys
      007A70 C0 07            [24] 1145 	push	ar7
      007A72 12 78 83         [24] 1146 	lcall	_ak820_macro_change
      007A75 E5 82            [12] 1147 	mov	a, dpl
      007A77 D0 07            [24] 1148 	pop	ar7
      007A79 70 03            [24] 1149 	jnz	00102$
      007A7B F5 82            [12] 1150 	mov	dpl,a
      007A7D 22               [24] 1151 	ret
      007A7E                       1152 00102$:
                                   1153 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007A7E 12 7D AF         [24] 1154 	lcall	_ak820_outline_0029
      007A81 FC               [12] 1155 	mov	r4,a
      007A82 04               [12] 1156 	inc	a
      007A83 12 7D E4         [24] 1157 	lcall	_ak820_outline_0117
      007A86 EC               [12] 1158 	mov	a,r4
      007A87 60 04            [24] 1159 	jz	00104$
      007A89 75 82 00         [24] 1160 	mov	dpl, #0x00
      007A8C 22               [24] 1161 	ret
      007A8D                       1162 00104$:
                                   1163 ;	quantum/action_util.c:128: ++distinct_keys;
      007A8D 90 0A 2A         [24] 1164 	mov	dptr,#_distinct_keys
      007A90 E0               [24] 1165 	movx	a,@dptr
      007A91 24 01            [12] 1166 	add	a, #0x01
      007A93 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007A94 90 0D A2         [24] 1169 	mov	dptr,#_keyboard_protocol
      007A97 E0               [24] 1170 	movx	a,@dptr
      007A98 60 11            [24] 1171 	jz	00106$
      007A9A 90 0A AF         [24] 1172 	mov	dptr,#_keymap_config
      007A9D E0               [24] 1173 	movx	a,@dptr
      007A9E 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007AA1 12 7E 00         [24] 1176 	lcall	_ak820_outline_0171
      007AA4 12 6C D9         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007AA7 75 82 01         [24] 1179 	mov	dpl, #0x01
      007AAA 22               [24] 1180 	ret
      007AAB                       1181 00106$:
                                   1182 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007AAB 90 0A 2A         [24] 1183 	mov	dptr,#_distinct_keys
      007AAE E0               [24] 1184 	movx	a,@dptr
      007AAF 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007AB1 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007AB3 7F 00            [12] 1189 	mov	r7,#0x00
      007AB5                       1190 00115$:
      007AB5 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007AB8                       1192 00174$:
      007AB8 50 1E            [24] 1193 	jnc	00111$
      007ABA EF               [12] 1194 	mov	a,r7
      007ABB 24 B7            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007ABD F5 82            [12] 1196 	mov	dpl,a
      007ABF E4               [12] 1197 	clr	a
      007AC0 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007AC2 F5 83            [12] 1199 	mov	dph,a
      007AC4 74 01            [12] 1200 	mov	a,#0x01
      007AC6 F0               [24] 1201 	movx	@dptr,a
      007AC7 0F               [12] 1202 	inc	r7
      007AC8 80 EB            [24] 1203 	sjmp	00115$
      007ACA                       1204 00110$:
                                   1205 ;	quantum/action_util.c:134: } else add_key(code);
      007ACA 90 0A 40         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007ACD E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007ACE 90 07 F3         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007AD1 F0               [24] 1210 	movx	@dptr,a
      007AD2 90 0D B5         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007AD5 12 6C D9         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:134: } else add_key(code);
      007AD8                       1214 00111$:
                                   1215 ;	quantum/action_util.c:135: return true;
      007AD8 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:136: }
      007ADB 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007ADC                       1235 _del_owned_key:
      007ADC E5 82            [12] 1236 	mov	a,dpl
      007ADE 90 0A 41         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007AE1 12 7D F5         [24] 1238 	lcall	_ak820_outline_0128
                                   1239 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007AE4 E4               [12] 1240 	clr	a
      007AE5 F0               [24] 1241 	movx	@dptr,a
      007AE6 90 0A 2B         [24] 1242 	mov	dptr,#_macro_keys
      007AE9 C0 07            [24] 1243 	push	ar7
      007AEB 12 78 83         [24] 1244 	lcall	_ak820_macro_change
      007AEE E5 82            [12] 1245 	mov	a, dpl
      007AF0 D0 07            [24] 1246 	pop	ar7
      007AF2 70 03            [24] 1247 	jnz	00102$
      007AF4 F5 82            [12] 1248 	mov	dpl,a
      007AF6 22               [24] 1249 	ret
      007AF7                       1250 00102$:
                                   1251 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007AF7 12 7D AF         [24] 1252 	lcall	_ak820_outline_0029
      007AFA FC               [12] 1253 	mov	r4,a
      007AFB 60 09            [24] 1254 	jz	00103$
      007AFD 1C               [12] 1255 	dec	r4
      007AFE 12 38 9C         [24] 1256 	lcall	_ak820_outline_0129
      007B01 EC               [12] 1257 	mov	a,r4
      007B02 F0               [24] 1258 	movx	@dptr,a
      007B03 EC               [12] 1259 	mov	a,r4
      007B04 60 04            [24] 1260 	jz	00104$
      007B06                       1261 00103$:
      007B06 75 82 00         [24] 1262 	mov	dpl, #0x00
      007B09 22               [24] 1263 	ret
      007B0A                       1264 00104$:
                                   1265 ;	quantum/action_util.c:140: --distinct_keys;
      007B0A 90 0A 2A         [24] 1266 	mov	dptr,#_distinct_keys
      007B0D E0               [24] 1267 	movx	a,@dptr
      007B0E 14               [12] 1268 	dec	a
      007B0F F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B10 90 0D A2         [24] 1271 	mov	dptr,#_keyboard_protocol
      007B13 E0               [24] 1272 	movx	a,@dptr
      007B14 60 16            [24] 1273 	jz	00107$
      007B16 90 0A AF         [24] 1274 	mov	dptr,#_keymap_config
      007B19 E0               [24] 1275 	movx	a,@dptr
      007B1A 30 E7 0F         [24] 1276 	jnb	acc.7,00107$
                                   1277 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B1D 90 07 F6         [24] 1278 	mov	dptr,#_del_key_from_report_PARM_2
      007B20 EF               [12] 1279 	mov	a,r7
      007B21 F0               [24] 1280 	movx	@dptr,a
      007B22 90 0D B5         [24] 1281 	mov	dptr,#_actual_keyboard_report
      007B25 12 6D 0F         [24] 1282 	lcall	_del_key_from_report
                                   1283 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B28 75 82 01         [24] 1284 	mov	dpl, #0x01
      007B2B 22               [24] 1285 	ret
      007B2C                       1286 00107$:
                                   1287 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007B2C 90 0A 2A         [24] 1288 	mov	dptr,#_distinct_keys
      007B2F E0               [24] 1289 	movx	a,@dptr
      007B30 FF               [12] 1290 	mov  r7,a
      007B31 24 F9            [12] 1291 	add	a,#0xff - 0x06
      007B33 50 04            [24] 1292 	jnc	00110$
                                   1293 ;	free result
      007B35 75 82 01         [24] 1294 	mov	dpl, #0x01
      007B38 22               [24] 1295 	ret
      007B39                       1296 00110$:
                                   1297 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007B39 BF 06 1F         [24] 1298 	cjne	r7,#0x06,00115$
                                   1299 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B3C 90 0D B5         [24] 1300 	mov	dptr,#_actual_keyboard_report
      007B3F 12 6D 45         [24] 1301 	lcall	_clear_keys_from_report
                                   1302 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B42 7F 04            [12] 1303 	mov	r7,#0x04
      007B44                       1304 00122$:
      007B44 EF               [12] 1305 	mov	a,r7
      007B45 24 5B            [12] 1306 	add	a,#0xff - 0xa4
      007B47 40 20            [24] 1307 	jc	00116$
                                   1308 ;	free result
      007B49 12 7D AF         [24] 1309 	lcall	_ak820_outline_0029
      007B4C 60 0A            [24] 1310 	jz	00123$
                                   1311 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007B4E 12 7E 00         [24] 1312 	lcall	_ak820_outline_0171
      007B51 C0 07            [24] 1313 	push	ar7
      007B53 12 6C D9         [24] 1314 	lcall	_add_key_to_report
      007B56 D0 07            [24] 1315 	pop	ar7
                                   1316 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B58                       1317 00123$:
      007B58 0F               [12] 1318 	inc	r7
      007B59 80 E9            [24] 1319 	sjmp	00122$
      007B5B                       1320 00115$:
                                   1321 ;	quantum/action_util.c:149: } else del_key(code);
      007B5B 90 0A 41         [24] 1322 	mov	dptr,#_del_owned_key_code_10000_341
      007B5E E0               [24] 1323 	movx	a,@dptr
                                   1324 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B5F 90 07 F6         [24] 1325 	mov	dptr,#_del_key_from_report_PARM_2
      007B62 F0               [24] 1326 	movx	@dptr,a
      007B63 90 0D B5         [24] 1327 	mov	dptr,#_actual_keyboard_report
      007B66 12 6D 0F         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:149: } else del_key(code);
      007B69                       1330 00116$:
                                   1331 ;	quantum/action_util.c:150: return true;
      007B69 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:151: }
      007B6C 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007B6D                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007B6D 7F 00            [12] 1347 	mov	r7,#0x00
      007B6F                       1348 00104$:
      007B6F BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007B72                       1350 00141$:
      007B72 50 14            [24] 1351 	jnc	00101$
      007B74 EF               [12] 1352 	mov	a,r7
      007B75 24 42            [12] 1353 	add	a, #_usage_refs
      007B77 FD               [12] 1354 	mov	r5,a
      007B78 E4               [12] 1355 	clr	a
      007B79 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007B7B FE               [12] 1357 	mov	r6,a
      007B7C EF               [12] 1358 	mov	a,r7
      007B7D 12 7D C4         [24] 1359 	lcall	_ak820_outline_0066
      007B80 E4               [12] 1360 	clr	a
      007B81 F0               [24] 1361 	movx	@dptr,a
      007B82 12 7D E4         [24] 1362 	lcall	_ak820_outline_0117
      007B85 0F               [12] 1363 	inc	r7
      007B86 80 E7            [24] 1364 	sjmp	00104$
      007B88                       1365 00101$:
                                   1366 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007B88 90 0A 7F         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007B8B E4               [12] 1368 	clr	a
      007B8C F0               [24] 1369 	movx	@dptr,a
      007B8D 90 0A 7E         [24] 1370 	mov	dptr,#_usage_lengths
      007B90 F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007B91 FF               [12] 1373 	mov	r7,a
      007B92                       1374 00107$:
      007B92 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007B95                       1376 00143$:
      007B95 50 0D            [24] 1377 	jnc	00109$
      007B97 EF               [12] 1378 	mov	a,r7
      007B98 24 80            [12] 1379 	add	a, #_macro_usages
      007B9A F5 82            [12] 1380 	mov	dpl,a
      007B9C E4               [12] 1381 	clr	a
      007B9D 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007B9F 12 78 74         [24] 1383 	lcall	_ak820_outline_0157
      007BA2 80 EE            [24] 1384 	sjmp	00107$
      007BA4                       1385 00109$:
                                   1386 ;	quantum/action_util.c:165: }
      007BA4 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007BA5                       1407 _owned_usage_key:
      007BA5 E5 82            [12] 1408 	mov	a,dpl
      007BA7 90 0A 85         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_368
      007BAA F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007BAB E0               [24] 1412 	movx	a,@dptr
      007BAC FF               [12] 1413 	mov	r7,a
      007BAD BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007BB0                       1415 00244$:
      007BB0 B3               [12] 1416 	cpl	c
      007BB1 92 22            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007BB3 E4               [12] 1418 	clr	a
      007BB4 33               [12] 1419 	rlc	a
      007BB5 FF               [12] 1420 	mov	r7,a
      007BB6 90 0A 88         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_369
      007BB9 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007BBA EF               [12] 1424 	mov	a,r7
      007BBB 60 02            [24] 1425 	jz	00129$
      007BBD 74 03            [12] 1426 	mov	a,#0x03
      007BBF                       1427 00129$:
      007BBF FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007BC0 EF               [12] 1430 	mov	a,r7
      007BC1 24 7E            [12] 1431 	add	a, #_usage_lengths
      007BC3 FD               [12] 1432 	mov	r5,a
      007BC4 E4               [12] 1433 	clr	a
      007BC5 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      007BC7 FF               [12] 1435 	mov	r7,a
      007BC8 12 7E 09         [24] 1436 	lcall	_ak820_outline_0182
      007BCB E0               [24] 1437 	movx	a,@dptr
      007BCC FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007BCD 90 0A 85         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_368
      007BD0 E0               [24] 1441 	movx	a,@dptr
      007BD1 24 5B            [12] 1442 	add	a,#0x5b
      007BD3 FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007BD4 90 0A 84         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      007BD7 E0               [24] 1446 	movx	a,@dptr
      007BD8 FA               [12] 1447 	mov	r2,a
      007BD9 90 09 79         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      007BDC EB               [12] 1449 	mov	a,r3
      007BDD F0               [24] 1450 	movx	@dptr,a
      007BDE 90 09 7A         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      007BE1 EA               [12] 1452 	mov	a,r2
      007BE2 F0               [24] 1453 	movx	@dptr,a
      007BE3 90 0A 80         [24] 1454 	mov	dptr,#_macro_usages
      007BE6 C0 07            [24] 1455 	push	ar7
      007BE8 C0 06            [24] 1456 	push	ar6
      007BEA C0 05            [24] 1457 	push	ar5
      007BEC C0 04            [24] 1458 	push	ar4
      007BEE C0 03            [24] 1459 	push	ar3
      007BF0 C0 02            [24] 1460 	push	ar2
      007BF2 12 78 83         [24] 1461 	lcall	_ak820_macro_change
      007BF5 E5 82            [12] 1462 	mov	a, dpl
      007BF7 D0 02            [24] 1463 	pop	ar2
      007BF9 D0 03            [24] 1464 	pop	ar3
      007BFB D0 04            [24] 1465 	pop	ar4
      007BFD D0 05            [24] 1466 	pop	ar5
      007BFF D0 06            [24] 1467 	pop	ar6
      007C01 D0 07            [24] 1468 	pop	ar7
      007C03 70 01            [24] 1469 	jnz	00102$
      007C05 22               [24] 1470 	ret
      007C06                       1471 00102$:
                                   1472 ;	quantum/action_util.c:172: if (pressed) {
      007C06 EA               [12] 1473 	mov	a,r2
      007C07 60 1B            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007C09 12 7D CE         [24] 1476 	lcall	_ak820_outline_0074
      007C0C 04               [12] 1477 	inc	a
      007C0D 12 6A 58         [24] 1478 	lcall	_ak820_outline_0134
      007C10 E8               [12] 1479 	mov	a,r0
      007C11 60 01            [24] 1480 	jz	00104$
      007C13 22               [24] 1481 	ret
      007C14                       1482 00104$:
                                   1483 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007C14 90 0A 89         [24] 1484 	mov	dptr,#_owned_usage_key_count_10000_369
      007C17 EC               [12] 1485 	mov	a,r4
      007C18 04               [12] 1486 	inc	a
      007C19 F0               [24] 1487 	movx	@dptr,a
      007C1A EC               [12] 1488 	mov	a,r4
      007C1B 2E               [12] 1489 	add	a, r6
      007C1C 12 7D C4         [24] 1490 	lcall	_ak820_outline_0066
      007C1F EB               [12] 1491 	mov	a,r3
      007C20 F0               [24] 1492 	movx	@dptr,a
      007C21 02 7C 85         [24] 1493 	ljmp	00116$
      007C24                       1494 00115$:
                                   1495 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007C24 12 7D CE         [24] 1496 	lcall	_ak820_outline_0074
      007C27 60 07            [24] 1497 	jz	00105$
      007C29 18               [12] 1498 	dec	r0
      007C2A 12 7D BD         [24] 1499 	lcall	_ak820_outline_0062
      007C2D E8               [12] 1500 	mov	a,r0
      007C2E 60 01            [24] 1501 	jz	00106$
      007C30                       1502 00105$:
      007C30 22               [24] 1503 	ret
      007C31                       1504 00106$:
                                   1505 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007C31 7A 00            [12] 1506 	mov	r2,#0x00
      007C33                       1507 00108$:
      007C33 EA               [12] 1508 	mov	a,r2
      007C34 2E               [12] 1509 	add	a, r6
      007C35 12 7D C4         [24] 1510 	lcall	_ak820_outline_0066
      007C38 E0               [24] 1511 	movx	a,@dptr
      007C39 B5 03 02         [24] 1512 	cjne	a,ar3,00251$
      007C3C 80 03            [24] 1513 	sjmp	00167$
      007C3E                       1514 00251$:
      007C3E 0A               [12] 1515 	inc	r2
      007C3F 80 F2            [24] 1516 	sjmp	00108$
      007C41                       1517 00167$:
      007C41 90 0A 8A         [24] 1518 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C44 EA               [12] 1519 	mov	a,r2
      007C45 F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action_util.c:179: --count;
      007C46 1C               [12] 1522 	dec	r4
      007C47 90 0A 89         [24] 1523 	mov	dptr,#_owned_usage_key_count_10000_369
      007C4A EC               [12] 1524 	mov	a,r4
      007C4B F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007C4C 8A 03            [24] 1527 	mov	ar3,r2
      007C4E                       1528 00125$:
      007C4E C3               [12] 1529 	clr	c
      007C4F EB               [12] 1530 	mov	a,r3
      007C50 9C               [12] 1531 	subb	a,r4
      007C51 50 23            [24] 1532 	jnc	00111$
      007C53 C0 05            [24] 1533 	push	ar5
      007C55 C0 07            [24] 1534 	push	ar7
      007C57 EB               [12] 1535 	mov	a,r3
      007C58 2E               [12] 1536 	add	a, r6
      007C59 FA               [12] 1537 	mov	r2,a
      007C5A 24 60            [12] 1538 	add	a, #_usage_order
      007C5C F8               [12] 1539 	mov	r0,a
      007C5D E4               [12] 1540 	clr	a
      007C5E 34 0A            [12] 1541 	addc	a, #(_usage_order >> 8)
      007C60 F9               [12] 1542 	mov	r1,a
      007C61 0A               [12] 1543 	inc	r2
      007C62 EA               [12] 1544 	mov	a,r2
      007C63 33               [12] 1545 	rlc	a
      007C64 95 E0            [12] 1546 	subb	a,acc
      007C66 FF               [12] 1547 	mov	r7,a
      007C67 EA               [12] 1548 	mov	a,r2
      007C68 12 7D EA         [24] 1549 	lcall	_ak820_outline_0122
      007C6B 12 38 B1         [24] 1550 	lcall	_ak820_outline_0151
      007C6E F0               [24] 1551 	movx	@dptr,a
      007C6F 0B               [12] 1552 	inc	r3
      007C70 D0 07            [24] 1553 	pop	ar7
      007C72 D0 05            [24] 1554 	pop	ar5
      007C74 80 D8            [24] 1555 	sjmp	00125$
      007C76                       1556 00111$:
                                   1557 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007C76 12 7E 09         [24] 1558 	lcall	_ak820_outline_0182
      007C79 EC               [12] 1559 	mov	a,r4
      007C7A F0               [24] 1560 	movx	@dptr,a
                                   1561 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007C7B 90 0A 8A         [24] 1562 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C7E E0               [24] 1563 	movx	a,@dptr
      007C7F B5 04 02         [24] 1564 	cjne	a,ar4,00253$
      007C82 80 01            [24] 1565 	sjmp	00116$
      007C84                       1566 00253$:
      007C84 22               [24] 1567 	ret
      007C85                       1568 00116$:
                                   1569 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007C85 90 0A 89         [24] 1570 	mov	dptr,#_owned_usage_key_count_10000_369
      007C88 E0               [24] 1571 	movx	a,@dptr
      007C89 FC               [12] 1572 	mov	r4,a
      007C8A 12 7E 09         [24] 1573 	lcall	_ak820_outline_0182
      007C8D F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007C8E EC               [12] 1576 	mov	a,r4
      007C8F 60 15            [24] 1577 	jz	00131$
      007C91 EC               [12] 1578 	mov	a,r4
      007C92 2E               [12] 1579 	add	a, r6
      007C93 FE               [12] 1580 	mov	r6,a
      007C94 1E               [12] 1581 	dec	r6
      007C95 EE               [12] 1582 	mov	a,r6
      007C96 33               [12] 1583 	rlc	a
      007C97 95 E0            [12] 1584 	subb	a,acc
      007C99 FF               [12] 1585 	mov	r7,a
      007C9A EE               [12] 1586 	mov	a,r6
      007C9B 12 7D EA         [24] 1587 	lcall	_ak820_outline_0122
      007C9E 24 A5            [12] 1588 	add	a,#0xa5
      007CA0 FE               [12] 1589 	mov	r6,a
      007CA1 33               [12] 1590 	rlc	a
      007CA2 95 E0            [12] 1591 	subb	a,acc
      007CA4 80 02            [24] 1592 	sjmp	00132$
      007CA6                       1593 00131$:
      007CA6 7E 00            [12] 1594 	mov	r6,#0x00
      007CA8                       1595 00132$:
      007CA8 90 0A 85         [24] 1596 	mov	dptr,#_owned_usage_key_code_10000_368
      007CAB EE               [12] 1597 	mov	a,r6
      007CAC F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007CAD 90 0A 88         [24] 1600 	mov	dptr,#_owned_usage_key_which_10000_369
      007CB0 E0               [24] 1601 	movx	a,@dptr
      007CB1 60 18            [24] 1602 	jz	00118$
      007CB3 EE               [12] 1603 	mov	a,r6
      007CB4 60 0B            [24] 1604 	jz	00133$
      007CB6 8E 82            [24] 1605 	mov	dpl, r6
      007CB8 12 6B 98         [24] 1606 	lcall	_KEYCODE2CONSUMER
      007CBB AD 82            [24] 1607 	mov	r5, dpl
      007CBD AF 83            [24] 1608 	mov	r7, dph
      007CBF 80 04            [24] 1609 	sjmp	00134$
      007CC1                       1610 00133$:
      007CC1 7D 00            [12] 1611 	mov	r5,#0x00
      007CC3 7F 00            [12] 1612 	mov	r7,#0x00
      007CC5                       1613 00134$:
      007CC5 12 7E 09         [24] 1614 	lcall	_ak820_outline_0182
      007CC8 02 6B 4B         [24] 1615 	ljmp	_host_consumer_send
      007CCB                       1616 00118$:
                                   1617 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007CCB EE               [12] 1618 	mov	a,r6
      007CCC 60 22            [24] 1619 	jz	00135$
                                   1620 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007CCE BE A5 00         [24] 1621 	cjne	r6,#0xa5,00258$
      007CD1                       1622 00258$:
      007CD1 40 05            [24] 1623 	jc	00121$
      007CD3 EE               [12] 1624 	mov	a,r6
      007CD4 24 58            [12] 1625 	add	a,#0xff - 0xa7
      007CD6 50 08            [24] 1626 	jnc	00122$
                                   1627 ;	free result
      007CD8                       1628 00121$:
      007CD8 90 0A 86         [24] 1629 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CDB 12 4D 73         [24] 1630 	lcall	_ak820_outline_0164
      007CDE 80 09            [24] 1631 	sjmp	00123$
      007CE0                       1632 00122$:
                                   1633 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007CE0 74 DC            [12] 1634 	mov	a,#0xdc
      007CE2 2E               [12] 1635 	add	a, r6
      007CE3 90 0A 86         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CE6 12 38 97         [24] 1637 	lcall	_ak820_outline_0121
                                   1638 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007CE9                       1639 00123$:
      007CE9 90 0A 86         [24] 1640 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007CEC E0               [24] 1641 	movx	a,@dptr
      007CED FF               [12] 1642 	mov	r7,a
      007CEE 80 02            [24] 1643 	sjmp	00136$
      007CF0                       1644 00135$:
      007CF0 7F 00            [12] 1645 	mov	r7,#0x00
      007CF2                       1646 00136$:
      007CF2 7E 00            [12] 1647 	mov	r6,#0x00
      007CF4 12 43 71         [24] 1648 	lcall	_ak820_outline_0152
                                   1649 ;	quantum/action_util.c:188: }
      007CF7 02 6B 1B         [24] 1650 	ljmp	_host_system_send
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1653 ;------------------------------------------------------------
                                   1654 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1655 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1656 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1657 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1658 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1659 ;------------------------------------------------------------
                                   1660 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1661 ;	-----------------------------------------
                                   1662 ;	 function send_keyboard_report
                                   1663 ;	-----------------------------------------
      007CFA                       1664 _send_keyboard_report:
                                   1665 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      007CFA 90 0D B3         [24] 1666 	mov	dptr,#_real_mods
      007CFD E0               [24] 1667 	movx	a,@dptr
      007CFE FF               [12] 1668 	mov	r7,a
      007CFF 90 0D B5         [24] 1669 	mov	dptr,#_actual_keyboard_report
      007D02 F0               [24] 1670 	movx	@dptr,a
                                   1671 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      007D03 90 0D B4         [24] 1672 	mov	dptr,#_weak_mods
      007D06 E0               [24] 1673 	movx	a,@dptr
      007D07 42 07            [12] 1674 	orl	ar7,a
      007D09 90 0D B5         [24] 1675 	mov	dptr,#_actual_keyboard_report
      007D0C EF               [12] 1676 	mov	a,r7
      007D0D F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007D0E 90 09 74         [24] 1679 	mov	dptr,#_owned_weak_mods
      007D11 E0               [24] 1680 	movx	a,@dptr
      007D12 FE               [12] 1681 	mov	r6,a
      007D13 90 09 73         [24] 1682 	mov	dptr,#_owned_mods
      007D16 E0               [24] 1683 	movx	a,@dptr
      007D17 4E               [12] 1684 	orl	a,r6
      007D18 42 07            [12] 1685 	orl	ar7,a
      007D1A 90 0D B5         [24] 1686 	mov	dptr,#_actual_keyboard_report
      007D1D EF               [12] 1687 	mov	a,r7
      007D1E F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:455: bool changed = false;
      007D1F 90 0A AC         [24] 1690 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D22 E4               [12] 1691 	clr	a
      007D23 F0               [24] 1692 	movx	@dptr,a
                                   1693 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1694 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1695 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D24 FF               [12] 1696 	mov	r7,a
      007D25                       1697 00107$:
      007D25 BF 20 00         [24] 1698 	cjne	r7,#0x20,00140$
      007D28                       1699 00140$:
      007D28 50 2A            [24] 1700 	jnc	00103$
                                   1701 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      007D2A EF               [12] 1702 	mov	a,r7
      007D2B 24 8C            [12] 1703 	add	a, #_send_keyboard_report_last_report_10001_388
      007D2D FD               [12] 1704 	mov	r5,a
      007D2E E4               [12] 1705 	clr	a
      007D2F 34 0A            [12] 1706 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007D31 12 46 D6         [24] 1707 	lcall	_ak820_outline_0057
      007D34 EF               [12] 1708 	mov	a,r7
      007D35 24 B5            [12] 1709 	add	a, #_actual_keyboard_report
      007D37 F5 82            [12] 1710 	mov	dpl,a
      007D39 E4               [12] 1711 	clr	a
      007D3A 34 0D            [12] 1712 	addc	a, #(_actual_keyboard_report >> 8)
      007D3C F5 83            [12] 1713 	mov	dph,a
      007D3E E0               [24] 1714 	movx	a,@dptr
      007D3F FB               [12] 1715 	mov	r3,a
      007D40 EC               [12] 1716 	mov	a,r4
      007D41 B5 03 02         [24] 1717 	cjne	a,ar3,00142$
      007D44 80 0B            [24] 1718 	sjmp	00108$
      007D46                       1719 00142$:
                                   1720 ;	quantum/action_util.c:465: dest[i] = src[i];
      007D46 12 38 9C         [24] 1721 	lcall	_ak820_outline_0129
      007D49 EB               [12] 1722 	mov	a,r3
      007D4A F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action_util.c:466: changed = true;
      007D4B 90 0A AC         [24] 1725 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D4E 74 01            [12] 1726 	mov	a,#0x01
      007D50 F0               [24] 1727 	movx	@dptr,a
      007D51                       1728 00108$:
                                   1729 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D51 0F               [12] 1730 	inc	r7
      007D52 80 D1            [24] 1731 	sjmp	00107$
      007D54                       1732 00103$:
                                   1733 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      007D54 90 0A AC         [24] 1734 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D57 E0               [24] 1735 	movx	a,@dptr
      007D58 60 09            [24] 1736 	jz	00109$
      007D5A 90 0D B5         [24] 1737 	mov	dptr,#_actual_keyboard_report
      007D5D 75 F0 00         [24] 1738 	mov	b, #0x00
                                   1739 ;	quantum/action_util.c:477: }
      007D60 02 6A 90         [24] 1740 	ljmp	_host_keyboard_send
      007D63                       1741 00109$:
      007D63 22               [24] 1742 	ret
                                   1743 ;------------------------------------------------------------
                                   1744 ;Allocation info for local variables in function 'get_mods'
                                   1745 ;------------------------------------------------------------
                                   1746 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1747 ;	-----------------------------------------
                                   1748 ;	 function get_mods
                                   1749 ;	-----------------------------------------
      007D64                       1750 _get_mods:
      007D64 C0 07            [24] 1751 	push	ar7
                                   1752 ;	quantum/action_util.c:488: ;
      007D66 90 09 73         [24] 1753 	mov	dptr,#_owned_mods
      007D69 E0               [24] 1754 	movx	a,@dptr
      007D6A FF               [12] 1755 	mov	r7,a
      007D6B 90 0D B3         [24] 1756 	mov	dptr,#_real_mods
      007D6E 12 78 6E         [24] 1757 	lcall	_ak820_outline_0136
                                   1758 ;	quantum/action_util.c:489: }
      007D71 D0 07            [24] 1759 	pop	ar7
      007D73 22               [24] 1760 	ret
                                   1761 ;------------------------------------------------------------
                                   1762 ;Allocation info for local variables in function 'add_mods'
                                   1763 ;------------------------------------------------------------
                                   1764 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function clear_mods
                                   1769 ;	-----------------------------------------
      007D74                       1770 _clear_mods:
                                   1771 ;	quantum/action_util.c:516: real_mods = 0;
      007D74 90 0D B3         [24] 1772 	mov	dptr,#_real_mods
      007D77 E4               [12] 1773 	clr	a
      007D78 F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	quantum/action_util.c:517: }
      007D79 22               [24] 1776 	ret
                                   1777 ;------------------------------------------------------------
                                   1778 ;Allocation info for local variables in function 'get_weak_mods'
                                   1779 ;------------------------------------------------------------
                                   1780 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1781 ;	-----------------------------------------
                                   1782 ;	 function get_weak_mods
                                   1783 ;	-----------------------------------------
      007D7A                       1784 _get_weak_mods:
      007D7A C0 07            [24] 1785 	push	ar7
                                   1786 ;	quantum/action_util.c:528: ;
      007D7C 90 09 74         [24] 1787 	mov	dptr,#_owned_weak_mods
      007D7F E0               [24] 1788 	movx	a,@dptr
      007D80 FF               [12] 1789 	mov	r7,a
      007D81 90 0D B4         [24] 1790 	mov	dptr,#_weak_mods
      007D84 12 78 6E         [24] 1791 	lcall	_ak820_outline_0136
                                   1792 ;	quantum/action_util.c:529: }
      007D87 D0 07            [24] 1793 	pop	ar7
      007D89 22               [24] 1794 	ret
                                   1795 ;------------------------------------------------------------
                                   1796 ;Allocation info for local variables in function 'add_weak_mods'
                                   1797 ;------------------------------------------------------------
                                   1798 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1799 ;------------------------------------------------------------
                                   1800 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1801 ;	-----------------------------------------
                                   1802 ;	 function add_weak_mods
                                   1803 ;	-----------------------------------------
      007D8A                       1804 _add_weak_mods:
      007D8A E5 82            [12] 1805 	mov	a,dpl
      007D8C 90 0A AD         [24] 1806 	mov	dptr,#_add_weak_mods_mods_10000_406
      007D8F F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:535: weak_mods |= mods;
      007D90 E0               [24] 1809 	movx	a,@dptr
      007D91 FF               [12] 1810 	mov	r7,a
      007D92 90 0D B4         [24] 1811 	mov	dptr,#_weak_mods
      007D95 E0               [24] 1812 	movx	a,@dptr
      007D96 4F               [12] 1813 	orl	a,r7
      007D97 F0               [24] 1814 	movx	@dptr,a
                                   1815 ;	quantum/action_util.c:536: }
      007D98 22               [24] 1816 	ret
                                   1817 ;------------------------------------------------------------
                                   1818 ;Allocation info for local variables in function 'del_weak_mods'
                                   1819 ;------------------------------------------------------------
                                   1820 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1821 ;------------------------------------------------------------
                                   1822 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1823 ;	-----------------------------------------
                                   1824 ;	 function del_weak_mods
                                   1825 ;	-----------------------------------------
      007D99                       1826 _del_weak_mods:
      007D99 E5 82            [12] 1827 	mov	a,dpl
      007D9B 90 0A AE         [24] 1828 	mov	dptr,#_del_weak_mods_mods_10000_408
      007D9E F0               [24] 1829 	movx	@dptr,a
                                   1830 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      007D9F E0               [24] 1831 	movx	a,@dptr
      007DA0 F4               [12] 1832 	cpl	a
      007DA1 FF               [12] 1833 	mov	r7,a
      007DA2 90 0D B4         [24] 1834 	mov	dptr,#_weak_mods
      007DA5 E0               [24] 1835 	movx	a,@dptr
      007DA6 5F               [12] 1836 	anl	a,r7
      007DA7 F0               [24] 1837 	movx	@dptr,a
                                   1838 ;	quantum/action_util.c:543: }
      007DA8 22               [24] 1839 	ret
                                   1840 ;------------------------------------------------------------
                                   1841 ;Allocation info for local variables in function 'set_weak_mods'
                                   1842 ;------------------------------------------------------------
                                   1843 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1844 ;------------------------------------------------------------
                                   1845 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1846 ;	-----------------------------------------
                                   1847 ;	 function clear_weak_mods
                                   1848 ;	-----------------------------------------
      007DA9                       1849 _clear_weak_mods:
                                   1850 ;	quantum/action_util.c:556: weak_mods = 0;
      007DA9 90 0D B4         [24] 1851 	mov	dptr,#_weak_mods
      007DAC E4               [12] 1852 	clr	a
      007DAD F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/action_util.c:557: }
      007DAE 22               [24] 1855 	ret
                                   1856 ;------------------------------------------------------------
                                   1857 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1858 ;------------------------------------------------------------
                                   1859 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1860 ;------------------------------------------------------------
                                   1861 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1862 ;	-----------------------------------------
                                   1863 	.area CSEG    (CODE)
                                   1864 	.area CONST   (CODE)
                                   1865 	.area XINIT   (CODE)
      00BDDF                       1866 __xinit__real_mods:
      00BDDF 00                    1867 	.db #0x00	; 0
      00BDE0                       1868 __xinit__weak_mods:
      00BDE0 00                    1869 	.db #0x00	; 0
      00BDE1                       1870 __xinit__actual_keyboard_report:
      00BDE1 00                    1871 	.db #0x00	; 0
      00BDE2 00                    1872 	.db #0x00	; 0
      00BDE3 00                    1873 	.db #0x00	; 0
      00BDE4 00                    1874 	.db #0x00	; 0
      00BDE5 00                    1875 	.db #0x00	; 0
      00BDE6 00                    1876 	.db #0x00	; 0
      00BDE7 00                    1877 	.db #0x00	; 0
      00BDE8 00                    1878 	.db #0x00	; 0
      00BDE9 00                    1879 	.db 0x00
      00BDEA 00                    1880 	.db 0x00
      00BDEB 00                    1881 	.db 0x00
      00BDEC 00                    1882 	.db 0x00
      00BDED 00                    1883 	.db 0x00
      00BDEE 00                    1884 	.db 0x00
      00BDEF 00                    1885 	.db 0x00
      00BDF0 00                    1886 	.db 0x00
      00BDF1 00                    1887 	.db 0x00
      00BDF2 00                    1888 	.db 0x00
      00BDF3 00                    1889 	.db 0x00
      00BDF4 00                    1890 	.db 0x00
      00BDF5 00                    1891 	.db 0x00
      00BDF6 00                    1892 	.db 0x00
      00BDF7 00                    1893 	.db 0x00
      00BDF8 00                    1894 	.db 0x00
      00BDF9 00                    1895 	.db 0x00
      00BDFA 00                    1896 	.db 0x00
      00BDFB 00                    1897 	.db 0x00
      00BDFC 00                    1898 	.db 0x00
      00BDFD 00                    1899 	.db 0x00
      00BDFE 00                    1900 	.db 0x00
      00BDFF 00                    1901 	.db 0x00
      00BE00 00                    1902 	.db 0x00
                                   1903 	.area CABS    (ABS,CODE)
                                   1904 
                                   1905 ; Experimental exact instruction outlining.
                                   1906 	.globl _ak820_outline_0014
                                   1907 	.globl _ak820_outline_0029
                                   1908 	.globl _ak820_outline_0055
                                   1909 	.globl _ak820_outline_0057
                                   1910 	.globl _ak820_outline_0058
                                   1911 	.globl _ak820_outline_0061
                                   1912 	.globl _ak820_outline_0062
                                   1913 	.globl _ak820_outline_0066
                                   1914 	.globl _ak820_outline_0074
                                   1915 	.globl _ak820_outline_0103
                                   1916 	.globl _ak820_outline_0104
                                   1917 	.globl _ak820_outline_0111
                                   1918 	.globl _ak820_outline_0117
                                   1919 	.globl _ak820_outline_0119
                                   1920 	.globl _ak820_outline_0121
                                   1921 	.globl _ak820_outline_0122
                                   1922 	.globl _ak820_outline_0128
                                   1923 	.globl _ak820_outline_0129
                                   1924 	.globl _ak820_outline_0134
                                   1925 	.globl _ak820_outline_0136
                                   1926 	.globl _ak820_outline_0151
                                   1927 	.globl _ak820_outline_0152
                                   1928 	.globl _ak820_outline_0157
                                   1929 	.globl _ak820_outline_0164
                                   1930 	.globl _ak820_outline_0171
                                   1931 	.globl _ak820_outline_0181
                                   1932 	.globl _ak820_outline_0182
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0029
      007DAF                       1936 _ak820_outline_0029:
      007DAF EF               [12] 1937 	mov	a,r7
      007DB0 24 85            [12] 1938 	add	a,#_key_refs
      007DB2 FD               [12] 1939 	mov	r5,a
      007DB3 E4               [12] 1940 	clr	a
      007DB4 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      007DB6 FE               [12] 1942 	mov	r6,a
      007DB7 8D 82            [24] 1943 	mov	dpl,r5
      007DB9 8E 83            [24] 1944 	mov	dph,r6
      007DBB E0               [24] 1945 	movx	a,@dptr
      007DBC 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0062
      007DBD                       1950 _ak820_outline_0062:
      007DBD 89 82            [24] 1951 	mov	dpl,r1
      007DBF 8A 83            [24] 1952 	mov	dph,r2
      007DC1 E8               [12] 1953 	mov	a,r0
      007DC2 F0               [24] 1954 	movx	@dptr,a
      007DC3 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0066
      007DC4                       1959 _ak820_outline_0066:
      007DC4 24 60            [12] 1960 	add	a,#_usage_order
      007DC6 F5 82            [12] 1961 	mov	dpl,a
      007DC8 E4               [12] 1962 	clr	a
      007DC9 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      007DCB F5 83            [12] 1964 	mov	dph,a
      007DCD 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0074
      007DCE                       1969 _ak820_outline_0074:
      007DCE EB               [12] 1970 	mov	a,r3
      007DCF 24 42            [12] 1971 	add	a,#_usage_refs
      007DD1 F9               [12] 1972 	mov	r1,a
      007DD2 E4               [12] 1973 	clr	a
      007DD3 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      007DD5 FA               [12] 1975 	mov	r2,a
      007DD6 89 82            [24] 1976 	mov	dpl,r1
      007DD8 8A 83            [24] 1977 	mov	dph,r2
      007DDA E0               [24] 1978 	movx	a,@dptr
      007DDB F8               [12] 1979 	mov	r0,a
      007DDC 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0111
      007DDD                       1984 _ak820_outline_0111:
      007DDD F0               [24] 1985 	movx	@dptr,a
      007DDE E0               [24] 1986 	movx	a,@dptr
      007DDF FF               [12] 1987 	mov	r7,a
      007DE0 90 09 7D         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      007DE3 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0117
      007DE4                       1993 _ak820_outline_0117:
      007DE4 8D 82            [24] 1994 	mov	dpl,r5
      007DE6 8E 83            [24] 1995 	mov	dph,r6
      007DE8 F0               [24] 1996 	movx	@dptr,a
      007DE9 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0122
      007DEA                       2001 _ak820_outline_0122:
      007DEA 24 60            [12] 2002 	add	a,#_usage_order
      007DEC F5 82            [12] 2003 	mov	dpl,a
      007DEE EF               [12] 2004 	mov	a,r7
      007DEF 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      007DF1 F5 83            [12] 2006 	mov	dph,a
      007DF3 E0               [24] 2007 	movx	a,@dptr
      007DF4 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0128
      007DF5                       2012 _ak820_outline_0128:
      007DF5 F0               [24] 2013 	movx	@dptr,a
      007DF6 E0               [24] 2014 	movx	a,@dptr
      007DF7 FF               [12] 2015 	mov	r7,a
      007DF8 90 09 79         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      007DFB F0               [24] 2017 	movx	@dptr,a
      007DFC 90 09 7A         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      007DFF 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0171
      007E00                       2023 _ak820_outline_0171:
      007E00 90 07 F3         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      007E03 EF               [12] 2025 	mov	a,r7
      007E04 F0               [24] 2026 	movx	@dptr,a
      007E05 90 0D B5         [24] 2027 	mov	dptr,#_actual_keyboard_report
      007E08 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0182
      007E09                       2032 _ak820_outline_0182:
      007E09 8D 82            [24] 2033 	mov	dpl,r5
      007E0B 8F 83            [24] 2034 	mov	dph,r7
      007E0D 22               [24] 2035 	ret
