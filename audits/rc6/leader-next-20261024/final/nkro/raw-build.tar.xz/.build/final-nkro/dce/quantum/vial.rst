                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000046                        541 _vial_handle_cmd_sloc0_1_0:
      000046                        542 	.ds 2
      000048                        543 _vial_handle_cmd_sloc1_1_0:
      000048                        544 	.ds 2
      00004A                        545 _vial_handle_cmd_sloc2_1_0:
      00004A                        546 	.ds 2
      00004C                        547 _vial_handle_cmd_sloc3_1_0:
      00004C                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C47                        573 _vial_unlock_timer:
      000C47                        574 	.ds 4
      000C4B                        575 _vial_unlock_holding:
      000C4B                        576 	.ds 1
      000C4C                        577 _vial_keycode_firewall_in_10000_609:
      000C4C                        578 	.ds 2
      000C4E                        579 _vial_fill_packet_PARM_2:
      000C4E                        580 	.ds 1
      000C4F                        581 _vial_fill_packet_msg_10000_612:
      000C4F                        582 	.ds 2
      000C51                        583 _vial_handle_cmd_PARM_2:
      000C51                        584 	.ds 1
      000C52                        585 _vial_handle_cmd_data_10000_617:
      000C52                        586 	.ds 3
      000C55                        587 _vial_handle_cmd_entry_70000_645:
      000C55                        588 	.ds 10
      000C5F                        589 _vial_handle_cmd_entry_70000_646:
      000C5F                        590 	.ds 10
      000C69                        591 _g_vial_magic_keycode_override::
      000C69                        592 	.ds 2
      000C6B                        593 _vial_keycode_down_keycode_10000_648:
      000C6B                        594 	.ds 2
      000C6D                        595 _vial_keycode_down_dummy_event_30000_655:
      000C6D                        596 	.ds 6
      000C73                        597 _vial_keycode_up_keycode_10000_656:
      000C73                        598 	.ds 2
      000C75                        599 _vial_keycode_up_dummy_event_30000_663:
      000C75                        600 	.ds 6
      000C7B                        601 _vial_keycode_tap_keycode_10000_664:
      000C7B                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E10                        611 _vial_unlocked::
      000E10                        612 	.ds 1
      000E11                        613 _vial_unlock_in_progress::
      000E11                        614 	.ds 1
      000E12                        615 _vial_unlock_counter:
      000E12                        616 	.ds 1
      000E13                        617 _vial_unlock_combo_rows:
      000E13                        618 	.ds 2
      000E15                        619 _vial_unlock_combo_cols:
      000E15                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00A996                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00A996 90 0E 11         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00A999 E0               [24]  667 	movx	a,@dptr
      00A99A 70 01            [24]  668 	jnz	00131$
      00A99C 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A99D                        671 00131$:
      00A99D 7F 00            [12]  672 	mov	r7,#0x00
      00A99F                        673 00115$:
      00A99F BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00A9A2                        675 00184$:
      00A9A2 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00A9A4 EF               [12]  678 	mov	a,r7
      00A9A5 12 AF 5B         [24]  679 	lcall	_ak820_outline_0124
      00A9A8 FE               [12]  680 	mov	r6,a
      00A9A9 EF               [12]  681 	mov	a,r7
      00A9AA 12 AF 50         [24]  682 	lcall	_ak820_outline_0123
      00A9AD 90 07 53         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00A9B0 F0               [24]  684 	movx	@dptr,a
      00A9B1 8E 82            [24]  685 	mov	dpl, r6
      00A9B3 C0 07            [24]  686 	push	ar7
      00A9B5 12 57 67         [24]  687 	lcall	_matrix_is_on
      00A9B8 E5 82            [12]  688 	mov	a, dpl
      00A9BA D0 07            [24]  689 	pop	ar7
      00A9BC 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00A9BE 90 0C 4B         [24]  692 	mov	dptr,#_vial_unlock_holding
      00A9C1 E4               [12]  693 	clr	a
      00A9C2 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00A9C3 90 0E 12         [24]  696 	mov	dptr,#_vial_unlock_counter
      00A9C6 74 1E            [12]  697 	mov	a,#0x1e
      00A9C8 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00A9C9 22               [24]  700 	ret
      00A9CA                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00A9CA 0F               [12]  703 	inc	r7
      00A9CB 80 D2            [24]  704 	sjmp	00115$
      00A9CD                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00A9CD 90 0C 4B         [24]  707 	mov	dptr,#_vial_unlock_holding
      00A9D0 E0               [24]  708 	movx	a,@dptr
      00A9D1 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00A9D3 90 0C 4B         [24]  711 	mov	dptr,#_vial_unlock_holding
      00A9D6 74 01            [12]  712 	mov	a,#0x01
      00A9D8 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00A9D9 12 47 3E         [24]  715 	lcall	_timer_read32
      00A9DC 12 4D 52         [24]  716 	lcall	_ak820_outline_0056
      00A9DF 90 0C 47         [24]  717 	mov	dptr,#_vial_unlock_timer
      00A9E2 12 8D 13         [24]  718 	lcall	_ak820_outline_0006
      00A9E5                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00A9E5 90 0C 47         [24]  721 	mov	dptr,#_vial_unlock_timer
      00A9E8 12 4D 41         [24]  722 	lcall	_ak820_outline_0054
      00A9EB 12 47 97         [24]  723 	lcall	_timer_elapsed32
      00A9EE 12 4D 52         [24]  724 	lcall	_ak820_outline_0056
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00A9F1 7B 1E            [12]  726 	mov	r3,#0x1e
      00A9F3                        727 00109$:
      00A9F3 EB               [12]  728 	mov	a,r3
      00A9F4 60 22            [24]  729 	jz	00111$
      00A9F6 C3               [12]  730 	clr	c
      00A9F7 EC               [12]  731 	mov	a,r4
      00A9F8 94 64            [12]  732 	subb	a,#0x64
      00A9FA ED               [12]  733 	mov	a,r5
      00A9FB 94 00            [12]  734 	subb	a,#0x00
      00A9FD EE               [12]  735 	mov	a,r6
      00A9FE 94 00            [12]  736 	subb	a,#0x00
      00AA00 EF               [12]  737 	mov	a,r7
      00AA01 94 00            [12]  738 	subb	a,#0x00
      00AA03 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AA05 EC               [12]  741 	mov	a,r4
      00AA06 24 9C            [12]  742 	add	a,#0x9c
      00AA08 FC               [12]  743 	mov	r4,a
      00AA09 ED               [12]  744 	mov	a,r5
      00AA0A 34 FF            [12]  745 	addc	a,#0xff
      00AA0C FD               [12]  746 	mov	r5,a
      00AA0D EE               [12]  747 	mov	a,r6
      00AA0E 34 FF            [12]  748 	addc	a,#0xff
      00AA10 FE               [12]  749 	mov	r6,a
      00AA11 EF               [12]  750 	mov	a,r7
      00AA12 34 FF            [12]  751 	addc	a,#0xff
      00AA14 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AA15 1B               [12]  754 	dec	r3
      00AA16 80 DB            [24]  755 	sjmp	00109$
      00AA18                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AA18 90 0E 12         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AA1B EB               [12]  759 	mov	a,r3
      00AA1C F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AA1D EB               [12]  762 	mov	a,r3
      00AA1E 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AA20 90 0E 11         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AA23 E4               [12]  766 	clr	a
      00AA24 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AA25 90 0E 10         [24]  769 	mov	dptr,#_vial_unlocked
      00AA28 04               [12]  770 	inc	a
      00AA29 F0               [24]  771 	movx	@dptr,a
      00AA2A                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AA2A 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:108: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AA2B                        782 _vial_init:
                                    783 ;	quantum/vial.c:113: reload_combo();
                                    784 ;	quantum/vial.c:118: }
      00AA2B 02 35 80         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AA2E                        795 _vial_keycode_firewall:
      00AA2E 12 38 88         [24]  796 	lcall	_ak820_outline_0104
      00AA31 90 0C 4C         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AA34 12 38 83         [24]  798 	lcall	_ak820_outline_0103
                                    799 ;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
      00AA37 90 0C 4C         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AA3A 12 46 89         [24]  801 	lcall	_ak820_outline_0008
      00AA3D BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AA40 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AA43 90 0E 10         [24]  804 	mov	dptr,#_vial_unlocked
      00AA46 E0               [24]  805 	movx	a,@dptr
      00AA47 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:122: return 0;
      00AA49 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AA4C 22               [24]  809 	ret
      00AA4D                        810 00102$:
                                    811 ;	quantum/vial.c:123: return in;
      00AA4D 12 38 8D         [24]  812 	lcall	_ak820_outline_0112
                                    813 ;	quantum/vial.c:124: }
      00AA50 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AA51                        826 _vial_fill_packet:
      00AA51 12 38 88         [24]  827 	lcall	_ak820_outline_0104
      00AA54 90 0C 4F         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AA57 12 38 83         [24]  829 	lcall	_ak820_outline_0103
                                    830 ;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AA5A 90 0C 4F         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AA5D 12 38 42         [24]  832 	lcall	_ak820_outline_0051
      00AA60 90 0C 4E         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AA63 E0               [24]  834 	movx	a,@dptr
      00AA64 FD               [12]  835 	mov	r5,a
      00AA65 7C 00            [12]  836 	mov	r4,#0x00
      00AA67                        837 00103$:
      00AA67 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AA6A                        839 00122$:
      00AA6A 50 09            [24]  840 	jnc	00105$
      00AA6C EC               [12]  841 	mov	a,r4
      00AA6D 12 38 32         [24]  842 	lcall	_ak820_outline_0021
      00AA70 ED               [12]  843 	mov	a,r5
      00AA71 F0               [24]  844 	movx	@dptr,a
      00AA72 0C               [12]  845 	inc	r4
      00AA73 80 F2            [24]  846 	sjmp	00103$
      00AA75                        847 00105$:
                                    848 ;	quantum/vial.c:129: }
      00AA75 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:140: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AA76                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:162: repeat_key_cancel();
      00AA76 12 9E 56         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:164: clear_keyboard();
                                    861 ;	quantum/vial.c:165: }
      00AA79 02 73 BF         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AA7C                        893 _vial_handle_cmd:
      00AA7C 12 43 0E         [24]  894 	lcall	_ak820_outline_0036
      00AA7F 90 0C 52         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AA82 12 38 2A         [24]  896 	lcall	_ak820_outline_0015
                                    897 ;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AA85 90 0C 52         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AA88 12 38 42         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
      00AA8B 90 0C 51         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AA8E E0               [24]  902 	movx	a,@dptr
      00AA8F FD               [12]  903 	mov	r5,a
      00AA90 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AA93 80 01            [24]  905 	sjmp	00102$
      00AA95                        906 00258$:
                                    907 ;	quantum/vial.c:178: return;
      00AA95 22               [24]  908 	ret
      00AA96                        909 00102$:
                                    910 ;	quantum/vial.c:181: switch (msg[1]) {
      00AA96 74 01            [12]  911 	mov	a,#0x01
      00AA98 12 46 C3         [24]  912 	lcall	_ak820_outline_0031
      00AA9B FB               [12]  913 	mov  r3,a
      00AA9C 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AA9E 50 01            [24]  915 	jnc	00259$
      00AAA0 22               [24]  916 	ret
      00AAA1                        917 00259$:
                                    918 ;	free result
      00AAA1 EB               [12]  919 	mov	a,r3
      00AAA2 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AAA4 83               [24]  921 	movc	a,@a+pc
      00AAA5 F5 82            [12]  922 	mov	dpl,a
      00AAA7 EB               [12]  923 	mov	a,r3
      00AAA8 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AAAA 83               [24]  925 	movc	a,@a+pc
      00AAAB F5 83            [12]  926 	mov	dph,a
      00AAAD E4               [12]  927 	clr	a
      00AAAE 73               [24]  928 	jmp	@a+dptr
      00AAAF                        929 00260$:
      00AAAF CB                     930 	.db	00103$
      00AAB0 13                     931 	.db	00105$
      00AAB1 28                     932 	.db	00106$
      00AAB2 B4                     933 	.db	00112$
      00AAB3 3A                     934 	.db	00113$
      00AAB4 85                     935 	.db	00114$
      00AAB5 F4                     936 	.db	00116$
      00AAB6 0F                     937 	.db	00119$
      00AAB7 2E                     938 	.db	00120$
      00AAB8 3C                     939 	.db	00121$
      00AAB9 3C                     940 	.db	00139$
      00AABA 3C                     941 	.db	00139$
      00AABB 3C                     942 	.db	00139$
      00AABC 47                     943 	.db	00122$
      00AABD                        944 00261$:
      00AABD AA                     945 	.db	00103$>>8
      00AABE AB                     946 	.db	00105$>>8
      00AABF AB                     947 	.db	00106$>>8
      00AAC0 AB                     948 	.db	00112$>>8
      00AAC1 AC                     949 	.db	00113$>>8
      00AAC2 AC                     950 	.db	00114$>>8
      00AAC3 AC                     951 	.db	00116$>>8
      00AAC4 AD                     952 	.db	00119$>>8
      00AAC5 AD                     953 	.db	00120$>>8
      00AAC6 AD                     954 	.db	00121$>>8
      00AAC7 AE                     955 	.db	00139$>>8
      00AAC8 AE                     956 	.db	00139$>>8
      00AAC9 AE                     957 	.db	00139$>>8
      00AACA AD                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:183: case vial_get_keyboard_id: {
      00AACB                        960 00103$:
                                    961 ;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
      00AACB 90 0C 4E         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AACE E4               [12]  963 	clr	a
      00AACF 12 43 32         [24]  964 	lcall	_ak820_outline_0071
      00AAD2 C0 07            [24]  965 	push	ar7
      00AAD4 C0 06            [24]  966 	push	ar6
      00AAD6 12 AA 51         [24]  967 	lcall	_vial_fill_packet
      00AAD9 D0 06            [24]  968 	pop	ar6
      00AADB D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AADD 12 38 8D         [24]  971 	lcall	_ak820_outline_0112
      00AAE0 74 06            [12]  972 	mov	a,#0x06
      00AAE2 12 43 32         [24]  973 	lcall	_ak820_outline_0071
                                    974 ;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AAE5 A3               [24]  975 	inc	dptr
      00AAE6 E4               [12]  976 	clr	a
      00AAE7 12 43 06         [24]  977 	lcall	_ak820_outline_0032
                                    978 ;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AAEA 12 43 06         [24]  979 	lcall	_ak820_outline_0032
                                    980 ;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AAED A3               [24]  981 	inc	dptr
      00AAEE F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AAEF FB               [12]  984 	mov	r3,a
      00AAF0                        985 00131$:
      00AAF0 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AAF3                        987 00262$:
      00AAF3 50 15            [24]  988 	jnc	00104$
      00AAF5 8B 02            [24]  989 	mov	ar2,r3
      00AAF7 74 04            [12]  990 	mov	a,#0x04
      00AAF9 2A               [12]  991 	add	a, r2
      00AAFA 2E               [12]  992 	add	a, r6
      00AAFB F9               [12]  993 	mov	r1,a
      00AAFC E4               [12]  994 	clr	a
      00AAFD 3F               [12]  995 	addc	a,r7
      00AAFE FA               [12]  996 	mov	r2,a
      00AAFF EB               [12]  997 	mov	a,r3
      00AB00 90 BC 07         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00AB03 93               [24]  999 	movc	a,@a+dptr
      00AB04 12 6A 58         [24] 1000 	lcall	_ak820_outline_0134
      00AB07 0B               [12] 1001 	inc	r3
      00AB08 80 E6            [24] 1002 	sjmp	00131$
      00AB0A                       1003 00104$:
                                   1004 ;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AB0A 74 0C            [12] 1005 	mov	a,#0x0c
      00AB0C 12 38 32         [24] 1006 	lcall	_ak820_outline_0021
      00AB0F 74 01            [12] 1007 	mov	a,#0x01
      00AB11 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:195: break;
      00AB12 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:198: case vial_get_size: {
      00AB13                       1012 00105$:
                                   1013 ;	quantum/vial.c:200: msg[0] = sz & 0xFF;
      00AB13 12 38 8D         [24] 1014 	lcall	_ak820_outline_0112
      00AB16 74 7C            [12] 1015 	mov	a,#0x7c
      00AB18 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
      00AB19 12 38 92         [24] 1018 	lcall	_ak820_outline_0120
      00AB1C 74 01            [12] 1019 	mov	a,#0x01
      00AB1E 12 43 06         [24] 1020 	lcall	_ak820_outline_0032
                                   1021 ;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
      00AB21 E4               [12] 1022 	clr	a
      00AB22 12 43 06         [24] 1023 	lcall	_ak820_outline_0032
                                   1024 ;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
      00AB25 A3               [24] 1025 	inc	dptr
      00AB26 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:204: break;
      00AB27 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:207: case vial_get_def: {
      00AB28                       1030 00106$:
                                   1031 ;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
      00AB28 12 A9 5A         [24] 1032 	lcall	_ak820_outline_0020
      00AB2B E0               [24] 1033 	movx	a,@dptr
      00AB2C FB               [12] 1034 	mov	r3,a
      00AB2D 12 42 FC         [24] 1035 	lcall	_ak820_outline_0011
      00AB30 E0               [24] 1036 	movx	a,@dptr
      00AB31 4B               [12] 1037 	orl	a,r3
      00AB32 60 01            [24] 1038 	jz	00108$
      00AB34 22               [24] 1039 	ret
      00AB35                       1040 00108$:
                                   1041 ;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AB35 12 38 3A         [24] 1042 	lcall	_ak820_outline_0035
      00AB38 FB               [12] 1043 	mov	r3,a
      00AB39 7A 00            [12] 1044 	mov	r2,#0x00
      00AB3B 12 A9 51         [24] 1045 	lcall	_ak820_outline_0016
      00AB3E F9               [12] 1046 	mov	r1,a
      00AB3F E4               [12] 1047 	clr	a
      00AB40 42 03            [12] 1048 	orl	ar3,a
      00AB42 E9               [12] 1049 	mov	a,r1
      00AB43 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AB45 C3               [12] 1052 	clr	c
      00AB46 EB               [12] 1053 	mov	a,r3
      00AB47 94 0C            [12] 1054 	subb	a,#0x0c
      00AB49 EA               [12] 1055 	mov	a,r2
      00AB4A 94 00            [12] 1056 	subb	a,#0x00
      00AB4C 40 01            [24] 1057 	jc	00110$
      00AB4E 22               [24] 1058 	ret
      00AB4F                       1059 00110$:
                                   1060 ;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AB4F EA               [12] 1061 	mov	a,r2
      00AB50 C4               [12] 1062 	swap	a
      00AB51 23               [12] 1063 	rl	a
      00AB52 54 E0            [12] 1064 	anl	a,#0xe0
      00AB54 CB               [12] 1065 	xch	a,r3
      00AB55 C4               [12] 1066 	swap	a
      00AB56 23               [12] 1067 	rl	a
      00AB57 CB               [12] 1068 	xch	a,r3
      00AB58 6B               [12] 1069 	xrl	a,r3
      00AB59 CB               [12] 1070 	xch	a,r3
      00AB5A 54 E0            [12] 1071 	anl	a,#0xe0
      00AB5C CB               [12] 1072 	xch	a,r3
      00AB5D 6B               [12] 1073 	xrl	a,r3
      00AB5E FA               [12] 1074 	mov	r2,a
      00AB5F 8B 46            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00AB61 8A 47            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
      00AB63 74 7C            [12] 1078 	mov	a,#0x7c
      00AB65 C3               [12] 1079 	clr	c
      00AB66 95 46            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00AB68 F8               [12] 1081 	mov	r0,a
      00AB69 74 01            [12] 1082 	mov	a,#0x01
      00AB6B 95 47            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AB6D F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00AB6E C3               [12] 1086 	clr	c
      00AB6F E8               [12] 1087 	mov	a,r0
      00AB70 94 20            [12] 1088 	subb	a,#0x20
      00AB72 E9               [12] 1089 	mov	a,r1
      00AB73 94 00            [12] 1090 	subb	a,#0x00
      00AB75 40 02            [24] 1091 	jc	00142$
      00AB77 78 20            [12] 1092 	mov	r0,#0x20
      00AB79                       1093 00142$:
                                   1094 ;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00AB79 79 00            [12] 1095 	mov	r1,#0x00
      00AB7B                       1096 00134$:
      00AB7B C3               [12] 1097 	clr	c
      00AB7C E9               [12] 1098 	mov	a,r1
      00AB7D 98               [12] 1099 	subb	a,r0
      00AB7E 40 01            [24] 1100 	jc	00267$
      00AB80 22               [24] 1101 	ret
      00AB81                       1102 00267$:
      00AB81 C0 00            [24] 1103 	push	ar0
      00AB83 E9               [12] 1104 	mov	a,r1
      00AB84 2E               [12] 1105 	add	a, r6
      00AB85 F5 48            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AB87 E4               [12] 1107 	clr	a
      00AB88 3F               [12] 1108 	addc	a, r7
      00AB89 F5 49            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AB8B 89 4A            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00AB8D 75 4B 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00AB90 A8 46            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00AB92 AB 47            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AB94 E5 4A            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AB96 28               [12] 1115 	add	a, r0
      00AB97 F8               [12] 1116 	mov	r0,a
      00AB98 E5 4B            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00AB9A 3B               [12] 1118 	addc	a, r3
      00AB9B FB               [12] 1119 	mov	r3,a
      00AB9C E8               [12] 1120 	mov	a,r0
      00AB9D 24 8B            [12] 1121 	add	a, #_keyboard_definition
      00AB9F F5 82            [12] 1122 	mov	dpl,a
      00ABA1 EB               [12] 1123 	mov	a,r3
      00ABA2 34 BA            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00ABA4 F5 83            [12] 1125 	mov	dph,a
      00ABA6 E4               [12] 1126 	clr	a
      00ABA7 93               [24] 1127 	movc	a,@a+dptr
      00ABA8 85 48 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00ABAB 85 49 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00ABAE F0               [24] 1130 	movx	@dptr,a
      00ABAF 09               [12] 1131 	inc	r1
      00ABB0 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:234: case vial_get_encoder: {
      00ABB2 80 C7            [24] 1134 	sjmp	00134$
      00ABB4                       1135 00112$:
                                   1136 ;	quantum/vial.c:235: uint8_t layer = msg[2];
      00ABB4 74 02            [12] 1137 	mov	a,#0x02
      00ABB6 12 46 B8         [24] 1138 	lcall	_ak820_outline_0030
      00ABB9 F5 4A            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:236: uint8_t idx = msg[3];
      00ABBB 74 03            [12] 1141 	mov	a,#0x03
      00ABBD 2E               [12] 1142 	add	a, r6
      00ABBE F5 48            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00ABC0 E4               [12] 1144 	clr	a
      00ABC1 3F               [12] 1145 	addc	a, r7
      00ABC2 F5 49            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00ABC4 85 48 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00ABC7 85 49 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00ABCA E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00ABCB F5 46            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00ABCD 90 0A D6         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00ABD0 F0               [24] 1153 	movx	@dptr,a
      00ABD1 90 0A D7         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00ABD4 E4               [12] 1155 	clr	a
      00ABD5 F0               [24] 1156 	movx	@dptr,a
      00ABD6 85 4A 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00ABD9 C0 07            [24] 1158 	push	ar7
      00ABDB C0 06            [24] 1159 	push	ar6
      00ABDD C0 05            [24] 1160 	push	ar5
      00ABDF C0 04            [24] 1161 	push	ar4
      00ABE1 C0 03            [24] 1162 	push	ar3
      00ABE3 C0 02            [24] 1163 	push	ar2
      00ABE5 12 81 98         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00ABE8 85 82 4C         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00ABEB 85 83 4D         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00ABEE D0 02            [24] 1167 	pop	ar2
      00ABF0 D0 03            [24] 1168 	pop	ar3
      00ABF2 D0 04            [24] 1169 	pop	ar4
      00ABF4 D0 05            [24] 1170 	pop	ar5
      00ABF6 D0 06            [24] 1171 	pop	ar6
      00ABF8 D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:238: msg[0]  = keycode >> 8;
      00ABFA A9 4D            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00ABFC 12 38 8D         [24] 1175 	lcall	_ak820_outline_0112
      00ABFF E9               [12] 1176 	mov	a,r1
      00AC00 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
      00AC01 A8 4C            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AC03 12 38 92         [24] 1180 	lcall	_ak820_outline_0120
      00AC06 E8               [12] 1181 	mov	a,r0
      00AC07 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AC08 90 0A D6         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AC0B E5 46            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00AC0D F0               [24] 1186 	movx	@dptr,a
      00AC0E 90 0A D7         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AC11 74 01            [12] 1188 	mov	a,#0x01
      00AC13 F0               [24] 1189 	movx	@dptr,a
      00AC14 85 4A 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AC17 C0 03            [24] 1191 	push	ar3
      00AC19 C0 02            [24] 1192 	push	ar2
      00AC1B 12 81 98         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00AC1E 85 82 4C         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AC21 85 83 4D         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AC24 D0 02            [24] 1196 	pop	ar2
      00AC26 D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:241: msg[2] = keycode >> 8;
      00AC28 A9 4D            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AC2A 12 38 A7         [24] 1200 	lcall	_ak820_outline_0138
      00AC2D E9               [12] 1201 	mov	a,r1
      00AC2E F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
      00AC2F A8 4C            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AC31 85 48 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AC34 85 49 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AC37 E8               [12] 1207 	mov	a,r0
      00AC38 F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:243: break;
      00AC39 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:245: case vial_set_encoder: {
      00AC3A                       1212 00113$:
                                   1213 ;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AC3A 12 38 3A         [24] 1214 	lcall	_ak820_outline_0035
      00AC3D F5 48            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AC3F 12 A9 51         [24] 1216 	lcall	_ak820_outline_0016
      00AC42 F5 4A            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AC44 12 A9 5A         [24] 1218 	lcall	_ak820_outline_0020
      00AC47 E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00AC48 24 FF            [12] 1221 	add	a,#0xff
      00AC4A E4               [12] 1222 	clr	a
      00AC4B 33               [12] 1223 	rlc	a
      00AC4C F5 4C            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AC4E 12 42 FC         [24] 1225 	lcall	_ak820_outline_0011
      00AC51 E0               [24] 1226 	movx	a,@dptr
      00AC52 F9               [12] 1227 	mov	r1,a
      00AC53 78 00            [12] 1228 	mov	r0,#0x00
      00AC55 74 06            [12] 1229 	mov	a,#0x06
      00AC57 12 38 32         [24] 1230 	lcall	_ak820_outline_0021
      00AC5A E0               [24] 1231 	movx	a,@dptr
      00AC5B 7B 00            [12] 1232 	mov	r3,#0x00
      00AC5D 42 00            [12] 1233 	orl	ar0,a
      00AC5F EB               [12] 1234 	mov	a,r3
      00AC60 42 01            [12] 1235 	orl	ar1,a
      00AC62 12 38 B1         [24] 1236 	lcall	_ak820_outline_0151
      00AC65 12 AA 2E         [24] 1237 	lcall	_vial_keycode_firewall
      00AC68 AA 82            [24] 1238 	mov	r2, dpl
      00AC6A AB 83            [24] 1239 	mov	r3, dph
      00AC6C 90 0A D9         [24] 1240 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00AC6F E5 4A            [12] 1241 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AC71 F0               [24] 1242 	movx	@dptr,a
      00AC72 90 0A DA         [24] 1243 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00AC75 E5 4C            [12] 1244 	mov	a,_vial_handle_cmd_sloc3_1_0
      00AC77 F0               [24] 1245 	movx	@dptr,a
      00AC78 90 0A DB         [24] 1246 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00AC7B EA               [12] 1247 	mov	a,r2
      00AC7C 12 8B 94         [24] 1248 	lcall	_ak820_outline_0183
      00AC7F 85 48 82         [24] 1249 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1250 ;	quantum/vial.c:247: break;
      00AC82 02 82 00         [24] 1251 	ljmp	_dynamic_keymap_set_encoder
                                   1252 ;	quantum/vial.c:250: case vial_get_unlock_status: {
      00AC85                       1253 00114$:
                                   1254 ;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
      00AC85 90 0C 4E         [24] 1255 	mov	dptr,#_vial_fill_packet_PARM_2
      00AC88 74 FF            [12] 1256 	mov	a,#0xff
      00AC8A 12 43 32         [24] 1257 	lcall	_ak820_outline_0071
      00AC8D C0 07            [24] 1258 	push	ar7
      00AC8F C0 06            [24] 1259 	push	ar6
      00AC91 12 AA 51         [24] 1260 	lcall	_vial_fill_packet
      00AC94 D0 06            [24] 1261 	pop	ar6
      00AC96 D0 07            [24] 1262 	pop	ar7
                                   1263 ;	quantum/vial.c:254: msg[0] = vial_unlocked;
      00AC98 90 0E 10         [24] 1264 	mov	dptr,#_vial_unlocked
      00AC9B E0               [24] 1265 	movx	a,@dptr
      00AC9C 12 38 8D         [24] 1266 	lcall	_ak820_outline_0112
      00AC9F F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
      00ACA0 74 01            [12] 1269 	mov	a,#0x01
      00ACA2 2E               [12] 1270 	add	a, r6
      00ACA3 FA               [12] 1271 	mov	r2,a
      00ACA4 E4               [12] 1272 	clr	a
      00ACA5 3F               [12] 1273 	addc	a, r7
      00ACA6 FB               [12] 1274 	mov	r3,a
      00ACA7 90 0E 11         [24] 1275 	mov	dptr,#_vial_unlock_in_progress
      00ACAA E0               [24] 1276 	movx	a,@dptr
      00ACAB 12 38 A7         [24] 1277 	lcall	_ak820_outline_0138
      00ACAE F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00ACAF 7B 00            [12] 1280 	mov	r3,#0x00
      00ACB1                       1281 00137$:
      00ACB1 BB 02 00         [24] 1282 	cjne	r3,#0x02,00268$
      00ACB4                       1283 00268$:
      00ACB4 40 01            [24] 1284 	jc	00269$
      00ACB6 22               [24] 1285 	ret
      00ACB7                       1286 00269$:
                                   1287 ;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00ACB7 8B 01            [24] 1288 	mov	ar1,r3
      00ACB9 7A 00            [12] 1289 	mov	r2,#0x00
      00ACBB E9               [12] 1290 	mov	a,r1
      00ACBC 29               [12] 1291 	add	a,r1
      00ACBD F5 4C            [12] 1292 	mov	_vial_handle_cmd_sloc3_1_0,a
      00ACBF EA               [12] 1293 	mov	a,r2
      00ACC0 33               [12] 1294 	rlc	a
      00ACC1 F5 4D            [12] 1295 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00ACC3 74 02            [12] 1296 	mov	a,#0x02
      00ACC5 25 4C            [12] 1297 	add	a, _vial_handle_cmd_sloc3_1_0
      00ACC7 F8               [12] 1298 	mov	r0,a
      00ACC8 E4               [12] 1299 	clr	a
      00ACC9 35 4D            [12] 1300 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00ACCB FA               [12] 1301 	mov	r2,a
      00ACCC E8               [12] 1302 	mov	a,r0
      00ACCD 2E               [12] 1303 	add	a, r6
      00ACCE F8               [12] 1304 	mov	r0,a
      00ACCF EA               [12] 1305 	mov	a,r2
      00ACD0 3F               [12] 1306 	addc	a, r7
      00ACD1 FA               [12] 1307 	mov	r2,a
      00ACD2 EB               [12] 1308 	mov	a,r3
      00ACD3 12 AF 5B         [24] 1309 	lcall	_ak820_outline_0124
      00ACD6 88 82            [24] 1310 	mov	dpl,r0
      00ACD8 8A 83            [24] 1311 	mov	dph,r2
      00ACDA F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00ACDB 74 03            [12] 1314 	mov	a,#0x03
      00ACDD 25 4C            [12] 1315 	add	a, _vial_handle_cmd_sloc3_1_0
      00ACDF F9               [12] 1316 	mov	r1,a
      00ACE0 E4               [12] 1317 	clr	a
      00ACE1 35 4D            [12] 1318 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00ACE3 FA               [12] 1319 	mov	r2,a
      00ACE4 E9               [12] 1320 	mov	a,r1
      00ACE5 2E               [12] 1321 	add	a, r6
      00ACE6 F9               [12] 1322 	mov	r1,a
      00ACE7 EA               [12] 1323 	mov	a,r2
      00ACE8 3F               [12] 1324 	addc	a, r7
      00ACE9 FA               [12] 1325 	mov	r2,a
      00ACEA EB               [12] 1326 	mov	a,r3
      00ACEB 12 AF 50         [24] 1327 	lcall	_ak820_outline_0123
      00ACEE 12 6A 58         [24] 1328 	lcall	_ak820_outline_0134
                                   1329 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00ACF1 0B               [12] 1330 	inc	r3
                                   1331 ;	quantum/vial.c:266: case vial_unlock_start: {
      00ACF2 80 BD            [24] 1332 	sjmp	00137$
      00ACF4                       1333 00116$:
                                   1334 ;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
      00ACF4 90 0E 11         [24] 1335 	mov	dptr,#_vial_unlock_in_progress
      00ACF7 E0               [24] 1336 	movx	a,@dptr
      00ACF8 70 03            [24] 1337 	jnz	00118$
      00ACFA 12 AA 76         [24] 1338 	lcall	_vial_release_held_state
      00ACFD                       1339 00118$:
                                   1340 ;	quantum/vial.c:270: vial_unlock_in_progress = 1;
      00ACFD 90 0E 11         [24] 1341 	mov	dptr,#_vial_unlock_in_progress
      00AD00 74 01            [12] 1342 	mov	a,#0x01
      00AD02 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AD03 90 0E 12         [24] 1345 	mov	dptr,#_vial_unlock_counter
      00AD06 74 1E            [12] 1346 	mov	a,#0x1e
      00AD08 F0               [24] 1347 	movx	@dptr,a
                                   1348 ;	quantum/vial.c:273: vial_unlock_holding = false;
      00AD09 90 0C 4B         [24] 1349 	mov	dptr,#_vial_unlock_holding
      00AD0C E4               [12] 1350 	clr	a
      00AD0D F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/vial.c:275: break;
      00AD0E 22               [24] 1353 	ret
                                   1354 ;	quantum/vial.c:277: case vial_unlock_poll: {
      00AD0F                       1355 00119$:
                                   1356 ;	quantum/vial.c:278: msg[0] = vial_unlocked;
      00AD0F 90 0E 10         [24] 1357 	mov	dptr,#_vial_unlocked
      00AD12 E0               [24] 1358 	movx	a,@dptr
      00AD13 12 38 8D         [24] 1359 	lcall	_ak820_outline_0112
      00AD16 F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
      00AD17 90 0E 11         [24] 1362 	mov	dptr,#_vial_unlock_in_progress
      00AD1A E0               [24] 1363 	movx	a,@dptr
      00AD1B 12 43 50         [24] 1364 	lcall	_ak820_outline_0116
                                   1365 ;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
      00AD1E 74 02            [12] 1366 	mov	a,#0x02
      00AD20 2E               [12] 1367 	add	a, r6
      00AD21 FA               [12] 1368 	mov	r2,a
      00AD22 E4               [12] 1369 	clr	a
      00AD23 3F               [12] 1370 	addc	a, r7
      00AD24 FB               [12] 1371 	mov	r3,a
      00AD25 90 0E 12         [24] 1372 	mov	dptr,#_vial_unlock_counter
      00AD28 E0               [24] 1373 	movx	a,@dptr
      00AD29 12 38 A7         [24] 1374 	lcall	_ak820_outline_0138
      00AD2C F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/vial.c:281: break;
      00AD2D 22               [24] 1377 	ret
                                   1378 ;	quantum/vial.c:283: case vial_lock: {
      00AD2E                       1379 00120$:
                                   1380 ;	quantum/vial.c:285: vial_unlocked = 0;
      00AD2E 90 0E 10         [24] 1381 	mov	dptr,#_vial_unlocked
      00AD31 E4               [12] 1382 	clr	a
      00AD32 F0               [24] 1383 	movx	@dptr,a
                                   1384 ;	quantum/vial.c:286: vial_unlock_in_progress = 0;
      00AD33 90 0E 11         [24] 1385 	mov	dptr,#_vial_unlock_in_progress
      00AD36 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:287: vial_unlock_holding = false;
      00AD37 90 0C 4B         [24] 1388 	mov	dptr,#_vial_unlock_holding
      00AD3A F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:289: break;
      00AD3B 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:291: case vial_qmk_settings_query: {
      00AD3C                       1393 00121$:
                                   1394 ;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00AD3C 90 0C 4E         [24] 1395 	mov	dptr,#_vial_fill_packet_PARM_2
      00AD3F 74 FF            [12] 1396 	mov	a,#0xff
      00AD41 12 43 32         [24] 1397 	lcall	_ak820_outline_0071
                                   1398 ;	quantum/vial.c:298: break;
      00AD44 02 AA 51         [24] 1399 	ljmp	_vial_fill_packet
                                   1400 ;	quantum/vial.c:318: case vial_dynamic_entry_op: {
      00AD47                       1401 00122$:
                                   1402 ;	quantum/vial.c:319: switch (msg[2]) {
      00AD47 12 38 3A         [24] 1403 	lcall	_ak820_outline_0035
      00AD4A FB               [12] 1404 	mov	r3,a
      00AD4B 60 0C            [24] 1405 	jz	00123$
      00AD4D BB 03 02         [24] 1406 	cjne	r3,#0x03,00272$
      00AD50 80 31            [24] 1407 	sjmp	00124$
      00AD52                       1408 00272$:
      00AD52 BB 04 03         [24] 1409 	cjne	r3,#0x04,00273$
      00AD55 02 AD E1         [24] 1410 	ljmp	00125$
      00AD58                       1411 00273$:
      00AD58 22               [24] 1412 	ret
                                   1413 ;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
      00AD59                       1414 00123$:
                                   1415 ;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
      00AD59 90 0C 4E         [24] 1416 	mov	dptr,#_vial_fill_packet_PARM_2
      00AD5C E4               [12] 1417 	clr	a
      00AD5D 12 43 32         [24] 1418 	lcall	_ak820_outline_0071
      00AD60 C0 07            [24] 1419 	push	ar7
      00AD62 C0 06            [24] 1420 	push	ar6
      00AD64 12 AA 51         [24] 1421 	lcall	_vial_fill_packet
      00AD67 D0 06            [24] 1422 	pop	ar6
      00AD69 D0 07            [24] 1423 	pop	ar7
                                   1424 ;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00AD6B 12 38 8D         [24] 1425 	lcall	_ak820_outline_0112
      00AD6E E4               [12] 1426 	clr	a
      00AD6F 12 43 32         [24] 1427 	lcall	_ak820_outline_0071
                                   1428 ;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
      00AD72 A3               [24] 1429 	inc	dptr
      00AD73 74 08            [12] 1430 	mov	a,#0x08
      00AD75 12 43 06         [24] 1431 	lcall	_ak820_outline_0032
                                   1432 ;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00AD78 E4               [12] 1433 	clr	a
      00AD79 F0               [24] 1434 	movx	@dptr,a
                                   1435 ;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00AD7A 74 1F            [12] 1436 	mov	a,#0x1f
      00AD7C 12 38 32         [24] 1437 	lcall	_ak820_outline_0021
      00AD7F 74 01            [12] 1438 	mov	a,#0x01
      00AD81 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/vial.c:328: break;
      00AD82 22               [24] 1441 	ret
                                   1442 ;	quantum/vial.c:352: case dynamic_vial_combo_get: {
      00AD83                       1443 00124$:
                                   1444 ;	quantum/vial.c:353: uint8_t idx = msg[3];
      00AD83 12 A9 51         [24] 1445 	lcall	_ak820_outline_0016
      00AD86 FB               [12] 1446 	mov	r3,a
                                   1447 ;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
      00AD87 90 0C 55         [24] 1448 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00AD8A 12 4D 73         [24] 1449 	lcall	_ak820_outline_0164
      00AD8D 90 0C 57         [24] 1450 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00AD90 F0               [24] 1451 	movx	@dptr,a
      00AD91 A3               [24] 1452 	inc	dptr
      00AD92 F0               [24] 1453 	movx	@dptr,a
      00AD93 90 0C 59         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00AD96 F0               [24] 1455 	movx	@dptr,a
      00AD97 A3               [24] 1456 	inc	dptr
      00AD98 F0               [24] 1457 	movx	@dptr,a
      00AD99 90 0C 5B         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00AD9C F0               [24] 1459 	movx	@dptr,a
      00AD9D A3               [24] 1460 	inc	dptr
      00AD9E F0               [24] 1461 	movx	@dptr,a
      00AD9F 90 0C 5D         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00ADA2 F0               [24] 1463 	movx	@dptr,a
      00ADA3 A3               [24] 1464 	inc	dptr
      00ADA4 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00ADA5 90 0A DE         [24] 1467 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00ADA8 74 55            [12] 1468 	mov	a,#_vial_handle_cmd_entry_70000_645
      00ADAA F0               [24] 1469 	movx	@dptr,a
      00ADAB 74 0C            [12] 1470 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00ADAD 12 38 6B         [24] 1471 	lcall	_ak820_outline_0088
      00ADB0 8B 82            [24] 1472 	mov	dpl, r3
      00ADB2 C0 07            [24] 1473 	push	ar7
      00ADB4 C0 06            [24] 1474 	push	ar6
      00ADB6 C0 05            [24] 1475 	push	ar5
      00ADB8 C0 04            [24] 1476 	push	ar4
      00ADBA 12 82 6C         [24] 1477 	lcall	_dynamic_keymap_get_combo
      00ADBD AA 82            [24] 1478 	mov	r2, dpl
      00ADBF D0 04            [24] 1479 	pop	ar4
      00ADC1 D0 05            [24] 1480 	pop	ar5
      00ADC3 D0 06            [24] 1481 	pop	ar6
      00ADC5 D0 07            [24] 1482 	pop	ar7
      00ADC7 12 38 8D         [24] 1483 	lcall	_ak820_outline_0112
      00ADCA EA               [12] 1484 	mov	a,r2
      00ADCB F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
      00ADCC 7B 00            [12] 1487 	mov	r3,#0x00
      00ADCE 90 0D 91         [24] 1488 	mov	dptr,#___memcpy_PARM_2
      00ADD1 74 55            [12] 1489 	mov	a,#_vial_handle_cmd_entry_70000_645
      00ADD3 F0               [24] 1490 	movx	@dptr,a
      00ADD4 74 0C            [12] 1491 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00ADD6 12 AF 41         [24] 1492 	lcall	_ak820_outline_0073
      00ADD9 12 38 92         [24] 1493 	lcall	_ak820_outline_0120
      00ADDC 8B F0            [24] 1494 	mov	b, r3
                                   1495 ;	quantum/vial.c:357: break;
      00ADDE 02 B5 0D         [24] 1496 	ljmp	___memcpy
                                   1497 ;	quantum/vial.c:359: case dynamic_vial_combo_set: {
      00ADE1                       1498 00125$:
                                   1499 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00ADE1 12 A9 51         [24] 1500 	lcall	_ak820_outline_0016
      00ADE4 FD               [12] 1501 	mov	r5,a
                                   1502 ;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
      00ADE5 74 04            [12] 1503 	mov	a,#0x04
      00ADE7 2E               [12] 1504 	add	a, r6
      00ADE8 FB               [12] 1505 	mov	r3,a
      00ADE9 E4               [12] 1506 	clr	a
      00ADEA 3F               [12] 1507 	addc	a, r7
      00ADEB FC               [12] 1508 	mov	r4,a
      00ADEC 90 0D 91         [24] 1509 	mov	dptr,#___memcpy_PARM_2
      00ADEF EB               [12] 1510 	mov	a,r3
      00ADF0 F0               [24] 1511 	movx	@dptr,a
      00ADF1 EC               [12] 1512 	mov	a,r4
      00ADF2 12 AF 41         [24] 1513 	lcall	_ak820_outline_0073
      00ADF5 90 0C 5F         [24] 1514 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00ADF8 F5 F0            [12] 1515 	mov	b,a
      00ADFA C0 07            [24] 1516 	push	ar7
      00ADFC C0 06            [24] 1517 	push	ar6
      00ADFE C0 05            [24] 1518 	push	ar5
      00AE00 12 B5 0D         [24] 1519 	lcall	___memcpy
                                   1520 ;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
      00AE03 90 0C 67         [24] 1521 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AE06 12 38 7D         [24] 1522 	lcall	_ak820_outline_0099
      00AE09 12 33 FC         [24] 1523 	lcall	_ak820_outline_0119
      00AE0C 12 AA 2E         [24] 1524 	lcall	_vial_keycode_firewall
      00AE0F AB 82            [24] 1525 	mov	r3, dpl
      00AE11 AC 83            [24] 1526 	mov	r4, dph
      00AE13 D0 05            [24] 1527 	pop	ar5
      00AE15 90 0C 67         [24] 1528 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AE18 12 38 65         [24] 1529 	lcall	_ak820_outline_0080
                                   1530 ;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00AE1B 90 0A E2         [24] 1531 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00AE1E 74 5F            [12] 1532 	mov	a,#_vial_handle_cmd_entry_70000_646
      00AE20 F0               [24] 1533 	movx	@dptr,a
      00AE21 74 0C            [12] 1534 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00AE23 12 38 6B         [24] 1535 	lcall	_ak820_outline_0088
      00AE26 8D 82            [24] 1536 	mov	dpl, r5
      00AE28 12 83 0B         [24] 1537 	lcall	_dynamic_keymap_set_combo
      00AE2B AC 82            [24] 1538 	mov	r4, dpl
      00AE2D D0 06            [24] 1539 	pop	ar6
      00AE2F D0 07            [24] 1540 	pop	ar7
      00AE31 12 38 8D         [24] 1541 	lcall	_ak820_outline_0112
      00AE34 EC               [12] 1542 	mov	a,r4
      00AE35 F0               [24] 1543 	movx	@dptr,a
                                   1544 ;	quantum/vial.c:365: if (!msg[0]) reload_combo();
      00AE36 EC               [12] 1545 	mov	a,r4
      00AE37 70 03            [24] 1546 	jnz	00139$
                                   1547 ;	quantum/vial.c:391: }
                                   1548 ;	quantum/vial.c:392: }
      00AE39 02 35 80         [24] 1549 	ljmp	_ak820_combo_reload
      00AE3C                       1550 00139$:
      00AE3C 22               [24] 1551 	ret
                                   1552 ;------------------------------------------------------------
                                   1553 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1554 ;------------------------------------------------------------
                                   1555 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1556 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1557 ;------------------------------------------------------------
                                   1558 ;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
                                   1559 ;	-----------------------------------------
                                   1560 ;	 function vial_keycode_down
                                   1561 ;	-----------------------------------------
      00AE3D                       1562 _vial_keycode_down:
      00AE3D 12 38 88         [24] 1563 	lcall	_ak820_outline_0104
      00AE40 90 0C 6B         [24] 1564 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE43 12 38 83         [24] 1565 	lcall	_ak820_outline_0103
                                   1566 ;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AE46 90 0C 6B         [24] 1567 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE49 12 46 89         [24] 1568 	lcall	_ak820_outline_0008
      00AE4C 74 E0            [12] 1569 	mov	a,#0x100 - 0x20
      00AE4E 2D               [12] 1570 	add	a,r5
      00AE4F 50 19            [24] 1571 	jnc	00104$
      00AE51 C3               [12] 1572 	clr	c
      00AE52 74 FF            [12] 1573 	mov	a,#0xff
      00AE54 9C               [12] 1574 	subb	a,r4
      00AE55 74 4F            [12] 1575 	mov	a,#0x4f
      00AE57 9D               [12] 1576 	subb	a,r5
      00AE58 40 10            [24] 1577 	jc	00104$
                                   1578 ;	free result
                                   1579 ;	quantum/vial.c:401: keycode = (uint8_t)keycode;
      00AE5A 90 0C 6B         [24] 1580 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE5D EE               [12] 1581 	mov	a,r6
      00AE5E 12 38 97         [24] 1582 	lcall	_ak820_outline_0121
                                   1583 ;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
      00AE61 90 0C 6B         [24] 1584 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE64 E0               [24] 1585 	movx	a,@dptr
      00AE65 24 FE            [12] 1586 	add	a,#0xff - 0x01
      00AE67 40 01            [24] 1587 	jc	00104$
                                   1588 ;	free result
      00AE69 22               [24] 1589 	ret
      00AE6A                       1590 00104$:
                                   1591 ;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
      00AE6A 90 0C 6B         [24] 1592 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00AE6D 12 AF 28         [24] 1593 	lcall	_ak820_outline_0023
                                   1594 ;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
      00AE70 40 06            [24] 1595 	jc	00107$
                                   1596 ;	free result
                                   1597 ;	quantum/vial.c:408: register_code16(keycode);
      00AE72 12 38 8D         [24] 1598 	lcall	_ak820_outline_0112
      00AE75 02 9A 5A         [24] 1599 	ljmp	_register_code16
      00AE78                       1600 00107$:
                                   1601 ;	quantum/vial.c:410: keyevent_t dummy_event = {
      00AE78 90 0C 71         [24] 1602 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00AE7B 74 01            [12] 1603 	mov	a,#0x01
      00AE7D F0               [24] 1604 	movx	@dptr,a
      00AE7E 90 0C 6E         [24] 1605 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00AE81 74 F0            [12] 1606 	mov	a,#0xf0
      00AE83 F0               [24] 1607 	movx	@dptr,a
      00AE84 90 0C 6D         [24] 1608 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00AE87 F0               [24] 1609 	movx	@dptr,a
      00AE88 90 0C 72         [24] 1610 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00AE8B 74 01            [12] 1611 	mov	a,#0x01
      00AE8D F0               [24] 1612 	movx	@dptr,a
      00AE8E 12 47 6F         [24] 1613 	lcall	_timer_read
      00AE91 12 43 56         [24] 1614 	lcall	_ak820_outline_0130
      00AE94 43 06 01         [24] 1615 	orl	ar6,#0x01
      00AE97 90 0C 6F         [24] 1616 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00AE9A 12 46 DE         [24] 1617 	lcall	_ak820_outline_0059
                                   1618 ;	quantum/vial.c:414: AK820_ACTION_EXEC(dummy_event);
      00AE9D 90 0C 6D         [24] 1619 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1620 ;	quantum/vial.c:416: }
      00AEA0 02 6E 93         [24] 1621 	ljmp	_ak820_action_exec
                                   1622 ;------------------------------------------------------------
                                   1623 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1624 ;------------------------------------------------------------
                                   1625 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1626 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1627 ;------------------------------------------------------------
                                   1628 ;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
                                   1629 ;	-----------------------------------------
                                   1630 ;	 function vial_keycode_up
                                   1631 ;	-----------------------------------------
      00AEA3                       1632 _vial_keycode_up:
      00AEA3 12 38 88         [24] 1633 	lcall	_ak820_outline_0104
      00AEA6 90 0C 73         [24] 1634 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AEA9 12 38 83         [24] 1635 	lcall	_ak820_outline_0103
                                   1636 ;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00AEAC 90 0C 73         [24] 1637 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AEAF 12 46 89         [24] 1638 	lcall	_ak820_outline_0008
      00AEB2 74 E0            [12] 1639 	mov	a,#0x100 - 0x20
      00AEB4 2D               [12] 1640 	add	a,r5
      00AEB5 50 19            [24] 1641 	jnc	00104$
      00AEB7 C3               [12] 1642 	clr	c
      00AEB8 74 FF            [12] 1643 	mov	a,#0xff
      00AEBA 9C               [12] 1644 	subb	a,r4
      00AEBB 74 4F            [12] 1645 	mov	a,#0x4f
      00AEBD 9D               [12] 1646 	subb	a,r5
      00AEBE 40 10            [24] 1647 	jc	00104$
                                   1648 ;	free result
                                   1649 ;	quantum/vial.c:423: keycode = (uint8_t)keycode;
      00AEC0 90 0C 73         [24] 1650 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AEC3 EE               [12] 1651 	mov	a,r6
      00AEC4 12 38 97         [24] 1652 	lcall	_ak820_outline_0121
                                   1653 ;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
      00AEC7 90 0C 73         [24] 1654 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AECA E0               [24] 1655 	movx	a,@dptr
      00AECB 24 FE            [12] 1656 	add	a,#0xff - 0x01
      00AECD 40 01            [24] 1657 	jc	00104$
                                   1658 ;	free result
      00AECF 22               [24] 1659 	ret
      00AED0                       1660 00104$:
                                   1661 ;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
      00AED0 90 0C 73         [24] 1662 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00AED3 12 AF 28         [24] 1663 	lcall	_ak820_outline_0023
                                   1664 ;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
      00AED6 40 06            [24] 1665 	jc	00107$
                                   1666 ;	free result
                                   1667 ;	quantum/vial.c:430: unregister_code16(keycode);
      00AED8 12 38 8D         [24] 1668 	lcall	_ak820_outline_0112
      00AEDB 02 9A 9F         [24] 1669 	ljmp	_unregister_code16
      00AEDE                       1670 00107$:
                                   1671 ;	quantum/vial.c:432: keyevent_t dummy_event = {
      00AEDE 90 0C 79         [24] 1672 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00AEE1 74 01            [12] 1673 	mov	a,#0x01
      00AEE3 F0               [24] 1674 	movx	@dptr,a
      00AEE4 90 0C 76         [24] 1675 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00AEE7 74 F0            [12] 1676 	mov	a,#0xf0
      00AEE9 F0               [24] 1677 	movx	@dptr,a
      00AEEA 90 0C 75         [24] 1678 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00AEED F0               [24] 1679 	movx	@dptr,a
      00AEEE 90 0C 7A         [24] 1680 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00AEF1 E4               [12] 1681 	clr	a
      00AEF2 F0               [24] 1682 	movx	@dptr,a
      00AEF3 12 47 6F         [24] 1683 	lcall	_timer_read
      00AEF6 12 43 56         [24] 1684 	lcall	_ak820_outline_0130
      00AEF9 43 06 01         [24] 1685 	orl	ar6,#0x01
      00AEFC 90 0C 77         [24] 1686 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00AEFF 12 46 DE         [24] 1687 	lcall	_ak820_outline_0059
                                   1688 ;	quantum/vial.c:436: AK820_ACTION_EXEC(dummy_event);
      00AF02 90 0C 75         [24] 1689 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1690 ;	quantum/vial.c:438: }
      00AF05 02 6E 93         [24] 1691 	ljmp	_ak820_action_exec
                                   1692 ;------------------------------------------------------------
                                   1693 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1694 ;------------------------------------------------------------
                                   1695 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1696 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1697 ;------------------------------------------------------------
                                   1698 ;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
                                   1699 ;	-----------------------------------------
                                   1700 ;	 function vial_keycode_tap
                                   1701 ;	-----------------------------------------
      00AF08                       1702 _vial_keycode_tap:
      00AF08 12 38 88         [24] 1703 	lcall	_ak820_outline_0104
      00AF0B 90 0C 7B         [24] 1704 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AF0E 12 38 83         [24] 1705 	lcall	_ak820_outline_0103
                                   1706 ;	quantum/vial.c:441: vial_keycode_down(keycode);
      00AF11 90 0C 7B         [24] 1707 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00AF14 12 37 F5         [24] 1708 	lcall	_ak820_outline_0005
      00AF17 C0 07            [24] 1709 	push	ar7
      00AF19 C0 06            [24] 1710 	push	ar6
      00AF1B 12 AE 3D         [24] 1711 	lcall	_vial_keycode_down
      00AF1E D0 06            [24] 1712 	pop	ar6
      00AF20 D0 07            [24] 1713 	pop	ar7
                                   1714 ;	quantum/vial.c:443: vial_keycode_up(keycode);
      00AF22 12 38 8D         [24] 1715 	lcall	_ak820_outline_0112
                                   1716 ;	quantum/vial.c:444: }
      00AF25 02 AE A3         [24] 1717 	ljmp	_vial_keycode_up
                                   1718 ;------------------------------------------------------------
                                   1719 ;Allocation info for local variables in function 'process_record_vial'
                                   1720 ;------------------------------------------------------------
                                   1721 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1722 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1723 ;------------------------------------------------------------
                                   1724 ;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1725 ;	-----------------------------------------
                                   1726 	.area CSEG    (CODE)
                                   1727 	.area CONST   (CODE)
                                   1728 	.area CONST   (CODE)
      00BA8B                       1729 _keyboard_definition:
      00BA8B FD                    1730 	.db #0xfd	; 253
      00BA8C 37                    1731 	.db #0x37	; 55	'7'
      00BA8D 7A                    1732 	.db #0x7a	; 122	'z'
      00BA8E 58                    1733 	.db #0x58	; 88	'X'
      00BA8F 5A                    1734 	.db #0x5a	; 90	'Z'
      00BA90 00                    1735 	.db #0x00	; 0
      00BA91 00                    1736 	.db #0x00	; 0
      00BA92 04                    1737 	.db #0x04	; 4
      00BA93 E6                    1738 	.db #0xe6	; 230
      00BA94 D6                    1739 	.db #0xd6	; 214
      00BA95 B4                    1740 	.db #0xb4	; 180
      00BA96 46                    1741 	.db #0x46	; 70	'F'
      00BA97 02                    1742 	.db #0x02	; 2
      00BA98 00                    1743 	.db #0x00	; 0
      00BA99 21                    1744 	.db #0x21	; 33
      00BA9A 01                    1745 	.db #0x01	; 1
      00BA9B 00                    1746 	.db #0x00	; 0
      00BA9C 00                    1747 	.db #0x00	; 0
      00BA9D 00                    1748 	.db #0x00	; 0
      00BA9E 00                    1749 	.db #0x00	; 0
      00BA9F 37                    1750 	.db #0x37	; 55	'7'
      00BAA0 27                    1751 	.db #0x27	; 39
      00BAA1 97                    1752 	.db #0x97	; 151
      00BAA2 D6                    1753 	.db #0xd6	; 214
      00BAA3 E0                    1754 	.db #0xe0	; 224
      00BAA4 03                    1755 	.db #0x03	; 3
      00BAA5 CB                    1756 	.db #0xcb	; 203
      00BAA6 01                    1757 	.db #0x01	; 1
      00BAA7 3C                    1758 	.db #0x3c	; 60
      00BAA8 00                    1759 	.db #0x00	; 0
      00BAA9 00                    1760 	.db #0x00	; 0
      00BAAA 3D                    1761 	.db #0x3d	; 61
      00BAAB 88                    1762 	.db #0x88	; 136
      00BAAC CD                    1763 	.db #0xcd	; 205
      00BAAD A5                    1764 	.db #0xa5	; 165
      00BAAE AA                    1765 	.db #0xaa	; 170
      00BAAF E5                    1766 	.db #0xe5	; 229
      00BAB0 A8                    1767 	.db #0xa8	; 168
      00BAB1 76                    1768 	.db #0x76	; 118	'v'
      00BAB2 F6                    1769 	.db #0xf6	; 246
      00BAB3 43                    1770 	.db #0x43	; 67	'C'
      00BAB4 0E                    1771 	.db #0x0e	; 14
      00BAB5 D2                    1772 	.db #0xd2	; 210
      00BAB6 90                    1773 	.db #0x90	; 144
      00BAB7 7D                    1774 	.db #0x7d	; 125
      00BAB8 94                    1775 	.db #0x94	; 148
      00BAB9 79                    1776 	.db #0x79	; 121	'y'
      00BABA 78                    1777 	.db #0x78	; 120	'x'
      00BABB EF                    1778 	.db #0xef	; 239
      00BABC 49                    1779 	.db #0x49	; 73	'I'
      00BABD 3E                    1780 	.db #0x3e	; 62
      00BABE EF                    1781 	.db #0xef	; 239
      00BABF FD                    1782 	.db #0xfd	; 253
      00BAC0 8F                    1783 	.db #0x8f	; 143
      00BAC1 EF                    1784 	.db #0xef	; 239
      00BAC2 00                    1785 	.db #0x00	; 0
      00BAC3 C6                    1786 	.db #0xc6	; 198
      00BAC4 D1                    1787 	.db #0xd1	; 209
      00BAC5 DB                    1788 	.db #0xdb	; 219
      00BAC6 FB                    1789 	.db #0xfb	; 251
      00BAC7 EB                    1790 	.db #0xeb	; 235
      00BAC8 DE                    1791 	.db #0xde	; 222
      00BAC9 66                    1792 	.db #0x66	; 102	'f'
      00BACA 63                    1793 	.db #0x63	; 99	'c'
      00BACB 0C                    1794 	.db #0x0c	; 12
      00BACC 92                    1795 	.db #0x92	; 146
      00BACD 7B                    1796 	.db #0x7b	; 123
      00BACE F9                    1797 	.db #0xf9	; 249
      00BACF D4                    1798 	.db #0xd4	; 212
      00BAD0 7A                    1799 	.db #0x7a	; 122	'z'
      00BAD1 4F                    1800 	.db #0x4f	; 79	'O'
      00BAD2 83                    1801 	.db #0x83	; 131
      00BAD3 4B                    1802 	.db #0x4b	; 75	'K'
      00BAD4 86                    1803 	.db #0x86	; 134
      00BAD5 0E                    1804 	.db #0x0e	; 14
      00BAD6 6A                    1805 	.db #0x6a	; 106	'j'
      00BAD7 F2                    1806 	.db #0xf2	; 242
      00BAD8 22                    1807 	.db #0x22	; 34
      00BAD9 22                    1808 	.db #0x22	; 34
      00BADA 0B                    1809 	.db #0x0b	; 11
      00BADB 03                    1810 	.db #0x03	; 3
      00BADC BA                    1811 	.db #0xba	; 186
      00BADD 67                    1812 	.db #0x67	; 103	'g'
      00BADE 9B                    1813 	.db #0x9b	; 155
      00BADF 7A                    1814 	.db #0x7a	; 122	'z'
      00BAE0 E1                    1815 	.db #0xe1	; 225
      00BAE1 BC                    1816 	.db #0xbc	; 188
      00BAE2 37                    1817 	.db #0x37	; 55	'7'
      00BAE3 26                    1818 	.db #0x26	; 38
      00BAE4 46                    1819 	.db #0x46	; 70	'F'
      00BAE5 78                    1820 	.db #0x78	; 120	'x'
      00BAE6 05                    1821 	.db #0x05	; 5
      00BAE7 0D                    1822 	.db #0x0d	; 13
      00BAE8 95                    1823 	.db #0x95	; 149
      00BAE9 02                    1824 	.db #0x02	; 2
      00BAEA E4                    1825 	.db #0xe4	; 228
      00BAEB 18                    1826 	.db #0x18	; 24
      00BAEC CA                    1827 	.db #0xca	; 202
      00BAED 33                    1828 	.db #0x33	; 51	'3'
      00BAEE EA                    1829 	.db #0xea	; 234
      00BAEF 24                    1830 	.db #0x24	; 36
      00BAF0 C8                    1831 	.db #0xc8	; 200
      00BAF1 81                    1832 	.db #0x81	; 129
      00BAF2 4E                    1833 	.db #0x4e	; 78	'N'
      00BAF3 47                    1834 	.db #0x47	; 71	'G'
      00BAF4 A8                    1835 	.db #0xa8	; 168
      00BAF5 44                    1836 	.db #0x44	; 68	'D'
      00BAF6 DD                    1837 	.db #0xdd	; 221
      00BAF7 91                    1838 	.db #0x91	; 145
      00BAF8 6D                    1839 	.db #0x6d	; 109	'm'
      00BAF9 69                    1840 	.db #0x69	; 105	'i'
      00BAFA DB                    1841 	.db #0xdb	; 219
      00BAFB 4F                    1842 	.db #0x4f	; 79	'O'
      00BAFC 3A                    1843 	.db #0x3a	; 58
      00BAFD 43                    1844 	.db #0x43	; 67	'C'
      00BAFE 9D                    1845 	.db #0x9d	; 157
      00BAFF 26                    1846 	.db #0x26	; 38
      00BB00 49                    1847 	.db #0x49	; 73	'I'
      00BB01 4C                    1848 	.db #0x4c	; 76	'L'
      00BB02 EF                    1849 	.db #0xef	; 239
      00BB03 2B                    1850 	.db #0x2b	; 43
      00BB04 D8                    1851 	.db #0xd8	; 216
      00BB05 55                    1852 	.db #0x55	; 85	'U'
      00BB06 95                    1853 	.db #0x95	; 149
      00BB07 70                    1854 	.db #0x70	; 112	'p'
      00BB08 B1                    1855 	.db #0xb1	; 177
      00BB09 CC                    1856 	.db #0xcc	; 204
      00BB0A CF                    1857 	.db #0xcf	; 207
      00BB0B 13                    1858 	.db #0x13	; 19
      00BB0C 32                    1859 	.db #0x32	; 50	'2'
      00BB0D 6A                    1860 	.db #0x6a	; 106	'j'
      00BB0E A1                    1861 	.db #0xa1	; 161
      00BB0F FF                    1862 	.db #0xff	; 255
      00BB10 99                    1863 	.db #0x99	; 153
      00BB11 61                    1864 	.db #0x61	; 97	'a'
      00BB12 95                    1865 	.db #0x95	; 149
      00BB13 B1                    1866 	.db #0xb1	; 177
      00BB14 89                    1867 	.db #0x89	; 137
      00BB15 9B                    1868 	.db #0x9b	; 155
      00BB16 11                    1869 	.db #0x11	; 17
      00BB17 D9                    1870 	.db #0xd9	; 217
      00BB18 35                    1871 	.db #0x35	; 53	'5'
      00BB19 78                    1872 	.db #0x78	; 120	'x'
      00BB1A ED                    1873 	.db #0xed	; 237
      00BB1B CD                    1874 	.db #0xcd	; 205
      00BB1C 94                    1875 	.db #0x94	; 148
      00BB1D 6E                    1876 	.db #0x6e	; 110	'n'
      00BB1E 60                    1877 	.db #0x60	; 96
      00BB1F 8E                    1878 	.db #0x8e	; 142
      00BB20 63                    1879 	.db #0x63	; 99	'c'
      00BB21 8B                    1880 	.db #0x8b	; 139
      00BB22 FF                    1881 	.db #0xff	; 255
      00BB23 4E                    1882 	.db #0x4e	; 78	'N'
      00BB24 20                    1883 	.db #0x20	; 32
      00BB25 7A                    1884 	.db #0x7a	; 122	'z'
      00BB26 B5                    1885 	.db #0xb5	; 181
      00BB27 87                    1886 	.db #0x87	; 135
      00BB28 C2                    1887 	.db #0xc2	; 194
      00BB29 35                    1888 	.db #0x35	; 53	'5'
      00BB2A A4                    1889 	.db #0xa4	; 164
      00BB2B 6D                    1890 	.db #0x6d	; 109	'm'
      00BB2C 18                    1891 	.db #0x18	; 24
      00BB2D C1                    1892 	.db #0xc1	; 193
      00BB2E A3                    1893 	.db #0xa3	; 163
      00BB2F DB                    1894 	.db #0xdb	; 219
      00BB30 53                    1895 	.db #0x53	; 83	'S'
      00BB31 1D                    1896 	.db #0x1d	; 29
      00BB32 EC                    1897 	.db #0xec	; 236
      00BB33 F0                    1898 	.db #0xf0	; 240
      00BB34 BF                    1899 	.db #0xbf	; 191
      00BB35 4A                    1900 	.db #0x4a	; 74	'J'
      00BB36 4C                    1901 	.db #0x4c	; 76	'L'
      00BB37 4A                    1902 	.db #0x4a	; 74	'J'
      00BB38 C4                    1903 	.db #0xc4	; 196
      00BB39 AA                    1904 	.db #0xaa	; 170
      00BB3A 37                    1905 	.db #0x37	; 55	'7'
      00BB3B 19                    1906 	.db #0x19	; 25
      00BB3C 34                    1907 	.db #0x34	; 52	'4'
      00BB3D 3F                    1908 	.db #0x3f	; 63
      00BB3E A1                    1909 	.db #0xa1	; 161
      00BB3F D3                    1910 	.db #0xd3	; 211
      00BB40 1A                    1911 	.db #0x1a	; 26
      00BB41 5C                    1912 	.db #0x5c	; 92
      00BB42 03                    1913 	.db #0x03	; 3
      00BB43 4D                    1914 	.db #0x4d	; 77	'M'
      00BB44 BC                    1915 	.db #0xbc	; 188
      00BB45 10                    1916 	.db #0x10	; 16
      00BB46 2E                    1917 	.db #0x2e	; 46
      00BB47 80                    1918 	.db #0x80	; 128
      00BB48 F7                    1919 	.db #0xf7	; 247
      00BB49 D6                    1920 	.db #0xd6	; 214
      00BB4A 82                    1921 	.db #0x82	; 130
      00BB4B 24                    1922 	.db #0x24	; 36
      00BB4C 4C                    1923 	.db #0x4c	; 76	'L'
      00BB4D 87                    1924 	.db #0x87	; 135
      00BB4E B9                    1925 	.db #0xb9	; 185
      00BB4F F8                    1926 	.db #0xf8	; 248
      00BB50 BE                    1927 	.db #0xbe	; 190
      00BB51 67                    1928 	.db #0x67	; 103	'g'
      00BB52 96                    1929 	.db #0x96	; 150
      00BB53 89                    1930 	.db #0x89	; 137
      00BB54 30                    1931 	.db #0x30	; 48	'0'
      00BB55 C8                    1932 	.db #0xc8	; 200
      00BB56 8D                    1933 	.db #0x8d	; 141
      00BB57 2C                    1934 	.db #0x2c	; 44
      00BB58 F5                    1935 	.db #0xf5	; 245
      00BB59 06                    1936 	.db #0x06	; 6
      00BB5A 05                    1937 	.db #0x05	; 5
      00BB5B 7C                    1938 	.db #0x7c	; 124
      00BB5C 48                    1939 	.db #0x48	; 72	'H'
      00BB5D 1B                    1940 	.db #0x1b	; 27
      00BB5E 76                    1941 	.db #0x76	; 118	'v'
      00BB5F AA                    1942 	.db #0xaa	; 170
      00BB60 3D                    1943 	.db #0x3d	; 61
      00BB61 28                    1944 	.db #0x28	; 40
      00BB62 FC                    1945 	.db #0xfc	; 252
      00BB63 80                    1946 	.db #0x80	; 128
      00BB64 75                    1947 	.db #0x75	; 117	'u'
      00BB65 EB                    1948 	.db #0xeb	; 235
      00BB66 78                    1949 	.db #0x78	; 120	'x'
      00BB67 D0                    1950 	.db #0xd0	; 208
      00BB68 8A                    1951 	.db #0x8a	; 138
      00BB69 8F                    1952 	.db #0x8f	; 143
      00BB6A 27                    1953 	.db #0x27	; 39
      00BB6B F7                    1954 	.db #0xf7	; 247
      00BB6C F2                    1955 	.db #0xf2	; 242
      00BB6D EB                    1956 	.db #0xeb	; 235
      00BB6E 58                    1957 	.db #0x58	; 88	'X'
      00BB6F 37                    1958 	.db #0x37	; 55	'7'
      00BB70 3C                    1959 	.db #0x3c	; 60
      00BB71 2B                    1960 	.db #0x2b	; 43
      00BB72 6F                    1961 	.db #0x6f	; 111	'o'
      00BB73 0E                    1962 	.db #0x0e	; 14
      00BB74 C7                    1963 	.db #0xc7	; 199
      00BB75 E2                    1964 	.db #0xe2	; 226
      00BB76 A0                    1965 	.db #0xa0	; 160
      00BB77 97                    1966 	.db #0x97	; 151
      00BB78 EE                    1967 	.db #0xee	; 238
      00BB79 FD                    1968 	.db #0xfd	; 253
      00BB7A 9F                    1969 	.db #0x9f	; 159
      00BB7B 45                    1970 	.db #0x45	; 69	'E'
      00BB7C 17                    1971 	.db #0x17	; 23
      00BB7D 94                    1972 	.db #0x94	; 148
      00BB7E E6                    1973 	.db #0xe6	; 230
      00BB7F E7                    1974 	.db #0xe7	; 231
      00BB80 FA                    1975 	.db #0xfa	; 250
      00BB81 4C                    1976 	.db #0x4c	; 76	'L'
      00BB82 7A                    1977 	.db #0x7a	; 122	'z'
      00BB83 D6                    1978 	.db #0xd6	; 214
      00BB84 7A                    1979 	.db #0x7a	; 122	'z'
      00BB85 7B                    1980 	.db #0x7b	; 123
      00BB86 ED                    1981 	.db #0xed	; 237
      00BB87 10                    1982 	.db #0x10	; 16
      00BB88 C5                    1983 	.db #0xc5	; 197
      00BB89 BC                    1984 	.db #0xbc	; 188
      00BB8A E3                    1985 	.db #0xe3	; 227
      00BB8B A9                    1986 	.db #0xa9	; 169
      00BB8C 1F                    1987 	.db #0x1f	; 31
      00BB8D CF                    1988 	.db #0xcf	; 207
      00BB8E C4                    1989 	.db #0xc4	; 196
      00BB8F 9D                    1990 	.db #0x9d	; 157
      00BB90 DC                    1991 	.db #0xdc	; 220
      00BB91 45                    1992 	.db #0x45	; 69	'E'
      00BB92 2A                    1993 	.db #0x2a	; 42
      00BB93 69                    1994 	.db #0x69	; 105	'i'
      00BB94 57                    1995 	.db #0x57	; 87	'W'
      00BB95 8F                    1996 	.db #0x8f	; 143
      00BB96 EC                    1997 	.db #0xec	; 236
      00BB97 85                    1998 	.db #0x85	; 133
      00BB98 6C                    1999 	.db #0x6c	; 108	'l'
      00BB99 43                    2000 	.db #0x43	; 67	'C'
      00BB9A 1C                    2001 	.db #0x1c	; 28
      00BB9B BA                    2002 	.db #0xba	; 186
      00BB9C 89                    2003 	.db #0x89	; 137
      00BB9D 68                    2004 	.db #0x68	; 104	'h'
      00BB9E 4A                    2005 	.db #0x4a	; 74	'J'
      00BB9F 1C                    2006 	.db #0x1c	; 28
      00BBA0 91                    2007 	.db #0x91	; 145
      00BBA1 3F                    2008 	.db #0x3f	; 63
      00BBA2 D1                    2009 	.db #0xd1	; 209
      00BBA3 B3                    2010 	.db #0xb3	; 179
      00BBA4 96                    2011 	.db #0x96	; 150
      00BBA5 1D                    2012 	.db #0x1d	; 29
      00BBA6 7C                    2013 	.db #0x7c	; 124
      00BBA7 14                    2014 	.db #0x14	; 20
      00BBA8 77                    2015 	.db #0x77	; 119	'w'
      00BBA9 9C                    2016 	.db #0x9c	; 156
      00BBAA 74                    2017 	.db #0x74	; 116	't'
      00BBAB 36                    2018 	.db #0x36	; 54	'6'
      00BBAC FF                    2019 	.db #0xff	; 255
      00BBAD 2C                    2020 	.db #0x2c	; 44
      00BBAE 66                    2021 	.db #0x66	; 102	'f'
      00BBAF AF                    2022 	.db #0xaf	; 175
      00BBB0 0F                    2023 	.db #0x0f	; 15
      00BBB1 3C                    2024 	.db #0x3c	; 60
      00BBB2 A2                    2025 	.db #0xa2	; 162
      00BBB3 23                    2026 	.db #0x23	; 35
      00BBB4 85                    2027 	.db #0x85	; 133
      00BBB5 05                    2028 	.db #0x05	; 5
      00BBB6 87                    2029 	.db #0x87	; 135
      00BBB7 DA                    2030 	.db #0xda	; 218
      00BBB8 61                    2031 	.db #0x61	; 97	'a'
      00BBB9 5E                    2032 	.db #0x5e	; 94
      00BBBA 42                    2033 	.db #0x42	; 66	'B'
      00BBBB 54                    2034 	.db #0x54	; 84	'T'
      00BBBC 60                    2035 	.db #0x60	; 96
      00BBBD 23                    2036 	.db #0x23	; 35
      00BBBE CA                    2037 	.db #0xca	; 202
      00BBBF BC                    2038 	.db #0xbc	; 188
      00BBC0 B3                    2039 	.db #0xb3	; 179
      00BBC1 18                    2040 	.db #0x18	; 24
      00BBC2 1D                    2041 	.db #0x1d	; 29
      00BBC3 F8                    2042 	.db #0xf8	; 248
      00BBC4 0A                    2043 	.db #0x0a	; 10
      00BBC5 55                    2044 	.db #0x55	; 85	'U'
      00BBC6 CD                    2045 	.db #0xcd	; 205
      00BBC7 A3                    2046 	.db #0xa3	; 163
      00BBC8 DE                    2047 	.db #0xde	; 222
      00BBC9 FF                    2048 	.db #0xff	; 255
      00BBCA B2                    2049 	.db #0xb2	; 178
      00BBCB 2A                    2050 	.db #0x2a	; 42
      00BBCC 35                    2051 	.db #0x35	; 53	'5'
      00BBCD 00                    2052 	.db #0x00	; 0
      00BBCE D6                    2053 	.db #0xd6	; 214
      00BBCF 7B                    2054 	.db #0x7b	; 123
      00BBD0 E8                    2055 	.db #0xe8	; 232
      00BBD1 F2                    2056 	.db #0xf2	; 242
      00BBD2 1A                    2057 	.db #0x1a	; 26
      00BBD3 BC                    2058 	.db #0xbc	; 188
      00BBD4 F5                    2059 	.db #0xf5	; 245
      00BBD5 7E                    2060 	.db #0x7e	; 126
      00BBD6 48                    2061 	.db #0x48	; 72	'H'
      00BBD7 72                    2062 	.db #0x72	; 114	'r'
      00BBD8 E0                    2063 	.db #0xe0	; 224
      00BBD9 E4                    2064 	.db #0xe4	; 228
      00BBDA E0                    2065 	.db #0xe0	; 224
      00BBDB 27                    2066 	.db #0x27	; 39
      00BBDC 87                    2067 	.db #0x87	; 135
      00BBDD 9A                    2068 	.db #0x9a	; 154
      00BBDE 51                    2069 	.db #0x51	; 81	'Q'
      00BBDF D4                    2070 	.db #0xd4	; 212
      00BBE0 DD                    2071 	.db #0xdd	; 221
      00BBE1 C3                    2072 	.db #0xc3	; 195
      00BBE2 AA                    2073 	.db #0xaa	; 170
      00BBE3 49                    2074 	.db #0x49	; 73	'I'
      00BBE4 5A                    2075 	.db #0x5a	; 90	'Z'
      00BBE5 2A                    2076 	.db #0x2a	; 42
      00BBE6 00                    2077 	.db #0x00	; 0
      00BBE7 A0                    2078 	.db #0xa0	; 160
      00BBE8 8C                    2079 	.db #0x8c	; 140
      00BBE9 FF                    2080 	.db #0xff	; 255
      00BBEA 74                    2081 	.db #0x74	; 116	't'
      00BBEB BF                    2082 	.db #0xbf	; 191
      00BBEC EC                    2083 	.db #0xec	; 236
      00BBED 1D                    2084 	.db #0x1d	; 29
      00BBEE F1                    2085 	.db #0xf1	; 241
      00BBEF 00                    2086 	.db #0x00	; 0
      00BBF0 01                    2087 	.db #0x01	; 1
      00BBF1 D8                    2088 	.db #0xd8	; 216
      00BBF2 02                    2089 	.db #0x02	; 2
      00BBF3 CC                    2090 	.db #0xcc	; 204
      00BBF4 07                    2091 	.db #0x07	; 7
      00BBF5 00                    2092 	.db #0x00	; 0
      00BBF6 00                    2093 	.db #0x00	; 0
      00BBF7 C4                    2094 	.db #0xc4	; 196
      00BBF8 5E                    2095 	.db #0x5e	; 94
      00BBF9 2C                    2096 	.db #0x2c	; 44
      00BBFA 7E                    2097 	.db #0x7e	; 126
      00BBFB B1                    2098 	.db #0xb1	; 177
      00BBFC C4                    2099 	.db #0xc4	; 196
      00BBFD 67                    2100 	.db #0x67	; 103	'g'
      00BBFE FB                    2101 	.db #0xfb	; 251
      00BBFF 02                    2102 	.db #0x02	; 2
      00BC00 00                    2103 	.db #0x00	; 0
      00BC01 00                    2104 	.db #0x00	; 0
      00BC02 00                    2105 	.db #0x00	; 0
      00BC03 00                    2106 	.db #0x00	; 0
      00BC04 04                    2107 	.db #0x04	; 4
      00BC05 59                    2108 	.db #0x59	; 89	'Y'
      00BC06 5A                    2109 	.db #0x5a	; 90	'Z'
                                   2110 	.area CSEG    (CODE)
                                   2111 	.area CONST   (CODE)
      00BC07                       2112 _vial_handle_cmd_keyboard_uid_40000_622:
      00BC07 04                    2113 	.db #0x04	; 4
      00BC08 70                    2114 	.db #0x70	; 112	'p'
      00BC09 FF                    2115 	.db #0xff	; 255
      00BC0A 90                    2116 	.db #0x90	; 144
      00BC0B 01                    2117 	.db #0x01	; 1
      00BC0C B9                    2118 	.db #0xb9	; 185
      00BC0D 15                    2119 	.db #0x15	; 21
      00BC0E D3                    2120 	.db #0xd3	; 211
                                   2121 	.area CSEG    (CODE)
                                   2122 	.area XINIT   (CODE)
      00BE3C                       2123 __xinit__vial_unlocked:
      00BE3C 00                    2124 	.db #0x00	;  0
      00BE3D                       2125 __xinit__vial_unlock_in_progress:
      00BE3D 00                    2126 	.db #0x00	;  0
      00BE3E                       2127 __xinit__vial_unlock_counter:
      00BE3E 00                    2128 	.db #0x00	; 0
      00BE3F                       2129 __xinit__vial_unlock_combo_rows:
      00BE3F 00                    2130 	.db #0x00	; 0
      00BE40 00                    2131 	.db #0x00	; 0
      00BE41                       2132 __xinit__vial_unlock_combo_cols:
      00BE41 00                    2133 	.db #0x00	; 0
      00BE42 05                    2134 	.db #0x05	; 5
                                   2135 	.area CABS    (ABS,CODE)
                                   2136 
                                   2137 ; Experimental exact instruction outlining.
                                   2138 	.globl _ak820_outline_0005
                                   2139 	.globl _ak820_outline_0006
                                   2140 	.globl _ak820_outline_0008
                                   2141 	.globl _ak820_outline_0011
                                   2142 	.globl _ak820_outline_0015
                                   2143 	.globl _ak820_outline_0016
                                   2144 	.globl _ak820_outline_0020
                                   2145 	.globl _ak820_outline_0021
                                   2146 	.globl _ak820_outline_0023
                                   2147 	.globl _ak820_outline_0030
                                   2148 	.globl _ak820_outline_0031
                                   2149 	.globl _ak820_outline_0032
                                   2150 	.globl _ak820_outline_0035
                                   2151 	.globl _ak820_outline_0036
                                   2152 	.globl _ak820_outline_0051
                                   2153 	.globl _ak820_outline_0054
                                   2154 	.globl _ak820_outline_0056
                                   2155 	.globl _ak820_outline_0059
                                   2156 	.globl _ak820_outline_0071
                                   2157 	.globl _ak820_outline_0073
                                   2158 	.globl _ak820_outline_0080
                                   2159 	.globl _ak820_outline_0088
                                   2160 	.globl _ak820_outline_0099
                                   2161 	.globl _ak820_outline_0103
                                   2162 	.globl _ak820_outline_0104
                                   2163 	.globl _ak820_outline_0112
                                   2164 	.globl _ak820_outline_0116
                                   2165 	.globl _ak820_outline_0119
                                   2166 	.globl _ak820_outline_0120
                                   2167 	.globl _ak820_outline_0121
                                   2168 	.globl _ak820_outline_0123
                                   2169 	.globl _ak820_outline_0124
                                   2170 	.globl _ak820_outline_0130
                                   2171 	.globl _ak820_outline_0134
                                   2172 	.globl _ak820_outline_0138
                                   2173 	.globl _ak820_outline_0151
                                   2174 	.globl _ak820_outline_0164
                                   2175 	.globl _ak820_outline_0183
                                   2176 
                                   2177 	.area CSEG (CODE)
                                   2178 ; function ak820_outline_0023
      00AF28                       2179 _ak820_outline_0023:
      00AF28 E0               [24] 2180 	movx	a,@dptr
      00AF29 FE               [12] 2181 	mov	r6,a
      00AF2A A3               [24] 2182 	inc	dptr
      00AF2B E0               [24] 2183 	movx	a,@dptr
      00AF2C FF               [12] 2184 	mov	r7,a
      00AF2D 90 0C 69         [24] 2185 	mov	dptr,#_g_vial_magic_keycode_override
      00AF30 EE               [12] 2186 	mov	a,r6
      00AF31 F0               [24] 2187 	movx	@dptr,a
      00AF32 EF               [12] 2188 	mov	a,r7
      00AF33 A3               [24] 2189 	inc	dptr
      00AF34 F0               [24] 2190 	movx	@dptr,a
      00AF35 8E 04            [24] 2191 	mov	ar4,r6
      00AF37 8F 05            [24] 2192 	mov	ar5,r7
      00AF39 C3               [12] 2193 	clr	c
      00AF3A 74 FF            [12] 2194 	mov	a,#0xff
      00AF3C 9C               [12] 2195 	subb	a,r4
      00AF3D 74 1F            [12] 2196 	mov	a,#0x1f
      00AF3F 9D               [12] 2197 	subb	a,r5
      00AF40 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0073
      00AF41                       2202 _ak820_outline_0073:
      00AF41 A3               [24] 2203 	inc	dptr
      00AF42 F0               [24] 2204 	movx	@dptr,a
      00AF43 E4               [12] 2205 	clr	a
      00AF44 A3               [24] 2206 	inc	dptr
      00AF45 F0               [24] 2207 	movx	@dptr,a
      00AF46 90 0D 94         [24] 2208 	mov	dptr,#___memcpy_PARM_3
      00AF49 74 0A            [12] 2209 	mov	a,#0x0a
      00AF4B F0               [24] 2210 	movx	@dptr,a
      00AF4C E4               [12] 2211 	clr	a
      00AF4D A3               [24] 2212 	inc	dptr
      00AF4E F0               [24] 2213 	movx	@dptr,a
      00AF4F 22               [24] 2214 	ret
                                   2215 
                                   2216 	.area CSEG (CODE)
                                   2217 ; function ak820_outline_0123
      00AF50                       2218 _ak820_outline_0123:
      00AF50 24 15            [12] 2219 	add	a,#_vial_unlock_combo_cols
      00AF52 F5 82            [12] 2220 	mov	dpl,a
      00AF54 E4               [12] 2221 	clr	a
      00AF55 34 0E            [12] 2222 	addc	a,#(_vial_unlock_combo_cols>>8)
      00AF57 F5 83            [12] 2223 	mov	dph,a
      00AF59 E0               [24] 2224 	movx	a,@dptr
      00AF5A 22               [24] 2225 	ret
                                   2226 
                                   2227 	.area CSEG (CODE)
                                   2228 ; function ak820_outline_0124
      00AF5B                       2229 _ak820_outline_0124:
      00AF5B 24 13            [12] 2230 	add	a,#_vial_unlock_combo_rows
      00AF5D F5 82            [12] 2231 	mov	dpl,a
      00AF5F E4               [12] 2232 	clr	a
      00AF60 34 0E            [12] 2233 	addc	a,#(_vial_unlock_combo_rows>>8)
      00AF62 F5 83            [12] 2234 	mov	dph,a
      00AF64 E0               [24] 2235 	movx	a,@dptr
      00AF65 22               [24] 2236 	ret
