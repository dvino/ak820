                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000017                        577 _control_setup_valid_interface_10000_287:
      000017                        578 	.ds 1
      000018                        579 _control_setup_zero_index_10000_287:
      000018                        580 	.ds 1
      000019                        581 _control_setup_zero_value_10000_287:
      000019                        582 	.ds 1
      00001A                        583 _control_setup_zero_length_10000_287:
      00001A                        584 	.ds 1
      00001B                        585 _control_setup_sloc0_1_0:
      00001B                        586 	.ds 1
      00001C                        587 _control_setup_sloc2_1_0:
      00001C                        588 	.ds 1
      00001D                        589 _ak820_usb_try_send_sloc0_1_0:
      00001D                        590 	.ds 1
      00001E                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        592 	.ds 1
      00001F                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      00001F                        594 	.ds 1
      000020                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000020                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007BB                        605 _D0SetupReqCode::
      0007BB                        606 	.ds 1
      0007BC                        607 _D0SetupLen::
      0007BC                        608 	.ds 2
      0007BE                        609 _pD0Descr::
      0007BE                        610 	.ds 3
      0007C1                        611 _D0UsbConfig::
      0007C1                        612 	.ds 1
      0007C2                        613 _USB_EnumStatus::
      0007C2                        614 	.ds 1
      0007C3                        615 _USB_SleepStatus::
      0007C3                        616 	.ds 1
      0007C4                        617 _MCU_Sleep_Operate::
      0007C4                        618 	.ds 1
      0007C5                        619 _KB_USB_UpStatus::
      0007C5                        620 	.ds 1
      0007C6                        621 _KB_USB_SetReport::
      0007C6                        622 	.ds 1
      0007C7                        623 _ak820_boot_stage::
      0007C7                        624 	.ds 1
      0007C8                        625 _ak820_main_heartbeat::
      0007C8                        626 	.ds 1
      0007C9                        627 _raw_state:
      0007C9                        628 	.ds 1
      0007CA                        629 _raw_buffer:
      0007CA                        630 	.ds 32
      0007EA                        631 _raw_reply_without_nvm:
      0007EA                        632 	.ds 1
      0007EB                        633 _keyboard_reset:
      0007EB                        634 	.ds 1
      0007EC                        635 _input_snapshot:
      0007EC                        636 	.ds 46
      00081A                        637 _control_phase:
      00081A                        638 	.ds 1
      00081B                        639 _output_kind:
      00081B                        640 	.ds 1
      00081C                        641 _output_report_id:
      00081C                        642 	.ds 1
      00081D                        643 _control_zlp:
      00081D                        644 	.ds 1
      00081E                        645 _control_pointer:
      00081E                        646 	.ds 2
      000820                        647 _descriptor_select_PARM_2:
      000820                        648 	.ds 1
      000821                        649 _descriptor_select_PARM_3:
      000821                        650 	.ds 2
      000823                        651 _descriptor_select_type_10000_269:
      000823                        652 	.ds 1
      000824                        653 _control_setup_length_10000_287:
      000824                        654 	.ds 2
      000826                        655 _control_setup_offset_10000_287:
      000826                        656 	.ds 1
      000827                        657 _ak820_usb_send_PARM_2:
      000827                        658 	.ds 2
      000829                        659 _ak820_usb_send_PARM_3:
      000829                        660 	.ds 1
      00082A                        661 _ak820_usb_send_endpoint_10000_423:
      00082A                        662 	.ds 1
      00082B                        663 _ak820_usb_send_offset_10000_424:
      00082B                        664 	.ds 1
      00082C                        665 _ak820_usb_try_send_PARM_2:
      00082C                        666 	.ds 2
      00082E                        667 _ak820_usb_try_send_PARM_3:
      00082E                        668 	.ds 1
      00082F                        669 _ak820_usb_try_send_endpoint_10000_444:
      00082F                        670 	.ds 1
      000830                        671 _ak820_usb_try_send_sent_10000_445:
      000830                        672 	.ds 1
      000831                        673 _ak820_usb_raw_send_PARM_2:
      000831                        674 	.ds 1
      000832                        675 _ak820_usb_raw_send_report_10000_460:
      000832                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      005D84                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D84 90 07 C9         [24]  730 	mov	dptr,#_raw_state
      005D87 E0               [24]  731 	movx	a,@dptr
      005D88 FF               [12]  732 	mov	r7,a
      005D89 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      005D8C 80 1C            [24]  734 	sjmp	00101$
      005D8E                        735 00130$:
      005D8E 90 07 C9         [24]  736 	mov	dptr,#_raw_state
      005D91 E0               [24]  737 	movx	a,@dptr
      005D92 FF               [12]  738 	mov	r7,a
      005D93 BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      005D96 80 12            [24]  740 	sjmp	00101$
      005D98                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005D98 90 07 C9         [24]  743 	mov	dptr,#_raw_state
      005D9B E0               [24]  744 	movx	a,@dptr
      005D9C FF               [12]  745 	mov	r7,a
      005D9D BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      005DA0 80 08            [24]  747 	sjmp	00101$
      005DA2                        748 00132$:
      005DA2 90 07 C9         [24]  749 	mov	dptr,#_raw_state
      005DA5 E0               [24]  750 	movx	a,@dptr
      005DA6 FF               [12]  751 	mov	r7,a
      005DA7 BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      005DAA                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005DAA 90 07 C9         [24]  755 	mov	dptr,#_raw_state
      005DAD 74 07            [12]  756 	mov	a,#0x07
      005DAF F0               [24]  757 	movx	@dptr,a
      005DB0 80 05            [24]  758 	sjmp	00103$
      005DB2                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005DB2 90 07 C9         [24]  761 	mov	dptr,#_raw_state
      005DB5 E4               [12]  762 	clr	a
      005DB6 F0               [24]  763 	movx	@dptr,a
      005DB7                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005DB7 90 08 1B         [24]  766 	mov	dptr,#_output_kind
      005DBA E4               [12]  767 	clr	a
      005DBB F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005DBC 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      005DBD                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005DBD 90 07 C9         [24]  780 	mov	dptr,#_raw_state
      005DC0 E0               [24]  781 	movx	a,@dptr
      005DC1 FF               [12]  782 	mov	r7,a
      005DC2 BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      005DC5 90 07 C9         [24]  784 	mov	dptr,#_raw_state
      005DC8 74 06            [12]  785 	mov	a,#0x06
      005DCA F0               [24]  786 	movx	@dptr,a
      005DCB 22               [24]  787 	ret
      005DCC                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005DCC 90 07 C9         [24]  790 	mov	dptr,#_raw_state
      005DCF E0               [24]  791 	movx	a,@dptr
      005DD0 FF               [12]  792 	mov	r7,a
      005DD1 BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      005DD4 90 07 C9         [24]  794 	mov	dptr,#_raw_state
      005DD7 E4               [12]  795 	clr	a
      005DD8 F0               [24]  796 	movx	@dptr,a
      005DD9                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005DD9 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      005DDA                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005DDA 90 22 0C         [24]  811 	mov	dptr,#0x220c
      005DDD 74 01            [12]  812 	mov	a,#0x01
      005DDF F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE0 F5 82            [12]  815 	mov	dpl,a
      005DE2 74 12            [12]  816 	mov	a,#0x12
      005DE4 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE5 A3               [24]  819 	inc	dptr
      005DE6 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DE7 A3               [24]  822 	inc	dptr
      005DE8 F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005DE9 90 22 0B         [24]  825 	mov	dptr,#0x220b
      005DEC E4               [12]  826 	clr	a
      005DED F0               [24]  827 	movx	@dptr,a
      005DEE 15 82            [12]  828 	dec	dpl
      005DF0 F0               [24]  829 	movx	@dptr,a
      005DF1 15 82            [12]  830 	dec	dpl
      005DF3 F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005DF4 FF               [12]  833 	mov	r7,a
      005DF5                        834 00103$:
      005DF5 EF               [12]  835 	mov	a,r7
      005DF6 24 EC            [12]  836 	add	a, #_input_snapshot
      005DF8 F5 82            [12]  837 	mov	dpl,a
      005DFA E4               [12]  838 	clr	a
      005DFB 34 07            [12]  839 	addc	a, #(_input_snapshot >> 8)
      005DFD F5 83            [12]  840 	mov	dph,a
      005DFF E4               [12]  841 	clr	a
      005E00 F0               [24]  842 	movx	@dptr,a
      005E01 0F               [12]  843 	inc	r7
      005E02 BF 2E 00         [24]  844 	cjne	r7,#0x2e,00139$
      005E05                        845 00139$:
      005E05 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005E07 90 07 F4         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      005E0A 74 06            [12]  849 	mov	a,#0x06
      005E0C F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005E0D 90 08 14         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      005E10 03               [12]  853 	rr	a
      005E11 F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005E12 90 08 17         [24]  856 	mov	dptr,#(_input_snapshot + 0x002b)
      005E15 04               [12]  857 	inc	a
      005E16 F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005E17 7F 00            [12]  860 	mov	r7,#0x00
      005E19                        861 00105$:
      005E19 8F 06            [24]  862 	mov	ar6,r7
      005E1B 74 C0            [12]  863 	mov	a,#0xc0
      005E1D 2E               [12]  864 	add	a, r6
      005E1E F5 82            [12]  865 	mov	dpl,a
      005E20 74 10            [12]  866 	mov	a,#0x10
      005E22 24 00            [12]  867 	add	a, #0x00
      005E24 F5 83            [12]  868 	mov	dph,a
      005E26 E4               [12]  869 	clr	a
      005E27 F0               [24]  870 	movx	@dptr,a
      005E28 0F               [12]  871 	inc	r7
      005E29 BF 20 00         [24]  872 	cjne	r7,#0x20,00141$
      005E2C                        873 00141$:
      005E2C 40 EB            [24]  874 	jc	00105$
                                    875 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005E2E 02 5D 84         [24]  877 	ljmp	_raw_abort
                                    878 ;------------------------------------------------------------
                                    879 ;Allocation info for local variables in function 'control_stall'
                                    880 ;------------------------------------------------------------
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function control_stall
                                    884 ;	-----------------------------------------
      005E31                        885 _control_stall:
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005E31 90 07 C9         [24]  887 	mov	dptr,#_raw_state
      005E34 E0               [24]  888 	movx	a,@dptr
      005E35 FF               [12]  889 	mov	r7,a
      005E36 BF 01 05         [24]  890 	cjne	r7,#0x01,00102$
      005E39 90 07 C9         [24]  891 	mov	dptr,#_raw_state
      005E3C E4               [12]  892 	clr	a
      005E3D F0               [24]  893 	movx	@dptr,a
      005E3E                        894 00102$:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005E3E 90 08 1B         [24]  896 	mov	dptr,#_output_kind
      005E41 E4               [12]  897 	clr	a
      005E42 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005E43 90 08 1A         [24]  900 	mov	dptr,#_control_phase
      005E46 F0               [24]  901 	movx	@dptr,a
                                    902 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005E47 90 07 BB         [24]  903 	mov	dptr,#_D0SetupReqCode
      005E4A 14               [12]  904 	dec	a
      005E4B F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005E4C 90 22 00         [24]  907 	mov	dptr,#0x2200
      005E4F 74 CF            [12]  908 	mov	a,#0xcf
      005E51 F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005E52 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'control_next'
                                    914 ;------------------------------------------------------------
                                    915 ;i             Allocated with name '_control_next_i_10000_266'
                                    916 ;length        Allocated with name '_control_next_length_10000_266'
                                    917 ;------------------------------------------------------------
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function control_next
                                    921 ;	-----------------------------------------
      005E53                        922 _control_next:
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005E53 90 07 BC         [24]  924 	mov	dptr,#_D0SetupLen
      005E56 E0               [24]  925 	movx	a,@dptr
      005E57 FE               [12]  926 	mov	r6,a
      005E58 A3               [24]  927 	inc	dptr
      005E59 E0               [24]  928 	movx	a,@dptr
      005E5A FF               [12]  929 	mov	r7,a
      005E5B C3               [12]  930 	clr	c
      005E5C 74 40            [12]  931 	mov	a,#0x40
      005E5E 9E               [12]  932 	subb	a,r6
      005E5F E4               [12]  933 	clr	a
      005E60 9F               [12]  934 	subb	a,r7
      005E61 50 04            [24]  935 	jnc	00109$
                                    936 ;	free result
      005E63 7E 40            [12]  937 	mov	r6,#0x40
      005E65 80 07            [24]  938 	sjmp	00110$
      005E67                        939 00109$:
      005E67 90 07 BC         [24]  940 	mov	dptr,#_D0SetupLen
      005E6A E0               [24]  941 	movx	a,@dptr
      005E6B FE               [12]  942 	mov	r6,a
      005E6C A3               [24]  943 	inc	dptr
      005E6D E0               [24]  944 	movx	a,@dptr
      005E6E                        945 00110$:
                                    946 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E6E 7F 00            [12]  947 	mov	r7,#0x00
      005E70                        948 00105$:
      005E70 C3               [12]  949 	clr	c
      005E71 EF               [12]  950 	mov	a,r7
      005E72 9E               [12]  951 	subb	a,r6
      005E73 50 2A            [24]  952 	jnc	00101$
      005E75 8F 04            [24]  953 	mov	ar4,r7
      005E77 74 10            [12]  954 	mov	a,#0x10
      005E79 24 00            [12]  955 	add	a, #0x00
      005E7B FD               [12]  956 	mov	r5,a
      005E7C 90 08 1E         [24]  957 	mov	dptr,#_control_pointer
      005E7F E0               [24]  958 	movx	a,@dptr
      005E80 FA               [12]  959 	mov	r2,a
      005E81 A3               [24]  960 	inc	dptr
      005E82 E0               [24]  961 	movx	a,@dptr
      005E83 FB               [12]  962 	mov	r3,a
      005E84 8A 82            [24]  963 	mov	dpl,r2
      005E86 8B 83            [24]  964 	mov	dph,r3
      005E88 E4               [12]  965 	clr	a
      005E89 93               [24]  966 	movc	a,@a+dptr
      005E8A F9               [12]  967 	mov	r1,a
      005E8B 90 08 1E         [24]  968 	mov	dptr,#_control_pointer
      005E8E 74 01            [12]  969 	mov	a,#0x01
      005E90 2A               [12]  970 	add	a, r2
      005E91 F0               [24]  971 	movx	@dptr,a
      005E92 E4               [12]  972 	clr	a
      005E93 3B               [12]  973 	addc	a, r3
      005E94 A3               [24]  974 	inc	dptr
      005E95 F0               [24]  975 	movx	@dptr,a
      005E96 8C 82            [24]  976 	mov	dpl,r4
      005E98 8D 83            [24]  977 	mov	dph,r5
      005E9A E9               [12]  978 	mov	a,r1
      005E9B F0               [24]  979 	movx	@dptr,a
      005E9C 0F               [12]  980 	inc	r7
      005E9D 80 D1            [24]  981 	sjmp	00105$
      005E9F                        982 00101$:
                                    983 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005E9F 8E 05            [24]  984 	mov	ar5,r6
      005EA1 7F 00            [12]  985 	mov	r7,#0x00
      005EA3 90 07 BC         [24]  986 	mov	dptr,#_D0SetupLen
      005EA6 E0               [24]  987 	movx	a,@dptr
      005EA7 FB               [12]  988 	mov	r3,a
      005EA8 A3               [24]  989 	inc	dptr
      005EA9 E0               [24]  990 	movx	a,@dptr
      005EAA FC               [12]  991 	mov	r4,a
      005EAB EB               [12]  992 	mov	a,r3
      005EAC C3               [12]  993 	clr	c
      005EAD 9D               [12]  994 	subb	a,r5
      005EAE FB               [12]  995 	mov	r3,a
      005EAF EC               [12]  996 	mov	a,r4
      005EB0 9F               [12]  997 	subb	a,r7
      005EB1 FC               [12]  998 	mov	r4,a
      005EB2 90 07 BC         [24]  999 	mov	dptr,#_D0SetupLen
      005EB5 EB               [12] 1000 	mov	a,r3
      005EB6 F0               [24] 1001 	movx	@dptr,a
      005EB7 EC               [12] 1002 	mov	a,r4
      005EB8 A3               [24] 1003 	inc	dptr
      005EB9 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005EBA EE               [12] 1006 	mov	a,r6
      005EBB 70 05            [24] 1007 	jnz	00103$
      005EBD 90 08 1D         [24] 1008 	mov	dptr,#_control_zlp
      005EC0 E4               [12] 1009 	clr	a
      005EC1 F0               [24] 1010 	movx	@dptr,a
      005EC2                       1011 00103$:
                                   1012 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005EC2 90 22 08         [24] 1013 	mov	dptr,#0x2208
      005EC5 EE               [12] 1014 	mov	a,r6
      005EC6 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005EC7 90 22 00         [24] 1017 	mov	dptr,#0x2200
      005ECA E0               [24] 1018 	movx	a,@dptr
      005ECB 54 C0            [12] 1019 	anl	a,#0xc0
      005ECD F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005ECE 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'descriptor_select'
                                   1025 ;------------------------------------------------------------
                                   1026 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1027 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1028 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1029 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function descriptor_select
                                   1034 ;	-----------------------------------------
      005ECF                       1035 _descriptor_select:
      005ECF E5 82            [12] 1036 	mov	a,dpl
      005ED1 90 08 23         [24] 1037 	mov	dptr,#_descriptor_select_type_10000_269
      005ED4 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005ED5 E0               [24] 1040 	movx	a,@dptr
      005ED6 FF               [12] 1041 	mov	r7,a
      005ED7 BF 01 20         [24] 1042 	cjne	r7,#0x01,00102$
      005EDA 90 08 20         [24] 1043 	mov	dptr,#_descriptor_select_PARM_2
      005EDD E0               [24] 1044 	movx	a,@dptr
      005EDE 70 1A            [24] 1045 	jnz	00102$
      005EE0 90 08 21         [24] 1046 	mov	dptr,#_descriptor_select_PARM_3
      005EE3 E0               [24] 1047 	movx	a,@dptr
      005EE4 F5 F0            [12] 1048 	mov	b,a
      005EE6 A3               [24] 1049 	inc	dptr
      005EE7 E0               [24] 1050 	movx	a,@dptr
      005EE8 45 F0            [12] 1051 	orl	a,b
      005EEA 70 0E            [24] 1052 	jnz	00102$
                                   1053 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005EEC 90 08 1E         [24] 1054 	mov	dptr,#_control_pointer
      005EEF 74 DD            [12] 1055 	mov	a,#_DeviceDescriptor
      005EF1 F0               [24] 1056 	movx	@dptr,a
      005EF2 74 C3            [12] 1057 	mov	a,#(_DeviceDescriptor >> 8)
      005EF4 A3               [24] 1058 	inc	dptr
      005EF5 F0               [24] 1059 	movx	@dptr,a
                                   1060 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005EF6 90 00 12         [24] 1061 	mov	dptr,#0x0012
      005EF9 22               [24] 1062 	ret
      005EFA                       1063 00102$:
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005EFA 90 08 23         [24] 1065 	mov	dptr,#_descriptor_select_type_10000_269
      005EFD E0               [24] 1066 	movx	a,@dptr
      005EFE FF               [12] 1067 	mov	r7,a
      005EFF BF 02 20         [24] 1068 	cjne	r7,#0x02,00106$
      005F02 90 08 20         [24] 1069 	mov	dptr,#_descriptor_select_PARM_2
      005F05 E0               [24] 1070 	movx	a,@dptr
      005F06 70 1A            [24] 1071 	jnz	00106$
      005F08 90 08 21         [24] 1072 	mov	dptr,#_descriptor_select_PARM_3
      005F0B E0               [24] 1073 	movx	a,@dptr
      005F0C F5 F0            [12] 1074 	mov	b,a
      005F0E A3               [24] 1075 	inc	dptr
      005F0F E0               [24] 1076 	movx	a,@dptr
      005F10 45 F0            [12] 1077 	orl	a,b
      005F12 70 0E            [24] 1078 	jnz	00106$
                                   1079 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005F14 90 08 1E         [24] 1080 	mov	dptr,#_control_pointer
      005F17 74 EF            [12] 1081 	mov	a,#_ConfigurationDescriptor
      005F19 F0               [24] 1082 	movx	@dptr,a
      005F1A 74 C3            [12] 1083 	mov	a,#(_ConfigurationDescriptor >> 8)
      005F1C A3               [24] 1084 	inc	dptr
      005F1D F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005F1E 90 00 54         [24] 1087 	mov	dptr,#0x0054
      005F21 22               [24] 1088 	ret
      005F22                       1089 00106$:
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005F22 90 08 23         [24] 1091 	mov	dptr,#_descriptor_select_type_10000_269
      005F25 E0               [24] 1092 	movx	a,@dptr
      005F26 FF               [12] 1093 	mov	r7,a
      005F27 BF 03 02         [24] 1094 	cjne	r7,#0x03,00238$
      005F2A 80 03            [24] 1095 	sjmp	00239$
      005F2C                       1096 00238$:
      005F2C 02 5F C6         [24] 1097 	ljmp	00119$
      005F2F                       1098 00239$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005F2F 90 08 21         [24] 1100 	mov	dptr,#_descriptor_select_PARM_3
      005F32 E0               [24] 1101 	movx	a,@dptr
      005F33 FD               [12] 1102 	mov	r5,a
      005F34 A3               [24] 1103 	inc	dptr
      005F35 E0               [24] 1104 	movx	a,@dptr
      005F36 FE               [12] 1105 	mov	r6,a
      005F37 90 08 21         [24] 1106 	mov	dptr,#_descriptor_select_PARM_3
      005F3A E0               [24] 1107 	movx	a,@dptr
      005F3B F5 F0            [12] 1108 	mov	b,a
      005F3D A3               [24] 1109 	inc	dptr
      005F3E E0               [24] 1110 	movx	a,@dptr
      005F3F 45 F0            [12] 1111 	orl	a,b
      005F41 60 0C            [24] 1112 	jz	00110$
      005F43 BD 09 05         [24] 1113 	cjne	r5,#0x09,00241$
      005F46 BE 04 02         [24] 1114 	cjne	r6,#0x04,00241$
      005F49 80 04            [24] 1115 	sjmp	00110$
      005F4B                       1116 00241$:
      005F4B 90 00 00         [24] 1117 	mov	dptr,#0x0000
      005F4E 22               [24] 1118 	ret
      005F4F                       1119 00110$:
                                   1120 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005F4F 90 08 20         [24] 1121 	mov	dptr,#_descriptor_select_PARM_2
      005F52 E0               [24] 1122 	movx	a,@dptr
      005F53 FE               [12] 1123 	mov  r6,a
      005F54 24 FC            [12] 1124 	add	a,#0xff - 0x03
      005F56 40 6A            [24] 1125 	jc	00116$
                                   1126 ;	free result
      005F58 EE               [12] 1127 	mov	a,r6
      005F59 2E               [12] 1128 	add	a,r6
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005F5A 90 5F 5E         [24] 1130 	mov	dptr,#00243$
      005F5D 73               [24] 1131 	jmp	@a+dptr
      005F5E                       1132 00243$:
      005F5E 80 06            [24] 1133 	sjmp	00112$
      005F60 80 1B            [24] 1134 	sjmp	00113$
      005F62 80 30            [24] 1135 	sjmp	00114$
      005F64 80 45            [24] 1136 	sjmp	00115$
      005F66                       1137 00112$:
      005F66 90 08 1E         [24] 1138 	mov	dptr,#_control_pointer
      005F69 74 43            [12] 1139 	mov	a,#_LanguageString
      005F6B F0               [24] 1140 	movx	@dptr,a
      005F6C 74 C4            [12] 1141 	mov	a,#(_LanguageString >> 8)
      005F6E A3               [24] 1142 	inc	dptr
      005F6F F0               [24] 1143 	movx	@dptr,a
      005F70 90 C4 43         [24] 1144 	mov	dptr,#_LanguageString
      005F73 E4               [12] 1145 	clr	a
      005F74 93               [24] 1146 	movc	a,@a+dptr
      005F75 FE               [12] 1147 	mov	r6,a
      005F76 7D 00            [12] 1148 	mov	r5,#0x00
      005F78 8E 82            [24] 1149 	mov	dpl, r6
      005F7A 8D 83            [24] 1150 	mov	dph, r5
      005F7C 22               [24] 1151 	ret
                                   1152 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F7D                       1153 00113$:
      005F7D 90 08 1E         [24] 1154 	mov	dptr,#_control_pointer
      005F80 74 47            [12] 1155 	mov	a,#_ManufacturerString
      005F82 F0               [24] 1156 	movx	@dptr,a
      005F83 74 C4            [12] 1157 	mov	a,#(_ManufacturerString >> 8)
      005F85 A3               [24] 1158 	inc	dptr
      005F86 F0               [24] 1159 	movx	@dptr,a
      005F87 90 C4 47         [24] 1160 	mov	dptr,#_ManufacturerString
      005F8A E4               [12] 1161 	clr	a
      005F8B 93               [24] 1162 	movc	a,@a+dptr
      005F8C FE               [12] 1163 	mov	r6,a
      005F8D 7D 00            [12] 1164 	mov	r5,#0x00
      005F8F 8E 82            [24] 1165 	mov	dpl, r6
      005F91 8D 83            [24] 1166 	mov	dph, r5
      005F93 22               [24] 1167 	ret
                                   1168 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005F94                       1169 00114$:
      005F94 90 08 1E         [24] 1170 	mov	dptr,#_control_pointer
      005F97 74 55            [12] 1171 	mov	a,#_ProductString
      005F99 F0               [24] 1172 	movx	@dptr,a
      005F9A 74 C4            [12] 1173 	mov	a,#(_ProductString >> 8)
      005F9C A3               [24] 1174 	inc	dptr
      005F9D F0               [24] 1175 	movx	@dptr,a
      005F9E 90 C4 55         [24] 1176 	mov	dptr,#_ProductString
      005FA1 E4               [12] 1177 	clr	a
      005FA2 93               [24] 1178 	movc	a,@a+dptr
      005FA3 FE               [12] 1179 	mov	r6,a
      005FA4 7D 00            [12] 1180 	mov	r5,#0x00
      005FA6 8E 82            [24] 1181 	mov	dpl, r6
      005FA8 8D 83            [24] 1182 	mov	dph, r5
      005FAA 22               [24] 1183 	ret
                                   1184 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005FAB                       1185 00115$:
      005FAB 90 08 1E         [24] 1186 	mov	dptr,#_control_pointer
      005FAE 74 8D            [12] 1187 	mov	a,#_SerialNumberString
      005FB0 F0               [24] 1188 	movx	@dptr,a
      005FB1 74 C4            [12] 1189 	mov	a,#(_SerialNumberString >> 8)
      005FB3 A3               [24] 1190 	inc	dptr
      005FB4 F0               [24] 1191 	movx	@dptr,a
      005FB5 90 C4 8D         [24] 1192 	mov	dptr,#_SerialNumberString
      005FB8 E4               [12] 1193 	clr	a
      005FB9 93               [24] 1194 	movc	a,@a+dptr
      005FBA FE               [12] 1195 	mov	r6,a
      005FBB 7D 00            [12] 1196 	mov	r5,#0x00
      005FBD 8E 82            [24] 1197 	mov	dpl, r6
      005FBF 8D 83            [24] 1198 	mov	dph, r5
      005FC1 22               [24] 1199 	ret
                                   1200 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005FC2                       1201 00116$:
      005FC2 90 00 00         [24] 1202 	mov	dptr,#0x0000
      005FC5 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005FC6                       1205 00119$:
                                   1206 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005FC6 90 08 20         [24] 1207 	mov	dptr,#_descriptor_select_PARM_2
      005FC9 E0               [24] 1208 	movx	a,@dptr
      005FCA 70 11            [24] 1209 	jnz	00120$
      005FCC 90 08 21         [24] 1210 	mov	dptr,#_descriptor_select_PARM_3
      005FCF E0               [24] 1211 	movx	a,@dptr
      005FD0 FD               [12] 1212 	mov	r5,a
      005FD1 A3               [24] 1213 	inc	dptr
      005FD2 E0               [24] 1214 	movx	a,@dptr
      005FD3 FE               [12] 1215 	mov	r6,a
      005FD4 C3               [12] 1216 	clr	c
      005FD5 ED               [12] 1217 	mov	a,r5
      005FD6 94 03            [12] 1218 	subb	a,#0x03
      005FD8 EE               [12] 1219 	mov	a,r6
      005FD9 94 00            [12] 1220 	subb	a,#0x00
      005FDB 40 04            [24] 1221 	jc	00121$
      005FDD                       1222 00120$:
      005FDD 90 00 00         [24] 1223 	mov	dptr,#0x0000
      005FE0 22               [24] 1224 	ret
      005FE1                       1225 00121$:
                                   1226 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005FE1 BF 22 02         [24] 1227 	cjne	r7,#0x22,00246$
      005FE4 80 03            [24] 1228 	sjmp	00127$
      005FE6                       1229 00246$:
      005FE6 BF 21 5D         [24] 1230 	cjne	r7,#0x21,00128$
      005FE9                       1231 00127$:
                                   1232 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005FE9 ED               [12] 1233 	mov	a,r5
      005FEA 75 F0 04         [24] 1234 	mov	b,#0x04
      005FED A4               [48] 1235 	mul	ab
      005FEE 24 66            [12] 1236 	add	a, #_interface_descriptors
      005FF0 FE               [12] 1237 	mov	r6,a
      005FF1 74 BD            [12] 1238 	mov	a,#(_interface_descriptors >> 8)
      005FF3 35 F0            [12] 1239 	addc	a, b
      005FF5 FF               [12] 1240 	mov	r7,a
      005FF6 8E 82            [24] 1241 	mov	dpl,r6
      005FF8 8F 83            [24] 1242 	mov	dph,r7
      005FFA A3               [24] 1243 	inc	dptr
      005FFB A3               [24] 1244 	inc	dptr
      005FFC E4               [12] 1245 	clr	a
      005FFD 93               [24] 1246 	movc	a,@a+dptr
      005FFE FC               [12] 1247 	mov	r4,a
      005FFF A3               [24] 1248 	inc	dptr
      006000 E4               [12] 1249 	clr	a
      006001 93               [24] 1250 	movc	a,@a+dptr
                                   1251 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      006002 FD               [12] 1252 	mov	r5,a
      006003 4C               [12] 1253 	orl	a,r4
      006004 70 04            [24] 1254 	jnz	00124$
      006006 90 00 00         [24] 1255 	mov	dptr,#0x0000
      006009 22               [24] 1256 	ret
      00600A                       1257 00124$:
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      00600A 90 08 23         [24] 1259 	mov	dptr,#_descriptor_select_type_10000_269
      00600D E0               [24] 1260 	movx	a,@dptr
      00600E FB               [12] 1261 	mov	r3,a
      00600F BB 22 28         [24] 1262 	cjne	r3,#0x22,00126$
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006012 8E 82            [24] 1264 	mov	dpl,r6
      006014 8F 83            [24] 1265 	mov	dph,r7
      006016 E4               [12] 1266 	clr	a
      006017 93               [24] 1267 	movc	a,@a+dptr
      006018 FE               [12] 1268 	mov	r6,a
      006019 A3               [24] 1269 	inc	dptr
      00601A E4               [12] 1270 	clr	a
      00601B 93               [24] 1271 	movc	a,@a+dptr
      00601C FF               [12] 1272 	mov	r7,a
      00601D 90 08 1E         [24] 1273 	mov	dptr,#_control_pointer
      006020 EE               [12] 1274 	mov	a,r6
      006021 F0               [24] 1275 	movx	@dptr,a
      006022 EF               [12] 1276 	mov	a,r7
      006023 A3               [24] 1277 	inc	dptr
      006024 F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      006025 74 07            [12] 1280 	mov	a,#0x07
      006027 2C               [12] 1281 	add	a, r4
      006028 F5 82            [12] 1282 	mov	dpl,a
      00602A E4               [12] 1283 	clr	a
      00602B 3D               [12] 1284 	addc	a, r5
      00602C F5 83            [12] 1285 	mov	dph,a
      00602E E4               [12] 1286 	clr	a
      00602F 93               [24] 1287 	movc	a,@a+dptr
      006030 FE               [12] 1288 	mov	r6,a
      006031 A3               [24] 1289 	inc	dptr
      006032 E4               [12] 1290 	clr	a
      006033 93               [24] 1291 	movc	a,@a+dptr
      006034 FF               [12] 1292 	mov	r7,a
      006035 8E 82            [24] 1293 	mov	dpl, r6
      006037 8F 83            [24] 1294 	mov	dph, r7
      006039 22               [24] 1295 	ret
      00603A                       1296 00126$:
                                   1297 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      00603A 90 08 1E         [24] 1298 	mov	dptr,#_control_pointer
      00603D EC               [12] 1299 	mov	a,r4
      00603E F0               [24] 1300 	movx	@dptr,a
      00603F ED               [12] 1301 	mov	a,r5
      006040 A3               [24] 1302 	inc	dptr
      006041 F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      006042 90 00 09         [24] 1305 	mov	dptr,#0x0009
      006045 22               [24] 1306 	ret
      006046                       1307 00128$:
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      006046 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      006049 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'control_setup'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1316 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1317 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1318 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1319 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1320 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1321 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1322 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1323 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1324 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1325 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1326 ;------------------------------------------------------------
                                   1327 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1328 ;	-----------------------------------------
                                   1329 ;	 function control_setup
                                   1330 ;	-----------------------------------------
      00604A                       1331 _control_setup:
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00604A 90 10 00         [24] 1333 	mov	dptr,#0x1000
      00604D E0               [24] 1334 	movx	a,@dptr
      00604E FF               [12] 1335 	mov	r7,a
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      00604F A3               [24] 1337 	inc	dptr
      006050 A3               [24] 1338 	inc	dptr
      006051 E0               [24] 1339 	movx	a,@dptr
      006052 FE               [12] 1340 	mov	r6,a
      006053 A3               [24] 1341 	inc	dptr
      006054 E0               [24] 1342 	movx	a,@dptr
      006055 FC               [12] 1343 	mov	r4,a
      006056 7D 00            [12] 1344 	mov	r5,#0x00
      006058 8E 03            [24] 1345 	mov	ar3,r6
      00605A 7E 00            [12] 1346 	mov	r6,#0x00
      00605C ED               [12] 1347 	mov	a,r5
      00605D 4B               [12] 1348 	orl	a,r3
      00605E FD               [12] 1349 	mov	r5,a
      00605F EC               [12] 1350 	mov	a,r4
      006060 4E               [12] 1351 	orl	a,r6
      006061 FE               [12] 1352 	mov	r6,a
                                   1353 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006062 A3               [24] 1354 	inc	dptr
      006063 E0               [24] 1355 	movx	a,@dptr
      006064 FC               [12] 1356 	mov	r4,a
      006065 A3               [24] 1357 	inc	dptr
      006066 E0               [24] 1358 	movx	a,@dptr
      006067 FA               [12] 1359 	mov	r2,a
      006068 7B 00            [12] 1360 	mov	r3,#0x00
      00606A 8C 01            [24] 1361 	mov	ar1,r4
      00606C 7C 00            [12] 1362 	mov	r4,#0x00
      00606E EB               [12] 1363 	mov	a,r3
      00606F 49               [12] 1364 	orl	a,r1
      006070 FB               [12] 1365 	mov	r3,a
      006071 EA               [12] 1366 	mov	a,r2
      006072 4C               [12] 1367 	orl	a,r4
      006073 FC               [12] 1368 	mov	r4,a
                                   1369 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      006074 C3               [12] 1370 	clr	c
      006075 EB               [12] 1371 	mov	a,r3
      006076 94 03            [12] 1372 	subb	a,#0x03
      006078 EC               [12] 1373 	mov	a,r4
      006079 94 00            [12] 1374 	subb	a,#0x00
      00607B 92 17            [24] 1375 	mov	_control_setup_valid_interface_10000_287,c
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      00607D EB               [12] 1377 	mov	a,r3
      00607E 4C               [12] 1378 	orl	a,r4
      00607F B4 01 00         [24] 1379 	cjne	a,#0x01,01201$
      006082                       1380 01201$:
      006082 92 18            [24] 1381 	mov	_control_setup_zero_index_10000_287,c
                                   1382 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      006084 ED               [12] 1383 	mov	a,r5
      006085 4E               [12] 1384 	orl	a,r6
      006086 B4 01 00         [24] 1385 	cjne	a,#0x01,01202$
      006089                       1386 01202$:
                                   1387 ;	assignBit
      006089 92 1B            [24] 1388 	mov  _control_setup_sloc0_1_0,c
      00608B 92 19            [24] 1389 	mov	_control_setup_zero_value_10000_287,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      00608D 90 08 26         [24] 1391 	mov	dptr,#_control_setup_offset_10000_287
      006090 E4               [12] 1392 	clr	a
      006091 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006092 90 07 C9         [24] 1395 	mov	dptr,#_raw_state
      006095 E0               [24] 1396 	movx	a,@dptr
      006096 FA               [12] 1397 	mov	r2,a
      006097 BA 01 05         [24] 1398 	cjne	r2,#0x01,00102$
      00609A 90 07 C9         [24] 1399 	mov	dptr,#_raw_state
      00609D E4               [12] 1400 	clr	a
      00609E F0               [24] 1401 	movx	@dptr,a
      00609F                       1402 00102$:
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      00609F C0 07            [24] 1404 	push	ar7
      0060A1 90 08 1B         [24] 1405 	mov	dptr,#_output_kind
      0060A4 E4               [12] 1406 	clr	a
      0060A5 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      0060A6 90 08 1A         [24] 1409 	mov	dptr,#_control_phase
      0060A9 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      0060AA 90 08 1D         [24] 1412 	mov	dptr,#_control_zlp
      0060AD F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0060AE 90 10 01         [24] 1415 	mov	dptr,#0x1001
      0060B1 E0               [24] 1416 	movx	a,@dptr
      0060B2 90 07 BB         [24] 1417 	mov	dptr,#_D0SetupReqCode
      0060B5 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0060B6 90 10 06         [24] 1420 	mov	dptr,#0x1006
      0060B9 E0               [24] 1421 	movx	a,@dptr
      0060BA FA               [12] 1422 	mov	r2,a
      0060BB A3               [24] 1423 	inc	dptr
      0060BC E0               [24] 1424 	movx	a,@dptr
      0060BD F9               [12] 1425 	mov	r1,a
      0060BE 78 00            [12] 1426 	mov	r0,#0x00
      0060C0 7F 00            [12] 1427 	mov	r7,#0x00
      0060C2 90 07 BC         [24] 1428 	mov	dptr,#_D0SetupLen
      0060C5 E8               [12] 1429 	mov	a,r0
      0060C6 4A               [12] 1430 	orl	a,r2
      0060C7 F0               [24] 1431 	movx	@dptr,a
      0060C8 E9               [12] 1432 	mov	a,r1
      0060C9 4F               [12] 1433 	orl	a,r7
      0060CA A3               [24] 1434 	inc	dptr
      0060CB F0               [24] 1435 	movx	@dptr,a
                                   1436 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      0060CC 90 07 BC         [24] 1437 	mov	dptr,#_D0SetupLen
      0060CF E0               [24] 1438 	movx	a,@dptr
      0060D0 FA               [12] 1439 	mov	r2,a
      0060D1 A3               [24] 1440 	inc	dptr
      0060D2 E0               [24] 1441 	movx	a,@dptr
      0060D3 4A               [12] 1442 	orl	a,r2
      0060D4 B4 01 00         [24] 1443 	cjne	a,#0x01,01205$
      0060D7                       1444 01205$:
      0060D7 92 1A            [24] 1445 	mov	_control_setup_zero_length_10000_287,c
                                   1446 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0060D9 90 22 00         [24] 1447 	mov	dptr,#0x2200
      0060DC 74 C2            [12] 1448 	mov	a,#0xc2
      0060DE F0               [24] 1449 	movx	@dptr,a
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      0060DF 90 22 08         [24] 1451 	mov	dptr,#0x2208
      0060E2 E4               [12] 1452 	clr	a
      0060E3 F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      0060E4 90 07 BB         [24] 1455 	mov	dptr,#_D0SetupReqCode
      0060E7 E0               [24] 1456 	movx	a,@dptr
      0060E8 F5 16            [12] 1457 	mov	_control_setup_sloc1_1_0,a
      0060EA C3               [12] 1458 	clr	c
      0060EB 74 0B            [12] 1459 	mov	a,#0x0b
      0060ED 95 16            [12] 1460 	subb	a,_control_setup_sloc1_1_0
      0060EF D0 07            [24] 1461 	pop	ar7
      0060F1 50 03            [24] 1462 	jnc	01206$
      0060F3 02 5E 31         [24] 1463 	ljmp	_control_stall
      0060F6                       1464 01206$:
                                   1465 ;	free result
      0060F6 E5 16            [12] 1466 	mov	a,_control_setup_sloc1_1_0
      0060F8 F5 F0            [12] 1467 	mov	b,a
      0060FA 24 0B            [12] 1468 	add	a,#(01207$-3-.)
      0060FC 83               [24] 1469 	movc	a,@a+pc
      0060FD F5 82            [12] 1470 	mov	dpl,a
      0060FF E5 F0            [12] 1471 	mov	a,b
      006101 24 10            [12] 1472 	add	a,#(01208$-3-.)
      006103 83               [24] 1473 	movc	a,@a+pc
      006104 F5 83            [12] 1474 	mov	dph,a
      006106 E4               [12] 1475 	clr	a
      006107 73               [24] 1476 	jmp	@a+dptr
      006108                       1477 01207$:
      006108 B0                    1478 	.db	00188$
      006109 56                    1479 	.db	00205$
      00610A 99                    1480 	.db	00282$
      00610B 56                    1481 	.db	00205$
      00610C DD                    1482 	.db	00290$
      00610D DA                    1483 	.db	00116$
      00610E 20                    1484 	.db	00103$
      00610F DD                    1485 	.db	00290$
      006110 DF                    1486 	.db	00150$
      006111 03                    1487 	.db	00123$
      006112 0F                    1488 	.db	00157$
      006113 62                    1489 	.db	00173$
      006114                       1490 01208$:
      006114 63                    1491 	.db	00188$>>8
      006115 64                    1492 	.db	00205$>>8
      006116 67                    1493 	.db	00282$>>8
      006117 64                    1494 	.db	00205$>>8
      006118 67                    1495 	.db	00290$>>8
      006119 61                    1496 	.db	00116$>>8
      00611A 61                    1497 	.db	00103$>>8
      00611B 67                    1498 	.db	00290$>>8
      00611C 62                    1499 	.db	00150$>>8
      00611D 62                    1500 	.db	00123$>>8
      00611E 63                    1501 	.db	00157$>>8
      00611F 63                    1502 	.db	00173$>>8
                                   1503 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      006120                       1504 00103$:
                                   1505 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      006120 BF 80 02         [24] 1506 	cjne	r7,#0x80,01209$
      006123 80 08            [24] 1507 	sjmp	00112$
      006125                       1508 01209$:
      006125 BF 81 02         [24] 1509 	cjne	r7,#0x81,01210$
      006128 80 03            [24] 1510 	sjmp	01211$
      00612A                       1511 01210$:
      00612A 02 5E 31         [24] 1512 	ljmp	_control_stall
      00612D                       1513 01211$:
      00612D                       1514 00112$:
                                   1515 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      00612D 8E 01            [24] 1516 	mov	ar1,r6
      00612F B9 21 02         [24] 1517 	cjne	r1,#0x21,01212$
      006132 80 09            [24] 1518 	sjmp	00301$
      006134                       1519 01212$:
      006134 B9 22 02         [24] 1520 	cjne	r1,#0x22,01213$
      006137 80 04            [24] 1521 	sjmp	00301$
      006139                       1522 01213$:
                                   1523 ;	assignBit
      006139 C2 1C            [12] 1524 	clr	_control_setup_sloc2_1_0
      00613B 80 02            [24] 1525 	sjmp	00302$
      00613D                       1526 00301$:
                                   1527 ;	assignBit
      00613D D2 1C            [12] 1528 	setb	_control_setup_sloc2_1_0
      00613F                       1529 00302$:
      00613F E4               [12] 1530 	clr	a
      006140 BF 81 01         [24] 1531 	cjne	r7,#0x81,01214$
      006143 04               [12] 1532 	inc	a
      006144                       1533 01214$:
      006144 FA               [12] 1534 	mov	r2,a
      006145 A2 1C            [12] 1535 	mov	c,_control_setup_sloc2_1_0
      006147 E4               [12] 1536 	clr	a
      006148 33               [12] 1537 	rlc	a
      006149 B5 02 02         [24] 1538 	cjne	a,ar2,01216$
      00614C 80 03            [24] 1539 	sjmp	00105$
      00614E                       1540 01216$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      00614E 02 5E 31         [24] 1542 	ljmp	_control_stall
      006151                       1543 00105$:
                                   1544 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      006151 8E 02            [24] 1545 	mov	ar2,r6
      006153 90 08 20         [24] 1546 	mov	dptr,#_descriptor_select_PARM_2
      006156 ED               [12] 1547 	mov	a,r5
      006157 F0               [24] 1548 	movx	@dptr,a
      006158 90 08 21         [24] 1549 	mov	dptr,#_descriptor_select_PARM_3
      00615B EB               [12] 1550 	mov	a,r3
      00615C F0               [24] 1551 	movx	@dptr,a
      00615D EC               [12] 1552 	mov	a,r4
      00615E A3               [24] 1553 	inc	dptr
      00615F F0               [24] 1554 	movx	@dptr,a
      006160 8A 82            [24] 1555 	mov	dpl, r2
      006162 12 5E CF         [24] 1556 	lcall	_descriptor_select
      006165 85 82 17         [24] 1557 	mov	_control_setup_sloc3_1_0,dpl
      006168 85 83 18         [24] 1558 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1559 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      00616B E5 17            [12] 1560 	mov	a,_control_setup_sloc3_1_0
      00616D 45 18            [12] 1561 	orl	a,(_control_setup_sloc3_1_0 + 1)
      00616F 70 03            [24] 1562 	jnz	00107$
      006171 02 5E 31         [24] 1563 	ljmp	_control_stall
      006174                       1564 00107$:
                                   1565 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006174 90 07 BC         [24] 1566 	mov	dptr,#_D0SetupLen
      006177 E0               [24] 1567 	movx	a,@dptr
      006178 F8               [12] 1568 	mov	r0,a
      006179 A3               [24] 1569 	inc	dptr
      00617A E0               [24] 1570 	movx	a,@dptr
      00617B FA               [12] 1571 	mov	r2,a
      00617C C3               [12] 1572 	clr	c
      00617D E5 17            [12] 1573 	mov	a,_control_setup_sloc3_1_0
      00617F 98               [12] 1574 	subb	a,r0
      006180 E5 18            [12] 1575 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006182 9A               [12] 1576 	subb	a,r2
      006183 50 06            [24] 1577 	jnc	00303$
      006185 E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      006187 54 3F            [12] 1579 	anl	a,#0x3f
      006189 60 04            [24] 1580 	jz	00304$
      00618B                       1581 00303$:
                                   1582 ;	assignBit
      00618B C2 1C            [12] 1583 	clr	_control_setup_sloc2_1_0
      00618D 80 02            [24] 1584 	sjmp	00305$
      00618F                       1585 00304$:
                                   1586 ;	assignBit
      00618F D2 1C            [12] 1587 	setb	_control_setup_sloc2_1_0
      006191                       1588 00305$:
      006191 90 08 1D         [24] 1589 	mov	dptr,#_control_zlp
      006194 A2 1C            [12] 1590 	mov	c,_control_setup_sloc2_1_0
      006196 E4               [12] 1591 	clr	a
      006197 33               [12] 1592 	rlc	a
      006198 F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      006199 90 07 BC         [24] 1595 	mov	dptr,#_D0SetupLen
      00619C E0               [24] 1596 	movx	a,@dptr
      00619D F9               [12] 1597 	mov	r1,a
      00619E A3               [24] 1598 	inc	dptr
      00619F E0               [24] 1599 	movx	a,@dptr
      0061A0 FA               [12] 1600 	mov	r2,a
      0061A1 C3               [12] 1601 	clr	c
      0061A2 E5 17            [12] 1602 	mov	a,_control_setup_sloc3_1_0
      0061A4 99               [12] 1603 	subb	a,r1
      0061A5 E5 18            [12] 1604 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061A7 9A               [12] 1605 	subb	a,r2
      0061A8 50 0A            [24] 1606 	jnc	00109$
                                   1607 ;	free result
      0061AA 90 07 BC         [24] 1608 	mov	dptr,#_D0SetupLen
      0061AD E5 17            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      0061AF F0               [24] 1610 	movx	@dptr,a
      0061B0 E5 18            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061B2 A3               [24] 1612 	inc	dptr
      0061B3 F0               [24] 1613 	movx	@dptr,a
      0061B4                       1614 00109$:
                                   1615 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0061B4 90 07 BC         [24] 1616 	mov	dptr,#_D0SetupLen
      0061B7 E0               [24] 1617 	movx	a,@dptr
      0061B8 F9               [12] 1618 	mov	r1,a
      0061B9 A3               [24] 1619 	inc	dptr
      0061BA E0               [24] 1620 	movx	a,@dptr
      0061BB 49               [12] 1621 	orl	a,r1
      0061BC 60 04            [24] 1622 	jz	00306$
      0061BE 7A 01            [12] 1623 	mov	r2,#0x01
      0061C0 80 02            [24] 1624 	sjmp	00307$
      0061C2                       1625 00306$:
      0061C2 7A 02            [12] 1626 	mov	r2,#0x02
      0061C4                       1627 00307$:
      0061C4 90 08 1A         [24] 1628 	mov	dptr,#_control_phase
      0061C7 EA               [12] 1629 	mov	a,r2
      0061C8 F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      0061C9 90 07 BC         [24] 1632 	mov	dptr,#_D0SetupLen
      0061CC E0               [24] 1633 	movx	a,@dptr
      0061CD F9               [12] 1634 	mov	r1,a
      0061CE A3               [24] 1635 	inc	dptr
      0061CF E0               [24] 1636 	movx	a,@dptr
      0061D0 49               [12] 1637 	orl	a,r1
      0061D1 60 03            [24] 1638 	jz	00111$
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      0061D3 02 5E 53         [24] 1640 	ljmp	_control_next
      0061D6                       1641 00111$:
      0061D6 22               [24] 1642 	ret
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      0061D7 02 5E 31         [24] 1644 	ljmp	_control_stall
                                   1645 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      0061DA                       1646 00116$:
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0061DA EF               [12] 1648 	mov	a,r7
      0061DB 70 23            [24] 1649 	jnz	00118$
      0061DD 30 18 20         [24] 1650 	jnb	_control_setup_zero_index_10000_287,00118$
      0061E0 30 1A 1D         [24] 1651 	jnb	_control_setup_zero_length_10000_287,00118$
      0061E3 8D 01            [24] 1652 	mov	ar1,r5
      0061E5 8E 02            [24] 1653 	mov	ar2,r6
      0061E7 C3               [12] 1654 	clr	c
      0061E8 74 7F            [12] 1655 	mov	a,#0x7f
      0061EA 99               [12] 1656 	subb	a,r1
      0061EB E4               [12] 1657 	clr	a
      0061EC 9A               [12] 1658 	subb	a,r2
      0061ED 40 11            [24] 1659 	jc	00118$
                                   1660 ;	free result
                                   1661 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      0061EF 90 07 BC         [24] 1662 	mov	dptr,#_D0SetupLen
      0061F2 ED               [12] 1663 	mov	a,r5
      0061F3 F0               [24] 1664 	movx	@dptr,a
      0061F4 EE               [12] 1665 	mov	a,r6
      0061F5 A3               [24] 1666 	inc	dptr
      0061F6 F0               [24] 1667 	movx	@dptr,a
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      0061F7 90 08 1A         [24] 1669 	mov	dptr,#_control_phase
      0061FA 74 03            [12] 1670 	mov	a,#0x03
      0061FC F0               [24] 1671 	movx	@dptr,a
      0061FD 02 67 E0         [24] 1672 	ljmp	00291$
      006200                       1673 00118$:
                                   1674 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006200 02 5E 31         [24] 1675 	ljmp	_control_stall
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006203                       1677 00123$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006203 EF               [12] 1679 	mov	a,r7
      006204 70 3C            [24] 1680 	jnz	00145$
      006206 30 18 39         [24] 1681 	jnb	_control_setup_zero_index_10000_287,00145$
      006209 30 1A 36         [24] 1682 	jnb	_control_setup_zero_length_10000_287,00145$
      00620C 8D 01            [24] 1683 	mov	ar1,r5
      00620E 8E 02            [24] 1684 	mov	ar2,r6
      006210 C3               [12] 1685 	clr	c
      006211 74 01            [12] 1686 	mov	a,#0x01
      006213 99               [12] 1687 	subb	a,r1
      006214 E4               [12] 1688 	clr	a
      006215 9A               [12] 1689 	subb	a,r2
      006216 40 2A            [24] 1690 	jc	00145$
                                   1691 ;	free result
                                   1692 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      006218 C0 06            [24] 1693 	push	ar6
      00621A C0 05            [24] 1694 	push	ar5
      00621C 12 5D DA         [24] 1695 	lcall	_endpoints_reset
      00621F D0 05            [24] 1696 	pop	ar5
      006221 D0 06            [24] 1697 	pop	ar6
                                   1698 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      006223 90 07 C1         [24] 1699 	mov	dptr,#_D0UsbConfig
      006226 ED               [12] 1700 	mov	a,r5
      006227 F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      006228 A2 1B            [12] 1703 	mov	c,_control_setup_sloc0_1_0
      00622A B3               [12] 1704 	cpl	c
      00622B 92 1C            [24] 1705 	mov	_control_setup_sloc2_1_0,c
      00622D 90 07 C2         [24] 1706 	mov	dptr,#_USB_EnumStatus
      006230 E4               [12] 1707 	clr	a
      006231 33               [12] 1708 	rlc	a
      006232 F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      006233 90 07 EB         [24] 1711 	mov	dptr,#_keyboard_reset
      006236 74 01            [12] 1712 	mov	a,#0x01
      006238 F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      006239 90 08 1A         [24] 1715 	mov	dptr,#_control_phase
      00623C 74 03            [12] 1716 	mov	a,#0x03
      00623E F0               [24] 1717 	movx	@dptr,a
      00623F 02 67 E0         [24] 1718 	ljmp	00291$
      006242                       1719 00145$:
                                   1720 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      006242 BF 21 02         [24] 1721 	cjne	r7,#0x21,01231$
      006245 80 03            [24] 1722 	sjmp	01232$
      006247                       1723 01231$:
      006247 02 5E 31         [24] 1724 	ljmp	_control_stall
      00624A                       1725 01232$:
      00624A 90 07 C1         [24] 1726 	mov	dptr,#_D0UsbConfig
      00624D E0               [24] 1727 	movx	a,@dptr
      00624E 70 03            [24] 1728 	jnz	01233$
      006250 02 5E 31         [24] 1729 	ljmp	_control_stall
      006253                       1730 01233$:
                                   1731 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006253 BB 01 2D         [24] 1732 	cjne	r3,#0x01,00135$
      006256 BC 00 2A         [24] 1733 	cjne	r4,#0x00,00135$
      006259 8D 01            [24] 1734 	mov	ar1,r5
      00625B 8E 02            [24] 1735 	mov	ar2,r6
      00625D B9 00 23         [24] 1736 	cjne	r1,#0x00,00135$
      006260 BA 02 20         [24] 1737 	cjne	r2,#0x02,00135$
      006263 90 07 BC         [24] 1738 	mov	dptr,#_D0SetupLen
      006266 E0               [24] 1739 	movx	a,@dptr
      006267 F9               [12] 1740 	mov	r1,a
      006268 A3               [24] 1741 	inc	dptr
      006269 E0               [24] 1742 	movx	a,@dptr
      00626A FA               [12] 1743 	mov	r2,a
      00626B B9 20 15         [24] 1744 	cjne	r1,#0x20,00135$
      00626E BA 00 12         [24] 1745 	cjne	r2,#0x00,00135$
      006271 90 07 C9         [24] 1746 	mov	dptr,#_raw_state
      006274 E0               [24] 1747 	movx	a,@dptr
      006275 70 0C            [24] 1748 	jnz	00135$
                                   1749 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      006277 90 07 C9         [24] 1750 	mov	dptr,#_raw_state
      00627A 74 01            [12] 1751 	mov	a,#0x01
      00627C F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      00627D 90 08 1B         [24] 1754 	mov	dptr,#_output_kind
      006280 F0               [24] 1755 	movx	@dptr,a
      006281 80 52            [24] 1756 	sjmp	00136$
      006283                       1757 00135$:
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006283 EB               [12] 1759 	mov	a,r3
      006284 4C               [12] 1760 	orl	a,r4
      006285 70 20            [24] 1761 	jnz	00130$
      006287 8D 01            [24] 1762 	mov	ar1,r5
      006289 8E 02            [24] 1763 	mov	ar2,r6
      00628B B9 00 19         [24] 1764 	cjne	r1,#0x00,00130$
      00628E BA 02 16         [24] 1765 	cjne	r2,#0x02,00130$
      006291 90 07 BC         [24] 1766 	mov	dptr,#_D0SetupLen
      006294 E0               [24] 1767 	movx	a,@dptr
      006295 F9               [12] 1768 	mov	r1,a
      006296 A3               [24] 1769 	inc	dptr
      006297 E0               [24] 1770 	movx	a,@dptr
      006298 FA               [12] 1771 	mov	r2,a
      006299 B9 01 0B         [24] 1772 	cjne	r1,#0x01,00130$
      00629C BA 00 08         [24] 1773 	cjne	r2,#0x00,00130$
                                   1774 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      00629F 90 08 1B         [24] 1775 	mov	dptr,#_output_kind
      0062A2 74 02            [12] 1776 	mov	a,#0x02
      0062A4 F0               [24] 1777 	movx	@dptr,a
      0062A5 80 2E            [24] 1778 	sjmp	00136$
      0062A7                       1779 00130$:
                                   1780 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0062A7 BB 02 28         [24] 1781 	cjne	r3,#0x02,00125$
      0062AA BC 00 25         [24] 1782 	cjne	r4,#0x00,00125$
      0062AD 8D 01            [24] 1783 	mov	ar1,r5
      0062AF 8E 02            [24] 1784 	mov	ar2,r6
      0062B1 B9 06 1E         [24] 1785 	cjne	r1,#0x06,00125$
      0062B4 BA 02 1B         [24] 1786 	cjne	r2,#0x02,00125$
      0062B7 90 07 BC         [24] 1787 	mov	dptr,#_D0SetupLen
      0062BA E0               [24] 1788 	movx	a,@dptr
      0062BB F9               [12] 1789 	mov	r1,a
      0062BC A3               [24] 1790 	inc	dptr
      0062BD E0               [24] 1791 	movx	a,@dptr
      0062BE FA               [12] 1792 	mov	r2,a
      0062BF B9 02 10         [24] 1793 	cjne	r1,#0x02,00125$
      0062C2 BA 00 0D         [24] 1794 	cjne	r2,#0x00,00125$
                                   1795 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      0062C5 90 08 1B         [24] 1796 	mov	dptr,#_output_kind
      0062C8 74 03            [12] 1797 	mov	a,#0x03
      0062CA F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      0062CB 90 08 1C         [24] 1800 	mov	dptr,#_output_report_id
      0062CE 23               [12] 1801 	rl	a
      0062CF F0               [24] 1802 	movx	@dptr,a
      0062D0 80 03            [24] 1803 	sjmp	00136$
      0062D2                       1804 00125$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      0062D2 02 5E 31         [24] 1806 	ljmp	_control_stall
      0062D5                       1807 00136$:
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      0062D5 90 08 1A         [24] 1809 	mov	dptr,#_control_phase
      0062D8 74 04            [12] 1810 	mov	a,#0x04
      0062DA F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      0062DB 22               [24] 1813 	ret
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      0062DC 02 5E 31         [24] 1815 	ljmp	_control_stall
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      0062DF                       1817 00150$:
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0062DF BF 80 2A         [24] 1819 	cjne	r7,#0x80,00152$
      0062E2 30 18 27         [24] 1820 	jnb	_control_setup_zero_index_10000_287,00152$
      0062E5 30 19 24         [24] 1821 	jnb	_control_setup_zero_value_10000_287,00152$
      0062E8 90 07 BC         [24] 1822 	mov	dptr,#_D0SetupLen
      0062EB E0               [24] 1823 	movx	a,@dptr
      0062EC F9               [12] 1824 	mov	r1,a
      0062ED A3               [24] 1825 	inc	dptr
      0062EE E0               [24] 1826 	movx	a,@dptr
      0062EF FA               [12] 1827 	mov	r2,a
      0062F0 B9 01 19         [24] 1828 	cjne	r1,#0x01,00152$
      0062F3 BA 00 16         [24] 1829 	cjne	r2,#0x00,00152$
                                   1830 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      0062F6 90 07 C1         [24] 1831 	mov	dptr,#_D0UsbConfig
      0062F9 E0               [24] 1832 	movx	a,@dptr
      0062FA 90 10 00         [24] 1833 	mov	dptr,#0x1000
      0062FD F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      0062FE 90 22 08         [24] 1836 	mov	dptr,#0x2208
      006301 74 01            [12] 1837 	mov	a,#0x01
      006303 F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      006304 90 08 1A         [24] 1840 	mov	dptr,#_control_phase
      006307 04               [12] 1841 	inc	a
      006308 F0               [24] 1842 	movx	@dptr,a
      006309 02 67 E0         [24] 1843 	ljmp	00291$
      00630C                       1844 00152$:
                                   1845 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      00630C 02 5E 31         [24] 1846 	ljmp	_control_stall
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      00630F                       1848 00157$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      00630F BF 81 2C         [24] 1850 	cjne	r7,#0x81,00167$
      006312 30 17 29         [24] 1851 	jnb	_control_setup_valid_interface_10000_287,00167$
      006315 30 19 26         [24] 1852 	jnb	_control_setup_zero_value_10000_287,00167$
      006318 90 07 BC         [24] 1853 	mov	dptr,#_D0SetupLen
      00631B E0               [24] 1854 	movx	a,@dptr
      00631C F9               [12] 1855 	mov	r1,a
      00631D A3               [24] 1856 	inc	dptr
      00631E E0               [24] 1857 	movx	a,@dptr
      00631F FA               [12] 1858 	mov	r2,a
      006320 B9 01 1B         [24] 1859 	cjne	r1,#0x01,00167$
      006323 BA 00 18         [24] 1860 	cjne	r2,#0x00,00167$
      006326 90 07 C1         [24] 1861 	mov	dptr,#_D0UsbConfig
      006329 E0               [24] 1862 	movx	a,@dptr
      00632A 60 12            [24] 1863 	jz	00167$
                                   1864 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      00632C 90 10 00         [24] 1865 	mov	dptr,#0x1000
      00632F E4               [12] 1866 	clr	a
      006330 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      006331 90 22 08         [24] 1869 	mov	dptr,#0x2208
      006334 04               [12] 1870 	inc	a
      006335 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      006336 90 08 1A         [24] 1873 	mov	dptr,#_control_phase
      006339 04               [12] 1874 	inc	a
      00633A F0               [24] 1875 	movx	@dptr,a
      00633B 02 67 E0         [24] 1876 	ljmp	00291$
      00633E                       1877 00167$:
                                   1878 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      00633E 30 17 1E         [24] 1879 	jnb	_control_setup_valid_interface_10000_287,00161$
      006341 90 07 C1         [24] 1880 	mov	dptr,#_D0UsbConfig
      006344 E0               [24] 1881 	movx	a,@dptr
      006345 60 18            [24] 1882 	jz	00161$
      006347 BF 21 15         [24] 1883 	cjne	r7,#0x21,00161$
      00634A 30 1A 12         [24] 1884 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      00634D EB               [12] 1886 	mov	a,r3
      00634E 4C               [12] 1887 	orl	a,r4
      00634F 70 05            [24] 1888 	jnz	00159$
      006351 90 06 99         [24] 1889 	mov	dptr,#_keyboard_idle
      006354 EE               [12] 1890 	mov	a,r6
      006355 F0               [24] 1891 	movx	@dptr,a
      006356                       1892 00159$:
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      006356 90 08 1A         [24] 1894 	mov	dptr,#_control_phase
      006359 74 03            [12] 1895 	mov	a,#0x03
      00635B F0               [24] 1896 	movx	@dptr,a
      00635C 02 67 E0         [24] 1897 	ljmp	00291$
      00635F                       1898 00161$:
                                   1899 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      00635F 02 5E 31         [24] 1900 	ljmp	_control_stall
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006362                       1902 00173$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006362 BF 01 18         [24] 1904 	cjne	r7,#0x01,00182$
      006365 30 17 15         [24] 1905 	jnb	_control_setup_valid_interface_10000_287,00182$
      006368 30 19 12         [24] 1906 	jnb	_control_setup_zero_value_10000_287,00182$
      00636B 30 1A 0F         [24] 1907 	jnb	_control_setup_zero_length_10000_287,00182$
      00636E 90 07 C1         [24] 1908 	mov	dptr,#_D0UsbConfig
      006371 E0               [24] 1909 	movx	a,@dptr
      006372 60 09            [24] 1910 	jz	00182$
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      006374 90 08 1A         [24] 1912 	mov	dptr,#_control_phase
      006377 74 03            [12] 1913 	mov	a,#0x03
      006379 F0               [24] 1914 	movx	@dptr,a
      00637A 02 67 E0         [24] 1915 	ljmp	00291$
      00637D                       1916 00182$:
                                   1917 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00637D EB               [12] 1918 	mov	a,r3
      00637E 4C               [12] 1919 	orl	a,r4
      00637F 70 2C            [24] 1920 	jnz	00175$
      006381 90 07 C1         [24] 1921 	mov	dptr,#_D0UsbConfig
      006384 E0               [24] 1922 	movx	a,@dptr
      006385 60 26            [24] 1923 	jz	00175$
      006387 BF 21 23         [24] 1924 	cjne	r7,#0x21,00175$
      00638A 30 1A 20         [24] 1925 	jnb	_control_setup_zero_length_10000_287,00175$
      00638D 8D 01            [24] 1926 	mov	ar1,r5
      00638F 8E 02            [24] 1927 	mov	ar2,r6
      006391 C3               [12] 1928 	clr	c
      006392 74 01            [12] 1929 	mov	a,#0x01
      006394 99               [12] 1930 	subb	a,r1
      006395 E4               [12] 1931 	clr	a
      006396 9A               [12] 1932 	subb	a,r2
      006397 40 14            [24] 1933 	jc	00175$
                                   1934 ;	free result
                                   1935 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      006399 90 0E 05         [24] 1936 	mov	dptr,#_keyboard_protocol
      00639C ED               [12] 1937 	mov	a,r5
      00639D F0               [24] 1938 	movx	@dptr,a
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      00639E 90 07 EB         [24] 1940 	mov	dptr,#_keyboard_reset
      0063A1 74 01            [12] 1941 	mov	a,#0x01
      0063A3 F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      0063A4 90 08 1A         [24] 1944 	mov	dptr,#_control_phase
      0063A7 74 03            [12] 1945 	mov	a,#0x03
      0063A9 F0               [24] 1946 	movx	@dptr,a
      0063AA 02 67 E0         [24] 1947 	ljmp	00291$
      0063AD                       1948 00175$:
                                   1949 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      0063AD 02 5E 31         [24] 1950 	ljmp	_control_stall
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      0063B0                       1952 00188$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      0063B0 20 19 03         [24] 1954 	jb	_control_setup_zero_value_10000_287,01283$
      0063B3 02 5E 31         [24] 1955 	ljmp	_control_stall
      0063B6                       1956 01283$:
      0063B6 90 07 BC         [24] 1957 	mov	dptr,#_D0SetupLen
      0063B9 E0               [24] 1958 	movx	a,@dptr
      0063BA F9               [12] 1959 	mov	r1,a
      0063BB A3               [24] 1960 	inc	dptr
      0063BC E0               [24] 1961 	movx	a,@dptr
      0063BD FA               [12] 1962 	mov	r2,a
      0063BE B9 02 05         [24] 1963 	cjne	r1,#0x02,01284$
      0063C1 BA 00 02         [24] 1964 	cjne	r2,#0x00,01284$
      0063C4 80 03            [24] 1965 	sjmp	01285$
      0063C6                       1966 01284$:
      0063C6 02 5E 31         [24] 1967 	ljmp	_control_stall
      0063C9                       1968 01285$:
                                   1969 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0063C9 E4               [12] 1970 	clr	a
      0063CA BF 80 01         [24] 1971 	cjne	r7,#0x80,01286$
      0063CD 04               [12] 1972 	inc	a
      0063CE                       1973 01286$:
      0063CE FA               [12] 1974 	mov	r2,a
      0063CF 60 03            [24] 1975 	jz	00196$
      0063D1 20 18 35         [24] 1976 	jb	_control_setup_zero_index_10000_287,00189$
      0063D4                       1977 00196$:
      0063D4 BF 81 09         [24] 1978 	cjne	r7,#0x81,00202$
      0063D7 30 17 06         [24] 1979 	jnb	_control_setup_valid_interface_10000_287,00202$
      0063DA 90 07 C1         [24] 1980 	mov	dptr,#_D0UsbConfig
      0063DD E0               [24] 1981 	movx	a,@dptr
      0063DE 70 29            [24] 1982 	jnz	00189$
      0063E0                       1983 00202$:
                                   1984 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0063E0 BF 82 70         [24] 1985 	cjne	r7,#0x82,00190$
      0063E3 90 07 C1         [24] 1986 	mov	dptr,#_D0UsbConfig
      0063E6 E0               [24] 1987 	movx	a,@dptr
      0063E7 60 6A            [24] 1988 	jz	00190$
      0063E9 EB               [12] 1989 	mov	a,r3
      0063EA 4C               [12] 1990 	orl	a,r4
      0063EB 60 1C            [24] 1991 	jz	00189$
      0063ED 8B 00            [24] 1992 	mov	ar0,r3
      0063EF 8C 01            [24] 1993 	mov	ar1,r4
      0063F1 B8 80 05         [24] 1994 	cjne	r0,#0x80,01298$
      0063F4 B9 00 02         [24] 1995 	cjne	r1,#0x00,01298$
      0063F7 80 10            [24] 1996 	sjmp	00189$
      0063F9                       1997 01298$:
      0063F9 C3               [12] 1998 	clr	c
      0063FA E8               [12] 1999 	mov	a,r0
      0063FB 94 81            [12] 2000 	subb	a,#0x81
      0063FD E9               [12] 2001 	mov	a,r1
      0063FE 94 00            [12] 2002 	subb	a,#0x00
      006400 40 51            [24] 2003 	jc	00190$
      006402 74 83            [12] 2004 	mov	a,#0x83
      006404 98               [12] 2005 	subb	a,r0
      006405 E4               [12] 2006 	clr	a
      006406 99               [12] 2007 	subb	a,r1
      006407 40 4A            [24] 2008 	jc	00190$
                                   2009 ;	free result
      006409                       2010 00189$:
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      006409 8B 01            [24] 2012 	mov	ar1,r3
      00640B 53 01 07         [24] 2013 	anl	ar1,#0x07
                                   2014 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00640E EA               [12] 2015 	mov	a,r2
      00640F 60 0B            [24] 2016 	jz	00308$
      006411 90 07 C3         [24] 2017 	mov	dptr,#_USB_SleepStatus
      006414 E0               [24] 2018 	movx	a,@dptr
      006415 54 01            [12] 2019 	anl	a,#0x01
      006417 25 E0            [12] 2020 	add	a,acc
      006419 FA               [12] 2021 	mov	r2,a
      00641A 80 22            [24] 2022 	sjmp	00309$
      00641C                       2023 00308$:
                                   2024 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      00641C BF 82 1B         [24] 2025 	cjne	r7,#0x82,00310$
      00641F E9               [12] 2026 	mov	a,r1
      006420 60 18            [24] 2027 	jz	00310$
      006422 89 00            [24] 2028 	mov	ar0,r1
      006424 79 00            [12] 2029 	mov	r1,#0x00
      006426 74 22            [12] 2030 	mov	a,#0x22
      006428 29               [12] 2031 	add	a, r1
      006429 F9               [12] 2032 	mov	r1,a
      00642A 88 82            [24] 2033 	mov	dpl,r0
      00642C 89 83            [24] 2034 	mov	dph,r1
      00642E E0               [24] 2035 	movx	a,@dptr
      00642F F9               [12] 2036 	mov	r1,a
      006430 53 01 03         [24] 2037 	anl	ar1,#0x03
      006433 B9 03 04         [24] 2038 	cjne	r1,#0x03,00310$
      006436 79 01            [12] 2039 	mov	r1,#0x01
      006438 80 02            [24] 2040 	sjmp	00311$
      00643A                       2041 00310$:
      00643A 79 00            [12] 2042 	mov	r1,#0x00
      00643C                       2043 00311$:
      00643C 89 02            [24] 2044 	mov	ar2,r1
      00643E                       2045 00309$:
      00643E 90 10 00         [24] 2046 	mov	dptr,#0x1000
      006441 EA               [12] 2047 	mov	a,r2
      006442 F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      006443 A3               [24] 2050 	inc	dptr
      006444 E4               [12] 2051 	clr	a
      006445 F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      006446 90 22 08         [24] 2054 	mov	dptr,#0x2208
      006449 74 02            [12] 2055 	mov	a,#0x02
      00644B F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      00644C 90 08 1A         [24] 2058 	mov	dptr,#_control_phase
      00644F F0               [24] 2059 	movx	@dptr,a
      006450 02 67 E0         [24] 2060 	ljmp	00291$
      006453                       2061 00190$:
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      006453 02 5E 31         [24] 2063 	ljmp	_control_stall
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006456                       2065 00205$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      006456 20 1A 03         [24] 2067 	jb	_control_setup_zero_length_10000_287,01307$
      006459 02 64 E9         [24] 2068 	ljmp	00279$
      00645C                       2069 01307$:
      00645C 90 07 C1         [24] 2070 	mov	dptr,#_D0UsbConfig
      00645F E0               [24] 2071 	movx	a,@dptr
      006460 70 03            [24] 2072 	jnz	01308$
      006462 02 64 E9         [24] 2073 	ljmp	00279$
      006465                       2074 01308$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      006465 EF               [12] 2076 	mov	a,r7
      006466 70 29            [24] 2077 	jnz	00218$
      006468 8D 01            [24] 2078 	mov	ar1,r5
      00646A 8E 02            [24] 2079 	mov	ar2,r6
      00646C B9 01 22         [24] 2080 	cjne	r1,#0x01,00218$
      00646F BA 00 1F         [24] 2081 	cjne	r2,#0x00,00218$
      006472 30 18 1C         [24] 2082 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006475 90 07 BB         [24] 2084 	mov	dptr,#_D0SetupReqCode
      006478 E0               [24] 2085 	movx	a,@dptr
      006479 FA               [12] 2086 	mov	r2,a
      00647A BA 03 0A         [24] 2087 	cjne	r2,#0x03,00207$
      00647D 90 07 C3         [24] 2088 	mov	dptr,#_USB_SleepStatus
      006480 E0               [24] 2089 	movx	a,@dptr
      006481 43 E0 01         [24] 2090 	orl	acc,#0x01
      006484 F0               [24] 2091 	movx	@dptr,a
      006485 80 59            [24] 2092 	sjmp	00219$
      006487                       2093 00207$:
                                   2094 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      006487 90 07 C3         [24] 2095 	mov	dptr,#_USB_SleepStatus
      00648A E0               [24] 2096 	movx	a,@dptr
      00648B 53 E0 FE         [24] 2097 	anl	acc,#0xfe
      00648E F0               [24] 2098 	movx	@dptr,a
      00648F 80 4F            [24] 2099 	sjmp	00219$
      006491                       2100 00218$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006491 BF 02 49         [24] 2102 	cjne	r7,#0x02,00212$
      006494 30 19 46         [24] 2103 	jnb	_control_setup_zero_value_10000_287,00212$
      006497 8B 01            [24] 2104 	mov	ar1,r3
      006499 8C 02            [24] 2105 	mov	ar2,r4
      00649B C3               [12] 2106 	clr	c
      00649C E9               [12] 2107 	mov	a,r1
      00649D 94 81            [12] 2108 	subb	a,#0x81
      00649F EA               [12] 2109 	mov	a,r2
      0064A0 94 00            [12] 2110 	subb	a,#0x00
      0064A2 40 39            [24] 2111 	jc	00212$
      0064A4 74 83            [12] 2112 	mov	a,#0x83
      0064A6 99               [12] 2113 	subb	a,r1
      0064A7 E4               [12] 2114 	clr	a
      0064A8 9A               [12] 2115 	subb	a,r2
      0064A9 40 32            [24] 2116 	jc	00212$
                                   2117 ;	free result
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      0064AB 8B 02            [24] 2119 	mov	ar2,r3
      0064AD 53 02 07         [24] 2120 	anl	ar2,#0x07
                                   2121 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0064B0 8A 00            [24] 2122 	mov	ar0,r2
      0064B2 79 00            [12] 2123 	mov	r1,#0x00
      0064B4 74 22            [12] 2124 	mov	a,#0x22
      0064B6 29               [12] 2125 	add	a, r1
      0064B7 F9               [12] 2126 	mov	r1,a
      0064B8 88 17            [24] 2127 	mov	_control_setup_sloc3_1_0,r0
      0064BA 89 18            [24] 2128 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0064BC 90 07 BB         [24] 2129 	mov	dptr,#_D0SetupReqCode
      0064BF E0               [24] 2130 	movx	a,@dptr
      0064C0 F9               [12] 2131 	mov	r1,a
      0064C1 B9 03 04         [24] 2132 	cjne	r1,#0x03,00318$
      0064C4 79 03            [12] 2133 	mov	r1,#0x03
      0064C6 80 02            [24] 2134 	sjmp	00319$
      0064C8                       2135 00318$:
      0064C8 79 02            [12] 2136 	mov	r1,#0x02
      0064CA                       2137 00319$:
      0064CA 43 01 10         [24] 2138 	orl	ar1,#0x10
      0064CD 85 17 82         [24] 2139 	mov	dpl,_control_setup_sloc3_1_0
      0064D0 85 18 83         [24] 2140 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0064D3 E9               [12] 2141 	mov	a,r1
      0064D4 F0               [24] 2142 	movx	@dptr,a
                                   2143 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0064D5 BA 03 08         [24] 2144 	cjne	r2,#0x03,00219$
      0064D8 12 5D BD         [24] 2145 	lcall	_raw_complete
      0064DB 80 03            [24] 2146 	sjmp	00219$
      0064DD                       2147 00212$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      0064DD 02 5E 31         [24] 2149 	ljmp	_control_stall
      0064E0                       2150 00219$:
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      0064E0 90 08 1A         [24] 2152 	mov	dptr,#_control_phase
      0064E3 74 03            [12] 2153 	mov	a,#0x03
      0064E5 F0               [24] 2154 	movx	@dptr,a
      0064E6 02 67 E0         [24] 2155 	ljmp	00291$
      0064E9                       2156 00279$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0064E9 E4               [12] 2158 	clr	a
      0064EA BF A1 01         [24] 2159 	cjne	r7,#0xa1,01324$
      0064ED 04               [12] 2160 	inc	a
      0064EE                       2161 01324$:
      0064EE FA               [12] 2162 	mov	r2,a
      0064EF 70 03            [24] 2163 	jnz	01326$
      0064F1 02 67 5B         [24] 2164 	ljmp	00273$
      0064F4                       2165 01326$:
      0064F4 90 07 BB         [24] 2166 	mov	dptr,#_D0SetupReqCode
      0064F7 E0               [24] 2167 	movx	a,@dptr
      0064F8 F9               [12] 2168 	mov	r1,a
      0064F9 B9 01 02         [24] 2169 	cjne	r1,#0x01,01327$
      0064FC 80 03            [24] 2170 	sjmp	01328$
      0064FE                       2171 01327$:
      0064FE 02 67 5B         [24] 2172 	ljmp	00273$
      006501                       2173 01328$:
      006501 90 07 C1         [24] 2174 	mov	dptr,#_D0UsbConfig
      006504 E0               [24] 2175 	movx	a,@dptr
      006505 70 03            [24] 2176 	jnz	01329$
      006507 02 67 5B         [24] 2177 	ljmp	00273$
      00650A                       2178 01329$:
      00650A 90 07 BC         [24] 2179 	mov	dptr,#_D0SetupLen
      00650D E0               [24] 2180 	movx	a,@dptr
      00650E F8               [12] 2181 	mov	r0,a
      00650F A3               [24] 2182 	inc	dptr
      006510 E0               [24] 2183 	movx	a,@dptr
      006511 48               [12] 2184 	orl	a,r0
      006512 70 03            [24] 2185 	jnz	01330$
      006514 02 67 5B         [24] 2186 	ljmp	00273$
      006517                       2187 01330$:
                                   2188 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      006517 C0 03            [24] 2189 	push	ar3
      006519 C0 04            [24] 2190 	push	ar4
      00651B 8D 01            [24] 2191 	mov	ar1,r5
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00651D 8E 00            [24] 2193 	mov	ar0,r6
      00651F B8 01 03         [24] 2194 	cjne	r0,#0x01,01331$
      006522 E8               [12] 2195 	mov	a,r0
      006523 80 01            [24] 2196 	sjmp	01332$
      006525                       2197 01331$:
      006525 E4               [12] 2198 	clr	a
      006526                       2199 01332$:
      006526 F5 17            [12] 2200 	mov	_control_setup_sloc3_1_0,a
      006528 D0 04            [24] 2201 	pop	ar4
      00652A D0 03            [24] 2202 	pop	ar3
      00652C E5 17            [12] 2203 	mov	a,_control_setup_sloc3_1_0
      00652E 60 17            [24] 2204 	jz	00251$
      006530 EB               [12] 2205 	mov	a,r3
      006531 4C               [12] 2206 	orl	a,r4
      006532 70 13            [24] 2207 	jnz	00251$
      006534 E9               [12] 2208 	mov	a,r1
      006535 70 10            [24] 2209 	jnz	00251$
                                   2210 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      006537 90 08 24         [24] 2211 	mov	dptr,#_control_setup_length_10000_287
      00653A 74 08            [12] 2212 	mov	a,#0x08
      00653C F0               [24] 2213 	movx	@dptr,a
      00653D E4               [12] 2214 	clr	a
      00653E A3               [24] 2215 	inc	dptr
      00653F F0               [24] 2216 	movx	@dptr,a
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      006540 90 08 26         [24] 2218 	mov	dptr,#_control_setup_offset_10000_287
      006543 F0               [24] 2219 	movx	@dptr,a
      006544 02 66 CB         [24] 2220 	ljmp	00252$
      006547                       2221 00251$:
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006547 E5 17            [12] 2223 	mov	a,_control_setup_sloc3_1_0
      006549 60 27            [24] 2224 	jz	00245$
      00654B BB 02 24         [24] 2225 	cjne	r3,#0x02,00245$
      00654E BC 00 21         [24] 2226 	cjne	r4,#0x00,00245$
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006551 B9 07 00         [24] 2228 	cjne	r1,#0x07,01339$
      006554                       2229 01339$:
      006554 50 1C            [24] 2230 	jnc	00245$
      006556 E9               [12] 2231 	mov	a,r1
      006557 90 BD 5F         [24] 2232 	mov	dptr,#_shared_lengths
      00655A 93               [24] 2233 	movc	a,@a+dptr
      00655B F8               [12] 2234 	mov	r0,a
      00655C 60 14            [24] 2235 	jz	00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      00655E 90 08 24         [24] 2237 	mov	dptr,#_control_setup_length_10000_287
      006561 E8               [12] 2238 	mov	a,r0
      006562 F0               [24] 2239 	movx	@dptr,a
      006563 E4               [12] 2240 	clr	a
      006564 A3               [24] 2241 	inc	dptr
      006565 F0               [24] 2242 	movx	@dptr,a
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      006566 E9               [12] 2244 	mov	a,r1
      006567 90 BD 58         [24] 2245 	mov	dptr,#_shared_offsets
      00656A 93               [24] 2246 	movc	a,@a+dptr
      00656B 90 08 26         [24] 2247 	mov	dptr,#_control_setup_offset_10000_287
      00656E F0               [24] 2248 	movx	@dptr,a
      00656F 02 66 CB         [24] 2249 	ljmp	00252$
      006572                       2250 00245$:
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006572 E5 17            [12] 2252 	mov	a,_control_setup_sloc3_1_0
      006574 60 7A            [24] 2253 	jz	00240$
      006576 BB 01 77         [24] 2254 	cjne	r3,#0x01,00240$
      006579 BC 00 74         [24] 2255 	cjne	r4,#0x00,00240$
      00657C E9               [12] 2256 	mov	a,r1
      00657D 70 71            [24] 2257 	jnz	00240$
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00657F 90 07 BC         [24] 2259 	mov	dptr,#_D0SetupLen
      006582 E0               [24] 2260 	movx	a,@dptr
      006583 F8               [12] 2261 	mov	r0,a
      006584 A3               [24] 2262 	inc	dptr
      006585 E0               [24] 2263 	movx	a,@dptr
      006586 F9               [12] 2264 	mov	r1,a
      006587 C3               [12] 2265 	clr	c
      006588 E8               [12] 2266 	mov	a,r0
      006589 94 20            [12] 2267 	subb	a,#0x20
      00658B E9               [12] 2268 	mov	a,r1
      00658C 94 00            [12] 2269 	subb	a,#0x00
      00658E 50 0A            [24] 2270 	jnc	00320$
      006590 90 07 BC         [24] 2271 	mov	dptr,#_D0SetupLen
      006593 E0               [24] 2272 	movx	a,@dptr
      006594 F8               [12] 2273 	mov	r0,a
      006595 A3               [24] 2274 	inc	dptr
      006596 E0               [24] 2275 	movx	a,@dptr
      006597 F9               [12] 2276 	mov	r1,a
      006598 80 04            [24] 2277 	sjmp	00321$
      00659A                       2278 00320$:
      00659A 78 20            [12] 2279 	mov	r0,#0x20
      00659C 79 00            [12] 2280 	mov	r1,#0x00
      00659E                       2281 00321$:
                                   2282 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00659E 75 17 00         [24] 2283 	mov	_control_setup_sloc3_1_0,#0x00
      0065A1                       2284 00293$:
      0065A1 C0 03            [24] 2285 	push	ar3
      0065A3 C0 04            [24] 2286 	push	ar4
      0065A5 AB 17            [24] 2287 	mov	r3,_control_setup_sloc3_1_0
      0065A7 7C 00            [12] 2288 	mov	r4,#0x00
      0065A9 C3               [12] 2289 	clr	c
      0065AA EB               [12] 2290 	mov	a,r3
      0065AB 98               [12] 2291 	subb	a,r0
      0065AC EC               [12] 2292 	mov	a,r4
      0065AD 99               [12] 2293 	subb	a,r1
      0065AE D0 04            [24] 2294 	pop	ar4
      0065B0 D0 03            [24] 2295 	pop	ar3
      0065B2 50 32            [24] 2296 	jnc	00222$
      0065B4 C0 00            [24] 2297 	push	ar0
      0065B6 C0 01            [24] 2298 	push	ar1
      0065B8 85 17 19         [24] 2299 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0065BB 74 10            [12] 2300 	mov	a,#0x10
      0065BD 24 00            [12] 2301 	add	a, #0x00
      0065BF F5 1A            [12] 2302 	mov	(_control_setup_sloc4_1_0 + 1),a
      0065C1 A8 17            [24] 2303 	mov	r0,_control_setup_sloc3_1_0
      0065C3 79 00            [12] 2304 	mov	r1,#0x00
      0065C5 74 C0            [12] 2305 	mov	a,#0xc0
      0065C7 28               [12] 2306 	add	a, r0
      0065C8 F8               [12] 2307 	mov	r0,a
      0065C9 E4               [12] 2308 	clr	a
      0065CA 39               [12] 2309 	addc	a, r1
      0065CB F9               [12] 2310 	mov	r1,a
      0065CC 88 82            [24] 2311 	mov	dpl,r0
      0065CE 74 10            [12] 2312 	mov	a,#0x10
      0065D0 29               [12] 2313 	add	a, r1
      0065D1 F5 83            [12] 2314 	mov	dph,a
      0065D3 E0               [24] 2315 	movx	a,@dptr
      0065D4 85 19 82         [24] 2316 	mov	dpl,_control_setup_sloc4_1_0
      0065D7 85 1A 83         [24] 2317 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0065DA F0               [24] 2318 	movx	@dptr,a
      0065DB E5 17            [12] 2319 	mov	a,_control_setup_sloc3_1_0
      0065DD 04               [12] 2320 	inc	a
      0065DE F5 17            [12] 2321 	mov	_control_setup_sloc3_1_0,a
      0065E0 D0 01            [24] 2322 	pop	ar1
      0065E2 D0 00            [24] 2323 	pop	ar0
      0065E4 80 BB            [24] 2324 	sjmp	00293$
      0065E6                       2325 00222$:
                                   2326 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      0065E6 90 08 24         [24] 2327 	mov	dptr,#_control_setup_length_10000_287
      0065E9 E4               [12] 2328 	clr	a
      0065EA F0               [24] 2329 	movx	@dptr,a
      0065EB A3               [24] 2330 	inc	dptr
      0065EC F0               [24] 2331 	movx	@dptr,a
      0065ED 02 66 CB         [24] 2332 	ljmp	00252$
      0065F0                       2333 00240$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0065F0 8D 00            [24] 2335 	mov	ar0,r5
      0065F2 8E 01            [24] 2336 	mov	ar1,r6
      0065F4 B8 00 21         [24] 2337 	cjne	r0,#0x00,00236$
      0065F7 B9 02 1E         [24] 2338 	cjne	r1,#0x02,00236$
      0065FA EB               [12] 2339 	mov	a,r3
      0065FB 4C               [12] 2340 	orl	a,r4
      0065FC 70 1A            [24] 2341 	jnz	00236$
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0065FE 90 07 C6         [24] 2343 	mov	dptr,#_KB_USB_SetReport
      006601 E0               [24] 2344 	movx	a,@dptr
      006602 90 10 00         [24] 2345 	mov	dptr,#0x1000
      006605 F0               [24] 2346 	movx	@dptr,a
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      006606 90 08 24         [24] 2348 	mov	dptr,#_control_setup_length_10000_287
      006609 E4               [12] 2349 	clr	a
      00660A F0               [24] 2350 	movx	@dptr,a
      00660B A3               [24] 2351 	inc	dptr
      00660C F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      00660D 90 07 BC         [24] 2354 	mov	dptr,#_D0SetupLen
      006610 04               [12] 2355 	inc	a
      006611 F0               [24] 2356 	movx	@dptr,a
      006612 E4               [12] 2357 	clr	a
      006613 A3               [24] 2358 	inc	dptr
      006614 F0               [24] 2359 	movx	@dptr,a
      006615 02 66 CB         [24] 2360 	ljmp	00252$
      006618                       2361 00236$:
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006618 B8 06 41         [24] 2363 	cjne	r0,#0x06,00232$
      00661B B9 02 3E         [24] 2364 	cjne	r1,#0x02,00232$
      00661E BB 02 3B         [24] 2365 	cjne	r3,#0x02,00232$
      006621 BC 00 38         [24] 2366 	cjne	r4,#0x00,00232$
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006624 C0 03            [24] 2368 	push	ar3
      006626 C0 04            [24] 2369 	push	ar4
      006628 90 10 00         [24] 2370 	mov	dptr,#0x1000
      00662B 74 06            [12] 2371 	mov	a,#0x06
      00662D F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      00662E 90 07 C6         [24] 2374 	mov	dptr,#_KB_USB_SetReport
      006631 E0               [24] 2375 	movx	a,@dptr
      006632 90 10 01         [24] 2376 	mov	dptr,#0x1001
      006635 F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      006636 90 08 24         [24] 2379 	mov	dptr,#_control_setup_length_10000_287
      006639 E4               [12] 2380 	clr	a
      00663A F0               [24] 2381 	movx	@dptr,a
      00663B A3               [24] 2382 	inc	dptr
      00663C F0               [24] 2383 	movx	@dptr,a
                                   2384 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      00663D 90 07 BC         [24] 2385 	mov	dptr,#_D0SetupLen
      006640 E0               [24] 2386 	movx	a,@dptr
      006641 FB               [12] 2387 	mov	r3,a
      006642 A3               [24] 2388 	inc	dptr
      006643 E0               [24] 2389 	movx	a,@dptr
      006644 FC               [12] 2390 	mov	r4,a
      006645 C3               [12] 2391 	clr	c
      006646 74 02            [12] 2392 	mov	a,#0x02
      006648 9B               [12] 2393 	subb	a,r3
      006649 E4               [12] 2394 	clr	a
      00664A 9C               [12] 2395 	subb	a,r4
      00664B D0 04            [24] 2396 	pop	ar4
      00664D D0 03            [24] 2397 	pop	ar3
      00664F 50 7A            [24] 2398 	jnc	00252$
                                   2399 ;	free result
      006651 90 07 BC         [24] 2400 	mov	dptr,#_D0SetupLen
      006654 74 02            [12] 2401 	mov	a,#0x02
      006656 F0               [24] 2402 	movx	@dptr,a
      006657 E4               [12] 2403 	clr	a
      006658 A3               [24] 2404 	inc	dptr
      006659 F0               [24] 2405 	movx	@dptr,a
      00665A 80 6F            [24] 2406 	sjmp	00252$
      00665C                       2407 00232$:
                                   2408 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00665C B8 00 69         [24] 2409 	cjne	r0,#0x00,00228$
      00665F B9 03 66         [24] 2410 	cjne	r1,#0x03,00228$
      006662 BB 01 63         [24] 2411 	cjne	r3,#0x01,00228$
      006665 BC 00 60         [24] 2412 	cjne	r4,#0x00,00228$
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      006668 90 10 00         [24] 2414 	mov	dptr,#0x1000
      00666B 74 41            [12] 2415 	mov	a,#0x41
      00666D F0               [24] 2416 	movx	@dptr,a
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      00666E A3               [24] 2418 	inc	dptr
      00666F 74 4B            [12] 2419 	mov	a,#0x4b
      006671 F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      006672 A3               [24] 2422 	inc	dptr
      006673 74 42            [12] 2423 	mov	a,#0x42
      006675 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006676 A3               [24] 2426 	inc	dptr
      006677 74 54            [12] 2427 	mov	a,#0x54
      006679 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      00667A A3               [24] 2430 	inc	dptr
      00667B 74 01            [12] 2431 	mov	a,#0x01
      00667D F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      00667E 90 07 C7         [24] 2434 	mov	dptr,#_ak820_boot_stage
      006681 E0               [24] 2435 	movx	a,@dptr
      006682 90 10 05         [24] 2436 	mov	dptr,#0x1005
      006685 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006686 90 07 C8         [24] 2439 	mov	dptr,#_ak820_main_heartbeat
      006689 E0               [24] 2440 	movx	a,@dptr
      00668A 90 10 06         [24] 2441 	mov	dptr,#0x1006
      00668D F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00668E 90 07 C2         [24] 2444 	mov	dptr,#_USB_EnumStatus
      006691 E0               [24] 2445 	movx	a,@dptr
      006692 60 02            [24] 2446 	jz	00322$
      006694 74 01            [12] 2447 	mov	a,#0x01
      006696                       2448 00322$:
      006696 F9               [12] 2449 	mov	r1,a
      006697 90 07 C3         [24] 2450 	mov	dptr,#_USB_SleepStatus
      00669A E0               [24] 2451 	movx	a,@dptr
      00669B 54 02            [12] 2452 	anl	a,#0x02
      00669D F8               [12] 2453 	mov	r0,a
      00669E E9               [12] 2454 	mov	a,r1
      00669F 42 00            [12] 2455 	orl	ar0,a
      0066A1 90 10 07         [24] 2456 	mov	dptr,#0x1007
      0066A4 E8               [12] 2457 	mov	a,r0
      0066A5 F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      0066A6 90 08 24         [24] 2460 	mov	dptr,#_control_setup_length_10000_287
      0066A9 E4               [12] 2461 	clr	a
      0066AA F0               [24] 2462 	movx	@dptr,a
      0066AB A3               [24] 2463 	inc	dptr
      0066AC F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      0066AD 90 07 BC         [24] 2466 	mov	dptr,#_D0SetupLen
      0066B0 E0               [24] 2467 	movx	a,@dptr
      0066B1 F8               [12] 2468 	mov	r0,a
      0066B2 A3               [24] 2469 	inc	dptr
      0066B3 E0               [24] 2470 	movx	a,@dptr
      0066B4 F9               [12] 2471 	mov	r1,a
      0066B5 C3               [12] 2472 	clr	c
      0066B6 74 08            [12] 2473 	mov	a,#0x08
      0066B8 98               [12] 2474 	subb	a,r0
      0066B9 E4               [12] 2475 	clr	a
      0066BA 99               [12] 2476 	subb	a,r1
      0066BB 50 0E            [24] 2477 	jnc	00252$
                                   2478 ;	free result
      0066BD 90 07 BC         [24] 2479 	mov	dptr,#_D0SetupLen
      0066C0 74 08            [12] 2480 	mov	a,#0x08
      0066C2 F0               [24] 2481 	movx	@dptr,a
      0066C3 E4               [12] 2482 	clr	a
      0066C4 A3               [24] 2483 	inc	dptr
      0066C5 F0               [24] 2484 	movx	@dptr,a
      0066C6 80 03            [24] 2485 	sjmp	00252$
      0066C8                       2486 00228$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      0066C8 02 5E 31         [24] 2488 	ljmp	_control_stall
      0066CB                       2489 00252$:
                                   2490 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      0066CB 90 08 24         [24] 2491 	mov	dptr,#_control_setup_length_10000_287
      0066CE E0               [24] 2492 	movx	a,@dptr
      0066CF F5 19            [12] 2493 	mov	_control_setup_sloc4_1_0,a
      0066D1 A3               [24] 2494 	inc	dptr
      0066D2 E0               [24] 2495 	movx	a,@dptr
      0066D3 F5 1A            [12] 2496 	mov	(_control_setup_sloc4_1_0 + 1),a
      0066D5 E5 19            [12] 2497 	mov	a,_control_setup_sloc4_1_0
      0066D7 45 1A            [12] 2498 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0066D9 60 50            [24] 2499 	jz	00262$
                                   2500 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      0066DB 90 07 BC         [24] 2501 	mov	dptr,#_D0SetupLen
      0066DE E0               [24] 2502 	movx	a,@dptr
      0066DF F8               [12] 2503 	mov	r0,a
      0066E0 A3               [24] 2504 	inc	dptr
      0066E1 E0               [24] 2505 	movx	a,@dptr
      0066E2 F9               [12] 2506 	mov	r1,a
      0066E3 C3               [12] 2507 	clr	c
      0066E4 E5 19            [12] 2508 	mov	a,_control_setup_sloc4_1_0
      0066E6 98               [12] 2509 	subb	a,r0
      0066E7 E5 1A            [12] 2510 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066E9 99               [12] 2511 	subb	a,r1
      0066EA 50 0A            [24] 2512 	jnc	00559$
                                   2513 ;	free result
      0066EC 90 07 BC         [24] 2514 	mov	dptr,#_D0SetupLen
      0066EF E5 19            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      0066F1 F0               [24] 2516 	movx	@dptr,a
      0066F2 E5 1A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066F4 A3               [24] 2518 	inc	dptr
      0066F5 F0               [24] 2519 	movx	@dptr,a
                                   2520 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0066F6                       2521 00559$:
      0066F6 75 19 00         [24] 2522 	mov	_control_setup_sloc4_1_0,#0x00
      0066F9                       2523 00296$:
      0066F9 90 07 BC         [24] 2524 	mov	dptr,#_D0SetupLen
      0066FC E0               [24] 2525 	movx	a,@dptr
      0066FD F8               [12] 2526 	mov	r0,a
      0066FE C3               [12] 2527 	clr	c
      0066FF E5 19            [12] 2528 	mov	a,_control_setup_sloc4_1_0
      006701 98               [12] 2529 	subb	a,r0
      006702 50 46            [24] 2530 	jnc	00263$
      006704 85 19 17         [24] 2531 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006707 74 10            [12] 2532 	mov	a,#0x10
      006709 24 00            [12] 2533 	add	a, #0x00
      00670B F5 18            [12] 2534 	mov	(_control_setup_sloc3_1_0 + 1),a
      00670D 90 08 26         [24] 2535 	mov	dptr,#_control_setup_offset_10000_287
      006710 E0               [24] 2536 	movx	a,@dptr
      006711 25 19            [12] 2537 	add	a, _control_setup_sloc4_1_0
      006713 24 EC            [12] 2538 	add	a, #_input_snapshot
      006715 F5 82            [12] 2539 	mov	dpl,a
      006717 E4               [12] 2540 	clr	a
      006718 34 07            [12] 2541 	addc	a,#(_input_snapshot >> 8)
      00671A F5 83            [12] 2542 	mov	dph,a
      00671C E0               [24] 2543 	movx	a,@dptr
      00671D 85 17 82         [24] 2544 	mov	dpl,_control_setup_sloc3_1_0
      006720 85 18 83         [24] 2545 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006723 F0               [24] 2546 	movx	@dptr,a
      006724 E5 19            [12] 2547 	mov	a,_control_setup_sloc4_1_0
      006726 04               [12] 2548 	inc	a
      006727 F5 19            [12] 2549 	mov	_control_setup_sloc4_1_0,a
      006729 80 CE            [24] 2550 	sjmp	00296$
      00672B                       2551 00262$:
                                   2552 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00672B BB 01 1C         [24] 2553 	cjne	r3,#0x01,00263$
      00672E BC 00 19         [24] 2554 	cjne	r4,#0x00,00263$
      006731 90 07 BC         [24] 2555 	mov	dptr,#_D0SetupLen
      006734 E0               [24] 2556 	movx	a,@dptr
      006735 F8               [12] 2557 	mov	r0,a
      006736 A3               [24] 2558 	inc	dptr
      006737 E0               [24] 2559 	movx	a,@dptr
      006738 F9               [12] 2560 	mov	r1,a
      006739 C3               [12] 2561 	clr	c
      00673A 74 20            [12] 2562 	mov	a,#0x20
      00673C 98               [12] 2563 	subb	a,r0
      00673D E4               [12] 2564 	clr	a
      00673E 99               [12] 2565 	subb	a,r1
      00673F 50 09            [24] 2566 	jnc	00263$
                                   2567 ;	free result
      006741 90 07 BC         [24] 2568 	mov	dptr,#_D0SetupLen
      006744 74 20            [12] 2569 	mov	a,#0x20
      006746 F0               [24] 2570 	movx	@dptr,a
      006747 E4               [12] 2571 	clr	a
      006748 A3               [24] 2572 	inc	dptr
      006749 F0               [24] 2573 	movx	@dptr,a
      00674A                       2574 00263$:
                                   2575 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      00674A 90 07 BC         [24] 2576 	mov	dptr,#_D0SetupLen
      00674D E0               [24] 2577 	movx	a,@dptr
      00674E 90 22 08         [24] 2578 	mov	dptr,#0x2208
      006751 F0               [24] 2579 	movx	@dptr,a
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      006752 90 08 1A         [24] 2581 	mov	dptr,#_control_phase
      006755 74 02            [12] 2582 	mov	a,#0x02
      006757 F0               [24] 2583 	movx	@dptr,a
      006758 02 67 E0         [24] 2584 	ljmp	00291$
      00675B                       2585 00273$:
                                   2586 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00675B EB               [12] 2587 	mov	a,r3
      00675C 4C               [12] 2588 	orl	a,r4
      00675D 70 37            [24] 2589 	jnz	00265$
      00675F 90 07 C1         [24] 2590 	mov	dptr,#_D0UsbConfig
      006762 E0               [24] 2591 	movx	a,@dptr
      006763 60 31            [24] 2592 	jz	00265$
      006765 EA               [12] 2593 	mov	a,r2
      006766 60 2E            [24] 2594 	jz	00265$
      006768 90 07 BB         [24] 2595 	mov	dptr,#_D0SetupReqCode
      00676B E0               [24] 2596 	movx	a,@dptr
      00676C FA               [12] 2597 	mov	r2,a
      00676D BA 03 26         [24] 2598 	cjne	r2,#0x03,00265$
      006770 30 19 23         [24] 2599 	jnb	_control_setup_zero_value_10000_287,00265$
      006773 90 07 BC         [24] 2600 	mov	dptr,#_D0SetupLen
      006776 E0               [24] 2601 	movx	a,@dptr
      006777 F9               [12] 2602 	mov	r1,a
      006778 A3               [24] 2603 	inc	dptr
      006779 E0               [24] 2604 	movx	a,@dptr
      00677A FA               [12] 2605 	mov	r2,a
      00677B B9 01 18         [24] 2606 	cjne	r1,#0x01,00265$
      00677E BA 00 15         [24] 2607 	cjne	r2,#0x00,00265$
                                   2608 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006781 90 0E 05         [24] 2609 	mov	dptr,#_keyboard_protocol
      006784 E0               [24] 2610 	movx	a,@dptr
      006785 90 10 00         [24] 2611 	mov	dptr,#0x1000
      006788 F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      006789 90 22 08         [24] 2614 	mov	dptr,#0x2208
      00678C 74 01            [12] 2615 	mov	a,#0x01
      00678E F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      00678F 90 08 1A         [24] 2618 	mov	dptr,#_control_phase
      006792 04               [12] 2619 	inc	a
      006793 F0               [24] 2620 	movx	@dptr,a
      006794 80 4A            [24] 2621 	sjmp	00291$
      006796                       2622 00265$:
                                   2623 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006796 02 5E 31         [24] 2625 	ljmp	_control_stall
      006799                       2626 00282$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006799 30 17 3E         [24] 2628 	jnb	_control_setup_valid_interface_10000_287,00284$
      00679C 90 07 C1         [24] 2629 	mov	dptr,#_D0UsbConfig
      00679F E0               [24] 2630 	movx	a,@dptr
      0067A0 60 38            [24] 2631 	jz	00284$
      0067A2 BF A1 35         [24] 2632 	cjne	r7,#0xa1,00284$
      0067A5 8E 05            [24] 2633 	mov	ar5,r6
      0067A7 7E 00            [12] 2634 	mov	r6,#0x00
      0067A9 ED               [12] 2635 	mov	a,r5
      0067AA 4E               [12] 2636 	orl	a,r6
      0067AB 70 2D            [24] 2637 	jnz	00284$
      0067AD 90 07 BC         [24] 2638 	mov	dptr,#_D0SetupLen
      0067B0 E0               [24] 2639 	movx	a,@dptr
      0067B1 FE               [12] 2640 	mov	r6,a
      0067B2 A3               [24] 2641 	inc	dptr
      0067B3 E0               [24] 2642 	movx	a,@dptr
      0067B4 FF               [12] 2643 	mov	r7,a
      0067B5 BE 01 22         [24] 2644 	cjne	r6,#0x01,00284$
      0067B8 BF 00 1F         [24] 2645 	cjne	r7,#0x00,00284$
                                   2646 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0067BB EB               [12] 2647 	mov	a,r3
      0067BC 4C               [12] 2648 	orl	a,r4
      0067BD 70 07            [24] 2649 	jnz	00324$
      0067BF 90 06 99         [24] 2650 	mov	dptr,#_keyboard_idle
      0067C2 E0               [24] 2651 	movx	a,@dptr
      0067C3 FF               [12] 2652 	mov	r7,a
      0067C4 80 02            [24] 2653 	sjmp	00325$
      0067C6                       2654 00324$:
      0067C6 7F 00            [12] 2655 	mov	r7,#0x00
      0067C8                       2656 00325$:
      0067C8 90 10 00         [24] 2657 	mov	dptr,#0x1000
      0067CB EF               [12] 2658 	mov	a,r7
      0067CC F0               [24] 2659 	movx	@dptr,a
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      0067CD 90 22 08         [24] 2661 	mov	dptr,#0x2208
      0067D0 74 01            [12] 2662 	mov	a,#0x01
      0067D2 F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      0067D3 90 08 1A         [24] 2665 	mov	dptr,#_control_phase
      0067D6 04               [12] 2666 	inc	a
      0067D7 F0               [24] 2667 	movx	@dptr,a
      0067D8 80 06            [24] 2668 	sjmp	00291$
      0067DA                       2669 00284$:
                                   2670 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      0067DA 02 5E 31         [24] 2672 	ljmp	_control_stall
      0067DD                       2673 00290$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      0067DD 02 5E 31         [24] 2675 	ljmp	_control_stall
      0067E0                       2676 00291$:
                                   2677 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0067E0 90 22 00         [24] 2678 	mov	dptr,#0x2200
      0067E3 74 C0            [12] 2679 	mov	a,#0xc0
      0067E5 F0               [24] 2680 	movx	@dptr,a
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      0067E6 22               [24] 2682 	ret
                                   2683 ;------------------------------------------------------------
                                   2684 ;Allocation info for local variables in function 'control_out'
                                   2685 ;------------------------------------------------------------
                                   2686 ;i             Allocated with name '_control_out_i_10000_371'
                                   2687 ;------------------------------------------------------------
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2689 ;	-----------------------------------------
                                   2690 ;	 function control_out
                                   2691 ;	-----------------------------------------
      0067E7                       2692 _control_out:
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0067E7 90 22 0F         [24] 2694 	mov	dptr,#0x220f
      0067EA E0               [24] 2695 	movx	a,@dptr
      0067EB 20 E6 01         [24] 2696 	jb	acc.6,00102$
      0067EE 22               [24] 2697 	ret
      0067EF                       2698 00102$:
                                   2699 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0067EF 90 08 1A         [24] 2700 	mov	dptr,#_control_phase
      0067F2 E0               [24] 2701 	movx	a,@dptr
      0067F3 FF               [12] 2702 	mov	r7,a
      0067F4 BF 02 12         [24] 2703 	cjne	r7,#0x02,00104$
      0067F7 90 22 0E         [24] 2704 	mov	dptr,#0x220e
      0067FA E0               [24] 2705 	movx	a,@dptr
      0067FB 70 0C            [24] 2706 	jnz	00104$
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      0067FD 90 08 1A         [24] 2708 	mov	dptr,#_control_phase
      006800 E4               [12] 2709 	clr	a
      006801 F0               [24] 2710 	movx	@dptr,a
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006802 90 22 00         [24] 2712 	mov	dptr,#0x2200
      006805 74 02            [12] 2713 	mov	a,#0x02
      006807 F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006808 22               [24] 2716 	ret
      006809                       2717 00104$:
                                   2718 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006809 BF 04 19         [24] 2719 	cjne	r7,#0x04,00106$
      00680C 90 22 0E         [24] 2720 	mov	dptr,#0x220e
      00680F E0               [24] 2721 	movx	a,@dptr
      006810 FF               [12] 2722 	mov	r7,a
      006811 90 07 BC         [24] 2723 	mov	dptr,#_D0SetupLen
      006814 E0               [24] 2724 	movx	a,@dptr
      006815 FD               [12] 2725 	mov	r5,a
      006816 A3               [24] 2726 	inc	dptr
      006817 E0               [24] 2727 	movx	a,@dptr
      006818 FE               [12] 2728 	mov	r6,a
      006819 7C 00            [12] 2729 	mov	r4,#0x00
      00681B EF               [12] 2730 	mov	a,r7
      00681C B5 05 06         [24] 2731 	cjne	a,ar5,00209$
      00681F EC               [12] 2732 	mov	a,r4
      006820 B5 06 02         [24] 2733 	cjne	a,ar6,00209$
      006823 80 03            [24] 2734 	sjmp	00107$
      006825                       2735 00209$:
      006825                       2736 00106$:
      006825 02 5E 31         [24] 2737 	ljmp	_control_stall
      006828                       2738 00107$:
                                   2739 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006828 90 08 1B         [24] 2740 	mov	dptr,#_output_kind
      00682B E0               [24] 2741 	movx	a,@dptr
      00682C FF               [12] 2742 	mov	r7,a
      00682D BF 01 2E         [24] 2743 	cjne	r7,#0x01,00118$
      006830 90 07 C9         [24] 2744 	mov	dptr,#_raw_state
      006833 E0               [24] 2745 	movx	a,@dptr
      006834 FE               [12] 2746 	mov	r6,a
      006835 BE 01 26         [24] 2747 	cjne	r6,#0x01,00118$
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006838 7E 00            [12] 2749 	mov	r6,#0x00
      00683A                       2750 00121$:
      00683A EE               [12] 2751 	mov	a,r6
      00683B 24 CA            [12] 2752 	add	a, #_raw_buffer
      00683D FC               [12] 2753 	mov	r4,a
      00683E E4               [12] 2754 	clr	a
      00683F 34 07            [12] 2755 	addc	a, #(_raw_buffer >> 8)
      006841 FD               [12] 2756 	mov	r5,a
      006842 8E 82            [24] 2757 	mov	dpl,r6
      006844 74 10            [12] 2758 	mov	a,#0x10
      006846 24 00            [12] 2759 	add	a, #0x00
      006848 F5 83            [12] 2760 	mov	dph,a
      00684A E0               [24] 2761 	movx	a,@dptr
      00684B 8C 82            [24] 2762 	mov	dpl,r4
      00684D 8D 83            [24] 2763 	mov	dph,r5
      00684F F0               [24] 2764 	movx	@dptr,a
      006850 0E               [12] 2765 	inc	r6
      006851 BE 20 00         [24] 2766 	cjne	r6,#0x20,00214$
      006854                       2767 00214$:
      006854 40 E4            [24] 2768 	jc	00121$
                                   2769 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006856 90 07 C9         [24] 2770 	mov	dptr,#_raw_state
      006859 74 02            [12] 2771 	mov	a,#0x02
      00685B F0               [24] 2772 	movx	@dptr,a
      00685C 80 2B            [24] 2773 	sjmp	00119$
      00685E                       2774 00118$:
                                   2775 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      00685E BF 02 0A         [24] 2776 	cjne	r7,#0x02,00115$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      006861 90 10 00         [24] 2778 	mov	dptr,#0x1000
      006864 E0               [24] 2779 	movx	a,@dptr
      006865 90 07 C6         [24] 2780 	mov	dptr,#_KB_USB_SetReport
      006868 F0               [24] 2781 	movx	@dptr,a
      006869 80 1E            [24] 2782 	sjmp	00119$
      00686B                       2783 00115$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      00686B BF 03 18         [24] 2785 	cjne	r7,#0x03,00111$
      00686E 90 10 00         [24] 2786 	mov	dptr,#0x1000
      006871 E0               [24] 2787 	movx	a,@dptr
      006872 FF               [12] 2788 	mov	r7,a
      006873 90 08 1C         [24] 2789 	mov	dptr,#_output_report_id
      006876 E0               [24] 2790 	movx	a,@dptr
      006877 FE               [12] 2791 	mov	r6,a
      006878 EF               [12] 2792 	mov	a,r7
      006879 B5 06 0A         [24] 2793 	cjne	a,ar6,00111$
                                   2794 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      00687C 90 10 01         [24] 2795 	mov	dptr,#0x1001
      00687F E0               [24] 2796 	movx	a,@dptr
      006880 90 07 C6         [24] 2797 	mov	dptr,#_KB_USB_SetReport
      006883 F0               [24] 2798 	movx	@dptr,a
      006884 80 03            [24] 2799 	sjmp	00119$
      006886                       2800 00111$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006886 02 5E 31         [24] 2802 	ljmp	_control_stall
      006889                       2803 00119$:
                                   2804 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006889 90 08 1B         [24] 2805 	mov	dptr,#_output_kind
      00688C E4               [12] 2806 	clr	a
      00688D F0               [24] 2807 	movx	@dptr,a
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      00688E 90 07 BC         [24] 2809 	mov	dptr,#_D0SetupLen
      006891 F0               [24] 2810 	movx	@dptr,a
      006892 A3               [24] 2811 	inc	dptr
      006893 F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006894 90 08 1A         [24] 2814 	mov	dptr,#_control_phase
      006897 74 03            [12] 2815 	mov	a,#0x03
      006899 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      00689A 90 22 08         [24] 2818 	mov	dptr,#0x2208
      00689D E4               [12] 2819 	clr	a
      00689E F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00689F F5 82            [12] 2822 	mov	dpl,a
      0068A1 74 48            [12] 2823 	mov	a,#0x48
      0068A3 F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      0068A4 22               [24] 2826 	ret
                                   2827 ;------------------------------------------------------------
                                   2828 ;Allocation info for local variables in function 'control_in'
                                   2829 ;------------------------------------------------------------
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2831 ;	-----------------------------------------
                                   2832 ;	 function control_in
                                   2833 ;	-----------------------------------------
      0068A5                       2834 _control_in:
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      0068A5 90 08 1A         [24] 2836 	mov	dptr,#_control_phase
      0068A8 E0               [24] 2837 	movx	a,@dptr
      0068A9 FF               [12] 2838 	mov	r7,a
      0068AA BF 01 22         [24] 2839 	cjne	r7,#0x01,00109$
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      0068AD 90 07 BC         [24] 2841 	mov	dptr,#_D0SetupLen
      0068B0 E0               [24] 2842 	movx	a,@dptr
      0068B1 FD               [12] 2843 	mov	r5,a
      0068B2 A3               [24] 2844 	inc	dptr
      0068B3 E0               [24] 2845 	movx	a,@dptr
      0068B4 4D               [12] 2846 	orl	a,r5
      0068B5 70 06            [24] 2847 	jnz	00101$
      0068B7 90 08 1D         [24] 2848 	mov	dptr,#_control_zlp
      0068BA E0               [24] 2849 	movx	a,@dptr
      0068BB 60 0A            [24] 2850 	jz	00102$
      0068BD                       2851 00101$:
                                   2852 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      0068BD 90 22 00         [24] 2853 	mov	dptr,#0x2200
      0068C0 E0               [24] 2854 	movx	a,@dptr
      0068C1 64 40            [12] 2855 	xrl	a,#0x40
      0068C3 F0               [24] 2856 	movx	@dptr,a
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      0068C4 02 5E 53         [24] 2859 	ljmp	_control_next
      0068C7                       2860 00102$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      0068C7 90 08 1A         [24] 2862 	mov	dptr,#_control_phase
      0068CA 74 02            [12] 2863 	mov	a,#0x02
      0068CC F0               [24] 2864 	movx	@dptr,a
      0068CD 80 18            [24] 2865 	sjmp	00110$
      0068CF                       2866 00109$:
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      0068CF BF 03 15         [24] 2868 	cjne	r7,#0x03,00110$
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0068D2 90 07 BB         [24] 2870 	mov	dptr,#_D0SetupReqCode
      0068D5 E0               [24] 2871 	movx	a,@dptr
      0068D6 FF               [12] 2872 	mov	r7,a
      0068D7 BF 05 08         [24] 2873 	cjne	r7,#0x05,00105$
      0068DA 90 07 BC         [24] 2874 	mov	dptr,#_D0SetupLen
      0068DD E0               [24] 2875 	movx	a,@dptr
      0068DE 90 22 07         [24] 2876 	mov	dptr,#0x2207
      0068E1 F0               [24] 2877 	movx	@dptr,a
      0068E2                       2878 00105$:
                                   2879 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      0068E2 90 08 1A         [24] 2880 	mov	dptr,#_control_phase
      0068E5 E4               [12] 2881 	clr	a
      0068E6 F0               [24] 2882 	movx	@dptr,a
      0068E7                       2883 00110$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068E7 90 22 00         [24] 2885 	mov	dptr,#0x2200
      0068EA 74 82            [12] 2886 	mov	a,#0x82
      0068EC F0               [24] 2887 	movx	@dptr,a
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      0068ED 22               [24] 2889 	ret
                                   2890 ;------------------------------------------------------------
                                   2891 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2892 ;------------------------------------------------------------
                                   2893 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2894 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2895 ;------------------------------------------------------------
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function USB_DeviceInterrupt
                                   2899 ;	-----------------------------------------
      0068EE                       2900 _USB_DeviceInterrupt:
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      0068EE                       2902 00129$:
                                   2903 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      0068EE 90 22 3D         [24] 2904 	mov	dptr,#0x223d
      0068F1 E0               [24] 2905 	movx	a,@dptr
      0068F2 30 E0 4B         [24] 2906 	jnb	acc.0,00127$
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      0068F5 12 5D DA         [24] 2908 	lcall	_endpoints_reset
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      0068F8 90 22 07         [24] 2910 	mov	dptr,#0x2207
      0068FB E4               [12] 2911 	clr	a
      0068FC F0               [24] 2912 	movx	@dptr,a
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0068FD 90 07 C3         [24] 2914 	mov	dptr,#_USB_SleepStatus
      006900 F0               [24] 2915 	movx	@dptr,a
      006901 90 07 C2         [24] 2916 	mov	dptr,#_USB_EnumStatus
      006904 F0               [24] 2917 	movx	@dptr,a
      006905 90 07 C1         [24] 2918 	mov	dptr,#_D0UsbConfig
      006908 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006909 90 07 C6         [24] 2921 	mov	dptr,#_KB_USB_SetReport
      00690C F0               [24] 2922 	movx	@dptr,a
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      00690D 90 0E 05         [24] 2924 	mov	dptr,#_keyboard_protocol
      006910 04               [12] 2925 	inc	a
      006911 F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      006912 90 06 99         [24] 2928 	mov	dptr,#_keyboard_idle
      006915 E4               [12] 2929 	clr	a
      006916 F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006917 90 07 EB         [24] 2932 	mov	dptr,#_keyboard_reset
      00691A 04               [12] 2933 	inc	a
      00691B F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      00691C 90 07 BB         [24] 2936 	mov	dptr,#_D0SetupReqCode
      00691F 74 FF            [12] 2937 	mov	a,#0xff
      006921 F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      006922 90 07 BC         [24] 2940 	mov	dptr,#_D0SetupLen
      006925 E4               [12] 2941 	clr	a
      006926 F0               [24] 2942 	movx	@dptr,a
      006927 A3               [24] 2943 	inc	dptr
      006928 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006929 90 08 1A         [24] 2946 	mov	dptr,#_control_phase
      00692C F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00692D 90 22 00         [24] 2949 	mov	dptr,#0x2200
      006930 74 02            [12] 2950 	mov	a,#0x02
      006932 F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      006933 90 22 0F         [24] 2953 	mov	dptr,#0x220f
      006936 E4               [12] 2954 	clr	a
      006937 F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006938 90 22 3D         [24] 2957 	mov	dptr,#0x223d
      00693B 04               [12] 2958 	inc	a
      00693C F0               [24] 2959 	movx	@dptr,a
      00693D 02 69 D3         [24] 2960 	ljmp	00130$
      006940                       2961 00127$:
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006940 90 22 3D         [24] 2963 	mov	dptr,#0x223d
      006943 E0               [24] 2964 	movx	a,@dptr
      006944 30 E5 60         [24] 2965 	jnb	acc.5,00124$
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006947 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      00694A E0               [24] 2968 	movx	a,@dptr
      00694B FF               [12] 2969 	mov	r7,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      00694C 74 07            [12] 2971 	mov	a,#0x07
      00694E 5F               [12] 2972 	anl	a,r7
      00694F FE               [12] 2973 	mov	r6,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006950 EF               [12] 2975 	mov	a,r7
      006951 54 18            [12] 2976 	anl	a,#0x18
      006953 70 08            [24] 2977 	jnz	00115$
      006955 EE               [12] 2978 	mov	a,r6
      006956 70 05            [24] 2979 	jnz	00115$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006958 12 67 E7         [24] 2981 	lcall	_control_out
      00695B 80 43            [24] 2982 	sjmp	00116$
      00695D                       2983 00115$:
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      00695D 8F 05            [24] 2985 	mov	ar5,r7
      00695F 74 18            [12] 2986 	mov	a,#0x18
      006961 5D               [12] 2987 	anl	a,r5
      006962 FC               [12] 2988 	mov	r4,a
      006963 BC 10 2D         [24] 2989 	cjne	r4,#0x10,00112$
                                   2990 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006966 EE               [12] 2991 	mov	a,r6
      006967 70 05            [24] 2992 	jnz	00106$
      006969 12 68 A5         [24] 2993 	lcall	_control_in
      00696C 80 32            [24] 2994 	sjmp	00116$
      00696E                       2995 00106$:
                                   2996 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      00696E EE               [12] 2997 	mov	a,r6
      00696F 24 FC            [12] 2998 	add	a,#0xff - 0x03
      006971 40 2D            [24] 2999 	jc	00116$
                                   3000 ;	free result
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006973 8E 04            [24] 3002 	mov	ar4,r6
      006975 7B 00            [12] 3003 	mov	r3,#0x00
      006977 74 22            [12] 3004 	mov	a,#0x22
      006979 2B               [12] 3005 	add	a, r3
      00697A FB               [12] 3006 	mov	r3,a
      00697B 8C 82            [24] 3007 	mov	dpl,r4
      00697D 8B 83            [24] 3008 	mov	dph,r3
      00697F E0               [24] 3009 	movx	a,@dptr
      006980 FA               [12] 3010 	mov	r2,a
      006981 74 FC            [12] 3011 	mov	a,#0xfc
      006983 5A               [12] 3012 	anl	a,r2
      006984 44 02            [12] 3013 	orl	a,#0x02
      006986 8C 82            [24] 3014 	mov	dpl,r4
      006988 8B 83            [24] 3015 	mov	dph,r3
      00698A F0               [24] 3016 	movx	@dptr,a
                                   3017 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00698B BE 03 12         [24] 3018 	cjne	r6,#0x03,00116$
      00698E 12 5D BD         [24] 3019 	lcall	_raw_complete
      006991 80 0D            [24] 3020 	sjmp	00116$
      006993                       3021 00112$:
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006993 53 05 18         [24] 3023 	anl	ar5,#0x18
      006996 BD 18 07         [24] 3024 	cjne	r5,#0x18,00116$
      006999 EF               [12] 3025 	mov	a,r7
      00699A 30 E5 03         [24] 3026 	jnb	acc.5,00116$
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      00699D 12 60 4A         [24] 3028 	lcall	_control_setup
      0069A0                       3029 00116$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      0069A0 90 22 0F         [24] 3031 	mov	dptr,#0x220f
      0069A3 E4               [12] 3032 	clr	a
      0069A4 F0               [24] 3033 	movx	@dptr,a
      0069A5 80 2C            [24] 3034 	sjmp	00130$
      0069A7                       3035 00124$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      0069A7 90 22 3D         [24] 3037 	mov	dptr,#0x223d
      0069AA E0               [24] 3038 	movx	a,@dptr
      0069AB 30 E2 25         [24] 3039 	jnb	acc.2,00130$
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0069AE 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      0069B1 E0               [24] 3042 	movx	a,@dptr
      0069B2 30 E3 0A         [24] 3043 	jnb	acc.3,00119$
      0069B5 90 07 C3         [24] 3044 	mov	dptr,#_USB_SleepStatus
      0069B8 E0               [24] 3045 	movx	a,@dptr
      0069B9 43 E0 02         [24] 3046 	orl	acc,#0x02
      0069BC F0               [24] 3047 	movx	@dptr,a
      0069BD 80 0E            [24] 3048 	sjmp	00120$
      0069BF                       3049 00119$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      0069BF 90 07 C3         [24] 3051 	mov	dptr,#_USB_SleepStatus
      0069C2 E0               [24] 3052 	movx	a,@dptr
      0069C3 53 E0 FD         [24] 3053 	anl	acc,#0xfd
      0069C6 F0               [24] 3054 	movx	@dptr,a
                                   3055 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      0069C7 90 07 EB         [24] 3056 	mov	dptr,#_keyboard_reset
      0069CA 74 01            [12] 3057 	mov	a,#0x01
      0069CC F0               [24] 3058 	movx	@dptr,a
      0069CD                       3059 00120$:
                                   3060 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      0069CD 90 22 3D         [24] 3061 	mov	dptr,#0x223d
      0069D0 74 04            [12] 3062 	mov	a,#0x04
      0069D2 F0               [24] 3063 	movx	@dptr,a
      0069D3                       3064 00130$:
                                   3065 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      0069D3 90 22 3D         [24] 3066 	mov	dptr,#0x223d
      0069D6 E0               [24] 3067 	movx	a,@dptr
      0069D7 54 25            [12] 3068 	anl	a,#0x25
      0069D9 60 03            [24] 3069 	jz	00242$
      0069DB 02 68 EE         [24] 3070 	ljmp	00129$
      0069DE                       3071 00242$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      0069DE 22               [24] 3073 	ret
                                   3074 ;------------------------------------------------------------
                                   3075 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3076 ;------------------------------------------------------------
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3078 ;	-----------------------------------------
                                   3079 ;	 function USB_Device_Init
                                   3080 ;	-----------------------------------------
      0069DF                       3081 _USB_Device_Init:
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3083 ;	assignBit
      0069DF C2 E9            [12] 3084 	clr	_IE_USB
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      0069E1 90 22 3C         [24] 3086 	mov	dptr,#0x223c
      0069E4 E4               [12] 3087 	clr	a
      0069E5 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      0069E6 90 07 C9         [24] 3090 	mov	dptr,#_raw_state
      0069E9 F0               [24] 3091 	movx	@dptr,a
                                   3092 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      0069EA 12 5D DA         [24] 3093 	lcall	_endpoints_reset
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0069ED 90 07 C3         [24] 3095 	mov	dptr,#_USB_SleepStatus
      0069F0 E4               [12] 3096 	clr	a
      0069F1 F0               [24] 3097 	movx	@dptr,a
      0069F2 90 07 C2         [24] 3098 	mov	dptr,#_USB_EnumStatus
      0069F5 F0               [24] 3099 	movx	@dptr,a
      0069F6 90 07 C1         [24] 3100 	mov	dptr,#_D0UsbConfig
      0069F9 F0               [24] 3101 	movx	@dptr,a
      0069FA 90 22 07         [24] 3102 	mov	dptr,#0x2207
      0069FD F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0069FE 90 07 C4         [24] 3105 	mov	dptr,#_MCU_Sleep_Operate
      006A01 F0               [24] 3106 	movx	@dptr,a
      006A02 90 07 C5         [24] 3107 	mov	dptr,#_KB_USB_UpStatus
      006A05 F0               [24] 3108 	movx	@dptr,a
      006A06 90 07 C6         [24] 3109 	mov	dptr,#_KB_USB_SetReport
      006A09 F0               [24] 3110 	movx	@dptr,a
                                   3111 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006A0A 90 0E 05         [24] 3112 	mov	dptr,#_keyboard_protocol
      006A0D 04               [12] 3113 	inc	a
      006A0E F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006A0F 90 06 99         [24] 3116 	mov	dptr,#_keyboard_idle
      006A12 E4               [12] 3117 	clr	a
      006A13 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006A14 90 07 EB         [24] 3120 	mov	dptr,#_keyboard_reset
      006A17 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006A18 90 08 1A         [24] 3123 	mov	dptr,#_control_phase
      006A1B F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006A1C 90 07 BB         [24] 3126 	mov	dptr,#_D0SetupReqCode
      006A1F 14               [12] 3127 	dec	a
      006A20 F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006A21 90 07 BC         [24] 3130 	mov	dptr,#_D0SetupLen
      006A24 E4               [12] 3131 	clr	a
      006A25 F0               [24] 3132 	movx	@dptr,a
      006A26 A3               [24] 3133 	inc	dptr
      006A27 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A28 90 22 00         [24] 3136 	mov	dptr,#0x2200
      006A2B 74 02            [12] 3137 	mov	a,#0x02
      006A2D F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006A2E 90 22 37         [24] 3140 	mov	dptr,#0x2237
      006A31 74 7F            [12] 3141 	mov	a,#0x7f
      006A33 F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006A34 90 22 3D         [24] 3144 	mov	dptr,#0x223d
      006A37 74 FF            [12] 3145 	mov	a,#0xff
      006A39 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006A3A 90 22 3B         [24] 3148 	mov	dptr,#0x223b
      006A3D 74 07            [12] 3149 	mov	a,#0x07
      006A3F F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006A40 A3               [24] 3152 	inc	dptr
      006A41 74 80            [12] 3153 	mov	a,#0x80
      006A43 F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3156 ;	assignBit
      006A44 D2 E9            [12] 3157 	setb	_IE_USB
                                   3158 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006A46 22               [24] 3159 	ret
                                   3160 ;------------------------------------------------------------
                                   3161 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3162 ;------------------------------------------------------------
                                   3163 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3164 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3165 ;------------------------------------------------------------
                                   3166 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3167 ;	-----------------------------------------
                                   3168 ;	 function USB_WakeUp_PC
                                   3169 ;	-----------------------------------------
      006A47                       3170 _USB_WakeUp_PC:
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006A47 90 07 C3         [24] 3172 	mov	dptr,#_USB_SleepStatus
      006A4A E0               [24] 3173 	movx	a,@dptr
      006A4B FF               [12] 3174 	mov	r7,a
      006A4C BF 03 22         [24] 3175 	cjne	r7,#0x03,00110$
                                   3176 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006A4F 90 22 3C         [24] 3177 	mov	dptr,#0x223c
      006A52 E0               [24] 3178 	movx	a,@dptr
      006A53 FF               [12] 3179 	mov	r7,a
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006A54 E0               [24] 3181 	movx	a,@dptr
      006A55 FE               [12] 3182 	mov	r6,a
      006A56 63 06 C0         [24] 3183 	xrl	ar6,#0xc0
      006A59 90 22 3C         [24] 3184 	mov	dptr,#0x223c
      006A5C EE               [12] 3185 	mov	a,r6
      006A5D F0               [24] 3186 	movx	@dptr,a
                                   3187 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006A5E 7E 0A            [12] 3188 	mov	r6,#0x0a
      006A60                       3189 00108$:
      006A60 EE               [12] 3190 	mov	a,r6
      006A61 60 09            [24] 3191 	jz	00105$
      006A63 90 00 01         [24] 3192 	mov	dptr,#0x0001
      006A66 12 5C 21         [24] 3193 	lcall	_mDelaymS
      006A69 1E               [12] 3194 	dec	r6
      006A6A 80 F4            [24] 3195 	sjmp	00108$
      006A6C                       3196 00105$:
                                   3197 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006A6C 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006A6F EF               [12] 3199 	mov	a,r7
      006A70 F0               [24] 3200 	movx	@dptr,a
      006A71                       3201 00110$:
                                   3202 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006A71 22               [24] 3203 	ret
                                   3204 ;------------------------------------------------------------
                                   3205 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3206 ;------------------------------------------------------------
                                   3207 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3208 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3209 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3210 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3211 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3212 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3213 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3214 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3215 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3216 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3218 ;------------------------------------------------------------
                                   3219 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3220 ;	-----------------------------------------
                                   3221 ;	 function ak820_usb_send
                                   3222 ;	-----------------------------------------
      006A72                       3223 _ak820_usb_send:
      006A72 E5 82            [12] 3224 	mov	a,dpl
      006A74 90 08 2A         [24] 3225 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A77 F0               [24] 3226 	movx	@dptr,a
                                   3227 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006A78 90 08 2B         [24] 3228 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A7B 74 2E            [12] 3229 	mov	a,#0x2e
      006A7D F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A7E 90 08 2A         [24] 3232 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A81 E0               [24] 3233 	movx	a,@dptr
      006A82 FF               [12] 3234 	mov	r7,a
      006A83 BF 01 00         [24] 3235 	cjne	r7,#0x01,00306$
      006A86                       3236 00306$:
      006A86 40 14            [24] 3237 	jc	00101$
      006A88 EF               [12] 3238 	mov	a,r7
      006A89 24 FC            [12] 3239 	add	a,#0xff - 0x03
      006A8B 40 0F            [24] 3240 	jc	00101$
                                   3241 ;	free result
      006A8D 90 08 29         [24] 3242 	mov	dptr,#_ak820_usb_send_PARM_3
      006A90 E0               [24] 3243 	movx	a,@dptr
      006A91 FE               [12] 3244 	mov  r6,a
      006A92 24 BF            [12] 3245 	add	a,#0xff - 0x40
      006A94 40 06            [24] 3246 	jc	00101$
                                   3247 ;	free result
      006A96 90 07 C2         [24] 3248 	mov	dptr,#_USB_EnumStatus
      006A99 E0               [24] 3249 	movx	a,@dptr
      006A9A 70 04            [24] 3250 	jnz	00102$
      006A9C                       3251 00101$:
      006A9C 75 82 00         [24] 3252 	mov	dpl, #0x00
      006A9F 22               [24] 3253 	ret
      006AA0                       3254 00102$:
                                   3255 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006AA0 BF 01 10         [24] 3256 	cjne	r7,#0x01,00118$
                                   3257 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006AA3 BE 08 02         [24] 3258 	cjne	r6,#0x08,00313$
      006AA6 80 04            [24] 3259 	sjmp	00107$
      006AA8                       3260 00313$:
      006AA8 75 82 00         [24] 3261 	mov	dpl, #0x00
      006AAB 22               [24] 3262 	ret
      006AAC                       3263 00107$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006AAC 90 08 2B         [24] 3265 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006AAF E4               [12] 3266 	clr	a
      006AB0 F0               [24] 3267 	movx	@dptr,a
      006AB1 80 3C            [24] 3268 	sjmp	00119$
      006AB3                       3269 00118$:
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006AB3 BF 02 30         [24] 3271 	cjne	r7,#0x02,00115$
                                   3272 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006AB6 90 08 27         [24] 3273 	mov	dptr,#_ak820_usb_send_PARM_2
      006AB9 E0               [24] 3274 	movx	a,@dptr
      006ABA FD               [12] 3275 	mov	r5,a
      006ABB A3               [24] 3276 	inc	dptr
      006ABC E0               [24] 3277 	movx	a,@dptr
      006ABD FF               [12] 3278 	mov	r7,a
      006ABE 8D 82            [24] 3279 	mov	dpl,r5
      006AC0 8F 83            [24] 3280 	mov	dph,r7
      006AC2 E0               [24] 3281 	movx	a,@dptr
      006AC3 FF               [12] 3282 	mov	r7,a
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006AC4 BF 07 00         [24] 3284 	cjne	r7,#0x07,00316$
      006AC7                       3285 00316$:
      006AC7 50 0E            [24] 3286 	jnc	00108$
      006AC9 EF               [12] 3287 	mov	a,r7
      006ACA 90 BD 5F         [24] 3288 	mov	dptr,#_shared_lengths
      006ACD 93               [24] 3289 	movc	a,@a+dptr
      006ACE FD               [12] 3290 	mov	r5,a
      006ACF 60 06            [24] 3291 	jz	00108$
      006AD1 EE               [12] 3292 	mov	a,r6
      006AD2 B5 05 02         [24] 3293 	cjne	a,ar5,00319$
      006AD5 80 04            [24] 3294 	sjmp	00109$
      006AD7                       3295 00319$:
      006AD7                       3296 00108$:
      006AD7 75 82 00         [24] 3297 	mov	dpl, #0x00
      006ADA 22               [24] 3298 	ret
      006ADB                       3299 00109$:
                                   3300 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006ADB EF               [12] 3301 	mov	a,r7
      006ADC 90 BD 58         [24] 3302 	mov	dptr,#_shared_offsets
      006ADF 93               [24] 3303 	movc	a,@a+dptr
      006AE0 90 08 2B         [24] 3304 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006AE3 F0               [24] 3305 	movx	@dptr,a
      006AE4 80 09            [24] 3306 	sjmp	00119$
      006AE6                       3307 00115$:
                                   3308 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006AE6 BE 20 02         [24] 3309 	cjne	r6,#0x20,00320$
      006AE9 80 04            [24] 3310 	sjmp	00119$
      006AEB                       3311 00320$:
      006AEB 75 82 00         [24] 3312 	mov	dpl, #0x00
      006AEE 22               [24] 3313 	ret
      006AEF                       3314 00119$:
                                   3315 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006AEF 90 07 C3         [24] 3316 	mov	dptr,#_USB_SleepStatus
      006AF2 E0               [24] 3317 	movx	a,@dptr
      006AF3 30 E1 07         [24] 3318 	jnb	acc.1,00184$
      006AF6 12 6A 47         [24] 3319 	lcall	_USB_WakeUp_PC
      006AF9 75 82 00         [24] 3320 	mov	dpl, #0x00
      006AFC 22               [24] 3321 	ret
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006AFD                       3323 00184$:
      006AFD 7F FA            [12] 3324 	mov	r7,#0xfa
      006AFF                       3325 00127$:
      006AFF 90 08 2A         [24] 3326 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B02 E0               [24] 3327 	movx	a,@dptr
      006B03 FC               [12] 3328 	mov	r4,a
      006B04 7D 00            [12] 3329 	mov	r5,#0x00
      006B06 8C 02            [24] 3330 	mov	ar2,r4
      006B08 74 22            [12] 3331 	mov	a,#0x22
      006B0A 2D               [12] 3332 	add	a, r5
      006B0B FB               [12] 3333 	mov	r3,a
      006B0C 8A 82            [24] 3334 	mov	dpl,r2
      006B0E 8B 83            [24] 3335 	mov	dph,r3
      006B10 E0               [24] 3336 	movx	a,@dptr
      006B11 54 03            [12] 3337 	anl	a,#0x03
      006B13 70 14            [24] 3338 	jnz	00129$
      006B15 8F 03            [24] 3339 	mov	ar3,r7
      006B17 1F               [12] 3340 	dec	r7
      006B18 EB               [12] 3341 	mov	a,r3
      006B19 60 0E            [24] 3342 	jz	00129$
      006B1B 7B 28            [12] 3343 	mov	r3,#0x28
      006B1D                       3344 00141$:
      006B1D EB               [12] 3345 	mov	a,r3
      006B1E 60 DF            [24] 3346 	jz	00127$
      006B20 90 00 01         [24] 3347 	mov	dptr,#0x0001
      006B23 12 5B DD         [24] 3348 	lcall	_mDelayuS
      006B26 1B               [12] 3349 	dec	r3
      006B27 80 F4            [24] 3350 	sjmp	00141$
      006B29                       3351 00129$:
                                   3352 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006B29 A2 AF            [12] 3353 	mov	c,_EA
      006B2B E4               [12] 3354 	clr	a
      006B2C 33               [12] 3355 	rlc	a
      006B2D FF               [12] 3356 	mov	r7,a
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3358 ;	assignBit
      006B2E C2 AF            [12] 3359 	clr	_EA
                                   3360 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006B30 90 07 C2         [24] 3361 	mov	dptr,#_USB_EnumStatus
      006B33 E0               [24] 3362 	movx	a,@dptr
      006B34 60 25            [24] 3363 	jz	00130$
      006B36 90 08 2A         [24] 3364 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B39 E0               [24] 3365 	movx	a,@dptr
      006B3A FB               [12] 3366 	mov	r3,a
      006B3B F9               [12] 3367 	mov	r1,a
      006B3C 7A 00            [12] 3368 	mov	r2,#0x00
      006B3E 74 22            [12] 3369 	mov	a,#0x22
      006B40 2A               [12] 3370 	add	a, r2
      006B41 FA               [12] 3371 	mov	r2,a
      006B42 89 82            [24] 3372 	mov	dpl,r1
      006B44 8A 83            [24] 3373 	mov	dph,r2
      006B46 E0               [24] 3374 	movx	a,@dptr
      006B47 FA               [12] 3375 	mov	r2,a
      006B48 53 02 03         [24] 3376 	anl	ar2,#0x03
      006B4B BA 02 0D         [24] 3377 	cjne	r2,#0x02,00130$
                                   3378 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006B4E BB 03 13         [24] 3379 	cjne	r3,#0x03,00192$
      006B51 90 07 C9         [24] 3380 	mov	dptr,#_raw_state
      006B54 E0               [24] 3381 	movx	a,@dptr
      006B55 FB               [12] 3382 	mov	r3,a
      006B56 BB 03 02         [24] 3383 	cjne	r3,#0x03,00331$
      006B59 80 09            [24] 3384 	sjmp	00192$
      006B5B                       3385 00331$:
      006B5B                       3386 00130$:
                                   3387 ;	assignBit
      006B5B EF               [12] 3388 	mov	a,r7
      006B5C 24 FF            [12] 3389 	add	a,#0xff
      006B5E 92 AF            [24] 3390 	mov	_EA,c
      006B60 75 82 00         [24] 3391 	mov	dpl, #0x00
      006B63 22               [24] 3392 	ret
                                   3393 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006B64                       3394 00192$:
      006B64 7B 00            [12] 3395 	mov	r3,#0x00
      006B66                       3396 00144$:
      006B66 C3               [12] 3397 	clr	c
      006B67 EB               [12] 3398 	mov	a,r3
      006B68 9E               [12] 3399 	subb	a,r6
      006B69 50 67            [24] 3400 	jnc	00137$
                                   3401 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B6B C0 07            [24] 3402 	push	ar7
      006B6D 90 08 2A         [24] 3403 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B70 E0               [24] 3404 	movx	a,@dptr
      006B71 F9               [12] 3405 	mov	r1,a
      006B72 E4               [12] 3406 	clr	a
      006B73 C3               [12] 3407 	clr	c
      006B74 C9               [12] 3408 	xch	a,r1
      006B75 13               [12] 3409 	rrc	a
      006B76 C9               [12] 3410 	xch	a,r1
      006B77 13               [12] 3411 	rrc	a
      006B78 A2 E0            [12] 3412 	mov	c,acc.0
      006B7A C9               [12] 3413 	xch	a,r1
      006B7B 13               [12] 3414 	rrc	a
      006B7C C9               [12] 3415 	xch	a,r1
      006B7D 13               [12] 3416 	rrc	a
      006B7E C9               [12] 3417 	xch	a,r1
      006B7F FA               [12] 3418 	mov	r2,a
      006B80 8B 00            [24] 3419 	mov	ar0,r3
      006B82 7F 00            [12] 3420 	mov	r7,#0x00
      006B84 E8               [12] 3421 	mov	a,r0
      006B85 29               [12] 3422 	add	a, r1
      006B86 F9               [12] 3423 	mov	r1,a
      006B87 EF               [12] 3424 	mov	a,r7
      006B88 3A               [12] 3425 	addc	a, r2
      006B89 24 10            [12] 3426 	add	a,#0x10
      006B8B FA               [12] 3427 	mov	r2,a
      006B8C 90 08 27         [24] 3428 	mov	dptr,#_ak820_usb_send_PARM_2
      006B8F E0               [24] 3429 	movx	a,@dptr
      006B90 F8               [12] 3430 	mov	r0,a
      006B91 A3               [24] 3431 	inc	dptr
      006B92 E0               [24] 3432 	movx	a,@dptr
      006B93 FF               [12] 3433 	mov	r7,a
      006B94 EB               [12] 3434 	mov	a,r3
      006B95 28               [12] 3435 	add	a, r0
      006B96 F5 1B            [12] 3436 	mov	_ak820_usb_send_sloc0_1_0,a
      006B98 E4               [12] 3437 	clr	a
      006B99 3F               [12] 3438 	addc	a, r7
      006B9A F5 1C            [12] 3439 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006B9C 85 1B 82         [24] 3440 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B9F 85 1C 83         [24] 3441 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BA2 E0               [24] 3442 	movx	a,@dptr
      006BA3 89 82            [24] 3443 	mov	dpl,r1
      006BA5 8A 83            [24] 3444 	mov	dph,r2
      006BA7 F0               [24] 3445 	movx	@dptr,a
                                   3446 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006BA8 90 08 2B         [24] 3447 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006BAB E0               [24] 3448 	movx	a,@dptr
      006BAC F5 1D            [12] 3449 	mov	_ak820_usb_send_sloc1_1_0,a
      006BAE 74 2E            [12] 3450 	mov	a,#0x2e
      006BB0 B5 1D 04         [24] 3451 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006BB3 D0 07            [24] 3452 	pop	ar7
      006BB5 80 18            [24] 3453 	sjmp	00145$
      006BB7                       3454 00333$:
      006BB7 D0 07            [24] 3455 	pop	ar7
      006BB9 EB               [12] 3456 	mov	a,r3
      006BBA 25 1D            [12] 3457 	add	a, _ak820_usb_send_sloc1_1_0
      006BBC 24 EC            [12] 3458 	add	a, #_input_snapshot
      006BBE F9               [12] 3459 	mov	r1,a
      006BBF E4               [12] 3460 	clr	a
      006BC0 34 07            [12] 3461 	addc	a,#(_input_snapshot >> 8)
      006BC2 FA               [12] 3462 	mov	r2,a
      006BC3 85 1B 82         [24] 3463 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BC6 85 1C 83         [24] 3464 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BC9 E0               [24] 3465 	movx	a,@dptr
      006BCA 89 82            [24] 3466 	mov	dpl,r1
      006BCC 8A 83            [24] 3467 	mov	dph,r2
      006BCE F0               [24] 3468 	movx	@dptr,a
      006BCF                       3469 00145$:
                                   3470 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006BCF 0B               [12] 3471 	inc	r3
      006BD0 80 94            [24] 3472 	sjmp	00144$
      006BD2                       3473 00137$:
                                   3474 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006BD2 90 08 2A         [24] 3475 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BD5 E0               [24] 3476 	movx	a,@dptr
      006BD6 FB               [12] 3477 	mov	r3,a
      006BD7 F9               [12] 3478 	mov	r1,a
      006BD8 7A 00            [12] 3479 	mov	r2,#0x00
      006BDA 74 08            [12] 3480 	mov	a,#0x08
      006BDC 29               [12] 3481 	add	a, r1
      006BDD F9               [12] 3482 	mov	r1,a
      006BDE 74 22            [12] 3483 	mov	a,#0x22
      006BE0 3A               [12] 3484 	addc	a, r2
      006BE1 FA               [12] 3485 	mov	r2,a
      006BE2 89 82            [24] 3486 	mov	dpl,r1
      006BE4 8A 83            [24] 3487 	mov	dph,r2
      006BE6 EE               [12] 3488 	mov	a,r6
      006BE7 F0               [24] 3489 	movx	@dptr,a
                                   3490 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006BE8 BB 03 06         [24] 3491 	cjne	r3,#0x03,00139$
      006BEB 90 07 C9         [24] 3492 	mov	dptr,#_raw_state
      006BEE 74 04            [12] 3493 	mov	a,#0x04
      006BF0 F0               [24] 3494 	movx	@dptr,a
      006BF1                       3495 00139$:
                                   3496 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006BF1 74 22            [12] 3497 	mov	a,#0x22
      006BF3 2D               [12] 3498 	add	a, r5
      006BF4 FD               [12] 3499 	mov	r5,a
      006BF5 8C 82            [24] 3500 	mov	dpl,r4
      006BF7 8D 83            [24] 3501 	mov	dph,r5
      006BF9 E0               [24] 3502 	movx	a,@dptr
      006BFA FE               [12] 3503 	mov	r6,a
      006BFB 53 06 FC         [24] 3504 	anl	ar6,#0xfc
      006BFE 8C 82            [24] 3505 	mov	dpl,r4
      006C00 8D 83            [24] 3506 	mov	dph,r5
      006C02 EE               [12] 3507 	mov	a,r6
      006C03 F0               [24] 3508 	movx	@dptr,a
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3510 ;	assignBit
      006C04 EF               [12] 3511 	mov	a,r7
      006C05 24 FF            [12] 3512 	add	a,#0xff
      006C07 92 AF            [24] 3513 	mov	_EA,c
                                   3514 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006C09 75 82 01         [24] 3515 	mov	dpl, #0x01
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006C0C 22               [24] 3517 	ret
                                   3518 ;------------------------------------------------------------
                                   3519 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3520 ;------------------------------------------------------------
                                   3521 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3522 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3523 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3524 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3525 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3526 ;------------------------------------------------------------
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3528 ;	-----------------------------------------
                                   3529 ;	 function ak820_usb_try_send
                                   3530 ;	-----------------------------------------
      006C0D                       3531 _ak820_usb_try_send:
      006C0D E5 82            [12] 3532 	mov	a,dpl
      006C0F 90 08 2F         [24] 3533 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006C12 F0               [24] 3534 	movx	@dptr,a
                                   3535 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3536 ;	assignBit
      006C13 A2 AF            [12] 3537 	mov	c,_EA
      006C15 92 1D            [24] 3538 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3539 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006C17 90 08 30         [24] 3540 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C1A E4               [12] 3541 	clr	a
      006C1B F0               [24] 3542 	movx	@dptr,a
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3544 ;	assignBit
      006C1C C2 AF            [12] 3545 	clr	_EA
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006C1E 90 08 2F         [24] 3547 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006C21 E0               [24] 3548 	movx	a,@dptr
      006C22 FF               [12] 3549 	mov	r7,a
      006C23 BF 01 00         [24] 3550 	cjne	r7,#0x01,00152$
      006C26                       3551 00152$:
      006C26 40 4E            [24] 3552 	jc	00102$
      006C28 EF               [12] 3553 	mov	a,r7
      006C29 24 FD            [12] 3554 	add	a,#0xff - 0x02
      006C2B 40 49            [24] 3555 	jc	00102$
                                   3556 ;	free result
      006C2D 90 07 C2         [24] 3557 	mov	dptr,#_USB_EnumStatus
      006C30 E0               [24] 3558 	movx	a,@dptr
      006C31 60 43            [24] 3559 	jz	00102$
                                   3560 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006C33 90 07 C3         [24] 3561 	mov	dptr,#_USB_SleepStatus
      006C36 E0               [24] 3562 	movx	a,@dptr
      006C37 20 E1 3C         [24] 3563 	jb	acc.1,00102$
      006C3A 90 07 EB         [24] 3564 	mov	dptr,#_keyboard_reset
      006C3D E0               [24] 3565 	movx	a,@dptr
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006C3E 70 36            [24] 3567 	jnz	00102$
      006C40 8F 06            [24] 3568 	mov	ar6,r7
      006C42 24 22            [12] 3569 	add	a,#0x22
      006C44 FD               [12] 3570 	mov	r5,a
      006C45 8E 82            [24] 3571 	mov	dpl,r6
      006C47 8D 83            [24] 3572 	mov	dph,r5
      006C49 E0               [24] 3573 	movx	a,@dptr
      006C4A FE               [12] 3574 	mov	r6,a
      006C4B 53 06 03         [24] 3575 	anl	ar6,#0x03
      006C4E BE 02 25         [24] 3576 	cjne	r6,#0x02,00102$
                                   3577 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006C51 90 08 2C         [24] 3578 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006C54 E0               [24] 3579 	movx	a,@dptr
      006C55 FD               [12] 3580 	mov	r5,a
      006C56 A3               [24] 3581 	inc	dptr
      006C57 E0               [24] 3582 	movx	a,@dptr
      006C58 FE               [12] 3583 	mov	r6,a
      006C59 90 08 2E         [24] 3584 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006C5C E0               [24] 3585 	movx	a,@dptr
      006C5D FC               [12] 3586 	mov	r4,a
      006C5E 90 08 27         [24] 3587 	mov	dptr,#_ak820_usb_send_PARM_2
      006C61 ED               [12] 3588 	mov	a,r5
      006C62 F0               [24] 3589 	movx	@dptr,a
      006C63 EE               [12] 3590 	mov	a,r6
      006C64 A3               [24] 3591 	inc	dptr
      006C65 F0               [24] 3592 	movx	@dptr,a
      006C66 90 08 29         [24] 3593 	mov	dptr,#_ak820_usb_send_PARM_3
      006C69 EC               [12] 3594 	mov	a,r4
      006C6A F0               [24] 3595 	movx	@dptr,a
      006C6B 8F 82            [24] 3596 	mov	dpl, r7
      006C6D 12 6A 72         [24] 3597 	lcall	_ak820_usb_send
      006C70 E5 82            [12] 3598 	mov	a, dpl
      006C72 90 08 30         [24] 3599 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C75 F0               [24] 3600 	movx	@dptr,a
      006C76                       3601 00102$:
                                   3602 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3603 ;	assignBit
      006C76 A2 1D            [12] 3604 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C78 92 AF            [24] 3605 	mov	_EA,c
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006C7A 90 08 30         [24] 3607 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C7D E0               [24] 3608 	movx	a,@dptr
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006C7E F5 82            [12] 3610 	mov	dpl,a
      006C80 22               [24] 3611 	ret
                                   3612 ;------------------------------------------------------------
                                   3613 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3614 ;------------------------------------------------------------
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3616 ;	-----------------------------------------
                                   3617 ;	 function raw_request_is_nonpersistent
                                   3618 ;	-----------------------------------------
      006C81                       3619 _raw_request_is_nonpersistent:
                                   3620 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006C81 90 07 CA         [24] 3621 	mov	dptr,#_raw_buffer
      006C84 E0               [24] 3622 	movx	a,@dptr
      006C85 FF               [12] 3623 	mov	r7,a
      006C86 BF 01 02         [24] 3624 	cjne	r7,#0x01,00302$
      006C89 80 35            [24] 3625 	sjmp	00108$
      006C8B                       3626 00302$:
      006C8B BF 02 02         [24] 3627 	cjne	r7,#0x02,00303$
      006C8E 80 34            [24] 3628 	sjmp	00109$
      006C90                       3629 00303$:
      006C90 BF 04 02         [24] 3630 	cjne	r7,#0x04,00304$
      006C93 80 2B            [24] 3631 	sjmp	00108$
      006C95                       3632 00304$:
      006C95 BF 08 02         [24] 3633 	cjne	r7,#0x08,00305$
      006C98 80 47            [24] 3634 	sjmp	00116$
      006C9A                       3635 00305$:
      006C9A BF 0B 02         [24] 3636 	cjne	r7,#0x0b,00306$
      006C9D 80 21            [24] 3637 	sjmp	00108$
      006C9F                       3638 00306$:
      006C9F BF 0C 02         [24] 3639 	cjne	r7,#0x0c,00307$
      006CA2 80 1C            [24] 3640 	sjmp	00108$
      006CA4                       3641 00307$:
      006CA4 BF 0D 02         [24] 3642 	cjne	r7,#0x0d,00308$
      006CA7 80 17            [24] 3643 	sjmp	00108$
      006CA9                       3644 00308$:
      006CA9 BF 0E 02         [24] 3645 	cjne	r7,#0x0e,00309$
      006CAC 80 12            [24] 3646 	sjmp	00108$
      006CAE                       3647 00309$:
      006CAE BF 11 02         [24] 3648 	cjne	r7,#0x11,00310$
      006CB1 80 0D            [24] 3649 	sjmp	00108$
      006CB3                       3650 00310$:
      006CB3 BF 12 02         [24] 3651 	cjne	r7,#0x12,00311$
      006CB6 80 08            [24] 3652 	sjmp	00108$
      006CB8                       3653 00311$:
      006CB8 BF FE 02         [24] 3654 	cjne	r7,#0xfe,00312$
      006CBB 80 46            [24] 3655 	sjmp	00124$
      006CBD                       3656 00312$:
      006CBD 02 6D 58         [24] 3657 	ljmp	00144$
                                   3658 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006CC0                       3659 00108$:
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006CC0 75 82 01         [24] 3661 	mov	dpl, #0x01
      006CC3 22               [24] 3662 	ret
                                   3663 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006CC4                       3664 00109$:
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006CC4 12 6F AC         [24] 3666 	lcall	_ak820_outline_0163
      006CC7 BF 01 02         [24] 3667 	cjne	r7,#0x01,00313$
      006CCA 80 0D            [24] 3668 	sjmp	00113$
      006CCC                       3669 00313$:
      006CCC BF 02 02         [24] 3670 	cjne	r7,#0x02,00314$
      006CCF 80 08            [24] 3671 	sjmp	00113$
      006CD1                       3672 00314$:
      006CD1 BF 03 02         [24] 3673 	cjne	r7,#0x03,00315$
      006CD4 80 03            [24] 3674 	sjmp	00113$
      006CD6                       3675 00315$:
      006CD6 BF 04 04         [24] 3676 	cjne	r7,#0x04,00114$
                                   3677 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006CD9                       3678 00113$:
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006CD9 75 82 01         [24] 3680 	mov	dpl, #0x01
      006CDC 22               [24] 3681 	ret
                                   3682 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006CDD                       3683 00114$:
      006CDD 75 82 00         [24] 3684 	mov	dpl, #0x00
      006CE0 22               [24] 3685 	ret
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006CE1                       3687 00116$:
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006CE1 12 6F AC         [24] 3689 	lcall	_ak820_outline_0163
      006CE4 BF 40 02         [24] 3690 	cjne	r7,#0x40,00318$
      006CE7 80 12            [24] 3691 	sjmp	00121$
      006CE9                       3692 00318$:
      006CE9 BF 41 02         [24] 3693 	cjne	r7,#0x41,00319$
      006CEC 80 0D            [24] 3694 	sjmp	00121$
      006CEE                       3695 00319$:
      006CEE BF 42 02         [24] 3696 	cjne	r7,#0x42,00320$
      006CF1 80 08            [24] 3697 	sjmp	00121$
      006CF3                       3698 00320$:
      006CF3 BF 43 02         [24] 3699 	cjne	r7,#0x43,00321$
      006CF6 80 03            [24] 3700 	sjmp	00121$
      006CF8                       3701 00321$:
      006CF8 BF 44 04         [24] 3702 	cjne	r7,#0x44,00122$
                                   3703 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006CFB                       3704 00121$:
                                   3705 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006CFB 75 82 01         [24] 3706 	mov	dpl, #0x01
                                   3707 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006CFE 22               [24] 3708 	ret
      006CFF                       3709 00122$:
      006CFF 75 82 00         [24] 3710 	mov	dpl, #0x00
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006D02 22               [24] 3712 	ret
      006D03                       3713 00124$:
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006D03 12 6F AC         [24] 3715 	lcall	_ak820_outline_0163
      006D06 24 F2            [12] 3716 	add	a,#0xff - 0x0d
      006D08 40 4A            [24] 3717 	jc	00142$
                                   3718 ;	free result
      006D0A EF               [12] 3719 	mov	a,r7
      006D0B 24 0A            [12] 3720 	add	a,#(00325$-3-.)
      006D0D 83               [24] 3721 	movc	a,@a+pc
      006D0E F5 82            [12] 3722 	mov	dpl,a
      006D10 EF               [12] 3723 	mov	a,r7
      006D11 24 12            [12] 3724 	add	a,#(00326$-3-.)
      006D13 83               [24] 3725 	movc	a,@a+pc
      006D14 F5 83            [12] 3726 	mov	dph,a
      006D16 E4               [12] 3727 	clr	a
      006D17 73               [24] 3728 	jmp	@a+dptr
      006D18                       3729 00325$:
      006D18 34                    3730 	.db	00134$
      006D19 34                    3731 	.db	00134$
      006D1A 34                    3732 	.db	00134$
      006D1B 34                    3733 	.db	00134$
      006D1C 54                    3734 	.db	00142$
      006D1D 34                    3735 	.db	00134$
      006D1E 34                    3736 	.db	00134$
      006D1F 34                    3737 	.db	00134$
      006D20 34                    3738 	.db	00134$
      006D21 34                    3739 	.db	00134$
      006D22 34                    3740 	.db	00134$
      006D23 54                    3741 	.db	00142$
      006D24 54                    3742 	.db	00142$
      006D25 38                    3743 	.db	00135$
      006D26                       3744 00326$:
      006D26 6D                    3745 	.db	00134$>>8
      006D27 6D                    3746 	.db	00134$>>8
      006D28 6D                    3747 	.db	00134$>>8
      006D29 6D                    3748 	.db	00134$>>8
      006D2A 6D                    3749 	.db	00142$>>8
      006D2B 6D                    3750 	.db	00134$>>8
      006D2C 6D                    3751 	.db	00134$>>8
      006D2D 6D                    3752 	.db	00134$>>8
      006D2E 6D                    3753 	.db	00134$>>8
      006D2F 6D                    3754 	.db	00134$>>8
      006D30 6D                    3755 	.db	00134$>>8
      006D31 6D                    3756 	.db	00142$>>8
      006D32 6D                    3757 	.db	00142$>>8
      006D33 6D                    3758 	.db	00135$>>8
                                   3759 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006D34                       3760 00134$:
                                   3761 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006D34 75 82 01         [24] 3762 	mov	dpl, #0x01
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006D37 22               [24] 3764 	ret
      006D38                       3765 00135$:
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006D38 90 07 CC         [24] 3767 	mov	dptr,#(_raw_buffer + 0x0002)
      006D3B E0               [24] 3768 	movx	a,@dptr
      006D3C FF               [12] 3769 	mov	r7,a
      006D3D 60 0D            [24] 3770 	jz	00139$
      006D3F BF 01 02         [24] 3771 	cjne	r7,#0x01,00328$
      006D42 80 08            [24] 3772 	sjmp	00139$
      006D44                       3773 00328$:
      006D44 BF 03 02         [24] 3774 	cjne	r7,#0x03,00329$
      006D47 80 03            [24] 3775 	sjmp	00139$
      006D49                       3776 00329$:
      006D49 BF 05 04         [24] 3777 	cjne	r7,#0x05,00140$
                                   3778 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006D4C                       3779 00139$:
                                   3780 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006D4C 75 82 01         [24] 3781 	mov	dpl, #0x01
                                   3782 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006D4F 22               [24] 3783 	ret
      006D50                       3784 00140$:
      006D50 75 82 00         [24] 3785 	mov	dpl, #0x00
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006D53 22               [24] 3787 	ret
      006D54                       3788 00142$:
      006D54 75 82 00         [24] 3789 	mov	dpl, #0x00
                                   3790 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006D57 22               [24] 3791 	ret
      006D58                       3792 00144$:
      006D58 75 82 00         [24] 3793 	mov	dpl, #0x00
                                   3794 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006D5B 22               [24] 3796 	ret
                                   3797 ;------------------------------------------------------------
                                   3798 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3799 ;------------------------------------------------------------
                                   3800 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3801 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3802 ;------------------------------------------------------------
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3804 ;	-----------------------------------------
                                   3805 ;	 function ak820_usb_raw_send
                                   3806 ;	-----------------------------------------
      006D5C                       3807 _ak820_usb_raw_send:
      006D5C 12 46 60         [24] 3808 	lcall	_ak820_outline_0037
      006D5F 90 08 32         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006D62 12 38 29         [24] 3810 	lcall	_ak820_outline_0017
                                   3811 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006D65 90 08 31         [24] 3812 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D68 E0               [24] 3813 	movx	a,@dptr
      006D69 FF               [12] 3814 	mov	r7,a
      006D6A BF 20 2B         [24] 3815 	cjne	r7,#0x20,00106$
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006D6D C0 07            [24] 3817 	push	ar7
      006D6F 12 41 76         [24] 3818 	lcall	_ak820_nvm_flush
      006D72 D0 07            [24] 3819 	pop	ar7
                                   3820 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D74 90 07 EA         [24] 3821 	mov	dptr,#_raw_reply_without_nvm
      006D77 E0               [24] 3822 	movx	a,@dptr
      006D78 70 07            [24] 3823 	jnz	00103$
      006D7A 12 41 67         [24] 3824 	lcall	_ak820_nvm_ok
      006D7D E5 82            [12] 3825 	mov	a, dpl
      006D7F 60 17            [24] 3826 	jz	00106$
      006D81                       3827 00103$:
      006D81 90 08 32         [24] 3828 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006D84 12 38 64         [24] 3829 	lcall	_ak820_outline_0079
      006D87 90 08 27         [24] 3830 	mov	dptr,#_ak820_usb_send_PARM_2
      006D8A 12 46 CA         [24] 3831 	lcall	_ak820_outline_0161
      006D8D 90 08 29         [24] 3832 	mov	dptr,#_ak820_usb_send_PARM_3
      006D90 EF               [12] 3833 	mov	a,r7
      006D91 F0               [24] 3834 	movx	@dptr,a
      006D92 75 82 03         [24] 3835 	mov	dpl, #0x03
                                   3836 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006D95 02 6A 72         [24] 3837 	ljmp	_ak820_usb_send
      006D98                       3838 00106$:
      006D98 22               [24] 3839 	ret
                                   3840 ;------------------------------------------------------------
                                   3841 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3842 ;------------------------------------------------------------
                                   3843 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3844 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3845 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3846 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3847 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3848 ;------------------------------------------------------------
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3850 ;	-----------------------------------------
                                   3851 ;	 function ak820_usb_raw_task
                                   3852 ;	-----------------------------------------
      006D99                       3853 _ak820_usb_raw_task:
                                   3854 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006D99 A2 AF            [12] 3855 	mov	c,_EA
      006D9B E4               [12] 3856 	clr	a
      006D9C 33               [12] 3857 	rlc	a
      006D9D FF               [12] 3858 	mov	r7,a
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3860 ;	assignBit
      006D9E C2 AF            [12] 3861 	clr	_EA
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006DA0 90 07 C2         [24] 3863 	mov	dptr,#_USB_EnumStatus
      006DA3 E0               [24] 3864 	movx	a,@dptr
      006DA4 60 0A            [24] 3865 	jz	00101$
      006DA6 90 07 C9         [24] 3866 	mov	dptr,#_raw_state
      006DA9 E0               [24] 3867 	movx	a,@dptr
      006DAA FE               [12] 3868 	mov	r6,a
      006DAB BE 02 02         [24] 3869 	cjne	r6,#0x02,00270$
      006DAE 80 06            [24] 3870 	sjmp	00102$
      006DB0                       3871 00270$:
      006DB0                       3872 00101$:
                                   3873 ;	assignBit
      006DB0 EF               [12] 3874 	mov	a,r7
      006DB1 24 FF            [12] 3875 	add	a,#0xff
      006DB3 92 AF            [24] 3876 	mov	_EA,c
      006DB5 22               [24] 3877 	ret
      006DB6                       3878 00102$:
                                   3879 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006DB6 90 07 C9         [24] 3880 	mov	dptr,#_raw_state
      006DB9 74 03            [12] 3881 	mov	a,#0x03
      006DBB F0               [24] 3882 	movx	@dptr,a
                                   3883 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3884 ;	assignBit
      006DBC EF               [12] 3885 	mov	a,r7
      006DBD 24 FF            [12] 3886 	add	a,#0xff
      006DBF 92 AF            [24] 3887 	mov	_EA,c
                                   3888 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006DC1 90 07 CA         [24] 3889 	mov	dptr,#_raw_buffer
      006DC4 E0               [24] 3890 	movx	a,@dptr
      006DC5 FF               [12] 3891 	mov	r7,a
      006DC6 E4               [12] 3892 	clr	a
      006DC7 BF FD 01         [24] 3893 	cjne	r7,#0xfd,00271$
      006DCA 04               [12] 3894 	inc	a
      006DCB                       3895 00271$:
      006DCB FF               [12] 3896 	mov	r7,a
      006DCC 70 03            [24] 3897 	jnz	00273$
      006DCE 02 6E 6E         [24] 3898 	ljmp	00118$
      006DD1                       3899 00273$:
      006DD1 90 07 CB         [24] 3900 	mov	dptr,#(_raw_buffer + 0x0001)
      006DD4 E0               [24] 3901 	movx	a,@dptr
      006DD5 60 03            [24] 3902 	jz	00274$
      006DD7 02 6E 6E         [24] 3903 	ljmp	00118$
      006DDA                       3904 00274$:
                                   3905 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006DDA 90 07 CC         [24] 3906 	mov	dptr,#(_raw_buffer + 0x0002)
      006DDD E0               [24] 3907 	movx	a,@dptr
      006DDE FD               [12] 3908 	mov	r5,a
      006DDF 7E 00            [12] 3909 	mov	r6,#0x00
      006DE1 90 07 CD         [24] 3910 	mov	dptr,#(_raw_buffer + 0x0003)
      006DE4 E0               [24] 3911 	movx	a,@dptr
      006DE5 7B 00            [12] 3912 	mov	r3,#0x00
      006DE7 42 06            [12] 3913 	orl	ar6,a
      006DE9 EB               [12] 3914 	mov	a,r3
      006DEA 42 05            [12] 3915 	orl	ar5,a
                                   3916 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006DEC 90 07 CE         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0004)
      006DEF E0               [24] 3918 	movx	a,@dptr
      006DF0 FC               [12] 3919 	mov	r4,a
                                   3920 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006DF1 7B 05            [12] 3921 	mov	r3,#0x05
      006DF3                       3922 00128$:
      006DF3 EB               [12] 3923 	mov	a,r3
      006DF4 12 6F 9A         [24] 3924 	lcall	_ak820_outline_0105
      006DF7 0B               [12] 3925 	inc	r3
      006DF8 BB 20 00         [24] 3926 	cjne	r3,#0x20,00275$
      006DFB                       3927 00275$:
      006DFB 40 F6            [24] 3928 	jc	00128$
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006DFD EC               [12] 3930 	mov	a,r4
      006DFE 24 E4            [12] 3931 	add	a,#0xff - 0x1b
      006E00 40 1C            [24] 3932 	jc	00106$
                                   3933 ;	free result
      006E02 EC               [12] 3934 	mov	a,r4
      006E03 60 26            [24] 3935 	jz	00165$
      006E05 8C 03            [24] 3936 	mov	ar3,r4
      006E07 1B               [12] 3937 	dec	r3
      006E08 7A 00            [12] 3938 	mov	r2,#0x00
      006E0A 74 FF            [12] 3939 	mov	a,#0xff
      006E0C C3               [12] 3940 	clr	c
      006E0D 9B               [12] 3941 	subb	a,r3
      006E0E FB               [12] 3942 	mov	r3,a
      006E0F 74 FF            [12] 3943 	mov	a,#0xff
      006E11 9A               [12] 3944 	subb	a,r2
      006E12 FA               [12] 3945 	mov	r2,a
      006E13 8E 00            [24] 3946 	mov	ar0,r6
      006E15 8D 01            [24] 3947 	mov	ar1,r5
      006E17 C3               [12] 3948 	clr	c
      006E18 EB               [12] 3949 	mov	a,r3
      006E19 98               [12] 3950 	subb	a,r0
      006E1A EA               [12] 3951 	mov	a,r2
      006E1B 99               [12] 3952 	subb	a,r1
      006E1C 50 0D            [24] 3953 	jnc	00165$
                                   3954 ;	free result
      006E1E                       3955 00106$:
                                   3956 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006E1E 90 07 CB         [24] 3957 	mov	dptr,#(_raw_buffer + 0x0001)
      006E21 74 FF            [12] 3958 	mov	a,#0xff
      006E23 F0               [24] 3959 	movx	@dptr,a
                                   3960 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006E24 90 07 CE         [24] 3961 	mov	dptr,#(_raw_buffer + 0x0004)
      006E27 E4               [12] 3962 	clr	a
      006E28 F0               [24] 3963 	movx	@dptr,a
                                   3964 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006E29 80 3A            [24] 3965 	sjmp	00108$
      006E2B                       3966 00165$:
      006E2B 7B 00            [12] 3967 	mov	r3,#0x00
      006E2D                       3968 00131$:
      006E2D C3               [12] 3969 	clr	c
      006E2E EB               [12] 3970 	mov	a,r3
      006E2F 9C               [12] 3971 	subb	a,r4
      006E30 50 33            [24] 3972 	jnc	00108$
      006E32 C0 04            [24] 3973 	push	ar4
      006E34 8B 02            [24] 3974 	mov	ar2,r3
      006E36 74 05            [12] 3975 	mov	a,#0x05
      006E38 2A               [12] 3976 	add	a, r2
      006E39 F9               [12] 3977 	mov	r1,a
      006E3A 33               [12] 3978 	rlc	a
      006E3B 95 E0            [12] 3979 	subb	a,acc
      006E3D FA               [12] 3980 	mov	r2,a
      006E3E E9               [12] 3981 	mov	a,r1
      006E3F 24 CA            [12] 3982 	add	a, #_raw_buffer
      006E41 F9               [12] 3983 	mov	r1,a
      006E42 EA               [12] 3984 	mov	a,r2
      006E43 34 07            [12] 3985 	addc	a, #(_raw_buffer >> 8)
      006E45 FA               [12] 3986 	mov	r2,a
      006E46 8B 1E            [24] 3987 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006E48 75 1F 00         [24] 3988 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006E4B 8E 00            [24] 3989 	mov	ar0,r6
      006E4D 8D 04            [24] 3990 	mov	ar4,r5
      006E4F E5 1E            [12] 3991 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006E51 28               [12] 3992 	add	a, r0
      006E52 F8               [12] 3993 	mov	r0,a
      006E53 E5 1F            [12] 3994 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006E55 3C               [12] 3995 	addc	a, r4
      006E56 FC               [12] 3996 	mov	r4,a
      006E57 88 82            [24] 3997 	mov	dpl,r0
      006E59 8C 83            [24] 3998 	mov	dph,r4
      006E5B E4               [12] 3999 	clr	a
      006E5C 93               [24] 4000 	movc	a,@a+dptr
      006E5D 12 6F A6         [24] 4001 	lcall	_ak820_outline_0139
      006E60 0B               [12] 4002 	inc	r3
      006E61 D0 04            [24] 4003 	pop	ar4
      006E63 80 C8            [24] 4004 	sjmp	00131$
      006E65                       4005 00108$:
                                   4006 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E65 12 6F 86         [24] 4007 	lcall	_ak820_outline_0045
      006E68 12 6A 72         [24] 4008 	lcall	_ak820_usb_send
      006E6B 02 6F 14         [24] 4009 	ljmp	00119$
      006E6E                       4010 00118$:
                                   4011 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E6E EF               [12] 4012 	mov	a,r7
      006E6F 70 03            [24] 4013 	jnz	00281$
      006E71 02 6E F1         [24] 4014 	ljmp	00114$
      006E74                       4015 00281$:
      006E74 12 6F AC         [24] 4016 	lcall	_ak820_outline_0163
      006E77 BF 01 02         [24] 4017 	cjne	r7,#0x01,00282$
      006E7A 80 03            [24] 4018 	sjmp	00283$
      006E7C                       4019 00282$:
      006E7C 02 6E F1         [24] 4020 	ljmp	00114$
      006E7F                       4021 00283$:
                                   4022 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E7F 7F 02            [12] 4023 	mov	r7,#0x02
      006E81                       4024 00133$:
      006E81 EF               [12] 4025 	mov	a,r7
      006E82 12 6F 9A         [24] 4026 	lcall	_ak820_outline_0105
      006E85 0F               [12] 4027 	inc	r7
      006E86 BF 20 00         [24] 4028 	cjne	r7,#0x20,00284$
      006E89                       4029 00284$:
      006E89 40 F6            [24] 4030 	jc	00133$
                                   4031 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006E8B 90 07 CC         [24] 4032 	mov	dptr,#(_raw_buffer + 0x0002)
      006E8E 74 01            [12] 4033 	mov	a,#0x01
      006E90 F0               [24] 4034 	movx	@dptr,a
                                   4035 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006E91 90 07 CD         [24] 4036 	mov	dptr,#(_raw_buffer + 0x0003)
      006E94 74 A8            [12] 4037 	mov	a,#0xa8
      006E96 F0               [24] 4038 	movx	@dptr,a
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006E97 90 07 CE         [24] 4040 	mov	dptr,#(_raw_buffer + 0x0004)
      006E9A 12 3E E4         [24] 4041 	lcall	_ak820_nvm_diagnostic
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006E9D 7F 00            [12] 4043 	mov	r7,#0x00
      006E9F                       4044 00135$:
      006E9F 8F 06            [24] 4045 	mov	ar6,r7
      006EA1 74 0B            [12] 4046 	mov	a,#0x0b
      006EA3 2E               [12] 4047 	add	a, r6
      006EA4 24 CA            [12] 4048 	add	a,#_raw_buffer
      006EA6 FE               [12] 4049 	mov	r6,a
      006EA7 E4               [12] 4050 	clr	a
      006EA8 34 07            [12] 4051 	addc	a, #(_raw_buffer >> 8)
      006EAA FD               [12] 4052 	mov	r5,a
      006EAB EF               [12] 4053 	mov	a,r7
      006EAC 24 BA            [12] 4054 	add	a, #_ak820_flash_diagnostic
      006EAE F5 82            [12] 4055 	mov	dpl,a
      006EB0 E4               [12] 4056 	clr	a
      006EB1 34 04            [12] 4057 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006EB3 F5 83            [12] 4058 	mov	dph,a
      006EB5 E0               [24] 4059 	movx	a,@dptr
      006EB6 8E 82            [24] 4060 	mov	dpl,r6
      006EB8 8D 83            [24] 4061 	mov	dph,r5
      006EBA F0               [24] 4062 	movx	@dptr,a
      006EBB 0F               [12] 4063 	inc	r7
      006EBC BF 06 00         [24] 4064 	cjne	r7,#0x06,00286$
      006EBF                       4065 00286$:
      006EBF 40 DE            [24] 4066 	jc	00135$
                                   4067 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006EC1 90 0E 73         [24] 4068 	mov	dptr,#_vial_unlocked
      006EC4 E0               [24] 4069 	movx	a,@dptr
      006EC5 90 07 DB         [24] 4070 	mov	dptr,#(_raw_buffer + 0x0011)
      006EC8 F0               [24] 4071 	movx	@dptr,a
                                   4072 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006EC9 90 0E 74         [24] 4073 	mov	dptr,#_vial_unlock_in_progress
      006ECC E0               [24] 4074 	movx	a,@dptr
      006ECD 90 07 DC         [24] 4075 	mov	dptr,#(_raw_buffer + 0x0012)
      006ED0 F0               [24] 4076 	movx	@dptr,a
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006ED1 90 07 C2         [24] 4078 	mov	dptr,#_USB_EnumStatus
      006ED4 E0               [24] 4079 	movx	a,@dptr
      006ED5 90 07 DD         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0013)
      006ED8 F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006ED9 90 07 C3         [24] 4083 	mov	dptr,#_USB_SleepStatus
      006EDC E0               [24] 4084 	movx	a,@dptr
      006EDD 90 07 DE         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0014)
      006EE0 F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006EE1 90 07 C9         [24] 4088 	mov	dptr,#_raw_state
      006EE4 E0               [24] 4089 	movx	a,@dptr
      006EE5 90 07 DF         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0015)
      006EE8 F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006EE9 12 6F 86         [24] 4093 	lcall	_ak820_outline_0045
      006EEC 12 6A 72         [24] 4094 	lcall	_ak820_usb_send
      006EEF 80 23            [24] 4095 	sjmp	00119$
      006EF1                       4096 00114$:
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006EF1 12 6C 81         [24] 4098 	lcall	_raw_request_is_nonpersistent
      006EF4 E5 82            [12] 4099 	mov	a, dpl
      006EF6 90 07 EA         [24] 4100 	mov	dptr,#_raw_reply_without_nvm
      006EF9 F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006EFA 12 42 C9         [24] 4103 	lcall	_ak820_nvm_begin
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006EFD 90 0C A5         [24] 4105 	mov	dptr,#_raw_hid_receive_PARM_2
      006F00 74 20            [12] 4106 	mov	a,#0x20
      006F02 F0               [24] 4107 	movx	@dptr,a
      006F03 90 07 CA         [24] 4108 	mov	dptr,#_raw_buffer
      006F06 75 F0 00         [24] 4109 	mov	b, #0x00
      006F09 12 AA 84         [24] 4110 	lcall	_raw_hid_receive
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006F0C 12 42 DE         [24] 4112 	lcall	_ak820_nvm_end
                                   4113 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006F0F 90 07 EA         [24] 4114 	mov	dptr,#_raw_reply_without_nvm
      006F12 E4               [12] 4115 	clr	a
      006F13 F0               [24] 4116 	movx	@dptr,a
      006F14                       4117 00119$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4119 ;	assignBit
      006F14 A2 AF            [12] 4120 	mov	c,_EA
      006F16 92 1E            [24] 4121 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4123 ;	assignBit
      006F18 C2 AF            [12] 4124 	clr	_EA
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006F1A 12 6F B2         [24] 4126 	lcall	_ak820_outline_0165
      006F1D BF 04 08         [24] 4127 	cjne	r7,#0x04,00126$
      006F20 90 07 C9         [24] 4128 	mov	dptr,#_raw_state
      006F23 74 05            [12] 4129 	mov	a,#0x05
      006F25 F0               [24] 4130 	movx	@dptr,a
      006F26 80 1B            [24] 4131 	sjmp	00127$
      006F28                       4132 00126$:
                                   4133 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006F28 12 6F B2         [24] 4134 	lcall	_ak820_outline_0165
      006F2B BF 03 02         [24] 4135 	cjne	r7,#0x03,00290$
      006F2E 80 0E            [24] 4136 	sjmp	00121$
      006F30                       4137 00290$:
      006F30 12 6F B2         [24] 4138 	lcall	_ak820_outline_0165
      006F33 BF 06 02         [24] 4139 	cjne	r7,#0x06,00291$
      006F36 80 06            [24] 4140 	sjmp	00121$
      006F38                       4141 00291$:
      006F38 12 6F B2         [24] 4142 	lcall	_ak820_outline_0165
      006F3B BF 07 05         [24] 4143 	cjne	r7,#0x07,00127$
      006F3E                       4144 00121$:
      006F3E 90 07 C9         [24] 4145 	mov	dptr,#_raw_state
      006F41 E4               [12] 4146 	clr	a
      006F42 F0               [24] 4147 	movx	@dptr,a
      006F43                       4148 00127$:
                                   4149 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4150 ;	assignBit
      006F43 A2 1E            [12] 4151 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006F45 92 AF            [24] 4152 	mov	_EA,c
                                   4153 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006F47 22               [24] 4154 	ret
                                   4155 ;------------------------------------------------------------
                                   4156 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:665: bool ak820_usb_keyboard_blocked(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_keyboard_blocked
                                   4161 ;	-----------------------------------------
      006F48                       4162 _ak820_usb_keyboard_blocked:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:666: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      006F48 90 07 C2         [24] 4164 	mov	dptr,#_USB_EnumStatus
      006F4B E0               [24] 4165 	movx	a,@dptr
      006F4C 60 13            [24] 4166 	jz	00104$
      006F4E 90 07 C3         [24] 4167 	mov	dptr,#_USB_SleepStatus
      006F51 E0               [24] 4168 	movx	a,@dptr
      006F52 03               [12] 4169 	rr	a
      006F53 54 01            [12] 4170 	anl	a,#0x01
      006F55 70 0A            [24] 4171 	jnz	00104$
      006F57 90 07 EB         [24] 4172 	mov	dptr,#_keyboard_reset
      006F5A E0               [24] 4173 	movx	a,@dptr
      006F5B 70 04            [24] 4174 	jnz	00104$
                                   4175 ;	assignBit
      006F5D C2 1F            [12] 4176 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      006F5F 80 02            [24] 4177 	sjmp	00105$
      006F61                       4178 00104$:
                                   4179 ;	assignBit
      006F61 D2 1F            [12] 4180 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      006F63                       4181 00105$:
      006F63 A2 1F            [12] 4182 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      006F65 E4               [12] 4183 	clr	a
      006F66 33               [12] 4184 	rlc	a
      006F67 F5 82            [12] 4185 	mov	dpl, a
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:667: }
      006F69 22               [24] 4187 	ret
                                   4188 ;------------------------------------------------------------
                                   4189 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4190 ;------------------------------------------------------------
                                   4191 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_485'
                                   4192 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_485'
                                   4193 ;------------------------------------------------------------
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4195 ;	-----------------------------------------
                                   4196 ;	 function ak820_usb_take_keyboard_reset
                                   4197 ;	-----------------------------------------
      006F6A                       4198 _ak820_usb_take_keyboard_reset:
                                   4199 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4200 ;	assignBit
      006F6A A2 AF            [12] 4201 	mov	c,_EA
      006F6C 92 20            [24] 4202 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4203 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4204 ;	assignBit
      006F6E C2 AF            [12] 4205 	clr	_EA
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006F70 90 07 EB         [24] 4207 	mov	dptr,#_keyboard_reset
      006F73 E0               [24] 4208 	movx	a,@dptr
      006F74 FF               [12] 4209 	mov	r7,a
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006F75 E4               [12] 4211 	clr	a
      006F76 F0               [24] 4212 	movx	@dptr,a
                                   4213 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4214 ;	assignBit
      006F77 A2 20            [12] 4215 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006F79 92 AF            [24] 4216 	mov	_EA,c
                                   4217 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006F7B EF               [12] 4218 	mov	a,r7
      006F7C B4 01 00         [24] 4219 	cjne	a,#0x01,00103$
      006F7F                       4220 00103$:
      006F7F B3               [12] 4221 	cpl	c
      006F80 92 20            [24] 4222 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006F82 12 38 B6         [24] 4223 	lcall	_ak820_outline_0156
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006F85 22               [24] 4225 	ret
                                   4226 	.area CSEG    (CODE)
                                   4227 	.area CONST   (CODE)
                                   4228 	.area CONST   (CODE)
      00BD58                       4229 _shared_offsets:
      00BD58 00                    4230 	.db #0x00	; 0
      00BD59 00                    4231 	.db #0x00	; 0
      00BD5A 28                    4232 	.db #0x28	; 40
      00BD5B 28                    4233 	.db #0x28	; 40
      00BD5C 2B                    4234 	.db #0x2b	; 43
      00BD5D 00                    4235 	.db #0x00	; 0
      00BD5E 08                    4236 	.db #0x08	; 8
                                   4237 	.area CSEG    (CODE)
                                   4238 	.area CONST   (CODE)
      00BD5F                       4239 _shared_lengths:
      00BD5F 00                    4240 	.db #0x00	; 0
      00BD60 00                    4241 	.db #0x00	; 0
      00BD61 00                    4242 	.db #0x00	; 0
      00BD62 03                    4243 	.db #0x03	; 3
      00BD63 03                    4244 	.db #0x03	; 3
      00BD64 00                    4245 	.db #0x00	; 0
      00BD65 20                    4246 	.db #0x20	; 32
                                   4247 	.area CSEG    (CODE)
                                   4248 	.area CONST   (CODE)
      00BD66                       4249 _interface_descriptors:
      00BD66 01 C3                 4250 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BD68 01 C4                 4251 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BD6A B4 C3                 4252 	.byte _RawReport, (_RawReport >> 8)
      00BD6C 1A C4                 4253 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BD6E 46 C3                 4254 	.byte _SharedReport, (_SharedReport >> 8)
      00BD70 33 C4                 4255 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4256 	.area CSEG    (CODE)
                                   4257 	.area XINIT   (CODE)
                                   4258 	.area CABS    (ABS,CODE)
                                   4259 
                                   4260 ; Experimental exact instruction outlining.
                                   4261 	.globl _ak820_outline_0017
                                   4262 	.globl _ak820_outline_0037
                                   4263 	.globl _ak820_outline_0045
                                   4264 	.globl _ak820_outline_0079
                                   4265 	.globl _ak820_outline_0105
                                   4266 	.globl _ak820_outline_0139
                                   4267 	.globl _ak820_outline_0156
                                   4268 	.globl _ak820_outline_0161
                                   4269 	.globl _ak820_outline_0163
                                   4270 	.globl _ak820_outline_0165
                                   4271 
                                   4272 	.area CSEG (CODE)
                                   4273 ; function ak820_outline_0045
      006F86                       4274 _ak820_outline_0045:
      006F86 90 08 27         [24] 4275 	mov	dptr,#_ak820_usb_send_PARM_2
      006F89 74 CA            [12] 4276 	mov	a,#_raw_buffer
      006F8B F0               [24] 4277 	movx	@dptr,a
      006F8C 74 07            [12] 4278 	mov	a,#(_raw_buffer>>8)
      006F8E A3               [24] 4279 	inc	dptr
      006F8F F0               [24] 4280 	movx	@dptr,a
      006F90 90 08 29         [24] 4281 	mov	dptr,#_ak820_usb_send_PARM_3
      006F93 74 20            [12] 4282 	mov	a,#0x20
      006F95 F0               [24] 4283 	movx	@dptr,a
      006F96 75 82 03         [24] 4284 	mov	dpl,#0x03
      006F99 22               [24] 4285 	ret
                                   4286 
                                   4287 	.area CSEG (CODE)
                                   4288 ; function ak820_outline_0105
      006F9A                       4289 _ak820_outline_0105:
      006F9A 24 CA            [12] 4290 	add	a,#_raw_buffer
      006F9C F5 82            [12] 4291 	mov	dpl,a
      006F9E E4               [12] 4292 	clr	a
      006F9F 34 07            [12] 4293 	addc	a,#(_raw_buffer>>8)
      006FA1 F5 83            [12] 4294 	mov	dph,a
      006FA3 E4               [12] 4295 	clr	a
      006FA4 F0               [24] 4296 	movx	@dptr,a
      006FA5 22               [24] 4297 	ret
                                   4298 
                                   4299 	.area CSEG (CODE)
                                   4300 ; function ak820_outline_0139
      006FA6                       4301 _ak820_outline_0139:
      006FA6 89 82            [24] 4302 	mov	dpl,r1
      006FA8 8A 83            [24] 4303 	mov	dph,r2
      006FAA F0               [24] 4304 	movx	@dptr,a
      006FAB 22               [24] 4305 	ret
                                   4306 
                                   4307 	.area CSEG (CODE)
                                   4308 ; function ak820_outline_0163
      006FAC                       4309 _ak820_outline_0163:
      006FAC 90 07 CB         [24] 4310 	mov	dptr,#(_raw_buffer+0x0001)
      006FAF E0               [24] 4311 	movx	a,@dptr
      006FB0 FF               [12] 4312 	mov	r7,a
      006FB1 22               [24] 4313 	ret
                                   4314 
                                   4315 	.area CSEG (CODE)
                                   4316 ; function ak820_outline_0165
      006FB2                       4317 _ak820_outline_0165:
      006FB2 90 07 C9         [24] 4318 	mov	dptr,#_raw_state
      006FB5 E0               [24] 4319 	movx	a,@dptr
      006FB6 FF               [12] 4320 	mov	r7,a
      006FB7 22               [24] 4321 	ret
