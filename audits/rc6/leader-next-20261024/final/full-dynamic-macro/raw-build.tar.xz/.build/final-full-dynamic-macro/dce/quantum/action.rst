                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _get_repeat_key_count
                                     27 	.globl _repeat_key_cancel
                                     28 	.globl _clear_owned_usages
                                     29 	.globl _owned_usage_key
                                     30 	.globl _clear_owned_keys
                                     31 	.globl _del_owned_key
                                     32 	.globl _add_owned_key
                                     33 	.globl _clear_owned_mods
                                     34 	.globl _del_owned_weak_mods
                                     35 	.globl _add_owned_weak_mods
                                     36 	.globl _del_owned_mods
                                     37 	.globl _add_owned_mods
                                     38 	.globl _clear_weak_mods
                                     39 	.globl _clear_mods
                                     40 	.globl _send_keyboard_report
                                     41 	.globl _layer_hold_clear
                                     42 	.globl _layer_hold_off
                                     43 	.globl _layer_hold_on
                                     44 	.globl _ak820_resolve_key
                                     45 	.globl _layer_xor
                                     46 	.globl _layer_and
                                     47 	.globl _layer_or
                                     48 	.globl _layer_off
                                     49 	.globl _layer_on
                                     50 	.globl _layer_move
                                     51 	.globl _layer_clear
                                     52 	.globl _layer_state_set
                                     53 	.globl _default_layer_xor
                                     54 	.globl _default_layer_and
                                     55 	.globl _default_layer_or
                                     56 	.globl _default_layer_set
                                     57 	.globl _post_process_record_quantum
                                     58 	.globl _process_record_quantum
                                     59 	.globl _action_for_keycode
                                     60 	.globl _mDelaymS
                                     61 	.globl _host_consumer_send
                                     62 	.globl _host_system_send
                                     63 	.globl _host_keyboard_leds
                                     64 	.globl _led_set
                                     65 	.globl _clear_keys_from_report
                                     66 	.globl ___memcpy
                                     67 	.globl _ADC_START
                                     68 	.globl _S0_R_FIFO
                                     69 	.globl _S0_T_FIFO
                                     70 	.globl _S0_FREE
                                     71 	.globl _S0_IF_BYTE
                                     72 	.globl _S0_IF_FIRST
                                     73 	.globl _S0_IF_OV
                                     74 	.globl _S0_FST_ACT
                                     75 	.globl _CP_RL2
                                     76 	.globl _C_T2
                                     77 	.globl _TR2
                                     78 	.globl _EXEN2
                                     79 	.globl _TCLK
                                     80 	.globl _RCLK
                                     81 	.globl _EXF2
                                     82 	.globl _CAP1F
                                     83 	.globl _TF2
                                     84 	.globl _RI
                                     85 	.globl _TI
                                     86 	.globl _RB8
                                     87 	.globl _TB8
                                     88 	.globl _REN
                                     89 	.globl _SM2
                                     90 	.globl _SM1
                                     91 	.globl _SM0
                                     92 	.globl _IT0
                                     93 	.globl _IE0
                                     94 	.globl _IT1
                                     95 	.globl _IE1
                                     96 	.globl _TR0
                                     97 	.globl _TF0
                                     98 	.globl _TR1
                                     99 	.globl _TF1
                                    100 	.globl _P4_0
                                    101 	.globl _P4_1
                                    102 	.globl _P4_2
                                    103 	.globl _P4_3
                                    104 	.globl _P4_4
                                    105 	.globl _P4_5
                                    106 	.globl _P4_6
                                    107 	.globl _RXD
                                    108 	.globl _TXD
                                    109 	.globl _INT0
                                    110 	.globl _INT1
                                    111 	.globl _T0
                                    112 	.globl _T1
                                    113 	.globl _MOSI1
                                    114 	.globl _MISO1
                                    115 	.globl _SCK1
                                    116 	.globl _P3_0
                                    117 	.globl _P3_1
                                    118 	.globl _P3_2
                                    119 	.globl _P3_3
                                    120 	.globl _P3_4
                                    121 	.globl _P3_5
                                    122 	.globl _P3_6
                                    123 	.globl _P3_7
                                    124 	.globl _CAP1_
                                    125 	.globl _T2_
                                    126 	.globl _CAP2_
                                    127 	.globl _T2EX_
                                    128 	.globl _RXD1
                                    129 	.globl _TXD1
                                    130 	.globl _P2_0
                                    131 	.globl _P2_1
                                    132 	.globl _P2_2
                                    133 	.globl _P2_3
                                    134 	.globl _P2_4
                                    135 	.globl _P2_5
                                    136 	.globl _P2_6
                                    137 	.globl _P2_7
                                    138 	.globl _AIN0
                                    139 	.globl _AIN1
                                    140 	.globl _AIN2
                                    141 	.globl _AIN3
                                    142 	.globl _AIN4
                                    143 	.globl _AIN5
                                    144 	.globl _AIN6
                                    145 	.globl _AIN7
                                    146 	.globl _CAP1
                                    147 	.globl _T2
                                    148 	.globl _CAP2
                                    149 	.globl _T2EX
                                    150 	.globl _INT0_
                                    151 	.globl _SCS
                                    152 	.globl _MOSI
                                    153 	.globl _MISO
                                    154 	.globl _SCK
                                    155 	.globl _RXD1_
                                    156 	.globl _TXD1_
                                    157 	.globl _P1_0
                                    158 	.globl _P1_1
                                    159 	.globl _P1_2
                                    160 	.globl _P1_3
                                    161 	.globl _P1_4
                                    162 	.globl _P1_5
                                    163 	.globl _P1_6
                                    164 	.globl _P1_7
                                    165 	.globl _AIN8
                                    166 	.globl _AIN9
                                    167 	.globl _AIN10
                                    168 	.globl _AIN11
                                    169 	.globl _AIN12
                                    170 	.globl _AIN13
                                    171 	.globl _RXD_
                                    172 	.globl _TXD_
                                    173 	.globl _SCL0
                                    174 	.globl _SDA0
                                    175 	.globl _P0_0
                                    176 	.globl _P0_1
                                    177 	.globl _P0_2
                                    178 	.globl _P0_3
                                    179 	.globl _P0_4
                                    180 	.globl _P0_5
                                    181 	.globl _P0_6
                                    182 	.globl _P0_7
                                    183 	.globl _IE_SPI0
                                    184 	.globl _IE_USB
                                    185 	.globl _IE_ADC
                                    186 	.globl _IE_UART1
                                    187 	.globl _IE_PWM_I2C
                                    188 	.globl _IE_GPIO
                                    189 	.globl _IE_WDOG
                                    190 	.globl _PX0
                                    191 	.globl _PT0
                                    192 	.globl _PX1
                                    193 	.globl _PT1
                                    194 	.globl _PS
                                    195 	.globl _PT2
                                    196 	.globl _PL_FLAG
                                    197 	.globl _PH_FLAG
                                    198 	.globl _EX0
                                    199 	.globl _ET0
                                    200 	.globl _EX1
                                    201 	.globl _ET1
                                    202 	.globl _ES
                                    203 	.globl _ET2
                                    204 	.globl _E_DIS
                                    205 	.globl _EA
                                    206 	.globl _P
                                    207 	.globl _F1
                                    208 	.globl _OV
                                    209 	.globl _RS0
                                    210 	.globl _RS1
                                    211 	.globl _F0
                                    212 	.globl _AC
                                    213 	.globl _CY
                                    214 	.globl _I2CS_INT_ST
                                    215 	.globl _I2CX_INT
                                    216 	.globl _LED_STATUS
                                    217 	.globl _LED_DMA_H
                                    218 	.globl _LED_DMA_L
                                    219 	.globl _LED_DMA
                                    220 	.globl _LED_PWM_OE
                                    221 	.globl _LED_COMMON
                                    222 	.globl _ADC_CHAN
                                    223 	.globl _ADC_DAT_H
                                    224 	.globl _ADC_DAT_L
                                    225 	.globl _ADC_DAT
                                    226 	.globl _ADC_CTRL
                                    227 	.globl _SPI1_CK_SE
                                    228 	.globl _SPI1_CTRL
                                    229 	.globl _SPI1_DATA
                                    230 	.globl _SPI1_STAT
                                    231 	.globl _SIF1
                                    232 	.globl _SBAUD1
                                    233 	.globl _SBUF1
                                    234 	.globl _SCON1
                                    235 	.globl _SPI0_SETUP
                                    236 	.globl _SPI0_CK_SE
                                    237 	.globl _SPI0_CTRL
                                    238 	.globl _SPI0_DATA
                                    239 	.globl _SPI0_STAT
                                    240 	.globl _T2CAP1H
                                    241 	.globl _T2CAP1L
                                    242 	.globl _T2CAP1
                                    243 	.globl _TH2
                                    244 	.globl _TL2
                                    245 	.globl _T2COUNT
                                    246 	.globl _RCAP2H
                                    247 	.globl _RCAP2L
                                    248 	.globl _RCAP2
                                    249 	.globl _T2MOD
                                    250 	.globl _T2CON
                                    251 	.globl _SBUF
                                    252 	.globl _SCON
                                    253 	.globl _TH1
                                    254 	.globl _TH0
                                    255 	.globl _TL1
                                    256 	.globl _TL0
                                    257 	.globl _TMOD
                                    258 	.globl _TCON
                                    259 	.globl _XBUS_AUX
                                    260 	.globl _P7
                                    261 	.globl _P6_DIR
                                    262 	.globl _P6_OUT_PU
                                    263 	.globl _P6_IN
                                    264 	.globl _P5_DIR
                                    265 	.globl _P5_OUT_PU
                                    266 	.globl _P5_IN
                                    267 	.globl _P4_LED_KEY
                                    268 	.globl _P4_DIR_PU
                                    269 	.globl _P4_MOD_OC
                                    270 	.globl _P4
                                    271 	.globl _P3_DIR_PU
                                    272 	.globl _P3_MOD_OC
                                    273 	.globl _P3
                                    274 	.globl _P2_DIR_PU
                                    275 	.globl _P2_MOD_OC
                                    276 	.globl _P2
                                    277 	.globl _P1_DIR_PU
                                    278 	.globl _P1_MOD_OC
                                    279 	.globl _P1
                                    280 	.globl _P0_DIR_PU
                                    281 	.globl _P0_MOD_OC
                                    282 	.globl _P0
                                    283 	.globl _ROM_CTRL
                                    284 	.globl _ROM_DATA_HH
                                    285 	.globl _ROM_DATA_HL
                                    286 	.globl _ROM_DATA_HI
                                    287 	.globl _ROM_ADDR_H
                                    288 	.globl _ROM_ADDR_L
                                    289 	.globl _ROM_ADDR
                                    290 	.globl _GPIO_IE
                                    291 	.globl _IP_EX
                                    292 	.globl _IE_EX
                                    293 	.globl _IP
                                    294 	.globl _IE
                                    295 	.globl _WDOG_COUNT
                                    296 	.globl _RESET_KEEP
                                    297 	.globl _WAKE_CTRL
                                    298 	.globl _CLOCK_CFG
                                    299 	.globl _POWER_CFG
                                    300 	.globl _PCON
                                    301 	.globl _GLOBAL_CFG
                                    302 	.globl _SAFE_MOD
                                    303 	.globl _DPH
                                    304 	.globl _DPL
                                    305 	.globl _SP
                                    306 	.globl _A_INV
                                    307 	.globl _B
                                    308 	.globl _ACC
                                    309 	.globl _PSW
                                    310 	.globl _disable_action_cache
                                    311 	.globl _tap_code_delay_PARM_2
                                    312 	.globl _process_action_PARM_2
                                    313 	.globl _action_exec_PARM_1
                                    314 	.globl _tp_buttons
                                    315 	.globl _action_exec
                                    316 	.globl _ak820_action_exec
                                    317 	.globl _process_record
                                    318 	.globl _process_record_handler
                                    319 	.globl _process_action
                                    320 	.globl _register_code
                                    321 	.globl _unregister_code
                                    322 	.globl _tap_code_delay
                                    323 	.globl _tap_code
                                    324 	.globl _register_mods
                                    325 	.globl _unregister_mods
                                    326 	.globl _register_weak_mods
                                    327 	.globl _unregister_weak_mods
                                    328 	.globl _clear_keyboard
                                    329 	.globl _clear_keyboard_but_mods
                                    330 	.globl _clear_keyboard_but_mods_and_keys
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000027                        593 _process_record_sloc0_1_0:
      000027                        594 	.ds 1
      000028                        595 _process_action_sloc0_1_0:
      000028                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; overlayable items in internal ram
                                    599 ;--------------------------------------------------------
                                    600 ;--------------------------------------------------------
                                    601 ; indirectly addressable internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area ISEG    (DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; absolute internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area IABS    (ABS,DATA)
                                    608 	.area IABS    (ABS,DATA)
                                    609 ;--------------------------------------------------------
                                    610 ; bit data
                                    611 ;--------------------------------------------------------
                                    612 	.area BSEG    (BIT)
      000021                        613 _process_action_sloc1_1_0:
      000021                        614 	.ds 1
                                    615 ;--------------------------------------------------------
                                    616 ; paged external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area PSEG    (PAG,XDATA)
                                    619 ;--------------------------------------------------------
                                    620 ; uninitialized external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area XSEG    (XDATA)
      000864                        623 _tp_buttons::
      000864                        624 	.ds 2
      000866                        625 _action_exec_PARM_1:
      000866                        626 	.ds 6
      00086C                        627 _action_exec_record_10001_629:
      00086C                        628 	.ds 9
      000875                        629 _ak820_action_exec_event_10000_633:
      000875                        630 	.ds 2
      000877                        631 _ak820_action_exec_snapshot_10000_634:
      000877                        632 	.ds 6
      00087D                        633 _process_record_record_10000_637:
      00087D                        634 	.ds 3
      000880                        635 _process_record_handler_record_argument_10000_646:
      000880                        636 	.ds 3
      000883                        637 _process_record_handler_action_10000_647:
      000883                        638 	.ds 2
      000885                        639 _process_action_PARM_2:
      000885                        640 	.ds 2
      000887                        641 _process_action_record_argument_10000_658:
      000887                        642 	.ds 3
      00088A                        643 _process_action_on_40000_681:
      00088A                        644 	.ds 1
      00088B                        645 _register_code_code_10000_715:
      00088B                        646 	.ds 1
      00088C                        647 _unregister_code_code_10000_729:
      00088C                        648 	.ds 1
      00088D                        649 _tap_code_delay_PARM_2:
      00088D                        650 	.ds 2
      00088F                        651 _tap_code_delay_code_10000_742:
      00088F                        652 	.ds 1
      000890                        653 _tap_code_code_10000_749:
      000890                        654 	.ds 1
      000891                        655 _register_mods_mods_10000_751:
      000891                        656 	.ds 1
      000892                        657 _unregister_mods_mods_10000_755:
      000892                        658 	.ds 1
      000893                        659 _register_weak_mods_mods_10000_759:
      000893                        660 	.ds 1
      000894                        661 _unregister_weak_mods_mods_10000_763:
      000894                        662 	.ds 1
                                    663 ;--------------------------------------------------------
                                    664 ; absolute external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XABS    (ABS,XDATA)
                                    667 ;--------------------------------------------------------
                                    668 ; initialized external ram data
                                    669 ;--------------------------------------------------------
                                    670 	.area XISEG   (XDATA)
      000E13                        671 _disable_action_cache::
      000E13                        672 	.ds 1
                                    673 	.area HOME    (CODE)
                                    674 	.area GSINIT0 (CODE)
                                    675 	.area GSINIT1 (CODE)
                                    676 	.area GSINIT2 (CODE)
                                    677 	.area GSINIT3 (CODE)
                                    678 	.area GSINIT4 (CODE)
                                    679 	.area GSINIT5 (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area CSEG    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; global & static initialisations
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    701 ;------------------------------------------------------------
                                    702 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    703 ;------------------------------------------------------------
                                    704 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function action_exec
                                    715 ;	-----------------------------------------
      00737C                        716 _action_exec:
                                    717 ;	quantum/action.c:92: ak820_dynamic_macro_task(event.time);
      00737C 90 08 68         [24]  718 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00737F 12 37 F4         [24]  719 	lcall	_ak820_outline_0005
      007382 12 3B 26         [24]  720 	lcall	_ak820_dynamic_macro_task
                                    721 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      007385 90 08 68         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007388 12 37 F4         [24]  723 	lcall	_ak820_outline_0005
      00738B 12 36 04         [24]  724 	lcall	_ak820_combo_tick
                                    725 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      00738E 90 08 66         [24]  726 	mov	dptr,#_action_exec_PARM_1
      007391 12 47 A0         [24]  727 	lcall	_ak820_tapping_before
      007394 E5 82            [12]  728 	mov	a, dpl
      007396 70 01            [24]  729 	jnz	00102$
      007398 22               [24]  730 	ret
      007399                        731 00102$:
                                    732 ;	quantum/action.c:116: if (event.pressed) {
      007399 90 08 6B         [24]  733 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00739C E0               [24]  734 	movx	a,@dptr
      00739D 60 03            [24]  735 	jz	00104$
                                    736 ;	quantum/action.c:118: clear_weak_mods();
      00739F 12 84 BE         [24]  737 	lcall	_clear_weak_mods
      0073A2                        738 00104$:
                                    739 ;	quantum/action.c:130: record.event = event;
      0073A2 90 0D F3         [24]  740 	mov	dptr,#___memcpy_PARM_2
      0073A5 74 66            [12]  741 	mov	a,#_action_exec_PARM_1
      0073A7 F0               [24]  742 	movx	@dptr,a
      0073A8 74 08            [12]  743 	mov	a,#(_action_exec_PARM_1 >> 8)
      0073AA 12 38 70         [24]  744 	lcall	_ak820_outline_0094
      0073AD 12 7B 2A         [24]  745 	lcall	_ak820_outline_0070
      0073B0 90 08 6C         [24]  746 	mov	dptr,#_action_exec_record_10001_629
      0073B3 F5 F0            [12]  747 	mov	b,a
      0073B5 12 BB ED         [24]  748 	lcall	___memcpy
                                    749 ;	quantum/action.c:132: record.tap.count = 0;
      0073B8 90 08 72         [24]  750 	mov	dptr,#(_action_exec_record_10001_629 + 0x0006)
      0073BB E0               [24]  751 	movx	a,@dptr
      0073BC 54 0F            [12]  752 	anl	a,#0x0f
      0073BE F0               [24]  753 	movx	@dptr,a
                                    754 ;	quantum/action.c:137: record.keycode = 0;
      0073BF 90 08 73         [24]  755 	mov	dptr,#(_action_exec_record_10001_629 + 0x0007)
      0073C2 12 52 A0         [24]  756 	lcall	_ak820_outline_0181
                                    757 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0073C5 90 08 70         [24]  758 	mov	dptr,#(_action_exec_record_10001_629 + 0x0004)
      0073C8 E0               [24]  759 	movx	a,@dptr
      0073C9 60 0D            [24]  760 	jz	00107$
      0073CB 90 08 6C         [24]  761 	mov	dptr,#_action_exec_record_10001_629
      0073CE 75 F0 00         [24]  762 	mov	b, #0x00
      0073D1 12 A2 93         [24]  763 	lcall	_pre_process_record_quantum
      0073D4 E5 82            [12]  764 	mov	a, dpl
      0073D6 60 14            [24]  765 	jz	00110$
      0073D8                        766 00107$:
                                    767 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      0073D8 90 08 6C         [24]  768 	mov	dptr,#_action_exec_record_10001_629
      0073DB 12 48 87         [24]  769 	lcall	_ak820_tapping_process
      0073DE E5 82            [12]  770 	mov	a, dpl
      0073E0 70 01            [24]  771 	jnz	00106$
      0073E2 22               [24]  772 	ret
      0073E3                        773 00106$:
                                    774 ;	quantum/action.c:175: process_record(&record);
      0073E3 90 08 6C         [24]  775 	mov	dptr,#_action_exec_record_10001_629
      0073E6 75 F0 00         [24]  776 	mov	b, #0x00
                                    777 ;	quantum/action.c:190: }
      0073E9 02 74 29         [24]  778 	ljmp	_process_record
      0073EC                        779 00110$:
      0073EC 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'ak820_action_exec'
                                    783 ;------------------------------------------------------------
                                    784 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    785 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_action_exec
                                    790 ;	-----------------------------------------
      0073ED                        791 _ak820_action_exec:
      0073ED 12 38 82         [24]  792 	lcall	_ak820_outline_0108
      0073F0 90 08 75         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_633
      0073F3 12 38 87         [24]  794 	lcall	_ak820_outline_0109
                                    795 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      0073F6 90 08 75         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_633
      0073F9 12 38 64         [24]  797 	lcall	_ak820_outline_0079
      0073FC 7F 00            [12]  798 	mov	r7,#0x00
      0073FE 90 0D F3         [24]  799 	mov	dptr,#___memcpy_PARM_2
      007401 ED               [12]  800 	mov	a,r5
      007402 12 38 29         [24]  801 	lcall	_ak820_outline_0017
      007405 12 7B 2A         [24]  802 	lcall	_ak820_outline_0070
      007408 90 08 77         [24]  803 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      00740B F5 F0            [12]  804 	mov	b,a
      00740D 12 BB ED         [24]  805 	lcall	___memcpy
                                    806 ;	quantum/action.c:197: action_exec(snapshot);
      007410 90 0D F3         [24]  807 	mov	dptr,#___memcpy_PARM_2
      007413 74 77            [12]  808 	mov	a,#_ak820_action_exec_snapshot_10000_634
      007415 F0               [24]  809 	movx	@dptr,a
      007416 74 08            [12]  810 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      007418 12 38 70         [24]  811 	lcall	_ak820_outline_0094
      00741B 12 7B 2A         [24]  812 	lcall	_ak820_outline_0070
      00741E 90 08 66         [24]  813 	mov	dptr,#_action_exec_PARM_1
      007421 F5 F0            [12]  814 	mov	b,a
      007423 12 BB ED         [24]  815 	lcall	___memcpy
                                    816 ;	quantum/action.c:198: }
      007426 02 73 7C         [24]  817 	ljmp	_action_exec
                                    818 ;------------------------------------------------------------
                                    819 ;Allocation info for local variables in function 'process_record_nocache'
                                    820 ;------------------------------------------------------------
                                    821 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    822 ;------------------------------------------------------------
                                    823 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    824 ;	-----------------------------------------
                                    825 ;	 function process_record
                                    826 ;	-----------------------------------------
      007429                        827 _process_record:
      007429 12 46 60         [24]  828 	lcall	_ak820_outline_0037
      00742C 90 08 7D         [24]  829 	mov	dptr,#_process_record_record_10000_637
      00742F 12 38 29         [24]  830 	lcall	_ak820_outline_0017
                                    831 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      007432 90 08 7D         [24]  832 	mov	dptr,#_process_record_record_10000_637
      007435 12 52 4D         [24]  833 	lcall	_ak820_outline_0013
      007438 74 04            [12]  834 	mov	a,#0x04
      00743A 12 7A E6         [24]  835 	lcall	_ak820_outline_0006
      00743D 12 BC C6         [24]  836 	lcall	__gptrget
      007440 70 01            [24]  837 	jnz	00102$
                                    838 ;	quantum/action.c:338: return;
      007442 22               [24]  839 	ret
      007443                        840 00102$:
                                    841 ;	quantum/action.c:342: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      007443 74 01            [12]  842 	mov	a,#0x01
      007445 12 7A E6         [24]  843 	lcall	_ak820_outline_0006
      007448 12 BC C6         [24]  844 	lcall	__gptrget
      00744B FA               [12]  845 	mov	r2,a
      00744C BA 10 00         [24]  846 	cjne	r2,#0x10,00192$
      00744F                        847 00192$:
      00744F 50 4B            [24]  848 	jnc	00104$
      007451 8D 02            [24]  849 	mov	ar2,r5
      007453 8E 03            [24]  850 	mov	ar3,r6
      007455 8F 04            [24]  851 	mov	ar4,r7
      007457 12 38 AC         [24]  852 	lcall	_ak820_outline_0143
      00745A 8C F0            [24]  853 	mov	b,r4
      00745C 12 BC C6         [24]  854 	lcall	__gptrget
      00745F FA               [12]  855 	mov	r2,a
      007460 BA 08 00         [24]  856 	cjne	r2,#0x08,00194$
      007463                        857 00194$:
      007463 50 37            [24]  858 	jnc	00104$
      007465 90 09 D9         [24]  859 	mov	dptr,#_ak820_macro_primitive
      007468 E0               [24]  860 	movx	a,@dptr
      007469 70 31            [24]  861 	jnz	00104$
                                    862 ;	quantum/action.c:343: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      00746B 90 0C 4A         [24]  863 	mov	dptr,#_get_record_keycode_PARM_2
      00746E 74 01            [12]  864 	mov	a,#0x01
      007470 12 52 56         [24]  865 	lcall	_ak820_outline_0031
      007473 12 A2 55         [24]  866 	lcall	_get_record_keycode
      007476 12 46 A9         [24]  867 	lcall	_ak820_outline_0125
      007479 90 08 7D         [24]  868 	mov	dptr,#_process_record_record_10000_637
      00747C 12 7B 11         [24]  869 	lcall	_ak820_outline_0024
      00747F 74 05            [12]  870 	mov	a,#0x05
      007481 2B               [12]  871 	add	a, r3
      007482 FB               [12]  872 	mov	r3,a
      007483 E4               [12]  873 	clr	a
      007484 3C               [12]  874 	addc	a, r4
      007485 FC               [12]  875 	mov	r4,a
      007486 12 33 FC         [24]  876 	lcall	_ak820_outline_0121
      007489 8D F0            [24]  877 	mov	b,r5
      00748B 12 BC C6         [24]  878 	lcall	__gptrget
      00748E 90 04 AE         [24]  879 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      007491 12 46 8B         [24]  880 	lcall	_ak820_outline_0071
      007494 12 39 7D         [24]  881 	lcall	_ak820_dynamic_macro_process
      007497 E5 82            [12]  882 	mov	a, dpl
      007499 70 01            [24]  883 	jnz	00104$
      00749B 22               [24]  884 	ret
      00749C                        885 00104$:
                                    886 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00749C 90 08 7D         [24]  887 	mov	dptr,#_process_record_record_10000_637
      00749F 12 52 4D         [24]  888 	lcall	_ak820_outline_0013
      0074A2 8D 02            [24]  889 	mov	ar2,r5
      0074A4 8E 03            [24]  890 	mov	ar3,r6
      0074A6 8F 04            [24]  891 	mov	ar4,r7
      0074A8 90 0D F3         [24]  892 	mov	dptr,#___memcpy_PARM_2
      0074AB EA               [12]  893 	mov	a,r2
      0074AC 12 7B 75         [24]  894 	lcall	_ak820_outline_0186
      0074AF EC               [12]  895 	mov	a,r4
      0074B0 A3               [24]  896 	inc	dptr
      0074B1 F0               [24]  897 	movx	@dptr,a
      0074B2 90 0D F6         [24]  898 	mov	dptr,#___memcpy_PARM_3
      0074B5 12 52 92         [24]  899 	lcall	_ak820_outline_0111
      0074B8 90 06 7A         [24]  900 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074BB F5 F0            [12]  901 	mov	b,a
      0074BD C0 07            [24]  902 	push	ar7
      0074BF C0 06            [24]  903 	push	ar6
      0074C1 C0 05            [24]  904 	push	ar5
      0074C3 12 BB ED         [24]  905 	lcall	___memcpy
      0074C6 12 46 DA         [24]  906 	lcall	_ak820_tapping_source
      0074C9 AC 82            [24]  907 	mov	r4, dpl
      0074CB D0 05            [24]  908 	pop	ar5
      0074CD D0 06            [24]  909 	pop	ar6
      0074CF D0 07            [24]  910 	pop	ar7
                                    911 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0074D1 74 05            [12]  912 	mov	a,#0x05
      0074D3 12 7A F4         [24]  913 	lcall	_ak820_outline_0014
      0074D6 12 BC C6         [24]  914 	lcall	__gptrget
      0074D9 FB               [12]  915 	mov	r3,a
                                    916 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      0074DA 74 07            [12]  917 	mov	a,#0x07
      0074DC 2D               [12]  918 	add	a, r5
      0074DD F8               [12]  919 	mov	r0,a
      0074DE E4               [12]  920 	clr	a
      0074DF 3E               [12]  921 	addc	a, r6
      0074E0 F9               [12]  922 	mov	r1,a
      0074E1 8F 02            [24]  923 	mov	ar2,r7
      0074E3 90 0C 4A         [24]  924 	mov	dptr,#_get_record_keycode_PARM_2
      0074E6 74 01            [12]  925 	mov	a,#0x01
      0074E8 12 52 56         [24]  926 	lcall	_ak820_outline_0031
      0074EB C0 04            [24]  927 	push	ar4
      0074ED C0 03            [24]  928 	push	ar3
      0074EF C0 02            [24]  929 	push	ar2
      0074F1 C0 01            [24]  930 	push	ar1
      0074F3 C0 00            [24]  931 	push	ar0
      0074F5 12 A2 55         [24]  932 	lcall	_get_record_keycode
      0074F8 12 46 A9         [24]  933 	lcall	_ak820_outline_0125
      0074FB D0 00            [24]  934 	pop	ar0
      0074FD D0 01            [24]  935 	pop	ar1
      0074FF D0 02            [24]  936 	pop	ar2
      007501 D0 03            [24]  937 	pop	ar3
      007503 D0 04            [24]  938 	pop	ar4
      007505 12 38 B1         [24]  939 	lcall	_ak820_outline_0144
      007508 8A F0            [24]  940 	mov	b,r2
      00750A EE               [12]  941 	mov	a,r6
      00750B 12 BC 8B         [24]  942 	lcall	__gptrput
      00750E A3               [24]  943 	inc	dptr
      00750F EF               [12]  944 	mov	a,r7
      007510 12 BC 8B         [24]  945 	lcall	__gptrput
                                    946 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007513 90 08 7D         [24]  947 	mov	dptr,#_process_record_record_10000_637
      007516 12 52 4D         [24]  948 	lcall	_ak820_outline_0013
      007519 74 07            [12]  949 	mov	a,#0x07
      00751B 12 7B 3B         [24]  950 	lcall	_ak820_outline_0081
      00751E 12 BC C6         [24]  951 	lcall	__gptrget
      007521 F8               [12]  952 	mov	r0,a
      007522 A3               [24]  953 	inc	dptr
      007523 12 BC C6         [24]  954 	lcall	__gptrget
      007526 F9               [12]  955 	mov	r1,a
      007527 90 06 8A         [24]  956 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00752A EC               [12]  957 	mov	a,r4
      00752B F0               [24]  958 	movx	@dptr,a
      00752C 90 06 8B         [24]  959 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00752F EB               [12]  960 	mov	a,r3
      007530 F0               [24]  961 	movx	@dptr,a
      007531 12 38 B1         [24]  962 	lcall	_ak820_outline_0144
      007534 C0 07            [24]  963 	push	ar7
      007536 C0 06            [24]  964 	push	ar6
      007538 C0 05            [24]  965 	push	ar5
      00753A C0 04            [24]  966 	push	ar4
      00753C C0 03            [24]  967 	push	ar3
      00753E 12 4A 3B         [24]  968 	lcall	_ak820_oneshot_process
      007541 E5 82            [12]  969 	mov	a, dpl
      007543 D0 03            [24]  970 	pop	ar3
      007545 D0 04            [24]  971 	pop	ar4
      007547 D0 05            [24]  972 	pop	ar5
      007549 D0 06            [24]  973 	pop	ar6
      00754B D0 07            [24]  974 	pop	ar7
      00754D 70 01            [24]  975 	jnz	00109$
      00754F 22               [24]  976 	ret
      007550                        977 00109$:
                                    978 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      007550 12 70 DF         [24]  979 	lcall	_ak820_outline_0050
      007553 C0 04            [24]  980 	push	ar4
      007555 C0 03            [24]  981 	push	ar3
      007557 12 A3 1F         [24]  982 	lcall	_process_record_quantum
      00755A E5 82            [12]  983 	mov	a, dpl
      00755C D0 03            [24]  984 	pop	ar3
      00755E D0 04            [24]  985 	pop	ar4
      007560 70 0A            [24]  986 	jnz	00111$
                                    987 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007562 90 05 F2         [24]  988 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007565 EB               [12]  989 	mov	a,r3
      007566 F0               [24]  990 	movx	@dptr,a
      007567 8C 82            [24]  991 	mov	dpl, r4
                                    992 ;	quantum/action.c:360: return;
      007569 02 2E BB         [24]  993 	ljmp	_ak820_oneshot_post
      00756C                        994 00111$:
                                    995 ;	quantum/action.c:364: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      00756C 90 08 7D         [24]  996 	mov	dptr,#_process_record_record_10000_637
      00756F 12 52 4D         [24]  997 	lcall	_ak820_outline_0013
      007572 74 01            [12]  998 	mov	a,#0x01
      007574 12 7B 3B         [24]  999 	lcall	_ak820_outline_0081
      007577 12 BC C6         [24] 1000 	lcall	__gptrget
      00757A F8               [12] 1001 	mov	r0,a
      00757B B8 10 00         [24] 1002 	cjne	r0,#0x10,00200$
      00757E                       1003 00200$:
      00757E 50 21            [24] 1004 	jnc	00114$
      007580 12 70 DF         [24] 1005 	lcall	_ak820_outline_0050
      007583 12 BC C6         [24] 1006 	lcall	__gptrget
      007586 FD               [12] 1007 	mov	r5,a
      007587 BD 08 00         [24] 1008 	cjne	r5,#0x08,00202$
      00758A                       1009 00202$:
      00758A 50 15            [24] 1010 	jnc	00114$
      00758C C0 04            [24] 1011 	push	ar4
      00758E C0 03            [24] 1012 	push	ar3
      007590 12 A5 D0         [24] 1013 	lcall	_get_repeat_key_count
      007593 E5 82            [12] 1014 	mov	a, dpl
      007595 D0 03            [24] 1015 	pop	ar3
      007597 D0 04            [24] 1016 	pop	ar4
      007599 70 06            [24] 1017 	jnz	00114$
      00759B 90 09 D9         [24] 1018 	mov	dptr,#_ak820_macro_primitive
      00759E E0               [24] 1019 	movx	a,@dptr
      00759F 60 05            [24] 1020 	jz	00115$
      0075A1                       1021 00114$:
      0075A1 75 27 00         [24] 1022 	mov	_process_record_sloc0_1_0,#0x00
      0075A4 80 03            [24] 1023 	sjmp	00116$
      0075A6                       1024 00115$:
      0075A6 75 27 01         [24] 1025 	mov	_process_record_sloc0_1_0,#0x01
      0075A9                       1026 00116$:
      0075A9 90 04 AD         [24] 1027 	mov	dptr,#_ak820_dynamic_macro_source
      0075AC E5 27            [12] 1028 	mov	a,_process_record_sloc0_1_0
      0075AE F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	quantum/action.c:366: process_record_handler(record);
      0075AF 90 08 7D         [24] 1031 	mov	dptr,#_process_record_record_10000_637
      0075B2 12 52 27         [24] 1032 	lcall	_ak820_outline_0001
      0075B5 C0 04            [24] 1033 	push	ar4
      0075B7 C0 03            [24] 1034 	push	ar3
      0075B9 12 75 D8         [24] 1035 	lcall	_process_record_handler
                                   1036 ;	quantum/action.c:368: ak820_dynamic_macro_source = false;
      0075BC 90 04 AD         [24] 1037 	mov	dptr,#_ak820_dynamic_macro_source
      0075BF E4               [12] 1038 	clr	a
      0075C0 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	quantum/action.c:370: post_process_record_quantum(record);
      0075C1 90 08 7D         [24] 1041 	mov	dptr,#_process_record_record_10000_637
      0075C4 12 52 27         [24] 1042 	lcall	_ak820_outline_0001
      0075C7 12 A2 F4         [24] 1043 	lcall	_post_process_record_quantum
      0075CA D0 03            [24] 1044 	pop	ar3
      0075CC D0 04            [24] 1045 	pop	ar4
                                   1046 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0075CE 90 05 F2         [24] 1047 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0075D1 EB               [12] 1048 	mov	a,r3
      0075D2 F0               [24] 1049 	movx	@dptr,a
      0075D3 8C 82            [24] 1050 	mov	dpl, r4
                                   1051 ;	quantum/action.c:374: }
      0075D5 02 2E BB         [24] 1052 	ljmp	_ak820_oneshot_post
                                   1053 ;------------------------------------------------------------
                                   1054 ;Allocation info for local variables in function 'process_record_handler'
                                   1055 ;------------------------------------------------------------
                                   1056 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_646'
                                   1057 ;record        Allocated with name '_process_record_handler_record_10000_647'
                                   1058 ;action        Allocated with name '_process_record_handler_action_10000_647'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function process_record_handler
                                   1063 ;	-----------------------------------------
      0075D8                       1064 _process_record_handler:
      0075D8 12 46 60         [24] 1065 	lcall	_ak820_outline_0037
      0075DB 90 08 80         [24] 1066 	mov	dptr,#_process_record_handler_record_argument_10000_646
      0075DE 12 38 29         [24] 1067 	lcall	_ak820_outline_0017
                                   1068 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0075E1 90 08 80         [24] 1069 	mov	dptr,#_process_record_handler_record_argument_10000_646
      0075E4 12 37 FE         [24] 1070 	lcall	_ak820_outline_0008
                                   1071 ;	quantum/action.c:387: if (record->keycode) {
      0075E7 4C               [12] 1072 	orl	a,r4
      0075E8 60 19            [24] 1073 	jz	00102$
                                   1074 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      0075EA 12 38 97         [24] 1075 	lcall	_ak820_outline_0124
      0075ED C0 07            [24] 1076 	push	ar7
      0075EF C0 06            [24] 1077 	push	ar6
      0075F1 12 98 9A         [24] 1078 	lcall	_action_for_keycode
      0075F4 12 46 BA         [24] 1079 	lcall	_ak820_outline_0149
      0075F7 D0 06            [24] 1080 	pop	ar6
      0075F9 D0 07            [24] 1081 	pop	ar7
      0075FB 90 08 83         [24] 1082 	mov	dptr,#_process_record_handler_action_10000_647
      0075FE 12 38 5E         [24] 1083 	lcall	_ak820_outline_0072
      007601 80 2B            [24] 1084 	sjmp	00104$
      007603                       1085 00102$:
                                   1086 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007603 12 7B 02         [24] 1087 	lcall	_ak820_outline_0021
      007606 7A 00            [12] 1088 	mov	r2,#0x00
      007608 12 46 B4         [24] 1089 	lcall	_ak820_outline_0142
      00760B 12 46 4E         [24] 1090 	lcall	_ak820_outline_0012
      00760E E0               [24] 1091 	movx	a,@dptr
      00760F 90 09 BF         [24] 1092 	mov	dptr,#_ak820_resolve_key_PARM_2
      007612 F0               [24] 1093 	movx	@dptr,a
      007613 8D 82            [24] 1094 	mov	dpl, r5
      007615 8C 83            [24] 1095 	mov	dph, r4
      007617 C0 07            [24] 1096 	push	ar7
      007619 C0 06            [24] 1097 	push	ar6
      00761B 12 7E BB         [24] 1098 	lcall	_ak820_resolve_key
      00761E 12 98 9A         [24] 1099 	lcall	_action_for_keycode
      007621 12 46 BA         [24] 1100 	lcall	_ak820_outline_0149
      007624 D0 06            [24] 1101 	pop	ar6
      007626 D0 07            [24] 1102 	pop	ar7
      007628 90 08 83         [24] 1103 	mov	dptr,#_process_record_handler_action_10000_647
      00762B 12 38 5E         [24] 1104 	lcall	_ak820_outline_0072
                                   1105 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      00762E                       1106 00104$:
                                   1107 ;	quantum/action.c:411: process_action(record, action);
      00762E 7D 00            [12] 1108 	mov	r5,#0x00
      007630 90 0D F3         [24] 1109 	mov	dptr,#___memcpy_PARM_2
      007633 74 83            [12] 1110 	mov	a,#_process_record_handler_action_10000_647
      007635 F0               [24] 1111 	movx	@dptr,a
      007636 74 08            [12] 1112 	mov	a,#(_process_record_handler_action_10000_647 >> 8)
      007638 12 38 70         [24] 1113 	lcall	_ak820_outline_0094
      00763B 90 0D F6         [24] 1114 	mov	dptr,#___memcpy_PARM_3
      00763E 12 52 92         [24] 1115 	lcall	_ak820_outline_0111
      007641 90 08 85         [24] 1116 	mov	dptr,#_process_action_PARM_2
      007644 F5 F0            [12] 1117 	mov	b,a
      007646 C0 07            [24] 1118 	push	ar7
      007648 C0 06            [24] 1119 	push	ar6
      00764A C0 05            [24] 1120 	push	ar5
      00764C 12 BB ED         [24] 1121 	lcall	___memcpy
      00764F D0 05            [24] 1122 	pop	ar5
      007651 D0 06            [24] 1123 	pop	ar6
      007653 D0 07            [24] 1124 	pop	ar7
      007655 12 72 F4         [24] 1125 	lcall	_ak820_outline_0064
                                   1126 ;	quantum/action.c:412: }
      007658 02 76 5B         [24] 1127 	ljmp	_process_action
                                   1128 ;------------------------------------------------------------
                                   1129 ;Allocation info for local variables in function 'register_mouse'
                                   1130 ;------------------------------------------------------------
                                   1131 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1132 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_655'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function process_action
                                   1137 ;	-----------------------------------------
      00765B                       1138 _process_action:
      00765B 12 46 60         [24] 1139 	lcall	_ak820_outline_0037
      00765E 90 08 87         [24] 1140 	mov	dptr,#_process_action_record_argument_10000_658
      007661 12 38 29         [24] 1141 	lcall	_ak820_outline_0017
                                   1142 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007664 90 08 87         [24] 1143 	mov	dptr,#_process_action_record_argument_10000_658
      007667 12 37 F4         [24] 1144 	lcall	_ak820_outline_0005
                                   1145 ;	quantum/action.c:483: pressed = record->event.pressed;
      00766A A3               [24] 1146 	inc	dptr
      00766B A3               [24] 1147 	inc	dptr
      00766C A3               [24] 1148 	inc	dptr
      00766D A3               [24] 1149 	inc	dptr
      00766E A3               [24] 1150 	inc	dptr
      00766F E0               [24] 1151 	movx	a,@dptr
      007670 F5 28            [12] 1152 	mov	_process_action_sloc0_1_0,a
                                   1153 ;	quantum/action.c:507: switch (action.kind.id) {
      007672 90 08 86         [24] 1154 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007675 E0               [24] 1155 	movx	a,@dptr
      007676 C4               [12] 1156 	swap	a
      007677 54 0F            [12] 1157 	anl	a,#0x0f
      007679 FD               [12] 1158 	mov  r5,a
      00767A 24 F4            [12] 1159 	add	a,#0xff - 0x0b
      00767C 50 03            [24] 1160 	jnc	00434$
      00767E 02 78 FC         [24] 1161 	ljmp	00181$
      007681                       1162 00434$:
                                   1163 ;	free result
      007681 ED               [12] 1164 	mov	a,r5
      007682 24 0A            [12] 1165 	add	a,#(00435$-3-.)
      007684 83               [24] 1166 	movc	a,@a+pc
      007685 F5 82            [12] 1167 	mov	dpl,a
      007687 ED               [12] 1168 	mov	a,r5
      007688 24 10            [12] 1169 	add	a,#(00436$-3-.)
      00768A 83               [24] 1170 	movc	a,@a+pc
      00768B F5 83            [12] 1171 	mov	dph,a
      00768D E4               [12] 1172 	clr	a
      00768E 73               [24] 1173 	jmp	@a+dptr
      00768F                       1174 00435$:
      00768F A7                    1175 	.db	00102$
      007690 A7                    1176 	.db	00102$
      007691 FC                    1177 	.db	00181$
      007692 FC                    1178 	.db	00181$
      007693 31                    1179 	.db	00123$
      007694 FC                    1180 	.db	00181$
      007695 FC                    1181 	.db	00181$
      007696 FC                    1182 	.db	00181$
      007697 91                    1183 	.db	00131$
      007698 63                    1184 	.db	00147$
      007699 89                    1185 	.db	00152$
      00769A 89                    1186 	.db	00152$
      00769B                       1187 00436$:
      00769B 76                    1188 	.db	00102$>>8
      00769C 76                    1189 	.db	00102$>>8
      00769D 78                    1190 	.db	00181$>>8
      00769E 78                    1191 	.db	00181$>>8
      00769F 77                    1192 	.db	00123$>>8
      0076A0 78                    1193 	.db	00181$>>8
      0076A1 78                    1194 	.db	00181$>>8
      0076A2 78                    1195 	.db	00181$>>8
      0076A3 77                    1196 	.db	00131$>>8
      0076A4 78                    1197 	.db	00147$>>8
      0076A5 78                    1198 	.db	00152$>>8
      0076A6 78                    1199 	.db	00152$>>8
                                   1200 ;	quantum/action.c:510: case ACT_RMODS: {
      0076A7                       1201 00102$:
                                   1202 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076A7 90 08 86         [24] 1203 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076AA E0               [24] 1204 	movx	a,@dptr
      0076AB 54 F0            [12] 1205 	anl	a,#0xf0
      0076AD 70 06            [24] 1206 	jnz	00194$
      0076AF 12 7B 52         [24] 1207 	lcall	_ak820_outline_0113
      0076B2 FD               [12] 1208 	mov	r5,a
      0076B3 80 07            [24] 1209 	sjmp	00195$
      0076B5                       1210 00194$:
      0076B5 12 7B 52         [24] 1211 	lcall	_ak820_outline_0113
      0076B8 C4               [12] 1212 	swap	a
      0076B9 54 F0            [12] 1213 	anl	a,#0xf0
      0076BB FD               [12] 1214 	mov	r5,a
      0076BC                       1215 00195$:
                                   1216 ;	quantum/action.c:513: if (pressed) {
      0076BC E5 28            [12] 1217 	mov	a,_process_action_sloc0_1_0
      0076BE 60 35            [24] 1218 	jz	00119$
                                   1219 ;	quantum/action.c:514: if (mods) {
      0076C0 ED               [12] 1220 	mov	a,r5
      0076C1 60 29            [24] 1221 	jz	00110$
                                   1222 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076C3 12 7B 64         [24] 1223 	lcall	_ak820_outline_0158
      0076C6 FC               [12] 1224 	mov	r4,a
      0076C7 BC E0 00         [24] 1225 	cjne	r4,#0xe0,00440$
      0076CA                       1226 00440$:
      0076CA 40 07            [24] 1227 	jc	00108$
      0076CC 12 7B 64         [24] 1228 	lcall	_ak820_outline_0158
      0076CF 24 18            [12] 1229 	add	a,#0xff - 0xe7
      0076D1 50 0A            [24] 1230 	jnc	00104$
                                   1231 ;	free result
      0076D3                       1232 00108$:
      0076D3 7B 85            [12] 1233 	mov	r3,#_process_action_PARM_2
      0076D5 7C 08            [12] 1234 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076D7 12 33 FC         [24] 1235 	lcall	_ak820_outline_0121
      0076DA E0               [24] 1236 	movx	a,@dptr
      0076DB 70 07            [24] 1237 	jnz	00105$
      0076DD                       1238 00104$:
                                   1239 ;	quantum/action.c:519: add_owned_mods(mods);
      0076DD 8D 82            [24] 1240 	mov	dpl, r5
      0076DF 12 80 D5         [24] 1241 	lcall	_add_owned_mods
      0076E2 80 05            [24] 1242 	sjmp	00106$
      0076E4                       1243 00105$:
                                   1244 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0076E4 8D 82            [24] 1245 	mov	dpl, r5
      0076E6 12 80 F3         [24] 1246 	lcall	_add_owned_weak_mods
      0076E9                       1247 00106$:
                                   1248 ;	quantum/action.c:523: send_keyboard_report();
      0076E9 12 84 0E         [24] 1249 	lcall	_send_keyboard_report
      0076EC                       1250 00110$:
                                   1251 ;	quantum/action.c:525: register_code(action.key.code);
      0076EC 12 7B 34         [24] 1252 	lcall	_ak820_outline_0078
      0076EF 12 79 13         [24] 1253 	lcall	_register_code
      0076F2 02 78 FC         [24] 1254 	ljmp	00181$
      0076F5                       1255 00119$:
                                   1256 ;	quantum/action.c:527: unregister_code(action.key.code);
      0076F5 12 7B 34         [24] 1257 	lcall	_ak820_outline_0078
      0076F8 C0 05            [24] 1258 	push	ar5
      0076FA 12 79 8F         [24] 1259 	lcall	_unregister_code
      0076FD D0 05            [24] 1260 	pop	ar5
                                   1261 ;	quantum/action.c:528: if (mods) {
      0076FF ED               [12] 1262 	mov	a,r5
      007700 70 03            [24] 1263 	jnz	00444$
      007702 02 78 FC         [24] 1264 	ljmp	00181$
      007705                       1265 00444$:
                                   1266 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007705 12 7B 64         [24] 1267 	lcall	_ak820_outline_0158
      007708 FC               [12] 1268 	mov	r4,a
      007709 BC E0 00         [24] 1269 	cjne	r4,#0xe0,00445$
      00770C                       1270 00445$:
      00770C 40 07            [24] 1271 	jc	00115$
      00770E 12 7B 64         [24] 1272 	lcall	_ak820_outline_0158
      007711 24 18            [12] 1273 	add	a,#0xff - 0xe7
      007713 50 0A            [24] 1274 	jnc	00111$
                                   1275 ;	free result
      007715                       1276 00115$:
      007715 7B 85            [12] 1277 	mov	r3,#_process_action_PARM_2
      007717 7C 08            [12] 1278 	mov	r4,#(_process_action_PARM_2 >> 8)
      007719 12 33 FC         [24] 1279 	lcall	_ak820_outline_0121
      00771C E0               [24] 1280 	movx	a,@dptr
      00771D 70 07            [24] 1281 	jnz	00112$
      00771F                       1282 00111$:
                                   1283 ;	quantum/action.c:530: del_owned_mods(mods);
      00771F 8D 82            [24] 1284 	mov	dpl, r5
      007721 12 80 E5         [24] 1285 	lcall	_del_owned_mods
      007724 80 05            [24] 1286 	sjmp	00113$
      007726                       1287 00112$:
                                   1288 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      007726 8D 82            [24] 1289 	mov	dpl, r5
      007728 12 81 03         [24] 1290 	lcall	_del_owned_weak_mods
      00772B                       1291 00113$:
                                   1292 ;	quantum/action.c:534: send_keyboard_report();
      00772B 12 84 0E         [24] 1293 	lcall	_send_keyboard_report
                                   1294 ;	quantum/action.c:537: } break;
      00772E 02 78 FC         [24] 1295 	ljmp	00181$
                                   1296 ;	quantum/action.c:614: case ACT_USAGE:
      007731                       1297 00123$:
                                   1298 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007731 74 07            [12] 1299 	mov	a,#0x07
      007733 12 38 31         [24] 1300 	lcall	_ak820_outline_0022
      007736 12 4B 75         [24] 1301 	lcall	_ak820_outline_0009
      007739 C3               [12] 1302 	clr	c
      00773A EC               [12] 1303 	mov	a,r4
      00773B 94 A5            [12] 1304 	subb	a,#0xa5
      00773D ED               [12] 1305 	mov	a,r5
      00773E 94 00            [12] 1306 	subb	a,#0x00
      007740 40 15            [24] 1307 	jc	00125$
      007742 74 C2            [12] 1308 	mov	a,#0xc2
      007744 9C               [12] 1309 	subb	a,r4
      007745 E4               [12] 1310 	clr	a
      007746 9D               [12] 1311 	subb	a,r5
      007747 40 0E            [24] 1312 	jc	00125$
                                   1313 ;	free result
                                   1314 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007749 90 0A E6         [24] 1315 	mov	dptr,#_owned_usage_key_PARM_2
      00774C E5 28            [12] 1316 	mov	a,_process_action_sloc0_1_0
      00774E F0               [24] 1317 	movx	@dptr,a
      00774F 8E 82            [24] 1318 	mov	dpl, r6
      007751 12 82 B9         [24] 1319 	lcall	_owned_usage_key
                                   1320 ;	quantum/action.c:622: break;
      007754 02 78 FC         [24] 1321 	ljmp	00181$
      007757                       1322 00125$:
                                   1323 ;	quantum/action.c:625: switch (action.usage.page) {
      007757 12 7B 49         [24] 1324 	lcall	_ak820_outline_0090
      00775A FF               [12] 1325 	mov	r7,a
      00775B 60 08            [24] 1326 	jz	00127$
      00775D BF 01 02         [24] 1327 	cjne	r7,#0x01,00452$
      007760 80 19            [24] 1328 	sjmp	00128$
      007762                       1329 00452$:
      007762 02 78 FC         [24] 1330 	ljmp	00181$
                                   1331 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007765                       1332 00127$:
                                   1333 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007765 E5 28            [12] 1334 	mov	a,_process_action_sloc0_1_0
      007767 60 05            [24] 1335 	jz	00196$
      007769 12 7B 59         [24] 1336 	lcall	_ak820_outline_0131
      00776C 80 04            [24] 1337 	sjmp	00197$
      00776E                       1338 00196$:
      00776E 7E 00            [12] 1339 	mov	r6,#0x00
      007770 7F 00            [12] 1340 	mov	r7,#0x00
      007772                       1341 00197$:
      007772 12 38 8C         [24] 1342 	lcall	_ak820_outline_0118
      007775 12 70 69         [24] 1343 	lcall	_host_system_send
                                   1344 ;	quantum/action.c:628: break;
      007778 02 78 FC         [24] 1345 	ljmp	00181$
                                   1346 ;	quantum/action.c:629: case PAGE_CONSUMER:
      00777B                       1347 00128$:
                                   1348 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      00777B E5 28            [12] 1349 	mov	a,_process_action_sloc0_1_0
      00777D 60 05            [24] 1350 	jz	00198$
      00777F 12 7B 59         [24] 1351 	lcall	_ak820_outline_0131
      007782 80 04            [24] 1352 	sjmp	00199$
      007784                       1353 00198$:
      007784 7E 00            [12] 1354 	mov	r6,#0x00
      007786 7F 00            [12] 1355 	mov	r7,#0x00
      007788                       1356 00199$:
      007788 12 38 8C         [24] 1357 	lcall	_ak820_outline_0118
      00778B 12 70 99         [24] 1358 	lcall	_host_consumer_send
                                   1359 ;	quantum/action.c:633: break;
      00778E 02 78 FC         [24] 1360 	ljmp	00181$
                                   1361 ;	quantum/action.c:640: case ACT_LAYER: {
      007791                       1362 00131$:
                                   1363 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      007791 90 08 86         [24] 1364 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007794 E0               [24] 1365 	movx	a,@dptr
      007795 54 03            [12] 1366 	anl	a,#0x03
      007797 90 08 8A         [24] 1367 	mov	dptr,#_process_action_on_40000_681
      00779A F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00779B E0               [24] 1370 	movx	a,@dptr
      00779C FF               [12] 1371 	mov	r7,a
      00779D 60 11            [24] 1372 	jz	00200$
      00779F E5 28            [12] 1373 	mov	a,_process_action_sloc0_1_0
      0077A1 60 07            [24] 1374 	jz	00202$
      0077A3 8F 06            [24] 1375 	mov	ar6,r7
      0077A5 53 06 01         [24] 1376 	anl	ar6,#0x01
      0077A8 80 10            [24] 1377 	sjmp	00201$
      0077AA                       1378 00202$:
      0077AA 74 02            [12] 1379 	mov	a,#0x02
      0077AC 5F               [12] 1380 	anl	a,r7
      0077AD FE               [12] 1381 	mov	r6,a
      0077AE 80 0A            [24] 1382 	sjmp	00201$
      0077B0                       1383 00200$:
      0077B0 E5 28            [12] 1384 	mov	a,_process_action_sloc0_1_0
      0077B2 B4 01 00         [24] 1385 	cjne	a,#0x01,00457$
      0077B5                       1386 00457$:
      0077B5 92 21            [24] 1387 	mov  _process_action_sloc1_1_0,c
      0077B7 E4               [12] 1388 	clr	a
      0077B8 33               [12] 1389 	rlc	a
      0077B9 FE               [12] 1390 	mov	r6,a
      0077BA                       1391 00201$:
      0077BA EE               [12] 1392 	mov	a,r6
      0077BB 70 03            [24] 1393 	jnz	00458$
      0077BD 02 78 FC         [24] 1394 	ljmp	00181$
      0077C0                       1395 00458$:
                                   1396 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0077C0 12 7B 64         [24] 1397 	lcall	_ak820_outline_0158
      0077C3 C4               [12] 1398 	swap	a
      0077C4 03               [12] 1399 	rr	a
      0077C5 54 07            [12] 1400 	anl	a,#0x07
      0077C7 25 E0            [12] 1401 	add	a,acc
      0077C9 25 E0            [12] 1402 	add	a,acc
      0077CB FF               [12] 1403 	mov	r7,a
                                   1404 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0077CC 12 7B 64         [24] 1405 	lcall	_ak820_outline_0158
      0077CF 54 0F            [12] 1406 	anl	a,#0x0f
      0077D1 FE               [12] 1407 	mov	r6,a
      0077D2 8F F0            [24] 1408 	mov	b,r7
      0077D4 05 F0            [12] 1409 	inc	b
      0077D6 EE               [12] 1410 	mov	a,r6
      0077D7 80 02            [24] 1411 	sjmp	00460$
      0077D9                       1412 00459$:
      0077D9 25 E0            [12] 1413 	add	a,acc
      0077DB                       1414 00460$:
      0077DB D5 F0 FB         [24] 1415 	djnz	b,00459$
      0077DE FE               [12] 1416 	mov	r6,a
                                   1417 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0077DF 12 7B 64         [24] 1418 	lcall	_ak820_outline_0158
      0077E2 30 E4 11         [24] 1419 	jnb	acc.4,00204$
      0077E5 8F F0            [24] 1420 	mov	b,r7
      0077E7 05 F0            [12] 1421 	inc	b
      0077E9 74 0F            [12] 1422 	mov	a,#0x0f
      0077EB 80 02            [24] 1423 	sjmp	00463$
      0077ED                       1424 00462$:
      0077ED 25 E0            [12] 1425 	add	a,acc
      0077EF                       1426 00463$:
      0077EF D5 F0 FB         [24] 1427 	djnz	b,00462$
      0077F2 F4               [12] 1428 	cpl	a
      0077F3 FF               [12] 1429 	mov	r7,a
      0077F4 80 02            [24] 1430 	sjmp	00205$
      0077F6                       1431 00204$:
      0077F6 7F 00            [12] 1432 	mov	r7,#0x00
      0077F8                       1433 00205$:
                                   1434 ;	quantum/action.c:648: bits |= mask;
      0077F8 EE               [12] 1435 	mov	a,r6
      0077F9 42 07            [12] 1436 	orl	ar7,a
                                   1437 ;	quantum/action.c:649: if (!on) {
      0077FB 90 08 8A         [24] 1438 	mov	dptr,#_process_action_on_40000_681
      0077FE E0               [24] 1439 	movx	a,@dptr
      0077FF 70 31            [24] 1440 	jnz	00143$
                                   1441 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      007801 12 7B 49         [24] 1442 	lcall	_ak820_outline_0090
      007804 FE               [12] 1443 	mov	r6,a
      007805 2E               [12] 1444 	add	a,r6
                                   1445 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      007806 90 78 0A         [24] 1446 	mov	dptr,#00465$
      007809 73               [24] 1447 	jmp	@a+dptr
      00780A                       1448 00465$:
      00780A 80 06            [24] 1449 	sjmp	00132$
      00780C 80 0C            [24] 1450 	sjmp	00133$
      00780E 80 12            [24] 1451 	sjmp	00134$
      007810 80 18            [24] 1452 	sjmp	00135$
      007812                       1453 00132$:
      007812 8F 82            [24] 1454 	mov	dpl, r7
      007814 12 7B C9         [24] 1455 	lcall	_default_layer_and
      007817 02 78 FC         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      00781A                       1458 00133$:
      00781A 8F 82            [24] 1459 	mov	dpl, r7
      00781C 12 7B B8         [24] 1460 	lcall	_default_layer_or
      00781F 02 78 FC         [24] 1461 	ljmp	00181$
                                   1462 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      007822                       1463 00134$:
      007822 8F 82            [24] 1464 	mov	dpl, r7
      007824 12 7B DF         [24] 1465 	lcall	_default_layer_xor
      007827 02 78 FC         [24] 1466 	ljmp	00181$
                                   1467 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      00782A                       1468 00135$:
      00782A 8F 82            [24] 1469 	mov	dpl, r7
      00782C 12 7B AD         [24] 1470 	lcall	_default_layer_set
                                   1471 ;	quantum/action.c:655: }
      00782F 02 78 FC         [24] 1472 	ljmp	00181$
      007832                       1473 00143$:
                                   1474 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007832 12 7B 49         [24] 1475 	lcall	_ak820_outline_0090
      007835 FE               [12] 1476 	mov	r6,a
      007836 2E               [12] 1477 	add	a,r6
                                   1478 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      007837 90 78 3B         [24] 1479 	mov	dptr,#00466$
      00783A 73               [24] 1480 	jmp	@a+dptr
      00783B                       1481 00466$:
      00783B 80 06            [24] 1482 	sjmp	00137$
      00783D 80 0C            [24] 1483 	sjmp	00138$
      00783F 80 12            [24] 1484 	sjmp	00139$
      007841 80 18            [24] 1485 	sjmp	00140$
      007843                       1486 00137$:
      007843 8F 82            [24] 1487 	mov	dpl, r7
      007845 12 7D 63         [24] 1488 	lcall	_layer_and
      007848 02 78 FC         [24] 1489 	ljmp	00181$
                                   1490 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      00784B                       1491 00138$:
      00784B 8F 82            [24] 1492 	mov	dpl, r7
      00784D 12 7D 52         [24] 1493 	lcall	_layer_or
      007850 02 78 FC         [24] 1494 	ljmp	00181$
                                   1495 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007853                       1496 00139$:
      007853 8F 82            [24] 1497 	mov	dpl, r7
      007855 12 7D 79         [24] 1498 	lcall	_layer_xor
      007858 02 78 FC         [24] 1499 	ljmp	00181$
                                   1500 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      00785B                       1501 00140$:
      00785B 8F 82            [24] 1502 	mov	dpl, r7
      00785D 12 7C EF         [24] 1503 	lcall	_layer_state_set
                                   1504 ;	quantum/action.c:665: break;
      007860 02 78 FC         [24] 1505 	ljmp	00181$
                                   1506 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007863                       1507 00147$:
                                   1508 ;	quantum/action.c:668: if (pressed) {
      007863 E5 28            [12] 1509 	mov	a,_process_action_sloc0_1_0
      007865 60 11            [24] 1510 	jz	00149$
                                   1511 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007867 12 7B 52         [24] 1512 	lcall	_ak820_outline_0113
      00786A F5 82            [12] 1513 	mov	dpl,a
      00786C 12 7C 4F         [24] 1514 	lcall	_layer_hold_on
                                   1515 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      00786F 12 7B 34         [24] 1516 	lcall	_ak820_outline_0078
      007872 12 7A 51         [24] 1517 	lcall	_register_mods
      007875 02 78 FC         [24] 1518 	ljmp	00181$
      007878                       1519 00149$:
                                   1520 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007878 12 7B 34         [24] 1521 	lcall	_ak820_outline_0078
      00787B 12 7A 65         [24] 1522 	lcall	_unregister_mods
                                   1523 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      00787E 12 7B 52         [24] 1524 	lcall	_ak820_outline_0113
      007881 F5 82            [12] 1525 	mov	dpl,a
      007883 12 7C 87         [24] 1526 	lcall	_layer_hold_off
                                   1527 ;	quantum/action.c:675: break;
      007886 02 78 FC         [24] 1528 	ljmp	00181$
                                   1529 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007889                       1530 00152$:
                                   1531 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007889 12 7B 64         [24] 1532 	lcall	_ak820_outline_0158
      00788C FF               [12] 1533 	mov	r7,a
      00788D BF F1 02         [24] 1534 	cjne	r7,#0xf1,00468$
      007890 80 0A            [24] 1535 	sjmp	00154$
      007892                       1536 00468$:
      007892 BF F2 02         [24] 1537 	cjne	r7,#0xf2,00469$
      007895 80 19            [24] 1538 	sjmp	00155$
      007897                       1539 00469$:
                                   1540 ;	quantum/action.c:694: momentary_layer_action:
      007897 BF F3 3B         [24] 1541 	cjne	r7,#0xf3,00160$
      00789A 80 28            [24] 1542 	sjmp	00156$
      00789C                       1543 00154$:
                                   1544 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00789C E5 28            [12] 1545 	mov	a,_process_action_sloc0_1_0
      00789E 60 08            [24] 1546 	jz	00206$
      0078A0 12 7B 1A         [24] 1547 	lcall	_ak820_outline_0042
      0078A3 12 7C 4F         [24] 1548 	lcall	_layer_hold_on
      0078A6 80 54            [24] 1549 	sjmp	00181$
      0078A8                       1550 00206$:
      0078A8 12 7B 1A         [24] 1551 	lcall	_ak820_outline_0042
      0078AB 12 7C 87         [24] 1552 	lcall	_layer_hold_off
                                   1553 ;	quantum/action.c:696: break;
                                   1554 ;	quantum/action.c:697: case OP_OFF_ON:
      0078AE 80 4C            [24] 1555 	sjmp	00181$
      0078B0                       1556 00155$:
                                   1557 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0078B0 E5 28            [12] 1558 	mov	a,_process_action_sloc0_1_0
      0078B2 60 08            [24] 1559 	jz	00208$
      0078B4 12 7B 1A         [24] 1560 	lcall	_ak820_outline_0042
      0078B7 12 7D 34         [24] 1561 	lcall	_layer_off
      0078BA 80 40            [24] 1562 	sjmp	00181$
      0078BC                       1563 00208$:
      0078BC 12 7B 1A         [24] 1564 	lcall	_ak820_outline_0042
      0078BF 12 7D 19         [24] 1565 	lcall	_layer_on
                                   1566 ;	quantum/action.c:699: break;
                                   1567 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0078C2 80 38            [24] 1568 	sjmp	00181$
      0078C4                       1569 00156$:
                                   1570 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0078C4 E5 28            [12] 1571 	mov	a,_process_action_sloc0_1_0
      0078C6 60 08            [24] 1572 	jz	00210$
      0078C8 12 7B 1A         [24] 1573 	lcall	_ak820_outline_0042
      0078CB 12 7D 03         [24] 1574 	lcall	_layer_move
      0078CE 80 2C            [24] 1575 	sjmp	00181$
      0078D0                       1576 00210$:
      0078D0 12 7C FD         [24] 1577 	lcall	_layer_clear
                                   1578 ;	quantum/action.c:702: break;
                                   1579 ;	quantum/action.c:748: default:
      0078D3 80 27            [24] 1580 	sjmp	00181$
      0078D5                       1581 00160$:
                                   1582 ;	quantum/action.c:755: if (pressed) {
      0078D5 E5 28            [12] 1583 	mov	a,_process_action_sloc0_1_0
      0078D7 60 08            [24] 1584 	jz	00163$
                                   1585 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0078D9 12 7B 34         [24] 1586 	lcall	_ak820_outline_0078
      0078DC 12 79 13         [24] 1587 	lcall	_register_code
                                   1588 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0078DF 80 1B            [24] 1589 	sjmp	00181$
      0078E1                       1590 00163$:
                                   1591 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0078E1 12 7B 64         [24] 1592 	lcall	_ak820_outline_0158
      0078E4 FF               [12] 1593 	mov	r7,a
      0078E5 BF 39 0E         [24] 1594 	cjne	r7,#0x39,00175$
                                   1595 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0078E8 7F 50            [12] 1596 	mov	r7,#0x50
      0078EA                       1597 00187$:
      0078EA EF               [12] 1598 	mov	a,r7
      0078EB 60 09            [24] 1599 	jz	00175$
      0078ED 90 00 01         [24] 1600 	mov	dptr,#0x0001
      0078F0 12 5C 21         [24] 1601 	lcall	_mDelaymS
      0078F3 1F               [12] 1602 	dec	r7
                                   1603 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0078F4 80 F4            [24] 1604 	sjmp	00187$
      0078F6                       1605 00175$:
                                   1606 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0078F6 12 7B 34         [24] 1607 	lcall	_ak820_outline_0078
      0078F9 12 79 8F         [24] 1608 	lcall	_unregister_code
                                   1609 ;	quantum/action.c:848: }
      0078FC                       1610 00181$:
                                   1611 ;	quantum/action.c:869: switch (action.kind.id) {
      0078FC 90 08 86         [24] 1612 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078FF E0               [24] 1613 	movx	a,@dptr
      007900 C4               [12] 1614 	swap	a
      007901 54 0F            [12] 1615 	anl	a,#0x0f
      007903 FF               [12] 1616 	mov	r7,a
      007904 BF 08 02         [24] 1617 	cjne	r7,#0x08,00478$
      007907 80 03            [24] 1618 	sjmp	00183$
      007909                       1619 00478$:
      007909 BF 09 06         [24] 1620 	cjne	r7,#0x09,00192$
                                   1621 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      00790C                       1622 00183$:
                                   1623 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      00790C 12 6F CE         [24] 1624 	lcall	_host_keyboard_leds
                                   1625 ;	quantum/action.c:880: }
                                   1626 ;	quantum/action.c:933: }
      00790F 02 9B 4F         [24] 1627 	ljmp	_led_set
      007912                       1628 00192$:
      007912 22               [24] 1629 	ret
                                   1630 ;------------------------------------------------------------
                                   1631 ;Allocation info for local variables in function 'register_code'
                                   1632 ;------------------------------------------------------------
                                   1633 ;code          Allocated with name '_register_code_code_10000_715'
                                   1634 ;------------------------------------------------------------
                                   1635 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1636 ;	-----------------------------------------
                                   1637 ;	 function register_code
                                   1638 ;	-----------------------------------------
      007913                       1639 _register_code:
      007913 E5 82            [12] 1640 	mov	a,dpl
      007915 90 08 8B         [24] 1641 	mov	dptr,#_register_code_code_10000_715
      007918 F0               [24] 1642 	movx	@dptr,a
                                   1643 ;	quantum/action.c:940: if (code == KC_NO) {
      007919 E0               [24] 1644 	movx	a,@dptr
      00791A FF               [12] 1645 	mov	r7,a
      00791B 70 01            [24] 1646 	jnz	00123$
                                   1647 ;	quantum/action.c:941: return;
      00791D 22               [24] 1648 	ret
      00791E                       1649 00123$:
                                   1650 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      00791E BF 04 00         [24] 1651 	cjne	r7,#0x04,00186$
      007921                       1652 00186$:
      007921 40 21            [24] 1653 	jc	00119$
      007923 EF               [12] 1654 	mov	a,r7
      007924 24 5B            [12] 1655 	add	a,#0xff - 0xa4
      007926 40 1C            [24] 1656 	jc	00119$
                                   1657 ;	free result
                                   1658 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007928 8F 82            [24] 1659 	mov	dpl, r7
      00792A C0 07            [24] 1660 	push	ar7
      00792C 12 81 78         [24] 1661 	lcall	_add_owned_key
      00792F E5 82            [12] 1662 	mov	a, dpl
      007931 D0 07            [24] 1663 	pop	ar7
      007933 70 01            [24] 1664 	jnz	00104$
      007935 22               [24] 1665 	ret
      007936                       1666 00104$:
                                   1667 ;	quantum/action.c:983: ak820_dynamic_macro_observe(code, true);
      007936 90 04 B1         [24] 1668 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007939 74 01            [12] 1669 	mov	a,#0x01
      00793B F0               [24] 1670 	movx	@dptr,a
      00793C 8F 82            [24] 1671 	mov	dpl, r7
      00793E 12 3A 3B         [24] 1672 	lcall	_ak820_dynamic_macro_observe
                                   1673 ;	quantum/action.c:995: send_keyboard_report();
      007941 02 84 0E         [24] 1674 	ljmp	_send_keyboard_report
      007944                       1675 00119$:
                                   1676 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      007944 12 7B 69         [24] 1677 	lcall	_ak820_outline_0166
      007947 BF E0 00         [24] 1678 	cjne	r7,#0xe0,00190$
      00794A                       1679 00190$:
      00794A 40 1A            [24] 1680 	jc	00115$
      00794C EF               [12] 1681 	mov	a,r7
      00794D 24 18            [12] 1682 	add	a,#0xff - 0xe7
      00794F 40 15            [24] 1683 	jc	00115$
                                   1684 ;	free result
                                   1685 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007951 74 07            [12] 1686 	mov	a,#0x07
      007953 5F               [12] 1687 	anl	a,r7
      007954 12 7B 23         [24] 1688 	lcall	_ak820_outline_0061
      007957 80 02            [24] 1689 	sjmp	00194$
      007959                       1690 00193$:
      007959 25 E0            [12] 1691 	add	a,acc
      00795B                       1692 00194$:
      00795B D5 F0 FB         [24] 1693 	djnz	b,00193$
      00795E F5 82            [12] 1694 	mov	dpl,a
      007960 12 80 D5         [24] 1695 	lcall	_add_owned_mods
                                   1696 ;	quantum/action.c:998: send_keyboard_report();
      007963 02 84 0E         [24] 1697 	ljmp	_send_keyboard_report
      007966                       1698 00115$:
                                   1699 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007966 12 7B 69         [24] 1700 	lcall	_ak820_outline_0166
      007969 BF A5 00         [24] 1701 	cjne	r7,#0xa5,00195$
      00796C                       1702 00195$:
      00796C 40 05            [24] 1703 	jc	00113$
      00796E EF               [12] 1704 	mov	a,r7
      00796F 24 58            [12] 1705 	add	a,#0xff - 0xa7
      007971 50 0D            [24] 1706 	jnc	00108$
                                   1707 ;	free result
      007973                       1708 00113$:
      007973 12 7B 69         [24] 1709 	lcall	_ak820_outline_0166
      007976 BF A8 00         [24] 1710 	cjne	r7,#0xa8,00198$
      007979                       1711 00198$:
      007979 40 13            [24] 1712 	jc	00125$
      00797B EF               [12] 1713 	mov	a,r7
      00797C 24 3D            [12] 1714 	add	a,#0xff - 0xc2
      00797E 40 0E            [24] 1715 	jc	00125$
                                   1716 ;	free result
      007980                       1717 00108$:
                                   1718 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007980 12 7B 69         [24] 1719 	lcall	_ak820_outline_0166
      007983 90 0A E6         [24] 1720 	mov	dptr,#_owned_usage_key_PARM_2
      007986 74 01            [12] 1721 	mov	a,#0x01
      007988 F0               [24] 1722 	movx	@dptr,a
      007989 8F 82            [24] 1723 	mov	dpl, r7
                                   1724 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1725 ;	quantum/action.c:1013: }
      00798B 02 82 B9         [24] 1726 	ljmp	_owned_usage_key
      00798E                       1727 00125$:
      00798E 22               [24] 1728 	ret
                                   1729 ;------------------------------------------------------------
                                   1730 ;Allocation info for local variables in function 'unregister_code'
                                   1731 ;------------------------------------------------------------
                                   1732 ;code          Allocated with name '_unregister_code_code_10000_729'
                                   1733 ;------------------------------------------------------------
                                   1734 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1735 ;	-----------------------------------------
                                   1736 ;	 function unregister_code
                                   1737 ;	-----------------------------------------
      00798F                       1738 _unregister_code:
      00798F E5 82            [12] 1739 	mov	a,dpl
      007991 90 08 8C         [24] 1740 	mov	dptr,#_unregister_code_code_10000_729
      007994 F0               [24] 1741 	movx	@dptr,a
                                   1742 ;	quantum/action.c:1020: if (code == KC_NO) {
      007995 E0               [24] 1743 	movx	a,@dptr
      007996 FF               [12] 1744 	mov	r7,a
      007997 70 01            [24] 1745 	jnz	00121$
                                   1746 ;	quantum/action.c:1021: return;
      007999 22               [24] 1747 	ret
      00799A                       1748 00121$:
                                   1749 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      00799A BF 04 00         [24] 1750 	cjne	r7,#0x04,00184$
      00799D                       1751 00184$:
      00799D 40 1F            [24] 1752 	jc	00117$
      00799F EF               [12] 1753 	mov	a,r7
      0079A0 24 5B            [12] 1754 	add	a,#0xff - 0xa4
      0079A2 40 1A            [24] 1755 	jc	00117$
                                   1756 ;	free result
                                   1757 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      0079A4 8F 82            [24] 1758 	mov	dpl, r7
      0079A6 C0 07            [24] 1759 	push	ar7
      0079A8 12 81 F2         [24] 1760 	lcall	_del_owned_key
      0079AB E5 82            [12] 1761 	mov	a, dpl
      0079AD D0 07            [24] 1762 	pop	ar7
      0079AF 70 01            [24] 1763 	jnz	00102$
      0079B1 22               [24] 1764 	ret
      0079B2                       1765 00102$:
                                   1766 ;	quantum/action.c:1057: ak820_dynamic_macro_observe(code, false);
      0079B2 90 04 B1         [24] 1767 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      0079B5 12 7B 7A         [24] 1768 	lcall	_ak820_outline_0188
      0079B8 12 3A 3B         [24] 1769 	lcall	_ak820_dynamic_macro_observe
                                   1770 ;	quantum/action.c:1062: send_keyboard_report();
      0079BB 02 84 0E         [24] 1771 	ljmp	_send_keyboard_report
      0079BE                       1772 00117$:
                                   1773 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079BE 12 7B 6F         [24] 1774 	lcall	_ak820_outline_0167
      0079C1 BF E0 00         [24] 1775 	cjne	r7,#0xe0,00188$
      0079C4                       1776 00188$:
      0079C4 40 1A            [24] 1777 	jc	00113$
      0079C6 EF               [12] 1778 	mov	a,r7
      0079C7 24 18            [12] 1779 	add	a,#0xff - 0xe7
      0079C9 40 15            [24] 1780 	jc	00113$
                                   1781 ;	free result
                                   1782 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0079CB 74 07            [12] 1783 	mov	a,#0x07
      0079CD 5F               [12] 1784 	anl	a,r7
      0079CE 12 7B 23         [24] 1785 	lcall	_ak820_outline_0061
      0079D1 80 02            [24] 1786 	sjmp	00192$
      0079D3                       1787 00191$:
      0079D3 25 E0            [12] 1788 	add	a,acc
      0079D5                       1789 00192$:
      0079D5 D5 F0 FB         [24] 1790 	djnz	b,00191$
      0079D8 F5 82            [12] 1791 	mov	dpl,a
      0079DA 12 80 E5         [24] 1792 	lcall	_del_owned_mods
                                   1793 ;	quantum/action.c:1065: send_keyboard_report();
      0079DD 02 84 0E         [24] 1794 	ljmp	_send_keyboard_report
      0079E0                       1795 00113$:
                                   1796 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0079E0 12 7B 6F         [24] 1797 	lcall	_ak820_outline_0167
      0079E3 BF A5 00         [24] 1798 	cjne	r7,#0xa5,00193$
      0079E6                       1799 00193$:
      0079E6 40 05            [24] 1800 	jc	00111$
      0079E8 EF               [12] 1801 	mov	a,r7
      0079E9 24 58            [12] 1802 	add	a,#0xff - 0xa7
      0079EB 50 0D            [24] 1803 	jnc	00106$
                                   1804 ;	free result
      0079ED                       1805 00111$:
      0079ED 12 7B 6F         [24] 1806 	lcall	_ak820_outline_0167
      0079F0 BF A8 00         [24] 1807 	cjne	r7,#0xa8,00196$
      0079F3                       1808 00196$:
      0079F3 40 11            [24] 1809 	jc	00123$
      0079F5 EF               [12] 1810 	mov	a,r7
      0079F6 24 3D            [12] 1811 	add	a,#0xff - 0xc2
      0079F8 40 0C            [24] 1812 	jc	00123$
                                   1813 ;	free result
      0079FA                       1814 00106$:
                                   1815 ;	quantum/action.c:1070: owned_usage_key(code, false);
      0079FA 12 7B 6F         [24] 1816 	lcall	_ak820_outline_0167
      0079FD 90 0A E6         [24] 1817 	mov	dptr,#_owned_usage_key_PARM_2
      007A00 12 7B 7A         [24] 1818 	lcall	_ak820_outline_0188
                                   1819 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1820 ;	quantum/action.c:1080: }
      007A03 02 82 B9         [24] 1821 	ljmp	_owned_usage_key
      007A06                       1822 00123$:
      007A06 22               [24] 1823 	ret
                                   1824 ;------------------------------------------------------------
                                   1825 ;Allocation info for local variables in function 'tap_code_delay'
                                   1826 ;------------------------------------------------------------
                                   1827 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1828 ;code          Allocated with name '_tap_code_delay_code_10000_742'
                                   1829 ;i             Allocated with name '_tap_code_delay_i_20000_744'
                                   1830 ;i             Allocated with name '_tap_code_delay_i_50000_747'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function tap_code_delay
                                   1835 ;	-----------------------------------------
      007A07                       1836 _tap_code_delay:
      007A07 E5 82            [12] 1837 	mov	a,dpl
      007A09 90 08 8F         [24] 1838 	mov	dptr,#_tap_code_delay_code_10000_742
      007A0C F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	quantum/action.c:1088: register_code(code);
      007A0D E0               [24] 1841 	movx	a,@dptr
      007A0E FF               [12] 1842 	mov	r7,a
      007A0F F5 82            [12] 1843 	mov	dpl,a
      007A11 C0 07            [24] 1844 	push	ar7
      007A13 12 79 13         [24] 1845 	lcall	_register_code
      007A16 D0 07            [24] 1846 	pop	ar7
                                   1847 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007A18 90 08 8D         [24] 1848 	mov	dptr,#_tap_code_delay_PARM_2
      007A1B 12 38 64         [24] 1849 	lcall	_ak820_outline_0079
      007A1E                       1850 00110$:
      007A1E ED               [12] 1851 	mov	a,r5
      007A1F 4E               [12] 1852 	orl	a,r6
      007A20 60 0D            [24] 1853 	jz	00105$
                                   1854 ;	quantum/action.c:1090: wait_ms(1);
      007A22 90 00 01         [24] 1855 	mov	dptr,#0x0001
      007A25 12 5C 21         [24] 1856 	lcall	_mDelaymS
                                   1857 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007A28 1D               [12] 1858 	dec	r5
      007A29 BD FF 01         [24] 1859 	cjne	r5,#0xff,00141$
      007A2C 1E               [12] 1860 	dec	r6
      007A2D                       1861 00141$:
      007A2D 80 EF            [24] 1862 	sjmp	00110$
      007A2F                       1863 00105$:
                                   1864 ;	quantum/action.c:1092: unregister_code(code);
      007A2F 8F 82            [24] 1865 	mov	dpl, r7
                                   1866 ;	quantum/action.c:1093: }
      007A31 02 79 8F         [24] 1867 	ljmp	_unregister_code
                                   1868 ;------------------------------------------------------------
                                   1869 ;Allocation info for local variables in function 'tap_code'
                                   1870 ;------------------------------------------------------------
                                   1871 ;code          Allocated with name '_tap_code_code_10000_749'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function tap_code
                                   1876 ;	-----------------------------------------
      007A34                       1877 _tap_code:
      007A34 E5 82            [12] 1878 	mov	a,dpl
      007A36 90 08 90         [24] 1879 	mov	dptr,#_tap_code_code_10000_749
      007A39 F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A3A E0               [24] 1882 	movx	a,@dptr
      007A3B FF               [12] 1883 	mov	r7,a
      007A3C BF 39 04         [24] 1884 	cjne	r7,#0x39,00103$
      007A3F 7E 50            [12] 1885 	mov	r6,#0x50
      007A41 80 02            [24] 1886 	sjmp	00104$
      007A43                       1887 00103$:
      007A43 7E 00            [12] 1888 	mov	r6,#0x00
      007A45                       1889 00104$:
      007A45 90 08 8D         [24] 1890 	mov	dptr,#_tap_code_delay_PARM_2
      007A48 EE               [12] 1891 	mov	a,r6
      007A49 12 38 9C         [24] 1892 	lcall	_ak820_outline_0134
      007A4C 8F 82            [24] 1893 	mov	dpl, r7
                                   1894 ;	quantum/action.c:1101: }
      007A4E 02 7A 07         [24] 1895 	ljmp	_tap_code_delay
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'register_mods'
                                   1898 ;------------------------------------------------------------
                                   1899 ;mods          Allocated with name '_register_mods_mods_10000_751'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function register_mods
                                   1904 ;	-----------------------------------------
      007A51                       1905 _register_mods:
      007A51 E5 82            [12] 1906 	mov	a,dpl
      007A53 90 08 91         [24] 1907 	mov	dptr,#_register_mods_mods_10000_751
      007A56 F0               [24] 1908 	movx	@dptr,a
                                   1909 ;	quantum/action.c:1108: if (mods) {
      007A57 E0               [24] 1910 	movx	a,@dptr
      007A58 FF               [12] 1911 	mov	r7,a
      007A59 E0               [24] 1912 	movx	a,@dptr
      007A5A 60 08            [24] 1913 	jz	00103$
                                   1914 ;	quantum/action.c:1109: add_owned_mods(mods);
      007A5C 8F 82            [24] 1915 	mov	dpl, r7
      007A5E 12 80 D5         [24] 1916 	lcall	_add_owned_mods
                                   1917 ;	quantum/action.c:1110: send_keyboard_report();
                                   1918 ;	quantum/action.c:1112: }
      007A61 02 84 0E         [24] 1919 	ljmp	_send_keyboard_report
      007A64                       1920 00103$:
      007A64 22               [24] 1921 	ret
                                   1922 ;------------------------------------------------------------
                                   1923 ;Allocation info for local variables in function 'unregister_mods'
                                   1924 ;------------------------------------------------------------
                                   1925 ;mods          Allocated with name '_unregister_mods_mods_10000_755'
                                   1926 ;------------------------------------------------------------
                                   1927 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1928 ;	-----------------------------------------
                                   1929 ;	 function unregister_mods
                                   1930 ;	-----------------------------------------
      007A65                       1931 _unregister_mods:
      007A65 E5 82            [12] 1932 	mov	a,dpl
      007A67 90 08 92         [24] 1933 	mov	dptr,#_unregister_mods_mods_10000_755
      007A6A F0               [24] 1934 	movx	@dptr,a
                                   1935 ;	quantum/action.c:1119: if (mods) {
      007A6B E0               [24] 1936 	movx	a,@dptr
      007A6C FF               [12] 1937 	mov	r7,a
      007A6D E0               [24] 1938 	movx	a,@dptr
      007A6E 60 08            [24] 1939 	jz	00103$
                                   1940 ;	quantum/action.c:1120: del_owned_mods(mods);
      007A70 8F 82            [24] 1941 	mov	dpl, r7
      007A72 12 80 E5         [24] 1942 	lcall	_del_owned_mods
                                   1943 ;	quantum/action.c:1121: send_keyboard_report();
                                   1944 ;	quantum/action.c:1123: }
      007A75 02 84 0E         [24] 1945 	ljmp	_send_keyboard_report
      007A78                       1946 00103$:
      007A78 22               [24] 1947 	ret
                                   1948 ;------------------------------------------------------------
                                   1949 ;Allocation info for local variables in function 'register_weak_mods'
                                   1950 ;------------------------------------------------------------
                                   1951 ;mods          Allocated with name '_register_weak_mods_mods_10000_759'
                                   1952 ;------------------------------------------------------------
                                   1953 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1954 ;	-----------------------------------------
                                   1955 ;	 function register_weak_mods
                                   1956 ;	-----------------------------------------
      007A79                       1957 _register_weak_mods:
      007A79 E5 82            [12] 1958 	mov	a,dpl
      007A7B 90 08 93         [24] 1959 	mov	dptr,#_register_weak_mods_mods_10000_759
      007A7E F0               [24] 1960 	movx	@dptr,a
                                   1961 ;	quantum/action.c:1130: if (mods) {
      007A7F E0               [24] 1962 	movx	a,@dptr
      007A80 FF               [12] 1963 	mov	r7,a
      007A81 E0               [24] 1964 	movx	a,@dptr
      007A82 60 08            [24] 1965 	jz	00103$
                                   1966 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007A84 8F 82            [24] 1967 	mov	dpl, r7
      007A86 12 80 F3         [24] 1968 	lcall	_add_owned_weak_mods
                                   1969 ;	quantum/action.c:1132: send_keyboard_report();
                                   1970 ;	quantum/action.c:1134: }
      007A89 02 84 0E         [24] 1971 	ljmp	_send_keyboard_report
      007A8C                       1972 00103$:
      007A8C 22               [24] 1973 	ret
                                   1974 ;------------------------------------------------------------
                                   1975 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1976 ;------------------------------------------------------------
                                   1977 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_763'
                                   1978 ;------------------------------------------------------------
                                   1979 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1980 ;	-----------------------------------------
                                   1981 ;	 function unregister_weak_mods
                                   1982 ;	-----------------------------------------
      007A8D                       1983 _unregister_weak_mods:
      007A8D E5 82            [12] 1984 	mov	a,dpl
      007A8F 90 08 94         [24] 1985 	mov	dptr,#_unregister_weak_mods_mods_10000_763
      007A92 F0               [24] 1986 	movx	@dptr,a
                                   1987 ;	quantum/action.c:1141: if (mods) {
      007A93 E0               [24] 1988 	movx	a,@dptr
      007A94 FF               [12] 1989 	mov	r7,a
      007A95 E0               [24] 1990 	movx	a,@dptr
      007A96 60 08            [24] 1991 	jz	00103$
                                   1992 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007A98 8F 82            [24] 1993 	mov	dpl, r7
      007A9A 12 81 03         [24] 1994 	lcall	_del_owned_weak_mods
                                   1995 ;	quantum/action.c:1143: send_keyboard_report();
                                   1996 ;	quantum/action.c:1145: }
      007A9D 02 84 0E         [24] 1997 	ljmp	_send_keyboard_report
      007AA0                       1998 00103$:
      007AA0 22               [24] 1999 	ret
                                   2000 ;------------------------------------------------------------
                                   2001 ;Allocation info for local variables in function 'clear_keyboard'
                                   2002 ;------------------------------------------------------------
                                   2003 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   2004 ;	-----------------------------------------
                                   2005 ;	 function clear_keyboard
                                   2006 ;	-----------------------------------------
      007AA1                       2007 _clear_keyboard:
                                   2008 ;	quantum/action.c:1152: clear_mods();
      007AA1 12 84 89         [24] 2009 	lcall	_clear_mods
                                   2010 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   2011 ;	quantum/action.c:1154: }
      007AA4 02 7A A7         [24] 2012 	ljmp	_clear_keyboard_but_mods
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2015 ;------------------------------------------------------------
                                   2016 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   2017 ;	-----------------------------------------
                                   2018 ;	 function clear_keyboard_but_mods
                                   2019 ;	-----------------------------------------
      007AA7                       2020 _clear_keyboard_but_mods:
                                   2021 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AA7 90 0E 18         [24] 2022 	mov	dptr,#_actual_keyboard_report
      007AAA 12 72 95         [24] 2023 	lcall	_clear_keys_from_report
                                   2024 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   2025 ;	quantum/action.c:1163: }
      007AAD 02 7A B0         [24] 2026 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2027 ;------------------------------------------------------------
                                   2028 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2029 ;------------------------------------------------------------
                                   2030 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   2031 ;	-----------------------------------------
                                   2032 ;	 function clear_keyboard_but_mods_and_keys
                                   2033 ;	-----------------------------------------
      007AB0                       2034 _clear_keyboard_but_mods_and_keys:
                                   2035 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007AB0 12 4A 1A         [24] 2036 	lcall	_ak820_tapping_cancel
                                   2037 ;	quantum/action.c:1176: ak820_dynamic_macro_cancel();
      007AB3 12 39 6C         [24] 2038 	lcall	_ak820_dynamic_macro_cancel
                                   2039 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007AB6 12 2E F0         [24] 2040 	lcall	_ak820_oneshot_cancel
                                   2041 ;	quantum/action.c:1185: ak820_combo_cancel();
      007AB9 12 35 70         [24] 2042 	lcall	_ak820_combo_cancel
                                   2043 ;	quantum/action.c:1188: repeat_key_cancel();
      007ABC 12 A5 3C         [24] 2044 	lcall	_repeat_key_cancel
                                   2045 ;	quantum/action.c:1190: clear_owned_mods();
      007ABF 12 81 13         [24] 2046 	lcall	_clear_owned_mods
                                   2047 ;	quantum/action.c:1191: clear_owned_keys();
      007AC2 12 81 4B         [24] 2048 	lcall	_clear_owned_keys
                                   2049 ;	quantum/action.c:1192: clear_owned_usages();
      007AC5 12 82 81         [24] 2050 	lcall	_clear_owned_usages
                                   2051 ;	quantum/action.c:1193: layer_hold_clear();
      007AC8 12 7C C0         [24] 2052 	lcall	_layer_hold_clear
                                   2053 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007ACB 12 9F FB         [24] 2054 	lcall	_clear_macro_tri_layer
                                   2055 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007ACE 90 0E 18         [24] 2056 	mov	dptr,#_actual_keyboard_report
      007AD1 12 72 95         [24] 2057 	lcall	_clear_keys_from_report
                                   2058 ;	quantum/action.c:1200: host_system_send(0);
      007AD4 90 00 00         [24] 2059 	mov	dptr,#0x0000
      007AD7 12 70 69         [24] 2060 	lcall	_host_system_send
                                   2061 ;	quantum/action.c:1201: host_consumer_send(0);
      007ADA 90 00 00         [24] 2062 	mov	dptr,#0x0000
      007ADD 12 70 99         [24] 2063 	lcall	_host_consumer_send
                                   2064 ;	quantum/action.c:1203: clear_weak_mods();
      007AE0 12 84 BE         [24] 2065 	lcall	_clear_weak_mods
                                   2066 ;	quantum/action.c:1204: send_keyboard_report();
                                   2067 ;	quantum/action.c:1212: }
      007AE3 02 84 0E         [24] 2068 	ljmp	_send_keyboard_report
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'is_tap_record'
                                   2071 ;------------------------------------------------------------
                                   2072 ;record        Allocated with name '_is_tap_record_record_10000_779'
                                   2073 ;action        Allocated with name '_is_tap_record_action_10001_783'
                                   2074 ;------------------------------------------------------------
                                   2075 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   2076 ;	-----------------------------------------
                                   2077 	.area CSEG    (CODE)
                                   2078 	.area CONST   (CODE)
                                   2079 	.area XINIT   (CODE)
      00C4BD                       2080 __xinit__disable_action_cache:
      00C4BD 00                    2081 	.db #0x00	;  0
                                   2082 	.area CABS    (ABS,CODE)
                                   2083 
                                   2084 ; Experimental exact instruction outlining.
                                   2085 	.globl _ak820_outline_0001
                                   2086 	.globl _ak820_outline_0005
                                   2087 	.globl _ak820_outline_0006
                                   2088 	.globl _ak820_outline_0008
                                   2089 	.globl _ak820_outline_0009
                                   2090 	.globl _ak820_outline_0012
                                   2091 	.globl _ak820_outline_0013
                                   2092 	.globl _ak820_outline_0014
                                   2093 	.globl _ak820_outline_0017
                                   2094 	.globl _ak820_outline_0021
                                   2095 	.globl _ak820_outline_0022
                                   2096 	.globl _ak820_outline_0024
                                   2097 	.globl _ak820_outline_0031
                                   2098 	.globl _ak820_outline_0037
                                   2099 	.globl _ak820_outline_0042
                                   2100 	.globl _ak820_outline_0050
                                   2101 	.globl _ak820_outline_0061
                                   2102 	.globl _ak820_outline_0064
                                   2103 	.globl _ak820_outline_0070
                                   2104 	.globl _ak820_outline_0071
                                   2105 	.globl _ak820_outline_0072
                                   2106 	.globl _ak820_outline_0078
                                   2107 	.globl _ak820_outline_0079
                                   2108 	.globl _ak820_outline_0081
                                   2109 	.globl _ak820_outline_0090
                                   2110 	.globl _ak820_outline_0094
                                   2111 	.globl _ak820_outline_0108
                                   2112 	.globl _ak820_outline_0109
                                   2113 	.globl _ak820_outline_0111
                                   2114 	.globl _ak820_outline_0113
                                   2115 	.globl _ak820_outline_0118
                                   2116 	.globl _ak820_outline_0121
                                   2117 	.globl _ak820_outline_0124
                                   2118 	.globl _ak820_outline_0125
                                   2119 	.globl _ak820_outline_0131
                                   2120 	.globl _ak820_outline_0134
                                   2121 	.globl _ak820_outline_0142
                                   2122 	.globl _ak820_outline_0143
                                   2123 	.globl _ak820_outline_0144
                                   2124 	.globl _ak820_outline_0149
                                   2125 	.globl _ak820_outline_0158
                                   2126 	.globl _ak820_outline_0166
                                   2127 	.globl _ak820_outline_0167
                                   2128 	.globl _ak820_outline_0181
                                   2129 	.globl _ak820_outline_0186
                                   2130 	.globl _ak820_outline_0188
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0006
      007AE6                       2134 _ak820_outline_0006:
      007AE6 2D               [12] 2135 	add	a,r5
      007AE7 FA               [12] 2136 	mov	r2,a
      007AE8 E4               [12] 2137 	clr	a
      007AE9 3E               [12] 2138 	addc	a,r6
      007AEA FB               [12] 2139 	mov	r3,a
      007AEB 8F 04            [24] 2140 	mov	ar4,r7
      007AED 8A 82            [24] 2141 	mov	dpl,r2
      007AEF 8B 83            [24] 2142 	mov	dph,r3
      007AF1 8C F0            [24] 2143 	mov	b,r4
      007AF3 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0014
      007AF4                       2148 _ak820_outline_0014:
      007AF4 2D               [12] 2149 	add	a,r5
      007AF5 F9               [12] 2150 	mov	r1,a
      007AF6 E4               [12] 2151 	clr	a
      007AF7 3E               [12] 2152 	addc	a,r6
      007AF8 FA               [12] 2153 	mov	r2,a
      007AF9 8F 03            [24] 2154 	mov	ar3,r7
      007AFB 89 82            [24] 2155 	mov	dpl,r1
      007AFD 8A 83            [24] 2156 	mov	dph,r2
      007AFF 8B F0            [24] 2157 	mov	b,r3
      007B01 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0021
      007B02                       2162 _ak820_outline_0021:
      007B02 8E 82            [24] 2163 	mov	dpl,r6
      007B04 8F 83            [24] 2164 	mov	dph,r7
      007B06 A3               [24] 2165 	inc	dptr
      007B07 E0               [24] 2166 	movx	a,@dptr
      007B08 FC               [12] 2167 	mov	r4,a
      007B09 7D 00            [12] 2168 	mov	r5,#0x00
      007B0B 8E 82            [24] 2169 	mov	dpl,r6
      007B0D 8F 83            [24] 2170 	mov	dph,r7
      007B0F E0               [24] 2171 	movx	a,@dptr
      007B10 22               [24] 2172 	ret
                                   2173 
                                   2174 	.area CSEG (CODE)
                                   2175 ; function ak820_outline_0024
      007B11                       2176 _ak820_outline_0024:
      007B11 E0               [24] 2177 	movx	a,@dptr
      007B12 FB               [12] 2178 	mov	r3,a
      007B13 A3               [24] 2179 	inc	dptr
      007B14 E0               [24] 2180 	movx	a,@dptr
      007B15 FC               [12] 2181 	mov	r4,a
      007B16 A3               [24] 2182 	inc	dptr
      007B17 E0               [24] 2183 	movx	a,@dptr
      007B18 FD               [12] 2184 	mov	r5,a
      007B19 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0042
      007B1A                       2189 _ak820_outline_0042:
      007B1A 90 08 86         [24] 2190 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B1D E0               [24] 2191 	movx	a,@dptr
      007B1E 54 1F            [12] 2192 	anl	a,#0x1f
      007B20 F5 82            [12] 2193 	mov	dpl,a
      007B22 22               [24] 2194 	ret
                                   2195 
                                   2196 	.area CSEG (CODE)
                                   2197 ; function ak820_outline_0061
      007B23                       2198 _ak820_outline_0061:
      007B23 F5 F0            [12] 2199 	mov	b,a
      007B25 05 F0            [12] 2200 	inc	b
      007B27 74 01            [12] 2201 	mov	a,#0x01
      007B29 22               [24] 2202 	ret
                                   2203 
                                   2204 	.area CSEG (CODE)
                                   2205 ; function ak820_outline_0070
      007B2A                       2206 _ak820_outline_0070:
      007B2A 90 0D F6         [24] 2207 	mov	dptr,#___memcpy_PARM_3
      007B2D 74 06            [12] 2208 	mov	a,#0x06
      007B2F F0               [24] 2209 	movx	@dptr,a
      007B30 E4               [12] 2210 	clr	a
      007B31 A3               [24] 2211 	inc	dptr
      007B32 F0               [24] 2212 	movx	@dptr,a
      007B33 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0078
      007B34                       2217 _ak820_outline_0078:
      007B34 90 08 85         [24] 2218 	mov	dptr,#_process_action_PARM_2
      007B37 E0               [24] 2219 	movx	a,@dptr
      007B38 F5 82            [12] 2220 	mov	dpl,a
      007B3A 22               [24] 2221 	ret
                                   2222 
                                   2223 	.area CSEG (CODE)
                                   2224 ; function ak820_outline_0081
      007B3B                       2225 _ak820_outline_0081:
      007B3B 2D               [12] 2226 	add	a,r5
      007B3C F8               [12] 2227 	mov	r0,a
      007B3D E4               [12] 2228 	clr	a
      007B3E 3E               [12] 2229 	addc	a,r6
      007B3F F9               [12] 2230 	mov	r1,a
      007B40 8F 02            [24] 2231 	mov	ar2,r7
      007B42 88 82            [24] 2232 	mov	dpl,r0
      007B44 89 83            [24] 2233 	mov	dph,r1
      007B46 8A F0            [24] 2234 	mov	b,r2
      007B48 22               [24] 2235 	ret
                                   2236 
                                   2237 	.area CSEG (CODE)
                                   2238 ; function ak820_outline_0090
      007B49                       2239 _ak820_outline_0090:
      007B49 90 08 86         [24] 2240 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B4C E0               [24] 2241 	movx	a,@dptr
      007B4D 03               [12] 2242 	rr	a
      007B4E 03               [12] 2243 	rr	a
      007B4F 54 03            [12] 2244 	anl	a,#0x03
      007B51 22               [24] 2245 	ret
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0113
      007B52                       2249 _ak820_outline_0113:
      007B52 90 08 86         [24] 2250 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B55 E0               [24] 2251 	movx	a,@dptr
      007B56 54 0F            [12] 2252 	anl	a,#0x0f
      007B58 22               [24] 2253 	ret
                                   2254 
                                   2255 	.area CSEG (CODE)
                                   2256 ; function ak820_outline_0131
      007B59                       2257 _ak820_outline_0131:
      007B59 90 08 85         [24] 2258 	mov	dptr,#_process_action_PARM_2
      007B5C E0               [24] 2259 	movx	a,@dptr
      007B5D FE               [12] 2260 	mov	r6,a
      007B5E A3               [24] 2261 	inc	dptr
      007B5F E0               [24] 2262 	movx	a,@dptr
      007B60 54 03            [12] 2263 	anl	a,#0x03
      007B62 FF               [12] 2264 	mov	r7,a
      007B63 22               [24] 2265 	ret
                                   2266 
                                   2267 	.area CSEG (CODE)
                                   2268 ; function ak820_outline_0158
      007B64                       2269 _ak820_outline_0158:
      007B64 90 08 85         [24] 2270 	mov	dptr,#_process_action_PARM_2
      007B67 E0               [24] 2271 	movx	a,@dptr
      007B68 22               [24] 2272 	ret
                                   2273 
                                   2274 	.area CSEG (CODE)
                                   2275 ; function ak820_outline_0166
      007B69                       2276 _ak820_outline_0166:
      007B69 90 08 8B         [24] 2277 	mov	dptr,#_register_code_code_10000_715
      007B6C E0               [24] 2278 	movx	a,@dptr
      007B6D FF               [12] 2279 	mov	r7,a
      007B6E 22               [24] 2280 	ret
                                   2281 
                                   2282 	.area CSEG (CODE)
                                   2283 ; function ak820_outline_0167
      007B6F                       2284 _ak820_outline_0167:
      007B6F 90 08 8C         [24] 2285 	mov	dptr,#_unregister_code_code_10000_729
      007B72 E0               [24] 2286 	movx	a,@dptr
      007B73 FF               [12] 2287 	mov	r7,a
      007B74 22               [24] 2288 	ret
                                   2289 
                                   2290 	.area CSEG (CODE)
                                   2291 ; function ak820_outline_0186
      007B75                       2292 _ak820_outline_0186:
      007B75 F0               [24] 2293 	movx	@dptr,a
      007B76 EB               [12] 2294 	mov	a,r3
      007B77 A3               [24] 2295 	inc	dptr
      007B78 F0               [24] 2296 	movx	@dptr,a
      007B79 22               [24] 2297 	ret
                                   2298 
                                   2299 	.area CSEG (CODE)
                                   2300 ; function ak820_outline_0188
      007B7A                       2301 _ak820_outline_0188:
      007B7A E4               [12] 2302 	clr	a
      007B7B F0               [24] 2303 	movx	@dptr,a
      007B7C 8F 82            [24] 2304 	mov	dpl,r7
      007B7E 22               [24] 2305 	ret
