                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000573                        109 _page_data:
      000573                        110 	.ds 64
      0005B3                        111 _cached_page:
      0005B3                        112 	.ds 1
      0005B4                        113 _batch_depth:
      0005B4                        114 	.ds 1
      0005B5                        115 _first_failure_stage:
      0005B5                        116 	.ds 1
      0005B6                        117 _nvm_fail_stage_10000_20:
      0005B6                        118 	.ds 1
      0005B7                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005B7                        120 	.ds 2
      0005B9                        121 _crc_byte_PARM_2:
      0005B9                        122 	.ds 1
      0005BA                        123 _crc_byte_crc_10000_25:
      0005BA                        124 	.ds 2
      0005BC                        125 _page_crc_crc_10000_30:
      0005BC                        126 	.ds 2
      0005BE                        127 _write_page_address_10000_32:
      0005BE                        128 	.ds 2
      0005C0                        129 _journal_header_valid_header_10000_39:
      0005C0                        130 	.ds 2
      0005C2                        131 _recover_journal_header_10000_46:
      0005C2                        132 	.ds 9
      0005CB                        133 _ak820_nvm_flush_header_10000_62:
      0005CB                        134 	.ds 9
      0005D4                        135 _ak820_nvm_flush_stage_10000_62:
      0005D4                        136 	.ds 1
      0005D5                        137 _load_page_page_10000_87:
      0005D5                        138 	.ds 1
      0005D6                        139 _read_offset_offset_10000_93:
      0005D6                        140 	.ds 2
      0005D8                        141 _eeprom_read_byte_addr_10000_97:
      0005D8                        142 	.ds 3
      0005DB                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005DB                        144 	.ds 3
      0005DE                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005DE                        146 	.ds 2
      0005E0                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005E0                        148 	.ds 2
      0005E2                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005E2                        150 	.ds 2
      0005E4                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005E4                        152 	.ds 3
      0005E7                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005E7                        154 	.ds 2
      0005E9                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005E9                        156 	.ds 2
      0005EB                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005EB                        158 	.ds 3
      0005EE                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005EE                        160 	.ds 2
      0005F0                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005F0                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003ED0                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003ED0 E5 82            [12]  215 	mov	a,dpl
      003ED2 90 05 B6         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003ED5 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003ED6 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003ED9 90 05 B6         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003EDC E0               [24]  221 	movx	a,@dptr
      003EDD 90 05 B5         [24]  222 	mov	dptr,#_first_failure_stage
      003EE0 F0               [24]  223 	movx	@dptr,a
      003EE1                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003EE1 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003EE3 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003EE4                        239 _ak820_nvm_diagnostic:
      003EE4 12 38 82         [24]  240 	lcall	_ak820_outline_0108
      003EE7 90 05 B7         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EEA 12 38 87         [24]  242 	lcall	_ak820_outline_0109
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003EED 90 05 B7         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003EF0 12 38 41         [24]  245 	lcall	_ak820_outline_0052
      003EF3 A2 0B            [12]  246 	mov	c,_storage_failed
      003EF5 E4               [12]  247 	clr	a
      003EF6 33               [12]  248 	rlc	a
      003EF7 12 38 8C         [24]  249 	lcall	_ak820_outline_0118
      003EFA 12 46 8B         [24]  250 	lcall	_ak820_outline_0071
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003EFD A3               [24]  252 	inc	dptr
      003EFE A2 09            [12]  253 	mov	c,_page_valid
      003F00 E4               [12]  254 	clr	a
      003F01 33               [12]  255 	rlc	a
      003F02 12 46 58         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003F05 A2 0A            [12]  258 	mov	c,_page_dirty
      003F07 E4               [12]  259 	clr	a
      003F08 33               [12]  260 	rlc	a
      003F09 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003F0A 74 03            [12]  263 	mov	a,#0x03
      003F0C 12 46 C4         [24]  264 	lcall	_ak820_outline_0160
      003F0F 90 05 B4         [24]  265 	mov	dptr,#_batch_depth
      003F12 E0               [24]  266 	movx	a,@dptr
      003F13 12 38 97         [24]  267 	lcall	_ak820_outline_0124
      003F16 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003F17 74 04            [12]  270 	mov	a,#0x04
      003F19 12 46 C4         [24]  271 	lcall	_ak820_outline_0160
      003F1C 90 05 B3         [24]  272 	mov	dptr,#_cached_page
      003F1F E0               [24]  273 	movx	a,@dptr
      003F20 12 38 97         [24]  274 	lcall	_ak820_outline_0124
      003F23 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003F24 12 46 4E         [24]  277 	lcall	_ak820_outline_0012
      003F27 E4               [12]  278 	clr	a
      003F28 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003F29 74 06            [12]  281 	mov	a,#0x06
      003F2B 12 46 AE         [24]  282 	lcall	_ak820_outline_0137
      003F2E 90 05 B5         [24]  283 	mov	dptr,#_first_failure_stage
      003F31 E0               [24]  284 	movx	a,@dptr
      003F32 12 38 8C         [24]  285 	lcall	_ak820_outline_0118
      003F35 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003F36 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003F37                        300 _crc_byte:
      003F37 12 38 82         [24]  301 	lcall	_ak820_outline_0108
      003F3A 90 05 BA         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003F3D 12 38 87         [24]  303 	lcall	_ak820_outline_0109
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003F40 90 05 B9         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003F43 E0               [24]  306 	movx	a,@dptr
      003F44 FF               [12]  307 	mov	r7,a
      003F45 7E 00            [12]  308 	mov	r6,#0x00
      003F47 90 05 BA         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003F4A E0               [24]  310 	movx	a,@dptr
      003F4B 6E               [12]  311 	xrl	a,r6
      003F4C F0               [24]  312 	movx	@dptr,a
      003F4D A3               [24]  313 	inc	dptr
      003F4E E0               [24]  314 	movx	a,@dptr
      003F4F 6F               [12]  315 	xrl	a,r7
      003F50 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F51 7F 00            [12]  318 	mov	r7,#0x00
      003F53                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003F53 90 05 BA         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003F56 12 38 64         [24]  322 	lcall	_ak820_outline_0079
      003F59 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003F5C ED               [12]  324 	mov	a,r5
      003F5D 2D               [12]  325 	add	a,r5
      003F5E FB               [12]  326 	mov	r3,a
      003F5F EE               [12]  327 	mov	a,r6
      003F60 33               [12]  328 	rlc	a
      003F61 FC               [12]  329 	mov	r4,a
      003F62 63 03 21         [24]  330 	xrl	ar3,#0x21
      003F65 63 04 10         [24]  331 	xrl	ar4,#0x10
      003F68 80 06            [24]  332 	sjmp	00107$
      003F6A                        333 00106$:
      003F6A ED               [12]  334 	mov	a,r5
      003F6B 2D               [12]  335 	add	a,r5
      003F6C FB               [12]  336 	mov	r3,a
      003F6D EE               [12]  337 	mov	a,r6
      003F6E 33               [12]  338 	rlc	a
      003F6F FC               [12]  339 	mov	r4,a
      003F70                        340 00107$:
      003F70 90 05 BA         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003F73 12 38 6A         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003F76 0F               [12]  344 	inc	r7
      003F77 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003F7A 12 33 FC         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003F7D 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003F7E                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003F7E 90 05 BC         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003F81 74 FF            [12]  363 	mov	a,#0xff
      003F83 F0               [24]  364 	movx	@dptr,a
      003F84 A3               [24]  365 	inc	dptr
      003F85 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003F86 7F 00            [12]  368 	mov	r7,#0x00
      003F88                        369 00102$:
      003F88 90 05 BC         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003F8B 12 38 64         [24]  371 	lcall	_ak820_outline_0079
      003F8E 12 46 9D         [24]  372 	lcall	_ak820_outline_0106
      003F91 90 05 B9         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003F94 F0               [24]  374 	movx	@dptr,a
      003F95 12 38 A1         [24]  375 	lcall	_ak820_outline_0135
      003F98 C0 07            [24]  376 	push	ar7
      003F9A 12 3F 37         [24]  377 	lcall	_crc_byte
      003F9D AD 82            [24]  378 	mov	r5, dpl
      003F9F AE 83            [24]  379 	mov	r6, dph
      003FA1 D0 07            [24]  380 	pop	ar7
      003FA3 90 05 BC         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003FA6 12 46 CA         [24]  382 	lcall	_ak820_outline_0161
      003FA9 0F               [12]  383 	inc	r7
      003FAA BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003FAD 12 38 A1         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003FB0 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003FB1                        399 _write_page:
      003FB1 12 38 82         [24]  400 	lcall	_ak820_outline_0108
      003FB4 90 05 BE         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003FB7 12 38 87         [24]  402 	lcall	_ak820_outline_0109
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003FBA 90 05 BE         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003FBD 12 37 F4         [24]  405 	lcall	_ak820_outline_0005
      003FC0 C0 07            [24]  406 	push	ar7
      003FC2 C0 06            [24]  407 	push	ar6
      003FC4 12 3D 49         [24]  408 	lcall	_ak820_flash_erase
      003FC7 E5 82            [12]  409 	mov	a, dpl
      003FC9 D0 06            [24]  410 	pop	ar6
      003FCB D0 07            [24]  411 	pop	ar7
      003FCD 70 03            [24]  412 	jnz	00102$
      003FCF F5 82            [12]  413 	mov	dpl,a
      003FD1 22               [24]  414 	ret
      003FD2                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003FD2 90 05 4F         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003FD5 74 73            [12]  418 	mov	a,#_page_data
      003FD7 F0               [24]  419 	movx	@dptr,a
      003FD8 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003FDA A3               [24]  421 	inc	dptr
      003FDB 12 46 8B         [24]  422 	lcall	_ak820_outline_0071
      003FDE 12 3E 5D         [24]  423 	lcall	_ak820_flash_program_page
      003FE1 E5 82            [12]  424 	mov	a, dpl
      003FE3 70 03            [24]  425 	jnz	00120$
      003FE5 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FE7 22               [24]  428 	ret
      003FE8                        429 00120$:
      003FE8 7F 00            [12]  430 	mov	r7,#0x00
      003FEA                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003FEA 8F 05            [24]  433 	mov	ar5,r7
      003FEC 7E 00            [12]  434 	mov	r6,#0x00
      003FEE 90 05 BE         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003FF1 12 38 91         [24]  436 	lcall	_ak820_outline_0123
      003FF4 ED               [12]  437 	mov	a,r5
      003FF5 2B               [12]  438 	add	a, r3
      003FF6 FB               [12]  439 	mov	r3,a
      003FF7 EE               [12]  440 	mov	a,r6
      003FF8 3C               [12]  441 	addc	a, r4
      003FF9 FC               [12]  442 	mov	r4,a
      003FFA 12 33 FC         [24]  443 	lcall	_ak820_outline_0121
      003FFD 12 3C 3C         [24]  444 	lcall	_ak820_flash_read
      004000 AE 82            [24]  445 	mov	r6, dpl
      004002 12 46 9D         [24]  446 	lcall	_ak820_outline_0106
      004005 FD               [12]  447 	mov	r5,a
      004006 EE               [12]  448 	mov	a,r6
      004007 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      00400A 80 04            [24]  450 	sjmp	00109$
      00400C                        451 00149$:
      00400C 75 82 00         [24]  452 	mov	dpl, #0x00
      00400F 22               [24]  453 	ret
      004010                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004010 0F               [12]  456 	inc	r7
      004011 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      004014 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      004017 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      004018                        472 _journal_header_valid:
      004018 12 38 82         [24]  473 	lcall	_ak820_outline_0108
      00401B 90 05 C0         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      00401E 12 38 87         [24]  475 	lcall	_ak820_outline_0109
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      004021 90 05 C0         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      004024 12 37 F4         [24]  478 	lcall	_ak820_outline_0005
      004027 E0               [24]  479 	movx	a,@dptr
      004028 FD               [12]  480 	mov	r5,a
      004029 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      00402C 80 04            [24]  482 	sjmp	00116$
      00402E                        483 00138$:
      00402E 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004031 22               [24]  486 	ret
      004032                        487 00116$:
      004032 7D 01            [12]  488 	mov	r5,#0x01
      004034                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      004034 ED               [12]  491 	mov	a,r5
      004035 12 38 31         [24]  492 	lcall	_ak820_outline_0022
      004038 E0               [24]  493 	movx	a,@dptr
      004039 FC               [12]  494 	mov	r4,a
      00403A 8D 02            [24]  495 	mov	ar2,r5
      00403C 7B 00            [12]  496 	mov	r3,#0x00
      00403E 74 04            [12]  497 	mov	a,#0x04
      004040 2A               [12]  498 	add	a, r2
      004041 FA               [12]  499 	mov	r2,a
      004042 E4               [12]  500 	clr	a
      004043 3B               [12]  501 	addc	a, r3
      004044 FB               [12]  502 	mov	r3,a
      004045 EA               [12]  503 	mov	a,r2
      004046 2E               [12]  504 	add	a, r6
      004047 F5 82            [12]  505 	mov	dpl,a
      004049 EB               [12]  506 	mov	a,r3
      00404A 3F               [12]  507 	addc	a, r7
      00404B F5 83            [12]  508 	mov	dph,a
      00404D E0               [24]  509 	movx	a,@dptr
      00404E 62 04            [12]  510 	xrl	ar4,a
      004050 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      004053 80 04            [24]  512 	sjmp	00107$
      004055                        513 00139$:
      004055 75 82 00         [24]  514 	mov	dpl, #0x00
      004058 22               [24]  515 	ret
      004059                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004059 0D               [12]  518 	inc	r5
      00405A BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      00405D 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      004060 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      004061                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      004061 7F 00            [12]  538 	mov	r7,#0x00
      004063                        539 00115$:
      004063 EF               [12]  540 	mov	a,r7
      004064 24 C2            [12]  541 	add	a, #_recover_journal_header_10000_46
      004066 FD               [12]  542 	mov	r5,a
      004067 E4               [12]  543 	clr	a
      004068 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      00406A FE               [12]  545 	mov	r6,a
      00406B 8F 04            [24]  546 	mov	ar4,r7
      00406D 7B 00            [12]  547 	mov	r3,#0x00
      00406F 74 40            [12]  548 	mov	a,#0x40
      004071 2C               [12]  549 	add	a, r4
      004072 FC               [12]  550 	mov	r4,a
      004073 74 EF            [12]  551 	mov	a,#0xef
      004075 3B               [12]  552 	addc	a, r3
      004076 FB               [12]  553 	mov	r3,a
      004077 12 46 D5         [24]  554 	lcall	_ak820_outline_0183
      00407A 12 3C 3C         [24]  555 	lcall	_ak820_flash_read
      00407D AC 82            [24]  556 	mov	r4, dpl
      00407F 12 46 84         [24]  557 	lcall	_ak820_outline_0063
      004082 0F               [12]  558 	inc	r7
      004083 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      004086 90 05 C2         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      004089 12 40 18         [24]  562 	lcall	_journal_header_valid
      00408C E5 82            [12]  563 	mov	a, dpl
      00408E 70 01            [24]  564 	jnz	00103$
      004090 22               [24]  565 	ret
      004091                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      004091 90 05 C3         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      004094 E0               [24]  569 	movx	a,@dptr
      004095 FF               [12]  570 	mov	r7,a
      004096 7E 00            [12]  571 	mov	r6,#0x00
      004098 90 05 C4         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      00409B E0               [24]  573 	movx	a,@dptr
      00409C FC               [12]  574 	mov	r4,a
      00409D E4               [12]  575 	clr	a
      00409E 42 07            [12]  576 	orl	ar7,a
      0040A0 EC               [12]  577 	mov	a,r4
      0040A1 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      0040A3 90 05 C5         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      0040A6 E0               [24]  581 	movx	a,@dptr
      0040A7 FD               [12]  582 	mov	r5,a
      0040A8 7C 00            [12]  583 	mov	r4,#0x00
      0040AA 90 05 C6         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      0040AD E0               [24]  585 	movx	a,@dptr
      0040AE FA               [12]  586 	mov	r2,a
      0040AF E4               [12]  587 	clr	a
      0040B0 12 46 B4         [24]  588 	lcall	_ak820_outline_0142
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      0040B3 C3               [12]  590 	clr	c
      0040B4 EF               [12]  591 	mov	a,r7
      0040B5 94 A0            [12]  592 	subb	a,#0xa0
      0040B7 EE               [12]  593 	mov	a,r6
      0040B8 94 00            [12]  594 	subb	a,#0x00
      0040BA 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      0040BC 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      0040BF 02 3E D0         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      0040C2                        601 00134$:
      0040C2 7B 00            [12]  602 	mov	r3,#0x00
      0040C4                        603 00117$:
      0040C4 C0 05            [24]  604 	push	ar5
      0040C6 C0 04            [24]  605 	push	ar4
      0040C8 EB               [12]  606 	mov	a,r3
      0040C9 24 73            [12]  607 	add	a, #_page_data
      0040CB F9               [12]  608 	mov	r1,a
      0040CC E4               [12]  609 	clr	a
      0040CD 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      0040CF FA               [12]  611 	mov	r2,a
      0040D0 8B 00            [24]  612 	mov	ar0,r3
      0040D2 7D 00            [12]  613 	mov	r5,#0x00
      0040D4 74 EF            [12]  614 	mov	a,#0xef
      0040D6 2D               [12]  615 	add	a, r5
      0040D7 FD               [12]  616 	mov	r5,a
      0040D8 88 82            [24]  617 	mov	dpl, r0
      0040DA 8D 83            [24]  618 	mov	dph, r5
      0040DC 12 3C 3C         [24]  619 	lcall	_ak820_flash_read
      0040DF AD 82            [24]  620 	mov	r5, dpl
      0040E1 12 46 D0         [24]  621 	lcall	_ak820_outline_0182
      0040E4 ED               [12]  622 	mov	a,r5
      0040E5 F0               [24]  623 	movx	@dptr,a
      0040E6 0B               [12]  624 	inc	r3
      0040E7 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      0040EA 80 06            [24]  626 	sjmp	00191$
      0040EC                        627 00190$:
      0040EC D0 04            [24]  628 	pop	ar4
      0040EE D0 05            [24]  629 	pop	ar5
      0040F0 80 D2            [24]  630 	sjmp	00117$
      0040F2                        631 00191$:
      0040F2 D0 04            [24]  632 	pop	ar4
      0040F4 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      0040F6 C0 07            [24]  635 	push	ar7
      0040F8 C0 06            [24]  636 	push	ar6
      0040FA C0 05            [24]  637 	push	ar5
      0040FC C0 04            [24]  638 	push	ar4
      0040FE 12 3F 7E         [24]  639 	lcall	_page_crc
      004101 AA 82            [24]  640 	mov	r2, dpl
      004103 AB 83            [24]  641 	mov	r3, dph
      004105 D0 04            [24]  642 	pop	ar4
      004107 D0 05            [24]  643 	pop	ar5
      004109 D0 06            [24]  644 	pop	ar6
      00410B D0 07            [24]  645 	pop	ar7
      00410D EA               [12]  646 	mov	a,r2
      00410E B5 05 06         [24]  647 	cjne	a,ar5,00192$
      004111 EB               [12]  648 	mov	a,r3
      004112 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004115 80 06            [24]  650 	sjmp	00113$
      004117                        651 00192$:
      004117 75 82 02         [24]  652 	mov	dpl, #0x02
      00411A 02 3E D0         [24]  653 	ljmp	_nvm_fail
      00411D                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00411D EE               [12]  656 	mov	a,r6
      00411E 54 03            [12]  657 	anl	a,#0x03
      004120 A2 E0            [12]  658 	mov	c,acc.0
      004122 CF               [12]  659 	xch	a,r7
      004123 13               [12]  660 	rrc	a
      004124 CF               [12]  661 	xch	a,r7
      004125 13               [12]  662 	rrc	a
      004126 A2 E0            [12]  663 	mov	c,acc.0
      004128 CF               [12]  664 	xch	a,r7
      004129 13               [12]  665 	rrc	a
      00412A CF               [12]  666 	xch	a,r7
      00412B 13               [12]  667 	rrc	a
      00412C CF               [12]  668 	xch	a,r7
      00412D 24 C7            [12]  669 	add	a,#0xc7
      00412F FE               [12]  670 	mov	r6,a
      004130 12 46 BF         [24]  671 	lcall	_ak820_outline_0157
      004133 12 3F B1         [24]  672 	lcall	_write_page
      004136 E5 82            [12]  673 	mov	a, dpl
      004138 70 06            [24]  674 	jnz	00110$
      00413A 75 82 03         [24]  675 	mov	dpl, #0x03
      00413D 02 3E D0         [24]  676 	ljmp	_nvm_fail
      004140                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004140 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004143 12 3D 49         [24]  680 	lcall	_ak820_flash_erase
      004146 E5 82            [12]  681 	mov	a, dpl
      004148 70 06            [24]  682 	jnz	00119$
      00414A 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00414D 02 3E D0         [24]  685 	ljmp	_nvm_fail
      004150                        686 00119$:
      004150 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      004151                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      004151 C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004153 90 05 B5         [24]  700 	mov	dptr,#_first_failure_stage
      004156 E4               [12]  701 	clr	a
      004157 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      004158 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      00415A C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00415C 90 05 B4         [24]  709 	mov	dptr,#_batch_depth
      00415F E4               [12]  710 	clr	a
      004160 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004161 12 40 61         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004164 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      004167                        724 _ak820_nvm_ok:
      004167 A2 0B            [12]  725 	mov	c,_storage_failed
      004169 B3               [12]  726 	cpl	c
      00416A 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00416C 12 38 B6         [24]  728 	lcall	_ak820_outline_0156
      00416F 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      004170                        737 _ak820_nvm_schema_fault:
      004170 75 82 10         [24]  738 	mov	dpl, #0x10
      004173 02 3E D0         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      004176                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004176 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      004179 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      00417C                        756 00101$:
      00417C 22               [24]  757 	ret
      00417D                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00417D 12 3F 7E         [24]  760 	lcall	_page_crc
      004180 12 46 A9         [24]  761 	lcall	_ak820_outline_0125
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004183 90 05 CB         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004186 74 A5            [12]  764 	mov	a,#0xa5
      004188 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004189 90 05 B3         [24]  767 	mov	dptr,#_cached_page
      00418C E0               [24]  768 	movx	a,@dptr
      00418D 90 05 CC         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      004190 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      004191 90 05 CD         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004194 E4               [12]  773 	clr	a
      004195 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004196 8E 05            [24]  776 	mov	ar5,r6
      004198 90 05 CE         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      00419B ED               [12]  778 	mov	a,r5
      00419C F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00419D 8F 06            [24]  781 	mov	ar6,r7
      00419F 90 05 CF         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0041A2 EE               [12]  783 	mov	a,r6
      0041A3 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0041A4 7F 01            [12]  786 	mov	r7,#0x01
      0041A6                        787 00128$:
      0041A6 8F 06            [24]  788 	mov	ar6,r7
      0041A8 EE               [12]  789 	mov	a,r6
      0041A9 24 04            [12]  790 	add	a,#0x04
      0041AB FE               [12]  791 	mov	r6,a
      0041AC 33               [12]  792 	rlc	a
      0041AD 95 E0            [12]  793 	subb	a,acc
      0041AF FD               [12]  794 	mov	r5,a
      0041B0 EE               [12]  795 	mov	a,r6
      0041B1 24 CB            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0041B3 FE               [12]  797 	mov	r6,a
      0041B4 ED               [12]  798 	mov	a,r5
      0041B5 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0041B7 FD               [12]  800 	mov	r5,a
      0041B8 12 46 67         [24]  801 	lcall	_ak820_outline_0043
      0041BB FC               [12]  802 	mov	r4,a
      0041BC 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0041BF 8E 82            [24]  804 	mov	dpl,r6
      0041C1 8D 83            [24]  805 	mov	dph,r5
      0041C3 EC               [12]  806 	mov	a,r4
      0041C4 F0               [24]  807 	movx	@dptr,a
      0041C5 0F               [12]  808 	inc	r7
      0041C6 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0041C9 90 05 D4         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041CC 74 05            [12]  812 	mov	a,#0x05
      0041CE F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041CF 90 EF 40         [24]  815 	mov	dptr,#0xef40
      0041D2 12 3D 49         [24]  816 	lcall	_ak820_flash_erase
      0041D5 E5 82            [12]  817 	mov	a, dpl
      0041D7 70 03            [24]  818 	jnz	00269$
      0041D9 02 42 C0         [24]  819 	ljmp	00127$
      0041DC                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      0041DC 90 05 D4         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041DF 74 06            [12]  823 	mov	a,#0x06
      0041E1 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041E2 7F 00            [12]  826 	mov	r7,#0x00
      0041E4                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0041E4 12 46 73         [24]  829 	lcall	_ak820_outline_0053
      0041E7 12 3C 3C         [24]  830 	lcall	_ak820_flash_read
      0041EA E5 82            [12]  831 	mov	a, dpl
      0041EC 60 03            [24]  832 	jz	00270$
      0041EE 02 42 C0         [24]  833 	ljmp	00127$
      0041F1                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0041F1 0F               [12]  836 	inc	r7
      0041F2 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0041F5 90 05 D4         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041F8 74 07            [12]  840 	mov	a,#0x07
      0041FA F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0041FB 90 EF 00         [24]  843 	mov	dptr,#0xef00
      0041FE 12 3F B1         [24]  844 	lcall	_write_page
      004201 E5 82            [12]  845 	mov	a, dpl
      004203 70 03            [24]  846 	jnz	00273$
      004205 02 42 C0         [24]  847 	ljmp	00127$
      004208                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004208 90 05 D4         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00420B 74 08            [12]  851 	mov	a,#0x08
      00420D F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00420E 7F 01            [12]  854 	mov	r7,#0x01
      004210                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004210 12 46 67         [24]  857 	lcall	_ak820_outline_0043
      004213 FE               [12]  858 	mov	r6,a
      004214 60 23            [24]  859 	jz	00133$
      004216 8F 05            [24]  860 	mov	ar5,r7
      004218 7C 00            [12]  861 	mov	r4,#0x00
      00421A 74 40            [12]  862 	mov	a,#0x40
      00421C 2D               [12]  863 	add	a, r5
      00421D FD               [12]  864 	mov	r5,a
      00421E 74 EF            [12]  865 	mov	a,#0xef
      004220 3C               [12]  866 	addc	a, r4
      004221 FC               [12]  867 	mov	r4,a
      004222 90 05 4C         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004225 EE               [12]  869 	mov	a,r6
      004226 F0               [24]  870 	movx	@dptr,a
      004227 8D 82            [24]  871 	mov	dpl, r5
      004229 8C 83            [24]  872 	mov	dph, r4
      00422B C0 07            [24]  873 	push	ar7
      00422D 12 3D A9         [24]  874 	lcall	_ak820_flash_program
      004230 E5 82            [12]  875 	mov	a, dpl
      004232 D0 07            [24]  876 	pop	ar7
      004234 70 03            [24]  877 	jnz	00275$
      004236 02 42 C0         [24]  878 	ljmp	00127$
      004239                        879 00275$:
      004239                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004239 0F               [12]  882 	inc	r7
      00423A BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00423D 90 05 D4         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004240 74 09            [12]  886 	mov	a,#0x09
      004242 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004243 7F 01            [12]  889 	mov	r7,#0x01
      004245                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004245 12 46 73         [24]  892 	lcall	_ak820_outline_0053
      004248 12 3C 3C         [24]  893 	lcall	_ak820_flash_read
      00424B AE 82            [24]  894 	mov	r6, dpl
      00424D 12 46 67         [24]  895 	lcall	_ak820_outline_0043
      004250 FD               [12]  896 	mov	r5,a
      004251 EE               [12]  897 	mov	a,r6
      004252 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004255 0F               [12]  900 	inc	r7
      004256 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004259 90 05 D4         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00425C 74 0A            [12]  904 	mov	a,#0x0a
      00425E F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00425F 90 05 CB         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004262 E0               [24]  908 	movx	a,@dptr
      004263 90 05 4C         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      004266 F0               [24]  910 	movx	@dptr,a
      004267 90 EF 40         [24]  911 	mov	dptr,#0xef40
      00426A 12 3D A9         [24]  912 	lcall	_ak820_flash_program
      00426D E5 82            [12]  913 	mov	a, dpl
      00426F 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004271 90 05 D4         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004274 74 0B            [12]  917 	mov	a,#0x0b
      004276 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004277 90 EF 40         [24]  920 	mov	dptr,#0xef40
      00427A 12 3C 3C         [24]  921 	lcall	_ak820_flash_read
      00427D AF 82            [24]  922 	mov	r7, dpl
      00427F 90 05 CB         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004282 E0               [24]  924 	movx	a,@dptr
      004283 FE               [12]  925 	mov	r6,a
      004284 EF               [12]  926 	mov	a,r7
      004285 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004288 90 05 D4         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00428B 74 0C            [12]  930 	mov	a,#0x0c
      00428D F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      00428E 90 05 B3         [24]  933 	mov	dptr,#_cached_page
      004291 E0               [24]  934 	movx	a,@dptr
      004292 FE               [12]  935 	mov	r6,a
      004293 E4               [12]  936 	clr	a
      004294 C3               [12]  937 	clr	c
      004295 CE               [12]  938 	xch	a,r6
      004296 13               [12]  939 	rrc	a
      004297 CE               [12]  940 	xch	a,r6
      004298 13               [12]  941 	rrc	a
      004299 A2 E0            [12]  942 	mov	c,acc.0
      00429B CE               [12]  943 	xch	a,r6
      00429C 13               [12]  944 	rrc	a
      00429D CE               [12]  945 	xch	a,r6
      00429E 13               [12]  946 	rrc	a
      00429F CE               [12]  947 	xch	a,r6
      0042A0 24 C7            [12]  948 	add	a,#0xc7
      0042A2 FF               [12]  949 	mov	r7,a
      0042A3 12 38 8C         [24]  950 	lcall	_ak820_outline_0118
      0042A6 12 3F B1         [24]  951 	lcall	_write_page
      0042A9 E5 82            [12]  952 	mov	a, dpl
      0042AB 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0042AD 90 05 D4         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0042B0 74 0D            [12]  956 	mov	a,#0x0d
      0042B2 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0042B3 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0042B6 12 3D 49         [24]  960 	lcall	_ak820_flash_erase
      0042B9 E5 82            [12]  961 	mov	a, dpl
      0042BB 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0042BD C2 0A            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0042BF 22               [24]  968 	ret
      0042C0                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0042C0 90 05 D4         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0042C3 E0               [24]  972 	movx	a,@dptr
      0042C4 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0042C6 02 3E D0         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0042C9                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0042C9 90 05 B4         [24]  985 	mov	dptr,#_batch_depth
      0042CC E0               [24]  986 	movx	a,@dptr
      0042CD FF               [12]  987 	mov	r7,a
      0042CE BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      0042D1 75 82 0F         [24]  989 	mov	dpl, #0x0f
      0042D4 02 3E D0         [24]  990 	ljmp	_nvm_fail
      0042D7                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0042D7 90 05 B4         [24]  993 	mov	dptr,#_batch_depth
      0042DA EF               [12]  994 	mov	a,r7
      0042DB 04               [12]  995 	inc	a
      0042DC F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      0042DD 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      0042DE                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      0042DE 90 05 B4         [24] 1008 	mov	dptr,#_batch_depth
      0042E1 E0               [24] 1009 	movx	a,@dptr
      0042E2 FF               [12] 1010 	mov	r7,a
      0042E3 E0               [24] 1011 	movx	a,@dptr
      0042E4 60 06            [24] 1012 	jz	00102$
      0042E6 EF               [12] 1013 	mov	a,r7
      0042E7 14               [12] 1014 	dec	a
      0042E8 90 05 B4         [24] 1015 	mov	dptr,#_batch_depth
      0042EB F0               [24] 1016 	movx	@dptr,a
      0042EC                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0042EC 90 05 B4         [24] 1019 	mov	dptr,#_batch_depth
      0042EF E0               [24] 1020 	movx	a,@dptr
      0042F0 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0042F2 02 41 76         [24] 1023 	ljmp	_ak820_nvm_flush
      0042F5                       1024 00105$:
      0042F5 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      0042F6                       1036 _load_page:
      0042F6 E5 82            [12] 1037 	mov	a,dpl
      0042F8 90 05 D5         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      0042FB F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0042FC 30 09 17         [24] 1041 	jnb	_page_valid,00102$
      0042FF 90 05 B3         [24] 1042 	mov	dptr,#_cached_page
      004302 E0               [24] 1043 	movx	a,@dptr
      004303 FF               [12] 1044 	mov	r7,a
      004304 90 05 D5         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      004307 E0               [24] 1046 	movx	a,@dptr
      004308 FE               [12] 1047 	mov	r6,a
      004309 EF               [12] 1048 	mov	a,r7
      00430A B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      00430D A2 0B            [12] 1050 	mov	c,_storage_failed
      00430F B3               [12] 1051 	cpl	c
      004310 92 0D            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004312 12 38 B6         [24] 1053 	lcall	_ak820_outline_0156
      004315 22               [24] 1054 	ret
      004316                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004316 12 41 76         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004319 30 0B 04         [24] 1059 	jnb	_storage_failed,00119$
      00431C 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00431F 22               [24] 1062 	ret
      004320                       1063 00119$:
      004320 7F 00            [12] 1064 	mov	r7,#0x00
      004322                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004322 EF               [12] 1067 	mov	a,r7
      004323 24 73            [12] 1068 	add	a, #_page_data
      004325 FD               [12] 1069 	mov	r5,a
      004326 E4               [12] 1070 	clr	a
      004327 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      004329 FE               [12] 1072 	mov	r6,a
      00432A 90 05 D5         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00432D E0               [24] 1074 	movx	a,@dptr
      00432E FC               [12] 1075 	mov	r4,a
      00432F FA               [12] 1076 	mov	r2,a
      004330 E4               [12] 1077 	clr	a
      004331 C3               [12] 1078 	clr	c
      004332 CA               [12] 1079 	xch	a,r2
      004333 13               [12] 1080 	rrc	a
      004334 CA               [12] 1081 	xch	a,r2
      004335 13               [12] 1082 	rrc	a
      004336 A2 E0            [12] 1083 	mov	c,acc.0
      004338 CA               [12] 1084 	xch	a,r2
      004339 13               [12] 1085 	rrc	a
      00433A CA               [12] 1086 	xch	a,r2
      00433B 13               [12] 1087 	rrc	a
      00433C CA               [12] 1088 	xch	a,r2
      00433D 24 C7            [12] 1089 	add	a,#0xc7
      00433F FB               [12] 1090 	mov	r3,a
      004340 8F 01            [24] 1091 	mov	ar1,r7
      004342 89 00            [24] 1092 	mov	ar0,r1
      004344 79 00            [12] 1093 	mov	r1,#0x00
      004346 E8               [12] 1094 	mov	a,r0
      004347 2A               [12] 1095 	add	a, r2
      004348 FA               [12] 1096 	mov	r2,a
      004349 E9               [12] 1097 	mov	a,r1
      00434A 3B               [12] 1098 	addc	a, r3
      00434B FB               [12] 1099 	mov	r3,a
      00434C 12 38 AC         [24] 1100 	lcall	_ak820_outline_0143
      00434F 12 3C 3C         [24] 1101 	lcall	_ak820_flash_read
      004352 AB 82            [24] 1102 	mov	r3, dpl
      004354 12 38 A1         [24] 1103 	lcall	_ak820_outline_0135
      004357 EB               [12] 1104 	mov	a,r3
      004358 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004359 0F               [12] 1107 	inc	r7
      00435A BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00435D 90 05 B3         [24] 1110 	mov	dptr,#_cached_page
      004360 EC               [12] 1111 	mov	a,r4
      004361 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004362 D2 09            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004364 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004367 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004368                       1129 _read_offset:
      004368 12 38 82         [24] 1130 	lcall	_ak820_outline_0108
      00436B 90 05 D6         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00436E 12 38 87         [24] 1132 	lcall	_ak820_outline_0109
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004371 90 05 D6         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004374 12 38 41         [24] 1135 	lcall	_ak820_outline_0052
      004377 C3               [12] 1136 	clr	c
      004378 94 28            [12] 1137 	subb	a,#0x28
      00437A 40 04            [24] 1138 	jc	00102$
      00437C 75 82 00         [24] 1139 	mov	dpl, #0x00
      00437F 22               [24] 1140 	ret
      004380                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004380 30 09 34         [24] 1143 	jnb	_page_valid,00104$
      004383 8E 04            [24] 1144 	mov	ar4,r6
      004385 EF               [12] 1145 	mov	a,r7
      004386 A2 E7            [12] 1146 	mov	c,acc.7
      004388 CC               [12] 1147 	xch	a,r4
      004389 33               [12] 1148 	rlc	a
      00438A CC               [12] 1149 	xch	a,r4
      00438B 33               [12] 1150 	rlc	a
      00438C A2 E7            [12] 1151 	mov	c,acc.7
      00438E CC               [12] 1152 	xch	a,r4
      00438F 33               [12] 1153 	rlc	a
      004390 CC               [12] 1154 	xch	a,r4
      004391 33               [12] 1155 	rlc	a
      004392 CC               [12] 1156 	xch	a,r4
      004393 54 03            [12] 1157 	anl	a,#0x03
      004395 FD               [12] 1158 	mov	r5,a
      004396 90 05 B3         [24] 1159 	mov	dptr,#_cached_page
      004399 E0               [24] 1160 	movx	a,@dptr
      00439A FA               [12] 1161 	mov	r2,a
      00439B 7B 00            [12] 1162 	mov	r3,#0x00
      00439D EC               [12] 1163 	mov	a,r4
      00439E B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0043A1 ED               [12] 1165 	mov	a,r5
      0043A2 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0043A5 74 3F            [12] 1168 	mov	a,#0x3f
      0043A7 5E               [12] 1169 	anl	a,r6
      0043A8 7D 00            [12] 1170 	mov	r5,#0x00
      0043AA 24 73            [12] 1171 	add	a, #_page_data
      0043AC F5 82            [12] 1172 	mov	dpl,a
      0043AE ED               [12] 1173 	mov	a,r5
      0043AF 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0043B1 F5 83            [12] 1175 	mov	dph,a
      0043B3 E0               [24] 1176 	movx	a,@dptr
      0043B4 F5 82            [12] 1177 	mov	dpl,a
      0043B6 22               [24] 1178 	ret
      0043B7                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0043B7 74 C7            [12] 1181 	mov	a,#0xc7
      0043B9 2F               [12] 1182 	add	a, r7
      0043BA FF               [12] 1183 	mov	r7,a
      0043BB 12 38 8C         [24] 1184 	lcall	_ak820_outline_0118
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0043BE 02 3C 3C         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0043C1                       1196 _eeprom_read_byte:
      0043C1 C0 07            [24] 1197 	push	ar7
      0043C3 C0 06            [24] 1198 	push	ar6
      0043C5 12 46 60         [24] 1199 	lcall	_ak820_outline_0037
      0043C8 90 05 D8         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0043CB 12 38 29         [24] 1201 	lcall	_ak820_outline_0017
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0043CE 90 05 D8         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0043D1 12 37 F4         [24] 1204 	lcall	_ak820_outline_0005
      0043D4 C0 06            [24] 1205 	push	ar6
      0043D6 C0 05            [24] 1206 	push	ar5
      0043D8 C0 04            [24] 1207 	push	ar4
      0043DA C0 03            [24] 1208 	push	ar3
      0043DC C0 02            [24] 1209 	push	ar2
      0043DE C0 01            [24] 1210 	push	ar1
      0043E0 C0 00            [24] 1211 	push	ar0
      0043E2 12 43 68         [24] 1212 	lcall	_read_offset
      0043E5 AF 82            [24] 1213 	mov	r7, dpl
      0043E7 D0 00            [24] 1214 	pop	ar0
      0043E9 D0 01            [24] 1215 	pop	ar1
      0043EB D0 02            [24] 1216 	pop	ar2
      0043ED D0 03            [24] 1217 	pop	ar3
      0043EF D0 04            [24] 1218 	pop	ar4
      0043F1 D0 05            [24] 1219 	pop	ar5
      0043F3 D0 06            [24] 1220 	pop	ar6
      0043F5 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0043F7 D0 06            [24] 1223 	pop	ar6
      0043F9 D0 07            [24] 1224 	pop	ar7
      0043FB 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0043FC                       1239 _ak820_eeprom_read_block_xdata:
      0043FC 12 38 82         [24] 1240 	lcall	_ak820_outline_0108
      0043FF 90 05 E0         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004402 12 38 87         [24] 1242 	lcall	_ak820_outline_0109
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004405 90 05 DB         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004408 12 38 41         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00440B 90 05 E0         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00440E 12 38 58         [24] 1248 	lcall	_ak820_outline_0059
      004411 90 05 E2         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004414 12 38 5E         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004417 90 05 DE         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00441A 12 38 58         [24] 1253 	lcall	_ak820_outline_0059
      00441D                       1254 00103$:
      00441D 8C 02            [24] 1255 	mov	ar2,r4
      00441F 8D 03            [24] 1256 	mov	ar3,r5
      004421 1C               [12] 1257 	dec	r4
      004422 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004425 1D               [12] 1259 	dec	r5
      004426                       1260 00130$:
      004426 EA               [12] 1261 	mov	a,r2
      004427 4B               [12] 1262 	orl	a,r3
      004428 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00442A 8E 02            [24] 1265 	mov	ar2,r6
      00442C 8F 03            [24] 1266 	mov	ar3,r7
      00442E 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004430 2B               [12] 1268 	add	a,r3
      004431 50 17            [24] 1269 	jnc	00102$
      004433 90 05 E2         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004436 12 46 97         [24] 1271 	lcall	_ak820_outline_0104
      004439 12 38 AC         [24] 1272 	lcall	_ak820_outline_0143
      00443C E4               [12] 1273 	clr	a
      00443D F0               [24] 1274 	movx	@dptr,a
      00443E 90 05 E2         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004441 04               [12] 1276 	inc	a
      004442 2A               [12] 1277 	add	a, r2
      004443 F0               [24] 1278 	movx	@dptr,a
      004444 E4               [12] 1279 	clr	a
      004445 3B               [12] 1280 	addc	a, r3
      004446 A3               [24] 1281 	inc	dptr
      004447 F0               [24] 1282 	movx	@dptr,a
      004448 80 D3            [24] 1283 	sjmp	00103$
      00444A                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00444A 90 05 E2         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00444D 12 46 97         [24] 1287 	lcall	_ak820_outline_0104
      004450 12 38 8C         [24] 1288 	lcall	_ak820_outline_0118
      004453 C0 07            [24] 1289 	push	ar7
      004455 C0 06            [24] 1290 	push	ar6
      004457 C0 05            [24] 1291 	push	ar5
      004459 C0 04            [24] 1292 	push	ar4
      00445B C0 03            [24] 1293 	push	ar3
      00445D C0 02            [24] 1294 	push	ar2
      00445F 12 43 68         [24] 1295 	lcall	_read_offset
      004462 A9 82            [24] 1296 	mov	r1, dpl
      004464 D0 02            [24] 1297 	pop	ar2
      004466 D0 03            [24] 1298 	pop	ar3
      004468 D0 04            [24] 1299 	pop	ar4
      00446A D0 05            [24] 1300 	pop	ar5
      00446C D0 06            [24] 1301 	pop	ar6
      00446E D0 07            [24] 1302 	pop	ar7
      004470 12 38 AC         [24] 1303 	lcall	_ak820_outline_0143
      004473 E9               [12] 1304 	mov	a,r1
      004474 F0               [24] 1305 	movx	@dptr,a
      004475 90 05 E2         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004478 74 01            [12] 1307 	mov	a,#0x01
      00447A 2A               [12] 1308 	add	a, r2
      00447B F0               [24] 1309 	movx	@dptr,a
      00447C E4               [12] 1310 	clr	a
      00447D 3B               [12] 1311 	addc	a, r3
      00447E A3               [24] 1312 	inc	dptr
      00447F F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004480 0E               [12] 1315 	inc	r6
      004481 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      004484 0F               [12] 1317 	inc	r7
      004485 80 96            [24] 1318 	sjmp	00103$
      004487                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004487 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      004488                       1337 _ak820_eeprom_write_block_xdata:
      004488 12 38 82         [24] 1338 	lcall	_ak820_outline_0108
      00448B 90 05 E9         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00448E 12 38 87         [24] 1340 	lcall	_ak820_outline_0109
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004491 90 05 E4         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004494 12 38 41         [24] 1343 	lcall	_ak820_outline_0052
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004497 90 05 E9         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00449A 12 38 58         [24] 1346 	lcall	_ak820_outline_0059
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00449D 8E 02            [24] 1348 	mov	ar2,r6
      00449F 8F 03            [24] 1349 	mov	ar3,r7
      0044A1 C3               [12] 1350 	clr	c
      0044A2 E4               [12] 1351 	clr	a
      0044A3 9A               [12] 1352 	subb	a,r2
      0044A4 74 28            [12] 1353 	mov	a,#0x28
      0044A6 9B               [12] 1354 	subb	a,r3
      0044A7 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0044A9 E4               [12] 1357 	clr	a
      0044AA C3               [12] 1358 	clr	c
      0044AB 9E               [12] 1359 	subb	a,r6
      0044AC FA               [12] 1360 	mov	r2,a
      0044AD 74 28            [12] 1361 	mov	a,#0x28
      0044AF 9F               [12] 1362 	subb	a,r7
      0044B0 FB               [12] 1363 	mov	r3,a
      0044B1 90 05 E7         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044B4 12 38 7C         [24] 1365 	lcall	_ak820_outline_0103
      0044B7 C3               [12] 1366 	clr	c
      0044B8 EA               [12] 1367 	mov	a,r2
      0044B9 98               [12] 1368 	subb	a,r0
      0044BA EB               [12] 1369 	mov	a,r3
      0044BB 99               [12] 1370 	subb	a,r1
      0044BC 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0044BE                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0044BE 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0044C1 02 3E D0         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0044C4                       1379 00125$:
      0044C4 90 05 E7         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044C7 12 46 97         [24] 1381 	lcall	_ak820_outline_0104
      0044CA                       1382 00108$:
      0044CA 8A 00            [24] 1383 	mov	ar0,r2
      0044CC 8B 01            [24] 1384 	mov	ar1,r3
      0044CE 1A               [12] 1385 	dec	r2
      0044CF BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      0044D2 1B               [12] 1387 	dec	r3
      0044D3                       1388 00159$:
      0044D3 E8               [12] 1389 	mov	a,r0
      0044D4 49               [12] 1390 	orl	a,r1
      0044D5 70 03            [24] 1391 	jnz	00160$
      0044D7 02 45 61         [24] 1392 	ljmp	00110$
      0044DA                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0044DA C0 02            [24] 1395 	push	ar2
      0044DC C0 03            [24] 1396 	push	ar3
      0044DE 12 46 91         [24] 1397 	lcall	_ak820_outline_0096
      0044E1 F9               [12] 1398 	mov	r1,a
      0044E2 A3               [24] 1399 	inc	dptr
      0044E3 12 46 BA         [24] 1400 	lcall	_ak820_outline_0149
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0044E6 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0044E8 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0044EA A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0044EC E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0044EE A2 E7            [12] 1406 	mov	c,acc.7
      0044F0 C8               [12] 1407 	xch	a,r0
      0044F1 33               [12] 1408 	rlc	a
      0044F2 C8               [12] 1409 	xch	a,r0
      0044F3 33               [12] 1410 	rlc	a
      0044F4 A2 E7            [12] 1411 	mov	c,acc.7
      0044F6 C8               [12] 1412 	xch	a,r0
      0044F7 33               [12] 1413 	rlc	a
      0044F8 C8               [12] 1414 	xch	a,r0
      0044F9 33               [12] 1415 	rlc	a
      0044FA C8               [12] 1416 	xch	a,r0
      0044FB 54 03            [12] 1417 	anl	a,#0x03
      0044FD FB               [12] 1418 	mov	r3,a
      0044FE 88 82            [24] 1419 	mov	dpl, r0
      004500 C0 07            [24] 1420 	push	ar7
      004502 C0 06            [24] 1421 	push	ar6
      004504 C0 05            [24] 1422 	push	ar5
      004506 C0 04            [24] 1423 	push	ar4
      004508 C0 03            [24] 1424 	push	ar3
      00450A C0 02            [24] 1425 	push	ar2
      00450C C0 01            [24] 1426 	push	ar1
      00450E 12 42 F6         [24] 1427 	lcall	_load_page
      004511 E5 82            [12] 1428 	mov	a, dpl
      004513 D0 01            [24] 1429 	pop	ar1
      004515 D0 02            [24] 1430 	pop	ar2
      004517 D0 03            [24] 1431 	pop	ar3
      004519 D0 04            [24] 1432 	pop	ar4
      00451B D0 05            [24] 1433 	pop	ar5
      00451D D0 06            [24] 1434 	pop	ar6
      00451F D0 07            [24] 1435 	pop	ar7
      004521 D0 03            [24] 1436 	pop	ar3
      004523 D0 02            [24] 1437 	pop	ar2
      004525 70 01            [24] 1438 	jnz	00105$
      004527 22               [24] 1439 	ret
      004528                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004528 C0 06            [24] 1442 	push	ar6
      00452A C0 07            [24] 1443 	push	ar7
      00452C 74 3F            [12] 1444 	mov	a,#0x3f
      00452E 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004530 7F 00            [12] 1446 	mov	r7,#0x00
      004532 24 73            [12] 1447 	add	a, #_page_data
      004534 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004536 EF               [12] 1449 	mov	a,r7
      004537 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      004539 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00453B 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00453E 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004541 E0               [24] 1454 	movx	a,@dptr
      004542 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004545 D0 07            [24] 1456 	pop	ar7
      004547 D0 06            [24] 1457 	pop	ar6
      004549 80 0E            [24] 1458 	sjmp	00107$
      00454B                       1459 00162$:
      00454B D0 07            [24] 1460 	pop	ar7
      00454D D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00454F 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004552 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004555 E9               [12] 1465 	mov	a,r1
      004556 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004557 D2 0A            [12] 1469 	setb	_page_dirty
      004559                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004559 0E               [12] 1472 	inc	r6
      00455A BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00455D 0F               [12] 1474 	inc	r7
      00455E                       1475 00163$:
      00455E 02 44 CA         [24] 1476 	ljmp	00108$
      004561                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004561 90 05 B4         [24] 1479 	mov	dptr,#_batch_depth
      004564 E0               [24] 1480 	movx	a,@dptr
      004565 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004567 02 41 76         [24] 1483 	ljmp	_ak820_nvm_flush
      00456A                       1484 00113$:
      00456A 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      00456B                       1503 _ak820_eeprom_update_block_xdata:
      00456B 12 38 82         [24] 1504 	lcall	_ak820_outline_0108
      00456E 90 05 F0         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004571 12 38 87         [24] 1506 	lcall	_ak820_outline_0109
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004574 90 05 F0         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004577 12 38 41         [24] 1509 	lcall	_ak820_outline_0052
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00457A 90 05 EB         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00457D E0               [24] 1512 	movx	a,@dptr
      00457E F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004580 A3               [24] 1514 	inc	dptr
      004581 E0               [24] 1515 	movx	a,@dptr
      004582 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004584 A3               [24] 1517 	inc	dptr
      004585 E0               [24] 1518 	movx	a,@dptr
      004586 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004588 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00458A AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00458C E4               [12] 1523 	clr	a
      00458D F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00458F F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004591                       1526 00105$:
      004591 90 05 EE         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004594 E0               [24] 1528 	movx	a,@dptr
      004595 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004597 A3               [24] 1530 	inc	dptr
      004598 E0               [24] 1531 	movx	a,@dptr
      004599 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00459B C3               [12] 1533 	clr	c
      00459C E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00459E 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0045A0 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045A2 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0045A4 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0045A6 89 00            [24] 1540 	mov	ar0,r1
      0045A8 8A 05            [24] 1541 	mov	ar5,r2
      0045AA E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045AC 28               [12] 1543 	add	a, r0
      0045AD F8               [12] 1544 	mov	r0,a
      0045AE E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045B0 3D               [12] 1546 	addc	a, r5
      0045B1 FD               [12] 1547 	mov	r5,a
      0045B2 88 82            [24] 1548 	mov	dpl, r0
      0045B4 8D 83            [24] 1549 	mov	dph, r5
      0045B6 C0 07            [24] 1550 	push	ar7
      0045B8 C0 06            [24] 1551 	push	ar6
      0045BA C0 02            [24] 1552 	push	ar2
      0045BC C0 01            [24] 1553 	push	ar1
      0045BE 12 43 68         [24] 1554 	lcall	_read_offset
      0045C1 AD 82            [24] 1555 	mov	r5, dpl
      0045C3 D0 01            [24] 1556 	pop	ar1
      0045C5 D0 02            [24] 1557 	pop	ar2
      0045C7 D0 06            [24] 1558 	pop	ar6
      0045C9 D0 07            [24] 1559 	pop	ar7
      0045CB E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0045CD 2E               [12] 1561 	add	a, r6
      0045CE F5 82            [12] 1562 	mov	dpl,a
      0045D0 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0045D2 3F               [12] 1564 	addc	a, r7
      0045D3 F5 83            [12] 1565 	mov	dph,a
      0045D5 E0               [24] 1566 	movx	a,@dptr
      0045D6 FC               [12] 1567 	mov	r4,a
      0045D7 ED               [12] 1568 	mov	a,r5
      0045D8 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      0045DB 80 27            [24] 1570 	sjmp	00106$
      0045DD                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0045DD 90 05 F0         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0045E0 E0               [24] 1574 	movx	a,@dptr
      0045E1 F8               [12] 1575 	mov	r0,a
      0045E2 A3               [24] 1576 	inc	dptr
      0045E3 E0               [24] 1577 	movx	a,@dptr
      0045E4 FD               [12] 1578 	mov	r5,a
      0045E5 90 05 E4         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0045E8 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0045EA F0               [24] 1581 	movx	@dptr,a
      0045EB E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0045ED A3               [24] 1583 	inc	dptr
      0045EE F0               [24] 1584 	movx	@dptr,a
      0045EF E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0045F1 A3               [24] 1586 	inc	dptr
      0045F2 F0               [24] 1587 	movx	@dptr,a
      0045F3 90 05 E7         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0045F6 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0045F8 F0               [24] 1590 	movx	@dptr,a
      0045F9 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0045FB A3               [24] 1592 	inc	dptr
      0045FC F0               [24] 1593 	movx	@dptr,a
      0045FD 88 82            [24] 1594 	mov	dpl, r0
      0045FF 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004601 02 44 88         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004604                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004604 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004606 E4               [12] 1601 	clr	a
      004607 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00460A 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00460C 80 83            [24] 1604 	sjmp	00105$
      00460E                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00460E 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      00460F                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00460F 12 41 76         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004612 7F 00            [12] 1622 	mov	r7,#0x00
      004614                       1623 00111$:
      004614 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      004617 22               [24] 1625 	ret
      004618                       1626 00165$:
      004618 20 0B 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00461B 8F 82            [24] 1629 	mov	dpl, r7
      00461D C0 07            [24] 1630 	push	ar7
      00461F 12 42 F6         [24] 1631 	lcall	_load_page
      004622 E5 82            [12] 1632 	mov	a, dpl
      004624 D0 07            [24] 1633 	pop	ar7
      004626 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004628 22               [24] 1636 	ret
      004629                       1637 00126$:
      004629 7E 00            [12] 1638 	mov	r6,#0x00
      00462B                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00462B EE               [12] 1641 	mov	a,r6
      00462C 24 73            [12] 1642 	add	a, #_page_data
      00462E FC               [12] 1643 	mov	r4,a
      00462F E4               [12] 1644 	clr	a
      004630 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004632 FD               [12] 1646 	mov	r5,a
      004633 12 46 91         [24] 1647 	lcall	_ak820_outline_0096
      004636 60 07            [24] 1648 	jz	00108$
      004638 12 38 97         [24] 1649 	lcall	_ak820_outline_0124
      00463B E4               [12] 1650 	clr	a
      00463C F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      00463D D2 0A            [12] 1653 	setb	_page_dirty
      00463F                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00463F 0E               [12] 1656 	inc	r6
      004640 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004643 C0 07            [24] 1659 	push	ar7
      004645 12 41 76         [24] 1660 	lcall	_ak820_nvm_flush
      004648 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00464A 0F               [12] 1663 	inc	r7
      00464B 80 C7            [24] 1664 	sjmp	00111$
      00464D                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00464D 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0012
                                   1676 	.globl _ak820_outline_0017
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0032
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0053
                                   1683 	.globl _ak820_outline_0059
                                   1684 	.globl _ak820_outline_0063
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0072
                                   1687 	.globl _ak820_outline_0079
                                   1688 	.globl _ak820_outline_0086
                                   1689 	.globl _ak820_outline_0096
                                   1690 	.globl _ak820_outline_0103
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0106
                                   1693 	.globl _ak820_outline_0108
                                   1694 	.globl _ak820_outline_0109
                                   1695 	.globl _ak820_outline_0118
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0123
                                   1698 	.globl _ak820_outline_0124
                                   1699 	.globl _ak820_outline_0125
                                   1700 	.globl _ak820_outline_0135
                                   1701 	.globl _ak820_outline_0137
                                   1702 	.globl _ak820_outline_0142
                                   1703 	.globl _ak820_outline_0143
                                   1704 	.globl _ak820_outline_0149
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0157
                                   1707 	.globl _ak820_outline_0160
                                   1708 	.globl _ak820_outline_0161
                                   1709 	.globl _ak820_outline_0182
                                   1710 	.globl _ak820_outline_0183
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0012
      00464E                       1714 _ak820_outline_0012:
      00464E 8E 82            [24] 1715 	mov	dpl,r6
      004650 8F 83            [24] 1716 	mov	dph,r7
      004652 A3               [24] 1717 	inc	dptr
      004653 A3               [24] 1718 	inc	dptr
      004654 A3               [24] 1719 	inc	dptr
      004655 A3               [24] 1720 	inc	dptr
      004656 A3               [24] 1721 	inc	dptr
      004657 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0032
      004658                       1726 _ak820_outline_0032:
      004658 F0               [24] 1727 	movx	@dptr,a
      004659 8E 82            [24] 1728 	mov	dpl,r6
      00465B 8F 83            [24] 1729 	mov	dph,r7
      00465D A3               [24] 1730 	inc	dptr
      00465E A3               [24] 1731 	inc	dptr
      00465F 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0037
      004660                       1736 _ak820_outline_0037:
      004660 AF F0            [24] 1737 	mov	r7,b
      004662 AE 83            [24] 1738 	mov	r6,dph
      004664 E5 82            [12] 1739 	mov	a,dpl
      004666 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      004667                       1744 _ak820_outline_0043:
      004667 EF               [12] 1745 	mov	a,r7
      004668 24 CB            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      00466A F5 82            [12] 1747 	mov	dpl,a
      00466C E4               [12] 1748 	clr	a
      00466D 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00466F F5 83            [12] 1750 	mov	dph,a
      004671 E0               [24] 1751 	movx	a,@dptr
      004672 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      004673                       1756 _ak820_outline_0053:
      004673 8F 06            [24] 1757 	mov	ar6,r7
      004675 7D 00            [12] 1758 	mov	r5,#0x00
      004677 74 40            [12] 1759 	mov	a,#0x40
      004679 2E               [12] 1760 	add	a,r6
      00467A FE               [12] 1761 	mov	r6,a
      00467B 74 EF            [12] 1762 	mov	a,#0xef
      00467D 3D               [12] 1763 	addc	a,r5
      00467E FD               [12] 1764 	mov	r5,a
      00467F 8E 82            [24] 1765 	mov	dpl,r6
      004681 8D 83            [24] 1766 	mov	dph,r5
      004683 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0063
      004684                       1771 _ak820_outline_0063:
      004684 8D 82            [24] 1772 	mov	dpl,r5
      004686 8E 83            [24] 1773 	mov	dph,r6
      004688 EC               [12] 1774 	mov	a,r4
      004689 F0               [24] 1775 	movx	@dptr,a
      00468A 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0071
      00468B                       1780 _ak820_outline_0071:
      00468B F0               [24] 1781 	movx	@dptr,a
      00468C 8E 82            [24] 1782 	mov	dpl,r6
      00468E 8F 83            [24] 1783 	mov	dph,r7
      004690 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0096
      004691                       1788 _ak820_outline_0096:
      004691 8C 82            [24] 1789 	mov	dpl,r4
      004693 8D 83            [24] 1790 	mov	dph,r5
      004695 E0               [24] 1791 	movx	a,@dptr
      004696 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0104
      004697                       1796 _ak820_outline_0104:
      004697 E0               [24] 1797 	movx	a,@dptr
      004698 FA               [12] 1798 	mov	r2,a
      004699 A3               [24] 1799 	inc	dptr
      00469A E0               [24] 1800 	movx	a,@dptr
      00469B FB               [12] 1801 	mov	r3,a
      00469C 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0106
      00469D                       1806 _ak820_outline_0106:
      00469D EF               [12] 1807 	mov	a,r7
      00469E 24 73            [12] 1808 	add	a,#_page_data
      0046A0 F5 82            [12] 1809 	mov	dpl,a
      0046A2 E4               [12] 1810 	clr	a
      0046A3 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0046A5 F5 83            [12] 1812 	mov	dph,a
      0046A7 E0               [24] 1813 	movx	a,@dptr
      0046A8 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0125
      0046A9                       1818 _ak820_outline_0125:
      0046A9 AE 82            [24] 1819 	mov	r6,dpl
      0046AB AF 83            [24] 1820 	mov	r7,dph
      0046AD 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0137
      0046AE                       1825 _ak820_outline_0137:
      0046AE 2E               [12] 1826 	add	a,r6
      0046AF FE               [12] 1827 	mov	r6,a
      0046B0 E4               [12] 1828 	clr	a
      0046B1 3F               [12] 1829 	addc	a,r7
      0046B2 FF               [12] 1830 	mov	r7,a
      0046B3 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0142
      0046B4                       1835 _ak820_outline_0142:
      0046B4 42 05            [12] 1836 	orl	ar5,a
      0046B6 EA               [12] 1837 	mov	a,r2
      0046B7 42 04            [12] 1838 	orl	ar4,a
      0046B9 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0149
      0046BA                       1843 _ak820_outline_0149:
      0046BA AC 82            [24] 1844 	mov	r4,dpl
      0046BC AD 83            [24] 1845 	mov	r5,dph
      0046BE 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0157
      0046BF                       1850 _ak820_outline_0157:
      0046BF 8F 82            [24] 1851 	mov	dpl,r7
      0046C1 8E 83            [24] 1852 	mov	dph,r6
      0046C3 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0160
      0046C4                       1857 _ak820_outline_0160:
      0046C4 2E               [12] 1858 	add	a,r6
      0046C5 FC               [12] 1859 	mov	r4,a
      0046C6 E4               [12] 1860 	clr	a
      0046C7 3F               [12] 1861 	addc	a,r7
      0046C8 FD               [12] 1862 	mov	r5,a
      0046C9 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0161
      0046CA                       1867 _ak820_outline_0161:
      0046CA ED               [12] 1868 	mov	a,r5
      0046CB F0               [24] 1869 	movx	@dptr,a
      0046CC EE               [12] 1870 	mov	a,r6
      0046CD A3               [24] 1871 	inc	dptr
      0046CE F0               [24] 1872 	movx	@dptr,a
      0046CF 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0182
      0046D0                       1877 _ak820_outline_0182:
      0046D0 89 82            [24] 1878 	mov	dpl,r1
      0046D2 8A 83            [24] 1879 	mov	dph,r2
      0046D4 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0183
      0046D5                       1884 _ak820_outline_0183:
      0046D5 8C 82            [24] 1885 	mov	dpl,r4
      0046D7 8B 83            [24] 1886 	mov	dph,r3
      0046D9 22               [24] 1887 	ret
