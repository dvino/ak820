                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_board
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_driver
                                     12 	.globl _ak820_rgb_slots
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_set_slot_rgb_PARM_4
                                    257 	.globl _ak820_set_slot_rgb_PARM_3
                                    258 	.globl _ak820_set_slot_rgb_PARM_2
                                    259 	.globl _ak820_scan_sample
                                    260 	.globl _ak820_scan_ready
                                    261 	.globl _ak820_scan_rows
                                    262 	.globl _ak820_led_dma
                                    263 	.globl _ak820_clock_init
                                    264 	.globl _ak820_board_init
                                    265 	.globl _ak820_led_irq
                                    266 	.globl _ak820_matrix_snapshot
                                    267 	.globl _ak820_set_slot_rgb
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 	.area	OSEG    (OVR,DATA)
      000058                        534 _ak820_set_slot_rgb_sloc0_1_0:
      000058                        535 	.ds 1
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
                           000200   557 _ak820_led_dma	=	0x0200
      000400                        558 _ak820_scan_rows::
      000400                        559 	.ds 16
      000410                        560 _ak820_scan_ready::
      000410                        561 	.ds 1
      000411                        562 _ak820_scan_sample::
      000411                        563 	.ds 1
      000412                        564 _ak820_matrix_snapshot_rows_10000_60:
      000412                        565 	.ds 3
      000415                        566 _ak820_matrix_snapshot_changed_10000_61:
      000415                        567 	.ds 1
      000416                        568 _ak820_set_slot_rgb_PARM_2:
      000416                        569 	.ds 1
      000417                        570 _ak820_set_slot_rgb_PARM_3:
      000417                        571 	.ds 1
      000418                        572 _ak820_set_slot_rgb_PARM_4:
      000418                        573 	.ds 1
      000419                        574 _ak820_set_slot_rgb_slot_10000_70:
      000419                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; absolute external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XABS    (ABS,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; initialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XISEG   (XDATA)
                                    584 	.area HOME    (CODE)
                                    585 	.area GSINIT0 (CODE)
                                    586 	.area GSINIT1 (CODE)
                                    587 	.area GSINIT2 (CODE)
                                    588 	.area GSINIT3 (CODE)
                                    589 	.area GSINIT4 (CODE)
                                    590 	.area GSINIT5 (CODE)
                                    591 	.area GSINIT  (CODE)
                                    592 	.area GSFINAL (CODE)
                                    593 	.area CSEG    (CODE)
                                    594 ;--------------------------------------------------------
                                    595 ; global & static initialisations
                                    596 ;--------------------------------------------------------
                                    597 	.area HOME    (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 	.area GSFINAL (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 ;--------------------------------------------------------
                                    602 ; Home
                                    603 ;--------------------------------------------------------
                                    604 	.area HOME    (CODE)
                                    605 	.area HOME    (CODE)
                                    606 ;--------------------------------------------------------
                                    607 ; code
                                    608 ;--------------------------------------------------------
                                    609 	.area CSEG    (CODE)
                                    610 ;------------------------------------------------------------
                                    611 ;Allocation info for local variables in function 'ak820_clock_init'
                                    612 ;------------------------------------------------------------
                                    613 ;	keyboards/ajazz/ak820/ak820_board.c:40: void ak820_clock_init(void) __naked {
                                    614 ;	-----------------------------------------
                                    615 ;	 function ak820_clock_init
                                    616 ;	-----------------------------------------
      003164                        617 _ak820_clock_init:
                                    618 ;	naked function: no prologue.
                                    619 ;	keyboards/ajazz/ak820/ak820_board.c:55: __endasm;
      003164 75 A1 55         [24]  620 	mov 0xa1, #0x55
      003167 75 A1 AA         [24]  621 	mov 0xa1, #0xaa
      00316A 43 B9 80         [24]  622 	orl 0xb9, #0x80
      00316D 53 B9 BF         [24]  623 	anl 0xb9, #0xbf
      003170 75 A1 55         [24]  624 	mov 0xa1, #0x55
      003173 75 A1 AA         [24]  625 	mov 0xa1, #0xaa
      003176 E5 B9            [12]  626 	mov a, 0xb9
      003178 54 F8            [12]  627 	anl a, #0xf8
      00317A 44 06            [12]  628 	orl a, #0x06
      00317C F5 B9            [12]  629 	mov 0xb9, a
      00317E E4               [12]  630 	clr a
      00317F F5 A1            [12]  631 	mov 0xa1, a
      003181 22               [24]  632 	ret
                                    633 ;	keyboards/ajazz/ak820/ak820_board.c:56: }
                                    634 ;	naked function: no epilogue.
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'ak820_board_init'
                                    637 ;------------------------------------------------------------
                                    638 ;i             Allocated with name '_ak820_board_init_i_10000_53'
                                    639 ;------------------------------------------------------------
                                    640 ;	keyboards/ajazz/ak820/ak820_board.c:58: void ak820_board_init(void) {
                                    641 ;	-----------------------------------------
                                    642 ;	 function ak820_board_init
                                    643 ;	-----------------------------------------
      003182                        644 _ak820_board_init:
                           000007   645 	ar7 = 0x07
                           000006   646 	ar6 = 0x06
                           000005   647 	ar5 = 0x05
                           000004   648 	ar4 = 0x04
                           000003   649 	ar3 = 0x03
                           000002   650 	ar2 = 0x02
                           000001   651 	ar1 = 0x01
                           000000   652 	ar0 = 0x00
                                    653 ;	keyboards/ajazz/ak820/ak820_board.c:61: IE_PWM_I2C = 0;
                                    654 ;	assignBit
      003182 C2 ED            [12]  655 	clr	_IE_PWM_I2C
                                    656 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      003184 7E 00            [12]  657 	mov	r6,#0x00
      003186 7F 00            [12]  658 	mov	r7,#0x00
      003188                        659 00103$:
                                    660 ;	keyboards/ajazz/ak820/ak820_board.c:63: ak820_led_dma[i] = 0;
      003188 8E 82            [24]  661 	mov	dpl,r6
      00318A 74 02            [12]  662 	mov	a,#(_ak820_led_dma >> 8)
      00318C 2F               [12]  663 	add	a,r7
      00318D F5 83            [12]  664 	mov	dph,a
      00318F E4               [12]  665 	clr	a
      003190 F0               [24]  666 	movx	@dptr,a
                                    667 ;	keyboards/ajazz/ak820/ak820_board.c:62: for (i = 0; i < AK820_LED_DMA_BYTES; ++i) {
      003191 0E               [12]  668 	inc	r6
      003192 BE 00 01         [24]  669 	cjne	r6,#0x00,00139$
      003195 0F               [12]  670 	inc	r7
      003196                        671 00139$:
      003196 8E 04            [24]  672 	mov	ar4,r6
      003198 8F 05            [24]  673 	mov	ar5,r7
      00319A 74 FE            [12]  674 	mov	a,#0x100 - 0x02
      00319C 2D               [12]  675 	add	a,r5
      00319D 50 E9            [24]  676 	jnc	00103$
                                    677 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      00319F 7E 00            [12]  678 	mov	r6,#0x00
      0031A1 7F 00            [12]  679 	mov	r7,#0x00
      0031A3                        680 00105$:
                                    681 ;	keyboards/ajazz/ak820/ak820_board.c:66: ak820_scan_rows[i] = 0;
      0031A3 EE               [12]  682 	mov	a,r6
      0031A4 24 00            [12]  683 	add	a, #_ak820_scan_rows
      0031A6 F5 82            [12]  684 	mov	dpl,a
      0031A8 EF               [12]  685 	mov	a,r7
      0031A9 34 04            [12]  686 	addc	a, #(_ak820_scan_rows >> 8)
      0031AB F5 83            [12]  687 	mov	dph,a
      0031AD E4               [12]  688 	clr	a
      0031AE F0               [24]  689 	movx	@dptr,a
                                    690 ;	keyboards/ajazz/ak820/ak820_board.c:65: for (i = 0; i < AK820_SCAN_ROWS; ++i) {
      0031AF 0E               [12]  691 	inc	r6
      0031B0 BE 00 01         [24]  692 	cjne	r6,#0x00,00141$
      0031B3 0F               [12]  693 	inc	r7
      0031B4                        694 00141$:
      0031B4 8E 04            [24]  695 	mov	ar4,r6
      0031B6 8F 05            [24]  696 	mov	ar5,r7
      0031B8 C3               [12]  697 	clr	c
      0031B9 EC               [12]  698 	mov	a,r4
      0031BA 94 10            [12]  699 	subb	a,#0x10
      0031BC ED               [12]  700 	mov	a,r5
      0031BD 94 00            [12]  701 	subb	a,#0x00
      0031BF 40 E2            [24]  702 	jc	00105$
                                    703 ;	keyboards/ajazz/ak820/ak820_board.c:68: ak820_scan_ready  = 0;
      0031C1 90 04 10         [24]  704 	mov	dptr,#_ak820_scan_ready
      0031C4 E4               [12]  705 	clr	a
      0031C5 F0               [24]  706 	movx	@dptr,a
                                    707 ;	keyboards/ajazz/ak820/ak820_board.c:69: ak820_scan_sample = 0;
      0031C6 90 04 11         [24]  708 	mov	dptr,#_ak820_scan_sample
      0031C9 F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_board.c:72: P4 = P2 = P1 = P3 = P0 = 0xff;
      0031CA 75 80 FF         [24]  711 	mov	_P0,#0xff
      0031CD 75 B0 FF         [24]  712 	mov	_P3,#0xff
      0031D0 75 90 FF         [24]  713 	mov	_P1,#0xff
      0031D3 75 A0 FF         [24]  714 	mov	_P2,#0xff
      0031D6 75 C0 FF         [24]  715 	mov	_P4,#0xff
                                    716 ;	keyboards/ajazz/ak820/ak820_board.c:73: P1_MOD_OC = P2_MOD_OC = P4_MOD_OC = P3_MOD_OC = P0_MOD_OC = 0;
      0031D9 F5 C4            [12]  717 	mov	_P0_MOD_OC,a
      0031DB F5 96            [12]  718 	mov	_P3_MOD_OC,a
      0031DD F5 C2            [12]  719 	mov	_P4_MOD_OC,a
      0031DF F5 94            [12]  720 	mov	_P2_MOD_OC,a
      0031E1 F5 92            [12]  721 	mov	_P1_MOD_OC,a
                                    722 ;	keyboards/ajazz/ak820/ak820_board.c:75: LED_CTRL    = 0x01;
      0031E3 90 21 D1         [24]  723 	mov	dptr,#0x21d1
      0031E6 04               [12]  724 	inc	a
      0031E7 F0               [24]  725 	movx	@dptr,a
                                    726 ;	keyboards/ajazz/ak820/ak820_board.c:76: LED_CYCLE   = 0x30;
      0031E8 A3               [24]  727 	inc	dptr
      0031E9 74 30            [12]  728 	mov	a,#0x30
      0031EB F0               [24]  729 	movx	@dptr,a
                                    730 ;	keyboards/ajazz/ak820/ak820_board.c:77: LED_FRAME   = 0x50;
      0031EC A3               [24]  731 	inc	dptr
      0031ED 74 50            [12]  732 	mov	a,#0x50
      0031EF F0               [24]  733 	movx	@dptr,a
                                    734 ;	keyboards/ajazz/ak820/ak820_board.c:78: LED_DMA_H   = AK820_LED_DMA_ADDRESS >> 8;
      0031F0 75 C7 02         [24]  735 	mov	_LED_DMA_H,#0x02
                                    736 ;	keyboards/ajazz/ak820/ak820_board.c:79: LED_DMA_L   = AK820_LED_DMA_ADDRESS & 0xff;
      0031F3 75 C6 00         [24]  737 	mov	_LED_DMA_L,#0x00
                                    738 ;	keyboards/ajazz/ak820/ak820_board.c:80: LED_INT_ADJ = 0;
      0031F6 90 21 D8         [24]  739 	mov	dptr,#0x21d8
      0031F9 E4               [12]  740 	clr	a
      0031FA F0               [24]  741 	movx	@dptr,a
                                    742 ;	keyboards/ajazz/ak820/ak820_board.c:81: LED_PWM_OE  = 0xff;
      0031FB 75 A7 FF         [24]  743 	mov	_LED_PWM_OE,#0xff
                                    744 ;	keyboards/ajazz/ak820/ak820_board.c:82: LED_COMMON  = 0xff;
      0031FE 75 A6 FF         [24]  745 	mov	_LED_COMMON,#0xff
                                    746 ;	keyboards/ajazz/ak820/ak820_board.c:83: LED_CTRL    = 0xfd;
      003201 90 21 D1         [24]  747 	mov	dptr,#0x21d1
      003204 74 FD            [12]  748 	mov	a,#0xfd
      003206 F0               [24]  749 	movx	@dptr,a
                                    750 ;	keyboards/ajazz/ak820/ak820_board.c:86: P7 = 0x03;
      003207 75 F1 03         [24]  751 	mov	_P7,#0x03
                                    752 ;	keyboards/ajazz/ak820/ak820_board.c:88: LED_STATUS |= 0x40;
      00320A 43 F7 40         [24]  753 	orl	_LED_STATUS,#0x40
                                    754 ;	keyboards/ajazz/ak820/ak820_board.c:89: IE_PWM_I2C = 1;
                                    755 ;	assignBit
      00320D D2 ED            [12]  756 	setb	_IE_PWM_I2C
                                    757 ;	keyboards/ajazz/ak820/ak820_board.c:90: LED_RED_ADJ = LED_GRE_ADJ = LED_BLU_ADJ = 0;
      00320F 90 21 DB         [24]  758 	mov	dptr,#0x21db
      003212 E4               [12]  759 	clr	a
      003213 F0               [24]  760 	movx	@dptr,a
      003214 15 82            [12]  761 	dec	dpl
      003216 F0               [24]  762 	movx	@dptr,a
      003217 15 82            [12]  763 	dec	dpl
      003219 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_board.c:91: }
      00321A 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_led_irq'
                                    769 ;------------------------------------------------------------
                                    770 ;	keyboards/ajazz/ak820/ak820_board.c:101: void ak820_led_irq(void) __naked {
                                    771 ;	-----------------------------------------
                                    772 ;	 function ak820_led_irq
                                    773 ;	-----------------------------------------
      00321B                        774 _ak820_led_irq:
                                    775 ;	naked function: no prologue.
                                    776 ;	keyboards/ajazz/ak820/ak820_board.c:267: __endasm;
      00321B 05 A6            [12]  777 	inc 0xa6
      00321D E5 A6            [12]  778 	mov a, 0xa6
      00321F 54 0F            [12]  779 	anl a, #0x0f
      003221 FE               [12]  780 	mov r6, a
      003222 70 09            [24]  781 	jnz 00001$
      003224 75 A6 10         [24]  782 	mov 0xa6, #0x10
      003227 75 C7 02         [24]  783 	mov 0xc7, #0x02
      00322A 75 C6 00         [24]  784 	mov 0xc6, #0x00
      00322D                        785 00001$:
      00322D 12 32 88         [24]  786 	lcall 00010$
                                    787 ; Native D5ED..D617, only the sample XRAM address is relocated.
      003230 75 C1 FF         [24]  788 	mov 0xc1, #0xff
      003233 75 C2 FF         [24]  789 	mov 0xc2, #0xff
      003236 00               [12]  790 	nop
      003237 00               [12]  791 	nop
      003238 90 21 D1         [24]  792 	mov dptr, #0x21d1
      00323B E0               [24]  793 	movx a, @dptr
      00323C 00               [12]  794 	nop
      00323D 00               [12]  795 	nop
      00323E 00               [12]  796 	nop
      00323F 00               [12]  797 	nop
      003240 00               [12]  798 	nop
      003241 00               [12]  799 	nop
      003242 00               [12]  800 	nop
      003243 00               [12]  801 	nop
      003244 00               [12]  802 	nop
      003245 00               [12]  803 	nop
      003246 00               [12]  804 	nop
      003247 00               [12]  805 	nop
      003248 00               [12]  806 	nop
      003249 00               [12]  807 	nop
      00324A 00               [12]  808 	nop
      00324B 00               [12]  809 	nop
      00324C 00               [12]  810 	nop
      00324D 00               [12]  811 	nop
      00324E 00               [12]  812 	nop
      00324F 00               [12]  813 	nop
      003250 00               [12]  814 	nop
      003251 00               [12]  815 	nop
      003252 00               [12]  816 	nop
      003253 00               [12]  817 	nop
      003254 00               [12]  818 	nop
      003255 90 04 11         [24]  819 	mov dptr, #_ak820_scan_sample
      003258 E5 C0            [12]  820 	mov a, 0xc0
      00325A F0               [24]  821 	movx @dptr, a
      00325B E4               [12]  822 	clr a
      00325C F5 C2            [12]  823 	mov 0xc2, a
      00325E F5 C1            [12]  824 	mov 0xc1, a
      003260 75 A7 FF         [24]  825 	mov 0xa7, #0xff
      003263 75 B0 FF         [24]  826 	mov 0xb0, #0xff
      003266 75 80 FF         [24]  827 	mov 0x80, #0xff
      003269 90 04 11         [24]  828 	mov dptr, #_ak820_scan_sample
      00326C E0               [24]  829 	movx a, @dptr
      00326D F4               [12]  830 	cpl a
      00326E FD               [12]  831 	mov r5, a
      00326F 90 04 00         [24]  832 	mov dptr, #_ak820_scan_rows
      003272 E5 82            [12]  833 	mov a, dpl
      003274 2E               [12]  834 	add a, r6
      003275 F5 82            [12]  835 	mov dpl, a
      003277 E4               [12]  836 	clr a
      003278 35 83            [12]  837 	addc a, dph
      00327A F5 83            [12]  838 	mov dph, a
      00327C ED               [12]  839 	mov a, r5
      00327D F0               [24]  840 	movx @dptr, a
      00327E BE 0F 06         [24]  841 	cjne r6, #0x0f, 00002$
      003281 90 04 10         [24]  842 	mov dptr, #_ak820_scan_ready
      003284 74 01            [12]  843 	mov a, #1
      003286 F0               [24]  844 	movx @dptr, a
      003287                        845 00002$:
      003287 22               [24]  846 	ret
                                    847 ; Native E274..E29D: the32 MOVX operations feed the peripheral DMA.
      003288                        848 00010$:
      003288 D2 AE            [12]  849 	setb 0xae
      00328A D2 D0            [12]  850 	setb 0xd0
      00328C E0               [24]  851 	movx a, @dptr
      00328D E0               [24]  852 	movx a, @dptr
      00328E E0               [24]  853 	movx a, @dptr
      00328F E0               [24]  854 	movx a, @dptr
      003290 E0               [24]  855 	movx a, @dptr
      003291 E0               [24]  856 	movx a, @dptr
      003292 E0               [24]  857 	movx a, @dptr
      003293 E0               [24]  858 	movx a, @dptr
      003294 00               [12]  859 	nop
      003295 E0               [24]  860 	movx a, @dptr
      003296 E0               [24]  861 	movx a, @dptr
      003297 E0               [24]  862 	movx a, @dptr
      003298 E0               [24]  863 	movx a, @dptr
      003299 E0               [24]  864 	movx a, @dptr
      00329A E0               [24]  865 	movx a, @dptr
      00329B E0               [24]  866 	movx a, @dptr
      00329C E0               [24]  867 	movx a, @dptr
      00329D 00               [12]  868 	nop
      00329E E0               [24]  869 	movx a, @dptr
      00329F E0               [24]  870 	movx a, @dptr
      0032A0 E0               [24]  871 	movx a, @dptr
      0032A1 E0               [24]  872 	movx a, @dptr
      0032A2 E0               [24]  873 	movx a, @dptr
      0032A3 E0               [24]  874 	movx a, @dptr
      0032A4 E0               [24]  875 	movx a, @dptr
      0032A5 E0               [24]  876 	movx a, @dptr
      0032A6 00               [12]  877 	nop
      0032A7 E0               [24]  878 	movx a, @dptr
      0032A8 E0               [24]  879 	movx a, @dptr
      0032A9 E0               [24]  880 	movx a, @dptr
      0032AA E0               [24]  881 	movx a, @dptr
      0032AB E0               [24]  882 	movx a, @dptr
      0032AC E0               [24]  883 	movx a, @dptr
      0032AD E0               [24]  884 	movx a, @dptr
      0032AE E0               [24]  885 	movx a, @dptr
      0032AF C2 AE            [12]  886 	clr 0xae
                                    887 ; Native E29D..E2E0, with the jump table relocated locally.
      0032B1 E5 A6            [12]  888 	mov a, 0xa6
      0032B3 10 E4 08         [24]  889 	jbc 0xe4, 00011$
      0032B6 54 01            [12]  890 	anl a, #1
      0032B8 04               [12]  891 	inc a
      0032B9 F4               [12]  892 	cpl a
      0032BA 14               [12]  893 	dec a
      0032BB 52 F1            [12]  894 	anl 0xf1, a
      0032BD 22               [24]  895 	ret
      0032BE                        896 00011$:
                                    897 ; The selector has sixteen entries even if the peripheral sets high bits.
      0032BE 54 0F            [12]  898 	anl a, #0x0f
      0032C0 FF               [12]  899 	mov r7, a
      0032C1 2F               [12]  900 	add a, r7
      0032C2 2F               [12]  901 	add a, r7
      0032C3 90 32 C7         [24]  902 	mov dptr, #00012$
      0032C6 73               [24]  903 	jmp @a+dptr
      0032C7                        904 00012$:
      0032C7 C2 80            [12]  905 	clr 0x80
      0032C9 22               [24]  906 	ret
      0032CA C2 81            [12]  907 	clr 0x81
      0032CC 22               [24]  908 	ret
      0032CD C2 82            [12]  909 	clr 0x82
      0032CF 22               [24]  910 	ret
      0032D0 C2 83            [12]  911 	clr 0x83
      0032D2 22               [24]  912 	ret
      0032D3 C2 84            [12]  913 	clr 0x84
      0032D5 22               [24]  914 	ret
      0032D6 C2 85            [12]  915 	clr 0x85
      0032D8 22               [24]  916 	ret
      0032D9 C2 86            [12]  917 	clr 0x86
      0032DB 22               [24]  918 	ret
      0032DC C2 87            [12]  919 	clr 0x87
      0032DE 22               [24]  920 	ret
      0032DF C2 B0            [12]  921 	clr 0xb0
      0032E1 22               [24]  922 	ret
      0032E2 C2 B1            [12]  923 	clr 0xb1
      0032E4 22               [24]  924 	ret
      0032E5 C2 B2            [12]  925 	clr 0xb2
      0032E7 22               [24]  926 	ret
      0032E8 C2 B3            [12]  927 	clr 0xb3
      0032EA 22               [24]  928 	ret
      0032EB C2 B4            [12]  929 	clr 0xb4
      0032ED 22               [24]  930 	ret
      0032EE C2 B5            [12]  931 	clr 0xb5
      0032F0 22               [24]  932 	ret
      0032F1 C2 B6            [12]  933 	clr 0xb6
      0032F3 22               [24]  934 	ret
      0032F4 C2 B7            [12]  935 	clr 0xb7
      0032F6 22               [24]  936 	ret
                                    937 ;	keyboards/ajazz/ak820/ak820_board.c:268: }
                                    938 ;	naked function: no epilogue.
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'ak820_matrix_snapshot'
                                    941 ;------------------------------------------------------------
                                    942 ;rows          Allocated with name '_ak820_matrix_snapshot_rows_10000_60'
                                    943 ;row           Allocated with name '_ak820_matrix_snapshot_row_10000_61'
                                    944 ;value         Allocated with name '_ak820_matrix_snapshot_value_10000_61'
                                    945 ;irq_enabled   Allocated with name '_ak820_matrix_snapshot_irq_enabled_10000_61'
                                    946 ;changed       Allocated with name '_ak820_matrix_snapshot_changed_10000_61'
                                    947 ;------------------------------------------------------------
                                    948 ;	keyboards/ajazz/ak820/ak820_board.c:270: bool ak820_matrix_snapshot(uint8_t *rows) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function ak820_matrix_snapshot
                                    951 ;	-----------------------------------------
      0032F7                        952 _ak820_matrix_snapshot:
      0032F7 AF F0            [24]  953 	mov	r7,b
      0032F9 AE 83            [24]  954 	mov	r6,dph
      0032FB E5 82            [12]  955 	mov	a,dpl
      0032FD 90 04 12         [24]  956 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_60
      003300 F0               [24]  957 	movx	@dptr,a
      003301 EE               [12]  958 	mov	a,r6
      003302 A3               [24]  959 	inc	dptr
      003303 F0               [24]  960 	movx	@dptr,a
      003304 EF               [12]  961 	mov	a,r7
      003305 A3               [24]  962 	inc	dptr
      003306 F0               [24]  963 	movx	@dptr,a
                                    964 ;	keyboards/ajazz/ak820/ak820_board.c:274: bool changed = false;
      003307 90 04 15         [24]  965 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      00330A E4               [12]  966 	clr	a
      00330B F0               [24]  967 	movx	@dptr,a
                                    968 ;	keyboards/ajazz/ak820/ak820_board.c:276: if (!ak820_scan_ready) {
      00330C 90 04 10         [24]  969 	mov	dptr,#_ak820_scan_ready
      00330F E0               [24]  970 	movx	a,@dptr
                                    971 ;	keyboards/ajazz/ak820/ak820_board.c:277: return false;
      003310 70 03            [24]  972 	jnz	00102$
      003312 F5 82            [12]  973 	mov	dpl,a
      003314 22               [24]  974 	ret
      003315                        975 00102$:
                                    976 ;	keyboards/ajazz/ak820/ak820_board.c:281: irq_enabled = IE_EX & 0x20;
      003315 E5 E8            [12]  977 	mov	a,_IE_EX
      003317 54 20            [12]  978 	anl	a,#0x20
      003319 FF               [12]  979 	mov	r7,a
                                    980 ;	keyboards/ajazz/ak820/ak820_board.c:282: IE_PWM_I2C = 0;
                                    981 ;	assignBit
      00331A C2 ED            [12]  982 	clr	_IE_PWM_I2C
                                    983 ;	keyboards/ajazz/ak820/ak820_board.c:283: ak820_scan_ready = 0;
      00331C 90 04 10         [24]  984 	mov	dptr,#_ak820_scan_ready
      00331F E4               [12]  985 	clr	a
      003320 F0               [24]  986 	movx	@dptr,a
                                    987 ;	keyboards/ajazz/ak820/ak820_board.c:284: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      003321 FE               [12]  988 	mov	r6,a
      003322                        989 00108$:
                                    990 ;	keyboards/ajazz/ak820/ak820_board.c:285: value = ak820_scan_rows[row];
      003322 EE               [12]  991 	mov	a,r6
      003323 24 00            [12]  992 	add	a, #_ak820_scan_rows
      003325 F5 82            [12]  993 	mov	dpl,a
      003327 E4               [12]  994 	clr	a
      003328 34 04            [12]  995 	addc	a, #(_ak820_scan_rows >> 8)
      00332A F5 83            [12]  996 	mov	dph,a
      00332C E0               [24]  997 	movx	a,@dptr
      00332D FD               [12]  998 	mov	r5,a
                                    999 ;	keyboards/ajazz/ak820/ak820_board.c:287: value &= ak820_matrix_mask[row];
      00332E EE               [12] 1000 	mov	a,r6
      00332F 90 BD 00         [24] 1001 	mov	dptr,#_ak820_matrix_mask
      003332 93               [24] 1002 	movc	a,@a+dptr
      003333 52 05            [12] 1003 	anl	ar5,a
                                   1004 ;	keyboards/ajazz/ak820/ak820_board.c:289: if (rows[row] != value) {
      003335 90 04 12         [24] 1005 	mov	dptr,#_ak820_matrix_snapshot_rows_10000_60
      003338 E0               [24] 1006 	movx	a,@dptr
      003339 FA               [12] 1007 	mov	r2,a
      00333A A3               [24] 1008 	inc	dptr
      00333B E0               [24] 1009 	movx	a,@dptr
      00333C FB               [12] 1010 	mov	r3,a
      00333D A3               [24] 1011 	inc	dptr
      00333E E0               [24] 1012 	movx	a,@dptr
      00333F FC               [12] 1013 	mov	r4,a
      003340 EE               [12] 1014 	mov	a,r6
      003341 2A               [12] 1015 	add	a, r2
      003342 FA               [12] 1016 	mov	r2,a
      003343 E4               [12] 1017 	clr	a
      003344 3B               [12] 1018 	addc	a, r3
      003345 FB               [12] 1019 	mov	r3,a
      003346 8A 82            [24] 1020 	mov	dpl,r2
      003348 8B 83            [24] 1021 	mov	dph,r3
      00334A 8C F0            [24] 1022 	mov	b,r4
      00334C 12 BC E0         [24] 1023 	lcall	__gptrget
      00334F B5 05 02         [24] 1024 	cjne	a,ar5,00149$
      003352 80 10            [24] 1025 	sjmp	00109$
      003354                       1026 00149$:
                                   1027 ;	keyboards/ajazz/ak820/ak820_board.c:290: rows[row] = value;
      003354 8A 82            [24] 1028 	mov	dpl,r2
      003356 8B 83            [24] 1029 	mov	dph,r3
      003358 8C F0            [24] 1030 	mov	b,r4
      00335A ED               [12] 1031 	mov	a,r5
      00335B 12 BC A5         [24] 1032 	lcall	__gptrput
                                   1033 ;	keyboards/ajazz/ak820/ak820_board.c:291: changed = true;
      00335E 90 04 15         [24] 1034 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      003361 74 01            [12] 1035 	mov	a,#0x01
      003363 F0               [24] 1036 	movx	@dptr,a
      003364                       1037 00109$:
                                   1038 ;	keyboards/ajazz/ak820/ak820_board.c:284: for (row = 0; row < AK820_SCAN_ROWS; ++row) {
      003364 0E               [12] 1039 	inc	r6
      003365 BE 10 00         [24] 1040 	cjne	r6,#0x10,00150$
      003368                       1041 00150$:
      003368 40 B8            [24] 1042 	jc	00108$
                                   1043 ;	keyboards/ajazz/ak820/ak820_board.c:294: if (irq_enabled) {
      00336A EF               [12] 1044 	mov	a,r7
      00336B 60 02            [24] 1045 	jz	00107$
                                   1046 ;	keyboards/ajazz/ak820/ak820_board.c:295: IE_PWM_I2C = 1;
                                   1047 ;	assignBit
      00336D D2 ED            [12] 1048 	setb	_IE_PWM_I2C
      00336F                       1049 00107$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_board.c:297: return changed;
      00336F 90 04 15         [24] 1051 	mov	dptr,#_ak820_matrix_snapshot_changed_10000_61
      003372 E0               [24] 1052 	movx	a,@dptr
                                   1053 ;	keyboards/ajazz/ak820/ak820_board.c:298: }
      003373 F5 82            [12] 1054 	mov	dpl,a
      003375 22               [24] 1055 	ret
                                   1056 ;------------------------------------------------------------
                                   1057 ;Allocation info for local variables in function 'ak820_set_slot_rgb'
                                   1058 ;------------------------------------------------------------
                                   1059 ;r             Allocated with name '_ak820_set_slot_rgb_PARM_2'
                                   1060 ;g             Allocated with name '_ak820_set_slot_rgb_PARM_3'
                                   1061 ;b             Allocated with name '_ak820_set_slot_rgb_PARM_4'
                                   1062 ;slot          Allocated with name '_ak820_set_slot_rgb_slot_10000_70'
                                   1063 ;offset        Allocated with name '_ak820_set_slot_rgb_offset_10000_71'
                                   1064 ;irq_enabled   Allocated with name '_ak820_set_slot_rgb_irq_enabled_10000_71'
                                   1065 ;sloc0         Allocated with name '_ak820_set_slot_rgb_sloc0_1_0'
                                   1066 ;------------------------------------------------------------
                                   1067 ;	keyboards/ajazz/ak820/ak820_board.c:300: void ak820_set_slot_rgb(uint8_t slot, uint8_t r, uint8_t g, uint8_t b) {
                                   1068 ;	-----------------------------------------
                                   1069 ;	 function ak820_set_slot_rgb
                                   1070 ;	-----------------------------------------
      003376                       1071 _ak820_set_slot_rgb:
      003376 E5 82            [12] 1072 	mov	a,dpl
      003378 90 04 19         [24] 1073 	mov	dptr,#_ak820_set_slot_rgb_slot_10000_70
      00337B F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	keyboards/ajazz/ak820/ak820_board.c:303: if (slot >= AK820_SCAN_ROWS * AK820_SCAN_COLS) {
      00337C E0               [24] 1076 	movx	a,@dptr
      00337D FF               [12] 1077 	mov	r7,a
      00337E BF 80 00         [24] 1078 	cjne	r7,#0x80,00130$
      003381                       1079 00130$:
      003381 40 01            [24] 1080 	jc	00102$
                                   1081 ;	keyboards/ajazz/ak820/ak820_board.c:304: return;
      003383 22               [24] 1082 	ret
      003384                       1083 00102$:
                                   1084 ;	keyboards/ajazz/ak820/ak820_board.c:306: offset = (uint16_t)slot * 4;
      003384 7E 00            [12] 1085 	mov	r6,#0x00
      003386 EF               [12] 1086 	mov	a,r7
      003387 2F               [12] 1087 	add	a,r7
      003388 FF               [12] 1088 	mov	r7,a
      003389 EE               [12] 1089 	mov	a,r6
      00338A 33               [12] 1090 	rlc	a
      00338B FE               [12] 1091 	mov	r6,a
      00338C EF               [12] 1092 	mov	a,r7
      00338D 2F               [12] 1093 	add	a,r7
      00338E FF               [12] 1094 	mov	r7,a
      00338F EE               [12] 1095 	mov	a,r6
      003390 33               [12] 1096 	rlc	a
      003391 FE               [12] 1097 	mov	r6,a
                                   1098 ;	keyboards/ajazz/ak820/ak820_board.c:307: irq_enabled = IE_EX & 0x20;
      003392 E5 E8            [12] 1099 	mov	a,_IE_EX
      003394 54 20            [12] 1100 	anl	a,#0x20
      003396 FD               [12] 1101 	mov	r5,a
                                   1102 ;	keyboards/ajazz/ak820/ak820_board.c:308: IE_PWM_I2C = 0;
                                   1103 ;	assignBit
      003397 C2 ED            [12] 1104 	clr	_IE_PWM_I2C
                                   1105 ;	keyboards/ajazz/ak820/ak820_board.c:311: ak820_led_dma[offset]     = (r | g | b) ? 0xff : 0;
      003399 8F 03            [24] 1106 	mov	ar3,r7
      00339B 74 02            [12] 1107 	mov	a,#(_ak820_led_dma >> 8)
      00339D 2E               [12] 1108 	add	a,r6
      00339E FC               [12] 1109 	mov	r4,a
      00339F 90 04 17         [24] 1110 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      0033A2 E0               [24] 1111 	movx	a,@dptr
      0033A3 FA               [12] 1112 	mov	r2,a
      0033A4 90 04 16         [24] 1113 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      0033A7 E0               [24] 1114 	movx	a,@dptr
      0033A8 F9               [12] 1115 	mov	r1,a
      0033A9 4A               [12] 1116 	orl	a,r2
      0033AA F8               [12] 1117 	mov	r0,a
      0033AB 90 04 18         [24] 1118 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      0033AE E0               [24] 1119 	movx	a,@dptr
      0033AF F5 58            [12] 1120 	mov	_ak820_set_slot_rgb_sloc0_1_0,a
      0033B1 48               [12] 1121 	orl	a,r0
      0033B2 60 02            [24] 1122 	jz	00107$
      0033B4 74 FF            [12] 1123 	mov	a,#0xff
      0033B6                       1124 00107$:
      0033B6 F8               [12] 1125 	mov	r0,a
      0033B7 12 34 71         [24] 1126 	lcall	_ak820_outline_0129
      0033BA E8               [12] 1127 	mov	a,r0
      0033BB F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_board.c:312: ak820_led_dma[offset + 1] = r;
      0033BC 74 01            [12] 1130 	mov	a,#0x01
      0033BE 12 34 64         [24] 1131 	lcall	_ak820_outline_0105
      0033C1 E9               [12] 1132 	mov	a,r1
      0033C2 F0               [24] 1133 	movx	@dptr,a
                                   1134 ;	keyboards/ajazz/ak820/ak820_board.c:313: ak820_led_dma[offset + 2] = g;
      0033C3 74 02            [12] 1135 	mov	a,#0x02
      0033C5 12 34 64         [24] 1136 	lcall	_ak820_outline_0105
      0033C8 EA               [12] 1137 	mov	a,r2
      0033C9 F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_board.c:314: ak820_led_dma[offset + 3] = b;
      0033CA 74 03            [12] 1140 	mov	a,#0x03
      0033CC 2F               [12] 1141 	add	a, r7
      0033CD FF               [12] 1142 	mov	r7,a
      0033CE E4               [12] 1143 	clr	a
      0033CF 3E               [12] 1144 	addc	a, r6
      0033D0 FE               [12] 1145 	mov	r6,a
      0033D1 8F 82            [24] 1146 	mov	dpl,r7
      0033D3 74 02            [12] 1147 	mov	a,#(_ak820_led_dma >> 8)
      0033D5 2E               [12] 1148 	add	a,r6
      0033D6 F5 83            [12] 1149 	mov	dph,a
      0033D8 E5 58            [12] 1150 	mov	a,_ak820_set_slot_rgb_sloc0_1_0
      0033DA F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_board.c:315: if (irq_enabled) {
      0033DB ED               [12] 1153 	mov	a,r5
      0033DC 60 02            [24] 1154 	jz	00105$
                                   1155 ;	keyboards/ajazz/ak820/ak820_board.c:316: IE_PWM_I2C = 1;
                                   1156 ;	assignBit
      0033DE D2 ED            [12] 1157 	setb	_IE_PWM_I2C
      0033E0                       1158 00105$:
                                   1159 ;	keyboards/ajazz/ak820/ak820_board.c:318: }
      0033E0 22               [24] 1160 	ret
                                   1161 ;------------------------------------------------------------
                                   1162 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                   1163 ;------------------------------------------------------------
                                   1164 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_198'
                                   1165 ;------------------------------------------------------------
                                   1166 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                   1167 ;	-----------------------------------------
                                   1168 ;	 function ak820_rgb_init
                                   1169 ;	-----------------------------------------
      0033E1                       1170 _ak820_rgb_init:
                                   1171 ;	keyboards/ajazz/ak820/ak820_board.c:332: }
      0033E1 22               [24] 1172 	ret
                                   1173 ;------------------------------------------------------------
                                   1174 ;Allocation info for local variables in function 'ak820_rgb_set_color'
                                   1175 ;------------------------------------------------------------
                                   1176 ;r             Allocated to stack - _bp -3 +1 
                                   1177 ;g             Allocated to stack - _bp -4 +1 
                                   1178 ;b             Allocated to stack - _bp -5 +1 
                                   1179 ;index         Allocated to registers r6 r7 
                                   1180 ;------------------------------------------------------------
                                   1181 ;	keyboards/ajazz/ak820/ak820_board.c:335: static void ak820_rgb_set_color(int index, uint8_t r, uint8_t g, uint8_t b) __reentrant {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function ak820_rgb_set_color
                                   1184 ;	-----------------------------------------
      0033E2                       1185 _ak820_rgb_set_color:
      0033E2 C0 57            [24] 1186 	push	_bp
      0033E4 85 81 57         [24] 1187 	mov	_bp,sp
      0033E7 AE 82            [24] 1188 	mov	r6, dpl
                                   1189 ;	keyboards/ajazz/ak820/ak820_board.c:336: if (index < 0 || index >= RGB_MATRIX_LED_COUNT) {
      0033E9 E5 83            [12] 1190 	mov	a,dph
      0033EB FF               [12] 1191 	mov	r7,a
      0033EC 20 E7 35         [24] 1192 	jb	acc.7,00104$
      0033EF 12 34 7B         [24] 1193 	lcall	_ak820_outline_0150
                                   1194 ;	keyboards/ajazz/ak820/ak820_board.c:337: return;
      0033F2 50 30            [24] 1195 	jnc	00104$
                                   1196 ;	keyboards/ajazz/ak820/ak820_board.c:340: ak820_set_slot_rgb(ak820_rgb_slots[index], r, g, b);
      0033F4 EE               [12] 1197 	mov	a,r6
      0033F5 24 10            [12] 1198 	add	a, #_ak820_rgb_slots
      0033F7 F5 82            [12] 1199 	mov	dpl,a
      0033F9 EF               [12] 1200 	mov	a,r7
      0033FA 34 BD            [12] 1201 	addc	a, #(_ak820_rgb_slots >> 8)
      0033FC F5 83            [12] 1202 	mov	dph,a
      0033FE E4               [12] 1203 	clr	a
      0033FF 93               [24] 1204 	movc	a,@a+dptr
      003400 FF               [12] 1205 	mov	r7,a
      003401 E5 57            [12] 1206 	mov	a,_bp
      003403 24 FD            [12] 1207 	add	a,#0xfd
      003405 F8               [12] 1208 	mov	r0,a
      003406 90 04 16         [24] 1209 	mov	dptr,#_ak820_set_slot_rgb_PARM_2
      003409 E6               [12] 1210 	mov	a,@r0
      00340A F0               [24] 1211 	movx	@dptr,a
      00340B E5 57            [12] 1212 	mov	a,_bp
      00340D 24 FC            [12] 1213 	add	a,#0xfc
      00340F F8               [12] 1214 	mov	r0,a
      003410 90 04 17         [24] 1215 	mov	dptr,#_ak820_set_slot_rgb_PARM_3
      003413 E6               [12] 1216 	mov	a,@r0
      003414 F0               [24] 1217 	movx	@dptr,a
      003415 E5 57            [12] 1218 	mov	a,_bp
      003417 24 FB            [12] 1219 	add	a,#0xfb
      003419 F8               [12] 1220 	mov	r0,a
      00341A 90 04 18         [24] 1221 	mov	dptr,#_ak820_set_slot_rgb_PARM_4
      00341D E6               [12] 1222 	mov	a,@r0
      00341E F0               [24] 1223 	movx	@dptr,a
      00341F 8F 82            [24] 1224 	mov	dpl, r7
      003421 12 33 76         [24] 1225 	lcall	_ak820_set_slot_rgb
      003424                       1226 00104$:
                                   1227 ;	keyboards/ajazz/ak820/ak820_board.c:344: }
      003424 D0 57            [24] 1228 	pop	_bp
      003426 22               [24] 1229 	ret
                                   1230 ;------------------------------------------------------------
                                   1231 ;Allocation info for local variables in function 'ak820_rgb_set_color_all'
                                   1232 ;------------------------------------------------------------
                                   1233 ;g             Allocated to stack - _bp -3 +1 
                                   1234 ;b             Allocated to stack - _bp -4 +1 
                                   1235 ;r             Allocated to registers r7 
                                   1236 ;i             Allocated to registers r6 
                                   1237 ;------------------------------------------------------------
                                   1238 ;	keyboards/ajazz/ak820/ak820_board.c:346: static void ak820_rgb_set_color_all(uint8_t r, uint8_t g, uint8_t b) __reentrant {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function ak820_rgb_set_color_all
                                   1241 ;	-----------------------------------------
      003427                       1242 _ak820_rgb_set_color_all:
      003427 C0 57            [24] 1243 	push	_bp
      003429 85 81 57         [24] 1244 	mov	_bp,sp
      00342C AF 82            [24] 1245 	mov	r7, dpl
                                   1246 ;	keyboards/ajazz/ak820/ak820_board.c:348: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00342E 7E 00            [12] 1247 	mov	r6,#0x00
      003430                       1248 00102$:
                                   1249 ;	keyboards/ajazz/ak820/ak820_board.c:349: ak820_rgb_set_color(i, r, g, b);
      003430 8E 04            [24] 1250 	mov	ar4,r6
      003432 7D 00            [12] 1251 	mov	r5,#0x00
      003434 C0 07            [24] 1252 	push	ar7
      003436 C0 06            [24] 1253 	push	ar6
      003438 E5 57            [12] 1254 	mov	a,_bp
      00343A 24 FC            [12] 1255 	add	a,#0xfc
      00343C F8               [12] 1256 	mov	r0,a
      00343D E6               [12] 1257 	mov	a,@r0
      00343E C0 E0            [24] 1258 	push	acc
      003440 E5 57            [12] 1259 	mov	a,_bp
      003442 24 FD            [12] 1260 	add	a,#0xfd
      003444 F8               [12] 1261 	mov	r0,a
      003445 E6               [12] 1262 	mov	a,@r0
      003446 C0 E0            [24] 1263 	push	acc
      003448 C0 07            [24] 1264 	push	ar7
      00344A 12 34 76         [24] 1265 	lcall	_ak820_outline_0132
      00344D 12 33 E2         [24] 1266 	lcall	_ak820_rgb_set_color
      003450 15 81            [12] 1267 	dec	sp
      003452 15 81            [12] 1268 	dec	sp
      003454 15 81            [12] 1269 	dec	sp
      003456 D0 06            [24] 1270 	pop	ar6
      003458 D0 07            [24] 1271 	pop	ar7
                                   1272 ;	keyboards/ajazz/ak820/ak820_board.c:348: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00345A 0E               [12] 1273 	inc	r6
      00345B BE 52 00         [24] 1274 	cjne	r6,#0x52,00114$
      00345E                       1275 00114$:
      00345E 40 D0            [24] 1276 	jc	00102$
                                   1277 ;	keyboards/ajazz/ak820/ak820_board.c:351: }
      003460 D0 57            [24] 1278 	pop	_bp
      003462 22               [24] 1279 	ret
                                   1280 ;------------------------------------------------------------
                                   1281 ;Allocation info for local variables in function 'ak820_rgb_flush'
                                   1282 ;------------------------------------------------------------
                                   1283 ;	keyboards/ajazz/ak820/ak820_board.c:353: static void ak820_rgb_flush(void) {
                                   1284 ;	-----------------------------------------
                                   1285 ;	 function ak820_rgb_flush
                                   1286 ;	-----------------------------------------
      003463                       1287 _ak820_rgb_flush:
                                   1288 ;	keyboards/ajazz/ak820/ak820_board.c:355: }
      003463 22               [24] 1289 	ret
                                   1290 	.area CSEG    (CODE)
                                   1291 	.area CONST   (CODE)
                                   1292 	.area CONST   (CODE)
      00BD00                       1293 _ak820_matrix_mask:
      00BD00 3F                    1294 	.db #0x3f	; 63
      00BD01 2F                    1295 	.db #0x2f	; 47
      00BD02 3F                    1296 	.db #0x3f	; 63
      00BD03 1F                    1297 	.db #0x1f	; 31
      00BD04 1F                    1298 	.db #0x1f	; 31
      00BD05 3F                    1299 	.db #0x3f	; 63
      00BD06 1F                    1300 	.db #0x1f	; 31
      00BD07 1F                    1301 	.db #0x1f	; 31
      00BD08 1F                    1302 	.db #0x1f	; 31
      00BD09 3F                    1303 	.db #0x3f	; 63
      00BD0A 3F                    1304 	.db #0x3f	; 63
      00BD0B 3F                    1305 	.db #0x3f	; 63
      00BD0C 07                    1306 	.db #0x07	; 7
      00BD0D 3F                    1307 	.db #0x3f	; 63
      00BD0E 3C                    1308 	.db #0x3c	; 60
      00BD0F 2E                    1309 	.db #0x2e	; 46
                                   1310 	.area CSEG    (CODE)
                                   1311 	.area CONST   (CODE)
      00BD10                       1312 _ak820_rgb_slots:
      00BD10 00                    1313 	.db #0x00	; 0
      00BD11 08                    1314 	.db #0x08	; 8
      00BD12 10                    1315 	.db #0x10	; 16
      00BD13 18                    1316 	.db #0x18	; 24
      00BD14 20                    1317 	.db #0x20	; 32
      00BD15 28                    1318 	.db #0x28	; 40
      00BD16 30                    1319 	.db #0x30	; 48	'0'
      00BD17 38                    1320 	.db #0x38	; 56	'8'
      00BD18 40                    1321 	.db #0x40	; 64
      00BD19 48                    1322 	.db #0x48	; 72	'H'
      00BD1A 50                    1323 	.db #0x50	; 80	'P'
      00BD1B 58                    1324 	.db #0x58	; 88	'X'
      00BD1C 60                    1325 	.db #0x60	; 96
      00BD1D 72                    1326 	.db #0x72	; 114	'r'
      00BD1E 01                    1327 	.db #0x01	; 1
      00BD1F 09                    1328 	.db #0x09	; 9
      00BD20 11                    1329 	.db #0x11	; 17
      00BD21 19                    1330 	.db #0x19	; 25
      00BD22 21                    1331 	.db #0x21	; 33
      00BD23 29                    1332 	.db #0x29	; 41
      00BD24 31                    1333 	.db #0x31	; 49	'1'
      00BD25 39                    1334 	.db #0x39	; 57	'9'
      00BD26 41                    1335 	.db #0x41	; 65	'A'
      00BD27 49                    1336 	.db #0x49	; 73	'I'
      00BD28 51                    1337 	.db #0x51	; 81	'Q'
      00BD29 59                    1338 	.db #0x59	; 89	'Y'
      00BD2A 61                    1339 	.db #0x61	; 97	'a'
      00BD2B 69                    1340 	.db #0x69	; 105	'i'
      00BD2C 79                    1341 	.db #0x79	; 121	'y'
      00BD2D 02                    1342 	.db #0x02	; 2
      00BD2E 0A                    1343 	.db #0x0a	; 10
      00BD2F 12                    1344 	.db #0x12	; 18
      00BD30 1A                    1345 	.db #0x1a	; 26
      00BD31 22                    1346 	.db #0x22	; 34
      00BD32 2A                    1347 	.db #0x2a	; 42
      00BD33 32                    1348 	.db #0x32	; 50	'2'
      00BD34 3A                    1349 	.db #0x3a	; 58
      00BD35 42                    1350 	.db #0x42	; 66	'B'
      00BD36 4A                    1351 	.db #0x4a	; 74	'J'
      00BD37 52                    1352 	.db #0x52	; 82	'R'
      00BD38 5A                    1353 	.db #0x5a	; 90	'Z'
      00BD39 62                    1354 	.db #0x62	; 98	'b'
      00BD3A 6A                    1355 	.db #0x6a	; 106	'j'
      00BD3B 7A                    1356 	.db #0x7a	; 122	'z'
      00BD3C 03                    1357 	.db #0x03	; 3
      00BD3D 0B                    1358 	.db #0x0b	; 11
      00BD3E 13                    1359 	.db #0x13	; 19
      00BD3F 1B                    1360 	.db #0x1b	; 27
      00BD40 23                    1361 	.db #0x23	; 35
      00BD41 2B                    1362 	.db #0x2b	; 43
      00BD42 33                    1363 	.db #0x33	; 51	'3'
      00BD43 3B                    1364 	.db #0x3b	; 59
      00BD44 43                    1365 	.db #0x43	; 67	'C'
      00BD45 4B                    1366 	.db #0x4b	; 75	'K'
      00BD46 53                    1367 	.db #0x53	; 83	'S'
      00BD47 5B                    1368 	.db #0x5b	; 91
      00BD48 6B                    1369 	.db #0x6b	; 107	'k'
      00BD49 73                    1370 	.db #0x73	; 115	's'
      00BD4A 04                    1371 	.db #0x04	; 4
      00BD4B 14                    1372 	.db #0x14	; 20
      00BD4C 1C                    1373 	.db #0x1c	; 28
      00BD4D 24                    1374 	.db #0x24	; 36
      00BD4E 2C                    1375 	.db #0x2c	; 44
      00BD4F 34                    1376 	.db #0x34	; 52	'4'
      00BD50 3C                    1377 	.db #0x3c	; 60
      00BD51 44                    1378 	.db #0x44	; 68	'D'
      00BD52 4C                    1379 	.db #0x4c	; 76	'L'
      00BD53 54                    1380 	.db #0x54	; 84	'T'
      00BD54 5C                    1381 	.db #0x5c	; 92
      00BD55 6C                    1382 	.db #0x6c	; 108	'l'
      00BD56 74                    1383 	.db #0x74	; 116	't'
      00BD57 7B                    1384 	.db #0x7b	; 123
      00BD58 05                    1385 	.db #0x05	; 5
      00BD59 0D                    1386 	.db #0x0d	; 13
      00BD5A 15                    1387 	.db #0x15	; 21
      00BD5B 2D                    1388 	.db #0x2d	; 45
      00BD5C 4D                    1389 	.db #0x4d	; 77	'M'
      00BD5D 55                    1390 	.db #0x55	; 85	'U'
      00BD5E 5D                    1391 	.db #0x5d	; 93
      00BD5F 6D                    1392 	.db #0x6d	; 109	'm'
      00BD60 75                    1393 	.db #0x75	; 117	'u'
      00BD61 7D                    1394 	.db #0x7d	; 125
                                   1395 	.area CSEG    (CODE)
                                   1396 	.area CONST   (CODE)
      00BD62                       1397 _rgb_matrix_driver:
      00BD62 E1 33                 1398 	.byte _ak820_rgb_init, (_ak820_rgb_init >> 8)
      00BD64 E2 33                 1399 	.byte _ak820_rgb_set_color, (_ak820_rgb_set_color >> 8)
      00BD66 27 34                 1400 	.byte _ak820_rgb_set_color_all, (_ak820_rgb_set_color_all >> 8)
      00BD68 63 34                 1401 	.byte _ak820_rgb_flush, (_ak820_rgb_flush >> 8)
                                   1402 	.area CSEG    (CODE)
                                   1403 	.area XINIT   (CODE)
                                   1404 	.area CABS    (ABS,CODE)
                                   1405 
                                   1406 ; Experimental exact instruction outlining.
                                   1407 	.globl _ak820_outline_0105
                                   1408 	.globl _ak820_outline_0129
                                   1409 	.globl _ak820_outline_0132
                                   1410 	.globl _ak820_outline_0150
                                   1411 
                                   1412 	.area CSEG (CODE)
                                   1413 ; function ak820_outline_0105
      003464                       1414 _ak820_outline_0105:
      003464 2F               [12] 1415 	add	a,r7
      003465 FB               [12] 1416 	mov	r3,a
      003466 E4               [12] 1417 	clr	a
      003467 3E               [12] 1418 	addc	a,r6
      003468 FC               [12] 1419 	mov	r4,a
      003469 8B 82            [24] 1420 	mov	dpl,r3
      00346B 74 02            [12] 1421 	mov	a,#(_ak820_led_dma>>8)
      00346D 2C               [12] 1422 	add	a,r4
      00346E F5 83            [12] 1423 	mov	dph,a
      003470 22               [24] 1424 	ret
                                   1425 
                                   1426 	.area CSEG (CODE)
                                   1427 ; function ak820_outline_0129
      003471                       1428 _ak820_outline_0129:
      003471 8B 82            [24] 1429 	mov	dpl,r3
      003473 8C 83            [24] 1430 	mov	dph,r4
      003475 22               [24] 1431 	ret
                                   1432 
                                   1433 	.area CSEG (CODE)
                                   1434 ; function ak820_outline_0132
      003476                       1435 _ak820_outline_0132:
      003476 8C 82            [24] 1436 	mov	dpl,r4
      003478 8D 83            [24] 1437 	mov	dph,r5
      00347A 22               [24] 1438 	ret
                                   1439 
                                   1440 	.area CSEG (CODE)
                                   1441 ; function ak820_outline_0150
      00347B                       1442 _ak820_outline_0150:
      00347B C3               [12] 1443 	clr	c
      00347C EE               [12] 1444 	mov	a,r6
      00347D 94 52            [12] 1445 	subb	a,#0x52
      00347F EF               [12] 1446 	mov	a,r7
      003480 64 80            [12] 1447 	xrl	a,#0x80
      003482 94 80            [12] 1448 	subb	a,#0x80
      003484 22               [24] 1449 	ret
