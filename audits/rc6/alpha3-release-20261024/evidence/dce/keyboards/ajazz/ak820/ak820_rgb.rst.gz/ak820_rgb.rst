                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _timer_elapsed
                                     14 	.globl _timer_read
                                     15 	.globl _hsv_to_rgb_into
                                     16 	.globl _memset
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    261 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    262 	.globl _process_rgb_matrix_PARM_3
                                    263 	.globl _process_rgb_matrix_PARM_2
                                    264 	.globl _rgb_matrix_set_color_all_PARM_3
                                    265 	.globl _rgb_matrix_set_color_all_PARM_2
                                    266 	.globl _rgb_matrix_set_color_PARM_4
                                    267 	.globl _rgb_matrix_set_color_PARM_3
                                    268 	.globl _rgb_matrix_set_color_PARM_2
                                    269 	.globl _rgb_matrix_config
                                    270 	.globl _eeconfig_update_rgb_matrix
                                    271 	.globl _eeconfig_update_rgb_matrix_default
                                    272 	.globl _rgb_matrix_reload_from_eeprom
                                    273 	.globl _rgb_matrix_init
                                    274 	.globl _rgb_matrix_set_color
                                    275 	.globl _rgb_matrix_set_color_all
                                    276 	.globl _rgb_matrix_task
                                    277 	.globl _process_rgb_matrix
                                    278 	.globl _rgb_matrix_set_suspend_state
                                    279 	.globl _rgb_matrix_is_enabled
                                    280 	.globl _rgb_matrix_get_mode
                                    281 	.globl _rgb_matrix_get_hue
                                    282 	.globl _rgb_matrix_get_sat
                                    283 	.globl _rgb_matrix_get_val
                                    284 	.globl _rgb_matrix_get_speed
                                    285 	.globl _rgb_matrix_toggle_noeeprom
                                    286 	.globl _rgb_matrix_enable_noeeprom
                                    287 	.globl _rgb_matrix_disable_noeeprom
                                    288 	.globl _rgb_matrix_mode_noeeprom
                                    289 	.globl _rgb_matrix_step_noeeprom
                                    290 	.globl _rgb_matrix_step_reverse_noeeprom
                                    291 	.globl _rgb_matrix_sethsv_noeeprom
                                    292 	.globl _rgb_matrix_set_speed_noeeprom
                                    293 	.globl _rgb_matrix_increase_hue_noeeprom
                                    294 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    295 	.globl _rgb_matrix_increase_sat_noeeprom
                                    296 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    297 	.globl _rgb_matrix_increase_val_noeeprom
                                    298 	.globl _rgb_matrix_decrease_val_noeeprom
                                    299 	.globl _rgb_matrix_increase_speed_noeeprom
                                    300 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    301 	.globl _rgb_matrix_toggle
                                    302 	.globl _rgb_matrix_step
                                    303 	.globl _rgb_matrix_step_reverse
                                    304 	.globl _rgb_matrix_increase_hue
                                    305 	.globl _rgb_matrix_decrease_hue
                                    306 	.globl _rgb_matrix_increase_sat
                                    307 	.globl _rgb_matrix_decrease_sat
                                    308 	.globl _rgb_matrix_increase_val
                                    309 	.globl _rgb_matrix_decrease_val
                                    310 	.globl _rgb_matrix_increase_speed
                                    311 	.globl _rgb_matrix_decrease_speed
                                    312 	.globl _rgb_matrix_mode
                                    313 ;--------------------------------------------------------
                                    314 ; special function registers
                                    315 ;--------------------------------------------------------
                                    316 	.area RSEG    (ABS,DATA)
      000000                        317 	.org 0x0000
                           0000D0   318 _PSW	=	0x00d0
                           0000E0   319 _ACC	=	0x00e0
                           0000F0   320 _B	=	0x00f0
                           0000FD   321 _A_INV	=	0x00fd
                           000081   322 _SP	=	0x0081
                           000082   323 _DPL	=	0x0082
                           000083   324 _DPH	=	0x0083
                           0000A1   325 _SAFE_MOD	=	0x00a1
                           0000B1   326 _GLOBAL_CFG	=	0x00b1
                           000087   327 _PCON	=	0x0087
                           0000BA   328 _POWER_CFG	=	0x00ba
                           0000B9   329 _CLOCK_CFG	=	0x00b9
                           0000A9   330 _WAKE_CTRL	=	0x00a9
                           0000FE   331 _RESET_KEEP	=	0x00fe
                           0000FF   332 _WDOG_COUNT	=	0x00ff
                           0000A8   333 _IE	=	0x00a8
                           0000B8   334 _IP	=	0x00b8
                           0000E8   335 _IE_EX	=	0x00e8
                           0000E9   336 _IP_EX	=	0x00e9
                           0000B2   337 _GPIO_IE	=	0x00b2
                           008584   338 _ROM_ADDR	=	0x8584
                           000084   339 _ROM_ADDR_L	=	0x0084
                           000085   340 _ROM_ADDR_H	=	0x0085
                           008F8E   341 _ROM_DATA_HI	=	0x8f8e
                           00008E   342 _ROM_DATA_HL	=	0x008e
                           00008F   343 _ROM_DATA_HH	=	0x008f
                           000086   344 _ROM_CTRL	=	0x0086
                           000080   345 _P0	=	0x0080
                           0000C4   346 _P0_MOD_OC	=	0x00c4
                           0000C5   347 _P0_DIR_PU	=	0x00c5
                           000090   348 _P1	=	0x0090
                           000092   349 _P1_MOD_OC	=	0x0092
                           000093   350 _P1_DIR_PU	=	0x0093
                           0000A0   351 _P2	=	0x00a0
                           000094   352 _P2_MOD_OC	=	0x0094
                           000095   353 _P2_DIR_PU	=	0x0095
                           0000B0   354 _P3	=	0x00b0
                           000096   355 _P3_MOD_OC	=	0x0096
                           000097   356 _P3_DIR_PU	=	0x0097
                           0000C0   357 _P4	=	0x00c0
                           0000C2   358 _P4_MOD_OC	=	0x00c2
                           0000C3   359 _P4_DIR_PU	=	0x00c3
                           0000C1   360 _P4_LED_KEY	=	0x00c1
                           0000AA   361 _P5_IN	=	0x00aa
                           0000AB   362 _P5_OUT_PU	=	0x00ab
                           0000AC   363 _P5_DIR	=	0x00ac
                           0000AD   364 _P6_IN	=	0x00ad
                           0000AE   365 _P6_OUT_PU	=	0x00ae
                           0000AF   366 _P6_DIR	=	0x00af
                           0000F1   367 _P7	=	0x00f1
                           0000A2   368 _XBUS_AUX	=	0x00a2
                           000088   369 _TCON	=	0x0088
                           000089   370 _TMOD	=	0x0089
                           00008A   371 _TL0	=	0x008a
                           00008B   372 _TL1	=	0x008b
                           00008C   373 _TH0	=	0x008c
                           00008D   374 _TH1	=	0x008d
                           000098   375 _SCON	=	0x0098
                           000099   376 _SBUF	=	0x0099
                           0000C8   377 _T2CON	=	0x00c8
                           0000C9   378 _T2MOD	=	0x00c9
                           00CBCA   379 _RCAP2	=	0xcbca
                           0000CA   380 _RCAP2L	=	0x00ca
                           0000CB   381 _RCAP2H	=	0x00cb
                           00CDCC   382 _T2COUNT	=	0xcdcc
                           0000CC   383 _TL2	=	0x00cc
                           0000CD   384 _TH2	=	0x00cd
                           00CFCE   385 _T2CAP1	=	0xcfce
                           0000CE   386 _T2CAP1L	=	0x00ce
                           0000CF   387 _T2CAP1H	=	0x00cf
                           0000F8   388 _SPI0_STAT	=	0x00f8
                           0000F9   389 _SPI0_DATA	=	0x00f9
                           0000FA   390 _SPI0_CTRL	=	0x00fa
                           0000FB   391 _SPI0_CK_SE	=	0x00fb
                           0000FC   392 _SPI0_SETUP	=	0x00fc
                           0000BC   393 _SCON1	=	0x00bc
                           0000BD   394 _SBUF1	=	0x00bd
                           0000BE   395 _SBAUD1	=	0x00be
                           0000BF   396 _SIF1	=	0x00bf
                           0000B4   397 _SPI1_STAT	=	0x00b4
                           0000B5   398 _SPI1_DATA	=	0x00b5
                           0000B6   399 _SPI1_CTRL	=	0x00b6
                           0000B7   400 _SPI1_CK_SE	=	0x00b7
                           0000F3   401 _ADC_CTRL	=	0x00f3
                           00F5F4   402 _ADC_DAT	=	0xf5f4
                           0000F4   403 _ADC_DAT_L	=	0x00f4
                           0000F5   404 _ADC_DAT_H	=	0x00f5
                           0000F6   405 _ADC_CHAN	=	0x00f6
                           0000A6   406 _LED_COMMON	=	0x00a6
                           0000A7   407 _LED_PWM_OE	=	0x00a7
                           00C7C6   408 _LED_DMA	=	0xc7c6
                           0000C6   409 _LED_DMA_L	=	0x00c6
                           0000C7   410 _LED_DMA_H	=	0x00c7
                           0000F7   411 _LED_STATUS	=	0x00f7
                           0000B3   412 _I2CX_INT	=	0x00b3
                           0000BB   413 _I2CS_INT_ST	=	0x00bb
                                    414 ;--------------------------------------------------------
                                    415 ; special function bits
                                    416 ;--------------------------------------------------------
                                    417 	.area RSEG    (ABS,DATA)
      000000                        418 	.org 0x0000
                           0000D7   419 _CY	=	0x00d7
                           0000D6   420 _AC	=	0x00d6
                           0000D5   421 _F0	=	0x00d5
                           0000D4   422 _RS1	=	0x00d4
                           0000D3   423 _RS0	=	0x00d3
                           0000D2   424 _OV	=	0x00d2
                           0000D1   425 _F1	=	0x00d1
                           0000D0   426 _P	=	0x00d0
                           0000AF   427 _EA	=	0x00af
                           0000AE   428 _E_DIS	=	0x00ae
                           0000AD   429 _ET2	=	0x00ad
                           0000AC   430 _ES	=	0x00ac
                           0000AB   431 _ET1	=	0x00ab
                           0000AA   432 _EX1	=	0x00aa
                           0000A9   433 _ET0	=	0x00a9
                           0000A8   434 _EX0	=	0x00a8
                           0000BF   435 _PH_FLAG	=	0x00bf
                           0000BE   436 _PL_FLAG	=	0x00be
                           0000BD   437 _PT2	=	0x00bd
                           0000BC   438 _PS	=	0x00bc
                           0000BB   439 _PT1	=	0x00bb
                           0000BA   440 _PX1	=	0x00ba
                           0000B9   441 _PT0	=	0x00b9
                           0000B8   442 _PX0	=	0x00b8
                           0000EF   443 _IE_WDOG	=	0x00ef
                           0000EE   444 _IE_GPIO	=	0x00ee
                           0000ED   445 _IE_PWM_I2C	=	0x00ed
                           0000EC   446 _IE_UART1	=	0x00ec
                           0000EB   447 _IE_ADC	=	0x00eb
                           0000E9   448 _IE_USB	=	0x00e9
                           0000E8   449 _IE_SPI0	=	0x00e8
                           000087   450 _P0_7	=	0x0087
                           000086   451 _P0_6	=	0x0086
                           000085   452 _P0_5	=	0x0085
                           000084   453 _P0_4	=	0x0084
                           000083   454 _P0_3	=	0x0083
                           000082   455 _P0_2	=	0x0082
                           000081   456 _P0_1	=	0x0081
                           000080   457 _P0_0	=	0x0080
                           000081   458 _SDA0	=	0x0081
                           000080   459 _SCL0	=	0x0080
                           000083   460 _TXD_	=	0x0083
                           000082   461 _RXD_	=	0x0082
                           000085   462 _AIN13	=	0x0085
                           000084   463 _AIN12	=	0x0084
                           000083   464 _AIN11	=	0x0083
                           000082   465 _AIN10	=	0x0082
                           000081   466 _AIN9	=	0x0081
                           000080   467 _AIN8	=	0x0080
                           000097   468 _P1_7	=	0x0097
                           000096   469 _P1_6	=	0x0096
                           000095   470 _P1_5	=	0x0095
                           000094   471 _P1_4	=	0x0094
                           000093   472 _P1_3	=	0x0093
                           000092   473 _P1_2	=	0x0092
                           000091   474 _P1_1	=	0x0091
                           000090   475 _P1_0	=	0x0090
                           000097   476 _TXD1_	=	0x0097
                           000096   477 _RXD1_	=	0x0096
                           000097   478 _SCK	=	0x0097
                           000096   479 _MISO	=	0x0096
                           000095   480 _MOSI	=	0x0095
                           000094   481 _SCS	=	0x0094
                           000092   482 _INT0_	=	0x0092
                           000091   483 _T2EX	=	0x0091
                           000091   484 _CAP2	=	0x0091
                           000090   485 _T2	=	0x0090
                           000090   486 _CAP1	=	0x0090
                           000097   487 _AIN7	=	0x0097
                           000096   488 _AIN6	=	0x0096
                           000095   489 _AIN5	=	0x0095
                           000094   490 _AIN4	=	0x0094
                           000093   491 _AIN3	=	0x0093
                           000092   492 _AIN2	=	0x0092
                           000091   493 _AIN1	=	0x0091
                           000090   494 _AIN0	=	0x0090
                           0000A7   495 _P2_7	=	0x00a7
                           0000A6   496 _P2_6	=	0x00a6
                           0000A5   497 _P2_5	=	0x00a5
                           0000A4   498 _P2_4	=	0x00a4
                           0000A3   499 _P2_3	=	0x00a3
                           0000A2   500 _P2_2	=	0x00a2
                           0000A1   501 _P2_1	=	0x00a1
                           0000A0   502 _P2_0	=	0x00a0
                           0000A7   503 _TXD1	=	0x00a7
                           0000A6   504 _RXD1	=	0x00a6
                           0000A5   505 _T2EX_	=	0x00a5
                           0000A5   506 _CAP2_	=	0x00a5
                           0000A4   507 _T2_	=	0x00a4
                           0000A4   508 _CAP1_	=	0x00a4
                           0000B7   509 _P3_7	=	0x00b7
                           0000B6   510 _P3_6	=	0x00b6
                           0000B5   511 _P3_5	=	0x00b5
                           0000B4   512 _P3_4	=	0x00b4
                           0000B3   513 _P3_3	=	0x00b3
                           0000B2   514 _P3_2	=	0x00b2
                           0000B1   515 _P3_1	=	0x00b1
                           0000B0   516 _P3_0	=	0x00b0
                           0000B7   517 _SCK1	=	0x00b7
                           0000B6   518 _MISO1	=	0x00b6
                           0000B5   519 _MOSI1	=	0x00b5
                           0000B5   520 _T1	=	0x00b5
                           0000B4   521 _T0	=	0x00b4
                           0000B3   522 _INT1	=	0x00b3
                           0000B2   523 _INT0	=	0x00b2
                           0000B1   524 _TXD	=	0x00b1
                           0000B0   525 _RXD	=	0x00b0
                           0000C6   526 _P4_6	=	0x00c6
                           0000C5   527 _P4_5	=	0x00c5
                           0000C4   528 _P4_4	=	0x00c4
                           0000C3   529 _P4_3	=	0x00c3
                           0000C2   530 _P4_2	=	0x00c2
                           0000C1   531 _P4_1	=	0x00c1
                           0000C0   532 _P4_0	=	0x00c0
                           00008F   533 _TF1	=	0x008f
                           00008E   534 _TR1	=	0x008e
                           00008D   535 _TF0	=	0x008d
                           00008C   536 _TR0	=	0x008c
                           00008B   537 _IE1	=	0x008b
                           00008A   538 _IT1	=	0x008a
                           000089   539 _IE0	=	0x0089
                           000088   540 _IT0	=	0x0088
                           00009F   541 _SM0	=	0x009f
                           00009E   542 _SM1	=	0x009e
                           00009D   543 _SM2	=	0x009d
                           00009C   544 _REN	=	0x009c
                           00009B   545 _TB8	=	0x009b
                           00009A   546 _RB8	=	0x009a
                           000099   547 _TI	=	0x0099
                           000098   548 _RI	=	0x0098
                           0000CF   549 _TF2	=	0x00cf
                           0000CF   550 _CAP1F	=	0x00cf
                           0000CE   551 _EXF2	=	0x00ce
                           0000CD   552 _RCLK	=	0x00cd
                           0000CC   553 _TCLK	=	0x00cc
                           0000CB   554 _EXEN2	=	0x00cb
                           0000CA   555 _TR2	=	0x00ca
                           0000C9   556 _C_T2	=	0x00c9
                           0000C8   557 _CP_RL2	=	0x00c8
                           0000FF   558 _S0_FST_ACT	=	0x00ff
                           0000FE   559 _S0_IF_OV	=	0x00fe
                           0000FD   560 _S0_IF_FIRST	=	0x00fd
                           0000FC   561 _S0_IF_BYTE	=	0x00fc
                           0000FB   562 _S0_FREE	=	0x00fb
                           0000FA   563 _S0_T_FIFO	=	0x00fa
                           0000F8   564 _S0_R_FIFO	=	0x00f8
                           0000F7   565 _ADC_START	=	0x00f7
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable register banks
                                    568 ;--------------------------------------------------------
                                    569 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        570 	.ds 8
                                    571 ;--------------------------------------------------------
                                    572 ; internal ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area DSEG    (DATA)
      000015                        575 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        576 	.ds 1
                                    577 ;--------------------------------------------------------
                                    578 ; overlayable items in internal ram
                                    579 ;--------------------------------------------------------
                                    580 ;--------------------------------------------------------
                                    581 ; indirectly addressable internal ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area ISEG    (DATA)
                                    584 ;--------------------------------------------------------
                                    585 ; absolute internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area IABS    (ABS,DATA)
                                    588 	.area IABS    (ABS,DATA)
                                    589 ;--------------------------------------------------------
                                    590 ; bit data
                                    591 ;--------------------------------------------------------
                                    592 	.area BSEG    (BIT)
      000011                        593 _suspended:
      000011                        594 	.ds 1
      000012                        595 _dirty:
      000012                        596 	.ds 1
      000013                        597 _rendering:
      000013                        598 	.ds 1
      000014                        599 _rgb_matrix_task_sloc0_1_0:
      000014                        600 	.ds 1
                                    601 ;--------------------------------------------------------
                                    602 ; paged external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area PSEG    (PAG,XDATA)
                                    605 ;--------------------------------------------------------
                                    606 ; uninitialized external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XSEG    (XDATA)
      0006A4                        609 _rgb_matrix_config::
      0006A4                        610 	.ds 8
      0006AC                        611 _changed_at:
      0006AC                        612 	.ds 2
      0006AE                        613 _frame_at:
      0006AE                        614 	.ds 2
      0006B0                        615 _phase:
      0006B0                        616 	.ds 2
      0006B2                        617 _led_index:
      0006B2                        618 	.ds 1
      0006B3                        619 _frame_mode:
      0006B3                        620 	.ds 1
      0006B4                        621 _frame_hue:
      0006B4                        622 	.ds 1
      0006B5                        623 _frame_sat:
      0006B5                        624 	.ds 1
      0006B6                        625 _frame_val:
      0006B6                        626 	.ds 1
      0006B7                        627 _frame_flags:
      0006B7                        628 	.ds 1
      0006B8                        629 _frame_phase:
      0006B8                        630 	.ds 1
      0006B9                        631 _reactive_age:
      0006B9                        632 	.ds 82
      00070B                        633 _reactive_at:
      00070B                        634 	.ds 2
      00070D                        635 _add_sat_PARM_2:
      00070D                        636 	.ds 1
      00070E                        637 _add_sat_x_10000_264:
      00070E                        638 	.ds 1
      00070F                        639 _sub_sat_PARM_2:
      00070F                        640 	.ds 1
      000710                        641 _sub_sat_x_10000_266:
      000710                        642 	.ds 1
      000711                        643 _rgb_matrix_set_color_PARM_2:
      000711                        644 	.ds 1
      000712                        645 _rgb_matrix_set_color_PARM_3:
      000712                        646 	.ds 1
      000713                        647 _rgb_matrix_set_color_PARM_4:
      000713                        648 	.ds 1
      000714                        649 _rgb_matrix_set_color_index_10000_282:
      000714                        650 	.ds 2
      000716                        651 _rgb_matrix_set_color_all_PARM_2:
      000716                        652 	.ds 1
      000717                        653 _rgb_matrix_set_color_all_PARM_3:
      000717                        654 	.ds 1
      000718                        655 _rgb_matrix_set_color_all_r_10000_285:
      000718                        656 	.ds 1
      000719                        657 _sine8_theta_10000_287:
      000719                        658 	.ds 1
      00071A                        659 _sine8_offset_10000_288:
      00071A                        660 	.ds 1
      00071B                        661 _sine8_fraction_10000_288:
      00071B                        662 	.ds 1
      00071C                        663 _breathing_cie_value_10000_291:
      00071C                        664 	.ds 1
      00071D                        665 _rgb_matrix_task_end_10000_296:
      00071D                        666 	.ds 1
      00071E                        667 _rgb_matrix_task_hsv_10000_296:
      00071E                        668 	.ds 3
      000721                        669 _rgb_matrix_task_rgb_10000_296:
      000721                        670 	.ds 3
      000724                        671 _process_rgb_matrix_PARM_2:
      000724                        672 	.ds 1
      000725                        673 _process_rgb_matrix_PARM_3:
      000725                        674 	.ds 1
      000726                        675 _process_rgb_matrix_row_10000_317:
      000726                        676 	.ds 1
      000727                        677 _rgb_matrix_set_suspend_state_state_10000_324:
      000727                        678 	.ds 1
      000728                        679 _rgb_matrix_mode_noeeprom_mode_10000_353:
      000728                        680 	.ds 1
      000729                        681 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000729                        682 	.ds 1
      00072A                        683 _rgb_matrix_sethsv_noeeprom_PARM_3:
      00072A                        684 	.ds 1
      00072B                        685 _rgb_matrix_sethsv_noeeprom_hue_10000_361:
      00072B                        686 	.ds 2
      00072D                        687 _rgb_matrix_set_speed_noeeprom_speed_10000_363:
      00072D                        688 	.ds 1
      00072E                        689 _rgb_matrix_mode_mode_10000_409:
      00072E                        690 	.ds 1
                                    691 ;--------------------------------------------------------
                                    692 ; absolute external ram data
                                    693 ;--------------------------------------------------------
                                    694 	.area XABS    (ABS,XDATA)
                                    695 ;--------------------------------------------------------
                                    696 ; initialized external ram data
                                    697 ;--------------------------------------------------------
                                    698 	.area XISEG   (XDATA)
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT0 (CODE)
                                    701 	.area GSINIT1 (CODE)
                                    702 	.area GSINIT2 (CODE)
                                    703 	.area GSINIT3 (CODE)
                                    704 	.area GSINIT4 (CODE)
                                    705 	.area GSINIT5 (CODE)
                                    706 	.area GSINIT  (CODE)
                                    707 	.area GSFINAL (CODE)
                                    708 	.area CSEG    (CODE)
                                    709 ;--------------------------------------------------------
                                    710 ; global & static initialisations
                                    711 ;--------------------------------------------------------
                                    712 	.area HOME    (CODE)
                                    713 	.area GSINIT  (CODE)
                                    714 	.area GSFINAL (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 ;--------------------------------------------------------
                                    717 ; Home
                                    718 ;--------------------------------------------------------
                                    719 	.area HOME    (CODE)
                                    720 	.area HOME    (CODE)
                                    721 ;--------------------------------------------------------
                                    722 ; code
                                    723 ;--------------------------------------------------------
                                    724 	.area CSEG    (CODE)
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    727 ;------------------------------------------------------------
                                    728 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    729 ;------------------------------------------------------------
                                    730 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    731 ;	-----------------------------------------
                           000007   732 	ar7 = 0x07
                           000006   733 	ar6 = 0x06
                           000005   734 	ar5 = 0x05
                           000004   735 	ar4 = 0x04
                           000003   736 	ar3 = 0x03
                           000002   737 	ar2 = 0x02
                           000001   738 	ar1 = 0x01
                           000000   739 	ar0 = 0x00
                                    740 ;	 function clear_reactive
                                    741 ;	-----------------------------------------
      004FB8                        742 _clear_reactive:
                                    743 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      004FB8 12 58 09         [24]  744 	lcall	_ak820_outline_0187
      004FBB 74 52            [12]  745 	mov	a,#0x52
      004FBD 12 39 0D         [24]  746 	lcall	_ak820_outline_0130
      004FC0 90 06 B9         [24]  747 	mov	dptr,#_reactive_age
      004FC3 F5 F0            [12]  748 	mov	b,a
      004FC5 12 BC 7D         [24]  749 	lcall	_memset
                                    750 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      004FC8 12 49 A8         [24]  751 	lcall	_timer_read
      004FCB 12 39 22         [24]  752 	lcall	_ak820_outline_0145
      004FCE 90 07 0B         [24]  753 	mov	dptr,#_reactive_at
      004FD1 12 57 F5         [24]  754 	lcall	_ak820_outline_0173
                                    755 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      004FD4 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'age_reactive'
                                    759 ;------------------------------------------------------------
                                    760 ;ticks         Allocated with name '_age_reactive_ticks_10000_260'
                                    761 ;i             Allocated with name '_age_reactive_i_10000_260'
                                    762 ;decay         Allocated with name '_age_reactive_decay_10000_260'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function age_reactive
                                    767 ;	-----------------------------------------
      004FD5                        768 _age_reactive:
                                    769 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004FD5 90 07 0B         [24]  770 	mov	dptr,#_reactive_at
      004FD8 12 38 81         [24]  771 	lcall	_ak820_outline_0010
      004FDB 12 49 AB         [24]  772 	lcall	_timer_elapsed
      004FDE AE 82            [24]  773 	mov	r6, dpl
      004FE0 E5 83            [12]  774 	mov	a,dph
      004FE2 C4               [12]  775 	swap	a
      004FE3 CE               [12]  776 	xch	a,r6
      004FE4 C4               [12]  777 	swap	a
      004FE5 54 0F            [12]  778 	anl	a,#0x0f
      004FE7 6E               [12]  779 	xrl	a,r6
      004FE8 CE               [12]  780 	xch	a,r6
      004FE9 54 0F            [12]  781 	anl	a,#0x0f
      004FEB CE               [12]  782 	xch	a,r6
      004FEC 6E               [12]  783 	xrl	a,r6
      004FED CE               [12]  784 	xch	a,r6
                                    785 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      004FEE FF               [12]  786 	mov	r7,a
      004FEF 4E               [12]  787 	orl	a,r6
      004FF0 70 01            [24]  788 	jnz	00102$
      004FF2 22               [24]  789 	ret
      004FF3                        790 00102$:
                                    791 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      004FF3 8E 04            [24]  792 	mov	ar4,r6
      004FF5 EF               [12]  793 	mov	a,r7
      004FF6 C4               [12]  794 	swap	a
      004FF7 54 F0            [12]  795 	anl	a,#0xf0
      004FF9 CC               [12]  796 	xch	a,r4
      004FFA C4               [12]  797 	swap	a
      004FFB CC               [12]  798 	xch	a,r4
      004FFC 6C               [12]  799 	xrl	a,r4
      004FFD CC               [12]  800 	xch	a,r4
      004FFE 54 F0            [12]  801 	anl	a,#0xf0
      005000 CC               [12]  802 	xch	a,r4
      005001 6C               [12]  803 	xrl	a,r4
      005002 FD               [12]  804 	mov	r5,a
      005003 90 07 0B         [24]  805 	mov	dptr,#_reactive_at
      005006 12 43 B7         [24]  806 	lcall	_ak820_outline_0110
      005009 90 07 0B         [24]  807 	mov	dptr,#_reactive_at
      00500C EC               [12]  808 	mov	a,r4
      00500D 2A               [12]  809 	add	a, r2
      00500E F0               [24]  810 	movx	@dptr,a
      00500F ED               [12]  811 	mov	a,r5
      005010 3B               [12]  812 	addc	a, r3
      005011 A3               [24]  813 	inc	dptr
      005012 F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      005013 8E 04            [24]  816 	mov	ar4,r6
      005015 8F 05            [24]  817 	mov	ar5,r7
      005017 C3               [12]  818 	clr	c
      005018 74 FF            [12]  819 	mov	a,#0xff
      00501A 9C               [12]  820 	subb	a,r4
      00501B E4               [12]  821 	clr	a
      00501C 9D               [12]  822 	subb	a,r5
      00501D 50 04            [24]  823 	jnc	00108$
                                    824 ;	free result
      00501F 7D FF            [12]  825 	mov	r5,#0xff
      005021 80 02            [24]  826 	sjmp	00109$
      005023                        827 00108$:
      005023 8E 05            [24]  828 	mov	ar5,r6
      005025                        829 00109$:
                                    830 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005025 7F 00            [12]  831 	mov	r7,#0x00
      005027                        832 00104$:
                                    833 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      005027 EF               [12]  834 	mov	a,r7
      005028 24 B9            [12]  835 	add	a, #_reactive_age
      00502A FC               [12]  836 	mov	r4,a
      00502B E4               [12]  837 	clr	a
      00502C 34 06            [12]  838 	addc	a, #(_reactive_age >> 8)
      00502E FE               [12]  839 	mov	r6,a
      00502F 8C 82            [24]  840 	mov	dpl,r4
      005031 8E 83            [24]  841 	mov	dph,r6
      005033 E0               [24]  842 	movx	a,@dptr
      005034 FB               [12]  843 	mov	r3,a
      005035 C3               [12]  844 	clr	c
      005036 ED               [12]  845 	mov	a,r5
      005037 9B               [12]  846 	subb	a,r3
      005038 40 04            [24]  847 	jc	00110$
      00503A 7B 00            [12]  848 	mov	r3,#0x00
      00503C 80 08            [24]  849 	sjmp	00111$
      00503E                        850 00110$:
      00503E 8C 82            [24]  851 	mov	dpl,r4
      005040 8E 83            [24]  852 	mov	dph,r6
      005042 E0               [24]  853 	movx	a,@dptr
      005043 C3               [12]  854 	clr	c
      005044 9D               [12]  855 	subb	a,r5
      005045 FB               [12]  856 	mov	r3,a
      005046                        857 00111$:
      005046 8C 82            [24]  858 	mov	dpl,r4
      005048 8E 83            [24]  859 	mov	dph,r6
      00504A EB               [12]  860 	mov	a,r3
      00504B F0               [24]  861 	movx	@dptr,a
                                    862 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00504C 0F               [12]  863 	inc	r7
      00504D BF 52 00         [24]  864 	cjne	r7,#0x52,00144$
      005050                        865 00144$:
      005050 40 D5            [24]  866 	jc	00104$
                                    867 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      005052 22               [24]  868 	ret
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'add_sat'
                                    871 ;------------------------------------------------------------
                                    872 ;y             Allocated with name '_add_sat_PARM_2'
                                    873 ;x             Allocated with name '_add_sat_x_10000_264'
                                    874 ;------------------------------------------------------------
                                    875 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function add_sat
                                    878 ;	-----------------------------------------
      005053                        879 _add_sat:
      005053 E5 82            [12]  880 	mov	a,dpl
      005055 90 07 0E         [24]  881 	mov	dptr,#_add_sat_x_10000_264
      005058 F0               [24]  882 	movx	@dptr,a
                                    883 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      005059 90 07 0D         [24]  884 	mov	dptr,#_add_sat_PARM_2
      00505C E0               [24]  885 	movx	a,@dptr
      00505D FF               [12]  886 	mov	r7,a
      00505E FE               [12]  887 	mov	r6,a
      00505F 74 FF            [12]  888 	mov	a,#0xff
      005061 C3               [12]  889 	clr	c
      005062 9E               [12]  890 	subb	a,r6
      005063 FE               [12]  891 	mov	r6,a
      005064 90 07 0E         [24]  892 	mov	dptr,#_add_sat_x_10000_264
      005067 E0               [24]  893 	movx	a,@dptr
      005068 FD               [12]  894 	mov	r5,a
      005069 C3               [12]  895 	clr	c
      00506A EE               [12]  896 	mov	a,r6
      00506B 9D               [12]  897 	subb	a,r5
      00506C 50 04            [24]  898 	jnc	00103$
                                    899 ;	free result
      00506E 7E FF            [12]  900 	mov	r6,#0xff
      005070 80 03            [24]  901 	sjmp	00104$
      005072                        902 00103$:
      005072 EF               [12]  903 	mov	a,r7
      005073 2D               [12]  904 	add	a, r5
      005074 FE               [12]  905 	mov	r6,a
      005075                        906 00104$:
      005075 8E 82            [24]  907 	mov	dpl, r6
                                    908 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      005077 22               [24]  909 	ret
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'sub_sat'
                                    912 ;------------------------------------------------------------
                                    913 ;y             Allocated with name '_sub_sat_PARM_2'
                                    914 ;x             Allocated with name '_sub_sat_x_10000_266'
                                    915 ;------------------------------------------------------------
                                    916 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function sub_sat
                                    919 ;	-----------------------------------------
      005078                        920 _sub_sat:
      005078 E5 82            [12]  921 	mov	a,dpl
      00507A 90 07 10         [24]  922 	mov	dptr,#_sub_sat_x_10000_266
      00507D F0               [24]  923 	movx	@dptr,a
                                    924 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      00507E E0               [24]  925 	movx	a,@dptr
      00507F FF               [12]  926 	mov	r7,a
      005080 90 07 0F         [24]  927 	mov	dptr,#_sub_sat_PARM_2
      005083 E0               [24]  928 	movx	a,@dptr
      005084 FE               [12]  929 	mov	r6,a
      005085 C3               [12]  930 	clr	c
      005086 EF               [12]  931 	mov	a,r7
      005087 9E               [12]  932 	subb	a,r6
      005088 50 04            [24]  933 	jnc	00103$
      00508A 7D 00            [12]  934 	mov	r5,#0x00
      00508C 80 04            [24]  935 	sjmp	00104$
      00508E                        936 00103$:
      00508E EF               [12]  937 	mov	a,r7
      00508F C3               [12]  938 	clr	c
      005090 9E               [12]  939 	subb	a,r6
      005091 FD               [12]  940 	mov	r5,a
      005092                        941 00104$:
      005092 8D 82            [24]  942 	mov	dpl, r5
                                    943 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      005094 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'mark_dirty'
                                    947 ;------------------------------------------------------------
                                    948 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function mark_dirty
                                    951 ;	-----------------------------------------
      005095                        952 _mark_dirty:
                                    953 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    954 ;	assignBit
      005095 D2 12            [12]  955 	setb	_dirty
                                    956 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005097 12 49 A8         [24]  957 	lcall	_timer_read
      00509A 12 39 22         [24]  958 	lcall	_ak820_outline_0145
      00509D 90 06 AC         [24]  959 	mov	dptr,#_changed_at
      0050A0 12 57 F5         [24]  960 	lcall	_ak820_outline_0173
                                    961 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      0050A3 22               [24]  962 	ret
                                    963 ;------------------------------------------------------------
                                    964 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    965 ;------------------------------------------------------------
                                    966 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_271'
                                    967 ;------------------------------------------------------------
                                    968 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    969 ;	-----------------------------------------
                                    970 ;	 function eeconfig_update_rgb_matrix
                                    971 ;	-----------------------------------------
      0050A4                        972 _eeconfig_update_rgb_matrix:
                                    973 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    974 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      0050A4 90 06 AB         [24]  975 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      0050A7 E4               [12]  976 	clr	a
      0050A8 F0               [24]  977 	movx	@dptr,a
      0050A9 90 06 AA         [24]  978 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      0050AC F0               [24]  979 	movx	@dptr,a
                                    980 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0050AD 90 05 8E         [24]  981 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0050B0 12 57 D8         [24]  982 	lcall	_ak820_outline_0093
      0050B3 90 05 91         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0050B6 12 57 CE         [24]  984 	lcall	_ak820_outline_0080
      0050B9 12 42 8B         [24]  985 	lcall	_ak820_eeprom_update_block_xdata
                                    986 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    987 ;	assignBit
      0050BC C2 12            [12]  988 	clr	_dirty
                                    989 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      0050BE 22               [24]  990 	ret
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    993 ;------------------------------------------------------------
                                    994 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function eeconfig_update_rgb_matrix_default
                                    997 ;	-----------------------------------------
      0050BF                        998 _eeconfig_update_rgb_matrix_default:
                                    999 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      0050BF 12 58 09         [24] 1000 	lcall	_ak820_outline_0187
      0050C2 12 57 CE         [24] 1001 	lcall	_ak820_outline_0080
      0050C5 F5 F0            [12] 1002 	mov	b,a
      0050C7 12 BC 7D         [24] 1003 	lcall	_memset
                                   1004 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      0050CA 12 57 E1         [24] 1005 	lcall	_ak820_outline_0117
      0050CD 44 01            [12] 1006 	orl	a,#0x01
      0050CF F0               [24] 1007 	movx	@dptr,a
                                   1008 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      0050D0 12 57 C7         [24] 1009 	lcall	_ak820_outline_0075
      0050D3 44 04            [12] 1010 	orl	a,#0x04
      0050D5 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      0050D6 90 06 A5         [24] 1013 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0050D9 E4               [12] 1014 	clr	a
      0050DA F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      0050DB 90 06 A6         [24] 1017 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0050DE 14               [12] 1018 	dec	a
      0050DF F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      0050E0 90 06 A7         [24] 1021 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050E3 74 50            [12] 1022 	mov	a,#0x50
      0050E5 F0               [24] 1023 	movx	@dptr,a
                                   1024 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      0050E6 90 06 A8         [24] 1025 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0050E9 74 60            [12] 1026 	mov	a,#0x60
      0050EB F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      0050EC 90 06 A9         [24] 1029 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0050EF 74 FF            [12] 1030 	mov	a,#0xff
      0050F1 F0               [24] 1031 	movx	@dptr,a
                                   1032 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1033 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      0050F2 02 50 A4         [24] 1034 	ljmp	_eeconfig_update_rgb_matrix
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function rgb_matrix_reload_from_eeprom
                                   1041 ;	-----------------------------------------
      0050F5                       1042 _rgb_matrix_reload_from_eeprom:
                                   1043 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0050F5 90 05 7E         [24] 1044 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050F8 12 57 D8         [24] 1045 	lcall	_ak820_outline_0093
      0050FB 90 05 81         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050FE 12 57 CE         [24] 1047 	lcall	_ak820_outline_0080
      005101 12 41 1C         [24] 1048 	lcall	_ak820_eeprom_read_block_xdata
                                   1049 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      005104 12 57 E1         [24] 1050 	lcall	_ak820_outline_0117
      005107 60 11            [24] 1051 	jz	00101$
      005109 12 57 A0         [24] 1052 	lcall	_ak820_outline_0020
      00510C C3               [12] 1053 	clr	c
      00510D 64 80            [12] 1054 	xrl	a,#0x80
      00510F 94 87            [12] 1055 	subb	a,#0x87
      005111 50 07            [24] 1056 	jnc	00101$
      005113 12 57 C7         [24] 1057 	lcall	_ak820_outline_0075
      005116 24 FE            [12] 1058 	add	a,#0xff - 0x01
      005118 50 03            [24] 1059 	jnc	00102$
                                   1060 ;	free result
      00511A                       1061 00101$:
                                   1062 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      00511A 12 50 BF         [24] 1063 	lcall	_eeconfig_update_rgb_matrix_default
      00511D                       1064 00102$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      00511D 90 06 A7         [24] 1066 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005120 E0               [24] 1067 	movx	a,@dptr
      005121 24 5F            [12] 1068 	add	a,#0xff - 0xa0
      005123 50 06            [24] 1069 	jnc	00106$
                                   1070 ;	free result
                                   1071 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      005125 90 06 A7         [24] 1072 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005128 74 A0            [12] 1073 	mov	a,#0xa0
      00512A F0               [24] 1074 	movx	@dptr,a
      00512B                       1075 00106$:
                                   1076 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1077 ;	assignBit
      00512B C2 12            [12] 1078 	clr	_dirty
                                   1079 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1080 ;	assignBit
      00512D C2 13            [12] 1081 	clr	_rendering
                                   1082 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1083 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      00512F 02 4F B8         [24] 1084 	ljmp	_clear_reactive
                                   1085 ;------------------------------------------------------------
                                   1086 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function rgb_matrix_init
                                   1091 ;	-----------------------------------------
      005132                       1092 _rgb_matrix_init:
                                   1093 ;	keyboards/ajazz/ak820/ak820_rgb.c:113: rgb_matrix_driver.init();
      005132 90 BD 62         [24] 1094 	mov	dptr,#_rgb_matrix_driver
      005135 12 57 A9         [24] 1095 	lcall	_ak820_outline_0046
      005138 C0 07            [24] 1096 	push	ar7
      00513A C0 06            [24] 1097 	push	ar6
      00513C 12 39 08         [24] 1098 	lcall	_ak820_outline_0123
      00513F 12 30 75         [24] 1099 	lcall	__sdcc_call_dptr
      005142 D0 06            [24] 1100 	pop	ar6
      005144 D0 07            [24] 1101 	pop	ar7
                                   1102 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      005146 12 50 F5         [24] 1103 	lcall	_rgb_matrix_reload_from_eeprom
                                   1104 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      005149 12 49 A8         [24] 1105 	lcall	_timer_read
      00514C 12 43 D5         [24] 1106 	lcall	_ak820_outline_0131
      00514F EE               [12] 1107 	mov	a,r6
      005150 24 F0            [12] 1108 	add	a,#0xf0
      005152 FE               [12] 1109 	mov	r6,a
      005153 EF               [12] 1110 	mov	a,r7
      005154 34 FF            [12] 1111 	addc	a,#0xff
      005156 FF               [12] 1112 	mov	r7,a
      005157 90 06 AE         [24] 1113 	mov	dptr,#_frame_at
      00515A 12 48 F9         [24] 1114 	lcall	_ak820_outline_0068
                                   1115 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      00515D 22               [24] 1116 	ret
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1119 ;------------------------------------------------------------
                                   1120 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1121 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1122 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1123 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_282'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function rgb_matrix_set_color
                                   1128 ;	-----------------------------------------
      00515E                       1129 _rgb_matrix_set_color:
      00515E 12 39 03         [24] 1130 	lcall	_ak820_outline_0122
      005161 90 07 14         [24] 1131 	mov	dptr,#_rgb_matrix_set_color_index_10000_282
      005164 12 38 FE         [24] 1132 	lcall	_ak820_outline_0121
                                   1133 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) rgb_matrix_driver.set_color(index, r, g, b);
      005167 90 07 14         [24] 1134 	mov	dptr,#_rgb_matrix_set_color_index_10000_282
      00516A 12 38 C3         [24] 1135 	lcall	_ak820_outline_0060
      00516D 20 E7 3C         [24] 1136 	jb	acc.7,00104$
      005170 12 34 7B         [24] 1137 	lcall	_ak820_outline_0150
      005173 50 37            [24] 1138 	jnc	00104$
      005175 90 BD 64         [24] 1139 	mov	dptr,#(_rgb_matrix_driver + 0x0002)
      005178 E4               [12] 1140 	clr	a
      005179 93               [24] 1141 	movc	a,@a+dptr
      00517A FC               [12] 1142 	mov	r4,a
      00517B A3               [24] 1143 	inc	dptr
      00517C E4               [12] 1144 	clr	a
      00517D 93               [24] 1145 	movc	a,@a+dptr
      00517E FD               [12] 1146 	mov	r5,a
      00517F C0 05            [24] 1147 	push	ar5
      005181 C0 04            [24] 1148 	push	ar4
      005183 90 07 13         [24] 1149 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005186 E0               [24] 1150 	movx	a,@dptr
      005187 C0 E0            [24] 1151 	push	acc
      005189 90 07 12         [24] 1152 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00518C E0               [24] 1153 	movx	a,@dptr
      00518D C0 E0            [24] 1154 	push	acc
      00518F 90 07 11         [24] 1155 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005192 E0               [24] 1156 	movx	a,@dptr
      005193 C0 E0            [24] 1157 	push	acc
      005195 12 51 9A         [24] 1158 	lcall	00122$
      005198 80 08            [24] 1159 	sjmp	00123$
      00519A                       1160 00122$:
      00519A C0 04            [24] 1161 	push	ar4
      00519C C0 05            [24] 1162 	push	ar5
      00519E 12 39 08         [24] 1163 	lcall	_ak820_outline_0123
      0051A1 22               [24] 1164 	ret
      0051A2                       1165 00123$:
      0051A2 15 81            [12] 1166 	dec	sp
      0051A4 15 81            [12] 1167 	dec	sp
      0051A6 15 81            [12] 1168 	dec	sp
      0051A8 D0 04            [24] 1169 	pop	ar4
      0051AA D0 05            [24] 1170 	pop	ar5
      0051AC                       1171 00104$:
                                   1172 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0051AC 22               [24] 1173 	ret
                                   1174 ;------------------------------------------------------------
                                   1175 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1176 ;------------------------------------------------------------
                                   1177 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1178 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1179 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_285'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function rgb_matrix_set_color_all
                                   1184 ;	-----------------------------------------
      0051AD                       1185 _rgb_matrix_set_color_all:
      0051AD E5 82            [12] 1186 	mov	a,dpl
      0051AF 90 07 18         [24] 1187 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_285
      0051B2 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: rgb_matrix_driver.set_color_all(r, g, b);
      0051B3 90 BD 66         [24] 1190 	mov	dptr,#(_rgb_matrix_driver + 0x0004)
      0051B6 12 57 A9         [24] 1191 	lcall	_ak820_outline_0046
      0051B9 90 07 18         [24] 1192 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_285
      0051BC E0               [24] 1193 	movx	a,@dptr
      0051BD FD               [12] 1194 	mov	r5,a
      0051BE C0 07            [24] 1195 	push	ar7
      0051C0 C0 06            [24] 1196 	push	ar6
      0051C2 90 07 17         [24] 1197 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0051C5 E0               [24] 1198 	movx	a,@dptr
      0051C6 C0 E0            [24] 1199 	push	acc
      0051C8 90 07 16         [24] 1200 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0051CB E0               [24] 1201 	movx	a,@dptr
      0051CC C0 E0            [24] 1202 	push	acc
      0051CE 12 51 D3         [24] 1203 	lcall	00103$
      0051D1 80 07            [24] 1204 	sjmp	00104$
      0051D3                       1205 00103$:
      0051D3 C0 06            [24] 1206 	push	ar6
      0051D5 C0 07            [24] 1207 	push	ar7
      0051D7 8D 82            [24] 1208 	mov	dpl, r5
      0051D9 22               [24] 1209 	ret
      0051DA                       1210 00104$:
      0051DA 15 81            [12] 1211 	dec	sp
      0051DC 15 81            [12] 1212 	dec	sp
      0051DE D0 06            [24] 1213 	pop	ar6
      0051E0 D0 07            [24] 1214 	pop	ar7
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      0051E2 22               [24] 1216 	ret
                                   1217 ;------------------------------------------------------------
                                   1218 ;Allocation info for local variables in function 'sine8'
                                   1219 ;------------------------------------------------------------
                                   1220 ;theta         Allocated with name '_sine8_theta_10000_287'
                                   1221 ;offset        Allocated with name '_sine8_offset_10000_288'
                                   1222 ;section       Allocated with name '_sine8_section_10000_288'
                                   1223 ;fraction      Allocated with name '_sine8_fraction_10000_288'
                                   1224 ;value         Allocated with name '_sine8_value_10000_288'
                                   1225 ;------------------------------------------------------------
                                   1226 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1227 ;	-----------------------------------------
                                   1228 ;	 function sine8
                                   1229 ;	-----------------------------------------
      0051E3                       1230 _sine8:
      0051E3 E5 82            [12] 1231 	mov	a,dpl
      0051E5 90 07 19         [24] 1232 	mov	dptr,#_sine8_theta_10000_287
      0051E8 F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      0051E9 E0               [24] 1235 	movx	a,@dptr
      0051EA FF               [12] 1236 	mov	r7,a
      0051EB 90 07 1A         [24] 1237 	mov	dptr,#_sine8_offset_10000_288
      0051EE F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      0051EF EF               [12] 1240 	mov	a,r7
      0051F0 30 E6 08         [24] 1241 	jnb	acc.6,00102$
      0051F3 90 07 1A         [24] 1242 	mov	dptr,#_sine8_offset_10000_288
      0051F6 74 FF            [12] 1243 	mov	a,#0xff
      0051F8 C3               [12] 1244 	clr	c
      0051F9 9F               [12] 1245 	subb	a,r7
      0051FA F0               [24] 1246 	movx	@dptr,a
      0051FB                       1247 00102$:
                                   1248 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      0051FB 90 07 1A         [24] 1249 	mov	dptr,#_sine8_offset_10000_288
      0051FE E0               [24] 1250 	movx	a,@dptr
      0051FF 53 E0 3F         [24] 1251 	anl	acc,#0x3f
      005202 F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      005203 90 07 1A         [24] 1254 	mov	dptr,#_sine8_offset_10000_288
      005206 E0               [24] 1255 	movx	a,@dptr
      005207 54 0F            [12] 1256 	anl	a,#0x0f
      005209 FF               [12] 1257 	mov	r7,a
      00520A 90 07 1B         [24] 1258 	mov	dptr,#_sine8_fraction_10000_288
      00520D F0               [24] 1259 	movx	@dptr,a
                                   1260 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      00520E 90 07 19         [24] 1261 	mov	dptr,#_sine8_theta_10000_287
      005211 E0               [24] 1262 	movx	a,@dptr
      005212 30 E6 06         [24] 1263 	jnb	acc.6,00104$
      005215 90 07 1B         [24] 1264 	mov	dptr,#_sine8_fraction_10000_288
      005218 EF               [12] 1265 	mov	a,r7
      005219 04               [12] 1266 	inc	a
      00521A F0               [24] 1267 	movx	@dptr,a
      00521B                       1268 00104$:
                                   1269 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      00521B 90 07 1A         [24] 1270 	mov	dptr,#_sine8_offset_10000_288
      00521E E0               [24] 1271 	movx	a,@dptr
      00521F C4               [12] 1272 	swap	a
      005220 54 0F            [12] 1273 	anl	a,#0x0f
                                   1274 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005222 25 E0            [12] 1275 	add	a,acc
      005224 FF               [12] 1276 	mov	r7,a
      005225 90 BD 6A         [24] 1277 	mov	dptr,#_sine8_coefficients_10000_288
      005228 93               [24] 1278 	movc	a,@a+dptr
      005229 FE               [12] 1279 	mov	r6,a
      00522A 0F               [12] 1280 	inc	r7
      00522B EF               [12] 1281 	mov	a,r7
      00522C 90 BD 6A         [24] 1282 	mov	dptr,#_sine8_coefficients_10000_288
      00522F 93               [24] 1283 	movc	a,@a+dptr
      005230 FF               [12] 1284 	mov	r7,a
      005231 90 07 1B         [24] 1285 	mov	dptr,#_sine8_fraction_10000_288
      005234 E0               [24] 1286 	movx	a,@dptr
      005235 8F F0            [24] 1287 	mov	b,r7
      005237 A4               [48] 1288 	mul	ab
      005238 FF               [12] 1289 	mov	r7,a
      005239 E5 F0            [12] 1290 	mov	a,b
      00523B C4               [12] 1291 	swap	a
      00523C CF               [12] 1292 	xch	a,r7
      00523D C4               [12] 1293 	swap	a
      00523E 54 0F            [12] 1294 	anl	a,#0x0f
      005240 6F               [12] 1295 	xrl	a,r7
      005241 CF               [12] 1296 	xch	a,r7
      005242 54 0F            [12] 1297 	anl	a,#0x0f
      005244 CF               [12] 1298 	xch	a,r7
      005245 6F               [12] 1299 	xrl	a,r7
      005246 CF               [12] 1300 	xch	a,r7
      005247 EF               [12] 1301 	mov	a,r7
      005248 2E               [12] 1302 	add	a, r6
      005249 FF               [12] 1303 	mov	r7,a
                                   1304 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      00524A 90 07 19         [24] 1305 	mov	dptr,#_sine8_theta_10000_287
      00524D E0               [24] 1306 	movx	a,@dptr
      00524E 30 E7 09         [24] 1307 	jnb	acc.7,00107$
      005251 8F 06            [24] 1308 	mov	ar6,r7
      005253 74 80            [12] 1309 	mov	a,#0x80
      005255 C3               [12] 1310 	clr	c
      005256 9E               [12] 1311 	subb	a,r6
      005257 FE               [12] 1312 	mov	r6,a
      005258 80 04            [24] 1313 	sjmp	00108$
      00525A                       1314 00107$:
      00525A 74 80            [12] 1315 	mov	a,#0x80
      00525C 2F               [12] 1316 	add	a, r7
      00525D FE               [12] 1317 	mov	r6,a
      00525E                       1318 00108$:
      00525E 8E 82            [24] 1319 	mov	dpl, r6
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005260 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'breathing_cie'
                                   1324 ;------------------------------------------------------------
                                   1325 ;value         Allocated with name '_breathing_cie_value_10000_291'
                                   1326 ;index         Allocated with name '_breathing_cie_index_10000_292'
                                   1327 ;low           Allocated with name '_breathing_cie_low_10000_292'
                                   1328 ;delta         Allocated with name '_breathing_cie_delta_10001_294'
                                   1329 ;fraction      Allocated with name '_breathing_cie_fraction_10001_294'
                                   1330 ;product       Allocated with name '_breathing_cie_product_10001_294'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function breathing_cie
                                   1335 ;	-----------------------------------------
      005261                       1336 _breathing_cie:
      005261 E5 82            [12] 1337 	mov	a,dpl
      005263 90 07 1C         [24] 1338 	mov	dptr,#_breathing_cie_value_10000_291
      005266 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005267 E0               [24] 1341 	movx	a,@dptr
      005268 FF               [12] 1342 	mov	r7,a
      005269 12 58 17         [24] 1343 	lcall	_ak820_outline_0196
                                   1344 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00526C FE               [12] 1345 	mov	r6,a
      00526D 90 C0 76         [24] 1346 	mov	dptr,#_CIE1931_CURVE
      005270 93               [24] 1347 	movc	a,@a+dptr
      005271 FD               [12] 1348 	mov	r5,a
                                   1349 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      005272 BE 1F 03         [24] 1350 	cjne	r6,#0x1f,00102$
      005275 8D 82            [24] 1351 	mov	dpl, r5
      005277 22               [24] 1352 	ret
      005278                       1353 00102$:
                                   1354 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      005278 EE               [12] 1355 	mov	a,r6
      005279 04               [12] 1356 	inc	a
      00527A 90 C0 76         [24] 1357 	mov	dptr,#_CIE1931_CURVE
      00527D 93               [24] 1358 	movc	a,@a+dptr
      00527E C3               [12] 1359 	clr	c
      00527F 9D               [12] 1360 	subb	a,r5
      005280 FE               [12] 1361 	mov	r6,a
                                   1362 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005281 74 07            [12] 1363 	mov	a,#0x07
      005283 5F               [12] 1364 	anl	a,r7
                                   1365 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005284 F5 F0            [12] 1366 	mov	b,a
      005286 EE               [12] 1367 	mov	a,r6
      005287 A4               [48] 1368 	mul	ab
                                   1369 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005288 12 58 17         [24] 1370 	lcall	_ak820_outline_0196
      00528B 2D               [12] 1371 	add	a, r5
                                   1372 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      00528C F5 82            [12] 1373 	mov	dpl,a
      00528E 22               [24] 1374 	ret
                                   1375 ;------------------------------------------------------------
                                   1376 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1377 ;------------------------------------------------------------
                                   1378 ;end           Allocated with name '_rgb_matrix_task_end_10000_296'
                                   1379 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_296'
                                   1380 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_296'
                                   1381 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_314'
                                   1382 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_314'
                                   1383 ;age           Allocated with name '_rgb_matrix_task_age_80000_314'
                                   1384 ;------------------------------------------------------------
                                   1385 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1386 ;	-----------------------------------------
                                   1387 ;	 function rgb_matrix_task
                                   1388 ;	-----------------------------------------
      00528F                       1389 _rgb_matrix_task:
                                   1390 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      00528F 12 4F D5         [24] 1391 	lcall	_age_reactive
                                   1392 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005292 30 12 18         [24] 1393 	jnb	_dirty,00102$
      005295 90 06 AC         [24] 1394 	mov	dptr,#_changed_at
      005298 12 38 81         [24] 1395 	lcall	_ak820_outline_0010
      00529B 12 49 AB         [24] 1396 	lcall	_timer_elapsed
      00529E 12 43 D5         [24] 1397 	lcall	_ak820_outline_0131
      0052A1 C3               [12] 1398 	clr	c
      0052A2 EE               [12] 1399 	mov	a,r6
      0052A3 94 E8            [12] 1400 	subb	a,#0xe8
      0052A5 EF               [12] 1401 	mov	a,r7
      0052A6 94 03            [12] 1402 	subb	a,#0x03
      0052A8 40 03            [24] 1403 	jc	00102$
      0052AA 12 50 A4         [24] 1404 	lcall	_eeconfig_update_rgb_matrix
      0052AD                       1405 00102$:
                                   1406 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0052AD 30 13 03         [24] 1407 	jnb	_rendering,00254$
      0052B0 02 53 68         [24] 1408 	ljmp	00109$
      0052B3                       1409 00254$:
                                   1410 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0052B3 90 06 AE         [24] 1411 	mov	dptr,#_frame_at
      0052B6 12 38 81         [24] 1412 	lcall	_ak820_outline_0010
      0052B9 12 49 AB         [24] 1413 	lcall	_timer_elapsed
      0052BC 12 43 D5         [24] 1414 	lcall	_ak820_outline_0131
      0052BF C3               [12] 1415 	clr	c
      0052C0 EE               [12] 1416 	mov	a,r6
      0052C1 94 10            [12] 1417 	subb	a,#0x10
      0052C3 EF               [12] 1418 	mov	a,r7
      0052C4 94 00            [12] 1419 	subb	a,#0x00
      0052C6 50 01            [24] 1420 	jnc	00105$
      0052C8 22               [24] 1421 	ret
      0052C9                       1422 00105$:
                                   1423 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0052C9 12 49 A8         [24] 1424 	lcall	_timer_read
      0052CC 12 39 22         [24] 1425 	lcall	_ak820_outline_0145
      0052CF 90 06 AE         [24] 1426 	mov	dptr,#_frame_at
      0052D2 12 57 F5         [24] 1427 	lcall	_ak820_outline_0173
                                   1428 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0052D5 90 06 A8         [24] 1429 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0052D8 E0               [24] 1430 	movx	a,@dptr
      0052D9 FF               [12] 1431 	mov	r7,a
      0052DA 7E 00            [12] 1432 	mov	r6,#0x00
      0052DC 74 20            [12] 1433 	mov	a,#0x20
      0052DE 2F               [12] 1434 	add	a, r7
      0052DF FF               [12] 1435 	mov	r7,a
      0052E0 E4               [12] 1436 	clr	a
      0052E1 3E               [12] 1437 	addc	a, r6
      0052E2 FE               [12] 1438 	mov	r6,a
      0052E3 90 06 B0         [24] 1439 	mov	dptr,#_phase
      0052E6 12 38 DA         [24] 1440 	lcall	_ak820_outline_0076
      0052E9 EF               [12] 1441 	mov	a,r7
      0052EA 2C               [12] 1442 	add	a, r4
      0052EB FF               [12] 1443 	mov	r7,a
      0052EC EE               [12] 1444 	mov	a,r6
      0052ED 3D               [12] 1445 	addc	a, r5
      0052EE FE               [12] 1446 	mov	r6,a
      0052EF 90 06 B0         [24] 1447 	mov	dptr,#_phase
      0052F2 EF               [12] 1448 	mov	a,r7
      0052F3 F0               [24] 1449 	movx	@dptr,a
      0052F4 EE               [12] 1450 	mov	a,r6
      0052F5 A3               [24] 1451 	inc	dptr
      0052F6 F0               [24] 1452 	movx	@dptr,a
                                   1453 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      0052F7 90 06 B0         [24] 1454 	mov	dptr,#_phase
      0052FA E0               [24] 1455 	movx	a,@dptr
      0052FB A3               [24] 1456 	inc	dptr
      0052FC E0               [24] 1457 	movx	a,@dptr
      0052FD FF               [12] 1458 	mov	r7,a
      0052FE 90 06 B8         [24] 1459 	mov	dptr,#_frame_phase
      005301 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005302 20 11 05         [24] 1462 	jb	_suspended,00135$
      005305 12 57 C7         [24] 1463 	lcall	_ak820_outline_0075
      005308 70 04            [24] 1464 	jnz	00132$
      00530A                       1465 00135$:
      00530A 7E 00            [12] 1466 	mov	r6,#0x00
      00530C 80 04            [24] 1467 	sjmp	00133$
      00530E                       1468 00132$:
      00530E 12 57 A0         [24] 1469 	lcall	_ak820_outline_0020
      005311 FE               [12] 1470 	mov	r6,a
      005312                       1471 00133$:
      005312 90 06 B3         [24] 1472 	mov	dptr,#_frame_mode
      005315 EE               [12] 1473 	mov	a,r6
      005316 F0               [24] 1474 	movx	@dptr,a
                                   1475 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005317 90 06 A5         [24] 1476 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00531A E0               [24] 1477 	movx	a,@dptr
      00531B 90 06 B4         [24] 1478 	mov	dptr,#_frame_hue
      00531E F0               [24] 1479 	movx	@dptr,a
                                   1480 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      00531F 90 06 A6         [24] 1481 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005322 E0               [24] 1482 	movx	a,@dptr
      005323 90 06 B5         [24] 1483 	mov	dptr,#_frame_sat
      005326 F0               [24] 1484 	movx	@dptr,a
                                   1485 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005327 90 06 A7         [24] 1486 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00532A E0               [24] 1487 	movx	a,@dptr
      00532B FD               [12] 1488 	mov	r5,a
      00532C 90 06 B6         [24] 1489 	mov	dptr,#_frame_val
      00532F F0               [24] 1490 	movx	@dptr,a
                                   1491 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005330 90 06 A9         [24] 1492 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005333 E0               [24] 1493 	movx	a,@dptr
      005334 90 06 B7         [24] 1494 	mov	dptr,#_frame_flags
      005337 F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005338 BE 02 26         [24] 1497 	cjne	r6,#0x02,00107$
                                   1498 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00533B EF               [12] 1499 	mov	a,r7
      00533C 24 C0            [12] 1500 	add	a,#0xc0
      00533E F5 82            [12] 1501 	mov	dpl,a
      005340 C0 05            [24] 1502 	push	ar5
      005342 12 51 E3         [24] 1503 	lcall	_sine8
      005345 AF 82            [24] 1504 	mov	r7, dpl
      005347 D0 05            [24] 1505 	pop	ar5
      005349 8D F0            [24] 1506 	mov	b,r5
      00534B EF               [12] 1507 	mov	a,r7
      00534C A4               [48] 1508 	mul	ab
      00534D AE F0            [24] 1509 	mov	r6,b
      00534F 8E 05            [24] 1510 	mov	ar5,r6
      005351 90 06 B6         [24] 1511 	mov	dptr,#_frame_val
      005354 ED               [12] 1512 	mov	a,r5
      005355 F0               [24] 1513 	movx	@dptr,a
                                   1514 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005356 8D 82            [24] 1515 	mov	dpl, r5
      005358 12 52 61         [24] 1516 	lcall	_breathing_cie
      00535B E5 82            [12] 1517 	mov	a, dpl
      00535D 90 06 B6         [24] 1518 	mov	dptr,#_frame_val
      005360 F0               [24] 1519 	movx	@dptr,a
      005361                       1520 00107$:
                                   1521 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005361 90 06 B2         [24] 1522 	mov	dptr,#_led_index
      005364 E4               [12] 1523 	clr	a
      005365 F0               [24] 1524 	movx	@dptr,a
                                   1525 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1526 ;	assignBit
      005366 D2 13            [12] 1527 	setb	_rendering
      005368                       1528 00109$:
                                   1529 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005368 12 58 12         [24] 1530 	lcall	_ak820_outline_0192
      00536B 24 08            [12] 1531 	add	a,#0x08
      00536D FF               [12] 1532 	mov	r7,a
      00536E 90 07 1D         [24] 1533 	mov	dptr,#_rgb_matrix_task_end_10000_296
      005371 F0               [24] 1534 	movx	@dptr,a
                                   1535 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005372 EF               [12] 1536 	mov	a,r7
      005373 24 AD            [12] 1537 	add	a,#0xff - 0x52
      005375 50 06            [24] 1538 	jnc	00125$
                                   1539 ;	free result
      005377 90 07 1D         [24] 1540 	mov	dptr,#_rgb_matrix_task_end_10000_296
      00537A 74 52            [12] 1541 	mov	a,#0x52
      00537C F0               [24] 1542 	movx	@dptr,a
                                   1543 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      00537D                       1544 00125$:
      00537D 12 58 12         [24] 1545 	lcall	_ak820_outline_0192
      005380 FF               [12] 1546 	mov	r7,a
      005381 90 07 1D         [24] 1547 	mov	dptr,#_rgb_matrix_task_end_10000_296
      005384 E0               [24] 1548 	movx	a,@dptr
      005385 FE               [12] 1549 	mov	r6,a
      005386 C3               [12] 1550 	clr	c
      005387 EF               [12] 1551 	mov	a,r7
      005388 9E               [12] 1552 	subb	a,r6
      005389 40 03            [24] 1553 	jc	00261$
      00538B 02 54 FF         [24] 1554 	ljmp	00127$
      00538E                       1555 00261$:
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      00538E 12 57 E8         [24] 1557 	lcall	_ak820_outline_0146
      005391 E0               [24] 1558 	movx	a,@dptr
      005392 60 07            [24] 1559 	jz	00121$
      005394 90 06 B7         [24] 1560 	mov	dptr,#_frame_flags
      005397 E0               [24] 1561 	movx	a,@dptr
      005398 20 E2 1C         [24] 1562 	jb	acc.2,00122$
      00539B                       1563 00121$:
                                   1564 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      00539B 12 58 12         [24] 1565 	lcall	_ak820_outline_0192
      00539E FC               [12] 1566 	mov	r4,a
      00539F 7D 00            [12] 1567 	mov	r5,#0x00
      0053A1 90 07 11         [24] 1568 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0053A4 E4               [12] 1569 	clr	a
      0053A5 F0               [24] 1570 	movx	@dptr,a
      0053A6 90 07 12         [24] 1571 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0053A9 F0               [24] 1572 	movx	@dptr,a
      0053AA 90 07 13         [24] 1573 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0053AD F0               [24] 1574 	movx	@dptr,a
      0053AE 12 34 76         [24] 1575 	lcall	_ak820_outline_0132
      0053B1 12 51 5E         [24] 1576 	lcall	_rgb_matrix_set_color
      0053B4 02 54 F6         [24] 1577 	ljmp	00123$
      0053B7                       1578 00122$:
                                   1579 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0053B7 BE 05 29         [24] 1580 	cjne	r6,#0x05,00119$
                                   1581 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0053BA EF               [12] 1582 	mov	a,r7
      0053BB 75 F0 03         [24] 1583 	mov	b,#0x03
      0053BE A4               [48] 1584 	mul	ab
      0053BF 24 AE            [12] 1585 	add	a, #_g_direct_mode_colors
      0053C1 FD               [12] 1586 	mov	r5,a
      0053C2 74 0C            [12] 1587 	mov	a,#(_g_direct_mode_colors >> 8)
      0053C4 35 F0            [12] 1588 	addc	a, b
      0053C6 FE               [12] 1589 	mov	r6,a
      0053C7 90 0D C2         [24] 1590 	mov	dptr,#___memcpy_PARM_2
      0053CA ED               [12] 1591 	mov	a,r5
      0053CB F0               [24] 1592 	movx	@dptr,a
      0053CC EE               [12] 1593 	mov	a,r6
      0053CD 12 38 E0         [24] 1594 	lcall	_ak820_outline_0081
      0053D0 90 0D C5         [24] 1595 	mov	dptr,#___memcpy_PARM_3
      0053D3 74 03            [12] 1596 	mov	a,#0x03
      0053D5 12 39 0D         [24] 1597 	lcall	_ak820_outline_0130
      0053D8 90 07 1E         [24] 1598 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      0053DB F5 F0            [12] 1599 	mov	b,a
      0053DD 12 BC 07         [24] 1600 	lcall	___memcpy
      0053E0 02 54 92         [24] 1601 	ljmp	00120$
      0053E3                       1602 00119$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      0053E3 90 06 B4         [24] 1604 	mov	dptr,#_frame_hue
      0053E6 E0               [24] 1605 	movx	a,@dptr
      0053E7 90 07 1E         [24] 1606 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      0053EA F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      0053EB 90 06 B5         [24] 1609 	mov	dptr,#_frame_sat
      0053EE E0               [24] 1610 	movx	a,@dptr
      0053EF 90 07 1F         [24] 1611 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0001)
      0053F2 F0               [24] 1612 	movx	@dptr,a
                                   1613 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      0053F3 90 06 B6         [24] 1614 	mov	dptr,#_frame_val
      0053F6 E0               [24] 1615 	movx	a,@dptr
      0053F7 90 07 20         [24] 1616 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0002)
      0053FA F0               [24] 1617 	movx	@dptr,a
                                   1618 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      0053FB 12 57 E8         [24] 1619 	lcall	_ak820_outline_0146
      0053FE BE 03 0E         [24] 1620 	cjne	r6,#0x03,00113$
      005401 90 07 1E         [24] 1621 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      005404 E0               [24] 1622 	movx	a,@dptr
      005405 FE               [12] 1623 	mov	r6,a
      005406 90 06 B8         [24] 1624 	mov	dptr,#_frame_phase
      005409 E0               [24] 1625 	movx	a,@dptr
      00540A 2E               [12] 1626 	add	a, r6
      00540B 90 07 1E         [24] 1627 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      00540E F0               [24] 1628 	movx	@dptr,a
      00540F                       1629 00113$:
                                   1630 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      00540F 12 57 E8         [24] 1631 	lcall	_ak820_outline_0146
      005412 BE 04 23         [24] 1632 	cjne	r6,#0x04,00115$
      005415 90 07 1E         [24] 1633 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      005418 E0               [24] 1634 	movx	a,@dptr
      005419 FE               [12] 1635 	mov	r6,a
      00541A 12 58 12         [24] 1636 	lcall	_ak820_outline_0192
      00541D 75 F0 02         [24] 1637 	mov	b,#0x02
      005420 A4               [48] 1638 	mul	ab
      005421 24 D2            [12] 1639 	add	a, #_ak820_led_points
      005423 F5 82            [12] 1640 	mov	dpl,a
      005425 74 BF            [12] 1641 	mov	a,#(_ak820_led_points >> 8)
      005427 12 57 EE         [24] 1642 	lcall	_ak820_outline_0156
      00542A FD               [12] 1643 	mov	r5,a
      00542B 90 06 B8         [24] 1644 	mov	dptr,#_frame_phase
      00542E E0               [24] 1645 	movx	a,@dptr
      00542F FC               [12] 1646 	mov	r4,a
      005430 ED               [12] 1647 	mov	a,r5
      005431 C3               [12] 1648 	clr	c
      005432 9C               [12] 1649 	subb	a,r4
      005433 2E               [12] 1650 	add	a, r6
      005434 90 07 1E         [24] 1651 	mov	dptr,#_rgb_matrix_task_hsv_10000_296
      005437 F0               [24] 1652 	movx	@dptr,a
      005438                       1653 00115$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005438 12 57 E8         [24] 1655 	lcall	_ak820_outline_0146
      00543B BE 06 54         [24] 1656 	cjne	r6,#0x06,00120$
                                   1657 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      00543E 12 58 00         [24] 1658 	lcall	_ak820_outline_0179
      005441 FE               [12] 1659 	mov	r6,a
      005442 74 07            [12] 1660 	mov	a,#0x07
      005444 C3               [12] 1661 	clr	c
      005445 9E               [12] 1662 	subb	a,r6
      005446 FE               [12] 1663 	mov	r6,a
                                   1664 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      005447 8E F0            [24] 1665 	mov	b,r6
      005449 05 F0            [12] 1666 	inc	b
      00544B 74 01            [12] 1667 	mov	a,#0x01
      00544D 80 02            [24] 1668 	sjmp	00273$
      00544F                       1669 00272$:
      00544F 25 E0            [12] 1670 	add	a,acc
      005451                       1671 00273$:
      005451 D5 F0 FB         [24] 1672 	djnz	b,00272$
      005454 FD               [12] 1673 	mov	r5,a
                                   1674 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      005455 12 58 12         [24] 1675 	lcall	_ak820_outline_0192
      005458 24 B9            [12] 1676 	add	a, #_reactive_age
      00545A F5 82            [12] 1677 	mov	dpl,a
      00545C E4               [12] 1678 	clr	a
      00545D 34 06            [12] 1679 	addc	a, #(_reactive_age >> 8)
      00545F F5 83            [12] 1680 	mov	dph,a
      005461 E0               [24] 1681 	movx	a,@dptr
                                   1682 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005462 FC               [12] 1683 	mov	r4,a
      005463 C3               [12] 1684 	clr	c
      005464 9D               [12] 1685 	subb	a,r5
      005465 40 07            [24] 1686 	jc	00137$
      005467 90 06 B6         [24] 1687 	mov	dptr,#_frame_val
      00546A E0               [24] 1688 	movx	a,@dptr
      00546B FB               [12] 1689 	mov	r3,a
      00546C 80 1F            [24] 1690 	sjmp	00138$
      00546E                       1691 00137$:
      00546E 90 06 B6         [24] 1692 	mov	dptr,#_frame_val
      005471 E0               [24] 1693 	movx	a,@dptr
      005472 F5 F0            [12] 1694 	mov	b, a
      005474 EC               [12] 1695 	mov	a,r4
      005475 A4               [48] 1696 	mul	ab
      005476 FC               [12] 1697 	mov	r4,a
      005477 AA F0            [24] 1698 	mov	r2,b
      005479 8E F0            [24] 1699 	mov	b,r6
      00547B 05 F0            [12] 1700 	inc	b
      00547D AB 04            [24] 1701 	mov	r3,ar4
      00547F AD 02            [24] 1702 	mov	r5,ar2
      005481 80 07            [24] 1703 	sjmp	00276$
      005483                       1704 00275$:
      005483 C3               [12] 1705 	clr	c
      005484 ED               [12] 1706 	mov	a,r5
      005485 13               [12] 1707 	rrc	a
      005486 FD               [12] 1708 	mov	r5,a
      005487 EB               [12] 1709 	mov	a,r3
      005488 13               [12] 1710 	rrc	a
      005489 FB               [12] 1711 	mov	r3,a
      00548A                       1712 00276$:
      00548A D5 F0 F6         [24] 1713 	djnz	b,00275$
      00548D                       1714 00138$:
      00548D 90 07 20         [24] 1715 	mov	dptr,#(_rgb_matrix_task_hsv_10000_296 + 0x0002)
      005490 EB               [12] 1716 	mov	a,r3
      005491 F0               [24] 1717 	movx	@dptr,a
      005492                       1718 00120$:
                                   1719 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      005492 12 57 E8         [24] 1720 	lcall	_ak820_outline_0146
      005495 BE 02 03         [24] 1721 	cjne	r6,#0x02,00277$
      005498 D3               [12] 1722 	setb	c
      005499 80 01            [24] 1723 	sjmp	00278$
      00549B                       1724 00277$:
      00549B C3               [12] 1725 	clr	c
      00549C                       1726 00278$:
      00549C B3               [12] 1727 	cpl	c
      00549D 92 14            [24] 1728 	mov	_rgb_matrix_task_sloc0_1_0,c
      00549F 90 0D C2         [24] 1729 	mov	dptr,#___memcpy_PARM_2
      0054A2 74 1E            [12] 1730 	mov	a,#_rgb_matrix_task_hsv_10000_296
      0054A4 F0               [24] 1731 	movx	@dptr,a
      0054A5 74 07            [12] 1732 	mov	a,#(_rgb_matrix_task_hsv_10000_296 >> 8)
      0054A7 12 38 E0         [24] 1733 	lcall	_ak820_outline_0081
      0054AA 90 0D C5         [24] 1734 	mov	dptr,#___memcpy_PARM_3
      0054AD 74 03            [12] 1735 	mov	a,#0x03
      0054AF 12 39 0D         [24] 1736 	lcall	_ak820_outline_0130
      0054B2 90 0A BC         [24] 1737 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0054B5 F5 F0            [12] 1738 	mov	b,a
      0054B7 12 BC 07         [24] 1739 	lcall	___memcpy
      0054BA 90 0A BF         [24] 1740 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0054BD 74 21            [12] 1741 	mov	a,#_rgb_matrix_task_rgb_10000_296
      0054BF F0               [24] 1742 	movx	@dptr,a
      0054C0 74 07            [12] 1743 	mov	a,#(_rgb_matrix_task_rgb_10000_296 >> 8)
      0054C2 A3               [24] 1744 	inc	dptr
      0054C3 F0               [24] 1745 	movx	@dptr,a
      0054C4 A2 14            [12] 1746 	mov	c,_rgb_matrix_task_sloc0_1_0
      0054C6 12 39 33         [24] 1747 	lcall	_ak820_outline_0163
      0054C9 12 82 B9         [24] 1748 	lcall	_hsv_to_rgb_into
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0054CC 12 58 12         [24] 1750 	lcall	_ak820_outline_0192
      0054CF FD               [12] 1751 	mov	r5,a
      0054D0 7E 00            [12] 1752 	mov	r6,#0x00
      0054D2 90 07 22         [24] 1753 	mov	dptr,#(_rgb_matrix_task_rgb_10000_296 + 0x0001)
      0054D5 E0               [24] 1754 	movx	a,@dptr
      0054D6 FC               [12] 1755 	mov	r4,a
      0054D7 90 07 21         [24] 1756 	mov	dptr,#_rgb_matrix_task_rgb_10000_296
      0054DA E0               [24] 1757 	movx	a,@dptr
      0054DB FB               [12] 1758 	mov	r3,a
      0054DC 90 07 23         [24] 1759 	mov	dptr,#(_rgb_matrix_task_rgb_10000_296 + 0x0002)
      0054DF E0               [24] 1760 	movx	a,@dptr
      0054E0 FA               [12] 1761 	mov	r2,a
      0054E1 90 07 11         [24] 1762 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0054E4 EC               [12] 1763 	mov	a,r4
      0054E5 F0               [24] 1764 	movx	@dptr,a
      0054E6 90 07 12         [24] 1765 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0054E9 EB               [12] 1766 	mov	a,r3
      0054EA F0               [24] 1767 	movx	@dptr,a
      0054EB 90 07 13         [24] 1768 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0054EE EA               [12] 1769 	mov	a,r2
      0054EF F0               [24] 1770 	movx	@dptr,a
      0054F0 12 39 17         [24] 1771 	lcall	_ak820_outline_0141
      0054F3 12 51 5E         [24] 1772 	lcall	_rgb_matrix_set_color
      0054F6                       1773 00123$:
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      0054F6 12 58 12         [24] 1775 	lcall	_ak820_outline_0192
      0054F9 24 01            [12] 1776 	add	a, #0x01
      0054FB F0               [24] 1777 	movx	@dptr,a
      0054FC 02 53 7D         [24] 1778 	ljmp	00125$
      0054FF                       1779 00127$:
                                   1780 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      0054FF BF 52 16         [24] 1781 	cjne	r7,#0x52,00130$
                                   1782 ;	keyboards/ajazz/ak820/ak820_rgb.c:219: rgb_matrix_driver.flush();
      005502 90 BD 68         [24] 1783 	mov	dptr,#(_rgb_matrix_driver + 0x0006)
      005505 12 57 A9         [24] 1784 	lcall	_ak820_outline_0046
      005508 C0 07            [24] 1785 	push	ar7
      00550A C0 06            [24] 1786 	push	ar6
      00550C 12 39 08         [24] 1787 	lcall	_ak820_outline_0123
      00550F 12 30 75         [24] 1788 	lcall	__sdcc_call_dptr
      005512 D0 06            [24] 1789 	pop	ar6
      005514 D0 07            [24] 1790 	pop	ar7
                                   1791 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1792 ;	assignBit
      005516 C2 13            [12] 1793 	clr	_rendering
      005518                       1794 00130$:
                                   1795 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005518 22               [24] 1796 	ret
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1799 ;------------------------------------------------------------
                                   1800 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1801 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1802 ;row           Allocated with name '_process_rgb_matrix_row_10000_317'
                                   1803 ;i             Allocated with name '_process_rgb_matrix_i_10000_318'
                                   1804 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_318'
                                   1805 ;------------------------------------------------------------
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1807 ;	-----------------------------------------
                                   1808 ;	 function process_rgb_matrix
                                   1809 ;	-----------------------------------------
      005519                       1810 _process_rgb_matrix:
      005519 E5 82            [12] 1811 	mov	a,dpl
      00551B 90 07 26         [24] 1812 	mov	dptr,#_process_rgb_matrix_row_10000_317
      00551E F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00551F 90 07 25         [24] 1815 	mov	dptr,#_process_rgb_matrix_PARM_3
      005522 E0               [24] 1816 	movx	a,@dptr
      005523 60 23            [24] 1817 	jz	00101$
      005525 20 11 20         [24] 1818 	jb	_suspended,00101$
      005528 12 57 C7         [24] 1819 	lcall	_ak820_outline_0075
      00552B 60 1B            [24] 1820 	jz	00101$
                                   1821 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00552D 12 57 A0         [24] 1822 	lcall	_ak820_outline_0020
      005530 FF               [12] 1823 	mov	r7,a
      005531 BF 06 14         [24] 1824 	cjne	r7,#0x06,00101$
      005534 90 07 26         [24] 1825 	mov	dptr,#_process_rgb_matrix_row_10000_317
      005537 E0               [24] 1826 	movx	a,@dptr
      005538 FF               [12] 1827 	mov	r7,a
      005539 BF 10 00         [24] 1828 	cjne	r7,#0x10,00169$
      00553C                       1829 00169$:
      00553C 50 0A            [24] 1830 	jnc	00101$
      00553E 90 07 24         [24] 1831 	mov	dptr,#_process_rgb_matrix_PARM_2
      005541 E0               [24] 1832 	movx	a,@dptr
      005542 FE               [12] 1833 	mov	r6,a
      005543 BE 08 00         [24] 1834 	cjne	r6,#0x08,00171$
      005546                       1835 00171$:
      005546 40 01            [24] 1836 	jc	00102$
      005548                       1837 00101$:
      005548 22               [24] 1838 	ret
      005549                       1839 00102$:
                                   1840 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005549 C0 07            [24] 1841 	push	ar7
      00554B C0 06            [24] 1842 	push	ar6
      00554D 12 4F D5         [24] 1843 	lcall	_age_reactive
      005550 D0 06            [24] 1844 	pop	ar6
      005552 D0 07            [24] 1845 	pop	ar7
                                   1846 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005554 EF               [12] 1847 	mov	a,r7
      005555 C4               [12] 1848 	swap	a
      005556 03               [12] 1849 	rr	a
      005557 54 F8            [12] 1850 	anl	a,#0xf8
      005559 2E               [12] 1851 	add	a,r6
      00555A FF               [12] 1852 	mov	r7,a
                                   1853 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00555B 7E 00            [12] 1854 	mov	r6,#0x00
      00555D                       1855 00111$:
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      00555D EE               [12] 1857 	mov	a,r6
      00555E 90 BD 10         [24] 1858 	mov	dptr,#_ak820_rgb_slots
      005561 93               [24] 1859 	movc	a,@a+dptr
      005562 B5 07 29         [24] 1860 	cjne	a,ar7,00112$
                                   1861 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005565 EE               [12] 1862 	mov	a,r6
      005566 24 B9            [12] 1863 	add	a, #_reactive_age
      005568 FC               [12] 1864 	mov	r4,a
      005569 E4               [12] 1865 	clr	a
      00556A 34 06            [12] 1866 	addc	a, #(_reactive_age >> 8)
      00556C FD               [12] 1867 	mov	r5,a
      00556D 12 58 00         [24] 1868 	lcall	_ak820_outline_0179
      005570 F5 F0            [12] 1869 	mov	b, a
      005572 05 F0            [12] 1870 	inc	b
      005574 7B 80            [12] 1871 	mov	r3,#0x80
      005576 E4               [12] 1872 	clr	a
      005577 FA               [12] 1873 	mov	r2,a
      005578 33               [12] 1874 	rlc	a
      005579 92 D2            [24] 1875 	mov	ov,c
      00557B 80 08            [24] 1876 	sjmp	00176$
      00557D                       1877 00175$:
      00557D A2 D2            [12] 1878 	mov	c,ov
      00557F EA               [12] 1879 	mov	a,r2
      005580 13               [12] 1880 	rrc	a
      005581 FA               [12] 1881 	mov	r2,a
      005582 EB               [12] 1882 	mov	a,r3
      005583 13               [12] 1883 	rrc	a
      005584 FB               [12] 1884 	mov	r3,a
      005585                       1885 00176$:
      005585 D5 F0 F5         [24] 1886 	djnz	b,00175$
      005588 12 34 76         [24] 1887 	lcall	_ak820_outline_0132
      00558B EB               [12] 1888 	mov	a,r3
      00558C F0               [24] 1889 	movx	@dptr,a
                                   1890 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      00558D 22               [24] 1891 	ret
      00558E                       1892 00112$:
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00558E 0E               [12] 1894 	inc	r6
      00558F BE 52 00         [24] 1895 	cjne	r6,#0x52,00177$
      005592                       1896 00177$:
      005592 40 C9            [24] 1897 	jc	00111$
                                   1898 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005594 22               [24] 1899 	ret
                                   1900 ;------------------------------------------------------------
                                   1901 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1902 ;------------------------------------------------------------
                                   1903 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1904 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_324'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function rgb_matrix_set_suspend_state
                                   1909 ;	-----------------------------------------
      005595                       1910 _rgb_matrix_set_suspend_state:
      005595 E5 82            [12] 1911 	mov	a,dpl
      005597 90 07 27         [24] 1912 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_324
      00559A F0               [24] 1913 	movx	@dptr,a
                                   1914 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      00559B E0               [24] 1915 	movx	a,@dptr
                                   1916 ;	assignBit
      00559C F5 15            [12] 1917 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      00559E 13               [12] 1918 	rrc	a
      00559F 92 11            [24] 1919 	mov	_suspended,c
                                   1920 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1921 ;	assignBit
      0055A1 C2 13            [12] 1922 	clr	_rendering
                                   1923 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0055A3 12 4F B8         [24] 1924 	lcall	_clear_reactive
                                   1925 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0055A6 E5 15            [12] 1926 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0055A8 60 23            [24] 1927 	jz	00103$
                                   1928 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0055AA 90 07 16         [24] 1929 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0055AD E4               [12] 1930 	clr	a
      0055AE F0               [24] 1931 	movx	@dptr,a
      0055AF 90 07 17         [24] 1932 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0055B2 F0               [24] 1933 	movx	@dptr,a
      0055B3 75 82 00         [24] 1934 	mov	dpl, #0x00
      0055B6 12 51 AD         [24] 1935 	lcall	_rgb_matrix_set_color_all
                                   1936 ;	keyboards/ajazz/ak820/ak820_rgb.c:244: rgb_matrix_driver.flush();
      0055B9 90 BD 68         [24] 1937 	mov	dptr,#(_rgb_matrix_driver + 0x0006)
      0055BC 12 57 A9         [24] 1938 	lcall	_ak820_outline_0046
      0055BF C0 07            [24] 1939 	push	ar7
      0055C1 C0 06            [24] 1940 	push	ar6
      0055C3 12 39 08         [24] 1941 	lcall	_ak820_outline_0123
      0055C6 12 30 75         [24] 1942 	lcall	__sdcc_call_dptr
      0055C9 D0 06            [24] 1943 	pop	ar6
      0055CB D0 07            [24] 1944 	pop	ar7
      0055CD                       1945 00103$:
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:246: }
      0055CD 22               [24] 1947 	ret
                                   1948 ;------------------------------------------------------------
                                   1949 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1950 ;------------------------------------------------------------
                                   1951 ;	keyboards/ajazz/ak820/ak820_rgb.c:248: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1952 ;	-----------------------------------------
                                   1953 ;	 function rgb_matrix_is_enabled
                                   1954 ;	-----------------------------------------
      0055CE                       1955 _rgb_matrix_is_enabled:
      0055CE 12 57 C7         [24] 1956 	lcall	_ak820_outline_0075
      0055D1 F5 82            [12] 1957 	mov	dpl,a
      0055D3 22               [24] 1958 	ret
                                   1959 ;------------------------------------------------------------
                                   1960 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1961 ;------------------------------------------------------------
                                   1962 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1963 ;	-----------------------------------------
                                   1964 ;	 function rgb_matrix_get_mode
                                   1965 ;	-----------------------------------------
      0055D4                       1966 _rgb_matrix_get_mode:
      0055D4 12 57 A0         [24] 1967 	lcall	_ak820_outline_0020
      0055D7 F5 82            [12] 1968 	mov	dpl,a
      0055D9 22               [24] 1969 	ret
                                   1970 ;------------------------------------------------------------
                                   1971 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	keyboards/ajazz/ak820/ak820_rgb.c:251: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function rgb_matrix_get_hue
                                   1976 ;	-----------------------------------------
      0055DA                       1977 _rgb_matrix_get_hue:
      0055DA 90 06 A5         [24] 1978 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055DD E0               [24] 1979 	movx	a,@dptr
      0055DE F5 82            [12] 1980 	mov	dpl,a
      0055E0 22               [24] 1981 	ret
                                   1982 ;------------------------------------------------------------
                                   1983 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1984 ;------------------------------------------------------------
                                   1985 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1986 ;	-----------------------------------------
                                   1987 ;	 function rgb_matrix_get_sat
                                   1988 ;	-----------------------------------------
      0055E1                       1989 _rgb_matrix_get_sat:
      0055E1 90 06 A6         [24] 1990 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055E4 E0               [24] 1991 	movx	a,@dptr
      0055E5 F5 82            [12] 1992 	mov	dpl,a
      0055E7 22               [24] 1993 	ret
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function rgb_matrix_get_val
                                   2000 ;	-----------------------------------------
      0055E8                       2001 _rgb_matrix_get_val:
      0055E8 90 06 A7         [24] 2002 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055EB E0               [24] 2003 	movx	a,@dptr
      0055EC F5 82            [12] 2004 	mov	dpl,a
      0055EE 22               [24] 2005 	ret
                                   2006 ;------------------------------------------------------------
                                   2007 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   2008 ;------------------------------------------------------------
                                   2009 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   2010 ;	-----------------------------------------
                                   2011 ;	 function rgb_matrix_get_speed
                                   2012 ;	-----------------------------------------
      0055EF                       2013 _rgb_matrix_get_speed:
      0055EF 90 06 A8         [24] 2014 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0055F2 E0               [24] 2015 	movx	a,@dptr
      0055F3 F5 82            [12] 2016 	mov	dpl,a
      0055F5 22               [24] 2017 	ret
                                   2018 ;------------------------------------------------------------
                                   2019 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   2020 ;------------------------------------------------------------
                                   2021 ;	keyboards/ajazz/ak820/ak820_rgb.c:256: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   2022 ;	-----------------------------------------
                                   2023 ;	 function rgb_matrix_toggle_noeeprom
                                   2024 ;	-----------------------------------------
      0055F6                       2025 _rgb_matrix_toggle_noeeprom:
      0055F6 12 57 C7         [24] 2026 	lcall	_ak820_outline_0075
      0055F9 FF               [12] 2027 	mov	r7,a
      0055FA 63 07 01         [24] 2028 	xrl	ar7,#0x01
      0055FD 90 06 A4         [24] 2029 	mov	dptr,#_rgb_matrix_config
      005600 EF               [12] 2030 	mov	a,r7
      005601 54 03            [12] 2031 	anl	a,#0x03
      005603 F5 F0            [12] 2032 	mov	b,a
      005605 E0               [24] 2033 	movx	a,@dptr
      005606 54 FC            [12] 2034 	anl	a,#0xfc
      005608 45 F0            [12] 2035 	orl	a,b
      00560A F0               [24] 2036 	movx	@dptr,a
                                   2037 ;	assignBit
      00560B C2 13            [12] 2038 	clr	_rendering
      00560D 02 4F B8         [24] 2039 	ljmp	_clear_reactive
                                   2040 ;------------------------------------------------------------
                                   2041 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   2042 ;------------------------------------------------------------
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   2044 ;	-----------------------------------------
                                   2045 ;	 function rgb_matrix_enable_noeeprom
                                   2046 ;	-----------------------------------------
      005610                       2047 _rgb_matrix_enable_noeeprom:
      005610 12 57 C7         [24] 2048 	lcall	_ak820_outline_0075
      005613 70 03            [24] 2049 	jnz	00102$
      005615 12 4F B8         [24] 2050 	lcall	_clear_reactive
      005618                       2051 00102$:
      005618 12 57 E1         [24] 2052 	lcall	_ak820_outline_0117
      00561B 44 01            [12] 2053 	orl	a,#0x01
      00561D F0               [24] 2054 	movx	@dptr,a
                                   2055 ;	assignBit
      00561E C2 13            [12] 2056 	clr	_rendering
      005620 22               [24] 2057 	ret
                                   2058 ;------------------------------------------------------------
                                   2059 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2060 ;------------------------------------------------------------
                                   2061 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2062 ;	-----------------------------------------
                                   2063 ;	 function rgb_matrix_disable_noeeprom
                                   2064 ;	-----------------------------------------
      005621                       2065 _rgb_matrix_disable_noeeprom:
      005621 12 57 E1         [24] 2066 	lcall	_ak820_outline_0117
      005624 F0               [24] 2067 	movx	@dptr,a
                                   2068 ;	assignBit
      005625 C2 13            [12] 2069 	clr	_rendering
      005627 02 4F B8         [24] 2070 	ljmp	_clear_reactive
                                   2071 ;------------------------------------------------------------
                                   2072 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2073 ;------------------------------------------------------------
                                   2074 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_353'
                                   2075 ;------------------------------------------------------------
                                   2076 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2077 ;	-----------------------------------------
                                   2078 ;	 function rgb_matrix_mode_noeeprom
                                   2079 ;	-----------------------------------------
      00562A                       2080 _rgb_matrix_mode_noeeprom:
      00562A E5 82            [12] 2081 	mov	a,dpl
      00562C 90 07 28         [24] 2082 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_353
      00562F F0               [24] 2083 	movx	@dptr,a
                                   2084 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005630 E0               [24] 2085 	movx	a,@dptr
      005631 FF               [12] 2086 	mov	r7,a
      005632 60 05            [24] 2087 	jz	00101$
      005634 BF 07 00         [24] 2088 	cjne	r7,#0x07,00123$
      005637                       2089 00123$:
      005637 40 01            [24] 2090 	jc	00102$
      005639                       2091 00101$:
      005639 22               [24] 2092 	ret
      00563A                       2093 00102$:
                                   2094 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: if (mode != rgb_matrix_config.mode) clear_reactive();
      00563A 12 57 A0         [24] 2095 	lcall	_ak820_outline_0020
      00563D FE               [12] 2096 	mov	r6,a
      00563E EF               [12] 2097 	mov	a,r7
      00563F B5 06 02         [24] 2098 	cjne	a,ar6,00125$
      005642 80 03            [24] 2099 	sjmp	00105$
      005644                       2100 00125$:
      005644 12 4F B8         [24] 2101 	lcall	_clear_reactive
      005647                       2102 00105$:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rgb_matrix_config.mode = mode;
      005647 90 07 28         [24] 2104 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_353
      00564A E0               [24] 2105 	movx	a,@dptr
      00564B 90 06 A4         [24] 2106 	mov	dptr,#_rgb_matrix_config
      00564E 25 E0            [12] 2107 	add	a,acc
      005650 25 E0            [12] 2108 	add	a,acc
      005652 54 FC            [12] 2109 	anl	a,#0xfc
      005654 F5 F0            [12] 2110 	mov	b,a
      005656 E0               [24] 2111 	movx	a,@dptr
      005657 54 03            [12] 2112 	anl	a,#0x03
      005659 45 F0            [12] 2113 	orl	a,b
      00565B F0               [24] 2114 	movx	@dptr,a
                                   2115 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: rendering = false;
                                   2116 ;	assignBit
      00565C C2 13            [12] 2117 	clr	_rendering
                                   2118 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: }
      00565E 22               [24] 2119 	ret
                                   2120 ;------------------------------------------------------------
                                   2121 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2122 ;------------------------------------------------------------
                                   2123 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: void rgb_matrix_step_noeeprom(void) {
                                   2124 ;	-----------------------------------------
                                   2125 ;	 function rgb_matrix_step_noeeprom
                                   2126 ;	-----------------------------------------
      00565F                       2127 _rgb_matrix_step_noeeprom:
                                   2128 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      00565F 12 57 A0         [24] 2129 	lcall	_ak820_outline_0020
      005662 FF               [12] 2130 	mov	r7,a
      005663 0F               [12] 2131 	inc	r7
      005664 BF 07 00         [24] 2132 	cjne	r7,#0x07,00112$
      005667                       2133 00112$:
      005667 40 04            [24] 2134 	jc	00103$
      005669 7F 01            [12] 2135 	mov	r7,#0x01
      00566B 80 07            [24] 2136 	sjmp	00104$
      00566D                       2137 00103$:
      00566D 12 57 A0         [24] 2138 	lcall	_ak820_outline_0020
      005670 FE               [12] 2139 	mov	r6,a
      005671 0E               [12] 2140 	inc	r6
      005672 8E 07            [24] 2141 	mov	ar7,r6
      005674                       2142 00104$:
      005674 8F 82            [24] 2143 	mov	dpl, r7
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: }
      005676 02 56 2A         [24] 2145 	ljmp	_rgb_matrix_mode_noeeprom
                                   2146 ;------------------------------------------------------------
                                   2147 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2148 ;------------------------------------------------------------
                                   2149 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2150 ;	-----------------------------------------
                                   2151 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2152 ;	-----------------------------------------
      005679                       2153 _rgb_matrix_step_reverse_noeeprom:
                                   2154 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005679 12 57 A0         [24] 2155 	lcall	_ak820_outline_0020
      00567C 24 FE            [12] 2156 	add	a,#0xff - 0x01
      00567E 40 04            [24] 2157 	jc	00103$
                                   2158 ;	free result
      005680 7F 06            [12] 2159 	mov	r7,#0x06
      005682 80 05            [24] 2160 	sjmp	00104$
      005684                       2161 00103$:
      005684 12 57 A0         [24] 2162 	lcall	_ak820_outline_0020
      005687 14               [12] 2163 	dec	a
      005688 FF               [12] 2164 	mov	r7,a
      005689                       2165 00104$:
      005689 8F 82            [24] 2166 	mov	dpl, r7
                                   2167 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: }
      00568B 02 56 2A         [24] 2168 	ljmp	_rgb_matrix_mode_noeeprom
                                   2169 ;------------------------------------------------------------
                                   2170 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2171 ;------------------------------------------------------------
                                   2172 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2173 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2174 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_361'
                                   2175 ;------------------------------------------------------------
                                   2176 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2177 ;	-----------------------------------------
                                   2178 ;	 function rgb_matrix_sethsv_noeeprom
                                   2179 ;	-----------------------------------------
      00568E                       2180 _rgb_matrix_sethsv_noeeprom:
      00568E 12 39 03         [24] 2181 	lcall	_ak820_outline_0122
      005691 90 07 2B         [24] 2182 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_361
      005694 12 38 FE         [24] 2183 	lcall	_ak820_outline_0121
                                   2184 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.h = hue;
      005697 90 07 2B         [24] 2185 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_361
      00569A E0               [24] 2186 	movx	a,@dptr
      00569B 90 06 A5         [24] 2187 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00569E F0               [24] 2188 	movx	@dptr,a
                                   2189 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.s = sat;
      00569F 90 07 29         [24] 2190 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      0056A2 E0               [24] 2191 	movx	a,@dptr
      0056A3 FF               [12] 2192 	mov	r7,a
      0056A4 90 06 A6         [24] 2193 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056A7 F0               [24] 2194 	movx	@dptr,a
                                   2195 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0056A8 90 07 2A         [24] 2196 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      0056AB E0               [24] 2197 	movx	a,@dptr
      0056AC FF               [12] 2198 	mov  r7,a
      0056AD 24 5F            [12] 2199 	add	a,#0xff - 0xa0
      0056AF 50 04            [24] 2200 	jnc	00103$
                                   2201 ;	free result
      0056B1 7E A0            [12] 2202 	mov	r6,#0xa0
      0056B3 80 02            [24] 2203 	sjmp	00104$
      0056B5                       2204 00103$:
      0056B5 8F 06            [24] 2205 	mov	ar6,r7
      0056B7                       2206 00104$:
      0056B7 90 06 A7         [24] 2207 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0056BA EE               [12] 2208 	mov	a,r6
      0056BB F0               [24] 2209 	movx	@dptr,a
                                   2210 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: }
      0056BC 22               [24] 2211 	ret
                                   2212 ;------------------------------------------------------------
                                   2213 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2214 ;------------------------------------------------------------
                                   2215 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_363'
                                   2216 ;------------------------------------------------------------
                                   2217 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2218 ;	-----------------------------------------
                                   2219 ;	 function rgb_matrix_set_speed_noeeprom
                                   2220 ;	-----------------------------------------
      0056BD                       2221 _rgb_matrix_set_speed_noeeprom:
      0056BD E5 82            [12] 2222 	mov	a,dpl
      0056BF 90 07 2D         [24] 2223 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_363
      0056C2 F0               [24] 2224 	movx	@dptr,a
      0056C3 E0               [24] 2225 	movx	a,@dptr
      0056C4 90 06 A8         [24] 2226 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0056C7 F0               [24] 2227 	movx	@dptr,a
      0056C8 22               [24] 2228 	ret
                                   2229 ;------------------------------------------------------------
                                   2230 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2231 ;------------------------------------------------------------
                                   2232 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_365'
                                   2233 ;------------------------------------------------------------
                                   2234 ;	keyboards/ajazz/ak820/ak820_rgb.c:279: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2235 ;	-----------------------------------------
                                   2236 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2237 ;	-----------------------------------------
      0056C9                       2238 _rgb_matrix_increase_hue_noeeprom:
      0056C9 90 06 A5         [24] 2239 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056CC E0               [24] 2240 	movx	a,@dptr
      0056CD 24 08            [12] 2241 	add	a,#0x08
      0056CF 90 06 A5         [24] 2242 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056D2 F0               [24] 2243 	movx	@dptr,a
      0056D3 22               [24] 2244 	ret
                                   2245 ;------------------------------------------------------------
                                   2246 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2247 ;------------------------------------------------------------
                                   2248 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2249 ;	-----------------------------------------
                                   2250 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2251 ;	-----------------------------------------
      0056D4                       2252 _rgb_matrix_decrease_hue_noeeprom:
      0056D4 90 06 A5         [24] 2253 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056D7 E0               [24] 2254 	movx	a,@dptr
      0056D8 24 F8            [12] 2255 	add	a,#0xf8
      0056DA 90 06 A5         [24] 2256 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0056DD F0               [24] 2257 	movx	@dptr,a
      0056DE 22               [24] 2258 	ret
                                   2259 ;------------------------------------------------------------
                                   2260 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2261 ;------------------------------------------------------------
                                   2262 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2263 ;	-----------------------------------------
                                   2264 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2265 ;	-----------------------------------------
      0056DF                       2266 _rgb_matrix_increase_sat_noeeprom:
      0056DF 90 06 A6         [24] 2267 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056E2 12 57 B1         [24] 2268 	lcall	_ak820_outline_0056
      0056E5 12 50 53         [24] 2269 	lcall	_add_sat
      0056E8 AF 82            [24] 2270 	mov	r7, dpl
      0056EA 90 06 A6         [24] 2271 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056ED EF               [12] 2272 	mov	a,r7
      0056EE F0               [24] 2273 	movx	@dptr,a
      0056EF 22               [24] 2274 	ret
                                   2275 ;------------------------------------------------------------
                                   2276 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2277 ;------------------------------------------------------------
                                   2278 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2279 ;	-----------------------------------------
                                   2280 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2281 ;	-----------------------------------------
      0056F0                       2282 _rgb_matrix_decrease_sat_noeeprom:
      0056F0 90 06 A6         [24] 2283 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056F3 12 57 BC         [24] 2284 	lcall	_ak820_outline_0057
      0056F6 12 50 78         [24] 2285 	lcall	_sub_sat
      0056F9 AF 82            [24] 2286 	mov	r7, dpl
      0056FB 90 06 A6         [24] 2287 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0056FE EF               [12] 2288 	mov	a,r7
      0056FF F0               [24] 2289 	movx	@dptr,a
      005700 22               [24] 2290 	ret
                                   2291 ;------------------------------------------------------------
                                   2292 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2293 ;------------------------------------------------------------
                                   2294 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_376'
                                   2295 ;------------------------------------------------------------
                                   2296 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: void rgb_matrix_increase_val_noeeprom(void) {
                                   2297 ;	-----------------------------------------
                                   2298 ;	 function rgb_matrix_increase_val_noeeprom
                                   2299 ;	-----------------------------------------
      005701                       2300 _rgb_matrix_increase_val_noeeprom:
                                   2301 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005701 90 06 A7         [24] 2302 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005704 12 57 B1         [24] 2303 	lcall	_ak820_outline_0056
      005707 12 50 53         [24] 2304 	lcall	_add_sat
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00570A E5 82            [12] 2306 	mov	a,dpl
      00570C FF               [12] 2307 	mov	r7,a
      00570D 24 5F            [12] 2308 	add	a,#0xff - 0xa0
      00570F 50 04            [24] 2309 	jnc	00103$
                                   2310 ;	free result
      005711 7E A0            [12] 2311 	mov	r6,#0xa0
      005713 80 02            [24] 2312 	sjmp	00104$
      005715                       2313 00103$:
      005715 8F 06            [24] 2314 	mov	ar6,r7
      005717                       2315 00104$:
      005717 90 06 A7         [24] 2316 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00571A EE               [12] 2317 	mov	a,r6
      00571B F0               [24] 2318 	movx	@dptr,a
                                   2319 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: }
      00571C 22               [24] 2320 	ret
                                   2321 ;------------------------------------------------------------
                                   2322 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2323 ;------------------------------------------------------------
                                   2324 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2325 ;	-----------------------------------------
                                   2326 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2327 ;	-----------------------------------------
      00571D                       2328 _rgb_matrix_decrease_val_noeeprom:
      00571D 90 06 A7         [24] 2329 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005720 12 57 BC         [24] 2330 	lcall	_ak820_outline_0057
      005723 12 50 78         [24] 2331 	lcall	_sub_sat
      005726 AF 82            [24] 2332 	mov	r7, dpl
      005728 90 06 A7         [24] 2333 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00572B EF               [12] 2334 	mov	a,r7
      00572C F0               [24] 2335 	movx	@dptr,a
      00572D 22               [24] 2336 	ret
                                   2337 ;------------------------------------------------------------
                                   2338 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2339 ;------------------------------------------------------------
                                   2340 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2341 ;	-----------------------------------------
                                   2342 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2343 ;	-----------------------------------------
      00572E                       2344 _rgb_matrix_increase_speed_noeeprom:
      00572E 90 06 A8         [24] 2345 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005731 12 57 B1         [24] 2346 	lcall	_ak820_outline_0056
      005734 12 50 53         [24] 2347 	lcall	_add_sat
      005737 AF 82            [24] 2348 	mov	r7, dpl
      005739 90 06 A8         [24] 2349 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00573C EF               [12] 2350 	mov	a,r7
      00573D F0               [24] 2351 	movx	@dptr,a
      00573E 22               [24] 2352 	ret
                                   2353 ;------------------------------------------------------------
                                   2354 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2355 ;------------------------------------------------------------
                                   2356 ;	keyboards/ajazz/ak820/ak820_rgb.c:291: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2357 ;	-----------------------------------------
                                   2358 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2359 ;	-----------------------------------------
      00573F                       2360 _rgb_matrix_decrease_speed_noeeprom:
      00573F 90 06 A8         [24] 2361 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005742 12 57 BC         [24] 2362 	lcall	_ak820_outline_0057
      005745 12 50 78         [24] 2363 	lcall	_sub_sat
      005748 AF 82            [24] 2364 	mov	r7, dpl
      00574A 90 06 A8         [24] 2365 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00574D EF               [12] 2366 	mov	a,r7
      00574E F0               [24] 2367 	movx	@dptr,a
      00574F 22               [24] 2368 	ret
                                   2369 ;------------------------------------------------------------
                                   2370 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2371 ;------------------------------------------------------------
                                   2372 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2373 ;	-----------------------------------------
                                   2374 ;	 function rgb_matrix_toggle
                                   2375 ;	-----------------------------------------
      005750                       2376 _rgb_matrix_toggle:
      005750 12 55 F6         [24] 2377 	lcall	_rgb_matrix_toggle_noeeprom
      005753 02 50 95         [24] 2378 	ljmp	_mark_dirty
                                   2379 ;------------------------------------------------------------
                                   2380 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2381 ;------------------------------------------------------------
                                   2382 ;	keyboards/ajazz/ak820/ak820_rgb.c:295: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2383 ;	-----------------------------------------
                                   2384 ;	 function rgb_matrix_step
                                   2385 ;	-----------------------------------------
      005756                       2386 _rgb_matrix_step:
      005756 12 56 5F         [24] 2387 	lcall	_rgb_matrix_step_noeeprom
      005759 02 50 95         [24] 2388 	ljmp	_mark_dirty
                                   2389 ;------------------------------------------------------------
                                   2390 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2391 ;------------------------------------------------------------
                                   2392 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2393 ;	-----------------------------------------
                                   2394 ;	 function rgb_matrix_step_reverse
                                   2395 ;	-----------------------------------------
      00575C                       2396 _rgb_matrix_step_reverse:
      00575C 12 56 79         [24] 2397 	lcall	_rgb_matrix_step_reverse_noeeprom
      00575F 02 50 95         [24] 2398 	ljmp	_mark_dirty
                                   2399 ;------------------------------------------------------------
                                   2400 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2401 ;------------------------------------------------------------
                                   2402 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2403 ;	-----------------------------------------
                                   2404 ;	 function rgb_matrix_increase_hue
                                   2405 ;	-----------------------------------------
      005762                       2406 _rgb_matrix_increase_hue:
      005762 12 56 C9         [24] 2407 	lcall	_rgb_matrix_increase_hue_noeeprom
      005765 02 50 95         [24] 2408 	ljmp	_mark_dirty
                                   2409 ;------------------------------------------------------------
                                   2410 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2411 ;------------------------------------------------------------
                                   2412 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2413 ;	-----------------------------------------
                                   2414 ;	 function rgb_matrix_decrease_hue
                                   2415 ;	-----------------------------------------
      005768                       2416 _rgb_matrix_decrease_hue:
      005768 12 56 D4         [24] 2417 	lcall	_rgb_matrix_decrease_hue_noeeprom
      00576B 02 50 95         [24] 2418 	ljmp	_mark_dirty
                                   2419 ;------------------------------------------------------------
                                   2420 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2421 ;------------------------------------------------------------
                                   2422 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2423 ;	-----------------------------------------
                                   2424 ;	 function rgb_matrix_increase_sat
                                   2425 ;	-----------------------------------------
      00576E                       2426 _rgb_matrix_increase_sat:
      00576E 12 56 DF         [24] 2427 	lcall	_rgb_matrix_increase_sat_noeeprom
      005771 02 50 95         [24] 2428 	ljmp	_mark_dirty
                                   2429 ;------------------------------------------------------------
                                   2430 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2431 ;------------------------------------------------------------
                                   2432 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2433 ;	-----------------------------------------
                                   2434 ;	 function rgb_matrix_decrease_sat
                                   2435 ;	-----------------------------------------
      005774                       2436 _rgb_matrix_decrease_sat:
      005774 12 56 F0         [24] 2437 	lcall	_rgb_matrix_decrease_sat_noeeprom
      005777 02 50 95         [24] 2438 	ljmp	_mark_dirty
                                   2439 ;------------------------------------------------------------
                                   2440 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2441 ;------------------------------------------------------------
                                   2442 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2443 ;	-----------------------------------------
                                   2444 ;	 function rgb_matrix_increase_val
                                   2445 ;	-----------------------------------------
      00577A                       2446 _rgb_matrix_increase_val:
      00577A 12 57 01         [24] 2447 	lcall	_rgb_matrix_increase_val_noeeprom
      00577D 02 50 95         [24] 2448 	ljmp	_mark_dirty
                                   2449 ;------------------------------------------------------------
                                   2450 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2451 ;------------------------------------------------------------
                                   2452 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2453 ;	-----------------------------------------
                                   2454 ;	 function rgb_matrix_decrease_val
                                   2455 ;	-----------------------------------------
      005780                       2456 _rgb_matrix_decrease_val:
      005780 12 57 1D         [24] 2457 	lcall	_rgb_matrix_decrease_val_noeeprom
      005783 02 50 95         [24] 2458 	ljmp	_mark_dirty
                                   2459 ;------------------------------------------------------------
                                   2460 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2461 ;------------------------------------------------------------
                                   2462 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2463 ;	-----------------------------------------
                                   2464 ;	 function rgb_matrix_increase_speed
                                   2465 ;	-----------------------------------------
      005786                       2466 _rgb_matrix_increase_speed:
      005786 12 57 2E         [24] 2467 	lcall	_rgb_matrix_increase_speed_noeeprom
      005789 02 50 95         [24] 2468 	ljmp	_mark_dirty
                                   2469 ;------------------------------------------------------------
                                   2470 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2471 ;------------------------------------------------------------
                                   2472 ;	keyboards/ajazz/ak820/ak820_rgb.c:306: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2473 ;	-----------------------------------------
                                   2474 ;	 function rgb_matrix_decrease_speed
                                   2475 ;	-----------------------------------------
      00578C                       2476 _rgb_matrix_decrease_speed:
      00578C 12 57 3F         [24] 2477 	lcall	_rgb_matrix_decrease_speed_noeeprom
      00578F 02 50 95         [24] 2478 	ljmp	_mark_dirty
                                   2479 ;------------------------------------------------------------
                                   2480 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2481 ;------------------------------------------------------------
                                   2482 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_409'
                                   2483 ;------------------------------------------------------------
                                   2484 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2485 ;	-----------------------------------------
                                   2486 ;	 function rgb_matrix_mode
                                   2487 ;	-----------------------------------------
      005792                       2488 _rgb_matrix_mode:
      005792 E5 82            [12] 2489 	mov	a,dpl
      005794 90 07 2E         [24] 2490 	mov	dptr,#_rgb_matrix_mode_mode_10000_409
      005797 12 57 FB         [24] 2491 	lcall	_ak820_outline_0175
      00579A 12 56 2A         [24] 2492 	lcall	_rgb_matrix_mode_noeeprom
      00579D 02 50 95         [24] 2493 	ljmp	_mark_dirty
                                   2494 ;------------------------------------------------------------
                                   2495 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2496 ;------------------------------------------------------------
                                   2497 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2498 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2499 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_411'
                                   2500 ;------------------------------------------------------------
                                   2501 ;	keyboards/ajazz/ak820/ak820_rgb.c:310: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2502 ;	-----------------------------------------
                                   2503 	.area CSEG    (CODE)
                                   2504 	.area CONST   (CODE)
                                   2505 	.area CONST   (CODE)
      00BD6A                       2506 _sine8_coefficients_10000_288:
      00BD6A 00                    2507 	.db #0x00	; 0
      00BD6B 31                    2508 	.db #0x31	; 49	'1'
      00BD6C 31                    2509 	.db #0x31	; 49	'1'
      00BD6D 29                    2510 	.db #0x29	; 41
      00BD6E 5A                    2511 	.db #0x5a	; 90	'Z'
      00BD6F 1B                    2512 	.db #0x1b	; 27
      00BD70 75                    2513 	.db #0x75	; 117	'u'
      00BD71 0A                    2514 	.db #0x0a	; 10
                                   2515 	.area CSEG    (CODE)
                                   2516 	.area XINIT   (CODE)
                                   2517 	.area CABS    (ABS,CODE)
                                   2518 
                                   2519 ; Experimental exact instruction outlining.
                                   2520 	.globl _ak820_outline_0010
                                   2521 	.globl _ak820_outline_0020
                                   2522 	.globl _ak820_outline_0046
                                   2523 	.globl _ak820_outline_0056
                                   2524 	.globl _ak820_outline_0057
                                   2525 	.globl _ak820_outline_0060
                                   2526 	.globl _ak820_outline_0068
                                   2527 	.globl _ak820_outline_0075
                                   2528 	.globl _ak820_outline_0076
                                   2529 	.globl _ak820_outline_0080
                                   2530 	.globl _ak820_outline_0081
                                   2531 	.globl _ak820_outline_0093
                                   2532 	.globl _ak820_outline_0110
                                   2533 	.globl _ak820_outline_0117
                                   2534 	.globl _ak820_outline_0121
                                   2535 	.globl _ak820_outline_0122
                                   2536 	.globl _ak820_outline_0123
                                   2537 	.globl _ak820_outline_0130
                                   2538 	.globl _ak820_outline_0131
                                   2539 	.globl _ak820_outline_0132
                                   2540 	.globl _ak820_outline_0141
                                   2541 	.globl _ak820_outline_0145
                                   2542 	.globl _ak820_outline_0146
                                   2543 	.globl _ak820_outline_0150
                                   2544 	.globl _ak820_outline_0156
                                   2545 	.globl _ak820_outline_0163
                                   2546 	.globl _ak820_outline_0173
                                   2547 	.globl _ak820_outline_0175
                                   2548 	.globl _ak820_outline_0179
                                   2549 	.globl _ak820_outline_0187
                                   2550 	.globl _ak820_outline_0192
                                   2551 	.globl _ak820_outline_0196
                                   2552 
                                   2553 	.area CSEG (CODE)
                                   2554 ; function ak820_outline_0020
      0057A0                       2555 _ak820_outline_0020:
      0057A0 90 06 A4         [24] 2556 	mov	dptr,#_rgb_matrix_config
      0057A3 E0               [24] 2557 	movx	a,@dptr
      0057A4 03               [12] 2558 	rr	a
      0057A5 03               [12] 2559 	rr	a
      0057A6 54 3F            [12] 2560 	anl	a,#0x3f
      0057A8 22               [24] 2561 	ret
                                   2562 
                                   2563 	.area CSEG (CODE)
                                   2564 ; function ak820_outline_0046
      0057A9                       2565 _ak820_outline_0046:
      0057A9 E4               [12] 2566 	clr	a
      0057AA 93               [24] 2567 	movc	a,@a+dptr
      0057AB FE               [12] 2568 	mov	r6,a
      0057AC A3               [24] 2569 	inc	dptr
      0057AD E4               [12] 2570 	clr	a
      0057AE 93               [24] 2571 	movc	a,@a+dptr
      0057AF FF               [12] 2572 	mov	r7,a
      0057B0 22               [24] 2573 	ret
                                   2574 
                                   2575 	.area CSEG (CODE)
                                   2576 ; function ak820_outline_0056
      0057B1                       2577 _ak820_outline_0056:
      0057B1 E0               [24] 2578 	movx	a,@dptr
      0057B2 FF               [12] 2579 	mov	r7,a
      0057B3 90 07 0D         [24] 2580 	mov	dptr,#_add_sat_PARM_2
      0057B6 74 10            [12] 2581 	mov	a,#0x10
      0057B8 F0               [24] 2582 	movx	@dptr,a
      0057B9 8F 82            [24] 2583 	mov	dpl,r7
      0057BB 22               [24] 2584 	ret
                                   2585 
                                   2586 	.area CSEG (CODE)
                                   2587 ; function ak820_outline_0057
      0057BC                       2588 _ak820_outline_0057:
      0057BC E0               [24] 2589 	movx	a,@dptr
      0057BD FF               [12] 2590 	mov	r7,a
      0057BE 90 07 0F         [24] 2591 	mov	dptr,#_sub_sat_PARM_2
      0057C1 74 10            [12] 2592 	mov	a,#0x10
      0057C3 F0               [24] 2593 	movx	@dptr,a
      0057C4 8F 82            [24] 2594 	mov	dpl,r7
      0057C6 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0075
      0057C7                       2599 _ak820_outline_0075:
      0057C7 90 06 A4         [24] 2600 	mov	dptr,#_rgb_matrix_config
      0057CA E0               [24] 2601 	movx	a,@dptr
      0057CB 54 03            [12] 2602 	anl	a,#0x03
      0057CD 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0080
      0057CE                       2607 _ak820_outline_0080:
      0057CE 74 08            [12] 2608 	mov	a,#0x08
      0057D0 F0               [24] 2609 	movx	@dptr,a
      0057D1 E4               [12] 2610 	clr	a
      0057D2 A3               [24] 2611 	inc	dptr
      0057D3 F0               [24] 2612 	movx	@dptr,a
      0057D4 90 06 A4         [24] 2613 	mov	dptr,#_rgb_matrix_config
      0057D7 22               [24] 2614 	ret
                                   2615 
                                   2616 	.area CSEG (CODE)
                                   2617 ; function ak820_outline_0093
      0057D8                       2618 _ak820_outline_0093:
      0057D8 74 18            [12] 2619 	mov	a,#0x18
      0057DA F0               [24] 2620 	movx	@dptr,a
      0057DB E4               [12] 2621 	clr	a
      0057DC A3               [24] 2622 	inc	dptr
      0057DD F0               [24] 2623 	movx	@dptr,a
      0057DE A3               [24] 2624 	inc	dptr
      0057DF F0               [24] 2625 	movx	@dptr,a
      0057E0 22               [24] 2626 	ret
                                   2627 
                                   2628 	.area CSEG (CODE)
                                   2629 ; function ak820_outline_0117
      0057E1                       2630 _ak820_outline_0117:
      0057E1 90 06 A4         [24] 2631 	mov	dptr,#_rgb_matrix_config
      0057E4 E0               [24] 2632 	movx	a,@dptr
      0057E5 54 FC            [12] 2633 	anl	a,#0xfc
      0057E7 22               [24] 2634 	ret
                                   2635 
                                   2636 	.area CSEG (CODE)
                                   2637 ; function ak820_outline_0146
      0057E8                       2638 _ak820_outline_0146:
      0057E8 90 06 B3         [24] 2639 	mov	dptr,#_frame_mode
      0057EB E0               [24] 2640 	movx	a,@dptr
      0057EC FE               [12] 2641 	mov	r6,a
      0057ED 22               [24] 2642 	ret
                                   2643 
                                   2644 	.area CSEG (CODE)
                                   2645 ; function ak820_outline_0156
      0057EE                       2646 _ak820_outline_0156:
      0057EE 35 F0            [12] 2647 	addc	a,b
      0057F0 F5 83            [12] 2648 	mov	dph,a
      0057F2 E4               [12] 2649 	clr	a
      0057F3 93               [24] 2650 	movc	a,@a+dptr
      0057F4 22               [24] 2651 	ret
                                   2652 
                                   2653 	.area CSEG (CODE)
                                   2654 ; function ak820_outline_0173
      0057F5                       2655 _ak820_outline_0173:
      0057F5 F0               [24] 2656 	movx	@dptr,a
      0057F6 E5 F0            [12] 2657 	mov	a,b
      0057F8 A3               [24] 2658 	inc	dptr
      0057F9 F0               [24] 2659 	movx	@dptr,a
      0057FA 22               [24] 2660 	ret
                                   2661 
                                   2662 	.area CSEG (CODE)
                                   2663 ; function ak820_outline_0175
      0057FB                       2664 _ak820_outline_0175:
      0057FB F0               [24] 2665 	movx	@dptr,a
      0057FC E0               [24] 2666 	movx	a,@dptr
      0057FD F5 82            [12] 2667 	mov	dpl,a
      0057FF 22               [24] 2668 	ret
                                   2669 
                                   2670 	.area CSEG (CODE)
                                   2671 ; function ak820_outline_0179
      005800                       2672 _ak820_outline_0179:
      005800 90 06 A8         [24] 2673 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005803 E0               [24] 2674 	movx	a,@dptr
      005804 23               [12] 2675 	rl	a
      005805 23               [12] 2676 	rl	a
      005806 54 03            [12] 2677 	anl	a,#0x03
      005808 22               [24] 2678 	ret
                                   2679 
                                   2680 	.area CSEG (CODE)
                                   2681 ; function ak820_outline_0187
      005809                       2682 _ak820_outline_0187:
      005809 90 0D CA         [24] 2683 	mov	dptr,#_memset_PARM_2
      00580C E4               [12] 2684 	clr	a
      00580D F0               [24] 2685 	movx	@dptr,a
      00580E 90 0D CB         [24] 2686 	mov	dptr,#_memset_PARM_3
      005811 22               [24] 2687 	ret
                                   2688 
                                   2689 	.area CSEG (CODE)
                                   2690 ; function ak820_outline_0192
      005812                       2691 _ak820_outline_0192:
      005812 90 06 B2         [24] 2692 	mov	dptr,#_led_index
      005815 E0               [24] 2693 	movx	a,@dptr
      005816 22               [24] 2694 	ret
                                   2695 
                                   2696 	.area CSEG (CODE)
                                   2697 ; function ak820_outline_0196
      005817                       2698 _ak820_outline_0196:
      005817 C4               [12] 2699 	swap	a
      005818 23               [12] 2700 	rl	a
      005819 54 1F            [12] 2701 	anl	a,#0x1f
      00581B 22               [24] 2702 	ret
