                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000678                         85 _eeprom_read_word_addr_10000_91:
      000678                         86 	.ds 3
      00067B                         87 _eeprom_read_word_ret_10000_92:
      00067B                         88 	.ds 2
      00067D                         89 _eeprom_read_dword_addr_10000_93:
      00067D                         90 	.ds 3
      000680                         91 _eeprom_read_dword_ret_10000_94:
      000680                         92 	.ds 4
      000684                         93 _eeprom_write_byte_PARM_2:
      000684                         94 	.ds 1
      000685                         95 _eeprom_write_byte_addr_10000_95:
      000685                         96 	.ds 3
      000688                         97 _eeprom_write_word_PARM_2:
      000688                         98 	.ds 2
      00068A                         99 _eeprom_write_word_addr_10000_97:
      00068A                        100 	.ds 3
      00068D                        101 _eeprom_write_dword_PARM_2:
      00068D                        102 	.ds 4
      000691                        103 _eeprom_write_dword_addr_10000_99:
      000691                        104 	.ds 3
      000694                        105 _eeprom_update_byte_PARM_2:
      000694                        106 	.ds 1
      000695                        107 _eeprom_update_byte_addr_10000_107:
      000695                        108 	.ds 3
      000698                        109 _eeprom_update_word_PARM_2:
      000698                        110 	.ds 2
      00069A                        111 _eeprom_update_word_addr_10000_111:
      00069A                        112 	.ds 3
      00069D                        113 _eeprom_update_dword_PARM_2:
      00069D                        114 	.ds 4
      0006A1                        115 _eeprom_update_dword_addr_10000_115:
      0006A1                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004DA3                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004DA3 12 43 80         [24]  170 	lcall	_ak820_outline_0036
      004DA6 90 06 78         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004DA9 12 38 8B         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004DAC 90 06 7B         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DAF 12 4F B3         [24]  175 	lcall	_ak820_outline_0174
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004DB2 90 06 78         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004DB5 12 4F 61         [24]  178 	lcall	_ak820_outline_0014
      004DB8 90 05 7E         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DBB ED               [12]  180 	mov	a,r5
      004DBC 12 38 8B         [24]  181 	lcall	_ak820_outline_0017
      004DBF 90 05 81         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DC2 12 4F 8C         [24]  183 	lcall	_ak820_outline_0067
      004DC5 90 06 7B         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DC8 12 41 1C         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004DCB 90 06 7B         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DCE 12 4F A3         [24]  188 	lcall	_ak820_outline_0099
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004DD1 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004DD2                        201 _eeprom_read_dword:
      004DD2 12 43 80         [24]  202 	lcall	_ak820_outline_0036
      004DD5 90 06 7D         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004DD8 12 38 8B         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004DDB 90 06 80         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DDE 12 4F 7B         [24]  207 	lcall	_ak820_outline_0058
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004DE1 90 06 7D         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004DE4 12 4F 61         [24]  210 	lcall	_ak820_outline_0014
      004DE7 90 05 7E         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DEA ED               [12]  212 	mov	a,r5
      004DEB 12 38 8B         [24]  213 	lcall	_ak820_outline_0017
      004DEE 90 05 81         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DF1 74 04            [12]  215 	mov	a,#0x04
      004DF3 12 39 0D         [24]  216 	lcall	_ak820_outline_0130
      004DF6 90 06 80         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DF9 12 41 1C         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004DFC 90 06 80         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DFF 12 4F 72         [24]  221 	lcall	_ak820_outline_0044
      004E02 A3               [24]  222 	inc	dptr
      004E03 E0               [24]  223 	movx	a,@dptr
      004E04 12 4F 93         [24]  224 	lcall	_ak820_outline_0073
                                    225 ;	drivers/eeprom/eeprom_driver.c:54: }
      004E07 22               [24]  226 	ret
                                    227 ;------------------------------------------------------------
                                    228 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    229 ;------------------------------------------------------------
                                    230 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    231 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    232 ;------------------------------------------------------------
                                    233 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    234 ;	-----------------------------------------
                                    235 ;	 function eeprom_write_byte
                                    236 ;	-----------------------------------------
      004E08                        237 _eeprom_write_byte:
      004E08 12 43 80         [24]  238 	lcall	_ak820_outline_0036
      004E0B 90 06 85         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E0E 12 38 8B         [24]  240 	lcall	_ak820_outline_0017
                                    241 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004E11 90 06 85         [24]  242 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E14 12 4F 4A         [24]  243 	lcall	_ak820_outline_0009
      004E17 74 01            [12]  244 	mov	a,#0x01
      004E19 12 39 0D         [24]  245 	lcall	_ak820_outline_0130
      004E1C 90 06 84         [24]  246 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    247 ;	drivers/eeprom/eeprom_driver.c:58: }
      004E1F 02 41 A8         [24]  248 	ljmp	_ak820_eeprom_write_block_xdata
                                    249 ;------------------------------------------------------------
                                    250 ;Allocation info for local variables in function 'eeprom_write_word'
                                    251 ;------------------------------------------------------------
                                    252 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    253 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    254 ;------------------------------------------------------------
                                    255 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    256 ;	-----------------------------------------
                                    257 ;	 function eeprom_write_word
                                    258 ;	-----------------------------------------
      004E22                        259 _eeprom_write_word:
      004E22 12 43 80         [24]  260 	lcall	_ak820_outline_0036
      004E25 90 06 8A         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E28 12 38 8B         [24]  262 	lcall	_ak820_outline_0017
                                    263 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004E2B 90 06 8A         [24]  264 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E2E 12 4F 4A         [24]  265 	lcall	_ak820_outline_0009
      004E31 12 4F 8C         [24]  266 	lcall	_ak820_outline_0067
      004E34 90 06 88         [24]  267 	mov	dptr,#_eeprom_write_word_PARM_2
                                    268 ;	drivers/eeprom/eeprom_driver.c:62: }
      004E37 02 41 A8         [24]  269 	ljmp	_ak820_eeprom_write_block_xdata
                                    270 ;------------------------------------------------------------
                                    271 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    272 ;------------------------------------------------------------
                                    273 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    274 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    275 ;------------------------------------------------------------
                                    276 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    277 ;	-----------------------------------------
                                    278 ;	 function eeprom_write_dword
                                    279 ;	-----------------------------------------
      004E3A                        280 _eeprom_write_dword:
      004E3A 12 43 80         [24]  281 	lcall	_ak820_outline_0036
      004E3D 90 06 91         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E40 12 38 8B         [24]  283 	lcall	_ak820_outline_0017
                                    284 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004E43 90 06 91         [24]  285 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E46 12 4F 4A         [24]  286 	lcall	_ak820_outline_0009
      004E49 74 04            [12]  287 	mov	a,#0x04
      004E4B 12 39 0D         [24]  288 	lcall	_ak820_outline_0130
      004E4E 90 06 8D         [24]  289 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    290 ;	drivers/eeprom/eeprom_driver.c:66: }
      004E51 02 41 A8         [24]  291 	ljmp	_ak820_eeprom_write_block_xdata
                                    292 ;------------------------------------------------------------
                                    293 ;Allocation info for local variables in function 'eeprom_update_block'
                                    294 ;------------------------------------------------------------
                                    295 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    296 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    297 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    298 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    299 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    300 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    301 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    302 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    303 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    304 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    305 ;------------------------------------------------------------
                                    306 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    307 ;	-----------------------------------------
                                    308 ;	 function eeprom_update_byte
                                    309 ;	-----------------------------------------
      004E54                        310 _eeprom_update_byte:
      004E54 C0 07            [24]  311 	push	ar7
      004E56 C0 06            [24]  312 	push	ar6
      004E58 C0 05            [24]  313 	push	ar5
      004E5A C0 04            [24]  314 	push	ar4
      004E5C 12 43 80         [24]  315 	lcall	_ak820_outline_0036
      004E5F 90 06 95         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E62 12 38 8B         [24]  317 	lcall	_ak820_outline_0017
                                    318 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004E65 90 06 95         [24]  319 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E68 12 4F 3B         [24]  320 	lcall	_ak820_outline_0004
      004E6B 12 40 E1         [24]  321 	lcall	_eeprom_read_byte
      004E6E AF 82            [24]  322 	mov	r7, dpl
                                    323 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004E70 90 06 94         [24]  324 	mov	dptr,#_eeprom_update_byte_PARM_2
      004E73 E0               [24]  325 	movx	a,@dptr
      004E74 FE               [12]  326 	mov	r6,a
      004E75 EF               [12]  327 	mov	a,r7
      004E76 B5 06 02         [24]  328 	cjne	a,ar6,00112$
      004E79 80 36            [24]  329 	sjmp	00103$
      004E7B                        330 00112$:
                                    331 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004E7B 90 06 95         [24]  332 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E7E 12 38 DA         [24]  333 	lcall	_ak820_outline_0076
      004E81 A3               [24]  334 	inc	dptr
      004E82 E0               [24]  335 	movx	a,@dptr
      004E83 FF               [12]  336 	mov	r7,a
      004E84 90 06 84         [24]  337 	mov	dptr,#_eeprom_write_byte_PARM_2
      004E87 EE               [12]  338 	mov	a,r6
      004E88 F0               [24]  339 	movx	@dptr,a
      004E89 12 34 76         [24]  340 	lcall	_ak820_outline_0132
      004E8C 8F F0            [24]  341 	mov	b, r7
      004E8E C0 07            [24]  342 	push	ar7
      004E90 C0 06            [24]  343 	push	ar6
      004E92 C0 05            [24]  344 	push	ar5
      004E94 C0 04            [24]  345 	push	ar4
      004E96 C0 03            [24]  346 	push	ar3
      004E98 C0 02            [24]  347 	push	ar2
      004E9A C0 01            [24]  348 	push	ar1
      004E9C C0 00            [24]  349 	push	ar0
      004E9E 12 4E 08         [24]  350 	lcall	_eeprom_write_byte
      004EA1 D0 00            [24]  351 	pop	ar0
      004EA3 D0 01            [24]  352 	pop	ar1
      004EA5 D0 02            [24]  353 	pop	ar2
      004EA7 D0 03            [24]  354 	pop	ar3
      004EA9 D0 04            [24]  355 	pop	ar4
      004EAB D0 05            [24]  356 	pop	ar5
      004EAD D0 06            [24]  357 	pop	ar6
      004EAF D0 07            [24]  358 	pop	ar7
      004EB1                        359 00103$:
                                    360 ;	drivers/eeprom/eeprom_driver.c:87: }
      004EB1 D0 04            [24]  361 	pop	ar4
      004EB3 D0 05            [24]  362 	pop	ar5
      004EB5 D0 06            [24]  363 	pop	ar6
      004EB7 D0 07            [24]  364 	pop	ar7
      004EB9 22               [24]  365 	ret
                                    366 ;------------------------------------------------------------
                                    367 ;Allocation info for local variables in function 'eeprom_update_word'
                                    368 ;------------------------------------------------------------
                                    369 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    370 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    371 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    372 ;------------------------------------------------------------
                                    373 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    374 ;	-----------------------------------------
                                    375 ;	 function eeprom_update_word
                                    376 ;	-----------------------------------------
      004EBA                        377 _eeprom_update_word:
      004EBA 12 43 80         [24]  378 	lcall	_ak820_outline_0036
      004EBD 90 06 9A         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004EC0 12 38 8B         [24]  380 	lcall	_ak820_outline_0017
                                    381 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004EC3 90 06 9A         [24]  382 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004EC6 12 4F 3B         [24]  383 	lcall	_ak820_outline_0004
      004EC9 12 4D A3         [24]  384 	lcall	_eeprom_read_word
      004ECC 12 43 D5         [24]  385 	lcall	_ak820_outline_0131
                                    386 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004ECF 90 06 98         [24]  387 	mov	dptr,#_eeprom_update_word_PARM_2
      004ED2 12 38 DA         [24]  388 	lcall	_ak820_outline_0076
      004ED5 EE               [12]  389 	mov	a,r6
      004ED6 B5 04 05         [24]  390 	cjne	a,ar4,00112$
      004ED9 EF               [12]  391 	mov	a,r7
      004EDA B5 05 01         [24]  392 	cjne	a,ar5,00112$
      004EDD 22               [24]  393 	ret
      004EDE                        394 00112$:
                                    395 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004EDE 90 06 9A         [24]  396 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004EE1 E0               [24]  397 	movx	a,@dptr
      004EE2 FB               [12]  398 	mov	r3,a
      004EE3 A3               [24]  399 	inc	dptr
      004EE4 12 38 C3         [24]  400 	lcall	_ak820_outline_0060
      004EE7 90 06 88         [24]  401 	mov	dptr,#_eeprom_write_word_PARM_2
      004EEA 12 38 E6         [24]  402 	lcall	_ak820_outline_0087
      004EED 8B 82            [24]  403 	mov	dpl, r3
      004EEF 8E 83            [24]  404 	mov	dph, r6
      004EF1 8F F0            [24]  405 	mov	b, r7
                                    406 ;	drivers/eeprom/eeprom_driver.c:94: }
      004EF3 02 4E 22         [24]  407 	ljmp	_eeprom_write_word
                                    408 ;------------------------------------------------------------
                                    409 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    410 ;------------------------------------------------------------
                                    411 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    412 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    413 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    414 ;------------------------------------------------------------
                                    415 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    416 ;	-----------------------------------------
                                    417 ;	 function eeprom_update_dword
                                    418 ;	-----------------------------------------
      004EF6                        419 _eeprom_update_dword:
      004EF6 12 43 80         [24]  420 	lcall	_ak820_outline_0036
      004EF9 90 06 A1         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EFC 12 38 8B         [24]  422 	lcall	_ak820_outline_0017
                                    423 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004EFF 90 06 A1         [24]  424 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F02 12 4F 3B         [24]  425 	lcall	_ak820_outline_0004
      004F05 12 4D D2         [24]  426 	lcall	_eeprom_read_dword
      004F08 12 4F 84         [24]  427 	lcall	_ak820_outline_0064
                                    428 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004F0B 90 06 9D         [24]  429 	mov	dptr,#_eeprom_update_dword_PARM_2
      004F0E E0               [24]  430 	movx	a,@dptr
      004F0F F8               [12]  431 	mov	r0,a
      004F10 A3               [24]  432 	inc	dptr
      004F11 12 4F 9A         [24]  433 	lcall	_ak820_outline_0098
      004F14 EC               [12]  434 	mov	a,r4
      004F15 B5 00 0D         [24]  435 	cjne	a,ar0,00112$
      004F18 ED               [12]  436 	mov	a,r5
      004F19 B5 01 09         [24]  437 	cjne	a,ar1,00112$
      004F1C EE               [12]  438 	mov	a,r6
      004F1D B5 02 05         [24]  439 	cjne	a,ar2,00112$
      004F20 EF               [12]  440 	mov	a,r7
      004F21 B5 03 01         [24]  441 	cjne	a,ar3,00112$
      004F24 22               [24]  442 	ret
      004F25                        443 00112$:
                                    444 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004F25 90 06 A1         [24]  445 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F28 12 4F 61         [24]  446 	lcall	_ak820_outline_0014
      004F2B 90 06 8D         [24]  447 	mov	dptr,#_eeprom_write_dword_PARM_2
      004F2E E8               [12]  448 	mov	a,r0
      004F2F F0               [24]  449 	movx	@dptr,a
      004F30 E9               [12]  450 	mov	a,r1
      004F31 A3               [24]  451 	inc	dptr
      004F32 12 4F AC         [24]  452 	lcall	_ak820_outline_0119
      004F35 12 4F 6A         [24]  453 	lcall	_ak820_outline_0033
                                    454 ;	drivers/eeprom/eeprom_driver.c:101: }
      004F38 02 4E 3A         [24]  455 	ljmp	_eeprom_write_dword
                                    456 	.area CSEG    (CODE)
                                    457 	.area CONST   (CODE)
                                    458 	.area XINIT   (CODE)
                                    459 	.area CABS    (ABS,CODE)
                                    460 
                                    461 ; Experimental exact instruction outlining.
                                    462 	.globl _ak820_outline_0004
                                    463 	.globl _ak820_outline_0009
                                    464 	.globl _ak820_outline_0014
                                    465 	.globl _ak820_outline_0017
                                    466 	.globl _ak820_outline_0033
                                    467 	.globl _ak820_outline_0036
                                    468 	.globl _ak820_outline_0044
                                    469 	.globl _ak820_outline_0058
                                    470 	.globl _ak820_outline_0060
                                    471 	.globl _ak820_outline_0064
                                    472 	.globl _ak820_outline_0067
                                    473 	.globl _ak820_outline_0073
                                    474 	.globl _ak820_outline_0076
                                    475 	.globl _ak820_outline_0087
                                    476 	.globl _ak820_outline_0098
                                    477 	.globl _ak820_outline_0099
                                    478 	.globl _ak820_outline_0119
                                    479 	.globl _ak820_outline_0130
                                    480 	.globl _ak820_outline_0131
                                    481 	.globl _ak820_outline_0132
                                    482 	.globl _ak820_outline_0174
                                    483 
                                    484 	.area CSEG (CODE)
                                    485 ; function ak820_outline_0004
      004F3B                        486 _ak820_outline_0004:
      004F3B E0               [24]  487 	movx	a,@dptr
      004F3C FD               [12]  488 	mov	r5,a
      004F3D A3               [24]  489 	inc	dptr
      004F3E E0               [24]  490 	movx	a,@dptr
      004F3F FE               [12]  491 	mov	r6,a
      004F40 A3               [24]  492 	inc	dptr
      004F41 E0               [24]  493 	movx	a,@dptr
      004F42 FF               [12]  494 	mov	r7,a
      004F43 8D 82            [24]  495 	mov	dpl,r5
      004F45 8E 83            [24]  496 	mov	dph,r6
      004F47 8F F0            [24]  497 	mov	b,r7
      004F49 22               [24]  498 	ret
                                    499 
                                    500 	.area CSEG (CODE)
                                    501 ; function ak820_outline_0009
      004F4A                        502 _ak820_outline_0009:
      004F4A E0               [24]  503 	movx	a,@dptr
      004F4B FD               [12]  504 	mov	r5,a
      004F4C A3               [24]  505 	inc	dptr
      004F4D E0               [24]  506 	movx	a,@dptr
      004F4E FE               [12]  507 	mov	r6,a
      004F4F A3               [24]  508 	inc	dptr
      004F50 E0               [24]  509 	movx	a,@dptr
      004F51 FF               [12]  510 	mov	r7,a
      004F52 90 05 87         [24]  511 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004F55 ED               [12]  512 	mov	a,r5
      004F56 F0               [24]  513 	movx	@dptr,a
      004F57 EE               [12]  514 	mov	a,r6
      004F58 A3               [24]  515 	inc	dptr
      004F59 F0               [24]  516 	movx	@dptr,a
      004F5A EF               [12]  517 	mov	a,r7
      004F5B A3               [24]  518 	inc	dptr
      004F5C F0               [24]  519 	movx	@dptr,a
      004F5D 90 05 8A         [24]  520 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004F60 22               [24]  521 	ret
                                    522 
                                    523 	.area CSEG (CODE)
                                    524 ; function ak820_outline_0014
      004F61                        525 _ak820_outline_0014:
      004F61 E0               [24]  526 	movx	a,@dptr
      004F62 FD               [12]  527 	mov	r5,a
      004F63 A3               [24]  528 	inc	dptr
      004F64 E0               [24]  529 	movx	a,@dptr
      004F65 FE               [12]  530 	mov	r6,a
      004F66 A3               [24]  531 	inc	dptr
      004F67 E0               [24]  532 	movx	a,@dptr
      004F68 FF               [12]  533 	mov	r7,a
      004F69 22               [24]  534 	ret
                                    535 
                                    536 	.area CSEG (CODE)
                                    537 ; function ak820_outline_0033
      004F6A                        538 _ak820_outline_0033:
      004F6A F0               [24]  539 	movx	@dptr,a
      004F6B 8D 82            [24]  540 	mov	dpl,r5
      004F6D 8E 83            [24]  541 	mov	dph,r6
      004F6F 8F F0            [24]  542 	mov	b,r7
      004F71 22               [24]  543 	ret
                                    544 
                                    545 	.area CSEG (CODE)
                                    546 ; function ak820_outline_0044
      004F72                        547 _ak820_outline_0044:
      004F72 E0               [24]  548 	movx	a,@dptr
      004F73 FC               [12]  549 	mov	r4,a
      004F74 A3               [24]  550 	inc	dptr
      004F75 E0               [24]  551 	movx	a,@dptr
      004F76 FD               [12]  552 	mov	r5,a
      004F77 A3               [24]  553 	inc	dptr
      004F78 E0               [24]  554 	movx	a,@dptr
      004F79 FE               [12]  555 	mov	r6,a
      004F7A 22               [24]  556 	ret
                                    557 
                                    558 	.area CSEG (CODE)
                                    559 ; function ak820_outline_0058
      004F7B                        560 _ak820_outline_0058:
      004F7B E4               [12]  561 	clr	a
      004F7C F0               [24]  562 	movx	@dptr,a
      004F7D A3               [24]  563 	inc	dptr
      004F7E F0               [24]  564 	movx	@dptr,a
      004F7F A3               [24]  565 	inc	dptr
      004F80 F0               [24]  566 	movx	@dptr,a
      004F81 A3               [24]  567 	inc	dptr
      004F82 F0               [24]  568 	movx	@dptr,a
      004F83 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0064
      004F84                        573 _ak820_outline_0064:
      004F84 AC 82            [24]  574 	mov	r4,dpl
      004F86 AD 83            [24]  575 	mov	r5,dph
      004F88 AE F0            [24]  576 	mov	r6,b
      004F8A FF               [12]  577 	mov	r7,a
      004F8B 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0067
      004F8C                        582 _ak820_outline_0067:
      004F8C 74 02            [12]  583 	mov	a,#0x02
      004F8E F0               [24]  584 	movx	@dptr,a
      004F8F E4               [12]  585 	clr	a
      004F90 A3               [24]  586 	inc	dptr
      004F91 F0               [24]  587 	movx	@dptr,a
      004F92 22               [24]  588 	ret
                                    589 
                                    590 	.area CSEG (CODE)
                                    591 ; function ak820_outline_0073
      004F93                        592 _ak820_outline_0073:
      004F93 8C 82            [24]  593 	mov	dpl,r4
      004F95 8D 83            [24]  594 	mov	dph,r5
      004F97 8E F0            [24]  595 	mov	b,r6
      004F99 22               [24]  596 	ret
                                    597 
                                    598 	.area CSEG (CODE)
                                    599 ; function ak820_outline_0098
      004F9A                        600 _ak820_outline_0098:
      004F9A E0               [24]  601 	movx	a,@dptr
      004F9B F9               [12]  602 	mov	r1,a
      004F9C A3               [24]  603 	inc	dptr
      004F9D E0               [24]  604 	movx	a,@dptr
      004F9E FA               [12]  605 	mov	r2,a
      004F9F A3               [24]  606 	inc	dptr
      004FA0 E0               [24]  607 	movx	a,@dptr
      004FA1 FB               [12]  608 	mov	r3,a
      004FA2 22               [24]  609 	ret
                                    610 
                                    611 	.area CSEG (CODE)
                                    612 ; function ak820_outline_0099
      004FA3                        613 _ak820_outline_0099:
      004FA3 E0               [24]  614 	movx	a,@dptr
      004FA4 FE               [12]  615 	mov	r6,a
      004FA5 A3               [24]  616 	inc	dptr
      004FA6 E0               [24]  617 	movx	a,@dptr
      004FA7 8E 82            [24]  618 	mov	dpl,r6
      004FA9 F5 83            [12]  619 	mov	dph,a
      004FAB 22               [24]  620 	ret
                                    621 
                                    622 	.area CSEG (CODE)
                                    623 ; function ak820_outline_0119
      004FAC                        624 _ak820_outline_0119:
      004FAC F0               [24]  625 	movx	@dptr,a
      004FAD EA               [12]  626 	mov	a,r2
      004FAE A3               [24]  627 	inc	dptr
      004FAF F0               [24]  628 	movx	@dptr,a
      004FB0 EB               [12]  629 	mov	a,r3
      004FB1 A3               [24]  630 	inc	dptr
      004FB2 22               [24]  631 	ret
                                    632 
                                    633 	.area CSEG (CODE)
                                    634 ; function ak820_outline_0174
      004FB3                        635 _ak820_outline_0174:
      004FB3 E4               [12]  636 	clr	a
      004FB4 F0               [24]  637 	movx	@dptr,a
      004FB5 A3               [24]  638 	inc	dptr
      004FB6 F0               [24]  639 	movx	@dptr,a
      004FB7 22               [24]  640 	ret
