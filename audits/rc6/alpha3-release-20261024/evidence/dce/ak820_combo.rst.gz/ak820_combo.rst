                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _input_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _output_sloc0_1_0:
      000001                        542 	.ds 1
      000002                        543 _ak820_combo_valid_sloc0_1_0:
      000002                        544 	.ds 1
      000003                        545 _ak820_combo_process_sloc0_1_0:
      000003                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      00041B                        555 _input_code_10000_585:
      00041B                        556 	.ds 2
      00041D                        557 _output_code_10000_587:
      00041D                        558 	.ds 2
      00041F                        559 _combos:
      00041F                        560 	.ds 32
      00043F                        561 _saved:
      00043F                        562 	.ds 9
      000448                        563 _active:
      000448                        564 	.ds 1
      000449                        565 _ak820_combo_valid_entry_10000_589:
      000449                        566 	.ds 2
      00044B                        567 _ak820_combo_reload_entry_30000_601:
      00044B                        568 	.ds 10
      000455                        569 _ak820_combo_tick_now_10000_606:
      000455                        570 	.ds 2
      000457                        571 _ak820_combo_process_record_10000_609:
      000457                        572 	.ds 2
      000459                        573 _ak820_combo_process_eligible_10001_624:
      000459                        574 	.ds 1
      00045A                        575 _ak820_combo_process_i_40001_627:
      00045A                        576 	.ds 1
      00045B                        577 _ak820_combo_process_a_50001_628:
      00045B                        578 	.ds 1
      00045C                        579 _ak820_combo_process_b_50001_628:
      00045C                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000DD0                        589 _first:
      000DD0                        590 	.ds 1
      000DD1                        591 _second:
      000DD1                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      0034EC                        636 _input:
      0034EC 12 39 03         [24]  637 	lcall	_ak820_outline_0122
      0034EF 90 04 1B         [24]  638 	mov	dptr,#_input_code_10000_585
      0034F2 12 38 FE         [24]  639 	lcall	_ak820_outline_0121
      0034F5 90 04 1B         [24]  640 	mov	dptr,#_input_code_10000_585
      0034F8 12 38 C3         [24]  641 	lcall	_ak820_outline_0060
      0034FB C3               [12]  642 	clr	c
      0034FC EE               [12]  643 	mov	a,r6
      0034FD 94 04            [12]  644 	subb	a,#0x04
      0034FF EF               [12]  645 	mov	a,r7
      003500 94 00            [12]  646 	subb	a,#0x00
      003502 40 07            [24]  647 	jc	00103$
      003504 74 A4            [12]  648 	mov	a,#0xa4
      003506 9E               [12]  649 	subb	a,r6
      003507 E4               [12]  650 	clr	a
      003508 9F               [12]  651 	subb	a,r7
      003509 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      00350B                        654 00103$:
                                    655 ;	assignBit
      00350B C2 00            [12]  656 	clr	_input_sloc0_1_0
      00350D 80 02            [24]  657 	sjmp	00105$
      00350F                        658 00104$:
                                    659 ;	assignBit
      00350F D2 00            [12]  660 	setb	_input_sloc0_1_0
      003511                        661 00105$:
      003511 A2 00            [12]  662 	mov	c,_input_sloc0_1_0
      003513 12 39 33         [24]  663 	lcall	_ak820_outline_0163
      003516 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_587'
                                    669 ;basic         Allocated with name '_output_basic_10000_588'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:10: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      003517                        675 _output:
      003517 12 39 03         [24]  676 	lcall	_ak820_outline_0122
      00351A 90 04 1D         [24]  677 	mov	dptr,#_output_code_10000_587
      00351D 12 38 FE         [24]  678 	lcall	_ak820_outline_0121
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:11: uint8_t basic = code;
      003520 90 04 1D         [24]  680 	mov	dptr,#_output_code_10000_587
      003523 12 38 C3         [24]  681 	lcall	_ak820_outline_0060
      003526 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:12: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      003528 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      00352A 2F               [12]  685 	add	a,r7
      00352B 40 1C            [24]  686 	jc	00103$
      00352D 8D 06            [24]  687 	mov	ar6,r5
      00352F 7F 00            [12]  688 	mov	r7,#0x00
      003531 12 39 08         [24]  689 	lcall	_ak820_outline_0123
      003534 C0 05            [24]  690 	push	ar5
      003536 12 34 EC         [24]  691 	lcall	_input
      003539 E5 82            [12]  692 	mov	a, dpl
      00353B D0 05            [24]  693 	pop	ar5
      00353D 70 0E            [24]  694 	jnz	00104$
      00353F BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      003542                        696 00135$:
      003542 40 05            [24]  697 	jc	00103$
      003544 ED               [12]  698 	mov	a,r5
      003545 24 18            [12]  699 	add	a,#0xff - 0xe7
      003547 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      003549                        702 00103$:
                                    703 ;	assignBit
      003549 C2 01            [12]  704 	clr	_output_sloc0_1_0
      00354B 80 02            [24]  705 	sjmp	00105$
      00354D                        706 00104$:
                                    707 ;	assignBit
      00354D D2 01            [12]  708 	setb	_output_sloc0_1_0
      00354F                        709 00105$:
      00354F A2 01            [12]  710 	mov	c,_output_sloc0_1_0
      003551 12 39 33         [24]  711 	lcall	_ak820_outline_0163
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:13: }
      003554 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_589'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:19: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      003555                        723 _ak820_combo_valid:
      003555 12 39 03         [24]  724 	lcall	_ak820_outline_0122
      003558 90 04 49         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_589
      00355B 12 38 FE         [24]  726 	lcall	_ak820_outline_0121
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:20: if (entry->input[2] || entry->input[3]) return false;
      00355E 90 04 49         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_589
      003561 12 38 81         [24]  729 	lcall	_ak820_outline_0010
      003564 A3               [24]  730 	inc	dptr
      003565 A3               [24]  731 	inc	dptr
      003566 A3               [24]  732 	inc	dptr
      003567 A3               [24]  733 	inc	dptr
      003568 E0               [24]  734 	movx	a,@dptr
      003569 FC               [12]  735 	mov	r4,a
      00356A A3               [24]  736 	inc	dptr
      00356B E0               [24]  737 	movx	a,@dptr
      00356C 4C               [12]  738 	orl	a,r4
      00356D 70 0B            [24]  739 	jnz	00101$
      00356F 74 06            [12]  740 	mov	a,#0x06
      003571 12 38 9D         [24]  741 	lcall	_ak820_outline_0023
      003574 FC               [12]  742 	mov	r4,a
      003575 A3               [24]  743 	inc	dptr
      003576 E0               [24]  744 	movx	a,@dptr
      003577 4C               [12]  745 	orl	a,r4
      003578 60 04            [24]  746 	jz	00102$
      00357A                        747 00101$:
      00357A 75 82 00         [24]  748 	mov	dpl, #0x00
      00357D 22               [24]  749 	ret
      00357E                        750 00102$:
                                    751 ;	keyboards/ajazz/ak820/ak820_combo.c:21: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00357E 8E 04            [24]  752 	mov	ar4,r6
      003580 8F 05            [24]  753 	mov	ar5,r7
      003582 12 38 B3         [24]  754 	lcall	_ak820_outline_0038
      003585 FA               [12]  755 	mov	r2,a
      003586 A3               [24]  756 	inc	dptr
      003587 E0               [24]  757 	movx	a,@dptr
      003588 FB               [12]  758 	mov	r3,a
      003589 12 34 76         [24]  759 	lcall	_ak820_outline_0132
      00358C 12 38 DA         [24]  760 	lcall	_ak820_outline_0076
      00358F EA               [12]  761 	mov	a,r2
      003590 4C               [12]  762 	orl	a,r4
      003591 F8               [12]  763 	mov	r0,a
      003592 EB               [12]  764 	mov	a,r3
      003593 4D               [12]  765 	orl	a,r5
      003594 48               [12]  766 	orl	a,r0
      003595 70 12            [24]  767 	jnz	00105$
      003597 74 08            [12]  768 	mov	a,#0x08
      003599 12 38 9D         [24]  769 	lcall	_ak820_outline_0023
      00359C F8               [12]  770 	mov	r0,a
      00359D A3               [24]  771 	inc	dptr
      00359E E0               [24]  772 	movx	a,@dptr
      00359F 48               [12]  773 	orl	a,r0
      0035A0 B4 01 00         [24]  774 	cjne	a,#0x01,00152$
      0035A3                        775 00152$:
      0035A3 92 02            [24]  776 	mov  _ak820_combo_valid_sloc0_1_0,c
      0035A5 12 39 33         [24]  777 	lcall	_ak820_outline_0163
      0035A8 22               [24]  778 	ret
      0035A9                        779 00105$:
                                    780 ;	keyboards/ajazz/ak820/ak820_combo.c:22: if (entry->input[0] == entry->input[1]) return false;
      0035A9 EC               [12]  781 	mov	a,r4
      0035AA B5 02 08         [24]  782 	cjne	a,ar2,00107$
      0035AD ED               [12]  783 	mov	a,r5
      0035AE B5 03 04         [24]  784 	cjne	a,ar3,00107$
      0035B1 75 82 00         [24]  785 	mov	dpl, #0x00
      0035B4 22               [24]  786 	ret
      0035B5                        787 00107$:
                                    788 ;	keyboards/ajazz/ak820/ak820_combo.c:23: if (!input(entry->input[0])) return false;
      0035B5 12 34 76         [24]  789 	lcall	_ak820_outline_0132
      0035B8 C0 07            [24]  790 	push	ar7
      0035BA C0 06            [24]  791 	push	ar6
      0035BC C0 03            [24]  792 	push	ar3
      0035BE C0 02            [24]  793 	push	ar2
      0035C0 12 34 EC         [24]  794 	lcall	_input
      0035C3 E5 82            [12]  795 	mov	a, dpl
      0035C5 D0 02            [24]  796 	pop	ar2
      0035C7 D0 03            [24]  797 	pop	ar3
      0035C9 D0 06            [24]  798 	pop	ar6
      0035CB D0 07            [24]  799 	pop	ar7
      0035CD 70 03            [24]  800 	jnz	00109$
      0035CF F5 82            [12]  801 	mov	dpl,a
      0035D1 22               [24]  802 	ret
      0035D2                        803 00109$:
                                    804 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (!input(entry->input[1])) return false;
      0035D2 12 39 12         [24]  805 	lcall	_ak820_outline_0140
      0035D5 C0 07            [24]  806 	push	ar7
      0035D7 C0 06            [24]  807 	push	ar6
      0035D9 12 34 EC         [24]  808 	lcall	_input
      0035DC E5 82            [12]  809 	mov	a, dpl
      0035DE D0 06            [24]  810 	pop	ar6
      0035E0 D0 07            [24]  811 	pop	ar7
      0035E2 70 03            [24]  812 	jnz	00111$
      0035E4 F5 82            [12]  813 	mov	dpl,a
      0035E6 22               [24]  814 	ret
      0035E7                        815 00111$:
                                    816 ;	keyboards/ajazz/ak820/ak820_combo.c:25: return output(entry->output);
      0035E7 74 08            [12]  817 	mov	a,#0x08
      0035E9 12 38 BB         [24]  818 	lcall	_ak820_outline_0045
      0035EC 12 38 81         [24]  819 	lcall	_ak820_outline_0010
                                    820 ;	keyboards/ajazz/ak820/ak820_combo.c:26: }
      0035EF 02 35 17         [24]  821 	ljmp	_output
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    824 ;------------------------------------------------------------
                                    825 ;	keyboards/ajazz/ak820/ak820_combo.c:29: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    826 ;	-----------------------------------------
                                    827 ;	 function ak820_combo_cancel
                                    828 ;	-----------------------------------------
      0035F2                        829 _ak820_combo_cancel:
      0035F2 90 0D D1         [24]  830 	mov	dptr,#_second
      0035F5 74 FF            [12]  831 	mov	a,#0xff
      0035F7 F0               [24]  832 	movx	@dptr,a
      0035F8 90 0D D0         [24]  833 	mov	dptr,#_first
      0035FB F0               [24]  834 	movx	@dptr,a
      0035FC 90 04 48         [24]  835 	mov	dptr,#_active
      0035FF E4               [12]  836 	clr	a
      003600 F0               [24]  837 	movx	@dptr,a
      003601 22               [24]  838 	ret
                                    839 ;------------------------------------------------------------
                                    840 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    841 ;------------------------------------------------------------
                                    842 ;i             Allocated with name '_ak820_combo_reload_i_20000_600'
                                    843 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_601'
                                    844 ;------------------------------------------------------------
                                    845 ;	keyboards/ajazz/ak820/ak820_combo.c:30: void ak820_combo_reload(void) {
                                    846 ;	-----------------------------------------
                                    847 ;	 function ak820_combo_reload
                                    848 ;	-----------------------------------------
      003602                        849 _ak820_combo_reload:
                                    850 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003602 7F 00            [12]  851 	mov	r7,#0x00
      003604                        852 00105$:
      003604 BF 08 00         [24]  853 	cjne	r7,#0x08,00131$
      003607                        854 00131$:
      003607 40 01            [24]  855 	jc	00132$
      003609 22               [24]  856 	ret
      00360A                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_combo.c:33: combos[i].a = 0;
      00360A EF               [12]  859 	mov	a,r7
      00360B 75 F0 04         [24]  860 	mov	b,#0x04
      00360E A4               [48]  861 	mul	ab
      00360F 24 1F            [12]  862 	add	a, #_combos
      003611 FD               [12]  863 	mov	r5,a
      003612 74 04            [12]  864 	mov	a,#(_combos >> 8)
      003614 35 F0            [12]  865 	addc	a, b
      003616 FE               [12]  866 	mov	r6,a
      003617 8D 03            [24]  867 	mov	ar3,r5
      003619 8E 04            [24]  868 	mov	ar4,r6
      00361B 12 34 71         [24]  869 	lcall	_ak820_outline_0129
      00361E E4               [12]  870 	clr	a
      00361F F0               [24]  871 	movx	@dptr,a
                                    872 ;	keyboards/ajazz/ak820/ak820_combo.c:34: if (!dynamic_keymap_get_combo(i, &entry)) {
      003620 90 0A E6         [24]  873 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003623 74 4B            [12]  874 	mov	a,#_ak820_combo_reload_entry_30000_601
      003625 F0               [24]  875 	movx	@dptr,a
      003626 74 04            [12]  876 	mov	a,#(_ak820_combo_reload_entry_30000_601 >> 8)
      003628 12 38 E0         [24]  877 	lcall	_ak820_outline_0081
      00362B 8F 82            [24]  878 	mov	dpl, r7
      00362D C0 07            [24]  879 	push	ar7
      00362F C0 06            [24]  880 	push	ar6
      003631 C0 05            [24]  881 	push	ar5
      003633 C0 04            [24]  882 	push	ar4
      003635 C0 03            [24]  883 	push	ar3
      003637 12 86 AC         [24]  884 	lcall	_dynamic_keymap_get_combo
      00363A 12 39 22         [24]  885 	lcall	_ak820_outline_0145
      00363D D0 03            [24]  886 	pop	ar3
      00363F D0 04            [24]  887 	pop	ar4
      003641 D0 05            [24]  888 	pop	ar5
      003643 D0 06            [24]  889 	pop	ar6
      003645 D0 07            [24]  890 	pop	ar7
      003647 45 F0            [12]  891 	orl	a,b
      003649 70 28            [24]  892 	jnz	00106$
                                    893 ;	keyboards/ajazz/ak820/ak820_combo.c:35: combos[i].a = entry.input[0];
      00364B 90 04 4B         [24]  894 	mov	dptr,#_ak820_combo_reload_entry_30000_601
      00364E E0               [24]  895 	movx	a,@dptr
      00364F 12 34 71         [24]  896 	lcall	_ak820_outline_0129
      003652 F0               [24]  897 	movx	@dptr,a
                                    898 ;	keyboards/ajazz/ak820/ak820_combo.c:36: combos[i].b = entry.input[1];
      003653 74 01            [12]  899 	mov	a,#0x01
      003655 2D               [12]  900 	add	a, r5
      003656 FB               [12]  901 	mov	r3,a
      003657 E4               [12]  902 	clr	a
      003658 3E               [12]  903 	addc	a, r6
      003659 FC               [12]  904 	mov	r4,a
      00365A 90 04 4D         [24]  905 	mov	dptr,#(_ak820_combo_reload_entry_30000_601 + 0x0002)
      00365D E0               [24]  906 	movx	a,@dptr
      00365E 12 34 71         [24]  907 	lcall	_ak820_outline_0129
      003661 F0               [24]  908 	movx	@dptr,a
                                    909 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].output = entry.output;
      003662 74 02            [12]  910 	mov	a,#0x02
      003664 12 39 1C         [24]  911 	lcall	_ak820_outline_0143
      003667 90 04 53         [24]  912 	mov	dptr,#(_ak820_combo_reload_entry_30000_601 + 0x0008)
      00366A 12 39 28         [24]  913 	lcall	_ak820_outline_0147
      00366D 12 39 17         [24]  914 	lcall	_ak820_outline_0141
      003670 12 38 F2         [24]  915 	lcall	_ak820_outline_0103
      003673                        916 00106$:
                                    917 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003673 0F               [12]  918 	inc	r7
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:40: }
      003674 02 36 04         [24]  920 	ljmp	00105$
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'flush'
                                    923 ;------------------------------------------------------------
                                    924 ;	keyboards/ajazz/ak820/ak820_combo.c:41: static void flush(void) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function flush
                                    927 ;	-----------------------------------------
      003677                        928 _flush:
                                    929 ;	keyboards/ajazz/ak820/ak820_combo.c:42: first = NONE;
      003677 90 0D D0         [24]  930 	mov	dptr,#_first
      00367A 74 FF            [12]  931 	mov	a,#0xff
      00367C F0               [24]  932 	movx	@dptr,a
                                    933 ;	keyboards/ajazz/ak820/ak820_combo.c:43: process_record(&saved);
      00367D 90 04 3F         [24]  934 	mov	dptr,#_saved
      003680 75 F0 00         [24]  935 	mov	b, #0x00
                                    936 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      003683 02 71 82         [24]  937 	ljmp	_process_record
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    940 ;------------------------------------------------------------
                                    941 ;now           Allocated with name '_ak820_combo_tick_now_10000_606'
                                    942 ;------------------------------------------------------------
                                    943 ;	keyboards/ajazz/ak820/ak820_combo.c:45: void ak820_combo_tick(uint16_t now) {
                                    944 ;	-----------------------------------------
                                    945 ;	 function ak820_combo_tick
                                    946 ;	-----------------------------------------
      003686                        947 _ak820_combo_tick:
      003686 12 39 03         [24]  948 	lcall	_ak820_outline_0122
      003689 90 04 55         [24]  949 	mov	dptr,#_ak820_combo_tick_now_10000_606
      00368C 12 38 FE         [24]  950 	lcall	_ak820_outline_0121
                                    951 ;	keyboards/ajazz/ak820/ak820_combo.c:46: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= 40) flush();
      00368F 12 39 38         [24]  952 	lcall	_ak820_outline_0191
      003692 FF               [12]  953 	mov	r7,a
      003693 BF FF 01         [24]  954 	cjne	r7,#0xff,00128$
      003696 22               [24]  955 	ret
      003697                        956 00128$:
      003697 90 04 48         [24]  957 	mov	dptr,#_active
      00369A E0               [24]  958 	movx	a,@dptr
      00369B 70 1F            [24]  959 	jnz	00105$
      00369D 90 04 41         [24]  960 	mov	dptr,#(_saved + 0x0002)
      0036A0 12 38 C3         [24]  961 	lcall	_ak820_outline_0060
      0036A3 90 04 55         [24]  962 	mov	dptr,#_ak820_combo_tick_now_10000_606
      0036A6 12 38 DA         [24]  963 	lcall	_ak820_outline_0076
      0036A9 EC               [12]  964 	mov	a,r4
      0036AA C3               [12]  965 	clr	c
      0036AB 9E               [12]  966 	subb	a,r6
      0036AC FE               [12]  967 	mov	r6,a
      0036AD ED               [12]  968 	mov	a,r5
      0036AE 9F               [12]  969 	subb	a,r7
      0036AF FF               [12]  970 	mov	r7,a
      0036B0 C3               [12]  971 	clr	c
      0036B1 EE               [12]  972 	mov	a,r6
      0036B2 94 28            [12]  973 	subb	a,#0x28
      0036B4 EF               [12]  974 	mov	a,r7
      0036B5 94 00            [12]  975 	subb	a,#0x00
      0036B7 40 03            [24]  976 	jc	00105$
                                    977 ;	keyboards/ajazz/ak820/ak820_combo.c:47: }
      0036B9 02 36 77         [24]  978 	ljmp	_flush
      0036BC                        979 00105$:
      0036BC 22               [24]  980 	ret
                                    981 ;------------------------------------------------------------
                                    982 ;Allocation info for local variables in function 'ak820_combo_process'
                                    983 ;------------------------------------------------------------
                                    984 ;record        Allocated with name '_ak820_combo_process_record_10000_609'
                                    985 ;id            Allocated with name '_ak820_combo_process_id_10000_610'
                                    986 ;code          Allocated with name '_ak820_combo_process_code_10000_610'
                                    987 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_624'
                                    988 ;previous      Allocated with name '_ak820_combo_process_previous_30001_626'
                                    989 ;i             Allocated with name '_ak820_combo_process_i_40001_627'
                                    990 ;a             Allocated with name '_ak820_combo_process_a_50001_628'
                                    991 ;b             Allocated with name '_ak820_combo_process_b_50001_628'
                                    992 ;------------------------------------------------------------
                                    993 ;	keyboards/ajazz/ak820/ak820_combo.c:48: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function ak820_combo_process
                                    996 ;	-----------------------------------------
      0036BD                        997 _ak820_combo_process:
      0036BD 12 39 03         [24]  998 	lcall	_ak820_outline_0122
      0036C0 90 04 57         [24]  999 	mov	dptr,#_ak820_combo_process_record_10000_609
      0036C3 12 38 FE         [24] 1000 	lcall	_ak820_outline_0121
                                   1001 ;	keyboards/ajazz/ak820/ak820_combo.c:49: uint8_t id, code = record->keycode;
      0036C6 90 04 57         [24] 1002 	mov	dptr,#_ak820_combo_process_record_10000_609
      0036C9 12 38 C3         [24] 1003 	lcall	_ak820_outline_0060
      0036CC 74 07            [12] 1004 	mov	a,#0x07
      0036CE 12 38 9D         [24] 1005 	lcall	_ak820_outline_0023
      0036D1 FC               [12] 1006 	mov	r4,a
      0036D2 A3               [24] 1007 	inc	dptr
      0036D3 E0               [24] 1008 	movx	a,@dptr
      0036D4 FD               [12] 1009 	mov	r5,a
      0036D5 8C 03            [24] 1010 	mov	ar3,r4
                                   1011 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (IS_NOEVENT(record->event)) return true;
      0036D7 74 04            [12] 1012 	mov	a,#0x04
      0036D9 2E               [12] 1013 	add	a, r6
      0036DA 12 38 93         [24] 1014 	lcall	_ak820_outline_0018
      0036DD 70 04            [24] 1015 	jnz	00102$
      0036DF 75 82 01         [24] 1016 	mov	dpl, #0x01
      0036E2 22               [24] 1017 	ret
      0036E3                       1018 00102$:
                                   1019 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      0036E3 12 39 08         [24] 1020 	lcall	_ak820_outline_0123
      0036E6 A3               [24] 1021 	inc	dptr
      0036E7 E0               [24] 1022 	movx	a,@dptr
      0036E8 FA               [12] 1023 	mov	r2,a
      0036E9 BA 10 00         [24] 1024 	cjne	r2,#0x10,00300$
      0036EC                       1025 00300$:
      0036EC 50 0A            [24] 1026 	jnc	00106$
      0036EE 12 39 08         [24] 1027 	lcall	_ak820_outline_0123
      0036F1 E0               [24] 1028 	movx	a,@dptr
      0036F2 F9               [12] 1029 	mov	r1,a
      0036F3 B9 08 00         [24] 1030 	cjne	r1,#0x08,00302$
      0036F6                       1031 00302$:
      0036F6 40 16            [24] 1032 	jc	00107$
      0036F8                       1033 00106$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_combo.c:53: if (first != NONE && !active) flush();
      0036F8 12 39 38         [24] 1035 	lcall	_ak820_outline_0191
      0036FB F8               [12] 1036 	mov	r0,a
      0036FC B8 FF 02         [24] 1037 	cjne	r0,#0xff,00304$
      0036FF 80 09            [24] 1038 	sjmp	00104$
      003701                       1039 00304$:
      003701 90 04 48         [24] 1040 	mov	dptr,#_active
      003704 E0               [24] 1041 	movx	a,@dptr
      003705 70 03            [24] 1042 	jnz	00104$
      003707 12 36 77         [24] 1043 	lcall	_flush
      00370A                       1044 00104$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:54: return true;
      00370A 75 82 01         [24] 1046 	mov	dpl, #0x01
      00370D 22               [24] 1047 	ret
      00370E                       1048 00107$:
                                   1049 ;	keyboards/ajazz/ak820/ak820_combo.c:56: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      00370E EA               [12] 1050 	mov	a,r2
      00370F C4               [12] 1051 	swap	a
      003710 03               [12] 1052 	rr	a
      003711 54 F8            [12] 1053 	anl	a,#0xf8
      003713 29               [12] 1054 	add	a,r1
      003714 FA               [12] 1055 	mov	r2,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (active) {
      003715 90 04 48         [24] 1057 	mov	dptr,#_active
      003718 E0               [24] 1058 	movx	a,@dptr
      003719 60 71            [24] 1059 	jz	00123$
                                   1060 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (id != first && id != second) return true;
      00371B 12 39 38         [24] 1061 	lcall	_ak820_outline_0191
      00371E F9               [12] 1062 	mov	r1,a
      00371F EA               [12] 1063 	mov	a,r2
      003720 B5 01 02         [24] 1064 	cjne	a,ar1,00307$
      003723 80 0F            [24] 1065 	sjmp	00110$
      003725                       1066 00307$:
      003725 90 0D D1         [24] 1067 	mov	dptr,#_second
      003728 E0               [24] 1068 	movx	a,@dptr
      003729 F9               [12] 1069 	mov	r1,a
      00372A EA               [12] 1070 	mov	a,r2
      00372B B5 01 02         [24] 1071 	cjne	a,ar1,00308$
      00372E 80 04            [24] 1072 	sjmp	00110$
      003730                       1073 00308$:
      003730 75 82 01         [24] 1074 	mov	dpl, #0x01
      003733 22               [24] 1075 	ret
      003734                       1076 00110$:
                                   1077 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (!record->event.pressed) {
      003734 90 04 57         [24] 1078 	mov	dptr,#_ak820_combo_process_record_10000_609
      003737 12 38 F8         [24] 1079 	lcall	_ak820_outline_0109
      00373A 74 05            [12] 1080 	mov	a,#0x05
      00373C 28               [12] 1081 	add	a, r0
      00373D F8               [12] 1082 	mov	r0,a
      00373E E4               [12] 1083 	clr	a
      00373F 39               [12] 1084 	addc	a, r1
      003740 F9               [12] 1085 	mov	r1,a
      003741 12 39 2E         [24] 1086 	lcall	_ak820_outline_0155
      003744 E0               [24] 1087 	movx	a,@dptr
      003745 70 41            [24] 1088 	jnz	00121$
                                   1089 ;	keyboards/ajazz/ak820/ak820_combo.c:60: if (saved.event.pressed) {
      003747 90 04 44         [24] 1090 	mov	dptr,#(_saved + 0x0005)
      00374A E0               [24] 1091 	movx	a,@dptr
      00374B 60 11            [24] 1092 	jz	00113$
                                   1093 ;	keyboards/ajazz/ak820/ak820_combo.c:61: saved.event.pressed = false;
      00374D 90 04 44         [24] 1094 	mov	dptr,#(_saved + 0x0005)
      003750 E4               [12] 1095 	clr	a
      003751 F0               [24] 1096 	movx	@dptr,a
                                   1097 ;	keyboards/ajazz/ak820/ak820_combo.c:62: process_record(&saved);
      003752 90 04 3F         [24] 1098 	mov	dptr,#_saved
      003755 F5 F0            [12] 1099 	mov	b,a
      003757 C0 02            [24] 1100 	push	ar2
      003759 12 71 82         [24] 1101 	lcall	_process_record
      00375C D0 02            [24] 1102 	pop	ar2
      00375E                       1103 00113$:
                                   1104 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id == first) first = NONE;
      00375E 12 39 38         [24] 1105 	lcall	_ak820_outline_0191
      003761 F9               [12] 1106 	mov	r1,a
      003762 EA               [12] 1107 	mov	a,r2
      003763 B5 01 08         [24] 1108 	cjne	a,ar1,00115$
      003766 90 0D D0         [24] 1109 	mov	dptr,#_first
      003769 74 FF            [12] 1110 	mov	a,#0xff
      00376B F0               [24] 1111 	movx	@dptr,a
      00376C 80 06            [24] 1112 	sjmp	00116$
      00376E                       1113 00115$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_combo.c:65: else second = NONE;
      00376E 90 0D D1         [24] 1115 	mov	dptr,#_second
      003771 74 FF            [12] 1116 	mov	a,#0xff
      003773 F0               [24] 1117 	movx	@dptr,a
      003774                       1118 00116$:
                                   1119 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (first == NONE && second == NONE) active = false;
      003774 12 39 38         [24] 1120 	lcall	_ak820_outline_0191
      003777 F9               [12] 1121 	mov	r1,a
      003778 B9 FF 0D         [24] 1122 	cjne	r1,#0xff,00121$
      00377B 90 0D D1         [24] 1123 	mov	dptr,#_second
      00377E E0               [24] 1124 	movx	a,@dptr
      00377F F9               [12] 1125 	mov	r1,a
      003780 B9 FF 05         [24] 1126 	cjne	r1,#0xff,00121$
      003783 90 04 48         [24] 1127 	mov	dptr,#_active
      003786 E4               [12] 1128 	clr	a
      003787 F0               [24] 1129 	movx	@dptr,a
      003788                       1130 00121$:
                                   1131 ;	keyboards/ajazz/ak820/ak820_combo.c:68: return false;
      003788 75 82 00         [24] 1132 	mov	dpl, #0x00
      00378B 22               [24] 1133 	ret
      00378C                       1134 00123$:
                                   1135 ;	keyboards/ajazz/ak820/ak820_combo.c:70: bool eligible = false;
      00378C 90 04 59         [24] 1136 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      00378F E4               [12] 1137 	clr	a
      003790 F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_combo.c:71: if (record->event.pressed && input(record->keycode)) {
      003791 12 38 A6         [24] 1140 	lcall	_ak820_outline_0037
      003794 70 03            [24] 1141 	jnz	00317$
      003796 02 38 3F         [24] 1142 	ljmp	00134$
      003799                       1143 00317$:
      003799 12 34 76         [24] 1144 	lcall	_ak820_outline_0132
      00379C C0 03            [24] 1145 	push	ar3
      00379E C0 02            [24] 1146 	push	ar2
      0037A0 12 34 EC         [24] 1147 	lcall	_input
      0037A3 E5 82            [12] 1148 	mov	a, dpl
      0037A5 D0 02            [24] 1149 	pop	ar2
      0037A7 D0 03            [24] 1150 	pop	ar3
      0037A9 70 03            [24] 1151 	jnz	00318$
      0037AB 02 38 3F         [24] 1152 	ljmp	00134$
      0037AE                       1153 00318$:
                                   1154 ;	keyboards/ajazz/ak820/ak820_combo.c:72: uint8_t previous = saved.keycode;
      0037AE 90 04 46         [24] 1155 	mov	dptr,#(_saved + 0x0007)
      0037B1 E0               [24] 1156 	movx	a,@dptr
      0037B2 FF               [12] 1157 	mov	r7,a
                                   1158 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0037B3 90 04 5A         [24] 1159 	mov	dptr,#_ak820_combo_process_i_40001_627
      0037B6 E4               [12] 1160 	clr	a
      0037B7 F0               [24] 1161 	movx	@dptr,a
      0037B8 EB               [12] 1162 	mov	a,r3
      0037B9 B5 07 03         [24] 1163 	cjne	a,ar7,00319$
      0037BC D3               [12] 1164 	setb	c
      0037BD 80 01            [24] 1165 	sjmp	00320$
      0037BF                       1166 00319$:
      0037BF C3               [12] 1167 	clr	c
      0037C0                       1168 00320$:
      0037C0 92 03            [24] 1169 	mov	_ak820_combo_process_sloc0_1_0,c
      0037C2 7E 00            [12] 1170 	mov	r6,#0x00
      0037C4                       1171 00141$:
      0037C4 BE 08 00         [24] 1172 	cjne	r6,#0x08,00321$
      0037C7                       1173 00321$:
      0037C7 40 03            [24] 1174 	jc	00322$
      0037C9 02 38 3F         [24] 1175 	ljmp	00134$
      0037CC                       1176 00322$:
                                   1177 ;	keyboards/ajazz/ak820/ak820_combo.c:74: uint8_t a = combos[i].a, b = combos[i].b;
      0037CC EE               [12] 1178 	mov	a,r6
      0037CD 12 38 C9         [24] 1179 	lcall	_ak820_outline_0062
      0037D0 E0               [24] 1180 	movx	a,@dptr
      0037D1 F9               [12] 1181 	mov	r1,a
      0037D2 90 04 5B         [24] 1182 	mov	dptr,#_ak820_combo_process_a_50001_628
      0037D5 F0               [24] 1183 	movx	@dptr,a
      0037D6 12 34 76         [24] 1184 	lcall	_ak820_outline_0132
      0037D9 A3               [24] 1185 	inc	dptr
      0037DA E0               [24] 1186 	movx	a,@dptr
      0037DB FD               [12] 1187 	mov	r5,a
      0037DC 90 04 5C         [24] 1188 	mov	dptr,#_ak820_combo_process_b_50001_628
      0037DF F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (a == code || b == code) {
      0037E0 E9               [12] 1191 	mov	a,r1
      0037E1 B5 03 02         [24] 1192 	cjne	a,ar3,00323$
      0037E4 80 04            [24] 1193 	sjmp	00129$
      0037E6                       1194 00323$:
      0037E6 ED               [12] 1195 	mov	a,r5
      0037E7 B5 03 4C         [24] 1196 	cjne	a,ar3,00142$
      0037EA                       1197 00129$:
                                   1198 ;	keyboards/ajazz/ak820/ak820_combo.c:76: eligible = true;
      0037EA 90 04 59         [24] 1199 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      0037ED 74 01            [12] 1200 	mov	a,#0x01
      0037EF F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (first != NONE && code != previous && (a == previous || b == previous)) {
      0037F0 12 39 38         [24] 1203 	lcall	_ak820_outline_0191
      0037F3 FD               [12] 1204 	mov	r5,a
      0037F4 BD FF 02         [24] 1205 	cjne	r5,#0xff,00326$
      0037F7 80 3D            [24] 1206 	sjmp	00142$
      0037F9                       1207 00326$:
      0037F9 20 03 3A         [24] 1208 	jb	_ak820_combo_process_sloc0_1_0,00142$
      0037FC 90 04 5B         [24] 1209 	mov	dptr,#_ak820_combo_process_a_50001_628
      0037FF E0               [24] 1210 	movx	a,@dptr
      003800 B5 07 02         [24] 1211 	cjne	a,ar7,00328$
      003803 80 07            [24] 1212 	sjmp	00124$
      003805                       1213 00328$:
      003805 90 04 5C         [24] 1214 	mov	dptr,#_ak820_combo_process_b_50001_628
      003808 E0               [24] 1215 	movx	a,@dptr
      003809 B5 07 2A         [24] 1216 	cjne	a,ar7,00142$
      00380C                       1217 00124$:
                                   1218 ;	keyboards/ajazz/ak820/ak820_combo.c:78: second = id;
      00380C 90 0D D1         [24] 1219 	mov	dptr,#_second
      00380F EA               [12] 1220 	mov	a,r2
      003810 F0               [24] 1221 	movx	@dptr,a
                                   1222 ;	keyboards/ajazz/ak820/ak820_combo.c:79: active = true;
      003811 90 04 48         [24] 1223 	mov	dptr,#_active
      003814 74 01            [12] 1224 	mov	a,#0x01
      003816 F0               [24] 1225 	movx	@dptr,a
                                   1226 ;	keyboards/ajazz/ak820/ak820_combo.c:80: saved.keycode = combos[i].output;
      003817 90 04 5A         [24] 1227 	mov	dptr,#_ak820_combo_process_i_40001_627
      00381A E0               [24] 1228 	movx	a,@dptr
      00381B 12 38 C9         [24] 1229 	lcall	_ak820_outline_0062
      00381E A3               [24] 1230 	inc	dptr
      00381F A3               [24] 1231 	inc	dptr
      003820 12 38 DA         [24] 1232 	lcall	_ak820_outline_0076
      003823 90 04 46         [24] 1233 	mov	dptr,#(_saved + 0x0007)
      003826 12 38 E6         [24] 1234 	lcall	_ak820_outline_0087
                                   1235 ;	keyboards/ajazz/ak820/ak820_combo.c:81: process_record(&saved);
      003829 90 04 3F         [24] 1236 	mov	dptr,#_saved
      00382C 75 F0 00         [24] 1237 	mov	b, #0x00
      00382F 12 71 82         [24] 1238 	lcall	_process_record
                                   1239 ;	keyboards/ajazz/ak820/ak820_combo.c:82: return false;
      003832 75 82 00         [24] 1240 	mov	dpl, #0x00
      003835 22               [24] 1241 	ret
      003836                       1242 00142$:
                                   1243 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003836 0E               [12] 1244 	inc	r6
      003837 90 04 5A         [24] 1245 	mov	dptr,#_ak820_combo_process_i_40001_627
      00383A EE               [12] 1246 	mov	a,r6
      00383B F0               [24] 1247 	movx	@dptr,a
      00383C 02 37 C4         [24] 1248 	ljmp	00141$
      00383F                       1249 00134$:
                                   1250 ;	keyboards/ajazz/ak820/ak820_combo.c:87: if (first != NONE) flush();
      00383F 12 39 38         [24] 1251 	lcall	_ak820_outline_0191
      003842 FF               [12] 1252 	mov	r7,a
      003843 BF FF 02         [24] 1253 	cjne	r7,#0xff,00331$
      003846 80 07            [24] 1254 	sjmp	00137$
      003848                       1255 00331$:
      003848 C0 02            [24] 1256 	push	ar2
      00384A 12 36 77         [24] 1257 	lcall	_flush
      00384D D0 02            [24] 1258 	pop	ar2
      00384F                       1259 00137$:
                                   1260 ;	keyboards/ajazz/ak820/ak820_combo.c:88: if (eligible) {
      00384F 90 04 59         [24] 1261 	mov	dptr,#_ak820_combo_process_eligible_10001_624
      003852 E0               [24] 1262 	movx	a,@dptr
      003853 60 28            [24] 1263 	jz	00139$
                                   1264 ;	keyboards/ajazz/ak820/ak820_combo.c:89: first = id;
      003855 90 0D D0         [24] 1265 	mov	dptr,#_first
      003858 EA               [12] 1266 	mov	a,r2
      003859 F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	keyboards/ajazz/ak820/ak820_combo.c:90: saved = *record;
      00385A 90 04 57         [24] 1269 	mov	dptr,#_ak820_combo_process_record_10000_609
      00385D 12 38 EC         [24] 1270 	lcall	_ak820_outline_0089
      003860 7F 00            [12] 1271 	mov	r7,#0x00
      003862 90 0D C2         [24] 1272 	mov	dptr,#___memcpy_PARM_2
      003865 ED               [12] 1273 	mov	a,r5
      003866 12 38 8B         [24] 1274 	lcall	_ak820_outline_0017
      003869 90 0D C5         [24] 1275 	mov	dptr,#___memcpy_PARM_3
      00386C 74 09            [12] 1276 	mov	a,#0x09
      00386E 12 39 0D         [24] 1277 	lcall	_ak820_outline_0130
      003871 90 04 3F         [24] 1278 	mov	dptr,#_saved
      003874 F5 F0            [12] 1279 	mov	b,a
      003876 12 BC 07         [24] 1280 	lcall	___memcpy
                                   1281 ;	keyboards/ajazz/ak820/ak820_combo.c:91: return false;
      003879 75 82 00         [24] 1282 	mov	dpl, #0x00
      00387C 22               [24] 1283 	ret
      00387D                       1284 00139$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_combo.c:93: return true;
      00387D 75 82 01         [24] 1286 	mov	dpl, #0x01
                                   1287 ;	keyboards/ajazz/ak820/ak820_combo.c:94: }
      003880 22               [24] 1288 	ret
                                   1289 	.area CSEG    (CODE)
                                   1290 	.area CONST   (CODE)
                                   1291 	.area XINIT   (CODE)
      00C4CA                       1292 __xinit__first:
      00C4CA FF                    1293 	.db #0xff	; 255
      00C4CB                       1294 __xinit__second:
      00C4CB FF                    1295 	.db #0xff	; 255
                                   1296 	.area CABS    (ABS,CODE)
                                   1297 
                                   1298 ; Experimental exact instruction outlining.
                                   1299 	.globl _ak820_outline_0010
                                   1300 	.globl _ak820_outline_0017
                                   1301 	.globl _ak820_outline_0018
                                   1302 	.globl _ak820_outline_0023
                                   1303 	.globl _ak820_outline_0037
                                   1304 	.globl _ak820_outline_0038
                                   1305 	.globl _ak820_outline_0045
                                   1306 	.globl _ak820_outline_0060
                                   1307 	.globl _ak820_outline_0062
                                   1308 	.globl _ak820_outline_0076
                                   1309 	.globl _ak820_outline_0081
                                   1310 	.globl _ak820_outline_0087
                                   1311 	.globl _ak820_outline_0089
                                   1312 	.globl _ak820_outline_0103
                                   1313 	.globl _ak820_outline_0109
                                   1314 	.globl _ak820_outline_0121
                                   1315 	.globl _ak820_outline_0122
                                   1316 	.globl _ak820_outline_0123
                                   1317 	.globl _ak820_outline_0129
                                   1318 	.globl _ak820_outline_0130
                                   1319 	.globl _ak820_outline_0132
                                   1320 	.globl _ak820_outline_0140
                                   1321 	.globl _ak820_outline_0141
                                   1322 	.globl _ak820_outline_0143
                                   1323 	.globl _ak820_outline_0145
                                   1324 	.globl _ak820_outline_0147
                                   1325 	.globl _ak820_outline_0155
                                   1326 	.globl _ak820_outline_0163
                                   1327 	.globl _ak820_outline_0191
                                   1328 
                                   1329 	.area CSEG (CODE)
                                   1330 ; function ak820_outline_0010
      003881                       1331 _ak820_outline_0010:
      003881 E0               [24] 1332 	movx	a,@dptr
      003882 FE               [12] 1333 	mov	r6,a
      003883 A3               [24] 1334 	inc	dptr
      003884 E0               [24] 1335 	movx	a,@dptr
      003885 FF               [12] 1336 	mov	r7,a
      003886 8E 82            [24] 1337 	mov	dpl,r6
      003888 8F 83            [24] 1338 	mov	dph,r7
      00388A 22               [24] 1339 	ret
                                   1340 
                                   1341 	.area CSEG (CODE)
                                   1342 ; function ak820_outline_0017
      00388B                       1343 _ak820_outline_0017:
      00388B F0               [24] 1344 	movx	@dptr,a
      00388C EE               [12] 1345 	mov	a,r6
      00388D A3               [24] 1346 	inc	dptr
      00388E F0               [24] 1347 	movx	@dptr,a
      00388F EF               [12] 1348 	mov	a,r7
      003890 A3               [24] 1349 	inc	dptr
      003891 F0               [24] 1350 	movx	@dptr,a
      003892 22               [24] 1351 	ret
                                   1352 
                                   1353 	.area CSEG (CODE)
                                   1354 ; function ak820_outline_0018
      003893                       1355 _ak820_outline_0018:
      003893 F9               [12] 1356 	mov	r1,a
      003894 E4               [12] 1357 	clr	a
      003895 3F               [12] 1358 	addc	a,r7
      003896 FA               [12] 1359 	mov	r2,a
      003897 89 82            [24] 1360 	mov	dpl,r1
      003899 8A 83            [24] 1361 	mov	dph,r2
      00389B E0               [24] 1362 	movx	a,@dptr
      00389C 22               [24] 1363 	ret
                                   1364 
                                   1365 	.area CSEG (CODE)
                                   1366 ; function ak820_outline_0023
      00389D                       1367 _ak820_outline_0023:
      00389D 2E               [12] 1368 	add	a,r6
      00389E F5 82            [12] 1369 	mov	dpl,a
      0038A0 E4               [12] 1370 	clr	a
      0038A1 3F               [12] 1371 	addc	a,r7
      0038A2 F5 83            [12] 1372 	mov	dph,a
      0038A4 E0               [24] 1373 	movx	a,@dptr
      0038A5 22               [24] 1374 	ret
                                   1375 
                                   1376 	.area CSEG (CODE)
                                   1377 ; function ak820_outline_0037
      0038A6                       1378 _ak820_outline_0037:
      0038A6 74 05            [12] 1379 	mov	a,#0x05
      0038A8 2E               [12] 1380 	add	a,r6
      0038A9 FE               [12] 1381 	mov	r6,a
      0038AA E4               [12] 1382 	clr	a
      0038AB 3F               [12] 1383 	addc	a,r7
      0038AC FF               [12] 1384 	mov	r7,a
      0038AD 8E 82            [24] 1385 	mov	dpl,r6
      0038AF 8F 83            [24] 1386 	mov	dph,r7
      0038B1 E0               [24] 1387 	movx	a,@dptr
      0038B2 22               [24] 1388 	ret
                                   1389 
                                   1390 	.area CSEG (CODE)
                                   1391 ; function ak820_outline_0038
      0038B3                       1392 _ak820_outline_0038:
      0038B3 8E 82            [24] 1393 	mov	dpl,r6
      0038B5 8F 83            [24] 1394 	mov	dph,r7
      0038B7 A3               [24] 1395 	inc	dptr
      0038B8 A3               [24] 1396 	inc	dptr
      0038B9 E0               [24] 1397 	movx	a,@dptr
      0038BA 22               [24] 1398 	ret
                                   1399 
                                   1400 	.area CSEG (CODE)
                                   1401 ; function ak820_outline_0045
      0038BB                       1402 _ak820_outline_0045:
      0038BB 2E               [12] 1403 	add	a,r6
      0038BC F5 82            [12] 1404 	mov	dpl,a
      0038BE E4               [12] 1405 	clr	a
      0038BF 3F               [12] 1406 	addc	a,r7
      0038C0 F5 83            [12] 1407 	mov	dph,a
      0038C2 22               [24] 1408 	ret
                                   1409 
                                   1410 	.area CSEG (CODE)
                                   1411 ; function ak820_outline_0060
      0038C3                       1412 _ak820_outline_0060:
      0038C3 E0               [24] 1413 	movx	a,@dptr
      0038C4 FE               [12] 1414 	mov	r6,a
      0038C5 A3               [24] 1415 	inc	dptr
      0038C6 E0               [24] 1416 	movx	a,@dptr
      0038C7 FF               [12] 1417 	mov	r7,a
      0038C8 22               [24] 1418 	ret
                                   1419 
                                   1420 	.area CSEG (CODE)
                                   1421 ; function ak820_outline_0062
      0038C9                       1422 _ak820_outline_0062:
      0038C9 75 F0 04         [24] 1423 	mov	b,#0x04
      0038CC A4               [48] 1424 	mul	ab
      0038CD 24 1F            [12] 1425 	add	a,#_combos
      0038CF FC               [12] 1426 	mov	r4,a
      0038D0 74 04            [12] 1427 	mov	a,#(_combos>>8)
      0038D2 35 F0            [12] 1428 	addc	a,b
      0038D4 FD               [12] 1429 	mov	r5,a
      0038D5 8C 82            [24] 1430 	mov	dpl,r4
      0038D7 8D 83            [24] 1431 	mov	dph,r5
      0038D9 22               [24] 1432 	ret
                                   1433 
                                   1434 	.area CSEG (CODE)
                                   1435 ; function ak820_outline_0076
      0038DA                       1436 _ak820_outline_0076:
      0038DA E0               [24] 1437 	movx	a,@dptr
      0038DB FC               [12] 1438 	mov	r4,a
      0038DC A3               [24] 1439 	inc	dptr
      0038DD E0               [24] 1440 	movx	a,@dptr
      0038DE FD               [12] 1441 	mov	r5,a
      0038DF 22               [24] 1442 	ret
                                   1443 
                                   1444 	.area CSEG (CODE)
                                   1445 ; function ak820_outline_0081
      0038E0                       1446 _ak820_outline_0081:
      0038E0 A3               [24] 1447 	inc	dptr
      0038E1 F0               [24] 1448 	movx	@dptr,a
      0038E2 E4               [12] 1449 	clr	a
      0038E3 A3               [24] 1450 	inc	dptr
      0038E4 F0               [24] 1451 	movx	@dptr,a
      0038E5 22               [24] 1452 	ret
                                   1453 
                                   1454 	.area CSEG (CODE)
                                   1455 ; function ak820_outline_0087
      0038E6                       1456 _ak820_outline_0087:
      0038E6 EC               [12] 1457 	mov	a,r4
      0038E7 F0               [24] 1458 	movx	@dptr,a
      0038E8 ED               [12] 1459 	mov	a,r5
      0038E9 A3               [24] 1460 	inc	dptr
      0038EA F0               [24] 1461 	movx	@dptr,a
      0038EB 22               [24] 1462 	ret
                                   1463 
                                   1464 	.area CSEG (CODE)
                                   1465 ; function ak820_outline_0089
      0038EC                       1466 _ak820_outline_0089:
      0038EC E0               [24] 1467 	movx	a,@dptr
      0038ED FD               [12] 1468 	mov	r5,a
      0038EE A3               [24] 1469 	inc	dptr
      0038EF E0               [24] 1470 	movx	a,@dptr
      0038F0 FE               [12] 1471 	mov	r6,a
      0038F1 22               [24] 1472 	ret
                                   1473 
                                   1474 	.area CSEG (CODE)
                                   1475 ; function ak820_outline_0103
      0038F2                       1476 _ak820_outline_0103:
      0038F2 EB               [12] 1477 	mov	a,r3
      0038F3 F0               [24] 1478 	movx	@dptr,a
      0038F4 EC               [12] 1479 	mov	a,r4
      0038F5 A3               [24] 1480 	inc	dptr
      0038F6 F0               [24] 1481 	movx	@dptr,a
      0038F7 22               [24] 1482 	ret
                                   1483 
                                   1484 	.area CSEG (CODE)
                                   1485 ; function ak820_outline_0109
      0038F8                       1486 _ak820_outline_0109:
      0038F8 E0               [24] 1487 	movx	a,@dptr
      0038F9 F8               [12] 1488 	mov	r0,a
      0038FA A3               [24] 1489 	inc	dptr
      0038FB E0               [24] 1490 	movx	a,@dptr
      0038FC F9               [12] 1491 	mov	r1,a
      0038FD 22               [24] 1492 	ret
                                   1493 
                                   1494 	.area CSEG (CODE)
                                   1495 ; function ak820_outline_0121
      0038FE                       1496 _ak820_outline_0121:
      0038FE F0               [24] 1497 	movx	@dptr,a
      0038FF EF               [12] 1498 	mov	a,r7
      003900 A3               [24] 1499 	inc	dptr
      003901 F0               [24] 1500 	movx	@dptr,a
      003902 22               [24] 1501 	ret
                                   1502 
                                   1503 	.area CSEG (CODE)
                                   1504 ; function ak820_outline_0122
      003903                       1505 _ak820_outline_0122:
      003903 AF 83            [24] 1506 	mov	r7,dph
      003905 E5 82            [12] 1507 	mov	a,dpl
      003907 22               [24] 1508 	ret
                                   1509 
                                   1510 	.area CSEG (CODE)
                                   1511 ; function ak820_outline_0123
      003908                       1512 _ak820_outline_0123:
      003908 8E 82            [24] 1513 	mov	dpl,r6
      00390A 8F 83            [24] 1514 	mov	dph,r7
      00390C 22               [24] 1515 	ret
                                   1516 
                                   1517 	.area CSEG (CODE)
                                   1518 ; function ak820_outline_0130
      00390D                       1519 _ak820_outline_0130:
      00390D F0               [24] 1520 	movx	@dptr,a
      00390E E4               [12] 1521 	clr	a
      00390F A3               [24] 1522 	inc	dptr
      003910 F0               [24] 1523 	movx	@dptr,a
      003911 22               [24] 1524 	ret
                                   1525 
                                   1526 	.area CSEG (CODE)
                                   1527 ; function ak820_outline_0140
      003912                       1528 _ak820_outline_0140:
      003912 8A 82            [24] 1529 	mov	dpl,r2
      003914 8B 83            [24] 1530 	mov	dph,r3
      003916 22               [24] 1531 	ret
                                   1532 
                                   1533 	.area CSEG (CODE)
                                   1534 ; function ak820_outline_0141
      003917                       1535 _ak820_outline_0141:
      003917 8D 82            [24] 1536 	mov	dpl,r5
      003919 8E 83            [24] 1537 	mov	dph,r6
      00391B 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0143
      00391C                       1542 _ak820_outline_0143:
      00391C 2D               [12] 1543 	add	a,r5
      00391D FD               [12] 1544 	mov	r5,a
      00391E E4               [12] 1545 	clr	a
      00391F 3E               [12] 1546 	addc	a,r6
      003920 FE               [12] 1547 	mov	r6,a
      003921 22               [24] 1548 	ret
                                   1549 
                                   1550 	.area CSEG (CODE)
                                   1551 ; function ak820_outline_0145
      003922                       1552 _ak820_outline_0145:
      003922 E5 82            [12] 1553 	mov	a,dpl
      003924 85 83 F0         [24] 1554 	mov	b,dph
      003927 22               [24] 1555 	ret
                                   1556 
                                   1557 	.area CSEG (CODE)
                                   1558 ; function ak820_outline_0147
      003928                       1559 _ak820_outline_0147:
      003928 E0               [24] 1560 	movx	a,@dptr
      003929 FB               [12] 1561 	mov	r3,a
      00392A A3               [24] 1562 	inc	dptr
      00392B E0               [24] 1563 	movx	a,@dptr
      00392C FC               [12] 1564 	mov	r4,a
      00392D 22               [24] 1565 	ret
                                   1566 
                                   1567 	.area CSEG (CODE)
                                   1568 ; function ak820_outline_0155
      00392E                       1569 _ak820_outline_0155:
      00392E 88 82            [24] 1570 	mov	dpl,r0
      003930 89 83            [24] 1571 	mov	dph,r1
      003932 22               [24] 1572 	ret
                                   1573 
                                   1574 	.area CSEG (CODE)
                                   1575 ; function ak820_outline_0163
      003933                       1576 _ak820_outline_0163:
      003933 E4               [12] 1577 	clr	a
      003934 33               [12] 1578 	rlc	a
      003935 F5 82            [12] 1579 	mov	dpl,a
      003937 22               [24] 1580 	ret
                                   1581 
                                   1582 	.area CSEG (CODE)
                                   1583 ; function ak820_outline_0191
      003938                       1584 _ak820_outline_0191:
      003938 90 0D D0         [24] 1585 	mov	dptr,#_first
      00393B E0               [24] 1586 	movx	a,@dptr
      00393C 22               [24] 1587 	ret
