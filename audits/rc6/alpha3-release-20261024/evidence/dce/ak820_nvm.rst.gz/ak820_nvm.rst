                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000516                        109 _page_data:
      000516                        110 	.ds 64
      000556                        111 _cached_page:
      000556                        112 	.ds 1
      000557                        113 _batch_depth:
      000557                        114 	.ds 1
      000558                        115 _first_failure_stage:
      000558                        116 	.ds 1
      000559                        117 _nvm_fail_stage_10000_20:
      000559                        118 	.ds 1
      00055A                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055A                        120 	.ds 2
      00055C                        121 _crc_byte_PARM_2:
      00055C                        122 	.ds 1
      00055D                        123 _crc_byte_crc_10000_25:
      00055D                        124 	.ds 2
      00055F                        125 _page_crc_crc_10000_30:
      00055F                        126 	.ds 2
      000561                        127 _write_page_address_10000_32:
      000561                        128 	.ds 2
      000563                        129 _journal_header_valid_header_10000_39:
      000563                        130 	.ds 2
      000565                        131 _recover_journal_header_10000_46:
      000565                        132 	.ds 9
      00056E                        133 _ak820_nvm_flush_header_10000_62:
      00056E                        134 	.ds 9
      000577                        135 _ak820_nvm_flush_stage_10000_62:
      000577                        136 	.ds 1
      000578                        137 _load_page_page_10000_87:
      000578                        138 	.ds 1
      000579                        139 _read_offset_offset_10000_93:
      000579                        140 	.ds 2
      00057B                        141 _eeprom_read_byte_addr_10000_97:
      00057B                        142 	.ds 3
      00057E                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      00057E                        144 	.ds 3
      000581                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000581                        146 	.ds 2
      000583                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000583                        148 	.ds 2
      000585                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000585                        150 	.ds 2
      000587                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      000587                        152 	.ds 3
      00058A                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058A                        154 	.ds 2
      00058C                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058C                        156 	.ds 2
      00058E                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      00058E                        158 	.ds 3
      000591                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000591                        160 	.ds 2
      000593                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000593                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BF5                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BF5 E5 82            [12]  215 	mov	a,dpl
      003BF7 90 05 59         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BFA F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BFB 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003BFE 90 05 59         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003C01 E0               [24]  221 	movx	a,@dptr
      003C02 90 05 58         [24]  222 	mov	dptr,#_first_failure_stage
      003C05 F0               [24]  223 	movx	@dptr,a
      003C06                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003C06 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003C08 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003C09                        239 _ak820_nvm_diagnostic:
      003C09 12 39 03         [24]  240 	lcall	_ak820_outline_0122
      003C0C 90 05 5A         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C0F 12 38 FE         [24]  242 	lcall	_ak820_outline_0121
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003C12 90 05 5A         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C15 12 38 C3         [24]  245 	lcall	_ak820_outline_0060
      003C18 A2 0B            [12]  246 	mov	c,_storage_failed
      003C1A E4               [12]  247 	clr	a
      003C1B 33               [12]  248 	rlc	a
      003C1C 12 39 08         [24]  249 	lcall	_ak820_outline_0123
      003C1F 12 43 AB         [24]  250 	lcall	_ak820_outline_0088
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003C22 A3               [24]  252 	inc	dptr
      003C23 A2 09            [12]  253 	mov	c,_page_valid
      003C25 E4               [12]  254 	clr	a
      003C26 33               [12]  255 	rlc	a
      003C27 12 43 78         [24]  256 	lcall	_ak820_outline_0034
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003C2A A2 0A            [12]  258 	mov	c,_page_dirty
      003C2C E4               [12]  259 	clr	a
      003C2D 33               [12]  260 	rlc	a
      003C2E F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003C2F 74 03            [12]  263 	mov	a,#0x03
      003C31 12 43 E5         [24]  264 	lcall	_ak820_outline_0166
      003C34 90 05 57         [24]  265 	mov	dptr,#_batch_depth
      003C37 E0               [24]  266 	movx	a,@dptr
      003C38 12 43 CF         [24]  267 	lcall	_ak820_outline_0127
                                    268 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003C3B 74 04            [12]  269 	mov	a,#0x04
      003C3D 12 43 E5         [24]  270 	lcall	_ak820_outline_0166
      003C40 90 05 56         [24]  271 	mov	dptr,#_cached_page
      003C43 E0               [24]  272 	movx	a,@dptr
      003C44 12 43 CF         [24]  273 	lcall	_ak820_outline_0127
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C47 12 43 6E         [24]  275 	lcall	_ak820_outline_0016
      003C4A E4               [12]  276 	clr	a
      003C4B F0               [24]  277 	movx	@dptr,a
                                    278 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C4C 74 06            [12]  279 	mov	a,#0x06
      003C4E 12 43 DA         [24]  280 	lcall	_ak820_outline_0144
      003C51 90 05 58         [24]  281 	mov	dptr,#_first_failure_stage
      003C54 E0               [24]  282 	movx	a,@dptr
      003C55 12 39 08         [24]  283 	lcall	_ak820_outline_0123
      003C58 F0               [24]  284 	movx	@dptr,a
                                    285 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C59 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'crc_byte'
                                    289 ;------------------------------------------------------------
                                    290 ;value         Allocated with name '_crc_byte_PARM_2'
                                    291 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    292 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    293 ;------------------------------------------------------------
                                    294 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    295 ;	-----------------------------------------
                                    296 ;	 function crc_byte
                                    297 ;	-----------------------------------------
      003C5A                        298 _crc_byte:
      003C5A 12 39 03         [24]  299 	lcall	_ak820_outline_0122
      003C5D 90 05 5D         [24]  300 	mov	dptr,#_crc_byte_crc_10000_25
      003C60 12 38 FE         [24]  301 	lcall	_ak820_outline_0121
                                    302 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C63 90 05 5C         [24]  303 	mov	dptr,#_crc_byte_PARM_2
      003C66 E0               [24]  304 	movx	a,@dptr
      003C67 FF               [12]  305 	mov	r7,a
      003C68 7E 00            [12]  306 	mov	r6,#0x00
      003C6A 90 05 5D         [24]  307 	mov	dptr,#_crc_byte_crc_10000_25
      003C6D E0               [24]  308 	movx	a,@dptr
      003C6E 6E               [12]  309 	xrl	a,r6
      003C6F F0               [24]  310 	movx	@dptr,a
      003C70 A3               [24]  311 	inc	dptr
      003C71 E0               [24]  312 	movx	a,@dptr
      003C72 6F               [12]  313 	xrl	a,r7
      003C73 F0               [24]  314 	movx	@dptr,a
                                    315 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C74 7F 00            [12]  316 	mov	r7,#0x00
      003C76                        317 00102$:
                                    318 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C76 90 05 5D         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      003C79 12 38 EC         [24]  320 	lcall	_ak820_outline_0089
      003C7C 30 E7 0E         [24]  321 	jnb	acc.7,00106$
      003C7F ED               [12]  322 	mov	a,r5
      003C80 2D               [12]  323 	add	a,r5
      003C81 FB               [12]  324 	mov	r3,a
      003C82 EE               [12]  325 	mov	a,r6
      003C83 33               [12]  326 	rlc	a
      003C84 FC               [12]  327 	mov	r4,a
      003C85 63 03 21         [24]  328 	xrl	ar3,#0x21
      003C88 63 04 10         [24]  329 	xrl	ar4,#0x10
      003C8B 80 06            [24]  330 	sjmp	00107$
      003C8D                        331 00106$:
      003C8D ED               [12]  332 	mov	a,r5
      003C8E 2D               [12]  333 	add	a,r5
      003C8F FB               [12]  334 	mov	r3,a
      003C90 EE               [12]  335 	mov	a,r6
      003C91 33               [12]  336 	rlc	a
      003C92 FC               [12]  337 	mov	r4,a
      003C93                        338 00107$:
      003C93 90 05 5D         [24]  339 	mov	dptr,#_crc_byte_crc_10000_25
      003C96 12 38 F2         [24]  340 	lcall	_ak820_outline_0103
                                    341 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C99 0F               [12]  342 	inc	r7
      003C9A BF 08 D9         [24]  343 	cjne	r7,#0x08,00102$
                                    344 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C9D 12 34 71         [24]  345 	lcall	_ak820_outline_0129
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003CA0 22               [24]  347 	ret
                                    348 ;------------------------------------------------------------
                                    349 ;Allocation info for local variables in function 'page_crc'
                                    350 ;------------------------------------------------------------
                                    351 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    352 ;i             Allocated with name '_page_crc_i_10000_30'
                                    353 ;------------------------------------------------------------
                                    354 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function page_crc
                                    357 ;	-----------------------------------------
      003CA1                        358 _page_crc:
                                    359 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003CA1 90 05 5F         [24]  360 	mov	dptr,#_page_crc_crc_10000_30
      003CA4 74 FF            [12]  361 	mov	a,#0xff
      003CA6 F0               [24]  362 	movx	@dptr,a
      003CA7 A3               [24]  363 	inc	dptr
      003CA8 F0               [24]  364 	movx	@dptr,a
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003CA9 7F 00            [12]  366 	mov	r7,#0x00
      003CAB                        367 00102$:
      003CAB 90 05 5F         [24]  368 	mov	dptr,#_page_crc_crc_10000_30
      003CAE 12 38 EC         [24]  369 	lcall	_ak820_outline_0089
      003CB1 12 43 BD         [24]  370 	lcall	_ak820_outline_0112
      003CB4 90 05 5C         [24]  371 	mov	dptr,#_crc_byte_PARM_2
      003CB7 F0               [24]  372 	movx	@dptr,a
      003CB8 12 39 17         [24]  373 	lcall	_ak820_outline_0141
      003CBB C0 07            [24]  374 	push	ar7
      003CBD 12 3C 5A         [24]  375 	lcall	_crc_byte
      003CC0 AD 82            [24]  376 	mov	r5, dpl
      003CC2 AE 83            [24]  377 	mov	r6, dph
      003CC4 D0 07            [24]  378 	pop	ar7
      003CC6 90 05 5F         [24]  379 	mov	dptr,#_page_crc_crc_10000_30
      003CC9 12 43 C9         [24]  380 	lcall	_ak820_outline_0126
      003CCC 0F               [12]  381 	inc	r7
      003CCD BF 40 DB         [24]  382 	cjne	r7,#0x40,00102$
                                    383 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003CD0 12 39 17         [24]  384 	lcall	_ak820_outline_0141
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003CD3 22               [24]  386 	ret
                                    387 ;------------------------------------------------------------
                                    388 ;Allocation info for local variables in function 'write_page'
                                    389 ;------------------------------------------------------------
                                    390 ;address       Allocated with name '_write_page_address_10000_32'
                                    391 ;i             Allocated with name '_write_page_i_10000_33'
                                    392 ;------------------------------------------------------------
                                    393 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    394 ;	-----------------------------------------
                                    395 ;	 function write_page
                                    396 ;	-----------------------------------------
      003CD4                        397 _write_page:
      003CD4 12 39 03         [24]  398 	lcall	_ak820_outline_0122
      003CD7 90 05 61         [24]  399 	mov	dptr,#_write_page_address_10000_32
      003CDA 12 38 FE         [24]  400 	lcall	_ak820_outline_0121
                                    401 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003CDD 90 05 61         [24]  402 	mov	dptr,#_write_page_address_10000_32
      003CE0 12 38 81         [24]  403 	lcall	_ak820_outline_0010
      003CE3 C0 07            [24]  404 	push	ar7
      003CE5 C0 06            [24]  405 	push	ar6
      003CE7 12 3A 6E         [24]  406 	lcall	_ak820_flash_erase
      003CEA E5 82            [12]  407 	mov	a, dpl
      003CEC D0 06            [24]  408 	pop	ar6
      003CEE D0 07            [24]  409 	pop	ar7
      003CF0 70 03            [24]  410 	jnz	00102$
      003CF2 F5 82            [12]  411 	mov	dpl,a
      003CF4 22               [24]  412 	ret
      003CF5                        413 00102$:
                                    414 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CF5 90 04 F2         [24]  415 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CF8 74 16            [12]  416 	mov	a,#_page_data
      003CFA F0               [24]  417 	movx	@dptr,a
      003CFB 74 05            [12]  418 	mov	a,#(_page_data >> 8)
      003CFD A3               [24]  419 	inc	dptr
      003CFE 12 43 AB         [24]  420 	lcall	_ak820_outline_0088
      003D01 12 3B 82         [24]  421 	lcall	_ak820_flash_program_page
      003D04 E5 82            [12]  422 	mov	a, dpl
      003D06 70 03            [24]  423 	jnz	00120$
      003D08 F5 82            [12]  424 	mov	dpl,a
                                    425 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D0A 22               [24]  426 	ret
      003D0B                        427 00120$:
      003D0B 7F 00            [12]  428 	mov	r7,#0x00
      003D0D                        429 00108$:
                                    430 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003D0D 8F 05            [24]  431 	mov	ar5,r7
      003D0F 7E 00            [12]  432 	mov	r6,#0x00
      003D11 90 05 61         [24]  433 	mov	dptr,#_write_page_address_10000_32
      003D14 12 39 28         [24]  434 	lcall	_ak820_outline_0147
      003D17 ED               [12]  435 	mov	a,r5
      003D18 2B               [12]  436 	add	a, r3
      003D19 FB               [12]  437 	mov	r3,a
      003D1A EE               [12]  438 	mov	a,r6
      003D1B 3C               [12]  439 	addc	a, r4
      003D1C FC               [12]  440 	mov	r4,a
      003D1D 12 34 71         [24]  441 	lcall	_ak820_outline_0129
      003D20 12 39 61         [24]  442 	lcall	_ak820_flash_read
      003D23 AE 82            [24]  443 	mov	r6, dpl
      003D25 12 43 BD         [24]  444 	lcall	_ak820_outline_0112
      003D28 FD               [12]  445 	mov	r5,a
      003D29 EE               [12]  446 	mov	a,r6
      003D2A B5 05 02         [24]  447 	cjne	a,ar5,00149$
      003D2D 80 04            [24]  448 	sjmp	00109$
      003D2F                        449 00149$:
      003D2F 75 82 00         [24]  450 	mov	dpl, #0x00
      003D32 22               [24]  451 	ret
      003D33                        452 00109$:
                                    453 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D33 0F               [12]  454 	inc	r7
      003D34 BF 40 D6         [24]  455 	cjne	r7,#0x40,00108$
                                    456 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003D37 75 82 01         [24]  457 	mov	dpl, #0x01
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003D3A 22               [24]  459 	ret
                                    460 ;------------------------------------------------------------
                                    461 ;Allocation info for local variables in function 'journal_header_valid'
                                    462 ;------------------------------------------------------------
                                    463 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    464 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    465 ;------------------------------------------------------------
                                    466 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    467 ;	-----------------------------------------
                                    468 ;	 function journal_header_valid
                                    469 ;	-----------------------------------------
      003D3B                        470 _journal_header_valid:
      003D3B 12 39 03         [24]  471 	lcall	_ak820_outline_0122
      003D3E 90 05 63         [24]  472 	mov	dptr,#_journal_header_valid_header_10000_39
      003D41 12 38 FE         [24]  473 	lcall	_ak820_outline_0121
                                    474 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D44 90 05 63         [24]  475 	mov	dptr,#_journal_header_valid_header_10000_39
      003D47 12 38 81         [24]  476 	lcall	_ak820_outline_0010
      003D4A E0               [24]  477 	movx	a,@dptr
      003D4B FD               [12]  478 	mov	r5,a
      003D4C BD A5 02         [24]  479 	cjne	r5,#0xa5,00138$
      003D4F 80 04            [24]  480 	sjmp	00116$
      003D51                        481 00138$:
      003D51 75 82 00         [24]  482 	mov	dpl, #0x00
                                    483 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D54 22               [24]  484 	ret
      003D55                        485 00116$:
      003D55 7D 01            [12]  486 	mov	r5,#0x01
      003D57                        487 00106$:
                                    488 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D57 ED               [12]  489 	mov	a,r5
      003D58 12 38 9D         [24]  490 	lcall	_ak820_outline_0023
      003D5B FC               [12]  491 	mov	r4,a
      003D5C 8D 02            [24]  492 	mov	ar2,r5
      003D5E 7B 00            [12]  493 	mov	r3,#0x00
      003D60 74 04            [12]  494 	mov	a,#0x04
      003D62 2A               [12]  495 	add	a, r2
      003D63 FA               [12]  496 	mov	r2,a
      003D64 E4               [12]  497 	clr	a
      003D65 3B               [12]  498 	addc	a, r3
      003D66 FB               [12]  499 	mov	r3,a
      003D67 EA               [12]  500 	mov	a,r2
      003D68 2E               [12]  501 	add	a, r6
      003D69 F5 82            [12]  502 	mov	dpl,a
      003D6B EB               [12]  503 	mov	a,r3
      003D6C 3F               [12]  504 	addc	a, r7
      003D6D F5 83            [12]  505 	mov	dph,a
      003D6F E0               [24]  506 	movx	a,@dptr
      003D70 62 04            [12]  507 	xrl	ar4,a
      003D72 BC FF 02         [24]  508 	cjne	r4,#0xff,00139$
      003D75 80 04            [24]  509 	sjmp	00107$
      003D77                        510 00139$:
      003D77 75 82 00         [24]  511 	mov	dpl, #0x00
      003D7A 22               [24]  512 	ret
      003D7B                        513 00107$:
                                    514 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D7B 0D               [12]  515 	inc	r5
      003D7C BD 05 D8         [24]  516 	cjne	r5,#0x05,00106$
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D7F 75 82 01         [24]  518 	mov	dpl, #0x01
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D82 22               [24]  520 	ret
                                    521 ;------------------------------------------------------------
                                    522 ;Allocation info for local variables in function 'recover_journal'
                                    523 ;------------------------------------------------------------
                                    524 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    525 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    526 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    527 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    528 ;------------------------------------------------------------
                                    529 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    530 ;	-----------------------------------------
                                    531 ;	 function recover_journal
                                    532 ;	-----------------------------------------
      003D83                        533 _recover_journal:
                                    534 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D83 7F 00            [12]  535 	mov	r7,#0x00
      003D85                        536 00115$:
      003D85 EF               [12]  537 	mov	a,r7
      003D86 24 65            [12]  538 	add	a, #_recover_journal_header_10000_46
      003D88 FD               [12]  539 	mov	r5,a
      003D89 E4               [12]  540 	clr	a
      003D8A 34 05            [12]  541 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D8C FE               [12]  542 	mov	r6,a
      003D8D 8F 04            [24]  543 	mov	ar4,r7
      003D8F 7B 00            [12]  544 	mov	r3,#0x00
      003D91 74 40            [12]  545 	mov	a,#0x40
      003D93 2C               [12]  546 	add	a, r4
      003D94 FC               [12]  547 	mov	r4,a
      003D95 74 EF            [12]  548 	mov	a,#0xef
      003D97 3B               [12]  549 	addc	a, r3
      003D98 FB               [12]  550 	mov	r3,a
      003D99 12 43 F9         [24]  551 	lcall	_ak820_outline_0197
      003D9C 12 39 61         [24]  552 	lcall	_ak820_flash_read
      003D9F AC 82            [24]  553 	mov	r4, dpl
      003DA1 12 43 A4         [24]  554 	lcall	_ak820_outline_0074
      003DA4 0F               [12]  555 	inc	r7
      003DA5 BF 09 DD         [24]  556 	cjne	r7,#0x09,00115$
                                    557 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003DA8 90 05 65         [24]  558 	mov	dptr,#_recover_journal_header_10000_46
      003DAB 12 3D 3B         [24]  559 	lcall	_journal_header_valid
      003DAE E5 82            [12]  560 	mov	a, dpl
      003DB0 70 01            [24]  561 	jnz	00103$
      003DB2 22               [24]  562 	ret
      003DB3                        563 00103$:
                                    564 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003DB3 90 05 66         [24]  565 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003DB6 E0               [24]  566 	movx	a,@dptr
      003DB7 FF               [12]  567 	mov	r7,a
      003DB8 7E 00            [12]  568 	mov	r6,#0x00
      003DBA 90 05 67         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003DBD E0               [24]  570 	movx	a,@dptr
      003DBE FC               [12]  571 	mov	r4,a
      003DBF E4               [12]  572 	clr	a
      003DC0 42 07            [12]  573 	orl	ar7,a
      003DC2 EC               [12]  574 	mov	a,r4
      003DC3 42 06            [12]  575 	orl	ar6,a
                                    576 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003DC5 90 05 68         [24]  577 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003DC8 E0               [24]  578 	movx	a,@dptr
      003DC9 FD               [12]  579 	mov	r5,a
      003DCA 7C 00            [12]  580 	mov	r4,#0x00
      003DCC 90 05 69         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003DCF 12 43 EB         [24]  582 	lcall	_ak820_outline_0190
                                    583 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003DD2 C3               [12]  584 	clr	c
      003DD3 EF               [12]  585 	mov	a,r7
      003DD4 94 A0            [12]  586 	subb	a,#0xa0
      003DD6 EE               [12]  587 	mov	a,r6
      003DD7 94 00            [12]  588 	subb	a,#0x00
      003DD9 40 06            [24]  589 	jc	00134$
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003DDB 75 82 01         [24]  591 	mov	dpl, #0x01
                                    592 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DDE 02 3B F5         [24]  593 	ljmp	_nvm_fail
                                    594 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DE1                        595 00134$:
      003DE1 7B 00            [12]  596 	mov	r3,#0x00
      003DE3                        597 00117$:
      003DE3 C0 05            [24]  598 	push	ar5
      003DE5 C0 04            [24]  599 	push	ar4
      003DE7 EB               [12]  600 	mov	a,r3
      003DE8 24 16            [12]  601 	add	a, #_page_data
      003DEA F9               [12]  602 	mov	r1,a
      003DEB E4               [12]  603 	clr	a
      003DEC 34 05            [12]  604 	addc	a, #(_page_data >> 8)
      003DEE FA               [12]  605 	mov	r2,a
      003DEF 8B 00            [24]  606 	mov	ar0,r3
      003DF1 7D 00            [12]  607 	mov	r5,#0x00
      003DF3 74 EF            [12]  608 	mov	a,#0xef
      003DF5 2D               [12]  609 	add	a, r5
      003DF6 FD               [12]  610 	mov	r5,a
      003DF7 88 82            [24]  611 	mov	dpl, r0
      003DF9 8D 83            [24]  612 	mov	dph, r5
      003DFB 12 39 61         [24]  613 	lcall	_ak820_flash_read
      003DFE AD 82            [24]  614 	mov	r5, dpl
      003E00 89 82            [24]  615 	mov	dpl,r1
      003E02 8A 83            [24]  616 	mov	dph,r2
      003E04 ED               [12]  617 	mov	a,r5
      003E05 F0               [24]  618 	movx	@dptr,a
      003E06 0B               [12]  619 	inc	r3
      003E07 BB 40 02         [24]  620 	cjne	r3,#0x40,00190$
      003E0A 80 06            [24]  621 	sjmp	00191$
      003E0C                        622 00190$:
      003E0C D0 04            [24]  623 	pop	ar4
      003E0E D0 05            [24]  624 	pop	ar5
      003E10 80 D1            [24]  625 	sjmp	00117$
      003E12                        626 00191$:
      003E12 D0 04            [24]  627 	pop	ar4
      003E14 D0 05            [24]  628 	pop	ar5
                                    629 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003E16 C0 07            [24]  630 	push	ar7
      003E18 C0 06            [24]  631 	push	ar6
      003E1A C0 05            [24]  632 	push	ar5
      003E1C C0 04            [24]  633 	push	ar4
      003E1E 12 3C A1         [24]  634 	lcall	_page_crc
      003E21 AA 82            [24]  635 	mov	r2, dpl
      003E23 AB 83            [24]  636 	mov	r3, dph
      003E25 D0 04            [24]  637 	pop	ar4
      003E27 D0 05            [24]  638 	pop	ar5
      003E29 D0 06            [24]  639 	pop	ar6
      003E2B D0 07            [24]  640 	pop	ar7
      003E2D EA               [12]  641 	mov	a,r2
      003E2E B5 05 06         [24]  642 	cjne	a,ar5,00192$
      003E31 EB               [12]  643 	mov	a,r3
      003E32 B5 04 02         [24]  644 	cjne	a,ar4,00192$
      003E35 80 06            [24]  645 	sjmp	00113$
      003E37                        646 00192$:
      003E37 75 82 02         [24]  647 	mov	dpl, #0x02
      003E3A 02 3B F5         [24]  648 	ljmp	_nvm_fail
      003E3D                        649 00113$:
                                    650 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E3D EE               [12]  651 	mov	a,r6
      003E3E 54 03            [12]  652 	anl	a,#0x03
      003E40 A2 E0            [12]  653 	mov	c,acc.0
      003E42 CF               [12]  654 	xch	a,r7
      003E43 13               [12]  655 	rrc	a
      003E44 CF               [12]  656 	xch	a,r7
      003E45 13               [12]  657 	rrc	a
      003E46 A2 E0            [12]  658 	mov	c,acc.0
      003E48 CF               [12]  659 	xch	a,r7
      003E49 13               [12]  660 	rrc	a
      003E4A CF               [12]  661 	xch	a,r7
      003E4B 13               [12]  662 	rrc	a
      003E4C CF               [12]  663 	xch	a,r7
      003E4D 24 C7            [12]  664 	add	a,#0xc7
      003E4F FE               [12]  665 	mov	r6,a
      003E50 12 43 E0         [24]  666 	lcall	_ak820_outline_0164
      003E53 12 3C D4         [24]  667 	lcall	_write_page
      003E56 E5 82            [12]  668 	mov	a, dpl
      003E58 70 06            [24]  669 	jnz	00110$
      003E5A 75 82 03         [24]  670 	mov	dpl, #0x03
      003E5D 02 3B F5         [24]  671 	ljmp	_nvm_fail
      003E60                        672 00110$:
                                    673 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E60 90 EF 40         [24]  674 	mov	dptr,#0xef40
      003E63 12 3A 6E         [24]  675 	lcall	_ak820_flash_erase
      003E66 E5 82            [12]  676 	mov	a, dpl
      003E68 70 06            [24]  677 	jnz	00119$
      003E6A 75 82 04         [24]  678 	mov	dpl, #0x04
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E6D 02 3B F5         [24]  680 	ljmp	_nvm_fail
      003E70                        681 00119$:
      003E70 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    685 ;------------------------------------------------------------
                                    686 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    687 ;	-----------------------------------------
                                    688 ;	 function eeprom_driver_init
                                    689 ;	-----------------------------------------
      003E71                        690 _eeprom_driver_init:
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    692 ;	assignBit
      003E71 C2 0B            [12]  693 	clr	_storage_failed
                                    694 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E73 90 05 58         [24]  695 	mov	dptr,#_first_failure_stage
      003E76 E4               [12]  696 	clr	a
      003E77 F0               [24]  697 	movx	@dptr,a
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    699 ;	assignBit
      003E78 C2 0A            [12]  700 	clr	_page_dirty
                                    701 ;	assignBit
      003E7A C2 09            [12]  702 	clr	_page_valid
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E7C 90 05 57         [24]  704 	mov	dptr,#_batch_depth
      003E7F E4               [12]  705 	clr	a
      003E80 F0               [24]  706 	movx	@dptr,a
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E81 12 3D 83         [24]  708 	lcall	_recover_journal
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E84 02 2A B7         [24]  711 	ljmp	_ak820_macro_init
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    714 ;------------------------------------------------------------
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    716 ;	-----------------------------------------
                                    717 ;	 function ak820_nvm_ok
                                    718 ;	-----------------------------------------
      003E87                        719 _ak820_nvm_ok:
      003E87 A2 0B            [12]  720 	mov	c,_storage_failed
      003E89 B3               [12]  721 	cpl	c
      003E8A 92 0C            [24]  722 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E8C 12 39 33         [24]  723 	lcall	_ak820_outline_0163
      003E8F 22               [24]  724 	ret
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    727 ;------------------------------------------------------------
                                    728 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    729 ;	-----------------------------------------
                                    730 ;	 function ak820_nvm_schema_fault
                                    731 ;	-----------------------------------------
      003E90                        732 _ak820_nvm_schema_fault:
      003E90 75 82 10         [24]  733 	mov	dpl, #0x10
      003E93 02 3B F5         [24]  734 	ljmp	_nvm_fail
                                    735 ;------------------------------------------------------------
                                    736 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    737 ;------------------------------------------------------------
                                    738 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    739 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    740 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    741 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    742 ;------------------------------------------------------------
                                    743 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    744 ;	-----------------------------------------
                                    745 ;	 function ak820_nvm_flush
                                    746 ;	-----------------------------------------
      003E96                        747 _ak820_nvm_flush:
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E96 30 0A 03         [24]  749 	jnb	_page_dirty,00101$
      003E99 30 0B 01         [24]  750 	jnb	_storage_failed,00102$
      003E9C                        751 00101$:
      003E9C 22               [24]  752 	ret
      003E9D                        753 00102$:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E9D 12 3C A1         [24]  755 	lcall	_page_crc
      003EA0 12 43 D5         [24]  756 	lcall	_ak820_outline_0131
                                    757 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003EA3 90 05 6E         [24]  758 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EA6 74 A5            [12]  759 	mov	a,#0xa5
      003EA8 F0               [24]  760 	movx	@dptr,a
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003EA9 90 05 56         [24]  762 	mov	dptr,#_cached_page
      003EAC E0               [24]  763 	movx	a,@dptr
      003EAD 90 05 6F         [24]  764 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003EB0 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003EB1 90 05 70         [24]  767 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003EB4 E4               [12]  768 	clr	a
      003EB5 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003EB6 8E 05            [24]  771 	mov	ar5,r6
      003EB8 90 05 71         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003EBB ED               [12]  773 	mov	a,r5
      003EBC F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003EBD 8F 06            [24]  776 	mov	ar6,r7
      003EBF 90 05 72         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003EC2 EE               [12]  778 	mov	a,r6
      003EC3 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003EC4 7F 01            [12]  781 	mov	r7,#0x01
      003EC6                        782 00128$:
      003EC6 8F 06            [24]  783 	mov	ar6,r7
      003EC8 EE               [12]  784 	mov	a,r6
      003EC9 24 04            [12]  785 	add	a,#0x04
      003ECB FE               [12]  786 	mov	r6,a
      003ECC 33               [12]  787 	rlc	a
      003ECD 95 E0            [12]  788 	subb	a,acc
      003ECF FD               [12]  789 	mov	r5,a
      003ED0 EE               [12]  790 	mov	a,r6
      003ED1 24 6E            [12]  791 	add	a, #_ak820_nvm_flush_header_10000_62
      003ED3 FE               [12]  792 	mov	r6,a
      003ED4 ED               [12]  793 	mov	a,r5
      003ED5 34 05            [12]  794 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003ED7 FD               [12]  795 	mov	r5,a
      003ED8 12 43 87         [24]  796 	lcall	_ak820_outline_0047
      003EDB FC               [12]  797 	mov	r4,a
      003EDC 63 04 FF         [24]  798 	xrl	ar4,#0xff
      003EDF 8E 82            [24]  799 	mov	dpl,r6
      003EE1 8D 83            [24]  800 	mov	dph,r5
      003EE3 EC               [12]  801 	mov	a,r4
      003EE4 F0               [24]  802 	movx	@dptr,a
      003EE5 0F               [12]  803 	inc	r7
      003EE6 BF 05 DD         [24]  804 	cjne	r7,#0x05,00128$
                                    805 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EE9 90 05 77         [24]  806 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EEC 74 05            [12]  807 	mov	a,#0x05
      003EEE F0               [24]  808 	movx	@dptr,a
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EEF 90 EF 40         [24]  810 	mov	dptr,#0xef40
      003EF2 12 3A 6E         [24]  811 	lcall	_ak820_flash_erase
      003EF5 E5 82            [12]  812 	mov	a, dpl
      003EF7 70 03            [24]  813 	jnz	00269$
      003EF9 02 3F E0         [24]  814 	ljmp	00127$
      003EFC                        815 00269$:
                                    816 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EFC 90 05 77         [24]  817 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFF 74 06            [12]  818 	mov	a,#0x06
      003F01 F0               [24]  819 	movx	@dptr,a
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F02 7F 00            [12]  821 	mov	r7,#0x00
      003F04                        822 00130$:
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003F04 12 43 93         [24]  824 	lcall	_ak820_outline_0061
      003F07 12 39 61         [24]  825 	lcall	_ak820_flash_read
      003F0A E5 82            [12]  826 	mov	a, dpl
      003F0C 60 03            [24]  827 	jz	00270$
      003F0E 02 3F E0         [24]  828 	ljmp	00127$
      003F11                        829 00270$:
                                    830 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F11 0F               [12]  831 	inc	r7
      003F12 BF 40 EF         [24]  832 	cjne	r7,#0x40,00130$
                                    833 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003F15 90 05 77         [24]  834 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F18 74 07            [12]  835 	mov	a,#0x07
      003F1A F0               [24]  836 	movx	@dptr,a
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003F1B 90 EF 00         [24]  838 	mov	dptr,#0xef00
      003F1E 12 3C D4         [24]  839 	lcall	_write_page
      003F21 E5 82            [12]  840 	mov	a, dpl
      003F23 70 03            [24]  841 	jnz	00273$
      003F25 02 3F E0         [24]  842 	ljmp	00127$
      003F28                        843 00273$:
                                    844 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003F28 90 05 77         [24]  845 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2B 74 08            [12]  846 	mov	a,#0x08
      003F2D F0               [24]  847 	movx	@dptr,a
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F2E 7F 01            [12]  849 	mov	r7,#0x01
      003F30                        850 00132$:
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003F30 12 43 87         [24]  852 	lcall	_ak820_outline_0047
      003F33 FE               [12]  853 	mov	r6,a
      003F34 60 23            [24]  854 	jz	00133$
      003F36 8F 05            [24]  855 	mov	ar5,r7
      003F38 7C 00            [12]  856 	mov	r4,#0x00
      003F3A 74 40            [12]  857 	mov	a,#0x40
      003F3C 2D               [12]  858 	add	a, r5
      003F3D FD               [12]  859 	mov	r5,a
      003F3E 74 EF            [12]  860 	mov	a,#0xef
      003F40 3C               [12]  861 	addc	a, r4
      003F41 FC               [12]  862 	mov	r4,a
      003F42 90 04 EF         [24]  863 	mov	dptr,#_ak820_flash_program_PARM_2
      003F45 EE               [12]  864 	mov	a,r6
      003F46 F0               [24]  865 	movx	@dptr,a
      003F47 8D 82            [24]  866 	mov	dpl, r5
      003F49 8C 83            [24]  867 	mov	dph, r4
      003F4B C0 07            [24]  868 	push	ar7
      003F4D 12 3A CE         [24]  869 	lcall	_ak820_flash_program
      003F50 E5 82            [12]  870 	mov	a, dpl
      003F52 D0 07            [24]  871 	pop	ar7
      003F54 70 03            [24]  872 	jnz	00275$
      003F56 02 3F E0         [24]  873 	ljmp	00127$
      003F59                        874 00275$:
      003F59                        875 00133$:
                                    876 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F59 0F               [12]  877 	inc	r7
      003F5A BF 09 D3         [24]  878 	cjne	r7,#0x09,00132$
                                    879 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F5D 90 05 77         [24]  880 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F60 74 09            [12]  881 	mov	a,#0x09
      003F62 F0               [24]  882 	movx	@dptr,a
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F63 7F 01            [12]  884 	mov	r7,#0x01
      003F65                        885 00134$:
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F65 12 43 93         [24]  887 	lcall	_ak820_outline_0061
      003F68 12 39 61         [24]  888 	lcall	_ak820_flash_read
      003F6B AE 82            [24]  889 	mov	r6, dpl
      003F6D 12 43 87         [24]  890 	lcall	_ak820_outline_0047
      003F70 FD               [12]  891 	mov	r5,a
      003F71 EE               [12]  892 	mov	a,r6
      003F72 B5 05 6B         [24]  893 	cjne	a,ar5,00127$
                                    894 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F75 0F               [12]  895 	inc	r7
      003F76 BF 09 EC         [24]  896 	cjne	r7,#0x09,00134$
                                    897 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F79 90 05 77         [24]  898 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F7C 74 0A            [12]  899 	mov	a,#0x0a
      003F7E F0               [24]  900 	movx	@dptr,a
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F7F 90 05 6E         [24]  902 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F82 E0               [24]  903 	movx	a,@dptr
      003F83 90 04 EF         [24]  904 	mov	dptr,#_ak820_flash_program_PARM_2
      003F86 F0               [24]  905 	movx	@dptr,a
      003F87 90 EF 40         [24]  906 	mov	dptr,#0xef40
      003F8A 12 3A CE         [24]  907 	lcall	_ak820_flash_program
      003F8D E5 82            [12]  908 	mov	a, dpl
      003F8F 60 4F            [24]  909 	jz	00127$
                                    910 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F91 90 05 77         [24]  911 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F94 74 0B            [12]  912 	mov	a,#0x0b
      003F96 F0               [24]  913 	movx	@dptr,a
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F97 90 EF 40         [24]  915 	mov	dptr,#0xef40
      003F9A 12 39 61         [24]  916 	lcall	_ak820_flash_read
      003F9D AF 82            [24]  917 	mov	r7, dpl
      003F9F 90 05 6E         [24]  918 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003FA2 E0               [24]  919 	movx	a,@dptr
      003FA3 FE               [12]  920 	mov	r6,a
      003FA4 EF               [12]  921 	mov	a,r7
      003FA5 B5 06 38         [24]  922 	cjne	a,ar6,00127$
                                    923 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003FA8 90 05 77         [24]  924 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FAB 74 0C            [12]  925 	mov	a,#0x0c
      003FAD F0               [24]  926 	movx	@dptr,a
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003FAE 90 05 56         [24]  928 	mov	dptr,#_cached_page
      003FB1 E0               [24]  929 	movx	a,@dptr
      003FB2 FE               [12]  930 	mov	r6,a
      003FB3 E4               [12]  931 	clr	a
      003FB4 C3               [12]  932 	clr	c
      003FB5 CE               [12]  933 	xch	a,r6
      003FB6 13               [12]  934 	rrc	a
      003FB7 CE               [12]  935 	xch	a,r6
      003FB8 13               [12]  936 	rrc	a
      003FB9 A2 E0            [12]  937 	mov	c,acc.0
      003FBB CE               [12]  938 	xch	a,r6
      003FBC 13               [12]  939 	rrc	a
      003FBD CE               [12]  940 	xch	a,r6
      003FBE 13               [12]  941 	rrc	a
      003FBF CE               [12]  942 	xch	a,r6
      003FC0 24 C7            [12]  943 	add	a,#0xc7
      003FC2 FF               [12]  944 	mov	r7,a
      003FC3 12 39 08         [24]  945 	lcall	_ak820_outline_0123
      003FC6 12 3C D4         [24]  946 	lcall	_write_page
      003FC9 E5 82            [12]  947 	mov	a, dpl
      003FCB 60 13            [24]  948 	jz	00127$
                                    949 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003FCD 90 05 77         [24]  950 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FD0 74 0D            [12]  951 	mov	a,#0x0d
      003FD2 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003FD3 90 EF 40         [24]  954 	mov	dptr,#0xef40
      003FD6 12 3A 6E         [24]  955 	lcall	_ak820_flash_erase
      003FD9 E5 82            [12]  956 	mov	a, dpl
      003FDB 60 03            [24]  957 	jz	00127$
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    959 ;	assignBit
      003FDD C2 0A            [12]  960 	clr	_page_dirty
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003FDF 22               [24]  963 	ret
      003FE0                        964 00127$:
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FE0 90 05 77         [24]  966 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FE3 E0               [24]  967 	movx	a,@dptr
      003FE4 F5 82            [12]  968 	mov	dpl,a
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FE6 02 3B F5         [24]  970 	ljmp	_nvm_fail
                                    971 ;------------------------------------------------------------
                                    972 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    973 ;------------------------------------------------------------
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    975 ;	-----------------------------------------
                                    976 ;	 function ak820_nvm_begin
                                    977 ;	-----------------------------------------
      003FE9                        978 _ak820_nvm_begin:
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FE9 90 05 57         [24]  980 	mov	dptr,#_batch_depth
      003FEC E0               [24]  981 	movx	a,@dptr
      003FED FF               [12]  982 	mov	r7,a
      003FEE BF FF 06         [24]  983 	cjne	r7,#0xff,00102$
      003FF1 75 82 0F         [24]  984 	mov	dpl, #0x0f
      003FF4 02 3B F5         [24]  985 	ljmp	_nvm_fail
      003FF7                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FF7 90 05 57         [24]  988 	mov	dptr,#_batch_depth
      003FFA EF               [12]  989 	mov	a,r7
      003FFB 04               [12]  990 	inc	a
      003FFC F0               [24]  991 	movx	@dptr,a
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FFD 22               [24]  993 	ret
                                    994 ;------------------------------------------------------------
                                    995 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    996 ;------------------------------------------------------------
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                    998 ;	-----------------------------------------
                                    999 ;	 function ak820_nvm_end
                                   1000 ;	-----------------------------------------
      003FFE                       1001 _ak820_nvm_end:
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FFE 90 05 57         [24] 1003 	mov	dptr,#_batch_depth
      004001 E0               [24] 1004 	movx	a,@dptr
      004002 FF               [12] 1005 	mov	r7,a
      004003 E0               [24] 1006 	movx	a,@dptr
      004004 60 06            [24] 1007 	jz	00102$
      004006 EF               [12] 1008 	mov	a,r7
      004007 14               [12] 1009 	dec	a
      004008 90 05 57         [24] 1010 	mov	dptr,#_batch_depth
      00400B F0               [24] 1011 	movx	@dptr,a
      00400C                       1012 00102$:
                                   1013 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00400C 90 05 57         [24] 1014 	mov	dptr,#_batch_depth
      00400F E0               [24] 1015 	movx	a,@dptr
      004010 70 03            [24] 1016 	jnz	00105$
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004012 02 3E 96         [24] 1018 	ljmp	_ak820_nvm_flush
      004015                       1019 00105$:
      004015 22               [24] 1020 	ret
                                   1021 ;------------------------------------------------------------
                                   1022 ;Allocation info for local variables in function 'load_page'
                                   1023 ;------------------------------------------------------------
                                   1024 ;page          Allocated with name '_load_page_page_10000_87'
                                   1025 ;i             Allocated with name '_load_page_i_10000_88'
                                   1026 ;------------------------------------------------------------
                                   1027 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1028 ;	-----------------------------------------
                                   1029 ;	 function load_page
                                   1030 ;	-----------------------------------------
      004016                       1031 _load_page:
      004016 E5 82            [12] 1032 	mov	a,dpl
      004018 90 05 78         [24] 1033 	mov	dptr,#_load_page_page_10000_87
      00401B F0               [24] 1034 	movx	@dptr,a
                                   1035 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      00401C 30 09 17         [24] 1036 	jnb	_page_valid,00102$
      00401F 90 05 56         [24] 1037 	mov	dptr,#_cached_page
      004022 E0               [24] 1038 	movx	a,@dptr
      004023 FF               [12] 1039 	mov	r7,a
      004024 90 05 78         [24] 1040 	mov	dptr,#_load_page_page_10000_87
      004027 E0               [24] 1041 	movx	a,@dptr
      004028 FE               [12] 1042 	mov	r6,a
      004029 EF               [12] 1043 	mov	a,r7
      00402A B5 06 09         [24] 1044 	cjne	a,ar6,00102$
      00402D A2 0B            [12] 1045 	mov	c,_storage_failed
      00402F B3               [12] 1046 	cpl	c
      004030 92 0D            [24] 1047 	mov  _load_page_sloc0_1_0,c
      004032 12 39 33         [24] 1048 	lcall	_ak820_outline_0163
      004035 22               [24] 1049 	ret
      004036                       1050 00102$:
                                   1051 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004036 12 3E 96         [24] 1052 	lcall	_ak820_nvm_flush
                                   1053 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004039 30 0B 04         [24] 1054 	jnb	_storage_failed,00119$
      00403C 75 82 00         [24] 1055 	mov	dpl, #0x00
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00403F 22               [24] 1057 	ret
      004040                       1058 00119$:
      004040 7F 00            [12] 1059 	mov	r7,#0x00
      004042                       1060 00107$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004042 EF               [12] 1062 	mov	a,r7
      004043 24 16            [12] 1063 	add	a, #_page_data
      004045 FD               [12] 1064 	mov	r5,a
      004046 E4               [12] 1065 	clr	a
      004047 34 05            [12] 1066 	addc	a, #(_page_data >> 8)
      004049 FE               [12] 1067 	mov	r6,a
      00404A 90 05 78         [24] 1068 	mov	dptr,#_load_page_page_10000_87
      00404D E0               [24] 1069 	movx	a,@dptr
      00404E FC               [12] 1070 	mov	r4,a
      00404F FA               [12] 1071 	mov	r2,a
      004050 E4               [12] 1072 	clr	a
      004051 C3               [12] 1073 	clr	c
      004052 CA               [12] 1074 	xch	a,r2
      004053 13               [12] 1075 	rrc	a
      004054 CA               [12] 1076 	xch	a,r2
      004055 13               [12] 1077 	rrc	a
      004056 A2 E0            [12] 1078 	mov	c,acc.0
      004058 CA               [12] 1079 	xch	a,r2
      004059 13               [12] 1080 	rrc	a
      00405A CA               [12] 1081 	xch	a,r2
      00405B 13               [12] 1082 	rrc	a
      00405C CA               [12] 1083 	xch	a,r2
      00405D 24 C7            [12] 1084 	add	a,#0xc7
      00405F FB               [12] 1085 	mov	r3,a
      004060 8F 01            [24] 1086 	mov	ar1,r7
      004062 89 00            [24] 1087 	mov	ar0,r1
      004064 79 00            [12] 1088 	mov	r1,#0x00
      004066 E8               [12] 1089 	mov	a,r0
      004067 2A               [12] 1090 	add	a, r2
      004068 FA               [12] 1091 	mov	r2,a
      004069 E9               [12] 1092 	mov	a,r1
      00406A 3B               [12] 1093 	addc	a, r3
      00406B FB               [12] 1094 	mov	r3,a
      00406C 12 39 12         [24] 1095 	lcall	_ak820_outline_0140
      00406F 12 39 61         [24] 1096 	lcall	_ak820_flash_read
      004072 AB 82            [24] 1097 	mov	r3, dpl
      004074 12 39 17         [24] 1098 	lcall	_ak820_outline_0141
      004077 EB               [12] 1099 	mov	a,r3
      004078 F0               [24] 1100 	movx	@dptr,a
                                   1101 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004079 0F               [12] 1102 	inc	r7
      00407A BF 40 C5         [24] 1103 	cjne	r7,#0x40,00107$
                                   1104 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00407D 90 05 56         [24] 1105 	mov	dptr,#_cached_page
      004080 EC               [12] 1106 	mov	a,r4
      004081 F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1109 ;	assignBit
      004082 D2 09            [12] 1110 	setb	_page_valid
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004084 75 82 01         [24] 1112 	mov	dpl, #0x01
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004087 22               [24] 1114 	ret
                                   1115 ;------------------------------------------------------------
                                   1116 ;Allocation info for local variables in function 'read_offset'
                                   1117 ;------------------------------------------------------------
                                   1118 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1119 ;------------------------------------------------------------
                                   1120 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1121 ;	-----------------------------------------
                                   1122 ;	 function read_offset
                                   1123 ;	-----------------------------------------
      004088                       1124 _read_offset:
      004088 12 39 03         [24] 1125 	lcall	_ak820_outline_0122
      00408B 90 05 79         [24] 1126 	mov	dptr,#_read_offset_offset_10000_93
      00408E 12 38 FE         [24] 1127 	lcall	_ak820_outline_0121
                                   1128 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004091 90 05 79         [24] 1129 	mov	dptr,#_read_offset_offset_10000_93
      004094 12 38 C3         [24] 1130 	lcall	_ak820_outline_0060
      004097 C3               [12] 1131 	clr	c
      004098 94 28            [12] 1132 	subb	a,#0x28
      00409A 40 04            [24] 1133 	jc	00102$
      00409C 75 82 00         [24] 1134 	mov	dpl, #0x00
      00409F 22               [24] 1135 	ret
      0040A0                       1136 00102$:
                                   1137 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0040A0 30 09 34         [24] 1138 	jnb	_page_valid,00104$
      0040A3 8E 04            [24] 1139 	mov	ar4,r6
      0040A5 EF               [12] 1140 	mov	a,r7
      0040A6 A2 E7            [12] 1141 	mov	c,acc.7
      0040A8 CC               [12] 1142 	xch	a,r4
      0040A9 33               [12] 1143 	rlc	a
      0040AA CC               [12] 1144 	xch	a,r4
      0040AB 33               [12] 1145 	rlc	a
      0040AC A2 E7            [12] 1146 	mov	c,acc.7
      0040AE CC               [12] 1147 	xch	a,r4
      0040AF 33               [12] 1148 	rlc	a
      0040B0 CC               [12] 1149 	xch	a,r4
      0040B1 33               [12] 1150 	rlc	a
      0040B2 CC               [12] 1151 	xch	a,r4
      0040B3 54 03            [12] 1152 	anl	a,#0x03
      0040B5 FD               [12] 1153 	mov	r5,a
      0040B6 90 05 56         [24] 1154 	mov	dptr,#_cached_page
      0040B9 E0               [24] 1155 	movx	a,@dptr
      0040BA FA               [12] 1156 	mov	r2,a
      0040BB 7B 00            [12] 1157 	mov	r3,#0x00
      0040BD EC               [12] 1158 	mov	a,r4
      0040BE B5 02 16         [24] 1159 	cjne	a,ar2,00104$
      0040C1 ED               [12] 1160 	mov	a,r5
      0040C2 B5 03 12         [24] 1161 	cjne	a,ar3,00104$
                                   1162 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0040C5 74 3F            [12] 1163 	mov	a,#0x3f
      0040C7 5E               [12] 1164 	anl	a,r6
      0040C8 7D 00            [12] 1165 	mov	r5,#0x00
      0040CA 24 16            [12] 1166 	add	a, #_page_data
      0040CC F5 82            [12] 1167 	mov	dpl,a
      0040CE ED               [12] 1168 	mov	a,r5
      0040CF 34 05            [12] 1169 	addc	a, #(_page_data >> 8)
      0040D1 F5 83            [12] 1170 	mov	dph,a
      0040D3 E0               [24] 1171 	movx	a,@dptr
      0040D4 F5 82            [12] 1172 	mov	dpl,a
      0040D6 22               [24] 1173 	ret
      0040D7                       1174 00104$:
                                   1175 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0040D7 74 C7            [12] 1176 	mov	a,#0xc7
      0040D9 2F               [12] 1177 	add	a, r7
      0040DA FF               [12] 1178 	mov	r7,a
      0040DB 12 39 08         [24] 1179 	lcall	_ak820_outline_0123
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0040DE 02 39 61         [24] 1181 	ljmp	_ak820_flash_read
                                   1182 ;------------------------------------------------------------
                                   1183 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1184 ;------------------------------------------------------------
                                   1185 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function eeprom_read_byte
                                   1190 ;	-----------------------------------------
      0040E1                       1191 _eeprom_read_byte:
      0040E1 C0 07            [24] 1192 	push	ar7
      0040E3 C0 06            [24] 1193 	push	ar6
      0040E5 12 43 80         [24] 1194 	lcall	_ak820_outline_0036
      0040E8 90 05 7B         [24] 1195 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040EB 12 38 8B         [24] 1196 	lcall	_ak820_outline_0017
                                   1197 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040EE 90 05 7B         [24] 1198 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040F1 12 38 81         [24] 1199 	lcall	_ak820_outline_0010
      0040F4 C0 06            [24] 1200 	push	ar6
      0040F6 C0 05            [24] 1201 	push	ar5
      0040F8 C0 04            [24] 1202 	push	ar4
      0040FA C0 03            [24] 1203 	push	ar3
      0040FC C0 02            [24] 1204 	push	ar2
      0040FE C0 01            [24] 1205 	push	ar1
      004100 C0 00            [24] 1206 	push	ar0
      004102 12 40 88         [24] 1207 	lcall	_read_offset
      004105 AF 82            [24] 1208 	mov	r7, dpl
      004107 D0 00            [24] 1209 	pop	ar0
      004109 D0 01            [24] 1210 	pop	ar1
      00410B D0 02            [24] 1211 	pop	ar2
      00410D D0 03            [24] 1212 	pop	ar3
      00410F D0 04            [24] 1213 	pop	ar4
      004111 D0 05            [24] 1214 	pop	ar5
      004113 D0 06            [24] 1215 	pop	ar6
      004115 8F 82            [24] 1216 	mov	dpl, r7
                                   1217 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004117 D0 06            [24] 1218 	pop	ar6
      004119 D0 07            [24] 1219 	pop	ar7
      00411B 22               [24] 1220 	ret
                                   1221 ;------------------------------------------------------------
                                   1222 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1223 ;------------------------------------------------------------
                                   1224 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1225 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1226 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1227 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1228 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function ak820_eeprom_read_block_xdata
                                   1233 ;	-----------------------------------------
      00411C                       1234 _ak820_eeprom_read_block_xdata:
      00411C 12 39 03         [24] 1235 	lcall	_ak820_outline_0122
      00411F 90 05 83         [24] 1236 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004122 12 38 FE         [24] 1237 	lcall	_ak820_outline_0121
                                   1238 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004125 90 05 7E         [24] 1239 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004128 12 38 C3         [24] 1240 	lcall	_ak820_outline_0060
                                   1241 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00412B 90 05 83         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00412E 12 38 DA         [24] 1243 	lcall	_ak820_outline_0076
      004131 90 05 85         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004134 12 38 E6         [24] 1245 	lcall	_ak820_outline_0087
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004137 90 05 81         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00413A 12 38 DA         [24] 1248 	lcall	_ak820_outline_0076
      00413D                       1249 00103$:
      00413D 8C 02            [24] 1250 	mov	ar2,r4
      00413F 8D 03            [24] 1251 	mov	ar3,r5
      004141 1C               [12] 1252 	dec	r4
      004142 BC FF 01         [24] 1253 	cjne	r4,#0xff,00130$
      004145 1D               [12] 1254 	dec	r5
      004146                       1255 00130$:
      004146 EA               [12] 1256 	mov	a,r2
      004147 4B               [12] 1257 	orl	a,r3
      004148 60 5D            [24] 1258 	jz	00106$
                                   1259 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00414A 8E 02            [24] 1260 	mov	ar2,r6
      00414C 8F 03            [24] 1261 	mov	ar3,r7
      00414E 74 D8            [12] 1262 	mov	a,#0x100 - 0x28
      004150 2B               [12] 1263 	add	a,r3
      004151 50 17            [24] 1264 	jnc	00102$
      004153 90 05 85         [24] 1265 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004156 12 43 B7         [24] 1266 	lcall	_ak820_outline_0110
      004159 12 39 12         [24] 1267 	lcall	_ak820_outline_0140
      00415C E4               [12] 1268 	clr	a
      00415D F0               [24] 1269 	movx	@dptr,a
      00415E 90 05 85         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004161 04               [12] 1271 	inc	a
      004162 2A               [12] 1272 	add	a, r2
      004163 F0               [24] 1273 	movx	@dptr,a
      004164 E4               [12] 1274 	clr	a
      004165 3B               [12] 1275 	addc	a, r3
      004166 A3               [24] 1276 	inc	dptr
      004167 F0               [24] 1277 	movx	@dptr,a
      004168 80 D3            [24] 1278 	sjmp	00103$
      00416A                       1279 00102$:
                                   1280 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00416A 90 05 85         [24] 1281 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00416D 12 43 B7         [24] 1282 	lcall	_ak820_outline_0110
      004170 12 39 08         [24] 1283 	lcall	_ak820_outline_0123
      004173 C0 07            [24] 1284 	push	ar7
      004175 C0 06            [24] 1285 	push	ar6
      004177 C0 05            [24] 1286 	push	ar5
      004179 C0 04            [24] 1287 	push	ar4
      00417B C0 03            [24] 1288 	push	ar3
      00417D C0 02            [24] 1289 	push	ar2
      00417F 12 40 88         [24] 1290 	lcall	_read_offset
      004182 A9 82            [24] 1291 	mov	r1, dpl
      004184 D0 02            [24] 1292 	pop	ar2
      004186 D0 03            [24] 1293 	pop	ar3
      004188 D0 04            [24] 1294 	pop	ar4
      00418A D0 05            [24] 1295 	pop	ar5
      00418C D0 06            [24] 1296 	pop	ar6
      00418E D0 07            [24] 1297 	pop	ar7
      004190 12 39 12         [24] 1298 	lcall	_ak820_outline_0140
      004193 E9               [12] 1299 	mov	a,r1
      004194 F0               [24] 1300 	movx	@dptr,a
      004195 90 05 85         [24] 1301 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004198 74 01            [12] 1302 	mov	a,#0x01
      00419A 2A               [12] 1303 	add	a, r2
      00419B F0               [24] 1304 	movx	@dptr,a
      00419C E4               [12] 1305 	clr	a
      00419D 3B               [12] 1306 	addc	a, r3
      00419E A3               [24] 1307 	inc	dptr
      00419F F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0041A0 0E               [12] 1310 	inc	r6
      0041A1 BE 00 99         [24] 1311 	cjne	r6,#0x00,00103$
      0041A4 0F               [12] 1312 	inc	r7
      0041A5 80 96            [24] 1313 	sjmp	00103$
      0041A7                       1314 00106$:
                                   1315 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0041A7 22               [24] 1316 	ret
                                   1317 ;------------------------------------------------------------
                                   1318 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1319 ;------------------------------------------------------------
                                   1320 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1321 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1322 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1323 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1324 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1325 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1326 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1327 ;------------------------------------------------------------
                                   1328 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1329 ;	-----------------------------------------
                                   1330 ;	 function ak820_eeprom_write_block_xdata
                                   1331 ;	-----------------------------------------
      0041A8                       1332 _ak820_eeprom_write_block_xdata:
      0041A8 12 39 03         [24] 1333 	lcall	_ak820_outline_0122
      0041AB 90 05 8C         [24] 1334 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041AE 12 38 FE         [24] 1335 	lcall	_ak820_outline_0121
                                   1336 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041B1 90 05 87         [24] 1337 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0041B4 12 38 C3         [24] 1338 	lcall	_ak820_outline_0060
                                   1339 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0041B7 90 05 8C         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041BA 12 38 DA         [24] 1341 	lcall	_ak820_outline_0076
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0041BD 8E 02            [24] 1343 	mov	ar2,r6
      0041BF 8F 03            [24] 1344 	mov	ar3,r7
      0041C1 C3               [12] 1345 	clr	c
      0041C2 E4               [12] 1346 	clr	a
      0041C3 9A               [12] 1347 	subb	a,r2
      0041C4 74 28            [12] 1348 	mov	a,#0x28
      0041C6 9B               [12] 1349 	subb	a,r3
      0041C7 40 15            [24] 1350 	jc	00101$
                                   1351 ;	free result
      0041C9 E4               [12] 1352 	clr	a
      0041CA C3               [12] 1353 	clr	c
      0041CB 9E               [12] 1354 	subb	a,r6
      0041CC FA               [12] 1355 	mov	r2,a
      0041CD 74 28            [12] 1356 	mov	a,#0x28
      0041CF 9F               [12] 1357 	subb	a,r7
      0041D0 FB               [12] 1358 	mov	r3,a
      0041D1 90 05 8A         [24] 1359 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041D4 12 38 F8         [24] 1360 	lcall	_ak820_outline_0109
      0041D7 C3               [12] 1361 	clr	c
      0041D8 EA               [12] 1362 	mov	a,r2
      0041D9 98               [12] 1363 	subb	a,r0
      0041DA EB               [12] 1364 	mov	a,r3
      0041DB 99               [12] 1365 	subb	a,r1
      0041DC 50 06            [24] 1366 	jnc	00125$
                                   1367 ;	free result
      0041DE                       1368 00101$:
                                   1369 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0041DE 75 82 0E         [24] 1370 	mov	dpl, #0x0e
                                   1371 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041E1 02 3B F5         [24] 1372 	ljmp	_nvm_fail
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041E4                       1374 00125$:
      0041E4 90 05 8A         [24] 1375 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041E7 12 43 B7         [24] 1376 	lcall	_ak820_outline_0110
      0041EA                       1377 00108$:
      0041EA 8A 00            [24] 1378 	mov	ar0,r2
      0041EC 8B 01            [24] 1379 	mov	ar1,r3
      0041EE 1A               [12] 1380 	dec	r2
      0041EF BA FF 01         [24] 1381 	cjne	r2,#0xff,00159$
      0041F2 1B               [12] 1382 	dec	r3
      0041F3                       1383 00159$:
      0041F3 E8               [12] 1384 	mov	a,r0
      0041F4 49               [12] 1385 	orl	a,r1
      0041F5 70 03            [24] 1386 	jnz	00160$
      0041F7 02 42 81         [24] 1387 	ljmp	00110$
      0041FA                       1388 00160$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041FA C0 02            [24] 1390 	push	ar2
      0041FC C0 03            [24] 1391 	push	ar3
      0041FE 12 43 B1         [24] 1392 	lcall	_ak820_outline_0104
      004201 F9               [12] 1393 	mov	r1,a
      004202 A3               [24] 1394 	inc	dptr
      004203 12 43 F4         [24] 1395 	lcall	_ak820_outline_0193
                                   1396 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004206 8E 0C            [24] 1397 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004208 8F 0D            [24] 1398 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00420A A8 0C            [24] 1399 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00420C E5 0D            [12] 1400 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00420E A2 E7            [12] 1401 	mov	c,acc.7
      004210 C8               [12] 1402 	xch	a,r0
      004211 33               [12] 1403 	rlc	a
      004212 C8               [12] 1404 	xch	a,r0
      004213 33               [12] 1405 	rlc	a
      004214 A2 E7            [12] 1406 	mov	c,acc.7
      004216 C8               [12] 1407 	xch	a,r0
      004217 33               [12] 1408 	rlc	a
      004218 C8               [12] 1409 	xch	a,r0
      004219 33               [12] 1410 	rlc	a
      00421A C8               [12] 1411 	xch	a,r0
      00421B 54 03            [12] 1412 	anl	a,#0x03
      00421D FB               [12] 1413 	mov	r3,a
      00421E 88 82            [24] 1414 	mov	dpl, r0
      004220 C0 07            [24] 1415 	push	ar7
      004222 C0 06            [24] 1416 	push	ar6
      004224 C0 05            [24] 1417 	push	ar5
      004226 C0 04            [24] 1418 	push	ar4
      004228 C0 03            [24] 1419 	push	ar3
      00422A C0 02            [24] 1420 	push	ar2
      00422C C0 01            [24] 1421 	push	ar1
      00422E 12 40 16         [24] 1422 	lcall	_load_page
      004231 E5 82            [12] 1423 	mov	a, dpl
      004233 D0 01            [24] 1424 	pop	ar1
      004235 D0 02            [24] 1425 	pop	ar2
      004237 D0 03            [24] 1426 	pop	ar3
      004239 D0 04            [24] 1427 	pop	ar4
      00423B D0 05            [24] 1428 	pop	ar5
      00423D D0 06            [24] 1429 	pop	ar6
      00423F D0 07            [24] 1430 	pop	ar7
      004241 D0 03            [24] 1431 	pop	ar3
      004243 D0 02            [24] 1432 	pop	ar2
      004245 70 01            [24] 1433 	jnz	00105$
      004247 22               [24] 1434 	ret
      004248                       1435 00105$:
                                   1436 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004248 C0 06            [24] 1437 	push	ar6
      00424A C0 07            [24] 1438 	push	ar7
      00424C 74 3F            [12] 1439 	mov	a,#0x3f
      00424E 55 0C            [12] 1440 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004250 7F 00            [12] 1441 	mov	r7,#0x00
      004252 24 16            [12] 1442 	add	a, #_page_data
      004254 F5 0C            [12] 1443 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004256 EF               [12] 1444 	mov	a,r7
      004257 34 05            [12] 1445 	addc	a, #(_page_data >> 8)
      004259 F5 0D            [12] 1446 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00425B 85 0C 82         [24] 1447 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00425E 85 0D 83         [24] 1448 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004261 E0               [24] 1449 	movx	a,@dptr
      004262 B5 01 06         [24] 1450 	cjne	a,ar1,00162$
      004265 D0 07            [24] 1451 	pop	ar7
      004267 D0 06            [24] 1452 	pop	ar6
      004269 80 0E            [24] 1453 	sjmp	00107$
      00426B                       1454 00162$:
      00426B D0 07            [24] 1455 	pop	ar7
      00426D D0 06            [24] 1456 	pop	ar6
                                   1457 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00426F 85 0C 82         [24] 1458 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004272 85 0D 83         [24] 1459 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004275 E9               [12] 1460 	mov	a,r1
      004276 F0               [24] 1461 	movx	@dptr,a
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1463 ;	assignBit
      004277 D2 0A            [12] 1464 	setb	_page_dirty
      004279                       1465 00107$:
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004279 0E               [12] 1467 	inc	r6
      00427A BE 00 01         [24] 1468 	cjne	r6,#0x00,00163$
      00427D 0F               [12] 1469 	inc	r7
      00427E                       1470 00163$:
      00427E 02 41 EA         [24] 1471 	ljmp	00108$
      004281                       1472 00110$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004281 90 05 57         [24] 1474 	mov	dptr,#_batch_depth
      004284 E0               [24] 1475 	movx	a,@dptr
      004285 70 03            [24] 1476 	jnz	00113$
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004287 02 3E 96         [24] 1478 	ljmp	_ak820_nvm_flush
      00428A                       1479 00113$:
      00428A 22               [24] 1480 	ret
                                   1481 ;------------------------------------------------------------
                                   1482 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1483 ;------------------------------------------------------------
                                   1484 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1485 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1486 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1487 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1488 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1489 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1490 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1491 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1492 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1493 ;------------------------------------------------------------
                                   1494 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1495 ;	-----------------------------------------
                                   1496 ;	 function ak820_eeprom_update_block_xdata
                                   1497 ;	-----------------------------------------
      00428B                       1498 _ak820_eeprom_update_block_xdata:
      00428B 12 39 03         [24] 1499 	lcall	_ak820_outline_0122
      00428E 90 05 93         [24] 1500 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004291 12 38 FE         [24] 1501 	lcall	_ak820_outline_0121
                                   1502 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004294 90 05 93         [24] 1503 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004297 12 38 C3         [24] 1504 	lcall	_ak820_outline_0060
                                   1505 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00429A 90 05 8E         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00429D E0               [24] 1507 	movx	a,@dptr
      00429E F5 12            [12] 1508 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0042A0 A3               [24] 1509 	inc	dptr
      0042A1 E0               [24] 1510 	movx	a,@dptr
      0042A2 F5 13            [12] 1511 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0042A4 A3               [24] 1512 	inc	dptr
      0042A5 E0               [24] 1513 	movx	a,@dptr
      0042A6 F5 14            [12] 1514 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0042A8 A9 12            [24] 1515 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042AA AA 13            [24] 1516 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1517 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042AC E4               [12] 1518 	clr	a
      0042AD F5 0E            [12] 1519 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0042AF F5 0F            [12] 1520 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0042B1                       1521 00105$:
      0042B1 90 05 91         [24] 1522 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0042B4 E0               [24] 1523 	movx	a,@dptr
      0042B5 F5 10            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0042B7 A3               [24] 1525 	inc	dptr
      0042B8 E0               [24] 1526 	movx	a,@dptr
      0042B9 F5 11            [12] 1527 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0042BB C3               [12] 1528 	clr	c
      0042BC E5 0E            [12] 1529 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042BE 95 10            [12] 1530 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042C0 E5 0F            [12] 1531 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042C2 95 11            [12] 1532 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042C4 50 68            [24] 1533 	jnc	00107$
                                   1534 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0042C6 89 00            [24] 1535 	mov	ar0,r1
      0042C8 8A 05            [24] 1536 	mov	ar5,r2
      0042CA E5 0E            [12] 1537 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042CC 28               [12] 1538 	add	a, r0
      0042CD F8               [12] 1539 	mov	r0,a
      0042CE E5 0F            [12] 1540 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042D0 3D               [12] 1541 	addc	a, r5
      0042D1 FD               [12] 1542 	mov	r5,a
      0042D2 88 82            [24] 1543 	mov	dpl, r0
      0042D4 8D 83            [24] 1544 	mov	dph, r5
      0042D6 C0 07            [24] 1545 	push	ar7
      0042D8 C0 06            [24] 1546 	push	ar6
      0042DA C0 02            [24] 1547 	push	ar2
      0042DC C0 01            [24] 1548 	push	ar1
      0042DE 12 40 88         [24] 1549 	lcall	_read_offset
      0042E1 AD 82            [24] 1550 	mov	r5, dpl
      0042E3 D0 01            [24] 1551 	pop	ar1
      0042E5 D0 02            [24] 1552 	pop	ar2
      0042E7 D0 06            [24] 1553 	pop	ar6
      0042E9 D0 07            [24] 1554 	pop	ar7
      0042EB E5 0E            [12] 1555 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042ED 2E               [12] 1556 	add	a, r6
      0042EE F5 82            [12] 1557 	mov	dpl,a
      0042F0 E5 0F            [12] 1558 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042F2 3F               [12] 1559 	addc	a, r7
      0042F3 F5 83            [12] 1560 	mov	dph,a
      0042F5 E0               [24] 1561 	movx	a,@dptr
      0042F6 FC               [12] 1562 	mov	r4,a
      0042F7 ED               [12] 1563 	mov	a,r5
      0042F8 B5 04 02         [24] 1564 	cjne	a,ar4,00131$
      0042FB 80 27            [24] 1565 	sjmp	00106$
      0042FD                       1566 00131$:
                                   1567 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042FD 90 05 93         [24] 1568 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004300 E0               [24] 1569 	movx	a,@dptr
      004301 F8               [12] 1570 	mov	r0,a
      004302 A3               [24] 1571 	inc	dptr
      004303 E0               [24] 1572 	movx	a,@dptr
      004304 FD               [12] 1573 	mov	r5,a
      004305 90 05 87         [24] 1574 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004308 E5 12            [12] 1575 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00430A F0               [24] 1576 	movx	@dptr,a
      00430B E5 13            [12] 1577 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00430D A3               [24] 1578 	inc	dptr
      00430E F0               [24] 1579 	movx	@dptr,a
      00430F E5 14            [12] 1580 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004311 A3               [24] 1581 	inc	dptr
      004312 F0               [24] 1582 	movx	@dptr,a
      004313 90 05 8A         [24] 1583 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004316 E5 10            [12] 1584 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004318 F0               [24] 1585 	movx	@dptr,a
      004319 E5 11            [12] 1586 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00431B A3               [24] 1587 	inc	dptr
      00431C F0               [24] 1588 	movx	@dptr,a
      00431D 88 82            [24] 1589 	mov	dpl, r0
      00431F 8D 83            [24] 1590 	mov	dph, r5
                                   1591 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004321 02 41 A8         [24] 1592 	ljmp	_ak820_eeprom_write_block_xdata
      004324                       1593 00106$:
                                   1594 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004324 05 0E            [12] 1595 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004326 E4               [12] 1596 	clr	a
      004327 B5 0E 87         [24] 1597 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00432A 05 0F            [12] 1598 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00432C 80 83            [24] 1599 	sjmp	00105$
      00432E                       1600 00107$:
                                   1601 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00432E 22               [24] 1602 	ret
                                   1603 ;------------------------------------------------------------
                                   1604 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1605 ;------------------------------------------------------------
                                   1606 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1607 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1608 ;------------------------------------------------------------
                                   1609 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1610 ;	-----------------------------------------
                                   1611 ;	 function eeprom_driver_erase
                                   1612 ;	-----------------------------------------
      00432F                       1613 _eeprom_driver_erase:
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00432F 12 3E 96         [24] 1615 	lcall	_ak820_nvm_flush
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004332 7F 00            [12] 1617 	mov	r7,#0x00
      004334                       1618 00111$:
      004334 BF A0 01         [24] 1619 	cjne	r7,#0xa0,00165$
      004337 22               [24] 1620 	ret
      004338                       1621 00165$:
      004338 20 0B 32         [24] 1622 	jb	_storage_failed,00113$
                                   1623 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00433B 8F 82            [24] 1624 	mov	dpl, r7
      00433D C0 07            [24] 1625 	push	ar7
      00433F 12 40 16         [24] 1626 	lcall	_load_page
      004342 E5 82            [12] 1627 	mov	a, dpl
      004344 D0 07            [24] 1628 	pop	ar7
      004346 70 01            [24] 1629 	jnz	00126$
                                   1630 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004348 22               [24] 1631 	ret
      004349                       1632 00126$:
      004349 7E 00            [12] 1633 	mov	r6,#0x00
      00434B                       1634 00107$:
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00434B EE               [12] 1636 	mov	a,r6
      00434C 24 16            [12] 1637 	add	a, #_page_data
      00434E FC               [12] 1638 	mov	r4,a
      00434F E4               [12] 1639 	clr	a
      004350 34 05            [12] 1640 	addc	a, #(_page_data >> 8)
      004352 FD               [12] 1641 	mov	r5,a
      004353 12 43 B1         [24] 1642 	lcall	_ak820_outline_0104
      004356 60 07            [24] 1643 	jz	00108$
      004358 12 34 76         [24] 1644 	lcall	_ak820_outline_0132
      00435B E4               [12] 1645 	clr	a
      00435C F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	assignBit
      00435D D2 0A            [12] 1648 	setb	_page_dirty
      00435F                       1649 00108$:
                                   1650 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00435F 0E               [12] 1651 	inc	r6
      004360 BE 40 E8         [24] 1652 	cjne	r6,#0x40,00107$
                                   1653 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004363 C0 07            [24] 1654 	push	ar7
      004365 12 3E 96         [24] 1655 	lcall	_ak820_nvm_flush
      004368 D0 07            [24] 1656 	pop	ar7
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00436A 0F               [12] 1658 	inc	r7
      00436B 80 C7            [24] 1659 	sjmp	00111$
      00436D                       1660 00113$:
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00436D 22               [24] 1662 	ret
                                   1663 	.area CSEG    (CODE)
                                   1664 	.area CONST   (CODE)
                                   1665 	.area XINIT   (CODE)
                                   1666 	.area CABS    (ABS,CODE)
                                   1667 
                                   1668 ; Experimental exact instruction outlining.
                                   1669 	.globl _ak820_outline_0010
                                   1670 	.globl _ak820_outline_0016
                                   1671 	.globl _ak820_outline_0017
                                   1672 	.globl _ak820_outline_0023
                                   1673 	.globl _ak820_outline_0034
                                   1674 	.globl _ak820_outline_0036
                                   1675 	.globl _ak820_outline_0047
                                   1676 	.globl _ak820_outline_0060
                                   1677 	.globl _ak820_outline_0061
                                   1678 	.globl _ak820_outline_0074
                                   1679 	.globl _ak820_outline_0076
                                   1680 	.globl _ak820_outline_0087
                                   1681 	.globl _ak820_outline_0088
                                   1682 	.globl _ak820_outline_0089
                                   1683 	.globl _ak820_outline_0103
                                   1684 	.globl _ak820_outline_0104
                                   1685 	.globl _ak820_outline_0109
                                   1686 	.globl _ak820_outline_0110
                                   1687 	.globl _ak820_outline_0112
                                   1688 	.globl _ak820_outline_0121
                                   1689 	.globl _ak820_outline_0122
                                   1690 	.globl _ak820_outline_0123
                                   1691 	.globl _ak820_outline_0126
                                   1692 	.globl _ak820_outline_0127
                                   1693 	.globl _ak820_outline_0129
                                   1694 	.globl _ak820_outline_0131
                                   1695 	.globl _ak820_outline_0132
                                   1696 	.globl _ak820_outline_0140
                                   1697 	.globl _ak820_outline_0141
                                   1698 	.globl _ak820_outline_0144
                                   1699 	.globl _ak820_outline_0147
                                   1700 	.globl _ak820_outline_0163
                                   1701 	.globl _ak820_outline_0164
                                   1702 	.globl _ak820_outline_0166
                                   1703 	.globl _ak820_outline_0190
                                   1704 	.globl _ak820_outline_0193
                                   1705 	.globl _ak820_outline_0197
                                   1706 
                                   1707 	.area CSEG (CODE)
                                   1708 ; function ak820_outline_0016
      00436E                       1709 _ak820_outline_0016:
      00436E 8E 82            [24] 1710 	mov	dpl,r6
      004370 8F 83            [24] 1711 	mov	dph,r7
      004372 A3               [24] 1712 	inc	dptr
      004373 A3               [24] 1713 	inc	dptr
      004374 A3               [24] 1714 	inc	dptr
      004375 A3               [24] 1715 	inc	dptr
      004376 A3               [24] 1716 	inc	dptr
      004377 22               [24] 1717 	ret
                                   1718 
                                   1719 	.area CSEG (CODE)
                                   1720 ; function ak820_outline_0034
      004378                       1721 _ak820_outline_0034:
      004378 F0               [24] 1722 	movx	@dptr,a
      004379 8E 82            [24] 1723 	mov	dpl,r6
      00437B 8F 83            [24] 1724 	mov	dph,r7
      00437D A3               [24] 1725 	inc	dptr
      00437E A3               [24] 1726 	inc	dptr
      00437F 22               [24] 1727 	ret
                                   1728 
                                   1729 	.area CSEG (CODE)
                                   1730 ; function ak820_outline_0036
      004380                       1731 _ak820_outline_0036:
      004380 AF F0            [24] 1732 	mov	r7,b
      004382 AE 83            [24] 1733 	mov	r6,dph
      004384 E5 82            [12] 1734 	mov	a,dpl
      004386 22               [24] 1735 	ret
                                   1736 
                                   1737 	.area CSEG (CODE)
                                   1738 ; function ak820_outline_0047
      004387                       1739 _ak820_outline_0047:
      004387 EF               [12] 1740 	mov	a,r7
      004388 24 6E            [12] 1741 	add	a,#_ak820_nvm_flush_header_10000_62
      00438A F5 82            [12] 1742 	mov	dpl,a
      00438C E4               [12] 1743 	clr	a
      00438D 34 05            [12] 1744 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00438F F5 83            [12] 1745 	mov	dph,a
      004391 E0               [24] 1746 	movx	a,@dptr
      004392 22               [24] 1747 	ret
                                   1748 
                                   1749 	.area CSEG (CODE)
                                   1750 ; function ak820_outline_0061
      004393                       1751 _ak820_outline_0061:
      004393 8F 06            [24] 1752 	mov	ar6,r7
      004395 7D 00            [12] 1753 	mov	r5,#0x00
      004397 74 40            [12] 1754 	mov	a,#0x40
      004399 2E               [12] 1755 	add	a,r6
      00439A FE               [12] 1756 	mov	r6,a
      00439B 74 EF            [12] 1757 	mov	a,#0xef
      00439D 3D               [12] 1758 	addc	a,r5
      00439E FD               [12] 1759 	mov	r5,a
      00439F 8E 82            [24] 1760 	mov	dpl,r6
      0043A1 8D 83            [24] 1761 	mov	dph,r5
      0043A3 22               [24] 1762 	ret
                                   1763 
                                   1764 	.area CSEG (CODE)
                                   1765 ; function ak820_outline_0074
      0043A4                       1766 _ak820_outline_0074:
      0043A4 8D 82            [24] 1767 	mov	dpl,r5
      0043A6 8E 83            [24] 1768 	mov	dph,r6
      0043A8 EC               [12] 1769 	mov	a,r4
      0043A9 F0               [24] 1770 	movx	@dptr,a
      0043AA 22               [24] 1771 	ret
                                   1772 
                                   1773 	.area CSEG (CODE)
                                   1774 ; function ak820_outline_0088
      0043AB                       1775 _ak820_outline_0088:
      0043AB F0               [24] 1776 	movx	@dptr,a
      0043AC 8E 82            [24] 1777 	mov	dpl,r6
      0043AE 8F 83            [24] 1778 	mov	dph,r7
      0043B0 22               [24] 1779 	ret
                                   1780 
                                   1781 	.area CSEG (CODE)
                                   1782 ; function ak820_outline_0104
      0043B1                       1783 _ak820_outline_0104:
      0043B1 8C 82            [24] 1784 	mov	dpl,r4
      0043B3 8D 83            [24] 1785 	mov	dph,r5
      0043B5 E0               [24] 1786 	movx	a,@dptr
      0043B6 22               [24] 1787 	ret
                                   1788 
                                   1789 	.area CSEG (CODE)
                                   1790 ; function ak820_outline_0110
      0043B7                       1791 _ak820_outline_0110:
      0043B7 E0               [24] 1792 	movx	a,@dptr
      0043B8 FA               [12] 1793 	mov	r2,a
      0043B9 A3               [24] 1794 	inc	dptr
      0043BA E0               [24] 1795 	movx	a,@dptr
      0043BB FB               [12] 1796 	mov	r3,a
      0043BC 22               [24] 1797 	ret
                                   1798 
                                   1799 	.area CSEG (CODE)
                                   1800 ; function ak820_outline_0112
      0043BD                       1801 _ak820_outline_0112:
      0043BD EF               [12] 1802 	mov	a,r7
      0043BE 24 16            [12] 1803 	add	a,#_page_data
      0043C0 F5 82            [12] 1804 	mov	dpl,a
      0043C2 E4               [12] 1805 	clr	a
      0043C3 34 05            [12] 1806 	addc	a,#(_page_data>>8)
      0043C5 F5 83            [12] 1807 	mov	dph,a
      0043C7 E0               [24] 1808 	movx	a,@dptr
      0043C8 22               [24] 1809 	ret
                                   1810 
                                   1811 	.area CSEG (CODE)
                                   1812 ; function ak820_outline_0126
      0043C9                       1813 _ak820_outline_0126:
      0043C9 ED               [12] 1814 	mov	a,r5
      0043CA F0               [24] 1815 	movx	@dptr,a
      0043CB EE               [12] 1816 	mov	a,r6
      0043CC A3               [24] 1817 	inc	dptr
      0043CD F0               [24] 1818 	movx	@dptr,a
      0043CE 22               [24] 1819 	ret
                                   1820 
                                   1821 	.area CSEG (CODE)
                                   1822 ; function ak820_outline_0127
      0043CF                       1823 _ak820_outline_0127:
      0043CF 8C 82            [24] 1824 	mov	dpl,r4
      0043D1 8D 83            [24] 1825 	mov	dph,r5
      0043D3 F0               [24] 1826 	movx	@dptr,a
      0043D4 22               [24] 1827 	ret
                                   1828 
                                   1829 	.area CSEG (CODE)
                                   1830 ; function ak820_outline_0131
      0043D5                       1831 _ak820_outline_0131:
      0043D5 AE 82            [24] 1832 	mov	r6,dpl
      0043D7 AF 83            [24] 1833 	mov	r7,dph
      0043D9 22               [24] 1834 	ret
                                   1835 
                                   1836 	.area CSEG (CODE)
                                   1837 ; function ak820_outline_0144
      0043DA                       1838 _ak820_outline_0144:
      0043DA 2E               [12] 1839 	add	a,r6
      0043DB FE               [12] 1840 	mov	r6,a
      0043DC E4               [12] 1841 	clr	a
      0043DD 3F               [12] 1842 	addc	a,r7
      0043DE FF               [12] 1843 	mov	r7,a
      0043DF 22               [24] 1844 	ret
                                   1845 
                                   1846 	.area CSEG (CODE)
                                   1847 ; function ak820_outline_0164
      0043E0                       1848 _ak820_outline_0164:
      0043E0 8F 82            [24] 1849 	mov	dpl,r7
      0043E2 8E 83            [24] 1850 	mov	dph,r6
      0043E4 22               [24] 1851 	ret
                                   1852 
                                   1853 	.area CSEG (CODE)
                                   1854 ; function ak820_outline_0166
      0043E5                       1855 _ak820_outline_0166:
      0043E5 2E               [12] 1856 	add	a,r6
      0043E6 FC               [12] 1857 	mov	r4,a
      0043E7 E4               [12] 1858 	clr	a
      0043E8 3F               [12] 1859 	addc	a,r7
      0043E9 FD               [12] 1860 	mov	r5,a
      0043EA 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0190
      0043EB                       1865 _ak820_outline_0190:
      0043EB E0               [24] 1866 	movx	a,@dptr
      0043EC FA               [12] 1867 	mov	r2,a
      0043ED E4               [12] 1868 	clr	a
      0043EE 42 05            [12] 1869 	orl	ar5,a
      0043F0 EA               [12] 1870 	mov	a,r2
      0043F1 42 04            [12] 1871 	orl	ar4,a
      0043F3 22               [24] 1872 	ret
                                   1873 
                                   1874 	.area CSEG (CODE)
                                   1875 ; function ak820_outline_0193
      0043F4                       1876 _ak820_outline_0193:
      0043F4 AC 82            [24] 1877 	mov	r4,dpl
      0043F6 AD 83            [24] 1878 	mov	r5,dph
      0043F8 22               [24] 1879 	ret
                                   1880 
                                   1881 	.area CSEG (CODE)
                                   1882 ; function ak820_outline_0197
      0043F9                       1883 _ak820_outline_0197:
      0043F9 8C 82            [24] 1884 	mov	dpl,r4
      0043FB 8B 83            [24] 1885 	mov	dph,r3
      0043FD 22               [24] 1886 	ret
