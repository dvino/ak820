                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_285:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_285:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_285:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_285:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00075E                        602 _D0SetupReqCode::
      00075E                        603 	.ds 1
      00075F                        604 _D0SetupLen::
      00075F                        605 	.ds 2
      000761                        606 _pD0Descr::
      000761                        607 	.ds 3
      000764                        608 _D0UsbConfig::
      000764                        609 	.ds 1
      000765                        610 _USB_EnumStatus::
      000765                        611 	.ds 1
      000766                        612 _USB_SleepStatus::
      000766                        613 	.ds 1
      000767                        614 _MCU_Sleep_Operate::
      000767                        615 	.ds 1
      000768                        616 _KB_USB_UpStatus::
      000768                        617 	.ds 1
      000769                        618 _KB_USB_SetReport::
      000769                        619 	.ds 1
      00076A                        620 _ak820_boot_stage::
      00076A                        621 	.ds 1
      00076B                        622 _ak820_main_heartbeat::
      00076B                        623 	.ds 1
      00076C                        624 _raw_state:
      00076C                        625 	.ds 1
      00076D                        626 _raw_buffer:
      00076D                        627 	.ds 32
      00078D                        628 _raw_reply_without_nvm:
      00078D                        629 	.ds 1
      00078E                        630 _keyboard_reset:
      00078E                        631 	.ds 1
      00078F                        632 _input_snapshot:
      00078F                        633 	.ds 46
      0007BD                        634 _control_phase:
      0007BD                        635 	.ds 1
      0007BE                        636 _output_kind:
      0007BE                        637 	.ds 1
      0007BF                        638 _output_report_id:
      0007BF                        639 	.ds 1
      0007C0                        640 _control_zlp:
      0007C0                        641 	.ds 1
      0007C1                        642 _control_pointer:
      0007C1                        643 	.ds 2
      0007C3                        644 _descriptor_select_PARM_2:
      0007C3                        645 	.ds 1
      0007C4                        646 _descriptor_select_PARM_3:
      0007C4                        647 	.ds 2
      0007C6                        648 _descriptor_select_type_10000_267:
      0007C6                        649 	.ds 1
      0007C7                        650 _control_setup_length_10000_285:
      0007C7                        651 	.ds 2
      0007C9                        652 _control_setup_offset_10000_285:
      0007C9                        653 	.ds 1
      0007CA                        654 _ak820_usb_send_PARM_2:
      0007CA                        655 	.ds 2
      0007CC                        656 _ak820_usb_send_PARM_3:
      0007CC                        657 	.ds 1
      0007CD                        658 _ak820_usb_send_endpoint_10000_421:
      0007CD                        659 	.ds 1
      0007CE                        660 _ak820_usb_send_offset_10000_422:
      0007CE                        661 	.ds 1
      0007CF                        662 _ak820_usb_try_send_PARM_2:
      0007CF                        663 	.ds 2
      0007D1                        664 _ak820_usb_try_send_PARM_3:
      0007D1                        665 	.ds 1
      0007D2                        666 _ak820_usb_try_send_endpoint_10000_442:
      0007D2                        667 	.ds 1
      0007D3                        668 _ak820_usb_try_send_sent_10000_443:
      0007D3                        669 	.ds 1
      0007D4                        670 _ak820_usb_raw_send_PARM_2:
      0007D4                        671 	.ds 1
      0007D5                        672 _ak820_usb_raw_send_report_10000_458:
      0007D5                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005B19                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005B19 90 07 6C         [24]  727 	mov	dptr,#_raw_state
      005B1C E0               [24]  728 	movx	a,@dptr
      005B1D FF               [12]  729 	mov	r7,a
      005B1E BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005B21 80 1C            [24]  731 	sjmp	00101$
      005B23                        732 00130$:
      005B23 90 07 6C         [24]  733 	mov	dptr,#_raw_state
      005B26 E0               [24]  734 	movx	a,@dptr
      005B27 FF               [12]  735 	mov	r7,a
      005B28 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005B2B 80 12            [24]  737 	sjmp	00101$
      005B2D                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005B2D 90 07 6C         [24]  740 	mov	dptr,#_raw_state
      005B30 E0               [24]  741 	movx	a,@dptr
      005B31 FF               [12]  742 	mov	r7,a
      005B32 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005B35 80 08            [24]  744 	sjmp	00101$
      005B37                        745 00132$:
      005B37 90 07 6C         [24]  746 	mov	dptr,#_raw_state
      005B3A E0               [24]  747 	movx	a,@dptr
      005B3B FF               [12]  748 	mov	r7,a
      005B3C BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005B3F                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005B3F 90 07 6C         [24]  752 	mov	dptr,#_raw_state
      005B42 74 07            [12]  753 	mov	a,#0x07
      005B44 F0               [24]  754 	movx	@dptr,a
      005B45 80 05            [24]  755 	sjmp	00103$
      005B47                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005B47 90 07 6C         [24]  758 	mov	dptr,#_raw_state
      005B4A E4               [12]  759 	clr	a
      005B4B F0               [24]  760 	movx	@dptr,a
      005B4C                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005B4C 90 07 BE         [24]  763 	mov	dptr,#_output_kind
      005B4F E4               [12]  764 	clr	a
      005B50 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005B51 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005B52                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005B52 90 07 6C         [24]  777 	mov	dptr,#_raw_state
      005B55 E0               [24]  778 	movx	a,@dptr
      005B56 FF               [12]  779 	mov	r7,a
      005B57 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005B5A 90 07 6C         [24]  781 	mov	dptr,#_raw_state
      005B5D 74 06            [12]  782 	mov	a,#0x06
      005B5F F0               [24]  783 	movx	@dptr,a
      005B60 22               [24]  784 	ret
      005B61                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005B61 90 07 6C         [24]  787 	mov	dptr,#_raw_state
      005B64 E0               [24]  788 	movx	a,@dptr
      005B65 FF               [12]  789 	mov	r7,a
      005B66 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005B69 90 07 6C         [24]  791 	mov	dptr,#_raw_state
      005B6C E4               [12]  792 	clr	a
      005B6D F0               [24]  793 	movx	@dptr,a
      005B6E                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005B6E 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_257'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005B6F                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005B6F 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005B72 74 01            [12]  809 	mov	a,#0x01
      005B74 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005B75 F5 82            [12]  812 	mov	dpl,a
      005B77 74 12            [12]  813 	mov	a,#0x12
      005B79 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005B7A A3               [24]  816 	inc	dptr
      005B7B F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005B7C A3               [24]  819 	inc	dptr
      005B7D F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005B7E 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005B81 E4               [12]  823 	clr	a
      005B82 F0               [24]  824 	movx	@dptr,a
      005B83 15 82            [12]  825 	dec	dpl
      005B85 F0               [24]  826 	movx	@dptr,a
      005B86 15 82            [12]  827 	dec	dpl
      005B88 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005B89 FF               [12]  830 	mov	r7,a
      005B8A                        831 00103$:
      005B8A EF               [12]  832 	mov	a,r7
      005B8B 24 8F            [12]  833 	add	a, #_input_snapshot
      005B8D F5 82            [12]  834 	mov	dpl,a
      005B8F E4               [12]  835 	clr	a
      005B90 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005B92 F5 83            [12]  837 	mov	dph,a
      005B94 E4               [12]  838 	clr	a
      005B95 F0               [24]  839 	movx	@dptr,a
      005B96 0F               [12]  840 	inc	r7
      005B97 BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005B9A                        842 00139$:
      005B9A 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005B9C 90 07 97         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005B9F 74 06            [12]  846 	mov	a,#0x06
      005BA1 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005BA2 90 07 B7         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005BA5 03               [12]  850 	rr	a
      005BA6 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005BA7 90 07 BA         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005BAA 04               [12]  854 	inc	a
      005BAB F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005BAC 7F 00            [12]  857 	mov	r7,#0x00
      005BAE                        858 00105$:
      005BAE 8F 06            [24]  859 	mov	ar6,r7
      005BB0 74 C0            [12]  860 	mov	a,#0xc0
      005BB2 2E               [12]  861 	add	a, r6
      005BB3 F5 82            [12]  862 	mov	dpl,a
      005BB5 74 10            [12]  863 	mov	a,#0x10
      005BB7 24 00            [12]  864 	add	a, #0x00
      005BB9 F5 83            [12]  865 	mov	dph,a
      005BBB E4               [12]  866 	clr	a
      005BBC F0               [24]  867 	movx	@dptr,a
      005BBD 0F               [12]  868 	inc	r7
      005BBE BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005BC1                        870 00141$:
      005BC1 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005BC3 02 5B 19         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005BC6                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005BC6 90 07 6C         [24]  884 	mov	dptr,#_raw_state
      005BC9 E0               [24]  885 	movx	a,@dptr
      005BCA FF               [12]  886 	mov	r7,a
      005BCB BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005BCE 90 07 6C         [24]  888 	mov	dptr,#_raw_state
      005BD1 E4               [12]  889 	clr	a
      005BD2 F0               [24]  890 	movx	@dptr,a
      005BD3                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005BD3 90 07 BE         [24]  893 	mov	dptr,#_output_kind
      005BD6 E4               [12]  894 	clr	a
      005BD7 F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005BD8 90 07 BD         [24]  897 	mov	dptr,#_control_phase
      005BDB F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005BDC 90 07 5E         [24]  900 	mov	dptr,#_D0SetupReqCode
      005BDF 14               [12]  901 	dec	a
      005BE0 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005BE1 90 22 00         [24]  904 	mov	dptr,#0x2200
      005BE4 74 CF            [12]  905 	mov	a,#0xcf
      005BE6 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005BE7 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_264'
                                    913 ;length        Allocated with name '_control_next_length_10000_264'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005BE8                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005BE8 90 07 5F         [24]  921 	mov	dptr,#_D0SetupLen
      005BEB E0               [24]  922 	movx	a,@dptr
      005BEC FE               [12]  923 	mov	r6,a
      005BED A3               [24]  924 	inc	dptr
      005BEE E0               [24]  925 	movx	a,@dptr
      005BEF FF               [12]  926 	mov	r7,a
      005BF0 C3               [12]  927 	clr	c
      005BF1 74 40            [12]  928 	mov	a,#0x40
      005BF3 9E               [12]  929 	subb	a,r6
      005BF4 E4               [12]  930 	clr	a
      005BF5 9F               [12]  931 	subb	a,r7
      005BF6 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005BF8 7E 40            [12]  934 	mov	r6,#0x40
      005BFA 80 07            [24]  935 	sjmp	00110$
      005BFC                        936 00109$:
      005BFC 90 07 5F         [24]  937 	mov	dptr,#_D0SetupLen
      005BFF E0               [24]  938 	movx	a,@dptr
      005C00 FE               [12]  939 	mov	r6,a
      005C01 A3               [24]  940 	inc	dptr
      005C02 E0               [24]  941 	movx	a,@dptr
      005C03                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005C03 7F 00            [12]  944 	mov	r7,#0x00
      005C05                        945 00105$:
      005C05 C3               [12]  946 	clr	c
      005C06 EF               [12]  947 	mov	a,r7
      005C07 9E               [12]  948 	subb	a,r6
      005C08 50 2A            [24]  949 	jnc	00101$
      005C0A 8F 04            [24]  950 	mov	ar4,r7
      005C0C 74 10            [12]  951 	mov	a,#0x10
      005C0E 24 00            [12]  952 	add	a, #0x00
      005C10 FD               [12]  953 	mov	r5,a
      005C11 90 07 C1         [24]  954 	mov	dptr,#_control_pointer
      005C14 E0               [24]  955 	movx	a,@dptr
      005C15 FA               [12]  956 	mov	r2,a
      005C16 A3               [24]  957 	inc	dptr
      005C17 E0               [24]  958 	movx	a,@dptr
      005C18 FB               [12]  959 	mov	r3,a
      005C19 8A 82            [24]  960 	mov	dpl,r2
      005C1B 8B 83            [24]  961 	mov	dph,r3
      005C1D E4               [12]  962 	clr	a
      005C1E 93               [24]  963 	movc	a,@a+dptr
      005C1F F9               [12]  964 	mov	r1,a
      005C20 90 07 C1         [24]  965 	mov	dptr,#_control_pointer
      005C23 74 01            [12]  966 	mov	a,#0x01
      005C25 2A               [12]  967 	add	a, r2
      005C26 F0               [24]  968 	movx	@dptr,a
      005C27 E4               [12]  969 	clr	a
      005C28 3B               [12]  970 	addc	a, r3
      005C29 A3               [24]  971 	inc	dptr
      005C2A F0               [24]  972 	movx	@dptr,a
      005C2B 8C 82            [24]  973 	mov	dpl,r4
      005C2D 8D 83            [24]  974 	mov	dph,r5
      005C2F E9               [12]  975 	mov	a,r1
      005C30 F0               [24]  976 	movx	@dptr,a
      005C31 0F               [12]  977 	inc	r7
      005C32 80 D1            [24]  978 	sjmp	00105$
      005C34                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005C34 8E 05            [24]  981 	mov	ar5,r6
      005C36 7F 00            [12]  982 	mov	r7,#0x00
      005C38 90 07 5F         [24]  983 	mov	dptr,#_D0SetupLen
      005C3B E0               [24]  984 	movx	a,@dptr
      005C3C FB               [12]  985 	mov	r3,a
      005C3D A3               [24]  986 	inc	dptr
      005C3E E0               [24]  987 	movx	a,@dptr
      005C3F FC               [12]  988 	mov	r4,a
      005C40 EB               [12]  989 	mov	a,r3
      005C41 C3               [12]  990 	clr	c
      005C42 9D               [12]  991 	subb	a,r5
      005C43 FB               [12]  992 	mov	r3,a
      005C44 EC               [12]  993 	mov	a,r4
      005C45 9F               [12]  994 	subb	a,r7
      005C46 FC               [12]  995 	mov	r4,a
      005C47 90 07 5F         [24]  996 	mov	dptr,#_D0SetupLen
      005C4A EB               [12]  997 	mov	a,r3
      005C4B F0               [24]  998 	movx	@dptr,a
      005C4C EC               [12]  999 	mov	a,r4
      005C4D A3               [24] 1000 	inc	dptr
      005C4E F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005C4F EE               [12] 1003 	mov	a,r6
      005C50 70 05            [24] 1004 	jnz	00103$
      005C52 90 07 C0         [24] 1005 	mov	dptr,#_control_zlp
      005C55 E4               [12] 1006 	clr	a
      005C56 F0               [24] 1007 	movx	@dptr,a
      005C57                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005C57 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005C5A EE               [12] 1011 	mov	a,r6
      005C5B F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005C5C 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005C5F E0               [24] 1015 	movx	a,@dptr
      005C60 54 C0            [12] 1016 	anl	a,#0xc0
      005C62 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005C63 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_267'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_280'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005C64                       1032 _descriptor_select:
      005C64 E5 82            [12] 1033 	mov	a,dpl
      005C66 90 07 C6         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_267
      005C69 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005C6A E0               [24] 1037 	movx	a,@dptr
      005C6B FF               [12] 1038 	mov	r7,a
      005C6C BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005C6F 90 07 C3         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005C72 E0               [24] 1041 	movx	a,@dptr
      005C73 70 1A            [24] 1042 	jnz	00102$
      005C75 90 07 C4         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005C78 E0               [24] 1044 	movx	a,@dptr
      005C79 F5 F0            [12] 1045 	mov	b,a
      005C7B A3               [24] 1046 	inc	dptr
      005C7C E0               [24] 1047 	movx	a,@dptr
      005C7D 45 F0            [12] 1048 	orl	a,b
      005C7F 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005C81 90 07 C1         [24] 1051 	mov	dptr,#_control_pointer
      005C84 74 FC            [12] 1052 	mov	a,#_DeviceDescriptor
      005C86 F0               [24] 1053 	movx	@dptr,a
      005C87 74 C3            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005C89 A3               [24] 1055 	inc	dptr
      005C8A F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005C8B 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005C8E 22               [24] 1059 	ret
      005C8F                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005C8F 90 07 C6         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_267
      005C92 E0               [24] 1063 	movx	a,@dptr
      005C93 FF               [12] 1064 	mov	r7,a
      005C94 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005C97 90 07 C3         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005C9A E0               [24] 1067 	movx	a,@dptr
      005C9B 70 1A            [24] 1068 	jnz	00106$
      005C9D 90 07 C4         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005CA0 E0               [24] 1070 	movx	a,@dptr
      005CA1 F5 F0            [12] 1071 	mov	b,a
      005CA3 A3               [24] 1072 	inc	dptr
      005CA4 E0               [24] 1073 	movx	a,@dptr
      005CA5 45 F0            [12] 1074 	orl	a,b
      005CA7 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005CA9 90 07 C1         [24] 1077 	mov	dptr,#_control_pointer
      005CAC 74 0E            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005CAE F0               [24] 1079 	movx	@dptr,a
      005CAF 74 C4            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005CB1 A3               [24] 1081 	inc	dptr
      005CB2 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005CB3 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005CB6 22               [24] 1085 	ret
      005CB7                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005CB7 90 07 C6         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_267
      005CBA E0               [24] 1089 	movx	a,@dptr
      005CBB FF               [12] 1090 	mov	r7,a
      005CBC BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005CBF 80 03            [24] 1092 	sjmp	00239$
      005CC1                       1093 00238$:
      005CC1 02 5D 5B         [24] 1094 	ljmp	00119$
      005CC4                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005CC4 90 07 C4         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005CC7 E0               [24] 1098 	movx	a,@dptr
      005CC8 FD               [12] 1099 	mov	r5,a
      005CC9 A3               [24] 1100 	inc	dptr
      005CCA E0               [24] 1101 	movx	a,@dptr
      005CCB FE               [12] 1102 	mov	r6,a
      005CCC 90 07 C4         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005CCF E0               [24] 1104 	movx	a,@dptr
      005CD0 F5 F0            [12] 1105 	mov	b,a
      005CD2 A3               [24] 1106 	inc	dptr
      005CD3 E0               [24] 1107 	movx	a,@dptr
      005CD4 45 F0            [12] 1108 	orl	a,b
      005CD6 60 0C            [24] 1109 	jz	00110$
      005CD8 BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005CDB BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005CDE 80 04            [24] 1112 	sjmp	00110$
      005CE0                       1113 00241$:
      005CE0 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005CE3 22               [24] 1115 	ret
      005CE4                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005CE4 90 07 C3         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005CE7 E0               [24] 1119 	movx	a,@dptr
      005CE8 FE               [12] 1120 	mov  r6,a
      005CE9 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005CEB 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005CED EE               [12] 1124 	mov	a,r6
      005CEE 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005CEF 90 5C F3         [24] 1127 	mov	dptr,#00243$
      005CF2 73               [24] 1128 	jmp	@a+dptr
      005CF3                       1129 00243$:
      005CF3 80 06            [24] 1130 	sjmp	00112$
      005CF5 80 1B            [24] 1131 	sjmp	00113$
      005CF7 80 30            [24] 1132 	sjmp	00114$
      005CF9 80 45            [24] 1133 	sjmp	00115$
      005CFB                       1134 00112$:
      005CFB 90 07 C1         [24] 1135 	mov	dptr,#_control_pointer
      005CFE 74 62            [12] 1136 	mov	a,#_LanguageString
      005D00 F0               [24] 1137 	movx	@dptr,a
      005D01 74 C4            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005D03 A3               [24] 1139 	inc	dptr
      005D04 F0               [24] 1140 	movx	@dptr,a
      005D05 90 C4 62         [24] 1141 	mov	dptr,#_LanguageString
      005D08 E4               [12] 1142 	clr	a
      005D09 93               [24] 1143 	movc	a,@a+dptr
      005D0A FE               [12] 1144 	mov	r6,a
      005D0B 7D 00            [12] 1145 	mov	r5,#0x00
      005D0D 8E 82            [24] 1146 	mov	dpl, r6
      005D0F 8D 83            [24] 1147 	mov	dph, r5
      005D11 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005D12                       1150 00113$:
      005D12 90 07 C1         [24] 1151 	mov	dptr,#_control_pointer
      005D15 74 66            [12] 1152 	mov	a,#_ManufacturerString
      005D17 F0               [24] 1153 	movx	@dptr,a
      005D18 74 C4            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005D1A A3               [24] 1155 	inc	dptr
      005D1B F0               [24] 1156 	movx	@dptr,a
      005D1C 90 C4 66         [24] 1157 	mov	dptr,#_ManufacturerString
      005D1F E4               [12] 1158 	clr	a
      005D20 93               [24] 1159 	movc	a,@a+dptr
      005D21 FE               [12] 1160 	mov	r6,a
      005D22 7D 00            [12] 1161 	mov	r5,#0x00
      005D24 8E 82            [24] 1162 	mov	dpl, r6
      005D26 8D 83            [24] 1163 	mov	dph, r5
      005D28 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005D29                       1166 00114$:
      005D29 90 07 C1         [24] 1167 	mov	dptr,#_control_pointer
      005D2C 74 74            [12] 1168 	mov	a,#_ProductString
      005D2E F0               [24] 1169 	movx	@dptr,a
      005D2F 74 C4            [12] 1170 	mov	a,#(_ProductString >> 8)
      005D31 A3               [24] 1171 	inc	dptr
      005D32 F0               [24] 1172 	movx	@dptr,a
      005D33 90 C4 74         [24] 1173 	mov	dptr,#_ProductString
      005D36 E4               [12] 1174 	clr	a
      005D37 93               [24] 1175 	movc	a,@a+dptr
      005D38 FE               [12] 1176 	mov	r6,a
      005D39 7D 00            [12] 1177 	mov	r5,#0x00
      005D3B 8E 82            [24] 1178 	mov	dpl, r6
      005D3D 8D 83            [24] 1179 	mov	dph, r5
      005D3F 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005D40                       1182 00115$:
      005D40 90 07 C1         [24] 1183 	mov	dptr,#_control_pointer
      005D43 74 AC            [12] 1184 	mov	a,#_SerialNumberString
      005D45 F0               [24] 1185 	movx	@dptr,a
      005D46 74 C4            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005D48 A3               [24] 1187 	inc	dptr
      005D49 F0               [24] 1188 	movx	@dptr,a
      005D4A 90 C4 AC         [24] 1189 	mov	dptr,#_SerialNumberString
      005D4D E4               [12] 1190 	clr	a
      005D4E 93               [24] 1191 	movc	a,@a+dptr
      005D4F FE               [12] 1192 	mov	r6,a
      005D50 7D 00            [12] 1193 	mov	r5,#0x00
      005D52 8E 82            [24] 1194 	mov	dpl, r6
      005D54 8D 83            [24] 1195 	mov	dph, r5
      005D56 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005D57                       1198 00116$:
      005D57 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005D5A 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005D5B                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005D5B 90 07 C3         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005D5E E0               [24] 1205 	movx	a,@dptr
      005D5F 70 11            [24] 1206 	jnz	00120$
      005D61 90 07 C4         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005D64 E0               [24] 1208 	movx	a,@dptr
      005D65 FD               [12] 1209 	mov	r5,a
      005D66 A3               [24] 1210 	inc	dptr
      005D67 E0               [24] 1211 	movx	a,@dptr
      005D68 FE               [12] 1212 	mov	r6,a
      005D69 C3               [12] 1213 	clr	c
      005D6A ED               [12] 1214 	mov	a,r5
      005D6B 94 03            [12] 1215 	subb	a,#0x03
      005D6D EE               [12] 1216 	mov	a,r6
      005D6E 94 00            [12] 1217 	subb	a,#0x00
      005D70 40 04            [24] 1218 	jc	00121$
      005D72                       1219 00120$:
      005D72 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005D75 22               [24] 1221 	ret
      005D76                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005D76 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005D79 80 03            [24] 1225 	sjmp	00127$
      005D7B                       1226 00246$:
      005D7B BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005D7E                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005D7E ED               [12] 1230 	mov	a,r5
      005D7F 75 F0 04         [24] 1231 	mov	b,#0x04
      005D82 A4               [48] 1232 	mul	ab
      005D83 24 88            [12] 1233 	add	a, #_interface_descriptors
      005D85 FE               [12] 1234 	mov	r6,a
      005D86 74 BD            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005D88 35 F0            [12] 1236 	addc	a, b
      005D8A FF               [12] 1237 	mov	r7,a
      005D8B 8E 82            [24] 1238 	mov	dpl,r6
      005D8D 8F 83            [24] 1239 	mov	dph,r7
      005D8F A3               [24] 1240 	inc	dptr
      005D90 A3               [24] 1241 	inc	dptr
      005D91 E4               [12] 1242 	clr	a
      005D92 93               [24] 1243 	movc	a,@a+dptr
      005D93 FC               [12] 1244 	mov	r4,a
      005D94 A3               [24] 1245 	inc	dptr
      005D95 E4               [12] 1246 	clr	a
      005D96 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005D97 FD               [12] 1249 	mov	r5,a
      005D98 4C               [12] 1250 	orl	a,r4
      005D99 70 04            [24] 1251 	jnz	00124$
      005D9B 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005D9E 22               [24] 1253 	ret
      005D9F                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005D9F 90 07 C6         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_267
      005DA2 E0               [24] 1257 	movx	a,@dptr
      005DA3 FB               [12] 1258 	mov	r3,a
      005DA4 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005DA7 8E 82            [24] 1261 	mov	dpl,r6
      005DA9 8F 83            [24] 1262 	mov	dph,r7
      005DAB E4               [12] 1263 	clr	a
      005DAC 93               [24] 1264 	movc	a,@a+dptr
      005DAD FE               [12] 1265 	mov	r6,a
      005DAE A3               [24] 1266 	inc	dptr
      005DAF E4               [12] 1267 	clr	a
      005DB0 93               [24] 1268 	movc	a,@a+dptr
      005DB1 FF               [12] 1269 	mov	r7,a
      005DB2 90 07 C1         [24] 1270 	mov	dptr,#_control_pointer
      005DB5 EE               [12] 1271 	mov	a,r6
      005DB6 F0               [24] 1272 	movx	@dptr,a
      005DB7 EF               [12] 1273 	mov	a,r7
      005DB8 A3               [24] 1274 	inc	dptr
      005DB9 F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005DBA 74 07            [12] 1277 	mov	a,#0x07
      005DBC 2C               [12] 1278 	add	a, r4
      005DBD F5 82            [12] 1279 	mov	dpl,a
      005DBF E4               [12] 1280 	clr	a
      005DC0 3D               [12] 1281 	addc	a, r5
      005DC1 F5 83            [12] 1282 	mov	dph,a
      005DC3 E4               [12] 1283 	clr	a
      005DC4 93               [24] 1284 	movc	a,@a+dptr
      005DC5 FE               [12] 1285 	mov	r6,a
      005DC6 A3               [24] 1286 	inc	dptr
      005DC7 E4               [12] 1287 	clr	a
      005DC8 93               [24] 1288 	movc	a,@a+dptr
      005DC9 FF               [12] 1289 	mov	r7,a
      005DCA 8E 82            [24] 1290 	mov	dpl, r6
      005DCC 8F 83            [24] 1291 	mov	dph, r7
      005DCE 22               [24] 1292 	ret
      005DCF                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005DCF 90 07 C1         [24] 1295 	mov	dptr,#_control_pointer
      005DD2 EC               [12] 1296 	mov	a,r4
      005DD3 F0               [24] 1297 	movx	@dptr,a
      005DD4 ED               [12] 1298 	mov	a,r5
      005DD5 A3               [24] 1299 	inc	dptr
      005DD6 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005DD7 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005DDA 22               [24] 1303 	ret
      005DDB                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005DDB 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005DDE 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_285'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_285'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_285'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_285'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_285'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_285'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_285'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_285'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005DDF                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005DDF 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005DE2 E0               [24] 1331 	movx	a,@dptr
      005DE3 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005DE4 A3               [24] 1334 	inc	dptr
      005DE5 A3               [24] 1335 	inc	dptr
      005DE6 E0               [24] 1336 	movx	a,@dptr
      005DE7 FE               [12] 1337 	mov	r6,a
      005DE8 A3               [24] 1338 	inc	dptr
      005DE9 E0               [24] 1339 	movx	a,@dptr
      005DEA FC               [12] 1340 	mov	r4,a
      005DEB 7D 00            [12] 1341 	mov	r5,#0x00
      005DED 8E 03            [24] 1342 	mov	ar3,r6
      005DEF 7E 00            [12] 1343 	mov	r6,#0x00
      005DF1 ED               [12] 1344 	mov	a,r5
      005DF2 4B               [12] 1345 	orl	a,r3
      005DF3 FD               [12] 1346 	mov	r5,a
      005DF4 EC               [12] 1347 	mov	a,r4
      005DF5 4E               [12] 1348 	orl	a,r6
      005DF6 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005DF7 A3               [24] 1351 	inc	dptr
      005DF8 E0               [24] 1352 	movx	a,@dptr
      005DF9 FC               [12] 1353 	mov	r4,a
      005DFA A3               [24] 1354 	inc	dptr
      005DFB E0               [24] 1355 	movx	a,@dptr
      005DFC FA               [12] 1356 	mov	r2,a
      005DFD 7B 00            [12] 1357 	mov	r3,#0x00
      005DFF 8C 01            [24] 1358 	mov	ar1,r4
      005E01 7C 00            [12] 1359 	mov	r4,#0x00
      005E03 EB               [12] 1360 	mov	a,r3
      005E04 49               [12] 1361 	orl	a,r1
      005E05 FB               [12] 1362 	mov	r3,a
      005E06 EA               [12] 1363 	mov	a,r2
      005E07 4C               [12] 1364 	orl	a,r4
      005E08 FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005E09 C3               [12] 1367 	clr	c
      005E0A EB               [12] 1368 	mov	a,r3
      005E0B 94 03            [12] 1369 	subb	a,#0x03
      005E0D EC               [12] 1370 	mov	a,r4
      005E0E 94 00            [12] 1371 	subb	a,#0x00
      005E10 92 16            [24] 1372 	mov	_control_setup_valid_interface_10000_285,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005E12 EB               [12] 1374 	mov	a,r3
      005E13 4C               [12] 1375 	orl	a,r4
      005E14 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005E17                       1377 01201$:
      005E17 92 17            [24] 1378 	mov	_control_setup_zero_index_10000_285,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005E19 ED               [12] 1380 	mov	a,r5
      005E1A 4E               [12] 1381 	orl	a,r6
      005E1B B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005E1E                       1383 01202$:
                                   1384 ;	assignBit
      005E1E 92 1A            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005E20 92 18            [24] 1386 	mov	_control_setup_zero_value_10000_285,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005E22 90 07 C9         [24] 1388 	mov	dptr,#_control_setup_offset_10000_285
      005E25 E4               [12] 1389 	clr	a
      005E26 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005E27 90 07 6C         [24] 1392 	mov	dptr,#_raw_state
      005E2A E0               [24] 1393 	movx	a,@dptr
      005E2B FA               [12] 1394 	mov	r2,a
      005E2C BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005E2F 90 07 6C         [24] 1396 	mov	dptr,#_raw_state
      005E32 E4               [12] 1397 	clr	a
      005E33 F0               [24] 1398 	movx	@dptr,a
      005E34                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005E34 C0 07            [24] 1401 	push	ar7
      005E36 90 07 BE         [24] 1402 	mov	dptr,#_output_kind
      005E39 E4               [12] 1403 	clr	a
      005E3A F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005E3B 90 07 BD         [24] 1406 	mov	dptr,#_control_phase
      005E3E F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005E3F 90 07 C0         [24] 1409 	mov	dptr,#_control_zlp
      005E42 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005E43 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005E46 E0               [24] 1413 	movx	a,@dptr
      005E47 90 07 5E         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005E4A F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005E4B 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005E4E E0               [24] 1418 	movx	a,@dptr
      005E4F FA               [12] 1419 	mov	r2,a
      005E50 A3               [24] 1420 	inc	dptr
      005E51 E0               [24] 1421 	movx	a,@dptr
      005E52 F9               [12] 1422 	mov	r1,a
      005E53 78 00            [12] 1423 	mov	r0,#0x00
      005E55 7F 00            [12] 1424 	mov	r7,#0x00
      005E57 90 07 5F         [24] 1425 	mov	dptr,#_D0SetupLen
      005E5A E8               [12] 1426 	mov	a,r0
      005E5B 4A               [12] 1427 	orl	a,r2
      005E5C F0               [24] 1428 	movx	@dptr,a
      005E5D E9               [12] 1429 	mov	a,r1
      005E5E 4F               [12] 1430 	orl	a,r7
      005E5F A3               [24] 1431 	inc	dptr
      005E60 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      005E61 90 07 5F         [24] 1434 	mov	dptr,#_D0SetupLen
      005E64 E0               [24] 1435 	movx	a,@dptr
      005E65 FA               [12] 1436 	mov	r2,a
      005E66 A3               [24] 1437 	inc	dptr
      005E67 E0               [24] 1438 	movx	a,@dptr
      005E68 4A               [12] 1439 	orl	a,r2
      005E69 B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005E6C                       1441 01205$:
      005E6C 92 19            [24] 1442 	mov	_control_setup_zero_length_10000_285,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005E6E 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005E71 74 C2            [12] 1445 	mov	a,#0xc2
      005E73 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      005E74 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005E77 E4               [12] 1449 	clr	a
      005E78 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      005E79 90 07 5E         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005E7C E0               [24] 1453 	movx	a,@dptr
      005E7D F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005E7F C3               [12] 1455 	clr	c
      005E80 74 0B            [12] 1456 	mov	a,#0x0b
      005E82 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005E84 D0 07            [24] 1458 	pop	ar7
      005E86 50 03            [24] 1459 	jnc	01206$
      005E88 02 5B C6         [24] 1460 	ljmp	_control_stall
      005E8B                       1461 01206$:
                                   1462 ;	free result
      005E8B E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005E8D F5 F0            [12] 1464 	mov	b,a
      005E8F 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005E91 83               [24] 1466 	movc	a,@a+pc
      005E92 F5 82            [12] 1467 	mov	dpl,a
      005E94 E5 F0            [12] 1468 	mov	a,b
      005E96 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005E98 83               [24] 1470 	movc	a,@a+pc
      005E99 F5 83            [12] 1471 	mov	dph,a
      005E9B E4               [12] 1472 	clr	a
      005E9C 73               [24] 1473 	jmp	@a+dptr
      005E9D                       1474 01207$:
      005E9D 45                    1475 	.db	00188$
      005E9E EB                    1476 	.db	00205$
      005E9F 2E                    1477 	.db	00282$
      005EA0 EB                    1478 	.db	00205$
      005EA1 72                    1479 	.db	00290$
      005EA2 6F                    1480 	.db	00116$
      005EA3 B5                    1481 	.db	00103$
      005EA4 72                    1482 	.db	00290$
      005EA5 74                    1483 	.db	00150$
      005EA6 98                    1484 	.db	00123$
      005EA7 A4                    1485 	.db	00157$
      005EA8 F7                    1486 	.db	00173$
      005EA9                       1487 01208$:
      005EA9 61                    1488 	.db	00188$>>8
      005EAA 61                    1489 	.db	00205$>>8
      005EAB 65                    1490 	.db	00282$>>8
      005EAC 61                    1491 	.db	00205$>>8
      005EAD 65                    1492 	.db	00290$>>8
      005EAE 5F                    1493 	.db	00116$>>8
      005EAF 5E                    1494 	.db	00103$>>8
      005EB0 65                    1495 	.db	00290$>>8
      005EB1 60                    1496 	.db	00150$>>8
      005EB2 5F                    1497 	.db	00123$>>8
      005EB3 60                    1498 	.db	00157$>>8
      005EB4 60                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      005EB5                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      005EB5 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005EB8 80 08            [24] 1504 	sjmp	00112$
      005EBA                       1505 01209$:
      005EBA BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005EBD 80 03            [24] 1507 	sjmp	01211$
      005EBF                       1508 01210$:
      005EBF 02 5B C6         [24] 1509 	ljmp	_control_stall
      005EC2                       1510 01211$:
      005EC2                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005EC2 8E 01            [24] 1513 	mov	ar1,r6
      005EC4 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005EC7 80 09            [24] 1515 	sjmp	00301$
      005EC9                       1516 01212$:
      005EC9 B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005ECC 80 04            [24] 1518 	sjmp	00301$
      005ECE                       1519 01213$:
                                   1520 ;	assignBit
      005ECE C2 1B            [12] 1521 	clr	_control_setup_sloc2_1_0
      005ED0 80 02            [24] 1522 	sjmp	00302$
      005ED2                       1523 00301$:
                                   1524 ;	assignBit
      005ED2 D2 1B            [12] 1525 	setb	_control_setup_sloc2_1_0
      005ED4                       1526 00302$:
      005ED4 E4               [12] 1527 	clr	a
      005ED5 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005ED8 04               [12] 1529 	inc	a
      005ED9                       1530 01214$:
      005ED9 FA               [12] 1531 	mov	r2,a
      005EDA A2 1B            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005EDC E4               [12] 1533 	clr	a
      005EDD 33               [12] 1534 	rlc	a
      005EDE B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005EE1 80 03            [24] 1536 	sjmp	00105$
      005EE3                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      005EE3 02 5B C6         [24] 1539 	ljmp	_control_stall
      005EE6                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      005EE6 8E 02            [24] 1542 	mov	ar2,r6
      005EE8 90 07 C3         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005EEB ED               [12] 1544 	mov	a,r5
      005EEC F0               [24] 1545 	movx	@dptr,a
      005EED 90 07 C4         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005EF0 EB               [12] 1547 	mov	a,r3
      005EF1 F0               [24] 1548 	movx	@dptr,a
      005EF2 EC               [12] 1549 	mov	a,r4
      005EF3 A3               [24] 1550 	inc	dptr
      005EF4 F0               [24] 1551 	movx	@dptr,a
      005EF5 8A 82            [24] 1552 	mov	dpl, r2
      005EF7 12 5C 64         [24] 1553 	lcall	_descriptor_select
      005EFA 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005EFD 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      005F00 E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005F02 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005F04 70 03            [24] 1559 	jnz	00107$
      005F06 02 5B C6         [24] 1560 	ljmp	_control_stall
      005F09                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005F09 90 07 5F         [24] 1563 	mov	dptr,#_D0SetupLen
      005F0C E0               [24] 1564 	movx	a,@dptr
      005F0D F8               [12] 1565 	mov	r0,a
      005F0E A3               [24] 1566 	inc	dptr
      005F0F E0               [24] 1567 	movx	a,@dptr
      005F10 FA               [12] 1568 	mov	r2,a
      005F11 C3               [12] 1569 	clr	c
      005F12 E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005F14 98               [12] 1571 	subb	a,r0
      005F15 E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005F17 9A               [12] 1573 	subb	a,r2
      005F18 50 06            [24] 1574 	jnc	00303$
      005F1A E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005F1C 54 3F            [12] 1576 	anl	a,#0x3f
      005F1E 60 04            [24] 1577 	jz	00304$
      005F20                       1578 00303$:
                                   1579 ;	assignBit
      005F20 C2 1B            [12] 1580 	clr	_control_setup_sloc2_1_0
      005F22 80 02            [24] 1581 	sjmp	00305$
      005F24                       1582 00304$:
                                   1583 ;	assignBit
      005F24 D2 1B            [12] 1584 	setb	_control_setup_sloc2_1_0
      005F26                       1585 00305$:
      005F26 90 07 C0         [24] 1586 	mov	dptr,#_control_zlp
      005F29 A2 1B            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005F2B E4               [12] 1588 	clr	a
      005F2C 33               [12] 1589 	rlc	a
      005F2D F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      005F2E 90 07 5F         [24] 1592 	mov	dptr,#_D0SetupLen
      005F31 E0               [24] 1593 	movx	a,@dptr
      005F32 F9               [12] 1594 	mov	r1,a
      005F33 A3               [24] 1595 	inc	dptr
      005F34 E0               [24] 1596 	movx	a,@dptr
      005F35 FA               [12] 1597 	mov	r2,a
      005F36 C3               [12] 1598 	clr	c
      005F37 E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005F39 99               [12] 1600 	subb	a,r1
      005F3A E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005F3C 9A               [12] 1602 	subb	a,r2
      005F3D 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005F3F 90 07 5F         [24] 1605 	mov	dptr,#_D0SetupLen
      005F42 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005F44 F0               [24] 1607 	movx	@dptr,a
      005F45 E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005F47 A3               [24] 1609 	inc	dptr
      005F48 F0               [24] 1610 	movx	@dptr,a
      005F49                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005F49 90 07 5F         [24] 1613 	mov	dptr,#_D0SetupLen
      005F4C E0               [24] 1614 	movx	a,@dptr
      005F4D F9               [12] 1615 	mov	r1,a
      005F4E A3               [24] 1616 	inc	dptr
      005F4F E0               [24] 1617 	movx	a,@dptr
      005F50 49               [12] 1618 	orl	a,r1
      005F51 60 04            [24] 1619 	jz	00306$
      005F53 7A 01            [12] 1620 	mov	r2,#0x01
      005F55 80 02            [24] 1621 	sjmp	00307$
      005F57                       1622 00306$:
      005F57 7A 02            [12] 1623 	mov	r2,#0x02
      005F59                       1624 00307$:
      005F59 90 07 BD         [24] 1625 	mov	dptr,#_control_phase
      005F5C EA               [12] 1626 	mov	a,r2
      005F5D F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      005F5E 90 07 5F         [24] 1629 	mov	dptr,#_D0SetupLen
      005F61 E0               [24] 1630 	movx	a,@dptr
      005F62 F9               [12] 1631 	mov	r1,a
      005F63 A3               [24] 1632 	inc	dptr
      005F64 E0               [24] 1633 	movx	a,@dptr
      005F65 49               [12] 1634 	orl	a,r1
      005F66 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      005F68 02 5B E8         [24] 1637 	ljmp	_control_next
      005F6B                       1638 00111$:
      005F6B 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      005F6C 02 5B C6         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      005F6F                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005F6F EF               [12] 1645 	mov	a,r7
      005F70 70 23            [24] 1646 	jnz	00118$
      005F72 30 17 20         [24] 1647 	jnb	_control_setup_zero_index_10000_285,00118$
      005F75 30 19 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_285,00118$
      005F78 8D 01            [24] 1649 	mov	ar1,r5
      005F7A 8E 02            [24] 1650 	mov	ar2,r6
      005F7C C3               [12] 1651 	clr	c
      005F7D 74 7F            [12] 1652 	mov	a,#0x7f
      005F7F 99               [12] 1653 	subb	a,r1
      005F80 E4               [12] 1654 	clr	a
      005F81 9A               [12] 1655 	subb	a,r2
      005F82 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      005F84 90 07 5F         [24] 1659 	mov	dptr,#_D0SetupLen
      005F87 ED               [12] 1660 	mov	a,r5
      005F88 F0               [24] 1661 	movx	@dptr,a
      005F89 EE               [12] 1662 	mov	a,r6
      005F8A A3               [24] 1663 	inc	dptr
      005F8B F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      005F8C 90 07 BD         [24] 1666 	mov	dptr,#_control_phase
      005F8F 74 03            [12] 1667 	mov	a,#0x03
      005F91 F0               [24] 1668 	movx	@dptr,a
      005F92 02 65 75         [24] 1669 	ljmp	00291$
      005F95                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      005F95 02 5B C6         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005F98                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005F98 EF               [12] 1676 	mov	a,r7
      005F99 70 3C            [24] 1677 	jnz	00145$
      005F9B 30 17 39         [24] 1678 	jnb	_control_setup_zero_index_10000_285,00145$
      005F9E 30 19 36         [24] 1679 	jnb	_control_setup_zero_length_10000_285,00145$
      005FA1 8D 01            [24] 1680 	mov	ar1,r5
      005FA3 8E 02            [24] 1681 	mov	ar2,r6
      005FA5 C3               [12] 1682 	clr	c
      005FA6 74 01            [12] 1683 	mov	a,#0x01
      005FA8 99               [12] 1684 	subb	a,r1
      005FA9 E4               [12] 1685 	clr	a
      005FAA 9A               [12] 1686 	subb	a,r2
      005FAB 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      005FAD C0 06            [24] 1690 	push	ar6
      005FAF C0 05            [24] 1691 	push	ar5
      005FB1 12 5B 6F         [24] 1692 	lcall	_endpoints_reset
      005FB4 D0 05            [24] 1693 	pop	ar5
      005FB6 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      005FB8 90 07 64         [24] 1696 	mov	dptr,#_D0UsbConfig
      005FBB ED               [12] 1697 	mov	a,r5
      005FBC F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      005FBD A2 1A            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005FBF B3               [12] 1701 	cpl	c
      005FC0 92 1B            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005FC2 90 07 65         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005FC5 E4               [12] 1704 	clr	a
      005FC6 33               [12] 1705 	rlc	a
      005FC7 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      005FC8 90 07 8E         [24] 1708 	mov	dptr,#_keyboard_reset
      005FCB 74 01            [12] 1709 	mov	a,#0x01
      005FCD F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      005FCE 90 07 BD         [24] 1712 	mov	dptr,#_control_phase
      005FD1 74 03            [12] 1713 	mov	a,#0x03
      005FD3 F0               [24] 1714 	movx	@dptr,a
      005FD4 02 65 75         [24] 1715 	ljmp	00291$
      005FD7                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      005FD7 BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005FDA 80 03            [24] 1719 	sjmp	01232$
      005FDC                       1720 01231$:
      005FDC 02 5B C6         [24] 1721 	ljmp	_control_stall
      005FDF                       1722 01232$:
      005FDF 90 07 64         [24] 1723 	mov	dptr,#_D0UsbConfig
      005FE2 E0               [24] 1724 	movx	a,@dptr
      005FE3 70 03            [24] 1725 	jnz	01233$
      005FE5 02 5B C6         [24] 1726 	ljmp	_control_stall
      005FE8                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005FE8 BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005FEB BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005FEE 8D 01            [24] 1731 	mov	ar1,r5
      005FF0 8E 02            [24] 1732 	mov	ar2,r6
      005FF2 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005FF5 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005FF8 90 07 5F         [24] 1735 	mov	dptr,#_D0SetupLen
      005FFB E0               [24] 1736 	movx	a,@dptr
      005FFC F9               [12] 1737 	mov	r1,a
      005FFD A3               [24] 1738 	inc	dptr
      005FFE E0               [24] 1739 	movx	a,@dptr
      005FFF FA               [12] 1740 	mov	r2,a
      006000 B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      006003 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      006006 90 07 6C         [24] 1743 	mov	dptr,#_raw_state
      006009 E0               [24] 1744 	movx	a,@dptr
      00600A 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      00600C 90 07 6C         [24] 1747 	mov	dptr,#_raw_state
      00600F 74 01            [12] 1748 	mov	a,#0x01
      006011 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      006012 90 07 BE         [24] 1751 	mov	dptr,#_output_kind
      006015 F0               [24] 1752 	movx	@dptr,a
      006016 80 52            [24] 1753 	sjmp	00136$
      006018                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006018 EB               [12] 1756 	mov	a,r3
      006019 4C               [12] 1757 	orl	a,r4
      00601A 70 20            [24] 1758 	jnz	00130$
      00601C 8D 01            [24] 1759 	mov	ar1,r5
      00601E 8E 02            [24] 1760 	mov	ar2,r6
      006020 B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      006023 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      006026 90 07 5F         [24] 1763 	mov	dptr,#_D0SetupLen
      006029 E0               [24] 1764 	movx	a,@dptr
      00602A F9               [12] 1765 	mov	r1,a
      00602B A3               [24] 1766 	inc	dptr
      00602C E0               [24] 1767 	movx	a,@dptr
      00602D FA               [12] 1768 	mov	r2,a
      00602E B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      006031 BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      006034 90 07 BE         [24] 1772 	mov	dptr,#_output_kind
      006037 74 02            [12] 1773 	mov	a,#0x02
      006039 F0               [24] 1774 	movx	@dptr,a
      00603A 80 2E            [24] 1775 	sjmp	00136$
      00603C                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00603C BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      00603F BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      006042 8D 01            [24] 1780 	mov	ar1,r5
      006044 8E 02            [24] 1781 	mov	ar2,r6
      006046 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      006049 BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      00604C 90 07 5F         [24] 1784 	mov	dptr,#_D0SetupLen
      00604F E0               [24] 1785 	movx	a,@dptr
      006050 F9               [12] 1786 	mov	r1,a
      006051 A3               [24] 1787 	inc	dptr
      006052 E0               [24] 1788 	movx	a,@dptr
      006053 FA               [12] 1789 	mov	r2,a
      006054 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      006057 BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      00605A 90 07 BE         [24] 1793 	mov	dptr,#_output_kind
      00605D 74 03            [12] 1794 	mov	a,#0x03
      00605F F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      006060 90 07 BF         [24] 1797 	mov	dptr,#_output_report_id
      006063 23               [12] 1798 	rl	a
      006064 F0               [24] 1799 	movx	@dptr,a
      006065 80 03            [24] 1800 	sjmp	00136$
      006067                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      006067 02 5B C6         [24] 1803 	ljmp	_control_stall
      00606A                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      00606A 90 07 BD         [24] 1806 	mov	dptr,#_control_phase
      00606D 74 04            [12] 1807 	mov	a,#0x04
      00606F F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      006070 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      006071 02 5B C6         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006074                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006074 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      006077 30 17 27         [24] 1817 	jnb	_control_setup_zero_index_10000_285,00152$
      00607A 30 18 24         [24] 1818 	jnb	_control_setup_zero_value_10000_285,00152$
      00607D 90 07 5F         [24] 1819 	mov	dptr,#_D0SetupLen
      006080 E0               [24] 1820 	movx	a,@dptr
      006081 F9               [12] 1821 	mov	r1,a
      006082 A3               [24] 1822 	inc	dptr
      006083 E0               [24] 1823 	movx	a,@dptr
      006084 FA               [12] 1824 	mov	r2,a
      006085 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      006088 BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      00608B 90 07 64         [24] 1828 	mov	dptr,#_D0UsbConfig
      00608E E0               [24] 1829 	movx	a,@dptr
      00608F 90 10 00         [24] 1830 	mov	dptr,#0x1000
      006092 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      006093 90 22 08         [24] 1833 	mov	dptr,#0x2208
      006096 74 01            [12] 1834 	mov	a,#0x01
      006098 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      006099 90 07 BD         [24] 1837 	mov	dptr,#_control_phase
      00609C 04               [12] 1838 	inc	a
      00609D F0               [24] 1839 	movx	@dptr,a
      00609E 02 65 75         [24] 1840 	ljmp	00291$
      0060A1                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      0060A1 02 5B C6         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0060A4                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0060A4 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      0060A7 30 16 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_285,00167$
      0060AA 30 18 26         [24] 1849 	jnb	_control_setup_zero_value_10000_285,00167$
      0060AD 90 07 5F         [24] 1850 	mov	dptr,#_D0SetupLen
      0060B0 E0               [24] 1851 	movx	a,@dptr
      0060B1 F9               [12] 1852 	mov	r1,a
      0060B2 A3               [24] 1853 	inc	dptr
      0060B3 E0               [24] 1854 	movx	a,@dptr
      0060B4 FA               [12] 1855 	mov	r2,a
      0060B5 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      0060B8 BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      0060BB 90 07 64         [24] 1858 	mov	dptr,#_D0UsbConfig
      0060BE E0               [24] 1859 	movx	a,@dptr
      0060BF 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      0060C1 90 10 00         [24] 1862 	mov	dptr,#0x1000
      0060C4 E4               [12] 1863 	clr	a
      0060C5 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      0060C6 90 22 08         [24] 1866 	mov	dptr,#0x2208
      0060C9 04               [12] 1867 	inc	a
      0060CA F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      0060CB 90 07 BD         [24] 1870 	mov	dptr,#_control_phase
      0060CE 04               [12] 1871 	inc	a
      0060CF F0               [24] 1872 	movx	@dptr,a
      0060D0 02 65 75         [24] 1873 	ljmp	00291$
      0060D3                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0060D3 30 16 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_285,00161$
      0060D6 90 07 64         [24] 1877 	mov	dptr,#_D0UsbConfig
      0060D9 E0               [24] 1878 	movx	a,@dptr
      0060DA 60 18            [24] 1879 	jz	00161$
      0060DC BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      0060DF 30 19 12         [24] 1881 	jnb	_control_setup_zero_length_10000_285,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0060E2 EB               [12] 1883 	mov	a,r3
      0060E3 4C               [12] 1884 	orl	a,r4
      0060E4 70 05            [24] 1885 	jnz	00159$
      0060E6 90 06 3C         [24] 1886 	mov	dptr,#_keyboard_idle
      0060E9 EE               [12] 1887 	mov	a,r6
      0060EA F0               [24] 1888 	movx	@dptr,a
      0060EB                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      0060EB 90 07 BD         [24] 1891 	mov	dptr,#_control_phase
      0060EE 74 03            [12] 1892 	mov	a,#0x03
      0060F0 F0               [24] 1893 	movx	@dptr,a
      0060F1 02 65 75         [24] 1894 	ljmp	00291$
      0060F4                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      0060F4 02 5B C6         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0060F7                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0060F7 BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      0060FA 30 16 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_285,00182$
      0060FD 30 18 12         [24] 1903 	jnb	_control_setup_zero_value_10000_285,00182$
      006100 30 19 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_285,00182$
      006103 90 07 64         [24] 1905 	mov	dptr,#_D0UsbConfig
      006106 E0               [24] 1906 	movx	a,@dptr
      006107 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      006109 90 07 BD         [24] 1909 	mov	dptr,#_control_phase
      00610C 74 03            [12] 1910 	mov	a,#0x03
      00610E F0               [24] 1911 	movx	@dptr,a
      00610F 02 65 75         [24] 1912 	ljmp	00291$
      006112                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006112 EB               [12] 1915 	mov	a,r3
      006113 4C               [12] 1916 	orl	a,r4
      006114 70 2C            [24] 1917 	jnz	00175$
      006116 90 07 64         [24] 1918 	mov	dptr,#_D0UsbConfig
      006119 E0               [24] 1919 	movx	a,@dptr
      00611A 60 26            [24] 1920 	jz	00175$
      00611C BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      00611F 30 19 20         [24] 1922 	jnb	_control_setup_zero_length_10000_285,00175$
      006122 8D 01            [24] 1923 	mov	ar1,r5
      006124 8E 02            [24] 1924 	mov	ar2,r6
      006126 C3               [12] 1925 	clr	c
      006127 74 01            [12] 1926 	mov	a,#0x01
      006129 99               [12] 1927 	subb	a,r1
      00612A E4               [12] 1928 	clr	a
      00612B 9A               [12] 1929 	subb	a,r2
      00612C 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      00612E 90 0D D4         [24] 1933 	mov	dptr,#_keyboard_protocol
      006131 ED               [12] 1934 	mov	a,r5
      006132 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      006133 90 07 8E         [24] 1937 	mov	dptr,#_keyboard_reset
      006136 74 01            [12] 1938 	mov	a,#0x01
      006138 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      006139 90 07 BD         [24] 1941 	mov	dptr,#_control_phase
      00613C 74 03            [12] 1942 	mov	a,#0x03
      00613E F0               [24] 1943 	movx	@dptr,a
      00613F 02 65 75         [24] 1944 	ljmp	00291$
      006142                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006142 02 5B C6         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      006145                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      006145 20 18 03         [24] 1951 	jb	_control_setup_zero_value_10000_285,01283$
      006148 02 5B C6         [24] 1952 	ljmp	_control_stall
      00614B                       1953 01283$:
      00614B 90 07 5F         [24] 1954 	mov	dptr,#_D0SetupLen
      00614E E0               [24] 1955 	movx	a,@dptr
      00614F F9               [12] 1956 	mov	r1,a
      006150 A3               [24] 1957 	inc	dptr
      006151 E0               [24] 1958 	movx	a,@dptr
      006152 FA               [12] 1959 	mov	r2,a
      006153 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      006156 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      006159 80 03            [24] 1962 	sjmp	01285$
      00615B                       1963 01284$:
      00615B 02 5B C6         [24] 1964 	ljmp	_control_stall
      00615E                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00615E E4               [12] 1967 	clr	a
      00615F BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      006162 04               [12] 1969 	inc	a
      006163                       1970 01286$:
      006163 FA               [12] 1971 	mov	r2,a
      006164 60 03            [24] 1972 	jz	00196$
      006166 20 17 35         [24] 1973 	jb	_control_setup_zero_index_10000_285,00189$
      006169                       1974 00196$:
      006169 BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      00616C 30 16 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_285,00202$
      00616F 90 07 64         [24] 1977 	mov	dptr,#_D0UsbConfig
      006172 E0               [24] 1978 	movx	a,@dptr
      006173 70 29            [24] 1979 	jnz	00189$
      006175                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006175 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      006178 90 07 64         [24] 1983 	mov	dptr,#_D0UsbConfig
      00617B E0               [24] 1984 	movx	a,@dptr
      00617C 60 6A            [24] 1985 	jz	00190$
      00617E EB               [12] 1986 	mov	a,r3
      00617F 4C               [12] 1987 	orl	a,r4
      006180 60 1C            [24] 1988 	jz	00189$
      006182 8B 00            [24] 1989 	mov	ar0,r3
      006184 8C 01            [24] 1990 	mov	ar1,r4
      006186 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      006189 B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      00618C 80 10            [24] 1993 	sjmp	00189$
      00618E                       1994 01298$:
      00618E C3               [12] 1995 	clr	c
      00618F E8               [12] 1996 	mov	a,r0
      006190 94 81            [12] 1997 	subb	a,#0x81
      006192 E9               [12] 1998 	mov	a,r1
      006193 94 00            [12] 1999 	subb	a,#0x00
      006195 40 51            [24] 2000 	jc	00190$
      006197 74 83            [12] 2001 	mov	a,#0x83
      006199 98               [12] 2002 	subb	a,r0
      00619A E4               [12] 2003 	clr	a
      00619B 99               [12] 2004 	subb	a,r1
      00619C 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      00619E                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      00619E 8B 01            [24] 2009 	mov	ar1,r3
      0061A0 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0061A3 EA               [12] 2012 	mov	a,r2
      0061A4 60 0B            [24] 2013 	jz	00308$
      0061A6 90 07 66         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0061A9 E0               [24] 2015 	movx	a,@dptr
      0061AA 54 01            [12] 2016 	anl	a,#0x01
      0061AC 25 E0            [12] 2017 	add	a,acc
      0061AE FA               [12] 2018 	mov	r2,a
      0061AF 80 22            [24] 2019 	sjmp	00309$
      0061B1                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0061B1 BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      0061B4 E9               [12] 2023 	mov	a,r1
      0061B5 60 18            [24] 2024 	jz	00310$
      0061B7 89 00            [24] 2025 	mov	ar0,r1
      0061B9 79 00            [12] 2026 	mov	r1,#0x00
      0061BB 74 22            [12] 2027 	mov	a,#0x22
      0061BD 29               [12] 2028 	add	a, r1
      0061BE F9               [12] 2029 	mov	r1,a
      0061BF 88 82            [24] 2030 	mov	dpl,r0
      0061C1 89 83            [24] 2031 	mov	dph,r1
      0061C3 E0               [24] 2032 	movx	a,@dptr
      0061C4 F9               [12] 2033 	mov	r1,a
      0061C5 53 01 03         [24] 2034 	anl	ar1,#0x03
      0061C8 B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      0061CB 79 01            [12] 2036 	mov	r1,#0x01
      0061CD 80 02            [24] 2037 	sjmp	00311$
      0061CF                       2038 00310$:
      0061CF 79 00            [12] 2039 	mov	r1,#0x00
      0061D1                       2040 00311$:
      0061D1 89 02            [24] 2041 	mov	ar2,r1
      0061D3                       2042 00309$:
      0061D3 90 10 00         [24] 2043 	mov	dptr,#0x1000
      0061D6 EA               [12] 2044 	mov	a,r2
      0061D7 F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0061D8 A3               [24] 2047 	inc	dptr
      0061D9 E4               [12] 2048 	clr	a
      0061DA F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0061DB 90 22 08         [24] 2051 	mov	dptr,#0x2208
      0061DE 74 02            [12] 2052 	mov	a,#0x02
      0061E0 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      0061E1 90 07 BD         [24] 2055 	mov	dptr,#_control_phase
      0061E4 F0               [24] 2056 	movx	@dptr,a
      0061E5 02 65 75         [24] 2057 	ljmp	00291$
      0061E8                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      0061E8 02 5B C6         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0061EB                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      0061EB 20 19 03         [24] 2064 	jb	_control_setup_zero_length_10000_285,01307$
      0061EE 02 62 7E         [24] 2065 	ljmp	00279$
      0061F1                       2066 01307$:
      0061F1 90 07 64         [24] 2067 	mov	dptr,#_D0UsbConfig
      0061F4 E0               [24] 2068 	movx	a,@dptr
      0061F5 70 03            [24] 2069 	jnz	01308$
      0061F7 02 62 7E         [24] 2070 	ljmp	00279$
      0061FA                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      0061FA EF               [12] 2073 	mov	a,r7
      0061FB 70 29            [24] 2074 	jnz	00218$
      0061FD 8D 01            [24] 2075 	mov	ar1,r5
      0061FF 8E 02            [24] 2076 	mov	ar2,r6
      006201 B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      006204 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      006207 30 17 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_285,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00620A 90 07 5E         [24] 2081 	mov	dptr,#_D0SetupReqCode
      00620D E0               [24] 2082 	movx	a,@dptr
      00620E FA               [12] 2083 	mov	r2,a
      00620F BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006212 90 07 66         [24] 2085 	mov	dptr,#_USB_SleepStatus
      006215 E0               [24] 2086 	movx	a,@dptr
      006216 43 E0 01         [24] 2087 	orl	acc,#0x01
      006219 F0               [24] 2088 	movx	@dptr,a
      00621A 80 59            [24] 2089 	sjmp	00219$
      00621C                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      00621C 90 07 66         [24] 2092 	mov	dptr,#_USB_SleepStatus
      00621F E0               [24] 2093 	movx	a,@dptr
      006220 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      006223 F0               [24] 2095 	movx	@dptr,a
      006224 80 4F            [24] 2096 	sjmp	00219$
      006226                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006226 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      006229 30 18 46         [24] 2100 	jnb	_control_setup_zero_value_10000_285,00212$
      00622C 8B 01            [24] 2101 	mov	ar1,r3
      00622E 8C 02            [24] 2102 	mov	ar2,r4
      006230 C3               [12] 2103 	clr	c
      006231 E9               [12] 2104 	mov	a,r1
      006232 94 81            [12] 2105 	subb	a,#0x81
      006234 EA               [12] 2106 	mov	a,r2
      006235 94 00            [12] 2107 	subb	a,#0x00
      006237 40 39            [24] 2108 	jc	00212$
      006239 74 83            [12] 2109 	mov	a,#0x83
      00623B 99               [12] 2110 	subb	a,r1
      00623C E4               [12] 2111 	clr	a
      00623D 9A               [12] 2112 	subb	a,r2
      00623E 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      006240 8B 02            [24] 2116 	mov	ar2,r3
      006242 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006245 8A 00            [24] 2119 	mov	ar0,r2
      006247 79 00            [12] 2120 	mov	r1,#0x00
      006249 74 22            [12] 2121 	mov	a,#0x22
      00624B 29               [12] 2122 	add	a, r1
      00624C F9               [12] 2123 	mov	r1,a
      00624D 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      00624F 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006251 90 07 5E         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006254 E0               [24] 2127 	movx	a,@dptr
      006255 F9               [12] 2128 	mov	r1,a
      006256 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      006259 79 03            [12] 2130 	mov	r1,#0x03
      00625B 80 02            [24] 2131 	sjmp	00319$
      00625D                       2132 00318$:
      00625D 79 02            [12] 2133 	mov	r1,#0x02
      00625F                       2134 00319$:
      00625F 43 01 10         [24] 2135 	orl	ar1,#0x10
      006262 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006265 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006268 E9               [12] 2138 	mov	a,r1
      006269 F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00626A BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      00626D 12 5B 52         [24] 2142 	lcall	_raw_complete
      006270 80 03            [24] 2143 	sjmp	00219$
      006272                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006272 02 5B C6         [24] 2146 	ljmp	_control_stall
      006275                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006275 90 07 BD         [24] 2149 	mov	dptr,#_control_phase
      006278 74 03            [12] 2150 	mov	a,#0x03
      00627A F0               [24] 2151 	movx	@dptr,a
      00627B 02 65 75         [24] 2152 	ljmp	00291$
      00627E                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00627E E4               [12] 2155 	clr	a
      00627F BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      006282 04               [12] 2157 	inc	a
      006283                       2158 01324$:
      006283 FA               [12] 2159 	mov	r2,a
      006284 70 03            [24] 2160 	jnz	01326$
      006286 02 64 F0         [24] 2161 	ljmp	00273$
      006289                       2162 01326$:
      006289 90 07 5E         [24] 2163 	mov	dptr,#_D0SetupReqCode
      00628C E0               [24] 2164 	movx	a,@dptr
      00628D F9               [12] 2165 	mov	r1,a
      00628E B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      006291 80 03            [24] 2167 	sjmp	01328$
      006293                       2168 01327$:
      006293 02 64 F0         [24] 2169 	ljmp	00273$
      006296                       2170 01328$:
      006296 90 07 64         [24] 2171 	mov	dptr,#_D0UsbConfig
      006299 E0               [24] 2172 	movx	a,@dptr
      00629A 70 03            [24] 2173 	jnz	01329$
      00629C 02 64 F0         [24] 2174 	ljmp	00273$
      00629F                       2175 01329$:
      00629F 90 07 5F         [24] 2176 	mov	dptr,#_D0SetupLen
      0062A2 E0               [24] 2177 	movx	a,@dptr
      0062A3 F8               [12] 2178 	mov	r0,a
      0062A4 A3               [24] 2179 	inc	dptr
      0062A5 E0               [24] 2180 	movx	a,@dptr
      0062A6 48               [12] 2181 	orl	a,r0
      0062A7 70 03            [24] 2182 	jnz	01330$
      0062A9 02 64 F0         [24] 2183 	ljmp	00273$
      0062AC                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0062AC C0 03            [24] 2186 	push	ar3
      0062AE C0 04            [24] 2187 	push	ar4
      0062B0 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0062B2 8E 00            [24] 2190 	mov	ar0,r6
      0062B4 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      0062B7 E8               [12] 2192 	mov	a,r0
      0062B8 80 01            [24] 2193 	sjmp	01332$
      0062BA                       2194 01331$:
      0062BA E4               [12] 2195 	clr	a
      0062BB                       2196 01332$:
      0062BB F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0062BD D0 04            [24] 2198 	pop	ar4
      0062BF D0 03            [24] 2199 	pop	ar3
      0062C1 E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0062C3 60 17            [24] 2201 	jz	00251$
      0062C5 EB               [12] 2202 	mov	a,r3
      0062C6 4C               [12] 2203 	orl	a,r4
      0062C7 70 13            [24] 2204 	jnz	00251$
      0062C9 E9               [12] 2205 	mov	a,r1
      0062CA 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0062CC 90 07 C7         [24] 2208 	mov	dptr,#_control_setup_length_10000_285
      0062CF 74 08            [12] 2209 	mov	a,#0x08
      0062D1 F0               [24] 2210 	movx	@dptr,a
      0062D2 E4               [12] 2211 	clr	a
      0062D3 A3               [24] 2212 	inc	dptr
      0062D4 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0062D5 90 07 C9         [24] 2215 	mov	dptr,#_control_setup_offset_10000_285
      0062D8 F0               [24] 2216 	movx	@dptr,a
      0062D9 02 64 60         [24] 2217 	ljmp	00252$
      0062DC                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0062DC E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      0062DE 60 27            [24] 2221 	jz	00245$
      0062E0 BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      0062E3 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0062E6 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      0062E9                       2226 01339$:
      0062E9 50 1C            [24] 2227 	jnc	00245$
      0062EB E9               [12] 2228 	mov	a,r1
      0062EC 90 BD 81         [24] 2229 	mov	dptr,#_shared_lengths
      0062EF 93               [24] 2230 	movc	a,@a+dptr
      0062F0 F8               [12] 2231 	mov	r0,a
      0062F1 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0062F3 90 07 C7         [24] 2234 	mov	dptr,#_control_setup_length_10000_285
      0062F6 E8               [12] 2235 	mov	a,r0
      0062F7 F0               [24] 2236 	movx	@dptr,a
      0062F8 E4               [12] 2237 	clr	a
      0062F9 A3               [24] 2238 	inc	dptr
      0062FA F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      0062FB E9               [12] 2241 	mov	a,r1
      0062FC 90 BD 7A         [24] 2242 	mov	dptr,#_shared_offsets
      0062FF 93               [24] 2243 	movc	a,@a+dptr
      006300 90 07 C9         [24] 2244 	mov	dptr,#_control_setup_offset_10000_285
      006303 F0               [24] 2245 	movx	@dptr,a
      006304 02 64 60         [24] 2246 	ljmp	00252$
      006307                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006307 E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      006309 60 7A            [24] 2250 	jz	00240$
      00630B BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      00630E BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      006311 E9               [12] 2253 	mov	a,r1
      006312 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006314 90 07 5F         [24] 2256 	mov	dptr,#_D0SetupLen
      006317 E0               [24] 2257 	movx	a,@dptr
      006318 F8               [12] 2258 	mov	r0,a
      006319 A3               [24] 2259 	inc	dptr
      00631A E0               [24] 2260 	movx	a,@dptr
      00631B F9               [12] 2261 	mov	r1,a
      00631C C3               [12] 2262 	clr	c
      00631D E8               [12] 2263 	mov	a,r0
      00631E 94 20            [12] 2264 	subb	a,#0x20
      006320 E9               [12] 2265 	mov	a,r1
      006321 94 00            [12] 2266 	subb	a,#0x00
      006323 50 0A            [24] 2267 	jnc	00320$
      006325 90 07 5F         [24] 2268 	mov	dptr,#_D0SetupLen
      006328 E0               [24] 2269 	movx	a,@dptr
      006329 F8               [12] 2270 	mov	r0,a
      00632A A3               [24] 2271 	inc	dptr
      00632B E0               [24] 2272 	movx	a,@dptr
      00632C F9               [12] 2273 	mov	r1,a
      00632D 80 04            [24] 2274 	sjmp	00321$
      00632F                       2275 00320$:
      00632F 78 20            [12] 2276 	mov	r0,#0x20
      006331 79 00            [12] 2277 	mov	r1,#0x00
      006333                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006333 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      006336                       2281 00293$:
      006336 C0 03            [24] 2282 	push	ar3
      006338 C0 04            [24] 2283 	push	ar4
      00633A AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      00633C 7C 00            [12] 2285 	mov	r4,#0x00
      00633E C3               [12] 2286 	clr	c
      00633F EB               [12] 2287 	mov	a,r3
      006340 98               [12] 2288 	subb	a,r0
      006341 EC               [12] 2289 	mov	a,r4
      006342 99               [12] 2290 	subb	a,r1
      006343 D0 04            [24] 2291 	pop	ar4
      006345 D0 03            [24] 2292 	pop	ar3
      006347 50 32            [24] 2293 	jnc	00222$
      006349 C0 00            [24] 2294 	push	ar0
      00634B C0 01            [24] 2295 	push	ar1
      00634D 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006350 74 10            [12] 2297 	mov	a,#0x10
      006352 24 00            [12] 2298 	add	a, #0x00
      006354 F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006356 A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      006358 79 00            [12] 2301 	mov	r1,#0x00
      00635A 74 C0            [12] 2302 	mov	a,#0xc0
      00635C 28               [12] 2303 	add	a, r0
      00635D F8               [12] 2304 	mov	r0,a
      00635E E4               [12] 2305 	clr	a
      00635F 39               [12] 2306 	addc	a, r1
      006360 F9               [12] 2307 	mov	r1,a
      006361 88 82            [24] 2308 	mov	dpl,r0
      006363 74 10            [12] 2309 	mov	a,#0x10
      006365 29               [12] 2310 	add	a, r1
      006366 F5 83            [12] 2311 	mov	dph,a
      006368 E0               [24] 2312 	movx	a,@dptr
      006369 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      00636C 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00636F F0               [24] 2315 	movx	@dptr,a
      006370 E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006372 04               [12] 2317 	inc	a
      006373 F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006375 D0 01            [24] 2319 	pop	ar1
      006377 D0 00            [24] 2320 	pop	ar0
      006379 80 BB            [24] 2321 	sjmp	00293$
      00637B                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      00637B 90 07 C7         [24] 2324 	mov	dptr,#_control_setup_length_10000_285
      00637E E4               [12] 2325 	clr	a
      00637F F0               [24] 2326 	movx	@dptr,a
      006380 A3               [24] 2327 	inc	dptr
      006381 F0               [24] 2328 	movx	@dptr,a
      006382 02 64 60         [24] 2329 	ljmp	00252$
      006385                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006385 8D 00            [24] 2332 	mov	ar0,r5
      006387 8E 01            [24] 2333 	mov	ar1,r6
      006389 B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      00638C B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      00638F EB               [12] 2336 	mov	a,r3
      006390 4C               [12] 2337 	orl	a,r4
      006391 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006393 90 07 69         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006396 E0               [24] 2341 	movx	a,@dptr
      006397 90 10 00         [24] 2342 	mov	dptr,#0x1000
      00639A F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00639B 90 07 C7         [24] 2345 	mov	dptr,#_control_setup_length_10000_285
      00639E E4               [12] 2346 	clr	a
      00639F F0               [24] 2347 	movx	@dptr,a
      0063A0 A3               [24] 2348 	inc	dptr
      0063A1 F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      0063A2 90 07 5F         [24] 2351 	mov	dptr,#_D0SetupLen
      0063A5 04               [12] 2352 	inc	a
      0063A6 F0               [24] 2353 	movx	@dptr,a
      0063A7 E4               [12] 2354 	clr	a
      0063A8 A3               [24] 2355 	inc	dptr
      0063A9 F0               [24] 2356 	movx	@dptr,a
      0063AA 02 64 60         [24] 2357 	ljmp	00252$
      0063AD                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0063AD B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      0063B0 B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      0063B3 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      0063B6 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0063B9 C0 03            [24] 2365 	push	ar3
      0063BB C0 04            [24] 2366 	push	ar4
      0063BD 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0063C0 74 06            [12] 2368 	mov	a,#0x06
      0063C2 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0063C3 90 07 69         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0063C6 E0               [24] 2372 	movx	a,@dptr
      0063C7 90 10 01         [24] 2373 	mov	dptr,#0x1001
      0063CA F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      0063CB 90 07 C7         [24] 2376 	mov	dptr,#_control_setup_length_10000_285
      0063CE E4               [12] 2377 	clr	a
      0063CF F0               [24] 2378 	movx	@dptr,a
      0063D0 A3               [24] 2379 	inc	dptr
      0063D1 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      0063D2 90 07 5F         [24] 2382 	mov	dptr,#_D0SetupLen
      0063D5 E0               [24] 2383 	movx	a,@dptr
      0063D6 FB               [12] 2384 	mov	r3,a
      0063D7 A3               [24] 2385 	inc	dptr
      0063D8 E0               [24] 2386 	movx	a,@dptr
      0063D9 FC               [12] 2387 	mov	r4,a
      0063DA C3               [12] 2388 	clr	c
      0063DB 74 02            [12] 2389 	mov	a,#0x02
      0063DD 9B               [12] 2390 	subb	a,r3
      0063DE E4               [12] 2391 	clr	a
      0063DF 9C               [12] 2392 	subb	a,r4
      0063E0 D0 04            [24] 2393 	pop	ar4
      0063E2 D0 03            [24] 2394 	pop	ar3
      0063E4 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      0063E6 90 07 5F         [24] 2397 	mov	dptr,#_D0SetupLen
      0063E9 74 02            [12] 2398 	mov	a,#0x02
      0063EB F0               [24] 2399 	movx	@dptr,a
      0063EC E4               [12] 2400 	clr	a
      0063ED A3               [24] 2401 	inc	dptr
      0063EE F0               [24] 2402 	movx	@dptr,a
      0063EF 80 6F            [24] 2403 	sjmp	00252$
      0063F1                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0063F1 B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0063F4 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0063F7 BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      0063FA BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      0063FD 90 10 00         [24] 2411 	mov	dptr,#0x1000
      006400 74 41            [12] 2412 	mov	a,#0x41
      006402 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      006403 A3               [24] 2415 	inc	dptr
      006404 74 4B            [12] 2416 	mov	a,#0x4b
      006406 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      006407 A3               [24] 2419 	inc	dptr
      006408 74 42            [12] 2420 	mov	a,#0x42
      00640A F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      00640B A3               [24] 2423 	inc	dptr
      00640C 74 54            [12] 2424 	mov	a,#0x54
      00640E F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      00640F A3               [24] 2427 	inc	dptr
      006410 74 01            [12] 2428 	mov	a,#0x01
      006412 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      006413 90 07 6A         [24] 2431 	mov	dptr,#_ak820_boot_stage
      006416 E0               [24] 2432 	movx	a,@dptr
      006417 90 10 05         [24] 2433 	mov	dptr,#0x1005
      00641A F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00641B 90 07 6B         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      00641E E0               [24] 2437 	movx	a,@dptr
      00641F 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006422 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006423 90 07 65         [24] 2441 	mov	dptr,#_USB_EnumStatus
      006426 E0               [24] 2442 	movx	a,@dptr
      006427 60 02            [24] 2443 	jz	00322$
      006429 74 01            [12] 2444 	mov	a,#0x01
      00642B                       2445 00322$:
      00642B F9               [12] 2446 	mov	r1,a
      00642C 90 07 66         [24] 2447 	mov	dptr,#_USB_SleepStatus
      00642F E0               [24] 2448 	movx	a,@dptr
      006430 54 02            [12] 2449 	anl	a,#0x02
      006432 F8               [12] 2450 	mov	r0,a
      006433 E9               [12] 2451 	mov	a,r1
      006434 42 00            [12] 2452 	orl	ar0,a
      006436 90 10 07         [24] 2453 	mov	dptr,#0x1007
      006439 E8               [12] 2454 	mov	a,r0
      00643A F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      00643B 90 07 C7         [24] 2457 	mov	dptr,#_control_setup_length_10000_285
      00643E E4               [12] 2458 	clr	a
      00643F F0               [24] 2459 	movx	@dptr,a
      006440 A3               [24] 2460 	inc	dptr
      006441 F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006442 90 07 5F         [24] 2463 	mov	dptr,#_D0SetupLen
      006445 E0               [24] 2464 	movx	a,@dptr
      006446 F8               [12] 2465 	mov	r0,a
      006447 A3               [24] 2466 	inc	dptr
      006448 E0               [24] 2467 	movx	a,@dptr
      006449 F9               [12] 2468 	mov	r1,a
      00644A C3               [12] 2469 	clr	c
      00644B 74 08            [12] 2470 	mov	a,#0x08
      00644D 98               [12] 2471 	subb	a,r0
      00644E E4               [12] 2472 	clr	a
      00644F 99               [12] 2473 	subb	a,r1
      006450 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006452 90 07 5F         [24] 2476 	mov	dptr,#_D0SetupLen
      006455 74 08            [12] 2477 	mov	a,#0x08
      006457 F0               [24] 2478 	movx	@dptr,a
      006458 E4               [12] 2479 	clr	a
      006459 A3               [24] 2480 	inc	dptr
      00645A F0               [24] 2481 	movx	@dptr,a
      00645B 80 03            [24] 2482 	sjmp	00252$
      00645D                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      00645D 02 5B C6         [24] 2485 	ljmp	_control_stall
      006460                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006460 90 07 C7         [24] 2488 	mov	dptr,#_control_setup_length_10000_285
      006463 E0               [24] 2489 	movx	a,@dptr
      006464 F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006466 A3               [24] 2491 	inc	dptr
      006467 E0               [24] 2492 	movx	a,@dptr
      006468 F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      00646A E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      00646C 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00646E 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006470 90 07 5F         [24] 2498 	mov	dptr,#_D0SetupLen
      006473 E0               [24] 2499 	movx	a,@dptr
      006474 F8               [12] 2500 	mov	r0,a
      006475 A3               [24] 2501 	inc	dptr
      006476 E0               [24] 2502 	movx	a,@dptr
      006477 F9               [12] 2503 	mov	r1,a
      006478 C3               [12] 2504 	clr	c
      006479 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      00647B 98               [12] 2506 	subb	a,r0
      00647C E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00647E 99               [12] 2508 	subb	a,r1
      00647F 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      006481 90 07 5F         [24] 2511 	mov	dptr,#_D0SetupLen
      006484 E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006486 F0               [24] 2513 	movx	@dptr,a
      006487 E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006489 A3               [24] 2515 	inc	dptr
      00648A F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00648B                       2518 00559$:
      00648B 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      00648E                       2520 00296$:
      00648E 90 07 5F         [24] 2521 	mov	dptr,#_D0SetupLen
      006491 E0               [24] 2522 	movx	a,@dptr
      006492 F8               [12] 2523 	mov	r0,a
      006493 C3               [12] 2524 	clr	c
      006494 E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006496 98               [12] 2526 	subb	a,r0
      006497 50 46            [24] 2527 	jnc	00263$
      006499 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00649C 74 10            [12] 2529 	mov	a,#0x10
      00649E 24 00            [12] 2530 	add	a, #0x00
      0064A0 F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      0064A2 90 07 C9         [24] 2532 	mov	dptr,#_control_setup_offset_10000_285
      0064A5 E0               [24] 2533 	movx	a,@dptr
      0064A6 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      0064A8 24 8F            [12] 2535 	add	a, #_input_snapshot
      0064AA F5 82            [12] 2536 	mov	dpl,a
      0064AC E4               [12] 2537 	clr	a
      0064AD 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      0064AF F5 83            [12] 2539 	mov	dph,a
      0064B1 E0               [24] 2540 	movx	a,@dptr
      0064B2 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      0064B5 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0064B8 F0               [24] 2543 	movx	@dptr,a
      0064B9 E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0064BB 04               [12] 2545 	inc	a
      0064BC F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0064BE 80 CE            [24] 2547 	sjmp	00296$
      0064C0                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0064C0 BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0064C3 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0064C6 90 07 5F         [24] 2552 	mov	dptr,#_D0SetupLen
      0064C9 E0               [24] 2553 	movx	a,@dptr
      0064CA F8               [12] 2554 	mov	r0,a
      0064CB A3               [24] 2555 	inc	dptr
      0064CC E0               [24] 2556 	movx	a,@dptr
      0064CD F9               [12] 2557 	mov	r1,a
      0064CE C3               [12] 2558 	clr	c
      0064CF 74 20            [12] 2559 	mov	a,#0x20
      0064D1 98               [12] 2560 	subb	a,r0
      0064D2 E4               [12] 2561 	clr	a
      0064D3 99               [12] 2562 	subb	a,r1
      0064D4 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      0064D6 90 07 5F         [24] 2565 	mov	dptr,#_D0SetupLen
      0064D9 74 20            [12] 2566 	mov	a,#0x20
      0064DB F0               [24] 2567 	movx	@dptr,a
      0064DC E4               [12] 2568 	clr	a
      0064DD A3               [24] 2569 	inc	dptr
      0064DE F0               [24] 2570 	movx	@dptr,a
      0064DF                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      0064DF 90 07 5F         [24] 2573 	mov	dptr,#_D0SetupLen
      0064E2 E0               [24] 2574 	movx	a,@dptr
      0064E3 90 22 08         [24] 2575 	mov	dptr,#0x2208
      0064E6 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      0064E7 90 07 BD         [24] 2578 	mov	dptr,#_control_phase
      0064EA 74 02            [12] 2579 	mov	a,#0x02
      0064EC F0               [24] 2580 	movx	@dptr,a
      0064ED 02 65 75         [24] 2581 	ljmp	00291$
      0064F0                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0064F0 EB               [12] 2584 	mov	a,r3
      0064F1 4C               [12] 2585 	orl	a,r4
      0064F2 70 37            [24] 2586 	jnz	00265$
      0064F4 90 07 64         [24] 2587 	mov	dptr,#_D0UsbConfig
      0064F7 E0               [24] 2588 	movx	a,@dptr
      0064F8 60 31            [24] 2589 	jz	00265$
      0064FA EA               [12] 2590 	mov	a,r2
      0064FB 60 2E            [24] 2591 	jz	00265$
      0064FD 90 07 5E         [24] 2592 	mov	dptr,#_D0SetupReqCode
      006500 E0               [24] 2593 	movx	a,@dptr
      006501 FA               [12] 2594 	mov	r2,a
      006502 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      006505 30 18 23         [24] 2596 	jnb	_control_setup_zero_value_10000_285,00265$
      006508 90 07 5F         [24] 2597 	mov	dptr,#_D0SetupLen
      00650B E0               [24] 2598 	movx	a,@dptr
      00650C F9               [12] 2599 	mov	r1,a
      00650D A3               [24] 2600 	inc	dptr
      00650E E0               [24] 2601 	movx	a,@dptr
      00650F FA               [12] 2602 	mov	r2,a
      006510 B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      006513 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006516 90 0D D4         [24] 2606 	mov	dptr,#_keyboard_protocol
      006519 E0               [24] 2607 	movx	a,@dptr
      00651A 90 10 00         [24] 2608 	mov	dptr,#0x1000
      00651D F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      00651E 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006521 74 01            [12] 2612 	mov	a,#0x01
      006523 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      006524 90 07 BD         [24] 2615 	mov	dptr,#_control_phase
      006527 04               [12] 2616 	inc	a
      006528 F0               [24] 2617 	movx	@dptr,a
      006529 80 4A            [24] 2618 	sjmp	00291$
      00652B                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      00652B 02 5B C6         [24] 2622 	ljmp	_control_stall
      00652E                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      00652E 30 16 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_285,00284$
      006531 90 07 64         [24] 2626 	mov	dptr,#_D0UsbConfig
      006534 E0               [24] 2627 	movx	a,@dptr
      006535 60 38            [24] 2628 	jz	00284$
      006537 BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      00653A 8E 05            [24] 2630 	mov	ar5,r6
      00653C 7E 00            [12] 2631 	mov	r6,#0x00
      00653E ED               [12] 2632 	mov	a,r5
      00653F 4E               [12] 2633 	orl	a,r6
      006540 70 2D            [24] 2634 	jnz	00284$
      006542 90 07 5F         [24] 2635 	mov	dptr,#_D0SetupLen
      006545 E0               [24] 2636 	movx	a,@dptr
      006546 FE               [12] 2637 	mov	r6,a
      006547 A3               [24] 2638 	inc	dptr
      006548 E0               [24] 2639 	movx	a,@dptr
      006549 FF               [12] 2640 	mov	r7,a
      00654A BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      00654D BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006550 EB               [12] 2644 	mov	a,r3
      006551 4C               [12] 2645 	orl	a,r4
      006552 70 07            [24] 2646 	jnz	00324$
      006554 90 06 3C         [24] 2647 	mov	dptr,#_keyboard_idle
      006557 E0               [24] 2648 	movx	a,@dptr
      006558 FF               [12] 2649 	mov	r7,a
      006559 80 02            [24] 2650 	sjmp	00325$
      00655B                       2651 00324$:
      00655B 7F 00            [12] 2652 	mov	r7,#0x00
      00655D                       2653 00325$:
      00655D 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006560 EF               [12] 2655 	mov	a,r7
      006561 F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006562 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006565 74 01            [12] 2659 	mov	a,#0x01
      006567 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      006568 90 07 BD         [24] 2662 	mov	dptr,#_control_phase
      00656B 04               [12] 2663 	inc	a
      00656C F0               [24] 2664 	movx	@dptr,a
      00656D 80 06            [24] 2665 	sjmp	00291$
      00656F                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      00656F 02 5B C6         [24] 2669 	ljmp	_control_stall
      006572                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006572 02 5B C6         [24] 2672 	ljmp	_control_stall
      006575                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006575 90 22 00         [24] 2675 	mov	dptr,#0x2200
      006578 74 C0            [12] 2676 	mov	a,#0xc0
      00657A F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      00657B 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_369'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      00657C                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      00657C 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      00657F E0               [24] 2692 	movx	a,@dptr
      006580 20 E6 01         [24] 2693 	jb	acc.6,00102$
      006583 22               [24] 2694 	ret
      006584                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006584 90 07 BD         [24] 2697 	mov	dptr,#_control_phase
      006587 E0               [24] 2698 	movx	a,@dptr
      006588 FF               [12] 2699 	mov	r7,a
      006589 BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      00658C 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      00658F E0               [24] 2702 	movx	a,@dptr
      006590 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006592 90 07 BD         [24] 2705 	mov	dptr,#_control_phase
      006595 E4               [12] 2706 	clr	a
      006596 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006597 90 22 00         [24] 2709 	mov	dptr,#0x2200
      00659A 74 02            [12] 2710 	mov	a,#0x02
      00659C F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      00659D 22               [24] 2713 	ret
      00659E                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      00659E BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      0065A1 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      0065A4 E0               [24] 2718 	movx	a,@dptr
      0065A5 FF               [12] 2719 	mov	r7,a
      0065A6 90 07 5F         [24] 2720 	mov	dptr,#_D0SetupLen
      0065A9 E0               [24] 2721 	movx	a,@dptr
      0065AA FD               [12] 2722 	mov	r5,a
      0065AB A3               [24] 2723 	inc	dptr
      0065AC E0               [24] 2724 	movx	a,@dptr
      0065AD FE               [12] 2725 	mov	r6,a
      0065AE 7C 00            [12] 2726 	mov	r4,#0x00
      0065B0 EF               [12] 2727 	mov	a,r7
      0065B1 B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      0065B4 EC               [12] 2729 	mov	a,r4
      0065B5 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      0065B8 80 03            [24] 2731 	sjmp	00107$
      0065BA                       2732 00209$:
      0065BA                       2733 00106$:
      0065BA 02 5B C6         [24] 2734 	ljmp	_control_stall
      0065BD                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0065BD 90 07 BE         [24] 2737 	mov	dptr,#_output_kind
      0065C0 E0               [24] 2738 	movx	a,@dptr
      0065C1 FF               [12] 2739 	mov	r7,a
      0065C2 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      0065C5 90 07 6C         [24] 2741 	mov	dptr,#_raw_state
      0065C8 E0               [24] 2742 	movx	a,@dptr
      0065C9 FE               [12] 2743 	mov	r6,a
      0065CA BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0065CD 7E 00            [12] 2746 	mov	r6,#0x00
      0065CF                       2747 00121$:
      0065CF EE               [12] 2748 	mov	a,r6
      0065D0 24 6D            [12] 2749 	add	a, #_raw_buffer
      0065D2 FC               [12] 2750 	mov	r4,a
      0065D3 E4               [12] 2751 	clr	a
      0065D4 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      0065D6 FD               [12] 2753 	mov	r5,a
      0065D7 8E 82            [24] 2754 	mov	dpl,r6
      0065D9 74 10            [12] 2755 	mov	a,#0x10
      0065DB 24 00            [12] 2756 	add	a, #0x00
      0065DD F5 83            [12] 2757 	mov	dph,a
      0065DF E0               [24] 2758 	movx	a,@dptr
      0065E0 8C 82            [24] 2759 	mov	dpl,r4
      0065E2 8D 83            [24] 2760 	mov	dph,r5
      0065E4 F0               [24] 2761 	movx	@dptr,a
      0065E5 0E               [12] 2762 	inc	r6
      0065E6 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      0065E9                       2764 00214$:
      0065E9 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0065EB 90 07 6C         [24] 2767 	mov	dptr,#_raw_state
      0065EE 74 02            [12] 2768 	mov	a,#0x02
      0065F0 F0               [24] 2769 	movx	@dptr,a
      0065F1 80 2B            [24] 2770 	sjmp	00119$
      0065F3                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0065F3 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0065F6 90 10 00         [24] 2775 	mov	dptr,#0x1000
      0065F9 E0               [24] 2776 	movx	a,@dptr
      0065FA 90 07 69         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      0065FD F0               [24] 2778 	movx	@dptr,a
      0065FE 80 1E            [24] 2779 	sjmp	00119$
      006600                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006600 BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      006603 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006606 E0               [24] 2784 	movx	a,@dptr
      006607 FF               [12] 2785 	mov	r7,a
      006608 90 07 BF         [24] 2786 	mov	dptr,#_output_report_id
      00660B E0               [24] 2787 	movx	a,@dptr
      00660C FE               [12] 2788 	mov	r6,a
      00660D EF               [12] 2789 	mov	a,r7
      00660E B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006611 90 10 01         [24] 2792 	mov	dptr,#0x1001
      006614 E0               [24] 2793 	movx	a,@dptr
      006615 90 07 69         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      006618 F0               [24] 2795 	movx	@dptr,a
      006619 80 03            [24] 2796 	sjmp	00119$
      00661B                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      00661B 02 5B C6         [24] 2799 	ljmp	_control_stall
      00661E                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      00661E 90 07 BE         [24] 2802 	mov	dptr,#_output_kind
      006621 E4               [12] 2803 	clr	a
      006622 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006623 90 07 5F         [24] 2806 	mov	dptr,#_D0SetupLen
      006626 F0               [24] 2807 	movx	@dptr,a
      006627 A3               [24] 2808 	inc	dptr
      006628 F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006629 90 07 BD         [24] 2811 	mov	dptr,#_control_phase
      00662C 74 03            [12] 2812 	mov	a,#0x03
      00662E F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      00662F 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006632 E4               [12] 2816 	clr	a
      006633 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006634 F5 82            [12] 2819 	mov	dpl,a
      006636 74 48            [12] 2820 	mov	a,#0x48
      006638 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006639 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      00663A                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      00663A 90 07 BD         [24] 2833 	mov	dptr,#_control_phase
      00663D E0               [24] 2834 	movx	a,@dptr
      00663E FF               [12] 2835 	mov	r7,a
      00663F BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006642 90 07 5F         [24] 2838 	mov	dptr,#_D0SetupLen
      006645 E0               [24] 2839 	movx	a,@dptr
      006646 FD               [12] 2840 	mov	r5,a
      006647 A3               [24] 2841 	inc	dptr
      006648 E0               [24] 2842 	movx	a,@dptr
      006649 4D               [12] 2843 	orl	a,r5
      00664A 70 06            [24] 2844 	jnz	00101$
      00664C 90 07 C0         [24] 2845 	mov	dptr,#_control_zlp
      00664F E0               [24] 2846 	movx	a,@dptr
      006650 60 0A            [24] 2847 	jz	00102$
      006652                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006652 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006655 E0               [24] 2851 	movx	a,@dptr
      006656 64 40            [12] 2852 	xrl	a,#0x40
      006658 F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006659 02 5B E8         [24] 2856 	ljmp	_control_next
      00665C                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      00665C 90 07 BD         [24] 2859 	mov	dptr,#_control_phase
      00665F 74 02            [12] 2860 	mov	a,#0x02
      006661 F0               [24] 2861 	movx	@dptr,a
      006662 80 18            [24] 2862 	sjmp	00110$
      006664                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006664 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006667 90 07 5E         [24] 2867 	mov	dptr,#_D0SetupReqCode
      00666A E0               [24] 2868 	movx	a,@dptr
      00666B FF               [12] 2869 	mov	r7,a
      00666C BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      00666F 90 07 5F         [24] 2871 	mov	dptr,#_D0SetupLen
      006672 E0               [24] 2872 	movx	a,@dptr
      006673 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006676 F0               [24] 2874 	movx	@dptr,a
      006677                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006677 90 07 BD         [24] 2877 	mov	dptr,#_control_phase
      00667A E4               [12] 2878 	clr	a
      00667B F0               [24] 2879 	movx	@dptr,a
      00667C                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00667C 90 22 00         [24] 2882 	mov	dptr,#0x2200
      00667F 74 82            [12] 2883 	mov	a,#0x82
      006681 F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006682 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_393'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_393'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      006683                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006683                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006683 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006686 E0               [24] 2902 	movx	a,@dptr
      006687 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      00668A 12 5B 6F         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      00668D 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006690 E4               [12] 2908 	clr	a
      006691 F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006692 90 07 66         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006695 F0               [24] 2912 	movx	@dptr,a
      006696 90 07 65         [24] 2913 	mov	dptr,#_USB_EnumStatus
      006699 F0               [24] 2914 	movx	@dptr,a
      00669A 90 07 64         [24] 2915 	mov	dptr,#_D0UsbConfig
      00669D F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      00669E 90 07 69         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      0066A1 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      0066A2 90 0D D4         [24] 2921 	mov	dptr,#_keyboard_protocol
      0066A5 04               [12] 2922 	inc	a
      0066A6 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      0066A7 90 06 3C         [24] 2925 	mov	dptr,#_keyboard_idle
      0066AA E4               [12] 2926 	clr	a
      0066AB F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      0066AC 90 07 8E         [24] 2929 	mov	dptr,#_keyboard_reset
      0066AF 04               [12] 2930 	inc	a
      0066B0 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      0066B1 90 07 5E         [24] 2933 	mov	dptr,#_D0SetupReqCode
      0066B4 74 FF            [12] 2934 	mov	a,#0xff
      0066B6 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      0066B7 90 07 5F         [24] 2937 	mov	dptr,#_D0SetupLen
      0066BA E4               [12] 2938 	clr	a
      0066BB F0               [24] 2939 	movx	@dptr,a
      0066BC A3               [24] 2940 	inc	dptr
      0066BD F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      0066BE 90 07 BD         [24] 2943 	mov	dptr,#_control_phase
      0066C1 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066C2 90 22 00         [24] 2946 	mov	dptr,#0x2200
      0066C5 74 02            [12] 2947 	mov	a,#0x02
      0066C7 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      0066C8 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      0066CB E4               [12] 2951 	clr	a
      0066CC F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      0066CD 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      0066D0 04               [12] 2955 	inc	a
      0066D1 F0               [24] 2956 	movx	@dptr,a
      0066D2 02 67 68         [24] 2957 	ljmp	00130$
      0066D5                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0066D5 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      0066D8 E0               [24] 2961 	movx	a,@dptr
      0066D9 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      0066DC 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      0066DF E0               [24] 2965 	movx	a,@dptr
      0066E0 FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      0066E1 74 07            [12] 2968 	mov	a,#0x07
      0066E3 5F               [12] 2969 	anl	a,r7
      0066E4 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      0066E5 EF               [12] 2972 	mov	a,r7
      0066E6 54 18            [12] 2973 	anl	a,#0x18
      0066E8 70 08            [24] 2974 	jnz	00115$
      0066EA EE               [12] 2975 	mov	a,r6
      0066EB 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      0066ED 12 65 7C         [24] 2978 	lcall	_control_out
      0066F0 80 43            [24] 2979 	sjmp	00116$
      0066F2                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0066F2 8F 05            [24] 2982 	mov	ar5,r7
      0066F4 74 18            [12] 2983 	mov	a,#0x18
      0066F6 5D               [12] 2984 	anl	a,r5
      0066F7 FC               [12] 2985 	mov	r4,a
      0066F8 BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      0066FB EE               [12] 2988 	mov	a,r6
      0066FC 70 05            [24] 2989 	jnz	00106$
      0066FE 12 66 3A         [24] 2990 	lcall	_control_in
      006701 80 32            [24] 2991 	sjmp	00116$
      006703                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006703 EE               [12] 2994 	mov	a,r6
      006704 24 FC            [12] 2995 	add	a,#0xff - 0x03
      006706 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006708 8E 04            [24] 2999 	mov	ar4,r6
      00670A 7B 00            [12] 3000 	mov	r3,#0x00
      00670C 74 22            [12] 3001 	mov	a,#0x22
      00670E 2B               [12] 3002 	add	a, r3
      00670F FB               [12] 3003 	mov	r3,a
      006710 8C 82            [24] 3004 	mov	dpl,r4
      006712 8B 83            [24] 3005 	mov	dph,r3
      006714 E0               [24] 3006 	movx	a,@dptr
      006715 FA               [12] 3007 	mov	r2,a
      006716 74 FC            [12] 3008 	mov	a,#0xfc
      006718 5A               [12] 3009 	anl	a,r2
      006719 44 02            [12] 3010 	orl	a,#0x02
      00671B 8C 82            [24] 3011 	mov	dpl,r4
      00671D 8B 83            [24] 3012 	mov	dph,r3
      00671F F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006720 BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006723 12 5B 52         [24] 3016 	lcall	_raw_complete
      006726 80 0D            [24] 3017 	sjmp	00116$
      006728                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006728 53 05 18         [24] 3020 	anl	ar5,#0x18
      00672B BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      00672E EF               [12] 3022 	mov	a,r7
      00672F 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006732 12 5D DF         [24] 3025 	lcall	_control_setup
      006735                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006735 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      006738 E4               [12] 3029 	clr	a
      006739 F0               [24] 3030 	movx	@dptr,a
      00673A 80 2C            [24] 3031 	sjmp	00130$
      00673C                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      00673C 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      00673F E0               [24] 3035 	movx	a,@dptr
      006740 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006743 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006746 E0               [24] 3039 	movx	a,@dptr
      006747 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      00674A 90 07 66         [24] 3041 	mov	dptr,#_USB_SleepStatus
      00674D E0               [24] 3042 	movx	a,@dptr
      00674E 43 E0 02         [24] 3043 	orl	acc,#0x02
      006751 F0               [24] 3044 	movx	@dptr,a
      006752 80 0E            [24] 3045 	sjmp	00120$
      006754                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006754 90 07 66         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006757 E0               [24] 3049 	movx	a,@dptr
      006758 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      00675B F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      00675C 90 07 8E         [24] 3053 	mov	dptr,#_keyboard_reset
      00675F 74 01            [12] 3054 	mov	a,#0x01
      006761 F0               [24] 3055 	movx	@dptr,a
      006762                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006762 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006765 74 04            [12] 3059 	mov	a,#0x04
      006767 F0               [24] 3060 	movx	@dptr,a
      006768                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006768 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      00676B E0               [24] 3064 	movx	a,@dptr
      00676C 54 25            [12] 3065 	anl	a,#0x25
      00676E 60 03            [24] 3066 	jz	00242$
      006770 02 66 83         [24] 3067 	ljmp	00129$
      006773                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006773 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006774                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3080 ;	assignBit
      006774 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006776 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      006779 E4               [12] 3084 	clr	a
      00677A F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      00677B 90 07 6C         [24] 3087 	mov	dptr,#_raw_state
      00677E F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      00677F 12 5B 6F         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006782 90 07 66         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006785 E4               [12] 3093 	clr	a
      006786 F0               [24] 3094 	movx	@dptr,a
      006787 90 07 65         [24] 3095 	mov	dptr,#_USB_EnumStatus
      00678A F0               [24] 3096 	movx	@dptr,a
      00678B 90 07 64         [24] 3097 	mov	dptr,#_D0UsbConfig
      00678E F0               [24] 3098 	movx	@dptr,a
      00678F 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006792 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006793 90 07 67         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006796 F0               [24] 3103 	movx	@dptr,a
      006797 90 07 68         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      00679A F0               [24] 3105 	movx	@dptr,a
      00679B 90 07 69         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      00679E F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      00679F 90 0D D4         [24] 3109 	mov	dptr,#_keyboard_protocol
      0067A2 04               [12] 3110 	inc	a
      0067A3 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      0067A4 90 06 3C         [24] 3113 	mov	dptr,#_keyboard_idle
      0067A7 E4               [12] 3114 	clr	a
      0067A8 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      0067A9 90 07 8E         [24] 3117 	mov	dptr,#_keyboard_reset
      0067AC F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      0067AD 90 07 BD         [24] 3120 	mov	dptr,#_control_phase
      0067B0 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      0067B1 90 07 5E         [24] 3123 	mov	dptr,#_D0SetupReqCode
      0067B4 14               [12] 3124 	dec	a
      0067B5 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      0067B6 90 07 5F         [24] 3127 	mov	dptr,#_D0SetupLen
      0067B9 E4               [12] 3128 	clr	a
      0067BA F0               [24] 3129 	movx	@dptr,a
      0067BB A3               [24] 3130 	inc	dptr
      0067BC F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0067BD 90 22 00         [24] 3133 	mov	dptr,#0x2200
      0067C0 74 02            [12] 3134 	mov	a,#0x02
      0067C2 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      0067C3 90 22 37         [24] 3137 	mov	dptr,#0x2237
      0067C6 74 7F            [12] 3138 	mov	a,#0x7f
      0067C8 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      0067C9 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      0067CC 74 FF            [12] 3142 	mov	a,#0xff
      0067CE F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0067CF 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      0067D2 74 07            [12] 3146 	mov	a,#0x07
      0067D4 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      0067D5 A3               [24] 3149 	inc	dptr
      0067D6 74 80            [12] 3150 	mov	a,#0x80
      0067D8 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3153 ;	assignBit
      0067D9 D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      0067DB 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_416'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_419'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      0067DC                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      0067DC 90 07 66         [24] 3169 	mov	dptr,#_USB_SleepStatus
      0067DF E0               [24] 3170 	movx	a,@dptr
      0067E0 FF               [12] 3171 	mov	r7,a
      0067E1 BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      0067E4 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      0067E7 E0               [24] 3175 	movx	a,@dptr
      0067E8 FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      0067E9 E0               [24] 3178 	movx	a,@dptr
      0067EA FE               [12] 3179 	mov	r6,a
      0067EB 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      0067EE 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      0067F1 EE               [12] 3182 	mov	a,r6
      0067F2 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      0067F3 7E 0A            [12] 3185 	mov	r6,#0x0a
      0067F5                       3186 00108$:
      0067F5 EE               [12] 3187 	mov	a,r6
      0067F6 60 09            [24] 3188 	jz	00105$
      0067F8 90 00 01         [24] 3189 	mov	dptr,#0x0001
      0067FB 12 59 96         [24] 3190 	lcall	_mDelaymS
      0067FE 1E               [12] 3191 	dec	r6
      0067FF 80 F4            [24] 3192 	sjmp	00108$
      006801                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006801 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      006804 EF               [12] 3196 	mov	a,r7
      006805 F0               [24] 3197 	movx	@dptr,a
      006806                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006806 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_421'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_422'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_422'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_422'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_422'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_422'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_434'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      006807                       3220 _ak820_usb_send:
      006807 E5 82            [12] 3221 	mov	a,dpl
      006809 90 07 CD         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      00680C F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      00680D 90 07 CE         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006810 74 2E            [12] 3226 	mov	a,#0x2e
      006812 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006813 90 07 CD         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006816 E0               [24] 3230 	movx	a,@dptr
      006817 FF               [12] 3231 	mov	r7,a
      006818 BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      00681B                       3233 00306$:
      00681B 40 14            [24] 3234 	jc	00101$
      00681D EF               [12] 3235 	mov	a,r7
      00681E 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006820 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006822 90 07 CC         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      006825 E0               [24] 3240 	movx	a,@dptr
      006826 FE               [12] 3241 	mov  r6,a
      006827 24 BF            [12] 3242 	add	a,#0xff - 0x40
      006829 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      00682B 90 07 65         [24] 3245 	mov	dptr,#_USB_EnumStatus
      00682E E0               [24] 3246 	movx	a,@dptr
      00682F 70 04            [24] 3247 	jnz	00102$
      006831                       3248 00101$:
      006831 75 82 00         [24] 3249 	mov	dpl, #0x00
      006834 22               [24] 3250 	ret
      006835                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006835 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006838 BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      00683B 80 04            [24] 3256 	sjmp	00107$
      00683D                       3257 00313$:
      00683D 75 82 00         [24] 3258 	mov	dpl, #0x00
      006840 22               [24] 3259 	ret
      006841                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006841 90 07 CE         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006844 E4               [12] 3263 	clr	a
      006845 F0               [24] 3264 	movx	@dptr,a
      006846 80 3C            [24] 3265 	sjmp	00119$
      006848                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006848 BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      00684B 90 07 CA         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      00684E E0               [24] 3271 	movx	a,@dptr
      00684F FD               [12] 3272 	mov	r5,a
      006850 A3               [24] 3273 	inc	dptr
      006851 E0               [24] 3274 	movx	a,@dptr
      006852 FF               [12] 3275 	mov	r7,a
      006853 8D 82            [24] 3276 	mov	dpl,r5
      006855 8F 83            [24] 3277 	mov	dph,r7
      006857 E0               [24] 3278 	movx	a,@dptr
      006858 FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006859 BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      00685C                       3282 00316$:
      00685C 50 0E            [24] 3283 	jnc	00108$
      00685E EF               [12] 3284 	mov	a,r7
      00685F 90 BD 81         [24] 3285 	mov	dptr,#_shared_lengths
      006862 93               [24] 3286 	movc	a,@a+dptr
      006863 FD               [12] 3287 	mov	r5,a
      006864 60 06            [24] 3288 	jz	00108$
      006866 EE               [12] 3289 	mov	a,r6
      006867 B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      00686A 80 04            [24] 3291 	sjmp	00109$
      00686C                       3292 00319$:
      00686C                       3293 00108$:
      00686C 75 82 00         [24] 3294 	mov	dpl, #0x00
      00686F 22               [24] 3295 	ret
      006870                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006870 EF               [12] 3298 	mov	a,r7
      006871 90 BD 7A         [24] 3299 	mov	dptr,#_shared_offsets
      006874 93               [24] 3300 	movc	a,@a+dptr
      006875 90 07 CE         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_422
      006878 F0               [24] 3302 	movx	@dptr,a
      006879 80 09            [24] 3303 	sjmp	00119$
      00687B                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      00687B BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      00687E 80 04            [24] 3307 	sjmp	00119$
      006880                       3308 00320$:
      006880 75 82 00         [24] 3309 	mov	dpl, #0x00
      006883 22               [24] 3310 	ret
      006884                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006884 90 07 66         [24] 3313 	mov	dptr,#_USB_SleepStatus
      006887 E0               [24] 3314 	movx	a,@dptr
      006888 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      00688B 12 67 DC         [24] 3316 	lcall	_USB_WakeUp_PC
      00688E 75 82 00         [24] 3317 	mov	dpl, #0x00
      006891 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006892                       3320 00184$:
      006892 7F FA            [12] 3321 	mov	r7,#0xfa
      006894                       3322 00127$:
      006894 90 07 CD         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006897 E0               [24] 3324 	movx	a,@dptr
      006898 FC               [12] 3325 	mov	r4,a
      006899 7D 00            [12] 3326 	mov	r5,#0x00
      00689B 8C 02            [24] 3327 	mov	ar2,r4
      00689D 74 22            [12] 3328 	mov	a,#0x22
      00689F 2D               [12] 3329 	add	a, r5
      0068A0 FB               [12] 3330 	mov	r3,a
      0068A1 8A 82            [24] 3331 	mov	dpl,r2
      0068A3 8B 83            [24] 3332 	mov	dph,r3
      0068A5 E0               [24] 3333 	movx	a,@dptr
      0068A6 54 03            [12] 3334 	anl	a,#0x03
      0068A8 70 20            [24] 3335 	jnz	00129$
      0068AA 8F 03            [24] 3336 	mov	ar3,r7
      0068AC 1F               [12] 3337 	dec	r7
      0068AD EB               [12] 3338 	mov	a,r3
      0068AE 60 1A            [24] 3339 	jz	00129$
      0068B0 7B 28            [12] 3340 	mov	r3,#0x28
      0068B2                       3341 00141$:
      0068B2 EB               [12] 3342 	mov	a,r3
      0068B3 60 DF            [24] 3343 	jz	00127$
      0068B5 90 00 01         [24] 3344 	mov	dptr,#0x0001
      0068B8 C0 07            [24] 3345 	push	ar7
      0068BA C0 06            [24] 3346 	push	ar6
      0068BC C0 03            [24] 3347 	push	ar3
      0068BE 12 59 5A         [24] 3348 	lcall	_mDelayuS
      0068C1 D0 03            [24] 3349 	pop	ar3
      0068C3 D0 06            [24] 3350 	pop	ar6
      0068C5 D0 07            [24] 3351 	pop	ar7
      0068C7 1B               [12] 3352 	dec	r3
      0068C8 80 E8            [24] 3353 	sjmp	00141$
      0068CA                       3354 00129$:
                                   3355 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      0068CA A2 AF            [12] 3356 	mov	c,_EA
      0068CC E4               [12] 3357 	clr	a
      0068CD 33               [12] 3358 	rlc	a
      0068CE FF               [12] 3359 	mov	r7,a
                                   3360 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3361 ;	assignBit
      0068CF C2 AF            [12] 3362 	clr	_EA
                                   3363 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      0068D1 90 07 65         [24] 3364 	mov	dptr,#_USB_EnumStatus
      0068D4 E0               [24] 3365 	movx	a,@dptr
      0068D5 60 25            [24] 3366 	jz	00130$
      0068D7 90 07 CD         [24] 3367 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      0068DA E0               [24] 3368 	movx	a,@dptr
      0068DB FB               [12] 3369 	mov	r3,a
      0068DC F9               [12] 3370 	mov	r1,a
      0068DD 7A 00            [12] 3371 	mov	r2,#0x00
      0068DF 74 22            [12] 3372 	mov	a,#0x22
      0068E1 2A               [12] 3373 	add	a, r2
      0068E2 FA               [12] 3374 	mov	r2,a
      0068E3 89 82            [24] 3375 	mov	dpl,r1
      0068E5 8A 83            [24] 3376 	mov	dph,r2
      0068E7 E0               [24] 3377 	movx	a,@dptr
      0068E8 FA               [12] 3378 	mov	r2,a
      0068E9 53 02 03         [24] 3379 	anl	ar2,#0x03
      0068EC BA 02 0D         [24] 3380 	cjne	r2,#0x02,00130$
                                   3381 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      0068EF BB 03 13         [24] 3382 	cjne	r3,#0x03,00192$
      0068F2 90 07 6C         [24] 3383 	mov	dptr,#_raw_state
      0068F5 E0               [24] 3384 	movx	a,@dptr
      0068F6 FB               [12] 3385 	mov	r3,a
      0068F7 BB 03 02         [24] 3386 	cjne	r3,#0x03,00331$
      0068FA 80 09            [24] 3387 	sjmp	00192$
      0068FC                       3388 00331$:
      0068FC                       3389 00130$:
                                   3390 ;	assignBit
      0068FC EF               [12] 3391 	mov	a,r7
      0068FD 24 FF            [12] 3392 	add	a,#0xff
      0068FF 92 AF            [24] 3393 	mov	_EA,c
      006901 75 82 00         [24] 3394 	mov	dpl, #0x00
      006904 22               [24] 3395 	ret
                                   3396 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006905                       3397 00192$:
      006905 7B 00            [12] 3398 	mov	r3,#0x00
      006907                       3399 00144$:
      006907 C3               [12] 3400 	clr	c
      006908 EB               [12] 3401 	mov	a,r3
      006909 9E               [12] 3402 	subb	a,r6
      00690A 50 67            [24] 3403 	jnc	00137$
                                   3404 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      00690C C0 07            [24] 3405 	push	ar7
      00690E 90 07 CD         [24] 3406 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006911 E0               [24] 3407 	movx	a,@dptr
      006912 F9               [12] 3408 	mov	r1,a
      006913 E4               [12] 3409 	clr	a
      006914 C3               [12] 3410 	clr	c
      006915 C9               [12] 3411 	xch	a,r1
      006916 13               [12] 3412 	rrc	a
      006917 C9               [12] 3413 	xch	a,r1
      006918 13               [12] 3414 	rrc	a
      006919 A2 E0            [12] 3415 	mov	c,acc.0
      00691B C9               [12] 3416 	xch	a,r1
      00691C 13               [12] 3417 	rrc	a
      00691D C9               [12] 3418 	xch	a,r1
      00691E 13               [12] 3419 	rrc	a
      00691F C9               [12] 3420 	xch	a,r1
      006920 FA               [12] 3421 	mov	r2,a
      006921 8B 00            [24] 3422 	mov	ar0,r3
      006923 7F 00            [12] 3423 	mov	r7,#0x00
      006925 E8               [12] 3424 	mov	a,r0
      006926 29               [12] 3425 	add	a, r1
      006927 F9               [12] 3426 	mov	r1,a
      006928 EF               [12] 3427 	mov	a,r7
      006929 3A               [12] 3428 	addc	a, r2
      00692A 24 10            [12] 3429 	add	a,#0x10
      00692C FA               [12] 3430 	mov	r2,a
      00692D 90 07 CA         [24] 3431 	mov	dptr,#_ak820_usb_send_PARM_2
      006930 E0               [24] 3432 	movx	a,@dptr
      006931 F8               [12] 3433 	mov	r0,a
      006932 A3               [24] 3434 	inc	dptr
      006933 E0               [24] 3435 	movx	a,@dptr
      006934 FF               [12] 3436 	mov	r7,a
      006935 EB               [12] 3437 	mov	a,r3
      006936 28               [12] 3438 	add	a, r0
      006937 F5 1B            [12] 3439 	mov	_ak820_usb_send_sloc0_1_0,a
      006939 E4               [12] 3440 	clr	a
      00693A 3F               [12] 3441 	addc	a, r7
      00693B F5 1C            [12] 3442 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      00693D 85 1B 82         [24] 3443 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006940 85 1C 83         [24] 3444 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006943 E0               [24] 3445 	movx	a,@dptr
      006944 89 82            [24] 3446 	mov	dpl,r1
      006946 8A 83            [24] 3447 	mov	dph,r2
      006948 F0               [24] 3448 	movx	@dptr,a
                                   3449 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006949 90 07 CE         [24] 3450 	mov	dptr,#_ak820_usb_send_offset_10000_422
      00694C E0               [24] 3451 	movx	a,@dptr
      00694D F5 1D            [12] 3452 	mov	_ak820_usb_send_sloc1_1_0,a
      00694F 74 2E            [12] 3453 	mov	a,#0x2e
      006951 B5 1D 04         [24] 3454 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006954 D0 07            [24] 3455 	pop	ar7
      006956 80 18            [24] 3456 	sjmp	00145$
      006958                       3457 00333$:
      006958 D0 07            [24] 3458 	pop	ar7
      00695A EB               [12] 3459 	mov	a,r3
      00695B 25 1D            [12] 3460 	add	a, _ak820_usb_send_sloc1_1_0
      00695D 24 8F            [12] 3461 	add	a, #_input_snapshot
      00695F F9               [12] 3462 	mov	r1,a
      006960 E4               [12] 3463 	clr	a
      006961 34 07            [12] 3464 	addc	a,#(_input_snapshot >> 8)
      006963 FA               [12] 3465 	mov	r2,a
      006964 85 1B 82         [24] 3466 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006967 85 1C 83         [24] 3467 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00696A E0               [24] 3468 	movx	a,@dptr
      00696B 89 82            [24] 3469 	mov	dpl,r1
      00696D 8A 83            [24] 3470 	mov	dph,r2
      00696F F0               [24] 3471 	movx	@dptr,a
      006970                       3472 00145$:
                                   3473 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006970 0B               [12] 3474 	inc	r3
      006971 80 94            [24] 3475 	sjmp	00144$
      006973                       3476 00137$:
                                   3477 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006973 90 07 CD         [24] 3478 	mov	dptr,#_ak820_usb_send_endpoint_10000_421
      006976 E0               [24] 3479 	movx	a,@dptr
      006977 FB               [12] 3480 	mov	r3,a
      006978 F9               [12] 3481 	mov	r1,a
      006979 7A 00            [12] 3482 	mov	r2,#0x00
      00697B 74 08            [12] 3483 	mov	a,#0x08
      00697D 29               [12] 3484 	add	a, r1
      00697E F9               [12] 3485 	mov	r1,a
      00697F 74 22            [12] 3486 	mov	a,#0x22
      006981 3A               [12] 3487 	addc	a, r2
      006982 FA               [12] 3488 	mov	r2,a
      006983 89 82            [24] 3489 	mov	dpl,r1
      006985 8A 83            [24] 3490 	mov	dph,r2
      006987 EE               [12] 3491 	mov	a,r6
      006988 F0               [24] 3492 	movx	@dptr,a
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006989 BB 03 06         [24] 3494 	cjne	r3,#0x03,00139$
      00698C 90 07 6C         [24] 3495 	mov	dptr,#_raw_state
      00698F 74 04            [12] 3496 	mov	a,#0x04
      006991 F0               [24] 3497 	movx	@dptr,a
      006992                       3498 00139$:
                                   3499 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006992 74 22            [12] 3500 	mov	a,#0x22
      006994 2D               [12] 3501 	add	a, r5
      006995 FD               [12] 3502 	mov	r5,a
      006996 8C 82            [24] 3503 	mov	dpl,r4
      006998 8D 83            [24] 3504 	mov	dph,r5
      00699A E0               [24] 3505 	movx	a,@dptr
      00699B FE               [12] 3506 	mov	r6,a
      00699C 53 06 FC         [24] 3507 	anl	ar6,#0xfc
      00699F 8C 82            [24] 3508 	mov	dpl,r4
      0069A1 8D 83            [24] 3509 	mov	dph,r5
      0069A3 EE               [12] 3510 	mov	a,r6
      0069A4 F0               [24] 3511 	movx	@dptr,a
                                   3512 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3513 ;	assignBit
      0069A5 EF               [12] 3514 	mov	a,r7
      0069A6 24 FF            [12] 3515 	add	a,#0xff
      0069A8 92 AF            [24] 3516 	mov	_EA,c
                                   3517 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      0069AA 75 82 01         [24] 3518 	mov	dpl, #0x01
                                   3519 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      0069AD 22               [24] 3520 	ret
                                   3521 ;------------------------------------------------------------
                                   3522 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3523 ;------------------------------------------------------------
                                   3524 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3525 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3526 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_442'
                                   3527 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_443'
                                   3528 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_443'
                                   3529 ;------------------------------------------------------------
                                   3530 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3531 ;	-----------------------------------------
                                   3532 ;	 function ak820_usb_try_send
                                   3533 ;	-----------------------------------------
      0069AE                       3534 _ak820_usb_try_send:
      0069AE E5 82            [12] 3535 	mov	a,dpl
      0069B0 90 07 D2         [24] 3536 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_442
      0069B3 F0               [24] 3537 	movx	@dptr,a
                                   3538 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3539 ;	assignBit
      0069B4 A2 AF            [12] 3540 	mov	c,_EA
      0069B6 92 1C            [24] 3541 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3542 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      0069B8 90 07 D3         [24] 3543 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      0069BB E4               [12] 3544 	clr	a
      0069BC F0               [24] 3545 	movx	@dptr,a
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3547 ;	assignBit
      0069BD C2 AF            [12] 3548 	clr	_EA
                                   3549 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0069BF 90 07 D2         [24] 3550 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_442
      0069C2 E0               [24] 3551 	movx	a,@dptr
      0069C3 FF               [12] 3552 	mov	r7,a
      0069C4 BF 01 00         [24] 3553 	cjne	r7,#0x01,00152$
      0069C7                       3554 00152$:
      0069C7 40 4E            [24] 3555 	jc	00102$
      0069C9 EF               [12] 3556 	mov	a,r7
      0069CA 24 FD            [12] 3557 	add	a,#0xff - 0x02
      0069CC 40 49            [24] 3558 	jc	00102$
                                   3559 ;	free result
      0069CE 90 07 65         [24] 3560 	mov	dptr,#_USB_EnumStatus
      0069D1 E0               [24] 3561 	movx	a,@dptr
      0069D2 60 43            [24] 3562 	jz	00102$
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      0069D4 90 07 66         [24] 3564 	mov	dptr,#_USB_SleepStatus
      0069D7 E0               [24] 3565 	movx	a,@dptr
      0069D8 20 E1 3C         [24] 3566 	jb	acc.1,00102$
      0069DB 90 07 8E         [24] 3567 	mov	dptr,#_keyboard_reset
      0069DE E0               [24] 3568 	movx	a,@dptr
                                   3569 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      0069DF 70 36            [24] 3570 	jnz	00102$
      0069E1 8F 06            [24] 3571 	mov	ar6,r7
      0069E3 24 22            [12] 3572 	add	a,#0x22
      0069E5 FD               [12] 3573 	mov	r5,a
      0069E6 8E 82            [24] 3574 	mov	dpl,r6
      0069E8 8D 83            [24] 3575 	mov	dph,r5
      0069EA E0               [24] 3576 	movx	a,@dptr
      0069EB FE               [12] 3577 	mov	r6,a
      0069EC 53 06 03         [24] 3578 	anl	ar6,#0x03
      0069EF BE 02 25         [24] 3579 	cjne	r6,#0x02,00102$
                                   3580 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      0069F2 90 07 CF         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_2
      0069F5 E0               [24] 3582 	movx	a,@dptr
      0069F6 FD               [12] 3583 	mov	r5,a
      0069F7 A3               [24] 3584 	inc	dptr
      0069F8 E0               [24] 3585 	movx	a,@dptr
      0069F9 FE               [12] 3586 	mov	r6,a
      0069FA 90 07 D1         [24] 3587 	mov	dptr,#_ak820_usb_try_send_PARM_3
      0069FD E0               [24] 3588 	movx	a,@dptr
      0069FE FC               [12] 3589 	mov	r4,a
      0069FF 90 07 CA         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_2
      006A02 ED               [12] 3591 	mov	a,r5
      006A03 F0               [24] 3592 	movx	@dptr,a
      006A04 EE               [12] 3593 	mov	a,r6
      006A05 A3               [24] 3594 	inc	dptr
      006A06 F0               [24] 3595 	movx	@dptr,a
      006A07 90 07 CC         [24] 3596 	mov	dptr,#_ak820_usb_send_PARM_3
      006A0A EC               [12] 3597 	mov	a,r4
      006A0B F0               [24] 3598 	movx	@dptr,a
      006A0C 8F 82            [24] 3599 	mov	dpl, r7
      006A0E 12 68 07         [24] 3600 	lcall	_ak820_usb_send
      006A11 E5 82            [12] 3601 	mov	a, dpl
      006A13 90 07 D3         [24] 3602 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      006A16 F0               [24] 3603 	movx	@dptr,a
      006A17                       3604 00102$:
                                   3605 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3606 ;	assignBit
      006A17 A2 1C            [12] 3607 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006A19 92 AF            [24] 3608 	mov	_EA,c
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006A1B 90 07 D3         [24] 3610 	mov	dptr,#_ak820_usb_try_send_sent_10000_443
      006A1E E0               [24] 3611 	movx	a,@dptr
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006A1F F5 82            [12] 3613 	mov	dpl,a
      006A21 22               [24] 3614 	ret
                                   3615 ;------------------------------------------------------------
                                   3616 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3617 ;------------------------------------------------------------
                                   3618 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3619 ;	-----------------------------------------
                                   3620 ;	 function raw_request_is_nonpersistent
                                   3621 ;	-----------------------------------------
      006A22                       3622 _raw_request_is_nonpersistent:
                                   3623 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006A22 90 07 6D         [24] 3624 	mov	dptr,#_raw_buffer
      006A25 E0               [24] 3625 	movx	a,@dptr
      006A26 FF               [12] 3626 	mov	r7,a
      006A27 BF 01 02         [24] 3627 	cjne	r7,#0x01,00302$
      006A2A 80 35            [24] 3628 	sjmp	00108$
      006A2C                       3629 00302$:
      006A2C BF 02 02         [24] 3630 	cjne	r7,#0x02,00303$
      006A2F 80 34            [24] 3631 	sjmp	00109$
      006A31                       3632 00303$:
      006A31 BF 04 02         [24] 3633 	cjne	r7,#0x04,00304$
      006A34 80 2B            [24] 3634 	sjmp	00108$
      006A36                       3635 00304$:
      006A36 BF 08 02         [24] 3636 	cjne	r7,#0x08,00305$
      006A39 80 47            [24] 3637 	sjmp	00116$
      006A3B                       3638 00305$:
      006A3B BF 0B 02         [24] 3639 	cjne	r7,#0x0b,00306$
      006A3E 80 21            [24] 3640 	sjmp	00108$
      006A40                       3641 00306$:
      006A40 BF 0C 02         [24] 3642 	cjne	r7,#0x0c,00307$
      006A43 80 1C            [24] 3643 	sjmp	00108$
      006A45                       3644 00307$:
      006A45 BF 0D 02         [24] 3645 	cjne	r7,#0x0d,00308$
      006A48 80 17            [24] 3646 	sjmp	00108$
      006A4A                       3647 00308$:
      006A4A BF 0E 02         [24] 3648 	cjne	r7,#0x0e,00309$
      006A4D 80 12            [24] 3649 	sjmp	00108$
      006A4F                       3650 00309$:
      006A4F BF 11 02         [24] 3651 	cjne	r7,#0x11,00310$
      006A52 80 0D            [24] 3652 	sjmp	00108$
      006A54                       3653 00310$:
      006A54 BF 12 02         [24] 3654 	cjne	r7,#0x12,00311$
      006A57 80 08            [24] 3655 	sjmp	00108$
      006A59                       3656 00311$:
      006A59 BF FE 02         [24] 3657 	cjne	r7,#0xfe,00312$
      006A5C 80 46            [24] 3658 	sjmp	00124$
      006A5E                       3659 00312$:
      006A5E 02 6A F9         [24] 3660 	ljmp	00144$
                                   3661 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006A61                       3662 00108$:
                                   3663 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006A61 75 82 01         [24] 3664 	mov	dpl, #0x01
      006A64 22               [24] 3665 	ret
                                   3666 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006A65                       3667 00109$:
                                   3668 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006A65 12 6D 2B         [24] 3669 	lcall	_ak820_outline_0168
      006A68 BF 01 02         [24] 3670 	cjne	r7,#0x01,00313$
      006A6B 80 0D            [24] 3671 	sjmp	00113$
      006A6D                       3672 00313$:
      006A6D BF 02 02         [24] 3673 	cjne	r7,#0x02,00314$
      006A70 80 08            [24] 3674 	sjmp	00113$
      006A72                       3675 00314$:
      006A72 BF 03 02         [24] 3676 	cjne	r7,#0x03,00315$
      006A75 80 03            [24] 3677 	sjmp	00113$
      006A77                       3678 00315$:
      006A77 BF 04 04         [24] 3679 	cjne	r7,#0x04,00114$
                                   3680 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006A7A                       3681 00113$:
                                   3682 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006A7A 75 82 01         [24] 3683 	mov	dpl, #0x01
      006A7D 22               [24] 3684 	ret
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006A7E                       3686 00114$:
      006A7E 75 82 00         [24] 3687 	mov	dpl, #0x00
      006A81 22               [24] 3688 	ret
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006A82                       3690 00116$:
                                   3691 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006A82 12 6D 2B         [24] 3692 	lcall	_ak820_outline_0168
      006A85 BF 40 02         [24] 3693 	cjne	r7,#0x40,00318$
      006A88 80 12            [24] 3694 	sjmp	00121$
      006A8A                       3695 00318$:
      006A8A BF 41 02         [24] 3696 	cjne	r7,#0x41,00319$
      006A8D 80 0D            [24] 3697 	sjmp	00121$
      006A8F                       3698 00319$:
      006A8F BF 42 02         [24] 3699 	cjne	r7,#0x42,00320$
      006A92 80 08            [24] 3700 	sjmp	00121$
      006A94                       3701 00320$:
      006A94 BF 43 02         [24] 3702 	cjne	r7,#0x43,00321$
      006A97 80 03            [24] 3703 	sjmp	00121$
      006A99                       3704 00321$:
      006A99 BF 44 04         [24] 3705 	cjne	r7,#0x44,00122$
                                   3706 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006A9C                       3707 00121$:
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006A9C 75 82 01         [24] 3709 	mov	dpl, #0x01
                                   3710 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006A9F 22               [24] 3711 	ret
      006AA0                       3712 00122$:
      006AA0 75 82 00         [24] 3713 	mov	dpl, #0x00
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006AA3 22               [24] 3715 	ret
      006AA4                       3716 00124$:
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006AA4 12 6D 2B         [24] 3718 	lcall	_ak820_outline_0168
      006AA7 24 F2            [12] 3719 	add	a,#0xff - 0x0d
      006AA9 40 4A            [24] 3720 	jc	00142$
                                   3721 ;	free result
      006AAB EF               [12] 3722 	mov	a,r7
      006AAC 24 0A            [12] 3723 	add	a,#(00325$-3-.)
      006AAE 83               [24] 3724 	movc	a,@a+pc
      006AAF F5 82            [12] 3725 	mov	dpl,a
      006AB1 EF               [12] 3726 	mov	a,r7
      006AB2 24 12            [12] 3727 	add	a,#(00326$-3-.)
      006AB4 83               [24] 3728 	movc	a,@a+pc
      006AB5 F5 83            [12] 3729 	mov	dph,a
      006AB7 E4               [12] 3730 	clr	a
      006AB8 73               [24] 3731 	jmp	@a+dptr
      006AB9                       3732 00325$:
      006AB9 D5                    3733 	.db	00134$
      006ABA D5                    3734 	.db	00134$
      006ABB D5                    3735 	.db	00134$
      006ABC D5                    3736 	.db	00134$
      006ABD F5                    3737 	.db	00142$
      006ABE D5                    3738 	.db	00134$
      006ABF D5                    3739 	.db	00134$
      006AC0 D5                    3740 	.db	00134$
      006AC1 D5                    3741 	.db	00134$
      006AC2 D5                    3742 	.db	00134$
      006AC3 D5                    3743 	.db	00134$
      006AC4 F5                    3744 	.db	00142$
      006AC5 F5                    3745 	.db	00142$
      006AC6 D9                    3746 	.db	00135$
      006AC7                       3747 00326$:
      006AC7 6A                    3748 	.db	00134$>>8
      006AC8 6A                    3749 	.db	00134$>>8
      006AC9 6A                    3750 	.db	00134$>>8
      006ACA 6A                    3751 	.db	00134$>>8
      006ACB 6A                    3752 	.db	00142$>>8
      006ACC 6A                    3753 	.db	00134$>>8
      006ACD 6A                    3754 	.db	00134$>>8
      006ACE 6A                    3755 	.db	00134$>>8
      006ACF 6A                    3756 	.db	00134$>>8
      006AD0 6A                    3757 	.db	00134$>>8
      006AD1 6A                    3758 	.db	00134$>>8
      006AD2 6A                    3759 	.db	00142$>>8
      006AD3 6A                    3760 	.db	00142$>>8
      006AD4 6A                    3761 	.db	00135$>>8
                                   3762 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006AD5                       3763 00134$:
                                   3764 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006AD5 75 82 01         [24] 3765 	mov	dpl, #0x01
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006AD8 22               [24] 3767 	ret
      006AD9                       3768 00135$:
                                   3769 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006AD9 90 07 6F         [24] 3770 	mov	dptr,#(_raw_buffer + 0x0002)
      006ADC E0               [24] 3771 	movx	a,@dptr
      006ADD FF               [12] 3772 	mov	r7,a
      006ADE 60 0D            [24] 3773 	jz	00139$
      006AE0 BF 01 02         [24] 3774 	cjne	r7,#0x01,00328$
      006AE3 80 08            [24] 3775 	sjmp	00139$
      006AE5                       3776 00328$:
      006AE5 BF 03 02         [24] 3777 	cjne	r7,#0x03,00329$
      006AE8 80 03            [24] 3778 	sjmp	00139$
      006AEA                       3779 00329$:
      006AEA BF 05 04         [24] 3780 	cjne	r7,#0x05,00140$
                                   3781 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006AED                       3782 00139$:
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006AED 75 82 01         [24] 3784 	mov	dpl, #0x01
                                   3785 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006AF0 22               [24] 3786 	ret
      006AF1                       3787 00140$:
      006AF1 75 82 00         [24] 3788 	mov	dpl, #0x00
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006AF4 22               [24] 3790 	ret
      006AF5                       3791 00142$:
      006AF5 75 82 00         [24] 3792 	mov	dpl, #0x00
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006AF8 22               [24] 3794 	ret
      006AF9                       3795 00144$:
      006AF9 75 82 00         [24] 3796 	mov	dpl, #0x00
                                   3797 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3798 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006AFC 22               [24] 3799 	ret
                                   3800 ;------------------------------------------------------------
                                   3801 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3802 ;------------------------------------------------------------
                                   3803 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3804 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_458'
                                   3805 ;------------------------------------------------------------
                                   3806 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3807 ;	-----------------------------------------
                                   3808 ;	 function ak820_usb_raw_send
                                   3809 ;	-----------------------------------------
      006AFD                       3810 _ak820_usb_raw_send:
      006AFD 12 43 80         [24] 3811 	lcall	_ak820_outline_0036
      006B00 90 07 D5         [24] 3812 	mov	dptr,#_ak820_usb_raw_send_report_10000_458
      006B03 12 38 8B         [24] 3813 	lcall	_ak820_outline_0017
                                   3814 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006B06 90 07 D4         [24] 3815 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006B09 E0               [24] 3816 	movx	a,@dptr
      006B0A FF               [12] 3817 	mov	r7,a
      006B0B BF 20 2B         [24] 3818 	cjne	r7,#0x20,00106$
                                   3819 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006B0E C0 07            [24] 3820 	push	ar7
      006B10 12 3E 96         [24] 3821 	lcall	_ak820_nvm_flush
      006B13 D0 07            [24] 3822 	pop	ar7
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006B15 90 07 8D         [24] 3824 	mov	dptr,#_raw_reply_without_nvm
      006B18 E0               [24] 3825 	movx	a,@dptr
      006B19 70 07            [24] 3826 	jnz	00103$
      006B1B 12 3E 87         [24] 3827 	lcall	_ak820_nvm_ok
      006B1E E5 82            [12] 3828 	mov	a, dpl
      006B20 60 17            [24] 3829 	jz	00106$
      006B22                       3830 00103$:
      006B22 90 07 D5         [24] 3831 	mov	dptr,#_ak820_usb_raw_send_report_10000_458
      006B25 12 38 EC         [24] 3832 	lcall	_ak820_outline_0089
      006B28 90 07 CA         [24] 3833 	mov	dptr,#_ak820_usb_send_PARM_2
      006B2B 12 43 C9         [24] 3834 	lcall	_ak820_outline_0126
      006B2E 90 07 CC         [24] 3835 	mov	dptr,#_ak820_usb_send_PARM_3
      006B31 EF               [12] 3836 	mov	a,r7
      006B32 F0               [24] 3837 	movx	@dptr,a
      006B33 75 82 03         [24] 3838 	mov	dpl, #0x03
                                   3839 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006B36 02 68 07         [24] 3840 	ljmp	_ak820_usb_send
      006B39                       3841 00106$:
      006B39 22               [24] 3842 	ret
                                   3843 ;------------------------------------------------------------
                                   3844 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3845 ;------------------------------------------------------------
                                   3846 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3847 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_463'
                                   3848 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_463'
                                   3849 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_463'
                                   3850 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_463'
                                   3851 ;------------------------------------------------------------
                                   3852 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3853 ;	-----------------------------------------
                                   3854 ;	 function ak820_usb_raw_task
                                   3855 ;	-----------------------------------------
      006B3A                       3856 _ak820_usb_raw_task:
                                   3857 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006B3A A2 AF            [12] 3858 	mov	c,_EA
      006B3C E4               [12] 3859 	clr	a
      006B3D 33               [12] 3860 	rlc	a
      006B3E FF               [12] 3861 	mov	r7,a
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3863 ;	assignBit
      006B3F C2 AF            [12] 3864 	clr	_EA
                                   3865 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006B41 90 07 65         [24] 3866 	mov	dptr,#_USB_EnumStatus
      006B44 E0               [24] 3867 	movx	a,@dptr
      006B45 60 0A            [24] 3868 	jz	00101$
      006B47 90 07 6C         [24] 3869 	mov	dptr,#_raw_state
      006B4A E0               [24] 3870 	movx	a,@dptr
      006B4B FE               [12] 3871 	mov	r6,a
      006B4C BE 02 02         [24] 3872 	cjne	r6,#0x02,00270$
      006B4F 80 06            [24] 3873 	sjmp	00102$
      006B51                       3874 00270$:
      006B51                       3875 00101$:
                                   3876 ;	assignBit
      006B51 EF               [12] 3877 	mov	a,r7
      006B52 24 FF            [12] 3878 	add	a,#0xff
      006B54 92 AF            [24] 3879 	mov	_EA,c
      006B56 22               [24] 3880 	ret
      006B57                       3881 00102$:
                                   3882 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006B57 90 07 6C         [24] 3883 	mov	dptr,#_raw_state
      006B5A 74 03            [12] 3884 	mov	a,#0x03
      006B5C F0               [24] 3885 	movx	@dptr,a
                                   3886 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3887 ;	assignBit
      006B5D EF               [12] 3888 	mov	a,r7
      006B5E 24 FF            [12] 3889 	add	a,#0xff
      006B60 92 AF            [24] 3890 	mov	_EA,c
                                   3891 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006B62 90 07 6D         [24] 3892 	mov	dptr,#_raw_buffer
      006B65 E0               [24] 3893 	movx	a,@dptr
      006B66 FF               [12] 3894 	mov	r7,a
      006B67 E4               [12] 3895 	clr	a
      006B68 BF FD 01         [24] 3896 	cjne	r7,#0xfd,00271$
      006B6B 04               [12] 3897 	inc	a
      006B6C                       3898 00271$:
      006B6C FF               [12] 3899 	mov	r7,a
      006B6D 70 03            [24] 3900 	jnz	00273$
      006B6F 02 6C 0E         [24] 3901 	ljmp	00118$
      006B72                       3902 00273$:
      006B72 90 07 6E         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0001)
      006B75 E0               [24] 3904 	movx	a,@dptr
      006B76 60 03            [24] 3905 	jz	00274$
      006B78 02 6C 0E         [24] 3906 	ljmp	00118$
      006B7B                       3907 00274$:
                                   3908 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006B7B 90 07 6F         [24] 3909 	mov	dptr,#(_raw_buffer + 0x0002)
      006B7E E0               [24] 3910 	movx	a,@dptr
      006B7F FD               [12] 3911 	mov	r5,a
      006B80 7E 00            [12] 3912 	mov	r6,#0x00
      006B82 90 07 70         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0003)
      006B85 E0               [24] 3914 	movx	a,@dptr
      006B86 7B 00            [12] 3915 	mov	r3,#0x00
      006B88 42 06            [12] 3916 	orl	ar6,a
      006B8A EB               [12] 3917 	mov	a,r3
      006B8B 42 05            [12] 3918 	orl	ar5,a
                                   3919 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006B8D 90 07 71         [24] 3920 	mov	dptr,#(_raw_buffer + 0x0004)
      006B90 E0               [24] 3921 	movx	a,@dptr
      006B91 FC               [12] 3922 	mov	r4,a
                                   3923 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006B92 7B 05            [12] 3924 	mov	r3,#0x05
      006B94                       3925 00128$:
      006B94 EB               [12] 3926 	mov	a,r3
      006B95 12 6D 18         [24] 3927 	lcall	_ak820_outline_0111
      006B98 0B               [12] 3928 	inc	r3
      006B99 BB 20 00         [24] 3929 	cjne	r3,#0x20,00275$
      006B9C                       3930 00275$:
      006B9C 40 F6            [24] 3931 	jc	00128$
                                   3932 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006B9E EC               [12] 3933 	mov	a,r4
      006B9F 24 E4            [12] 3934 	add	a,#0xff - 0x1b
      006BA1 40 1C            [24] 3935 	jc	00106$
                                   3936 ;	free result
      006BA3 EC               [12] 3937 	mov	a,r4
      006BA4 60 26            [24] 3938 	jz	00165$
      006BA6 8C 03            [24] 3939 	mov	ar3,r4
      006BA8 1B               [12] 3940 	dec	r3
      006BA9 7A 00            [12] 3941 	mov	r2,#0x00
      006BAB 74 FF            [12] 3942 	mov	a,#0xff
      006BAD C3               [12] 3943 	clr	c
      006BAE 9B               [12] 3944 	subb	a,r3
      006BAF FB               [12] 3945 	mov	r3,a
      006BB0 74 FF            [12] 3946 	mov	a,#0xff
      006BB2 9A               [12] 3947 	subb	a,r2
      006BB3 FA               [12] 3948 	mov	r2,a
      006BB4 8E 00            [24] 3949 	mov	ar0,r6
      006BB6 8D 01            [24] 3950 	mov	ar1,r5
      006BB8 C3               [12] 3951 	clr	c
      006BB9 EB               [12] 3952 	mov	a,r3
      006BBA 98               [12] 3953 	subb	a,r0
      006BBB EA               [12] 3954 	mov	a,r2
      006BBC 99               [12] 3955 	subb	a,r1
      006BBD 50 0D            [24] 3956 	jnc	00165$
                                   3957 ;	free result
      006BBF                       3958 00106$:
                                   3959 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006BBF 90 07 6E         [24] 3960 	mov	dptr,#(_raw_buffer + 0x0001)
      006BC2 74 FF            [12] 3961 	mov	a,#0xff
      006BC4 F0               [24] 3962 	movx	@dptr,a
                                   3963 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006BC5 90 07 71         [24] 3964 	mov	dptr,#(_raw_buffer + 0x0004)
      006BC8 E4               [12] 3965 	clr	a
      006BC9 F0               [24] 3966 	movx	@dptr,a
                                   3967 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006BCA 80 39            [24] 3968 	sjmp	00108$
      006BCC                       3969 00165$:
      006BCC 7B 00            [12] 3970 	mov	r3,#0x00
      006BCE                       3971 00131$:
      006BCE C3               [12] 3972 	clr	c
      006BCF EB               [12] 3973 	mov	a,r3
      006BD0 9C               [12] 3974 	subb	a,r4
      006BD1 50 32            [24] 3975 	jnc	00108$
      006BD3 C0 04            [24] 3976 	push	ar4
      006BD5 8B 02            [24] 3977 	mov	ar2,r3
      006BD7 74 05            [12] 3978 	mov	a,#0x05
      006BD9 2A               [12] 3979 	add	a, r2
      006BDA F9               [12] 3980 	mov	r1,a
      006BDB 33               [12] 3981 	rlc	a
      006BDC 95 E0            [12] 3982 	subb	a,acc
      006BDE FA               [12] 3983 	mov	r2,a
      006BDF E9               [12] 3984 	mov	a,r1
      006BE0 24 6D            [12] 3985 	add	a, #_raw_buffer
      006BE2 F9               [12] 3986 	mov	r1,a
      006BE3 EA               [12] 3987 	mov	a,r2
      006BE4 34 07            [12] 3988 	addc	a, #(_raw_buffer >> 8)
      006BE6 FA               [12] 3989 	mov	r2,a
      006BE7 8B 1E            [24] 3990 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006BE9 75 1F 00         [24] 3991 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006BEC 8E 00            [24] 3992 	mov	ar0,r6
      006BEE 8D 04            [24] 3993 	mov	ar4,r5
      006BF0 E5 1E            [12] 3994 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006BF2 28               [12] 3995 	add	a, r0
      006BF3 F8               [12] 3996 	mov	r0,a
      006BF4 E5 1F            [12] 3997 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006BF6 3C               [12] 3998 	addc	a, r4
      006BF7 FC               [12] 3999 	mov	r4,a
      006BF8 88 82            [24] 4000 	mov	dpl,r0
      006BFA 8C 83            [24] 4001 	mov	dph,r4
      006BFC E4               [12] 4002 	clr	a
      006BFD 93               [24] 4003 	movc	a,@a+dptr
      006BFE 12 6D 24         [24] 4004 	lcall	_ak820_outline_0158
      006C01 D0 04            [24] 4005 	pop	ar4
      006C03 80 C9            [24] 4006 	sjmp	00131$
      006C05                       4007 00108$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006C05 12 6D 04         [24] 4009 	lcall	_ak820_outline_0050
      006C08 12 68 07         [24] 4010 	lcall	_ak820_usb_send
      006C0B 02 6C B4         [24] 4011 	ljmp	00119$
      006C0E                       4012 00118$:
                                   4013 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006C0E EF               [12] 4014 	mov	a,r7
      006C0F 70 03            [24] 4015 	jnz	00281$
      006C11 02 6C 91         [24] 4016 	ljmp	00114$
      006C14                       4017 00281$:
      006C14 12 6D 2B         [24] 4018 	lcall	_ak820_outline_0168
      006C17 BF 01 02         [24] 4019 	cjne	r7,#0x01,00282$
      006C1A 80 03            [24] 4020 	sjmp	00283$
      006C1C                       4021 00282$:
      006C1C 02 6C 91         [24] 4022 	ljmp	00114$
      006C1F                       4023 00283$:
                                   4024 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006C1F 7F 02            [12] 4025 	mov	r7,#0x02
      006C21                       4026 00133$:
      006C21 EF               [12] 4027 	mov	a,r7
      006C22 12 6D 18         [24] 4028 	lcall	_ak820_outline_0111
      006C25 0F               [12] 4029 	inc	r7
      006C26 BF 20 00         [24] 4030 	cjne	r7,#0x20,00284$
      006C29                       4031 00284$:
      006C29 40 F6            [24] 4032 	jc	00133$
                                   4033 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006C2B 90 07 6F         [24] 4034 	mov	dptr,#(_raw_buffer + 0x0002)
      006C2E 74 01            [12] 4035 	mov	a,#0x01
      006C30 F0               [24] 4036 	movx	@dptr,a
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006C31 90 07 70         [24] 4038 	mov	dptr,#(_raw_buffer + 0x0003)
      006C34 74 A8            [12] 4039 	mov	a,#0xa8
      006C36 F0               [24] 4040 	movx	@dptr,a
                                   4041 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006C37 90 07 71         [24] 4042 	mov	dptr,#(_raw_buffer + 0x0004)
      006C3A 12 3C 09         [24] 4043 	lcall	_ak820_nvm_diagnostic
                                   4044 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006C3D 7F 00            [12] 4045 	mov	r7,#0x00
      006C3F                       4046 00135$:
      006C3F 8F 06            [24] 4047 	mov	ar6,r7
      006C41 74 0B            [12] 4048 	mov	a,#0x0b
      006C43 2E               [12] 4049 	add	a, r6
      006C44 24 6D            [12] 4050 	add	a,#_raw_buffer
      006C46 FE               [12] 4051 	mov	r6,a
      006C47 E4               [12] 4052 	clr	a
      006C48 34 07            [12] 4053 	addc	a, #(_raw_buffer >> 8)
      006C4A FD               [12] 4054 	mov	r5,a
      006C4B EF               [12] 4055 	mov	a,r7
      006C4C 24 5D            [12] 4056 	add	a, #_ak820_flash_diagnostic
      006C4E F5 82            [12] 4057 	mov	dpl,a
      006C50 E4               [12] 4058 	clr	a
      006C51 34 04            [12] 4059 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006C53 F5 83            [12] 4060 	mov	dph,a
      006C55 E0               [24] 4061 	movx	a,@dptr
      006C56 8E 82            [24] 4062 	mov	dpl,r6
      006C58 8D 83            [24] 4063 	mov	dph,r5
      006C5A F0               [24] 4064 	movx	@dptr,a
      006C5B 0F               [12] 4065 	inc	r7
      006C5C BF 06 00         [24] 4066 	cjne	r7,#0x06,00286$
      006C5F                       4067 00286$:
      006C5F 40 DE            [24] 4068 	jc	00135$
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006C61 90 0E 42         [24] 4070 	mov	dptr,#_vial_unlocked
      006C64 E0               [24] 4071 	movx	a,@dptr
      006C65 90 07 7E         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0011)
      006C68 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006C69 90 0E 43         [24] 4075 	mov	dptr,#_vial_unlock_in_progress
      006C6C E0               [24] 4076 	movx	a,@dptr
      006C6D 90 07 7F         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0012)
      006C70 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006C71 90 07 65         [24] 4080 	mov	dptr,#_USB_EnumStatus
      006C74 E0               [24] 4081 	movx	a,@dptr
      006C75 90 07 80         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0013)
      006C78 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006C79 90 07 66         [24] 4085 	mov	dptr,#_USB_SleepStatus
      006C7C E0               [24] 4086 	movx	a,@dptr
      006C7D 90 07 81         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0014)
      006C80 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006C81 90 07 6C         [24] 4090 	mov	dptr,#_raw_state
      006C84 E0               [24] 4091 	movx	a,@dptr
      006C85 90 07 82         [24] 4092 	mov	dptr,#(_raw_buffer + 0x0015)
      006C88 F0               [24] 4093 	movx	@dptr,a
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006C89 12 6D 04         [24] 4095 	lcall	_ak820_outline_0050
      006C8C 12 68 07         [24] 4096 	lcall	_ak820_usb_send
      006C8F 80 23            [24] 4097 	sjmp	00119$
      006C91                       4098 00114$:
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006C91 12 6A 22         [24] 4100 	lcall	_raw_request_is_nonpersistent
      006C94 E5 82            [12] 4101 	mov	a, dpl
      006C96 90 07 8D         [24] 4102 	mov	dptr,#_raw_reply_without_nvm
      006C99 F0               [24] 4103 	movx	@dptr,a
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006C9A 12 3F E9         [24] 4105 	lcall	_ak820_nvm_begin
                                   4106 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006C9D 90 0C 74         [24] 4107 	mov	dptr,#_raw_hid_receive_PARM_2
      006CA0 74 20            [12] 4108 	mov	a,#0x20
      006CA2 F0               [24] 4109 	movx	@dptr,a
      006CA3 90 07 6D         [24] 4110 	mov	dptr,#_raw_buffer
      006CA6 75 F0 00         [24] 4111 	mov	b, #0x00
      006CA9 12 AA 79         [24] 4112 	lcall	_raw_hid_receive
                                   4113 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006CAC 12 3F FE         [24] 4114 	lcall	_ak820_nvm_end
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006CAF 90 07 8D         [24] 4116 	mov	dptr,#_raw_reply_without_nvm
      006CB2 E4               [12] 4117 	clr	a
      006CB3 F0               [24] 4118 	movx	@dptr,a
      006CB4                       4119 00119$:
                                   4120 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4121 ;	assignBit
      006CB4 A2 AF            [12] 4122 	mov	c,_EA
      006CB6 92 1D            [24] 4123 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4124 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4125 ;	assignBit
      006CB8 C2 AF            [12] 4126 	clr	_EA
                                   4127 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006CBA 12 6D 31         [24] 4128 	lcall	_ak820_outline_0170
      006CBD BF 04 08         [24] 4129 	cjne	r7,#0x04,00126$
      006CC0 90 07 6C         [24] 4130 	mov	dptr,#_raw_state
      006CC3 74 05            [12] 4131 	mov	a,#0x05
      006CC5 F0               [24] 4132 	movx	@dptr,a
      006CC6 80 1B            [24] 4133 	sjmp	00127$
      006CC8                       4134 00126$:
                                   4135 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006CC8 12 6D 31         [24] 4136 	lcall	_ak820_outline_0170
      006CCB BF 03 02         [24] 4137 	cjne	r7,#0x03,00290$
      006CCE 80 0E            [24] 4138 	sjmp	00121$
      006CD0                       4139 00290$:
      006CD0 12 6D 31         [24] 4140 	lcall	_ak820_outline_0170
      006CD3 BF 06 02         [24] 4141 	cjne	r7,#0x06,00291$
      006CD6 80 06            [24] 4142 	sjmp	00121$
      006CD8                       4143 00291$:
      006CD8 12 6D 31         [24] 4144 	lcall	_ak820_outline_0170
      006CDB BF 07 05         [24] 4145 	cjne	r7,#0x07,00127$
      006CDE                       4146 00121$:
      006CDE 90 07 6C         [24] 4147 	mov	dptr,#_raw_state
      006CE1 E4               [12] 4148 	clr	a
      006CE2 F0               [24] 4149 	movx	@dptr,a
      006CE3                       4150 00127$:
                                   4151 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4152 ;	assignBit
      006CE3 A2 1D            [12] 4153 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006CE5 92 AF            [24] 4154 	mov	_EA,c
                                   4155 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006CE7 22               [24] 4156 	ret
                                   4157 ;------------------------------------------------------------
                                   4158 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4159 ;------------------------------------------------------------
                                   4160 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_481'
                                   4161 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_481'
                                   4162 ;------------------------------------------------------------
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:664: bool ak820_usb_take_keyboard_reset(void) {
                                   4164 ;	-----------------------------------------
                                   4165 ;	 function ak820_usb_take_keyboard_reset
                                   4166 ;	-----------------------------------------
      006CE8                       4167 _ak820_usb_take_keyboard_reset:
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:666: uint8_t saved_ea = EA;
                                   4169 ;	assignBit
      006CE8 A2 AF            [12] 4170 	mov	c,_EA
      006CEA 92 1E            [24] 4171 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4172 ;	tmk_core/protocol/ch555/usb_ak820.c:667: EA = 0;
                                   4173 ;	assignBit
      006CEC C2 AF            [12] 4174 	clr	_EA
                                   4175 ;	tmk_core/protocol/ch555/usb_ak820.c:668: result = keyboard_reset;
      006CEE 90 07 8E         [24] 4176 	mov	dptr,#_keyboard_reset
      006CF1 E0               [24] 4177 	movx	a,@dptr
      006CF2 FF               [12] 4178 	mov	r7,a
                                   4179 ;	tmk_core/protocol/ch555/usb_ak820.c:669: keyboard_reset = 0;
      006CF3 E4               [12] 4180 	clr	a
      006CF4 F0               [24] 4181 	movx	@dptr,a
                                   4182 ;	tmk_core/protocol/ch555/usb_ak820.c:670: EA = saved_ea;
                                   4183 ;	assignBit
      006CF5 A2 1E            [12] 4184 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006CF7 92 AF            [24] 4185 	mov	_EA,c
                                   4186 ;	tmk_core/protocol/ch555/usb_ak820.c:671: return result != 0;
      006CF9 EF               [12] 4187 	mov	a,r7
      006CFA B4 01 00         [24] 4188 	cjne	a,#0x01,00103$
      006CFD                       4189 00103$:
      006CFD B3               [12] 4190 	cpl	c
      006CFE 92 1E            [24] 4191 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006D00 12 39 33         [24] 4192 	lcall	_ak820_outline_0163
                                   4193 ;	tmk_core/protocol/ch555/usb_ak820.c:672: }
      006D03 22               [24] 4194 	ret
                                   4195 	.area CSEG    (CODE)
                                   4196 	.area CONST   (CODE)
                                   4197 	.area CONST   (CODE)
      00BD7A                       4198 _shared_offsets:
      00BD7A 00                    4199 	.db #0x00	; 0
      00BD7B 00                    4200 	.db #0x00	; 0
      00BD7C 28                    4201 	.db #0x28	; 40
      00BD7D 28                    4202 	.db #0x28	; 40
      00BD7E 2B                    4203 	.db #0x2b	; 43
      00BD7F 00                    4204 	.db #0x00	; 0
      00BD80 08                    4205 	.db #0x08	; 8
                                   4206 	.area CSEG    (CODE)
                                   4207 	.area CONST   (CODE)
      00BD81                       4208 _shared_lengths:
      00BD81 00                    4209 	.db #0x00	; 0
      00BD82 00                    4210 	.db #0x00	; 0
      00BD83 00                    4211 	.db #0x00	; 0
      00BD84 03                    4212 	.db #0x03	; 3
      00BD85 03                    4213 	.db #0x03	; 3
      00BD86 00                    4214 	.db #0x00	; 0
      00BD87 20                    4215 	.db #0x20	; 32
                                   4216 	.area CSEG    (CODE)
                                   4217 	.area CONST   (CODE)
      00BD88                       4218 _interface_descriptors:
      00BD88 20 C3                 4219 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BD8A 20 C4                 4220 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BD8C D3 C3                 4221 	.byte _RawReport, (_RawReport >> 8)
      00BD8E 39 C4                 4222 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BD90 65 C3                 4223 	.byte _SharedReport, (_SharedReport >> 8)
      00BD92 52 C4                 4224 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4225 	.area CSEG    (CODE)
                                   4226 	.area XINIT   (CODE)
                                   4227 	.area CABS    (ABS,CODE)
                                   4228 
                                   4229 ; Experimental exact instruction outlining.
                                   4230 	.globl _ak820_outline_0017
                                   4231 	.globl _ak820_outline_0036
                                   4232 	.globl _ak820_outline_0050
                                   4233 	.globl _ak820_outline_0089
                                   4234 	.globl _ak820_outline_0111
                                   4235 	.globl _ak820_outline_0126
                                   4236 	.globl _ak820_outline_0158
                                   4237 	.globl _ak820_outline_0163
                                   4238 	.globl _ak820_outline_0168
                                   4239 	.globl _ak820_outline_0170
                                   4240 
                                   4241 	.area CSEG (CODE)
                                   4242 ; function ak820_outline_0050
      006D04                       4243 _ak820_outline_0050:
      006D04 90 07 CA         [24] 4244 	mov	dptr,#_ak820_usb_send_PARM_2
      006D07 74 6D            [12] 4245 	mov	a,#_raw_buffer
      006D09 F0               [24] 4246 	movx	@dptr,a
      006D0A 74 07            [12] 4247 	mov	a,#(_raw_buffer>>8)
      006D0C A3               [24] 4248 	inc	dptr
      006D0D F0               [24] 4249 	movx	@dptr,a
      006D0E 90 07 CC         [24] 4250 	mov	dptr,#_ak820_usb_send_PARM_3
      006D11 74 20            [12] 4251 	mov	a,#0x20
      006D13 F0               [24] 4252 	movx	@dptr,a
      006D14 75 82 03         [24] 4253 	mov	dpl,#0x03
      006D17 22               [24] 4254 	ret
                                   4255 
                                   4256 	.area CSEG (CODE)
                                   4257 ; function ak820_outline_0111
      006D18                       4258 _ak820_outline_0111:
      006D18 24 6D            [12] 4259 	add	a,#_raw_buffer
      006D1A F5 82            [12] 4260 	mov	dpl,a
      006D1C E4               [12] 4261 	clr	a
      006D1D 34 07            [12] 4262 	addc	a,#(_raw_buffer>>8)
      006D1F F5 83            [12] 4263 	mov	dph,a
      006D21 E4               [12] 4264 	clr	a
      006D22 F0               [24] 4265 	movx	@dptr,a
      006D23 22               [24] 4266 	ret
                                   4267 
                                   4268 	.area CSEG (CODE)
                                   4269 ; function ak820_outline_0158
      006D24                       4270 _ak820_outline_0158:
      006D24 89 82            [24] 4271 	mov	dpl,r1
      006D26 8A 83            [24] 4272 	mov	dph,r2
      006D28 F0               [24] 4273 	movx	@dptr,a
      006D29 0B               [12] 4274 	inc	r3
      006D2A 22               [24] 4275 	ret
                                   4276 
                                   4277 	.area CSEG (CODE)
                                   4278 ; function ak820_outline_0168
      006D2B                       4279 _ak820_outline_0168:
      006D2B 90 07 6E         [24] 4280 	mov	dptr,#(_raw_buffer+0x0001)
      006D2E E0               [24] 4281 	movx	a,@dptr
      006D2F FF               [12] 4282 	mov	r7,a
      006D30 22               [24] 4283 	ret
                                   4284 
                                   4285 	.area CSEG (CODE)
                                   4286 ; function ak820_outline_0170
      006D31                       4287 _ak820_outline_0170:
      006D31 90 07 6C         [24] 4288 	mov	dptr,#_raw_state
      006D34 E0               [24] 4289 	movx	a,@dptr
      006D35 FF               [12] 4290 	mov	r7,a
      006D36 22               [24] 4291 	ret
