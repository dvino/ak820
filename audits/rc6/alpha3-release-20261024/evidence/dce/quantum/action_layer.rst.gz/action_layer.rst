                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _keymap_key_to_keycode
                                     14 	.globl _action_for_keycode
                                     15 	.globl _action_for_key
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _layer_state
                                    260 	.globl _default_layer_state
                                    261 	.globl _layer_switch_get_action_PARM_1
                                    262 	.globl _layer_switch_get_layer_PARM_1
                                    263 	.globl _store_or_get_action_PARM_2
                                    264 	.globl _read_source_keycode_cache_PARM_1
                                    265 	.globl _update_source_layers_cache_PARM_1
                                    266 	.globl _update_source_keycode_cache_PARM_1
                                    267 	.globl _default_layer_state_set_user
                                    268 	.globl _default_layer_state_set_kb
                                    269 	.globl _default_layer_set
                                    270 	.globl _default_layer_or
                                    271 	.globl _default_layer_and
                                    272 	.globl _default_layer_xor
                                    273 	.globl _ak820_layer_refresh
                                    274 	.globl _layer_hold_on
                                    275 	.globl _layer_hold_off
                                    276 	.globl _layer_hold_clear
                                    277 	.globl _layer_state_set_user
                                    278 	.globl _layer_state_set_kb
                                    279 	.globl _layer_state_set
                                    280 	.globl _layer_clear
                                    281 	.globl _layer_move
                                    282 	.globl _layer_on
                                    283 	.globl _layer_off
                                    284 	.globl _layer_or
                                    285 	.globl _layer_and
                                    286 	.globl _layer_xor
                                    287 	.globl _update_source_keycode_cache
                                    288 	.globl _update_source_layers_cache
                                    289 	.globl _read_source_keycode_cache
                                    290 	.globl _store_or_get_action
                                    291 	.globl _layer_switch_get_layer
                                    292 	.globl _layer_switch_get_action
                                    293 ;--------------------------------------------------------
                                    294 ; special function registers
                                    295 ;--------------------------------------------------------
                                    296 	.area RSEG    (ABS,DATA)
      000000                        297 	.org 0x0000
                           0000D0   298 _PSW	=	0x00d0
                           0000E0   299 _ACC	=	0x00e0
                           0000F0   300 _B	=	0x00f0
                           0000FD   301 _A_INV	=	0x00fd
                           000081   302 _SP	=	0x0081
                           000082   303 _DPL	=	0x0082
                           000083   304 _DPH	=	0x0083
                           0000A1   305 _SAFE_MOD	=	0x00a1
                           0000B1   306 _GLOBAL_CFG	=	0x00b1
                           000087   307 _PCON	=	0x0087
                           0000BA   308 _POWER_CFG	=	0x00ba
                           0000B9   309 _CLOCK_CFG	=	0x00b9
                           0000A9   310 _WAKE_CTRL	=	0x00a9
                           0000FE   311 _RESET_KEEP	=	0x00fe
                           0000FF   312 _WDOG_COUNT	=	0x00ff
                           0000A8   313 _IE	=	0x00a8
                           0000B8   314 _IP	=	0x00b8
                           0000E8   315 _IE_EX	=	0x00e8
                           0000E9   316 _IP_EX	=	0x00e9
                           0000B2   317 _GPIO_IE	=	0x00b2
                           008584   318 _ROM_ADDR	=	0x8584
                           000084   319 _ROM_ADDR_L	=	0x0084
                           000085   320 _ROM_ADDR_H	=	0x0085
                           008F8E   321 _ROM_DATA_HI	=	0x8f8e
                           00008E   322 _ROM_DATA_HL	=	0x008e
                           00008F   323 _ROM_DATA_HH	=	0x008f
                           000086   324 _ROM_CTRL	=	0x0086
                           000080   325 _P0	=	0x0080
                           0000C4   326 _P0_MOD_OC	=	0x00c4
                           0000C5   327 _P0_DIR_PU	=	0x00c5
                           000090   328 _P1	=	0x0090
                           000092   329 _P1_MOD_OC	=	0x0092
                           000093   330 _P1_DIR_PU	=	0x0093
                           0000A0   331 _P2	=	0x00a0
                           000094   332 _P2_MOD_OC	=	0x0094
                           000095   333 _P2_DIR_PU	=	0x0095
                           0000B0   334 _P3	=	0x00b0
                           000096   335 _P3_MOD_OC	=	0x0096
                           000097   336 _P3_DIR_PU	=	0x0097
                           0000C0   337 _P4	=	0x00c0
                           0000C2   338 _P4_MOD_OC	=	0x00c2
                           0000C3   339 _P4_DIR_PU	=	0x00c3
                           0000C1   340 _P4_LED_KEY	=	0x00c1
                           0000AA   341 _P5_IN	=	0x00aa
                           0000AB   342 _P5_OUT_PU	=	0x00ab
                           0000AC   343 _P5_DIR	=	0x00ac
                           0000AD   344 _P6_IN	=	0x00ad
                           0000AE   345 _P6_OUT_PU	=	0x00ae
                           0000AF   346 _P6_DIR	=	0x00af
                           0000F1   347 _P7	=	0x00f1
                           0000A2   348 _XBUS_AUX	=	0x00a2
                           000088   349 _TCON	=	0x0088
                           000089   350 _TMOD	=	0x0089
                           00008A   351 _TL0	=	0x008a
                           00008B   352 _TL1	=	0x008b
                           00008C   353 _TH0	=	0x008c
                           00008D   354 _TH1	=	0x008d
                           000098   355 _SCON	=	0x0098
                           000099   356 _SBUF	=	0x0099
                           0000C8   357 _T2CON	=	0x00c8
                           0000C9   358 _T2MOD	=	0x00c9
                           00CBCA   359 _RCAP2	=	0xcbca
                           0000CA   360 _RCAP2L	=	0x00ca
                           0000CB   361 _RCAP2H	=	0x00cb
                           00CDCC   362 _T2COUNT	=	0xcdcc
                           0000CC   363 _TL2	=	0x00cc
                           0000CD   364 _TH2	=	0x00cd
                           00CFCE   365 _T2CAP1	=	0xcfce
                           0000CE   366 _T2CAP1L	=	0x00ce
                           0000CF   367 _T2CAP1H	=	0x00cf
                           0000F8   368 _SPI0_STAT	=	0x00f8
                           0000F9   369 _SPI0_DATA	=	0x00f9
                           0000FA   370 _SPI0_CTRL	=	0x00fa
                           0000FB   371 _SPI0_CK_SE	=	0x00fb
                           0000FC   372 _SPI0_SETUP	=	0x00fc
                           0000BC   373 _SCON1	=	0x00bc
                           0000BD   374 _SBUF1	=	0x00bd
                           0000BE   375 _SBAUD1	=	0x00be
                           0000BF   376 _SIF1	=	0x00bf
                           0000B4   377 _SPI1_STAT	=	0x00b4
                           0000B5   378 _SPI1_DATA	=	0x00b5
                           0000B6   379 _SPI1_CTRL	=	0x00b6
                           0000B7   380 _SPI1_CK_SE	=	0x00b7
                           0000F3   381 _ADC_CTRL	=	0x00f3
                           00F5F4   382 _ADC_DAT	=	0xf5f4
                           0000F4   383 _ADC_DAT_L	=	0x00f4
                           0000F5   384 _ADC_DAT_H	=	0x00f5
                           0000F6   385 _ADC_CHAN	=	0x00f6
                           0000A6   386 _LED_COMMON	=	0x00a6
                           0000A7   387 _LED_PWM_OE	=	0x00a7
                           00C7C6   388 _LED_DMA	=	0xc7c6
                           0000C6   389 _LED_DMA_L	=	0x00c6
                           0000C7   390 _LED_DMA_H	=	0x00c7
                           0000F7   391 _LED_STATUS	=	0x00f7
                           0000B3   392 _I2CX_INT	=	0x00b3
                           0000BB   393 _I2CS_INT_ST	=	0x00bb
                                    394 ;--------------------------------------------------------
                                    395 ; special function bits
                                    396 ;--------------------------------------------------------
                                    397 	.area RSEG    (ABS,DATA)
      000000                        398 	.org 0x0000
                           0000D7   399 _CY	=	0x00d7
                           0000D6   400 _AC	=	0x00d6
                           0000D5   401 _F0	=	0x00d5
                           0000D4   402 _RS1	=	0x00d4
                           0000D3   403 _RS0	=	0x00d3
                           0000D2   404 _OV	=	0x00d2
                           0000D1   405 _F1	=	0x00d1
                           0000D0   406 _P	=	0x00d0
                           0000AF   407 _EA	=	0x00af
                           0000AE   408 _E_DIS	=	0x00ae
                           0000AD   409 _ET2	=	0x00ad
                           0000AC   410 _ES	=	0x00ac
                           0000AB   411 _ET1	=	0x00ab
                           0000AA   412 _EX1	=	0x00aa
                           0000A9   413 _ET0	=	0x00a9
                           0000A8   414 _EX0	=	0x00a8
                           0000BF   415 _PH_FLAG	=	0x00bf
                           0000BE   416 _PL_FLAG	=	0x00be
                           0000BD   417 _PT2	=	0x00bd
                           0000BC   418 _PS	=	0x00bc
                           0000BB   419 _PT1	=	0x00bb
                           0000BA   420 _PX1	=	0x00ba
                           0000B9   421 _PT0	=	0x00b9
                           0000B8   422 _PX0	=	0x00b8
                           0000EF   423 _IE_WDOG	=	0x00ef
                           0000EE   424 _IE_GPIO	=	0x00ee
                           0000ED   425 _IE_PWM_I2C	=	0x00ed
                           0000EC   426 _IE_UART1	=	0x00ec
                           0000EB   427 _IE_ADC	=	0x00eb
                           0000E9   428 _IE_USB	=	0x00e9
                           0000E8   429 _IE_SPI0	=	0x00e8
                           000087   430 _P0_7	=	0x0087
                           000086   431 _P0_6	=	0x0086
                           000085   432 _P0_5	=	0x0085
                           000084   433 _P0_4	=	0x0084
                           000083   434 _P0_3	=	0x0083
                           000082   435 _P0_2	=	0x0082
                           000081   436 _P0_1	=	0x0081
                           000080   437 _P0_0	=	0x0080
                           000081   438 _SDA0	=	0x0081
                           000080   439 _SCL0	=	0x0080
                           000083   440 _TXD_	=	0x0083
                           000082   441 _RXD_	=	0x0082
                           000085   442 _AIN13	=	0x0085
                           000084   443 _AIN12	=	0x0084
                           000083   444 _AIN11	=	0x0083
                           000082   445 _AIN10	=	0x0082
                           000081   446 _AIN9	=	0x0081
                           000080   447 _AIN8	=	0x0080
                           000097   448 _P1_7	=	0x0097
                           000096   449 _P1_6	=	0x0096
                           000095   450 _P1_5	=	0x0095
                           000094   451 _P1_4	=	0x0094
                           000093   452 _P1_3	=	0x0093
                           000092   453 _P1_2	=	0x0092
                           000091   454 _P1_1	=	0x0091
                           000090   455 _P1_0	=	0x0090
                           000097   456 _TXD1_	=	0x0097
                           000096   457 _RXD1_	=	0x0096
                           000097   458 _SCK	=	0x0097
                           000096   459 _MISO	=	0x0096
                           000095   460 _MOSI	=	0x0095
                           000094   461 _SCS	=	0x0094
                           000092   462 _INT0_	=	0x0092
                           000091   463 _T2EX	=	0x0091
                           000091   464 _CAP2	=	0x0091
                           000090   465 _T2	=	0x0090
                           000090   466 _CAP1	=	0x0090
                           000097   467 _AIN7	=	0x0097
                           000096   468 _AIN6	=	0x0096
                           000095   469 _AIN5	=	0x0095
                           000094   470 _AIN4	=	0x0094
                           000093   471 _AIN3	=	0x0093
                           000092   472 _AIN2	=	0x0092
                           000091   473 _AIN1	=	0x0091
                           000090   474 _AIN0	=	0x0090
                           0000A7   475 _P2_7	=	0x00a7
                           0000A6   476 _P2_6	=	0x00a6
                           0000A5   477 _P2_5	=	0x00a5
                           0000A4   478 _P2_4	=	0x00a4
                           0000A3   479 _P2_3	=	0x00a3
                           0000A2   480 _P2_2	=	0x00a2
                           0000A1   481 _P2_1	=	0x00a1
                           0000A0   482 _P2_0	=	0x00a0
                           0000A7   483 _TXD1	=	0x00a7
                           0000A6   484 _RXD1	=	0x00a6
                           0000A5   485 _T2EX_	=	0x00a5
                           0000A5   486 _CAP2_	=	0x00a5
                           0000A4   487 _T2_	=	0x00a4
                           0000A4   488 _CAP1_	=	0x00a4
                           0000B7   489 _P3_7	=	0x00b7
                           0000B6   490 _P3_6	=	0x00b6
                           0000B5   491 _P3_5	=	0x00b5
                           0000B4   492 _P3_4	=	0x00b4
                           0000B3   493 _P3_3	=	0x00b3
                           0000B2   494 _P3_2	=	0x00b2
                           0000B1   495 _P3_1	=	0x00b1
                           0000B0   496 _P3_0	=	0x00b0
                           0000B7   497 _SCK1	=	0x00b7
                           0000B6   498 _MISO1	=	0x00b6
                           0000B5   499 _MOSI1	=	0x00b5
                           0000B5   500 _T1	=	0x00b5
                           0000B4   501 _T0	=	0x00b4
                           0000B3   502 _INT1	=	0x00b3
                           0000B2   503 _INT0	=	0x00b2
                           0000B1   504 _TXD	=	0x00b1
                           0000B0   505 _RXD	=	0x00b0
                           0000C6   506 _P4_6	=	0x00c6
                           0000C5   507 _P4_5	=	0x00c5
                           0000C4   508 _P4_4	=	0x00c4
                           0000C3   509 _P4_3	=	0x00c3
                           0000C2   510 _P4_2	=	0x00c2
                           0000C1   511 _P4_1	=	0x00c1
                           0000C0   512 _P4_0	=	0x00c0
                           00008F   513 _TF1	=	0x008f
                           00008E   514 _TR1	=	0x008e
                           00008D   515 _TF0	=	0x008d
                           00008C   516 _TR0	=	0x008c
                           00008B   517 _IE1	=	0x008b
                           00008A   518 _IT1	=	0x008a
                           000089   519 _IE0	=	0x0089
                           000088   520 _IT0	=	0x0088
                           00009F   521 _SM0	=	0x009f
                           00009E   522 _SM1	=	0x009e
                           00009D   523 _SM2	=	0x009d
                           00009C   524 _REN	=	0x009c
                           00009B   525 _TB8	=	0x009b
                           00009A   526 _RB8	=	0x009a
                           000099   527 _TI	=	0x0099
                           000098   528 _RI	=	0x0098
                           0000CF   529 _TF2	=	0x00cf
                           0000CF   530 _CAP1F	=	0x00cf
                           0000CE   531 _EXF2	=	0x00ce
                           0000CD   532 _RCLK	=	0x00cd
                           0000CC   533 _TCLK	=	0x00cc
                           0000CB   534 _EXEN2	=	0x00cb
                           0000CA   535 _TR2	=	0x00ca
                           0000C9   536 _C_T2	=	0x00c9
                           0000C8   537 _CP_RL2	=	0x00c8
                           0000FF   538 _S0_FST_ACT	=	0x00ff
                           0000FE   539 _S0_IF_OV	=	0x00fe
                           0000FD   540 _S0_IF_FIRST	=	0x00fd
                           0000FC   541 _S0_IF_BYTE	=	0x00fc
                           0000FB   542 _S0_FREE	=	0x00fb
                           0000FA   543 _S0_T_FIFO	=	0x00fa
                           0000F8   544 _S0_R_FIFO	=	0x00f8
                           0000F7   545 _ADC_START	=	0x00f7
                                    546 ;--------------------------------------------------------
                                    547 ; overlayable register banks
                                    548 ;--------------------------------------------------------
                                    549 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        550 	.ds 8
                                    551 ;--------------------------------------------------------
                                    552 ; internal ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area DSEG    (DATA)
                                    555 ;--------------------------------------------------------
                                    556 ; overlayable items in internal ram
                                    557 ;--------------------------------------------------------
                                    558 ;--------------------------------------------------------
                                    559 ; indirectly addressable internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area ISEG    (DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; absolute internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area IABS    (ABS,DATA)
                                    566 	.area IABS    (ABS,DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; bit data
                                    569 ;--------------------------------------------------------
                                    570 	.area BSEG    (BIT)
                                    571 ;--------------------------------------------------------
                                    572 ; paged external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area PSEG    (PAG,XDATA)
                                    575 ;--------------------------------------------------------
                                    576 ; uninitialized external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area XSEG    (XDATA)
      000837                        579 _default_layer_state_set_user_state_10000_310:
      000837                        580 	.ds 1
      000838                        581 _default_layer_state_set_kb_state_10000_312:
      000838                        582 	.ds 1
      000839                        583 _default_layer_state_set_state_10000_314:
      000839                        584 	.ds 1
      00083A                        585 _default_layer_set_state_10000_319:
      00083A                        586 	.ds 1
      00083B                        587 _default_layer_or_state_10000_321:
      00083B                        588 	.ds 1
      00083C                        589 _default_layer_and_state_10000_323:
      00083C                        590 	.ds 1
      00083D                        591 _default_layer_xor_state_10000_325:
      00083D                        592 	.ds 1
      00083E                        593 _persistent_layers:
      00083E                        594 	.ds 1
      00083F                        595 _layer_refs:
      00083F                        596 	.ds 6
      000845                        597 _macro_layers:
      000845                        598 	.ds 1
      000846                        599 _ak820_layer_refresh_state_10000_328:
      000846                        600 	.ds 1
      000847                        601 _layer_hold_on_layer_10000_331:
      000847                        602 	.ds 1
      000848                        603 _layer_hold_off_layer_10000_335:
      000848                        604 	.ds 1
      000849                        605 _layer_state_set_user_state_10000_342:
      000849                        606 	.ds 1
      00084A                        607 _layer_state_set_kb_state_10000_344:
      00084A                        608 	.ds 1
      00084B                        609 _layer_state_set_state_10000_346:
      00084B                        610 	.ds 1
      00084C                        611 _layer_move_layer_10000_359:
      00084C                        612 	.ds 1
      00084D                        613 _layer_on_layer_10000_361:
      00084D                        614 	.ds 1
      00084E                        615 _layer_off_layer_10000_363:
      00084E                        616 	.ds 1
      00084F                        617 _layer_or_state_10000_367:
      00084F                        618 	.ds 1
      000850                        619 _layer_and_state_10000_369:
      000850                        620 	.ds 1
      000851                        621 _layer_xor_state_10000_371:
      000851                        622 	.ds 1
      000852                        623 _source_keycodes_cache:
      000852                        624 	.ds 256
      000952                        625 _encoder_source_keycodes_cache:
      000952                        626 	.ds 4
      000956                        627 _source_keycode_cache_slot_PARM_1:
      000956                        628 	.ds 2
      000958                        629 _update_source_keycode_cache_PARM_1:
      000958                        630 	.ds 2
      00095A                        631 _update_source_keycode_cache_keycode_10000_379:
      00095A                        632 	.ds 2
      00095C                        633 _update_source_layers_cache_PARM_1:
      00095C                        634 	.ds 2
      00095E                        635 _update_source_layers_cache_layer_10000_382:
      00095E                        636 	.ds 1
      00095F                        637 _read_source_keycode_cache_PARM_1:
      00095F                        638 	.ds 2
      000961                        639 _store_or_get_action_PARM_2:
      000961                        640 	.ds 2
      000963                        641 _store_or_get_action_pressed_10000_390:
      000963                        642 	.ds 1
      000964                        643 _layer_switch_get_layer_PARM_1:
      000964                        644 	.ds 2
      000966                        645 _layer_switch_get_layer_action_10000_396:
      000966                        646 	.ds 2
      000968                        647 _layer_switch_get_layer_layers_10001_397:
      000968                        648 	.ds 1
      000969                        649 _layer_switch_get_action_PARM_1:
      000969                        650 	.ds 2
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DE3                        659 _default_layer_state::
      000DE3                        660 	.ds 1
      000DE4                        661 _layer_state::
      000DE4                        662 	.ds 1
                                    663 	.area HOME    (CODE)
                                    664 	.area GSINIT0 (CODE)
                                    665 	.area GSINIT1 (CODE)
                                    666 	.area GSINIT2 (CODE)
                                    667 	.area GSINIT3 (CODE)
                                    668 	.area GSINIT4 (CODE)
                                    669 	.area GSINIT5 (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 	.area GSFINAL (CODE)
                                    672 	.area CSEG    (CODE)
                                    673 ;--------------------------------------------------------
                                    674 ; global & static initialisations
                                    675 ;--------------------------------------------------------
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; Home
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area HOME    (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; code
                                    687 ;--------------------------------------------------------
                                    688 	.area CSEG    (CODE)
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    691 ;------------------------------------------------------------
                                    692 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_183'
                                    693 ;------------------------------------------------------------
                                    694 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    695 ;	-----------------------------------------
                           000007   696 	ar7 = 0x07
                           000006   697 	ar6 = 0x06
                           000005   698 	ar5 = 0x05
                           000004   699 	ar4 = 0x04
                           000003   700 	ar3 = 0x03
                           000002   701 	ar2 = 0x02
                           000001   702 	ar1 = 0x01
                           000000   703 	ar0 = 0x00
                                    704 ;	 function default_layer_state_set_user
                                    705 ;	-----------------------------------------
      007827                        706 _default_layer_state_set_user:
      007827 E5 82            [12]  707 	mov	a,dpl
      007829 90 08 37         [24]  708 	mov	dptr,#_default_layer_state_set_user_state_10000_310
      00782C 12 57 FB         [24]  709 	lcall	_ak820_outline_0175
                                    710 ;	quantum/action_layer.c:32: return state;
                                    711 ;	quantum/action_layer.c:33: }
      00782F 22               [24]  712 	ret
                                    713 ;------------------------------------------------------------
                                    714 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    715 ;------------------------------------------------------------
                                    716 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_312'
                                    717 ;------------------------------------------------------------
                                    718 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    719 ;	-----------------------------------------
                                    720 ;	 function default_layer_state_set_kb
                                    721 ;	-----------------------------------------
      007830                        722 _default_layer_state_set_kb:
      007830 E5 82            [12]  723 	mov	a,dpl
      007832 90 08 38         [24]  724 	mov	dptr,#_default_layer_state_set_kb_state_10000_312
      007835 12 57 FB         [24]  725 	lcall	_ak820_outline_0175
                                    726 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    727 ;	quantum/action_layer.c:41: }
      007838 02 78 27         [24]  728 	ljmp	_default_layer_state_set_user
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'default_layer_state_set'
                                    731 ;------------------------------------------------------------
                                    732 ;state         Allocated with name '_default_layer_state_set_state_10000_314'
                                    733 ;------------------------------------------------------------
                                    734 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    735 ;	-----------------------------------------
                                    736 ;	 function default_layer_state_set
                                    737 ;	-----------------------------------------
      00783B                        738 _default_layer_state_set:
      00783B E5 82            [12]  739 	mov	a,dpl
      00783D 90 08 39         [24]  740 	mov	dptr,#_default_layer_state_set_state_10000_314
      007840 12 57 FB         [24]  741 	lcall	_ak820_outline_0175
                                    742 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      007843 12 78 30         [24]  743 	lcall	_default_layer_state_set_kb
      007846 AF 82            [24]  744 	mov	r7, dpl
      007848 90 08 39         [24]  745 	mov	dptr,#_default_layer_state_set_state_10000_314
      00784B EF               [12]  746 	mov	a,r7
      00784C F0               [24]  747 	movx	@dptr,a
                                    748 ;	quantum/action_layer.c:52: default_layer_state = state;
      00784D 90 0D E3         [24]  749 	mov	dptr,#_default_layer_state
      007850 EF               [12]  750 	mov	a,r7
      007851 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    753 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    754 ;	quantum/action_layer.c:63: }
      007852 02 78 9A         [24]  755 	ljmp	_ak820_layer_refresh
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'default_layer_set'
                                    758 ;------------------------------------------------------------
                                    759 ;state         Allocated with name '_default_layer_set_state_10000_319'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function default_layer_set
                                    764 ;	-----------------------------------------
      007855                        765 _default_layer_set:
      007855 E5 82            [12]  766 	mov	a,dpl
      007857 90 08 3A         [24]  767 	mov	dptr,#_default_layer_set_state_10000_319
      00785A 12 57 FB         [24]  768 	lcall	_ak820_outline_0175
                                    769 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    770 ;	quantum/action_layer.c:81: }
      00785D 02 78 3B         [24]  771 	ljmp	_default_layer_state_set
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'default_layer_or'
                                    774 ;------------------------------------------------------------
                                    775 ;state         Allocated with name '_default_layer_or_state_10000_321'
                                    776 ;------------------------------------------------------------
                                    777 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    778 ;	-----------------------------------------
                                    779 ;	 function default_layer_or
                                    780 ;	-----------------------------------------
      007860                        781 _default_layer_or:
      007860 E5 82            [12]  782 	mov	a,dpl
      007862 90 08 3B         [24]  783 	mov	dptr,#_default_layer_or_state_10000_321
      007865 F0               [24]  784 	movx	@dptr,a
                                    785 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      007866 E0               [24]  786 	movx	a,@dptr
      007867 FF               [12]  787 	mov	r7,a
      007868 90 0D E3         [24]  788 	mov	dptr,#_default_layer_state
      00786B 12 7C 95         [24]  789 	lcall	_ak820_outline_0148
                                    790 ;	quantum/action_layer.c:90: }
      00786E 02 78 3B         [24]  791 	ljmp	_default_layer_state_set
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'default_layer_and'
                                    794 ;------------------------------------------------------------
                                    795 ;state         Allocated with name '_default_layer_and_state_10000_323'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function default_layer_and
                                    800 ;	-----------------------------------------
      007871                        801 _default_layer_and:
      007871 E5 82            [12]  802 	mov	a,dpl
      007873 90 08 3C         [24]  803 	mov	dptr,#_default_layer_and_state_10000_323
      007876 F0               [24]  804 	movx	@dptr,a
                                    805 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      007877 90 0D E3         [24]  806 	mov	dptr,#_default_layer_state
      00787A E0               [24]  807 	movx	a,@dptr
      00787B FF               [12]  808 	mov	r7,a
      00787C 90 08 3C         [24]  809 	mov	dptr,#_default_layer_and_state_10000_323
      00787F E0               [24]  810 	movx	a,@dptr
      007880 52 07            [12]  811 	anl	ar7,a
      007882 8F 82            [24]  812 	mov	dpl, r7
                                    813 ;	quantum/action_layer.c:97: }
      007884 02 78 3B         [24]  814 	ljmp	_default_layer_state_set
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'default_layer_xor'
                                    817 ;------------------------------------------------------------
                                    818 ;state         Allocated with name '_default_layer_xor_state_10000_325'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function default_layer_xor
                                    823 ;	-----------------------------------------
      007887                        824 _default_layer_xor:
      007887 E5 82            [12]  825 	mov	a,dpl
      007889 90 08 3D         [24]  826 	mov	dptr,#_default_layer_xor_state_10000_325
      00788C F0               [24]  827 	movx	@dptr,a
                                    828 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      00788D E0               [24]  829 	movx	a,@dptr
      00788E FF               [12]  830 	mov	r7,a
      00788F 90 0D E3         [24]  831 	mov	dptr,#_default_layer_state
      007892 E0               [24]  832 	movx	a,@dptr
      007893 62 07            [12]  833 	xrl	ar7,a
      007895 8F 82            [24]  834 	mov	dpl, r7
                                    835 ;	quantum/action_layer.c:104: }
      007897 02 78 3B         [24]  836 	ljmp	_default_layer_state_set
                                    837 ;------------------------------------------------------------
                                    838 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    839 ;------------------------------------------------------------
                                    840 ;state         Allocated with name '_ak820_layer_refresh_state_10000_328'
                                    841 ;i             Allocated with name '_ak820_layer_refresh_i_20000_329'
                                    842 ;------------------------------------------------------------
                                    843 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    844 ;	-----------------------------------------
                                    845 ;	 function ak820_layer_refresh
                                    846 ;	-----------------------------------------
      00789A                        847 _ak820_layer_refresh:
                                    848 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      00789A 90 08 3E         [24]  849 	mov	dptr,#_persistent_layers
      00789D E0               [24]  850 	movx	a,@dptr
      00789E 90 08 46         [24]  851 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      0078A1 F0               [24]  852 	movx	@dptr,a
                                    853 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      0078A2 7F 00            [12]  854 	mov	r7,#0x00
      0078A4                        855 00105$:
      0078A4 BF 06 00         [24]  856 	cjne	r7,#0x06,00131$
      0078A7                        857 00131$:
      0078A7 50 25            [24]  858 	jnc	00103$
      0078A9 EF               [12]  859 	mov	a,r7
      0078AA 24 3F            [12]  860 	add	a, #_layer_refs
      0078AC FD               [12]  861 	mov	r5,a
      0078AD E4               [12]  862 	clr	a
      0078AE 34 08            [12]  863 	addc	a, #(_layer_refs >> 8)
      0078B0 FE               [12]  864 	mov	r6,a
      0078B1 12 39 17         [24]  865 	lcall	_ak820_outline_0141
      0078B4 E0               [24]  866 	movx	a,@dptr
      0078B5 60 14            [24]  867 	jz	00106$
      0078B7 8F F0            [24]  868 	mov	b,r7
      0078B9 05 F0            [12]  869 	inc	b
      0078BB 74 01            [12]  870 	mov	a,#0x01
      0078BD 80 02            [24]  871 	sjmp	00135$
      0078BF                        872 00134$:
      0078BF 25 E0            [12]  873 	add	a,acc
      0078C1                        874 00135$:
      0078C1 D5 F0 FB         [24]  875 	djnz	b,00134$
      0078C4 FE               [12]  876 	mov	r6,a
      0078C5 90 08 46         [24]  877 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      0078C8 E0               [24]  878 	movx	a,@dptr
      0078C9 4E               [12]  879 	orl	a,r6
      0078CA F0               [24]  880 	movx	@dptr,a
      0078CB                        881 00106$:
      0078CB 0F               [12]  882 	inc	r7
      0078CC 80 D6            [24]  883 	sjmp	00105$
      0078CE                        884 00103$:
                                    885 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      0078CE 90 0D E3         [24]  886 	mov	dptr,#_default_layer_state
      0078D1 E0               [24]  887 	movx	a,@dptr
      0078D2 FF               [12]  888 	mov	r7,a
      0078D3 90 08 46         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      0078D6 E0               [24]  890 	movx	a,@dptr
      0078D7 FE               [12]  891 	mov	r6,a
      0078D8 42 07            [12]  892 	orl	ar7,a
      0078DA 8F 82            [24]  893 	mov	dpl, r7
      0078DC C0 06            [24]  894 	push	ar6
      0078DE 12 A9 16         [24]  895 	lcall	_ak820_tri_layer_derived
      0078E1 AF 82            [24]  896 	mov	r7, dpl
      0078E3 D0 06            [24]  897 	pop	ar6
      0078E5 90 08 46         [24]  898 	mov	dptr,#_ak820_layer_refresh_state_10000_328
      0078E8 EF               [12]  899 	mov	a,r7
      0078E9 4E               [12]  900 	orl	a,r6
      0078EA 12 57 FB         [24]  901 	lcall	_ak820_outline_0175
                                    902 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      0078ED 12 79 8C         [24]  903 	lcall	_layer_state_set_kb
      0078F0 E5 82            [12]  904 	mov	a, dpl
      0078F2 90 0D E4         [24]  905 	mov	dptr,#_layer_state
      0078F5 F0               [24]  906 	movx	@dptr,a
                                    907 ;	quantum/action_layer.c:121: }
      0078F6 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'layer_hold_on'
                                    911 ;------------------------------------------------------------
                                    912 ;layer         Allocated with name '_layer_hold_on_layer_10000_331'
                                    913 ;------------------------------------------------------------
                                    914 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    915 ;	-----------------------------------------
                                    916 ;	 function layer_hold_on
                                    917 ;	-----------------------------------------
      0078F7                        918 _layer_hold_on:
      0078F7 E5 82            [12]  919 	mov	a,dpl
      0078F9 90 08 47         [24]  920 	mov	dptr,#_layer_hold_on_layer_10000_331
      0078FC F0               [24]  921 	movx	@dptr,a
      0078FD E0               [24]  922 	movx	a,@dptr
      0078FE FF               [12]  923 	mov	r7,a
      0078FF BF 06 00         [24]  924 	cjne	r7,#0x06,00120$
      007902                        925 00120$:
      007902 50 2A            [24]  926 	jnc	00104$
      007904 12 7C B3         [24]  927 	lcall	_ak820_outline_0183
      007907 74 01            [12]  928 	mov	a,#0x01
      007909 F0               [24]  929 	movx	@dptr,a
      00790A 90 08 45         [24]  930 	mov	dptr,#_macro_layers
      00790D C0 07            [24]  931 	push	ar7
      00790F 12 7C BC         [24]  932 	lcall	_ak820_macro_change
      007912 E5 82            [12]  933 	mov	a, dpl
      007914 D0 07            [24]  934 	pop	ar7
      007916 60 16            [24]  935 	jz	00104$
      007918 EF               [12]  936 	mov	a,r7
      007919 24 3F            [12]  937 	add	a, #_layer_refs
      00791B FF               [12]  938 	mov	r7,a
      00791C E4               [12]  939 	clr	a
      00791D 34 08            [12]  940 	addc	a, #(_layer_refs >> 8)
      00791F FE               [12]  941 	mov	r6,a
      007920 12 43 E0         [24]  942 	lcall	_ak820_outline_0164
      007923 E0               [24]  943 	movx	a,@dptr
      007924 FD               [12]  944 	mov	r5,a
      007925 0D               [12]  945 	inc	r5
      007926 12 43 E0         [24]  946 	lcall	_ak820_outline_0164
      007929 ED               [12]  947 	mov	a,r5
      00792A F0               [24]  948 	movx	@dptr,a
      00792B 02 78 9A         [24]  949 	ljmp	_ak820_layer_refresh
      00792E                        950 00104$:
      00792E 22               [24]  951 	ret
                                    952 ;------------------------------------------------------------
                                    953 ;Allocation info for local variables in function 'layer_hold_off'
                                    954 ;------------------------------------------------------------
                                    955 ;layer         Allocated with name '_layer_hold_off_layer_10000_335'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    958 ;	-----------------------------------------
                                    959 ;	 function layer_hold_off
                                    960 ;	-----------------------------------------
      00792F                        961 _layer_hold_off:
      00792F E5 82            [12]  962 	mov	a,dpl
      007931 90 08 48         [24]  963 	mov	dptr,#_layer_hold_off_layer_10000_335
      007934 F0               [24]  964 	movx	@dptr,a
      007935 E0               [24]  965 	movx	a,@dptr
      007936 FF               [12]  966 	mov	r7,a
      007937 BF 06 00         [24]  967 	cjne	r7,#0x06,00128$
      00793A                        968 00128$:
      00793A 50 2B            [24]  969 	jnc	00105$
      00793C 12 7C B3         [24]  970 	lcall	_ak820_outline_0183
      00793F E4               [12]  971 	clr	a
      007940 F0               [24]  972 	movx	@dptr,a
      007941 90 08 45         [24]  973 	mov	dptr,#_macro_layers
      007944 C0 07            [24]  974 	push	ar7
      007946 12 7C BC         [24]  975 	lcall	_ak820_macro_change
      007949 E5 82            [12]  976 	mov	a, dpl
      00794B D0 07            [24]  977 	pop	ar7
      00794D 60 18            [24]  978 	jz	00105$
      00794F EF               [12]  979 	mov	a,r7
      007950 24 3F            [12]  980 	add	a, #_layer_refs
      007952 FE               [12]  981 	mov	r6,a
      007953 E4               [12]  982 	clr	a
      007954 34 08            [12]  983 	addc	a, #(_layer_refs >> 8)
      007956 FF               [12]  984 	mov	r7,a
      007957 12 39 08         [24]  985 	lcall	_ak820_outline_0123
      00795A E0               [24]  986 	movx	a,@dptr
      00795B FD               [12]  987 	mov	r5,a
      00795C 60 09            [24]  988 	jz	00105$
      00795E 1D               [12]  989 	dec	r5
      00795F 12 39 08         [24]  990 	lcall	_ak820_outline_0123
      007962 ED               [12]  991 	mov	a,r5
      007963 F0               [24]  992 	movx	@dptr,a
      007964 02 78 9A         [24]  993 	ljmp	_ak820_layer_refresh
      007967                        994 00105$:
      007967 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'layer_hold_clear'
                                    998 ;------------------------------------------------------------
                                    999 ;i             Allocated with name '_layer_hold_clear_i_20000_341'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function layer_hold_clear
                                   1004 ;	-----------------------------------------
      007968                       1005 _layer_hold_clear:
      007968 90 08 45         [24] 1006 	mov	dptr,#_macro_layers
      00796B E4               [12] 1007 	clr	a
      00796C F0               [24] 1008 	movx	@dptr,a
      00796D FF               [12] 1009 	mov	r7,a
      00796E                       1010 00103$:
      00796E BF 06 00         [24] 1011 	cjne	r7,#0x06,00122$
      007971                       1012 00122$:
      007971 50 0D            [24] 1013 	jnc	00101$
      007973 EF               [12] 1014 	mov	a,r7
      007974 24 3F            [12] 1015 	add	a, #_layer_refs
      007976 F5 82            [12] 1016 	mov	dpl,a
      007978 E4               [12] 1017 	clr	a
      007979 34 08            [12] 1018 	addc	a, #(_layer_refs >> 8)
      00797B 12 7C 9B         [24] 1019 	lcall	_ak820_outline_0167
      00797E 80 EE            [24] 1020 	sjmp	00103$
      007980                       1021 00101$:
      007980 02 78 9A         [24] 1022 	ljmp	_ak820_layer_refresh
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1025 ;------------------------------------------------------------
                                   1026 ;state         Allocated with name '_layer_state_set_user_state_10000_342'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function layer_state_set_user
                                   1031 ;	-----------------------------------------
      007983                       1032 _layer_state_set_user:
      007983 E5 82            [12] 1033 	mov	a,dpl
      007985 90 08 49         [24] 1034 	mov	dptr,#_layer_state_set_user_state_10000_342
      007988 12 57 FB         [24] 1035 	lcall	_ak820_outline_0175
                                   1036 ;	quantum/action_layer.c:132: return state;
                                   1037 ;	quantum/action_layer.c:133: }
      00798B 22               [24] 1038 	ret
                                   1039 ;------------------------------------------------------------
                                   1040 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1041 ;------------------------------------------------------------
                                   1042 ;state         Allocated with name '_layer_state_set_kb_state_10000_344'
                                   1043 ;------------------------------------------------------------
                                   1044 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1045 ;	-----------------------------------------
                                   1046 ;	 function layer_state_set_kb
                                   1047 ;	-----------------------------------------
      00798C                       1048 _layer_state_set_kb:
      00798C E5 82            [12] 1049 	mov	a,dpl
      00798E 90 08 4A         [24] 1050 	mov	dptr,#_layer_state_set_kb_state_10000_344
      007991 12 57 FB         [24] 1051 	lcall	_ak820_outline_0175
                                   1052 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1053 ;	quantum/action_layer.c:141: }
      007994 02 79 83         [24] 1054 	ljmp	_layer_state_set_user
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'layer_state_set'
                                   1057 ;------------------------------------------------------------
                                   1058 ;state         Allocated with name '_layer_state_set_state_10000_346'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function layer_state_set
                                   1063 ;	-----------------------------------------
      007997                       1064 _layer_state_set:
      007997 E5 82            [12] 1065 	mov	a,dpl
      007999 90 08 4B         [24] 1066 	mov	dptr,#_layer_state_set_state_10000_346
      00799C F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/action_layer.c:149: persistent_layers = state;
      00799D E0               [24] 1069 	movx	a,@dptr
      00799E 90 08 3E         [24] 1070 	mov	dptr,#_persistent_layers
      0079A1 F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1073 ;	quantum/action_layer.c:151: return;
                                   1074 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1075 ;	quantum/action_layer.c:165: }
      0079A2 02 78 9A         [24] 1076 	ljmp	_ak820_layer_refresh
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'layer_clear'
                                   1079 ;------------------------------------------------------------
                                   1080 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1081 ;	-----------------------------------------
                                   1082 ;	 function layer_clear
                                   1083 ;	-----------------------------------------
      0079A5                       1084 _layer_clear:
                                   1085 ;	quantum/action_layer.c:172: layer_state_set(0);
      0079A5 75 82 00         [24] 1086 	mov	dpl, #0x00
                                   1087 ;	quantum/action_layer.c:173: }
      0079A8 02 79 97         [24] 1088 	ljmp	_layer_state_set
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'layer_state_is'
                                   1091 ;------------------------------------------------------------
                                   1092 ;layer         Allocated with name '_layer_state_is_layer_10000_353'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function layer_move
                                   1097 ;	-----------------------------------------
      0079AB                       1098 _layer_move:
      0079AB E5 82            [12] 1099 	mov	a,dpl
      0079AD 90 08 4C         [24] 1100 	mov	dptr,#_layer_move_layer_10000_359
      0079B0 F0               [24] 1101 	movx	@dptr,a
                                   1102 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      0079B1 E0               [24] 1103 	movx	a,@dptr
      0079B2 12 77 DE         [24] 1104 	lcall	_ak820_outline_0071
      0079B5 80 02            [24] 1105 	sjmp	00104$
      0079B7                       1106 00103$:
      0079B7 25 E0            [12] 1107 	add	a,acc
      0079B9                       1108 00104$:
      0079B9 D5 F0 FB         [24] 1109 	djnz	b,00103$
      0079BC F5 82            [12] 1110 	mov	dpl,a
                                   1111 ;	quantum/action_layer.c:200: }
      0079BE 02 79 97         [24] 1112 	ljmp	_layer_state_set
                                   1113 ;------------------------------------------------------------
                                   1114 ;Allocation info for local variables in function 'layer_on'
                                   1115 ;------------------------------------------------------------
                                   1116 ;layer         Allocated with name '_layer_on_layer_10000_361'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function layer_on
                                   1121 ;	-----------------------------------------
      0079C1                       1122 _layer_on:
      0079C1 E5 82            [12] 1123 	mov	a,dpl
      0079C3 90 08 4D         [24] 1124 	mov	dptr,#_layer_on_layer_10000_361
      0079C6 F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      0079C7 E0               [24] 1127 	movx	a,@dptr
      0079C8 12 77 DE         [24] 1128 	lcall	_ak820_outline_0071
      0079CB 80 02            [24] 1129 	sjmp	00104$
      0079CD                       1130 00103$:
      0079CD 25 E0            [12] 1131 	add	a,acc
      0079CF                       1132 00104$:
      0079CF D5 F0 FB         [24] 1133 	djnz	b,00103$
      0079D2 FF               [12] 1134 	mov	r7,a
      0079D3 90 08 3E         [24] 1135 	mov	dptr,#_persistent_layers
      0079D6 12 7C 95         [24] 1136 	lcall	_ak820_outline_0148
                                   1137 ;	quantum/action_layer.c:214: }
      0079D9 02 79 97         [24] 1138 	ljmp	_layer_state_set
                                   1139 ;------------------------------------------------------------
                                   1140 ;Allocation info for local variables in function 'layer_off'
                                   1141 ;------------------------------------------------------------
                                   1142 ;layer         Allocated with name '_layer_off_layer_10000_363'
                                   1143 ;------------------------------------------------------------
                                   1144 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1145 ;	-----------------------------------------
                                   1146 ;	 function layer_off
                                   1147 ;	-----------------------------------------
      0079DC                       1148 _layer_off:
      0079DC E5 82            [12] 1149 	mov	a,dpl
      0079DE 90 08 4E         [24] 1150 	mov	dptr,#_layer_off_layer_10000_363
      0079E1 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      0079E2 E0               [24] 1153 	movx	a,@dptr
      0079E3 12 77 DE         [24] 1154 	lcall	_ak820_outline_0071
      0079E6 80 02            [24] 1155 	sjmp	00104$
      0079E8                       1156 00103$:
      0079E8 25 E0            [12] 1157 	add	a,acc
      0079EA                       1158 00104$:
      0079EA D5 F0 FB         [24] 1159 	djnz	b,00103$
      0079ED F4               [12] 1160 	cpl	a
      0079EE FF               [12] 1161 	mov	r7,a
      0079EF 90 08 3E         [24] 1162 	mov	dptr,#_persistent_layers
      0079F2 E0               [24] 1163 	movx	a,@dptr
      0079F3 52 07            [12] 1164 	anl	ar7,a
      0079F5 8F 82            [24] 1165 	mov	dpl, r7
                                   1166 ;	quantum/action_layer.c:228: }
      0079F7 02 79 97         [24] 1167 	ljmp	_layer_state_set
                                   1168 ;------------------------------------------------------------
                                   1169 ;Allocation info for local variables in function 'layer_invert'
                                   1170 ;------------------------------------------------------------
                                   1171 ;layer         Allocated with name '_layer_invert_layer_10000_365'
                                   1172 ;------------------------------------------------------------
                                   1173 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1174 ;	-----------------------------------------
                                   1175 ;	 function layer_or
                                   1176 ;	-----------------------------------------
      0079FA                       1177 _layer_or:
      0079FA E5 82            [12] 1178 	mov	a,dpl
      0079FC 90 08 4F         [24] 1179 	mov	dptr,#_layer_or_state_10000_367
      0079FF F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	quantum/action_layer.c:255: state);
      007A00 E0               [24] 1182 	movx	a,@dptr
      007A01 FF               [12] 1183 	mov	r7,a
      007A02 90 08 3E         [24] 1184 	mov	dptr,#_persistent_layers
      007A05 12 7C 95         [24] 1185 	lcall	_ak820_outline_0148
                                   1186 ;	quantum/action_layer.c:256: }
      007A08 02 79 97         [24] 1187 	ljmp	_layer_state_set
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'layer_and'
                                   1190 ;------------------------------------------------------------
                                   1191 ;state         Allocated with name '_layer_and_state_10000_369'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function layer_and
                                   1196 ;	-----------------------------------------
      007A0B                       1197 _layer_and:
      007A0B E5 82            [12] 1198 	mov	a,dpl
      007A0D 90 08 50         [24] 1199 	mov	dptr,#_layer_and_state_10000_369
      007A10 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	quantum/action_layer.c:268: state);
      007A11 90 08 3E         [24] 1202 	mov	dptr,#_persistent_layers
      007A14 E0               [24] 1203 	movx	a,@dptr
      007A15 FF               [12] 1204 	mov	r7,a
      007A16 90 08 50         [24] 1205 	mov	dptr,#_layer_and_state_10000_369
      007A19 E0               [24] 1206 	movx	a,@dptr
      007A1A 52 07            [12] 1207 	anl	ar7,a
      007A1C 8F 82            [24] 1208 	mov	dpl, r7
                                   1209 ;	quantum/action_layer.c:269: }
      007A1E 02 79 97         [24] 1210 	ljmp	_layer_state_set
                                   1211 ;------------------------------------------------------------
                                   1212 ;Allocation info for local variables in function 'layer_xor'
                                   1213 ;------------------------------------------------------------
                                   1214 ;state         Allocated with name '_layer_xor_state_10000_371'
                                   1215 ;------------------------------------------------------------
                                   1216 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1217 ;	-----------------------------------------
                                   1218 ;	 function layer_xor
                                   1219 ;	-----------------------------------------
      007A21                       1220 _layer_xor:
      007A21 E5 82            [12] 1221 	mov	a,dpl
      007A23 90 08 51         [24] 1222 	mov	dptr,#_layer_xor_state_10000_371
      007A26 F0               [24] 1223 	movx	@dptr,a
                                   1224 ;	quantum/action_layer.c:281: state);
      007A27 E0               [24] 1225 	movx	a,@dptr
      007A28 FF               [12] 1226 	mov	r7,a
      007A29 90 08 3E         [24] 1227 	mov	dptr,#_persistent_layers
      007A2C E0               [24] 1228 	movx	a,@dptr
      007A2D 62 07            [12] 1229 	xrl	ar7,a
      007A2F 8F 82            [24] 1230 	mov	dpl, r7
                                   1231 ;	quantum/action_layer.c:282: }
      007A31 02 79 97         [24] 1232 	ljmp	_layer_state_set
                                   1233 ;------------------------------------------------------------
                                   1234 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1235 ;------------------------------------------------------------
                                   1236 ;key           Allocated with name '_source_keycode_cache_slot_PARM_1'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(keypos_t key) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function source_keycode_cache_slot
                                   1241 ;	-----------------------------------------
      007A34                       1242 _source_keycode_cache_slot:
                                   1243 ;	quantum/action_layer.c:325: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) {
      007A34 90 09 57         [24] 1244 	mov	dptr,#(_source_keycode_cache_slot_PARM_1 + 0x0001)
      007A37 E0               [24] 1245 	movx	a,@dptr
      007A38 FF               [12] 1246 	mov	r7,a
      007A39 BF 10 00         [24] 1247 	cjne	r7,#0x10,00147$
      007A3C                       1248 00147$:
      007A3C 50 1D            [24] 1249 	jnc	00102$
      007A3E 90 09 56         [24] 1250 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007A41 E0               [24] 1251 	movx	a,@dptr
      007A42 FE               [12] 1252 	mov	r6,a
      007A43 BE 08 00         [24] 1253 	cjne	r6,#0x08,00149$
      007A46                       1254 00149$:
      007A46 50 13            [24] 1255 	jnc	00102$
                                   1256 ;	quantum/action_layer.c:326: return &source_keycodes_cache[(uint8_t)(key.row * MATRIX_COLS + key.col)];
      007A48 12 49 29         [24] 1257 	lcall	_ak820_outline_0177
      007A4B 75 F0 02         [24] 1258 	mov	b,#0x02
      007A4E A4               [48] 1259 	mul	ab
      007A4F 24 52            [12] 1260 	add	a, #_source_keycodes_cache
      007A51 FD               [12] 1261 	mov	r5,a
      007A52 74 08            [12] 1262 	mov	a,#(_source_keycodes_cache >> 8)
      007A54 35 F0            [12] 1263 	addc	a, b
      007A56 FE               [12] 1264 	mov	r6,a
      007A57 12 39 17         [24] 1265 	lcall	_ak820_outline_0141
      007A5A 22               [24] 1266 	ret
      007A5B                       1267 00102$:
                                   1268 ;	quantum/action_layer.c:329: if ((key.row == KEYLOC_ENCODER_CW || key.row == KEYLOC_ENCODER_CCW) && key.col < NUM_ENCODERS) {
      007A5B BF FD 02         [24] 1269 	cjne	r7,#0xfd,00151$
      007A5E 80 03            [24] 1270 	sjmp	00107$
      007A60                       1271 00151$:
      007A60 BF FC 33         [24] 1272 	cjne	r7,#0xfc,00105$
      007A63                       1273 00107$:
      007A63 90 09 56         [24] 1274 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007A66 E0               [24] 1275 	movx	a,@dptr
      007A67 FE               [12] 1276 	mov	r6,a
      007A68 BE 01 00         [24] 1277 	cjne	r6,#0x01,00154$
      007A6B                       1278 00154$:
      007A6B 50 29            [24] 1279 	jnc	00105$
                                   1280 ;	quantum/action_layer.c:330: return &encoder_source_keycodes_cache[key.col + (key.row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007A6D BF FC 04         [24] 1281 	cjne	r7,#0xfc,00110$
      007A70 7F 01            [12] 1282 	mov	r7,#0x01
      007A72 80 02            [24] 1283 	sjmp	00111$
      007A74                       1284 00110$:
      007A74 7F 00            [12] 1285 	mov	r7,#0x00
      007A76                       1286 00111$:
      007A76 C2 D5            [12] 1287 	clr	F0
      007A78 75 F0 02         [24] 1288 	mov	b,#0x02
      007A7B EF               [12] 1289 	mov	a,r7
      007A7C 30 E7 04         [24] 1290 	jnb	acc.7,00158$
      007A7F B2 D5            [12] 1291 	cpl	F0
      007A81 F4               [12] 1292 	cpl	a
      007A82 04               [12] 1293 	inc	a
      007A83                       1294 00158$:
      007A83 A4               [48] 1295 	mul	ab
      007A84 30 D5 03         [24] 1296 	jnb	F0,00159$
      007A87 12 70 94         [24] 1297 	lcall	_ak820_outline_0137
      007A8A                       1298 00159$:
      007A8A 24 52            [12] 1299 	add	a, #_encoder_source_keycodes_cache
      007A8C FE               [12] 1300 	mov	r6,a
      007A8D 74 09            [12] 1301 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007A8F 35 F0            [12] 1302 	addc	a, b
      007A91 FF               [12] 1303 	mov	r7,a
      007A92 12 39 08         [24] 1304 	lcall	_ak820_outline_0123
      007A95 22               [24] 1305 	ret
      007A96                       1306 00105$:
                                   1307 ;	quantum/action_layer.c:333: return 0;
      007A96 90 00 00         [24] 1308 	mov	dptr,#0x0000
                                   1309 ;	quantum/action_layer.c:334: }
      007A99 22               [24] 1310 	ret
                                   1311 ;------------------------------------------------------------
                                   1312 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1313 ;------------------------------------------------------------
                                   1314 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1315 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_379'
                                   1316 ;slot          Allocated with name '_update_source_keycode_cache_slot_10000_380'
                                   1317 ;------------------------------------------------------------
                                   1318 ;	quantum/action_layer.c:338: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1319 ;	-----------------------------------------
                                   1320 ;	 function update_source_keycode_cache
                                   1321 ;	-----------------------------------------
      007A9A                       1322 _update_source_keycode_cache:
      007A9A 12 39 03         [24] 1323 	lcall	_ak820_outline_0122
      007A9D 90 09 5A         [24] 1324 	mov	dptr,#_update_source_keycode_cache_keycode_10000_379
      007AA0 12 38 FE         [24] 1325 	lcall	_ak820_outline_0121
                                   1326 ;	quantum/action_layer.c:339: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      007AA3 90 0D C2         [24] 1327 	mov	dptr,#___memcpy_PARM_2
      007AA6 74 58            [12] 1328 	mov	a,#_update_source_keycode_cache_PARM_1
      007AA8 F0               [24] 1329 	movx	@dptr,a
      007AA9 74 09            [12] 1330 	mov	a,#(_update_source_keycode_cache_PARM_1 >> 8)
      007AAB 12 7C 7D         [24] 1331 	lcall	_ak820_outline_0002
      007AAE 90 09 56         [24] 1332 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007AB1 F5 F0            [12] 1333 	mov	b,a
      007AB3 12 BC 07         [24] 1334 	lcall	___memcpy
      007AB6 12 7A 34         [24] 1335 	lcall	_source_keycode_cache_slot
      007AB9 12 43 D5         [24] 1336 	lcall	_ak820_outline_0131
                                   1337 ;	quantum/action_layer.c:340: if (!slot) return false;
      007ABC EE               [12] 1338 	mov	a,r6
      007ABD 4F               [12] 1339 	orl	a,r7
      007ABE 70 03            [24] 1340 	jnz	00102$
      007AC0 F5 82            [12] 1341 	mov	dpl,a
      007AC2 22               [24] 1342 	ret
      007AC3                       1343 00102$:
                                   1344 ;	quantum/action_layer.c:341: *slot = keycode;
      007AC3 90 09 5A         [24] 1345 	mov	dptr,#_update_source_keycode_cache_keycode_10000_379
      007AC6 12 38 DA         [24] 1346 	lcall	_ak820_outline_0076
      007AC9 12 39 08         [24] 1347 	lcall	_ak820_outline_0123
      007ACC 12 38 E6         [24] 1348 	lcall	_ak820_outline_0087
                                   1349 ;	quantum/action_layer.c:342: return true;
      007ACF 75 82 01         [24] 1350 	mov	dpl, #0x01
                                   1351 ;	quantum/action_layer.c:343: }
      007AD2 22               [24] 1352 	ret
                                   1353 ;------------------------------------------------------------
                                   1354 ;Allocation info for local variables in function 'update_source_layers_cache'
                                   1355 ;------------------------------------------------------------
                                   1356 ;key           Allocated with name '_update_source_layers_cache_PARM_1'
                                   1357 ;layer         Allocated with name '_update_source_layers_cache_layer_10000_382'
                                   1358 ;slot          Allocated with name '_update_source_layers_cache_slot_10000_383'
                                   1359 ;------------------------------------------------------------
                                   1360 ;	quantum/action_layer.c:345: void update_source_layers_cache(keypos_t key, uint8_t layer) {
                                   1361 ;	-----------------------------------------
                                   1362 ;	 function update_source_layers_cache
                                   1363 ;	-----------------------------------------
      007AD3                       1364 _update_source_layers_cache:
      007AD3 E5 82            [12] 1365 	mov	a,dpl
      007AD5 90 09 5E         [24] 1366 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      007AD8 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/action_layer.c:346: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      007AD9 12 7C AA         [24] 1369 	lcall	_ak820_outline_0181
      007ADC 12 7C 7D         [24] 1370 	lcall	_ak820_outline_0002
      007ADF 90 09 56         [24] 1371 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007AE2 F5 F0            [12] 1372 	mov	b,a
      007AE4 12 BC 07         [24] 1373 	lcall	___memcpy
      007AE7 12 7A 34         [24] 1374 	lcall	_source_keycode_cache_slot
      007AEA 12 43 D5         [24] 1375 	lcall	_ak820_outline_0131
                                   1376 ;	quantum/action_layer.c:347: if (!slot) return;
      007AED EE               [12] 1377 	mov	a,r6
      007AEE 4F               [12] 1378 	orl	a,r7
      007AEF 70 01            [24] 1379 	jnz	00102$
      007AF1 22               [24] 1380 	ret
      007AF2                       1381 00102$:
                                   1382 ;	quantum/action_layer.c:348: layer &= (1u << MAX_LAYER_BITS) - 1;
      007AF2 90 09 5E         [24] 1383 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      007AF5 E0               [24] 1384 	movx	a,@dptr
      007AF6 53 E0 07         [24] 1385 	anl	acc,#0x07
      007AF9 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/action_layer.c:359: *slot = keymap_key_to_keycode(layer, key);
      007AFA 90 09 5E         [24] 1388 	mov	dptr,#_update_source_layers_cache_layer_10000_382
      007AFD E0               [24] 1389 	movx	a,@dptr
      007AFE FD               [12] 1390 	mov	r5,a
      007AFF 12 7C AA         [24] 1391 	lcall	_ak820_outline_0181
      007B02 12 7C 7D         [24] 1392 	lcall	_ak820_outline_0002
      007B05 90 0B A7         [24] 1393 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      007B08 F5 F0            [12] 1394 	mov	b,a
      007B0A C0 07            [24] 1395 	push	ar7
      007B0C C0 06            [24] 1396 	push	ar6
      007B0E C0 05            [24] 1397 	push	ar5
      007B10 12 BC 07         [24] 1398 	lcall	___memcpy
      007B13 D0 05            [24] 1399 	pop	ar5
      007B15 8D 82            [24] 1400 	mov	dpl, r5
      007B17 12 98 36         [24] 1401 	lcall	_keymap_key_to_keycode
      007B1A 12 43 F4         [24] 1402 	lcall	_ak820_outline_0193
      007B1D D0 06            [24] 1403 	pop	ar6
      007B1F D0 07            [24] 1404 	pop	ar7
      007B21 12 39 08         [24] 1405 	lcall	_ak820_outline_0123
      007B24 12 38 E6         [24] 1406 	lcall	_ak820_outline_0087
                                   1407 ;	quantum/action_layer.c:360: }
      007B27 22               [24] 1408 	ret
                                   1409 ;------------------------------------------------------------
                                   1410 ;Allocation info for local variables in function 'read_source_keycode_cache'
                                   1411 ;------------------------------------------------------------
                                   1412 ;key           Allocated with name '_read_source_keycode_cache_PARM_1'
                                   1413 ;slot          Allocated with name '_read_source_keycode_cache_slot_10001_389'
                                   1414 ;------------------------------------------------------------
                                   1415 ;	quantum/action_layer.c:381: uint16_t read_source_keycode_cache(keypos_t key) {
                                   1416 ;	-----------------------------------------
                                   1417 ;	 function read_source_keycode_cache
                                   1418 ;	-----------------------------------------
      007B28                       1419 _read_source_keycode_cache:
                                   1420 ;	quantum/action_layer.c:384: if (vial_unlock_in_progress) return KC_NO;
      007B28 90 0E 43         [24] 1421 	mov	dptr,#_vial_unlock_in_progress
      007B2B E0               [24] 1422 	movx	a,@dptr
      007B2C 60 04            [24] 1423 	jz	00102$
      007B2E 90 00 00         [24] 1424 	mov	dptr,#0x0000
      007B31 22               [24] 1425 	ret
      007B32                       1426 00102$:
                                   1427 ;	quantum/action_layer.c:385: if (key.row == VIAL_MATRIX_MAGIC && key.col == VIAL_MATRIX_MAGIC) return g_vial_magic_keycode_override;
      007B32 90 09 60         [24] 1428 	mov	dptr,#(_read_source_keycode_cache_PARM_1 + 0x0001)
      007B35 E0               [24] 1429 	movx	a,@dptr
      007B36 FF               [12] 1430 	mov	r7,a
      007B37 BF F0 0F         [24] 1431 	cjne	r7,#0xf0,00104$
      007B3A 90 09 5F         [24] 1432 	mov	dptr,#_read_source_keycode_cache_PARM_1
      007B3D E0               [24] 1433 	movx	a,@dptr
      007B3E FF               [12] 1434 	mov	r7,a
      007B3F BF F0 07         [24] 1435 	cjne	r7,#0xf0,00104$
      007B42 90 0C 9A         [24] 1436 	mov	dptr,#_g_vial_magic_keycode_override
      007B45 12 38 81         [24] 1437 	lcall	_ak820_outline_0010
      007B48 22               [24] 1438 	ret
      007B49                       1439 00104$:
                                   1440 ;	quantum/action_layer.c:387: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(key);
      007B49 90 0D C2         [24] 1441 	mov	dptr,#___memcpy_PARM_2
      007B4C 74 5F            [12] 1442 	mov	a,#_read_source_keycode_cache_PARM_1
      007B4E F0               [24] 1443 	movx	@dptr,a
      007B4F 74 09            [12] 1444 	mov	a,#(_read_source_keycode_cache_PARM_1 >> 8)
      007B51 12 7C 7D         [24] 1445 	lcall	_ak820_outline_0002
      007B54 90 09 56         [24] 1446 	mov	dptr,#_source_keycode_cache_slot_PARM_1
      007B57 F5 F0            [12] 1447 	mov	b,a
      007B59 12 BC 07         [24] 1448 	lcall	___memcpy
      007B5C 12 7A 34         [24] 1449 	lcall	_source_keycode_cache_slot
      007B5F 12 43 D5         [24] 1450 	lcall	_ak820_outline_0131
                                   1451 ;	quantum/action_layer.c:388: return slot ? *slot : KC_NO;
      007B62 EE               [12] 1452 	mov	a,r6
      007B63 4F               [12] 1453 	orl	a,r7
      007B64 60 08            [24] 1454 	jz	00108$
      007B66 12 39 08         [24] 1455 	lcall	_ak820_outline_0123
      007B69 12 38 C3         [24] 1456 	lcall	_ak820_outline_0060
      007B6C 80 04            [24] 1457 	sjmp	00109$
      007B6E                       1458 00108$:
      007B6E 7E 00            [12] 1459 	mov	r6,#0x00
      007B70 7F 00            [12] 1460 	mov	r7,#0x00
      007B72                       1461 00109$:
      007B72 12 39 08         [24] 1462 	lcall	_ak820_outline_0123
                                   1463 ;	quantum/action_layer.c:389: }
      007B75 22               [24] 1464 	ret
                                   1465 ;------------------------------------------------------------
                                   1466 ;Allocation info for local variables in function 'store_or_get_action'
                                   1467 ;------------------------------------------------------------
                                   1468 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1469 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_390'
                                   1470 ;------------------------------------------------------------
                                   1471 ;	quantum/action_layer.c:478: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1472 ;	-----------------------------------------
                                   1473 ;	 function store_or_get_action
                                   1474 ;	-----------------------------------------
      007B76                       1475 _store_or_get_action:
      007B76 E5 82            [12] 1476 	mov	a,dpl
      007B78 90 09 63         [24] 1477 	mov	dptr,#_store_or_get_action_pressed_10000_390
      007B7B F0               [24] 1478 	movx	@dptr,a
                                   1479 ;	quantum/action_layer.c:480: if (disable_action_cache) {
      007B7C 90 0D E2         [24] 1480 	mov	dptr,#_disable_action_cache
      007B7F E0               [24] 1481 	movx	a,@dptr
      007B80 60 11            [24] 1482 	jz	00102$
                                   1483 ;	quantum/action_layer.c:481: return layer_switch_get_action(key);
      007B82 12 7C 8C         [24] 1484 	lcall	_ak820_outline_0059
      007B85 12 7C 7D         [24] 1485 	lcall	_ak820_outline_0002
      007B88 90 09 69         [24] 1486 	mov	dptr,#_layer_switch_get_action_PARM_1
      007B8B F5 F0            [12] 1487 	mov	b,a
      007B8D 12 BC 07         [24] 1488 	lcall	___memcpy
      007B90 02 7C 53         [24] 1489 	ljmp	_layer_switch_get_action
      007B93                       1490 00102$:
                                   1491 ;	quantum/action_layer.c:485: if (pressed) update_source_layers_cache(key, layer_switch_get_layer(key));
      007B93 90 09 63         [24] 1492 	mov	dptr,#_store_or_get_action_pressed_10000_390
      007B96 E0               [24] 1493 	movx	a,@dptr
      007B97 60 2A            [24] 1494 	jz	00104$
      007B99 12 7C 8C         [24] 1495 	lcall	_ak820_outline_0059
      007B9C 12 7C 7D         [24] 1496 	lcall	_ak820_outline_0002
      007B9F 90 09 64         [24] 1497 	mov	dptr,#_layer_switch_get_layer_PARM_1
      007BA2 F5 F0            [12] 1498 	mov	b,a
      007BA4 12 BC 07         [24] 1499 	lcall	___memcpy
      007BA7 12 7B D9         [24] 1500 	lcall	_layer_switch_get_layer
      007BAA AF 82            [24] 1501 	mov	r7, dpl
      007BAC 12 7C 8C         [24] 1502 	lcall	_ak820_outline_0059
      007BAF 12 7C 7D         [24] 1503 	lcall	_ak820_outline_0002
      007BB2 90 09 5C         [24] 1504 	mov	dptr,#_update_source_layers_cache_PARM_1
      007BB5 F5 F0            [12] 1505 	mov	b,a
      007BB7 C0 07            [24] 1506 	push	ar7
      007BB9 12 BC 07         [24] 1507 	lcall	___memcpy
      007BBC D0 07            [24] 1508 	pop	ar7
      007BBE 8F 82            [24] 1509 	mov	dpl, r7
      007BC0 12 7A D3         [24] 1510 	lcall	_update_source_layers_cache
      007BC3                       1511 00104$:
                                   1512 ;	quantum/action_layer.c:486: return action_for_keycode(read_source_keycode_cache(key));
      007BC3 12 7C 8C         [24] 1513 	lcall	_ak820_outline_0059
      007BC6 12 7C 7D         [24] 1514 	lcall	_ak820_outline_0002
      007BC9 90 09 5F         [24] 1515 	mov	dptr,#_read_source_keycode_cache_PARM_1
      007BCC F5 F0            [12] 1516 	mov	b,a
      007BCE 12 BC 07         [24] 1517 	lcall	___memcpy
      007BD1 12 7B 28         [24] 1518 	lcall	_read_source_keycode_cache
      007BD4 AF 83            [24] 1519 	mov  r7,dph
                                   1520 ;	quantum/action_layer.c:500: }
      007BD6 02 96 D0         [24] 1521 	ljmp	_action_for_keycode
                                   1522 ;------------------------------------------------------------
                                   1523 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1524 ;------------------------------------------------------------
                                   1525 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1526 ;action        Allocated with name '_layer_switch_get_layer_action_10000_396'
                                   1527 ;layers        Allocated with name '_layer_switch_get_layer_layers_10001_397'
                                   1528 ;i             Allocated with name '_layer_switch_get_layer_i_20001_398'
                                   1529 ;------------------------------------------------------------
                                   1530 ;	quantum/action_layer.c:506: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1531 ;	-----------------------------------------
                                   1532 ;	 function layer_switch_get_layer
                                   1533 ;	-----------------------------------------
      007BD9                       1534 _layer_switch_get_layer:
                                   1535 ;	quantum/action_layer.c:509: action.code = ACTION_TRANSPARENT;
      007BD9 90 09 66         [24] 1536 	mov	dptr,#_layer_switch_get_layer_action_10000_396
      007BDC 74 01            [12] 1537 	mov	a,#0x01
      007BDE 12 39 0D         [24] 1538 	lcall	_ak820_outline_0130
                                   1539 ;	quantum/action_layer.c:511: layer_state_t layers = layer_state | default_layer_state;
      007BE1 90 0D E3         [24] 1540 	mov	dptr,#_default_layer_state
      007BE4 E0               [24] 1541 	movx	a,@dptr
      007BE5 FF               [12] 1542 	mov	r7,a
      007BE6 90 0D E4         [24] 1543 	mov	dptr,#_layer_state
      007BE9 E0               [24] 1544 	movx	a,@dptr
      007BEA 90 09 68         [24] 1545 	mov	dptr,#_layer_switch_get_layer_layers_10001_397
      007BED 4F               [12] 1546 	orl	a,r7
      007BEE F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/action_layer.c:513: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007BEF 7F 05            [12] 1549 	mov	r7,#0x05
      007BF1                       1550 00107$:
      007BF1 EF               [12] 1551 	mov	a,r7
      007BF2 20 E7 5A         [24] 1552 	jb	acc.7,00105$
                                   1553 ;	quantum/action_layer.c:514: if (layers & ((layer_state_t)1 << i)) {
      007BF5 8F F0            [24] 1554 	mov	b,r7
      007BF7 05 F0            [12] 1555 	inc	b
      007BF9 7D 01            [12] 1556 	mov	r5,#0x01
      007BFB 7E 00            [12] 1557 	mov	r6,#0x00
      007BFD 80 06            [24] 1558 	sjmp	00141$
      007BFF                       1559 00140$:
      007BFF ED               [12] 1560 	mov	a,r5
      007C00 2D               [12] 1561 	add	a,r5
      007C01 FD               [12] 1562 	mov	r5,a
      007C02 EE               [12] 1563 	mov	a,r6
      007C03 33               [12] 1564 	rlc	a
      007C04 FE               [12] 1565 	mov	r6,a
      007C05                       1566 00141$:
      007C05 D5 F0 F7         [24] 1567 	djnz	b,00140$
      007C08 90 09 68         [24] 1568 	mov	dptr,#_layer_switch_get_layer_layers_10001_397
      007C0B E0               [24] 1569 	movx	a,@dptr
      007C0C 7C 00            [12] 1570 	mov	r4,#0x00
      007C0E 52 05            [12] 1571 	anl	ar5,a
      007C10 EC               [12] 1572 	mov	a,r4
      007C11 52 06            [12] 1573 	anl	ar6,a
      007C13 ED               [12] 1574 	mov	a,r5
      007C14 4E               [12] 1575 	orl	a,r6
      007C15 60 35            [24] 1576 	jz	00108$
                                   1577 ;	quantum/action_layer.c:515: action.code = action_for_key(i, key);
      007C17 90 0D C2         [24] 1578 	mov	dptr,#___memcpy_PARM_2
      007C1A 74 64            [12] 1579 	mov	a,#_layer_switch_get_layer_PARM_1
      007C1C F0               [24] 1580 	movx	@dptr,a
      007C1D 74 09            [12] 1581 	mov	a,#(_layer_switch_get_layer_PARM_1 >> 8)
      007C1F 12 7C 7D         [24] 1582 	lcall	_ak820_outline_0002
      007C22 90 0B 9D         [24] 1583 	mov	dptr,#_action_for_key_PARM_2
      007C25 F5 F0            [12] 1584 	mov	b,a
      007C27 C0 07            [24] 1585 	push	ar7
      007C29 12 BC 07         [24] 1586 	lcall	___memcpy
      007C2C D0 07            [24] 1587 	pop	ar7
      007C2E 8F 82            [24] 1588 	mov	dpl, r7
      007C30 C0 07            [24] 1589 	push	ar7
      007C32 12 96 A1         [24] 1590 	lcall	_action_for_key
      007C35 AD 82            [24] 1591 	mov	r5, dpl
      007C37 AE 83            [24] 1592 	mov	r6, dph
      007C39 D0 07            [24] 1593 	pop	ar7
      007C3B 90 09 66         [24] 1594 	mov	dptr,#_layer_switch_get_layer_action_10000_396
      007C3E 12 43 C9         [24] 1595 	lcall	_ak820_outline_0126
                                   1596 ;	quantum/action_layer.c:516: if (action.code != ACTION_TRANSPARENT) {
      007C41 BD 01 05         [24] 1597 	cjne	r5,#0x01,00143$
      007C44 BE 00 02         [24] 1598 	cjne	r6,#0x00,00143$
      007C47 80 03            [24] 1599 	sjmp	00108$
      007C49                       1600 00143$:
                                   1601 ;	quantum/action_layer.c:517: return i;
      007C49 8F 82            [24] 1602 	mov	dpl, r7
      007C4B 22               [24] 1603 	ret
      007C4C                       1604 00108$:
                                   1605 ;	quantum/action_layer.c:513: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007C4C 1F               [12] 1606 	dec	r7
      007C4D 80 A2            [24] 1607 	sjmp	00107$
      007C4F                       1608 00105$:
                                   1609 ;	quantum/action_layer.c:522: return 0;
      007C4F 75 82 00         [24] 1610 	mov	dpl, #0x00
                                   1611 ;	quantum/action_layer.c:527: }
      007C52 22               [24] 1612 	ret
                                   1613 ;------------------------------------------------------------
                                   1614 ;Allocation info for local variables in function 'layer_switch_get_action'
                                   1615 ;------------------------------------------------------------
                                   1616 ;key           Allocated with name '_layer_switch_get_action_PARM_1'
                                   1617 ;layer         Allocated with name '_layer_switch_get_action_layer_10000_405'
                                   1618 ;action        Allocated with name '_layer_switch_get_action_action_10000_405'
                                   1619 ;------------------------------------------------------------
                                   1620 ;	quantum/action_layer.c:533: uint16_t layer_switch_get_action(keypos_t key) {
                                   1621 ;	-----------------------------------------
                                   1622 ;	 function layer_switch_get_action
                                   1623 ;	-----------------------------------------
      007C53                       1624 _layer_switch_get_action:
                                   1625 ;	quantum/action_layer.c:535: uint8_t layer = layer_switch_get_layer(key);
      007C53 12 7C A1         [24] 1626 	lcall	_ak820_outline_0180
      007C56 12 7C 7D         [24] 1627 	lcall	_ak820_outline_0002
      007C59 90 09 64         [24] 1628 	mov	dptr,#_layer_switch_get_layer_PARM_1
      007C5C F5 F0            [12] 1629 	mov	b,a
      007C5E 12 BC 07         [24] 1630 	lcall	___memcpy
      007C61 12 7B D9         [24] 1631 	lcall	_layer_switch_get_layer
      007C64 AF 82            [24] 1632 	mov	r7, dpl
                                   1633 ;	quantum/action_layer.c:538: action = action_for_key(layer, key);
      007C66 12 7C A1         [24] 1634 	lcall	_ak820_outline_0180
      007C69 12 7C 7D         [24] 1635 	lcall	_ak820_outline_0002
      007C6C 90 0B 9D         [24] 1636 	mov	dptr,#_action_for_key_PARM_2
      007C6F F5 F0            [12] 1637 	mov	b,a
      007C71 C0 07            [24] 1638 	push	ar7
      007C73 12 BC 07         [24] 1639 	lcall	___memcpy
      007C76 D0 07            [24] 1640 	pop	ar7
      007C78 8F 82            [24] 1641 	mov	dpl, r7
                                   1642 ;	quantum/action_layer.c:540: return action;
                                   1643 ;	quantum/action_layer.c:541: }
      007C7A 02 96 A1         [24] 1644 	ljmp	_action_for_key
                                   1645 ;------------------------------------------------------------
                                   1646 ;Allocation info for local variables in function 'update_tri_layer_state'
                                   1647 ;------------------------------------------------------------
                                   1648 ;layer1        Allocated with name '_update_tri_layer_state_PARM_2'
                                   1649 ;layer2        Allocated with name '_update_tri_layer_state_PARM_3'
                                   1650 ;layer3        Allocated with name '_update_tri_layer_state_PARM_4'
                                   1651 ;state         Allocated with name '_update_tri_layer_state_state_10000_406'
                                   1652 ;mask12        Allocated with name '_update_tri_layer_state_mask12_10000_407'
                                   1653 ;mask3         Allocated with name '_update_tri_layer_state_mask3_10000_407'
                                   1654 ;------------------------------------------------------------
                                   1655 ;	quantum/action_layer.c:544: layer_state_t update_tri_layer_state(layer_state_t state, uint8_t layer1, uint8_t layer2, uint8_t layer3) {
                                   1656 ;	-----------------------------------------
                                   1657 	.area CSEG    (CODE)
                                   1658 	.area CONST   (CODE)
                                   1659 	.area XINIT   (CODE)
      00C4DD                       1660 __xinit__default_layer_state:
      00C4DD 00                    1661 	.db #0x00	; 0
      00C4DE                       1662 __xinit__layer_state:
      00C4DE 00                    1663 	.db #0x00	; 0
                                   1664 	.area CABS    (ABS,CODE)
                                   1665 
                                   1666 ; Experimental exact instruction outlining.
                                   1667 	.globl _ak820_outline_0002
                                   1668 	.globl _ak820_outline_0010
                                   1669 	.globl _ak820_outline_0059
                                   1670 	.globl _ak820_outline_0060
                                   1671 	.globl _ak820_outline_0071
                                   1672 	.globl _ak820_outline_0076
                                   1673 	.globl _ak820_outline_0087
                                   1674 	.globl _ak820_outline_0121
                                   1675 	.globl _ak820_outline_0122
                                   1676 	.globl _ak820_outline_0123
                                   1677 	.globl _ak820_outline_0126
                                   1678 	.globl _ak820_outline_0130
                                   1679 	.globl _ak820_outline_0131
                                   1680 	.globl _ak820_outline_0137
                                   1681 	.globl _ak820_outline_0141
                                   1682 	.globl _ak820_outline_0148
                                   1683 	.globl _ak820_outline_0164
                                   1684 	.globl _ak820_outline_0167
                                   1685 	.globl _ak820_outline_0175
                                   1686 	.globl _ak820_outline_0177
                                   1687 	.globl _ak820_outline_0180
                                   1688 	.globl _ak820_outline_0181
                                   1689 	.globl _ak820_outline_0183
                                   1690 	.globl _ak820_outline_0193
                                   1691 
                                   1692 	.area CSEG (CODE)
                                   1693 ; function ak820_outline_0002
      007C7D                       1694 _ak820_outline_0002:
      007C7D A3               [24] 1695 	inc	dptr
      007C7E F0               [24] 1696 	movx	@dptr,a
      007C7F E4               [12] 1697 	clr	a
      007C80 A3               [24] 1698 	inc	dptr
      007C81 F0               [24] 1699 	movx	@dptr,a
      007C82 90 0D C5         [24] 1700 	mov	dptr,#___memcpy_PARM_3
      007C85 74 02            [12] 1701 	mov	a,#0x02
      007C87 F0               [24] 1702 	movx	@dptr,a
      007C88 E4               [12] 1703 	clr	a
      007C89 A3               [24] 1704 	inc	dptr
      007C8A F0               [24] 1705 	movx	@dptr,a
      007C8B 22               [24] 1706 	ret
                                   1707 
                                   1708 	.area CSEG (CODE)
                                   1709 ; function ak820_outline_0059
      007C8C                       1710 _ak820_outline_0059:
      007C8C 90 0D C2         [24] 1711 	mov	dptr,#___memcpy_PARM_2
      007C8F 74 61            [12] 1712 	mov	a,#_store_or_get_action_PARM_2
      007C91 F0               [24] 1713 	movx	@dptr,a
      007C92 74 09            [12] 1714 	mov	a,#(_store_or_get_action_PARM_2>>8)
      007C94 22               [24] 1715 	ret
                                   1716 
                                   1717 	.area CSEG (CODE)
                                   1718 ; function ak820_outline_0148
      007C95                       1719 _ak820_outline_0148:
      007C95 E0               [24] 1720 	movx	a,@dptr
      007C96 42 07            [12] 1721 	orl	ar7,a
      007C98 8F 82            [24] 1722 	mov	dpl,r7
      007C9A 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0167
      007C9B                       1727 _ak820_outline_0167:
      007C9B F5 83            [12] 1728 	mov	dph,a
      007C9D E4               [12] 1729 	clr	a
      007C9E F0               [24] 1730 	movx	@dptr,a
      007C9F 0F               [12] 1731 	inc	r7
      007CA0 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0180
      007CA1                       1736 _ak820_outline_0180:
      007CA1 90 0D C2         [24] 1737 	mov	dptr,#___memcpy_PARM_2
      007CA4 74 69            [12] 1738 	mov	a,#_layer_switch_get_action_PARM_1
      007CA6 F0               [24] 1739 	movx	@dptr,a
      007CA7 74 09            [12] 1740 	mov	a,#(_layer_switch_get_action_PARM_1>>8)
      007CA9 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0181
      007CAA                       1745 _ak820_outline_0181:
      007CAA 90 0D C2         [24] 1746 	mov	dptr,#___memcpy_PARM_2
      007CAD 74 5C            [12] 1747 	mov	a,#_update_source_layers_cache_PARM_1
      007CAF F0               [24] 1748 	movx	@dptr,a
      007CB0 74 09            [12] 1749 	mov	a,#(_update_source_layers_cache_PARM_1>>8)
      007CB2 22               [24] 1750 	ret
                                   1751 
                                   1752 	.area CSEG (CODE)
                                   1753 ; function ak820_outline_0183
      007CB3                       1754 _ak820_outline_0183:
      007CB3 90 09 81         [24] 1755 	mov	dptr,#_ak820_macro_change_PARM_2
      007CB6 EF               [12] 1756 	mov	a,r7
      007CB7 F0               [24] 1757 	movx	@dptr,a
      007CB8 90 09 82         [24] 1758 	mov	dptr,#_ak820_macro_change_PARM_3
      007CBB 22               [24] 1759 	ret
