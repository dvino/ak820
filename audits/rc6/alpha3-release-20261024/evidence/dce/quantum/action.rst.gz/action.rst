                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _layer_switch_get_action
                                     40 	.globl _store_or_get_action
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _post_process_record_quantum
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mDelaymS
                                     57 	.globl _host_consumer_send
                                     58 	.globl _host_system_send
                                     59 	.globl _host_keyboard_leds
                                     60 	.globl _led_set
                                     61 	.globl _clear_keys_from_report
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000027                        587 _process_action_sloc0_1_0:
      000027                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001F                        605 _process_action_sloc1_1_0:
      00001F                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      00080E                        615 _tp_buttons::
      00080E                        616 	.ds 2
      000810                        617 _action_exec_PARM_1:
      000810                        618 	.ds 6
      000816                        619 _action_exec_record_10001_617:
      000816                        620 	.ds 9
      00081F                        621 _process_record_record_10000_623:
      00081F                        622 	.ds 3
      000822                        623 _process_record_handler_record_10000_631:
      000822                        624 	.ds 3
      000825                        625 _process_record_handler_action_10000_632:
      000825                        626 	.ds 2
      000827                        627 _process_action_PARM_2:
      000827                        628 	.ds 2
      000829                        629 _process_action_record_10000_643:
      000829                        630 	.ds 3
      00082C                        631 _process_action_on_40000_666:
      00082C                        632 	.ds 1
      00082D                        633 _register_code_code_10000_700:
      00082D                        634 	.ds 1
      00082E                        635 _unregister_code_code_10000_714:
      00082E                        636 	.ds 1
      00082F                        637 _tap_code_delay_PARM_2:
      00082F                        638 	.ds 2
      000831                        639 _tap_code_delay_code_10000_727:
      000831                        640 	.ds 1
      000832                        641 _tap_code_code_10000_734:
      000832                        642 	.ds 1
      000833                        643 _register_mods_mods_10000_736:
      000833                        644 	.ds 1
      000834                        645 _unregister_mods_mods_10000_740:
      000834                        646 	.ds 1
      000835                        647 _register_weak_mods_mods_10000_744:
      000835                        648 	.ds 1
      000836                        649 _unregister_weak_mods_mods_10000_748:
      000836                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DE2                        659 _disable_action_cache::
      000DE2                        660 	.ds 1
                                    661 	.area HOME    (CODE)
                                    662 	.area GSINIT0 (CODE)
                                    663 	.area GSINIT1 (CODE)
                                    664 	.area GSINIT2 (CODE)
                                    665 	.area GSINIT3 (CODE)
                                    666 	.area GSINIT4 (CODE)
                                    667 	.area GSINIT5 (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area CSEG    (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; global & static initialisations
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; Home
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area HOME    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; code
                                    685 ;--------------------------------------------------------
                                    686 	.area CSEG    (CODE)
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    689 ;------------------------------------------------------------
                                    690 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    693 ;	-----------------------------------------
                           000007   694 	ar7 = 0x07
                           000006   695 	ar6 = 0x06
                           000005   696 	ar5 = 0x05
                           000004   697 	ar4 = 0x04
                           000003   698 	ar3 = 0x03
                           000002   699 	ar2 = 0x02
                           000001   700 	ar1 = 0x01
                           000000   701 	ar0 = 0x00
                                    702 ;	 function action_exec
                                    703 ;	-----------------------------------------
      007115                        704 _action_exec:
                                    705 ;	quantum/action.c:83: ak820_combo_tick(event.time);
      007115 90 08 12         [24]  706 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007118 12 38 81         [24]  707 	lcall	_ak820_outline_0010
      00711B 12 36 86         [24]  708 	lcall	_ak820_combo_tick
                                    709 ;	quantum/action.c:86: if (!ak820_tapping_before(&event)) return;
      00711E 90 08 10         [24]  710 	mov	dptr,#_action_exec_PARM_1
      007121 12 44 C0         [24]  711 	lcall	_ak820_tapping_before
      007124 E5 82            [12]  712 	mov	a, dpl
      007126 70 01            [24]  713 	jnz	00102$
      007128 22               [24]  714 	ret
      007129                        715 00102$:
                                    716 ;	quantum/action.c:101: if (event.pressed) {
      007129 90 08 15         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00712C E0               [24]  718 	movx	a,@dptr
      00712D 60 03            [24]  719 	jz	00104$
                                    720 ;	quantum/action.c:103: clear_weak_mods();
      00712F 12 81 EB         [24]  721 	lcall	_clear_weak_mods
      007132                        722 00104$:
                                    723 ;	quantum/action.c:115: record.event = event;
      007132 90 0D C2         [24]  724 	mov	dptr,#___memcpy_PARM_2
      007135 74 10            [12]  725 	mov	a,#_action_exec_PARM_1
      007137 F0               [24]  726 	movx	@dptr,a
      007138 74 08            [12]  727 	mov	a,#(_action_exec_PARM_1 >> 8)
      00713A 12 38 E0         [24]  728 	lcall	_ak820_outline_0081
      00713D 90 0D C5         [24]  729 	mov	dptr,#___memcpy_PARM_3
      007140 74 06            [12]  730 	mov	a,#0x06
      007142 12 39 0D         [24]  731 	lcall	_ak820_outline_0130
      007145 90 08 16         [24]  732 	mov	dptr,#_action_exec_record_10001_617
      007148 F5 F0            [12]  733 	mov	b,a
      00714A 12 BC 07         [24]  734 	lcall	___memcpy
                                    735 ;	quantum/action.c:117: record.tap.count = 0;
      00714D 90 08 1C         [24]  736 	mov	dptr,#(_action_exec_record_10001_617 + 0x0006)
      007150 E0               [24]  737 	movx	a,@dptr
      007151 54 0F            [12]  738 	anl	a,#0x0f
      007153 F0               [24]  739 	movx	@dptr,a
                                    740 ;	quantum/action.c:122: record.keycode = 0;
      007154 90 08 1D         [24]  741 	mov	dptr,#(_action_exec_record_10001_617 + 0x0007)
      007157 12 4F B3         [24]  742 	lcall	_ak820_outline_0174
                                    743 ;	quantum/action.c:153: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00715A 90 08 1A         [24]  744 	mov	dptr,#(_action_exec_record_10001_617 + 0x0004)
      00715D E0               [24]  745 	movx	a,@dptr
      00715E 60 0D            [24]  746 	jz	00107$
      007160 90 08 16         [24]  747 	mov	dptr,#_action_exec_record_10001_617
      007163 75 F0 00         [24]  748 	mov	b, #0x00
      007166 12 A2 97         [24]  749 	lcall	_pre_process_record_quantum
      007169 E5 82            [12]  750 	mov	a, dpl
      00716B 60 14            [24]  751 	jz	00110$
      00716D                        752 00107$:
                                    753 ;	quantum/action.c:155: if (!ak820_tapping_process(&record)) return;
      00716D 90 08 16         [24]  754 	mov	dptr,#_action_exec_record_10001_617
      007170 12 45 AE         [24]  755 	lcall	_ak820_tapping_process
      007173 E5 82            [12]  756 	mov	a, dpl
      007175 70 01            [24]  757 	jnz	00106$
      007177 22               [24]  758 	ret
      007178                        759 00106$:
                                    760 ;	quantum/action.c:157: process_record(&record);
      007178 90 08 16         [24]  761 	mov	dptr,#_action_exec_record_10001_617
      00717B 75 F0 00         [24]  762 	mov	b, #0x00
                                    763 ;	quantum/action.c:167: }
      00717E 02 71 82         [24]  764 	ljmp	_process_record
      007181                        765 00110$:
      007181 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'process_record_nocache'
                                    769 ;------------------------------------------------------------
                                    770 ;record        Allocated with name '_process_record_nocache_record_10000_621'
                                    771 ;------------------------------------------------------------
                                    772 ;	quantum/action.c:251: void process_record_nocache(keyrecord_t *record) {
                                    773 ;	-----------------------------------------
                                    774 ;	 function process_record
                                    775 ;	-----------------------------------------
      007182                        776 _process_record:
      007182 12 43 80         [24]  777 	lcall	_ak820_outline_0036
      007185 90 08 1F         [24]  778 	mov	dptr,#_process_record_record_10000_623
      007188 12 38 8B         [24]  779 	lcall	_ak820_outline_0017
                                    780 ;	quantum/action.c:305: if (IS_NOEVENT(record->event)) {
      00718B 90 08 1F         [24]  781 	mov	dptr,#_process_record_record_10000_623
      00718E 12 4F 61         [24]  782 	lcall	_ak820_outline_0014
      007191 74 04            [12]  783 	mov	a,#0x04
      007193 12 77 B7         [24]  784 	lcall	_ak820_outline_0027
      007196 12 BC E0         [24]  785 	lcall	__gptrget
      007199 70 01            [24]  786 	jnz	00102$
                                    787 ;	quantum/action.c:306: return;
      00719B 22               [24]  788 	ret
      00719C                        789 00102$:
                                    790 ;	quantum/action.c:310: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00719C 8D 02            [24]  791 	mov	ar2,r5
      00719E 8E 03            [24]  792 	mov	ar3,r6
      0071A0 8F 04            [24]  793 	mov	ar4,r7
      0071A2 90 0D C2         [24]  794 	mov	dptr,#___memcpy_PARM_2
      0071A5 EA               [12]  795 	mov	a,r2
      0071A6 12 78 22         [24]  796 	lcall	_ak820_outline_0194
      0071A9 EC               [12]  797 	mov	a,r4
      0071AA A3               [24]  798 	inc	dptr
      0071AB F0               [24]  799 	movx	@dptr,a
      0071AC 90 0D C5         [24]  800 	mov	dptr,#___memcpy_PARM_3
      0071AF 12 4F 8C         [24]  801 	lcall	_ak820_outline_0067
      0071B2 90 06 1D         [24]  802 	mov	dptr,#_ak820_tapping_source_PARM_1
      0071B5 F5 F0            [12]  803 	mov	b,a
      0071B7 C0 07            [24]  804 	push	ar7
      0071B9 C0 06            [24]  805 	push	ar6
      0071BB C0 05            [24]  806 	push	ar5
      0071BD 12 BC 07         [24]  807 	lcall	___memcpy
      0071C0 12 43 FE         [24]  808 	lcall	_ak820_tapping_source
      0071C3 AC 82            [24]  809 	mov	r4, dpl
      0071C5 D0 05            [24]  810 	pop	ar5
      0071C7 D0 06            [24]  811 	pop	ar6
      0071C9 D0 07            [24]  812 	pop	ar7
                                    813 ;	quantum/action.c:311: bool oneshot_pressed = record->event.pressed;
      0071CB 74 05            [12]  814 	mov	a,#0x05
      0071CD 12 77 A9         [24]  815 	lcall	_ak820_outline_0015
      0071D0 12 BC E0         [24]  816 	lcall	__gptrget
      0071D3 FB               [12]  817 	mov	r3,a
                                    818 ;	quantum/action.c:312: record->keycode = get_record_keycode(record, true);
      0071D4 12 78 07         [24]  819 	lcall	_ak820_outline_0152
      0071D7 90 0C 06         [24]  820 	mov	dptr,#_get_record_keycode_PARM_2
      0071DA 74 01            [12]  821 	mov	a,#0x01
      0071DC 12 4F 6A         [24]  822 	lcall	_ak820_outline_0033
      0071DF C0 04            [24]  823 	push	ar4
      0071E1 C0 03            [24]  824 	push	ar3
      0071E3 C0 02            [24]  825 	push	ar2
      0071E5 C0 01            [24]  826 	push	ar1
      0071E7 C0 00            [24]  827 	push	ar0
      0071E9 12 A1 E2         [24]  828 	lcall	_get_record_keycode
      0071EC 12 43 D5         [24]  829 	lcall	_ak820_outline_0131
      0071EF D0 00            [24]  830 	pop	ar0
      0071F1 D0 01            [24]  831 	pop	ar1
      0071F3 D0 02            [24]  832 	pop	ar2
      0071F5 D0 03            [24]  833 	pop	ar3
      0071F7 D0 04            [24]  834 	pop	ar4
      0071F9 12 49 06         [24]  835 	lcall	_ak820_outline_0084
      0071FC EE               [12]  836 	mov	a,r6
      0071FD 12 BC A5         [24]  837 	lcall	__gptrput
      007200 A3               [24]  838 	inc	dptr
      007201 EF               [12]  839 	mov	a,r7
      007202 12 BC A5         [24]  840 	lcall	__gptrput
                                    841 ;	quantum/action.c:313: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007205 90 08 1F         [24]  842 	mov	dptr,#_process_record_record_10000_623
      007208 12 4F 61         [24]  843 	lcall	_ak820_outline_0014
      00720B 12 78 07         [24]  844 	lcall	_ak820_outline_0152
      00720E 12 49 06         [24]  845 	lcall	_ak820_outline_0084
      007211 12 BC E0         [24]  846 	lcall	__gptrget
      007214 F8               [12]  847 	mov	r0,a
      007215 A3               [24]  848 	inc	dptr
      007216 12 BC E0         [24]  849 	lcall	__gptrget
      007219 F9               [12]  850 	mov	r1,a
      00721A 90 06 2D         [24]  851 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00721D EC               [12]  852 	mov	a,r4
      00721E F0               [24]  853 	movx	@dptr,a
      00721F 90 06 2E         [24]  854 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007222 EB               [12]  855 	mov	a,r3
      007223 F0               [24]  856 	movx	@dptr,a
      007224 12 39 2E         [24]  857 	lcall	_ak820_outline_0155
      007227 C0 07            [24]  858 	push	ar7
      007229 C0 06            [24]  859 	push	ar6
      00722B C0 05            [24]  860 	push	ar5
      00722D C0 04            [24]  861 	push	ar4
      00722F C0 03            [24]  862 	push	ar3
      007231 12 47 64         [24]  863 	lcall	_ak820_oneshot_process
      007234 E5 82            [12]  864 	mov	a, dpl
      007236 D0 03            [24]  865 	pop	ar3
      007238 D0 04            [24]  866 	pop	ar4
      00723A D0 05            [24]  867 	pop	ar5
      00723C D0 06            [24]  868 	pop	ar6
      00723E D0 07            [24]  869 	pop	ar7
      007240 70 01            [24]  870 	jnz	00104$
      007242 22               [24]  871 	ret
      007243                        872 00104$:
                                    873 ;	quantum/action.c:315: if (!process_record_quantum(record)) {
      007243 12 6E 5E         [24]  874 	lcall	_ak820_outline_0052
      007246 C0 04            [24]  875 	push	ar4
      007248 C0 03            [24]  876 	push	ar3
      00724A 12 A3 20         [24]  877 	lcall	_process_record_quantum
      00724D E5 82            [12]  878 	mov	a, dpl
      00724F D0 03            [24]  879 	pop	ar3
      007251 D0 04            [24]  880 	pop	ar4
      007253 70 0A            [24]  881 	jnz	00106$
                                    882 ;	quantum/action.c:317: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007255 90 05 95         [24]  883 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007258 EB               [12]  884 	mov	a,r3
      007259 F0               [24]  885 	movx	@dptr,a
      00725A 8C 82            [24]  886 	mov	dpl, r4
                                    887 ;	quantum/action.c:324: return;
      00725C 02 2E BB         [24]  888 	ljmp	_ak820_oneshot_post
      00725F                        889 00106$:
                                    890 ;	quantum/action.c:327: process_record_handler(record);
      00725F 90 08 1F         [24]  891 	mov	dptr,#_process_record_record_10000_623
      007262 12 4F 3B         [24]  892 	lcall	_ak820_outline_0004
      007265 C0 04            [24]  893 	push	ar4
      007267 C0 03            [24]  894 	push	ar3
      007269 12 72 83         [24]  895 	lcall	_process_record_handler
                                    896 ;	quantum/action.c:328: post_process_record_quantum(record);
      00726C 90 08 1F         [24]  897 	mov	dptr,#_process_record_record_10000_623
      00726F 12 4F 3B         [24]  898 	lcall	_ak820_outline_0004
      007272 12 A2 F5         [24]  899 	lcall	_post_process_record_quantum
      007275 D0 03            [24]  900 	pop	ar3
      007277 D0 04            [24]  901 	pop	ar4
                                    902 ;	quantum/action.c:330: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007279 90 05 95         [24]  903 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00727C EB               [12]  904 	mov	a,r3
      00727D F0               [24]  905 	movx	@dptr,a
      00727E 8C 82            [24]  906 	mov	dpl, r4
                                    907 ;	quantum/action.c:332: }
      007280 02 2E BB         [24]  908 	ljmp	_ak820_oneshot_post
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'process_record_handler'
                                    911 ;------------------------------------------------------------
                                    912 ;record        Allocated with name '_process_record_handler_record_10000_631'
                                    913 ;action        Allocated with name '_process_record_handler_action_10000_632'
                                    914 ;------------------------------------------------------------
                                    915 ;	quantum/action.c:334: void process_record_handler(keyrecord_t *record) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function process_record_handler
                                    918 ;	-----------------------------------------
      007283                        919 _process_record_handler:
      007283 12 43 80         [24]  920 	lcall	_ak820_outline_0036
      007286 90 08 22         [24]  921 	mov	dptr,#_process_record_handler_record_10000_631
      007289 12 38 8B         [24]  922 	lcall	_ak820_outline_0017
                                    923 ;	quantum/action.c:338: if (record->keycode) {
      00728C 90 08 22         [24]  924 	mov	dptr,#_process_record_handler_record_10000_631
      00728F 12 4F 61         [24]  925 	lcall	_ak820_outline_0014
      007292 12 77 CE         [24]  926 	lcall	_ak820_outline_0069
      007295 12 BC E0         [24]  927 	lcall	__gptrget
      007298 FB               [12]  928 	mov	r3,a
      007299 A3               [24]  929 	inc	dptr
      00729A 12 BC E0         [24]  930 	lcall	__gptrget
      00729D FC               [12]  931 	mov	r4,a
      00729E 4B               [12]  932 	orl	a,r3
      00729F 60 12            [24]  933 	jz	00102$
                                    934 ;	quantum/action.c:339: action.code = action_for_keycode(record->keycode);
      0072A1 12 34 71         [24]  935 	lcall	_ak820_outline_0129
      0072A4 12 96 D0         [24]  936 	lcall	_action_for_keycode
      0072A7 AB 82            [24]  937 	mov	r3, dpl
      0072A9 AC 83            [24]  938 	mov	r4, dph
      0072AB 90 08 25         [24]  939 	mov	dptr,#_process_record_handler_action_10000_632
      0072AE 12 38 F2         [24]  940 	lcall	_ak820_outline_0103
      0072B1 80 30            [24]  941 	sjmp	00104$
      0072B3                        942 00102$:
                                    943 ;	quantum/action.c:341: action.code = store_or_get_action(record->event.pressed, record->event.key);
      0072B3 74 05            [12]  944 	mov	a,#0x05
      0072B5 12 77 B7         [24]  945 	lcall	_ak820_outline_0027
      0072B8 12 BC E0         [24]  946 	lcall	__gptrget
      0072BB FA               [12]  947 	mov	r2,a
      0072BC 90 0D C2         [24]  948 	mov	dptr,#___memcpy_PARM_2
      0072BF ED               [12]  949 	mov	a,r5
      0072C0 12 38 8B         [24]  950 	lcall	_ak820_outline_0017
      0072C3 90 0D C5         [24]  951 	mov	dptr,#___memcpy_PARM_3
      0072C6 12 4F 8C         [24]  952 	lcall	_ak820_outline_0067
      0072C9 90 09 61         [24]  953 	mov	dptr,#_store_or_get_action_PARM_2
      0072CC F5 F0            [12]  954 	mov	b,a
      0072CE C0 02            [24]  955 	push	ar2
      0072D0 12 BC 07         [24]  956 	lcall	___memcpy
      0072D3 D0 02            [24]  957 	pop	ar2
      0072D5 8A 82            [24]  958 	mov	dpl, r2
      0072D7 12 7B 76         [24]  959 	lcall	_store_or_get_action
      0072DA 12 43 D5         [24]  960 	lcall	_ak820_outline_0131
      0072DD 90 08 25         [24]  961 	mov	dptr,#_process_record_handler_action_10000_632
      0072E0 12 48 F9         [24]  962 	lcall	_ak820_outline_0068
                                    963 ;	quantum/action.c:347: ac_dprintf("ACTION: ");
      0072E3                        964 00104$:
                                    965 ;	quantum/action.c:358: process_action(record, action);
      0072E3 90 08 22         [24]  966 	mov	dptr,#_process_record_handler_record_10000_631
      0072E6 12 4F 61         [24]  967 	lcall	_ak820_outline_0014
      0072E9 90 0D C2         [24]  968 	mov	dptr,#___memcpy_PARM_2
      0072EC 74 25            [12]  969 	mov	a,#_process_record_handler_action_10000_632
      0072EE F0               [24]  970 	movx	@dptr,a
      0072EF 74 08            [12]  971 	mov	a,#(_process_record_handler_action_10000_632 >> 8)
      0072F1 12 38 E0         [24]  972 	lcall	_ak820_outline_0081
      0072F4 90 0D C5         [24]  973 	mov	dptr,#___memcpy_PARM_3
      0072F7 12 4F 8C         [24]  974 	lcall	_ak820_outline_0067
      0072FA 90 08 27         [24]  975 	mov	dptr,#_process_action_PARM_2
      0072FD F5 F0            [12]  976 	mov	b,a
      0072FF C0 07            [24]  977 	push	ar7
      007301 C0 06            [24]  978 	push	ar6
      007303 C0 05            [24]  979 	push	ar5
      007305 12 BC 07         [24]  980 	lcall	___memcpy
      007308 D0 05            [24]  981 	pop	ar5
      00730A D0 06            [24]  982 	pop	ar6
      00730C D0 07            [24]  983 	pop	ar7
      00730E 12 6E 5E         [24]  984 	lcall	_ak820_outline_0052
                                    985 ;	quantum/action.c:359: }
      007311 02 73 14         [24]  986 	ljmp	_process_action
                                    987 ;------------------------------------------------------------
                                    988 ;Allocation info for local variables in function 'register_mouse'
                                    989 ;------------------------------------------------------------
                                    990 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    991 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_640'
                                    992 ;------------------------------------------------------------
                                    993 ;	quantum/action.c:371: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function process_action
                                    996 ;	-----------------------------------------
      007314                        997 _process_action:
      007314 12 43 80         [24]  998 	lcall	_ak820_outline_0036
      007317 90 08 29         [24]  999 	mov	dptr,#_process_action_record_10000_643
      00731A 12 38 8B         [24] 1000 	lcall	_ak820_outline_0017
                                   1001 ;	quantum/action.c:425: pressed = record->event.pressed;
      00731D 90 08 29         [24] 1002 	mov	dptr,#_process_action_record_10000_643
      007320 E0               [24] 1003 	movx	a,@dptr
      007321 FE               [12] 1004 	mov	r6,a
      007322 A3               [24] 1005 	inc	dptr
      007323 E0               [24] 1006 	movx	a,@dptr
      007324 FD               [12] 1007 	mov	r5,a
      007325 A3               [24] 1008 	inc	dptr
      007326 E0               [24] 1009 	movx	a,@dptr
      007327 FF               [12] 1010 	mov	r7,a
      007328 74 05            [12] 1011 	mov	a,#0x05
      00732A 2E               [12] 1012 	add	a, r6
      00732B FA               [12] 1013 	mov	r2,a
      00732C E4               [12] 1014 	clr	a
      00732D 3D               [12] 1015 	addc	a, r5
      00732E FB               [12] 1016 	mov	r3,a
      00732F 8F 04            [24] 1017 	mov	ar4,r7
      007331 12 39 12         [24] 1018 	lcall	_ak820_outline_0140
      007334 8C F0            [24] 1019 	mov	b,r4
      007336 12 BC E0         [24] 1020 	lcall	__gptrget
      007339 F5 27            [12] 1021 	mov	_process_action_sloc0_1_0,a
                                   1022 ;	quantum/action.c:449: switch (action.kind.id) {
      00733B 90 08 28         [24] 1023 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00733E E0               [24] 1024 	movx	a,@dptr
      00733F C4               [12] 1025 	swap	a
      007340 54 0F            [12] 1026 	anl	a,#0x0f
      007342 FC               [12] 1027 	mov  r4,a
      007343 24 F4            [12] 1028 	add	a,#0xff - 0x0b
      007345 50 03            [24] 1029 	jnc	00434$
      007347 02 75 D7         [24] 1030 	ljmp	00181$
      00734A                       1031 00434$:
                                   1032 ;	free result
      00734A EC               [12] 1033 	mov	a,r4
      00734B 24 0A            [12] 1034 	add	a,#(00435$-3-.)
      00734D 83               [24] 1035 	movc	a,@a+pc
      00734E F5 82            [12] 1036 	mov	dpl,a
      007350 EC               [12] 1037 	mov	a,r4
      007351 24 10            [12] 1038 	add	a,#(00436$-3-.)
      007353 83               [24] 1039 	movc	a,@a+pc
      007354 F5 83            [12] 1040 	mov	dph,a
      007356 E4               [12] 1041 	clr	a
      007357 73               [24] 1042 	jmp	@a+dptr
      007358                       1043 00435$:
      007358 70                    1044 	.db	00102$
      007359 70                    1045 	.db	00102$
      00735A D7                    1046 	.db	00181$
      00735B D7                    1047 	.db	00181$
      00735C FA                    1048 	.db	00123$
      00735D D7                    1049 	.db	00181$
      00735E D7                    1050 	.db	00181$
      00735F D7                    1051 	.db	00181$
      007360 6C                    1052 	.db	00131$
      007361 3E                    1053 	.db	00147$
      007362 64                    1054 	.db	00152$
      007363 64                    1055 	.db	00152$
      007364                       1056 00436$:
      007364 73                    1057 	.db	00102$>>8
      007365 73                    1058 	.db	00102$>>8
      007366 75                    1059 	.db	00181$>>8
      007367 75                    1060 	.db	00181$>>8
      007368 73                    1061 	.db	00123$>>8
      007369 75                    1062 	.db	00181$>>8
      00736A 75                    1063 	.db	00181$>>8
      00736B 75                    1064 	.db	00181$>>8
      00736C 74                    1065 	.db	00131$>>8
      00736D 75                    1066 	.db	00147$>>8
      00736E 75                    1067 	.db	00152$>>8
      00736F 75                    1068 	.db	00152$>>8
                                   1069 ;	quantum/action.c:452: case ACT_RMODS: {
      007370                       1070 00102$:
                                   1071 ;	quantum/action.c:453: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007370 90 08 28         [24] 1072 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007373 E0               [24] 1073 	movx	a,@dptr
      007374 54 F0            [12] 1074 	anl	a,#0xf0
      007376 70 06            [24] 1075 	jnz	00194$
      007378 12 77 F5         [24] 1076 	lcall	_ak820_outline_0115
      00737B FC               [12] 1077 	mov	r4,a
      00737C 80 07            [24] 1078 	sjmp	00195$
      00737E                       1079 00194$:
      00737E 12 77 F5         [24] 1080 	lcall	_ak820_outline_0115
      007381 C4               [12] 1081 	swap	a
      007382 54 F0            [12] 1082 	anl	a,#0xf0
      007384 FC               [12] 1083 	mov	r4,a
      007385                       1084 00195$:
                                   1085 ;	quantum/action.c:455: if (pressed) {
      007385 E5 27            [12] 1086 	mov	a,_process_action_sloc0_1_0
      007387 60 35            [24] 1087 	jz	00119$
                                   1088 ;	quantum/action.c:456: if (mods) {
      007389 EC               [12] 1089 	mov	a,r4
      00738A 60 29            [24] 1090 	jz	00110$
                                   1091 ;	quantum/action.c:457: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00738C 12 78 11         [24] 1092 	lcall	_ak820_outline_0165
      00738F FB               [12] 1093 	mov	r3,a
      007390 BB E0 00         [24] 1094 	cjne	r3,#0xe0,00440$
      007393                       1095 00440$:
      007393 40 07            [24] 1096 	jc	00108$
      007395 12 78 11         [24] 1097 	lcall	_ak820_outline_0165
      007398 24 18            [12] 1098 	add	a,#0xff - 0xe7
      00739A 50 0A            [24] 1099 	jnc	00104$
                                   1100 ;	free result
      00739C                       1101 00108$:
      00739C 7A 27            [12] 1102 	mov	r2,#_process_action_PARM_2
      00739E 7B 08            [12] 1103 	mov	r3,#(_process_action_PARM_2 >> 8)
      0073A0 12 39 12         [24] 1104 	lcall	_ak820_outline_0140
      0073A3 E0               [24] 1105 	movx	a,@dptr
      0073A4 70 07            [24] 1106 	jnz	00105$
      0073A6                       1107 00104$:
                                   1108 ;	quantum/action.c:461: add_owned_mods(mods);
      0073A6 8C 82            [24] 1109 	mov	dpl, r4
      0073A8 12 7D F7         [24] 1110 	lcall	_add_owned_mods
      0073AB 80 05            [24] 1111 	sjmp	00106$
      0073AD                       1112 00105$:
                                   1113 ;	quantum/action.c:463: add_owned_weak_mods(mods);
      0073AD 8C 82            [24] 1114 	mov	dpl, r4
      0073AF 12 7E 16         [24] 1115 	lcall	_add_owned_weak_mods
      0073B2                       1116 00106$:
                                   1117 ;	quantum/action.c:465: send_keyboard_report();
      0073B2 12 81 3B         [24] 1118 	lcall	_send_keyboard_report
      0073B5                       1119 00110$:
                                   1120 ;	quantum/action.c:467: register_code(action.key.code);
      0073B5 12 77 E5         [24] 1121 	lcall	_ak820_outline_0086
      0073B8 12 75 EE         [24] 1122 	lcall	_register_code
      0073BB 02 75 D7         [24] 1123 	ljmp	00181$
      0073BE                       1124 00119$:
                                   1125 ;	quantum/action.c:469: unregister_code(action.key.code);
      0073BE 12 77 E5         [24] 1126 	lcall	_ak820_outline_0086
      0073C1 C0 04            [24] 1127 	push	ar4
      0073C3 12 76 5B         [24] 1128 	lcall	_unregister_code
      0073C6 D0 04            [24] 1129 	pop	ar4
                                   1130 ;	quantum/action.c:470: if (mods) {
      0073C8 EC               [12] 1131 	mov	a,r4
      0073C9 70 03            [24] 1132 	jnz	00444$
      0073CB 02 75 D7         [24] 1133 	ljmp	00181$
      0073CE                       1134 00444$:
                                   1135 ;	quantum/action.c:471: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0073CE 12 78 11         [24] 1136 	lcall	_ak820_outline_0165
      0073D1 FB               [12] 1137 	mov	r3,a
      0073D2 BB E0 00         [24] 1138 	cjne	r3,#0xe0,00445$
      0073D5                       1139 00445$:
      0073D5 40 07            [24] 1140 	jc	00115$
      0073D7 12 78 11         [24] 1141 	lcall	_ak820_outline_0165
      0073DA 24 18            [12] 1142 	add	a,#0xff - 0xe7
      0073DC 50 0A            [24] 1143 	jnc	00111$
                                   1144 ;	free result
      0073DE                       1145 00115$:
      0073DE 7A 27            [12] 1146 	mov	r2,#_process_action_PARM_2
      0073E0 7B 08            [12] 1147 	mov	r3,#(_process_action_PARM_2 >> 8)
      0073E2 12 39 12         [24] 1148 	lcall	_ak820_outline_0140
      0073E5 E0               [24] 1149 	movx	a,@dptr
      0073E6 70 07            [24] 1150 	jnz	00112$
      0073E8                       1151 00111$:
                                   1152 ;	quantum/action.c:472: del_owned_mods(mods);
      0073E8 8C 82            [24] 1153 	mov	dpl, r4
      0073EA 12 7E 07         [24] 1154 	lcall	_del_owned_mods
      0073ED 80 05            [24] 1155 	sjmp	00113$
      0073EF                       1156 00112$:
                                   1157 ;	quantum/action.c:474: del_owned_weak_mods(mods);
      0073EF 8C 82            [24] 1158 	mov	dpl, r4
      0073F1 12 7E 26         [24] 1159 	lcall	_del_owned_weak_mods
      0073F4                       1160 00113$:
                                   1161 ;	quantum/action.c:476: send_keyboard_report();
      0073F4 12 81 3B         [24] 1162 	lcall	_send_keyboard_report
                                   1163 ;	quantum/action.c:479: } break;
      0073F7 02 75 D7         [24] 1164 	ljmp	00181$
                                   1165 ;	quantum/action.c:556: case ACT_USAGE:
      0073FA                       1166 00123$:
                                   1167 ;	quantum/action.c:562: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0073FA 74 07            [12] 1168 	mov	a,#0x07
      0073FC 2E               [12] 1169 	add	a, r6
      0073FD FE               [12] 1170 	mov	r6,a
      0073FE E4               [12] 1171 	clr	a
      0073FF 3D               [12] 1172 	addc	a, r5
      007400 FD               [12] 1173 	mov	r5,a
      007401 8E 82            [24] 1174 	mov	dpl,r6
      007403 8D 83            [24] 1175 	mov	dph,r5
      007405 8F F0            [24] 1176 	mov	b,r7
      007407 12 BC E0         [24] 1177 	lcall	__gptrget
      00740A FE               [12] 1178 	mov	r6,a
      00740B A3               [24] 1179 	inc	dptr
      00740C 12 BC E0         [24] 1180 	lcall	__gptrget
      00740F FF               [12] 1181 	mov	r7,a
      007410 8E 04            [24] 1182 	mov	ar4,r6
      007412 8F 05            [24] 1183 	mov	ar5,r7
      007414 C3               [12] 1184 	clr	c
      007415 EC               [12] 1185 	mov	a,r4
      007416 94 A5            [12] 1186 	subb	a,#0xa5
      007418 ED               [12] 1187 	mov	a,r5
      007419 94 00            [12] 1188 	subb	a,#0x00
      00741B 40 15            [24] 1189 	jc	00125$
      00741D 74 C2            [12] 1190 	mov	a,#0xc2
      00741F 9C               [12] 1191 	subb	a,r4
      007420 E4               [12] 1192 	clr	a
      007421 9D               [12] 1193 	subb	a,r5
      007422 40 0E            [24] 1194 	jc	00125$
                                   1195 ;	free result
                                   1196 ;	quantum/action.c:563: owned_usage_key((uint8_t)record->keycode, pressed);
      007424 90 0A 8C         [24] 1197 	mov	dptr,#_owned_usage_key_PARM_2
      007427 E5 27            [12] 1198 	mov	a,_process_action_sloc0_1_0
      007429 F0               [24] 1199 	movx	@dptr,a
      00742A 8E 82            [24] 1200 	mov	dpl, r6
      00742C 12 7F E4         [24] 1201 	lcall	_owned_usage_key
                                   1202 ;	quantum/action.c:564: break;
      00742F 02 75 D7         [24] 1203 	ljmp	00181$
      007432                       1204 00125$:
                                   1205 ;	quantum/action.c:567: switch (action.usage.page) {
      007432 12 77 EC         [24] 1206 	lcall	_ak820_outline_0096
      007435 FF               [12] 1207 	mov	r7,a
      007436 60 08            [24] 1208 	jz	00127$
      007438 BF 01 02         [24] 1209 	cjne	r7,#0x01,00452$
      00743B 80 19            [24] 1210 	sjmp	00128$
      00743D                       1211 00452$:
      00743D 02 75 D7         [24] 1212 	ljmp	00181$
                                   1213 ;	quantum/action.c:568: case PAGE_SYSTEM:
      007440                       1214 00127$:
                                   1215 ;	quantum/action.c:569: host_system_send(pressed ? action.usage.code : 0);
      007440 E5 27            [12] 1216 	mov	a,_process_action_sloc0_1_0
      007442 60 05            [24] 1217 	jz	00196$
      007444 12 77 FC         [24] 1218 	lcall	_ak820_outline_0138
      007447 80 04            [24] 1219 	sjmp	00197$
      007449                       1220 00196$:
      007449 7E 00            [12] 1221 	mov	r6,#0x00
      00744B 7F 00            [12] 1222 	mov	r7,#0x00
      00744D                       1223 00197$:
      00744D 12 39 08         [24] 1224 	lcall	_ak820_outline_0123
      007450 12 6D E8         [24] 1225 	lcall	_host_system_send
                                   1226 ;	quantum/action.c:570: break;
      007453 02 75 D7         [24] 1227 	ljmp	00181$
                                   1228 ;	quantum/action.c:571: case PAGE_CONSUMER:
      007456                       1229 00128$:
                                   1230 ;	quantum/action.c:572: host_consumer_send(pressed ? action.usage.code : 0);
      007456 E5 27            [12] 1231 	mov	a,_process_action_sloc0_1_0
      007458 60 05            [24] 1232 	jz	00198$
      00745A 12 77 FC         [24] 1233 	lcall	_ak820_outline_0138
      00745D 80 04            [24] 1234 	sjmp	00199$
      00745F                       1235 00198$:
      00745F 7E 00            [12] 1236 	mov	r6,#0x00
      007461 7F 00            [12] 1237 	mov	r7,#0x00
      007463                       1238 00199$:
      007463 12 39 08         [24] 1239 	lcall	_ak820_outline_0123
      007466 12 6E 18         [24] 1240 	lcall	_host_consumer_send
                                   1241 ;	quantum/action.c:575: break;
      007469 02 75 D7         [24] 1242 	ljmp	00181$
                                   1243 ;	quantum/action.c:582: case ACT_LAYER: {
      00746C                       1244 00131$:
                                   1245 ;	quantum/action.c:583: uint8_t on = action.layer_bitop.on;
      00746C 90 08 28         [24] 1246 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00746F E0               [24] 1247 	movx	a,@dptr
      007470 54 03            [12] 1248 	anl	a,#0x03
      007472 90 08 2C         [24] 1249 	mov	dptr,#_process_action_on_40000_666
      007475 F0               [24] 1250 	movx	@dptr,a
                                   1251 ;	quantum/action.c:586: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007476 E0               [24] 1252 	movx	a,@dptr
      007477 FF               [12] 1253 	mov	r7,a
      007478 60 11            [24] 1254 	jz	00200$
      00747A E5 27            [12] 1255 	mov	a,_process_action_sloc0_1_0
      00747C 60 07            [24] 1256 	jz	00202$
      00747E 8F 06            [24] 1257 	mov	ar6,r7
      007480 53 06 01         [24] 1258 	anl	ar6,#0x01
      007483 80 10            [24] 1259 	sjmp	00201$
      007485                       1260 00202$:
      007485 74 02            [12] 1261 	mov	a,#0x02
      007487 5F               [12] 1262 	anl	a,r7
      007488 FE               [12] 1263 	mov	r6,a
      007489 80 0A            [24] 1264 	sjmp	00201$
      00748B                       1265 00200$:
      00748B E5 27            [12] 1266 	mov	a,_process_action_sloc0_1_0
      00748D B4 01 00         [24] 1267 	cjne	a,#0x01,00457$
      007490                       1268 00457$:
      007490 92 1F            [24] 1269 	mov  _process_action_sloc1_1_0,c
      007492 E4               [12] 1270 	clr	a
      007493 33               [12] 1271 	rlc	a
      007494 FE               [12] 1272 	mov	r6,a
      007495                       1273 00201$:
      007495 EE               [12] 1274 	mov	a,r6
      007496 70 03            [24] 1275 	jnz	00458$
      007498 02 75 D7         [24] 1276 	ljmp	00181$
      00749B                       1277 00458$:
                                   1278 ;	quantum/action.c:587: uint8_t shift = action.layer_bitop.part * 4;
      00749B 12 78 11         [24] 1279 	lcall	_ak820_outline_0165
      00749E C4               [12] 1280 	swap	a
      00749F 03               [12] 1281 	rr	a
      0074A0 54 07            [12] 1282 	anl	a,#0x07
      0074A2 25 E0            [12] 1283 	add	a,acc
      0074A4 25 E0            [12] 1284 	add	a,acc
      0074A6 FF               [12] 1285 	mov	r7,a
                                   1286 ;	quantum/action.c:588: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0074A7 12 78 11         [24] 1287 	lcall	_ak820_outline_0165
      0074AA 54 0F            [12] 1288 	anl	a,#0x0f
      0074AC FE               [12] 1289 	mov	r6,a
      0074AD 8F F0            [24] 1290 	mov	b,r7
      0074AF 05 F0            [12] 1291 	inc	b
      0074B1 EE               [12] 1292 	mov	a,r6
      0074B2 80 02            [24] 1293 	sjmp	00460$
      0074B4                       1294 00459$:
      0074B4 25 E0            [12] 1295 	add	a,acc
      0074B6                       1296 00460$:
      0074B6 D5 F0 FB         [24] 1297 	djnz	b,00459$
      0074B9 FE               [12] 1298 	mov	r6,a
                                   1299 ;	quantum/action.c:589: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0074BA 12 78 11         [24] 1300 	lcall	_ak820_outline_0165
      0074BD 30 E4 11         [24] 1301 	jnb	acc.4,00204$
      0074C0 8F F0            [24] 1302 	mov	b,r7
      0074C2 05 F0            [12] 1303 	inc	b
      0074C4 74 0F            [12] 1304 	mov	a,#0x0f
      0074C6 80 02            [24] 1305 	sjmp	00463$
      0074C8                       1306 00462$:
      0074C8 25 E0            [12] 1307 	add	a,acc
      0074CA                       1308 00463$:
      0074CA D5 F0 FB         [24] 1309 	djnz	b,00462$
      0074CD F4               [12] 1310 	cpl	a
      0074CE FF               [12] 1311 	mov	r7,a
      0074CF 80 02            [24] 1312 	sjmp	00205$
      0074D1                       1313 00204$:
      0074D1 7F 00            [12] 1314 	mov	r7,#0x00
      0074D3                       1315 00205$:
                                   1316 ;	quantum/action.c:590: bits |= mask;
      0074D3 EE               [12] 1317 	mov	a,r6
      0074D4 42 07            [12] 1318 	orl	ar7,a
                                   1319 ;	quantum/action.c:591: if (!on) {
      0074D6 90 08 2C         [24] 1320 	mov	dptr,#_process_action_on_40000_666
      0074D9 E0               [24] 1321 	movx	a,@dptr
      0074DA 70 31            [24] 1322 	jnz	00143$
                                   1323 ;	quantum/action.c:592: switch (action.layer_bitop.op) {
      0074DC 12 77 EC         [24] 1324 	lcall	_ak820_outline_0096
      0074DF FE               [12] 1325 	mov	r6,a
      0074E0 2E               [12] 1326 	add	a,r6
                                   1327 ;	quantum/action.c:593: case OP_BIT_AND: default_layer_and(bits); break;
      0074E1 90 74 E5         [24] 1328 	mov	dptr,#00465$
      0074E4 73               [24] 1329 	jmp	@a+dptr
      0074E5                       1330 00465$:
      0074E5 80 06            [24] 1331 	sjmp	00132$
      0074E7 80 0C            [24] 1332 	sjmp	00133$
      0074E9 80 12            [24] 1333 	sjmp	00134$
      0074EB 80 18            [24] 1334 	sjmp	00135$
      0074ED                       1335 00132$:
      0074ED 8F 82            [24] 1336 	mov	dpl, r7
      0074EF 12 78 71         [24] 1337 	lcall	_default_layer_and
      0074F2 02 75 D7         [24] 1338 	ljmp	00181$
                                   1339 ;	quantum/action.c:594: case OP_BIT_OR: default_layer_or(bits); break;
      0074F5                       1340 00133$:
      0074F5 8F 82            [24] 1341 	mov	dpl, r7
      0074F7 12 78 60         [24] 1342 	lcall	_default_layer_or
      0074FA 02 75 D7         [24] 1343 	ljmp	00181$
                                   1344 ;	quantum/action.c:595: case OP_BIT_XOR: default_layer_xor(bits); break;
      0074FD                       1345 00134$:
      0074FD 8F 82            [24] 1346 	mov	dpl, r7
      0074FF 12 78 87         [24] 1347 	lcall	_default_layer_xor
      007502 02 75 D7         [24] 1348 	ljmp	00181$
                                   1349 ;	quantum/action.c:596: case OP_BIT_SET: default_layer_set(bits); break;
      007505                       1350 00135$:
      007505 8F 82            [24] 1351 	mov	dpl, r7
      007507 12 78 55         [24] 1352 	lcall	_default_layer_set
                                   1353 ;	quantum/action.c:597: }
      00750A 02 75 D7         [24] 1354 	ljmp	00181$
      00750D                       1355 00143$:
                                   1356 ;	quantum/action.c:599: switch (action.layer_bitop.op) {
      00750D 12 77 EC         [24] 1357 	lcall	_ak820_outline_0096
      007510 FE               [12] 1358 	mov	r6,a
      007511 2E               [12] 1359 	add	a,r6
                                   1360 ;	quantum/action.c:600: case OP_BIT_AND: layer_and(bits); break;
      007512 90 75 16         [24] 1361 	mov	dptr,#00466$
      007515 73               [24] 1362 	jmp	@a+dptr
      007516                       1363 00466$:
      007516 80 06            [24] 1364 	sjmp	00137$
      007518 80 0C            [24] 1365 	sjmp	00138$
      00751A 80 12            [24] 1366 	sjmp	00139$
      00751C 80 18            [24] 1367 	sjmp	00140$
      00751E                       1368 00137$:
      00751E 8F 82            [24] 1369 	mov	dpl, r7
      007520 12 7A 0B         [24] 1370 	lcall	_layer_and
      007523 02 75 D7         [24] 1371 	ljmp	00181$
                                   1372 ;	quantum/action.c:601: case OP_BIT_OR: layer_or(bits); break;
      007526                       1373 00138$:
      007526 8F 82            [24] 1374 	mov	dpl, r7
      007528 12 79 FA         [24] 1375 	lcall	_layer_or
      00752B 02 75 D7         [24] 1376 	ljmp	00181$
                                   1377 ;	quantum/action.c:602: case OP_BIT_XOR: layer_xor(bits); break;
      00752E                       1378 00139$:
      00752E 8F 82            [24] 1379 	mov	dpl, r7
      007530 12 7A 21         [24] 1380 	lcall	_layer_xor
      007533 02 75 D7         [24] 1381 	ljmp	00181$
                                   1382 ;	quantum/action.c:603: case OP_BIT_SET: layer_state_set(bits); break;
      007536                       1383 00140$:
      007536 8F 82            [24] 1384 	mov	dpl, r7
      007538 12 79 97         [24] 1385 	lcall	_layer_state_set
                                   1386 ;	quantum/action.c:607: break;
      00753B 02 75 D7         [24] 1387 	ljmp	00181$
                                   1388 ;	quantum/action.c:609: case ACT_LAYER_MODS:
      00753E                       1389 00147$:
                                   1390 ;	quantum/action.c:610: if (pressed) {
      00753E E5 27            [12] 1391 	mov	a,_process_action_sloc0_1_0
      007540 60 11            [24] 1392 	jz	00149$
                                   1393 ;	quantum/action.c:611: layer_hold_on(action.layer_mods.layer);
      007542 12 77 F5         [24] 1394 	lcall	_ak820_outline_0115
      007545 F5 82            [12] 1395 	mov	dpl,a
      007547 12 78 F7         [24] 1396 	lcall	_layer_hold_on
                                   1397 ;	quantum/action.c:612: register_mods(action.layer_mods.mods);
      00754A 12 77 E5         [24] 1398 	lcall	_ak820_outline_0086
      00754D 12 77 11         [24] 1399 	lcall	_register_mods
      007550 02 75 D7         [24] 1400 	ljmp	00181$
      007553                       1401 00149$:
                                   1402 ;	quantum/action.c:614: unregister_mods(action.layer_mods.mods);
      007553 12 77 E5         [24] 1403 	lcall	_ak820_outline_0086
      007556 12 77 25         [24] 1404 	lcall	_unregister_mods
                                   1405 ;	quantum/action.c:615: layer_hold_off(action.layer_mods.layer);
      007559 12 77 F5         [24] 1406 	lcall	_ak820_outline_0115
      00755C F5 82            [12] 1407 	mov	dpl,a
      00755E 12 79 2F         [24] 1408 	lcall	_layer_hold_off
                                   1409 ;	quantum/action.c:617: break;
      007561 02 75 D7         [24] 1410 	ljmp	00181$
                                   1411 ;	quantum/action.c:619: case ACT_LAYER_TAP_EXT:
      007564                       1412 00152$:
                                   1413 ;	quantum/action.c:620: switch (action.layer_tap.code) {
      007564 12 78 11         [24] 1414 	lcall	_ak820_outline_0165
      007567 FF               [12] 1415 	mov	r7,a
      007568 BF F1 02         [24] 1416 	cjne	r7,#0xf1,00468$
      00756B 80 0A            [24] 1417 	sjmp	00154$
      00756D                       1418 00468$:
      00756D BF F2 02         [24] 1419 	cjne	r7,#0xf2,00469$
      007570 80 19            [24] 1420 	sjmp	00155$
      007572                       1421 00469$:
                                   1422 ;	quantum/action.c:636: momentary_layer_action:
      007572 BF F3 3B         [24] 1423 	cjne	r7,#0xf3,00160$
      007575 80 28            [24] 1424 	sjmp	00156$
      007577                       1425 00154$:
                                   1426 ;	quantum/action.c:637: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007577 E5 27            [12] 1427 	mov	a,_process_action_sloc0_1_0
      007579 60 08            [24] 1428 	jz	00206$
      00757B 12 77 C5         [24] 1429 	lcall	_ak820_outline_0043
      00757E 12 78 F7         [24] 1430 	lcall	_layer_hold_on
      007581 80 54            [24] 1431 	sjmp	00181$
      007583                       1432 00206$:
      007583 12 77 C5         [24] 1433 	lcall	_ak820_outline_0043
      007586 12 79 2F         [24] 1434 	lcall	_layer_hold_off
                                   1435 ;	quantum/action.c:638: break;
                                   1436 ;	quantum/action.c:639: case OP_OFF_ON:
      007589 80 4C            [24] 1437 	sjmp	00181$
      00758B                       1438 00155$:
                                   1439 ;	quantum/action.c:640: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00758B E5 27            [12] 1440 	mov	a,_process_action_sloc0_1_0
      00758D 60 08            [24] 1441 	jz	00208$
      00758F 12 77 C5         [24] 1442 	lcall	_ak820_outline_0043
      007592 12 79 DC         [24] 1443 	lcall	_layer_off
      007595 80 40            [24] 1444 	sjmp	00181$
      007597                       1445 00208$:
      007597 12 77 C5         [24] 1446 	lcall	_ak820_outline_0043
      00759A 12 79 C1         [24] 1447 	lcall	_layer_on
                                   1448 ;	quantum/action.c:641: break;
                                   1449 ;	quantum/action.c:642: case OP_SET_CLEAR:
      00759D 80 38            [24] 1450 	sjmp	00181$
      00759F                       1451 00156$:
                                   1452 ;	quantum/action.c:643: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      00759F E5 27            [12] 1453 	mov	a,_process_action_sloc0_1_0
      0075A1 60 08            [24] 1454 	jz	00210$
      0075A3 12 77 C5         [24] 1455 	lcall	_ak820_outline_0043
      0075A6 12 79 AB         [24] 1456 	lcall	_layer_move
      0075A9 80 2C            [24] 1457 	sjmp	00181$
      0075AB                       1458 00210$:
      0075AB 12 79 A5         [24] 1459 	lcall	_layer_clear
                                   1460 ;	quantum/action.c:644: break;
                                   1461 ;	quantum/action.c:690: default:
      0075AE 80 27            [24] 1462 	sjmp	00181$
      0075B0                       1463 00160$:
                                   1464 ;	quantum/action.c:697: if (pressed) {
      0075B0 E5 27            [12] 1465 	mov	a,_process_action_sloc0_1_0
      0075B2 60 08            [24] 1466 	jz	00163$
                                   1467 ;	quantum/action.c:699: register_code(action.layer_tap.code);
      0075B4 12 77 E5         [24] 1468 	lcall	_ak820_outline_0086
      0075B7 12 75 EE         [24] 1469 	lcall	_register_code
                                   1470 ;	quantum/action.c:701: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0075BA 80 1B            [24] 1471 	sjmp	00181$
      0075BC                       1472 00163$:
                                   1473 ;	quantum/action.c:702: if (action.layer_tap.code == KC_CAPS) {
      0075BC 12 78 11         [24] 1474 	lcall	_ak820_outline_0165
      0075BF FF               [12] 1475 	mov	r7,a
      0075C0 BF 39 0E         [24] 1476 	cjne	r7,#0x39,00175$
                                   1477 ;	quantum/action.c:703: wait_ms(TAP_HOLD_CAPS_DELAY);
      0075C3 7F 50            [12] 1478 	mov	r7,#0x50
      0075C5                       1479 00187$:
      0075C5 EF               [12] 1480 	mov	a,r7
      0075C6 60 09            [24] 1481 	jz	00175$
      0075C8 90 00 01         [24] 1482 	mov	dptr,#0x0001
      0075CB 12 59 96         [24] 1483 	lcall	_mDelaymS
      0075CE 1F               [12] 1484 	dec	r7
                                   1485 ;	quantum/action.c:705: wait_ms(TAP_CODE_DELAY);
      0075CF 80 F4            [24] 1486 	sjmp	00187$
      0075D1                       1487 00175$:
                                   1488 ;	quantum/action.c:707: unregister_code(action.layer_tap.code);
      0075D1 12 77 E5         [24] 1489 	lcall	_ak820_outline_0086
      0075D4 12 76 5B         [24] 1490 	lcall	_unregister_code
                                   1491 ;	quantum/action.c:790: }
      0075D7                       1492 00181$:
                                   1493 ;	quantum/action.c:811: switch (action.kind.id) {
      0075D7 90 08 28         [24] 1494 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075DA E0               [24] 1495 	movx	a,@dptr
      0075DB C4               [12] 1496 	swap	a
      0075DC 54 0F            [12] 1497 	anl	a,#0x0f
      0075DE FF               [12] 1498 	mov	r7,a
      0075DF BF 08 02         [24] 1499 	cjne	r7,#0x08,00478$
      0075E2 80 03            [24] 1500 	sjmp	00183$
      0075E4                       1501 00478$:
      0075E4 BF 09 06         [24] 1502 	cjne	r7,#0x09,00192$
                                   1503 ;	quantum/action.c:813: case ACT_LAYER_MODS:
      0075E7                       1504 00183$:
                                   1505 ;	quantum/action.c:818: led_set(host_keyboard_leds());
      0075E7 12 6D 4D         [24] 1506 	lcall	_host_keyboard_leds
                                   1507 ;	quantum/action.c:822: }
                                   1508 ;	quantum/action.c:875: }
      0075EA 02 99 96         [24] 1509 	ljmp	_led_set
      0075ED                       1510 00192$:
      0075ED 22               [24] 1511 	ret
                                   1512 ;------------------------------------------------------------
                                   1513 ;Allocation info for local variables in function 'register_code'
                                   1514 ;------------------------------------------------------------
                                   1515 ;code          Allocated with name '_register_code_code_10000_700'
                                   1516 ;------------------------------------------------------------
                                   1517 ;	quantum/action.c:881: __attribute__((weak)) void register_code(uint8_t code) {
                                   1518 ;	-----------------------------------------
                                   1519 ;	 function register_code
                                   1520 ;	-----------------------------------------
      0075EE                       1521 _register_code:
      0075EE E5 82            [12] 1522 	mov	a,dpl
      0075F0 90 08 2D         [24] 1523 	mov	dptr,#_register_code_code_10000_700
      0075F3 F0               [24] 1524 	movx	@dptr,a
                                   1525 ;	quantum/action.c:882: if (code == KC_NO) {
      0075F4 E0               [24] 1526 	movx	a,@dptr
      0075F5 FF               [12] 1527 	mov	r7,a
      0075F6 70 01            [24] 1528 	jnz	00123$
                                   1529 ;	quantum/action.c:883: return;
      0075F8 22               [24] 1530 	ret
      0075F9                       1531 00123$:
                                   1532 ;	quantum/action.c:918: } else if (IS_BASIC_KEYCODE(code)) {
      0075F9 BF 04 00         [24] 1533 	cjne	r7,#0x04,00186$
      0075FC                       1534 00186$:
      0075FC 40 12            [24] 1535 	jc	00119$
      0075FE EF               [12] 1536 	mov	a,r7
      0075FF 24 5B            [12] 1537 	add	a,#0xff - 0xa4
      007601 40 0D            [24] 1538 	jc	00119$
                                   1539 ;	free result
                                   1540 ;	quantum/action.c:923: if (!add_owned_key(code)) return;
      007603 8F 82            [24] 1541 	mov	dpl, r7
      007605 12 7E 9B         [24] 1542 	lcall	_add_owned_key
      007608 E5 82            [12] 1543 	mov	a, dpl
      00760A 70 01            [24] 1544 	jnz	00104$
      00760C 22               [24] 1545 	ret
      00760D                       1546 00104$:
                                   1547 ;	quantum/action.c:934: send_keyboard_report();
      00760D 02 81 3B         [24] 1548 	ljmp	_send_keyboard_report
      007610                       1549 00119$:
                                   1550 ;	quantum/action.c:935: } else if (IS_MODIFIER_KEYCODE(code)) {
      007610 12 78 16         [24] 1551 	lcall	_ak820_outline_0171
      007613 BF E0 00         [24] 1552 	cjne	r7,#0xe0,00190$
      007616                       1553 00190$:
      007616 40 1A            [24] 1554 	jc	00115$
      007618 EF               [12] 1555 	mov	a,r7
      007619 24 18            [12] 1556 	add	a,#0xff - 0xe7
      00761B 40 15            [24] 1557 	jc	00115$
                                   1558 ;	free result
                                   1559 ;	quantum/action.c:936: add_owned_mods(MOD_BIT(code));
      00761D 74 07            [12] 1560 	mov	a,#0x07
      00761F 5F               [12] 1561 	anl	a,r7
      007620 12 77 DE         [24] 1562 	lcall	_ak820_outline_0071
      007623 80 02            [24] 1563 	sjmp	00194$
      007625                       1564 00193$:
      007625 25 E0            [12] 1565 	add	a,acc
      007627                       1566 00194$:
      007627 D5 F0 FB         [24] 1567 	djnz	b,00193$
      00762A F5 82            [12] 1568 	mov	dpl,a
      00762C 12 7D F7         [24] 1569 	lcall	_add_owned_mods
                                   1570 ;	quantum/action.c:937: send_keyboard_report();
      00762F 02 81 3B         [24] 1571 	ljmp	_send_keyboard_report
      007632                       1572 00115$:
                                   1573 ;	quantum/action.c:940: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007632 12 78 16         [24] 1574 	lcall	_ak820_outline_0171
      007635 BF A5 00         [24] 1575 	cjne	r7,#0xa5,00195$
      007638                       1576 00195$:
      007638 40 05            [24] 1577 	jc	00113$
      00763A EF               [12] 1578 	mov	a,r7
      00763B 24 58            [12] 1579 	add	a,#0xff - 0xa7
      00763D 50 0D            [24] 1580 	jnc	00108$
                                   1581 ;	free result
      00763F                       1582 00113$:
      00763F 12 78 16         [24] 1583 	lcall	_ak820_outline_0171
      007642 BF A8 00         [24] 1584 	cjne	r7,#0xa8,00198$
      007645                       1585 00198$:
      007645 40 13            [24] 1586 	jc	00125$
      007647 EF               [12] 1587 	mov	a,r7
      007648 24 3D            [12] 1588 	add	a,#0xff - 0xc2
      00764A 40 0E            [24] 1589 	jc	00125$
                                   1590 ;	free result
      00764C                       1591 00108$:
                                   1592 ;	quantum/action.c:942: owned_usage_key(code, true);
      00764C 12 78 16         [24] 1593 	lcall	_ak820_outline_0171
      00764F 90 0A 8C         [24] 1594 	mov	dptr,#_owned_usage_key_PARM_2
      007652 74 01            [12] 1595 	mov	a,#0x01
      007654 F0               [24] 1596 	movx	@dptr,a
      007655 8F 82            [24] 1597 	mov	dpl, r7
                                   1598 ;	quantum/action.c:950: register_mouse(code, true);
                                   1599 ;	quantum/action.c:952: }
      007657 02 7F E4         [24] 1600 	ljmp	_owned_usage_key
      00765A                       1601 00125$:
      00765A 22               [24] 1602 	ret
                                   1603 ;------------------------------------------------------------
                                   1604 ;Allocation info for local variables in function 'unregister_code'
                                   1605 ;------------------------------------------------------------
                                   1606 ;code          Allocated with name '_unregister_code_code_10000_714'
                                   1607 ;------------------------------------------------------------
                                   1608 ;	quantum/action.c:958: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1609 ;	-----------------------------------------
                                   1610 ;	 function unregister_code
                                   1611 ;	-----------------------------------------
      00765B                       1612 _unregister_code:
      00765B E5 82            [12] 1613 	mov	a,dpl
      00765D 90 08 2E         [24] 1614 	mov	dptr,#_unregister_code_code_10000_714
      007660 F0               [24] 1615 	movx	@dptr,a
                                   1616 ;	quantum/action.c:959: if (code == KC_NO) {
      007661 E0               [24] 1617 	movx	a,@dptr
      007662 FF               [12] 1618 	mov	r7,a
      007663 70 01            [24] 1619 	jnz	00121$
                                   1620 ;	quantum/action.c:960: return;
      007665 22               [24] 1621 	ret
      007666                       1622 00121$:
                                   1623 ;	quantum/action.c:992: } else if (IS_BASIC_KEYCODE(code)) {
      007666 BF 04 00         [24] 1624 	cjne	r7,#0x04,00184$
      007669                       1625 00184$:
      007669 40 12            [24] 1626 	jc	00117$
      00766B EF               [12] 1627 	mov	a,r7
      00766C 24 5B            [12] 1628 	add	a,#0xff - 0xa4
      00766E 40 0D            [24] 1629 	jc	00117$
                                   1630 ;	free result
                                   1631 ;	quantum/action.c:994: if (!del_owned_key(code)) return;
      007670 8F 82            [24] 1632 	mov	dpl, r7
      007672 12 7F 18         [24] 1633 	lcall	_del_owned_key
      007675 E5 82            [12] 1634 	mov	a, dpl
      007677 70 01            [24] 1635 	jnz	00102$
      007679 22               [24] 1636 	ret
      00767A                       1637 00102$:
                                   1638 ;	quantum/action.c:998: send_keyboard_report();
      00767A 02 81 3B         [24] 1639 	ljmp	_send_keyboard_report
      00767D                       1640 00117$:
                                   1641 ;	quantum/action.c:999: } else if (IS_MODIFIER_KEYCODE(code)) {
      00767D 12 78 1C         [24] 1642 	lcall	_ak820_outline_0172
      007680 BF E0 00         [24] 1643 	cjne	r7,#0xe0,00188$
      007683                       1644 00188$:
      007683 40 1A            [24] 1645 	jc	00113$
      007685 EF               [12] 1646 	mov	a,r7
      007686 24 18            [12] 1647 	add	a,#0xff - 0xe7
      007688 40 15            [24] 1648 	jc	00113$
                                   1649 ;	free result
                                   1650 ;	quantum/action.c:1000: del_owned_mods(MOD_BIT(code));
      00768A 74 07            [12] 1651 	mov	a,#0x07
      00768C 5F               [12] 1652 	anl	a,r7
      00768D 12 77 DE         [24] 1653 	lcall	_ak820_outline_0071
      007690 80 02            [24] 1654 	sjmp	00192$
      007692                       1655 00191$:
      007692 25 E0            [12] 1656 	add	a,acc
      007694                       1657 00192$:
      007694 D5 F0 FB         [24] 1658 	djnz	b,00191$
      007697 F5 82            [12] 1659 	mov	dpl,a
      007699 12 7E 07         [24] 1660 	lcall	_del_owned_mods
                                   1661 ;	quantum/action.c:1001: send_keyboard_report();
      00769C 02 81 3B         [24] 1662 	ljmp	_send_keyboard_report
      00769F                       1663 00113$:
                                   1664 ;	quantum/action.c:1004: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00769F 12 78 1C         [24] 1665 	lcall	_ak820_outline_0172
      0076A2 BF A5 00         [24] 1666 	cjne	r7,#0xa5,00193$
      0076A5                       1667 00193$:
      0076A5 40 05            [24] 1668 	jc	00111$
      0076A7 EF               [12] 1669 	mov	a,r7
      0076A8 24 58            [12] 1670 	add	a,#0xff - 0xa7
      0076AA 50 0D            [24] 1671 	jnc	00106$
                                   1672 ;	free result
      0076AC                       1673 00111$:
      0076AC 12 78 1C         [24] 1674 	lcall	_ak820_outline_0172
      0076AF BF A8 00         [24] 1675 	cjne	r7,#0xa8,00196$
      0076B2                       1676 00196$:
      0076B2 40 12            [24] 1677 	jc	00123$
      0076B4 EF               [12] 1678 	mov	a,r7
      0076B5 24 3D            [12] 1679 	add	a,#0xff - 0xc2
      0076B7 40 0D            [24] 1680 	jc	00123$
                                   1681 ;	free result
      0076B9                       1682 00106$:
                                   1683 ;	quantum/action.c:1006: owned_usage_key(code, false);
      0076B9 12 78 1C         [24] 1684 	lcall	_ak820_outline_0172
      0076BC 90 0A 8C         [24] 1685 	mov	dptr,#_owned_usage_key_PARM_2
      0076BF E4               [12] 1686 	clr	a
      0076C0 F0               [24] 1687 	movx	@dptr,a
      0076C1 8F 82            [24] 1688 	mov	dpl, r7
                                   1689 ;	quantum/action.c:1014: register_mouse(code, false);
                                   1690 ;	quantum/action.c:1016: }
      0076C3 02 7F E4         [24] 1691 	ljmp	_owned_usage_key
      0076C6                       1692 00123$:
      0076C6 22               [24] 1693 	ret
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'tap_code_delay'
                                   1696 ;------------------------------------------------------------
                                   1697 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1698 ;code          Allocated with name '_tap_code_delay_code_10000_727'
                                   1699 ;i             Allocated with name '_tap_code_delay_i_20000_729'
                                   1700 ;i             Allocated with name '_tap_code_delay_i_50000_732'
                                   1701 ;------------------------------------------------------------
                                   1702 ;	quantum/action.c:1023: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1703 ;	-----------------------------------------
                                   1704 ;	 function tap_code_delay
                                   1705 ;	-----------------------------------------
      0076C7                       1706 _tap_code_delay:
      0076C7 E5 82            [12] 1707 	mov	a,dpl
      0076C9 90 08 31         [24] 1708 	mov	dptr,#_tap_code_delay_code_10000_727
      0076CC F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	quantum/action.c:1024: register_code(code);
      0076CD E0               [24] 1711 	movx	a,@dptr
      0076CE FF               [12] 1712 	mov	r7,a
      0076CF F5 82            [12] 1713 	mov	dpl,a
      0076D1 C0 07            [24] 1714 	push	ar7
      0076D3 12 75 EE         [24] 1715 	lcall	_register_code
      0076D6 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/action.c:1025: for (uint16_t i = delay; i > 0; i--) {
      0076D8 90 08 2F         [24] 1718 	mov	dptr,#_tap_code_delay_PARM_2
      0076DB 12 38 EC         [24] 1719 	lcall	_ak820_outline_0089
      0076DE                       1720 00110$:
      0076DE ED               [12] 1721 	mov	a,r5
      0076DF 4E               [12] 1722 	orl	a,r6
      0076E0 60 0D            [24] 1723 	jz	00105$
                                   1724 ;	quantum/action.c:1026: wait_ms(1);
      0076E2 90 00 01         [24] 1725 	mov	dptr,#0x0001
      0076E5 12 59 96         [24] 1726 	lcall	_mDelaymS
                                   1727 ;	quantum/action.c:1025: for (uint16_t i = delay; i > 0; i--) {
      0076E8 1D               [12] 1728 	dec	r5
      0076E9 BD FF 01         [24] 1729 	cjne	r5,#0xff,00141$
      0076EC 1E               [12] 1730 	dec	r6
      0076ED                       1731 00141$:
      0076ED 80 EF            [24] 1732 	sjmp	00110$
      0076EF                       1733 00105$:
                                   1734 ;	quantum/action.c:1028: unregister_code(code);
      0076EF 8F 82            [24] 1735 	mov	dpl, r7
                                   1736 ;	quantum/action.c:1029: }
      0076F1 02 76 5B         [24] 1737 	ljmp	_unregister_code
                                   1738 ;------------------------------------------------------------
                                   1739 ;Allocation info for local variables in function 'tap_code'
                                   1740 ;------------------------------------------------------------
                                   1741 ;code          Allocated with name '_tap_code_code_10000_734'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/action.c:1035: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function tap_code
                                   1746 ;	-----------------------------------------
      0076F4                       1747 _tap_code:
      0076F4 E5 82            [12] 1748 	mov	a,dpl
      0076F6 90 08 32         [24] 1749 	mov	dptr,#_tap_code_code_10000_734
      0076F9 F0               [24] 1750 	movx	@dptr,a
                                   1751 ;	quantum/action.c:1036: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0076FA E0               [24] 1752 	movx	a,@dptr
      0076FB FF               [12] 1753 	mov	r7,a
      0076FC BF 39 04         [24] 1754 	cjne	r7,#0x39,00103$
      0076FF 7E 50            [12] 1755 	mov	r6,#0x50
      007701 80 02            [24] 1756 	sjmp	00104$
      007703                       1757 00103$:
      007703 7E 00            [12] 1758 	mov	r6,#0x00
      007705                       1759 00104$:
      007705 90 08 2F         [24] 1760 	mov	dptr,#_tap_code_delay_PARM_2
      007708 EE               [12] 1761 	mov	a,r6
      007709 12 39 0D         [24] 1762 	lcall	_ak820_outline_0130
      00770C 8F 82            [24] 1763 	mov	dpl, r7
                                   1764 ;	quantum/action.c:1037: }
      00770E 02 76 C7         [24] 1765 	ljmp	_tap_code_delay
                                   1766 ;------------------------------------------------------------
                                   1767 ;Allocation info for local variables in function 'register_mods'
                                   1768 ;------------------------------------------------------------
                                   1769 ;mods          Allocated with name '_register_mods_mods_10000_736'
                                   1770 ;------------------------------------------------------------
                                   1771 ;	quantum/action.c:1043: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1772 ;	-----------------------------------------
                                   1773 ;	 function register_mods
                                   1774 ;	-----------------------------------------
      007711                       1775 _register_mods:
      007711 E5 82            [12] 1776 	mov	a,dpl
      007713 90 08 33         [24] 1777 	mov	dptr,#_register_mods_mods_10000_736
      007716 F0               [24] 1778 	movx	@dptr,a
                                   1779 ;	quantum/action.c:1044: if (mods) {
      007717 E0               [24] 1780 	movx	a,@dptr
      007718 FF               [12] 1781 	mov	r7,a
      007719 E0               [24] 1782 	movx	a,@dptr
      00771A 60 08            [24] 1783 	jz	00103$
                                   1784 ;	quantum/action.c:1045: add_owned_mods(mods);
      00771C 8F 82            [24] 1785 	mov	dpl, r7
      00771E 12 7D F7         [24] 1786 	lcall	_add_owned_mods
                                   1787 ;	quantum/action.c:1046: send_keyboard_report();
                                   1788 ;	quantum/action.c:1048: }
      007721 02 81 3B         [24] 1789 	ljmp	_send_keyboard_report
      007724                       1790 00103$:
      007724 22               [24] 1791 	ret
                                   1792 ;------------------------------------------------------------
                                   1793 ;Allocation info for local variables in function 'unregister_mods'
                                   1794 ;------------------------------------------------------------
                                   1795 ;mods          Allocated with name '_unregister_mods_mods_10000_740'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action.c:1054: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function unregister_mods
                                   1800 ;	-----------------------------------------
      007725                       1801 _unregister_mods:
      007725 E5 82            [12] 1802 	mov	a,dpl
      007727 90 08 34         [24] 1803 	mov	dptr,#_unregister_mods_mods_10000_740
      00772A F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action.c:1055: if (mods) {
      00772B E0               [24] 1806 	movx	a,@dptr
      00772C FF               [12] 1807 	mov	r7,a
      00772D E0               [24] 1808 	movx	a,@dptr
      00772E 60 08            [24] 1809 	jz	00103$
                                   1810 ;	quantum/action.c:1056: del_owned_mods(mods);
      007730 8F 82            [24] 1811 	mov	dpl, r7
      007732 12 7E 07         [24] 1812 	lcall	_del_owned_mods
                                   1813 ;	quantum/action.c:1057: send_keyboard_report();
                                   1814 ;	quantum/action.c:1059: }
      007735 02 81 3B         [24] 1815 	ljmp	_send_keyboard_report
      007738                       1816 00103$:
      007738 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'register_weak_mods'
                                   1820 ;------------------------------------------------------------
                                   1821 ;mods          Allocated with name '_register_weak_mods_mods_10000_744'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/action.c:1065: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function register_weak_mods
                                   1826 ;	-----------------------------------------
      007739                       1827 _register_weak_mods:
      007739 E5 82            [12] 1828 	mov	a,dpl
      00773B 90 08 35         [24] 1829 	mov	dptr,#_register_weak_mods_mods_10000_744
      00773E F0               [24] 1830 	movx	@dptr,a
                                   1831 ;	quantum/action.c:1066: if (mods) {
      00773F E0               [24] 1832 	movx	a,@dptr
      007740 FF               [12] 1833 	mov	r7,a
      007741 E0               [24] 1834 	movx	a,@dptr
      007742 60 08            [24] 1835 	jz	00103$
                                   1836 ;	quantum/action.c:1067: add_owned_weak_mods(mods);
      007744 8F 82            [24] 1837 	mov	dpl, r7
      007746 12 7E 16         [24] 1838 	lcall	_add_owned_weak_mods
                                   1839 ;	quantum/action.c:1068: send_keyboard_report();
                                   1840 ;	quantum/action.c:1070: }
      007749 02 81 3B         [24] 1841 	ljmp	_send_keyboard_report
      00774C                       1842 00103$:
      00774C 22               [24] 1843 	ret
                                   1844 ;------------------------------------------------------------
                                   1845 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1846 ;------------------------------------------------------------
                                   1847 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_748'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	quantum/action.c:1076: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1850 ;	-----------------------------------------
                                   1851 ;	 function unregister_weak_mods
                                   1852 ;	-----------------------------------------
      00774D                       1853 _unregister_weak_mods:
      00774D E5 82            [12] 1854 	mov	a,dpl
      00774F 90 08 36         [24] 1855 	mov	dptr,#_unregister_weak_mods_mods_10000_748
      007752 F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/action.c:1077: if (mods) {
      007753 E0               [24] 1858 	movx	a,@dptr
      007754 FF               [12] 1859 	mov	r7,a
      007755 E0               [24] 1860 	movx	a,@dptr
      007756 60 08            [24] 1861 	jz	00103$
                                   1862 ;	quantum/action.c:1078: del_owned_weak_mods(mods);
      007758 8F 82            [24] 1863 	mov	dpl, r7
      00775A 12 7E 26         [24] 1864 	lcall	_del_owned_weak_mods
                                   1865 ;	quantum/action.c:1079: send_keyboard_report();
                                   1866 ;	quantum/action.c:1081: }
      00775D 02 81 3B         [24] 1867 	ljmp	_send_keyboard_report
      007760                       1868 00103$:
      007760 22               [24] 1869 	ret
                                   1870 ;------------------------------------------------------------
                                   1871 ;Allocation info for local variables in function 'clear_keyboard'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	quantum/action.c:1087: void clear_keyboard(void) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function clear_keyboard
                                   1876 ;	-----------------------------------------
      007761                       1877 _clear_keyboard:
                                   1878 ;	quantum/action.c:1088: clear_mods();
      007761 12 81 B6         [24] 1879 	lcall	_clear_mods
                                   1880 ;	quantum/action.c:1089: clear_keyboard_but_mods();
                                   1881 ;	quantum/action.c:1090: }
      007764 02 77 67         [24] 1882 	ljmp	_clear_keyboard_but_mods
                                   1883 ;------------------------------------------------------------
                                   1884 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action.c:1096: void clear_keyboard_but_mods(void) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function clear_keyboard_but_mods
                                   1889 ;	-----------------------------------------
      007767                       1890 _clear_keyboard_but_mods:
                                   1891 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007767 90 0D E7         [24] 1892 	mov	dptr,#_actual_keyboard_report
      00776A 75 F0 00         [24] 1893 	mov	b, #0x00
      00776D 12 70 26         [24] 1894 	lcall	_clear_keys_from_report
                                   1895 ;	quantum/action.c:1098: clear_keyboard_but_mods_and_keys();
                                   1896 ;	quantum/action.c:1099: }
      007770 02 77 73         [24] 1897 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1105: void clear_keyboard_but_mods_and_keys(void) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function clear_keyboard_but_mods_and_keys
                                   1904 ;	-----------------------------------------
      007773                       1905 _clear_keyboard_but_mods_and_keys:
                                   1906 ;	quantum/action.c:1107: ak820_tapping_cancel();
      007773 12 47 43         [24] 1907 	lcall	_ak820_tapping_cancel
                                   1908 ;	quantum/action.c:1109: ak820_oneshot_cancel();
      007776 12 2E F0         [24] 1909 	lcall	_ak820_oneshot_cancel
                                   1910 ;	quantum/action.c:1112: ak820_combo_cancel();
      007779 12 35 F2         [24] 1911 	lcall	_ak820_combo_cancel
                                   1912 ;	quantum/action.c:1115: repeat_key_cancel();
      00777C 12 A5 35         [24] 1913 	lcall	_repeat_key_cancel
                                   1914 ;	quantum/action.c:1117: clear_owned_mods();
      00777F 12 7E 36         [24] 1915 	lcall	_clear_owned_mods
                                   1916 ;	quantum/action.c:1118: clear_owned_keys();
      007782 12 7E 6E         [24] 1917 	lcall	_clear_owned_keys
                                   1918 ;	quantum/action.c:1119: clear_owned_usages();
      007785 12 7F AC         [24] 1919 	lcall	_clear_owned_usages
                                   1920 ;	quantum/action.c:1120: layer_hold_clear();
      007788 12 79 68         [24] 1921 	lcall	_layer_hold_clear
                                   1922 ;	quantum/action.c:1122: clear_macro_tri_layer();
      00778B 12 9F 78         [24] 1923 	lcall	_clear_macro_tri_layer
                                   1924 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      00778E 90 0D E7         [24] 1925 	mov	dptr,#_actual_keyboard_report
      007791 75 F0 00         [24] 1926 	mov	b, #0x00
      007794 12 70 26         [24] 1927 	lcall	_clear_keys_from_report
                                   1928 ;	quantum/action.c:1127: host_system_send(0);
      007797 90 00 00         [24] 1929 	mov	dptr,#0x0000
      00779A 12 6D E8         [24] 1930 	lcall	_host_system_send
                                   1931 ;	quantum/action.c:1128: host_consumer_send(0);
      00779D 90 00 00         [24] 1932 	mov	dptr,#0x0000
      0077A0 12 6E 18         [24] 1933 	lcall	_host_consumer_send
                                   1934 ;	quantum/action.c:1130: clear_weak_mods();
      0077A3 12 81 EB         [24] 1935 	lcall	_clear_weak_mods
                                   1936 ;	quantum/action.c:1131: send_keyboard_report();
                                   1937 ;	quantum/action.c:1139: }
      0077A6 02 81 3B         [24] 1938 	ljmp	_send_keyboard_report
                                   1939 ;------------------------------------------------------------
                                   1940 ;Allocation info for local variables in function 'is_tap_record'
                                   1941 ;------------------------------------------------------------
                                   1942 ;record        Allocated with name '_is_tap_record_record_10000_764'
                                   1943 ;action        Allocated with name '_is_tap_record_action_10001_768'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	quantum/action.c:1145: bool is_tap_record(keyrecord_t *record) {
                                   1946 ;	-----------------------------------------
                                   1947 	.area CSEG    (CODE)
                                   1948 	.area CONST   (CODE)
                                   1949 	.area XINIT   (CODE)
      00C4DC                       1950 __xinit__disable_action_cache:
      00C4DC 00                    1951 	.db #0x00	;  0
                                   1952 	.area CABS    (ABS,CODE)
                                   1953 
                                   1954 ; Experimental exact instruction outlining.
                                   1955 	.globl _ak820_outline_0004
                                   1956 	.globl _ak820_outline_0010
                                   1957 	.globl _ak820_outline_0014
                                   1958 	.globl _ak820_outline_0015
                                   1959 	.globl _ak820_outline_0017
                                   1960 	.globl _ak820_outline_0027
                                   1961 	.globl _ak820_outline_0033
                                   1962 	.globl _ak820_outline_0036
                                   1963 	.globl _ak820_outline_0043
                                   1964 	.globl _ak820_outline_0052
                                   1965 	.globl _ak820_outline_0067
                                   1966 	.globl _ak820_outline_0068
                                   1967 	.globl _ak820_outline_0069
                                   1968 	.globl _ak820_outline_0071
                                   1969 	.globl _ak820_outline_0081
                                   1970 	.globl _ak820_outline_0084
                                   1971 	.globl _ak820_outline_0086
                                   1972 	.globl _ak820_outline_0089
                                   1973 	.globl _ak820_outline_0096
                                   1974 	.globl _ak820_outline_0103
                                   1975 	.globl _ak820_outline_0115
                                   1976 	.globl _ak820_outline_0123
                                   1977 	.globl _ak820_outline_0129
                                   1978 	.globl _ak820_outline_0130
                                   1979 	.globl _ak820_outline_0131
                                   1980 	.globl _ak820_outline_0138
                                   1981 	.globl _ak820_outline_0140
                                   1982 	.globl _ak820_outline_0152
                                   1983 	.globl _ak820_outline_0155
                                   1984 	.globl _ak820_outline_0165
                                   1985 	.globl _ak820_outline_0171
                                   1986 	.globl _ak820_outline_0172
                                   1987 	.globl _ak820_outline_0174
                                   1988 	.globl _ak820_outline_0194
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0015
      0077A9                       1992 _ak820_outline_0015:
      0077A9 2D               [12] 1993 	add	a,r5
      0077AA F9               [12] 1994 	mov	r1,a
      0077AB E4               [12] 1995 	clr	a
      0077AC 3E               [12] 1996 	addc	a,r6
      0077AD FA               [12] 1997 	mov	r2,a
      0077AE 8F 03            [24] 1998 	mov	ar3,r7
      0077B0 89 82            [24] 1999 	mov	dpl,r1
      0077B2 8A 83            [24] 2000 	mov	dph,r2
      0077B4 8B F0            [24] 2001 	mov	b,r3
      0077B6 22               [24] 2002 	ret
                                   2003 
                                   2004 	.area CSEG (CODE)
                                   2005 ; function ak820_outline_0027
      0077B7                       2006 _ak820_outline_0027:
      0077B7 2D               [12] 2007 	add	a,r5
      0077B8 FA               [12] 2008 	mov	r2,a
      0077B9 E4               [12] 2009 	clr	a
      0077BA 3E               [12] 2010 	addc	a,r6
      0077BB FB               [12] 2011 	mov	r3,a
      0077BC 8F 04            [24] 2012 	mov	ar4,r7
      0077BE 8A 82            [24] 2013 	mov	dpl,r2
      0077C0 8B 83            [24] 2014 	mov	dph,r3
      0077C2 8C F0            [24] 2015 	mov	b,r4
      0077C4 22               [24] 2016 	ret
                                   2017 
                                   2018 	.area CSEG (CODE)
                                   2019 ; function ak820_outline_0043
      0077C5                       2020 _ak820_outline_0043:
      0077C5 90 08 28         [24] 2021 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077C8 E0               [24] 2022 	movx	a,@dptr
      0077C9 54 1F            [12] 2023 	anl	a,#0x1f
      0077CB F5 82            [12] 2024 	mov	dpl,a
      0077CD 22               [24] 2025 	ret
                                   2026 
                                   2027 	.area CSEG (CODE)
                                   2028 ; function ak820_outline_0069
      0077CE                       2029 _ak820_outline_0069:
      0077CE 74 07            [12] 2030 	mov	a,#0x07
      0077D0 2D               [12] 2031 	add	a,r5
      0077D1 FB               [12] 2032 	mov	r3,a
      0077D2 E4               [12] 2033 	clr	a
      0077D3 3E               [12] 2034 	addc	a,r6
      0077D4 FA               [12] 2035 	mov	r2,a
      0077D5 8F 04            [24] 2036 	mov	ar4,r7
      0077D7 8B 82            [24] 2037 	mov	dpl,r3
      0077D9 8A 83            [24] 2038 	mov	dph,r2
      0077DB 8C F0            [24] 2039 	mov	b,r4
      0077DD 22               [24] 2040 	ret
                                   2041 
                                   2042 	.area CSEG (CODE)
                                   2043 ; function ak820_outline_0071
      0077DE                       2044 _ak820_outline_0071:
      0077DE F5 F0            [12] 2045 	mov	b,a
      0077E0 05 F0            [12] 2046 	inc	b
      0077E2 74 01            [12] 2047 	mov	a,#0x01
      0077E4 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0086
      0077E5                       2052 _ak820_outline_0086:
      0077E5 90 08 27         [24] 2053 	mov	dptr,#_process_action_PARM_2
      0077E8 E0               [24] 2054 	movx	a,@dptr
      0077E9 F5 82            [12] 2055 	mov	dpl,a
      0077EB 22               [24] 2056 	ret
                                   2057 
                                   2058 	.area CSEG (CODE)
                                   2059 ; function ak820_outline_0096
      0077EC                       2060 _ak820_outline_0096:
      0077EC 90 08 28         [24] 2061 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077EF E0               [24] 2062 	movx	a,@dptr
      0077F0 03               [12] 2063 	rr	a
      0077F1 03               [12] 2064 	rr	a
      0077F2 54 03            [12] 2065 	anl	a,#0x03
      0077F4 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0115
      0077F5                       2070 _ak820_outline_0115:
      0077F5 90 08 28         [24] 2071 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077F8 E0               [24] 2072 	movx	a,@dptr
      0077F9 54 0F            [12] 2073 	anl	a,#0x0f
      0077FB 22               [24] 2074 	ret
                                   2075 
                                   2076 	.area CSEG (CODE)
                                   2077 ; function ak820_outline_0138
      0077FC                       2078 _ak820_outline_0138:
      0077FC 90 08 27         [24] 2079 	mov	dptr,#_process_action_PARM_2
      0077FF E0               [24] 2080 	movx	a,@dptr
      007800 FE               [12] 2081 	mov	r6,a
      007801 A3               [24] 2082 	inc	dptr
      007802 E0               [24] 2083 	movx	a,@dptr
      007803 54 03            [12] 2084 	anl	a,#0x03
      007805 FF               [12] 2085 	mov	r7,a
      007806 22               [24] 2086 	ret
                                   2087 
                                   2088 	.area CSEG (CODE)
                                   2089 ; function ak820_outline_0152
      007807                       2090 _ak820_outline_0152:
      007807 74 07            [12] 2091 	mov	a,#0x07
      007809 2D               [12] 2092 	add	a,r5
      00780A F8               [12] 2093 	mov	r0,a
      00780B E4               [12] 2094 	clr	a
      00780C 3E               [12] 2095 	addc	a,r6
      00780D F9               [12] 2096 	mov	r1,a
      00780E 8F 02            [24] 2097 	mov	ar2,r7
      007810 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0165
      007811                       2102 _ak820_outline_0165:
      007811 90 08 27         [24] 2103 	mov	dptr,#_process_action_PARM_2
      007814 E0               [24] 2104 	movx	a,@dptr
      007815 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0171
      007816                       2109 _ak820_outline_0171:
      007816 90 08 2D         [24] 2110 	mov	dptr,#_register_code_code_10000_700
      007819 E0               [24] 2111 	movx	a,@dptr
      00781A FF               [12] 2112 	mov	r7,a
      00781B 22               [24] 2113 	ret
                                   2114 
                                   2115 	.area CSEG (CODE)
                                   2116 ; function ak820_outline_0172
      00781C                       2117 _ak820_outline_0172:
      00781C 90 08 2E         [24] 2118 	mov	dptr,#_unregister_code_code_10000_714
      00781F E0               [24] 2119 	movx	a,@dptr
      007820 FF               [12] 2120 	mov	r7,a
      007821 22               [24] 2121 	ret
                                   2122 
                                   2123 	.area CSEG (CODE)
                                   2124 ; function ak820_outline_0194
      007822                       2125 _ak820_outline_0194:
      007822 F0               [24] 2126 	movx	@dptr,a
      007823 EB               [12] 2127 	mov	a,r3
      007824 A3               [24] 2128 	inc	dptr
      007825 F0               [24] 2129 	movx	@dptr,a
      007826 22               [24] 2130 	ret
