                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00096B                        580 _owned_mod_refs:
      00096B                        581 	.ds 8
      000973                        582 _owned_weak_refs:
      000973                        583 	.ds 8
      00097B                        584 _owned_mods:
      00097B                        585 	.ds 1
      00097C                        586 _owned_weak_mods:
      00097C                        587 	.ds 1
      00097D                        588 _macro_mods:
      00097D                        589 	.ds 2
      00097F                        590 _ak820_macro_primitive::
      00097F                        591 	.ds 1
      000980                        592 _ak820_macro_cancelled::
      000980                        593 	.ds 1
      000981                        594 _ak820_macro_change_PARM_2:
      000981                        595 	.ds 1
      000982                        596 _ak820_macro_change_PARM_3:
      000982                        597 	.ds 1
      000983                        598 _ak820_macro_change_bits_10000_287:
      000983                        599 	.ds 2
      000985                        600 _change_owned_PARM_2:
      000985                        601 	.ds 1
      000986                        602 _change_owned_mods_10000_292:
      000986                        603 	.ds 1
      000987                        604 _change_owned_result_10001_296:
      000987                        605 	.ds 1
      000988                        606 _change_owned_bit_20001_297:
      000988                        607 	.ds 1
      000989                        608 _add_owned_mods_mods_10000_305:
      000989                        609 	.ds 1
      00098A                        610 _del_owned_mods_mods_10000_307:
      00098A                        611 	.ds 1
      00098B                        612 _add_owned_weak_mods_mods_10000_309:
      00098B                        613 	.ds 1
      00098C                        614 _del_owned_weak_mods_mods_10000_311:
      00098C                        615 	.ds 1
      00098D                        616 _key_refs:
      00098D                        617 	.ds 165
      000A32                        618 _distinct_keys:
      000A32                        619 	.ds 1
      000A33                        620 _macro_keys:
      000A33                        621 	.ds 21
      000A48                        622 _add_owned_key_code_10000_320:
      000A48                        623 	.ds 1
      000A49                        624 _del_owned_key_code_10000_335:
      000A49                        625 	.ds 1
      000A4A                        626 _usage_refs:
      000A4A                        627 	.ds 30
      000A68                        628 _usage_order:
      000A68                        629 	.ds 30
      000A86                        630 _usage_lengths:
      000A86                        631 	.ds 2
      000A88                        632 _macro_usages:
      000A88                        633 	.ds 4
      000A8C                        634 _owned_usage_key_PARM_2:
      000A8C                        635 	.ds 1
      000A8D                        636 _owned_usage_key_code_10000_362:
      000A8D                        637 	.ds 1
      000A8E                        638 _owned_usage_key___200000085_20000_363:
      000A8E                        639 	.ds 2
      000A90                        640 _owned_usage_key_which_10000_363:
      000A90                        641 	.ds 1
      000A91                        642 _owned_usage_key_count_10000_363:
      000A91                        643 	.ds 1
      000A92                        644 _owned_usage_key_pos_30001_370:
      000A92                        645 	.ds 1
      000A93                        646 _owned_usage_key_key_40000_375:
      000A93                        647 	.ds 1
      000A94                        648 _send_keyboard_report_last_report_10001_382:
      000A94                        649 	.ds 32
      000AB4                        650 _send_keyboard_report_changed_10001_382:
      000AB4                        651 	.ds 1
      000AB5                        652 _add_weak_mods_mods_10000_400:
      000AB5                        653 	.ds 1
      000AB6                        654 _del_weak_mods_mods_10000_402:
      000AB6                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DE5                        664 _real_mods:
      000DE5                        665 	.ds 1
      000DE6                        666 _weak_mods:
      000DE6                        667 	.ds 1
      000DE7                        668 _actual_keyboard_report::
      000DE7                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007CBC                        713 _ak820_macro_change:
      007CBC 12 39 03         [24]  714 	lcall	_ak820_outline_0122
      007CBF 90 09 83         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007CC2 12 38 FE         [24]  716 	lcall	_ak820_outline_0121
                                    717 ;	quantum/action_util.c:40: if (!ak820_macro_primitive) return true;
      007CC5 90 09 7F         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007CC8 E0               [24]  719 	movx	a,@dptr
      007CC9 70 04            [24]  720 	jnz	00102$
      007CCB 75 82 01         [24]  721 	mov	dpl, #0x01
      007CCE 22               [24]  722 	ret
      007CCF                        723 00102$:
                                    724 ;	quantum/action_util.c:41: uint8_t mask = 1u << (index & 7);
      007CCF 90 09 81         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007CD2 E0               [24]  726 	movx	a,@dptr
      007CD3 FF               [12]  727 	mov	r7,a
      007CD4 74 07            [12]  728 	mov	a,#0x07
      007CD6 5F               [12]  729 	anl	a,r7
      007CD7 12 77 DE         [24]  730 	lcall	_ak820_outline_0071
      007CDA 80 02            [24]  731 	sjmp	00123$
      007CDC                        732 00122$:
      007CDC 25 E0            [12]  733 	add	a,acc
      007CDE                        734 00123$:
      007CDE D5 F0 FB         [24]  735 	djnz	b,00122$
      007CE1 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:42: bits += index >> 3;
      007CE2 EF               [12]  738 	mov	a,r7
      007CE3 12 58 17         [24]  739 	lcall	_ak820_outline_0196
      007CE6 FF               [12]  740 	mov	r7,a
      007CE7 90 09 83         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007CEA 12 38 DA         [24]  742 	lcall	_ak820_outline_0076
      007CED 90 09 83         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007CF0 EF               [12]  744 	mov	a,r7
      007CF1 2C               [12]  745 	add	a, r4
      007CF2 F0               [24]  746 	movx	@dptr,a
      007CF3 E4               [12]  747 	clr	a
      007CF4 3D               [12]  748 	addc	a, r5
      007CF5 A3               [24]  749 	inc	dptr
      007CF6 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:43: if (((*bits & mask) != 0) == pressed) return false;
      007CF7 90 09 83         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_287
      007CFA E0               [24]  753 	movx	a,@dptr
      007CFB FD               [12]  754 	mov	r5,a
      007CFC A3               [24]  755 	inc	dptr
      007CFD E0               [24]  756 	movx	a,@dptr
      007CFE FF               [12]  757 	mov	r7,a
      007CFF 12 82 4A         [24]  758 	lcall	_ak820_outline_0198
      007D02 E0               [24]  759 	movx	a,@dptr
      007D03 FC               [12]  760 	mov	r4,a
      007D04 EE               [12]  761 	mov	a,r6
      007D05 5C               [12]  762 	anl	a,r4
      007D06 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007D09                        764 00124$:
      007D09 B3               [12]  765 	cpl	c
      007D0A 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007D0C 90 09 82         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007D0F E0               [24]  768 	movx	a,@dptr
      007D10 FB               [12]  769 	mov	r3,a
      007D11 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007D13 E4               [12]  771 	clr	a
      007D14 33               [12]  772 	rlc	a
      007D15 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007D18 75 82 00         [24]  774 	mov	dpl, #0x00
      007D1B 22               [24]  775 	ret
      007D1C                        776 00104$:
                                    777 ;	quantum/action_util.c:44: *bits ^= mask;
      007D1C EC               [12]  778 	mov	a,r4
      007D1D 62 06            [12]  779 	xrl	ar6,a
      007D1F 12 82 4A         [24]  780 	lcall	_ak820_outline_0198
      007D22 EE               [12]  781 	mov	a,r6
      007D23 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:45: return true;
      007D24 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:46: }
      007D27 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_292'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_293'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_293'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_293'
                                    795 ;old           Allocated with name '_change_owned_old_30000_295'
                                    796 ;result        Allocated with name '_change_owned_result_10001_296'
                                    797 ;i             Allocated with name '_change_owned_i_20001_297'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_297'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:47: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007D28                        805 _change_owned:
      007D28 E5 82            [12]  806 	mov	a,dpl
      007D2A 90 09 86         [24]  807 	mov	dptr,#_change_owned_mods_10000_292
      007D2D F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:48: uint8_t kind = mode >> 1;
      007D2E 90 09 85         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007D31 E0               [24]  811 	movx	a,@dptr
      007D32 FF               [12]  812 	mov	r7,a
      007D33 C3               [12]  813 	clr	c
      007D34 13               [12]  814 	rrc	a
      007D35 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:49: bool pressed = (mode & 1) != 0;
      007D36 53 07 01         [24]  817 	anl	ar7,#0x01
      007D39 EF               [12]  818 	mov	a,r7
      007D3A B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007D3D                        820 00205$:
      007D3D 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007D3F B3               [12]  822 	cpl	c
      007D40 E4               [12]  823 	clr	a
      007D41 33               [12]  824 	rlc	a
      007D42 F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:50: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007D44 EE               [12]  827 	mov	a,r6
      007D45 60 06            [24]  828 	jz	00121$
      007D47 7D 73            [12]  829 	mov	r5,#_owned_weak_refs
      007D49 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007D4B 80 04            [24]  831 	sjmp	00122$
      007D4D                        832 00121$:
      007D4D 7D 6B            [12]  833 	mov	r5,#_owned_mod_refs
      007D4F 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007D51                        835 00122$:
                                    836 ;	quantum/action_util.c:51: if (ak820_macro_primitive) {
      007D51 90 09 7F         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007D54 E0               [24]  838 	movx	a,@dptr
      007D55 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:52: uint8_t old = macro_mods[kind];
      007D57 EE               [12]  841 	mov	a,r6
      007D58 24 7D            [12]  842 	add	a, #_macro_mods
      007D5A FB               [12]  843 	mov	r3,a
      007D5B E4               [12]  844 	clr	a
      007D5C 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007D5E 12 48 F1         [24]  846 	lcall	_ak820_outline_0063
                                    847 ;	quantum/action_util.c:53: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007D61 E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007D63 60 0A            [24]  849 	jz	00123$
      007D65 90 09 86         [24]  850 	mov	dptr,#_change_owned_mods_10000_292
      007D68 E0               [24]  851 	movx	a,@dptr
      007D69 F9               [12]  852 	mov	r1,a
      007D6A EA               [12]  853 	mov	a,r2
      007D6B 42 01            [12]  854 	orl	ar1,a
      007D6D 80 07            [24]  855 	sjmp	00124$
      007D6F                        856 00123$:
      007D6F 90 09 86         [24]  857 	mov	dptr,#_change_owned_mods_10000_292
      007D72 E0               [24]  858 	movx	a,@dptr
      007D73 F4               [12]  859 	cpl	a
      007D74 5A               [12]  860 	anl	a,r2
      007D75 F9               [12]  861 	mov	r1,a
      007D76                        862 00124$:
      007D76 12 34 71         [24]  863 	lcall	_ak820_outline_0129
      007D79 E9               [12]  864 	mov	a,r1
      007D7A F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:54: mods &= pressed ? ~old : old;
      007D7B E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007D7D 60 06            [24]  868 	jz	00125$
      007D7F 74 FF            [12]  869 	mov	a,#0xff
      007D81 6A               [12]  870 	xrl	a,r2
      007D82 FC               [12]  871 	mov	r4,a
      007D83 80 02            [24]  872 	sjmp	00126$
      007D85                        873 00125$:
      007D85 8A 04            [24]  874 	mov	ar4,r2
      007D87                        875 00126$:
      007D87 90 09 86         [24]  876 	mov	dptr,#_change_owned_mods_10000_292
      007D8A E0               [24]  877 	movx	a,@dptr
      007D8B 5C               [12]  878 	anl	a,r4
      007D8C F0               [24]  879 	movx	@dptr,a
      007D8D                        880 00102$:
                                    881 ;	quantum/action_util.c:56: uint8_t result = 0;
      007D8D 90 09 87         [24]  882 	mov	dptr,#_change_owned_result_10001_296
      007D90 E4               [12]  883 	clr	a
      007D91 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:57: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007D92 90 09 88         [24]  886 	mov	dptr,#_change_owned_bit_20001_297
      007D95 04               [12]  887 	inc	a
      007D96 F0               [24]  888 	movx	@dptr,a
      007D97 90 09 86         [24]  889 	mov	dptr,#_change_owned_mods_10000_292
      007D9A E0               [24]  890 	movx	a,@dptr
      007D9B FC               [12]  891 	mov	r4,a
      007D9C 7B 00            [12]  892 	mov	r3,#0x00
      007D9E                        893 00117$:
      007D9E BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007DA1                        895 00210$:
      007DA1 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:58: if (mods & bit) {
      007DA3 90 09 88         [24]  898 	mov	dptr,#_change_owned_bit_20001_297
      007DA6 E0               [24]  899 	movx	a,@dptr
      007DA7 5C               [12]  900 	anl	a,r4
      007DA8 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:59: if (pressed) ++refs[i];
      007DAA E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007DAC 60 0C            [24]  904 	jz	00106$
      007DAE EB               [12]  905 	mov	a,r3
      007DAF 2D               [12]  906 	add	a, r5
      007DB0 12 38 93         [24]  907 	lcall	_ak820_outline_0018
      007DB3 F8               [12]  908 	mov	r0,a
      007DB4 08               [12]  909 	inc	r0
      007DB5 12 82 07         [24]  910 	lcall	_ak820_outline_0072
      007DB8 80 0C            [24]  911 	sjmp	00109$
      007DBA                        912 00106$:
                                    913 ;	quantum/action_util.c:60: else if (refs[i]) --refs[i];
      007DBA EB               [12]  914 	mov	a,r3
      007DBB 2D               [12]  915 	add	a, r5
      007DBC 12 38 93         [24]  916 	lcall	_ak820_outline_0018
      007DBF F8               [12]  917 	mov	r0,a
      007DC0 60 04            [24]  918 	jz	00109$
      007DC2 18               [12]  919 	dec	r0
      007DC3 12 82 07         [24]  920 	lcall	_ak820_outline_0072
      007DC6                        921 00109$:
                                    922 ;	quantum/action_util.c:62: if (refs[i]) result |= bit;
      007DC6 EB               [12]  923 	mov	a,r3
      007DC7 2D               [12]  924 	add	a, r5
      007DC8 12 38 93         [24]  925 	lcall	_ak820_outline_0018
      007DCB 60 0B            [24]  926 	jz	00118$
      007DCD 90 09 88         [24]  927 	mov	dptr,#_change_owned_bit_20001_297
      007DD0 E0               [24]  928 	movx	a,@dptr
      007DD1 FA               [12]  929 	mov	r2,a
      007DD2 90 09 87         [24]  930 	mov	dptr,#_change_owned_result_10001_296
      007DD5 E0               [24]  931 	movx	a,@dptr
      007DD6 4A               [12]  932 	orl	a,r2
      007DD7 F0               [24]  933 	movx	@dptr,a
      007DD8                        934 00118$:
                                    935 ;	quantum/action_util.c:57: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007DD8 0B               [12]  936 	inc	r3
      007DD9 90 09 88         [24]  937 	mov	dptr,#_change_owned_bit_20001_297
      007DDC E0               [24]  938 	movx	a,@dptr
      007DDD 25 E0            [12]  939 	add	a,acc
      007DDF F0               [24]  940 	movx	@dptr,a
      007DE0 80 BC            [24]  941 	sjmp	00117$
      007DE2                        942 00112$:
                                    943 ;	quantum/action_util.c:64: if (kind) owned_weak_mods = result;
      007DE2 EE               [12]  944 	mov	a,r6
      007DE3 60 09            [24]  945 	jz	00114$
      007DE5 90 09 87         [24]  946 	mov	dptr,#_change_owned_result_10001_296
      007DE8 E0               [24]  947 	movx	a,@dptr
      007DE9 90 09 7C         [24]  948 	mov	dptr,#_owned_weak_mods
      007DEC F0               [24]  949 	movx	@dptr,a
      007DED 22               [24]  950 	ret
      007DEE                        951 00114$:
                                    952 ;	quantum/action_util.c:65: else owned_mods = result;
      007DEE 90 09 87         [24]  953 	mov	dptr,#_change_owned_result_10001_296
      007DF1 E0               [24]  954 	movx	a,@dptr
      007DF2 90 09 7B         [24]  955 	mov	dptr,#_owned_mods
      007DF5 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:66: }
      007DF6 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_305'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:67: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007DF7                        968 _add_owned_mods:
      007DF7 E5 82            [12]  969 	mov	a,dpl
      007DF9 90 09 89         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_305
      007DFC 12 82 27         [24]  971 	lcall	_ak820_outline_0120
      007DFF 74 01            [12]  972 	mov	a,#0x01
      007E01 F0               [24]  973 	movx	@dptr,a
      007E02 8F 82            [24]  974 	mov	dpl, r7
      007E04 02 7D 28         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_307'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:68: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007E07                        985 _del_owned_mods:
      007E07 E5 82            [12]  986 	mov	a,dpl
      007E09 90 09 8A         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_307
      007E0C 12 82 27         [24]  988 	lcall	_ak820_outline_0120
      007E0F E4               [12]  989 	clr	a
      007E10 F0               [24]  990 	movx	@dptr,a
      007E11 8F 82            [24]  991 	mov	dpl, r7
      007E13 02 7D 28         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_309'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:69: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007E16                       1002 _add_owned_weak_mods:
      007E16 E5 82            [12] 1003 	mov	a,dpl
      007E18 90 09 8B         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_309
      007E1B 12 82 27         [24] 1005 	lcall	_ak820_outline_0120
      007E1E 74 03            [12] 1006 	mov	a,#0x03
      007E20 F0               [24] 1007 	movx	@dptr,a
      007E21 8F 82            [24] 1008 	mov	dpl, r7
      007E23 02 7D 28         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_311'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:70: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007E26                       1019 _del_owned_weak_mods:
      007E26 E5 82            [12] 1020 	mov	a,dpl
      007E28 90 09 8C         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_311
      007E2B 12 82 27         [24] 1022 	lcall	_ak820_outline_0120
      007E2E 74 02            [12] 1023 	mov	a,#0x02
      007E30 F0               [24] 1024 	movx	@dptr,a
      007E31 8F 82            [24] 1025 	mov	dpl, r7
      007E33 02 7D 28         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_315'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:71: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007E36                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:72: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007E36 7F 00            [12] 1038 	mov	r7,#0x00
      007E38                       1039 00103$:
      007E38 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007E3B                       1041 00122$:
      007E3B 50 1A            [24] 1042 	jnc	00101$
      007E3D EF               [12] 1043 	mov	a,r7
      007E3E 24 6B            [12] 1044 	add	a, #_owned_mod_refs
      007E40 FD               [12] 1045 	mov	r5,a
      007E41 E4               [12] 1046 	clr	a
      007E42 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007E44 FE               [12] 1048 	mov	r6,a
      007E45 EF               [12] 1049 	mov	a,r7
      007E46 24 73            [12] 1050 	add	a, #_owned_weak_refs
      007E48 F5 82            [12] 1051 	mov	dpl,a
      007E4A E4               [12] 1052 	clr	a
      007E4B 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007E4D F5 83            [12] 1054 	mov	dph,a
      007E4F E4               [12] 1055 	clr	a
      007E50 F0               [24] 1056 	movx	@dptr,a
      007E51 12 82 2E         [24] 1057 	lcall	_ak820_outline_0128
      007E54 0F               [12] 1058 	inc	r7
      007E55 80 E1            [24] 1059 	sjmp	00103$
      007E57                       1060 00101$:
                                   1061 ;	quantum/action_util.c:73: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007E57 90 09 7E         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007E5A E4               [12] 1063 	clr	a
      007E5B F0               [24] 1064 	movx	@dptr,a
      007E5C 90 09 7D         [24] 1065 	mov	dptr,#_macro_mods
      007E5F F0               [24] 1066 	movx	@dptr,a
      007E60 90 09 7C         [24] 1067 	mov	dptr,#_owned_weak_mods
      007E63 F0               [24] 1068 	movx	@dptr,a
      007E64 90 09 7B         [24] 1069 	mov	dptr,#_owned_mods
      007E67 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:74: ak820_macro_cancelled = true;
      007E68 90 09 80         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007E6B 04               [12] 1073 	inc	a
      007E6C F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:75: }
      007E6D 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_318'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_319'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:81: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007E6E                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:82: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007E6E 7F 00            [12] 1089 	mov	r7,#0x00
      007E70                       1090 00104$:
      007E70 EF               [12] 1091 	mov	a,r7
      007E71 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007E73 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007E75 EF               [12] 1095 	mov	a,r7
      007E76 24 8D            [12] 1096 	add	a, #_key_refs
      007E78 F5 82            [12] 1097 	mov	dpl,a
      007E7A E4               [12] 1098 	clr	a
      007E7B 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007E7D 12 7C 9B         [24] 1100 	lcall	_ak820_outline_0167
      007E80 80 EE            [24] 1101 	sjmp	00104$
      007E82                       1102 00101$:
                                   1103 ;	quantum/action_util.c:83: distinct_keys = 0;
      007E82 90 0A 32         [24] 1104 	mov	dptr,#_distinct_keys
      007E85 E4               [12] 1105 	clr	a
      007E86 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:84: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007E87 FF               [12] 1108 	mov	r7,a
      007E88                       1109 00107$:
      007E88 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007E8B                       1111 00142$:
      007E8B 50 0D            [24] 1112 	jnc	00109$
      007E8D EF               [12] 1113 	mov	a,r7
      007E8E 24 33            [12] 1114 	add	a, #_macro_keys
      007E90 F5 82            [12] 1115 	mov	dpl,a
      007E92 E4               [12] 1116 	clr	a
      007E93 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007E95 12 7C 9B         [24] 1118 	lcall	_ak820_outline_0167
      007E98 80 EE            [24] 1119 	sjmp	00107$
      007E9A                       1120 00109$:
                                   1121 ;	quantum/action_util.c:85: }
      007E9A 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_320'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_329'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_330'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_328'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_332'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_333'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:86: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007E9B                       1137 _add_owned_key:
      007E9B E5 82            [12] 1138 	mov	a,dpl
      007E9D 90 0A 48         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_320
      007EA0 12 82 3F         [24] 1140 	lcall	_ak820_outline_0139
                                   1141 ;	quantum/action_util.c:87: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007EA3 74 01            [12] 1142 	mov	a,#0x01
      007EA5 F0               [24] 1143 	movx	@dptr,a
      007EA6 90 0A 33         [24] 1144 	mov	dptr,#_macro_keys
      007EA9 C0 07            [24] 1145 	push	ar7
      007EAB 12 7C BC         [24] 1146 	lcall	_ak820_macro_change
      007EAE E5 82            [12] 1147 	mov	a, dpl
      007EB0 D0 07            [24] 1148 	pop	ar7
      007EB2 70 03            [24] 1149 	jnz	00102$
      007EB4 F5 82            [12] 1150 	mov	dpl,a
      007EB6 22               [24] 1151 	ret
      007EB7                       1152 00102$:
                                   1153 ;	quantum/action_util.c:88: if (key_refs[code]++) return false;
      007EB7 12 81 F1         [24] 1154 	lcall	_ak820_outline_0031
      007EBA FC               [12] 1155 	mov	r4,a
      007EBB 04               [12] 1156 	inc	a
      007EBC 12 82 2E         [24] 1157 	lcall	_ak820_outline_0128
      007EBF EC               [12] 1158 	mov	a,r4
      007EC0 60 04            [24] 1159 	jz	00104$
      007EC2 75 82 00         [24] 1160 	mov	dpl, #0x00
      007EC5 22               [24] 1161 	ret
      007EC6                       1162 00104$:
                                   1163 ;	quantum/action_util.c:89: ++distinct_keys;
      007EC6 90 0A 32         [24] 1164 	mov	dptr,#_distinct_keys
      007EC9 E0               [24] 1165 	movx	a,@dptr
      007ECA 24 01            [12] 1166 	add	a, #0x01
      007ECC F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:91: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007ECD 90 0D D4         [24] 1169 	mov	dptr,#_keyboard_protocol
      007ED0 E0               [24] 1170 	movx	a,@dptr
      007ED1 60 15            [24] 1171 	jz	00106$
      007ED3 90 0A B7         [24] 1172 	mov	dptr,#_keymap_config
      007ED6 E0               [24] 1173 	movx	a,@dptr
      007ED7 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007EDA 90 07 FC         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007EDD EF               [12] 1177 	mov	a,r7
      007EDE 12 81 FF         [24] 1178 	lcall	_ak820_outline_0066
      007EE1 12 6F A8         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:91: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007EE4 75 82 01         [24] 1181 	mov	dpl, #0x01
      007EE7 22               [24] 1182 	ret
      007EE8                       1183 00106$:
                                   1184 ;	quantum/action_util.c:93: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007EE8 90 0A 32         [24] 1185 	mov	dptr,#_distinct_keys
      007EEB E0               [24] 1186 	movx	a,@dptr
      007EEC 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007EEE 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:94: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007EF0 7F 00            [12] 1191 	mov	r7,#0x00
      007EF2                       1192 00115$:
      007EF2 BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007EF5                       1194 00174$:
      007EF5 50 1D            [24] 1195 	jnc	00111$
      007EF7 EF               [12] 1196 	mov	a,r7
      007EF8 24 E9            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007EFA F5 82            [12] 1198 	mov	dpl,a
      007EFC E4               [12] 1199 	clr	a
      007EFD 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007EFF F5 83            [12] 1201 	mov	dph,a
      007F01 74 01            [12] 1202 	mov	a,#0x01
      007F03 F0               [24] 1203 	movx	@dptr,a
      007F04 0F               [12] 1204 	inc	r7
      007F05 80 EB            [24] 1205 	sjmp	00115$
      007F07                       1206 00110$:
                                   1207 ;	quantum/action_util.c:95: } else add_key(code);
      007F07 90 0A 48         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_320
      007F0A E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007F0B 90 07 FC         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007F0E 12 81 FF         [24] 1212 	lcall	_ak820_outline_0066
      007F11 12 6F A8         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:95: } else add_key(code);
      007F14                       1215 00111$:
                                   1216 ;	quantum/action_util.c:96: return true;
      007F14 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:97: }
      007F17 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_335'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_346'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_347'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_344'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_352'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_353'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_355'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:98: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007F18                       1236 _del_owned_key:
      007F18 E5 82            [12] 1237 	mov	a,dpl
      007F1A 90 0A 49         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_335
      007F1D 12 82 3F         [24] 1239 	lcall	_ak820_outline_0139
                                   1240 ;	quantum/action_util.c:99: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007F20 E4               [12] 1241 	clr	a
      007F21 F0               [24] 1242 	movx	@dptr,a
      007F22 90 0A 33         [24] 1243 	mov	dptr,#_macro_keys
      007F25 C0 07            [24] 1244 	push	ar7
      007F27 12 7C BC         [24] 1245 	lcall	_ak820_macro_change
      007F2A E5 82            [12] 1246 	mov	a, dpl
      007F2C D0 07            [24] 1247 	pop	ar7
      007F2E 70 03            [24] 1248 	jnz	00102$
      007F30 F5 82            [12] 1249 	mov	dpl,a
      007F32 22               [24] 1250 	ret
      007F33                       1251 00102$:
                                   1252 ;	quantum/action_util.c:100: if (!key_refs[code] || --key_refs[code]) return false;
      007F33 12 81 F1         [24] 1253 	lcall	_ak820_outline_0031
      007F36 FC               [12] 1254 	mov	r4,a
      007F37 60 07            [24] 1255 	jz	00103$
      007F39 1C               [12] 1256 	dec	r4
      007F3A 12 43 A4         [24] 1257 	lcall	_ak820_outline_0074
      007F3D EC               [12] 1258 	mov	a,r4
      007F3E 60 04            [24] 1259 	jz	00104$
      007F40                       1260 00103$:
      007F40 75 82 00         [24] 1261 	mov	dpl, #0x00
      007F43 22               [24] 1262 	ret
      007F44                       1263 00104$:
                                   1264 ;	quantum/action_util.c:101: --distinct_keys;
      007F44 90 0A 32         [24] 1265 	mov	dptr,#_distinct_keys
      007F47 E0               [24] 1266 	movx	a,@dptr
      007F48 14               [12] 1267 	dec	a
      007F49 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/action_util.c:103: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007F4A 90 0D D4         [24] 1270 	mov	dptr,#_keyboard_protocol
      007F4D E0               [24] 1271 	movx	a,@dptr
      007F4E 60 15            [24] 1272 	jz	00107$
      007F50 90 0A B7         [24] 1273 	mov	dptr,#_keymap_config
      007F53 E0               [24] 1274 	movx	a,@dptr
      007F54 30 E7 0E         [24] 1275 	jnb	acc.7,00107$
                                   1276 ;	quantum/action_util.h:43: del_key_from_report(keyboard_report, key);
      007F57 90 08 00         [24] 1277 	mov	dptr,#_del_key_from_report_PARM_2
      007F5A EF               [12] 1278 	mov	a,r7
      007F5B 12 81 FF         [24] 1279 	lcall	_ak820_outline_0066
      007F5E 12 6F E7         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:103: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007F61 75 82 01         [24] 1282 	mov	dpl, #0x01
      007F64 22               [24] 1283 	ret
      007F65                       1284 00107$:
                                   1285 ;	quantum/action_util.c:105: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007F65 90 0A 32         [24] 1286 	mov	dptr,#_distinct_keys
      007F68 E0               [24] 1287 	movx	a,@dptr
      007F69 FF               [12] 1288 	mov  r7,a
      007F6A 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007F6C 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007F6E 75 82 01         [24] 1292 	mov	dpl, #0x01
      007F71 22               [24] 1293 	ret
      007F72                       1294 00110$:
                                   1295 ;	quantum/action_util.c:106: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007F72 BF 06 26         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007F75 90 0D E7         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007F78 75 F0 00         [24] 1299 	mov	b, #0x00
      007F7B 12 70 26         [24] 1300 	lcall	_clear_keys_from_report
                                   1301 ;	quantum/action_util.c:109: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007F7E 7F 04            [12] 1302 	mov	r7,#0x04
      007F80                       1303 00122$:
      007F80 EF               [12] 1304 	mov	a,r7
      007F81 24 5B            [12] 1305 	add	a,#0xff - 0xa4
      007F83 40 23            [24] 1306 	jc	00116$
                                   1307 ;	free result
      007F85 12 81 F1         [24] 1308 	lcall	_ak820_outline_0031
      007F88 60 0E            [24] 1309 	jz	00123$
                                   1310 ;	quantum/action_util.h:39: add_key_to_report(keyboard_report, key);
      007F8A 90 07 FC         [24] 1311 	mov	dptr,#_add_key_to_report_PARM_2
      007F8D EF               [12] 1312 	mov	a,r7
      007F8E 12 81 FF         [24] 1313 	lcall	_ak820_outline_0066
      007F91 C0 07            [24] 1314 	push	ar7
      007F93 12 6F A8         [24] 1315 	lcall	_add_key_to_report
      007F96 D0 07            [24] 1316 	pop	ar7
                                   1317 ;	quantum/action_util.c:109: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007F98                       1318 00123$:
      007F98 0F               [12] 1319 	inc	r7
      007F99 80 E5            [24] 1320 	sjmp	00122$
      007F9B                       1321 00115$:
                                   1322 ;	quantum/action_util.c:110: } else del_key(code);
      007F9B 90 0A 49         [24] 1323 	mov	dptr,#_del_owned_key_code_10000_335
      007F9E E0               [24] 1324 	movx	a,@dptr
                                   1325 ;	quantum/action_util.h:43: del_key_from_report(keyboard_report, key);
      007F9F 90 08 00         [24] 1326 	mov	dptr,#_del_key_from_report_PARM_2
      007FA2 12 81 FF         [24] 1327 	lcall	_ak820_outline_0066
      007FA5 12 6F E7         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:110: } else del_key(code);
      007FA8                       1330 00116$:
                                   1331 ;	quantum/action_util.c:111: return true;
      007FA8 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:112: }
      007FAB 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_360'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_361'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:122: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007FAC                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007FAC 7F 00            [12] 1347 	mov	r7,#0x00
      007FAE                       1348 00104$:
      007FAE BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007FB1                       1350 00141$:
      007FB1 50 14            [24] 1351 	jnc	00101$
      007FB3 EF               [12] 1352 	mov	a,r7
      007FB4 24 4A            [12] 1353 	add	a, #_usage_refs
      007FB6 FD               [12] 1354 	mov	r5,a
      007FB7 E4               [12] 1355 	clr	a
      007FB8 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007FBA FE               [12] 1357 	mov	r6,a
      007FBB EF               [12] 1358 	mov	a,r7
      007FBC 12 82 0E         [24] 1359 	lcall	_ak820_outline_0078
      007FBF E4               [12] 1360 	clr	a
      007FC0 F0               [24] 1361 	movx	@dptr,a
      007FC1 12 82 2E         [24] 1362 	lcall	_ak820_outline_0128
      007FC4 0F               [12] 1363 	inc	r7
      007FC5 80 E7            [24] 1364 	sjmp	00104$
      007FC7                       1365 00101$:
                                   1366 ;	quantum/action_util.c:124: usage_lengths[0] = usage_lengths[1] = 0;
      007FC7 90 0A 87         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007FCA E4               [12] 1368 	clr	a
      007FCB F0               [24] 1369 	movx	@dptr,a
      007FCC 90 0A 86         [24] 1370 	mov	dptr,#_usage_lengths
      007FCF F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:125: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007FD0 FF               [12] 1373 	mov	r7,a
      007FD1                       1374 00107$:
      007FD1 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007FD4                       1376 00143$:
      007FD4 50 0D            [24] 1377 	jnc	00109$
      007FD6 EF               [12] 1378 	mov	a,r7
      007FD7 24 88            [12] 1379 	add	a, #_macro_usages
      007FD9 F5 82            [12] 1380 	mov	dpl,a
      007FDB E4               [12] 1381 	clr	a
      007FDC 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007FDE 12 7C 9B         [24] 1383 	lcall	_ak820_outline_0167
      007FE1 80 EE            [24] 1384 	sjmp	00107$
      007FE3                       1385 00109$:
                                   1386 ;	quantum/action_util.c:126: }
      007FE3 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_362'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_363'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_363'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_363'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_363'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_363'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_370'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_371'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_374'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_375'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:127: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007FE4                       1407 _owned_usage_key:
      007FE4 E5 82            [12] 1408 	mov	a,dpl
      007FE6 90 0A 8D         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_362
      007FE9 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:128: uint8_t which = code >= KC_AUDIO_MUTE;
      007FEA E0               [24] 1412 	movx	a,@dptr
      007FEB FF               [12] 1413 	mov	r7,a
      007FEC BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007FEF                       1415 00244$:
      007FEF B3               [12] 1416 	cpl	c
      007FF0 92 22            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007FF2 E4               [12] 1418 	clr	a
      007FF3 33               [12] 1419 	rlc	a
      007FF4 FF               [12] 1420 	mov	r7,a
      007FF5 90 0A 90         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_363
      007FF8 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:129: uint8_t base = which ? SYSTEM_COUNT : 0;
      007FF9 EF               [12] 1424 	mov	a,r7
      007FFA 60 02            [24] 1425 	jz	00129$
      007FFC 74 03            [12] 1426 	mov	a,#0x03
      007FFE                       1427 00129$:
      007FFE FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:130: uint8_t count = usage_lengths[which];
      007FFF EF               [12] 1430 	mov	a,r7
      008000 24 86            [12] 1431 	add	a, #_usage_lengths
      008002 FD               [12] 1432 	mov	r5,a
      008003 E4               [12] 1433 	clr	a
      008004 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      008006 FF               [12] 1435 	mov	r7,a
      008007 12 82 4A         [24] 1436 	lcall	_ak820_outline_0198
      00800A E0               [24] 1437 	movx	a,@dptr
      00800B FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:131: uint8_t index = code - KC_SYSTEM_POWER;
      00800C 90 0A 8D         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_362
      00800F E0               [24] 1441 	movx	a,@dptr
      008010 24 5B            [12] 1442 	add	a,#0x5b
      008012 FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:132: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      008013 90 0A 8C         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      008016 E0               [24] 1446 	movx	a,@dptr
      008017 FA               [12] 1447 	mov	r2,a
      008018 90 09 81         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      00801B EB               [12] 1449 	mov	a,r3
      00801C F0               [24] 1450 	movx	@dptr,a
      00801D 90 09 82         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      008020 EA               [12] 1452 	mov	a,r2
      008021 F0               [24] 1453 	movx	@dptr,a
      008022 90 0A 88         [24] 1454 	mov	dptr,#_macro_usages
      008025 C0 07            [24] 1455 	push	ar7
      008027 C0 06            [24] 1456 	push	ar6
      008029 C0 05            [24] 1457 	push	ar5
      00802B C0 04            [24] 1458 	push	ar4
      00802D C0 03            [24] 1459 	push	ar3
      00802F C0 02            [24] 1460 	push	ar2
      008031 12 7C BC         [24] 1461 	lcall	_ak820_macro_change
      008034 E5 82            [12] 1462 	mov	a, dpl
      008036 D0 02            [24] 1463 	pop	ar2
      008038 D0 03            [24] 1464 	pop	ar3
      00803A D0 04            [24] 1465 	pop	ar4
      00803C D0 05            [24] 1466 	pop	ar5
      00803E D0 06            [24] 1467 	pop	ar6
      008040 D0 07            [24] 1468 	pop	ar7
      008042 70 01            [24] 1469 	jnz	00102$
      008044 22               [24] 1470 	ret
      008045                       1471 00102$:
                                   1472 ;	quantum/action_util.c:133: if (pressed) {
      008045 EA               [12] 1473 	mov	a,r2
      008046 60 1D            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:134: if (usage_refs[index]++) return;
      008048 12 82 18         [24] 1476 	lcall	_ak820_outline_0082
      00804B 04               [12] 1477 	inc	a
      00804C 89 82            [24] 1478 	mov	dpl,r1
      00804E 8A 83            [24] 1479 	mov	dph,r2
      008050 F0               [24] 1480 	movx	@dptr,a
      008051 E8               [12] 1481 	mov	a,r0
      008052 60 01            [24] 1482 	jz	00104$
      008054 22               [24] 1483 	ret
      008055                       1484 00104$:
                                   1485 ;	quantum/action_util.c:135: usage_order[base + count++] = index;
      008055 90 0A 91         [24] 1486 	mov	dptr,#_owned_usage_key_count_10000_363
      008058 EC               [12] 1487 	mov	a,r4
      008059 04               [12] 1488 	inc	a
      00805A F0               [24] 1489 	movx	@dptr,a
      00805B EC               [12] 1490 	mov	a,r4
      00805C 2E               [12] 1491 	add	a, r6
      00805D 12 82 0E         [24] 1492 	lcall	_ak820_outline_0078
      008060 EB               [12] 1493 	mov	a,r3
      008061 F0               [24] 1494 	movx	@dptr,a
      008062 02 80 C6         [24] 1495 	ljmp	00116$
      008065                       1496 00115$:
                                   1497 ;	quantum/action_util.c:137: if (!usage_refs[index] || --usage_refs[index]) return;
      008065 12 82 18         [24] 1498 	lcall	_ak820_outline_0082
      008068 60 07            [24] 1499 	jz	00105$
      00806A 18               [12] 1500 	dec	r0
      00806B 12 82 07         [24] 1501 	lcall	_ak820_outline_0072
      00806E E8               [12] 1502 	mov	a,r0
      00806F 60 01            [24] 1503 	jz	00106$
      008071                       1504 00105$:
      008071 22               [24] 1505 	ret
      008072                       1506 00106$:
                                   1507 ;	quantum/action_util.c:139: while (usage_order[base + pos] != index) ++pos;
      008072 7A 00            [12] 1508 	mov	r2,#0x00
      008074                       1509 00108$:
      008074 EA               [12] 1510 	mov	a,r2
      008075 2E               [12] 1511 	add	a, r6
      008076 12 82 0E         [24] 1512 	lcall	_ak820_outline_0078
      008079 E0               [24] 1513 	movx	a,@dptr
      00807A B5 03 02         [24] 1514 	cjne	a,ar3,00251$
      00807D 80 03            [24] 1515 	sjmp	00167$
      00807F                       1516 00251$:
      00807F 0A               [12] 1517 	inc	r2
      008080 80 F2            [24] 1518 	sjmp	00108$
      008082                       1519 00167$:
      008082 90 0A 92         [24] 1520 	mov	dptr,#_owned_usage_key_pos_30001_370
      008085 EA               [12] 1521 	mov	a,r2
      008086 F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	quantum/action_util.c:140: --count;
      008087 1C               [12] 1524 	dec	r4
      008088 90 0A 91         [24] 1525 	mov	dptr,#_owned_usage_key_count_10000_363
      00808B EC               [12] 1526 	mov	a,r4
      00808C F0               [24] 1527 	movx	@dptr,a
                                   1528 ;	quantum/action_util.c:141: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00808D 8A 03            [24] 1529 	mov	ar3,r2
      00808F                       1530 00125$:
      00808F C3               [12] 1531 	clr	c
      008090 EB               [12] 1532 	mov	a,r3
      008091 9C               [12] 1533 	subb	a,r4
      008092 50 23            [24] 1534 	jnc	00111$
      008094 C0 05            [24] 1535 	push	ar5
      008096 C0 07            [24] 1536 	push	ar7
      008098 EB               [12] 1537 	mov	a,r3
      008099 2E               [12] 1538 	add	a, r6
      00809A FA               [12] 1539 	mov	r2,a
      00809B 24 68            [12] 1540 	add	a, #_usage_order
      00809D F8               [12] 1541 	mov	r0,a
      00809E E4               [12] 1542 	clr	a
      00809F 34 0A            [12] 1543 	addc	a, #(_usage_order >> 8)
      0080A1 F9               [12] 1544 	mov	r1,a
      0080A2 0A               [12] 1545 	inc	r2
      0080A3 EA               [12] 1546 	mov	a,r2
      0080A4 33               [12] 1547 	rlc	a
      0080A5 95 E0            [12] 1548 	subb	a,acc
      0080A7 FF               [12] 1549 	mov	r7,a
      0080A8 EA               [12] 1550 	mov	a,r2
      0080A9 12 82 34         [24] 1551 	lcall	_ak820_outline_0133
      0080AC 12 39 2E         [24] 1552 	lcall	_ak820_outline_0155
      0080AF F0               [24] 1553 	movx	@dptr,a
      0080B0 0B               [12] 1554 	inc	r3
      0080B1 D0 07            [24] 1555 	pop	ar7
      0080B3 D0 05            [24] 1556 	pop	ar5
      0080B5 80 D8            [24] 1557 	sjmp	00125$
      0080B7                       1558 00111$:
                                   1559 ;	quantum/action_util.c:142: usage_lengths[which] = count;
      0080B7 12 82 4A         [24] 1560 	lcall	_ak820_outline_0198
      0080BA EC               [12] 1561 	mov	a,r4
      0080BB F0               [24] 1562 	movx	@dptr,a
                                   1563 ;	quantum/action_util.c:143: if (pos != count) return; /* A non-winning owner changed only storage. */
      0080BC 90 0A 92         [24] 1564 	mov	dptr,#_owned_usage_key_pos_30001_370
      0080BF E0               [24] 1565 	movx	a,@dptr
      0080C0 B5 04 02         [24] 1566 	cjne	a,ar4,00253$
      0080C3 80 01            [24] 1567 	sjmp	00116$
      0080C5                       1568 00253$:
      0080C5 22               [24] 1569 	ret
      0080C6                       1570 00116$:
                                   1571 ;	quantum/action_util.c:145: usage_lengths[which] = count;
      0080C6 90 0A 91         [24] 1572 	mov	dptr,#_owned_usage_key_count_10000_363
      0080C9 E0               [24] 1573 	movx	a,@dptr
      0080CA FC               [12] 1574 	mov	r4,a
      0080CB 12 82 4A         [24] 1575 	lcall	_ak820_outline_0198
      0080CE F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/action_util.c:146: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0080CF EC               [12] 1578 	mov	a,r4
      0080D0 60 15            [24] 1579 	jz	00131$
      0080D2 EC               [12] 1580 	mov	a,r4
      0080D3 2E               [12] 1581 	add	a, r6
      0080D4 FE               [12] 1582 	mov	r6,a
      0080D5 1E               [12] 1583 	dec	r6
      0080D6 EE               [12] 1584 	mov	a,r6
      0080D7 33               [12] 1585 	rlc	a
      0080D8 95 E0            [12] 1586 	subb	a,acc
      0080DA FF               [12] 1587 	mov	r7,a
      0080DB EE               [12] 1588 	mov	a,r6
      0080DC 12 82 34         [24] 1589 	lcall	_ak820_outline_0133
      0080DF 24 A5            [12] 1590 	add	a,#0xa5
      0080E1 FE               [12] 1591 	mov	r6,a
      0080E2 33               [12] 1592 	rlc	a
      0080E3 95 E0            [12] 1593 	subb	a,acc
      0080E5 80 02            [24] 1594 	sjmp	00132$
      0080E7                       1595 00131$:
      0080E7 7E 00            [12] 1596 	mov	r6,#0x00
      0080E9                       1597 00132$:
      0080E9 90 0A 8D         [24] 1598 	mov	dptr,#_owned_usage_key_code_10000_362
      0080EC EE               [12] 1599 	mov	a,r6
      0080ED F0               [24] 1600 	movx	@dptr,a
                                   1601 ;	quantum/action_util.c:147: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0080EE 90 0A 90         [24] 1602 	mov	dptr,#_owned_usage_key_which_10000_363
      0080F1 E0               [24] 1603 	movx	a,@dptr
      0080F2 60 18            [24] 1604 	jz	00118$
      0080F4 EE               [12] 1605 	mov	a,r6
      0080F5 60 0B            [24] 1606 	jz	00133$
      0080F7 8E 82            [24] 1607 	mov	dpl, r6
      0080F9 12 6E 65         [24] 1608 	lcall	_KEYCODE2CONSUMER
      0080FC AD 82            [24] 1609 	mov	r5, dpl
      0080FE AF 83            [24] 1610 	mov	r7, dph
      008100 80 04            [24] 1611 	sjmp	00134$
      008102                       1612 00133$:
      008102 7D 00            [12] 1613 	mov	r5,#0x00
      008104 7F 00            [12] 1614 	mov	r7,#0x00
      008106                       1615 00134$:
      008106 12 82 4A         [24] 1616 	lcall	_ak820_outline_0198
      008109 02 6E 18         [24] 1617 	ljmp	_host_consumer_send
      00810C                       1618 00118$:
                                   1619 ;	quantum/action_util.c:148: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00810C EE               [12] 1620 	mov	a,r6
      00810D 60 22            [24] 1621 	jz	00135$
                                   1622 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      00810F BE A5 00         [24] 1623 	cjne	r6,#0xa5,00258$
      008112                       1624 00258$:
      008112 40 05            [24] 1625 	jc	00121$
      008114 EE               [12] 1626 	mov	a,r6
      008115 24 58            [12] 1627 	add	a,#0xff - 0xa7
      008117 50 08            [24] 1628 	jnc	00122$
                                   1629 ;	free result
      008119                       1630 00121$:
      008119 90 0A 8E         [24] 1631 	mov	dptr,#_owned_usage_key___200000085_20000_363
      00811C 12 4F B3         [24] 1632 	lcall	_ak820_outline_0174
      00811F 80 09            [24] 1633 	sjmp	00123$
      008121                       1634 00122$:
                                   1635 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008121 74 DC            [12] 1636 	mov	a,#0xdc
      008123 2E               [12] 1637 	add	a, r6
      008124 90 0A 8E         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_363
      008127 12 39 0D         [24] 1639 	lcall	_ak820_outline_0130
                                   1640 ;	quantum/action_util.c:148: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00812A                       1641 00123$:
      00812A 90 0A 8E         [24] 1642 	mov	dptr,#_owned_usage_key___200000085_20000_363
      00812D E0               [24] 1643 	movx	a,@dptr
      00812E FF               [12] 1644 	mov	r7,a
      00812F 80 02            [24] 1645 	sjmp	00136$
      008131                       1646 00135$:
      008131 7F 00            [12] 1647 	mov	r7,#0x00
      008133                       1648 00136$:
      008133 7E 00            [12] 1649 	mov	r6,#0x00
      008135 12 43 E0         [24] 1650 	lcall	_ak820_outline_0164
                                   1651 ;	quantum/action_util.c:149: }
      008138 02 6D E8         [24] 1652 	ljmp	_host_system_send
                                   1653 ;------------------------------------------------------------
                                   1654 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1655 ;------------------------------------------------------------
                                   1656 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_382'
                                   1657 ;changed       Allocated with name '_send_keyboard_report_changed_10001_382'
                                   1658 ;dest          Allocated with name '_send_keyboard_report_dest_10001_382'
                                   1659 ;src           Allocated with name '_send_keyboard_report_src_10001_382'
                                   1660 ;i             Allocated with name '_send_keyboard_report_i_20001_383'
                                   1661 ;------------------------------------------------------------
                                   1662 ;	quantum/action_util.c:371: void send_keyboard_report(void) {
                                   1663 ;	-----------------------------------------
                                   1664 ;	 function send_keyboard_report
                                   1665 ;	-----------------------------------------
      00813B                       1666 _send_keyboard_report:
                                   1667 ;	quantum/action_util.c:372: keyboard_report->mods = real_mods;
      00813B 90 0D E5         [24] 1668 	mov	dptr,#_real_mods
      00813E E0               [24] 1669 	movx	a,@dptr
      00813F FF               [12] 1670 	mov	r7,a
      008140 90 0D E7         [24] 1671 	mov	dptr,#_actual_keyboard_report
      008143 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/action_util.c:373: keyboard_report->mods |= weak_mods;
      008144 90 0D E6         [24] 1674 	mov	dptr,#_weak_mods
      008147 E0               [24] 1675 	movx	a,@dptr
      008148 42 07            [12] 1676 	orl	ar7,a
      00814A 90 0D E7         [24] 1677 	mov	dptr,#_actual_keyboard_report
      00814D EF               [12] 1678 	mov	a,r7
      00814E F0               [24] 1679 	movx	@dptr,a
                                   1680 ;	quantum/action_util.c:375: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00814F 90 09 7C         [24] 1681 	mov	dptr,#_owned_weak_mods
      008152 E0               [24] 1682 	movx	a,@dptr
      008153 FE               [12] 1683 	mov	r6,a
      008154 90 09 7B         [24] 1684 	mov	dptr,#_owned_mods
      008157 E0               [24] 1685 	movx	a,@dptr
      008158 4E               [12] 1686 	orl	a,r6
      008159 42 07            [12] 1687 	orl	ar7,a
      00815B 90 0D E7         [24] 1688 	mov	dptr,#_actual_keyboard_report
      00815E EF               [12] 1689 	mov	a,r7
      00815F F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:406: bool changed = false;
      008160 90 0A B4         [24] 1692 	mov	dptr,#_send_keyboard_report_changed_10001_382
      008163 E4               [12] 1693 	clr	a
      008164 F0               [24] 1694 	movx	@dptr,a
                                   1695 ;	quantum/action_util.c:408: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1696 ;	quantum/action_util.c:409: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1697 ;	quantum/action_util.c:414: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008165 FF               [12] 1698 	mov	r7,a
      008166                       1699 00107$:
      008166 BF 20 00         [24] 1700 	cjne	r7,#0x20,00140$
      008169                       1701 00140$:
      008169 50 2B            [24] 1702 	jnc	00103$
                                   1703 ;	quantum/action_util.c:415: if (dest[i] != src[i]) {
      00816B EF               [12] 1704 	mov	a,r7
      00816C 24 94            [12] 1705 	add	a, #_send_keyboard_report_last_report_10001_382
      00816E FD               [12] 1706 	mov	r5,a
      00816F E4               [12] 1707 	clr	a
      008170 34 0A            [12] 1708 	addc	a, #(_send_keyboard_report_last_report_10001_382 >> 8)
      008172 FE               [12] 1709 	mov	r6,a
      008173 12 49 0D         [24] 1710 	lcall	_ak820_outline_0085
      008176 EF               [12] 1711 	mov	a,r7
      008177 24 E7            [12] 1712 	add	a, #_actual_keyboard_report
      008179 F5 82            [12] 1713 	mov	dpl,a
      00817B E4               [12] 1714 	clr	a
      00817C 34 0D            [12] 1715 	addc	a, #(_actual_keyboard_report >> 8)
      00817E F5 83            [12] 1716 	mov	dph,a
      008180 E0               [24] 1717 	movx	a,@dptr
      008181 FB               [12] 1718 	mov	r3,a
      008182 EC               [12] 1719 	mov	a,r4
      008183 B5 03 02         [24] 1720 	cjne	a,ar3,00142$
      008186 80 0B            [24] 1721 	sjmp	00108$
      008188                       1722 00142$:
                                   1723 ;	quantum/action_util.c:416: dest[i] = src[i];
      008188 12 39 17         [24] 1724 	lcall	_ak820_outline_0141
      00818B EB               [12] 1725 	mov	a,r3
      00818C F0               [24] 1726 	movx	@dptr,a
                                   1727 ;	quantum/action_util.c:417: changed = true;
      00818D 90 0A B4         [24] 1728 	mov	dptr,#_send_keyboard_report_changed_10001_382
      008190 74 01            [12] 1729 	mov	a,#0x01
      008192 F0               [24] 1730 	movx	@dptr,a
      008193                       1731 00108$:
                                   1732 ;	quantum/action_util.c:414: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008193 0F               [12] 1733 	inc	r7
      008194 80 D0            [24] 1734 	sjmp	00107$
      008196                       1735 00103$:
                                   1736 ;	quantum/action_util.c:420: if (changed) host_keyboard_send(keyboard_report);
      008196 90 0A B4         [24] 1737 	mov	dptr,#_send_keyboard_report_changed_10001_382
      008199 E0               [24] 1738 	movx	a,@dptr
      00819A 60 09            [24] 1739 	jz	00109$
      00819C 90 0D E7         [24] 1740 	mov	dptr,#_actual_keyboard_report
      00819F 75 F0 00         [24] 1741 	mov	b, #0x00
                                   1742 ;	quantum/action_util.c:428: }
      0081A2 02 6D 5D         [24] 1743 	ljmp	_host_keyboard_send
      0081A5                       1744 00109$:
      0081A5 22               [24] 1745 	ret
                                   1746 ;------------------------------------------------------------
                                   1747 ;Allocation info for local variables in function 'get_mods'
                                   1748 ;------------------------------------------------------------
                                   1749 ;	quantum/action_util.c:434: uint8_t get_mods(void) {
                                   1750 ;	-----------------------------------------
                                   1751 ;	 function get_mods
                                   1752 ;	-----------------------------------------
      0081A6                       1753 _get_mods:
      0081A6 C0 07            [24] 1754 	push	ar7
                                   1755 ;	quantum/action_util.c:439: ;
      0081A8 90 09 7B         [24] 1756 	mov	dptr,#_owned_mods
      0081AB E0               [24] 1757 	movx	a,@dptr
      0081AC FF               [12] 1758 	mov	r7,a
      0081AD 90 0D E5         [24] 1759 	mov	dptr,#_real_mods
      0081B0 12 7C 95         [24] 1760 	lcall	_ak820_outline_0148
                                   1761 ;	quantum/action_util.c:440: }
      0081B3 D0 07            [24] 1762 	pop	ar7
      0081B5 22               [24] 1763 	ret
                                   1764 ;------------------------------------------------------------
                                   1765 ;Allocation info for local variables in function 'add_mods'
                                   1766 ;------------------------------------------------------------
                                   1767 ;mods          Allocated with name '_add_mods_mods_10000_390'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/action_util.c:445: void add_mods(uint8_t mods) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function clear_mods
                                   1772 ;	-----------------------------------------
      0081B6                       1773 _clear_mods:
                                   1774 ;	quantum/action_util.c:467: real_mods = 0;
      0081B6 90 0D E5         [24] 1775 	mov	dptr,#_real_mods
      0081B9 E4               [12] 1776 	clr	a
      0081BA F0               [24] 1777 	movx	@dptr,a
                                   1778 ;	quantum/action_util.c:468: }
      0081BB 22               [24] 1779 	ret
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'get_weak_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;	quantum/action_util.c:474: uint8_t get_weak_mods(void) {
                                   1784 ;	-----------------------------------------
                                   1785 ;	 function get_weak_mods
                                   1786 ;	-----------------------------------------
      0081BC                       1787 _get_weak_mods:
      0081BC C0 07            [24] 1788 	push	ar7
                                   1789 ;	quantum/action_util.c:479: ;
      0081BE 90 09 7C         [24] 1790 	mov	dptr,#_owned_weak_mods
      0081C1 E0               [24] 1791 	movx	a,@dptr
      0081C2 FF               [12] 1792 	mov	r7,a
      0081C3 90 0D E6         [24] 1793 	mov	dptr,#_weak_mods
      0081C6 12 7C 95         [24] 1794 	lcall	_ak820_outline_0148
                                   1795 ;	quantum/action_util.c:480: }
      0081C9 D0 07            [24] 1796 	pop	ar7
      0081CB 22               [24] 1797 	ret
                                   1798 ;------------------------------------------------------------
                                   1799 ;Allocation info for local variables in function 'add_weak_mods'
                                   1800 ;------------------------------------------------------------
                                   1801 ;mods          Allocated with name '_add_weak_mods_mods_10000_400'
                                   1802 ;------------------------------------------------------------
                                   1803 ;	quantum/action_util.c:485: void add_weak_mods(uint8_t mods) {
                                   1804 ;	-----------------------------------------
                                   1805 ;	 function add_weak_mods
                                   1806 ;	-----------------------------------------
      0081CC                       1807 _add_weak_mods:
      0081CC E5 82            [12] 1808 	mov	a,dpl
      0081CE 90 0A B5         [24] 1809 	mov	dptr,#_add_weak_mods_mods_10000_400
      0081D1 F0               [24] 1810 	movx	@dptr,a
                                   1811 ;	quantum/action_util.c:486: weak_mods |= mods;
      0081D2 E0               [24] 1812 	movx	a,@dptr
      0081D3 FF               [12] 1813 	mov	r7,a
      0081D4 90 0D E6         [24] 1814 	mov	dptr,#_weak_mods
      0081D7 E0               [24] 1815 	movx	a,@dptr
      0081D8 4F               [12] 1816 	orl	a,r7
      0081D9 F0               [24] 1817 	movx	@dptr,a
                                   1818 ;	quantum/action_util.c:487: }
      0081DA 22               [24] 1819 	ret
                                   1820 ;------------------------------------------------------------
                                   1821 ;Allocation info for local variables in function 'del_weak_mods'
                                   1822 ;------------------------------------------------------------
                                   1823 ;mods          Allocated with name '_del_weak_mods_mods_10000_402'
                                   1824 ;------------------------------------------------------------
                                   1825 ;	quantum/action_util.c:492: void del_weak_mods(uint8_t mods) {
                                   1826 ;	-----------------------------------------
                                   1827 ;	 function del_weak_mods
                                   1828 ;	-----------------------------------------
      0081DB                       1829 _del_weak_mods:
      0081DB E5 82            [12] 1830 	mov	a,dpl
      0081DD 90 0A B6         [24] 1831 	mov	dptr,#_del_weak_mods_mods_10000_402
      0081E0 F0               [24] 1832 	movx	@dptr,a
                                   1833 ;	quantum/action_util.c:493: weak_mods &= ~mods;
      0081E1 E0               [24] 1834 	movx	a,@dptr
      0081E2 F4               [12] 1835 	cpl	a
      0081E3 FF               [12] 1836 	mov	r7,a
      0081E4 90 0D E6         [24] 1837 	mov	dptr,#_weak_mods
      0081E7 E0               [24] 1838 	movx	a,@dptr
      0081E8 5F               [12] 1839 	anl	a,r7
      0081E9 F0               [24] 1840 	movx	@dptr,a
                                   1841 ;	quantum/action_util.c:494: }
      0081EA 22               [24] 1842 	ret
                                   1843 ;------------------------------------------------------------
                                   1844 ;Allocation info for local variables in function 'set_weak_mods'
                                   1845 ;------------------------------------------------------------
                                   1846 ;mods          Allocated with name '_set_weak_mods_mods_10000_404'
                                   1847 ;------------------------------------------------------------
                                   1848 ;	quantum/action_util.c:499: void set_weak_mods(uint8_t mods) {
                                   1849 ;	-----------------------------------------
                                   1850 ;	 function clear_weak_mods
                                   1851 ;	-----------------------------------------
      0081EB                       1852 _clear_weak_mods:
                                   1853 ;	quantum/action_util.c:507: weak_mods = 0;
      0081EB 90 0D E6         [24] 1854 	mov	dptr,#_weak_mods
      0081EE E4               [12] 1855 	clr	a
      0081EF F0               [24] 1856 	movx	@dptr,a
                                   1857 ;	quantum/action_util.c:508: }
      0081F0 22               [24] 1858 	ret
                                   1859 ;------------------------------------------------------------
                                   1860 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1861 ;------------------------------------------------------------
                                   1862 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_408'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	quantum/action_util.c:590: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1865 ;	-----------------------------------------
                                   1866 	.area CSEG    (CODE)
                                   1867 	.area CONST   (CODE)
                                   1868 	.area XINIT   (CODE)
      00C4DF                       1869 __xinit__real_mods:
      00C4DF 00                    1870 	.db #0x00	; 0
      00C4E0                       1871 __xinit__weak_mods:
      00C4E0 00                    1872 	.db #0x00	; 0
      00C4E1                       1873 __xinit__actual_keyboard_report:
      00C4E1 00                    1874 	.db #0x00	; 0
      00C4E2 00                    1875 	.db #0x00	; 0
      00C4E3 00                    1876 	.db #0x00	; 0
      00C4E4 00                    1877 	.db #0x00	; 0
      00C4E5 00                    1878 	.db #0x00	; 0
      00C4E6 00                    1879 	.db #0x00	; 0
      00C4E7 00                    1880 	.db #0x00	; 0
      00C4E8 00                    1881 	.db #0x00	; 0
      00C4E9 00                    1882 	.db 0x00
      00C4EA 00                    1883 	.db 0x00
      00C4EB 00                    1884 	.db 0x00
      00C4EC 00                    1885 	.db 0x00
      00C4ED 00                    1886 	.db 0x00
      00C4EE 00                    1887 	.db 0x00
      00C4EF 00                    1888 	.db 0x00
      00C4F0 00                    1889 	.db 0x00
      00C4F1 00                    1890 	.db 0x00
      00C4F2 00                    1891 	.db 0x00
      00C4F3 00                    1892 	.db 0x00
      00C4F4 00                    1893 	.db 0x00
      00C4F5 00                    1894 	.db 0x00
      00C4F6 00                    1895 	.db 0x00
      00C4F7 00                    1896 	.db 0x00
      00C4F8 00                    1897 	.db 0x00
      00C4F9 00                    1898 	.db 0x00
      00C4FA 00                    1899 	.db 0x00
      00C4FB 00                    1900 	.db 0x00
      00C4FC 00                    1901 	.db 0x00
      00C4FD 00                    1902 	.db 0x00
      00C4FE 00                    1903 	.db 0x00
      00C4FF 00                    1904 	.db 0x00
      00C500 00                    1905 	.db 0x00
                                   1906 	.area CABS    (ABS,CODE)
                                   1907 
                                   1908 ; Experimental exact instruction outlining.
                                   1909 	.globl _ak820_outline_0018
                                   1910 	.globl _ak820_outline_0031
                                   1911 	.globl _ak820_outline_0063
                                   1912 	.globl _ak820_outline_0066
                                   1913 	.globl _ak820_outline_0071
                                   1914 	.globl _ak820_outline_0072
                                   1915 	.globl _ak820_outline_0074
                                   1916 	.globl _ak820_outline_0076
                                   1917 	.globl _ak820_outline_0078
                                   1918 	.globl _ak820_outline_0082
                                   1919 	.globl _ak820_outline_0085
                                   1920 	.globl _ak820_outline_0120
                                   1921 	.globl _ak820_outline_0121
                                   1922 	.globl _ak820_outline_0122
                                   1923 	.globl _ak820_outline_0128
                                   1924 	.globl _ak820_outline_0129
                                   1925 	.globl _ak820_outline_0130
                                   1926 	.globl _ak820_outline_0133
                                   1927 	.globl _ak820_outline_0139
                                   1928 	.globl _ak820_outline_0141
                                   1929 	.globl _ak820_outline_0148
                                   1930 	.globl _ak820_outline_0155
                                   1931 	.globl _ak820_outline_0164
                                   1932 	.globl _ak820_outline_0167
                                   1933 	.globl _ak820_outline_0174
                                   1934 	.globl _ak820_outline_0196
                                   1935 	.globl _ak820_outline_0198
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0031
      0081F1                       1939 _ak820_outline_0031:
      0081F1 EF               [12] 1940 	mov	a,r7
      0081F2 24 8D            [12] 1941 	add	a,#_key_refs
      0081F4 FD               [12] 1942 	mov	r5,a
      0081F5 E4               [12] 1943 	clr	a
      0081F6 34 09            [12] 1944 	addc	a,#(_key_refs>>8)
      0081F8 FE               [12] 1945 	mov	r6,a
      0081F9 8D 82            [24] 1946 	mov	dpl,r5
      0081FB 8E 83            [24] 1947 	mov	dph,r6
      0081FD E0               [24] 1948 	movx	a,@dptr
      0081FE 22               [24] 1949 	ret
                                   1950 
                                   1951 	.area CSEG (CODE)
                                   1952 ; function ak820_outline_0066
      0081FF                       1953 _ak820_outline_0066:
      0081FF F0               [24] 1954 	movx	@dptr,a
      008200 90 0D E7         [24] 1955 	mov	dptr,#_actual_keyboard_report
      008203 75 F0 00         [24] 1956 	mov	b,#0x00
      008206 22               [24] 1957 	ret
                                   1958 
                                   1959 	.area CSEG (CODE)
                                   1960 ; function ak820_outline_0072
      008207                       1961 _ak820_outline_0072:
      008207 89 82            [24] 1962 	mov	dpl,r1
      008209 8A 83            [24] 1963 	mov	dph,r2
      00820B E8               [12] 1964 	mov	a,r0
      00820C F0               [24] 1965 	movx	@dptr,a
      00820D 22               [24] 1966 	ret
                                   1967 
                                   1968 	.area CSEG (CODE)
                                   1969 ; function ak820_outline_0078
      00820E                       1970 _ak820_outline_0078:
      00820E 24 68            [12] 1971 	add	a,#_usage_order
      008210 F5 82            [12] 1972 	mov	dpl,a
      008212 E4               [12] 1973 	clr	a
      008213 34 0A            [12] 1974 	addc	a,#(_usage_order>>8)
      008215 F5 83            [12] 1975 	mov	dph,a
      008217 22               [24] 1976 	ret
                                   1977 
                                   1978 	.area CSEG (CODE)
                                   1979 ; function ak820_outline_0082
      008218                       1980 _ak820_outline_0082:
      008218 EB               [12] 1981 	mov	a,r3
      008219 24 4A            [12] 1982 	add	a,#_usage_refs
      00821B F9               [12] 1983 	mov	r1,a
      00821C E4               [12] 1984 	clr	a
      00821D 34 0A            [12] 1985 	addc	a,#(_usage_refs>>8)
      00821F FA               [12] 1986 	mov	r2,a
      008220 89 82            [24] 1987 	mov	dpl,r1
      008222 8A 83            [24] 1988 	mov	dph,r2
      008224 E0               [24] 1989 	movx	a,@dptr
      008225 F8               [12] 1990 	mov	r0,a
      008226 22               [24] 1991 	ret
                                   1992 
                                   1993 	.area CSEG (CODE)
                                   1994 ; function ak820_outline_0120
      008227                       1995 _ak820_outline_0120:
      008227 F0               [24] 1996 	movx	@dptr,a
      008228 E0               [24] 1997 	movx	a,@dptr
      008229 FF               [12] 1998 	mov	r7,a
      00822A 90 09 85         [24] 1999 	mov	dptr,#_change_owned_PARM_2
      00822D 22               [24] 2000 	ret
                                   2001 
                                   2002 	.area CSEG (CODE)
                                   2003 ; function ak820_outline_0128
      00822E                       2004 _ak820_outline_0128:
      00822E 8D 82            [24] 2005 	mov	dpl,r5
      008230 8E 83            [24] 2006 	mov	dph,r6
      008232 F0               [24] 2007 	movx	@dptr,a
      008233 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0133
      008234                       2012 _ak820_outline_0133:
      008234 24 68            [12] 2013 	add	a,#_usage_order
      008236 F5 82            [12] 2014 	mov	dpl,a
      008238 EF               [12] 2015 	mov	a,r7
      008239 34 0A            [12] 2016 	addc	a,#(_usage_order>>8)
      00823B F5 83            [12] 2017 	mov	dph,a
      00823D E0               [24] 2018 	movx	a,@dptr
      00823E 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0139
      00823F                       2023 _ak820_outline_0139:
      00823F F0               [24] 2024 	movx	@dptr,a
      008240 E0               [24] 2025 	movx	a,@dptr
      008241 FF               [12] 2026 	mov	r7,a
      008242 90 09 81         [24] 2027 	mov	dptr,#_ak820_macro_change_PARM_2
      008245 F0               [24] 2028 	movx	@dptr,a
      008246 90 09 82         [24] 2029 	mov	dptr,#_ak820_macro_change_PARM_3
      008249 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0198
      00824A                       2034 _ak820_outline_0198:
      00824A 8D 82            [24] 2035 	mov	dpl,r5
      00824C 8F 83            [24] 2036 	mov	dph,r7
      00824E 22               [24] 2037 	ret
