                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _action_exec
                                     28 	.globl _print_set_sendchar
                                     29 	.globl _sendchar
                                     30 	.globl _led_task
                                     31 	.globl _led_init_ports
                                     32 	.globl _magic
                                     33 	.globl _matrix_print
                                     34 	.globl _matrix_get_row
                                     35 	.globl _matrix_scan
                                     36 	.globl _matrix_init
                                     37 	.globl _keyboard_post_init_user
                                     38 	.globl _timer_elapsed32
                                     39 	.globl _timer_read32
                                     40 	.globl _timer_read
                                     41 	.globl _timer_init
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _switch_events_PARM_3
                                    286 	.globl _switch_events_PARM_2
                                    287 	.globl _keyboard_post_init_kb
                                    288 	.globl _matrix_can_read
                                    289 	.globl _keyboard_setup
                                    290 	.globl _is_keyboard_master
                                    291 	.globl _housekeeping_task
                                    292 	.globl _keyboard_init
                                    293 	.globl _keyboard_task
                                    294 ;--------------------------------------------------------
                                    295 ; special function registers
                                    296 ;--------------------------------------------------------
                                    297 	.area RSEG    (ABS,DATA)
      000000                        298 	.org 0x0000
                           0000D0   299 _PSW	=	0x00d0
                           0000E0   300 _ACC	=	0x00e0
                           0000F0   301 _B	=	0x00f0
                           0000FD   302 _A_INV	=	0x00fd
                           000081   303 _SP	=	0x0081
                           000082   304 _DPL	=	0x0082
                           000083   305 _DPH	=	0x0083
                           0000A1   306 _SAFE_MOD	=	0x00a1
                           0000B1   307 _GLOBAL_CFG	=	0x00b1
                           000087   308 _PCON	=	0x0087
                           0000BA   309 _POWER_CFG	=	0x00ba
                           0000B9   310 _CLOCK_CFG	=	0x00b9
                           0000A9   311 _WAKE_CTRL	=	0x00a9
                           0000FE   312 _RESET_KEEP	=	0x00fe
                           0000FF   313 _WDOG_COUNT	=	0x00ff
                           0000A8   314 _IE	=	0x00a8
                           0000B8   315 _IP	=	0x00b8
                           0000E8   316 _IE_EX	=	0x00e8
                           0000E9   317 _IP_EX	=	0x00e9
                           0000B2   318 _GPIO_IE	=	0x00b2
                           008584   319 _ROM_ADDR	=	0x8584
                           000084   320 _ROM_ADDR_L	=	0x0084
                           000085   321 _ROM_ADDR_H	=	0x0085
                           008F8E   322 _ROM_DATA_HI	=	0x8f8e
                           00008E   323 _ROM_DATA_HL	=	0x008e
                           00008F   324 _ROM_DATA_HH	=	0x008f
                           000086   325 _ROM_CTRL	=	0x0086
                           000080   326 _P0	=	0x0080
                           0000C4   327 _P0_MOD_OC	=	0x00c4
                           0000C5   328 _P0_DIR_PU	=	0x00c5
                           000090   329 _P1	=	0x0090
                           000092   330 _P1_MOD_OC	=	0x0092
                           000093   331 _P1_DIR_PU	=	0x0093
                           0000A0   332 _P2	=	0x00a0
                           000094   333 _P2_MOD_OC	=	0x0094
                           000095   334 _P2_DIR_PU	=	0x0095
                           0000B0   335 _P3	=	0x00b0
                           000096   336 _P3_MOD_OC	=	0x0096
                           000097   337 _P3_DIR_PU	=	0x0097
                           0000C0   338 _P4	=	0x00c0
                           0000C2   339 _P4_MOD_OC	=	0x00c2
                           0000C3   340 _P4_DIR_PU	=	0x00c3
                           0000C1   341 _P4_LED_KEY	=	0x00c1
                           0000AA   342 _P5_IN	=	0x00aa
                           0000AB   343 _P5_OUT_PU	=	0x00ab
                           0000AC   344 _P5_DIR	=	0x00ac
                           0000AD   345 _P6_IN	=	0x00ad
                           0000AE   346 _P6_OUT_PU	=	0x00ae
                           0000AF   347 _P6_DIR	=	0x00af
                           0000F1   348 _P7	=	0x00f1
                           0000A2   349 _XBUS_AUX	=	0x00a2
                           000088   350 _TCON	=	0x0088
                           000089   351 _TMOD	=	0x0089
                           00008A   352 _TL0	=	0x008a
                           00008B   353 _TL1	=	0x008b
                           00008C   354 _TH0	=	0x008c
                           00008D   355 _TH1	=	0x008d
                           000098   356 _SCON	=	0x0098
                           000099   357 _SBUF	=	0x0099
                           0000C8   358 _T2CON	=	0x00c8
                           0000C9   359 _T2MOD	=	0x00c9
                           00CBCA   360 _RCAP2	=	0xcbca
                           0000CA   361 _RCAP2L	=	0x00ca
                           0000CB   362 _RCAP2H	=	0x00cb
                           00CDCC   363 _T2COUNT	=	0xcdcc
                           0000CC   364 _TL2	=	0x00cc
                           0000CD   365 _TH2	=	0x00cd
                           00CFCE   366 _T2CAP1	=	0xcfce
                           0000CE   367 _T2CAP1L	=	0x00ce
                           0000CF   368 _T2CAP1H	=	0x00cf
                           0000F8   369 _SPI0_STAT	=	0x00f8
                           0000F9   370 _SPI0_DATA	=	0x00f9
                           0000FA   371 _SPI0_CTRL	=	0x00fa
                           0000FB   372 _SPI0_CK_SE	=	0x00fb
                           0000FC   373 _SPI0_SETUP	=	0x00fc
                           0000BC   374 _SCON1	=	0x00bc
                           0000BD   375 _SBUF1	=	0x00bd
                           0000BE   376 _SBAUD1	=	0x00be
                           0000BF   377 _SIF1	=	0x00bf
                           0000B4   378 _SPI1_STAT	=	0x00b4
                           0000B5   379 _SPI1_DATA	=	0x00b5
                           0000B6   380 _SPI1_CTRL	=	0x00b6
                           0000B7   381 _SPI1_CK_SE	=	0x00b7
                           0000F3   382 _ADC_CTRL	=	0x00f3
                           00F5F4   383 _ADC_DAT	=	0xf5f4
                           0000F4   384 _ADC_DAT_L	=	0x00f4
                           0000F5   385 _ADC_DAT_H	=	0x00f5
                           0000F6   386 _ADC_CHAN	=	0x00f6
                           0000A6   387 _LED_COMMON	=	0x00a6
                           0000A7   388 _LED_PWM_OE	=	0x00a7
                           00C7C6   389 _LED_DMA	=	0xc7c6
                           0000C6   390 _LED_DMA_L	=	0x00c6
                           0000C7   391 _LED_DMA_H	=	0x00c7
                           0000F7   392 _LED_STATUS	=	0x00f7
                           0000B3   393 _I2CX_INT	=	0x00b3
                           0000BB   394 _I2CS_INT_ST	=	0x00bb
                                    395 ;--------------------------------------------------------
                                    396 ; special function bits
                                    397 ;--------------------------------------------------------
                                    398 	.area RSEG    (ABS,DATA)
      000000                        399 	.org 0x0000
                           0000D7   400 _CY	=	0x00d7
                           0000D6   401 _AC	=	0x00d6
                           0000D5   402 _F0	=	0x00d5
                           0000D4   403 _RS1	=	0x00d4
                           0000D3   404 _RS0	=	0x00d3
                           0000D2   405 _OV	=	0x00d2
                           0000D1   406 _F1	=	0x00d1
                           0000D0   407 _P	=	0x00d0
                           0000AF   408 _EA	=	0x00af
                           0000AE   409 _E_DIS	=	0x00ae
                           0000AD   410 _ET2	=	0x00ad
                           0000AC   411 _ES	=	0x00ac
                           0000AB   412 _ET1	=	0x00ab
                           0000AA   413 _EX1	=	0x00aa
                           0000A9   414 _ET0	=	0x00a9
                           0000A8   415 _EX0	=	0x00a8
                           0000BF   416 _PH_FLAG	=	0x00bf
                           0000BE   417 _PL_FLAG	=	0x00be
                           0000BD   418 _PT2	=	0x00bd
                           0000BC   419 _PS	=	0x00bc
                           0000BB   420 _PT1	=	0x00bb
                           0000BA   421 _PX1	=	0x00ba
                           0000B9   422 _PT0	=	0x00b9
                           0000B8   423 _PX0	=	0x00b8
                           0000EF   424 _IE_WDOG	=	0x00ef
                           0000EE   425 _IE_GPIO	=	0x00ee
                           0000ED   426 _IE_PWM_I2C	=	0x00ed
                           0000EC   427 _IE_UART1	=	0x00ec
                           0000EB   428 _IE_ADC	=	0x00eb
                           0000E9   429 _IE_USB	=	0x00e9
                           0000E8   430 _IE_SPI0	=	0x00e8
                           000087   431 _P0_7	=	0x0087
                           000086   432 _P0_6	=	0x0086
                           000085   433 _P0_5	=	0x0085
                           000084   434 _P0_4	=	0x0084
                           000083   435 _P0_3	=	0x0083
                           000082   436 _P0_2	=	0x0082
                           000081   437 _P0_1	=	0x0081
                           000080   438 _P0_0	=	0x0080
                           000081   439 _SDA0	=	0x0081
                           000080   440 _SCL0	=	0x0080
                           000083   441 _TXD_	=	0x0083
                           000082   442 _RXD_	=	0x0082
                           000085   443 _AIN13	=	0x0085
                           000084   444 _AIN12	=	0x0084
                           000083   445 _AIN11	=	0x0083
                           000082   446 _AIN10	=	0x0082
                           000081   447 _AIN9	=	0x0081
                           000080   448 _AIN8	=	0x0080
                           000097   449 _P1_7	=	0x0097
                           000096   450 _P1_6	=	0x0096
                           000095   451 _P1_5	=	0x0095
                           000094   452 _P1_4	=	0x0094
                           000093   453 _P1_3	=	0x0093
                           000092   454 _P1_2	=	0x0092
                           000091   455 _P1_1	=	0x0091
                           000090   456 _P1_0	=	0x0090
                           000097   457 _TXD1_	=	0x0097
                           000096   458 _RXD1_	=	0x0096
                           000097   459 _SCK	=	0x0097
                           000096   460 _MISO	=	0x0096
                           000095   461 _MOSI	=	0x0095
                           000094   462 _SCS	=	0x0094
                           000092   463 _INT0_	=	0x0092
                           000091   464 _T2EX	=	0x0091
                           000091   465 _CAP2	=	0x0091
                           000090   466 _T2	=	0x0090
                           000090   467 _CAP1	=	0x0090
                           000097   468 _AIN7	=	0x0097
                           000096   469 _AIN6	=	0x0096
                           000095   470 _AIN5	=	0x0095
                           000094   471 _AIN4	=	0x0094
                           000093   472 _AIN3	=	0x0093
                           000092   473 _AIN2	=	0x0092
                           000091   474 _AIN1	=	0x0091
                           000090   475 _AIN0	=	0x0090
                           0000A7   476 _P2_7	=	0x00a7
                           0000A6   477 _P2_6	=	0x00a6
                           0000A5   478 _P2_5	=	0x00a5
                           0000A4   479 _P2_4	=	0x00a4
                           0000A3   480 _P2_3	=	0x00a3
                           0000A2   481 _P2_2	=	0x00a2
                           0000A1   482 _P2_1	=	0x00a1
                           0000A0   483 _P2_0	=	0x00a0
                           0000A7   484 _TXD1	=	0x00a7
                           0000A6   485 _RXD1	=	0x00a6
                           0000A5   486 _T2EX_	=	0x00a5
                           0000A5   487 _CAP2_	=	0x00a5
                           0000A4   488 _T2_	=	0x00a4
                           0000A4   489 _CAP1_	=	0x00a4
                           0000B7   490 _P3_7	=	0x00b7
                           0000B6   491 _P3_6	=	0x00b6
                           0000B5   492 _P3_5	=	0x00b5
                           0000B4   493 _P3_4	=	0x00b4
                           0000B3   494 _P3_3	=	0x00b3
                           0000B2   495 _P3_2	=	0x00b2
                           0000B1   496 _P3_1	=	0x00b1
                           0000B0   497 _P3_0	=	0x00b0
                           0000B7   498 _SCK1	=	0x00b7
                           0000B6   499 _MISO1	=	0x00b6
                           0000B5   500 _MOSI1	=	0x00b5
                           0000B5   501 _T1	=	0x00b5
                           0000B4   502 _T0	=	0x00b4
                           0000B3   503 _INT1	=	0x00b3
                           0000B2   504 _INT0	=	0x00b2
                           0000B1   505 _TXD	=	0x00b1
                           0000B0   506 _RXD	=	0x00b0
                           0000C6   507 _P4_6	=	0x00c6
                           0000C5   508 _P4_5	=	0x00c5
                           0000C4   509 _P4_4	=	0x00c4
                           0000C3   510 _P4_3	=	0x00c3
                           0000C2   511 _P4_2	=	0x00c2
                           0000C1   512 _P4_1	=	0x00c1
                           0000C0   513 _P4_0	=	0x00c0
                           00008F   514 _TF1	=	0x008f
                           00008E   515 _TR1	=	0x008e
                           00008D   516 _TF0	=	0x008d
                           00008C   517 _TR0	=	0x008c
                           00008B   518 _IE1	=	0x008b
                           00008A   519 _IT1	=	0x008a
                           000089   520 _IE0	=	0x0089
                           000088   521 _IT0	=	0x0088
                           00009F   522 _SM0	=	0x009f
                           00009E   523 _SM1	=	0x009e
                           00009D   524 _SM2	=	0x009d
                           00009C   525 _REN	=	0x009c
                           00009B   526 _TB8	=	0x009b
                           00009A   527 _RB8	=	0x009a
                           000099   528 _TI	=	0x0099
                           000098   529 _RI	=	0x0098
                           0000CF   530 _TF2	=	0x00cf
                           0000CF   531 _CAP1F	=	0x00cf
                           0000CE   532 _EXF2	=	0x00ce
                           0000CD   533 _RCLK	=	0x00cd
                           0000CC   534 _TCLK	=	0x00cc
                           0000CB   535 _EXEN2	=	0x00cb
                           0000CA   536 _TR2	=	0x00ca
                           0000C9   537 _C_T2	=	0x00c9
                           0000C8   538 _CP_RL2	=	0x00c8
                           0000FF   539 _S0_FST_ACT	=	0x00ff
                           0000FE   540 _S0_IF_OV	=	0x00fe
                           0000FD   541 _S0_IF_FIRST	=	0x00fd
                           0000FC   542 _S0_IF_BYTE	=	0x00fc
                           0000FB   543 _S0_FREE	=	0x00fb
                           0000FA   544 _S0_T_FIFO	=	0x00fa
                           0000F8   545 _S0_R_FIFO	=	0x00f8
                           0000F7   546 _ADC_START	=	0x00f7
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable register banks
                                    549 ;--------------------------------------------------------
                                    550 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        551 	.ds 8
                                    552 ;--------------------------------------------------------
                                    553 ; internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area DSEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 	.area	OSEG    (OVR,DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; indirectly addressable internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area ISEG    (DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; absolute internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area IABS    (ABS,DATA)
                                    568 	.area IABS    (ABS,DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; bit data
                                    571 ;--------------------------------------------------------
                                    572 	.area BSEG    (BIT)
                                    573 ;--------------------------------------------------------
                                    574 ; paged external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area PSEG    (PAG,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; uninitialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XSEG    (XDATA)
      000B6F                        581 _switch_events_PARM_2:
      000B6F                        582 	.ds 1
      000B70                        583 _switch_events_PARM_3:
      000B70                        584 	.ds 1
      000B71                        585 _switch_events_row_10000_486:
      000B71                        586 	.ds 1
      000B72                        587 _generate_tick_event_last_tick_10000_489:
      000B72                        588 	.ds 2
      000B74                        589 _matrix_task_last_tick_60000_518:
      000B74                        590 	.ds 2
      000B76                        591 _matrix_task_dummy_event_70000_519:
      000B76                        592 	.ds 6
      000B7C                        593 _matrix_task_matrix_previous_10001_496:
      000B7C                        594 	.ds 16
      000B8C                        595 _matrix_task_matrix_changed_10002_497:
      000B8C                        596 	.ds 1
      000B8D                        597 _matrix_task_last_tick_60002_522:
      000B8D                        598 	.ds 2
      000B8F                        599 _matrix_task_dummy_event_70002_523:
      000B8F                        600 	.ds 6
      000B95                        601 _matrix_task_row_changes_30003_506:
      000B95                        602 	.ds 1
      000B96                        603 _matrix_task_col_mask_30004_509:
      000B96                        604 	.ds 1
      000B97                        605 _matrix_task_dummy_event_90004_515:
      000B97                        606 	.ds 6
                                    607 ;--------------------------------------------------------
                                    608 ; absolute external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XABS    (ABS,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; initialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XISEG   (XDATA)
      000E20                        615 _last_input_modification_time:
      000E20                        616 	.ds 4
      000E24                        617 _last_matrix_modification_time:
      000E24                        618 	.ds 4
      000E28                        619 _last_encoder_modification_time:
      000E28                        620 	.ds 4
      000E2C                        621 _last_pointing_device_modification_time:
      000E2C                        622 	.ds 4
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT0 (CODE)
                                    625 	.area GSINIT1 (CODE)
                                    626 	.area GSINIT2 (CODE)
                                    627 	.area GSINIT3 (CODE)
                                    628 	.area GSINIT4 (CODE)
                                    629 	.area GSINIT5 (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area CSEG    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; global & static initialisations
                                    635 ;--------------------------------------------------------
                                    636 	.area HOME    (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 	.area GSFINAL (CODE)
                                    639 	.area GSINIT  (CODE)
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'generate_tick_event'
                                    642 ;------------------------------------------------------------
                                    643 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_489'
                                    644 ;now           Allocated with name '_generate_tick_event_now_10000_489'
                                    645 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_491'
                                    646 ;------------------------------------------------------------
                                    647 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      003108 90 0B 72         [24]  648 	mov	dptr,#_generate_tick_event_last_tick_10000_489
      00310B E4               [12]  649 	clr	a
      00310C F0               [24]  650 	movx	@dptr,a
      00310D A3               [24]  651 	inc	dptr
      00310E F0               [24]  652 	movx	@dptr,a
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'matrix_task'
                                    655 ;------------------------------------------------------------
                                    656 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_518'
                                    657 ;now           Allocated with name '_matrix_task_now_60000_518'
                                    658 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_519'
                                    659 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_496'
                                    660 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_497'
                                    661 ;row           Allocated with name '_matrix_task_row_20002_498'
                                    662 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_522'
                                    663 ;now           Allocated with name '_matrix_task_now_60002_522'
                                    664 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_523'
                                    665 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_504'
                                    666 ;row           Allocated with name '_matrix_task_row_20003_505'
                                    667 ;__400030089   Allocated with name '_matrix_task___400030089_40003_506'
                                    668 ;current_row   Allocated with name '_matrix_task_current_row_30003_506'
                                    669 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_506'
                                    670 ;__500030090   Allocated with name '_matrix_task___500030090_50003_524'
                                    671 ;__500030091   Allocated with name '_matrix_task___500030091_50003_524'
                                    672 ;row           Allocated with name '_matrix_task_row_60003_525'
                                    673 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_525'
                                    674 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_509'
                                    675 ;col           Allocated with name '_matrix_task_col_40004_510'
                                    676 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_513'
                                    677 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_515'
                                    678 ;------------------------------------------------------------
                                    679 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      00310F 90 0B 74         [24]  680 	mov	dptr,#_matrix_task_last_tick_60000_518
      003112 E4               [12]  681 	clr	a
      003113 F0               [24]  682 	movx	@dptr,a
      003114 A3               [24]  683 	inc	dptr
      003115 F0               [24]  684 	movx	@dptr,a
      003116 90 0B 8D         [24]  685 	mov	dptr,#_matrix_task_last_tick_60002_522
      003119 F0               [24]  686 	movx	@dptr,a
      00311A A3               [24]  687 	inc	dptr
      00311B F0               [24]  688 	movx	@dptr,a
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    700 ;------------------------------------------------------------
                                    701 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    702 ;------------------------------------------------------------
                                    703 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function last_matrix_activity_trigger
                                    714 ;	-----------------------------------------
      00941D                        715 _last_matrix_activity_trigger:
                                    716 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      00941D 12 49 77         [24]  717 	lcall	_timer_read32
      009420 12 4F 84         [24]  718 	lcall	_ak820_outline_0064
      009423 90 0E 20         [24]  719 	mov	dptr,#_last_input_modification_time
      009426 12 91 31         [24]  720 	lcall	_ak820_outline_0011
      009429 90 0E 24         [24]  721 	mov	dptr,#_last_matrix_modification_time
      00942C 12 91 31         [24]  722 	lcall	_ak820_outline_0011
                                    723 ;	quantum/keyboard.c:191: }
      00942F 22               [24]  724 	ret
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function last_encoder_activity_trigger
                                    731 ;	-----------------------------------------
      009430                        732 _last_encoder_activity_trigger:
                                    733 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      009430 12 49 77         [24]  734 	lcall	_timer_read32
      009433 12 4F 84         [24]  735 	lcall	_ak820_outline_0064
      009436 90 0E 20         [24]  736 	mov	dptr,#_last_input_modification_time
      009439 12 91 31         [24]  737 	lcall	_ak820_outline_0011
      00943C 90 0E 28         [24]  738 	mov	dptr,#_last_encoder_modification_time
      00943F 12 91 31         [24]  739 	lcall	_ak820_outline_0011
                                    740 ;	quantum/keyboard.c:202: }
      009442 22               [24]  741 	ret
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    744 ;------------------------------------------------------------
                                    745 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function keyboard_post_init_kb
                                    748 ;	-----------------------------------------
      009443                        749 _keyboard_post_init_kb:
                                    750 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    751 ;	quantum/keyboard.c:346: }
      009443 02 98 C7         [24]  752 	ljmp	_keyboard_post_init_user
                                    753 ;------------------------------------------------------------
                                    754 ;Allocation info for local variables in function 'matrix_can_read'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function matrix_can_read
                                    759 ;	-----------------------------------------
      009446                        760 _matrix_can_read:
                                    761 ;	quantum/keyboard.c:353: return true;
      009446 75 82 01         [24]  762 	mov	dpl, #0x01
                                    763 ;	quantum/keyboard.c:354: }
      009449 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'keyboard_setup'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function keyboard_setup
                                    771 ;	-----------------------------------------
      00944A                        772 _keyboard_setup:
                                    773 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      00944A 90 9A 2B         [24]  774 	mov	dptr,#_sendchar
      00944D 12 99 FF         [24]  775 	lcall	_print_set_sendchar
                                    776 ;	quantum/keyboard.c:363: eeprom_driver_init();
      009450 12 3E 71         [24]  777 	lcall	_eeprom_driver_init
                                    778 ;	quantum/keyboard.c:366: vial_init();
                                    779 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    780 ;	quantum/keyboard.c:373: }
      009453 02 B1 00         [24]  781 	ljmp	_vial_init
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'is_keyboard_master'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function is_keyboard_master
                                    788 ;	-----------------------------------------
      009456                        789 _is_keyboard_master:
                                    790 ;	quantum/keyboard.c:382: return true;
      009456 75 82 01         [24]  791 	mov	dpl, #0x01
                                    792 ;	quantum/keyboard.c:383: }
      009459 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'is_keyboard_left'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function should_process_keypress
                                    800 ;	-----------------------------------------
      00945A                        801 _should_process_keypress:
                                    802 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    803 ;	quantum/keyboard.c:402: }
      00945A 02 94 56         [24]  804 	ljmp	_is_keyboard_master
                                    805 ;------------------------------------------------------------
                                    806 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    809 ;	-----------------------------------------
                                    810 ;	 function housekeeping_task
                                    811 ;	-----------------------------------------
      00945D                        812 _housekeeping_task:
                                    813 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    814 ;	quantum/keyboard.c:425: }
      00945D 22               [24]  815 	ret
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'quantum_init'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function quantum_init
                                    822 ;	-----------------------------------------
      00945E                        823 _quantum_init:
                                    824 ;	quantum/keyboard.c:432: magic();
      00945E 12 82 7B         [24]  825 	lcall	_magic
                                    826 ;	quantum/keyboard.c:433: led_init_ports();
      009461 12 99 95         [24]  827 	lcall	_led_init_ports
                                    828 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    829 ;	quantum/keyboard.c:452: }
      009464 02 51 32         [24]  830 	ljmp	_rgb_matrix_init
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'keyboard_init'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function keyboard_init
                                    837 ;	-----------------------------------------
      009467                        838 _keyboard_init:
                                    839 ;	quantum/keyboard.c:459: timer_init();
      009467 12 49 39         [24]  840 	lcall	_timer_init
                                    841 ;	quantum/keyboard.c:462: via_init();
      00946A 12 A9 CC         [24]  842 	lcall	_via_init
                                    843 ;	quantum/keyboard.c:468: encoder_init();
      00946D 12 91 78         [24]  844 	lcall	_encoder_init
                                    845 ;	quantum/keyboard.c:470: matrix_init();
      009470 12 5A C2         [24]  846 	lcall	_matrix_init
                                    847 ;	quantum/keyboard.c:471: quantum_init();
      009473 12 94 5E         [24]  848 	lcall	_quantum_init
                                    849 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    850 ;	quantum/keyboard.c:522: }
      009476 02 94 43         [24]  851 	ljmp	_keyboard_post_init_kb
                                    852 ;------------------------------------------------------------
                                    853 ;Allocation info for local variables in function 'switch_events'
                                    854 ;------------------------------------------------------------
                                    855 ;col           Allocated with name '_switch_events_PARM_2'
                                    856 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    857 ;row           Allocated with name '_switch_events_row_10000_486'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function switch_events
                                    862 ;	-----------------------------------------
      009479                        863 _switch_events:
      009479 E5 82            [12]  864 	mov	a,dpl
      00947B 90 0B 71         [24]  865 	mov	dptr,#_switch_events_row_10000_486
      00947E F0               [24]  866 	movx	@dptr,a
                                    867 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      00947F E0               [24]  868 	movx	a,@dptr
      009480 FF               [12]  869 	mov	r7,a
      009481 90 0B 6F         [24]  870 	mov	dptr,#_switch_events_PARM_2
      009484 E0               [24]  871 	movx	a,@dptr
      009485 FE               [12]  872 	mov	r6,a
      009486 90 0B 70         [24]  873 	mov	dptr,#_switch_events_PARM_3
      009489 E0               [24]  874 	movx	a,@dptr
      00948A FD               [12]  875 	mov	r5,a
      00948B 90 07 24         [24]  876 	mov	dptr,#_process_rgb_matrix_PARM_2
      00948E EE               [12]  877 	mov	a,r6
      00948F F0               [24]  878 	movx	@dptr,a
      009490 90 07 25         [24]  879 	mov	dptr,#_process_rgb_matrix_PARM_3
      009493 ED               [12]  880 	mov	a,r5
      009494 F0               [24]  881 	movx	@dptr,a
      009495 8F 82            [24]  882 	mov	dpl, r7
                                    883 ;	quantum/keyboard.c:536: }
      009497 02 55 19         [24]  884 	ljmp	_process_rgb_matrix
                                    885 ;------------------------------------------------------------
                                    886 ;Allocation info for local variables in function 'generate_tick_event'
                                    887 ;------------------------------------------------------------
                                    888 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_489'
                                    889 ;now           Allocated with name '_generate_tick_event_now_10000_489'
                                    890 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_491'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function matrix_task
                                    895 ;	-----------------------------------------
      00949A                        896 _matrix_task:
                                    897 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      00949A 12 94 46         [24]  898 	lcall	_matrix_can_read
      00949D E5 82            [12]  899 	mov	a, dpl
      00949F 70 56            [24]  900 	jnz	00102$
                                    901 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      0094A1 12 49 A8         [24]  902 	lcall	_timer_read
      0094A4 12 43 D5         [24]  903 	lcall	_ak820_outline_0131
                                    904 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      0094A7 90 0B 74         [24]  905 	mov	dptr,#_matrix_task_last_tick_60000_518
      0094AA 12 38 DA         [24]  906 	lcall	_ak820_outline_0076
      0094AD EE               [12]  907 	mov	a,r6
      0094AE C3               [12]  908 	clr	c
      0094AF 9C               [12]  909 	subb	a,r4
      0094B0 FC               [12]  910 	mov	r4,a
      0094B1 EF               [12]  911 	mov	a,r7
      0094B2 9D               [12]  912 	subb	a,r5
      0094B3 4C               [12]  913 	orl	a,r4
      0094B4 60 3D            [24]  914 	jz	00120$
                                    915 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      0094B6 90 0B 76         [24]  916 	mov	dptr,#_matrix_task_dummy_event_70000_519
      0094B9 E4               [12]  917 	clr	a
      0094BA F0               [24]  918 	movx	@dptr,a
      0094BB 90 0B 77         [24]  919 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0001)
      0094BE F0               [24]  920 	movx	@dptr,a
      0094BF 12 49 A8         [24]  921 	lcall	_timer_read
      0094C2 12 43 F4         [24]  922 	lcall	_ak820_outline_0193
      0094C5 90 0B 78         [24]  923 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0002)
      0094C8 12 38 E6         [24]  924 	lcall	_ak820_outline_0087
      0094CB 90 0B 7A         [24]  925 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0004)
      0094CE E4               [12]  926 	clr	a
      0094CF F0               [24]  927 	movx	@dptr,a
      0094D0 90 0B 7B         [24]  928 	mov	dptr,#(_matrix_task_dummy_event_70000_519 + 0x0005)
      0094D3 F0               [24]  929 	movx	@dptr,a
                                    930 ;	quantum/keyboard.c:549: action_exec(dummy_event);
      0094D4 90 0D C2         [24]  931 	mov	dptr,#___memcpy_PARM_2
      0094D7 74 76            [12]  932 	mov	a,#_matrix_task_dummy_event_70000_519
      0094D9 F0               [24]  933 	movx	@dptr,a
      0094DA 74 0B            [12]  934 	mov	a,#(_matrix_task_dummy_event_70000_519 >> 8)
      0094DC 12 96 83         [24]  935 	lcall	_ak820_outline_0012
      0094DF C0 07            [24]  936 	push	ar7
      0094E1 C0 06            [24]  937 	push	ar6
      0094E3 12 BC 07         [24]  938 	lcall	___memcpy
      0094E6 12 71 15         [24]  939 	lcall	_action_exec
      0094E9 D0 06            [24]  940 	pop	ar6
      0094EB D0 07            [24]  941 	pop	ar7
                                    942 ;	quantum/keyboard.c:550: last_tick = now;
      0094ED 90 0B 74         [24]  943 	mov	dptr,#_matrix_task_last_tick_60000_518
      0094F0 12 48 F9         [24]  944 	lcall	_ak820_outline_0068
                                    945 ;	quantum/keyboard.c:563: generate_tick_event();
      0094F3                        946 00120$:
                                    947 ;	quantum/keyboard.c:564: return false;
      0094F3 75 82 00         [24]  948 	mov	dpl, #0x00
      0094F6 22               [24]  949 	ret
      0094F7                        950 00102$:
                                    951 ;	quantum/keyboard.c:569: matrix_scan();
      0094F7 12 5A EB         [24]  952 	lcall	_matrix_scan
                                    953 ;	quantum/keyboard.c:573: vial_unlock_task();
      0094FA 12 B0 66         [24]  954 	lcall	_vial_unlock_task
                                    955 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      0094FD 90 0B 8C         [24]  956 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      009500 E4               [12]  957 	clr	a
      009501 F0               [24]  958 	movx	@dptr,a
                                    959 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009502 FF               [12]  960 	mov	r7,a
      009503                        961 00127$:
      009503 BF 10 00         [24]  962 	cjne	r7,#0x10,00247$
      009506                        963 00247$:
      009506 50 1F            [24]  964 	jnc	00103$
      009508 90 0B 8C         [24]  965 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      00950B E0               [24]  966 	movx	a,@dptr
      00950C 70 19            [24]  967 	jnz	00103$
                                    968 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      00950E EF               [12]  969 	mov	a,r7
      00950F 12 96 97         [24]  970 	lcall	_ak820_outline_0077
      009512 E0               [24]  971 	movx	a,@dptr
      009513 FE               [12]  972 	mov	r6,a
      009514 8F 82            [24]  973 	mov	dpl, r7
      009516 12 5A 77         [24]  974 	lcall	_matrix_get_row
      009519 E5 82            [12]  975 	mov	a,dpl
      00951B 6E               [12]  976 	xrl	a,r6
                                    977 ;	assignBit
      00951C 90 0B 8C         [24]  978 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      00951F 24 FF            [12]  979 	add	a,#0xff
      009521 E4               [12]  980 	clr	a
      009522 33               [12]  981 	rlc	a
      009523 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009524 0F               [12]  984 	inc	r7
      009525 80 DC            [24]  985 	sjmp	00127$
      009527                        986 00103$:
                                    987 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      009527 90 0B 8C         [24]  988 	mov	dptr,#_matrix_task_matrix_changed_10002_497
      00952A E0               [24]  989 	movx	a,@dptr
      00952B 70 56            [24]  990 	jnz	00105$
                                    991 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      00952D 12 49 A8         [24]  992 	lcall	_timer_read
      009530 12 43 D5         [24]  993 	lcall	_ak820_outline_0131
                                    994 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009533 90 0B 8D         [24]  995 	mov	dptr,#_matrix_task_last_tick_60002_522
      009536 12 38 DA         [24]  996 	lcall	_ak820_outline_0076
      009539 EE               [12]  997 	mov	a,r6
      00953A C3               [12]  998 	clr	c
      00953B 9C               [12]  999 	subb	a,r4
      00953C FC               [12] 1000 	mov	r4,a
      00953D EF               [12] 1001 	mov	a,r7
      00953E 9D               [12] 1002 	subb	a,r5
      00953F 4C               [12] 1003 	orl	a,r4
      009540 60 3D            [24] 1004 	jz	00123$
                                   1005 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009542 90 0B 8F         [24] 1006 	mov	dptr,#_matrix_task_dummy_event_70002_523
      009545 E4               [12] 1007 	clr	a
      009546 F0               [24] 1008 	movx	@dptr,a
      009547 90 0B 90         [24] 1009 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0001)
      00954A F0               [24] 1010 	movx	@dptr,a
      00954B 12 49 A8         [24] 1011 	lcall	_timer_read
      00954E 12 43 F4         [24] 1012 	lcall	_ak820_outline_0193
      009551 90 0B 91         [24] 1013 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0002)
      009554 12 38 E6         [24] 1014 	lcall	_ak820_outline_0087
      009557 90 0B 93         [24] 1015 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0004)
      00955A E4               [12] 1016 	clr	a
      00955B F0               [24] 1017 	movx	@dptr,a
      00955C 90 0B 94         [24] 1018 	mov	dptr,#(_matrix_task_dummy_event_70002_523 + 0x0005)
      00955F F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	quantum/keyboard.c:549: action_exec(dummy_event);
      009560 90 0D C2         [24] 1021 	mov	dptr,#___memcpy_PARM_2
      009563 74 8F            [12] 1022 	mov	a,#_matrix_task_dummy_event_70002_523
      009565 F0               [24] 1023 	movx	@dptr,a
      009566 74 0B            [12] 1024 	mov	a,#(_matrix_task_dummy_event_70002_523 >> 8)
      009568 12 96 83         [24] 1025 	lcall	_ak820_outline_0012
      00956B C0 07            [24] 1026 	push	ar7
      00956D C0 06            [24] 1027 	push	ar6
      00956F 12 BC 07         [24] 1028 	lcall	___memcpy
      009572 12 71 15         [24] 1029 	lcall	_action_exec
      009575 D0 06            [24] 1030 	pop	ar6
      009577 D0 07            [24] 1031 	pop	ar7
                                   1032 ;	quantum/keyboard.c:550: last_tick = now;
      009579 90 0B 8D         [24] 1033 	mov	dptr,#_matrix_task_last_tick_60002_522
      00957C 12 48 F9         [24] 1034 	lcall	_ak820_outline_0068
                                   1035 ;	quantum/keyboard.c:584: generate_tick_event();
      00957F                       1036 00123$:
                                   1037 ;	quantum/keyboard.c:585: return matrix_changed;
      00957F 75 82 00         [24] 1038 	mov	dpl, #0x00
      009582 22               [24] 1039 	ret
      009583                       1040 00105$:
                                   1041 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      009583 90 0E 34         [24] 1042 	mov	dptr,#_debug_config
      009586 E0               [24] 1043 	movx	a,@dptr
      009587 30 E1 03         [24] 1044 	jnb	acc.1,00107$
                                   1045 ;	quantum/keyboard.c:589: matrix_print();
      00958A 12 5B 17         [24] 1046 	lcall	_matrix_print
      00958D                       1047 00107$:
                                   1048 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      00958D 12 94 5A         [24] 1049 	lcall	_should_process_keypress
      009590 AF 82            [24] 1050 	mov	r7, dpl
                                   1051 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009592 7E 00            [12] 1052 	mov	r6,#0x00
      009594                       1053 00133$:
      009594 BE 10 00         [24] 1054 	cjne	r6,#0x10,00253$
      009597                       1055 00253$:
      009597 40 03            [24] 1056 	jc	00254$
      009599 02 96 5F         [24] 1057 	ljmp	00117$
      00959C                       1058 00254$:
                                   1059 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      00959C 8E 82            [24] 1060 	mov	dpl, r6
      00959E 12 5A 77         [24] 1061 	lcall	_matrix_get_row
      0095A1 AD 82            [24] 1062 	mov	r5, dpl
                                   1063 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      0095A3 EE               [12] 1064 	mov	a,r6
      0095A4 12 96 97         [24] 1065 	lcall	_ak820_outline_0077
      0095A7 E0               [24] 1066 	movx	a,@dptr
      0095A8 FC               [12] 1067 	mov	r4,a
      0095A9 ED               [12] 1068 	mov	a,r5
      0095AA 62 04            [12] 1069 	xrl	ar4,a
      0095AC 90 0B 95         [24] 1070 	mov	dptr,#_matrix_task_row_changes_30003_506
      0095AF EC               [12] 1071 	mov	a,r4
      0095B0 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      0095B1 EC               [12] 1074 	mov	a,r4
      0095B2 70 03            [24] 1075 	jnz	00255$
      0095B4 02 96 5B         [24] 1076 	ljmp	00116$
      0095B7                       1077 00255$:
                                   1078 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      0095B7 90 0B 96         [24] 1079 	mov	dptr,#_matrix_task_col_mask_30004_509
      0095BA 74 01            [12] 1080 	mov	a,#0x01
      0095BC F0               [24] 1081 	movx	@dptr,a
                                   1082 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      0095BD 7C 00            [12] 1083 	mov	r4,#0x00
      0095BF                       1084 00130$:
      0095BF BC 08 00         [24] 1085 	cjne	r4,#0x08,00256$
      0095C2                       1086 00256$:
      0095C2 40 03            [24] 1087 	jc	00257$
      0095C4 02 96 55         [24] 1088 	ljmp	00115$
      0095C7                       1089 00257$:
                                   1090 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      0095C7 90 0B 95         [24] 1091 	mov	dptr,#_matrix_task_row_changes_30003_506
      0095CA E0               [24] 1092 	movx	a,@dptr
      0095CB FB               [12] 1093 	mov	r3,a
      0095CC 90 0B 96         [24] 1094 	mov	dptr,#_matrix_task_col_mask_30004_509
      0095CF E0               [24] 1095 	movx	a,@dptr
      0095D0 FA               [12] 1096 	mov	r2,a
      0095D1 5B               [12] 1097 	anl	a,r3
      0095D2 70 03            [24] 1098 	jnz	00258$
      0095D4 02 96 4A         [24] 1099 	ljmp	00131$
      0095D7                       1100 00258$:
                                   1101 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      0095D7 ED               [12] 1102 	mov	a,r5
      0095D8 52 02            [12] 1103 	anl	ar2,a
                                   1104 ;	assignBit
      0095DA EA               [12] 1105 	mov	a,r2
      0095DB 24 FF            [12] 1106 	add	a,#0xff
      0095DD E4               [12] 1107 	clr	a
      0095DE 33               [12] 1108 	rlc	a
      0095DF FA               [12] 1109 	mov	r2,a
                                   1110 ;	quantum/keyboard.c:607: if (process_keypress) {
      0095E0 EF               [12] 1111 	mov	a,r7
      0095E1 60 48            [24] 1112 	jz	00112$
                                   1113 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      0095E3 90 0B 97         [24] 1114 	mov	dptr,#_matrix_task_dummy_event_90004_515
      0095E6 EC               [12] 1115 	mov	a,r4
      0095E7 F0               [24] 1116 	movx	@dptr,a
      0095E8 90 0B 98         [24] 1117 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0001)
      0095EB EE               [12] 1118 	mov	a,r6
      0095EC F0               [24] 1119 	movx	@dptr,a
      0095ED 12 49 A8         [24] 1120 	lcall	_timer_read
      0095F0 A9 82            [24] 1121 	mov	r1, dpl
      0095F2 AB 83            [24] 1122 	mov	r3, dph
      0095F4 90 0B 99         [24] 1123 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0002)
      0095F7 E9               [12] 1124 	mov	a,r1
      0095F8 12 78 22         [24] 1125 	lcall	_ak820_outline_0194
      0095FB 90 0B 9B         [24] 1126 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0004)
      0095FE 74 01            [12] 1127 	mov	a,#0x01
      009600 F0               [24] 1128 	movx	@dptr,a
      009601 90 0B 9C         [24] 1129 	mov	dptr,#(_matrix_task_dummy_event_90004_515 + 0x0005)
      009604 EA               [12] 1130 	mov	a,r2
      009605 F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	quantum/keyboard.c:610: action_exec(dummy_event);
      009606 90 0D C2         [24] 1133 	mov	dptr,#___memcpy_PARM_2
      009609 74 97            [12] 1134 	mov	a,#_matrix_task_dummy_event_90004_515
      00960B F0               [24] 1135 	movx	@dptr,a
      00960C 74 0B            [12] 1136 	mov	a,#(_matrix_task_dummy_event_90004_515 >> 8)
      00960E 12 96 83         [24] 1137 	lcall	_ak820_outline_0012
      009611 C0 07            [24] 1138 	push	ar7
      009613 C0 06            [24] 1139 	push	ar6
      009615 C0 05            [24] 1140 	push	ar5
      009617 C0 04            [24] 1141 	push	ar4
      009619 C0 02            [24] 1142 	push	ar2
      00961B 12 BC 07         [24] 1143 	lcall	___memcpy
      00961E 12 71 15         [24] 1144 	lcall	_action_exec
      009621 D0 02            [24] 1145 	pop	ar2
      009623 D0 04            [24] 1146 	pop	ar4
      009625 D0 05            [24] 1147 	pop	ar5
      009627 D0 06            [24] 1148 	pop	ar6
      009629 D0 07            [24] 1149 	pop	ar7
      00962B                       1150 00112$:
                                   1151 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      00962B 90 0B 6F         [24] 1152 	mov	dptr,#_switch_events_PARM_2
      00962E EC               [12] 1153 	mov	a,r4
      00962F F0               [24] 1154 	movx	@dptr,a
      009630 90 0B 70         [24] 1155 	mov	dptr,#_switch_events_PARM_3
      009633 EA               [12] 1156 	mov	a,r2
      009634 F0               [24] 1157 	movx	@dptr,a
      009635 8E 82            [24] 1158 	mov	dpl, r6
      009637 C0 07            [24] 1159 	push	ar7
      009639 C0 06            [24] 1160 	push	ar6
      00963B C0 05            [24] 1161 	push	ar5
      00963D C0 04            [24] 1162 	push	ar4
      00963F 12 94 79         [24] 1163 	lcall	_switch_events
      009642 D0 04            [24] 1164 	pop	ar4
      009644 D0 05            [24] 1165 	pop	ar5
      009646 D0 06            [24] 1166 	pop	ar6
      009648 D0 07            [24] 1167 	pop	ar7
      00964A                       1168 00131$:
                                   1169 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      00964A 0C               [12] 1170 	inc	r4
      00964B 90 0B 96         [24] 1171 	mov	dptr,#_matrix_task_col_mask_30004_509
      00964E E0               [24] 1172 	movx	a,@dptr
      00964F 25 E0            [12] 1173 	add	a,acc
      009651 F0               [24] 1174 	movx	@dptr,a
      009652 02 95 BF         [24] 1175 	ljmp	00130$
      009655                       1176 00115$:
                                   1177 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      009655 EE               [12] 1178 	mov	a,r6
      009656 12 96 97         [24] 1179 	lcall	_ak820_outline_0077
      009659 ED               [12] 1180 	mov	a,r5
      00965A F0               [24] 1181 	movx	@dptr,a
      00965B                       1182 00116$:
                                   1183 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00965B 0E               [12] 1184 	inc	r6
      00965C 02 95 94         [24] 1185 	ljmp	00133$
      00965F                       1186 00117$:
                                   1187 ;	quantum/keyboard.c:620: return matrix_changed;
      00965F 75 82 01         [24] 1188 	mov	dpl, #0x01
                                   1189 ;	quantum/keyboard.c:621: }
      009662 22               [24] 1190 	ret
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'quantum_task'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function quantum_task
                                   1197 ;	-----------------------------------------
      009663                       1198 _quantum_task:
                                   1199 ;	quantum/keyboard.c:694: caps_word_task();
                                   1200 ;	quantum/keyboard.c:700: }
      009663 02 2E FF         [24] 1201 	ljmp	_caps_word_task
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'keyboard_task'
                                   1204 ;------------------------------------------------------------
                                   1205 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_530'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function keyboard_task
                                   1210 ;	-----------------------------------------
      009666                       1211 _keyboard_task:
                                   1212 ;	quantum/keyboard.c:705: if (matrix_task()) {
      009666 12 94 9A         [24] 1213 	lcall	_matrix_task
      009669 E5 82            [12] 1214 	mov	a, dpl
      00966B 60 03            [24] 1215 	jz	00102$
                                   1216 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      00966D 12 94 1D         [24] 1217 	lcall	_last_matrix_activity_trigger
                                   1218 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      009670                       1219 00102$:
                                   1220 ;	quantum/keyboard.c:710: quantum_task();
      009670 12 96 63         [24] 1221 	lcall	_quantum_task
                                   1222 ;	quantum/keyboard.c:724: rgb_matrix_task();
      009673 12 52 8F         [24] 1223 	lcall	_rgb_matrix_task
                                   1224 ;	quantum/keyboard.c:734: if (encoder_read()) {
      009676 12 93 6D         [24] 1225 	lcall	_encoder_read
      009679 E5 82            [12] 1226 	mov	a, dpl
      00967B 60 03            [24] 1227 	jz	00104$
                                   1228 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      00967D 12 94 30         [24] 1229 	lcall	_last_encoder_activity_trigger
                                   1230 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      009680                       1231 00104$:
                                   1232 ;	quantum/keyboard.c:790: led_task();
                                   1233 ;	quantum/keyboard.c:791: }
      009680 02 99 B7         [24] 1234 	ljmp	_led_task
                                   1235 	.area CSEG    (CODE)
                                   1236 	.area CONST   (CODE)
                                   1237 	.area XINIT   (CODE)
      00C51A                       1238 __xinit__last_input_modification_time:
      00C51A 00 00 00 00           1239 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C51E                       1240 __xinit__last_matrix_modification_time:
      00C51E 00 00 00 00           1241 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C522                       1242 __xinit__last_encoder_modification_time:
      00C522 00 00 00 00           1243 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C526                       1244 __xinit__last_pointing_device_modification_time:
      00C526 00 00 00 00           1245 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1246 	.area CABS    (ABS,CODE)
                                   1247 
                                   1248 ; Experimental exact instruction outlining.
                                   1249 	.globl _ak820_outline_0011
                                   1250 	.globl _ak820_outline_0012
                                   1251 	.globl _ak820_outline_0064
                                   1252 	.globl _ak820_outline_0068
                                   1253 	.globl _ak820_outline_0076
                                   1254 	.globl _ak820_outline_0077
                                   1255 	.globl _ak820_outline_0087
                                   1256 	.globl _ak820_outline_0131
                                   1257 	.globl _ak820_outline_0193
                                   1258 	.globl _ak820_outline_0194
                                   1259 
                                   1260 	.area CSEG (CODE)
                                   1261 ; function ak820_outline_0012
      009683                       1262 _ak820_outline_0012:
      009683 A3               [24] 1263 	inc	dptr
      009684 F0               [24] 1264 	movx	@dptr,a
      009685 E4               [12] 1265 	clr	a
      009686 A3               [24] 1266 	inc	dptr
      009687 F0               [24] 1267 	movx	@dptr,a
      009688 90 0D C5         [24] 1268 	mov	dptr,#___memcpy_PARM_3
      00968B 74 06            [12] 1269 	mov	a,#0x06
      00968D F0               [24] 1270 	movx	@dptr,a
      00968E E4               [12] 1271 	clr	a
      00968F A3               [24] 1272 	inc	dptr
      009690 F0               [24] 1273 	movx	@dptr,a
      009691 90 08 10         [24] 1274 	mov	dptr,#_action_exec_PARM_1
      009694 F5 F0            [12] 1275 	mov	b,a
      009696 22               [24] 1276 	ret
                                   1277 
                                   1278 	.area CSEG (CODE)
                                   1279 ; function ak820_outline_0077
      009697                       1280 _ak820_outline_0077:
      009697 24 7C            [12] 1281 	add	a,#_matrix_task_matrix_previous_10001_496
      009699 F5 82            [12] 1282 	mov	dpl,a
      00969B E4               [12] 1283 	clr	a
      00969C 34 0B            [12] 1284 	addc	a,#(_matrix_task_matrix_previous_10001_496>>8)
      00969E F5 83            [12] 1285 	mov	dph,a
      0096A0 22               [24] 1286 	ret
